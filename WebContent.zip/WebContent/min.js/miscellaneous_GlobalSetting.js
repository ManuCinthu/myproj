function loadGlobalSettingDetails(){$.ajax({type:"GET",url:"/repopro/web/globalsettings",dataType:"json",async:!1,cache:!1,complete:function(data){var json=JSON.parse(data.responseText);if(json.result[0].globalLdapSettingFlag==1){$("#radioBtn_LDAP").prop('checked',!0);$("#radioBtn_NativeDB").prop('checked',!1)}
else{$("#radioBtn_LDAP").prop('checked',!1);$("#radioBtn_NativeDB").prop('checked',!0)}
if(json.result[0].globalLockSettingFlag==1){$('#chk_EnblConcurrentEditLck').prop('checked',!0);$('#lockRelease').prop('disabled',!1)}else{$('#chk_EnblConcurrentEditLck').prop('checked',!1);$('#lockRelease').prop('disabled',!0)}
if(json.result[0].ssoFlag==1){$('#chk_SAML').prop('checked',!0)}else{$('#cchk_SAML').prop('checked',!1)}
if(json.result[0].circularImage==1){$('#themeCircle').prop('checked',!0)}else{$('#themeCircle').prop('checked',!1)}
if(json.result[0].invertedImage==1){$('#invertImage').prop('checked',!0)}else{$('#invertImage').prop('checked',!1)}
if(json.result[0].crossSiteScriptProtection==1){$("#chk_crossBrowserScripting").prop('checked',!0)}
else{$("#chk_crossBrowserScripting").prop('checked',!1)}
if(json.result[0].guestAccess==1){$("#chk_guestAccessPermission").prop('checked',!0)}
else{$("#chk_guestAccessPermission").prop('checked',!1)}
if(json.result[0].mechanism=="Native"){$("#radioBtn_restNative").prop('checked',!0);$("#radioBtn_restoAuth").prop('checked',!1)}
else{$("#radioBtn_restNative").prop('checked',!1);$("#radioBtn_restoAuth").prop('checked',!0)}
$('#lockRelease').val(json.result[0].lockTime);$('#showHideLoader').removeClass('active')}})}
$('#chk_EnblConcurrentEditLck').on('change',function(){var isChecked=$(this).is(':checked');if(isChecked){$('#lockRelease').prop('disabled',!1)}else{$('#lockRelease').prop('disabled',!0)}});function saveGlobalSettingData(){var ldapSettingFlag="";var lockSettingFlag="";var crossBrowserScripting="";var themeCircleFlag,invertImageFlag;var guestAccess="";var flag=!0;$(".errLockReleaseTime").hide();$(".errGlobalLockTime").hide();if($("#radioBtn_LDAP").is(':checked')){ldapSettingFlag=1}else{ldapSettingFlag=0}
if($("#chk_EnblConcurrentEditLck").is(':checked')){lockSettingFlag=1}else{lockSettingFlag=0}
if($("#chk_SAML").is(':checked')){SAMLFlag=1}else{SAMLFlag=0}
if($("#themeCircle").is(':checked')){themeCircleFlag=1}else{themeCircleFlag=0}
if($("#invertImage").is(':checked')){invertImageFlag=1}else{invertImageFlag=0}
if($("#chk_crossBrowserScripting").is(':checked')){crossBrowserScripting=1}else{crossBrowserScripting=0}
if($("#chk_guestAccessPermission").is(':checked')){guestAccess=1}else{guestAccess=0}
var globalLocktime=$('#lockRelease').val().trim();var specialCharRegexStr2=/^[0-9]*(?:\\d{1,4})?$/;var lockTimeIsValid=specialCharRegexStr2.test(globalLocktime);if(lockSettingFlag==1){if(globalLocktime==null||globalLocktime==""){$('#lockRelease').parent().addClass("error");$("#errIdGlobalLockTime").show();$(".errLockReleaseTime").hide();flag=!1}
else if(!lockTimeIsValid){$('#lockRelease').parent().addClass("error");$(".errLockReleaseTime").show().html('Please enter only positive whole number');$("#errIdGlobalLockTime").hide();flag=!1}else if(globalLocktime==0){$('#lockRelease').parent().addClass("error");$("#errIdGlobalLockTime").show().html('Please provide valid lock release time');flag=!1}else{$('#lockRelease').parent().removeClass("error");$("#errIdGlobalLockTime").hide();$(".errLockReleaseTime").hide();flag=!0}}else{$(".errLockReleaseTime").hide();$(".errGlobalLockTime").hide()}
var selectedData="";if($("#radioBtn_restNative").is(':checked')){selectedData="Native"}else{selectedData="oAuth"}
if(flag){var data={"globalLdapSettingFlag":ldapSettingFlag,"globalLockSettingFlag":lockSettingFlag,"lockTime":globalLocktime,"ssoFlag":SAMLFlag,"circularImage":themeCircleFlag,"invertedImage":invertImageFlag,"crossSiteScriptProtection":crossBrowserScripting,"guestAccess":guestAccess,"mechanism":selectedData}
$.ajax({type:"PUT",url:"/repopro/web/globalsettings",contentType:"application/json",dataType:"json",data:JSON.stringify(data),async:!1,cache:!1,complete:function(data){var json=JSON.parse(data.responseText);if(json.status=="SUCCESS"){if(themeCircleFlag==1){circularThemeColoredIcon=!0}else{circularThemeColoredIcon=!1}
if(invertImageFlag==1){invertAssetIconFlag=!0}else{invertAssetIconFlag=!1}
notifyMessage("Global Setting","Global settings updated","success")}
else{notifyMessage("Global Setting","Error attempting to update global settings","fail")}}})}}