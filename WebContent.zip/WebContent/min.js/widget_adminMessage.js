appendData="";function loadWidgetAdminMessageDetails(){$.ajax({type:"GET",url:"/repopro/web/message",dataType:"json",async:!1,complete:function(data){var json=JSON.parse(data.responseText);if(json.status=="SUCCESS"){if(localStorage.getItem("showAdminData")=="true"){$('#widgetAdminMessageContent').html(json.result[0].adminMessage);$('#adminMessageWidget').show()}else{$('#adminMessageWidget').hide()}
if(json.result[0].ison==1){if(localStorage.getItem("bannerDataForSecssion")=="true"){localStorage.setItem("showBannerData","true")}else{localStorage.setItem("showBannerData","false")}
$("#announcementCard").css('display','none');localStorage.setItem("marqueText",json.result[0].maintenance)}
else if(json.result[0].ison==0){localStorage.setItem("showBannerData","false")
$("#announcementCard").css('display','none')}
showBannerText()}
$('#showHideLoader').removeClass('active')}})}
function hideAdminMessageSecssion(){$('#adminMessageWidget').hide();localStorage.setItem("showAdminData","false")}