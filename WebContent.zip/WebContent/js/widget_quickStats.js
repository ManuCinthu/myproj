appendData = "";

//get quick stats
function loadQuickStatsData(){
	
	var url;
	
	if(loggedInUserName == "guest"){
		url = "/repopro/web/quickStat/getQuickStat?userName=roleAnonymous";
	}
	else{
		url = "/repopro/web/quickStat/getQuickStat?userName="+loggedInUserName;
	}
	
	$.ajax({ 
		type : "GET",
		url : url,
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){

				if(json.result == "" || json.result == null){
					$("#quickStatsStatistics").html('<div class="ui fluid message" style="width: 100%;">No quick statistics data yet</div>');
				}
				else{
					
					$.each(json.result, function(i) {
						appendData = getQuickStatsData(json.result[i].assetName, json.result[i].assetInstanceVersionCount, json.result[i].assetId, json.result[i].assetIconImageName);
						$("#quickStatsStatistics").append(appendData);
						$('.quickStatsStyle').hide();
					});
					
					 $('.quickStatsStyle')
					  .transition({
					    animation : 'scale in',
					    reverse   : false,
					    interval  : 175
					  });
				}

			}
			else{
				$("#quickStatsStatistics").html('<div class="ui fluid message" style="width: 100%;">No quick statistics data yet</div>');
			}
		}
	});
}

//get quick stats
function  getQuickStatsData(assetName,assetInstanceVersionCount,assetId,assetIconImageName){
	appendData = "";
	appendData += '<div class="quickStatsStyle statistic" onclick="loadbrowserPageForAsset('+assetId+',\''+assetName+'\')">';
	appendData += '<div class="value quickStatsValueStyle">';
	
	/*if(circularThemeColoredIcon){
		
	}else{
		appendData += '<div class="value quickStatsValueStyle">';
	}*/
		
	
	
	
	if(assetIconImageName == null || assetIconImageName == ""){
		if(circularThemeColoredIcon){
			if(invertAssetIconFlag){
				appendData += '<div style="float: left;"><div class="quickStatClass" style="margin-top: 0.19em;"><img  class="ui  image bigIconImageStyle_home invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png"></div></div>'; 
			}else{
				appendData += '<div style="float: left;"><div class="quickStatClass" style="margin-top: 0.19em;"><img  class="ui  image bigIconImageStyle_home"  src="/repopro/semantic/images/defaultAssetIcon.svg"></div></div>'; 
			}
			
		}else{
			if(invertAssetIconFlag){
				appendData += '<div style="float: left;"><div style="margin-top: 0.19em;"><img  class="ui  image bigIconImageStyle_home_normal invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png"></div></div>';
			}else{
				appendData += '<div style="float: left;"><div style="margin-top: 0.19em;"><img  class="ui  image bigIconImageStyle_home_normal"  src="/repopro/semantic/images/defaultAssetIcon.svg"></div></div>';
			}
			
			
		}
		
	}else{
		/*var imageType = assetIconImageName.split('.');*/
		var imageType = (assetIconImageName).substring((assetIconImageName).lastIndexOf(".") + 1, (assetIconImageName).length);
		//Chandana - 13-9-2019 Broken image
		if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
			imageType = imageType.toLowerCase()
		}
		if(circularThemeColoredIcon){
			appendData += '<div style="float: left;"><div class="quickStatClass" style="margin-top: 0.19em;">';
			
			if(invertAssetIconFlag){
				appendData += '<img  class="ui  image bigIconImageStyle_home invertImageColor"  src="/repopro/assetImages/inverted_'+assetId+'.'+imageType+'">';
			}else{
				appendData += '<img  class="ui  image bigIconImageStyle_home"  src="/repopro/assetImages/'+assetId+'.'+imageType+'">';
			}	
			appendData += '</div></div>';
			
		}else{
			appendData += '<div style="float: left;"><div  style="margin-top: 0.19em;">';
			
			if(invertAssetIconFlag){
				appendData += '<img  class="ui  image bigIconImageStyle_home_normal invertImageColor"  src="/repopro/assetImages/inverted_'+assetId+'.'+imageType+'">';
			}else{
				appendData += '<img  class="ui  image bigIconImageStyle_home_normal"  src="/repopro/assetImages/'+assetId+'.'+imageType+'">';
			}
			
			appendData += '</div></div>';
			
		}
		
		
		
	}
	appendData += '<div style="float: left; padding-left: 0.2em; padding-top: 0px;"><span class="quickStatsDataStyle themeTextColor">'+assetInstanceVersionCount+'</span>';
	//appendData += '<div class="label quickStatsLabelStyle">'+assetName+'</div></div>';
	appendData += '<p class="label quickStatsLabelStyle homeAssetIcons">'+assetName+'</p></div></div></div>';
	
	//console.log("color: "+$("#mainFixedMenu").css("background-color"))
	
	return appendData;
}

// chandana 04.02.2020 - added class when sidebar is open to avoid text overflow issue in the quick start at homepage
if($('#contentPushable').hasClass('sidebarPushable')){
	$('#quickStatsStatistics').removeClass('three');
	$('#quickStatsStatistics').addClass('two');
}


/*//load browser page
function loadbrowserPageForAsset(assetId,assetName){
	$('#breadcrumbData').html('<a class="section" onclick="getHomeDetails(this)">Home</a><i class="right chevron icon divider"></i>'+
			'<div class="active section">Browse - '+assetName+'</div>');
	localStorage.removeItem("pageName");
	localStorage.removeItem("browserAssetName");
	localStorage.setItem("browserAssetName", assetName);
	localStorage.removeItem("browserAssetId");
	localStorage.setItem("browserAssetId", assetId);
	$('#showHideLoader').addClass('active');
	$("#contentPushable").attr('style','background-color: #f8f8ff !important;');
	$('#loadContent').load('browser.html');	
}*/