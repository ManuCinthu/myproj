countOfWorkflowData = 0;
infiniteScrollFlag = true;
var appendWorkflowData = '';
var instanceCreate = jsPlumb.getInstance({ Container:".drawingArea" });
var instance =jsPlumb.getInstance({ Container:".editDrawingArea" });

var allAssets = '';
var allAssetNames ; 
var workflowNames =[];
var assignedAssets1=[];
var checkAssets =[];

var numberOfElements = 0;
var numberNodes = 0 ;
var saveflag = false;
var saveEditflag = false;

/*if(workflowFlag == true){
	location.reload(true); 
}*/

//** Chandana-29.01.2020 load data to workflow grid**

function loadWorkFlowDetails(){
	$('#workFlowGrid').show();	
	$.ajax({
		type : "GET",
		url : "/repopro/web/workflow/getAllWorkflows",
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			//console.log(" json "+JSON.stringify(json));
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null || json.result == []){
					if(countOfWorkflowData == 0){
						$('#noworkFlowGridData').show();
						$('#noworkFlowGridData').html('<div class="ui message">No workflow added yet</div>'); 
						$("#workFlowGrid").hide();
						infiniteScrollFlag = false;
					}
					else{
						$('#workFlowLoadingId').css('display', 'none');
						infiniteScrollFlag = false;
					}
				}
				else{
					
					$('#noworkFlowGridData').hide();
					$('#workFlowGrid').show();
					$("#newAssetInst").html("");
					$("#editAssetInst").html("");
					var allAssets = json.result[0].allAssets;
					allAssetNames = '';
					checkAssets = json.result[0].allAssets;
					$.each(allAssets, function(a){
						allAssetNames += '<option value="'+ a +'">'+ allAssets[a] +'</option>';
					});
					// console.log("All Assets :"+allAssetNames);
						
					$("#newAssetInst").append(allAssetNames);
					$("#editAssetInst").append(allAssetNames);				
					
					$.each(json.result, function(i) {						
						appendWorkflowData = getWorkFlowDetails (json.result[i].workflowName, json.result[i].workflowId, json.result[i].assignedAssets, json.result[i].jsonStructure, json.result[i].allAssets, json.result[i].flagIfStateUpdated);
						$('#tableWorkflow tbody').append(appendWorkflowData);
						countOfWorkflowData++;
						// Swathi - 09.03.2020 - Dropdown and selected Assets name display 
						var id= json.result[i].workflowId;
						var assets = json.result[i].assignedAssets;
						//numberOfElements = json.result[i].totalElements
						var assetsTypes = [];
						$('#gridAssetInst_'+id).append(allAssetNames);
						$.each(assets, function(a){
							assetsTypes.push(assets[a]);
							if(assets[a] !=null){
								assignedAssets1.push(a);
							}							
							
						});
						$('#gridAssetInst_'+id).dropdown('set selected',assetsTypes);	
						$('#gridAssetInst_'+id).parent().addClass('selectAssetInst');
						var name = json.result[i].workflowName.trim();
						name = name.toLowerCase();
						workflowNames.push(name);
						//console.log("API"+assignedAssets1);
						numberOfElements = numberNodes;
						numberOfElements = numberOfElements ++;
						//console.log(numberOfElements);
					});					
				

					$( ".delete" ).html( "<span class='new' data-tooltip ='Deleting the Assets will reset all the states' data-position=' bottom center'> </span>" );					
					
					//formRange = formRange + 20;
				}
				$('#workFlowLoadingId').css('display', 'none');
			}
			else{
				$('#workFlowLoadingId').css('display', 'none');
				
			}
			$('#showHideLoader').removeClass('active');
		}
	});
	$('#workFlowLoadingId').css('display', 'none');
	//scrollVisible(0);
}


//** Chandana-29.01.2020 add data to work flow grid row**

function getWorkFlowDetails (workflowName,workflowId,selectedAssets,savedjson,allAssets,statusflag){
	$('#workflowIcon').attr("src", "/repopro/semantic/images/IconWFlowRed.svg" );
	var assetNamesLabel = '';
	var multiAssetFlag = false;
	var allAssetNames = '';			
	var data = "<p>Are you sure you want to assign this asset to the new workflow as this asset will be removed from the previous workflow?</p><button class='right floated ui cancel themeSecondary mini button' onclick='cancelAsset("+workflowId+")'>No</button><button class='right floated ui primary mini button' onclick='moveAsset("+workflowId+")'>Yes</button>";
	appendData = "";
	appendData += '<tr id="workFlowGridRow_'+workflowId+'">';
	appendData += '<td class="one wide hidden" id="workFlowID_'+workflowId+'">'+workflowName+'</td>';
	appendData += '<td class="one wide hidden">'+workflowId+'</td>';
	appendData += '<td class="one wide hidden" id ="workFlowEditedFlag_'+workflowId+'">'+statusflag+'</td>';
	appendData += '<td class="three wide whitespaceNoTrim" id="workFlowNameId_'+workflowId+'"><div id="td_'+workflowId+'"><div class="mediumIconImageCircleStyle"> <i class="object ungroup outline icon" style="padding: 2px 3px;"></i></div><span  class = "editableName"  contenteditable="true" style="margin-left: 0.8em;" onkeypress="return (this.innerText.length <= 50)">'+workflowName+'</span><div class="ui up pointing red basic label valid gridErrorMsg null" style="display: none;" id="errEditWorkflowName_'+workflowId+'">Please enter workflow name</div></td>';

	// Swathi- Asset Dropdown- 05.03.2020		
	appendData += '<td class="two wide whitespaceNoTrim selectedAssets" id="selectedAssetsId_'+workflowId+'" "><select class="ui dropdown  gridAssetInst" id="gridAssetInst_'+workflowId+'" name="dropdown"  multiple=""><option value="">Select Asset</option></select><span class="selectPopup tram_'+workflowId+'" data-html="'+data+'" data-position= "right center"></span></td>';	
	appendData += '<td class="one wide"><i class="edit icon " onclick="openEditWorkflow('+workflowId+')"></i>';
	appendData += '<span id= "hiddenJSOn_'+workflowId+'" style="display:none">'+savedjson+'</span></td>';
	 if ( workflowId == 1) {
		  	appendData += '<td class="disabled disableDeleteIcon " id="deleteGridWorkflowIcon_'+workflowId+'"><span data-tooltip="The default workflow cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+workflowId+'" ></i></span></td>';
    }
	else {
		
		//Swathi- Adding check if Assets are assigned then show different popup else show confirmation message
		
		var data = "<p>Are you sure you want to delete the "+ workflowName +" workflow ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteWorkflowPopup("+workflowId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteWorkflowData("+workflowId+")'>Yes</button>";
				
		var assetsTypes = [];		
		$.each(selectedAssets, function(a){
			assetsTypes.push(selectedAssets[a]); 
		});	
		var assetsFlag ;
		$.each(assetsTypes, function(e){
			if(assetsTypes[0] != null){
				assetsFlag = true;
			}else{
				assetsFlag = false;
			}
		});
		if(assetsFlag == true){
			appendData += '<td class="disabled disableDeleteIcon " id="deleteGridWorkflowIcon_'+workflowId+'" ><span  data-tooltip="Asset/s are assigned to a workflow hence cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+workflowId+'"></i></span></td>';
		}
		else {
			appendData += '<td class="" id="deleteGridWorkflowIcon_'+workflowId+'"><a><i class="trash icon deleteEditIcon" id="trash_'+workflowId+'" data-html="'+data+'" onclick="openDeleteWorkflowPopup('+workflowId+')"></i></a></td>';
		}	
	

	}
	 appendData += '</tr>';
	var loop =  JSON.parse(savedjson);
	$.each(loop, function(i){
		
		if(loop[i].nodetype == "task"){
			var val = loop[i].blockId;
			val = val.split("_");
			val = val[1];
			numberNodes = parseInt(numberNodes);
			if(numberNodes < val){				
				numberNodes = val;
			}		
		}
	});
	return appendData;
	
}

//** Chandana-29.01.2020 delete workflow data*
function openDeleteWorkflowPopup(workflowId){
	$("#trash_"+workflowId)
	.popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	})
	.popup('show');
}

//** Chandana-29.01.2020 close delete workflow popup
function closeDeleteWorkflowPopup(workflowId){
		$("#trash_"+workflowId).popup('hide');
}

/** Swathi- Create New  workflow **/
function openNewWorkflow(){
	// Add javascript here
	$('.ui.popup').popup({ inline: true });

	region = "drawingArea";

	/*$('#btnSaveCreatedWorkflow').unbind();
	$('#btnCancelCreatedWorkflow').unbind();*/
	
	$('#addNewWorkflow').modal('destroy');	
	$('#newWorkflowName').val('');
	$('#newAssetInst').dropdown('clear');	
	$('#addNewWorkflow').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	// resetting the error messages
	$("#errNewWorkflowName").hide();
	$('#newWorkflowName').parent().removeClass("error");
	$("#errNewAssetType").hide();
	$('#newAssetInst').parent().removeClass("error");
	$(".drawingArea").html('<div class="elements startIcon window node" id="startTask" data-nodetype="startpoint"  style= "left: 8%; top: 7%"> <input class="startLabel taskname" value="Start" maxlength = "50" ></div>');
	$('.taskname').each(function (e) {
		var val = $(this).val();
		$(this).attr("title",val);
	});
	instanceCreate.ready(function() {
		
		var workflowConnectorStartpoint = {
			    isSource: true,
			    isTarget: false,
			    maxConnections: 1,				 
			    anchor:"Right",
			    anchors: [
			        [1.06, 0.5, 0, 1],
			        [-0.06, 0.5, 0, 0]
			    ],
			    endpoint: ["Dot", {
			        radius: 4
			    }],
			    setDragAllowedWhenFull: true,
			    
			    connector: ["Flowchart"],
			    connectorStyle: [{
			        lineWidth: 3,
			    }],
			    connectorOverlays: [
			        ["Arrow", {
			            width: 10,
			            length: 10,
			            foldback: 1,
			            location: 1,
			            id: "arrow"
			        }]
			    ]
			};
		instanceCreate.addEndpoint(
			    $('#startTask'),
			    workflowConnectorStartpoint
		);	
		instanceCreate.draggable($('#startTask'), {containment:true});
		
		 var cons = [];
		 instanceCreate.bind("connection", function (info) {
		        var src = info.sourceId;
		        var trgt = info.targetId;
		        if (!cons.includes(src+trgt)) {//if not exists
		           cons.push(src+trgt);
		           //cons.push(trgt+src);//(optional) use to prevent adding connection from target to source 
		        }
		    });
		/* instanceCreate.bind('connectionDetached' , function (info) {
			        var src = info.sourceId;
			        var trgt = info.targetId;
			        var newCon = src + trgt;
			        cons = cons.filter(e => e !== newCon);// Removing connection from stored
			        return true;
			}); */
				
		 instanceCreate.bind("beforeDrop", function (info) {
			// console.log("before drop: " + info.sourceId + ", " + info.targetId);
			    if (info.sourceId === info.targetId) { //source and target ID's are same
			    	notifyMessage("Create Workflow","Self connection is not allowed","Fail"); 
			        return false;
			    } 
			    var createCon = true;
		        var src = info.sourceId;
		        var trgt = info.targetId;
		        var newCon = src + trgt;
		        /*if(cons.includes(newCon)){//if new connection exists do not allow to create new connection
		        	notifyMessage("Create Workflow","Duplicate connection is not allowed","Fail"); 
		            createCon = false;
		        }*/
		        return createCon;
		});	
	});
}

/** Swathi- Edit workflow **/
var editedWorkflowId ;
var EnteredName;
var stateChanged;
function openEditWorkflow(workflowId){
	/*$('#btnSaveEditedWorkflow').unbind();
	$('#btnCancelEditedWorkflow').unbind();*/
	
	var editAssetTypes = '';
	var listArr = [];
	$('#editAssetInst').dropdown('clear');
	/*// Reset the JSPlumb values
	$(".node").each(function (idx, elem) { 		
		elem.remove();				
	});*/
	//instance.reset();
	$('#editWorkflow').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	// Error message removal
	$('#editWorkflowName').parent().removeClass("error"); 
	$("#errEditWorkflowName").hide(); 
	
	var editWorkflowName = $("#workFlowNameId_"+workflowId+" .editableName").text().trim();
	 EnteredName = editWorkflowName;
	
	//Set Workflow name to the modal header and input field WorflowName
	$('#editWorkflowModalName').text(editWorkflowName);
	
	$("#editWorkflowName").val(editWorkflowName);
	// Show selected values in the dropdown
	editAssetTypes = $('#gridAssetInst_'+workflowId).val();	

	$('#editAssetInst').parent().parent().removeClass('editAssetDiv');
		setTimeout(function(){
			$('#editAssetInst').dropdown('set selected',editAssetTypes);
			$('#editAssetInst').parent().parent().addClass('editAssetDiv');
	}, 100);
		
	
	region = "editDrawingArea";	
	editedWorkflowId = workflowId; // Setting the workflow id for future save and edit in the JSPlumb structure
	$(".editDrawingArea").html('<div class="elements startIcon window node" id="startTask" data-nodetype="startpoint"> <input class="startLabel taskname" maxlength = "50" ></div>');
	
	
	
	instance.ready(function() {	
		var workflowConnectorStartpoint = {
			    isSource: true,
			    isTarget: false,
			    maxConnections: 1,				 
			    anchor:"Right",
			    anchors: [
			        [1.06, 0.5, 0, 1],
			        [-0.06, 0.5, 0, 0]
			    ],
			    endpoint: ["Dot", {
			        radius: 4
			    }],
			    setDragAllowedWhenFull: true,
			    
			    connector: ["Flowchart"],
			    connectorStyle: [{
			        lineWidth: 3,
			    }],
			    connectorOverlays: [
			        ["Arrow", {
			            width: 10,
			            length: 10,
			            foldback: 1,
			            location: 1,
			            id: "arrow"
			        }]
			    ]
			};
		instance.addEndpoint(
			    $('#startTask'),
			    workflowConnectorStartpoint
		);
		instance.draggable($('#startTask'), {containment:true}); 
		
		 var cons = [];
		   instance.bind("connection", function (info) {
		        var src = info.sourceId;
		        var trgt = info.targetId;
		        if (!cons.includes(src+trgt)) {//if not exists
		           cons.push(src+trgt);
		           //cons.push(trgt+src);//(optional) use to prevent adding connection from target to source 
		        }
		    });
				
		    instance.bind("beforeDrop", function (info) {
			// console.log("before drop: " + info.sourceId + ", " + info.targetId);
			    if (info.sourceId === info.targetId) { //source and target ID's are same
			    	notifyMessage("Edit Workflow","Self connection is not allowed","Fail"); 
			        return false;
			    } 
			    var createCon = true;
			    var src = info.sourceId;
		        var trgt = info.targetId;
		        var newCon = src + trgt;
		      /*  if(cons.includes(newCon)){//if new connection exists do not allow to create new connection
		        	notifyMessage("Edit Workflow","Duplicate connection is not allowed","Fail"); 
		            createCon = false;
		        }*/
		        return createCon;
		}); 
		    
		    
	});
	loadFlowchart(workflowId); // Load the JSPlumb flowchart
	
	//Disabling of edit area and create state icon when states are changed
	stateChanged = $("#workFlowEditedFlag_"+workflowId).text();
	if(stateChanged == "true"){
		$(".editDrawingArea").addClass("disableClick");
		$(".jtk-connector").addClass("disableClick");
		$(".editDrawingArea .jtk-endpoint").addClass("disableClick");
		$("#editTaskSymbol").addClass("disableClick");
		$(".editDrawingArea svg").attr("class", "disableClick");
	}else{
		$(".editDrawingArea").removeClass("disableClick");
		$("#editTaskSymbol").removeClass("disableClick");
		$(".editDrawingArea .jtk-endpoint").removeClass("disableClick");
		$("#editTaskSymbol").removeClass("disableClick");
		$(".editDrawingArea svg").attr("class", "");
	}
}

/*** Swathi - SOC - JSPlumb Code ***/
var startId =1;
var taskId = 1;
var decisionId =1;
var endId = 1;
var htmlBase ;


//Adding intermediate states when creating new workflow
function addTask(base,id){
	 htmlBase = base;	
	if(typeof id === "undefined"){
	numberOfElements++;
	id = "taskSymbol_" + numberOfElements;
	}
	var taskSourceConnectorEndpoint = {
	    isSource: true,
	    isTarget: false,
	    maxConnections: 8,
	    anchor:"Right",
	    endpoint: ["Dot", {
	        radius: 4
	    }], anchors: [
	        [1.06, 0.5, 0, 1],
	        [-0.06, 0.5, 0, 0]
	    ],
	    setDragAllowedWhenFull: true,
	    
	    connector: ["Flowchart"],
	    connectorStyle: [{
	        lineWidth: 3,
	    }],
	    connectorOverlays: [
	        ["Arrow", {
	            width: 10,
	            length: 10,
	            foldback: 1,
	            location: 1,
	            id: "arrow"
	        }]
	    ],
	    
	};
	var taskTargetConnectorEndpoint = {
	    isSource: false,
	    isTarget: true,
	    maxConnections: 8,	
	    anchor:"Left",
	    endpoint: ["Dot", {
	        radius: 4
	    }],
	    anchors: [
	        [1.06, 0.5, 0, 1],
	        [-0.06, 0.5, 0, 0]
	    ],
	    setDragAllowedWhenFull: true,
	    
	    connector: ["Flowchart"],
	    connectorStyle: [{
	        lineWidth: 3,
	    }],
	    connectorOverlays: [
	        ["Arrow", {
	            width: 10,
	            length: 10,
	            foldback: 1,
	            location: 1,
	            id: "arrow"
	        }]
	    ]
	};
	
	$('<div class="window rectangle node" id="' + id + '" data-nodetype="task" ><input class="taskname taskTop " placeholder="Label" maxlength = "50"> <div class="button_remove" onclick= "deleteState(this)"><span>x<span></div></div>').appendTo('.'+htmlBase);
	
	instanceCreate.addEndpoint(
	    $('#'+id),
	    taskSourceConnectorEndpoint
	);
	    
	instanceCreate.addEndpoint(
	    $('#'+id),
	    taskTargetConnectorEndpoint
	);  
	
	instanceCreate.draggable($('#' + id), {containment:true}); 
	return id;
}


var interNodes=  [];
var nodesObjArr = [];
var nodesObj = {};
var statesArray = [];

// Saving the states in JSPlumb flowchart structure
function saveFlowchart(){
	interNodes=  [];
	nodesObjArr = [];
	nodesObj = {};
	statesArray = [];
	//saving node values in an array
	$(".node").each(function (idx, elem) { 
	// Code to store div name coming from Input
	var divLabel =   $(this).children(".taskname").val().trim();
	$(this).attr('title', divLabel); 
	
       
	var $elem = $(elem);
	var connections;
	//code to find next element   
	if(editedWorkflowId != "" && editedWorkflowId != null && editedWorkflowId != undefined){
		connections = instance.getConnections({ source: $elem }); 
	} else{
		connections = instanceCreate.getConnections({ source: $elem }); 
	}
	
	var targetIds =[];
	var sourceIds =[];
	if(connections.length > 0){
	    for (i=0;i<connections.length ;i++){
	    sourceIds[i] = connections[i].sourceId; 
	    targetIds[i] = connections[i].targetId;
	    }
	}   
	interNodes.push({
	    blockId: $elem.attr('id'),
	    nodetype: $elem.attr('data-nodetype'),
	    positionX: parseInt($elem.css("left"), 10),
	    positionY: parseInt($elem.css("top"), 10),
	    instanceState: $elem.attr('title'),
	    connectingSourceId: sourceIds,
	    connectingTargetId: targetIds,
	    
	}); 
	var name = divLabel;
	name = name.toLowerCase();
	statesArray.push(name) ;
	nodesObj[idx] = interNodes[idx]; 
	}); 
	if(editedWorkflowId != "" && editedWorkflowId != null && editedWorkflowId != undefined){
		editedNodesValidation();
	}else{
		nodesValidation();
	}
	}   

//validation code for checking single connection between the states
var saveJSON = false;
var saveJSON1 = false;
var saveJSON2 = false; 

var flag = true;	
function nodesValidation(){
	 saveJSON= false;
	$(".node").each(function (idx, elem) {
		var stateName = $(elem).attr('title');
		stateName =  stateName.toLowerCase();
	     if($(elem).attr('data-nodetype') == "startpoint"){
	    	 var connections = instanceCreate.getConnections({ source: $(elem)});
		        if(connections.length == 0){
		            saveJSON = false;
		            notifyMessage("Create Workflow","Please connect the states","Fail");	
		        	return false;
		        }  else{
		        	if($(elem).attr('title') == "" || $(elem).attr('title') == undefined  ){
		        		saveJSON = false;
		        		 notifyMessage("Create Workflow","Please enter all the state.","Fail");
		        			return false;
		              }else if((/^[a-zA-Z0-9- ]*$/.test(stateName) == false)){
		            	notifyMessage("Create Workflow","Please use only alphanumeric character for states.","Fail");
		            	saveJSON = false;
		        		return false;
		            } else{
		            	var state = hasDuplicates(statesArray);
			        	if(state == true){
			        		notifyMessage("Create Workflow","State(s) with the same name already exists.","Fail");
			        		saveJSON = false;
			        		return false;
			        	} else{
			        		saveJSON = true;
			        	}
			          }
		            //saveJSON = true;
		        }
	    }else{	    	
	        var connectionsSource = instanceCreate.getConnections({ source: $(elem) });
	        var connectionTarget = instanceCreate.getConnections({ target: $(elem) });      		
	        if(connectionTarget.length == 0){// teask can either of any connection
	            saveJSON2 = false;
	            notifyMessage("Create Workflow","Please connect the states","Fail");	
	            return false;
	        } else {	        	
	        	if(stateName == "" || stateName == undefined  ){
	        		saveJSON2 = false;
	        		notifyMessage("Create Workflow","Please enter all the state.","Fail");
	        		return false;
	            }else if((/^[a-zA-Z0-9- ]*$/.test(stateName) == false)){
	            	notifyMessage("Create Workflow","Please use only alphanumeric character for states.","Fail");
	        		saveJSON2 = false;
	        		return false;
	            } 
	        	else{
	            	var state = hasDuplicates(statesArray);
		        	if(state == true){
		        		notifyMessage("Create Workflow","State(s) with the same name already exists.","Fail");
		        		saveJSON2 = false;
		        		return false;
		        	} else{
		        		saveJSON2 = true;
		        	}
		          }
	        	
	        }
	        
	    }        
	    
	});
	if( saveJSON == true  && saveJSON2 == true ){
		saveflag = true;
	sendNodeValues();
	} else{
		saveflag=  false;
	}
}

//validation code for checking single connection between the states
var saveEditedJSON =false;
function editedNodesValidation(){
	$(".node").each(function (idx, elem) { 
		var stateName = $(elem).attr('title');
		stateName =  stateName.toLowerCase();
		
	     if($(elem).attr('data-nodetype') == "startpoint"){
	        var connections = instance.getConnections({ source: $(elem)});
	        if(connections.length == 0){
	            saveJSON = false;
	            notifyMessage("Edit Workflow","Please connect the states","Fail");	
	        	return false;
	        }  else{
	        	if($(elem).attr('title') == "" || $(elem).attr('title') == undefined  ){
	        		saveJSON = false;
	        		 notifyMessage("Edit Workflow","Please enter all the state.","Fail");
	        			return false;
	              }else if((/^[a-zA-Z0-9- ]*$/.test(stateName) == false)){
	            	notifyMessage("Edit Workflow","Please use only alphanumeric character for states.","Fail");
	            	saveJSON = false;
	        		return false;
	            } else{
	            	var state = hasDuplicates(statesArray);
		        	if(state == true){
		        		notifyMessage("Edit Workflow","State(s) with the same name already exists.","Fail");
		        		saveJSON = false;
		        		return false;
		        	} else{
		        		saveJSON = true;
		        	}
		          }
	            //saveJSON = true;
	        }
	    }else{	    	
	        var connectionsSource = instance.getConnections({ source: $(elem) });
	        var connectionTarget = instance.getConnections({ target: $(elem) });
	        if(connectionTarget.length == 0){// teask can either of any connection
	            saveJSON2 = false;
	            notifyMessage("Edit Workflow","Please connect the states","Fail");	
	        	return false;
	        } else {	        	
	        	if($(elem).attr('title') == "" || $(elem).attr('title') == undefined  ){
	        		saveJSON2 = false;
	        		 notifyMessage("Edit Workflow","Please enter all the state.","Fail");
	        			return false;
	              }else if((/^[a-zA-Z0-9- ]*$/.test(stateName) == false)){
	            	notifyMessage("Edit Workflow","Please use only alphanumeric character for states.","Fail");
	        		saveJSON2 = false;
	        		return false;
	            } else{
	            	var state = hasDuplicates(statesArray);
		        	if(state == true){
		        		notifyMessage("Edit Workflow","State(s) with the same name already exists.","Fail");
		        		saveJSON2 = false;
		        		return false;
		        	} else{
		        		saveJSON2 = true;
		        	}
		          }
	        	
	        }
	        
	    }        
	    
	});
	if( saveJSON == true && saveJSON2 == true ){
		saveEditflag = true;
		sendNodeValues();
	} else{
		saveEditflag=  false;
	}
}
function sendNodeValues(){
	for (index = 0; index < interNodes.length; index++) { 
		var ids = []; 
		for(i = 0; i< interNodes[index].connectingTargetId.length;i++){              
		    for( var row= 0; row< interNodes.length;row++ ){                   
		        if(interNodes[index].connectingTargetId[i] == interNodes[row].blockId){                                      
		            ids.push(row);                                          
		        }                    
		    }
		    interNodes[index].next = $.unique(ids);// Sending unique values
		}    
		if(interNodes[index].next == undefined){
		    interNodes[index].next = [];
		} 
	} 
	nodesObjArr.push(nodesObj);
	var nodesFlow ={};
	nodesFlow = nodesObj;
	
	var nodesFlowJSON = JSON.stringify(nodesFlow);
	
	//Storing the JSON value
	if(editedWorkflowId != "" && editedWorkflowId != null && editedWorkflowId != undefined){
		$("#editedJSON").val(nodesFlowJSON);
	}else{
		$("#newJSON").val(nodesFlowJSON);
	}
	
}

/*** Swathi- 03.03.2020 - End of JSPlumb code for Creating new workflow, and saving in JSOn structure ***/
var newWorkflowId = '';
var newWorkflowName = '';

var autoIdCreator = Math.floor((Math.random() * 1000000) + 1);
var appendData ='';
var autoCretaedIDs= [];
// Swathi- 02.03.2020 - Saving the newly created workflow 
$("#btnSaveCreatedWorkflow").on('click', function(){
	var newAssetNamesLabel ='';
	editedWorkflowId = ""
	newWorkflowName = $("#newWorkflowName").val().trim();
	newWorkflowName =newWorkflowName.toLowerCase();
	 var multiAssetFlag ;
	 var assetsInst	= $('#newAssetInst').val();	
	 //var assetsInst1 
	 
	//Workflow Name validation
	if(newWorkflowName == null || newWorkflowName == ""){
		$('#newWorkflowName').parent().addClass("error"); 
		$("#errNewWorkflowName").show();  
		flag = false;
	}
	else if (/^[a-zA-Z0-9- ]*$/.test(newWorkflowName) == false) {
			$('#newWorkflowName').parent().addClass("error"); 
		    $("#errNewWorkflowName").html('Please use only alphanumeric character for workflow name.').show();  
			flag = false;
	} else{
		$('#newWorkflowName').parent().removeClass("error"); 
		$("#errNewWorkflowName").hide(); 
		flag= true;
		finalSaveFlag = true; // Returning true when worklfow name is not empty.
		var test = jQuery.inArray( newWorkflowName, workflowNames );
		if(test== -1){
			$('#newWorkflowName').parent().removeClass("error"); 
			$("#errNewWorkflowName").hide(); 
			flag =true;
		} else{			
			$('#newWorkflowName').parent().addClass("error"); 
		    $("#errNewWorkflowName").html('Workflow(s) with the same name already exists.').show();  
			flag = false;
			
		}
	}
	
	
	saveFlowchart();// Saving of JSON plumb json structure
	
	if(flag == false || saveflag ==false ){
    	$('#addNewWorkflow').modal('show');
		return false;
    } else{   
    	
    	 var newJSON = $('#newJSON').val(); 
    	 autoCretaedIDs.push(autoIdCreator);
    	 var data = "<p>Are you sure you want to assign this asset to the new workflow as this asset will be removed from the previous workflow?</p><button class='right floated ui cancel themeSecondary mini button' onclick='cancelAsset("+autoIdCreator+")'>No</button><button class='right floated ui primary mini button' onclick='moveAsset("+autoIdCreator+")'>Yes</button>";
    	 //Saving of new workflow in Grid format
    	appendData = "";
 		appendData += '<tr id="workFlowGridRow_'+autoIdCreator+'">';
 		appendData += '<td class="one wide hidden" id="workFlowID_'+autoIdCreator+'">'+newWorkflowName+'</td>';
 		appendData += '<td class="one wide hidden">'+autoIdCreator+'</td>';
 		appendData += '<td class="three wide whitespaceNoTrim" id="workFlowNameId_'+autoIdCreator+'"><div><div class="mediumIconImageCircleStyle"><i class="object ungroup outline icon" style="padding: 2px 3px;"></i></div><span class = "editableName" contenteditable="true" style="margin-left: 0.8em;vertical-align: -webkit-baseline-middle;" onkeypress="return (this.innerText.length <= 50)">'+newWorkflowName+'</span></td>';

 	// Swathi- Asset Dropdown- 05.03.2020		
 		appendData += '<td class="two wide whitespaceNoTrim selectedAssets" id="selectedAssetsId_'+autoIdCreator+'"><select class="ui dropdown gridAssetInst" id="gridAssetInst_'+autoIdCreator+'" name="dropdown" multiple=""><option value="">Select Asset</option></select><span class="selectPopup tram_'+autoIdCreator+'" data-html="'+data+'" data-position= "right center"></span></td>';	
 		
 		appendData += '<td class="one wide"><i class="edit icon " onclick="openEditWorkflow('+autoIdCreator+')"></i>';
 		appendData += '<span id= "hiddenJSOn_'+autoIdCreator+'" style="display:none">'+newJSON+'</span></td>';
 		
 		//Swathi- Adding check if Assets are assigned then show different popup else show confirmation message
		
		var data = "<p>Are you sure you want to delete the "+ newWorkflowName +" workflow ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteWorkflowPopup("+autoIdCreator+")'>No</button><button class='right floated ui primary mini button' onclick='deleteWorkflowData("+autoIdCreator+")'>Yes</button>";
				
		var assetsFlag ;
			if(assetsInst != null && assetsInst != undefined && assetsInst != ""){
				assetsFlag = true;
			}else{
				assetsFlag = false;
			}
		
		if(assetsFlag == true){
			appendData += '<td class="disabled disableDeleteIcon " id="deleteGridWorkflowIcon_'+autoIdCreator+'" ><span  data-tooltip="Asset/s are assigned to a workflow hence cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+autoIdCreator+'"></i></span></td>';
		}
		else {
			appendData += '<td class="" id="deleteGridWorkflowIcon_'+autoIdCreator+'"><a><i class="trash icon deleteEditIcon" id="trash_'+autoIdCreator+'" data-html="'+data+'" onclick="openDeleteWorkflowPopup('+autoIdCreator+')"></i></a></td>';
		}	
		appendData += '</tr>';
 		$('#tableWorkflow tbody').append(appendData);
 		$('#gridAssetInst_'+autoIdCreator).append(allAssetNames);
 		$("#gridAssetInst_"+autoIdCreator).dropdown('set selected',assetsInst);	
 		
 		 		
 		$( ".delete" ).html( "<span class='new' data-tooltip ='Deleting the Assets will reset all the states' data-position=' bottom center'> </span>" );					 		
 		var addedId = autoIdCreator; 		
 		changedRowIds.push(addedId);
 		// Reset the JSPlumb values
 		$(".node").each(function (idx, elem) { 	
				elem.remove();
 		});
 		instanceCreate.reset();
 		workflowNames.push(newWorkflowName);// Adding newly created workflow names to array.
 		/*if(assetsInst != null && assetsInst != undefined){
 			assignedAssets1.push(assetsInst);
 		}*/
 		
 		 $('#gridAssetInst_'+autoIdCreator).parent().addClass("selectAssetInst ");
 		
 		autoIdCreator = Math.floor((Math.random() * 1000000) + 1);
    	 
    	 $('#addNewWorkflow').modal('hide');
    	 $('#addNewWorkflow').parent().css("display", "none !important");
    	
     }
});

/*** Cancel button on Create new workflow modal ***/
$("#btnCancelCreatedWorkflow").on('click', function(){
	$(".node").each(function (idx, elem) { 
				elem.remove();
	});
	instanceCreate.reset();
});

/*** Swathi - 03.03.2020 - BOC - JSPlumb flowchart Load using JSON structure in Edit Worflow Modal ***/
function loadFlowchart(id){
	var flowChartJson = $('#hiddenJSOn_'+id).text();
	var interNodes = JSON.parse(flowChartJson);
	//console.log(interNodes);
	var nodes = Object.values(interNodes);
	
	var sourceId;
	var targetId;
	
	
	$.each(nodes, function( index, elem ) {
		if(elem.nodetype === 'startpoint'){
		   repositionElement('startTask', elem.positionX, elem.positionY, elem.instanceState); 

		
		}else if(elem.nodetype === 'endpoint'){
			addEndTask1(region);
			repositionElement('endTask', elem.positionX, elem.positionY, elem.instanceState);
		}else if(elem.nodetype === 'task'){
			var id = addTask1(region, elem.blockId);
		    repositionElement(id, elem.positionX, elem.positionY, elem.instanceState); 
		}else{
			
		}
	});
	$.each(nodes, function( index, elem ) {
		if(elem.nodetype != 'endpoint'){
		    for(i=0;i<elem.connectingSourceId.length;i++){
		        connectToTarget(elem.connectingSourceId[i],elem.connectingTargetId[i]); 
		    }    
		    
		} 		
	});
	setTimeout(function(){
		instance.repaintEverything();

	}, 200);
	
	$('.taskname').each(function (e) {
		var val = $(this).val();
		$(this).attr("title",val);
	});
	
}

//Repositioning of elements(states) according to the stored values
function repositionElement(id, posX, posY, stateName){
	$('#'+id).css('left', posX);
	$('#'+id).css('top', posY);
	$('#'+id).children(".taskname").val(stateName);
}

// Reconnecting the connections between the states
function connectToTarget( sourceId, targetId){
	instance.importDefaults({
		
		Connector:[ "Flowchart" ],
		ConnectionOverlays : [
			[ "Arrow", { 
				 width: 10,
		            length: 10,
		            foldback: 1,
		            location: 1,
		            id: "arrow"
			} ]
		]
	});
	
	var connection1 = instance.connect({
		source: sourceId,
		target: targetId,
		endpoint: ["Dot", {
	        radius: 4
	    }],
		 anchors: [
		        [1, 0.5, 0, 1],
		        [0, 0.5, 0, 0]
		    ],
	    connector: ["Flowchart"],
	    connectorStyle: [{
	        lineWidth: 3,
	    }],
	    setDragAllowedWhenFull: true,
	    connectorOverlays: [
	        ["Arrow", {
	            width: 10,
	            length: 10,
	            foldback: 1,
	            location: 1,
	            id: "arrow"
	        }]
	    ]
		
	});
}

function addTask1(base,id){
	 htmlBase = base;
	if(typeof id === "undefined"){
	numberOfElements++;
	id = "taskSymbol_" + numberOfElements;
	}
	var taskSourceConnectorEndpoint = {
		    isSource: true,
		    isTarget: false,
		    maxConnections: 8,
		    anchor:"Right",
		    endpoint: ["Dot", {
		        radius: 4
		    }], 
		    anchors: [
		        [1.06, 0.5, 0, 1],
		        [-0.06, 0.5, 0, 0]
		    ],
		    setDragAllowedWhenFull: true,
		    
		    connector: ["Flowchart"],
		    connectorStyle: [{
		        lineWidth: 3,
		    }],
		    connectorOverlays: [
		        ["Arrow", {
		            width: 10,
		            length: 10,
		            foldback: 1,
		            location: 1,
		            id: "arrow"
		        }]
		    ]
		};
		var taskTargetConnectorEndpoint = {
		    isSource: false,
		    isTarget: true,
		    maxConnections: 8,	
		    anchor:"Left",
		    endpoint: ["Dot", {
		        radius: 4
		    }],
		    anchors: [
		        [1.06, 0.5, 0, 1],
		        [-0.06, 0.5, 0, 0]
		    ],
		    setDragAllowedWhenFull: true,
		    
		    connector: ["Flowchart"],
		    connectorStyle: [{
		        lineWidth: 3,
		    }],
		    connectorOverlays: [
		        ["Arrow", {
		            width: 10,
		            length: 10,
		            foldback: 1,
		            location: 1,
		            id: "arrow"
		        }]
		    ]
		};
		
		$('<div class="window rectangle node" id="' + id + '" data-nodetype="task" ><input class="taskname taskTop" placeholder="Label" maxlength = "50"><div class="button_remove" onclick= "deleteEditState(this)"><span>x<span></div></div>').appendTo('.'+htmlBase);
		instance.addEndpoint(
	    $('#'+id),
	    taskSourceConnectorEndpoint
	);
	    
	instance.addEndpoint(
	    $('#'+id),
	    taskTargetConnectorEndpoint
	);  
	
	instance.draggable($('#' + id), {containment:true}); 
	return id;
}

function addStartTask1(base){
	 htmlBase = base;
	$('<div class="elements startIcon window node" id="startTask" data-nodetype="startpoint" > <input class="startLabel taskname" value="Start" maxlength = "50"></div>').appendTo('.'+htmlBase);

	var workflowConnectorStartpoint = {
		    isSource: true,
		    isTarget: false,
		    maxConnections: 1,				 
		    anchor:"Right",
		    anchors: [
		        [1.06, 0.5, 0, 1],
		        [-0.06, 0.5, 0, 0]
		    ],
		    endpoint: ["Dot", {
		        radius: 4
		    }],
		    setDragAllowedWhenFull: true,
		    
		    connector: ["Flowchart"],
		    connectorStyle: [{
		        lineWidth: 3,
		    }],
		    connectorOverlays: [
		        ["Arrow", {
		            width: 10,
		            length: 10,
		            foldback: 1,
		            location: 1,
		            id: "arrow"
		        }]
		    ]
		};
	instance.addEndpoint(
		    $('#startTask'),
		    workflowConnectorStartpoint
	);
	//instance.draggable($('#startTask')); 
	 //instance.draggable($('#startTask'), {containment:true}); 
}

function addEndTask1(base){
	 htmlBase = base;
	var workflowConnectorEndpoint = {
		    isSource: false,
		    isTarget: true,
		    maxConnections: -1,				 
		    anchor:"TopCenter",
		    
		};
	$('<div class="elements circl window node" id="endTask" data-nodetype="endpoint" ><input class="taskname" maxlength = "50" value="end"></div>').appendTo('.'+htmlBase);
 
	instance.addEndpoint(
		    $('#endTask'),
		    workflowConnectorEndpoint
		);
	instance.draggable($('#endTask'), {containment:true}); 	
}
/*** EOC - JSPlumb load flowchart ***/

var editAssetNamesLabel ='';
var editWorkflowName = '';
var appendData ='';

// Swathi- 03.03.2020 - Saving the edited workflow 
$("#btnSaveEditedWorkflow").on('click', function(){
	 editAssetNamesLabel ='';
	 editWorkflowName = '';
	 editWorkflowName = $("#editWorkflowName").val().trim();
	// editWorkflowName =editWorkflowName.toLowerCase();
	 var editAssetInst	= $('#editAssetInst').val();
	 var flag = true
		
	//Workflow Name validation
	if(editWorkflowName == null || editWorkflowName == ""){
		$('#editWorkflowName').parent().addClass("error"); 
		$("#errEditWorkflowName").show();  
		flag = false;
	}
	else if (/^[a-zA-Z0-9- ]*$/.test(editWorkflowName) == false) {
			$('#editWorkflowName').parent().addClass("error"); 
		    $("#errEditWorkflowName").html('Please use only alphanumeric character for workflow name.').show();  
			flag = false;
	} else{	
			if(EnteredName.toLowerCase() != editWorkflowName.toLowerCase() ){
				var test = jQuery.inArray( editWorkflowName.toLowerCase(), workflowNames );
				if(test== -1){
					$('#editWorkflowName').parent().removeClass("error"); 
					$("#errEditWorkflowName").hide(); 
					flag =true;
				}	else{				
						$('#editWorkflowName').parent().addClass("error"); 
					    $("#errEditWorkflowName").html('Workflow(s) with the same name already exists.').show();  
						flag = false;					
				}		
			}else{
				$('#editWorkflowName').parent().removeClass("error"); 
				$("#errEditWorkflowName").hide(); 
			}
			finalSaveFlag = true; // Returning true when worklfow name is not empty.	
	}	
	
	 saveFlowchart();
	 
	if(flag == false || saveEditflag == false ){
    	$('#editWorkflow').modal('show');
		return false;
    } else{
    	
   	 	var editedJSON = $('#editedJSON').val();
   	 	var data = "<p>Are you sure you want to assign this asset to the new workflow as this asset will be removed from the previous workflow?</p><button class='right floated ui cancel themeSecondary mini button' onclick='cancelAsset("+editedWorkflowId+")'>No</button><button class='right floated ui primary mini button' onclick='moveAsset("+editedWorkflowId+")'>Yes</button>";
		 appendData = "";
		//appendData += '<tr id="workFlowGridRow_'+editedWorkflowId+'">';
		appendData += '<td class="one wide hidden" id="workFlowID_'+editedWorkflowId+'">'+editWorkflowName+'</td>';
		appendData += '<td class="one wide hidden" id ="workFlowEditedFlag_'+editedWorkflowId+'">'+stateChanged+'</td>';
		appendData += '<td class="one wide hidden">'+editedWorkflowId+'</td>';
		appendData += '<td class="three wide whitespaceNoTrim" id="workFlowNameId_'+editedWorkflowId+'"><div><div class="mediumIconImageCircleStyle"><i class="object ungroup outline icon" style="padding: 2px 3px;"></i></div><span  class = "editableName"  contenteditable="true" style="margin-left: 0.8em;vertical-align: -webkit-baseline-middle;" onkeypress="return (this.innerText.length <= 50)">'+editWorkflowName+'</span></td>';

		// Swathi- Asset Dropdown- 05.03.2020		
		appendData += '<td class="two wide whitespaceNoTrim selectedAssets" id="selectedAssetsId_'+editedWorkflowId+'"><select class="ui dropdown  gridAssetInst" id="gridAssetInst_'+editedWorkflowId+'" name="dropdown" multiple=""><option value="">Select Asset</option></select><span class="selectPopup tram_'+editedWorkflowId+'" data-html="'+data+'" data-position= "right center"></span></td>';	
		
		appendData += '<td class="one wide"><i class="edit icon " onclick="openEditWorkflow('+editedWorkflowId+')"></i>';
		appendData += '<span id= "hiddenJSOn_'+editedWorkflowId+'" style="display:none">'+editedJSON+'</span></td>';
		
		//Swathi- Adding check if Assets are assigned then show different popup else show confirmation message
		 if ( editedWorkflowId == 1) {
			  	appendData += '<td class="disabled disableDeleteIcon deleteGridWorkflowIcon" id="deleteGridWorkflowIcon"><span data-tooltip="The default workflow cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+editedWorkflowId+'" ></i></span></td>';
	    }
		else {
			var data = "<p>Are you sure you want to delete the "+ editWorkflowName +" workflow ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteWorkflowPopup("+editedWorkflowId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteWorkflowData("+editedWorkflowId+")'>Yes</button>";
					
			var assetsFlag ;
				if(editAssetInst != null && editAssetInst != undefined && editAssetInst != ""){
					assetsFlag = true;
				}else{
					assetsFlag = false;
				}
			
			if(assetsFlag == true){
				appendData += '<td class="disabled disableDeleteIcon " id="deleteGridWorkflowIcon_'+editedWorkflowId+'" ><span  data-tooltip="Asset/s are assigned to a workflow hence cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+editedWorkflowId+'"></i></span></td>';
			}
			else {
				appendData += '<td id="deleteGridWorkflowIcon_'+editedWorkflowId+'" ><a><i class="trash icon deleteEditIcon" id="trash_'+editedWorkflowId+'" data-html="'+data+'" onclick="openDeleteWorkflowPopup('+editedWorkflowId+')"></i></a></td>';
			}	
		
		}
		$("#workFlowGridRow_"+editedWorkflowId).html(appendData);
		$('#gridAssetInst_'+editedWorkflowId).append(allAssetNames);
 		$("#gridAssetInst_"+editedWorkflowId).dropdown('set selected',editAssetInst);	
 		
 		$( ".delete" ).html( "<span class='new' data-tooltip ='Deleting the Assets will reset all the states' data-position=' bottom center'> </span>" );					 		
 		 		
 		var interIdPush  = editedWorkflowId.toString();
 		if(autoCretaedIDs.indexOf(editedWorkflowId) == -1){
 			changedRowIds.push(interIdPush); 			
 	    } 		
 		
		// Reset the JSPlumb values
		$(".node").each(function (idx, elem) { 
				elem.remove();
		});
		instance.reset();
		/*if(editAssetInst != null && editAssetInst != undefined){
 			assignedAssets1.push(editAssetInst);
 		}*/
		//assignedAssets1.push(editAssetInst);
		//Remove previous workflow name from the final array which is used to comparison
		workflowNames = workflowNames.filter(e => e != EnteredName.toLowerCase());
		workflowNames.push(editWorkflowName);// Adding edited workflow names to array.
		 $('#gridAssetInst_'+editedWorkflowId).parent().addClass("selectAssetInst ");
		
		$('#editWorkflow').modal('hide'); //.modal('hide dimmer');
		$('#editWorkflow').parent().css("display", "none !important");
		
		$(".popup.visible").hide();
    }
});

/*** Cancel button on Edit workflow modal ***/
$("#btnCancelEditedWorkflow").on('click', function(){
	
	$(".node").each(function (idx, elem) { 
			elem.remove();
	});
	instance.reset();
});

var finalWorkflowJSON =[];

function saveWorkflowDetails() {
	finalWorkflowJSON = [];
	//$.unique(changedRowIds);
	var uniqueIds = getUnique(changedRowIds);
	// check if there are any changes in the grid 
	if(uniqueIds.length != 0){
		$.each(uniqueIds, function(e){
			var id= uniqueIds[e];
			var workId = '';
			if( typeof id === 'string'){
				workId = id;
			} else {
				workId = '';
			}
			var workName = $("#workFlowNameId_"+id).find('span').text().trim();
			if(workName == null || workName == undefined || workName == "" ){
				finalSaveFlag = false;
			}
			var selectedAssets = $('#gridAssetInst_'+id).val();
			if(selectedAssets == null){
				selectedAssets = [];
			}
			var workflowJSON1 = $("#hiddenJSOn_"+id).html();	
			
			//console.log("workflowJSON "+ JSON.parse(workflowJSON));
			finalWorkflowJSON.push({
				"workflowId": workId,
				"workflowName": workName,
				"selectedAssets" : selectedAssets,
				"status":   JSON.parse(workflowJSON1)		
			});			
		});
		
		if(finalSaveFlag == true){
			$.ajax({
			   	type: "PUT",
			   	url: '/repopro/web/workflow/saveWorkflow',
			   	contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(finalWorkflowJSON),
				async: false,
				cache:false,
				complete:function(data){	
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						notifyMessage("Update Workflow ","Workflow  updated Successfully","success");
						$('#tableWorkflow tbody').html("");
						changedRowIds = [];
						autoCretaedIDs = [];
						nontrIds = "";
						targetedtrId = "";
						assetId = "";
						changeRow = "" ;
						resetSelectedArray=[];
						moveAssetId = "";
						loadWorkFlowDetails(); //Page refresh - REPO-803 Fix
						//$('#loadContent').load('informationModeling_WorkFlow.html');
					}
					else {				
						notifyMessage("Update Workflow","Error attempting to update ","fail");
						finalSaveFlag = false;
					}
				}
			});
		}
	}
	
}

function deleteWorkflowData(deleteId){
	
	$.ajax({
	   	type: "DELETE",
	   	url: ' /repopro/web/workflow/deleteWorkflow?workflowId='+deleteId,
	   	contentType : "application/json",
		dataType : "json",
		data : JSON.stringify(finalWorkflowJSON),
		async: false,
		cache:false,
		complete:function(data){	
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){				
				var name = $("#workFlowID_"+deleteId).text().trim();
				var message = name +" workflow is deleted successfully";
				$("#workFlowGridRow_"+deleteId).remove();
				notifyMessage("Delete Workflow",message,"success");
			}
			else {				
				notifyMessage("Delete Workflow","Error attempting to delete ","fail");
			}
		}
	});
}

function deleteState(state){
	var parentnode = state.parentNode;
	instanceCreate.removeAllEndpoints(parentnode);
	$(parentnode).remove(); 
}

function deleteEditState(state){
	var parentnode = state.parentNode;
	instance.removeAllEndpoints(parentnode);
	$(parentnode).remove(); 
	
}

function hasDuplicates(array) {
    return (new Set(array)).size !== array.length;
}

function moveAsset(workId){	
	//Removing the  asset from otehr tds
	assetsTypes = $('#gridAssetInst_'+changeRow).val();
	var ModifiedType = [];
	if(assetsTypes!= null){
		for(var i=0;i<assetsTypes.length;i++){
			if(assetsTypes[i] != moveAssetId){
				ModifiedType.push(assetsTypes[i]);
			}
		}
	}
	if(nontrIds != undefined){
		nontrIds.remove();
	}
	
	// Adding the asset to the current td	
	//$('.selectAssetInst').off('change');
	
	$('#gridAssetInst_'+changeRow).parent().removeClass('selectAssetInst');
	//$('#gridAssetInst_'+changeRow).dropdown('clear');
	$('#gridAssetInst_'+changeRow).html('');	
	$('#gridAssetInst_'+changeRow).append(allAssetNames);
	setTimeout(function(){
		$('#gridAssetInst_'+changeRow).dropdown('set selected',ModifiedType);
	}, 100);
	
	$('#gridAssetInst_'+changeRow).parent().addClass('selectAssetInst');
	resetSelectedArray.push(moveAssetId);
	var assetName= $('#gridAssetInst_'+workId).find('option[value='+moveAssetId+']').text();	
	$('#gridAssetInst_'+workId).parent().removeClass('selectAssetInst');
	$('#gridAssetInst_'+workId).dropdown('clear');
	/*$('#gridAssetInst_'+workId).html('');
	$('#gridAssetInst_'+workId).append(allAssetNames);*/
	setTimeout(function(){
		$('#gridAssetInst_'+workId).dropdown('set selected',resetSelectedArray);
	}, 100);
	$('#gridAssetInst_'+workId).parent().addClass('selectAssetInst');
	$(".selectAssetInst").dropdown('refresh');
	$(".tram_"+workId).popup('hide');
	$("#workFlowLoadingId").click();
	
	//Swathi- Adding check if Assets are assigned then show different popup else show confirmation message	
	var workIdName = $("#workFlowID_"+changeRow).text();
	var select = $("#gridAssetInst_"+changeRow).val();
	var appendData = "";
	 if ( changeRow == 1) {
		  	appendData = '<span data-tooltip="The default workflow cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+changeRow+'" ></i></span>';
   }
	else {
		var data = "<p>Are you sure you want to delete the "+ workIdName +" workflow ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteWorkflowPopup("+changeRow+")'>No</button><button class='right floated ui primary mini button' onclick='deleteWorkflowData("+changeRow+")'>Yes</button>";
				
		var assetsFlag ;
			if(select != null && select != undefined && select != ""){
				assetsFlag = true;
			}else{
				assetsFlag = false;
			}
		
		if(assetsFlag == true){
			$("#deleteGridWorkflowIcon_"+changeRow).addClass("disabled");
			$("#deleteGridWorkflowIcon_"+changeRow).addClass("disableDeleteIcon"); 
			appendData = '<span  data-tooltip="Asset/s are assigned to a workflow hence cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+changeRow+'"></i></span>';
		}
		else {
			$("#deleteGridWorkflowIcon_"+changeRow).removeClass("disabled");
			$("#deleteGridWorkflowIcon_"+changeRow).removeClass("disableDeleteIcon"); 
			appendData = '<a><i class="trash icon deleteEditIcon" id="trash_'+changeRow+'" data-html="'+data+'" onclick="openDeleteWorkflowPopup('+changeRow+')"></i></a>';
		}	
	
	}
	$("#deleteGridWorkflowIcon_"+changeRow).html(appendData);
	
	setTimeout(function(){
		$( ".delete" ).html( "<span class='new' data-tooltip ='Deleting the Assets will reset all the states' data-position=' bottom center'> </span>" );

	}, 200);
	moveAssetId = '';
}

function cancelAsset(workId){
	assetsTypes = $('#gridAssetInst_'+workId).val();	
	$('#gridAssetInst_'+workId).html('');	
	$('#gridAssetInst_'+workId).append(allAssetNames);	
	setTimeout(function(){
		$('#gridAssetInst_'+workId).dropdown('set selected',assetsTypes);
	}, 100);
		
	$(".selectAssetInst").dropdown('refresh');
	$(".tram_"+workId).popup('hide');
	$("#workFlowLoadingId").click();
}


function moveAssetModal(){
	//Removing the  asset from otehr tds
	assetsTypes = $('#gridAssetInst_'+changeRow).val();	
	var ModifiedType = [];
	if(assetsTypes!= null){
		for(var i=0;i<assetsTypes.length;i++){
			if(assetsTypes[i] != moveAssetId){
				ModifiedType.push(assetsTypes[i]);
			}
		}
	}
	if(nontrIds != undefined){
		nontrIds.remove();
	}	
	$('.selectAssetInst').off('change');
	
	$('#gridAssetInst_'+changeRow).parent().removeClass('selectAssetInst');
	$('#gridAssetInst_'+changeRow).dropdown('clear');	
	$('#gridAssetInst_'+changeRow).html('');	
	$('#gridAssetInst_'+changeRow).append(allAssetNames);
	setTimeout(function(){
		$('#gridAssetInst_'+changeRow).dropdown('set selected',ModifiedType);
	}, 100);
	
	$('#gridAssetInst_'+changeRow).parent().addClass('selectAssetInst');
	

	resetSelectedArray.push(moveAssetId);
	var assetName= $('#newAssetInst').find('option[value='+moveAssetId+']').text();	
	
	/*$('#newAssetInst').html('');	
	$('#newAssetInst').append(allAssetNames);*/
	$("#newAssetInst").dropdown('clear');	
	setTimeout(function(){
		$('#newAssetInst').dropdown('set selected',resetSelectedArray);
	}, 100);
			
	
	$(".selectAssetInst").dropdown('refresh');	
	$(".tramNew").popup('hide');
	$("#workFlowLoadingId").click();
	
	//Swathi- Adding check if Assets are assigned then show different popup else show confirmation message	
	var workIdName = $("#workFlowID_"+changeRow).text();
	var select = $("#gridAssetInst_"+changeRow).val();
	var appendData = "";
	 if ( changeRow == 1) {
		  	appendData = '<span data-tooltip="The default workflow cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+changeRow+'" ></i></span>';
   }
	else {
		var data = "<p>Are you sure you want to delete the "+ workIdName +" workflow ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteWorkflowPopup("+changeRow+")'>No</button><button class='right floated ui primary mini button' onclick='deleteWorkflowData("+changeRow+")'>Yes</button>";
				
		var assetsFlag ;
			if(select != null && select != undefined && select != ""){
				assetsFlag = true;
			}else{
				assetsFlag = false;
			}
		
		if(assetsFlag == true){
			$("#deleteGridWorkflowIcon_"+changeRow).addClass("disabled");
			$("#deleteGridWorkflowIcon_"+changeRow).addClass("disableDeleteIcon"); 
			appendData = '<span  data-tooltip="Asset/s are assigned to a workflow hence cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+changeRow+'"></i></span>';
		}
		else {
			$("#deleteGridWorkflowIcon_"+changeRow).removeClass("disabled");
			$("#deleteGridWorkflowIcon_"+changeRow).removeClass("disableDeleteIcon"); 
			appendData = '<a><i class="trash icon deleteEditIcon" id="trash_'+changeRow+'" data-html="'+data+'" onclick="openDeleteWorkflowPopup('+changeRow+')"></i></a>';
		}	
	
	}
	$("#deleteGridWorkflowIcon_"+changeRow).html(appendData);
	
	setTimeout(function(){
		$( ".delete" ).html( "<span class='new' data-tooltip ='Deleting the Assets will reset all the states' data-position=' bottom center'> </span>" );

	}, 200);
	moveAssetId = '';
}

function cancelAssetModal(){	 
	$(".tramNew").popup('hide');
	$(".selectAssetInst").dropdown('refresh');
	$("#workFlowLoadingId").click();
}

function moveAssetModalEdit(){
	//Removing the  asset from otehr tds
	assetsTypes = $('#gridAssetInst_'+changeRow).val();	
	var ModifiedType = [];
	if(assetsTypes!= null){
		for(var i=0;i<assetsTypes.length;i++){
			if(assetsTypes[i] != moveAssetId){
				ModifiedType.push(assetsTypes[i]);
			}
		}
	}
	
	
	if(nontrIds != undefined){
		nontrIds.remove();
	}
	$('.selectAssetInst').off('change');
	
	$('#gridAssetInst_'+changeRow).parent().removeClass('selectAssetInst');
	$('#gridAssetInst_'+changeRow).dropdown('clear');	
	$('#gridAssetInst_'+changeRow).html('');	
	$('#gridAssetInst_'+changeRow).append(allAssetNames);
	setTimeout(function(){
		$('#gridAssetInst_'+changeRow).dropdown('set selected',ModifiedType);
	}, 100);
	
	$('#gridAssetInst_'+changeRow).parent().addClass('selectAssetInst');	
	
	resetSelectedArray.push(moveAssetId);
	var assetName= $('#editAssetInst').find('option[value='+moveAssetId+']').text();	
	/*$('#editAssetInst').html('');	
	$('#editAssetInst').append(allAssetNames);*/
	$("#editAssetInst").dropdown('clear');	
	setTimeout(function(){
		$('#editAssetInst').dropdown('set selected',resetSelectedArray);
	}, 100);
		
	
	$(".selectAssetInst").dropdown('refresh');	
	$(".tramEdit").popup('hide');
	
	//Swathi- Adding check if Assets are assigned then show different popup else show confirmation message	
	var workIdName = $("#workFlowID_"+changeRow).text();
	var select = $("#gridAssetInst_"+changeRow).val();
	var appendData = "";
	 if ( changeRow == 1) {
		  	appendData = '<span data-tooltip="The default workflow cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+changeRow+'" ></i></span>';
   }
	else {
		var data = "<p>Are you sure you want to delete the "+ workIdName +" workflow ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteWorkflowPopup("+changeRow+")'>No</button><button class='right floated ui primary mini button' onclick='deleteWorkflowData("+changeRow+")'>Yes</button>";
				
		var assetsFlag ;
			if(select != null && select != undefined && select != ""){
				assetsFlag = true;
			}else{
				assetsFlag = false;
			}
		
		if(assetsFlag == true){
			$("#deleteGridWorkflowIcon_"+changeRow).addClass("disabled");
			$("#deleteGridWorkflowIcon_"+changeRow).addClass("disableDeleteIcon"); 
			appendData = '<span  data-tooltip="Asset/s are assigned to a workflow hence cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+changeRow+'"></i></span>';
		}
		else {
			$("#deleteGridWorkflowIcon_"+changeRow).removeClass("disabled");
			$("#deleteGridWorkflowIcon_"+changeRow).removeClass("disableDeleteIcon"); 
			appendData = '<a><i class="trash icon deleteEditIcon" id="trash_'+changeRow+'" data-html="'+data+'" onclick="openDeleteWorkflowPopup('+changeRow+')"></i></a>';
		}	
	
	}
	$("#deleteGridWorkflowIcon_"+changeRow).html(appendData);
	
	setTimeout(function(){
		$( ".delete" ).html( "<span class='new' data-tooltip ='Deleting the Assets will reset all the states' data-position=' bottom center'> </span>" );

	}, 200);
	
	moveAssetId = '';
}

function cancelAssetModalEdit(){	 
	$(".tramEdit").popup('hide');
	$(".selectAssetInst").dropdown('refresh');
}

//Disbale of escape button 
$(document).keydown(function(event) { 
  if (event.keyCode == 27 && localStorage.getItem("pageName") == 'informationModeling_WorkFlow') { 
	  if($('#addNewWorkflow').is(":visible") ){
		  $(".node").each(function (idx, elem) { 
				elem.remove();
		});
		  instanceCreate.reset();
	  } else if($('#editWorkflow').is(":visible")){
		  $(".node").each(function (idx, elem) { 
				elem.remove();
		});
		instance.reset();
	  }
     
  }
});

function getKeyByValue(object, value) { 
    return Object.keys(object).find(key => object[key] === value); 
} 

function getUnique(array){
    var uniqueArray = [];
    
    // Loop through array values
    for(i=0; i < array.length; i++){
        if(uniqueArray.indexOf(array[i]) === -1) {
            uniqueArray.push(array[i]);
        }
    }
    return uniqueArray;
}
