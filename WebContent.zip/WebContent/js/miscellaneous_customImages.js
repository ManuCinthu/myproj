	// load font and frame colors 
	var fontColor = "";
	var frameColor = "";
	var fontColorFlag = true;
	var frameColorFlag = true;
	//var logoImgformData = "";
	var backgroundformData = "";
	var headerFormData = "";
	var faviconFormData = "";
	var getLogoImage = "";
	var getBackgroundImage = "";
	var getHeaderLogo  = "";
	var getFaviconLogo = "";
	
	function loadFontAndFrameColours(){
		$.ajax({
			type : "GET",    
			url : "/repopro/web/customimagesmanager/loginfontframecolor",
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				console.log("json : " + JSON.stringify(json));
				if(json.result[0] != null){
					fontColor = "";
					frameColor = "";
					$('#FontColourValue').val(json.result[0].loginFontColorCode);
					fontColor = json.result[0].loginFontColorCode;
					$('#FrameColourValue').val(json.result[0].loginFrameColorCode);
					frameColor = json.result[0].loginFrameColorCode;
					$('#fontColorChange').attr('style','border-top-color: '+json.result[0].loginFontColorCode+'!important');
					$('#frameColorChange').attr('style','border-top-color: '+json.result[0].loginFrameColorCode+'!important');
				}
				$('#showHideLoader').removeClass('active');
			}
		})
	}
	
	
	// Upload Logo Image Filename
	$('#logoImageFileNameFor123').on('change',function(){
		$("#logoImageFileName1").val(this.value);
	})
	
	// Upload Background Image file
	$('#backgroundImageFileFor').on('change',function(){
		document.getElementById("backgroundImageFile").value = this.value;
	})



	// Upload header logo Image file
	$('#headerLogoImageFileNameFor').on('change',function(){
		document.getElementById("headerLogoImageFileName").value = this.value;
	})
	
	// Upload favicon logo Image file
	$('#faviconLogoImageFileNameFor').on('change',function(){
		document.getElementById("faviconLogoImageFileName").value = this.value; 
	})

	// save logo Image 
	/*function saveLogoFile(){
		var flag = true;
		getLogoImage = $('input[id="logoImageFileNameFor123"').get(0).files[0];
		console.log(getLogoImage);
		logoImgformData = new FormData();
		logoImgformData.append('userImage', getLogoImage);
		
		if (typeof getLogoImage != "undefined") {
			var uploadImageSize = getLogoImage.size / 1024;
			if (uploadImageSize > 1024) {
				$('#logoImageFileName').parent().parent().addClass("error");
				$(".logoFileNameErr").html('Image size should not exceed 1 MB').show();
				flag = false;
			} else if(getLogoImage == "" || getLogoImage == null){
				$('#logoImageFileName').parent().parent().addClass("error");
				$(".logoFileNameErr").html('Please upload a file').show();
				flag = false;
			}
			else if (getLogoImage.type == "image/jpeg" || getLogoImage.type == "image/png") {
				$('#logoImageFileName').parent().parent().removeClass("error");
				$(".logoFileNameErr").hide();
			} else {
				$('#logoImageFileName').parent().parent().addClass("error");
				$(".logoFileNameErr").html('Please upload image file of type png or jpeg ').show();
				flag = false;
			}

		}
		
		if(flag == false){
			return true;
		}
		else {
			$('.logoFileNameErr').hide();
			$('#logoImageFileName').parent().parent().removeClass('error');
			$.ajax({
			url : '/repopro/web/customimagesmanager/uploadlogoimage',
			type : 'PUT',
			data : logoImgformData,
			cache : false,
			contentType : false,
			processData : false,
			success : function(data, textStatus, jqXHR) {
				var userObj = JSON.parse(jqXHR.responseText);
				notifyMessage("Logo Image File","Logo Image File Successfully Saved","success");
			},
			error : function(jqXHR, textStatus, errorThrown) {
				notifyMessage("Logo Image File","Error In Saving File","fail");
			}
		});
		}
	}*/
	
	// save background image
	/*function saveBackgroundImgFile(){
		var flag = true;
		getBackgroundImage = $('input[id="backgroundImageFileFor"').get(0).files[0];
		backgroundformData = new FormData();
		backgroundformData.append('userImage', getBackgroundImage);
		
		if (typeof getBackgroundImage != "undefined") {
			var uploadImageSize = getBackgroundImage.size / 1024;
			if (uploadImageSize > 1024) {
				$('#backgroundImageFile').parent().parent().addClass("error");
				$(".backgrounImgFileErr").html('Image size should not exceed 1 MB').show();
				flag = false;
			} else if(getBackgroundImage == "" || getBackgroundImage == null){
				$('#backgroundImageFile').parent().parent().addClass("error");
				$(".backgrounImgFileErr").html('Please upload a file').show();
				flag = false;
			}
			else if (getBackgroundImage.type == "image/jpeg" || getBackgroundImage.type == "image/png") {
				$('#backgroundImageFile').parent().parent().removeClass("error");
				$(".backgrounImgFileErr").hide();
			} else {
				$('#backgroundImageFile').parent().parent().addClass("error");
				$(".backgrounImgFileErr").html('Please upload image file of type png or jpeg ').show();
				flag = false;
			}

		}
		
		if(flag == false){
			return true;
		}
		else {
			$('.backgrounImgFileErr').hide();
			$('#backgroundImageFile').parent().parent().removeClass('error');
			$.ajax({
			url : '/repopro/web/customimagesmanager/uploadbackgroundimage',
			type : 'PUT',
			data : logoImgformData,
			cache : false,
			contentType : false,
			processData : false,
			success : function(data, textStatus, jqXHR) {
				var userObj = JSON.parse(jqXHR.responseText);
				notifyMessage("Background Image File","Background Image File Successfully Saved","success");
			},
			error : function(jqXHR, textStatus, errorThrown) {
				notifyMessage("Background Image File","Error In Saving File","fail");
			}
		});
		}
	}*/
	
	// Header logo Image file 
	/*function saveHeaderLogoImg(){
		var flag = true;
		//debugger;
		getHeaderLogo = $('input[id="headerLogoImageFileNameFor"').get(0).files[0];
		headerFormData = new FormData();
		headerFormData.append('userImage', getHeaderLogo);
		
		if (typeof getHeaderLogo != "undefined") {
			var uploadImageSize = getHeaderLogo.size / 1024;
			if (uploadImageSize > 1024) {
				$('#headerLogoImageFileName').parent().parent().addClass("error");
				$(".headerLogoImgFileErr").html('Image size should not exceed 1 MB').show();
				flag = false;
			} else if(getHeaderLogo == "" || getHeaderLogo == null){
				$('#headerLogoImageFileName').parent().parent().addClass("error");
				$(".headerLogoImgFileErr").html('Please upload a file').show();
				flag = false;
			}
			else if (getHeaderLogo.type == "image/jpeg" || getHeaderLogo.type == "image/png") {
				$('#headerLogoImageFileName').parent().parent().removeClass("error");
				$(".headerLogoImgFileErr").hide();
			} else {
				$('#headerLogoImageFileName').parent().parent().addClass("error");
				$(".headerLogoImgFileErr").html('Please upload image file of type png or jpeg ').show();
				flag = false;
			}

		}
		
		if(flag == false){
			return true;
		}
		else {
			$('.headerLogoImgFileErr').hide();
			$('#headerLogoImageFileName').parent().parent().removeClass('error');
			$.ajax({
			url : '/repopro/web/customimagesmanager/uploadheaderlogo',
			type : 'PUT',
			data : headerFormData,
			cache : false,
			contentType : false,
			processData : false,
			success : function(data, textStatus, jqXHR) {
				var userObj = JSON.parse(jqXHR.responseText);
				notifyMessage("Header Logo Image File","Header Logo Image File Successfully Saved","success");
				location.reload();
			},
			error : function(jqXHR, textStatus, errorThrown) {
				notifyMessage("Header Logo Image File","Error In Saving File","fail");
			}
		});
		}
	}*/
	
	// favicon logo Image
	/*function saveFavicon(){
		var flag = true;
		getFaviconLogo = $('input[id="faviconLogoImageFileNameFor"').get(0).files[0];
		faviconFormData = new FormData();
		faviconFormData.append('userImage', getFaviconLogo);
		
		if (typeof getFaviconLogo != "undefined") {
			var uploadImageSize = getFaviconLogo.size / 1024;
			if (uploadImageSize > 1024) {
				$('#faviconLogoImageFileName').parent().parent().addClass("error");
				$(".faviconImgFileErr").html('Image size should not exceed 1 MB').show();
				flag = false;
			} else if(getFaviconLogo == "" || getFaviconLogo == null){
				$('#faviconLogoImageFileName').parent().parent().addClass("error");
				$(".faviconImgFileErr").html('Please upload a file').show();
				flag = false;
			}
			else if (getFaviconLogo.type == "image/jpeg" || getFaviconLogo.type == "image/png") {
				$('#faviconLogoImageFileName').parent().parent().removeClass("error");
				$(".faviconImgFileErr").hide();
			} else {
				$('#faviconLogoImageFileName').parent().parent().addClass("error");
				$(".faviconImgFileErr").html('Please upload image file of type png or jpeg ').show();
				flag = false;
			}

		}
		
		if(flag == false){
			return true;
		}
		else {
			$('.faviconImgFileErr').hide();
			$('#faviconLogoImageFileName').parent().parent().removeClass('error');
			$.ajax({
			url : '/repopro/web/customimagesmanager/uploadfaviconlogo',
			type : 'PUT',
			data : logoImgformData,
			cache : false,
			contentType : false,
			processData : false,
			success : function(data, textStatus, jqXHR) {
				var userObj = JSON.parse(jqXHR.responseText);
				notifyMessage("Favicon Image File","Favicon Image File Successfully Saved","success");
			},
			error : function(jqXHR, textStatus, errorThrown) {
				notifyMessage("Favicon Image File","Error In Saving File","fail");
			}
		});
		}
	}*/
	
	
	// Select Font Color
	var fontColor1 = "";
	$("#fontcolor").change(function(){
		fontColor1 = document.getElementById("fontcolor").value;
	    $("#FontColourValue").innerHTML = fontColor1;
		$('#FontColourValue').val(fontColor1);
		$('#fontColorChange').attr('style','border-top-color: '+fontColor1+'!important');
	});

	// Select Frame Color
	var frameColor1 = "";
	$("#frameColor").change(function(){
	    frameColor1 = document.getElementById("frameColor").value;
	    $("#FrameColourValue").innerHTML = frameColor1;
		$('#FrameColourValue').val(frameColor1);
		$('#frameColorChange').attr('style','border-top-color: '+frameColor1+'!important');
	});
	
	/*function saveFontFrameColor(){
		var frameColor1 = $('#FrameColourValue').val();
		var fontColor1 = $('#FontColourValue').val();
		if(fontColor1 == "" || fontColor1 == null){
			$('.frameColorErr').hide(); 
			$('.fontColorErr').html('Enter Font Color').show();
			return true;
		}
		if(frameColor1 == "" || frameColor1 == null){
			$('.fontColorErr').hide();
			$('.frameColorErr').html('Enter Frame Color').show();
			return true;	
		}
		else {
			$('.fontColorErr').hide();
			$('.frameColorErr').hide(); 
			var fontFrameColorObj = {
					"loginFontColorCode" : fontColor1,
					"loginFrameColorCode" : frameColor1	
				};
				$.ajax({
					url : '/repopro/web/customimagesmanager/updateloginfontframecolor',
					type : 'PUT',
					contentType : 'application/json',
					data : JSON.stringify(fontFrameColorObj),
					complete : function(data){
						var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						notifyMessage("Font and Frame Color Image File","Font And Frame Colors Successfully Saved","success");
					}
					else {
						notifyMessage("Font and Frame Color Image File","Error In Saving File","fail");
					}
					}
				});
		}
		
	}*/
	
	/* function clearLogoFile(){
		 $('#logoImageFileName1').val("");
	 }
	 
	 function clearBackgroundImgFile(){
		 $('#backgroundImageFile').val("");
	 }
	 function clearFontFrameColor(){
		 $('#FontColourValue').val("");
		 $('#FrameColourValue').val("");
	 }
	 
	 function clearHeaderLogoImg(){
		 $('#headerLogoImageFileName').val("");
	 }
	 
	 function clearFavicon(){
		 $('#faviconLogoImageFileName').val("");
	 }*/
	 
	 
	 // save custom details
	 function SaveCustomDetails(){
		 	var flag = true;
			getLogoImage = $('input[id="logoImageFileNameFor123"').get(0).files[0];
			//console.log(getLogoImage);
			var formData = new FormData();
			formData.append('logoImage', getLogoImage);
			
			getBackgroundImage = $('input[id="backgroundImageFileFor"').get(0).files[0];
			formData.append('backgroundImage', getBackgroundImage);
			
			getHeaderLogo = $('input[id="headerLogoImageFileNameFor"').get(0).files[0];
			formData.append('headerLogo', getHeaderLogo);
			
			getFaviconLogo = $('input[id="faviconLogoImageFileNameFor"').get(0).files[0];
			formData.append('faviconLogo', getFaviconLogo);
			
			var frameColor1 = $('#FrameColourValue').val();
			var fontColor1 = $('#FontColourValue').val();
			formData.append("frameColour",frameColor1);
			formData.append("fontColour",fontColor1);
			
			if (typeof getLogoImage != "undefined") {
				var uploadImageSize = getLogoImage.size / 1024;
				if (uploadImageSize > 1024) {
					$('#logoImageFileName1').parent().parent().addClass("error");
					$(".logoFileNameErr").html('Image size should not exceed 1 MB').show();
					flag = false;
				} else if(getLogoImage == "" || getLogoImage == null){
					$('#logoImageFileName1').parent().parent().addClass("error");
					$(".logoFileNameErr").html('Please upload a file').show();
					flag = false;
				}
				else if (getLogoImage.type == "image/jpeg" || getLogoImage.type == "image/png") {
					$('#logoImageFileName1').parent().parent().removeClass("error");
					$(".logoFileNameErr").hide();
				} else {
					$('#logoImageFileName1').parent().parent().addClass("error");
					$(".logoFileNameErr").html('Please upload image file of type png or jpeg ').show();
					flag = false;
				}

			}
			
			// background image file
			if (typeof getBackgroundImage != "undefined") {
				var uploadImageSize = getBackgroundImage.size / 1024;
				if (uploadImageSize > 1024) {
					$('#backgroundImageFile').parent().parent().addClass("error");
					$(".backgrounImgFileErr").html('Image size should not exceed 1 MB').show();
					flag = false;
				} else if(getBackgroundImage == "" || getBackgroundImage == null){
					$('#backgroundImageFile').parent().parent().addClass("error");
					$(".backgrounImgFileErr").html('Please upload a file').show();
					flag = false;
				}
				else if (getBackgroundImage.type == "image/jpeg" || getBackgroundImage.type == "image/png") {
					$('#backgroundImageFile').parent().parent().removeClass("error");
					$(".backgrounImgFileErr").hide();
				} else {
					$('#backgroundImageFile').parent().parent().addClass("error");
					$(".backgrounImgFileErr").html('Please upload image file of type png or jpeg ').show();
					flag = false;
				}

			}
			
			// Header logo Image file 
			if (typeof getHeaderLogo != "undefined") {
				var uploadImageSize = getHeaderLogo.size / 1024;
				if (uploadImageSize > 1024) {
					$('#headerLogoImageFileName').parent().parent().addClass("error");
					$(".headerLogoImgFileErr").html('Image size should not exceed 1 MB').show();
					flag = false;
				} else if(getHeaderLogo == "" || getHeaderLogo == null){
					$('#headerLogoImageFileName').parent().parent().addClass("error");
					$(".headerLogoImgFileErr").html('Please upload a file').show();
					flag = false;
				}
				else if (getHeaderLogo.type == "image/jpeg" || getHeaderLogo.type == "image/png") {
					$('#headerLogoImageFileName').parent().parent().removeClass("error");
					$(".headerLogoImgFileErr").hide();
				} else {
					$('#headerLogoImageFileName').parent().parent().addClass("error");
					$(".headerLogoImgFileErr").html('Please upload image file of type png or jpeg ').show();
					flag = false;
				}

			}
			
			// favicon logo Image
			if (typeof getFaviconLogo != "undefined") {
				var uploadImageSize = getFaviconLogo.size / 1024;
				if (uploadImageSize > 1024) {
					$('#faviconLogoImageFileName').parent().parent().addClass("error");
					$(".faviconImgFileErr").html('Image size should not exceed 1 MB').show();
					flag = false;
				} else if(getFaviconLogo == "" || getFaviconLogo == null){
					$('#faviconLogoImageFileName').parent().parent().addClass("error");
					$(".faviconImgFileErr").html('Please upload a file').show();
					flag = false;
				}
				else if (getFaviconLogo.type == "image/jpeg" || getFaviconLogo.type == "image/png") {
					$('#faviconLogoImageFileName').parent().parent().removeClass("error");
					$(".faviconImgFileErr").hide();
				} else {
					$('#faviconLogoImageFileName').parent().parent().addClass("error");
					$(".faviconImgFileErr").html('Please upload image file of type png or jpeg ').show();
					flag = false;
				}

			}
			
			if(flag == false){
				return true;
			}
			else {
				$('.logoFileNameErr, .backgrounImgFileErr, .headerLogoImgFileErr, .faviconLogoImageFileName').hide();
				$('#logoImageFileName1, #backgroundImageFile, #headerLogoImageFileName, #faviconLogoImageFileName').parent().parent().removeClass('error');
				
				$.ajax({
					url :'/repopro/web/customimagesmanager/customImages',
					type : 'PUT',
					contentType : false,
					processData : false,
					data : formData,
					complete : function(data){
						var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						location.reload();
						/*setTimeout(function(){
							notifyMessage("Custom Images","Custom Images are saved successfully","success");
						}, 2000)*/
						
					}
					
					},
					error : function(data){
						notifyMessage("Custom Theme","Error attempting to update custom images","fail");
					}
				});
				
				
				
				
			}
	 }