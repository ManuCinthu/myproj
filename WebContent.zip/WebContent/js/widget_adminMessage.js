appendData = "";
//get admin message
function loadWidgetAdminMessageDetails(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/message",
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(localStorage.getItem("showAdminData") == "true"){
					$('#widgetAdminMessageContent').html(json.result[0].adminMessage);
					$('#adminMessageWidget').show();
				}else{
					$('#adminMessageWidget').hide();
				}
				if(json.result[0].ison == 1){
					//$("#announcementData").html(json.result[0].maintenance);
					if(localStorage.getItem("bannerDataForSecssion") == "true"){
						localStorage.setItem("showBannerData","true");
					}else{
						localStorage.setItem("showBannerData","false");
					}
					
					//$("#marqueeText").html(json.result[0].maintenance);
					$("#announcementCard").css('display','none');
					localStorage.setItem("marqueText",json.result[0].maintenance);
				}
				else if(json.result[0].ison == 0){
					localStorage.setItem("showBannerData","false")
					$("#announcementCard").css('display','none');
				}
				showBannerText();
				
			}
			$('#showHideLoader').removeClass('active');
		}
	
	});
}

//function hide admin message for the secssion
function hideAdminMessageSecssion(){
	
	$('#adminMessageWidget').hide();
	localStorage.setItem("showAdminData","false");
}