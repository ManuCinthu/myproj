// display all mail templates on load
 function loadMailTemplates(){
	 appendData = "";
		$.ajax({
			type : "GET",
			url : "/repopro/web/mailTemplate/allMailTemplate",
			dataType : "json",
			async: false,
			complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					$('#mailTemplateGrid').hide();
					$('#noGridData').show();
					$('#noGridData').html('<div class="ui message">No mail templates added yet</div>'); 
				}else {
					$('#noGridData').hide();
					$('#mailTemplateGrid').show();
					$('#mailTemplateGrid table tbody').html("");
					$.each(json.result, function(i) {
						appendData = getMailTemplateDetails(json.result[i].mailTemplateId,json.result[i].functionalityName,json.result[i].mailTemplate);
						$('#mailTemplateGrid table tbody').append(appendData);
					});
				}
				}
			 $('#showHideLoader').removeClass('active');
			}
		});
 }

 
//load mail configuration data
 function loadMailConfiguration(){
		$.ajax({
			type : "GET",
			url : "/repopro/web/mailconfig/getallmailconfig",
			dataType : "json",
			async: false,
			complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					
				}else {
						var mcUserNameValue = json.result[0].userName;
	                    var mcPasswordValue = json.result[0].password;
	                    var mcHostValue = json.result[0].host;
	                    var mcPortValue = json.result[0].port;
	                    var mcTLS = json.result[0].startTLSEnable;
	                    var mcAuth = json.result[0].authentication;
	                    var mcSenderMailId = json.result[0].senderMailId;
						
						//alert(mcUserNameValue +  mcPasswordValue +  mcHostValue + mcPortValue+ mcTLS + mcAuth + mcSenderMailId  );
						$('#editUserName').val(mcUserNameValue);
			            $('#editMCPassword').val(mcPasswordValue);
			            $('#editHost').val(mcHostValue);
			            $('#editPort').val(mcPortValue);
			            $('#senderMailID').val(mcSenderMailId);
			           
			            if(mcTLS == 1){
			            $('#check_TLS').prop('checked', true);
			            }else{
			            $('#check_TLS').prop('checked', false);
			            }
			           
			            if(mcAuth == 1){
			            $('#check_AUTH').prop('checked', true);
			            }else{
			            $('#check_AUTH').prop('checked', false);
			            }
						
				}
				}
			}
		});
 }
 
 
 loadMailConfiguration();
 
 // add mail template data to table 
   function getMailTemplateDetails(mailTemplateId, event, mailTemplate){
	   	appendData = "";
		appendData += '<tr id="trMailTemplateId'+mailTemplateId+'">';
		appendData += '<td class="hidden" id="mailTemplateId'+ mailTemplateId +'">' + mailTemplateId + '</td>';
		var eventName;
		var MacroAvailable;
			if(event == "createAssetType"){
				eventName =  "New Asset Type Created";
				MacroAvailable = "%assetType%";
			}
			if(event == "updateAssetType"){
				eventName = "Asset Type Details Updated";
				MacroAvailable = "%assetType%";	
			}
				
			if(event == "deleteAssetType"){
				eventName = "Asset Type Deleted";
				MacroAvailable = "%assetType%";
			}
				
			if(event == "createAssetInstanceNonVersion"){
				eventName = "New Asset Instance Created";
				MacroAvailable = "%assetType%, %assetInstName%";
			}
				
			if(event == "updateAssetInstDescForVersionableAsset"){
				eventName = "Asset Instance Description Updated (Versionable Asset)";
				MacroAvailable = "%assetInstName%, %versionName%";
			}
				
			if(event == "updateAssetInstDescForNonVersionableAsset"){
				eventName = "Asset Instance Description Updated (Non-Versionable Asset)";
				MacroAvailable = "%assetInstName%";
			}
				
			if(event == "saveDependenciesForVersionableAsset"){
				eventName = "Relationships Updated (Versionable Asset)";
				MacroAvailable = "%assetInstName%, %versionName%";
			}
				
			if(event == "saveDependenciesForNonVersionableAsset"){
				eventName = "Relationships Updated (Non-Versionable Asset)";
				MacroAvailable = "%assetInstName%";
			}
	
			if(event == "updateAssetInstanceName"){
				eventName = "Asset Instance Renamed";
				MacroAvailable = "%oldInstanceName%, %newInstanceName%";
			}
			
			if(event == "updatePropertiesForVersionableAsset"){
				eventName = "Property Values Updated (Versionable Asset)";
				MacroAvailable = " %assetInstName%, %versionName%";
			}
				
			if(event == "updatePropertiesForNonVersionableAsset"){
				eventName = "Property Values Updated (Non-Versionable Asset)";
				MacroAvailable = "%assetInstName%";
			}
				
			if(event == "removeTaxonomyName"){
				eventName = "Taxonomy Node Deleted from Tree";
				MacroAvailable = "%taxName%";
			}
				
			if(event == "renameTaxonomyName"){
				eventName = "Taxonomy Node Deleted from Tree";
				MacroAvailable = "%taxName%";
			}
				
			if(event == "assignTaxNameForAssetInstanceForVersionableAsset"){
				eventName = "Taxonomy Assigned to Asset Instance (Versionable Asset)";
				MacroAvailable = "%assignTaxName%, %assetInstName%, %versionName%";
			}
				
			if(event == "unassignTaxNameForAssetInstanceForVersionableAsset"){
				eventName = "Taxonomy Unassigned from Asset Instance (Versionable Asset)";
				MacroAvailable = "%unassignTaxName%, %assetInstName%, %versionName%";
			}
	
			if(event == "assignTaxNameForAssetInstanceForNonVersionableAsset"){
				eventName = "Taxonomy Assigned to Asset Instance (Non-Versionable Asset)";
				MacroAvailable = "%assignTaxName%, %assetInstName%";
			}
				
			if(event == "unassignTaxNameForAssetInstanceForNonVersionableAsset"){
				eventName = "Taxonomy Unassigned from Asset Instance (Non-Versionable Asset)";
				MacroAvailable = "%unassignTaxName%, %assetInstName%";
			}
				 
			if(event == "updateUserProfile"){
				eventName = "User Profile Updated";	
				MacroAvailable = "%fullName%, %emailId%, %userName%";
			}
				
			if(event == "passwordReset"){
				eventName = "User Password Changed";
				MacroAvailable = "%newPassword%";
			}
				
			if(event == "editAssetInstanceVersion"){
				eventName = "Version Edited for Asset Instance";
				MacroAvailable = "%assetInstName%, %versionName%, %newVersionName%";
			}
				
			if(event == "deleteAssetInstanceVersionForVersionableAsset"){
				eventName = "Asset Instance Deleted (Versionable Asset)";
				MacroAvailable = "%assetInstName%, %versionName%";
			}
				
			if(event == "deleteAssetInstanceVersionForNonVersionableAsset"){
				eventName = "Asset Instance Deleted (Non-Versionable Asset)"; 
				MacroAvailable = "%assetInstName%";
			}
			
			if(event == "addTaxonomyName"){
				eventName = "A taxonomy child has been added"; 
				MacroAvailable = "%childTaxonomyName%, %parentTaxonomyName%";  
			}
			
			if(event == "updateAssetInstanceForNonVersionableAsset"){
				eventName = "Asset Instance has been updated (Non-Versionable Asset)"; 
				MacroAvailable = "%assetInstName%";  
			}
			
			if(event == "updateAssetInstanceForVersionableAsset"){
				eventName = "Asset Instance has been updated (Versionable Asset)"; 
				MacroAvailable = "%assetInstName%,%versionName%";  
			}
				  
			/*if(event == "importExcelFailure"){
				eventName = "Import Excel Failed";
				//MacroAvailable =
			}
				
			if(event == "exportExcelFailure"){
				eventName = "Export Excel Failed";  
				//MacroAvailable =
			}*/
				 
			if(event == "createAssetInstanceVersion"){
				eventName = "Create New Asset Instance Version"; 
				MacroAvailable =  "%assetInstName%, %versionName%";
			}
				
			if(event == "renameTaxonomyName"){
				eventName = "Taxonomy Node Renamed";
			    MacroAvailable =  "%oldTaxName%, %newTaxName%";
			}
			
		appendData += '<td id="event_'+mailTemplateId+'">' + eventName + '</td>';
		appendData += '<td id="mailTemplate_'+mailTemplateId+'" ><textarea class="tempTextArea" id="txtAreaBody_'+mailTemplateId+'" rows="3" maxlength="10000" style="color: #525658 !important; border-color: #dedede; width:100% !important;">'+ mailTemplate + '</textarea></td>';	
		/*appendData += '<td id="mailTemplate_'+mailTemplateId+'" contenteditable="true">'+ mailTemplate + '</td>';*/
		appendData += '<td id="macrosAvailable_'+mailTemplateId+'" class="disabled" style="color:#909598 !important;">'+ MacroAvailable + '</td>';
		appendData += '</tr>';
		
		return appendData;
 }
   
   var arrMailTemplateData = [];
   function btnSubmitMailTemplateDetails(){
	 var validationFlag = true;
	 var message = "";
	 arrMailTemplateData.length = 0;
	 $('#tableMailTemplate tbody tr').each(function(h){
		 var $tds = $(this).find('td'), mailTemplateId = $tds.eq(0).text(),event = $tds.eq(1).text(), mailTemplate =  product = $tds.eq(2).find('textarea').val();
		 $("#txtAreaBody_"+mailTemplateId).removeClass("errorThemeStyle");//edited by aditya 12.03.18
		 
		 mailTemplate = mailTemplate.trim();
		 if(mailTemplate == null || mailTemplate == ""){
			 $("#txtAreaBody_"+mailTemplateId).addClass("errorThemeStyle");//edited by aditya 12.03.18
			 validationFlag = false;
			 message = "Mail Template cannot be empty.";
		 }else{
			 var macros = $("#macrosAvailable_"+mailTemplateId).text().trim();
			 macros = macros.replace(/ /g,"");
			 var arr = macros.split(",");
			 var valuesInTemplate = mailTemplate.match(/\%(.*?)\%/g);
			 
			 if(valuesInTemplate != null){
				 $.each(valuesInTemplate,function(i){
					 var count = 0;
					 
					 $.each(arr,function(j){
						 if(valuesInTemplate[i] == arr[j]){
							 count++;
						 }
					 });
						
					 if(count == 0){
						 validationFlag = false; 
						 $("#txtAreaBody_"+mailTemplateId).addClass("errorThemeStyle");//edited by aditya 12.03.18
						 message = "Unknown macro name found.";
					 }
					 
				 });
			 }
				
			 
			 arrMailTemplateData.push({"mailTemplate":mailTemplate, "mailTemplateId":mailTemplateId})
		 }
			
	 });

	 
		 if(validationFlag){
			 $.ajax({
					type: "PUT",
					url: "/repopro/web/mailTemplate/updateMailTemplate",
					contentType : "application/json",
					dataType : "json",
					data : JSON.stringify(arrMailTemplateData),
					async: false,
					complete:function(data){
						appenddata = "";
						var json = JSON.parse(data.responseText);
						if(json.status == "SUCCESS"){
							  notifyMessage("Mail Template","Mail Template successfully updated.","success");
						}
						else {
							  notifyMessage("Mail Template","Failed to update Mail Template.","fail");
	
						}
					}
				});
		 }else{
			 notifyMessage("Mail Template",message,"fail");
		 }
		
 }
   
  //Password show and hide method - 23.04.2020 
	function showHidePassContent(){
       var getPassValue =  $('#editMCPassword').val();
       var getText = $('#check').text();
      
       getPassValue = getPassValue.length;
       if(getPassValue > 0 && getText == 'Show') {
           $('#check').html('');
         $('#check').html('Hide');
       $('#editMCPassword').get(0).type = 'text';
      } else{
       $('#editMCPassword').get(0).type = 'password';
        $('#check').html('');
         $('#check').html('Show');
      }
	}
	
	//restrict white space entries in password field - chandana 22.5.2020
	$(function(){
		  $('#editMCPassword').bind('input', function(){
		    $(this).val(function(_, v){
		     return v.replace(/\s+/g, '');
		    });
		  });
		});
	
	
	 var getUsername,getHost,getPort,getMCPassword,getSenderEmailID = '';
	 var getTLSvalue = 0;
	 var getAuth = 0;
	 var MCValidationFlag;
	 var appendMCdata = '';
	 var mailDetails = '';
	 var testMailDetails = '';
	 var mailConfigSubmitFlag;
	
	function mailConfigFieldValidation(){
		MCValidationFlag = true;
		$(".errUserName").hide();
        $('#editUserName').parent().removeClass("error");
        $(".errPassword").hide();
        $('#editMCPassword').parent().removeClass("error");
        $(".errHost").hide();
        $('#editHost').parent().removeClass("error");
        $(".errPort").hide();
        $('#editPort').parent().removeClass("error");
		
        getUsername = $('#editUserName').val();
		 getHost = $('#editHost').val();
		 getPort = $('#editPort').val();
		 getMCPassword = $('#editMCPassword').val();
		 getSenderEmailID = $('#senderMailID').val();
		 getTLSvalue = $('#check_TLS').val();
		 getAuth = $('#check_AUTH').val();
		 
		//user name  validation
			if(getUsername == null || getUsername == ""){
				$('#editUserName').parent().addClass("error"); 
				$(".errUserName").show();  
				MCValidationFlag = false;
			}
			else{
				$('#editUserName').parent().removeClass("error"); 
				$('.errUserName').hide(); 
			}
		 
			//host validation
			 if(getHost == null || getHost == ""){
					$('#editHost').parent().addClass("error"); 
					$(".errHost").show();  
					MCValidationFlag = false;
				}
				else{
					if (/^[a-zA-Z0-9\.]*$/.test(getHost) == false) {
						$('#editHost').parent().addClass("error"); 
					    $(".errHost").html('Please use only alphanumeric character and . for host name.').show();  
					    MCValidationFlag = false;
					}
					else{
						$('#editHost').parent().removeClass("error"); 
						$(".errHost").hide(); 
					}
				}
			 
				//port validation			
			 if(getPort == null || getPort == "" || getPort == NaN ||getPort =="NaN" ){
					$('#editPort').parent().addClass("error"); 
					$(".errPort").show();  
					MCValidationFlag = false;
				}
				else{
					if (/^[0-9-]*$/.test(getPort) == false) {
						$('#editPort').parent().addClass("error"); 
					    $(".errPort").html('Please use only numerical character for port name.').show();  
					    MCValidationFlag = false;
					}
					else{
						$('#editPort').parent().removeClass("error"); 
						$(".errPort").hide(); 
						 getPort = parseInt(getPort);
					}
				}
				
				//password validation				
				if (getMCPassword == null || getMCPassword == "") {
					$('#editMCPassword').parent().addClass("error");
					$(".errPassword").html('Please provide password').show();
					MCValidationFlag = false;
				} else {
					if(getMCPassword.length > 7 && getMCPassword.match(/[a-z]/) && getMCPassword.match(/[A-Z]/) && getMCPassword.match(/\d/) && getMCPassword.match(/[!@#$%^&*]/)){
						$('#editMCPassword').parent().removeClass("error");
						$(".errPassword").hide();
					}else{
						$('#editMCPassword').parent().addClass("error");
						$(".errPassword").html('Password must be <br/> at least 8 characters long,<br/>include one lowercase letter,<br/> include one uppercase letter,<br/> include one number,<br/> include one special character').show();
						MCValidationFlag = false;
					}
					

				}
				
					
			         if($('#check_TLS').prop("checked") == true){
			            var getTLSvalue = 1;
			           
			            }else{
			            var getTLSvalue = 0;
			            }
			           
			           
			            if($('#check_AUTH').prop("checked") == true){
			            var getAuth = 1;
			           
			            }else{
			            var getAuth = 0;
			            }
			            
			            
			            if(mailConfigSubmitFlag == true){
			            mailDetails = {
				 				   "userName":getUsername ,
				 				   "password": getMCPassword,
				 				   "authentication":getAuth ,
				 				   "startTLSEnable":getTLSvalue ,
				 				   "host":getHost ,
				 				   "port": getPort,
				 				"senderMailId":getSenderEmailID
				 				}
			            }
			            else{
			            	
			            	   testMailDetails = {
					 				   "userName":getUsername ,
					 				   "password": getMCPassword,
					 				   "authentication":getAuth ,
					 				   "startTLSEnable":getTLSvalue ,
					 				   "host":getHost ,
					 				   "port": getPort,
					 				"senderMailId":getSenderEmailID
					 				}
			            }
				 				
				 				
	}
   
	
	
 // Save mail configuration details - chandana 28.04.2020  
   function btnSubmitMailConfigurationDetails(){
	      mailConfigSubmitFlag = true;
	   
		 var arrMailConfigurationData = []; 
	
		 
		 mailConfigFieldValidation();
		  
			            
			        
			 	arrMailConfigurationData.push({ "mailDetails": mailDetails});
				
				//Post call
				
				//console.log( JSON.stringify(arrMailConfigurationData))
				
				
				$('#hiddenInputForMCdata').val(JSON.stringify(mailDetails));
				if(MCValidationFlag){
				xhr = "";
				xhr = new XMLHttpRequest();
				xhr.open("POST","/repopro/web/mailconfig/addMailconfig");
				xhr.onload = function(event){
					var json = JSON.parse(event.target.responseText);

					if(json.status == "SUCCESS"){
						notifyMessage("Mail configuration ","Mail configuration successfully updated.","success");
					   }else{
						   notifyMessage("Mail configuration","Failed to update Mail configuration.","fail");
						   }
			 };
				var formData = new FormData(document.getElementById("sendMailConfigurationData"));
				xhr.send(formData);
				}	
				
		 
	
   }
   
   //Test mail call - chandana - 21-05-2020
   function sendTestMail(){

	   var arrTestMailConfigurationData = []; 
	   mailConfigSubmitFlag = false;

	   mailConfigFieldValidation();
		
	
		 				
	   arrTestMailConfigurationData.push({ "mailDetails": testMailDetails});
		
		
		//Post call
		
		
		$('#hiddenInputForMCdata').val(JSON.stringify(testMailDetails));
		if(MCValidationFlag){
		xhr = "";
		xhr = new XMLHttpRequest();
		xhr.open("POST","/repopro/web/mailconfig/testMailconfig");
		xhr.onload = function(event){
			var json = JSON.parse(event.target.responseText);

			if(json.status == "SUCCESS"){
				notifyMessage("Mail configuration ","Test mail sent successfully.","success");
			   }else{
				   notifyMessage("Mail configuration","Failed to send test mail.","fail");
				   }
	 };
		var formData = new FormData(document.getElementById("sendMailConfigurationData"));
		xhr.send(formData);
		}	
		
	   
   }