
//get admin message
function loadAdminMessageDetails(){
	$('#showHideLoader').removeClass('active');
	$.ajax({
		type : "GET",
		url : "/repopro/web/message",
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				
				$('#showAdminMessage').html(json.result[0].adminMessage);
				
				var editor = CKEDITOR.instances.msgBoardAdminMsgTextArea;
			    if (editor) {
			        editor.destroy(true); 
			    }   
			    CKEDITOR.replace('msgBoardAdminMsgTextArea');
				CKEDITOR.instances['msgBoardAdminMsgTextArea'].setData(json.result[0].adminMessage);
				if(json.result[0].maintenance != " "){
					$('#bannerTextarea').val(json.result[0].maintenance);
				}else{
					hidebannerMessage();
				}
				
				if(json.result[0].ison == 1){
					$('#bannerToggleSwitch').prop('checked', true);
					document.getElementById("bannerTextarea").disabled = false;
				}
				else if(json.result[0].ison == 0){
					$('#bannerToggleSwitch').prop('checked', false);
					document.getElementById("bannerTextarea").disabled = true;
				}
			}
		}
	});
}

//update admin message 
function updateAdminMessage(){

	//trimming white spaces and strings with empty values - chandana 21.02.2020 - #708
	var getTextfromCKeditor = $(".cke_contents iframe").contents().find("body").text();
	var trimextfromCKeditor = $.trim(getTextfromCKeditor);
	var adminMessageData = CKEDITOR.instances['msgBoardAdminMsgTextArea'].getData().trim();	
	if(getTextfromCKeditor == "" || getTextfromCKeditor == null || trimextfromCKeditor == ""){
		adminMessageData = "";
	}
	else{
		adminMessageData = adminMessageData;
	}
	/*if(adminMessageData != ""){
		var data = CKEDITOR.instances['msgBoardAdminMsgTextArea'].dataProcessor.toHtml(adminMessageData);

		adminMessageData = data;

	}*/
	var createdOn = getCurrentDateAndTime();
	var createdBy = loggedInUserName;

	var obj = {
				"createdOn": createdOn, 
				"createdBy": createdBy, 
				"adminMessage": adminMessageData
			};
	
		//console.log(" obj  "+JSON.stringify(obj));
	if(adminMessageData == ""){
		notifyMessage("Message Board","Please provide the admin message","warning");
	}
	else{
		$.ajax({
		       type: "POST",
		       url: "/repopro/web/message",
		       contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				complete:function(data){
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					
						$("#showAdminMessage").show();
						$("#showAdminMessageButton").removeClass("hideElement");
						$("#showAdminMessage").html(json.result[0].adminMessage);
						$("#editAdminMessage").hide();
						notifyMessage("Message Board","Admin Message Updated Successfully","success");

				}else{
						notifyMessage("Message Board","Error attempting to update Admin message","fail");
					
				}	
					
				}
		  });
	}
}

//update banner text
function updateBannerMessage(){
	
	var adminMessageData = CKEDITOR.instances['msgBoardAdminMsgTextArea'].getData();	
	/*if(adminMessageData != ""){
		var data = CKEDITOR.instances['msgBoardAdminMsgTextArea'].dataProcessor.toHtml(adminMessageData);

		adminMessageData = data;

	}*/
	var bannerData = $('#bannerTextarea').val();
	var createdOn = getCurrentDateAndTime();
	var createdBy = loggedInUserName;
	var ison = '';
	
	if($('#bannerToggleSwitch').prop('checked')){
		ison = 1;
	}
	else{
		ison = 0;
	}
	
	var obj = {
			"createdOn":createdOn, 
			"createdBy":createdBy, 
			"maintenance":bannerData, 
			"ison":ison
		
			};
	
	//console.log("   updateBannerMessage obj "+JSON.stringify(obj))
	if(bannerData == null || bannerData == "" && ison == 1){
		notifyMessage("Message Board","Please provide the banner message","warning");
	}
	else{
		$.ajax({
			type: "POST",
			url: "/repopro/web/message/addBannerMessage",
			contentType : "application/json",
			dataType : "json",
			data : JSON.stringify(obj),
			async: false,
			complete:function(data){
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){

					//getHomeDetails(this);
					notifyMessage("Message Board","Banner Message Updated Successfully","success");
					
					if(ison == 1){
						localStorage.setItem("bannerDataForSecssion","true");
						localStorage.setItem("showBannerData","true");
						localStorage.setItem("marqueText",json.result[0].maintenance);
						$('#bannerTextarea').val(json.result[0].maintenance);
					}else{
						localStorage.setItem("bannerDataForSecssion","false");
						localStorage.setItem("showBannerData","false");
					}
					showBannerText();

				}else{
					notifyMessage("Message Board","Error attempting to update banner message","fail");

				}	

			}
		});
	}
}


//show or hide banner
function showHideBanner(){
	if($('#bannerToggleSwitch').prop('checked')){
		//$('#bannerShowHide').css('visibility','visible');
		document.getElementById("bannerTextarea").disabled = false;
	}
	else{
		//$('#bannerShowHide').css('visibility','hidden');
		document.getElementById("bannerTextarea").disabled = true;
	}
}

// get current date and time
function getCurrentDateAndTime(){
	var dt = new Date();
	var dateTime =dt.getFullYear() + "-" + (dt.getMonth()+1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
	return dateTime;
}

$("#showAdminMessageButton").on("click",function(){
		$("#showAdminMessage").hide();
		$("#showAdminMessageButton").addClass("hideElement");
		$("#editAdminMessage").show();
		var editor = CKEDITOR.instances.msgBoardAdminMsgTextArea;
	    if (editor) {
	        editor.destroy(true); 
	    }   
	    CKEDITOR.replace('msgBoardAdminMsgTextArea');
	    CKEDITOR.instances['msgBoardAdminMsgTextArea'].setData($("#showAdminMessage").html());
});

/*$("#cancelAdminMessage").on("click",function(){
	var editor = CKEDITOR.instances.msgBoardAdminMsgTextArea;
    if (editor) {
        editor.destroy(true); 
    }
	$("#showAdminMessage").show();
	$("#showAdminMessageButton").removeClass("hideElement");
	$("#editAdminMessage").hide();
});*/