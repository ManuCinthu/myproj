autoId = 0; 

//show hide tag segment
function showTagSegment_AddAssetInst(){
	$('#tagSegment_AddAssetInst').toggle("slow");
	 $('span', "#showHideTagSegment_AddAssetInst").toggle();
}

function addNewTag_AddAssetInst(){
	var getNewTagName = $("#addNewTagName_AddAssetInst").val().trim();
	appendData = loadTagData(getNewTagName);
	$("#addNewTagSegment_AddAssetInst").append(appendData);
	autoId++;
	$("#addNewTagName_AddAssetInst").val("");
}

//load tag
function loadTagData(getNewTagName){
	appendData = "";
	appendData = '<a class="ui  label" id="tagName_'+autoId+'" style="margin-bottom:0.5em;"><i class="tag icon"></i> '+getNewTagName+' <i class="delete icon" onclick="deleteTag('+autoId+')"></i></a>'; 
	return appendData;
}

//delete tag
function deleteTag(id){
	$("#tagName_"+id).remove();
}