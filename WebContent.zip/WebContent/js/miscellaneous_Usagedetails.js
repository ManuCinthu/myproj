appendData = "";
globalAssetInstanceVersionId = "";
selectedList = [];
formRange = 0;
var browserAssetName = localStorage.getItem("browserAssetName");
var browserAssetId = localStorage.getItem("browserAssetId");
flag = "";

//get list of parameters saved for specific user and asset
function loadDynamicTableHeader(browserAssetId, browserAssetName){
	$('#assetName').html("");
	$('#th_AssetName').html("");
	$('#assetName').html(browserAssetName);
	$('#th_AssetName').html(browserAssetName + " Name");
	$.ajax({
		type : "GET",
		url : "/repopro/web/showHideColumn/getShowHideColumn?assetId="+browserAssetId+"&userId=1",
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				appendData = "";
				selectedList.length = 0;
				$('#browserAssetGrid table thead tr th.assetFields').remove();
				$.each(json.result[0].showParamDetails, function(key,value){
					selectedList.push(value);
					appendData = '<th class="assetFields">'+value+'</th>';
					$('#browserAssetGrid table thead tr').append(appendData);
				});
				
				
				$.each(json.result[0].showAivDetails, function(key, value){
					if(value == '`'){
						$("#th_AssetId").removeClass('hidden');
					}
				});
				
				$.each(json.result[0].showGroupDetails, function(key, value){
					if(value == '~'){
						$("#th_associatedGroups").removeClass('hidden');
					}
				});
				
			}
		}
	});
}

//get asset details
function loadBrowserAssets(browserAssetName){
	var url = "";
	if(selectedList.length == 0){
		url = "/repopro/web/assetInstanceVersionManager/getAssetInstanceGrid/Admin?assetName="+browserAssetName+"&from="+formRange;
	}else{
		url = "/repopro/web/assetInstanceVersionManager/getAssetInstanceGrid/Admin?assetName="+browserAssetName+"&from="+formRange+"&param="+selectedList;
	}

	$.ajax({
		type : "GET",
		url : url,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					$('#browserAssetGrid').hide();
					$('#noGridData').show();
					$('#noGridData').html('<div class="ui message">No assets added yet</div>'); 
				}else {
					$('#noGridData').hide();
					$('#browserAssetGrid').show();
					if(flag == true){
						$('#browserAssetGrid table tbody tr').remove();
					}
					
					$.each(json.result, function(i) {
						
						if(json.result[i].assetInstanceVersionId != globalAssetInstanceVersionId){
							appendData = "";
							appendData += '<tr id="'+json.result[i].assetInstanceVersionId+'">';

							//adding static column 
							appendData += getBrowserAssetDetails(json.result[i].assetInstanceVersionId,json.result[i].assetInstName,json.result[i].versionName, json.result[i].description);

							//adding dynamic column 
							$.each(selectedList,function(count,value){
								value = value.replace(/ /g,"_");
								appendData += '<td class="loadingData assetFields" id="'+json.result[i].assetInstanceVersionId+'_'+value+'"><div class="ui active centered inline loader"></div></td>';
							});
							appendData += '</tr>';

							$('#browserAssetGrid table tbody').append(appendData);
							globalAssetInstanceVersionId = json.result[i].assetInstanceVersionId;
						}


						
					});


					$.each(json.result, function(i) {

						$.each(selectedList,function(count,value){
							if (json.result[i].assetParamName == value){
								value = value.replace(/ /g,"_");
								$('#'+json.result[i].assetInstanceVersionId+'_'+value).html(json.result[i].paramValue).removeClass('loadingData');
							}
						});

					});

					$('#browserAssetGrid table tbody').find('td[class="loadingData assetFields"]').each (function() {
						var id = $(this).attr("id");
						$("#"+id).html('');
					}); 

					$('#loadingMoreAssetDetails').css('display', 'none');
					formRange = formRange + 20;
				}
			}
			else{
				$('#loadingMoreAssetDetails').css('display', 'none');
			}
		}
	});
}

function getBrowserAssetDetails(assetInstanceVersionId, assetInstName, versionName, Description){
	
	if($("#th_AssetId").hasClass('hidden')){
		appendData += '<td id="assetInstName_'+assetInstanceVersionId+'" class="hidden">'+assetInstanceVersionId+'</td>';
	}else{
		appendData += '<td id="assetInstName_'+assetInstanceVersionId+'">'+assetInstanceVersionId+'</td>';
	}
	
	appendData += '<td id="assetInstName'+assetInstanceVersionId+'">' + assetInstName + '</td>';
	appendData += '<td id="versionName'+assetInstanceVersionId+'">'+ versionName + '</td>';
	appendData += '<td id="Description'+assetInstanceVersionId+'">'+ Description + '</td>';
	appendData += '<td class="center aligned"><a><i class="trash icon deleteEditIcon"></i></a></td>';
	
	if($("#th_associatedGroups").hasClass('hidden')){
		appendData += '<td id="associatedGroups_'+assetInstanceVersionId+'" class="center aligned hidden"><a><i class="configure icon deleteEditIcon"></i></a></td>';
	}else{
		appendData += '<td id="associatedGroups_'+assetInstanceVersionId+'" class="center aligned"><a><i class="configure icon deleteEditIcon"></i></a></td>';
	}
	
	return appendData;
	
}

//show more details
function showMoreData(){
	$("#showMoreData").toggle();
	$('span','#showHideMoreData').toggle();
}