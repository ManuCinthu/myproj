countOfData = 0;
infiniteScrollFlag = true;
var appendAVData = '';

//** Chandana-26.11.19 load data to asset visualization grid**
function loadAssetVisualisationDetails(){
	$('#assetVisualisationGrid').show();
	//console.log("http://localhost:8080"+"/repopro/web/assetrepresentationmanager/getallrepresentations");
	
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetrepresentationmanager/getallrepresentations",
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			//console.log(" json "+JSON.stringify(json));
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null || json.result == []){
					if(countOfData == 0){
						$('#noAssetVisualisationGridData').show();
						$('#noAssetVisualisationGridData').html('<div class="ui message">No Asset Visualization added yet</div>'); 
						$("#assetVisualisationGrid").hide();
						infiniteScrollFlag = false;
					}
					else{
						$('#assetVisualisationLoadingId').css('display', 'none');
						infiniteScrollFlag = false;
					}
				}
				else{
					
					$('#noAssetVisualisationGridData').hide();
					$('#assetVisualisationGrid').show();
					$.each(json.result, function(i) {
						
						appendAVData = getAssetVisualisationDetails (json.result[i].jarName, json.result[i].assetRepresentationId, json.result[i].representationName, json.result[i].implementedClassName, json.result[i].allowedExtensions, json.result[i].linkedToAsset);
						$('#tableAssetVisualisation tbody').append(appendAVData);
						countOfData++;
						
					});
					//formRange = formRange + 20;
				}
				$('#assetVisualisationLoadingId').css('display', 'none');
			}
			else{
				$('#assetVisualisationLoadingId').css('display', 'none');
				
			}
			$('#showHideLoader').removeClass('active');
		}
	});
	$('#assetVisualisationLoadingId').css('display', 'none');
	//scrollVisible(0);
}

//** Chandana-26.11.19 add data to asset visualization grid row**
function getAssetVisualisationDetails (jarName,assetRepresentationId,representationName,implementedClassName,allowedExtensions, linkedToAsset){
	var splitallowedExtensions = allowedExtensions.replace(/^\["(.+)"\]$/,'$1');
	var extensionLabel = '';
	var multiTypeFlag = false;
		    if (splitallowedExtensions.indexOf(',') != -1) {
		    	multiTypeFlag = true;
		    	splitallowedExtensions = splitallowedExtensions.split(",");
		    	for(i=0; i<splitallowedExtensions.length ; i++){
		    	extensionLabel += '<span class="ui label" value='+splitallowedExtensions[i]+'>'+splitallowedExtensions[i]+'</span>'
		    	}   	 
		   	}
		    else{
		    	extensionLabel += '<span class="ui label" value='+splitallowedExtensions+'>'+splitallowedExtensions+'</span>'
		    }
		    
		//    $('allowedExtensionsId_'+assetRepresentationId).append(extensionLabel);
		    if(linkedToAsset != true){		    
		    	var data = "<p id='checkAVMapped'>You are about to delete the Asset Visualization. Sure to proceed ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteAssetVisualisationPopup("+assetRepresentationId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteAssetVisualisation("+assetRepresentationId+")'>Yes</button>";
		    }
		    else{
		    	var data = "<p id='checkAVMapped'>This visualization is used at the Asset level. Sure to proceed ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteAssetVisualisationPopup("+assetRepresentationId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteAssetVisualisation("+assetRepresentationId+")'>Yes</button>";
		    }
	appendData = "";
	appendData += '<tr id="assetVisualisationRow_'+assetRepresentationId+'">';
	appendData += '<td class="one wide hidden" id="jarPathId_'+assetRepresentationId+'">'+jarName+'</td>';
	appendData += '<td class="one wide hidden">'+assetRepresentationId+'</td>';
	appendData += '<td class="three wide whitespaceNoTrim" id="representationNameId_'+assetRepresentationId+'"><div><div class="mediumIconImageCircleStyle"><i class="image outline icon" style="padding-left: 0.4em !important;padding-top: 0.3em;"></i></div><span style="margin-left: 0.8em;">'+representationName+'</span></td>';
	appendData += '<td class="three wide whitespaceNoTrim" id="implementedClassNameId_'+assetRepresentationId+'">'+implementedClassName+'</td>';
	if(multiTypeFlag == true){
	appendData += '<td class="two wide whitespaceNoTrim multiExtensionLabel" id="allowedExtensionsId_'+assetRepresentationId+'" name='+splitallowedExtensions+'>'+extensionLabel+'</td>';
	}else{
	appendData += '<td class="two wide whitespaceNoTrim" id="allowedExtensionsId_'+assetRepresentationId+'">'+extensionLabel+'</td>';	
	}
	appendData += '<td class="one wide"><i class="edit icon deleteEditIcon" onclick="openEditAssetVisualisation(this,'+assetRepresentationId+')"></i></td>';
	//var $row = $("#tableAssetVisualisation tbody tr:first").addClass('defaultRow');
	 if (/*$('.defaultRow').is(":visible")*/ representationName == "Swagger") {
		  	appendData += '<td class="disabled disableDeleteIcon"><span data-tooltip="This is a default visualization and cannot be deleted" data-position="left center"><i class="trash icon" id="trash_'+assetRepresentationId+'" ></i></span></td>';
     }
		else {
			appendData += '<td class=""><a><i class="trash icon deleteEditIcon" id="trash_'+assetRepresentationId+'" data-html="'+data+'" onclick="openDeleteAssetVisualisationPopup('+assetRepresentationId+')"></i></a></td>';

	}
	appendData += '</tr>';
	return appendData;
}

//** Chandana-26.11.19 delete asset visualization data*

function openDeleteAssetVisualisationPopup(assetRepresentationId){
	$("#trash_"+assetRepresentationId)
	.popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	})
	.popup('show');
}

//** Chandana-26.11.19 close delete asset visualization popup
function closeDeleteAssetVisualisationPopup(assetRepresentationId){
		$("#trash_"+assetRepresentationId).popup('hide');
}


//** Chandana-26.11.19  add new asset visualization modal
function openAddAssetVisualisation(){
var obj = {};
var repjson = {};
var xhr = "";
var restrictExtnOnAdd;
	$('#submitAddedAssetVisualisation').unbind();
	$('#cancelAddedAssetVisualisation').unbind();
	
	$('#addAssetVisualisation').modal('destroy');
	
	$('#addAssetRepName').val('');
	$('#addExtensionType').dropdown('clear');
	
	//$('#addExtensionType').html('');
	//$("#addExtensionType").prepend('<option value="">Select Extension</option>');
	$('#addImpClassName').val('');
	$('#uploadAVfile').val("");
	$('#addAssetVisualisation').modal('setting', 'closable', false).modal('show');
	
	$('#uploadSwaggerFileBtn').val('');  // clearing hidden input to allow the user to select the same file
	
	$('.assetVisualInfoPopup').popup({
	    inline: true,
	  });
	
	$('.popup-button1').popup({
		on: 'hover',
		inline: true
	});
	
	//chandana 10.12.2019 - download interface 
		$('#downloadInterface').click(function(e){
			e.preventDefault();  //stop the browser from following
			var filePath = 'asset-representation.jar';
		    window.location.href = "/repopro/downloadJar/"+filePath;
		});
	
	$("#errAddAssetRepName").hide();
	$('#addAssetRepName').parent().removeClass("error");
	$("#errAddJarPath").hide();
	$('#uploadAVfile').parent().removeClass("error");
	$("#errAddExtensionType").hide();
	$('#addExtensionType').parent().removeClass("error");
	$("#errAddImpClassName").hide();
	$('#addImpClassName').parent().removeClass("error");
	
	$("#uploadSwaggerFileBtn").on('change', function() {
		$("#uploadAVfile").val(this.value);
		upFile = this.files;
		name = "";
		name = this.value;
		
	});
	//submit the added asset visualization data
	$('#submitAddedAssetVisualisation').on('click', function(){
		
		var addExtensionArray = [];
		var representationName = $("#addAssetRepName").val().trim();
		var implementedClassName = $("#addImpClassName").val().trim();
		var avFilepath = $('#uploadAVfile').val().trim();
		//var extensionType = $(".ui.dropdown a.ui.label").dropdown("get value"); 
		var extensionType = $('#addExtensionType').val(); 	
		
		if(extensionType == '' || extensionType == "null" || extensionType == null){
			extensionType = '';
		}
		else{
			extensionType = extensionType.toString();
		}
		addExtensionArray.push(extensionType);
		
		
		if(avFilepath != ""){
		var formData = new FormData();
		formData.append('uploadedjar', upFile[0]);
		}
		
		
		var flag = true;
		//rep name validation
		if(representationName == null || representationName == ""){
			$('#addAssetRepName').parent().addClass("error"); 
			$("#errAddAssetRepName").show();  
			flag = false;
		}
		else{
			if (/^[a-zA-Z0-9- ]*$/.test(representationName) == false) {
				$('#addAssetRepName').parent().addClass("error"); 
			    $("#errAddAssetRepName").html('Please use only alphanumeric character for representation name.').show();  
				flag = false;
			}
			else{
				$('#addAssetRepName').parent().removeClass("error"); 
				$("#errAddAssetRepName").hide(); 
			}
	
		}
		//class name 
		if(implementedClassName == null || implementedClassName == ""){
			$('#addImpClassName').parent().addClass("error"); 
			$("#errAddImpClassName").show();  
			flag = false;
		}
		else{
			$('#addImpClassName').parent().removeClass("error"); 
			$("#errAddImpClassName").hide(); 
		}

		//extenion type
		if($('#addExtensionType option:selected').text() == "Select Extension Type" || $('#addExtensionType option:selected').text() == ''){
			$("#errAddExtensionType").show();
			$('#addExtensionType').parent().addClass("error"); 
			flag = false;
		}
		 else {
			 $("#errAddExtensionType").hide();
			 $('#addExtensionType').parent().removeClass("error");  
		 }
		//file path
		if(avFilepath == null || avFilepath == ""){
			$('#uploadAVfile').parent().addClass("error"); 
			$("#errAddJarPath").show();  
			flag = false;
		}else{
			// allow only JAR file to upload - chandana - 16.12.19
			 restrictExtnOnAdd = '';
			 restrictExtnOnAdd = avFilepath.split('.').slice(-1);
			 if(restrictExtnOnAdd != 'jar' && restrictExtnOnAdd != 'JAR') {
				 $('#uploadAVfile').parent().addClass("error"); 
					$("#errAddJarPath").show(); 
				    flag = false;
				  }
			 else { $('#uploadAVfile').parent().removeClass("error"); 
			$("#errAddJarPath").hide(); 
			 }
		}
		
		
		 
		 
		
		if(flag == false){
			$('#addAssetVisualisation').modal('show');
			return false;
		}else{
			$('#addAssetVisualisation').modal('hide');  //.modal('hide dimmer');
			$('#addAssetVisualisation').parent().css("display", "none !important");
			repjson = {
					"AssetrepName":representationName,
					"ImplementedClassName":implementedClassName,
					"AllowedExtension":addExtensionArray.slice()
			};
			
			$('#hiddenInputForAddAVdata').val(JSON.stringify(repjson));
			
			xhr = "";
			xhr = new XMLHttpRequest();
			xhr.open("POST","/repopro/web/assetrepresentationmanager/addassetrepresentation");
			xhr.onload = function(event){
				var json = JSON.parse(event.target.responseText);

				if(json.status == "SUCCESS"){
					notifyMessage("Add Asset Visualization","Visualization added","success");
					formRange = 0;
					countOfData = 0;
					infiniteScrollFlag = true;
					$('#tableAssetVisualisation tbody').html("");
					loadAssetVisualisationDetails();
					
				   }else{
						notifyMessage("Asset Visualization",json.message,"fail")
						flag = false;
				   }
		 };
			var formData1 = new FormData(document.getElementById("addNewVisualisationData"));
			xhr.send(formData1);
		}
		
		if(flag == false){
	    	$('#addAssetVisualisation').modal('show');
			return false;
	     }
	     else{
	    	 $('#addAssetVisualisation').modal('hide'); //.modal('hide dimmer');
	    	 $('#addAssetVisualisation').parent().css("display", "none !important");
	     }
	});
	$('.ui.dropdown').dropdown();

$('#cancelAddedAssetVisualisation').on('click', function(){
	$("#uploadSwaggerFileBtn").unbind();
});
}


//** Chandana-26.11.19  edit asset visualization modal
var emptyPathFlag;
function openEditAssetVisualisation(obj,assetRepresentationId){
	
	var repjson = {};
	var xhr = "";
	//var editExtensionArray = [];
	var appendDataop = "";
	var upFileonEdit = '';
	var extensionTypeArray = [];
	var listArr = [];
	var restrictExtn = '';
	
	$('#submitEditedAssetVisualisation').unbind();
	$('#cancelEditedAssetVisualisation').unbind();
	
	$('#editAssetVisualisation').modal('destroy');
	$('#editAssetVisualisation').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	$('#uploadSwaggerFileBtnOnEdit').val(''); // clearing hidden input to allow the user to select the same file
	
	$('.assetVisualInfoPopup').popup({
	    inline: true,
	  });
	$('.popup-button1').popup({
		on: 'hover',
		inline: true
	});
	
	
	//chandana 10.12.2019 - download interface 
	$('#downloadInterfaceEdit').click(function(e){
		e.preventDefault();  //stop the browser from following
		var filePath = 'asset-representation.jar';
	    window.location.href = "/repopro/downloadJar/"+filePath;
	});
		
	$('#uploadSwaggerFileBtnOnEdit').attr('name','');
	 
	$("#uploadSwaggerFileBtnOnEdit").on('change', function() {
		emptyPathFlag = true;
		$("#uploadAVfileOnEdit").val(this.value);
		upFileonEdit = this.files;
		name = "";
		name = this.value;
		$('#uploadSwaggerFileBtnOnEdit').attr('name','uploadedjar');
		 $('#uploadAVfileOnEdit').val(name);
	});
	
	$("#errEditAssetVisualisationName").hide();
	$('#editAssetVisualisationName').parent().removeClass("error");
	$("#errEditJarPath").hide();
	$('#uploadAVfileOnEdit').parent().removeClass("error");
	$("#errEditExtensionType").hide();
	$('#editExtensionType').parent().removeClass("error");
	$("#errEditImpClassName").hide();
	$('#editImpClassName').parent().removeClass("error");

	var editAssetVisualisationName = $("#representationNameId_"+assetRepresentationId).text();
	var editPathName = $("#jarPathId_"+assetRepresentationId).text();
	var editExtensionTypes = $("#allowedExtensionsId_"+assetRepresentationId).text();
	var editImplementedClassName =  $("#implementedClassNameId_"+assetRepresentationId).text();
	
	//get visualization name on modal head
	$('#assetRepresentationName').text(editAssetVisualisationName)
	
	//checking and setting extension values to dropdown
	if($("#allowedExtensionsId_"+assetRepresentationId).hasClass('multiExtensionLabel')){
		var multiExtensionLabel = $("#allowedExtensionsId_"+assetRepresentationId).attr('name');
		if(multiExtensionLabel.indexOf(',') != -1){
			editExtensionTypes = '';
			multiExtensionLabel = multiExtensionLabel.split(',')
			editExtensionTypes = multiExtensionLabel;
		}else{
			editExtensionTypes = editExtensionTypes.replace(/^\["(.+)"\]$/,'$1');
		}
	}
	
	
    $("#editAssetVisualisationName").val(editAssetVisualisationName);
	$('#editImpClassName').val(editImplementedClassName);
	$('#uploadAVfileOnEdit').val(editPathName);
	
	var propertiesValue = '';
	
	// show selected option in the dropdown selection
	setTimeout(function(){ 
		$('.ui.fluid.dropdown').dropdown('clear');
		$.each(editExtensionTypes, function(j) {
			  listArr.push(encodeURIComponent(editExtensionTypes[j]));
		});
				//alert(editExtensionTypes)
				$('#editExtensionType').dropdown('set selected',editExtensionTypes);
	}, 100);
		

	//submit the edited asset visualization 
	$('#submitEditedAssetVisualisation').on('click', function(){
		var editExtensionArray = [];
		var visualisationName = $("#editAssetVisualisationName").val().trim();
		var jarPathName = $('#uploadAVfileOnEdit').val();
		//var types = $(".ui.dropdown a.ui.label").dropdown("get value");
		var types	= $('#editExtensionType').val();
		var className = $("#editImpClassName").val().trim();
		
		if(types == '' || types == "null" || types == null){
			types = '';
		}
		else{
			types = types.toString();
		}
		
		editExtensionArray.push(types);
		
		var flag = true;
		
		//validation
		 if(visualisationName == null || visualisationName == ""){
				$('#editAssetVisualisationName').parent().addClass("error"); 
				$("#errEditAssetVisualisationName").show();  
				flag = false;
			}
			else{
				if (/^[a-zA-Z0-9- ]*$/.test(visualisationName) == false) {
					$('#editAssetVisualisationName').parent().addClass("error"); 
				    $("#errEditAssetVisualisationName").html('Please use only alphanumeric character for relationship name.').show();  
					flag = false;
				}
				else{
					$('#editAssetVisualisationName').parent().removeClass("error"); 
					$("#errEditAssetVisualisationName").hide(); 
				}
			}
		 
		   //extenion type
			if($('#editExtensionType option:selected').text() == "Select Extension Type" || $('#editExtensionType option:selected').text() == ''){
				$("#errEditExtensionType").show();
				$('#editExtensionType').parent().addClass("error"); 
				flag = false;
			}
			 else {
				 $("#errEditExtensionType").hide();
				 $('#editExtensionType').parent().removeClass("error");  
			 }
			//file path
			if(jarPathName == null || jarPathName == ""){
				$('#uploadAVfileOnEdit').parent().addClass("error"); 
				$("#errEditJarPath").show();  
				flag = false;
			}else{
				// allow only JAR file to upload - chandana - 16.12.19
				 restrictExtn = jarPathName.split('.').slice(-1);
				 if(restrictExtn != 'jar' && restrictExtn != 'JAR') {
					 $('#uploadAVfileOnEdit').parent().addClass("error"); 
						$("#errEditJarPath").show(); 
					    flag = false;
					  }else{
				$('#uploadAVfileOnEdit').parent().removeClass("error"); 
				$("#errEditJarPath").hide(); 
					  }
			}
			
			 
			//validation
			 if(className == null || className == ""){
					$('#editImpClassName').parent().addClass("error"); 
					$("#errEditImpClassName").show();  
					flag = false;
				}
				else{
						$('#editImpClassName').parent().removeClass("error"); 
						$("#errEditImpClassName").hide(); 
				}
		 
			 if(flag == false){
					$('#editAssetVisualisation').modal('show');
					return false;
				}
				else {
					if(emptyPathFlag != true){
						 $('#uploadAVfileOnEdit').val('');
					}
					assetRepresentationId = assetRepresentationId.toString();
					
					repjson = {
							"RepresentId":assetRepresentationId,
							"AssetrepName":visualisationName,
							"ImplementedClassName":className,
							"AllowedExtension":editExtensionArray.slice()
					};
					
					$('#hiddenInputForEditAVdata').val(JSON.stringify(repjson));
					//console.log(JSON.stringify(repjson));
					xhr = "";
					xhr = new XMLHttpRequest();
					xhr.open("POST","/repopro/web/assetrepresentationmanager/updateassetrepresentation");
					xhr.onload = function(event){
						var json = JSON.parse(event.target.responseText);

						if(json.status == "SUCCESS"){
							notifyMessage("Edit Asset Visualization","Visualization updated","success");
							formRange = 0;
							countOfData = 0;
							infiniteScrollFlag = true;
							$('#tableAssetVisualisation tbody').html("");
							loadAssetVisualisationDetails();
							
						   }else{
								notifyMessage("Asset Visualization",json.message,"fail")
								flag = false;
						   }
				 };
					var formData = new FormData(document.getElementById("editVisualisationData"));
					xhr.send(formData);
					
				}
			 
				if(flag == false){
			    	$('#editAssetVisualisation').modal('show');
					return false;
			     }
			     else{
			    	 $('#editAssetVisualisation').modal('hide'); //.modal('hide dimmer'); 
			    	 $('#editAssetVisualisation').parent().css("display", "none !important");
			     }
			 
	});
	$('.ui.dropdown').dropdown();
}

//** Chandana-26.11.19  delete asset visualization 
function deleteAssetVisualisation(assetRepresentationId){
	var visualisationName = '';
	visualisationName = $('#representationNameId_'+assetRepresentationId).text();
	$.ajax({
		type : "DELETE",
		url : "/repopro/web/assetrepresentationmanager/deleteassetrepresentation?name="+visualisationName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			$("#trash_"+assetRepresentationId).popup('hide');
			if(json.status == "FAILURE"){
				notifyMessage("Asset Visualization",json.result,"fail");
			}
			else {
				$('#assetVisualisationRow_'+assetRepresentationId).remove();
				notifyMessage("Asset Visualization","Asset Visualization deleted","success");
			}

		}

	});
	
}