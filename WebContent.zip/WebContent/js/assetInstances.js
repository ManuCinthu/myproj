autoId = 0; 
autoIdTaxonomy = 0;
appendData = "";
assetInstanceId = 0;
assetId = "";
assetName = "";
versionable = "";
versionName = "";
assetIconType = "default";
versionList = [];
listArr = [];
assetInstanceVersionListSidebarRangeTo = 39;
assetInstanceVersionListSidebarRangeFrom = 0;
assetInstanceVersionListSidebarScrollFlag = true;
publicAccessFlag = true;
notificationFlag = false;
editingEnabled = false;

var editButtonClickedFlag = false;
var richTextClickFlag = false;
var initLayoutElementPos = [];
var tf_n_RTF_validationMsgFlg = false;
var getFlagForAssetExists = true;
var count = 0;

//toggle Asset Instance Side-Bar
function getCustomizedLayoutData(){
	$(".customizedLayout").each(function(key, val){
		initLayoutElementPos.push($(this).attr("id"));
	});
	
	/*getAssetInstanceOverview();
	getTagData();
	getTaxonomyDataOnLoad();
	getPropertiesData();
	//checkRelationshipAssets();
	//for relationship
	getRelationNameId(localStorage.getItem("assetInsVersionId"));
	root = getData();
	setup();
	createFilterList();
	//end
	getRevisionHistory();
	getCommentsData();
	getAssetInstanceVersions();
	getReverseRelationships();*/
	
	
	//getAssetInstanceOverview();
	
	
	
	getAllAssetInstanceDetailsOnLoad();
	
	if(getFlagForAssetExists){
		if(loggedInUserName == "roleAnonymous"){
			/*getAssetInstanceOverview();
			getTagData();
			getTaxonomyDataOnLoad();
			getPropertiesData();*/
			//for relationship
			getRelationNameId(localStorage.getItem("assetInsVersionId"));
			root = getData();
			setup();
			createFilterList();
			//end
			/*getRevisionHistory();
			getCommentsData();
			getAssetInstanceVersions();
			getReverseRelationships();*/
			smoothScrollAIVPage();
			loadElementsOnScroll();
			
		}else{
			$.ajax({
				type : "GET",
				url : "/repopro/web/assetInstanceVersionManager/getCustomizedSectionData?userName="+loggedInUserName,
				dataType : "json",
				async: false,
				cache: false,
				complete : function(data) {
					var json = JSON.parse(data.responseText);
					//console.log("json  res "+json.result[0].sectionVisibility);
					
					var data1 = json.result[0].sectionVisibility.split(",");
					var arrengedArray = [];
					var floatingBarArray = [];
					
					
					//console.log("data1 "+data1);
					
					$.each(data1, function(i) {
						var CheckedOrUnchecked  = data1[i].split("~~")[1];
						var tabsName  = data1[i].split("~~")[0];
						//console.log("CheckedOrUnchecked "+CheckedOrUnchecked+"  tabsName "+tabsName);
						 if(tabsName == "Overview"){
							arrengedArray.push("assetOverviewTab");
							floatingBarArray.push("#assetOverview");
						}else if(tabsName == "Tags"){
							arrengedArray.push("aivTags");
							floatingBarArray.push("#assetTag");
						}else if(tabsName == "Taxonomies"){
							arrengedArray.push("aivTaxonomy");
							floatingBarArray.push("#assetTaxonomies");
						}else if(tabsName == "Properties"){
							arrengedArray.push("assetPropertiesTab");
							floatingBarArray.push("#assetProperties");
						}else if(tabsName == "Relationships & Reverse Relationships"){
							arrengedArray.push("assetRelationshipAndRevRelationshipTab");
							floatingBarArray.push("#assetRelationships");
							if(CheckedOrUnchecked == "checked"){
								getRelationNameId(localStorage.getItem("assetInsVersionId"));
								root = getData();
								setup();
								createFilterList();
							}
							
						}else if(tabsName == "Revision History"){
							arrengedArray.push("assetRevisionHistoryTab");
							floatingBarArray.push("#assetRevisionHistory");
						}else if(tabsName == "Discussion"){
							arrengedArray.push("assetDiscussionTab");
							floatingBarArray.push("#assetDiscussion");
						}else if(tabsName == "Versions"){
							arrengedArray.push("assetVersionTab");
							floatingBarArray.push("#assetVersion");
						}else if(tabsName == "Asset Visualization"){
							//Swathi-05.11.2019- Asset Visualization
							arrengedArray.push("assetVisualizationTab");
							floatingBarArray.push("#assetVisualization");
						}
						
					});
					
					
					var arrengedOrderHtml = []; 
					var arrengedOrderFloatingMenu = [];
					//alert("before cust")
					$.each(arrengedArray,function(j){
						$(".customizedLayout").each(function(h){
							if(arrengedArray[j] == $(this).attr("id")){
								/*var id = $(this).attr("id");
								var htmlData = $("#"+id)html();*/
								//alert($(this).html())
								/*console.log(this);
								console.log($(this).html());*/
								
								//check for IE browser
								if (!!navigator.userAgent.match(/Trident\/7\./)){
									if(arrengedArray[j] != "assetRelationshipAndRevRelationshipTab"){
										arrengedOrderHtml.push('<div class="customizedLayout APINotCalledAIVPage"  id="'+$(this).attr("id")+'">'+$(this).html()+'</div>');
										$(this).remove();
									}else{
										arrengedOrderHtml.push('assetRelationshipCustomeIdKey');
									}
									
								}else{
									arrengedOrderHtml.push(this); //other browsers
								}
								
								
								
								//arrengedOrderHtml.push(this);
							}
						});
					});
					//alert("array ");
					
					
					//$("#showAllDataInCustomizedLayout").html("");
					
					if (!!navigator.userAgent.match(/Trident\/7\./)){
						 
						 var htmlBeforeRel = [];
						 var htmlAfterRel = [];
						 var indexVAL = arrengedOrderHtml.indexOf("assetRelationshipCustomeIdKey");
						$.each(arrengedOrderHtml,function(a){
							if(a < indexVAL){
								htmlBeforeRel.push(arrengedOrderHtml[a]);
							}else if(a > indexVAL){
								htmlAfterRel.push(arrengedOrderHtml[a]);
							}
						});
					
						htmlBeforeRel.reverse();
						
						$.each(htmlBeforeRel,function(a){
							$("#showAllDataInCustomizedLayout").prepend(htmlBeforeRel[a]);
						});
						
						$.each(htmlAfterRel,function(a){
							$("#showAllDataInCustomizedLayout").append(htmlAfterRel[a]);
						});
						
						
					
					}else{
						$("#showAllDataInCustomizedLayout").html("");
						$.each(arrengedOrderHtml,function(a){
							$("#showAllDataInCustomizedLayout").append(arrengedOrderHtml[a]);
						});
					}
					
					
					
					$.each(floatingBarArray,function(j){
						$("#floatingScrollerMenu > span").each(function(h){
							if(floatingBarArray[j] == $(this).children().attr("href")){
								arrengedOrderFloatingMenu.push("<span>"+$(this).html()+"</span>");
							}
						});
					});
					
					$("#floatingScrollerMenu").html("");
					
					
					
					$.each(arrengedOrderFloatingMenu,function(a){
						$("#floatingScrollerMenu").append(arrengedOrderFloatingMenu[a]);
						
					});
					
					
					
					
					$('.ui.accordion').accordion({
						exclusive: false
					 });
					$('.ui.dropdown').dropdown();
				
				
				
						var flag = true;
		
						$.each(data1, function(i) {
							var CheckedOrUnchecked  = data1[i].split("~~")[1];
							var tabsName  = data1[i].split("~~")[0];
							//console.log("CheckedOrUnchecked "+CheckedOrUnchecked+"  tabsName "+tabsName);
							 if(tabsName == "Overview"){
								
								if(CheckedOrUnchecked == "checked"){
									//getAssetInstanceOverview();
									$("#assetOverviewTab").show();
									$("#assetOverviewFloat").show();
									flag = false;
								}else{
									$("#assetOverviewTab").hide().addClass("hidden");
									$("#assetOverviewFloat").hide();
								}
							}else if(tabsName == "Tags"){
								
								if(CheckedOrUnchecked == "checked"){
									//getTagData();
									$("#aivTags").show();
									$("#assetTagFloat").show();
									
									flag = false;
								}else{
									$("#aivTags").hide().addClass("hidden");
									$("#assetTagFloat").hide();
								}
							}else if(tabsName == "Taxonomies"){
								
								if(CheckedOrUnchecked == "checked"){
									//getTaxonomyDataOnLoad();
									$("#aivTaxonomy").show();
									$("#assetTaxonomiesFloat").show();
									flag = false;
								}else{
									$("#aivTaxonomy").hide().addClass("hidden");
									$("#assetTaxonomiesFloat").hide();
								}
							}else if(tabsName == "Properties"){
								
								
								if(CheckedOrUnchecked == "checked"){
									//getPropertiesData();
									$("#assetPropertiesTab").show();
									$("#assetPropertiesFloat").show();
									flag = false;
								}else{
									$("#assetPropertiesTab").hide().addClass("hidden");
									$("#assetPropertiesFloat").hide();
								}
							}else if(tabsName == "Relationships & Reverse Relationships"){
								
								if(CheckedOrUnchecked == "checked"){
									//checkRelationshipAssets();
									//for relationship
									/*alert("after html cust")
									getRelationNameId(localStorage.getItem("assetInsVersionId"));
									root = getData();
									setup();
									createFilterList();*/
									
									root = getData();
									setup();
									//for reverse relationship
									//getReverseRelationships();
									
									$("#assetRelationshipAndRevRelationshipTab").show();
									$("#assetRelationshipsFloat").show();
									flag = false;
								}else{
									$("#assetRelationshipAndRevRelationshipTab").hide().addClass("hidden");
									$("#assetRelationshipsFloat").hide();
								}
							}else if(tabsName == "Revision History"){
								
								if(CheckedOrUnchecked == "checked"){
									//getRevisionHistory();
									$("#assetRevisionHistoryTab").show();
									$("#assetRevisionHistoryFloat").show();
									flag = false;
								}else{
									$("#assetRevisionHistoryTab").hide().addClass("hidden");
									$("#assetRevisionHistoryFloat").hide();
								}
							}else if(tabsName == "Discussion"){
								
								
								if(CheckedOrUnchecked == "checked"){
									//getCommentsData();
									$("#assetDiscussionTab").show();
									$("#assetDiscussionFloat").show();
									flag = false;
								}else{
									$("#assetDiscussionTab").hide().addClass("hidden");
									$("#assetDiscussionFloat").hide();
								}
							}else if(tabsName == "Versions"){
								
								if(CheckedOrUnchecked == "checked"){
									//getAssetInstanceVersions();
									$("#assetVersionTab").show();
									
									if(versionable){
										$("#assetVersionFloat").show();
									}else{
										
										$("#assetVersionFloat").hide();
									}
									flag = false;	
									
								}else{
									$("#assetVersionTab").hide().addClass("hidden");
									$("#assetVersionFloat").hide();
								}
							}else if(tabsName == "Asset Visualization"){
								//Swathi- Code to Asset Visualization - 04.11.2019
								if(CheckedOrUnchecked == "checked"){
									$("#assetVisualizationTab").show();
									$("#assetVisualizationFloat").show();
									flag = false;
								}else{
									$("#assetVisualizationTab").hide().addClass("hidden");
									$("#assetVisualizationFloat").hide();
								}
							}
							
						});
						
						
						if(flag){
							$("#showAllDataInCustomizedLayout").append('<div class="ui message" style="display:block !important;margin-top: 3em;" >All customizable actions are disabled.</div>');
						}
					
						$(".deleteTagClass").hide();
					
						formDataSubmit();
						smoothScrollAIVPage();
						//$('.customizedLayout').addClass("APINotCalledAIVPage");
						loadElementsOnScroll();
						$("#treeTabSegment").tab();
						
						
						if(globalSettingDetailsFlag){
							$("#editAIVPage").remove();
							
						}else{
							$("#editBtnAfterLock").remove();
						}
						
						$("#combinedBtns").show();
						
						$("#showAllDataInCustomizedLayout").append('<input type="hidden" id="assetInstanceDetails" name="assetInstanceDetails">');
						$("#showAllDataInCustomizedLayout").append(	'<input type="hidden" id="hiddenFormDataValue" name="hiddenFormDataValue">');
						$("#showAllDataInCustomizedLayout").append(	'<input type="hidden" id="hiddenRelationshipData" name="hiddenRelationshipData">');
						//$("#showAllDataInCustomizedLayout").append('<input id="editNewSubmitButton" type="submit" style="display: none;" value="Submit" formnovalidate="formnovalidate">');
				
						
				
				}
				
			
			});
		}
	}
		
	
		
	setTimeout(function(){ lazyLoadingImage(); }, 1000);
		
	
}







//submit properties data 
function formDataSubmit(){
		
	
	var xhr = "";
	
		$('#fileForm').submit(function(e){
			
			xhr = "";
			xhr = new XMLHttpRequest();
			xhr.open("POST","/repopro/web/assetInstanceVersionManager/updateAssetInstancePropertiesDetails");
			xhr.onload = function(event){
					var json = JSON.parse(event.target.responseText);
					//console.log("jsonResponse : " + JSON.stringify(json));
					
					if(json.status == "SUCCESS"){
						   notifyMessage("Edit Properties","Properties updated","success");
						   var currentTime = getDateTime();
						   $("#showAssetOverViewUpdatedOn").html(currentTime);
						  //getPropertiesData();
						
						   getRevisionHistory();
						   if($("#lockUnlockAssetInstance").hasClass("lock")){
								//$("#lockStatusMessage").html("");
								setTimeout(function(){
									unlockInstance();
								},1500);
							}
					   }else{
						   notifyMessage("Edit Properties",json.message,"fail");
					     // getPropertiesData();
					      
					   }
					  
					   //propertiesXMLDataValidations();
					   //$("#responseDataForProperties html body pre").html("");
					   
					   $("#propSubBtn").show();
					   $("#propSubBtnLoading").hide();
					   $("#fileForm").removeClass("loading");
					   
					   $(".showProperties.newTextFieldStyle").addClass("showDimmerButtonStyle");
					   $(".showProperties.newTextFieldStyle").removeClass("editDimmerButtonStyle");
					   //$(".showOrEditButton").text("Show Text");
						
						closePropertiesEditing();
					
			 };
			
			$("#propSubBtn").hide();
			$("#fileForm").addClass("loading");
		    $("#propSubBtnLoading").show();
			 
			var formData = new FormData(document.getElementById("fileForm"));
			xhr.send(formData);
			//window.close();
			return false;
		
		});

}

function smoothScrollAIVPage(){
	$('.innerItem').click(function() {
	    
		var href = $.attr(this, 'href');
	    $('.innerItem').removeClass('active assetInstanceFloatingMenuSelected').children().removeClass("themeTextColor");
    	$("#floatingScrollerMenu").find('a[href="'+href+'"]').addClass('active assetInstanceFloatingMenuSelected').children().addClass("themeTextColor");
    	
    	 $("html, body").animate({
	        scrollTop: $(href).offset().top-260
	    }, 500);
	    return false;
	});
	
	
}

//load element on scroll
function loadElementsOnScroll(){
	$('.customizedLayout').visibility({
		once: true,
		observeChanges: true,
		onTopVisible: function() {
			//console.log($(this).attr("id"))
			var id = $(this).attr("id");
			if(id == "aivTags"){
				if(!$("#aivTags").hasClass("hidden")){
					if($("#aivTags").hasClass("APINotCalledAIVPage")){
						getTagData();
						$("#aivTags").removeClass("APINotCalledAIVPage");
					}
				}
			}else if(id == "aivTaxonomy"){
				
				if(!$("#aivTaxonomy").hasClass("hidden")){
					if($("#aivTaxonomy").hasClass("APINotCalledAIVPage")){
						getTaxonomyDataOnLoad();
						$("#aivTaxonomy").removeClass("APINotCalledAIVPage");
					}
					
				}
			}else if(id == "assetOverviewTab"){
				if(!$("#assetOverviewTab").hasClass("hidden")){
					if($("#assetOverviewTab").hasClass("APINotCalledAIVPage")){
						getAssetInstanceOverview();
						$("#assetOverviewTab").removeClass("APINotCalledAIVPage");
					}
					
				}
			}else if(id == "assetPropertiesTab"){
				if(!$("#assetPropertiesTab").hasClass("hidden")){
					if($("#assetPropertiesTab").hasClass("APINotCalledAIVPage")){
						getPropertiesData();
						$("#assetPropertiesTab").removeClass("APINotCalledAIVPage");
					}
					
				}
			}else if(id == "assetRelationshipAndRevRelationshipTab"){
				if(!$("#assetRelationshipAndRevRelationshipTab").hasClass("hidden")){
					if($("#assetRelationshipAndRevRelationshipTab").hasClass("APINotCalledAIVPage")){
						root = getData();
						setup();
						getReverseRelationships();
						$("#assetRelationshipAndRevRelationshipTab").removeClass("APINotCalledAIVPage");
					}
					
				}
			}else if(id == "assetVersionTab"){
				if(!$("#assetVersionTab").hasClass("hidden")){
					if($("#assetVersionTab").hasClass("APINotCalledAIVPage")){
						getAssetInstanceVersions();
						$("#assetVersionTab").removeClass("APINotCalledAIVPage");
					}
					
				}
			}else if(id == "assetRevisionHistoryTab"){
				if(!$("#assetRevisionHistoryTab").hasClass("hidden")){
					if($("#assetRevisionHistoryTab").hasClass("APINotCalledAIVPage")){
						getRevisionHistory();
						$("#assetRevisionHistoryTab").removeClass("APINotCalledAIVPage");
					}
					
				}
			}else if(id == "assetDiscussionTab"){
				if(!$("#assetDiscussionTab").hasClass("hidden")){
					if($("#assetDiscussionTab").hasClass("APINotCalledAIVPage")){
						getCommentsData();
						$("#assetDiscussionTab").removeClass("APINotCalledAIVPage");
					}
					
				}
			}else if(id == "assetVisualizationTab"){
				//Swathi- Code to Asset Visualization - 04.11.2019
				if(!$("#assetVisualizationTab").hasClass("hidden")){
					if($("#assetVisualizationTab").hasClass("APINotCalledAIVPage")){
						getAssetVisualization();
						$("#assetVisualizationTab").removeClass("APINotCalledAIVPage");
					}
					
				}
			}
			lazyLoadingImage();
		}
  });
}

//validate uploaded file extension with saved visualization file extension -chandana - 11.12.19
function validateAVExtn(){
		$.ajax({
			type : "GET",
			url: "/repopro/web/assetrepresentationmanager/getrepresentationbyassetname?assetName="+assetName,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				//console.log(" json "+JSON.stringify(json));
				if(json.status == "SUCCESS"){
					$.each(json.result, function(i) {
						
						var getSavedExtn = json.result[i].allowedExtensions;
						getSavedExtn = getSavedExtn.replace(/^\["(.+)"\]$/,'$1');
						var ext = extnType.split(".");
						ext = ext[ext.length-1].toLowerCase();      
						var arrayExtensions = getSavedExtn;

					    if (arrayExtensions.lastIndexOf(ext) == -1) {
					        //alert("Wrong extension type.");
					        $("#uploadNewHTMLfile").val("");
					        $('#errAddJarPath').show();
					        $('#uploadSwaggerFileinAIVpage').addClass('error');
					    }
					    else{
					    	$('#errAddJarPath').hide();
					        $('#uploadSwaggerFileinAIVpage').removeClass('error');
					    	
					    }
						
					});
					
				}else{
					
				}
			}
		});
}


var upAVFile;
var AVFilename;
var extnType;
var uploadedFileNameOnEdit ='';
//get asset visualization file - chandana - 11.12.19
function upAVFile(){
$("#uploadSwaggerFileBtn").on('change', function() {
	
	
	$("#uploadNewHTMLfile").val(this.value);
	upAVFile = this.files;
	extnType = this.files[0].name;
	AVFilename = "";
	AVFilename = this.value;
	validateAVExtn();
});
}

// disabled file select input when no asset visualization is selected at the asset level - 09.1.2020 - chandana
var assetRepresentation;
function getSelectedAVoptionInAIV(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetType/getassetdetails/"+assetId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			assetRepresentation = json.result[0].assetRepresentation;
			if(assetRepresentation == null || assetRepresentation == 'null'){
				$('#uploadSwaggerFileinAIVpage').addClass('AIVDisabled');
			}
			else{
				$('#uploadSwaggerFileinAIVpage').removeClass('AIVDisabled');
			}
		}
	});
}
//get asset visualization data - chandana - 10.12.19
function getAssetVisualization(){
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetrepresentationmanager/getinstancerepresentationbyversionid?versionId="+assetInstanceVersionId,
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				setTimeout(function(){ 
					$("#assetVisualizationSegment").removeClass("loading");
				}, 50);
				getSelectedAVoptionInAIV();
				if(json.result == "" || json.result == null){
					$("#assetVisualizationSegment").html("No asset visualization added yet");
				}else{
					
					$.each(json.result, function(i) {
						$('#assetVisualizationSegment').append('<div class="ui segment" id="renderHTMLCode" style="height: 20em;" ><object data="" id="renderSigment" style="width: -webkit-fill-available;height: -webkit-fill-available; width: -moz-available;height: -moz-available;" >  </object></div>');
						var dataSrc = '';
						uploadedFileNameOnEdit = json.result[i].uploadedFileName;
						ipAddress = json.result[i].ipAddress;
						dataSrc = ipAddress + assetInstanceVersionId +'/';
						if(dataSrc != ''){
						$('#renderSigment').attr('data',dataSrc);
						}
						else{
							$('#renderHTMLCode').hide();
							$("#assetVisualizationSegment").html("No asset visualization added yet");
						}
					});
					
				}
			}
			else if(json.status == "FAILURE"){
				setTimeout(function(){ 
					$("#assetVisualizationSegment").removeClass("loading");
				}, 50);
				$("#assetVisualizationSegment").html("No asset visualization added yet");
			}
			/*$('.popup-button1').popup({
				on: 'hover',
				inline: true
			});*/
			$('.assetVisualInfoPopup').popup({
			    inline: true,
			  })
		upAVFile();
			
			checkAccessForUserOnSuccess();
		}
	});
	
}


// get All Asset Instance Details On Load
function getAllAssetInstanceDetailsOnLoad(){
	hidePublicAccessforGU();
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/getAssetInstanceVersionsAndDetails/"+assetInstanceVersionId+"?assetInstName="+encodeURIComponent(assetInstanceName)+"&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				
				setTimeout(function(){ 
					$("#showAssetOverViewMessage").removeClass("loading");
				}, 50);
				
				if(json.message == "ASSET_INSTANCE_VERSION_DETAILS_NOT_FETCHED"){
					//$('#showHideLoader').removeClass('active');
					getFlagForAssetExists = false;
					$('#loadContent').load("noAssetInstance.html");
					
				}else{
					//$('#showHideLoader').removeClass('active');
					/*var data = "";
					if(json.result[0].description == null){
						data = "<span id='showAssetOverViewDescription'>No description provided yet</span>";	
					}else{
						data = "<span id='showAssetOverViewDescription'>"+json.result[0].description+"</span>";	
					}*/
				$('#showAssetOverViewOwner').html(json.result[0].owner);
				var time = json.result[0].updatedOn.trim();
				time = time.split(" ");
				$('#showAssetOverViewUpdatedOn').html(time[0]+"T"+time[1]);
				//$("#showAssetOverViewMessage").html(data);
				
			
			assetInstanceId = json.result[0].assetInstanceId;
			assetId = json.result[0].assetId;
			assetName = json.result[0].assetName;
			versionable = json.result[0].versionable;
			versionName = json.result[0].versionName;
			assetIconType = "default";
			if(json.result[0].iconImageName != null){
				var imageType = json.result[0].iconImageName ;
				//imageType = imageType.split(".");
				//assetIconType = imageType[1];
				assetIconType = (json.result[i].iconImageName).substring((json.result[i].iconImageName).lastIndexOf(".") + 1, (json.result[i].iconImageName).length);

			}
			
			appendData = "";
			
			if(assetIconType != "default"){
				
				if(circularThemeColoredIcon){
					appendData += '<div class="bigIconImageCircleStyle_themeCircle" style="font-size: 1.4em; display: block !important;">';
					if(invertAssetIconFlag){
						appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" data-src="/repopro/assetImages/inverted_'+assetId+'.'+assetIconType+'" ></div>';
					}else{
						appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg"  data-src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';
					}
				}else{
					appendData += '<div class="bigIconImageCircleStyle" style="font-size: 1.4em; display: block !important; margin-left: -1rem !important;">';
					if(invertAssetIconFlag){
						appendData += '<img class="left floated ui  image bigIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" data-src="/repopro/assetImages/inverted_'+assetId+'.'+assetIconType+'" ></div>';
					}else{
						appendData += '<img class="left floated ui  image bigIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg" data-src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';
					}
				}
				/*appendData += '<div class="bigIconImageCircleStyle" style="font-size: 1.4em; display: block !important; margin-left: -1rem !important;">';
				appendData += '<img class="left floated ui circular image bigIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';*/
			}else{
				if(circularThemeColoredIcon){
					appendData += '<div class="bigIconImageCircleStyle_themeCircle" style="font-size: 1.4em; display: block !important;">';
					if(invertAssetIconFlag){
						appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" ></div>';
					}else{
						appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg" ></div>';
					}
				}else{
					appendData += '<div class="bigIconImageCircleStyle" style="font-size: 1.4em; display: block !important; margin-left: -1rem !important;">';
					if(invertAssetIconFlag){
						appendData += '<img class="left floated ui  image bigIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" ></div>';
					}else{
						appendData += '<img class="left floated ui  image bigIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg" ></div>';
					}
				}
			}
			
			$("#assetInstanceIcon").html(appendData);
			//lazyLoadingImage();
			
			$(".abc").removeClass("themeTextColor itemSelected");
			$("#browserAssetId_"+assetId).addClass("themeTextColor itemSelected");

			
			$('#breadcrumbData').html('<a class="section" onclick="getHomeDetails(this)">Home</a><i class="right chevron icon divider"></i><a class="section whitespaceNoTrim" onclick="navigateToAssetPage()">Browse - '+assetName+'</a><i class="right chevron icon divider"></i><div class="active section whitespaceNoTrim">'+assetInstanceName+'</div>');
			
			if(versionable){
				$("#openAddVersionDetailsModal").show();
				$("#assetVersionFloatingMenu").show();
				$("#assetVersionFloat").show();
				
			}else{
				$("#divVersionable").css("visibility","hidden");
				$("#openAddVersionDetailsModal").remove();
				$("#assetVersionFloatingMenu").hide();
				$("#assetVersionFloat").hide();
				$("#assetInstancesVersionHeader").remove();
				$("#assetInstancesVersionSegment").remove();
				$("#versionDivider").remove();
				//$("#floatingScrollerMenu").attr("style","height: 20.2em !important;border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;");
				$("#floatingScrollerMenu").attr("style","height: auto !important;border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;");
			}
			
			var assetInstanceVersionArr = [];
			appendData = "";
			$.each(json.result[0].versionList, function(j) {
				
				var id = (json.result[0].versionList[j]).split(":");
				
				assetInstanceVersionArr.push(id[1]);
				$(".versionDropdown").show();
				
				if(id[1] == assetInstanceVersionId){
					$("#selectedVersionId").val('');
					$("#selectedVersionId").html(versionName);
					
				}else{
					var encodedAssetInstName= encodeURIComponent(assetInstanceName);
					encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
					//appendData += '<div class="ui label" style="margin-left: 0.75em;"><a  onclick="getAssetInstances('+id[1]+',\''+encodedAssetInstName+'\')">'+id[0] +'</a></div>';
					appendData += '<div class="item" data-text="'+id[0]+'" onclick="getAssetInstances('+id[1]+',\''+encodedAssetInstName+'\')">'+id[0]+'</div>';
				}
				
										
			});
			//console.log(appendData)
			$("#versionDropdown").html(appendData);
			if(assetInstanceVersionArr.length == "1"){
				$(".versionDropdown").hide();
			}
			
			//$("#divVersionable").dropdown();
			
			//console.log(assetInstanceVersionArr)
			
			
			checkCompositionAggregationAssetType();
			//getCompositionAggregationAssetType(); 
			getSiblingsOfChildAssetInstance();
			getRatingDataOnLoad();
			loadGlobalSettingDetails();
			checkAccessForUserOnSuccess();
			
				}
						
				}
			
			
			
		}
	});
}



function openAssetInstanceSideBar(){

			$('#assetInstanceSideBar').transition({
				animation : 'slide right',
			    duration  : 500,
			});
			$('#assetInstanceSideBar').toggleClass('hideMenu');
			
			if($('#assetInstanceSideBar').hasClass('hideMenu')){
				if(versionable){
					$('#floatingScrollerMenu').addClass("floatIconMenuPositionStyle");
				 	//$('#floatingScrollerMenu').attr('style', 'margin-left: 0em !important; border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;');
				}else {
					$('#floatingScrollerMenu').addClass("floatIconMenuPositionStyle");
					//$("#floatingScrollerMenu").attr("style","margin-left: 0em !important; height: 20.2em !important;border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;");
				}
				$('#menuToggleButton').attr('style', 'margin-left: 0em !important');
				$('.assetInstanceMainLoaderSegment').attr('style', 'margin-left: 4em !important');
				$('#menuIconForAssetContentSideBar')
				.transition({
					animation : 'horizontal flip in',
				    duration  : 800,
				}).html('<i class="chevron right icon"></i>');
				$("#childListAssetInstance").hide();
				
				//chandana -css added to sticky header when side menu is closed
				
				
				if($('#assetInstanceSideBar').hasClass('hideMenu')){

					$('.stickyInstHead, .Infosticky ').addClass('StickytoggleClose');
				}
				else{
					$('.stickyInstHead,.Infosticky ').removeClass('StickytoggleClose');
				}
				
				//----Chandana 10-5-2019 EOC ----//
			}
			else{
				if(versionable){
					$('#floatingScrollerMenu').removeClass("floatIconMenuPositionStyle");
					//$('#floatingScrollerMenu').attr('style', 'margin-left: 15em !important; border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;');
				}else{
					$('#floatingScrollerMenu').removeClass("floatIconMenuPositionStyle");
					//$("#floatingScrollerMenu").attr("style","margin-left: 15em !important; height: 20.2em !important;border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;");
				}
				
				
				$('#menuToggleButton').attr('style', 'margin-left: 15em !important');
				$('.assetInstanceMainLoaderSegment').attr('style', 'margin-left: 18em !important');
				$('#menuIconForAssetContentSideBar')
				.transition({
					animation : 'horizontal flip in',
				    duration  : 800,
				}).html('<i class="chevron left icon"></i>');
				$("#childListAssetInstance").show();
				//chandana -css added to sticky header when side menu is closed
			
				$('.stickyInstHead ').removeClass('StickytoggleClose');
				$('.Infosticky ').removeClass('StickytoggleClose');
				
				//----Chandana 10-5-2019 EOC ----//
			} 
			
			/*if(editAIVPageFlag == "true"){
				$(".assetInstanceMainLoaderSegment").css("pointer-events", "none");
				$("#editAssetInstNameInputField").css("pointer-events", "auto");
			}*/
		}
 
function expandAllAccordion(){
	$(".propAccord").addClass("active").css("overflow","visible").children().next().removeClass("hidden");
	$("#expandAllAccordion").hide();
	$("#compressAllAccordion").show();
}

function compressAllAccordion(){
	$(".propAccord").removeClass("active");
	$("#expandAllAccordion").show();
	$("#compressAllAccordion").hide();
}

//$("#showAssetOverViewMessageButton").on("click",function(){
function showAssetOverViewMessageButton(){
	/*var flag = false;
	if(globalSettingDetailsFlag){
		flag = getLockStatus();
		if(flag){
			if(lockedBySameUser){
				flag = false;
			}else{
				notifyMessage("Lock Asset Instance","Instance "+assetInstanceName+" is already locked","fail");
			}
		}
		else{
			lockAssetInstance();
		}
	}*/
	
	//if(flag == false){
		$("#showAssetOverViewMessage").hide();
		$("#showAssetOverViewMessageButton").addClass("hideElement");
		$("#editAssetOverViewMessage").show();
		var editor = CKEDITOR.instances.msgBoardAdminMsgTextArea;
	    if (editor) {
	        editor.destroy(true); 
	    }   
	    CKEDITOR.replace('assetOverViewMessageTextArea');
	    var getData = $("#showAssetOverViewDescription").html();
	    CKEDITOR.instances['assetOverViewMessageTextArea'].setData(getData);
	    
	    
	//}

}
//});

function saveAssetOverViewMessage(){
	var messageData = CKEDITOR.instances['assetOverViewMessageTextArea'].getData();
	
	/*if(messageData != ""){
        var data = CKEDITOR.instances['assetOverViewMessageTextArea'].dataProcessor.toHtml(messageData);
        messageData = data;
      }*/
	
	if(messageData == "" || messageData == null){
		notifyMessage("Add Comment","Please provide a description","warning");
	}else{
		var url = "/repopro/web/assetInstance/Description?userName="+loggedInUserName;
		var obj = {
	
				"assetName": assetName,
				"assetInstName":assetInstanceName,
				"assetInstId": assetInstanceId,
				"versionName": versionName,
				"assetId": assetId,
				"newDescription": messageData 
				};
		
		
		 $.ajax({
		       	type: "PUT",
		       	url: url,
		       	contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				cache:false,
				complete:function(data){	
				appenddata = "";
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						var editor = CKEDITOR.instances.msgBoardAdminMsgTextArea;
					    if (editor) {
					        editor.destroy(true); 
					    }
						$("#showAssetOverViewMessage").show();
						$("#showAssetOverViewMessageButton").removeClass("hideElement");
						$("#showAssetOverViewDescription").html(messageData);
						$("#editAssetOverViewMessage").hide();
						var currentTime = getDateTime();
						$("#showAssetOverViewUpdatedOn").html(currentTime);
						getRevisionHistory();
						notifyMessage("Update Asset Instance Overview","Overview updated","success");
						if($("#lockUnlockAssetInstance").hasClass("lock")){
							//$("#lockStatusMessage").html("");
							setTimeout(function(){
								unlockInstance();
							},1500);
						}
					}
					else {
						
						notifyMessage("Update Asset Instance Overview","Error attempting to update overview","fail");
					}
				}
		  });
	}
	
}

//$("#cancelAssetOverViewMessage").on("click",function(){
function cancelAssetOverViewMessage(){	
	var editor = CKEDITOR.instances.assetOverViewMessageTextArea;
    if (editor) {
        editor.destroy(true); 
    }
	$("#showAssetOverViewMessage").show();
	$("#showAssetOverViewMessageButton").removeClass("hideElement");
	$("#editAssetOverViewMessage").hide();
}
//});





/*//add new taxonomy
function addNewTaxonomy(){
	var getNewTaxonomyName = $("#addNewTaxonomyName").val().trim();
	appendData = "";
	appendData = '<a class="ui label taxonomyNameClass_'+autoIdTaxonomy+'_'+getNewTaxonomyName.replace(/ /g,"_")+'" id="taxonomyName_'+autoIdTaxonomy+'_'+getNewTaxonomyName+'" style="margin-bottom:0.5em;"><i class="fork icon"></i> '+getNewTaxonomyName+' <i class="delete icon" onclick="deleteTaxonomy('+autoIdTaxonomy+',\''+getNewTaxonomyName+'\')"></i></a>'; 
	$("#addNewTaxonomySegment").append(appendData);
	autoIdTaxonomy++;
	$("#addNewTaxonomyName").val("");
}*/

//show hide tag segment
function showTagSegment(){
	$('#tagSegment').toggle("slow");
	 $('span', "#showHideTagSegment").toggle();
}



/*$(".marginFromBottomHeader").visibility({
    observeChanges: false,
    once: false,
    offset:180,
    onTopPassed: function(){
    	$('.innerItem').removeClass('active');
    	$("#floatingScrollerMenu").find('a[href="#'+$(this).attr('id')+'"]').addClass('active');
    },
    onBottomPassedReverse: function(){
    	$('.innerItem').removeClass('active');
    	$("#floatingScrollerMenu").find('a[href="#'+$(this).attr('id')+'"]').addClass('active');
    }
});*/


//get asset instance overview
function getAssetInstanceOverview(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/getAssetInstanceVersionDetails/"+assetInstanceVersionId+"?assetInstName="+encodeURIComponent(assetInstanceName),
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				
				setTimeout(function(){ 
					$("#showAssetOverViewMessage").removeClass("loading");
				}, 50);
				
				if(json.message == "ASSET_INSTANCE_VERSION_DETAILS_NOT_FETCHED"){
					//$('#showHideLoader').removeClass('active');
					$('#loadContent').load("noAssetInstance.html");
				}else{
					//$('#showHideLoader').removeClass('active');
					var data = "";
					if(json.result[0].description == null){
						data = "<span id='showAssetOverViewDescription'>No description provided yet</span>";	
					}else{
						data = "<span id='showAssetOverViewDescription'>"+json.result[0].description+"</span>";	
					}
					/*data += "<p style='color: rgba(0,0,0,0.6); font-size: 80%; margin-top: 1.5em;'><b>Created by : </b><span id='showAssetOverViewOwner'>"+json.result[0].owner+"</span>";
					data += "<b>  Last Updated: </b><span id='showAssetOverViewUpdatedOn'>"+json.result[0].updatedOn+"</span></p>";*/
				//$('#showAssetOverViewOwner').html(json.result[0].owner);
				//var time = json.result[0].updatedOn.trim();
				//time = time.split(" ");
				//$('#showAssetOverViewUpdatedOn').html(time[0]+"T"+time[1]);
				$("#showAssetOverViewMessage").html(data);
				getcallSuccess = true;	
			
			/*assetInstanceId = json.result[0].assetInstanceId;
			assetId = json.result[0].assetId;
			assetName = json.result[0].assetName;
			versionable = json.result[0].versionable;
			versionName = json.result[0].versionName;
			if(json.result[0].iconImageName != null){
				var imageType = json.result[0].iconImageName ;
				imageType = imageType.split(".");
				assetIconType = imageType[1];
			}*/
			
			/*if(assetIconType != "default"){
				$("#assetInstanceIcon").html('<div class="bigIconImageCircleStyle" style="font-size: 1.4em; display: block !important;"><img class="left floated ui image bigIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>');
			}*/
			
			//$(".abc").removeClass("themeTextColor itemSelected");
			//$("#browserAssetId_"+assetId).addClass("themeTextColor itemSelected");

			
			//$('#breadcrumbData').html('<a class="section" onclick="getHomeDetails(this)">Home</a><i class="right chevron icon divider"></i><a class="section" onclick="navigateToAssetPage()">Browse - '+assetName+'</a><i class="right chevron icon divider"></i><div class="active section">'+assetInstanceName+'</div>');
			/*getRelationNameId(localStorage.getItem("assetInsVersionId"));
			root = getData();
			setup();
			createFilterList();*/
			/*if(versionable){
				$("#openAddVersionDetailsModal").show();
				$("#assetVersionFloatingMenu").show();
			}else{
				$("#divVersionable").remove();
				$("#openAddVersionDetailsModal").remove();
				$("#assetVersionFloatingMenu").hide();
				$("#assetInstancesVersionHeader").remove();
				$("#assetInstancesVersionSegment").remove();
				$("#versionDivider").remove();
				$("#floatingScrollerMenu").attr("style","height: 20.2em !important;border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;");
				
			}*/
			
			//checkCompositionAggregationAssetType();
			//getCompositionAggregationAssetType(); 
			//getSiblingsOfChildAssetInstance();
			
			
				}
						
				}
			
			checkAccessForUserOnSuccess();
		}
	});
	
	
}


//navigate To AssetPage
/*function navigateToAssetPage(){
	$("html, body").animate({scrollTop: 0}, 10);
	localStorage.setItem("browserAssetName", assetName);
	localStorage.setItem("browserAssetId", assetId);
	$(".browserMainItem1").click();
	$(".browserAllAssetsSubMenu ").click();
	$("#browserAssetId_"+assetId).click();
	$('#loadContent').load('browser.html');	


}*/	

siblingsOfChildAssetInstance = [];
// get siblings of child asset instance
function  getSiblingsOfChildAssetInstance(){
	
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/getSiblingsOfChildAssetInstance?assetName="+encodeURIComponent(assetName)+"&assetInstName="+encodeURIComponent(assetInstanceName)+"&assetInstVerName="+versionName,
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				siblingsOfChildAssetInstance.length = 0; 
				if(json.result != "" || json.result != null){
					$.each(json.result, function(i) {
						var data = (json.result[i].assetInstName)+"~~"+(json.result[i].assetInstVersionId);
						siblingsOfChildAssetInstance.push(data);
					});
				}
			}
			getChildNameForAssetInstance();
		}
	});
	
	
}


//get Child Name For Asset Instance
function getChildNameForAssetInstance(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/getChildNamesForAssetInstance/?assetId="+assetId+"&assetInstVersionId="+assetInstanceVersionId,
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$("#assetInstanceSideBar").html("");
				$("#assetInstanceSideBar").html('<center class="quickBrowse aivSidebarHdr" style="color: #ffffff !important; font-weight: 900;    background-color: rgba(106, 106, 106, 0.788235294117647) !important;">Quick Browse</center><div id="childListAssetInstance"></div>');
				
				
				if(json.result == "" || json.result == null){
					if(siblingsOfChildAssetInstance.length == 0){
						$("#childListAssetInstance").html("<div class='item selectedAivsideAINames letterSpacingHeader whitespaceNoTrim'>"+assetInstanceName+"</div>");
					}else{
						appendData = "";
						appendData+= "<div class='item selectedAivsideAINames letterSpacingHeader'>"+assetInstanceName+"</div>";
						$.each(siblingsOfChildAssetInstance, function(i) {
							var siblingInstance = siblingsOfChildAssetInstance[i];
							siblingInstance = siblingInstance.split("~~");
							appendData+= '<a class="item selectedAivsideAINames letterSpacingHeader" onclick="getAssetInstances('+siblingInstance[1]+',\''+siblingInstance[0]+'\')">'+siblingInstance[0]+'</a>';
						});
						$("#childListAssetInstance").html(appendData);
					}
						
					
					
				}else{
					appendData = "";
					appendData += '<div class="ui vertical fluid accordion " style="font-size:10px;">';
					appendData += '<div class="item">';
					appendData += '<a class="title active" ><i class="dropdown icon" style="float: left;"></i><span>'+assetInstanceName+'</span></a>';
					appendData += '<div class="content menu active" id="assetInstanceChilds">';
					appendData += '</div></div></div>';
					
					$("#childListAssetInstance").html(appendData);
					
					$.each(json.result, function(i) {
						var assetInstName = json.result[i].assetInstName;
						var encodedAssetInstName= encodeURIComponent(assetInstName);
						encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
						appendData = '<a class="item" style="margin-left:2.5em;" onclick="getAssetInstances('+json.result[i].destAssetInstVersionId+',\''+encodedAssetInstName+'\')">'+assetInstName+'<span style="font-size: 9px;"> ['+json.result[i].assetName+']</span></a>';
						$("#assetInstanceChilds").append(appendData);
					});
					
					$('.ui.accordion').accordion({
						exclusive: false
					 });
					
				}
			}
			getAssetInstanceVersionListSidebar();
		}
	});
	
	
}

//get Asset Instance Versions list onclick
function getAssetInstanceVersionsOnclick(){
	if($("#assetVersion").hasClass("versionAPINotCall")){
    	if(versionable){
    		//getAssetInstanceVersions();
    	}
    	//$("#divVersionable").dropdown();
    	$("#assetVersion").removeClass("versionAPINotCall");
    }
}

function hidePublicAccessforGU(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/globalsettings",
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
		var json = JSON.parse(data.responseText);
		if(json.result[0].guestAccess == 0){
		$("#publicAccessOption").hide();
		}
		else{
		$("#publicAccessOption").show();
		}	
		}
	});
}
//get Public Access State On Load
function getPublicAccessStateOnLoad(){
	hidePublicAccessforGU();
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstance/getPublicAccessVal?assetInstanceId="+assetInstanceId,
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "TRUE"){
					publicAccessFlag = true;
					$("#publicAccessMessage").html("Block Public Access");
				}else{
					publicAccessFlag = false;
					$("#publicAccessMessage").html("Allow Public Access");
				}
			}
		}
	});
	
	
}

//change Public Access
function changePublicAccess(){
	var url = "";
	var message;
	if(publicAccessFlag){
		publicAccessFlag = false;
		message = "Public Access is Blocked";
		$("#publicAccessMessage").html("Allow Public Access");
		url = "/repopro/web/assetInstance/updatePublicAccessVal?assetId="+assetId+"&assetInstanceId="+assetInstanceId+"&options=disableAccess";
	}else{
		publicAccessFlag = true;
		message = "Public Access is Allowed";
		$("#publicAccessMessage").html("Block Public Access");
		url = "/repopro/web/assetInstance/updatePublicAccessVal?assetId="+assetId+"&assetInstanceId="+assetInstanceId+"&options=enableAccess";
	}
	$.ajax({
		type : "PUT",
		url: url,
		dataType : "json",
		async: false,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				notifyMessage("Public Access",message,"success");
			}
		}
	});
	
}



//get My Fav Status On Load
function getMyFavStatusOnLoad(){
	if(loggedInUserName != "roleAnonymous"){
		$.ajax({
			type : "GET",
			url : "/repopro/web/favourite/getMyFavourite?assetInstId="+assetInstanceId+"&userId="+loggedInUserId,
			dataType : "json",
			async: true,
			cache:false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null){
						myFavFlag = false;
						$("#addToFavouriteIcon").removeClass("yellowColorStar").addClass("empty");
						$('#changeFavouriteText').text('Add To Favourites');
					}else{
						myFavFlag = true;
						$("#addToFavouriteIcon").removeClass("empty").addClass("yellowColorStar");
						$('#changeFavouriteText').text('Remove Favourites');
					}
					
				}
			}
		});
	}
	
}


//get Notification Data On Load
function getNotificationDataOnLoad(){
	if(loggedInUserName != "roleAnonymous"){
		$.ajax({
			type : "GET",
			url : "/repopro/web/assetInstance/getUserAssetInstanceSubscription?userId="+loggedInUserId+"&assetInstanceId="+assetInstanceId,
			dataType : "json",
			async: true,
			cache:false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					
					if(json.result[0] == "FALSE"){
						notificationFlag = false;
						$("#notificationAssetInstanceIcon").removeClass("blue").addClass("outline");
						$('#changeNotoficatiobText').text('Enable Notification');
					}else{
						notificationFlag = true;
						$("#notificationAssetInstanceIcon").removeClass("outline").addClass("blue").attr("title", "Click to disable notification");
						$('#changeNotoficatiobText').text('Disable Notification');
					}
					
				}
			}
		});
	}
	
	
}



//get rating data on load 
function getRatingDataOnLoad(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/ratingmanager/getuserscount?assetInstanceVersionId="+assetInstanceVersionId,
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					appendData = "";
					appendData += '<i class="star  empty icon starIconSpacing"></i>';
					appendData += '<i class="star  empty icon starIconSpacing"></i>';
					appendData += '<i class="star  empty icon starIconSpacing"></i>';
					appendData += '<i class="star  empty icon starIconSpacing"></i>';
					appendData += '<i class="star  empty icon starIconSpacing"></i>';
					//appendData += '0 <i class="user icon"></i>';
					$("#ratingCompressedData").html(appendData);
				}else{
					var averageRating = json.result[0].avgRating;
					var totalCount = json.result[0].totalCount;
					appendData = "";
					
					for(var i= 0; i < Math.floor ( averageRating ); i++){
						appendData += '<i class="star icon starIconSpacing"></i>';
					}
					if(averageRating !== 5){	
						if( averageRating - Math.floor ( averageRating ) < 0.4){
							appendData += '<i class="star  empty icon starIconSpacing"></i>';
						}else{
							appendData += '<i class="star half empty icon starIconSpacing"></i>';
						}
						for(var i = 0; i < (4 - Math.floor ( averageRating )); i++){
							appendData += '<i class="star  empty icon starIconSpacing"></i>';
						}
					}
					//	appendData += totalCount+' <i class="user icon"></i>';
					
					$("#ratingCompressedData").html(appendData);
					
					
				}
			}
		}
	});
	
}

//get taxonomy data
var taxFromBackend = [];
function getTaxonomyDataOnLoad(){
	taxFromBackend.length = 0;
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstanceVersionManager/retTaxonomyIdByAssetInstVersionId?aivId="+assetInstanceVersionId,
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				
				setTimeout(function(){ 
					$("#addNewTaxonomySegment").removeClass("loading");
				}, 50);
					
				
				if(json.result == "" || json.result == null){
					$("#addNewTaxonomySegment").html("No taxonomies added yet")
				}else{
					$.each(json.result, function(i) {
						$('#addNewTaxonomySegment').append('<a class="ui label" onclick="navigateToClickedTaxonomy('+json.result[i].taxonomyId+',\''+json.result[i].taxonomyName+'\')" id="taxonomyName_'+json.result[i].taxonomyId+'_'+json.result[i].taxonomyName.replace(/ /g,"_")+'" style="margin-bottom:0.5em;"><span style="display:none;">'+json.result[i].taxonomyId+'</span><i class="fork icon"></i>'+json.result[i].taxonomyName+'</a>');
						// HEMA
						taxFromBackend.push({"taxId":json.result[i].taxonomyId, "taxName":json.result[i].taxonomyName});
					});
					
				}
			}
			checkAccessForUserOnSuccess();
		}
	});
	
}


//navigate To Clicked Taxonomy
function navigateToClickedTaxonomy(taxId,taxName){
	
	
	  localStorage.setItem("taxonomyId",taxId);
	  localStorage.setItem("taxonomyVal",taxName);
	 // $('#breadcrumbData').html('<a class="section" onclick="getHomeDetails(this)">Home</a><i class="right chevron icon divider"></i><div class="active section">Browser</div><i class="right chevron icon divider"></i><a class="active section" onclick="getAssetInstances('+assetInstanceVersionId+',\''+assetInstanceName+'\')">'+assetInstanceName+'</a><i class="right chevron icon divider"></i><div class="active section">'+taxName+'</div>');
	  $('#breadcrumbData').html('<a class="section" onclick="getHomeDetails(this)">Home</a><i class="right chevron icon divider"></i><a class="active section" onclick="getBrowserTaxonomy(this)">Browse by Taxonomy</a><i class="right chevron icon divider"></i><div class="active section">'+taxName+'</div>');
	  
	  
	  $("html, body").animate({scrollTop: 0}, 10);
	  $("#loadContent").load('associateTaxonomy.html');
	  
	  if ($('#contentPushable').hasClass('sidebarPushable')){
			$('#contentPushable').addClass('push-right-ctm');
		}
		else{
			$('#contentPushable').removeClass('push-right-ctm');
		}
		
}

//get asset Instance Version List on side bar
function getAssetInstanceVersionListSidebar(){
	var userName = "";
	 if(loggedInUserName == "roleAnonymous"){
		 userName = "roleAnonymous";
	 }else{
		 userName = loggedInUserName;
	 }
	 
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstance/getAllAssetInstancesForAivPage/?assetName="+encodeURIComponent(assetName)+"&userName="+userName+"&from="+assetInstanceVersionListSidebarRangeFrom,
		dataType : "json",
		async: true,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			//console.log(JSON.stringify(json.result))
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					assetInstanceVersionListSidebarScrollFlag = false;
				}else{
					$.each(json.result, function(i) {
						if(json.result[i].assetInstName != assetInstanceName){
							var flag = true;
							$.each(siblingsOfChildAssetInstance,function(j){
								var data = siblingsOfChildAssetInstance[j];
								data = data.split("~~");
								if(data[0] == json.result[i].assetInstName){
									flag = false;
									return false;
								}
							});
							
							if(flag){
								var encodedAssetInstName= encodeURIComponent(json.result[i].assetInstName);
								encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
								appendData = "";
								appendData += '<a class="item aivsideAINames letterSpacingHeader whitespaceNoTrim" style="font-size: 12px; color:rgba(0,0,0,0.6);" onclick="getAssetInstances('+json.result[i].assetInstVersionId+',\''+encodedAssetInstName+'\')">'+json.result[i].assetInstName+'</a> ';
								$("#assetInstanceSideBar").append(appendData);
								$('#childListAssetInstance').first().css( "background-color", "rgba(0,0,0,0.3)");
							}		
							
						}
					});
					 assetInstanceVersionListSidebarRangeFrom = assetInstanceVersionListSidebarRangeFrom + 40;
					
				}
			}else{
				assetInstanceVersionListSidebarScrollFlag = false;
			}
		}
	});
	
	
}


//edit Properties Data
function editPropertiesData(){
	//propertiesEditLock();
		/*var flag = false;
		if(globalSettingDetailsFlag){
			flag = getLockStatus();
			if(flag){
				if(lockedBySameUser){
					flag = false;
				}else{
					notifyMessage("Lock Asset Instance","Instance "+assetInstanceName+" is alredy locked","fail");
				}
			}
			else{
				lockAssetInstance();
			}
		}*/
		
		//if(flag == false){
			$(".editProperties").show();
			$(".showProperties").hide();
			
			/***************** Aditya 19.02.18 *************************/
			$(".showProperties.newTextFieldStyle").show();
			$(".editTextdimmerButtonStyle").show();
			//$(".showProperties.newTextFieldStyle").show();
			//$(".showProperties.newTextFieldStyle").children("p").hide();
			$(".showOrEditButton").removeClass("showText").text("Edit text");
			$(".textFieldMsg").text("Click on Edit button to edit the values.");
			//$(".showProperties").hide();
			//$(".showTextdimmerButtonStyle").show();
			/*$(".showProperties.newTextFieldStyle").removeClass("showDimmerButtonStyle");
			$(".showProperties.newTextFieldStyle").addClass("editDimmerButtonStyle");*/
			
			/*
			 $('.newTextFieldStyle').dimmer({
			    on: 'hover'
			  });*/
			/***************** Aditya Over ****************************/
			
			$("#editPropertiesDataEditButton").addClass("hideElement");
			$("#propSubBtn,#propCancelBtn").show();
			
			
			$(".showOrEditButton").popup({
				 inline     : true,
				 variation : 'inverted',
				 html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on edit button to edit the values !</spam></div>'
			 });
		//}
		
	
}

//function to edit the text field
var getPropertiesTextData = [];
var textFieldcount = 0;
var globalInputMaxLength = 0;

function editText(id){
	//$(".showOrEditButton").unbind();

	var jsonData = $("#hiddenJSON_"+id).text();
	jsonData = JSON.parse(jsonData);
	
	if($("#editTextButton_"+id).hasClass("showText")){
		$("#showAllTextFieldsList").html("");
		$('#showTextFieldModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
		
		var showTextParamName = $('#assetParamId_'+id).text();
		$('#showTextParamName').text(showTextParamName);
		
		var textDisplayData = "";
		
		if(jsonData.isArray == 0){
			textDisplayData += '<div class="ui fluid input " >';
			textDisplayData += '<input readonly value="'+jsonData.paramValue+'">';
			textDisplayData += '</div>';
			$("#showAllTextFieldsList").html(textDisplayData);
		}else{
			
			
			if((jsonData.text_data).length == 0 || jsonData.text_data == ""){
				$("#showAllTextFieldsList").html('<div class="ui  message" style="display:block !important;" >No data has been added yet.</div>');
			}else{
				$("#showAllTextFieldsList").html("");
				$.each(jsonData.text_data,function(i){
					//alert(jsonData.text_data[i])
					var randomId = makeRendomAlphaNumericValue();
					textDisplayData = "";
					
					//textDisplayData += '<div class="ui fluid input " style="margin-top:0.5em">';
					textDisplayData += '<div class="ui segment"  style="width: 100%;min-height:2em;max-height:10em;overflow:auto;"  id="randomId_'+randomId+'"></div>';
					//textDisplayData += '</div>';
					
					$("#showAllTextFieldsList").append(textDisplayData);
					
					var value = decodeURIComponent(jsonData.text_data[i]);
					
					if(value.startsWith("<")){
						
						if(!value.startsWith("<a")){
							/*var formatted =  formatXml(value);
							formatted = formatted.trim();
							formatted =	hljs.highlightAuto(formatted);
							value = '<pre class="showProperties">'+formatted.value+'</pre>';*/
							value = '<div class="showProperties">'+value+'</div>';
							
						}
						
					}else{
						var flag = validateURL(value);
						
						if(flag){
							value = '<a class="showProperties" href="'+value+'" target="_blank">'+value+'</a>';
						}
						
					}
					
					$("#randomId_"+randomId).html('<label class="ui label" style="margin-left: -1rem;margin-top:3px;padding: 2px;background:transparent;position: fixed;">'+(i+1)+'. </label><showText style="display: inline-block;margin-left: 1.5rem;">'+value+'</showText>');//edited by aditya
				});
				
			}
			
			
		}
		
		
		
	}else{
		$("#showAllTextEditFieldsList").html("");
		$("#submitEditText").unbind();
		$("#cancelEditText").unbind();
		
		$('#editTextFieldModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
		
		var editTextParamName = $('#assetParamId_'+id).text();
		$('#EditTextParamName').text(editTextParamName); 
		
		var textDisplayData = "";
		
		if(jsonData.isArray == 0){
			$("#addNewText").hide();
			//***Aditya 02.03.18 start
			if(jsonData.paramValue.length == 0){
				$("#submitEditText").text("Save");
			}
			//***Aditya 02.03.18 over
			
			textDisplayData += '<div class="ui action input customTextField" style="width: 100%;margin-bottom:5px;">';
			textDisplayData += '<input value="'+jsonData.paramValue+'" type="text" placeholder="Write your text here..."></div>'; 
			$("#showAllTextEditFieldsList").html(textDisplayData);
		}else{
			$("#addNewText").show();
			var maxlength = $("#maxLength_"+jsonData.assetParamId).text();
			globalInputMaxLength = maxlength;
			if((jsonData.text_data) != null){
				if((jsonData.text_data).length == 0){
					$("#submitEditText").text("Save");
					$("#showAllTextEditFieldsList").html('<div class="ui  message" id="multipleTextInputFilds" >No field has been added yet !</div>');
				}else{
					$("#showAllTextEditFieldsList").html("");
					
					
					$.each(jsonData.text_data, function(i){
						var randomId = makeRendomAlphaNumericValue();
						textDisplayData = "";
						textDisplayData += '<div class="ui action right labeled input customTextField" style="width: 100%;margin-bottom:5px; font-size:11px;">';
						textDisplayData += ' <label class="ui label txtSNo" style="background: transparent;border: 1px solid #dededf;border-right: none;padding-left: 1px;">'+(i+1)+'. '+'</label>';
						textDisplayData += '<input value="" id="randomId_'+randomId+'" maxlength="'+maxlength+'" type="text" placeholder="Maximun length '+maxlength+'">';
						textDisplayData += '<button class="ui icon button txtRmvBtn" onclick="removeTextField(this)">';
						textDisplayData += '<i class="close icon"></i></button></div>'; 
						
						$("#showAllTextEditFieldsList").append(textDisplayData);
						$("#randomId_"+randomId).val(decodeURIComponent(jsonData.text_data[i]));//(i+1)+'. '+
						
					});
					
				}
				
			}
				
			
			
		}
		
		
	}
	
	
	$("#submitEditText").on("click",function(i){
		var tempObj;
		if(jsonData.isArray == 0){
			var getData = $(".customTextField").children('input').val().trim();
			tempObj = {
			        "asset_category_name": jsonData.asset_category_name,
			        "assetParamId": jsonData.assetParamId,
			        "assetParamName": jsonData.assetParamName,
			        "isStatic": 0,
			        "isArray" : 0,
			        "paramTypeId": 1,
		            "paramValue": getData,
			        "text_data" : null
			};
			$("#hiddenJSON_"+id).html(JSON.stringify(tempObj));
			$('#editTextFieldModal').modal("hide");
			
		}else{
			var getDataArray = [];
			var flag = true;
			$(".customTextField").each(function(i){
				var getData = encodeURIComponent($(this).children('input').val().trim());
				//alert("update: "+getData)
				if(getData == ""){
					flag = false;
					return false;
				}else{
					getDataArray.push(getData);
				}
				
				
				
			});
			
			if(flag){
				closeNotifyMessageCard();
				tempObj = {
						"asset_category_name": jsonData.asset_category_name,
				        "assetParamId": jsonData.assetParamId,
				        "assetParamName": jsonData.assetParamName,
				        "isStatic": 0,
				        "isArray" : 1,
				        "paramTypeId": 1,
			            "paramValue": null,
				        "text_data" : getDataArray
				};
				$("#hiddenJSON_"+id).html(JSON.stringify(tempObj));
				$('#editTextFieldModal').modal("hide");
				
				$("#textCount_"+jsonData.assetParamId).html(getDataArray.length+" value(s)");
				
				
				
			}else{
				 notifyMessage("Update Multiple Text Field", "Please enter data, Input field(s) can not be empty.", "fail"); 
				
			}
				
			
		}
		
		
		
		
		
		
	});
	
	
	
	
}


//function to add new text field area
function addNewTextField(){
	$("#multipleTextInputFilds").remove();
	var customTextFieldLength = $(".customTextField").length;
	var appendTextField = '<div class="ui action right labeled input customTextField" style="width: 100%;margin-bottom:5px; font-size:11px;" >'
					+'<label class="ui label txtSNo" style="background: transparent;border: 1px solid #dededf;border-right: none;padding-left: 1px;">'+(customTextFieldLength+1)+'. </label>'
					+'<input type="text" maxlength="'+globalInputMaxLength+'" placeholder="Maximum length '+globalInputMaxLength+'">'
					+'<button class="ui icon button txtRmvBtn"  onclick="removeTextField(this)"><i class="close icon"></i></button></div>';
	$("#showAllTextEditFieldsList").append(appendTextField);
	
	textFieldcount++;
}

//function to remove custome text field
function removeTextField(obj){
	
	$(obj).parent().remove();
	
	if($("#showAllTextEditFieldsList").find("div.customTextField").length == 0){
		$("#showAllTextEditFieldsList").html('<div class="ui  message" id="multipleTextInputFilds" >No data has been added yet.</div>');
	}
	
	$(".customTextField").each(function(key, val){
		$(this).children("label.txtSNo").text(key+1+". ");
	});
	//$("#customText_"+id).remove();
	//customTextFieldAreaArray = [];
} 

var customTextFieldAreaArray = [];
//submit function of edit text
function finalSubmitEditText(){
	$(".customTextField").each(function(key, val){
		customTextFieldAreaArray.push($(this).children("input").val());
	});
	
	customTextFieldAreaArray = $.unique(customTextFieldAreaArray);
	
	$('#editTextFieldModal').modal({observeChanges:true, closable: false }).modal('hide').modal('refresh');
	
	editButtonClickedFlag = true;
}
//close Properties Editing
function closePropertiesEditing(){
	/***************** Aditya 19.02.18 *************************/
	$(".showOrEditButton").addClass("showText").text("Show text");
	/***************** Aditya Over ****************************/
	
	$(".editProperties").hide();
	$(".showProperties").show();
	$("#editPropertiesDataEditButton").removeClass("hideElement");
	$("#propSubBtn,#propCancelBtn").hide();
	 getPropertiesData();
}

//edit Rich Text Area 
function editRichTextArea(id){
	$("#submitEditRichText").unbind();
	$("#cancelEditRichText").unbind();
	
	
	$('#editRichTextModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	//editRichTextArea
	
	var getData = $("#input_"+id).html();
	var editor = CKEDITOR.instances.editRichTextArea;
	
	if (editor) {
		editor.destroy(true);
	}
	
	CKEDITOR.replace("editRichTextArea", {
		toolbar : 'BasicXmlSupport'
	});
	
   CKEDITOR.instances["editRichTextArea"].setData(getData);
   
   $("#submitEditRichText").on("click",function(){
	   var getUpdatedData = CKEDITOR.instances['editRichTextArea'].getData();
	   
	   $("#input_"+id).html(getUpdatedData);
	   //$("#input_"+id).addClass("editedText");
	   $('#editRichTextModal').modal("hide").modal("destroy");
   });
   
   $("#cancelEditRichText").on("click",function(){
	   $('#editRichTextModal').modal("hide").modal("destroy");
   });
	
}


//get Properties Data
var assetCategoryList = [];
var assetParamIdList = [];
var getPropertiesRichTextData = [];
var hasArrayFlagForRichText = false, hasArrayFlagForText = false;
function getPropertiesData(){
	var userName = "";
	getPropertiesTextData = [];
	getPropertiesRichTextData=[];
	 if(loggedInUserName == "roleAnonymous"){
		 userName = "roleAnonymous";
	 }else{
		 userName = loggedInUserName;
	 }
	 if(editAIVPageFlag == "false"){
		var url =  "/repopro/web/assetInstanceVersionManager/getAssetInstancePropertiesDetails?userName="+userName+"&assetName="+encodeURIComponent(assetName)+"&assetInstanceVersionId="+assetInstanceVersionId;
	 }else{
		 var url = "/repopro/web/assetInstanceVersionManager/propertiesStructure?assetName="+encodeURIComponent(browserAssetName)+"&userName="+userName;
	 }
	 
	 $("#propertiesAccordion").html("");
	 //console.log("properties edit url : " + url);
	 $.ajax({
			type : "GET",
			url: url,
			dataType : "json",
			async: false,
			cache:false,
			complete : function(data) {
				
				setTimeout(function(){ 
					$("#propertiesLoadingSegment").removeClass("loading");
				}, 50);
				var json = JSON.parse(data.responseText); 
				//console.log(JSON.stringify(json))
				var custListAssetParamID = "";
				var assetListAssetId = "";
				var assetListAssetParamID = "";
				var userListAssetParamID = "";
				var multiSelectFlag = ""; //harish
				
				
				if(json.status == "SUCCESS"){
					if(json.result == null || json.result == ""){
						$("#noAssetPropertiesData").show();
						$("#propertiesAccordion").hide();
						$("#propSubBtn").remove();
						$("#expandAllAccordion").remove();
						$("#editPropertiesDataEditButton").remove();
					}else{
							$("#noAssetPropertiesData").hide();
							$("#propertiesAccordion").show();
							$("#editPropertiesData").show();
							assetCategoryList.length = 0;
							assetParamIdList.length = 0;
							
							/*************Aditya 20Feb**************/
							/*console.log("Aditya 21Feb json.result :: "+JSON.stringify(json.result));
							var r_count=0;
							$.each(json.result, function(key, val){
								if(val.paramTypeId == 7 && val.rTFwithOutTags != null && val.rTFwithOutTags != ""){
									$.each(val.rTFwithOutTags, function(index, value){
										getPropertiesRichTextData.push({"value" : value, "id":"richTextFieldList_"+r_count});
										r_count++;
									});
									
								}else if(val.paramTypeId == 1 && val.isStatic == 0 && val.textDataList !=null  && val.textDataList != ""){
									console.log((val.textDataList).length+" :: else condition :: "+val.textDataList);
									$.each(val.textDataList, function(index, value){
										getPropertiesTextData.push(value);
									});
								}
								
								//-------21Feb
									if(val.paramTypeId == 7 && val.hasArray == 0){
										hasArrayFlagForRichText = false;
									}
									if(val.paramTypeId == 7 && val.hasArray == 1){
										hasArrayFlagForRichText = true;
									}
									
									if(val.paramTypeId == 1 && val.hasArray == 0){
										hasArrayFlagForText = false;
									}
									if(val.paramTypeId == 1 && val.hasArray == 1){
										hasArrayFlagForText = true;
									}
								//-------21Feb over
							});*/
							
							//console.log(JSON.stringify(getPropertiesTextData)+" :: getPropertiesTextData === getPropertiesRichTextData :: "+JSON.stringify(getPropertiesRichTextData));
							/**************Aditya over***************/
							
							
							$.each(json.result, function(i) {
								if ($.inArray(json.result[i].asset_category_name+"~~"+json.result[i].cat_disp, assetCategoryList) == -1){
									assetCategoryList.push(json.result[i].asset_category_name+"~~"+json.result[i].cat_disp);
								}
							});
							
							$.each(assetCategoryList, function(i) {
								var arr = assetCategoryList[i].split("~~");
								var appendPropertiesData = createPropertiesDataFormat(arr[0],arr[1]);
								$("#propertiesAccordion").append(appendPropertiesData);
							});
								
							$.each(json.result, function(i) {
								var propertiesValue = "";
								var inputType = "";
								var listFlag = false;
								var dateFlag = false;
								var textFlag = false;
								var richTextFlag = false;
								var deriveAttrFlag = false;
								var fileFlag = false;
								var ldapFlag = false;
								//----Chandana ----removing readonly class for paramTypeId 8
								if(loggedInUserName != "roleAnonymous"){
									if(json.result[i].editAccessFlag == false){
										if(json.result[i].paramTypeId != 5 && json.result[i].paramTypeId != 6 && json.result[i].paramTypeId != 8){
											$(".readOnlyMeta_"+json.result[i].cat_disp).show();
										}
									}
								}
								
								if(json.result[i].paramTypeId == 1){
									
									inputType = "text";
									textFlag = true;
									var value,valueforInputfield;
									
									if(json.result[i].isStatic == 0){
										if(json.result[i].paramValue != null)
										value = json.result[i].paramValue;
										
									}else{
										if(json.result[i].staticValue != null)
										value = json.result[i].staticValue;
									}
									if(value == null ){
										value = "";
										
									}
									
									
									
									var flag = validateURL(value);
									//var regex = /^\<a.*\>.*\<\/a\>/i;
									
									if(value.startsWith("<a")){
										flag = false;
									}
									/*propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
									propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" style="display:none;"></div>';*/
									
									//===Aditya 20feb
									propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
									propertiesValue += '<span id="hasArray_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].hasArray+'</span>';
									propertiesValue += '<span id="hiddenJSON_'+json.result[i].assetParamId+'" style="display:none;"></span>';
									propertiesValue += '<span id="isMandatory_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].mandatory+'</span>';
									propertiesValue += '<span id="isEditable_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].editAccessFlag+'</span>';
									
									propertiesValue += '<span id="maxLength_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].paramTextSize+'</span>';
									
									propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" style="display:none;">';
									if(json.result[i].isStatic == 0){
										if(json.result[i].hasArray == 0){
											propertiesValue += '<textarea class="mandetoryFieldValidation"  id="input_'+json.result[i].assetParamId+'"  value="" placeholder="Maximum characters '+json.result[i].paramTextSize+'" maxlength="'+json.result[i].paramTextSize+'"  rows="5" ></textarea></div>';
										}else{
											propertiesValue += '</div>';
										}
										
									}else{
										propertiesValue += '<textarea class="mandetoryFieldValidation"  id="input_'+json.result[i].assetParamId+'"  value="" placeholder="Maximum characters '+json.result[i].paramTextSize+'" maxlength="'+json.result[i].paramTextSize+'"  rows="5" ></textarea></div>';
									
									}
									//=======Aditya over
									
									//propertiesValue += '<input onclick="propertiesEditLock()" id="input_'+json.result[i].assetParamId+'" type="text" value="" placeholder="Maximum characters '+json.result[i].paramTextSize+'" maxlength="'+json.result[i].paramTextSize+'"></div>';
									
									/*======================= Aditya ====================*/
									//propertiesValue += '<textarea  id="input_'+json.result[i].assetParamId+'"  value="" placeholder="Maximum characters '+json.result[i].paramTextSize+'" maxlength="'+json.result[i].paramTextSize+'"  rows="5" ></textarea></div>';
									/*= ====================== Aditya-over ====================*/
									
									//propertiesValue += '<pre class="propertiesCustomTextField customPreTag" maxlength="'+json.result[i].paramTextSize+'"  placeholder="Maximum characters '+json.result[i].paramTextSize+'" contenteditable="true"  id="input_'+json.result[i].assetParamId+'"></pre></div>';
									if(flag){
										if(value.startsWith("<")){
											/*var formatted =  formatXml(value);
											formatted = formatted.trim();
											formatted =	hljs.highlightAuto(formatted);
											propertiesValue += '<pre class="showProperties" >'+formatted.value+'</pre>';*/
											propertiesValue += '<div class="showProperties" >'+value+'</div>';
											
										}else{
											propertiesValue += '<a class="showProperties" href="'+value+'" target="_blank">'+value+'</a>';
										}
										
										
									}else{
										if(value.startsWith("<a")){
											propertiesValue += '<span class="showProperties" >'+value+'</span>';
										}else{
											/*var formatted =  formatXml(value);
											formatted = formatted.trim();
											formatted =	hljs.highlightAuto(formatted);*/
											
											if(json.result[i].isStatic == 0){
												
												
												if(json.result[i].hasArray == 0){
													/*propertiesValue += '<pre class="showProperties" >'+formatted.value+'</pre>';*/
													propertiesValue += '<div class="showProperties" >'+value+'</div>';
												}else{
													propertiesValue += '<pre class="ui segment showProperties newTextFieldStyle customPreTag mandetoryFieldValidation" style="overflow: visible !important;">';//<p>';//+formatted.value+'</p>';
													
													if(json.result[i].textDataList != null){
														var textDataListLength = (json.result[i].textDataList).length;
														/*propertiesValue += '<div class="ui list">'
														$.each(json.result[i].textDataList, function(key, val){
															var value = decodeURIComponent(val);
															if(value.length < 30){
																propertiesValue += '<a class="item" style="color: #525658;">'+value+'</a>';
															}else{
																propertiesValue += '<a class="item" style="color: #525658;">'+value.substring(0,30) +'...'+'</a>';
															}
															
															
														});
														propertiesValue += '</div>';*/
													}
													propertiesValue += '<div class="center"><div class="ui icon text_field_msg_class" style="margin-top: -2rem;margin-left: 0.6rem;"><div class="text_info_and_button"  style="display: none;"><i class="info circle icon teal"></i>';
													propertiesValue += '<span class="textFieldMsg" style="color: #525658; font-family: sans-serif;font-weight: 500; font-size: 12px;">Click on Show button to view the values. </span> </div></div>';
													propertiesValue += '<div class="countDisp" style="margin-left: 1rem !important;" id="textCount_'+json.result[i].assetParamId+'">'+json.result[i].textCount+' value(s)</div></div>';
													propertiesValue += '<button class="ui mini button showOrEditButton showText" style="margin-top: 2rem;" data-title="" id="editTextButton_'+json.result[i].assetParamId+'" onclick="editText('+json.result[i].assetParamId+')">Show text</button>'; //CHANDANA -07-06-2010(DIV -BUTTON KEYBOARD SHORTCUT);
													propertiesValue += '</pre>';
													//propertiesValue += '</p>';
													/*========= Aditya 19.02.18 ======================*/
													/*propertiesValue += '<div class="ui inverted blurring dimmer editTextdimmerButtonStyle" style="z-index:1;"><div class="content">';
													propertiesValue += '<div class="center">';
													propertiesValue += '<div class="ui icon text_field_msg_class"><div class="text_info_and_button"><span class="" style="color: #525658;font-size: 12px;"><i class="info circle icon"></i>Click on </span> ';
													propertiesValue += '<div class="ui primary mini button showOrEditButton showText" id="editTextButton_'+json.result[i].assetParamId+'" onclick="editText('+json.result[i].assetParamId+')">Show Text</div>';
													propertiesValue += '<span class="textFieldMsg" style="color: #525658;font-size: 12px;"> to view the values. </span> </div>';
													
													if(json.result[i].textDataList != null){
														
														propertiesValue += '<div class="ui list" style="overflow-y: scroll;background: #f3f3f3;height: 2rem;">'
														$.each(json.result[i].textDataList, function(key, val){
															var value = decodeURIComponent(val);
															if(value.length < 30){
																propertiesValue += '<a class="item" style="color: #525658;font-size: 11px;">'+value+'</a>';
															}else{
																propertiesValue += '<a class="item" style="color: #525658;font-size: 11px;">'+value.substring(0,30) +'...'+'</a>';
															}
														});
														propertiesValue += '</div>';
													}
													
													
													propertiesValue += '</div></div></div></pre>';*/
													
													/*propertiesValue += '<div class="ui inverted blurring dimmer editTextdimmerButtonStyle" style="z-index:1;"><div class="content"><div class="center">'; 
													propertiesValue += '<div class="ui primary mini button showOrEditButton showText" id="editTextButton_'+json.result[i].assetParamId+'" onclick="editText('+json.result[i].assetParamId+')">Show Text</div>';
													propertiesValue += '</div></div></div></pre>';*/
													/*============ Aditya Over =====================*/
												}
												
												
											}else{
												/*propertiesValue += '<pre class="showProperties" >'+formatted.value+'</pre>';*/
												propertiesValue += '<div class="showProperties" >'+value+'</div>';
											}
											
											
										}
									}
									//propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
									propertiesValue += '<div class="ui  pointing red basic label errMandetoryField errMandetory_'+json.result[i].assetParamId+'" style="display:none;">Please provide value</div>';
								}else if(json.result[i].paramTypeId == 2){
									inputType = "date";
									dateFlag = true;
									var reversed,pieces,date;
									if(json.result[i].isStatic == 0){
										date = json.result[i].paramValue;
									}else{
										date = json.result[i].staticValue;
									}
								 	if(date == null){
								 		date = "";
								 	}
								 		
								 	propertiesValue += '<div class="ui left icon right action input editProperties propertiesLockedByOther" style="display:none;">';
								 	propertiesValue += '<input readonly id="input_'+json.result[i].assetParamId+'" class="editProperties" type="text" value="'+date+'" placeholder="dd/mm/yyyy" title="Click to change date" style="cursor:pointer" >';
								 	propertiesValue += ' <i class="calendar icon"></i>';
								 	propertiesValue += '<div class="ui icon button" title="Clear date field" onclick="$(\'#input_'+json.result[i].assetParamId+'\').val(\'\');"> <i class="close icon"></i> </div>';	
								 	propertiesValue += '</div>';
								 		
								 	propertiesValue += '<span class="showProperties" >'+date+'</span>';
								 	propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
								 	propertiesValue += '<span id="isMandatory_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].mandatory+'</span>';
								 	propertiesValue += '<span id="isEditable_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].editAccessFlag+'</span>';
								 	propertiesValue += '<br><div class="ui  pointing red basic label errMandetoryField errMandetory_'+json.result[i].assetParamId+'" style="display:none;">Please provide value</div>';
								 	
								}else if(json.result[i].paramTypeId == 3){
									inputType = "file";
									fileFlag = true;
									var fileName; 
									if(json.result[i].isStatic == 0){
										fileName = json.result[i].fileName;
									}else{
										fileName = json.result[i].apdFileName;
									}
									if(fileName == null){
										fileName = "";
									}
									
									var fileType = fileName.split('.').pop().toLowerCase();
									
								 	
								 	$('#fileForm').append("<input type='file' class='hidden' name='hidden_"+json.result[i].assetParamId+"' id='hidden_"+json.result[i].assetParamId+"' />");
								 	
								 	propertiesValue += '<label for="input_'+json.result[i].assetParamId+'" class="ui icon mini button editProperties propertiesLockedByOther fileUpload uploadBtn_'+json.result[i].assetParamId+'" tabindex = "0" style="display:none;">'; 
									propertiesValue += '<i class="file icon"></i> Upload File</label>';
									propertiesValue += '<input id="input_'+json.result[i].assetParamId+'" onchange="showUploadedFile(this,'+json.result[i].assetParamId+')" style="display: none;" class="upFile" type="file" name="uploadedFile_'+json.result[i].assetParamId+'">';
									
								 	if(json.result[i].isStatic == 1){
									 	if(fileType == "jpeg" || fileType == "png" || fileType == "jpg"){
									 		propertiesValue += '<image id="paramImage_'+json.result[i].assetParamId+'" src="/repopro/images/thumbnailImages/'+json.result[i].assetParamId+"_"+fileName+'">';
									 		propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json.result[i].assetParamId+'" href="/repopro/images/thumbnailImages/'+json.result[i].assetParamId+"_"+fileName+'" download>'+fileName+'</a>';
								 	
									 	}else{
									 		//console.log(JSON.stringify(json.result[i]))
									 		propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json.result[i].assetParamId+'" onclick="downloadFile('+json.result[i].isStatic+',\''+json.result[i].assetParamName+'\')">'+fileName+'</a>';
								 	
									 	}	
									 		
								 	}else{	
								 		if(fileType == "jpeg" || fileType == "png" || fileType == "jpg"){	
									 		propertiesValue += '<image id="paramImage_'+json.result[i].assetParamId+'" src="/repopro/images/thumbnailImages/'+json.result[i].assetInstParamId+"_"+fileName+'">';
									 		propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json.result[i].assetParamId+'" href="/repopro/images/thumbnailImages/'+json.result[i].assetInstParamId+"_"+fileName+'" download>'+fileName+'</a>';
								 		}else{
								 			propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json.result[i].assetParamId+'" onclick="downloadFile('+json.result[i].isStatic+',\''+json.result[i].assetParamName+'\')">'+fileName+'</a>';
								 		}
								 	}
								 	
								 	propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none; ">'+json.result[i].isStatic+'</span>';
								 	propertiesValue += '<span id="isMandatory_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].mandatory+'</span>';
								 	propertiesValue += '<span id="isEditable_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].editAccessFlag+'</span>';
								 	propertiesValue += '<span id="oldFileName_'+json.result[i].assetParamId+'" style="display:none; ">'+fileName+'</span>';
								 	/*propertiesValue += '<label for="input_'+json.result[i].assetParamId+'" class="ui icon mini button editProperties propertiesLockedByOther"  style="float: right;display:none;">'; 
									propertiesValue += '<i class="file icon"></i> Upload File</label>';
									propertiesValue += '<input id="input_'+json.result[i].assetParamId+'" onchange="showUploadedFile(this,'+json.result[i].assetParamId+')" style="display: none;" class="upFile" type="file" name="uploadedFile_'+json.result[i].assetParamId+'">';
									*/
								 	propertiesValue += '<br><div class="ui  pointing red basic label errMandetoryField errMandetory_'+json.result[i].assetParamId+'" style="display:none;">Please provide value</div>';
								}else if(json.result[i].paramTypeId == 4){
							
									var value;
									listFlag = true;
									
									if(json.result[i].isStatic == 0){
										value = json.result[i].paramValue;
									//alert("paramValue" + json.result[i].paramValue);
									}else{
										value = json.result[i].staticValue;
										
									}
									if(value == null ){
										value = "";
									}	
									
									if(json.result[i].listTypeParamTypeId == 1 ){
										inputType = "list";
										/*propertiesValue += getCustomList(json.result[i].assetParamId);*/
										var assetParamValue = json.result[i].assetParamId +"~~";
										custListAssetParamID += assetParamValue; 
										
										propertiesValue += '<span id="customList_'+json.result[i].assetParamId+'"></span>';
										
										if(value == -1 || value == ""){
											propertiesValue += '<span id="custListSelectValue_'+json.result[i].assetParamId+'" class="showProperties" style="display:none;"></span>';
										}else{
											
											var data = value.split("~~");
											var selectedLabels = "";
											$.each(data, function(j){
												selectedLabels += '<div class="ui label listShowPropertiesLabelStyle">'+data[j]+'</div>';
											});
											
											propertiesValue += '<span  class="showProperties" style="display:none;">'+selectedLabels+'</span>';
											propertiesValue += '<span id="custListSelectValue_'+json.result[i].assetParamId+'"  style="display:none;">'+value+'</span>';
											
										}
										propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
										propertiesValue += '<span id="isMandatory_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].mandatory+'</span>';
										propertiesValue += '<span id="isEditable_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].editAccessFlag+'</span>';
										propertiesValue += '<span id="isMultiple_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].singleMultipleFlag+'</span>'; //harish
										//propertiesValue += '<br><div class="ui  pointing red basic label errMandetoryField errMandetory_'+json.result[i].assetParamId+'" style="display:none;">Please provide value</div>';
									}else if(json.result[i].listTypeParamTypeId == 2 ){
										inputType = "list";
										
										if(value == -1 || value == ""){
											propertiesValue += '<span id="assetListSelectValue_'+json.result[i].assetParamId+'" class="showProperties" style="display:none;"></span>';
										}else{
											
											var data = value.split("~~");
											var selectedLabels = "";
											$.each(data, function(j){
												selectedLabels += '<div class="ui label listShowPropertiesLabelStyle">'+data[j]+'</div>';
											});
											
											propertiesValue += '<span class="showProperties" style="display:none;">'+selectedLabels+'</span>';
											propertiesValue += '<span id="assetListSelectValue_'+json.result[i].assetParamId+'"  style="display:none;">'+value+'</span>';
										
										}
										
										propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
										propertiesValue += '<span id="isMandatory_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].mandatory+'</span>';
										propertiesValue += '<span id="isEditable_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].editAccessFlag+'</span>';
										propertiesValue += '<span id="isMultiple_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].singleMultipleFlag+'</span>'; //harish
										
										
										propertiesValue += '<div id="assetList_'+json.result[i].assetParamId+'" >';
										if(json.result[i].singleMultipleFlag == false || json.result[i].singleMultipleFlag == "false") {
											propertiesValue += '<select  class="ui search selection dropdown propertiesLockedByOther callAssetListAPI propDropdownWidth"  id="input_'+json.result[i].assetParamId+'" multiple="">';
											propertiesValue += '<option value="">Select</option>';
										}
										if(json.result[i].singleMultipleFlag == true || json.result[i].singleMultipleFlag == "true") {
											propertiesValue += '<select  class="ui search selection dropdown propertiesLockedByOther callAssetListAPI propDropdownWidth"  id="input_'+json.result[i].assetParamId+'" >';
											propertiesValue += '<option value="">Select</option>';
											propertiesValue += '<option value="-1">Select</option>';
										}
										if(value != ""){
											//harish
											/*propertiesValue += '<option value="">Select</option>';*/
											if(json.result[i].singleMultipleFlag == false || json.result[i].singleMultipleFlag == "false") {
											value = value.split("~~");
											$.each(value, function(j) {
												  propertiesValue += '<option value="'+encodeURIComponent(value[j])+'">'+value[j]+'</option>';
												  listArr.push(encodeURIComponent(value[j]));
											});
											}
											if(json.result[i].singleMultipleFlag == true || json.result[i].singleMultipleFlag == "true") {
												 propertiesValue += '<option value="'+encodeURIComponent(value)+'">'+value+'</option>';
											}
										}else{
											propertiesValue += '<option value="">Select</option>';
										}
										propertiesValue += '</select></div>';
										setTimeout(function(){
											/*alert("set time out");*/
											//harish
											if(json.result[i].singleMultipleFlag == false || json.result[i].singleMultipleFlag == "false"){
												$('#input_'+json.result[i].assetParamId).dropdown('set selected',listArr);
											}
												
											if(json.result[i].singleMultipleFlag == true || json.result[i].singleMultipleFlag == "true"){
												$('#input_'+json.result[i].assetParamId).dropdown('set selected',encodeURIComponent(value));
											}
												
										}, 0);
										
										
									}else if(json.result[i].listTypeParamTypeId == 3 ){
										
										inputType = "list";
										/*propertiesValue += getActiveUserList(json.result[i].assetParamId);*/
										userListAssetParamID += json.result[i].assetParamId +"~~";
										multiSelectFlag += json.result[i].singleMultipleFlag + "~~";  //harish
										
										propertiesValue += '<span id="userList_'+json.result[i].assetParamId+'"></span>';
										
										if(value == -1 || value == ""){
											propertiesValue += '<span id="userListSelectValue_'+json.result[i].assetParamId+'" class="showProperties" style="display:none;"></span>';
										}else{
											
											var data = value.split("~~");
											var selectedLabels = "";
											$.each(data, function(j){
												selectedLabels += '<div class="ui label listShowPropertiesLabelStyle">'+data[j]+'</div>';
											});
											
											propertiesValue += '<span  class="showProperties" style="display:none;">'+selectedLabels+'</span>';
											
											propertiesValue += '<span id="userListSelectValue_'+json.result[i].assetParamId+'"  style="display:none;">'+value+'</span>';
										
										}
										
										propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
										propertiesValue += '<span id="isMandatory_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].mandatory+'</span>';
										propertiesValue += '<span id="isEditable_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].editAccessFlag+'</span>';
										propertiesValue += '<span id="isMultiple_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].singleMultipleFlag+'</span>'; //harish
										
									}else if(json.result[i].listTypeParamTypeId == 4 ){
										
										inputType = "list";
										
										propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
										propertiesValue += '<span id="isMandatory_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].mandatory+'</span>';
										propertiesValue += '<span id="isEditable_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].editAccessFlag+'</span>';
										propertiesValue += '<span id="isMultiple_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].singleMultipleFlag+'</span>';
										propertiesValue += '<span id="listType_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].listTypeParamTypeId+'</span>';
										propertiesValue += '<span id="hiddenJSON_'+json.result[i].assetParamId+'" style="display:none;">'+value+'</span>';
										
										
										
										if(json.result[i].singleMultipleFlag == false || json.result[i].singleMultipleFlag == "false"){
											
											propertiesValue += '<div  class="ui segment showProperties richTextCustomView " style="min-height:5.2rem !important;">';
											propertiesValue += '<div class="countDisp">'+json.result[i].ldapUserListCount+' value(s)</div>';
											propertiesValue += '<button class="ui mini button rtfBtnShow" id="viewLDAPUserList_'+json.result[i].assetParamId+'" style="margin-top: 2rem !important;" data-title=""  onclick="viewLDAPUserListModal('+json.result[i].assetParamId+')">Show all values</button></div>';//CHANDANA 06-06-2019 (changed div to button for keyboard controls)
										}else{
											propertiesValue += '<div class="showProperties">'+value+'</div>';
											
										}
										
										propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" id="ldapUserEditFileds_'+json.result[i].assetParamId+'">';

										propertiesValue += '<div class="ui segment richTextCustomView customPreTag mandetoryFieldValidation" style="min-height:5.2rem!important;color: #606365 !important;padding-left: 1rem !important;">';
									
										if(json.result[i].singleMultipleFlag == false || json.result[i].singleMultipleFlag == "false"){
											propertiesValue += '<div class="richTextBackendData countDisp" id="ldapUserCount_'+json.result[i].assetParamId+'">'+json.result[i].ldapUserListCount+' value(s)</div>';
											propertiesValue += '<button class="ui mini button rtfBtnEdit" style="margin-top: 2rem !important;" data-title="" id="editLDAPUserList_'+json.result[i].assetParamId+'" onclick="openEditLDAPUserModal('+json.result[i].assetParamId+')">Edit list</button>';
										
										}else{
											propertiesValue += '<div class="richTextBackendData countDispForSingleRichText" id="ldapUserCount_'+json.result[i].assetParamId+'" >'+value+'</div>';
											propertiesValue += '<button class="ui mini button rtfBtnEdit" style="margin-top: 1rem !important;" data-title="" id="editLDAPUserList_'+json.result[i].assetParamId+'" onclick="openEditLDAPUserModal('+json.result[i].assetParamId+')">Edit list</button>';
											
										}
										
										propertiesValue += '</div></div>';
									}
									
									
									
									
									
									propertiesValue += '<br><div class="ui  pointing red basic label errMandetoryField errMandetory_'+json.result[i].assetParamId+'" style="display:none;">Please provide value</div>';
									
								}else if(json.result[i].paramTypeId == 5){
									/*deriveAttrFlag = true;
									inputType = "derivedAttribute";
									var derivedData;
									if(json.result[i].paramValue == null){
										derivedData = "";
									}else{
										derivedData = json.result[i].paramValue;
									}
									
									var formatted =  formatXml(derivedData);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);
							
									formatted.value = formatted.value.replace(/~~/g,",");
									//console.log(" formatted "+JSON.stringify(formatted));
									
									propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
									propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
									propertiesValue += '<pre>'+formatted.value+'</pre>';
									
									propertiesValue += '</div>';*/
									
									deriveAttrFlag = true;
									inputType = "derivedAttribute";
									var derivedData;
									if(json.result[i].paramValue == null){
										derivedData = "";
									}else{
										derivedData = json.result[i].paramValue;
									}
									
									propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
									propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
									
									/*var formatted =  formatXml(derivedData);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);
									//console.log(" formatted:      "+formatted.value);
									formatted.value = formatted.value.replace(/~~/g,",");
									var derData = formatted.value;*/
									
									
									
									
									
									if (derivedData.indexOf('`!!`') != -1) {
										var data = derivedData.split('`!!`');
										derivedData = data[1];
									}
									//console.log(derivedData)
									
									if(derivedData.indexOf("``") != -1){
										var split_derivedData = derivedData.split("`~`");
										$.each(split_derivedData,function(s){
											if(split_derivedData[s].indexOf("``") != -1){
												split_derivedData[s] = split_derivedData[s].replace(/``/g,"|");
											}
											
											if(split_derivedData[s].indexOf('~~') != -1){
												split_derivedData[s] = split_derivedData[s].replace(/~~/g,",");
											}
										});
										
										$.each(split_derivedData,function(sData){
											console.log("split_derivedData : " + split_derivedData[sData]);
											formatted = split_derivedData[sData].trim();
											propertiesValue += '<div class="ui label listShowPropertiesLabelStyle">';
											//propertiesValue += '<span>'+formatted+'</span>';
											propertiesValue += formatted;
											propertiesValue += '</div>';
											
											if(sData < (split_derivedData.length-1)){
												propertiesValue += '<div class="ui divider"></div>';
											}
										});
										
										
									}
									
									else {
										derivedData = derivedData.split("`~`");
										$.each(derivedData,function(e){
											var derviedSplittedValue = derivedData[e].split("~~");

											$.each(derviedSplittedValue,function(n){
												//console.log(" derviedSplittedValue "+derviedSplittedValue[n]);

												formatted = derviedSplittedValue[n].trim();
												propertiesValue += '<div class="ui basic label disabled">';

												/*if(formatted.startsWith("<")){
												formatted =	hljs.highlightAuto(formatted);
												propertiesValue += '<pre>'+formatted.value+'</pre>';
											}else{*/
												propertiesValue += '<span>'+formatted+'</span>';
												//}


												propertiesValue += '</div>'; 

											});



											if(e < (derivedData.length-1)){
												propertiesValue += '<div class="ui divider"></div>';
											}


										});
										
									
								}
								propertiesValue += '</div>';
									
								}else if(json.result[i].paramTypeId == 6){
									inputType = "derivedComputation";
									var derivedData;
									if(json.result[i].paramValue == null){
										derivedData = "";
									}else{
										derivedData = json.result[i].paramValue;
									}
									propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
									propertiesValue += derivedData;
									propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
									propertiesValue += '</div>';
								}else if(json.result[i].paramTypeId == 7){  //souradip 06/02/18
									inputType = "richText";
									richTextFlag = true;
									var value,valueforInputfield;
									
									if(json.result[i].isStatic == 0){
										if(json.result[i].paramValue != null)
										value = json.result[i].paramValue;
										
									}else{
										if(json.result[i].staticValue != null)
										value = json.result[i].staticValue;
									}
									if(value == null ){
										value = "";
									}
									
									
									
									propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
									propertiesValue += '<span id="isMandatory_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].mandatory+'</span>';
									propertiesValue += '<span id="isEditable_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].editAccessFlag+'</span>';
									propertiesValue += '<span id="hasArray_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].hasArray+'</span>';
									propertiesValue += '<span id="hiddenJSON_'+json.result[i].assetParamId+'" style="display:none;"></span>';
									propertiesValue += '<span id="dataForText_'+json.result[i].assetParamId+'" style="display:none;"></span>';
									
									/*	if(value.startsWith("<pre")){
										propertiesValue += '<div class="showProperties" id="showProperties_'+json.result[i].assetParamId+'" style="display:none;">'+value+'</div>';
									}else{
										var formatted =  formatXml(value);
										formatted = formatted.trim();
										formatted =	hljs.highlightAuto(formatted);
										propertiesValue += '<pre class="showProperties" id="showProperties_'+json.result[i].assetParamId+'" style="display:none;">'+formatted.value+'</pre>';
									}*/
									
									
									
									//*****************Aditya02.03.18
									/*propertiesValue += '<div  class="ui stacked  segment showProperties richTextCustomView " style="min-height:5em;">Total No of fields: '+json.result[i].rtfCount;
									propertiesValue += '<div class="ui inverted dimmer" style="z-index:1;"><div class="content"><div class="center">';
									propertiesValue += '<div class="ui primary mini button" onclick="openViewRichTextModal('+json.result[i].assetParamId+')">Show All Fields</div>';
									propertiesValue += '</div></div></div>';
									propertiesValue += '</div>';
									*/
									propertiesValue += '<div  class="ui segment showProperties richTextCustomView " style="min-height:5.2rem !important;">';
									propertiesValue += '<div class="center"><div class="ui icon text_field_msg_class" style="margin-top: -0.5rem;display:none;"><div class="text_info_and_button"  style="display: none;"><i class="info circle icon teal"></i>';
									propertiesValue += '<span class="richTextFieldMsg" style="color: #525658 !important; font-family: sans-serif;font-weight: 500 !important; font-size: 12px !important;">Click on Show button to view the values. </span> </div></div>';
									if(json.result[i].hasArray == 0){
										
										propertiesValue += '<div class="countDispForSingleRichText">'+value+'</div>';
										
										propertiesValue += '</div>';//margin-left: 26.5rem;
										propertiesValue += '<button class="ui mini button rtfBtnShow" id="rtfBtn_'+json.result[i].assetParamId+'" style="margin-top: 1rem !important;" data-title=""  onclick="openViewRichTextModal('+json.result[i].assetParamId+')">Show all fields</button></div>';
										
									}else{
										propertiesValue += '<div class="countDisp">'+json.result[i].rtfCount+' value(s)</div>';
										
										propertiesValue += '</div>';//margin-left: 26.5rem;
										propertiesValue += '<button class="ui mini button rtfBtnShow" id="rtfBtn_'+json.result[i].assetParamId+'" style="margin-top: 2rem !important;" data-title=""  onclick="openViewRichTextModal('+json.result[i].assetParamId+')">Show all fields</button></div>';
										
									}
									
									/*propertiesValue += '</div>';
									propertiesValue += '<div class="ui mini button rtfBtn" id="rtfBtn_'+json.result[i].assetParamId+'" style="margin-left: 26.5rem;margin-top: -0.5rem !important;" data-title=""  onclick="openViewRichTextModal('+json.result[i].assetParamId+')">Show All Fields</div></div>';
									*///*******Aditya over
									
									propertiesValue += '<div  id="showProperties_'+json.result[i].assetParamId+'" style="display:none;">'+value+'</div>';
									
									
									
									//propertiesValue += '<div class="showProperties" id="showProperties_'+json.result[i].assetParamId+'" style="display:none;">'+value+'</div>';
									
									
									
									
									propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" >';

									//******Commented by aditya 02.03.18
									/*propertiesValue += '<div class="ui segment richTextCustomView customPreTag mandetoryFieldValidation" style="min-height:7em;">';
									propertiesValue += '<div class="richTextBackendData" style="min-height:5em; " id="input_'+json.result[i].assetParamId+'"  maxlength="'+json.result[i].paramTextSize+'">Total No of fields: '+json.result[i].rtfCount+'</div>';
									propertiesValue += '<div class="ui inverted blurring dimmer " style="z-index:1;"> <div class="content"> <div class="center">'; 
									propertiesValue += '<div class="ui primary mini button" id="editTextButton_'+json.result[i].assetParamId+'" onclick="editRichTextAreaFields('+json.result[i].assetParamId+')">Edit Rich Text</div>';
									propertiesValue += '</div> </div></div>';
									propertiesValue += '</div></div>';*/
									//******Commented over by aditya 02.03.18
									
									propertiesValue += '<div class="ui segment richTextCustomView customPreTag mandetoryFieldValidation" style="min-height:5.2rem!important;color: #606365 !important;padding-left: 1rem !important;">';
									propertiesValue += '<div class="center"><div class="ui icon text_field_msg_class" style="display: none;"><div class="text_info_and_button"  style="display: none;"><i class="info circle icon teal"></i>';
									propertiesValue += '<span class="richTextFieldMsg" style="color: #606365 !important; font-family: sans-serif;font-weight: 500 !important; font-size: 12px !important;">Click on Edit button to edit the values. </span> </div></div>';

									if(json.result[i].hasArray == 0){
										propertiesValue += '<div class="richTextBackendData countDispForSingleRichText" id="input_'+json.result[i].assetParamId+'"  maxlength="'+json.result[i].paramTextSize+'">'+value+'</div>';
										
										propertiesValue +='</div>';//margin-left: 25.3rem;
										propertiesValue += '<button class="ui mini button rtfBtnEdit" style="margin-top: 1rem !important;" data-title="" id="editTextButton_'+json.result[i].assetParamId+'" onclick="editRichTextAreaFields('+json.result[i].assetParamId+')">Edit rich text</button>';
										
									}else{
										propertiesValue += '<div class="richTextBackendData countDisp" id="input_'+json.result[i].assetParamId+'"  maxlength="'+json.result[i].paramTextSize+'">'+json.result[i].rtfCount+' value(s)</div>';
										
										propertiesValue +='</div>';//margin-left: 25.3rem;
										propertiesValue += '<button class="ui mini button rtfBtnEdit" style="margin-top: 2rem !important;" data-title="" id="editTextButton_'+json.result[i].assetParamId+'" onclick="editRichTextAreaFields('+json.result[i].assetParamId+')">Edit rich text</button>';
									}
									
									
									propertiesValue += '</div></div>';
									
									propertiesValue += '<div class="ui  pointing red basic label errMandetoryField errMandetory_'+json.result[i].assetParamId+'" style="display:none;">Please provide value</div>';
								}
								
								// Auto Complete Hema
								else if(json.result[i].paramTypeId == 8){
									deriveAttrFlag = true;
									inputType = "autoComplete";
									var derivedData;
									if(json.result[i].paramValue == null){
										derivedData = "";
									}else{
										derivedData = json.result[i].paramValue;
									}
									
									propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
									propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
									
									
									if (derivedData.indexOf('`!!`') != -1) {
										var data = derivedData.split('`!!`');
										derivedData = data[1];
									}
									//console.log(derivedData)
									
									
									if(derivedData.indexOf("``") != -1){
										var split_derivedData = derivedData.split("`~`");
										$.each(split_derivedData,function(s){
											if(split_derivedData[s].indexOf("``") != -1){
												split_derivedData[s] = split_derivedData[s].replace(/``/g,"|");
											}
											
											if(split_derivedData[s].indexOf('~~') != -1){
												split_derivedData[s] = split_derivedData[s].replace(/~~/g,",");
											}
										});
										
										$.each(split_derivedData,function(sData){
											//console.log("split_derivedData : " + split_derivedData[sData]);
											formatted = split_derivedData[sData].trim();
											propertiesValue += '<div class="ui label listShowPropertiesLabelStyle">';
											//propertiesValue += '<span>'+formatted+'</span>';
											propertiesValue += formatted;
											propertiesValue += '</div>';
											
											if(sData < (split_derivedData.length-1)){
												propertiesValue += '<div class="ui divider"></div>';
											}
										});
										
										
									}
									
									else {
									derivedData = derivedData.split("`~`");
									//console.log(" derivedData "+derivedData);
									$.each(derivedData,function(e){
										var derviedSplittedValue = derivedData[e].split("~~");
										
										$.each(derviedSplittedValue,function(n){
											//console.log(" derviedSplittedValue "+derviedSplittedValue[n]);
											
											formatted = derviedSplittedValue[n].trim();
											propertiesValue += '<div class="ui basic label disabled">';
											
											/*if(formatted.startsWith("<")){
												formatted =	hljs.highlightAuto(formatted);
												propertiesValue += '<pre>'+formatted.value+'</pre>';
											}else{*/
												propertiesValue += '<span>'+formatted+'</span>';
											//}
											
											
											propertiesValue += '</div>'; 
											
										});
										
										
										
										if(e < (derivedData.length-1)){
											propertiesValue += '<div class="ui divider"></div>';
										}
											
									});
									}
									propertiesValue += '</div>';
									
									
									
								}
								
							//	3.15.2019
								else if(json.result[i].paramTypeId == 9){
									inputType = "ldapMapping";
									ldapFlag = true;
									
									propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
									propertiesValue += '<span id="isMandatory_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].mandatory+'</span>';
									propertiesValue += '<span id="isEditable_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].editAccessFlag+'</span>';
									propertiesValue += '<span id="isMultiple_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].singleMultipleFlag+'</span>';

									if(json.result[i].singleMultipleFlag == false || json.result[i].singleMultipleFlag == "false"){

										//Show multi list
										propertiesValue += '<div  class="ui segment showProperties richTextCustomView " style="min-height:5.2rem !important;">';
										propertiesValue += '<div class="countDisp">'+json.result[i].ldapMappingListCount+' value(s)</div>';

										propertiesValue += '<table class="ui celled table multiDataTable hidden" id="showMultipleSelectData_'+json.result[i].assetParamId+'">';
										if(json.result[i].ldapmappingdata == null){
										}
										else {

											$(json.result[i].ldapmappingdata).each(function(k){


												var u_Id = "", u_email = "", u_firstName = "", u_lastName = "", u_fullName = "", u_dept = "";
												var count = 0;
												if(json.result[i].ldapmappingdata[k].userId != null){
													u_Id = json.result[i].ldapmappingdata[k].userId;
													u_Id = u_Id.split("~~");
													count = u_Id.length;
												}
												else {
													u_Id = "";
												}

												if(json.result[i].ldapmappingdata[k].email != null){
													u_email = json.result[i].ldapmappingdata[k].email;
													u_email = u_email.split("~~");
													count = u_email.length;
												}else {
													u_email = "";
												}

												if(json.result[i].ldapmappingdata[k].firstName != null){
													u_firstName = json.result[i].ldapmappingdata[k].firstName;
													u_firstName = u_firstName.split("~~");
													count = u_firstName.length;
												}else {
													u_firstName = "";
												}

												if(json.result[i].ldapmappingdata[k].lastName != null){
													u_lastName = json.result[i].ldapmappingdata[k].lastName;
													u_lastName = u_lastName.split("~~");
													count = u_lastName.length;
												}else {
													u_lastName = "";
												}

												if(json.result[i].ldapmappingdata[k].dept != null){
													u_dept = json.result[i].ldapmappingdata[k].dept;
													u_dept = u_dept.split("~~");
													count = u_dept.length;
												}else {
													u_dept = "";
												}

												if(json.result[i].ldapmappingdata[k].fullName != null){
													u_fullName = json.result[i].ldapmappingdata[k].fullName;
													u_fullName = u_fullName.split("~~");
													count = u_fullName.length;
												}else {
													u_fullName = "";
												}

												for(var h=0; h<count; h++){

													propertiesValue += '<tr>';
													if(u_Id[h] != undefined){
														propertiesValue += '<td>'+u_Id[h]+'<span class="hidden" id="multiShowUserAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].userIdAttributeId+'</span></td>';
													}


													if(u_firstName[h] != undefined){
														propertiesValue += '<td>'+u_firstName[h]+'<span class="hidden" id="multiShowFirstNameAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].firstNameAttributeId+'</span></td>';
													}


													if(u_lastName[h] != undefined){
														propertiesValue += '<td>'+u_lastName[h]+'<span class="hidden" id="multiShowLastNameAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].lastNameAttributeId+'</span></td>';
													}


													if(u_fullName[h] != undefined){
														propertiesValue += '<td>'+u_fullName[h]+'<span class="hidden" id="multiShowFullNameAttributeId'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].fullNameAttributeId+'</span></td>';
													}


													if(u_email[h] != undefined){
														propertiesValue += '<td>'+u_email[h]+'<span class="hidden" id="multiShowEmailAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].emailAttributeId+'</span></td>';
													}


													if(u_dept[h] != undefined){
														propertiesValue += '<td>'+u_dept[h]+'<span class="hidden" id="multiShowDeptAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].deptAttributeId+'</span></td>';
													}

													propertiesValue += '</tr>';
												}

											});
										}
										propertiesValue += '</table>';
										propertiesValue += '<button class="ui mini button rtfBtnShow" id="viewLDAPUserListMapping_'+json.result[i].assetParamId+'" style="margin-top: 2rem !important;" data-title=""  onclick="viewLDAPUserListModalMapping('+json.result[i].assetParamId+')">Show all values</button>'; //CHANDANA 06-06-2019 (changed div to button for keyboard controls)
										propertiesValue += '</div>';


									}else{

										propertiesValue += '<div  class="ui segment showProperties richTextCustomView " style="min-height:5.2rem !important;">';

										if(json.result[i].ldapmappingdata == null){
											propertiesValue += '<div class="countDisp SingleLdapMapping">0 value</div>';
										}
										else{
											propertiesValue += '<span id="ldapSingleCount_'+json.result[i].assetParamId+'" class="hidden"></span>';
											propertiesValue += '<table class="ui celled table SingleDataTable"><tr>';

											$(json.result[i].ldapmappingdata).each(function(k){

												if(json.result[i].ldapmappingdata[k].userId != null){
													propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].userId+'<span class="hidden" id="singleShowUserAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].userIdAttributeId+'</span></td>';
												}


												if(json.result[i].ldapmappingdata[k].firstName != null){
													propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].firstName+'<span class="hidden" id="singleShowFirstNameAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].firstNameAttributeId+'</span></td>';
												}


												if(json.result[i].ldapmappingdata[k].lastName != null){
													propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].lastName+'<span class="hidden" id="singleShowLastNameAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].lastNameAttributeId+'</span></td>';
												}


												if(json.result[i].ldapmappingdata[k].fullName != null){
													propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].fullName+'<span class="hidden" id="singleShowFullNameAttributeId'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].fullNameAttributeId+'</span></td>';
												}

												if(json.result[i].ldapmappingdata[k].email != null){
													propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].email+'<span class="hidden" id="singleShowEmailAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].emailAttributeId+'</span></td>';
												}
												if(json.result[i].ldapmappingdata[k].dept != null){
													propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].dept+'<span class="hidden" id="singleShowDeptAttributeId_'+json.result[i].assetParamId+'">$'+json.result[i].ldapmappingdata[k].deptAttributeId+'</span></td>';
												}

											});

											propertiesValue += '</tr></table>';

										}

										propertiesValue += '</div>';

									}


									//Edit
									propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" id="ldapUserMappingEditFileds_'+json.result[i].assetParamId+'">';

									propertiesValue += '<div class="ui segment richTextCustomView customPreTag mandetoryFieldValidation" style="min-height:5.2rem!important;color: #606365 !important;padding-left: 1rem !important;">';

									if(json.result[i].singleMultipleFlag == false || json.result[i].singleMultipleFlag == "false"){
										propertiesValue += '<div class="richTextBackendData countDisp" id="ldapUserCountMulti_'+json.result[i].assetParamId+'">'+json.result[i].ldapMappingListCount+' value(s)</div>';
										propertiesValue += '<button class="ui mini button rtfBtnEdit" style="margin-top: 2rem !important;" data-title="" id="editLDAPMappingUserListMulti_'+json.result[i].assetParamId+'" onclick="openEditLDAPMappingUserModal('+json.result[i].assetParamId+')">Edit list</button>'; 	//<!-- CHANDANA 04-06-2019 KEYBOARD CONTROLS -->

										if(json.result[i].ldapmappingdata != ""){
											propertiesValue += '<table class="ui celled table multiDataTable hidden" id = "edit_multiTableTable_'+json.result[i].assetParamId+'">';

											$(json.result[i].ldapmappingdata).each(function(k){

												var u_Id = "", u_email = "", u_firstName = "", u_lastName = "", u_fullName = "", u_dept = "";
												var count = 0;
												if(json.result[i].ldapmappingdata[k].userId != null){
													u_Id = json.result[i].ldapmappingdata[k].userId;
													u_Id = u_Id.split("~~");
													count = u_Id.length;
												}
												else {
													u_Id = "";
												}

												if(json.result[i].ldapmappingdata[k].email != null){
													u_email = json.result[i].ldapmappingdata[k].email;
													u_email = u_email.split("~~");
													count = u_email.length;
												}else {
													u_email = "";
												}

												if(json.result[i].ldapmappingdata[k].firstName != null){
													u_firstName = json.result[i].ldapmappingdata[k].firstName;
													u_firstName = u_firstName.split("~~");
													count = u_firstName.length;
												}else {
													u_firstName = "";
												}

												if(json.result[i].ldapmappingdata[k].lastName != null){
													u_lastName = json.result[i].ldapmappingdata[k].lastName;
													u_lastName = u_lastName.split("~~");
													count = u_lastName.length;
												}else {
													u_lastName = "";
												}

												if(json.result[i].ldapmappingdata[k].dept != null){
													u_dept = json.result[i].ldapmappingdata[k].dept;
													u_dept = u_dept.split("~~");
													count = u_dept.length;
												}else {
													u_dept = "";
												}

												if(json.result[i].ldapmappingdata[k].fullName != null){
													u_fullName = json.result[i].ldapmappingdata[k].fullName;
													u_fullName = u_fullName.split("~~");
													count = u_fullName.length;
												}else {
													u_fullName = "";
												}


												for(var h=0; h<count; h++){

													propertiesValue += '<tr>';
													if(u_Id[h] != undefined){
														propertiesValue += '<td>'+u_Id[h]+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].userIdAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+u_Id[h]+'<span>$'+json.result[i].ldapmappingdata[k].userIdAttributeId+'</span></td>';
													}

													if(u_firstName[h] != undefined){
														propertiesValue += '<td>'+u_firstName[h]+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].firstNameAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+u_firstName[h]+'<span>$'+json.result[i].ldapmappingdata[k].firstNameAttributeId+'</span></td>';
													}

													if(u_lastName[h] != undefined){
														propertiesValue += '<td>'+u_lastName[h]+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].lastNameAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+u_lastName[h]+'<span>$'+json.result[i].ldapmappingdata[k].lastNameAttributeId+'</span></td>';
													}

													if(u_fullName[h] != undefined){
														propertiesValue += '<td>'+u_fullName[h]+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].fullNameAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+u_fullName[h]+'<span>$'+json.result[i].ldapmappingdata[k].fullNameAttributeId+'</span></td>';
													}

													if(u_email[h] != undefined){
														propertiesValue += '<td>'+u_email[h]+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].emailAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+u_email[h]+'<span>$'+json.result[i].ldapmappingdata[k].emailAttributeId+'</span></td>';
													}

													if(u_dept[h] != undefined){
														propertiesValue += '<td>'+u_dept[h]+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].deptAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+u_dept[h]+'<span>$'+json.result[i].ldapmappingdata[k].deptAttributeId+'</span></td>';
													}
													propertiesValue += '</tr>';

												}

												propertiesValue += '</table>';
											});

										}


									}else{

										if(json.result[i].ldapmappingdata == ""){
											propertiesValue += '<div class="countDisp SingleLdapMapping">0 value</div>';
										}
										else{
											propertiesValue += '<span id="ldapSingleCount_'+json.result[i].assetParamId+'" class="hidden"></span>';
											propertiesValue += '<button class="ui mini button rtfBtnEdit" style="margin-top: 1rem !important;" data-title="" id="editLDAPMappingUserList_'+json.result[i].assetParamId+'" onclick="openEditLDAPMappingUserModal('+json.result[i].assetParamId+')">Edit list</button>'; //	<!-- CHANDANA 04-06-2019 KEYBOARD CONTROLS -->

											if(json.result[i].ldapmappingdata != null || json.result[i].ldapmappingdata == ""){
												propertiesValue += '<table class="ui celled table SingleDataTable" id="ldapMappingSingleListData_'+json.result[i].assetParamId+'"><tr id="tr_ldapMappingSingleListData_'+json.result[i].assetParamId+'">';

												$(json.result[i].ldapmappingdata).each(function(k){

													if(json.result[i].ldapmappingdata[k].userId != null){
														propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].userId+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].userIdAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+json.result[i].ldapmappingdata[k].userId+'<span>$'+json.result[i].ldapmappingdata[k].userIdAttributeId+'</span></td>';
													}

													if(json.result[i].ldapmappingdata[k].firstName != null){
														propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].firstName+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].firstNameAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+json.result[i].ldapmappingdata[k].firstName+'<span>$'+json.result[i].ldapmappingdata[k].firstNameAttributeId+'</span></td>';
													}

													if(json.result[i].ldapmappingdata[k].lastName != null){
														propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].lastName+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].lastNameAttributeId+'</span></td>';
													}
													else{
														propertiesValue += '<td class="hidden">'+json.result[i].ldapmappingdata[k].lastName+'<span>$'+json.result[i].ldapmappingdata[k].lastNameAttributeId+'</span></td>';
													}

													if(json.result[i].ldapmappingdata[k].fullName != null){
														propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].fullName+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].fullNameAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+json.result[i].ldapmappingdata[k].fullName+'<span>$'+json.result[i].ldapmappingdata[k].fullNameAttributeId+'</span></td>';
													}

													if(json.result[i].ldapmappingdata[k].email != null){
														propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].email+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].emailAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+json.result[i].ldapmappingdata[k].email+'<span>$'+json.result[i].ldapmappingdata[k].emailAttributeId+'</span></td>';
													}

													if(json.result[i].ldapmappingdata[k].dept != null){
														propertiesValue += '<td>'+json.result[i].ldapmappingdata[k].dept+'<span class="hidden">$'+json.result[i].ldapmappingdata[k].deptAttributeId+'</span></td>';
													}else{
														propertiesValue += '<td class="hidden">'+json.result[i].ldapmappingdata[k].dept+'<span>$'+json.result[i].ldapmappingdata[k].deptAttributeId+'</span></td>';
													}



												});

												propertiesValue += '</tr></table>';

											}else {
												propertiesValue += '<table class="ui celled table SingleDataTable hidden" id="ldapMappingSingleListData_'+json.result[i].assetParamId+'"></tr></table>';
											}

										}


									}

									propertiesValue += '</div></div>';


									propertiesValue += '<br><div class="ui  pointing red basic label errMandetoryField errMandetory_'+json.result[i].assetParamId+'" style="display:none;">Please provide value</div>';
								}
								
								assetParamIdList.push(json.result[i].assetParamId);
								var appendPropertiesData = loadPropertiesData(json.result[i].cat_disp, json.result[i].param_disp, json.result[i].assetParamName, json.result[i].assetParamId, propertiesValue, inputType,json.result[i].description,json.result[i].mandatory);
								$("#parameterTbody_"+json.result[i].cat_disp).append(appendPropertiesData);
								
								//check category wise access for the user
								if(json.result[i].editAccessFlag == false){
									//$("#desc_"+json.result[i].cat_disp+"_"+json.result[i].param_disp).addClass("propertiesAIVNoEditAccess");
									if(textFlag){
										if(json.result[i].hasArray == 0){
											$("#input_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										}else{
											$("#editTextButton_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										}
									}else if(richTextFlag){
										$("#editTextButton_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
									}else if(listFlag){
										$("#customList_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										$("#userList_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
	 									$("#assetList_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
	 									$("#editLDAPUserList_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
	 								}
									else if(ldapFlag){
										$("#editLDAPMappingUserList_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										$("#editLDAPMappingUserListMulti_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
									}
									else if(dateFlag){
										$("#input_"+json.result[i].assetParamId).parent().addClass("propertiesAIVNoEditAccess");
									}else if(fileFlag){
										$("#input_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										$(".uploadBtn_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										
									}/*else{
										$("#input_"+json.result[i].assetParamId).addClass("propertiesAIVNoEditAccess");
									}*/
								}
								
								var descriptionMini = json.result[i].description;
								
								if(descriptionMini != null){
									if(descriptionMini.length > 300){
										descriptionMini = descriptionMini.substring(0,300) + "...";
									 }
								}
								
								$("#param_desc_"+json.result[i].assetParamId).attr("data-html",descriptionMini);
								
								
								$(".parameterInfo").popup();
								$('.upFile').on('change', function(t){
									var parId = $(this).attr('id');
									parId = parId.split('_');
									parId = parId[1];
									$('#hidden_'+parId).val($(this).val());
								});
								
								
								if(textFlag){
									var multiData = [];
									 
									if(json.result[i].isStatic == 1){
										value = json.result[i].staticValue;
										
									}else{
										if(json.result[i].hasArray == 0){
											value = json.result[i].paramValue;
										}else{
											//multiData = json.result[i].textDataList;
											
											if(json.result[i].textDataList != null){
												$.each(json.result[i].textDataList,function(j){
													multiData.push(encodeURIComponent(json.result[i].textDataList[j]));
													
												});
											}
											
										}
									}
									if(value == null ){
										value = "";
										
									}
									
									
									
									if(multiData == null ){
										multiData = [];
										
									}
									
									var tempObj;
									
									if(json.result[i].isStatic == 0){
										if(json.result[i].hasArray == 1){
											tempObj = {
													"asset_category_name": json.result[i].asset_category_name,
											        "assetParamId": json.result[i].assetParamId,
											        "assetParamName": json.result[i].assetParamName,
											        "isStatic": 0,
											        "isArray" : 1,
											        "paramTypeId": 1,
										            "paramValue": null,
											        "text_data" : multiData
											};
										}
									}
									
								$("#hiddenJSON_"+json.result[i].assetParamId).html(JSON.stringify(tempObj));
									
									/*hljs.configure({
										lang : "xml",
										useBR: true
									});
									
									var formatted =  formatXml(value);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);*/
									
									$("#input_"+json.result[i].assetParamId).val(value);
									
								}
								
								if(dateFlag){
									
									$("#input_"+json.result[i].assetParamId).datepicker({
									      changeMonth: true,
									      changeYear: true,
									      showWeek: true,
									      firstDay: 1,
									      dateFormat: "dd/mm/yy",
									      showButtonPanel: true,
									      yearRange: '1900:2999',
									      beforeShow: function(input, inst) {
										        //Swathi-- Handle datepicker position before showing it.
										        // It's not supported by Datepicker itself (for now) so we need to use its internal variables.
										        var calendar = inst.dpDiv;										        
										        setTimeout(function() {
										            calendar.position({
										                my: 'right top',
										                at: 'right bottom',
										                collision: 'none',
										                of: input
										            });
										        }, 1);
										    }
									//end of code
									 });
								}
								
								if(listFlag){
									$("#input_"+json.result[i].assetParamId).dropdown();
									$("#input_"+json.result[i].assetParamId).parent().addClass("editProperties").attr("onclick","getAssetList("+json.result[i].mappedAssetId+","+json.result[i].assetParamId+")");
									$("#desc_"+json.result[i].cat_disp+"_"+json.result[i].param_disp).css("overflow","visible");
									$(".rtfBtnShow").popup({
										inline     : true,
										variation : 'inverted',
										html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on show button to view the values !</spam></div>'
									});
								}
								if(ldapFlag){
									$("#input_"+json.result[i].assetParamId).dropdown();
									$("#input_"+json.result[i].assetParamId).parent().addClass("editProperties").attr("onclick","getAssetList("+json.result[i].mappedAssetId+","+json.result[i].assetParamId+")");
									$("#desc_"+json.result[i].cat_disp+"_"+json.result[i].param_disp).css("overflow","visible");
									$(".rtfBtnShow").popup({
										inline     : true,
										variation : 'inverted',
										html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on show button to view ldap mapping values !</spam></div>'
									});
								}
								
								if(richTextFlag){
									/*$("#rtfBtn"+json.result[i].assetParamId).popup({*/
									$(".rtfBtnShow").popup({
										inline     : true,
										variation : 'inverted',
										html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on show button to view the values !</spam></div>'
									});
									//********Aditya 02.03.18
									/*$(".richTextCustomView").dimmer({
										  on: 'hover'
									});*/
									
									
									
									/*if(json.result[i].isStatic == 0){

										value = json.result[i].paramValue;

									}else{

										value = json.result[i].staticValue;
									}
									
									if(value == null ){
										value = "";

									}*/
									
									var onlyText = "";
									var arrWithTag = [];
									var arrWithoutTag = [];
									
									if(json.result[i].hasArray == 0){
										value = json.result[i].paramValue;
										$("#dataForText_"+json.result[i].assetParamId).html(value);
										onlyText = $("#dataForText_"+json.result[i].assetParamId).text();
										$("#dataForText_"+json.result[i].assetParamId).html("");
										
										
									}else{
										
										if(json.result[i].rTFwithOutTags != null && json.result[i].rTFwithTags != null){
											$.each(json.result[i].rTFwithOutTags,function(s){
												arrWithoutTag.push({
													"textField": encodeURIComponent(json.result[i].rTFwithOutTags[s])
												});
												
											});
											
											$.each(json.result[i].rTFwithTags,function(s){
												arrWithTag.push({
													"textField": encodeURIComponent(json.result[i].rTFwithTags[s])
												});
												
											});
										}
										
										
										
										
										
									}
										
									
									if(value == null ){
										value = "";
										
									}
									
									var tempObj;
									
									if(json.result[i].hasArray == 1){
										tempObj = {
												
												"asset_category_name": json.result[i].asset_category_name,
										        "assetParamId": json.result[i].assetParamId,
										        "assetParamName": json.result[i].assetParamName,
										        "isStatic": 0,
										        "isArray":1,
										        "paramTypeId": 7,
										        "paramValue":null,
										        "rich_text_data": {
										        	"with_tag": arrWithTag,
										        	"without_tag": arrWithoutTag
										        } 
										};
									}else{
										tempObj = {
										        
										        "asset_category_name": json.result[i].asset_category_name,
										        "assetParamId": json.result[i].assetParamId,
										        "assetParamName": json.result[i].assetParamName,
										        "isStatic": 0,
										        "isArray":0,
										        "paramTypeId": 7,
										        "paramValue":null,
										        "rich_text_data": {
										        					"with_tag": encodeURIComponent(value),
										        				    "without_tag": encodeURIComponent(onlyText)
										           				  }
												};
									}
									
									
									
									$("#hiddenJSON_"+json.result[i].assetParamId).html(JSON.stringify(tempObj));
									
									
									
									
									
									
									/*if(value.startsWith("<pre")){
										var formatted = $("#showProperties_"+json.result[i].assetParamId+" pre").text();
										formatted = formatted.trim();
										formatted =	hljs.highlightAuto(formatted);
										 $("#showProperties_"+json.result[i].assetParamId+" pre").html(formatted.value);
									}*/
									
									
									/*var id = "input_"+json.result[i].assetParamId;
									
									var editor = CKEDITOR.instances.id;
									if (editor) {
										editor.destroy(true);
									}
									
									CKEDITOR.replace(id, {
										toolbar : 'Basic',
										height : "10em"
									});
									
									if(json.result[i].isStatic == 0){

										value = json.result[i].paramValue;

									}else{

										value = json.result[i].staticValue;
									}
									
									if(value == null ){
										value = "";

									}
									
									var formatted =  formatXml(value);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);

									//CKEDITOR.instances[id].setData(value);
									$("#"+id).html(formatted.value)*/
								}
								
								
					});
							
							if(custListAssetParamID != ""){
								custListAssetParamID = custListAssetParamID.substr(0, custListAssetParamID.lastIndexOf("~~"));
								getCustomList(custListAssetParamID);
							}
							
							/*if(assetListAssetId != ""){
								assetListAssetId = assetListAssetId.substr(0, assetListAssetId.lastIndexOf("~~"));
								assetListAssetParamID = assetListAssetParamID.substr(0, assetListAssetParamID.lastIndexOf("~~"));
								
								getAssetList(assetListAssetId,assetListAssetParamID)
								
							}*/
							
							

							if(userListAssetParamID != ""){
								var userListArr = [];
								userListAssetParamID = userListAssetParamID.substr(0, userListAssetParamID.lastIndexOf("~~"));
								userListAssetParamID = userListAssetParamID.split("~~");
								multiSelectFlag = multiSelectFlag.split("~~"); //harish
								var userList = getActiveUserList(userListAssetParamID[0]);
								
								$.each(userListAssetParamID, function(i){
									var dropdownData = createListDropdown(userListAssetParamID[i],userList,multiSelectFlag[i]); //harish
									$("#userList_"+userListAssetParamID[i]).html(dropdownData);
									var selectedData = $("#userListSelectValue_"+userListAssetParamID[i]).text().trim();

									if(selectedData == "" || selectedData == null){
										$("#input_"+userListAssetParamID[i]).dropdown();
									}else{
										userListArr.length = 0;
										selectedData = selectedData.split("~~");
										/*alert(jQuery.type(selectedData));*/
										$.each(selectedData,function(i){
											userListArr.push(encodeURIComponent(selectedData[i]));
										});
										/*alert("  user list selectedData"+userListArr);*/
										$("#input_"+userListAssetParamID[i]).dropdown("set selected",userListArr);
									}
									$("#input_"+userListAssetParamID[i]).parent().addClass("editProperties");//.attr("onclick","propertiesEditLock()");
								});
							}
							
							
					}

				}else{
					if(json.message == "DATA_FROM_DB_NOT_FOUND"){
						$("#noAssetPropertiesData").show();
						$("#propertiesAccordion").hide();
						$("#editPropertiesData").hide();
						$("#expandAllAccordion").hide();
					}
				}
				
				
				$(".rtfBtnEdit").popup({
					 inline     : true,
					 variation : 'inverted',
					 html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on edit button to edit the values !</spam></div>'
				 });
				
				checkAccessForUserOnSuccess();
				$(".editProperties").hide();
				$(".showProperties").show();
			}
		});
	 
	 /********commented by Aditya
	  $('.newTextFieldStyle').dimmer({
	    on: 'hover'
	  });*/
	 
	$(".showOrEditButton").popup({
		 inline     : true,
		 variation : 'inverted',
		 html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on show button to view the values !</spam></div>'
	 });
	
	// BOC Hema 08.Mar.2019 Directs to ldap mapping parameter count
	if(localStorage.getItem("ldapMappingCountLink") == "true"){
		var target = localStorage.getItem("ldapMappingHref");

		var id = $(target).parent().parent().parent().attr('id');
		id = id.split('_');
		if(!$('#category_'+id[1]).hasClass('active')){
			$("#category_"+id[1]).addClass('active');
			$("#parameter_"+id[1]).addClass('active');
			$("#category_0, #parameter_0").removeClass('active');
		}
		var splitTarget = target.split("_");
		$('#assetParamId_'+splitTarget[1]).addClass("ldapMappingCountLink_addRemoveColor");
		$('.innerItem').removeClass('active assetInstanceFloatingMenuSelected').children().removeClass("themeTextColor");
		var href = "#assetProperties";
		$("#floatingScrollerMenu").find('a[href="'+href+'"]').addClass('active assetInstanceFloatingMenuSelected').children().addClass("themeTextColor");
		$('html, body').animate({
			scrollTop: ($(target).offset().top-240) //chandana -top value changed from 150 
		}, 500);

		//console.log("properties");

		setTimeout(function(){
			$('#assetParamId_'+splitTarget[1]).removeClass("ldapMappingCountLink_addRemoveColor");
		},2500)

	}
	// EOC
	 		
}

// create Properties Data format
function  createPropertiesDataFormat(assetCategoryName,categoryOrder){
	appendData = "";
	if(categoryOrder == 0){
		appendData += '<div class="title propAccord accordionChange active whitespaceNoTrim" onclick="accordionChange(this)" style="overflow:visible;" id="category_'+categoryOrder+'"><i class="dropdown icon"></i>'+assetCategoryName+'<span style="display:none;" class="metaReadOnlyData readOnlyMeta_'+categoryOrder+'">(Read Only)</span></div>';
		appendData += '<div class="content propAccord active whitespaceNoTrim" style="overflow: visible !important;" id="parameter_'+categoryOrder+'">';
		appendData += '<table class="ui fixed table noBorderTable whitespaceNoTrim">';
		/*appendData += '<thead>';
		appendData += '<tr><th class="two wide hidden">topic</th>';
		appendData += '<th class="hidden">Desc</th></tr>';
		appendData += '</thead>';*/
		appendData += '<tbody id="parameterTbody_'+categoryOrder+'" style="overflow: visible;"></tbody>';
		appendData += '</table>';
		appendData += '</div>';
	}else{
		appendData += '<div class="title propAccord accordionChange whitespaceNoTrim" onclick="accordionChange(this)" style="overflow:visible;" id="category_'+categoryOrder+'"><i class="dropdown icon"></i>'+assetCategoryName+'<span style="display:none;" class="metaReadOnlyData readOnlyMeta_'+categoryOrder+'">(Read Only)</span></div>';
		appendData += '<div class="content propAccord" style="overflow: visible !important;" id="parameter_'+categoryOrder+'">';
		appendData += '<table class="ui fixed table noBorderTable whitespaceNoTrim">';
		/*appendData += '<thead>';
		appendData += '<tr><th class="two wide hidden">topic</th>';
		appendData += '<th class="hidden">Desc</th></tr>';
		appendData += '</thead>';*/
		appendData += '<tbody id="parameterTbody_'+categoryOrder+'" style="overflow: visible;"></tbody>';
		appendData += '</table>';
		appendData += '</div>';
	}
	
	return appendData;
}

//load Properties Data
function loadPropertiesData(categoryOrder,paramOrder,assetParamName,assetParamId,propertiesValue,inputType,description,mandatory){
	
	var descriptionMini = description;
	
	if(descriptionMini != null){
		if(descriptionMini.length > 300){
			descriptionMini = descriptionMini.substring(0,300) + "...";
		 }
	}
	appendData = "";
	appendData += '<tr id="paramTR_'+assetParamId+'" class="'+inputType+'"><td class="four wide" style=" padding-left: 20px !important; "><span  style="font-size: 0.9em !important;" id="assetParamId_'+assetParamId+'">'+assetParamName+ '</span>';
	if(mandatory){
		appendData += '<i class="asterisk tiny red icon" style="vertical-align: top;"></i>';
	}
	appendData += ' <span><i id="param_desc_'+assetParamId+'" style="margin-left:1em;cursor:pointer;color: rgba(0,0,0,0.5);" data-html="" data-variation="wide" data-position="right center" class="info circle icon parameterInfo"></i></td>';
	
	appendData += '<td class="twelve wide"  id="desc_'+categoryOrder+'_'+paramOrder+'" style="overflow:visible;">'+propertiesValue+'</td>';
	//appendData += '<td class="twelve wide mandetoryFieldValidation"  id="desc_'+categoryOrder+'_'+paramOrder+'" style="overflow-x: auto !important;">'+propertiesValue+'</td>';// added by gayathri 
	appendData += '</tr>';
	
	return appendData;
}

//download File 
function downloadFile(isStatic,paramName){
 	//alert("downloadfile")
	$.ajax({
	   	   type: "GET",
	       url: "/repopro/web/assetInstanceVersionManager/downloadfile?assetInstverId="+assetInstanceVersionId+"&staticValue="+isStatic+"&assetName="+encodeURIComponent(assetName)+"&assetParamName="+encodeURIComponent(paramName),
	       dataType: "json",
	       cache:false,
	       complete: function(data){
	    	   var json = JSON.parse(data.responseText);
	    	   if(json.status == "SUCCESS"){
	    		   	var filePath = json.result;	
	    			window.location.href="/repopro/downloadfileservlet?exportedPath="+filePath;
	    			 
	    	   }else {
	    		   notifyMessage("Properties File Download", "Failed to download file.", "fail");
	    	   }
	       }
	}); 
}

//get Active User List
function getActiveUserList(assetParamId){
	var userList = "";
	//url modified by gomathi 08/02/2018
	$.ajax({
		type : "GET",
		url: "/repopro/web/user/allUsers",
		dataType : "json",
		async: false,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);

			$.each(json.result,function(i){
				 userList += json.result[i].userName +"~~";
			});
			
			userList = userList.substr(0, userList.lastIndexOf("~~"));

		}
	});
	return userList;
}

//get Custom List
function getCustomList(assetParamId){
	var customListArr = [];
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetType/getPossibleValues?assetId="+assetId+"&assetParamId="+assetParamId,
		dataType : "json",
		async: false,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			
			$.each(json.result,function(i){
				var dropdownData = createListDropdown(json.result[i].assetParamId,json.result[i].value,json.result[i].multiSelectFlag); //harish
				$("#customList_"+json.result[i].assetParamId).html(dropdownData);
				var selectedData = $("#custListSelectValue_"+json.result[i].assetParamId).text().trim();
				
				if(selectedData == "" || selectedData == null){
					$("#input_"+json.result[i].assetParamId).dropdown();
				}else{
					//var value = json.result[i].paramValue.replace(/ /g,"_")
					if(json.result[i].multiSelectFlag == false || json.result[i].multiSelectFlag == "false") {
						selectedData = selectedData.split("~~");
						$.each(selectedData,function(i){
							customListArr.push(encodeURIComponent(selectedData[i]));
						});
					
		/*			alert(" selectedData "+selectedData);*/
					
					$("#input_"+json.result[i].assetParamId).dropdown("set selected",customListArr);
					}else {
						$("#input_"+json.result[i].assetParamId).dropdown("set selected",encodeURIComponent(selectedData)).dropdown();
					}
				}
				$("#input_"+json.result[i].assetParamId).parent().addClass("editProperties").attr("onclick","propertiesEditLock()");
				
			});

		}
	});
	
}


//get Asset List
/*
function getAssetList(mappedAssetId,assetParamId){
	var list = [];
	url = "/repopro/web/assetInstance/getAllAssetInstanceNamesByAssetId?assetId="+mappedAssetId+"&userName="+loggedInUserName;
	console.log(" getAssetList url "+url);
	
	if($("#input_"+assetParamId).parent().hasClass("callAssetListAPI")){	
		$("#input_"+assetParamId).parent().addClass("loading");
		$.ajax({
				type : "GET",
				url: "/repopro/web/assetInstance/getAllAssetInstanceNamesByAssetId?assetId="+mappedAssetId+"&userName="+loggedInUserName,
				dataType : "json",
				async: true,
				cache:false,
				complete : function(data) {
					var json = JSON.parse(data.responseText);
					
					if(json.status == "SUCCESS"){
						$.each(json.result, function(i){
							list.push(json.result[i]);
						});
						console.log("list "+list);
						appendData = "";
						appendData += '<option value="">Select</option>';
						appendData += '<option value="-1">Select</option>';
						console.log(" listArr "+listArr);
						
						$.each(list , function(index, val) { 
							  if ($.inArray(val, listArr) == -1){
								  		console.log(val);
										appendData += '<option value="'+encodeURIComponent(val)+'">'+val+'</option>';
								}
						});
						
						
						$("#input_"+assetParamId).html(appendData);
						
						
						$("#input_"+assetParamId).dropdown();
						
						
					}
					$("#input_"+assetParamId).parent().removeClass("loading");
		
				}
			});
		
		$("#input_"+assetParamId).parent().removeClass("callAssetListAPI")
	}
	
	
}*/
//get Asset List
function getAssetList(mappedAssetId,assetParamId){
	 //url modified by gomathi 08/02/2018
	if($("#input_"+assetParamId).parent().hasClass("callAssetListAPI")){	
		$("#input_"+assetParamId).parent().addClass("loading");
		$.ajax({
				type : "GET",
				 url: "/repopro/web/assetInstance/getAllAssetInstanceNamesByAssetId?assetId="+mappedAssetId+"&userName="+loggedInUserName,
				 
				dataType : "json",
				async: true,
				cache:false,
				complete : function(data) {
					var json = JSON.parse(data.responseText);
					var assetArrayList = [];
					
					if(json.status == "SUCCESS"){
						appendData = "";
						/*appendData += '<option value="">Select</option>';*/
						/*appendData += '<option value="-1">Select</option>';*/
						$('#input_'+assetParamId+'> option').each(function(e){
							if($(this).val() != ""){
								assetArrayList.push($(this).val());
							}
							
						 });
						//console.log(assetArrayList);
						$.each(json.result, function(i){
							if ($.inArray(encodeURIComponent(json.result[i]), assetArrayList) == -1){
								//console.log(json.result[i]);
								appendData += '<option value="'+encodeURIComponent(json.result[i])+'">'+json.result[i]+'</option>';
							}
						});
					/*	$.each(json.result,function(i){
							appendData += '<option value="'+encodeURIComponent(json.result[i])+'">'+json.result[i]+'</option>';
						});*/
						$("#input_"+assetParamId).append(appendData);
						
						
						$("#input_"+assetParamId).parent().dropdown();
						
						
					}
					$("#input_"+assetParamId).parent().removeClass("loading");
		
				}
			});
		
		$("#input_"+assetParamId).parent().removeClass("callAssetListAPI")
	}
	
	
}

//create  List Dropdown
function createListDropdown(assetParamId,value,flag){//harish

	if(value == "" || value == null){
		appendData = "";
		appendData += '<select  class="ui search selection dropdown propertiesLockedByOther propDropdownWidth" id="input_'+assetParamId+'">';
		appendData += '<option value="">Select</option>';
		appendData += '</select>';
	}else{
		
		var options = value.split("~~");
		appendData = "";
		//harish
		if(flag == false || flag == "false"){
			appendData += '<select  class="ui search selection dropdown propertiesLockedByOther propDropdownWidth" multiple="" id="input_'+assetParamId+'" style="z-index:7 !important">';
			appendData += '<option value="">Select</option>';
		}else{
			appendData += '<select  class="ui search  dropdown propertiesLockedByOther propDropdownWidth" id="input_'+assetParamId+'" style="z-index:7 !important">';
			appendData += '<option value="">Select</option>';
			appendData += '<option value="-1">Select</option>';
		}
		$.each(options, function(i) {
			appendData += '<option value="'+encodeURIComponent(options[i])+'" >'+options[i]+'</option>';
		});
		appendData += '</select>';
	}
	return appendData;	
}



var richTextFieldFlag = false, arrayData=[];
//save Properties Data
//$("#fileForm").submit(function(){
function savePropertiesData(){
	
	$(".editProperties").removeClass("error").removeClass("dataErrorStyle");
	$(".errMandetoryField").hide();
	$(".mandetoryFieldValidation").removeClass("error").removeClass("dataErrorStyle"); 
	var assetInstVerionId = parseInt(assetInstanceVersionId);
	var obj = {
			"assetInstanceVersionId" : assetInstVerionId,
			"userId" : loggedInUserId,
			"activeFlag" : loggedInUserActiveFlag,
			"assetName" : assetName,
			"userName" : loggedInUserName
		};
	
	var inMandatoryFlag = true;
 	$("#hiddenQueryParamValue").val(JSON.stringify(obj));
 	var obj = [];
	var formData = new FormData();
	$.each(assetCategoryList,function(i){
		var arr = assetCategoryList[i].split("~~");
		var categoryName = arr[0];
		var categoryId = arr[1];
		var fileName,oldFileName,newFileName; 
		var multiDataValue = "";
		
		$("#parameter_"+categoryId+" > table > tbody > tr").each(function(){
			
				if(!$(this).hasClass("derivedAttribute") || !$(this).hasClass("derivedComputation")){
					var item = $(this).attr("id");
					var inputType = $(this).attr("class");
					var arr = item.split("_");
					var paramId = arr[1];
					paramId = parseInt(paramId); 
					var paramName = $("#assetParamId_"+paramId).text().replace(":","");
					var isStatic = $("#isStatic_"+paramId).text();
					isStatic = parseInt(isStatic);
					var hasArray = $("#hasArray_"+paramId).text();
					hasArray = parseInt(hasArray);
					
					var isMandatory = $("#isMandatory_"+paramId).text();
					var isEditable = $("#isEditable_"+paramId).text();
					var isMultiple = $("#isMultiple_"+paramId).text();
					var listTypeId = $("#listType_"+paramId).text();
					var paramMappingValue = "";
//					
					/*if(inputType == "text"){
						var paramValue = $("#input_"+paramId).text();
					}else*/
						
					/*   errMandetoryField errMandetory_     */
					
					if(inputType == "richText"){
						var paramValue = $("#input_"+paramId).html();
						//console.log(paramValue)
					}
//					if(inputType == "ldapMapping"){
//					//	var paramValue = $("#hiddenJSON_"+paramId).html();
//						Single_userID = $("#getSingleid").html();
//						Single_userFName = $("#getSingleFname").html()
//						Single_userLName	=$("#getSingleLname").html()
//						Single_userFullName = $("#getSingleFullname").html()
//						Single_userDept = $("#getSingleDept").html()
//						Single_userEmail =	$("#getSingleEmail").html()
////						//alert(LuserID + LuserFName + LuserLName+ LuserFullName + LuserDept + LuserEmail);
////						 
////						//paramMappingValue = $("#hiddenJSON_"+paramId).html();
////						paramMappingValue = LuserID;
////						var trr = paramMappingValue.split(",");
////						var mapid = trr[0];
////						//alert("ldap mapping paramMappingValue : " + JSON.stringify(paramMappingValue));
//					}
					if(inputType == "list"){
						if(listTypeId == 4){
							var paramValue = $("#hiddenJSON_"+paramId).html();
							//alert("values" + paramValue);
						}else{
							var paramValue = $("#input_"+paramId).val();
							if(paramValue == "-1"){
								paramValue = "";
							}
						}
					}else{
						var paramValue = $("#input_"+paramId).val();
						if(paramValue == "-1"){
							paramValue = "";
						}
					}
					
					
					
					//*************souradip 27/02/18 ******validation mandetory fields
					
						if(isEditable == "true"){ 
							if(isMandatory == "true"){
								//alert("should not enter");
									if(inputType == "file"){
										var fileName = $("#fileName_"+paramId).text();
										if(fileName == "" || fileName == null){
											$("#input_"+paramId).parent().addClass("error");
											$(".errMandetory_"+paramId).show();
											inMandatoryFlag = false;
											
											if($("#category_"+categoryId).hasClass("active") == false){
												$("#category_"+categoryId).addClass("active");
												$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
												
											}
										}
									}else if(inputType == "date"){
										if(paramValue.trim() == ""){
											$("#input_"+paramId).addClass("dataErrorStyle");
											$(".errMandetory_"+paramId).show();
											inMandatoryFlag = false;
											
											if($("#category_"+categoryId).hasClass("active") == false){
												$("#category_"+categoryId).addClass("active");
												$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
												
											}
										}
										
										
									}else if(inputType == "richText"){
										var getJsonData = $("#hiddenJSON_"+paramId).text();
										getJsonData = JSON.parse(getJsonData);
										
										if(hasArray == 1){
											
											if(getJsonData.rich_text_data.with_tag.length == 0 ){
												$("#editTextButton_"+paramId).parent().addClass("dataErrorStyle");
												$(".errMandetory_"+paramId).show();
												inMandatoryFlag = false;
												
												if($("#category_"+categoryId).hasClass("active") == false){
													$("#category_"+categoryId).addClass("active");
													$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
													
												}
											}
											
										}else{
											
											
											if(getJsonData.rich_text_data.with_tag == ""){
												$("#editTextButton_"+paramId).parent().addClass("dataErrorStyle");
												$(".errMandetory_"+paramId).show();
												inMandatoryFlag = false;
												
												if($("#category_"+categoryId).hasClass("active") == false){
													$("#category_"+categoryId).addClass("active");
													$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
													
												}
											}
											
											
										}
										
										
									}else if(inputType == "text"){
										if(isStatic == 1){
											if(paramValue.trim() == ""){
												$("#input_"+paramId).addClass("dataErrorStyle");
												$(".errMandetory_"+paramId).show();
												inMandatoryFlag = false;
												
												if($("#category_"+categoryId).hasClass("active") == false){
													$("#category_"+categoryId).addClass("active");
													$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
													
												}
											}
										}else{
											if(hasArray == 1){
												
												var getJsonData = $("#hiddenJSON_"+paramId).text();
												getJsonData = JSON.parse(getJsonData);
												if(getJsonData.text_data.length == 0 ){
													$("#editTextButton_"+paramId).parent().addClass("dataErrorStyle");
													$(".errMandetory_"+paramId).show();
													inMandatoryFlag = false;
													
													if($("#category_"+categoryId).hasClass("active") == false){
														$("#category_"+categoryId).addClass("active");
														$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
														
													}
												}
												
											}else{
												if(paramValue.trim() == ""){
													
													$("#input_"+paramId).addClass("dataErrorStyle");
													$(".errMandetory_"+paramId).show();
													inMandatoryFlag = false;
													
													if($("#category_"+categoryId).hasClass("active") == false){
														$("#category_"+categoryId).addClass("active");
														$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
														
													}
												}
												
												
											}
										}
										
										
									}else if(inputType == "list"){	
										if(listTypeId == 4){
											
											if(paramValue.trim() == ""){
												$("#ldapUserEditFileds_"+paramId).children().addClass("dataErrorStyle");
												$(".errMandetory_"+paramId).show();
												inMandatoryFlag = false;
												
												if($("#category_"+categoryId).hasClass("active") == false){
													$("#category_"+categoryId).addClass("active");
													$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
													
												}
											}
										}else{
											if(paramValue != null){
												if(paramValue.length == 0){
													$("#input_"+paramId).parent().addClass("error");
													$(".errMandetory_"+paramId).show();
													inMandatoryFlag = false;
													
													if($("#category_"+categoryId).hasClass("active") == false){
														$("#category_"+categoryId).addClass("active");
														$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
														
													}
												}
											}else{
												$("#input_"+paramId).parent().addClass("error");
												$(".errMandetory_"+paramId).show();
												inMandatoryFlag = false;
												
												if($("#category_"+categoryId).hasClass("active") == false){
													$("#category_"+categoryId).addClass("active");
													$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
													
												}
											}
										}
										
										
									}
									//-------Chandana--------- //
									else if(inputType == "ldapMapping"){	
								
										if(isMultiple == true || isMultiple == "true"){
											var SingleMandate = $('#ldapMappingSingleListData_'+paramId).find("td").length;
										
											var SingleMandateRow = $(this).find('td:empty').length;
											
												if(SingleMandate == 0){
													$("#input_"+paramId).parent().addClass("error");
													$(".errMandetory_"+paramId).show();
													inMandatoryFlag = false;
												
												}
											else{
												$("#input_"+paramId).parent().removeClass("error");
												$(".errMandetory_"+paramId).hide();
												inMandatoryFlag = true;
										
											}
										}
										
										
										if(isMultiple == false || isMultiple == "false"){
											var MultiMandate = $('#edit_multiTableTable_'+paramId).find("tr").length; 
											var tablerow = $(this).find('td:empty').length;

											
											if(MultiMandate != null){
												if(MultiMandate == 0){
											
													$("#input_"+paramId).parent().addClass("error");
													$(".errMandetory_"+paramId).show();
													inMandatoryFlag = false;
												
												}
											}else{
												$("#input_"+paramId).parent().removeClass("error");
												$(".errMandetory_"+paramId).hide();
												inMandatoryFlag = true;
										
											}
										}
									}
									
									
									else{
										if(paramValue.trim() == ""){
											$("#input_"+paramId).parent().addClass("error");
											$(".errMandetory_"+paramId).show();
											inMandatoryFlag = false;
											
											if($("#category_"+categoryId).hasClass("active") == false){
												$("#category_"+categoryId).addClass("active");
												$("#parameter_"+categoryId).addClass("active").children().addClass("visible").removeClass("hidden");
												
											}
										}
									}
								}
							
							
					//***********ends 27/02/18
					
					
					
					
					if(inputType == "text"){
						inputType = 1;
					}else if(inputType == "date"){
						inputType = 2;
					}else if(inputType == "file"){
						inputType = 3;
						newFileName = "";
						fileName = $("#input_"+paramId).get(0).files[0];
						//alert(fileName.name)
						if(typeof fileName == "undefined"){      
							fileName = null;     
						}  
						if(fileName != null ){
							newFileName = fileName.name;
						}
						
							//formData.append(paramName,fileName);
						oldFileName = $("#oldFileName_"+paramId).text();
					}else if(inputType == "list"){
						inputType = 4;
						//console.log("paramValue"+paramValue)
						if(paramValue == -1 || paramValue == null){
							paramValue = "";
							
						}
					}
					else if(inputType == "derivedAttribute"){
						inputType = 5;
					}else if(inputType == "derivedComputation"){
						inputType = 6;
					}else if(inputType == "richText"){
						inputType = 7;
					}
					else if(inputType == "ldapMapping"){
						inputType = 9;
					}
				
					
					if(inputType == 3){
						obj.push({
							 "asset_category_name": categoryName,
							 "assetParamId": paramId,
							 "assetParamName": paramName,
							 "isStatic": isStatic,
							 "paramTypeId": inputType,
							 "fileName": oldFileName,
							 "newFileName" : newFileName
							
						});
					}else if(inputType == 5 || inputType == 6){
						obj.push({
							 "asset_category_name": categoryName,
							 "assetParamId": paramId,
							 "assetParamName": paramName,
							 "isStatic": isStatic,
							 "paramTypeId": inputType,
							 "paramValue": null
						});
						
					}else if(inputType == 4){
						if(listTypeId == 4){
							obj.push({
								 "asset_category_name": categoryName,
								 "assetParamId": paramId,
								 "assetParamName": paramName,
								 "isStatic": isStatic,
								 "paramTypeId": inputType,
								 "paramValue": paramValue
							});
							
						}else{
							 var multiArray = "";
							 //harish
							 if(isMultiple == false || isMultiple == "false" ){
							$.each(paramValue,function(i){
							       multiArray = multiArray + paramValue[i] + "~~";
							       
							   });
							   multiArray = multiArray.substring(0, multiArray.length-2);
							 }
							 if(isMultiple == true || isMultiple == "true" ){
								 multiArray = paramValue;
							 }
							   //console.log("  multiArray "+multiArray);
							obj.push({
								 "asset_category_name": categoryName,
								 "assetParamId": paramId,
								 "assetParamName": paramName,
								 "isStatic": isStatic,
								 "paramTypeId": inputType,
								 "paramValue": multiArray
							});
						}
						
					}
					
					else if(inputType == 2){
						obj.push({
                            "asset_category_name": categoryName,
                            "assetParamId": paramId,
                            "assetParamName": paramName,
                            "isStatic": isStatic,
                            "paramTypeId": inputType,
                            "paramValue": paramValue
                       });
					}
					
					//================Hema 25.Mar.2019 ======================
					else if(inputType == 9){
						// SINGLE SELECT
						if(isMultiple == true || isMultiple == "true"){
							var singleSelectArray = []; 
							var userId = "", firstName = "", lastName = "", fullName = "", emailId = "", dept = "", split_UserId = "", userAttributeId = "", 
							split_firstName = "", firstNameAttributeId = "", split_lastName = "", lastNameAttributeId = "", split_fullName = "", fullNameAttributeId = "", 
							split_emailId = "", emailIdAttributeId = "", split_dept = "", deptAttributeId = "", singleSelectKeyValueObj = {};
							
							var singleSelectTableRowCount = $('#ldapMappingSingleListData_'+paramId).find("tr").length; 
							if(singleSelectTableRowCount > 0){
							$('#ldapMappingSingleListData_'+paramId).find('tr').each(function(index, tr) {
								
								// user Id
								userId = "", split_UserId="", userAttributeId = "";
								userId = $(tr).find('td:eq(0)').text();
								split_UserId = userId.split("$");
								userId = split_UserId[0];
								userAttributeId = split_UserId[1];
								
								
								// first name
								firstName = "", split_firstName = "", firstNameAttributeId = "";
								firstName = $(tr).find('td:eq(1)').text();
								split_firstName = firstName.split("$");
								firstName = split_firstName[0];
								firstNameAttributeId = split_firstName[1];
								
								
								// last name
								lastName = "", split_lastName = "", lastNameAttributeId = "";
								lastName = $(tr).find('td:eq(2)').text();
								split_lastName = lastName.split("$");
								lastName = split_lastName[0];
								lastNameAttributeId = split_lastName[1];
								
								// full name
								fullName = "", split_fullName = "", fullNameAttributeId = "";
								fullName = $(tr).find('td:eq(3)').text();
								split_fullName = fullName.split("$");
								fullName = split_fullName[0];
								fullNameAttributeId = split_fullName[1];
								
								emailId = "", split_emailId = "", emailIdAttributeId ="";
								emailId = $(tr).find('td:eq(4)').text();
								split_emailId = emailId.split("$");
								emailId = split_emailId[0];
								emailIdAttributeId = split_emailId[1];
								
								dept = "", split_dept = "", deptAttributeId = "";
								dept = $(tr).find('td:eq(5)').text();
								split_dept = dept.split("$");
								dept = split_dept[0];
								deptAttributeId = split_dept[1];
								
								singleSelectKeyValueObj = {};
								if(parseInt(userAttributeId) != 0){
									singleSelectKeyValueObj[userId] = parseInt(userAttributeId);
								}
								
								if(parseInt(firstNameAttributeId) != 0){
									singleSelectKeyValueObj[firstName] = parseInt(firstNameAttributeId);
								}
								
								if(parseInt(lastNameAttributeId) != 0){
									singleSelectKeyValueObj[lastName] = parseInt(lastNameAttributeId);
								}
								
								if(parseInt(fullNameAttributeId) != 0){
									singleSelectKeyValueObj[fullName] = parseInt(fullNameAttributeId);
								}
								
								if(parseInt(emailIdAttributeId) != 0){
									singleSelectKeyValueObj[emailId] = parseInt(emailIdAttributeId);
								}
								
								if(parseInt(deptAttributeId) != 0){
									singleSelectKeyValueObj[dept] = parseInt(deptAttributeId);
								}
								
							});
							 
						}
							obj.push({
	                            "asset_category_name": categoryName,
	                            "assetParamId": paramId,
	                            "assetParamName": paramName,
	                            "isStatic": isStatic,
	                            "paramTypeId": inputType,
	                            "paramValue": singleSelectKeyValueObj
	                       });
							
							
						}else {
							var split_userId = "", split_firstName = "", split_lastName = "", split_FullName = "" , split_EmailId = "", split_Dept = "";
							var userIdArray = [], firstNameArray = [], lastNameArray = [], fullNameArray = [], emailIdArray = [], deptArray = [];
							var collectUserIds = "", collectFirstNames = "", collectLastNames = "", collectFullNames = "", collectEmailIds = "", collectDepts = "";
							var userAttId = "", firstNameAttrId = "", lastNameAttrId = "", fullNameAttrId = "", emailAttrId = "", deptAttrId = "";
							var multiSelectKeyValueObj = {};
						
							var multiSelectTableRowCount = $('#edit_multiTableTable_'+paramId).find("tr").length; 
							if(multiSelectTableRowCount > 0){
							$('#edit_multiTableTable_'+paramId).find('tr').each(function(index, tr) {
								
								//user id
								var multiUserId = $(tr).find('td:eq(0)').text();
								split_userId = multiUserId.split("$");
								userIdArray.push(split_userId[0]);
								userAttId = split_userId[1];
								
								// first Name 
								var multiFirstName = $(tr).find('td:eq(1)').text();
								split_firstName = multiFirstName.split("$");
								firstNameArray.push(split_firstName[0]);
								firstNameAttrId = split_firstName[1];
								
								// last Name 
								var multiLastName = $(tr).find('td:eq(2)').text();
								split_lastName = multiLastName.split("$");
								lastNameArray.push(split_lastName[0]);
								lastNameAttrId = split_lastName[1];
								
								// full Name 
								var multiFullName = $(tr).find('td:eq(3)').text();
								split_FullName = multiFullName.split("$");
								fullNameArray.push(split_FullName[0]);
								fullNameAttrId = split_FullName[1];
								
								// email id 
								var multiEmail = $(tr).find('td:eq(4)').text();
								split_EmailId = multiEmail.split("$");
								emailIdArray.push(split_EmailId[0]);
								emailAttrId = split_EmailId[1];
								
								// dept  
								var multiDept = $(tr).find('td:eq(5)').text();
								split_Dept = multiDept.split("$");
								deptArray.push(split_Dept[0]);
								deptAttrId = split_Dept[1];
								});
							
							
							// loop user Id and separate by ~~
							if(parseInt(userAttId) != 0){
							$.each(userIdArray,function(p){
								collectUserIds = collectUserIds + userIdArray[p] + "~~";
							});
							collectUserIds = collectUserIds.substring(0, collectUserIds.length-2);
							multiSelectKeyValueObj[collectUserIds] = parseInt(userAttId);
							}
								
							// loop first name and separate by ~~
							if(parseInt(firstNameAttrId) != 0){
							$.each(firstNameArray,function(p){
								collectFirstNames = collectFirstNames + firstNameArray[p] + "~~";
							});
							collectFirstNames = collectFirstNames.substring(0, collectFirstNames.length-2);
							multiSelectKeyValueObj[collectFirstNames] = parseInt(firstNameAttrId);
							}
							
							// loop last name and separate by ~~
							if(parseInt(lastNameAttrId) != 0){
							$.each(lastNameArray,function(p){
								collectLastNames = collectLastNames + lastNameArray[p] + "~~";
							});
							collectLastNames = collectLastNames.substring(0, collectLastNames.length-2);
							multiSelectKeyValueObj[collectLastNames] = parseInt(lastNameAttrId);
							}
							
							// loop full name and separate by ~~
							if(parseInt(fullNameAttrId) != 0){
							$.each(fullNameArray,function(p){
								collectFullNames = collectFullNames + fullNameArray[p] + "~~";
							});
							collectFullNames = collectFullNames.substring(0, collectFullNames.length-2);
							multiSelectKeyValueObj[collectFullNames] = parseInt(fullNameAttrId);
							}
							
							// loop email ids and separate by ~~
							if(parseInt(emailAttrId) != 0){
							$.each(emailIdArray,function(p){
								collectEmailIds = collectEmailIds + emailIdArray[p] + "~~";
							});
							collectEmailIds = collectEmailIds.substring(0, collectEmailIds.length-2);
							multiSelectKeyValueObj[collectEmailIds] = parseInt(emailAttrId);
							}
							
							// loop depts and separate by ~~
							if(parseInt(deptAttrId) != 0){
							$.each(deptArray,function(p){
								collectDepts = collectDepts + deptArray[p] + "~~";
							});
							collectDepts = collectDepts.substring(0, collectDepts.length-2);
							multiSelectKeyValueObj[collectDepts] = parseInt(deptAttrId);
							}
							
						}
							
							obj.push({
	                            "asset_category_name": categoryName,
	                            "assetParamId": paramId,
	                            "assetParamName": paramName,
	                            "isStatic": isStatic,
	                            "paramTypeId": inputType,
	                            "paramValue": multiSelectKeyValueObj
	                       });
						}
						
						
					}
					
					//================Aditya start=======================
					else if(inputType == 7){
						
						var getJsonData = $("#hiddenJSON_"+paramId).text();
						//console.log(JSON.parse(getJsonData))
						obj.push(JSON.parse(getJsonData));
						
						
					}else if(inputType == 1){
						if(isStatic == 0){
							
							if(hasArray == 0){
								//console.log("Normal:      "+ paramValue)
								//console.log( "encode:        "+encodeURIComponent(paramValue))
								//console.log("encode-decode:     "+ decodeURIComponent(encodeURIComponent(paramValue)))
								obj.push({
							        "asset_category_name": categoryName,
							        "assetParamId": paramId,
							        "assetParamName": paramName,
							        "isStatic": 0,
							        "isArray":0,
							        "paramTypeId": 1,
							        "paramValue": encodeURIComponent(paramValue),
							        "text_data" : null
								});
								
							}else{
								var getJsonData = $("#hiddenJSON_"+paramId).text();
								//console.log(JSON.parse(getJsonData))
								obj.push(JSON.parse(getJsonData));
							}
							
						}else{
							obj.push({
						        "asset_category_name": categoryName,
						        "assetParamId": paramId,
						        "assetParamName": paramName,
						        "isStatic": 1,
						        "paramTypeId": 1,
						        "paramValue": encodeURIComponent(paramValue),
						        "text_data" : null
							});
						}
					}
					else if(editButtonClickedFlag == false){
						//alert("==========1 -----");
						//console.log("1 --- paramTypeId : "+inputType);
						obj.push({
							 "asset_category_name": categoryName,
							 "assetParamId": paramId,
							 "assetParamName": paramName,
							 "isStatic": isStatic,
							 "paramTypeId": 1,
							 "paramValue":"",
							 "text_data":getPropertiesTextData
						});
						//console.log("all the obj :: "+JSON.stringify(obj));
					}
				
					
				
					
					
					//================Aditya over ======================
					else {
						//console.log("3 --- paramTypeId : "+inputType);
						if(inputType != 1 && inputType != 7){
							obj.push({
								 "asset_category_name": categoryName,
								 "assetParamId": paramId,
								 "assetParamName": paramName,
								 "isStatic": isStatic,
								 "paramTypeId": inputType,
								 "paramValue": encodeURIComponent(paramValue)
							});
						}
					}
					
					
				  }	
				}
				
			
		});
		
	});
	
	
	/*var finalObj ={
		"aivList": obj.slice()
	};*/
	var finalObj = obj.slice();
	
	arrayData = obj;
	
	if(inMandatoryFlag == false){
		notifyMessage("Edit Properties", "Please enter mandatory fields.", "fail")
		return inMandatoryFlag;
		return false;
	}
	
	$("#hiddenFormDataValue").val(JSON.stringify(finalObj));
	formData.append("updateAssetInstProperties",JSON.stringify(obj));
	
	/*if(editAIVPageFlag == "false"){
		assetCategoryList.length = 0;
		$("#finalSubmitButton").click();
	}*/
	 
}	
//});	
	
/*****in html page****/

/*//get properties update data
$('iframe#responseDataForProperties').load(function() {
	//if(richTextFieldFlag != true){
		var json = JSON.parse($("#responseDataForProperties").contents().find("pre").html());
		var msg = json.message;
		msg = msg.replace(/_/g, ' ');
		//console.log(JSON.stringify(json)+" == JSON :: msg == :: "+msg);
		   if(json.status == "SUCCESS"){
			   notifyMessage("Edit Properties","Properties updated","success");
			   var currentTime = getDateTime();
			   $("#showAssetOverViewUpdatedOn").html(currentTime);
			  //getPropertiesData();
			
			   getRevisionHistory();
			   if($("#lockUnlockAssetInstance").hasClass("lock")){
					//$("#lockStatusMessage").html("");
					setTimeout(function(){
						unlockInstance();
					},1500);
				}
		   }
		   else{
			   notifyMessage("Edit Properties",msg,"fail");
		     // getPropertiesData();
		      
		   }
		  
		   propertiesXMLDataValidations();
		   $("#responseDataForProperties html body pre").html("");
		   $("#propSubBtn").show();
		   $("#propSubBtnLoading").hide();
		   $("#fileForm").removeClass("loading");
		   
		   $(".showProperties.newTextFieldStyle").addClass("showDimmerButtonStyle");
		   $(".showProperties.newTextFieldStyle").removeClass("editDimmerButtonStyle");
		   //$(".showOrEditButton").text("Show Text");
			
			closePropertiesEditing();
			
			//alert("Closed..");
});*/


	/*var json = JSON.parse($("#responseDataForProperties").contents().find("pre").html());
	var msg = json.message;
	msg = msg.replace(/_/g, ' ');
	   if(json.status == "SUCCESS"){
		   notifyMessage("Edit Properties","Properties updated","success");
		   var currentTime = getDateTime();
		   $("#showAssetOverViewUpdatedOn").html(currentTime);
		  //getPropertiesData();
		
		   getRevisionHistory();
		   if($("#lockUnlockAssetInstance").hasClass("lock")){
				//$("#lockStatusMessage").html("");
				setTimeout(function(){
					unlockInstance();
				},1500);
			}
	   }
	   else{
		   notifyMessage("Edit Properties",msg,"fail");
	     // getPropertiesData();
	      
	   }
	  
	   propertiesXMLDataValidations();
	   $("#responseDataForProperties html body pre").html("");
	   $("#propSubBtn").show();
	   $("#propSubBtnLoading").hide();
	   $("#fileForm").removeClass("loading");
		closePropertiesEditing();
});*/

//get data for versions table
function getAssetInstanceVersions(){
	var url = "/repopro/web/assetInstanceVersionManager/getAssetInstanceVersions/"+assetInstanceId+"?userName="+loggedInUserName;
	//console.log("url "+url)
	$.ajax({
		type : "GET",
		url : url,
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			
			setTimeout(function(){ 
				$("#assetInstancesVersionSegment").removeClass("loading");
			}, 50);
			var json = JSON.parse(data.responseText);
			//console.log(JSON.stringify(json))
			if(json.status == "SUCCESS"){
				
				if(json.result == "" || json.result == null){
					$("#noAssetInstancesVersionData").show();
					$("#assetInstancesVersionTable").hide();
				}
				else {
					$("#noAssetInstancesVersionData").hide();
					$("#assetInstancesVersionTable").show();
					versionList = [];
					apenDdData = "";	
					var versionData = "";
					$.each(json.result, function(i) {
						if(json.result[i].viewAccessFlag){
							versionList.push(json.result[i].versionName);
						}
						if(loggedInUserName == "roleAnonymous"){
							$("#compareVersionTh").remove();
						}
						if(json.result[i].assetInstVersionId != assetInstanceVersionId){
							//alert(json.result[i].versionName)
							var encodedAssetInstName= encodeURIComponent(assetInstanceName);
							encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
							
							apenDdData += '<div class="item" data-text="'+json.result[i].versionName+'" onclick="getAssetInstances('+json.result[i].assetInstVersionId+',\''+encodedAssetInstName+'\')">'+json.result[i].versionName+'</div>';
						}
						versionData += loadAssetInstanceVersions(json.result[i].versionName , json.result[i].versionNotes, json.result[i].assetInstVersionId,json.result[i].editAccessFlag ,json.result[i].deleteAccessFlag,json.result[i].viewAccessFlag);
					});
					$("#assetInstancesVersionTable table tbody").html(versionData);
					
					if(loggedInUserName == "roleAnonymous"){
						$(".guestUserAccess").remove();
					}
					//console.log("  apenDdData "+apenDdData);
					//$("#versionDropdown").append(apenDdData);
					
					/*var assetInstanceVersionArr = [];
					$.each(json.result, function(i) {
						appendData = "";
						
						assetInstanceVersionArr.push(json.result[i].assetInstVersionId);
						$(".versionDropdown").show();
						if(json.result[i].assetInstVersionId == assetInstanceVersionId){
							$("#selectedVersionId").val('');
							$("#selectedVersionId").html(json.result[i].versionName);
							//appendData = "<div class='ui label' style='margin-left: 0.75em;'><span><b>"+json.result[i].versionName +"<b></span></div>";
						}else{
							var encodedAssetInstName= encodeURIComponent(assetInstanceName);
							encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
							appendData += '<div class="ui label" style="margin-left: 0.75em;"><a  onclick="getAssetInstances('+json.result[i].assetInstVersionId+',\''+encodedAssetInstName+'\')">'+json.result[i].versionName +'</a></div>';
						}
						
												
					});
					
					$("#versionList").html(appendData);
					if(assetInstanceVersionArr.length == "1"){
						$(".versionDropdown").hide();
					}*/
				} 
			}
			else{
				$("#noAssetInstancesVersionData").show();
				$("#assetInstancesVersionTable").hide();
			}
			checkAccessForUserOnSuccess();
		}
	});
}


//load data for versions table
function loadAssetInstanceVersions(versionName,versionNotes,assetInstVersionId,editAccess,deleteAccess,viewAccess){
	/*console.log("versionName: "+versionName);
	console.log("viewAccess: "+viewAccess);
	console.log("editAccess: "+editAccess);
	console.log("deleteAccess: "+deleteAccess);*/
	var encodedAssetInstName= encodeURIComponent(assetInstanceName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	
	
	appendData = "";
	if(viewAccess){
		var data = "<p id='delVersion'>Are you sure you want to delete "+versionName+" ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteVersionPopup("+assetInstVersionId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteVersion("+assetInstVersionId+")'>Yes</button> ";
		appendData += '<tr class="versionTR" id="trAccessVarsion_'+assetInstVersionId+'">';
		if(assetInstVersionId == assetInstanceVersionId){
			appendData += '<td class="two wide"><span id="versionName_'+assetInstVersionId+'">'+versionName+'</span></td>';
		}else{
			appendData += '<td class="two wide"><a style="cursor:pointer;" onclick="getAssetInstances('+assetInstVersionId+',\''+encodedAssetInstName+'\')" id="versionName_'+assetInstVersionId+'">'+versionName+'</a></td>';
		}
		if(versionNotes == null || versionNotes == ""){
			appendData += '<td class="ten wide" id="versionNotes_'+assetInstVersionId+'"></td>';
		}else{
			appendData += '<td class="ten wide" id="versionNotes_'+assetInstVersionId+'">'+versionNotes+'</td>';
		}
		if(versionable){
			
			if(editAccess){
				appendData += '<td class="one wide center aligned guestUserAccess" ><i class="edit icon deleteEditIcon " onclick="openEditVersionDetailsModal('+assetInstVersionId+')"></i></td>';
			}else{
				appendData += '<td class="one wide center aligned  disabled guestUserAccess" ><i class="edit icon deleteEditIcon  disabled" ></i></td>';
			}
			
		}else{
			appendData += '<td class="one wide center aligned  disabled guestUserAccess" ><i class="edit icon  disabled" ></i></td>';
		}	
		
		if(deleteAccess){
			appendData += '<td class="one wide center aligned guestUserAccess"><i class="trash icon deleteEditIcon " id="trash_'+assetInstVersionId+'" data-html="'+data+'" onclick="openDeleteVersionPopup('+assetInstVersionId+')"></i></td>';
		}else{
			appendData += '<td class="one wide center aligned  disabled guestUserAccess"><i class="trash icon deleteEditIcon  disabled" id="trash_'+assetInstVersionId+'" data-html="'+data+'" ></i></td>';
		}
		
		
		
		if(loggedInUserName != "roleAnonymous"){
			appendData += '<td class="two wide center aligned">';
			appendData += '<div class="ui checkbox">';
			appendData += '<input type="checkbox" class="versionCB" id="versionCB_'+assetInstVersionId+'" onclick="compairVersionDetails('+assetInstVersionId+')"><label></label>';
			appendData += '</div></td>';
		}
		appendData += '</tr>';
	
	}
	
	return appendData;
	
}

//compare versions Details
var compareVersionIdList = [];
function compairVersionDetails(aivVersionId){

	if($('.versionCB:checked').length < 3){
		if($("#versionCB_"+aivVersionId).prop('checked')){
			$("#trAccessVarsion_"+aivVersionId).addClass("positive");
			compareVersionIdList.push(aivVersionId);
			$('#compareVersionModal').modal('destroy');
		}
		else{
			$("#trAccessVarsion_"+aivVersionId).removeClass("positive");
			compareVersionIdList.splice($.inArray(aivVersionId, compareVersionIdList),1);
		}

		if($('.versionCB:checked').length == 2){
			setTimeout(function(){
				$('#compareVersionModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
				$.ajax({
					type : "GET",
					url: "/repopro/web/assetInstanceVersionManager/assetInstanceVersionForComparison?assetName="+encodeURIComponent(assetName)+"&userName="+loggedInUserName+"&assetInstanceVersionIds="+compareVersionIdList,
					dataType : "json",
					async: false,
					cache:false,
					complete : function(data) {
						var json = JSON.parse(data.responseText);
						
						if(json.status == "SUCCESS"){
							$("#gridCompareMoreVersionTable tbody").html("");
							$("#gridCompareMoreVersionAccordion").html("");
							
							$("#firstSelectedVersion").html(json.result[0].versionName);
							$("#secondSelectedVersion").html(json.result[1].versionName);
							
							
							var description = loadCompareData("Overview",json.result[0].description, json.result[1].description); 
							$("#gridCompareMoreVersionTable").append(description);	
							
							var relationshipData = loadCompareData("Relationship Data",json.result[0].relationshipData, json.result[1].relationshipData); 
							$("#gridCompareMoreVersionTable").append(relationshipData);	
							
							if(json.result[0].parameterData !== "{}"){
								
								$.each(json.result[0].parameterData, function(key,value) {
										var categoryData = createCategoryModal(key);
										$("#gridCompareMoreVersionAccordion").append(categoryData);
								});
								
								$.each(json.result[0].parameterData, function(key,value) {
									var tableData= "";
									$.each(value, function(key,value) {
										tableData += loadCompareDataAccordionTable(key,value);
									});
									var id = key.replace(/ /g,"_");
									
									$("#accor_"+id).append(tableData);
									
								});
								
								$.each(json.result[1].parameterData, function(key,value) {
									$.each(value, function(key,value) {
										key = key.split("~~");
										var id = key[0].replace(/ /g,"_");
										if(value == null){
											value = "";
										}
										value = value.replace(/~~/g,",");
										
										appendData = "";
										
										if(key[1] == 1){
											if(value.startsWith("<")){
												if(value.startsWith("<a")){
													appendData = value;
												}else{
													var formatted =  formatXml(value);
													formatted = formatted.trim();
													formatted =	hljs.highlightAuto(formatted);
													appendData = '<pre>'+formatted.value+'</pre>';
												}
											}else{
												appendData = value;
											}
										}else if(key[1] == 7){
											appendData = value;
										}else{
											appendData = value;
										}
										
										$("#"+id+"_2").html(appendData);
									});
								});
								
							}
							
							if(JSON.stringify(json.result[0].composedparameterData2) == "{}"){
								$("#noDataCompareComposedRelationshipTable").show();
								$("#gridCompareComposedRelationshipTable").hide();
								$("#gridCompareComposedRelationshipAccordion").hide().html("");
								
								
							}else{
									$("#gridCompareComposedRelationshipTable").show();
									$("#noDataCompareComposedRelationshipTable").hide();
									$("#gridCompareComposedRelationshipTable").html("");
									var firstTable = [];
									var secondTable = [];
									var getData = "";
									$.each(json.result[0].composedparameterData2, function(key,value){
										firstTable.push(key);	
									});
										
									$.each(json.result[1].composedparameterData2, function(key,value){
										secondTable.push(key);
									});
										
									for(i=0; i< firstTable.length; i++){
										getData += createCompRelDataTable(firstTable[i],secondTable[i],i);
									}
									$("#gridCompareComposedRelationshipTable").html(getData);
									
									var count = 0;
									$.each(json.result[0].composedparameterData2, function(key,value) {
										var jsonData = value;
										for(key in jsonData){
											var categoryData = createCategoryModal(key);
											$("#gridCompareComposedRelationshipAccordion_"+count).append(categoryData);
										}
										count++;
									});
									
									$.each(json.result[0].composedparameterData2, function(key,value) {
										var jsonData = value;
										var tableData= "";
										for(i in jsonData){
											tableData= "";
											var paramData = jsonData[i];
											for(j in paramData){
												tableData += loadCompareDataAccordionTable(j,paramData[j]);
											}
											
											var id = i.replace(/ /g,"_");
											$("#accor_"+id).append(tableData);
											$('.ui.accordion').accordion();
										}
									});
									
									$.each(json.result[1].composedparameterData2, function(key,value) {
										var jsonData = value;
										
										for(i in jsonData){
											var paramData = jsonData[i];
											for(j in paramData){
												
												j = j.split("~~");
												var id = j[0].replace(/ /g,"_");
												if(paramData[j] == null){
													paramData[j] = "";
												}
												
												paramData[j] = paramData[j].replace(/~~/g,",");

												appendData = "";
												
												if(j[1] == 1){
													if(paramData[j].startsWith("<")){
														if(paramData[j].startsWith("<a")){
															appendData = paramData[j];
														}else{
															var formatted =  formatXml(paramData[j]);
															formatted = formatted.trim();
															formatted =	hljs.highlightAuto(formatted);
															appendData = '<pre>'+formatted.value+'</pre>';
														}
													}else{
														appendData = paramData[j];
													}
												}else if(j[1] == 7){
													appendData = paramData[j];
												}else{
													appendData = paramData[j];
												}
												
												
												$("#"+id+"_2").html(appendData);
											}
											
										}
									});
									
									
									
									
										/*$.each(json.result[0].composedparameterData, function(key,value) {
											var categoryData = createCategoryModal(key);
											$("#gridCompareComposedRelationshipAccordion").append(categoryData);
										});
								
									$.each(json.result[0].composedparameterData, function(key,value) {
										var tableData= "";
										$.each(value, function(key,value) {
											tableData += loadCompareDataAccordionTable(key,value);
										});
										var id = key.replace(/ /g,"_");
										$("#accor_"+id).append(tableData);
										
									});
									
									$.each(json.result[1].composedparameterData, function(key,value) {
										$.each(value, function(key,value) {
											var id = key.replace(/ /g,"_");
											if(value == null){
												value = "";
											}
											$("#"+id+"_2").html(value);
										});
									});*/
							}

						}

					}
				});
				compareVersionIdList.length = 0;
				$(".versionCB").prop("checked",false);
				$(".versionTR").removeClass("positive");
			},10);
		}
	}
	else{
		$("#versionCB_"+aivVersionId).prop('checked', false);
		notifyMessage("Revision History","Please select any two revisions to compare","warning");
	}
}

//create Comp Rel DataTable
function createCompRelDataTable(firstCol,secondCol,count){
	firstCol = decodeURIComponent(firstCol);
	secondCol = decodeURIComponent(secondCol);
	
	appendData = "";
	appendData += '<table class="ui definition fixed table" id="gridCompareComposedRelationshipTable_'+count+'" style="border-bottom:none;">';
	appendData += '<thead><tr>';
	appendData += '<th class="three wide" style="border-bottom:none;"></th>';
	appendData += '<th>'+firstCol+'</th>';
	appendData += '<th>'+secondCol+'</th>';
	appendData += '</tr></thead></table>';
	appendData += '<div class="ui  fluid accordion" style="margin-top: -1em;" id="gridCompareComposedRelationshipAccordion_'+count+'"></div>';
	return appendData;
}

//load compare data
function loadCompareData(defination, version1,version2){
	if(version1 == null || version1 == ""){
		version1 = "";
	}
	if(version2 == null || version2 == ""){
		version2 = "";
	}
	appendData = "";
	appendData += '<tr>';
	appendData += '<td class="three wide">'+defination+'</td>';
	appendData += '<td>'+version1+'</td>';
	appendData += '<td>'+version2+'</td>';
	appendData += '</tr>';

	return  appendData;
}


//create Category Modal
function createCategoryModal(value){
	var id = value.replace(/ /g,"_");
	appendData = "";
	appendData += '<div class="title active">';
	appendData += '<i class="dropdown icon"></i>'+value+'</div>';
	appendData += '<div class="content active">';
	appendData += '<table class="ui definition fixed table">';
	appendData += '<thead class="hidden">';
	appendData += '<tr>';
	appendData += '<th class="three wide"></th>';
	appendData += '<th></th>';
	appendData += '<th></th>';
	appendData += '</tr>';
	appendData += '</thead>';
	appendData += '<tbody id="accor_'+id+'"></tbody>';
	appendData += '</table></div>';
	
	return appendData;
	
}

//load compare data in accordion table
function loadCompareDataAccordionTable(defination,versionData){
	if(versionData == null){
		versionData = "";
	}
	
	
	
	/*if(value.startsWith("<pre")){
		appendData+= "<span style='color: #999999;'>"+key+" : </span><div> "+value+"</div></br>";
	}else{
		var formatted =  formatXml(value);
		formatted = formatted.trim();
		formatted =	hljs.highlightAuto(formatted);	
		
		var data  = (formatted.value).replace(/~~/g,",");
		
	}*/
	defination = defination.split('~~');
	versionData = versionData.replace(/~~/g,",");
	appendData = "";
	appendData += '<tr>';
	appendData += '<td class="three wide">'+defination[0]+'</td>';
	
	/*if(versionData.startsWith("<")){
		if(versionData.startsWith("<pre")){
			appendData += '<td>'+versionData+'</td>';
		}else{
			var formatted =  formatXml(versionData);
			formatted = formatted.trim();
			formatted =	hljs.highlightAuto(formatted);	
			
			var data  = (formatted.value).replace(/~~/g,",");
			appendData += '<td><pre>'+data+'</pre></td>';
		}
	}else{
		appendData += '<td>'+versionData+'</td>';
	}*/
	
	if(defination[1] == 1){
		if(versionData.startsWith("<")){
			if(versionData.startsWith("<a")){
				appendData += '<td>'+versionData+'</td>';
			}else{
				var formatted =  formatXml(versionData);
				formatted = formatted.trim();
				formatted =	hljs.highlightAuto(formatted);
				appendData += '<td><pre>'+formatted.value+'</pre></td>';
			}
		}else{
			appendData += '<td>'+versionData+'</td>';
		}
	}else if(defination[1] == 7){
		appendData += '<td>'+versionData+'</td>';
	}else{
		var data  = versionData.replace(/~~/g,",");
		appendData += '<td>'+data+'</td>';
	}
	
	
	appendData += '<td id="'+defination[0].replace(/ /g,"_")+'_2"></td>';
	appendData += '</tr>';

	return  appendData;
}



//add new version
function openAddVersionDetailsModal(){
	//<!-- CHANDANA 04-06-2019 DISABLE KEYBOARD CONTROLS -->
	if($('#assetVersionTab').hasClass('AIVDisabled')){
		$("#openAddVersionDetailsModal").blur(); 
		return false;
	}
	
	$('#addVersionDetailsModal').modal('destroy');
	$('#submitAddedVersionData').unbind();
	$('#cancelAddedVersionData').unbind();
	$('#addVersionName').parent().removeClass("error"); 
	$(".errAddVersionName").hide(); 
	$('#addVersionNotes').parent().removeClass("error"); 
	$(".errAddVersionNotes").hide(); 
	$('#selectCopyFromExisting').parent().parent().removeClass("error"); 
	$(".errAddCopyFromExistingVersion").hide(); 
	$('#addVersionDetailsModal').modal('destroy');
	$('#addVersionDetailsModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	$("#addVersionName").val("");
	$("#addVersionNotes").val("");
	$("#selectCopyFromExisting").html("");
	var createVersionList = '';
	
	$("#selectCopyFromExisting").html("");
	createVersionList += '<select class="ui fluid dropdown"  id="selectCopyFromExistingDropdown">';
	createVersionList += '<option value="none">None</option>';
	$.each(versionList, function(i) {
		createVersionList += '<option value="'+versionList[i]+'">'+versionList[i]+'</option>';
	});
	createVersionList += '</select>';
	
	$("#selectCopyFromExisting").append(createVersionList);
	$("#selectCopyFromExistingDropdown").dropdown();
	var latestVersion = Math.max.apply(Math,versionList);
	$("#selectCopyFromExistingDropdown").dropdown("set selected",latestVersion);
	
	$('#submitAddedVersionData').on('click', function(){
		var newVersionName = $("#addVersionName").val().trim();
		newVersionName = newVersionName.replace(/ /g, '');
		var newVersionNotes = $("#addVersionNotes").val().trim();
		var copyFromVersion = $("#selectCopyFromExistingDropdown").find(":selected").val();
		var flag = true;

		if(newVersionName == null || newVersionName == ""){
			$('#addVersionName').parent().addClass("error"); 
			$(".errAddVersionName").html("Please provide version name").show();  
			flag = false;
		}
		else{
			var arr = newVersionName.split('.');
			if(arr.length == 2){
				if(arr[0].match(/[0-9]/) && arr[1].match(/[0-9]/)){
					$('#addVersionName').parent().removeClass("error"); 
					$(".errAddVersionName").hide(); 
				}else{
					$('#addVersionName').parent().addClass("error"); 
					$(".errAddVersionName").html("Please enter version name in x.y format.").show();  
					flag = false;
				}
			}else{
				$('#addVersionName').parent().addClass("error"); 
				$(".errAddVersionName").html("Please enter version name in x.y format.").show();  
				flag = false;
			}
			
		}
		
		if(newVersionNotes == null || newVersionNotes == ""){
			$('#addVersionNotes').parent().addClass("error"); 
			$(".errAddVersionNotes").show();  
			flag = false;
		}
		else{
			$('#addVersionNotes').parent().removeClass("error"); 
			$(".errAddVersionNotes").hide(); 
		}
		
		if( $("#selectCopyFromExistingDropdown").val() == ""){
			$('#selectCopyFromExistingDropdown').parent().parent().addClass("error"); 
			$(".errAddCopyFromExistingVersion").show();  
			flag = false;
		}
		else{
			$('#selectCopyFromExistingDropdown').parent().parent().removeClass("error"); 
			$(".errAddCopyFromExistingVersion").hide(); 
		}
		
		if(flag == false){
			$('#addVersionDetailsModal').modal('show');
			return false;
		}
		else{
			var obj = {
					"versionName": newVersionName,
					"versionNotes": newVersionNotes
			};
			var url = "";
			if(versionable){
				versionableType = 1;
			}else{
				versionableType = 0;
			}
			
			url = "/repopro/web/assetInstanceVersionManager/addAssetInstanceVersions/?assetInstanceId="+assetInstanceId+"&assetInstName="+encodeURIComponent(assetInstanceName)+"&assetId="+assetId+"&assetName="+encodeURIComponent(assetName)+"&userId="+loggedInUserId+"&userName="+loggedInUserName+"&versionableFlag="+versionableType+"&copyFromVersion="+copyFromVersion+"&activeFlag="+loggedInUserActiveFlag;
			 $.ajax({
			       	type: "POST",
			       	url: url,
			       	contentType : "application/json",
					dataType : "json",
					data : JSON.stringify(obj),
					async: false,
					cache:false,
					complete:function(data){	
					appenddata = "";
						var json = JSON.parse(data.responseText);
						if(json.status == "SUCCESS"){
							$.each(json.result, function(i) {
								versionList.push(json.result[i].versionName);
								var versionData = loadAssetInstanceVersions(json.result[i].versionName , json.result[i].versionNotes, json.result[i].assetInstVersionId,true,true,true);
								$("#assetInstancesVersionTable table tbody").append(versionData);
							});
							
							
							notifyMessage("Add Version","New version added","success");
							/*$('#addVersionDetailsModal').modal('hide').modal('destroy'); //.modal('hide dimmer'); 
							$('#addVersionDetailsModal').parent().css("display", "none !important");*/
							$('#addVersionDetailsModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
							getAssetInstances(json.result[0].assetInstVersionId,json.result[0].assetInstName);
							
						}else {
							if(json.result[0] == "ASSET_INSTANCE_VERSION_NAME_EXIST"){
								$('#addVersionName').parent().addClass("error"); 
								$(".errAddVersionName").html("Asset Instance Version '"+newVersionName+"' already exists").show();  
								flag = false;
							}else{
								$('#addVersionName').parent().removeClass("error"); 
								$(".errAddVersionName").hide();
								notifyMessage("Add Version",json.result[0],"fail");
							}
							
							
						}
					}
			  });
			
			 if(flag){
				 /*$('#addVersionDetailsModal').modal('hide').modal('destroy'); //.modal('hide dimmer'); 
				 $('#addVersionDetailsModal').parent().css("display", "none !important");*/
				 $('#addVersionDetailsModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
			 }else{
				 return false;
			 }
			 	 
		
		}
		
	});
	
}

//  open Edit Version Details Modal
function openEditVersionDetailsModal(assetInstVersionId){
	$('#submitEditedVersionData').unbind();
	$('#cancelEditedVersionData').unbind();
	$('#editVersionDetailsModal').modal('destroy');
	$('#editVersionDetailsModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	var versionName = $("#versionName_"+assetInstVersionId).text();
	var versionNotes = $("#versionNotes_"+assetInstVersionId).html();
	
	
	$("#editVersionName").val(versionName);
	$("#editVersionNotes").val(versionNotes);
	
	$('#submitEditedVersionData').on('click', function(){
		var newVersionName = $("#editVersionName").val().trim();
		var newVersionNotes = $("#editVersionNotes").val().trim();
		var flag = true;

		if(newVersionName == null || newVersionName == ""){
			$('#editVersionName').parent().addClass("error"); 
			$(".errEditVersionName").show();  
			flag = false;
		}
		else{
			var arr = newVersionName.split('.');
			if(arr.length == 2){
				if(arr[0].match(/\d/) && arr[1].match(/\d/)){
					$('#editVersionName').parent().removeClass("error"); 
					$(".errEditVersionName").hide(); 
				}else{
					$('#editVersionName').parent().addClass("error"); 
					$(".errEditVersionName").html("Please enter version name in x.y format.").show();  
					flag = false;
				}
			}else{
				$('#editVersionName').parent().addClass("error"); 
				$(".errEditVersionName").html("Please enter version name in x.y format.").show();  
				flag = false;
			}
		}
		
		if(newVersionNotes == null || newVersionNotes == ""){
			$('#editVersionNotes').parent().addClass("error"); 
			$(".errEditVersionNotes").show();  
			flag = false;
		}
		else{
			$('#editVersionNotes').parent().removeClass("error"); 
			$(".errEditVersionNotes").hide(); 
		}
		
		if(flag == false){
			$('#editVersionDetailsModal').modal('show');
			return false;
		}
		else{
			var obj = {
					"versionName":newVersionName,
					"versionNotes": newVersionNotes
			};
			
			 $.ajax({
			       	type: "PUT",
			       	url: "/repopro/web/assetInstanceVersionManager/updateAssetInstanceVersions/?assetInstanceId="+assetInstanceId+"&assetInstanceVersionId="+assetInstVersionId+"&oldVersionName="+versionName+"&assetInstanceName="+encodeURIComponent(assetInstanceName)+"&assetId="+assetId+"&userName="+loggedInUserName+"&assetName="+encodeURIComponent(assetName),
			       	contentType : "application/json",
					dataType : "json",
					data : JSON.stringify(obj),
					async: false,
					cache:false,
					complete:function(data){	
					appenddata = "";
						var json = JSON.parse(data.responseText);
						if(json.status == "SUCCESS"){
							$("#versionName_"+assetInstVersionId).html(newVersionName);
							$("#versionNotes_"+assetInstVersionId).html(json.result[0].versionNotes);
							
							versionList.splice($.inArray(versionName, versionList),1);
							versionList.push(newVersionName);
							
							var Versiontime = json.result[0].updatedOn.trim();
							Versiontime = Versiontime.split(" ");
							
							
							$('#showAssetOverViewUpdatedOn').html('');
							$('#showAssetOverViewUpdatedOn').html(Versiontime[0]+"T"+Versiontime[1]);
							notifyMessage("Edit Version","Version details updated","success");
						}
						else {
							if(json.result[0] == "ASSET_INSTANCE_VERSION_NAME_EXIST"){
								$('#editVersionName').parent().addClass("error"); 
								$(".errEditVersionName").html("Asset Instance Version '"+newVersionName+"' already exists").show();  
								flag = false;
							}else if(json.result[0] == "NO_CHANGES_TO_UPDATE"){
								notifyMessage("Edit Version","No changes to update","warning");
							}else{
								notifyMessage("Edit Version","Error attempting to update version details","fail");
							}
							
						}
					}
			  });
			
			if(flag){
				$('#editVersionDetailsModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
				/*$('#editVersionDetailsModal').modal('hide'); //.modal('hide dimmer');
				$('#editVersionDetailsModal').parent().css("display", "none !important");*/
			}else{
				return false;
			}
			  
		}
		
			
	});
	
}

//delete version confirmation popup
function openDeleteVersionPopup(assetInstVersionId){
	
	$("#trash_"+assetInstVersionId)
	.popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	})
	.popup('show');
	 //Chandana 13-06-2019
	$.ajax({
		type:"GET",
		url:"/repopro/web/assetInstanceVersionManager/checkForDeletionOfMappedInstanceVersion?aivId="+assetInstVersionId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			//alert(JSON.stringify(json))
			if(json.result == "true"){
				$('#delVersion').html('');
				$('#delVersion').html('This asset instance was mapped in the relationship with other asset instance. Still Do you want to delete?');
			}
			else{
			}
			}
	});
}

//close delete version popup
function closeDeleteVersionPopup(assetInstVersionId){
	$("#trash_"+assetInstVersionId).popup('hide');
}

//delete version
function deleteVersion(assetInstVersionId){
	
	var versionNameFromTable = $("#versionName_"+assetInstVersionId).text();
	var url = "";

	
	if(versionable){
		url = "/repopro/web/assetInstanceVersionManager/deleteAssetInstanceVersions/?assetInstanceId="+assetInstanceId+"&assetInstName="+encodeURIComponent(assetInstanceName)+"&assetId="+assetId+"&assetName="+encodeURIComponent(assetName)+"&userId="+loggedInUserId+"&userName="+loggedInUserName+"&versionableFlag=1&assetInstanceVersionId="+assetInstVersionId+"&versionName="+versionNameFromTable;
	}
	else{
		url = "/repopro/web/assetInstanceVersionManager/deleteAssetInstanceVersions/?assetInstanceId="+assetInstanceId+"&assetInstName="+encodeURIComponent(assetInstanceName)+"&assetId="+assetId+"&assetName="+encodeURIComponent(assetName)+"&userId="+loggedInUserId+"&userName="+loggedInUserName+"&versionableFlag=0&assetInstanceVersionId="+assetInstVersionId+"&versionName="+versionNameFromTable;
	}
		$.ajax({
		type: "DELETE",
		url: url,
		dataType: "json",
		async: false,
		cache:false,
		complete:function(data){										
			var json = JSON.parse(data.responseText);
			var msg = json.message;
			msg = msg.replace(/_/g, ' ');
			if(json.status == "FAILURE"){
				notifyMessage("Delete Version",msg+" : "+json.result,"fail");
			}
			else {
				if(json.result != ""){
					notifyMessage("Delete Version",msg+" : "+json.result,"fail");
				} 
				else{	
					notifyMessage("Delete Version","Version deleted","success");
					$('#trAccessVarsion_'+assetInstVersionId).remove();
					versionList.splice($.inArray(versionNameFromTable, versionList),1);
				}
				closeDeleteVersionPopup(assetInstVersionId);
				if(assetInstanceVersionId == assetInstVersionId){
					if(versionList.length == 0){
						navigateToAssetPage();
					}else{
						var version = Math.max.apply(Math,versionList);
						
						$('#assetInstancesVersionTable table tbody tr').each(function(){
						        if($(this).find('td').eq(0).text() == version){
						        	 $(this).find('td a').click();
						        }
						    });
					}
					
				}
			}
		}
	});   
}


//get data for discussion 
function getCommentsData(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/discussionmanager/listallcomments?aivId="+assetInstanceVersionId+"&userName="+loggedInUserName,
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			
			setTimeout(function(){ 
				$("#discussionLoadingContent").removeClass("loading");
			}, 50);
			
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				
				if(json.result == "" || json.result == null){
					$("#commentSection").html('<div id="noCommentMessage" class="ui message">No comments added yet</div>');
				}
				else {
					$("#commentSection").html("");
					$(".ui.warning.message").css("display", "none");
					$.each(json.result, function(i) {
						var imageType = "";
						if(json.result[i].imageName !== null){
							if(typeof json.result[i].imageName !== undefined){
							//imageType = (json.result[i].imageName).split('.');
							imageType = (json.result[i].imageName).substring((json.result[i].imageName).lastIndexOf(".") + 1, (json.result[i].imageName).length);

							}
						}
						var commentData = loadComments(json.result[i].commentId , json.result[i].commentTimestamp, json.result[i].description, json.result[i].fullName, imageType, json.result[i].parentCommentId, json.result[i].userId,json.result[i].encryptImage,json.result[i].userName);
						
						if(json.result[i].parentCommentId == 0){
							$("#commentSection").append(commentData);
						}
						else{
							$("#replyToCommentId_"+json.result[i].parentCommentId).css('display','block');
							$("#replyToCommentId_"+json.result[i].parentCommentId).append(commentData);
						}
						
						
						$("#"+json.result[i].commentId+"userImage_"+json.result[i].userId).error(function() {
							$("#"+json.result[i].commentId+"userImage_"+json.result[i].userId).attr('src','/repopro/semantic/images/avatar/defaultUserImage.png');
						});
					});
						
				}
				
				
			}
			
			if(loggedInUserName == "roleAnonymous"){
				$("#commentButtonAccess").remove();
			}
			
			lazyLoadingImage();
			checkAccessForUserOnSuccess();
		}
	});
	//getReverseRelationships();
	
	
}
//get Composition & Aggregation Asset Type

var assetInstNameChild,assetIdChild;
function getCompositionAggregationAssetType(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstance/getAddAccessForCompositionAndAggregationAssetType?assetId="+assetId+"&userName="+loggedInUserName,
		dataType : "json",
		async: true,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$.each(json.result,function(i){
					if(json.result[i].addAccess == 1){
						var flagForChild = true;
						var buttonData = loadChildButton(json.result[i].assetId, json.result[i].assetName,flagForChild);
						$("#addNewAssetInstanceChildDropdown").show();
						$("#addNewAssetInstanceChild").append(buttonData).css("display","block");
					}
				});
				
			}else{
				$("#addNewAssetInstanceChildDropdown").hide();
				$("#addNewAssetInstanceChild").css("display","none");
			}
		}
	});
	
}

//load child button
function loadChildButton(childAssetId, childAssetName, flagForChild){
	appendData = '';
	/*appendData += '<div class="ui labeled icon primary mini button " style="float: right; margin-bottom: 1em;" onclick="addNewAssetInstanceChild('+childAssetId+','+flagForChild+')">';
	appendData += '<i class="plus icon"></i><span id="addNewAssetInstanceChildName_'+childAssetId+'">Add '+childAssetName+'</span>';
	appendData += '</div>';*/
	
	appendData += '<div class="item aivMenus" style="padding: 7px 15px 7px 15px !important;" onclick="addNewAssetInstanceChild('+childAssetId+','+flagForChild+',\''+childAssetName+'\')">';
	appendData += '<i class="plus icon"></i><span id="addNewAssetInstanceChildName_'+childAssetId+'">Add '+childAssetName+'</span>';
	appendData += '</div>';
	
	return appendData;
}

//add New Asset Instance Child
function addNewAssetInstanceChild(childAssetId,flagForChild,childAssetName){
	/*$("#addNewAssetInstanceChildModal").modal("destroy");
	$('#submitAddNewAssetInstanceChild').unbind();
	$('#cancelAddNewAssetInstanceChild').unbind();
	$("#addNewAssetInstanceName").val("");
	$('.errAddNewAssetInstanceName').parent().removeClass("error");
    $(".errAddNewAssetInstanceName").hide();
	$("#addNewAssetInstanceChildModal").modal('setting', 'closable', false).modal('show');
	
	$("#submitAddNewAssetInstanceChild").on("click",function(){
		var instanceName = $("#addNewAssetInstanceName").val().trim();
		var flag = true;
		
		if(instanceName == null || instanceName == ""){
			$('#addNewAssetInstanceName').parent().addClass("error"); 
		    $(".errAddNewAssetInstanceName").show().html("Please provide instance name");  
			flag = false;
		}else{
			$("#addNewAssetInstanceName").parent().removeClass("error");
			$('.errAddNewAssetInstanceName').hide();
		}
		
		
		var iChars = "`!%^*=[];{}|<>?~";
		  
		  for (var i = 0; i < instanceName.length; i++){
		  	if (iChars.indexOf(instanceName.charAt(i)) != -1){
		  		$("#addNewAssetInstanceName").parent().addClass("error");
		  		 $(".errAddNewAssetInstanceName").show().html("Special characters except ':'\"+#$/\&(),-_.@' are not allowed");
		  		flag = false;
		  		return false;
		  	}
		  }
		
		if(flag == false){
			$('#addNewAssetInstanceChildModal').modal('show');
			return false;
		}else{
			var obj = {

					"assetId": childAssetId,
					"assetInstName": encodeURIComponent(instanceName),
					"owner": loggedInUserName,
					"versionName":  "1.0",
					"parentAssetInstVersionId":assetInstanceVersionId, 
					"parentAssetId":assetId,
					"parentVersionName":versionName,
					"parentAssetInstName":encodeURIComponent(assetInstanceName)
					
			};
			  
			
			$.ajax({
			       type: "POST",
			       url: "/repopro/web/assetInstance/addAssetInstance?userName="+loggedInUserName+"&flagForChild="+flagForChild,
			       contentType : "application/json",
					dataType : "json",
					data : JSON.stringify(obj),
					async: false,
					cache:false,
					complete:function(data){	
					var json = JSON.parse(data.responseText);
					var msg = json.message;
					msg = msg.replace(/_/g, ' ');
					if(json.status == "SUCCESS"){
						
						if(json.message == "ASSET_INSTANCE_ALREADY_EXIST"){
							$('#addNewAssetInstanceName').parent().addClass("error"); 
						    $(".errAddNewAssetInstanceName").show().html("Instance by this name already exists"); 
						}else{
							$('#addNewAssetInstanceName').parent().removeClass("error"); 
							$(".errAddNewAssetInstanceName").hide();
							
							$('#addNewAssetInstanceChildModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
							$('#addNewAssetInstanceChildModal').modal('hide'); //.modal('hide dimmer');
							$('#addNewAssetInstanceChildModal').parent().css("display", "none !important");
							notifyMessage("Add Asset Instance",instanceName+" added","success");
							setTimeout(function(){
								getAssetInstances(json.result[0].assetInstVersionId, json.result[0].assetInstName);
							},400);
						}
					}
					else {
							$('#addNewAssetInstanceChildModal').modal('hide');
						$('#addNewAssetInstanceChildModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
							notifyMessage("Add Asset Instance",msg,"fail")
						}	
					}
			  });
			
			
		}
		
	});*/
	
	
	var obj = {
			"assetId": childAssetId,
			"childAssetName": childAssetName,
			"owner": loggedInUserName,
			"versionName":  "1.0",
			"parentAssetInstVersionId":assetInstanceVersionId, 
			"parentAssetId":assetId,
			"parentVersionName":versionName,
			"parentAssetInstName":assetInstanceName
	};
	
	//store obj in local storage
	localStorage.removeItem("addChildObject");
	localStorage.setItem("addChildObject",JSON.stringify(obj));
	
	//save other data
	localStorage.removeItem("browserAssetName");
	localStorage.setItem("browserAssetName",childAssetName);
	localStorage.removeItem("browserAssetId");
	localStorage.setItem("browserAssetId",childAssetId);
	localStorage.removeItem("editAIVPageFlag");
	localStorage.setItem("editAIVPageFlag", true);
	localStorage.removeItem("addChildAIVPage");
	localStorage.setItem("addChildAIVPage", true);
	
	getAssetInstances(0,"newInstance");
	
}


//add new comment
function addNewComment(){
	//CHANDANA 07-06-2019
	if($('#Newcomment').hasClass('disabled')){
		$('#Newcomment').blur();
	}
	var comment = $("#addNewComment").val().trim();
	
	
	
	if(comment == null || comment == ""){
		notifyMessage("Add Comment","Please provide the comment details","warning");
	}else{
		var obj = {
				"assetInstanceVersionId": assetInstanceVersionId,
				"userId": loggedInUserId,
				"description": comment
			};
	
	
	  $.ajax({
	       type: "POST",
	       url: "/repopro/web/discussionmanager/addcomment",
	       contentType : "application/json",
			dataType : "json",
			data : JSON.stringify(obj),
			async: false,
			cache:false,
			complete:function(data){
			var json = JSON.parse(data.responseText);
			var msg = json.message;
			msg = msg.replace(/_/g, ' ');
			if(json.status == "SUCCESS"){
					
					$(".ui.warning.message").css("display", "none");
					 $("#addNewComment").val("");
					$.each(json.result, function(i) {
						
						var commentData = loadComments(json.result[i].commentId , "Just Now", json.result[i].description, loggedInUserFullName, loggedInUserImageType, json.result[i].parentCommentId, json.result[i].userId,json.result[i].encryptImage,json.result[i].userName);
						
						$("#commentSection").append(commentData);
						$("#noCommentMessage").remove();
						$("#"+json.result[i].commentId+"userImage_"+json.result[i].userId).error(function() {
							$("#"+json.result[i].commentId+"userImage_"+json.result[i].userId).attr('src','/repopro/semantic/images/avatar/defaultUserImage.png');
						});
					});
						
				}
			else {
				notifyMessage("Add Comment",msg,"fail");
				}	
				
			}
	  });
	}
		
	
	
}

//add reply to a comment
function addReplyToComment(commentId){
	var comment = $("#replyInputFieldForCommentId_"+commentId).val().trim();
	
	
	if(comment == null || comment == ""){
		notifyMessage("Add Reply","Please provide the reply details","warning");
	}else{
		var obj = {
				"assetInstanceVersionId": assetInstanceVersionId,
				"userId": loggedInUserId,
				"description": comment,
				"parentCommentId": commentId
			};
	
	
	 $.ajax({
	       type: "POST",
	       url: "/repopro/web/discussionmanager/addreply",
	       contentType : "application/json",
			dataType : "json",
			data : JSON.stringify(obj),
			async: false,
			cache:false,
			complete:function(data){
			var json = JSON.parse(data.responseText);
			var msg = json.message;
			msg = msg.replace(/_/g, ' ');
			if(json.status == "SUCCESS"){
				notifyMessage("Add Reply","Reply added","success");
					$("#textboxReplyToCommentId_"+commentId).html("");
					$(".ui.warning.message").css("display", "none");
					 $("#addNewComment").val("");
					$.each(json.result, function(i) {
						
						var commentData = loadComments(json.result[i].commentId , "Just Now", json.result[i].description, loggedInUserFullName, loggedInUserImageType, json.result[i].parentCommentId, json.result[i].userId,json.result[i].encryptImage,json.result[i].userName);
						
						$("#replyToCommentId_"+json.result[i].parentCommentId).css('display','block');
						$("#replyToCommentId_"+json.result[i].parentCommentId).append(commentData);
						
						/*$("#"+json.result[i].commentId+"userImage_"+json.result[i].userId).error(function() {
							$("#"+json.result[i].commentId+"userImage_"+json.result[i].userId).attr('src','/repopro/semantic/images/avatar/defaultUserImage.png');
						});*/
					});
						
				}
			else {
				notifyMessage("Add Reply",msg,"fail");
				}	
				
			}
	  });
	}
		
	
	
}





//load comments
function loadComments(commentId,commentTimestamp,description,fullName,imageType,parentCommentId,userId,encImgId,userName){
	//Chandana - 13-9-2019 Broken image
	if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
		imageType = imageType.toLowerCase()
	}
	var imageName = "default";
	if(imageType != null){
		imageName = imageType;
	}
	
	appendData = "";
	appendData += '<div class="comment" id="commentId_'+commentId+'">';
	if(imageName != "default"){
		if((encImgId == 0) ||  (loggedInUserId == userId) || (loggedMapRoleFlag == 1)){// Encryption- Swathi
			appendData += '<a class="avatar" style="height: 2.5em;"> <img id="'+commentId+'userImage_'+userId+'" style="border-radius: 1.25rem !important;"  src="/repopro/profileImages/'+userId+'.'+imageType+'"></a>';
		} else{
			appendData += '<a class="avatar extra " style="height: 2.5em;"> <img id="'+commentId+'userImage_'+userId+'" style="border-radius: 1.25rem !important;" src="/repopro/semantic/images/avatar/defaultUserImage.png"></a>';
		}
		
	}else{
		appendData += '<a class="avatar" style="height: 2.5em;"> <img id="'+commentId+'userImage_'+userId+'" style="border-radius: 1.25rem !important;" src="/repopro/semantic/images/avatar/defaultUserImage.png"></a>';
	}
	appendData += '<div class="content">';
	appendData += '<span class="author" style="font-weight: 500 !important;">'+fullName+'</span>';
	appendData += '<div class="metadata">';
	appendData += '<span class="date">'+commentTimestamp+'</span>';
	appendData += '</div>';
	appendData += '<div class="text">'+description+'</div>';
	appendData += '<div class="actions">';
	if(loggedInUserName != "roleAnonymous"){
		appendData += '<a class="reply" id="giveReplyToCommentId_'+commentId+'" onclick="openReplyTextbox('+commentId+', \''+fullName+'\')">Reply</a>';
		
	}
		
	appendData += '<span id="textboxReplyToCommentId_'+commentId+'"></span></div></div>';
	appendData += '<div class="comments" style="display:none;" id="replyToCommentId_'+commentId+'"></div>';
	appendData += '</div>';
	return appendData;
}


//open reply comment textbox
function openReplyTextbox(commentId,fullName){
	appendData = '';
	appendData += '<div class="ui fluid action input" style="margin-top: 0.5em;">';
	appendData += '<input type="text" maxlength="1000" placeholder="Write a reply to '+fullName+' (Max characters 1000)" id="replyInputFieldForCommentId_'+commentId+'">';
	appendData += '<button class="ui icon primary button focusAddReply" title="Reply"  onclick="addReplyToComment('+commentId+')" id="replyButtonForCommentId_'+commentId+'">';
	appendData += '<i class="comment icon" style="margin-top: -0.3em;"></i>';
	appendData += '</button></div>';
	
	$("#textboxReplyToCommentId_"+commentId).html(appendData);
}

//toggle rating 
function showRating(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/ratingmanager/getuserscount?assetInstanceVersionId="+assetInstanceVersionId,
		dataType : "json",
		async: false,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					
					
				}else{
					var averageRating = json.result[0].avgRating;
					var totalCount = json.result[0].totalCount;
					appendData = "";
					
					for(var i= 0; i < Math.floor(averageRating); i++){
						appendData += '<i class="star large icon"></i>';
					}
					if(averageRating !== 5){
						if( averageRating - Math.floor(averageRating) < 0.4){
							appendData += '<i class="star large empty icon"></i>';
						}else{
							appendData += '<i class="star large half empty icon"></i>';
						}
					
						for(var i= 0; i < (4 - Math.floor(averageRating)); i++){
							appendData += '<i class="star large empty icon"></i>';
						}
					}
					$("#assetInstanceAvgRating").html(averageRating);
					$("#assetInstanceAvgRatingInStar").html(appendData);
					$("#assetInstanceRatingTotalCount").html(totalCount);
					$(".ratingProgressStyle").progress({
						  percent: "0"
					});
					$(".ratingProgressLabelStyle").html("0");
					
					$.each(json.result, function(i){
						var percentageRating = (json.result[i].count * 100)/ json.result[i].totalCount;
						if(percentageRating == 100){
							percentageRating = 99;
						}
						$("#countIndividualRating_"+json.result[i].rating).html(json.result[i].count);
						$("#dataPercent_"+json.result[i].rating).progress({
							  percent: percentageRating
							});
					});
					
					
				}
			}
		}
	});
	
	$.ajax({
		type : "GET",
		url : "/repopro/web/ratingmanager/getAllRating?assetInstanceVersionId="+assetInstanceVersionId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					$("#assetInstanceRatingComments").html('<div style="width: 100%;margin-bottom: 2em;" class="ui message">Be the first to review</div>')
				}else{
					var countComments = 0;
					$("#assetInstanceRatingComments").html("");
					$.each(json.result, function(i){
						if(countComments < 6){
							var reviewData = loadReviewData(json.result[i].userId,json.result[i].username,json.result[i].imageName,json.result[i].rating,json.result[i].ratingDescription,json.result[i].encryptImage);
							$("#assetInstanceRatingComments").append(reviewData);
							$("#userComment_"+json.result[i].userId).text(json.result[i].ratingDescription);
							$('.userGivenRating').rating('disable');
							countComments++;
						}
						
						
					});
				}
			}
		}
	});
	$("#ratingSegment").toggle('slow');
	//----Chandana 10-5-2019 SOC ----//
	$('html, body').animate({
        scrollTop: $("#ratingSegment").offset()
    }, 500);
	//----EOC ----//
}

//load review data
function loadReviewData(userId,username,imageName,rating,ratingDescription,encImg){
	appendData = "";
	appendData += '<div class="card">';
	appendData += '<div class="content">';
	appendData += '<div class="comment">';
	if((imageName == null) || ((encImg ==1) && (username != loggedInUserName) && (loggedMapRoleFlag == 0)) ){// Encryption- swathi
		appendData += '<a class="avatar"> <img src="/repopro/semantic/images/avatar/defaultUserImage.png"></a>';
	}else{
		//var imageType = imageName.split(".");
		var imageType = (imageName).substring((imageName).lastIndexOf(".") + 1, (imageName).length);

		appendData += '<a class="avatar"> <img src="/repopro/profileImages/'+userId+'.'+imageType+'"></a>';
	}
	appendData += '<div class="content">';
	appendData += '<div class="author">'+username+'</div>';
	appendData += '<div class="metadata">';
	appendData += '<div class="ui rating userGivenRating" data-rating="'+rating+'" data-max-rating="5"></div>';
	appendData += '</div>';
	appendData += '<div class="text" id="userComment_'+userId+'"></div>';
	appendData += '</div></div></div></div>';
	
	return appendData;
}

//add or remove my fav
function addAsMyFavourites(){
	if(myFavFlag){
		myFavFlag = false;
		$("#addToFavouriteIcon").removeClass("yellowColorStar").addClass("empty");
		$('#changeFavouriteText').text('Add To Favourites');
		$.ajax({
			type : "DELETE",
			url : "/repopro/web/favourite/removeFromFavourite?assetInstId="+assetInstanceId+"&userId="+loggedInUserId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage("Remove From My Favourites",assetInstanceName+" removed from favourites","success");
				
				}
			}
		});
		
	}else{
		myFavFlag = true;
		$("#addToFavouriteIcon").removeClass("empty").addClass("yellowColorStar");
		$('#changeFavouriteText').text('Remove Favourites');
		$.ajax({
			type : "POST",
			url : "/repopro/web/favourite/addtofavourites?userId="+loggedInUserId+"&assetInstanceId="+assetInstanceId+"&assetInstVersionId="+assetInstanceVersionId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage("Add To My Favourites",assetInstanceName+" added to favourites","success");
				
				}
			}
		});
		
	}
}

//lock Unlock Asset Instance
function lockUnlockAssetInstance(){
	var url = "";
	var notifyMessageTopic = "";
	var notifyMessageBody = "";
	var flag = true;
	var noUnlockFlag = false;
	var unlockFlag = false;
	var lockInstanceAPICallFlag = false;
	if($("#lockUnlockAssetInstance").hasClass("lock")){
			
		if(editingEnabled){
			var txt;
		    var r = confirm("All unsaved data will be lost. Do you want to proceed?");
		    if (r == true) {
					callOnlyOnceForpropertiesFlag = true;
					$("#lockUnlockAssetInstance").removeClass("lock").addClass("unlock").parent().attr("data-tooltip","Click to Lock and Edit");
					url = "/repopro/web/assetInstanceVersionManager/unlockassetinstanceversion?userName="+loggedInUserName+"&aivId="+assetInstanceVersionId;
					notifyMessageTopic = "Unlock Asset Instance";
					notifyMessageBody = assetInstanceName+" is not locked for editing";
					flag = true;
					$(".lockEditing").removeClass("disabled");
					$(".propertiesLockedByOther").removeClass("disabled");
					$("#lockStatusMessage").html("");
					clearTimeout(countdownTimerInterval);
					closeAllEditFieldsAfterUnlock();
					unlockFlag = true;
		    }else{
		    	noUnlockFlag = true;
		    	flag = false;
		    }
		}else{
			callOnlyOnceForpropertiesFlag = true;
			$("#lockUnlockAssetInstance").removeClass("lock").addClass("unlock").parent().attr("data-tooltip","Click to Lock and Edit");
			url = "/repopro/web/assetInstanceVersionManager/unlockassetinstanceversion?userName="+loggedInUserName+"&aivId="+assetInstanceVersionId;
			notifyMessageTopic = "Unlock Asset Instance";
			notifyMessageBody = assetInstanceName+" is not locked for editing";
			flag = true;
			$(".lockEditing").removeClass("disabled");
			$(".propertiesLockedByOther").removeClass("disabled");
			$("#lockStatusMessage").html("");
			clearTimeout(countdownTimerInterval);
			closeAllEditFieldsAfterUnlock();
			$("#editBtnAfterLock").addClass("disabled");
		}
				
		    
			    
	}else{
		var getLockStatusFlag = getLockStatus();
		if(getLockStatusFlag){
			flag = false;
			notifyMessage("Lock Asset Instance","Instance "+assetInstanceName+" is alredy locked","fail");
		}else{
			$("#lockUnlockAssetInstance").removeClass("unlock").addClass("lock").parent().attr("data-tooltip","Click to Unlock");
			url = "/repopro/web/assetInstanceVersionManager/lockassetinstanceversion?userName="+loggedInUserName+"&aivId="+assetInstanceVersionId;
			notifyMessageTopic = "Lock Asset Instance";
			notifyMessageBody = assetInstanceName+" is locked for editing";
			flag = true;
			lockInstanceAPICallFlag = true;
			editAIVPage();
		
		}
			
	}
	
	if(flag){	
		$.ajax({
			type : "PUT",
			url : url,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage(notifyMessageTopic,notifyMessageBody,"success");
					if(lockInstanceAPICallFlag){
						getLockStatus();
					}
				}else{
					notifyMessage(notifyMessageTopic,"Error attempting to lock / unlock "+assetInstanceName,"fail");
				}
	
			}
		});
	}else{
		if(noUnlockFlag == false){
			getLockStatus();
		}
		
	}
	
	if(unlockFlag){
		getAssetInstances(assetInstanceVersionId,assetInstanceName);
	}
	
}

//get notification Asset Instance
function notificationAssetInstance(){
	if(notificationFlag){
		notificationFlag = false;
		$("#notificationAssetInstanceIcon").removeClass("blue").addClass("outline");
		$('#changeNotoficatiobText').text('Enable Notification');
		$.ajax({
			type : "DELETE",
			url : "/repopro/web/assetInstance/updateUnSubscriptionNotification?userId="+loggedInUserId+"&assetInstanceId="+assetInstanceId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage("Disable Notifications","You will no longer get any notifications for "+assetInstanceName,"success");
				
				}
			}
		});
		
	}else{
		notificationFlag = true;
		$("#notificationAssetInstanceIcon").removeClass("outline").addClass("blue");
		$('#changeNotoficatiobText').text('Disable Notification');
	  $.ajax({
			type : "POST",
			url : "/repopro/web/assetInstance/updateSubscriptionNotification?userId="+loggedInUserId+"&assetInstanceId="+assetInstanceId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage("Enable Notifications","You will receive notifications for "+assetInstanceName,"success");
				
				}
			}
		});
		
	}
}



//get reverse relationship
reverseRelLegendList = [];
function getReverseRelationships(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/relationship/getallreverserelationships?assetInstanceVersionId="+assetInstanceVersionId,
		dataType : "json",
		async: true,
		complete : function(data) {
			
			setTimeout(function(){ 
				$("#reverseRelationshipsLoadingContent").removeClass("loading");
			}, 50);
			$('#showReverseRelationships').html('');
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					$("#showReverseRelationships").html('<div class="ui message" style="background-color: #ffffff !important;">No backward relationships found for '+assetInstanceName+'</div>');
					$("#showReverseRelationshipsLegends").hide();
					 $("#noRevRelLegendData").show();
				}
				else {
					 $("#showReverseRelationshipsLegends .header").show();
					 $("#noRevRelLegendData").hide();
					$.each(json.result, function(i) {
						var imageName = "default";
						if(json.result[i].iconImageName != null){
							var imageType = json.result[i].iconImageName;
							/*imageType = imageType.split(".");
							imageName = imageType[1];*/
							imageName = (json.result[i].iconImageName).substring((json.result[i].iconImageName).lastIndexOf(".") + 1, (json.result[i].iconImageName).length);

						}
							
						
						var reverseRelationshipsData = loadReverseRelationships(json.result[i].srcAssetInstanceVersionId , json.result[i].assetInstName, json.result[i].relName, json.result[i].versionName,json.result[i].versionable,imageName,json.result[i].assetId);
						$('#showReverseRelationships').append(reverseRelationshipsData);
						lazyLoadingImage();
						
						if(jQuery.inArray(json.result[i].assetName, reverseRelLegendList) == -1){
									  reverseRelLegendList.push(json.result[i].assetName);
					    			  appendData = "";
					    			 /* appendData += '<img class="ui mini spaced image" src="/repopro/semantic/images/defaultAssetIcon.svg"><a style="cursor: pointer;" onclick="legendAssetGridPage('+json.result[i].assetId+',\''+json.result[i].assetName+'\')">'+json.result[i].assetName+'</a>';*/
					    			 
					    			  appendData += '<a class="ui image label" style="font-size: 9px;word-break: break-all; margin-top:0.5em; margin-left:0.5em;background:none;" onclick="legendAssetGridPage('+json.result[i].assetId+',\''+json.result[i].assetName+'\')">';
					    			 
					    			  
					    			
					    			 
					    			  if(imageName == "default"){
					    				 
					    				  if(circularThemeColoredIcon){
					    					  appendData += '<div class="ui right spaced  image smallIconImageCircleStyle_themeCircle " style="font-size:8px;">';
					    					  if(invertAssetIconFlag){
					    						  appendData += '<img class="smallIconImageStyle invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png">'; 
					    					  }else{
					    						  appendData += '<img class="smallIconImageStyle"  src="/repopro/semantic/images/defaultAssetIcon.svg">'; 
					    					  }
					    				  }else{
					    					  appendData += '<div class="ui right spaced  image smallIconImageCircleStyle smallIconImageCircleRemove" style="font-size:8px;">';
					    					  if(invertAssetIconFlag){
					    						  appendData += '<img class="smallIconImageStyle invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png">'; 
					    					  }else{
					    						  appendData += '<img class="smallIconImageStyle"  src="/repopro/semantic/images/defaultAssetIcon.svg">'; 
					    					  }
					    				  }
					    				  
					    			  }else{
					    					if (imageName == 'PNG' || imageName == 'JPEG' || imageName == 'JPG'){
					    						imageName = imageName.toLowerCase()
					    					}

					    				  if(circularThemeColoredIcon){
					    					  appendData += '<div class="ui right spaced  image smallIconImageCircleStyle_themeCircle " style="font-size:8px;">'; 
					    					  if(invertAssetIconFlag){
					    						  appendData += '<img class="smallIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png"  data-src="/repopro/assetImages/inverted_'+json.result[i].assetId+'.'+imageName+'">';  
					    					  }else{
					    						  appendData += '<img class="smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg"  data-src="/repopro/assetImages/'+json.result[i].assetId+'.'+imageName+'">'; 
					    					  }
					    				  }else{
					    					  appendData += '<div class="ui right spaced  image smallIconImageCircleStyle smallIconImageCircleRemove" style="font-size:8px;">'; 
					    					  if(invertAssetIconFlag){
					    						  appendData += '<img class="smallIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png"  data-src="/repopro/assetImages/inverted_'+json.result[i].assetId+'.'+imageName+'">';
					    					  }else{
					    						  appendData += '<img class="smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg"  data-src="/repopro/assetImages/'+json.result[i].assetId+'.'+imageName+'">';
					    					  }
					    				  }
					    				
					    				  
					    				
					    			  }
					    			  
					    			  
					    			  appendData += '</div><span>'+json.result[i].assetName+'</span></a>';
					    			  
					    			  $("#reverseRelationshipsLegendList").append(appendData);
					    			  lazyLoadingImage();
				    	  }
						
					});
					//$("#showReverseRelationshipsLegends").hide();	
				} 
			}

		}
	});
	//getAssetInstanceVersions();
}


//load reverse relationship
function loadReverseRelationships(srcAssetInstanceVersionId,assetInstName,relName,versionName,versionable,imageName,assetId){
	var encodedAssetInstName= encodeURIComponent(assetInstName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	appendData = "";
	
	appendData += '<a class="ui label" style="padding: 0.2em 0.4em !important; margin-top:0.75em;margin-left:0.5em; font-size: 9px;" onclick="getAssetInstances('+srcAssetInstanceVersionId+',\''+encodedAssetInstName+'\')">';
	if(imageName == "default"){
		if(circularThemeColoredIcon){
			appendData += '<div class="smallIconImageCircleStyle_themeCircle">';
			if(circularThemeColoredIcon){
				appendData += '<img class="ui right spaced  image smallIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				appendData += '<img class="ui right spaced  image smallIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}else{
			appendData += '<div class="smallIconImageCircleStyle">';
			if(circularThemeColoredIcon){
				appendData += '<img class="ui right spaced  image smallIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				appendData += '<img class="ui right spaced  image smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}
		/*appendData += '<div class="smallIconImageCircleStyle">';
		appendData += '<img class="ui right spaced  image smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';*/
	}else{
		if (imageName == 'PNG' || imageName == 'JPEG' || imageName == 'JPG'){
			imageName = imageName.toLowerCase()
		}

		if(circularThemeColoredIcon){
			appendData += '<div class="smallIconImageCircleStyle_themeCircle">';
			if(invertAssetIconFlag){
				appendData += '<img class="ui right spaced  image smallIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png"  data-src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'">';
			}else{
				appendData += '<img class="ui right spaced  image smallIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg" data-src="/repopro/assetImages/'+assetId+'.'+imageName+'">';
			}
		}else{
			appendData += '<div class="smallIconImageCircleStyle">';
			if(invertAssetIconFlag){
				appendData += '<img class="ui right spaced  image smallIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" data-src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'">';
			}else{
				appendData += '<img class="ui right spaced  image smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg" data-src="/repopro/assetImages/'+assetId+'.'+imageName+'">';
			}
		}
		
		
	}
	
	if(versionable){
		/*appendData += '<a style="cursor: pointer !important; margin-left: 2em;" onclick="getAssetInstances('+srcAssetInstanceVersionId+',\''+encodedAssetInstName+'\')"><i class="retweet icon"></i>'+assetInstName+'_'+versionName+' <span style="font-size: 10px;"> ['+relName+']</span></a><br/>';*/
		/*appendData += '<a class="ui label" style="padding: 0.2em 0.4em !important;margin-top:0.75em; margin-left:0.5em; font-size: 9px;" onclick="getAssetInstances('+srcAssetInstanceVersionId+',\''+encodedAssetInstName+'\')"><div class="smallIconImageCircleStyle smallIconImageCircleRemove">';
		if(imageName == "default"){
			appendData += '<img class="ui right spaced circular image smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
		}else{
			appendData += '<img class="ui right spaced circular image smallIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+imageName+'">';
		}*/
		
		
		appendData += '</div><span style="vertical-align: -moz-middle-with-baseline;vertical-align: -webkit-baseline-middle;padding-left:1em;">'+assetInstName+'_'+versionName+' <span style="font-size: 10px;"> ['+relName+']</span></span></a>';
	
	}else{
		/*appendData += '<a style="cursor: pointer !important; margin-left: 2em;" onclick="getAssetInstances('+srcAssetInstanceVersionId+',\''+encodedAssetInstName+'\')"><i class="retweet icon"></i>'+assetInstName+' <span style="font-size: 10px;"> ['+relName+']</span></a><br/>';*/
		/*appendData += '<a class="ui label" style="padding: 0.2em 0.4em !important; margin-top:0.75em;margin-left:0.5em; font-size: 9px;" onclick="getAssetInstances('+srcAssetInstanceVersionId+',\''+encodedAssetInstName+'\')">';
		if(imageName == "default"){
			appendData += '<div class="smallIconImageCircleStyle smallIconImageCircleRemove"><img class="ui right spaced circular image smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
		}else{
			appendData += '<div class="smallIconImageCircleStyle smallIconImageCircleRemove"><img class="ui right spaced circular image smallIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+imageName+'">';
		}*/
		
		
		appendData += '</div><span style="vertical-align: -moz-middle-with-baseline;vertical-align: -webkit-baseline-middle;padding-left:1em;">'+assetInstName+'<span style="font-size: 10px;"> ['+relName+']</span></span></a>';
	}
		

	return appendData;
}


//open add review modal
function openAddReviewModal(){
	$("#submitReview").unbind();
	$("#cancelReview").unbind();
	$("#userReviewComment").val("");
	$('#ratingByUser').rating('enable').rating('setting', 'clearable', true);
	$('#ratingByUser').rating({
	    initialRating: 0,
	    maxRating: 5
	  })
	$('#addReviewAndRating').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	$("#reviewByUserName").html(loggedInUserName);
	$('#submitReview').on('click', function(){
		
		var ratingDescription = $("#userReviewComment").val().trim();
		var regex = /^[a-zA-Z0-9 \.\,]*$/;
		
		if(regex.test(ratingDescription)){
		
			var count = 0;
			$("#ratingByUser i[class='icon active']").each(function(){
	            count++;
	        });
			var obj = {
					"assetInstanceVersionId": assetInstanceVersionId,
					"rating": count,
					"username": loggedInUserName,
					"ratingDescription": ratingDescription 
					};
			
			$.ajax({
				type: "PUT",
				url: "/repopro/web/ratingmanager/updaterating",
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				complete:function(data){	
					appenddata = "";
					var json = JSON.parse(data.responseText);
					var groupId = "";
					if(json.status == "SUCCESS"){
						notifyMessage("Add new Review","Review successfully added","success");
						showRating();
						getRatingDataOnLoad();
					}
					else {
					
						notifyMessage("Add new Review","Review not added.","fail");
					}
					/*$('#addReviewAndRating').modal('hide'); //.modal('hide dimmer');
					$('#addReviewAndRating').parent().css("display", "none !important");*/
					$('#addReviewAndRating').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
	
				}
			});
			
		}else{
			notifyMessage("Add new Review","Please use only alphanumeric characters, space, \".\" and \",\" in review","fail");
			return false;
			
		}
		
	});
	
}

//get tag data
function getTagData(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/tagdetails?assetInstanceVersionId="+assetInstanceVersionId,
		dataType : "json",
		async: true,
		cache: false,
		complete : function(data) {
			setTimeout(function(){ 
				$("#tagLoadingSegment").removeClass("loading");
			}, 50);
			$('#addNewTagSegment').html("");
			var json = JSON.parse(data.responseText);
			$("#noTagDataShow").hide();
			$('#addNewTagSegment').show();
			if(json.status == "SUCCESS"){
				if(json.message != "NO TAGS FOUND BY SPECIFIED ASSET INSTANCE VERSION ID"){
					$.each(json.result, function(i) {
						$.each(json.result[i].tagNames, function(key,value){
							var tagData = loadTagData(value);
							$('#addNewTagSegment').append(tagData);
							autoId++;						
						});
					});
				}else{
					$("#addNewTagSegment").hide();
					$("#noTagDataShow").show();
				}	
				
			}else{
				$("#addNewTagSegment").hide();
				$("#noTagDataShow").show();
			}
			
			checkAccessForUserOnSuccess();
			
		}
	});
	
	
	//getRevisionHistory();
	//getCommentsData();
	//checkRelationshipAssets();
}

//add new tag
function addNewTag(){
	
	/*var flag = false;
	if(globalSettingDetailsFlag){
		flag = getLockStatus();
		if(flag){
			if(lockedBySameUser){
				flag = false;
			}else{
				notifyMessage("Lock Asset Instance","Instance "+assetInstanceName+" is alredy locked","fail");
			}
		}
		else{
			lockAssetInstance();
		}
	}*/
	
	//if(flag == false){
		$("#addNewTagInputFields").toggle('blind');
		$("#addNewTagShowButton").addClass("hideElement");
		$("#saveTagName").css('display','inline');
		$("#addNewTagName").val("");
		$("#addNewTagName").parent().removeClass("error");
	//}
}

//cancel Tag Details
function cancelTagDetails(){
	$("#addNewTagInputFields").toggle('blind');
	$("#addNewTagShowButton").removeClass("hideElement");
	$("#addNewTagName").val("");
}

//save tag details
function saveTagDetails(){
	$("#addNewTagName").parent().removeClass("error");
	var getTagName;
	addObject = {};
	
	var getNewTagName = $("#addNewTagName").val().trim();
	var diffTagName = getNewTagName.split(",");
	diffTagName = $.unique(diffTagName);
	
	diffTagName = diffTagName.map(function (el) {
		  return el.trim();
		});
	diffTagName = diffTagName.filter(function(v){return v!==''});
	diffTagName.reverse();
	
	if(diffTagName == null || diffTagName == ""){
		notifyMessage("Add new Tag","Please provide tag name(s)","fail");
		$("#addNewTagName").parent().addClass("error");
	}else{
		var flag = true;
		
		
		
		$.each(diffTagName,function(i){
			var tagName = (diffTagName[i]).trim();
			var regex = /^[a-zA-Z0-9- \-\_]*$/;
			if(regex.test(tagName) == false){
				/*if(tagName.match(/\-\_/)){
					alert("true")
					flag = true;
					return false;
				}else{*/
					flag = false;
					$("#addNewTagName").parent().addClass("error");
					notifyMessage("Add new Tag","Please use only alphanumeric characters, space, \"-\" and \"_\" in tags","fail");
				//}
			}
		});
		
		$.each(diffTagName,function(i){
			
		});
			
		$.each(diffTagName,function(i){	
			var tagName = (diffTagName[i]).trim();
			$("#addNewTagSegment > a").each(function(key){
				var data = $(this).find('span').text();
					if(data == tagName){
						flag = false;
						$("#addNewTagName").parent().addClass("error");
						notifyMessage("Add new Tag","Tag name '"+tagName+"' already added","fail");
						return false;
					}
				});	
			});
		
		
		if(flag){
			$("#addNewTagName").parent().removeClass("error");
			$('#addNewTagSegment').show();
			$("#noTagDataShow").hide();
			
			$.each(diffTagName,function(i){	
				var tagName = (diffTagName[i]).trim();
				if(!tagName == null || tagName != ""){	
					appendData = loadTagData(tagName);
					$("#addNewTagSegment").append(appendData);
					autoId++;
				}
			});
			
			$("#addNewTagName").val("");
	
			$("#addNewTagSegment > a").each(function(key){
				key++;
				getTagName = $(this).find('span').text();
				addObject[key] = getTagName;
			});
			var obj = {
					"assetInstanceVersionId": assetInstanceVersionId,
					"tagNames": addObject,
					"userId": loggedInUserId
			};
	
			$.ajax({
				type: "POST",
				url: "/repopro/web/tagdetails/taglist",
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				complete:function(data){	
					appenddata = "";
					var json = JSON.parse(data.responseText);
					var groupId = "";
					if(json.status == "SUCCESS"){
						notifyMessage("Add Tags","Tag(s) added","success");
						if($("#lockUnlockAssetInstance").hasClass("lock")){
							//$("#lockStatusMessage").html("");
							setTimeout(function(){
								unlockInstance();
							},1500);
						}
						cancelTagDetails();
					}
					else {
	
						notifyMessage("Add Tags","Error attempting to add tag(s)","fail");
					}
				}
			});
		}
			
		
	}	
}

//delete tag
function deleteTag(id){
	var deleteObj = {};
	$("#tagName_"+id).remove();
	$("#addNewTagSegment > a").each(function(key){
		key++;
		getTagName = $(this).find('span').text();
		deleteObj[key] = getTagName;
	});
	var obj = {
			"assetInstanceVersionId": assetInstanceVersionId,
			"tagNames": deleteObj,
			"userId": loggedInUserId
	};
	/*$.ajax({
		type: "POST",
		url: "/repopro/web/tagdetails/taglist",
		contentType : "application/json",
		dataType : "json",
		data : JSON.stringify(obj),
		async: false,
		complete:function(data){	
			appenddata = "";
			var json = JSON.parse(data.responseText);
			var groupId = "";
			if(json.status == "SUCCESS"){
				notifyMessage("Delete Tags","Tag deleted","success");
			}
			else {
				notifyMessage("Delete Tags","Error attempting to delete tag(s)","fail");
			}
		}
	});*/

}

/*//add new tag
function addNewTag(){
	var getNewTagName = $("#addNewTagName").val().trim();
	appendData = loadTagData(getNewTagName);
	$("#addNewTagSegment").append(appendData);
	autoId++;
	$("#addNewTagName").val("");
	
}

//save tag details
function saveTagDetails(){
	var count = 0;
	$("#tagSegment a").each(function(){
		count++;
	});
	var arr = [];
	for(i=0; i < count; i++){
		arr.push($("#tagName_"+i+" span").text());
	}
	var tagList = '';
	$.each(arr,function(key,value){
		tagList += '"'+(key+1)+'" : "'+value+'",';
	});
	tagList = "{"+tagList.replace(/^,|,$/g, "")+"}";
		var obj = {
			"assetInstanceVersionId": assetInstanceVersionId,
			"tagNames": JSON.parse(tagList),
			"userId": loggedInUserId
	};
		//console.log(obj)
	$.ajax({
		type: "POST",
		url: "/repopro/web/tagdetails/taglist",
		contentType : "application/json",
		dataType : "json",
		data : JSON.stringify(obj),
		async: false,
		complete:function(data){	
			appenddata = "";
			var json = JSON.parse(data.responseText);
			var groupId = "";
			if(json.status == "SUCCESS"){
				notifyMessage("Add new Tag","Tag successfully added","success");
			}
			else {
			
				notifyMessage("Add new Tag","Tag not added.","fail");
			}
			

		}
	});
}

//delete tag
function deleteTag(id){
	$("#tagName_"+id).remove();
}*/

//load tag
function loadTagData(getNewTagName){
	appendData = "";
	appendData = '<a class="ui label" id="tagName_'+autoId+'" style="margin-bottom:0.5em;cursor: default;"><i class="tag icon"></i> <span class="whitespaceNoTrim">'+getNewTagName+'</span> <i class="delete icon  deleteTagClass" style="display:none !important;" onclick="deleteTag('+autoId+')"></i></a>'; 
	return appendData;
}

//load guest access data from database 
var globalSettingDetailsFlag;
function loadGlobalSettingDetails(){
	
		$.ajax({
			type : "GET",
			url : "/repopro/web/globalsettings",
			dataType : "json",
			async: false,
			complete : function(data) {
				
				var json = JSON.parse(data.responseText);
				if(json.result[0].globalLockSettingFlag == 1){
					globalSettingDetailsFlag = true;
					getLockStatus();
				}else{
					globalSettingDetailsFlag = false;
					$("#lockUnlockAssetInstance").remove();
					$("#lockUnlockAssetInstanceBtn").remove();
					$("#editBtnAfterLock").hide();
				}
			}
		});
}

// get lock status
var lockFlag,lockedBySameUser;
var countdownTimerInterval;
function getLockStatus(){
	
	if(assetInstanceVersionId != 0){
			$.ajax({
				type : "GET",
				url : "/repopro/web/assetInstanceVersionManager/retAssetInstanceVersion?aivId="+assetInstanceVersionId+"&userName="+loggedInUserName,
				dataType : "json",
				async: false,
				complete : function(data) {
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						if(json.result[0].lockedBy == "" || json.result[0].lockedBy == null){
							$("#lockUnlockAssetInstance").removeClass("lock").addClass("unlock").parent().attr("data-tooltip","Click to Lock and Edit");
							lockFlag = false;
							$("#editBtnAfterLock").addClass("disabled");
						}else{
							$("#lockUnlockAssetInstance").removeClass("unlock").addClass("lock").parent().attr("data-tooltip","Click to Unlock");
							if(json.result[0].lockedBy == loggedInUserName){
								$(".lockEditing").removeClass("disabled");
								$(".propertiesLockedByOther").removeClass("disabled");
								lockedBySameUser = true;
								if(editingEnabled){
									$("#editBtnAfterLock").addClass("disabled");
								}else{
									$("#editBtnAfterLock").removeClass("disabled");
								}
								
							}else{
								$(".lockEditing").addClass("disabled");
								$(".propertiesLockedByOther").addClass("disabled");
								if(userAdminFlag == false){
									$("#lockUnlockAssetInstance").attr("onclick","").parent().addClass("disabled").css("pointer-events","none");
								}else{
									$("#lockUnlockAssetInstance").show();
								}
								lockedBySameUser = false;
								$("#editBtnAfterLock").addClass("disabled");
							}
							
							
							
		
							lockFlag = true;
							
								
								
								var countDownDate = new Date(json.result[0].lockTime).getTime();
								var now = new Date().getTime();
								 var distance = countDownDate - now;
								 $("#lockStatusMessage").html(" | <i>Locked By: </i> <b>"+json.result[0].lockedBy+"| </b><i>Unlock Time:</i> <b> "+json.result[0].lockTime).show()+"</b>"; 
								 if (distance < 0) {
								        clearInterval(countdownTimerInterval);
								        //$("#lockStatusMessageCountdown").html("EXPIRED");
								        $(".lockEditing").removeClass("disabled");
								        setTimeout(function(){
								        	//$("#lockStatusMessage").html("");
								        		 unlockInstance();
								        	
								        }, 100);
								       return false; 	
								    }
								
								/*// Update the count down every 1 second
								countdownTimerInterval = setInterval(function() {
		
								    // Get todays date and time
								    var now = new Date().getTime();
								    
								    // Find the distance between now an the count down date
								    var distance = countDownDate - now;
								    
								    // Time calculations for days, hours, minutes and seconds
								    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
								    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
								    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
								    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
								    
								    // Output the result in an element with id="demo"
								    $("#lockStatusMessageCountdown").html(days + "d " + hours + "h "+ minutes + "m " + seconds + "s ");
								    
								    // If the count down is over, write some text 
								    if (distance < 0) {
								        clearInterval(countdownTimerInterval);
								        $("#lockStatusMessageCountdown").html("EXPIRED");
								        $(".lockEditing").removeClass("disabled");
								        setTimeout(function(){
								        	//$("#lockStatusMessage").html("");
								        		 unlockInstance();
								        	
								        }, 100);
								       return false; 	
								    }
								}, 1000);
							*/
						}
					} 
				}
			});
			
			return lockFlag;
	}

}


//unlock instance
function unlockInstance(){
	callOnlyOnceForpropertiesFlag = true;
	$("#lockStatusMessage").html("");
	clearTimeout(countdownTimerInterval);
	$("#lockUnlockAssetInstance").removeClass("lock").addClass("unlock").parent().attr("data-tooltip","Click to Lock");
	url = "/repopro/web/assetInstanceVersionManager/unlockassetinstanceversion?userName="+loggedInUserName+"&aivId="+assetInstanceVersionId;
	notifyMessageTopic = "Unlock Asset Instance";
	notifyMessageBody = "The lock on this instance has expired. Please lock again before editing.";
	$.ajax({
		type : "PUT",
		url : url,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				notifyMessage(notifyMessageTopic,notifyMessageBody,"success");
				closeAllEditFieldsAfterUnlock();
			}else{
				notifyMessage(notifyMessageTopic,"Error attempting to lock / unlock "+assetInstanceName,"fail");
			}

		}
	});
}


//lock Asset Instance
function lockAssetInstance(){
	$("#lockUnlockAssetInstance").removeClass("unlock").addClass("lock").parent().attr("data-tooltip","Click to Unlock");
	url = "/repopro/web/assetInstanceVersionManager/lockassetinstanceversion?userName="+loggedInUserName+"&aivId="+assetInstanceVersionId;
	notifyMessageTopic = "Lock Asset Instance";
	notifyMessageBody = assetInstanceName+" is locked for editing";
	
	$.ajax({
		type : "PUT",
		url : url,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				notifyMessage(notifyMessageTopic,notifyMessageBody,"success");
				getLockStatus();
			}else{
				notifyMessage(notifyMessageTopic,"Error attempting to lock / unlock "+assetInstanceName,"fail");
			}

		}
	});
}

//lock for update properties
var callOnlyOnceForpropertiesFlag = true;
function propertiesEditLock(){
	/*if(callOnlyOnceForpropertiesFlag){
		var flag = false;
		if(globalSettingDetailsFlag){
			flag = getLockStatus();
			if(flag){
				if(lockedBySameUser){
					flag = false;
				}else{
					notifyMessage("Lock Asset Instance","Instance "+assetInstanceName+" is alredy locked","fail");
				}
			}
			else{
				lockAssetInstance();
			}
		}
		
		if(flag){
			callOnlyOnceForpropertiesFlag = false;
		}
		
	}*/
}



//get Revision History
function getRevisionHistory(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/revisionhistorymanager/showallrevisionhistory?assetName="+encodeURIComponent(assetName)+"&assetInstVersionId="+assetInstanceVersionId,
		dataType : "json",
		async: true,
		complete : function(data) {
			
			setTimeout(function(){ 
				$("#revisionHistoryLoadingSegment").removeClass("loading");
			}, 50);
			
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				appenData = "";
				if(json.result == "" || json.result == null){
					$("#noRevisionHistoryData").show();
					$("#gridRevisionHistoryData").hide();
					$("#noRevisionHistoryData").html('<div class="ui message">No revision history yet</div>');
				}
				else {
					$("#noRevisionHistoryData").hide();
					$("#gridRevisionHistoryData").show();
					$("#tbodyRevisionHistoryData").html("");
					$.each(json.result, function(i) {
						var imageType;
						if(json.result[i].imageName  !== null){
							/*imageName = json.result[i].imageName.split(".");
							imageType = imageName[1];*/
							imageType = (json.result[i].imageName).substring((json.result[i].imageName).lastIndexOf(".") + 1, (json.result[i].imageName).length);

						}
						
						if(loggedInUserName == "roleAnonymous"){
							$("#compareRevisionHistoryTh").remove();
						}
						var revisionData = loadRevisionHistory(json.result[i].aivRevisionHistoryId, json.result[i].revId, json.result[i].revisedOn, json.result[i].userName, json.result[i].userId, imageType,json.result[i].encryptImage); 
						$("#tbodyRevisionHistoryData").append(revisionData);
					});
					$('#gridRevisionHistoryData').DataTable( {
						 "aaSorting": [[ 1, "asc" ]],
						  "columnDefs": [
							    { "orderable": false,
							    	"targets": [0,1,2,3],
							  }
							  ]
							} );
						
				} 
			}
			lazyLoadingImage();
			checkAccessForUserOnSuccess();
		}
	});

	
	
	
}

//load Revision History
function loadRevisionHistory(aivRevisionHistoryId, revId, revisedOn, userName, userId, imageType,encImgId){
	//Chandana - 16-9-2019 Broken image
	if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
		imageType = imageType.toLowerCase()
	}
	appendData = "";
	appendData += '<tr class="revisionHistoryTR" id="revisionHistoryDetailsTR_'+aivRevisionHistoryId+'">';
	if(typeof imageType == "undefined"){
		appendData += '<td><img class="ui avatar image" src="/repopro/semantic/images/avatar/defaultUserImage.png" style="margin-right: 1em;">'+userName+'</td>';
	}else{//Swathi- Encryption - 06.01.2020
		if((encImgId == 1) && (loggedInUserName !=userName) && (loggedMapRoleFlag == 0)){
			appendData += '<td><img class="ui avatar image" src="/repopro/semantic/images/avatar/defaultUserImage.png" style="margin-right: 1em;">'+userName+'</td>';
		} else{
			appendData += '<td><img class="ui avatar image" src="/repopro/semantic/images/avatar/defaultUserImage.png" data-src="/repopro/profileImages/'+userId+'.'+imageType+'" style="margin-right: 1em;">'+userName+'</td>';
		}
	}
	var time = revisedOn.trim();
	time = time.split(" ");
	appendData += '<td>'+time[0]+'T'+time[1]+'</td>';
	appendData += '<td><a onclick="getRevisionHistoryDetails('+aivRevisionHistoryId+')" style="cursor: pointer;">'+revId+'</a></td>';
	
	if(loggedInUserName != "roleAnonymous"){
		appendData += '<td class="center aligned">';
		appendData += '<div class="ui checkbox" >';
		appendData += '<input type="checkbox" id="revisionHistoryCB_'+aivRevisionHistoryId+'" class="revisionHistoryCB" onclick="compairRevisionHistoryDetails('+aivRevisionHistoryId+',event)"> <label></label>';
		appendData += '</div></td>';
	}
	
	appendData += '</tr>';
	
	return appendData;
}

//compare Revision History Details
var compareRevisionIdList = [];
function compairRevisionHistoryDetails(aivRevisionHistoryId, event){
	//Chandana - 29/7/2019  datatable code to select multiple checkboxes
	var oTable = $('#gridRevisionHistoryData').DataTable();
	var checkBoxSelectOnDatatable = $('.revisionHistoryCB:checked', oTable.rows().nodes());
	var lengthofSelectedCheckboxes = checkBoxSelectOnDatatable.length;
	
	$('#compareRevisionHistoryModal').modal("destroy");
	if($('.revisionHistoryCB:checked').length < 3){
		if($("#revisionHistoryCB_"+aivRevisionHistoryId).prop('checked')){
			$("#revisionHistoryDetailsTR_"+aivRevisionHistoryId).addClass("positive");
			compareRevisionIdList.push(aivRevisionHistoryId);
			
		}
		else{
			$("#revisionHistoryDetailsTR_"+aivRevisionHistoryId).removeClass("positive");
			compareRevisionIdList.splice($.inArray(aivRevisionHistoryId, compareRevisionIdList),1);
		}
		//Chandana - 29/7/2019 - if selected checkboxes are more than 1 from datatable
		if($(checkBoxSelectOnDatatable).length == 2){ 
			setTimeout(function(){
				$('#compareRevisionHistoryModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
				$.ajax({
					type : "GET",
					url : "/repopro/web/revisionhistorymanager/displayrevisionhistoryforcomparison?revHistoryIds="+compareRevisionIdList+"&assetName="+encodeURIComponent(assetName)+"&username="+loggedInUserName,
					dataType : "json",
					async: false,
					complete : function(data) {
						var json = JSON.parse(data.responseText);
						if(json.status == "SUCCESS"){
							compareRevisionIdList = [];
							$.each(json.result, function(i) {
								$("#compareRevisionId_"+i).html(json.result[i].revId);
								var time = json.result[i].revisedOn.trim();
								time = time.split(" ");
								$("#compareRevisedOn_"+i).html(time[0]+"T"+time[1]);
								$("#compareRenameData_"+i).html("No values assigned");
								if((json.result[i].instanceRename) != null ){
									
									var rename = (json.result[i].instanceRename);
									rename = rename.split("<!!>");
									/*alert("rename[0]: "+rename[0])
									alert("rename[1]: "+rename[1])*/
									
									$("#compareRenameData_"+i).html("<b>Old Name: </b>"+rename[0]+"<br><b>New Name: </b>"+rename[1]);
								}
								$("#compareOverviewData_"+i).html('<div style="overflow: auto;">'+json.result[i].overviewData+'</div>');
								if(json.result[i].relationshipData == null || json.result[i].relationshipData == ""){
									$("#compareRelationshipData_"+i).html("No values assigned");
								}else{
									$("#compareRelationshipData_"+i).html(decodeURIComponent(json.result[i].relationshipData));
								}
								
								appendData = "";
								if(JSON.stringify(json.result[i].parameterDataMap) == "{}"){
									appendData = "No values assigned";
								}else{
									//console.log(json.result[i].parameterDataMap)
									 var count = Object.keys(json.result[i].parameterDataMap).length;
									
									 var dataCount = 0;
									  
									$.each(json.result[i].parameterDataMap, function(key,value){
										var arrayP = [];
										var arrayMulti = [];
										var AppendData = "";
										var taxName = "";
										var arrayMultiple = [];
										
										//Chandana 22-03-19 | compare rev strats here
										
										if (value.indexOf('~~') > -1)
										{
										var arrayMultiple = [];
										var count = 0;

										var GetMultiData = value.split(/``/g);												
																					
										count = GetMultiData.length;
										

										var arr = GetMultiData;
										var item, i;
										var line = [];
										var count = 0;
										


										for (i = 0; i < arr.length; ++i) {
											item = arr[i];
											if (item.indexOf && (item.indexOf(',') !== -1 || item.indexOf('~~') !== -1)) {
												//  item = '~~' + item.replace(/~~/g, ',') + '~~';
												//item = item.replace(/~~/g, ',') ;
											}
											line.push(item);	

										}

										var first = line[0];
										var second = line[1];
										var third = line[2];
										var fourth = line[3];
										var fifth = line[4];
										var sixth = line[5];
										var seventh = line[6];

										
										appendData += "<div style = 'display: block;  width: 100%;'> <table class='ui celled table tblrev'>"
											appendData += "<br/><b>"+key+" : </b><br/>";
											
										if(first != undefined){
											if(first.indexOf('~~') > -1){
												var splitFirst = first.split(/~~/g);
												count = splitFirst.length;
											}
										}
										if(second != undefined){
											if(second.indexOf('~~') > -1){
												var splitSecond = second.split(/~~/g);
												count = splitSecond.length;
											}
										}
										if(third != undefined){
											if(third.indexOf('~~') > -1){
												var splitthird = third.split(/~~/g);
												count = splitthird.length;
											}
										}
										if(fourth != undefined){
											if(fourth.indexOf('~~') > -1){
												var splitFourth = fourth.split(/~~/g);
												count = splitFourth.length;
											}
										}
										if(fifth != undefined){
											if(fifth.indexOf('~~') > -1){
												var splitfifth = fifth.split(/~~/g);
												count = splitfifth.length;
											}
										}
										if(sixth != undefined){
											if(sixth.indexOf('~~') > -1){
												var splitsixth = sixth.split(/~~/g);
												count = splitsixth.length;
											}
										}
										if(seventh != undefined){
											if(seventh.indexOf('~~') > -1){
												var splitseventh = seventh.split(/~~/g);
												count = splitseventh.length;
											}
										}


										for(var h=0; h<count; h++){

											appendData += '<tr>';
											if(splitFirst == undefined){
												event.stopPropagation();
												event.preventDefault();
											}
											else{
												appendData += '<td>'+splitFirst[h]+'</td>';
											}

											if(splitSecond == undefined){
												event.stopPropagation();
												event.preventDefault();
											}
											else{
												appendData += '<td>'+splitSecond[h]+'</td>';
											}

											if(splitthird == undefined){
												event.stopPropagation();
												event.preventDefault();
											}
											else{
												appendData += '<td>'+splitthird[h]+'</td>';
											}
											
											if( splitFourth == undefined || splitFourth == 'undefined'){
												event.stopPropagation();
												event.preventDefault();
											}
											else{
												appendData += '<td>'+splitFourth[h]+'</td>';
											}

											if(splitfifth == undefined){
												event.stopPropagation();
												event.preventDefault();
											}
											else{
												appendData += '<td>'+splitfifth[h]+'</td>';
											}

											if(splitsixth == undefined){
												event.stopPropagation();
												event.preventDefault();
											}
											else{
												appendData += '<td>'+splitsixth[h]+'</td>';
											}

											if(splitseventh == undefined){
												event.stopPropagation();
												event.preventDefault();
											}
											else{
												appendData += '<td>'+splitseventh[h]+'</td>';
											}

											appendData += '</tr>';

										}
										appendData += '</table></div><br/>';


										}
										 else	if (value.length > 1)
											{
											 var getData = value.split(/``/g);
										
												arrayP.push(getData);
												
												 appendData += "<div style='overflow: auto;'> <table class='ui celled table tblrev'><tr>"
													 appendData += "<br/><b>"+key+" : </b><br/>";
												for(var i = 0; i < getData.length; i++) {
													appendData += "<td>"+getData[i]+"<td>";
													
												}
												 appendData += "</tr></table></div></br>"
				
											}
										// comparision rev history ends here
									
										else{
										//5.3.18 souradip
										var data  = (value).replace(/~~/g,",");
										
										if(dataCount < (count-1)){
										
											appendData+= "<span style='color: #999999;'>"+key+" : </span><div style='overflow: auto;'>"+data+"</div><div class='ui  divider'></div>";
										}else{
											appendData+= "<span style='color: #999999;'>"+key+" : </span><div style='overflow: auto;' class='sd'>"+data+"</div>";
											
										}
										}
										
										dataCount++;
										
										/*if(value.startsWith("<pre")){
											appendData+= "<span style='color: #999999;'>"+key+" : </span><div> "+value+"</div></br>";
										}else{
											var formatted =  formatXml(value);
											formatted = formatted.trim();
											formatted =	hljs.highlightAuto(formatted);	
											
											var data  = (formatted.value).replace(/~~/g,",");
											
											appendData+= "<span style='color: #999999;'>"+key+" : </span><pre> "+data+"</pre></br>";
										}*/
										
											
										
									});
								}
									
								$("#compareParameterData_"+i).html(appendData);
								
								if(json.result[i].usedBy == null || json.result[i].usedBy == ""){
									$("#compareReverseRelData_"+i).html("No values assigned");
								}else{
									$("#compareReverseRelData_"+i).html(json.result[i].usedBy);
								}
								
								
							});

						}

					}
				});
				
				
				$(".revisionHistoryCB").prop("checked",false);
				$(".revisionHistoryTR").removeClass("positive");
				//Chandana - 29/7/2019 removing selected checkboxes after modal close
				oTable.$('input').removeAttr( 'checked' );
				oTable.$('input').removeClass("positive");
				oTable.$('.revisionHistoryTR').removeClass('positive');
				oTable.$('input').blur();
			},400);
		}
	}
	else{
		$("#revisionHistoryCB_"+aivRevisionHistoryId).prop('checked', false);
		notifyMessage("Revision History","Please select any two revisions to compare","warning");
	}
	
	
}

//get Revision History Details
function getRevisionHistoryDetails(aivRevisionHistoryId){
	
	$('#closeRevisionHistoryDetailsModal').unbind();
	$('#getRevisionHistoryDetailsModal').modal("destroy");
	$('#getRevisionHistoryDetailsModal').modal({observeChanges:true, closable: false }).modal('show').modal("refresh");
	
	//console.log("/repopro/web/revisionhistorymanager/showrevisionhistorydetails?revHistoryId="+aivRevisionHistoryId+"&username="+loggedInUserName+"&assetName="+encodeURIComponent(assetName));
		$.ajax({
		type : "GET",
		url : "/repopro/web/revisionhistorymanager/showrevisionhistorydetails?revHistoryId="+aivRevisionHistoryId+"&username="+loggedInUserName+"&assetName="+encodeURIComponent(assetName),
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$("#gridShowMoreRevisionHistoryDetailsTable tbody").html("");
				$.each(json.result, function(i) {
					var revisionDetailsData = "";
						revisionDetailsData += "<tr><td class='four wide' >Revision Id</td><td class='twelve wide'>"+json.result[i].revId+"</td></tr>";
						if(json.result[i].revisedOn == null || json.result[i].revisedOn == ""){
							revisionDetailsData += "<tr><td class='four wide'>Revised On</td><td class='twelve wide'>No values assigned</td></tr>";
						}else{
							var time = json.result[i].revisedOn.trim();
							time = time.split(" ");
							revisionDetailsData += "<tr><td class='four wide'>Revised On</td><td class='twelve wide'>"+time[0]+"T"+time[1]+"</td></tr>";
						}
						
						if(json.result[i].instanceRename == null || json.result[i].instanceRename == ""){
							revisionDetailsData += "<tr><td class='four wide'>Instance Rename</td><td class='twelve wide'>No values assigned</td></tr>";
						}else{
							var rename = json.result[i].instanceRename;
							rename = rename.split("<!!>");
							
							revisionDetailsData += "<tr><td class='four wide'>Instance Rename</td><td class='twelve wide'>";
							revisionDetailsData += "<b>Old Name: </b>"+rename[0]+"<br><b>New Name: </b>"+rename[1];
							revisionDetailsData += "</td></tr>";
						}
						
						if(json.result[i].overviewData == null || json.result[i].overviewData == ""){
							revisionDetailsData += "<tr><td class='four wide'>Overview Data</td><td class='twelve wide'>No values assigned</td></tr>";
						}else{
							revisionDetailsData += "<tr><td class='four wide'>Overview Data</td><td class='twelve wide'><div style='max-height: 10em;overflow: auto;'>"+json.result[i].overviewData+"</div></td></tr>";
						}
					
						if(json.result[i].relationshipData == "" || json.result[i].relationshipData == null){
							revisionDetailsData += "<tr><td class='four wide'>Relationship Data</td><td class='twelve wide'>No values assigned</td></tr>";
						}else{
							revisionDetailsData += "<tr><td class='four wide'>Relationship Data</td><td class='twelve wide'>"+decodeURIComponent(json.result[i].relationshipData)+"</td></tr>";
						}
						
						/*if(json.result[i].parameterData == "" || json.result[i].parameterData == null){
							revisionDetailsData += "<tr><td>Parameter Data</td><td></td></tr>";
						}else{
							revisionDetailsData += "<tr><td>Parameter Data</td><td>"+json.result[i].parameterData+"</td></tr>";
						}*/
						if(JSON.stringify(json.result[i].parameterDataMap) == "{}" ){
							revisionDetailsData += "<tr><td class='four wide'>Parameter Data</td><td class='twelve wide'>No values assigned</td></tr>";
						}else{
							revisionDetailsData += "<tr><td class='four wide'>Parameter Data</td><td class='twelve wide'>"
							$.each(json.result[i].parameterDataMap,function(key,value){
								
								var arrayP = [];
								var arrayMulti = [];
								var AppendData = "";
								var taxName = "";
								var arrayMultiple = [];
								
								//chandana 22-03-2019
								
								if (value.indexOf('~~') > -1)
								{
								var arrayMultiple = [];
								var count = 0;

								var GetMultiData = value.split(/``/g);												
																			
								count = GetMultiData.length;
								

								var arr = GetMultiData;
								var item, i;
								var line = [];
								var count = 0;
								


								for (i = 0; i < arr.length; ++i) {
									item = arr[i];
									if (item.indexOf && (item.indexOf(',') !== -1 || item.indexOf('~~') !== -1)) {
										//  item = '~~' + item.replace(/~~/g, ',') + '~~';
										//item = item.replace(/~~/g, ',') ;
									}
									line.push(item);	

								}

								var first = line[0];
								var second = line[1];
								var third = line[2];
								var fourth = line[3];
								var fifth = line[4];
								var sixth = line[5];
								var seventh = line[6];

								revisionDetailsData += "<br/><b>"+key+" : </b><br/>";
								revisionDetailsData += "<div style = 'display: block; height:auto; width: 100%;'> <table class='ui celled table tblrev'>"
									
								if(first != undefined){
									if(first.indexOf('~~') > -1){
										var splitFirst = first.split(/~~/g);
										count = splitFirst.length;
									}
								}
								if(second != undefined){
									if(second.indexOf('~~') > -1){
										var splitSecond = second.split(/~~/g);
										count = splitSecond.length;
									}
								}
								if(third != undefined){
									if(third.indexOf('~~') > -1){
										var splitthird = third.split(/~~/g);
										count = splitthird.length;
									}
								}
								if(fourth != undefined){
									if(fourth.indexOf('~~') > -1){
										var splitFourth = fourth.split(/~~/g);
										count = splitFourth.length;
									}
								}
								if(fifth != undefined){
									if(fifth.indexOf('~~') > -1){
										var splitfifth = fifth.split(/~~/g);
										count = splitfifth.length;
									}
								}
								if(sixth != undefined){
									if(sixth.indexOf('~~') > -1){
										var splitsixth = sixth.split(/~~/g);
										count = splitsixth.length;
									}
								}
								if(seventh != undefined){
									if(seventh.indexOf('~~') > -1){
										var splitseventh = seventh.split(/~~/g);
										count = splitseventh.length;
									}
								}


								for(var h=0; h<count; h++){

									revisionDetailsData += '<tr>';
									if(splitFirst == undefined){
										event.stopPropagation();
										event.preventDefault();
									}
									else{
										revisionDetailsData += '<td>'+splitFirst[h]+'</td>';
									}

									if(splitSecond == undefined){
										event.stopPropagation();
										event.preventDefault();
									}
									else{
										revisionDetailsData += '<td>'+splitSecond[h]+'</td>';
									}

									if(splitthird == undefined){
										event.stopPropagation();
										event.preventDefault();
									}
									else{
										revisionDetailsData += '<td>'+splitthird[h]+'</td>';
									}

									if( splitFourth == undefined){
										event.stopPropagation();
										event.preventDefault();
									}
									else{
										revisionDetailsData += '<td>'+splitFourth[h]+'</td>';
									}

									if(splitfifth == undefined){
										event.stopPropagation();
										event.preventDefault();
									}
									else{
										revisionDetailsData += '<td>'+splitfifth[h]+'</td>';
									}

									if(splitsixth == undefined){
										event.stopPropagation();
										event.preventDefault();
									}
									else{
										revisionDetailsData += '<td>'+splitsixth[h]+'</td>';
									}

									if(splitseventh == undefined){
										event.stopPropagation();
										event.preventDefault();
									}
									else{
										revisionDetailsData += '<td>'+splitseventh[h]+'</td>';
									}

									revisionDetailsData += '</tr>';

								}
								revisionDetailsData += '</table></div>';


								}
								 else	if (value.length > 1)
									{
									 var getData = value.split(/``/g);
								
										arrayP.push(getData);
										 revisionDetailsData += "<br/><b>"+key+" : </b><br/>";
										 revisionDetailsData += "<div style='overflow: auto;'> <table class='ui celled table tblrev'><tr>"
										for(var i = 0; i < getData.length; i++) {
											 revisionDetailsData += "<td>"+getData[i]+"<td>";
											
										}
										 revisionDetailsData += "</tr></table></div>"
		
									}
								else{
							
								//value = decodeURIComponent(value);
								
								/*if(value.startsWith("<pre")){
									revisionDetailsData += "<br/><b>"+key+" : </b><div>"+value+"</div>";
								}else{
									var formatted =  formatXml(value);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);
									
									var data =  (formatted.value).replace(/~~/g,",");
									revisionDetailsData += "<br/><b>"+key+" : </b><pre>"+data+"</pre>";
								}*/
								//5.3.18 souradip
								var data =  (value).replace(/~~/g,",");
								//alert(data);
								revisionDetailsData += "<br/><b>"+key+" : </b><div style='overflow: auto;'>"+data+"</div>";
								
								}
							});
							revisionDetailsData += "</td></tr>"
						}
						
						
						if(json.result[i].usedBy == "" || json.result[i].usedBy == null){
							revisionDetailsData += "<tr><td class='four wide'>Reverse Rel Data</td><td class='twelve wide'>No values assigned</td></tr>";
						}else{
							revisionDetailsData += "<tr><td class='four wide'>Reverse Rel Data</td><td class='twelve wide'>"+json.result[i].usedBy+"</td></tr>";
						}
						$("#gridShowMoreRevisionHistoryDetailsTable tbody").append(revisionDetailsData);
				});

			}

		}
	});
	
		
}

//add taxonomy
addedTaxonomy = [];
assignedTaxId = [];
var taxFlag = true;
function openAssignTaxonomyModal(){
	
	/*
	var flag = false;
	if(globalSettingDetailsFlag){
		flag = getLockStatus();
		if(flag){
			if(lockedBySameUser){
				flag = false;
			}else{
				notifyMessage("Lock Asset Instance","Instance "+assetInstanceName+" is alredy locked","fail");
			}
		}
		else{
			lockAssetInstance();
		}
	}
	
	if(flag == false){
	
	*/
	
	
		$('#assignTaxonomyModal').modal("destroy");
		$("#btnSubmitAssignTaxonomy").unbind();
		$("#btnCancelAssignTaxonomy").unbind();
		//$('#addNewTaxonomySegment').html(''); // souradip
		//$('#assignTaxonomyModal').modal('setting', 'closable', false).modal('show');
		 
		 $('#assignTaxonomyModal').modal({observeChanges : true}).modal('show').modal('refresh'); /*Hema 01.Dec.2017*/

		//souradip 9.7.18
		 assignedTaxId.length = 0;
		 
		 $.each(taxFromBackend,function(i){
			   assignedTaxId.push(taxFromBackend[i].taxId);
		   });
		 
		if(taxFlag){
			
			taxFlag = false;
			jQuery.ajax({
				type : "GET",
				url : "/repopro/web/taxonomy/getAssetTaxonomy?assetId="+assetId,
				dataType : "json",
				contentType : 'application/json',
				async : false,
				complete : function(data) {
					
					json = JSON.parse(data.responseText);
					if(json.message == "TAXONOMY_DATA_OBTAINED"){
						$("#btnSubmitAssignTaxonomy").removeClass('disabled');
						$("#btnSubmitAssignTaxonomyNewInstance").removeClass('disabled');
						
						$('#loadingDivTree').hide();
						$('#tree1').show();
						$('#tree1').tree({
							data : json.result,
							autoOpen : false
						});
						
						
						
						 jQuery('.jqtree-title').each(function(e){
							  var item = jQuery(this);
							  item.css('display','inline-block');
							  var valTax = jQuery(this).text();
							  var valTax1 = valTax.split("|");
							  var val = valTax1[0];
							  var val1 = valTax1[1];
							  jQuery(this).text(val);
							  item.parent().append("<span id="+val1+" class='someCls'></span>");
							  jQuery(this).addClass('treeViewElement');
							  
							  jQuery(this).unbind("click");
							  
							  
							  $('#addTaxonomySegment').html("");
							  
							  /*jQuery(this).on("click",function(h){
								  $('#addTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\')"></i></a>');
							  })*/
							 //  assignedTaxId.length = 0;
							  /*********souradip 4.5.18********/ 
							  
							 /* $.each(taxFromBackend,function(i){
								   console.log(taxFromBackend[i].taxId)
								   assignedTaxId.push(taxFromBackend[i].taxId);
									 
							   });*/
							  
							 /* $("#addNewTaxonomySegment > a").each(function(i){
								  
								  var id = $(this).attr("id");
								  id = id.split("_");console.log(id[1]);
								  assignedTaxId.push(id[1]);
							  });*/
							   
							   
							  jQuery(this).click(function(e){
									 jQuery(this).parents().find('.jqtree-element').parent().children().find('.someCls').addClass("hierarchy");
									 if(document.getElementById('add_hierarchy_taxonomy').checked == false){
										//souradip 14/09/17
										 var flag = true;
										 $.each(assignedTaxId,function(i){
											 if(parseInt(val1) == assignedTaxId[i]){
												 
												 flag = false;
											 }
											 
										 });
										
										 if(flag){
											 if(jQuery.inArray(parseInt(val1),assignedTaxId) == -1){
												 assignedTaxId.push(parseInt(val1));
												 $('#addTaxonomySegment').append('<a class="ui label hideShowAnchorTag taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\')"></i></a>');
											  }else{
												 notifyMessage("Add Taxonomy","This taxonomy is already assigned","fail");
											 } 
										 }else{
											 notifyMessage("Add Taxonomy","This taxonomy is already assigned","fail");
										 }
												 
										 
								 	/*if(jQuery('#addTaxonomySegment a').length == 1){
											jQuery('.hideShowAnchorTag').show();
										}else{
											jQuery('.hideShowAnchorTag').hide();
										} */
									}else{ 
													 jQuery.ajax({
														    type : "GET", 
														    url :'/repopro/web/assetInstanceVersionManager/getHierarchyForTaxonomy?taxonomyId='+val1, 
														    data : { 'taxonId':val1 },      
														    dataType: "json", 
														    cache : false, 
														    success : function(data){
																    	var assignedtaxonomyName = data.result[0].label;
																    	if(assignedtaxonomyName == 'Empty'){
																    		$('#addTaxonomySegment').html("<div class='ui warning message'>No Data</div>");
																    	}else{
																    		$.each(data.result, function(i){ 
																    			// for(var count = 0; count < data.result[i].length; count++){
																    			if(data.result[i]!= 'Root|1'){
																    				var valTax1 = data.result[i].label.split("|");
																    				var val = valTax1[0];
																    				var val1 = valTax1[1];
																    				jQuery('.hierarchy').each(function(e){
																    					var abc = jQuery(this).attr('id');
																    					if(val1 == abc){
																    						if(jQuery.inArray(parseInt(val1),assignedTaxId) == -1){
																    							assignedTaxId.push(parseInt(val1)); 
																    							$('#addTaxonomySegment').append('<a class="ui label hideShowAnchorTag taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\')"></i></a>');
																    						}
																    					}
																    				});
																    			}
		
																    			// }
																    		});
																    	}
														    	 },
														    	error: function(data){
														    	} 
														    });
													 
													 
								if(jQuery.inArray(parseInt(val1),assignedTaxId) == -1){
								    	assignedTaxId.push(parseInt(val1));
								    	$('#addTaxonomySegment').append('<a class="ui label hideShowAnchorTag taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\')"></i></a>');
								}else{
									 notifyMessage("Add Taxonomy","This Taxonomy is already assigned","fail");
								}
								/*if(jQuery('#addTaxonomySegment a').length == 1){
									jQuery('.hideShowAnchorTag').show();
								}else{
									jQuery('.hideShowAnchorTag').hide();
								}*/
								   	}});
							  
							  
							  jQuery(this).css('pointer','cursor');
						 });
					}else{
						$("#showTreeDataEdit").html('<div class="ui message">No taxonomies added yet</div>');
						$("#btnSubmitAssignTaxonomy").addClass('disabled');
						$("#btnSubmitAssignTaxonomyNewInstance").addClass('disabled');
						$("#addTaxonomySegment").hide();
					}
					
				}
			});	
		}
		//to get unused taxonomies
		 /*jQuery("#hideTaxId").change(function(e){
				
				  var taxinList = new Array;
				    jQuery.ajax({
				     url: '/repopro/web/taxonomy/getTaxonomiesUsedByAssets',
				     dataType: "json",
				     async: false,
				     success: function(data)
				    {
				     // actually here success is error portion and error is success (sending response in opposite way)
				    
				     }, 
				    
				    error: function(err){
				    	var json = JSON.parse(err.responseText);
				    	  var taxonIds = "";
				    	  var taxonIdsSplitted = "";
				    	 $.each(json.result, function(i) {
				    		taxonIds = json.result[i].label;
				    		taxonIdsSplitted = taxonIds.split('|');
				    		taxonIdsSplitted = taxonIdsSplitted[1];
						    taxinList.push(parseInt(taxonIdsSplitted));
				    		
				    	 })
				    	 
				    	  if(jQuery('#hideTaxId').is(':checked')){
				  		    jQuery('.jqtree-title').each(function(e){
				  		     var taxId = jQuery(this).next().attr('id');
				  		     if(jQuery.inArray(parseInt(taxId),taxinList) == -1){
				  		     jQuery(this).parent().parent().hide();
				  		     jQuery(this).parent().parent().css('background-position','0 -1766px');
				  		     
				  		     if(jQuery(this).parent().parent().parent().parent().children().find('li').css('display') == 'none'){
				  		     jQuery(this).parent().parent().parent().parent().children().find('a').hide();
				  		     }
				  		     }else{
				  		     jQuery(this).parent().parent().show();
				  		     jQuery(this).parent().parent().css('background-position','0 -1766px');
				  		     jQuery(this).parent().parent().parent().parent().children().find('a').show();
				  		     }
				  		   });
				  		   }
				  		   else{
				  		   jQuery('.jqtree-title').each(function(e){
				  		     jQuery(this).parent().parent().show();
				  		     jQuery(this).parent().parent().css('background-position','');
				  		     jQuery(this).parent().parent().parent().parent().children().find('a').show();
				  		   });
				  		   }
				    }
				  });
					 
			   });*/
		 
				
		
			// Hema
			$('#addTaxonomySegment').html("");
			for (var h = 0; h < taxFromBackend.length; h++) {
		    $('#addTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+taxFromBackend[h].taxId+'_'+taxFromBackend[h].taxName.replace(/ /g,"_")+'" id="taxonomyName_'+taxFromBackend[h].taxId+'_'+taxFromBackend[h].taxName+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+taxFromBackend[h].taxName+' <i class="delete icon" onclick="deleteTaxonomy('+taxFromBackend[h].taxId+',\''+taxFromBackend[h].taxName+'\')"></i></a>');
		
			}
			
			
		
			var taxIdsArr = [];
		$('#btnSubmitAssignTaxonomy').on('click', function(){
			//CHANDANA 07-06-2019 (KEYBOARD SHORTCUT)
			if($('#btnSubmitAssignTaxonomy').hasClass('disabled')){
				$('#btnSubmitAssignTaxonomy').blur();
				return false;
		}
			taxIdsArr.length = 0;
			var TaxId = "";
			var TaxName = "";
			var taxName = "";
			$('#addNewTaxonomySegment').html('');
			taxFromBackend.length = 0;
			/*********** souradip ********** 4.5.18***********/
			$('.assignTax a').each(function(i){
				var taxData = $(this).attr('id');
				taxData = taxData.split('_');
				TaxId = taxData[1];
				taxIdsArr.push(TaxId);
				taxName = taxData[2];
				//console.log(taxName);
				taxFromBackend.push({"taxId": TaxId, "taxName": taxName});
				$('#addNewTaxonomySegment').append('<a class="ui label" onclick="navigateToClickedTaxonomy('+TaxId+',\''+taxName+'\')" id="taxonomyName_'+TaxId+'_'+taxName.replace(/ /g,"_")+'" style="margin-bottom:0.5em;"><span style="display:none;">'+TaxId+'</span><i class="fork icon"></i>'+taxName+'</a>');
			});
			
			
			
			
			
			
			/*// PUT METHOD
			$.ajax({
				type: "PUT", 
				url: '/repopro/web/assetInstanceVersionManager/assigntaxonomy?assetInstVersionId='+assetInstanceVersionId+'&taxId='+taxIdsArr+'&versionable='+versionable+'&versionName='+versionName+'&assetInstName='+encodeURIComponent(assetInstanceName),
				contentType : "application/json",
				dataType : "json",
				async: false,
				complete:function(data){	
					appenddata = "";
					var json = JSON.parse(data.responseText);
					var msg = json.message;
					msg = msg.replace(/_/g, ' ');
					if(json.status == "SUCCESS"){
						notifyMessage("Assign Taxonomy","Assigned taxonomy updated","success");
						if($("#lockUnlockAssetInstance").hasClass("lock")){
							                           // $("#lockStatusMessage").html("");
							                            setTimeout(function(){
							                                unlockInstance();
							                            },1500);
							                        }
					}
					else {
						notifyMessage("Assign Taxonomy",msg,"fail");
					}
				}
	
			});*/
			/*$('#assignTaxonomyModal').modal('hide').modal('hide dimmer');*/
			$('#assignTaxonomyModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
			//$('#addNewTaxonomySegment').html(''); //souradip
			//getTaxonomyDataOnLoad();
			
		});
		
		
		$("#btnSubmitAssignTaxonomyNewInstance").on('click',function(){
			$("#addNewTaxonomySegment").html("");
			taxIdsArr.length = 0;
			var TaxId = "";
			var TaxName = "";
			taxFromBackend.length = 0;
			$('.assignTax a').each(function(i){
				var taxData = $(this).attr('id');
				//alert(taxData)
				taxData = taxData.split('_');
				//console.log(taxData[2])
				//$("#addNewTaxonomySegment").append('<a class="ui label" id="taxdata_'+taxData[1]+'_'+taxData[2]+'">'+taxData[2]+'</a>');
				$('#addNewTaxonomySegment').append('<a class="ui label" onclick="navigateToClickedTaxonomy('+taxData[1]+',\''+taxData[2]+'\')" id="taxonomyName_'+taxData[1]+'_'+(taxData[2]).replace(/ /g,"_")+'" style="margin-bottom:0.5em;"><span style="display:none;">'+taxData[1]+'</span><i class="fork icon"></i>'+taxData[2]+'</a>');
				TaxId = taxData[1];
				taxIdsArr.push(TaxId);
				taxFromBackend.push({"taxId": taxData[1], "taxName": taxData[2]});
			});
			//console.log(taxIdsArr)
			
			$('#assignTaxonomyModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
		});
		
	
	//}
		
		$("#btnCancelAssignTaxonomy").on("click",function(){
			$('#assignTaxonomyModal').modal("hide");
			$('#assignTaxonomyModal').modal("destroy");
		});
	
}

//delete taxonomy
function deleteTaxonomy(id,val){
	$(".taxonomyNameClass_"+id+"_"+val.replace(/ /g,"_")).remove();
	assignedTaxId.splice( $.inArray(id, assignedTaxId), 1 );
}


//change Asset Inst Name
function changeAssetInstName(){
	$('#editAssetInstName').focus(); //CHANDANA -06-06-2019(FOCUSING INPUT FOR UPDATE ON KEYPRESS)
	var assetInstname = $("#assetInstanceTitle").attr("title").trim();
	$("#editAssetInstName").val(assetInstname);
	$("#assetInstanceTitle").hide();
	$("#editAssetInstNameInputField").show();
	$("#noChangeAssetInstName").show();
	$("#deleteNewlyCreatedInstance").hide();
	$("#assetInstanceVersionIdTitle").hide();
	//Chandana
	$("#divVersionable").css("visibility",'hidden').css("margin-left",'-4em');
	$("#editAssetInstName").parent().removeClass("error");
	$("#divVersionable").css("visibility","hidden");
	$("#multiUseDropdown").css("visibility","hidden");
}

//update Asset Inst Name
function updateAssetInstName(){
	//alert("upadate  ");
	$("#editAssetInstName").parent().removeClass("error");
	var newAssetInstName = $("#editAssetInstName").val().trim();
	
	if(newAssetInstName == "" || newAssetInstName  == null){
		$("#editAssetInstName").parent().addClass("error");
		notifyMessage("Rename Instance","Please provide the instance name","fail");
	}else{
		var flag = true;
		/*var specialCharRegexStr = /^[\u00D8-\u00F6a-zA-Z0-9:'"+#$/&(),-_.@\s]+$/;
		if(specialCharRegexStr.test(newAssetInstName)){
			flag = true;
		}else{
			flag = false;
			$("#editAssetInstName").parent().addClass("error");
			notifyMessage("Rename Instance","Special characters except ':'\"+#$/\&(),-_.@' are not allowed","fail");
		}*/
		
		
		var iChars = "`!%^*=[];{}|<>?~";
		  
		  for (var i = 0; i < newAssetInstName.length; i++){
		  	if (iChars.indexOf(newAssetInstName.charAt(i)) != -1){
		  		$("#editAssetInstName").parent().addClass("error");
		  		notifyMessage("Rename Instance","Special characters except ':'\"+#$/\&(),-_.@' are not allowed","fail");
		  		flag = false;
		  		return false;
		  	}
		  }
		  //console.log(encodeURIComponent(newAssetInstName))
		  //console.log("without encoding:   "+ decodeURIComponent(encodeURIComponent(newAssetInstName)))
		if(flag){
			$("#editAssetInstName").parent().removeClass("error");
			$(".assetInstanceMainLoaderSegment").css("pointer-events", "auto");
			var obj = {
					"assetName": encodeURIComponent(assetName),
					"assetInstName": encodeURIComponent(assetInstanceName),
					"assetInstId": assetInstanceId,
					"versionName": versionName,
					"assetId": assetId 
		
					};
			var url = "/repopro/web/assetInstance/updateAssetInstanceName?userId="+loggedInUserId+"&newAssetInstanceName="+encodeURIComponent(newAssetInstName);
			$.ajax({
				type: "PUT",
				url: url,
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				complete:function(data){	
					appenddata = "";
					var json = JSON.parse(data.responseText);
					var msg = json.message;
					msg = msg.replace(/_/g, ' ');
					if(json.status == "SUCCESS"){
						$("#assetInstanceTitle").html(newAssetInstName);
						localStorage.setItem("assetInstanceName",newAssetInstName);
						assetInstanceName = localStorage.getItem("assetInstanceName");
						notifyMessage("Update Asset Instance Name","Asset Instance name updated","success");
						noChangeAssetInstName();
						getAssetInstances(assetInstanceVersionId,assetInstanceName);
					}
					else {
						if(json.message == "ASSET_INST_NAME_ALREADY_EXISTS"){
							$("#editAssetInstName").parent().addClass("error");
							notifyMessage("Update Asset Instance Name","Asset Instance by name '"+newAssetInstName+"' already exists. Please provide another name.","fail");
						}else{
							notifyMessage("Update Asset Instance Name",msg,"fail");
							noChangeAssetInstName();
						}
						
						
					}
				}
		
			});	
			
				
		}	
			
	}
		
	
}


//no Change Asset Inst Name
function noChangeAssetInstName(){
	$("#editAssetInstName").popup("hide");
	$("#assetInstanceTitle").show();
	$("#editAssetInstNameInputField").hide();
	$("#assetInstanceVersionIdTitle").show();
	
	if(versionable){
		$("#divVersionable").show();
		$("#divVersionable").css("visibility","visible");
	}
	$("#multiUseDropdown").css("visibility","visible");	
	
}

//open Asset Instance Access Modal
assetInstanceAccessGroupList = [];
var categoryWiseArr = [];
function openAssetInstanceAccessModal(){
	assetInstanceAccessGroupList.length = 0;
	$('#updateAssetInstanceAccessModal').modal("destroy");
	$('#submitAssetInstanceAccess').unbind();  //add submit button id
    $('#cancelAssetInstanceAccess').unbind();
   // $('#updateAssetInstanceAccessModal').modal('setting', 'closable', false).modal('show').modal('refresh');
    $('#updateAssetInstanceAccessModal').modal({observeChanges : true}).modal('show').modal('refresh'); /*Hema 01.Dec.2017*/

    $("#updateAssetInstanceAccessModalInstanceName").text(assetInstanceName);
    
    $.ajax({
		type : "GET",
		url : '/repopro/web/assetInstanceVersionManager/viewGroupsWithSingleAIAccess?userName='+loggedInUserName+'&aivId='+assetInstanceVersionId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				//console.log("json.result : " + JSON.stringify(json.result));
				$("#gridAssetInstanceAccessData table tbody").html("");
				if(json.result == "" || json.result == null){
					$('#gridAssetInstanceAccessData').hide();
					$('#noGridData_AssetInstanceAccessData').show();
				}
				else {
					$('#noGridData_AssetInstanceAccessData').hide();
					$('#gridAssetInstanceAccessData').show();
				$.each(json.result, function(i) {
					assetInstanceAccessGroupList.push(json.result[i].groupId);
					var getAssetInstanceAccessData = loadAssetInstanceAccessData(json.result[i].groupId, json.result[i].groupName, json.result[i].editAccess, json.result[i].viewAccess, json.result[i].deleteAccess);
					$("#gridAssetInstanceAccessData table tbody").append(getAssetInstanceAccessData);
				});
				}

			}

		}
	});
    $('#gridAssetInstanceAccessData table tbody tr').each(function(i){
			
        var $tds = $(this).find('td'),
        groupId = $tds.eq(0).attr("id"),
        groupId = groupId.split("_")[1];
        groupId = parseInt(groupId);

          	$('input[id=editCB_'+groupId+']').on('click',function(){
          		$('input[id=viewCB_'+groupId+']').prop("checked", true );
  			});
          	$('input[id=viewCB_'+groupId+']').on('click',function(){
          		if(!$('input[id=viewCB_'+groupId+']').is(':checked')){
          			$('input[id=editCB_'+groupId+']').prop("checked", false );
              		$('input[id=deleteCB_'+groupId+']').prop("checked", false );
          		}
  			});
          	$('input[id=deleteCB_'+groupId+']').on('click',function(){
          		$('input[id=viewCB_'+groupId+']').prop("checked", true );
  			});
        });
    
    $("#submitAssetInstanceAccess").on("click",function(){
		    	categoryWiseArr.length = 0;
		    	$.each(assetInstanceAccessGroupList,function(i){
		    		var editFlag , viewFlag , deleteFlag;
		    		if($("#editCB_"+assetInstanceAccessGroupList[i]).prop("checked")){
		    			editFlag = 1;
		    		}else{
		    			editFlag = 0;
		    		}
		    		
		    		if($("#viewCB_"+assetInstanceAccessGroupList[i]).prop("checked")){
		    			viewFlag = 1;
		    		}else{
		    			viewFlag = 0;
		    		}
		    		if($("#deleteCB_"+assetInstanceAccessGroupList[i]).prop("checked")){
		    			deleteFlag = 1;
		    		}else{
		    			deleteFlag = 0;
		    		}
		
		    		categoryWiseArr.push({"assetInstversionId":assetInstanceVersionId,"groupId":assetInstanceAccessGroupList[i],"editAccess":editFlag,"viewAccess":viewFlag,"deleteAccess":deleteFlag});
		    		
		    	});
		    	
		    	$.ajax({
		    		type: "PUT",
		    		url: "/repopro/web/assetInstanceVersionManager/saveGroupsAccessSingleAISubmit?aivId="+assetInstanceVersionId,
		    		contentType : "application/json",
		    		dataType : "json",
		    		data : JSON.stringify(categoryWiseArr),
		    		async: false,
		    		complete:function(data){	
		    			appenddata = "";
		    			var json = JSON.parse(data.responseText);
		    			var msg = json.message;
		    			msg = msg.replace(/_/g, ' ');
		    			if(json.status == "SUCCESS"){
		    				/*$('#updateAssetInstanceAccessModal').modal('hide').modal('destroy'); //.modal('hide dimmer');
		    				$('#updateAssetInstanceAccessModal').parent().css("display", "none !important");*/
		    				$('#updateAssetInstanceAccessModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
		    				notifyMessage("Update Asset Instance Access","Update Asset Instance Access","success");
		    				
		    			}
		    			else {
		    				notifyMessage("Update Asset Instance Access",msg,"fail");
		    			}
		    		}
		
		    	});	
    	
    });
    
}

//load Asset Instance Access Data
function loadAssetInstanceAccessData(groupId, groupName, editAccess, viewAccess, deleteAccess){
	appendData = "";
	appendData += '<tr>';
	appendData += '<td class="center aligned" id="groupName_'+groupId+'">'+groupName+'</td>';
	appendData += '<td class="center aligned"><div class="ui checkbox">';
	if(editAccess == 0){
		appendData += '<input type="checkbox" id="editCB_'+groupId+'" name="example"><label></label>';
	}else{
		appendData += '<input type="checkbox" id="editCB_'+groupId+'" name="example" checked><label></label>';
	}
	appendData += '</div></td>';
	appendData += '<td class="center aligned"><div class="ui checkbox">';
	if(viewAccess == 0){
		appendData += '<input type="checkbox" id="viewCB_'+groupId+'" name="example"><label></label>';
	}else{
		appendData += '<input type="checkbox" id="viewCB_'+groupId+'" name="example" checked><label></label>';
	}
	appendData += '</div></td>';
	appendData += '<td class="center aligned"><div class="ui checkbox">';
	if(deleteAccess == 0){
		appendData += '<input type="checkbox" id="deleteCB_'+groupId+'" name="example"><label></label>';
	}else{
		appendData += '<input type="checkbox" id="deleteCB_'+groupId+'" name="example" checked><label></label>';
	}
	appendData += '</div></td>';
	appendData += '</tr>';
	return appendData;

}

//check relationship
function checkRelationshipAssets(){
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstanceVersionManager/retDestAssetsForSrcAsset?srcAssetName="+encodeURIComponent(assetName),
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				appendData = "";
				var assetList = [];
				$.each(json.result,function(i){
					if(jQuery.inArray(json.result[i].assetName+"~~"+json.result[i].assetId, assetList) == -1){
						assetList.push(json.result[i].assetName+"~~"+json.result[i].assetId);
					}
				});
				if(assetList.length == 0){
					$("#toggleEditRelationshipButton").addClass("hideElement");
					$("#noDataForEditRelationshipTree").show();
				}
					
				
			}
		}
	});
}

//cancel Assigned Relationships
function cancelAssignedRelationships(){
	newAssignedRelationships.length = 0;
	editRelationshipTreeData();
	$("#toggleEditRelationshipButton").removeClass("hideElement");
}


//edit Relationship Tree Data
var globalAssignedRelationshipsList = [];
var removeAssignedRelationshipsList = [];
function editRelationshipTreeData(){
	$("#editRelationshipTree").toggle('blind');
	/*var flag = false;
	if(globalSettingDetailsFlag){
		flag = getLockStatus();
		if(flag){
			if(lockedBySameUser){
				flag = false;
			}else{
				notifyMessage("Lock Asset Instance","Instance "+assetInstanceName+" is already locked","fail");
			}
		}
		else{
			lockAssetInstance();
		}
	}
	if(flag == false){	*/
	
			
			/*$('#editRelationshipTree').transition({
				 	animation : 'slide down',
				    duration  : 350
			});*/
			
			$("#editRelationshipTree").toggleClass('visible');
			if($("#editRelationshipTree").hasClass('visible')){
				
				
					
						$("#toggleEditRelationshipButton").addClass("hideElement");
						$.ajax({
							type : "GET",
							url: "/repopro/web/assetInstanceVersionManager/retDestAssetsForSrcAsset?srcAssetName="+encodeURIComponent(assetName),
							dataType : "json",
							async: false,
							complete : function(data) {
								var json = JSON.parse(data.responseText);
								if(json.status == "SUCCESS"){
									appendData = "";
									var assetList = [];
									$.each(json.result,function(i){
										if(jQuery.inArray(json.result[i].assetName+"~~"+json.result[i].assetId, assetList) == -1){
											assetList.push(json.result[i].assetName+"~~"+json.result[i].assetId);
										}
									});
									if(assetList.length == 0){
										//$("#toggleEditRelationshipButton").hide();
										$("#gridDataEditRelationshipTree").remove();
										$("#noDataEditRelationshipTree").show();
									}else{
										
										var selectedData = "";
										appendData += '<select class="ui dropdown" id="getInstancesOfSelectedAsset" >';
										appendData += '<option value="">Select Asset</option>'
										$.each(assetList,function(i){
											var arr = assetList[i].split("~~");
											if(i == 0){
												selectedData = arr[1];
											}
											appendData += '<option value="'+arr[1]+'">'+arr[0]+'</option>';
										});
										appendData += '</select>';
										
										$("#loadInstancesOfSelectedAssetDropDown").html(appendData);
										$("#getInstancesOfSelectedAsset").dropdown();
									}
										
									
								}
							}
						});
						
						$("#relationAvailableAssetInstance").html("");
						/*var selectedAssetId = $("#getInstancesOfSelectedAsset").val();
						$.ajax({
							type : "GET",
							url: "/repopro/web/assetInstanceVersionManager/retAvailableAssetRelationship?srcAssetId="+assetId+"&destAssetId="+selectedAssetId+"&userName="+loggedInUserName+"&srcAssetInstId="+assetInstanceId,
							dataType : "json",
							async: false,
							complete : function(data) {
								var json = JSON.parse(data.responseText);
								if(json.status == "SUCCESS"){
									$("#relationAvailableAssetInstance").html("");
									$.each(json.result,function(i){
										appendData = "";
										appendData = '<p title="'+json.result[i].assetInstanceName+'" id="'+json.result[i].destAssetInstVersionId+'_'+json.result[i].assetrelationShipId+'" onclick="addToAssignedRelationships(this)"><a>'+json.result[i].assetInstanceName+'</a></p>';
										$("#relationAvailableAssetInstance").append(appendData);
									});
									
								}
							}
						});*/
						$.ajax({
							type : "GET",
							url: "/repopro/web/assetInstanceVersionManager/retAssignedRelationship?aivId="+assetInstanceVersionId,
							dataType : "json",
							async: false,
							complete : function(data) {
								var json = JSON.parse(data.responseText);
								if(json.status == "SUCCESS"){
									$("#assignedRelationships").html("");
									globalAssignedRelationshipsList.length = 0;
									$.each(json.result,function(i){
										if(json.result[i].relationShipName != "composition" && json.result[i].relationShipName != "aggregation"){	
											appendData = "";
											appendData += '<a class="ui label" style="margin-bottom:0.5em;" id="assign_'+json.result[i].destAssetInstVersionId+'_'+json.result[i].assetrelationShipId+'">';
											if(json.result[i].versionable == 1){
												appendData += '<i class="tag icon"></i> <span>'+json.result[i].assetInstanceName+'_'+json.result[i].versionName+' [<span class="relDescTextStyle"> '+json.result[i].descrption+' </span>] </span> ';
											}else{
												appendData += '<i class="tag icon"></i> <span>'+json.result[i].assetInstanceName+' [ <span class="relDescTextStyle">'+json.result[i].descrption+' </span>] </span> ';
											}
												
											
											appendData += '<i class="delete icon" onclick="removeFromAssignedRelationship('+json.result[i].destAssetInstVersionId+','+json.result[i].assetrelationShipId+')"></i></a>';
											globalAssignedRelationshipsList.push(json.result[i].destAssetInstVersionId+'_'+json.result[i].assetrelationShipId);
											$("#"+json.result[i].destAssetInstVersionId+'_'+json.result[i].assetrelationShipId).hide();
											$("#assignedRelationships").append(appendData);
										}
									});
								}
							}
						});
					
				
			}
	//}
	/*$.each(globalAssignedRelationshipsList,function(i){
		$("#"+globalAssignedRelationshipsList[i]).hide();
	});*/
	
	
}

//add To Assigned Relationships
var newAssignedRelationships = []; 
function addToAssignedRelationships(obj){
	var id = $(obj).attr("id");
	var assetInstName = $("#"+id+" a").text();
	assetInstName = assetInstName.split("[");
	var assetRelName = (assetInstName[1]).replace("]",'');
	
	var arr = id.split("_");
	//Chandana 2/5/2019
	 $("#"+id).addClass('InsAdd');
	 $('html, body').animate({
	        scrollTop: $("#assignedRelationships").offset().top-500
	    }, 500);
	 
	appendData = "";
	//chandana 26-04-2019
	appendData += '<a class="ui label blue basic" style="margin-bottom:0.5em;" id="assign_'+id+'">';
	appendData += '<i class="tag icon "></i> <span>'+assetInstName[0]+' [ <span class="relDescTextStyle ji">'+assetRelName+'</span> ] </span> ';
	appendData += '<i class="delete icon" onclick="removeFromAssignedRelationship('+arr[0]+','+arr[1]+')"></i></a>';
	
	if(jQuery.inArray(id, globalAssignedRelationshipsList) !== -1){
		removeAssignedRelationshipsList.splice( $.inArray(id, removeAssignedRelationshipsList), 1 );
	}else{
		newAssignedRelationships.push(id);
	}
	
	$("#assignedRelationships").append(appendData);	
	//Chandana 3/5/2019
	$('#assign_'+id).addClass('highlight');
	
}

//remove From Assigned Relationship
function removeFromAssignedRelationship(assetInstVerId,relId){
	if(jQuery.inArray(assetInstVerId+"_"+relId, globalAssignedRelationshipsList) !== -1){
		removeAssignedRelationshipsList.push(assetInstVerId+"_"+relId);
		
	}else{
		newAssignedRelationships.splice( $.inArray(assetInstVerId+"_"+relId, newAssignedRelationships), 1 );
	}	
	$("#assign_"+assetInstVerId+"_"+relId).remove();
	
	//Chandana 2/5/2019
	$("#"+assetInstVerId+"_"+relId).removeClass('InsAdd');
	//$("#"+assetInstVerId+"_"+relId).show().removeClass("hideInst");
	$('html, body').animate({
        scrollTop: $("#relationAvailableAssetInstance").offset().top-350
    }, 500);
}

//get Instances Of Selected Asset
function getInstancesOfSelectedAsset(){
	
	var selectedAssetId = $("#getInstancesOfSelectedAsset").val();
	if(selectedAssetId != ""){
		$.ajax({
			type : "GET",
			url: "/repopro/web/assetInstanceVersionManager/retAvailableAssetRelationship?srcAssetId="+assetId+"&destAssetId="+selectedAssetId+"&userName="+loggedInUserName+"&srcAssetInstId="+assetInstanceId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					$("#relationAvailableAssetInstance").html("");
					$.each(json.result,function(i){
						appendData = "";
						if(json.result[i].versionable == 1){
						//chandana - 2-5-2019
							appendData = '<p class="ui label basic grey" style="margin-bottom: 0.5em;" title="'+json.result[i].assetInstanceName+'_'+json.result[i].versionName+' [ '+json.result[i].descrption+' ]" id="'+json.result[i].destAssetInstVersionId+'_'+json.result[i].assetrelationShipId+'" onclick="addToAssignedRelationships(this)"><i class="tag icon" style="backface-visibility: visible;"></i><a style="cursor:pointer;opacity: 1;" class="divInAdd">'+json.result[i].assetInstanceName+'_'+json.result[i].versionName+' [ <span class="relDescTextStyle">'+json.result[i].descrption+' </span>]</a><i class="add icon" style="backface-visibility: visible;margin: 0px 0px 0px 12px;"></i></p>';
						}else{
							appendData = '<p class="ui label basic grey" style="margin-bottom: 0.5em;" title="'+json.result[i].assetInstanceName+' [ '+json.result[i].descrption+' ]" id="'+json.result[i].destAssetInstVersionId+'_'+json.result[i].assetrelationShipId+'" onclick="addToAssignedRelationships(this)"><i class="tag icon" style="backface-visibility: visible;"></i><a style="cursor:pointer;opacity: 1;" class="divInAdd">'+json.result[i].assetInstanceName+' [ <span class="relDescTextStyle">'+json.result[i].descrption+'</span> ]</a><i class="add icon" style="backface-visibility: visible;margin: 0px 0px 0px 12px;"></i></p>';
						}
							
						 $('html, body').animate({
						        scrollTop: $("#gridDataEditRelationshipTree").offset().top-300
						    }, 100);
						$("#relationAvailableAssetInstance").append(appendData);
					});
					
				}
			}
		});
		
		$.each(globalAssignedRelationshipsList,function(i){
			$("#"+globalAssignedRelationshipsList[i]).hide().addClass("hideInst");
		});
		
		$.each(removeAssignedRelationshipsList,function(i){
			$("#"+removeAssignedRelationshipsList[i]).show().removeClass("hideInst");
		});
		
		
		$.each(newAssignedRelationships,function(i){
			$("#"+newAssignedRelationships[i]).hide().addClass("hideInst");
		});
		
		var flag = true;
		$("#relationAvailableAssetInstance > p").each(function(){
			if($(this).hasClass('hideInst') == false){
				flag = false;
			}
		});
		
		if(flag){
			notifyMessage("Get Instances", "No instance to add", "fail")
		}
	}else{
		notifyMessage("Get Instances", "Please select an asset", "fail")
	}
	
	
}


//update Assigned Relationships
function updateAssignedRelationships(){
	var removedDestAssetInstVersionIdList = [];
	var removedRelationshipIdList = [];
	var addDestAssetInstVersionIdList = [];
	var addRelationshipIdList = [];
	
	$.each(newAssignedRelationships,function(i){
		var arr = newAssignedRelationships[i].split("_");
		addDestAssetInstVersionIdList.push(arr[0]);
		addRelationshipIdList.push(arr[1]);
	});
	
	$.each(removeAssignedRelationshipsList,function(i){
		var arr = removeAssignedRelationshipsList[i].split("_");
		removedDestAssetInstVersionIdList.push(arr[0]);
		removedRelationshipIdList.push(arr[1]);
	});
	
	
	var obj = {

			"srcAssetInstanceVersionId":assetInstanceVersionId,
			"assetName":encodeURIComponent(assetName),
			"assetInstName":encodeURIComponent(assetInstanceName),
			"assetInstanceId":assetInstanceId,
			"versionName":versionName,
			"assetId":assetId,
			"removedDestAssetInstVersionIds":removedDestAssetInstVersionIdList,
			"removedRelationshipIds":removedRelationshipIdList,
			"addDestAssetInstVersionIds":addDestAssetInstVersionIdList,
			"addRelationshipIds":addRelationshipIdList
	};
	
	$("#hiddenRelationshipData").val(JSON.stringify(obj));
	
	/*$.ajax({
		type: "POST",
		url: "/repopro/web/assetInstance/saveDependency?userName="+loggedInUserName,
		contentType : "application/json",
		dataType : "json",
		data : JSON.stringify(obj),
		async: false,
		complete:function(data){	
			appenddata = "";
			var json = JSON.parse(data.responseText);
			var msg = json.message;
			msg = msg.replace(/_/g, ' ');
			if(json.status == "SUCCESS"){
				  var currentTime = getDateTime();
				  $("#showAssetOverViewUpdatedOn").html(currentTime);
				  getRevisionHistory();
				  $("#toggleEditRelationshipButton").removeClass("hideElement");
				  editRelationshipTreeData();
				  removeAssignedRelationshipsList.length = 0;
				  newAssignedRelationships.length = 0;
				  
				  notifyMessage("Update Asset Instance Access",msg,"success");
				  getPropertiesData();
				  if($("#lockUnlockAssetInstance").hasClass("lock")){
					                              //$("#lockStatusMessage").html("");
					                              setTimeout(function(){
						                                  unlockInstance();
						                              },1500);
					                        }
				
			}
			else {
				notifyMessage("Update Asset Instance Access",msg,"fail");
			}
		}

	});	
	getRelationNameId(localStorage.getItem("assetInsVersionId"));
	 $("#legendListLink ul").html("");
	 $("#legendListContents").html("");
	 legendList.length = 0;
	root = getData();
	setup();
    createFilterList();*/
	
}

//search Instances
function searchInstancesValues(){
	
	  var input, filter, ul, li, a, i;
	    input = document.getElementById("searchInstances");
	    filter = input.value.toUpperCase();
	    ul = document.getElementById("relationAvailableAssetInstance");
	    li = ul.getElementsByTagName("p");
	    for (i = 0; i < li.length; i++) {
	        a = li[i].getElementsByTagName("a")[0];
	        id = $(li[i]).attr("id");
	        if (a.innerHTML.toUpperCase().indexOf(filter) > -1) {
	            
	            if($("#"+id).hasClass("hideInst") == false){
	            	li[i].style.display = "";
	            }
	       
	        } else {
	            li[i].style.display = "none";

	        }
	    }
	
}

//delete Asset Instance
function deleteAssetInstance(){
	 $('#cancelDeleteAssetInstModal').unbind();
	 $('#proceedDeleteAssetInstModal').unbind();
	 $('#deleteAssetInstModal').modal('setting', 'closable', false).modal('show');
	 //Chandana 10-06-2019
	$.ajax({
		type:"GET",
		url:"/repopro/web/assetInstanceVersionManager/checkForDeletionOfMappedInstance?assetInstId="+assetInstanceId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			//console.log(JSON.stringify(json))
			if(json.result == "true"){
				$('#insHasRelationship center').html('');
				$('#insHasRelationship center').html('This asset instance was mapped in the relationship with other asset instance. Still Do you want to delete?');
			}
			else{
			}
			}
	});
	
	 $('#proceedDeleteAssetInstModal').on('click', function(){
		 $.ajax({
				type : "DELETE",
				url: "/repopro/web/assetInstance/deleteAssetInstance?userName="+loggedInUserName+"&assetId="+assetId+"&assetInstId="+assetInstanceId+"&assetInstName="+encodeURIComponent(assetInstanceName),
				dataType : "json",
				async: false,
				complete : function(data) {
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						/* $('#deleteAssetInstModal').modal('hide'); //.modal('hide dimmer');
						 $('#deleteAssetInstModal').parent().css("display", "none !important");*/
						$('#deleteAssetInstModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
						localStorage.setItem("browserAssetName", assetName);
						localStorage.setItem("browserAssetId", assetId);
						$(".browserMainItem1").click();
						$(".browserAllAssetsSubMenu ").click();
						$("#browserAssetId_"+assetId).click();
						//$('#loadContent').load('browser.html');	
						if ($('#contentPushable').hasClass('sidebarPushable')) {
							$('#mainContainer').removeClass('pushStickyContent');
						}
						else{
							$('#mainContainer').removeClass('pushStickyContent');
						}
					
					}
				}
			});
	 });
}

function showHideAddCommenTSection(){
	//<!-- CHANDANA 04-06-2019 DISABLE KEYBOARD CONTROLS -->
	if($('#assetDiscussionTab').hasClass('AIVDisabled')){
		$("#commentButtonAccess").blur(); 
		return false;
	}
	
	$("#addNewComment").val("");
	$('#NewCommentSection').toggle('slow');
	
}

//get User Access Rights
userEditAccessFlag = true;
userDeleteAccessFlag = true;
userAdminFlag = true;

function getUserAccessRights(){
	if(loggedInUserName !== "admin"){
		$.ajax({
				type : "GET",
				url: "/repopro/web/assetInstanceVersionManager/retAivAccessRights?AivId="+assetInstanceVersionId+"&userName="+loggedInUserName,
				dataType : "json",
				async: false,
				complete : function(data) {
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						if(json.result[0].deleteFlag == true){
							$(".deleteAccess").show();
							userDeleteAccessFlag = true;
						}else{
							$(".deleteAccess").remove();
							userDeleteAccessFlag = false;
						}
							
						if(json.result[0].editFlag == true){
							//$(".editProperties").show();
							//$(".showProperties").hide();
							$(".editAccess").show();
							userEditAccessFlag = true;
						}else{
							//$(".editProperties").hide();
							//$(".showProperties").show();
							$(".editAccess").remove();
							userEditAccessFlag = false;
							$(".downloadAccess").attr('style',"pointer-events:none;");
							//$("#showAssetOverViewMessage").attr("style","pointer-events: none;");
						}
						
						
						if(json.result[0].adminFlag == true){
							$(".adminAccess").show();
							userAdminFlag = true;
							
						}else{
							$(".adminAccess").remove();
							userAdminFlag = false;
						}
						
						getLockStatus();
						
						/*if(loggedInUserName != "roleAnonymous"){	
							if(json.result[0].viewFlag == true){
								$("#fileForm").show();
								$("#expandAllAccordion").show();
								$("#noAssetPropertiesData").hide();
								
							}else{
								$("#fileForm").remove();
								$("#expandAllAccordion").remove();
								$("#noAssetPropertiesData").show();
							}
						}	*/
					
					}
				}
			});
	}
	
	//checkCompositionAggregationAssetType();
}

//check access for the user after each success call 
function checkAccessForUserOnSuccess(){
	
	if(userDeleteAccessFlag == true){
		$(".deleteAccess").show();
	}else{
		$(".deleteAccess").remove();
	}
		
	if(userEditAccessFlag == true){
		//$(".editProperties").hide();
		//$(".showProperties").show();
		$(".editAccess").show();
	}else{
		//$(".editProperties").hide();
		//$(".showProperties").show();
		$(".editAccess").remove();
		//$(".downloadAccess").attr('style',"pointer-events:none;");
	}
	
	if(userAdminFlag == true){
		$(".adminAccess").show();
	}else{
		$(".adminAccess").remove();
	}
	
}

//check Composition and Aggregation Asset Type
function checkCompositionAggregationAssetType(){
	var flag = false;
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstance/getdestAssetAccessForCompositionAndAggregationType?assetId="+assetId,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$.each(json.result,function(i){
					if(json.result[i].fwdRelId == 1 || json.result[i].fwdRelId == 5){
						flag = true;
					}
				});
			
				 if(flag){
					 $("#openAddVersionDetailsModal").remove();
				 }else{
					 $("#openAddVersionDetailsModal").show(); 
				 }
			}
		}
	});
	
}



//apply Relationship Filter
function applyRelationshipFilter(){
	//$("#legendListContents").html("");
	$("#applyRelationshipFilterButton").addClass("loading");
	var selectedData =  $("#relationshipFilterList").val();
	var relationId = "";
	if(selectedData == null){
		$.each(filterRelationNameList,function(i){
			relationId += filterRelationNameList[i]+"!";
		});
	}else{
		$.each(selectedData,function(i){
			relationId += selectedData[i]+"!";
		});
	}	
		
	relationId = relationId.replace(/!$/, "");
	
	$.ajax({
		type : "GET",
		url : "/repopro/web/relationship/relation/loaddependencies?assetName="+encodeURIComponent(assetName)+"&assetInstanceVersionId="+assetInstanceVersionId+"&relationId="+relationId,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
			var val = json.result[0];
			
			/*val = JSON.stringify(val).replace(/\\/g, '');
			val =  val.replace(/^[^"]*"(.*)"[^"]*$/, '$1');*/
			val = decodeURIComponent(val);
			
			globalTreeValue =  val;
			root = getData();
			setup();
			
		}
			$("#applyRelationshipFilterButton").removeClass("loading");
		}
	});
	
	
	
}

//create filter list
var filterRelationNameList = [];
function createFilterList(){
if(relationNameList.length == 0){
		$("#applyRelationshipFilter").css("visibility", "hidden");
	}else{
	filterRelationNameList.length = 0;
	
		appendData = "";
		appendData += '<option value="">Select Relationships</option>';
		$.each(relationNameList,function(i){
			var arr = relationNameList[i].split("-");
			appendData += '<option value="'+relationNameList[i]+'">'+arr[0]+'</option>';
			filterRelationNameList.push(relationNameList[i]);
		});
		//$("#relationshipFilterList").prepend("<option value=''>Select Relationships</option>");
		//setTimeout()
		$("#relationshipFilterList").append(appendData);
		$("#relationshipFilterList").dropdown();
	}

}


//get current date and time
function getDateTime(){
	var currentdate = new Date(); 
    var dateTime = currentdate.getFullYear() + "-"
                + (currentdate.getMonth()+1)  + "-" 
                + currentdate.getDate() + "T"  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds()+".0";
    
    return dateTime;
}


// naviate to legend Asset Grid Page
function legendAssetGridPage(legendAssetId,legendAssetName){
	
	localStorage.setItem("browserAssetName", legendAssetName);
	localStorage.setItem("browserAssetId", legendAssetId);
	$(".browserMainItem1").click();
	$(".browserAllAssetsSubMenu ").click();
	$("#browserAssetId_"+legendAssetId).click();
	$("html, body").animate({scrollTop: 0}, 10);
	$('#loadContent').load('browser.html');	
	
}

//show Uploaded File in properties folder
function showUploadedFile(input,paramId){
	 if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        var imageName = input.files[0]; 
	        reader.onload = function (e) {
	           if(imageName.type == "image/png" || imageName.type == "image/jpeg"){
	        	   $('#paramImage_'+paramId).attr('src', e.target.result).attr('width','50').attr('height','40').show();
	           }else{
	        	   $('#paramImage_'+paramId).hide();
	           } 
	            $("#fileName_"+paramId).html(imageName.name).attr("href",e.target.result).removeAttr("onclick");
	        }
	        
	        reader.readAsDataURL(input.files[0]);
	    }
}

// toggle expand/compress link
function accordionChange(obj){
	
	
	
	var count = 1;
	$(".accordionChange").each(function(){
		if($(this).hasClass("active")){
			count++;
		}
	});
	
	if($(".accordionChange").length == count){
		$("#expandAllAccordion").hide();
		$("#compressAllAccordion").show();
		
	}
	else{
		
		$("#expandAllAccordion").show();
		$("#compressAllAccordion").hide();
	}
	
	setTimeout(function(){
		if($(obj).hasClass('active')){
			$(obj).next().removeAttr('style');
			//$(obj).removeClass("active");
			//$(obj).next().removeClass("active");
		}else{
			//$(obj).addClass("active");
		//	$(obj).next().addClass("active");
		}
	}, 500);
	
}

//close all edit fields after unlock
function closeAllEditFieldsAfterUnlock(){
	
	if($("#addNewTagShowButton").hasClass('hideElement')){
		cancelTagDetails();
	}
	
	$("#cancelAssetOverViewMessage").click();
	
	if($("#toggleEditRelationshipButton").hasClass('hideElement')){
		//cancelAssignedRelationships();
		newAssignedRelationships.length = 0;
		$("#toggleEditRelationshipButton").removeClass("hideElement");
		$("#editRelationshipTree").toggle('blind');
	}
}

callCompositionAggregationAssetTypeFlag = true;

//multi Use Dropdown,function
function multiUseDropdown(){
	
	
	//============Chandana -- 12/8/2019 hide and show of guest user =============//
	hidePublicAccessforGU();
		
	$(".aivMenus").removeClass("selected");
	getPublicAccessStateOnLoad();
	getMyFavStatusOnLoad();
	getNotificationDataOnLoad();
	if(callCompositionAggregationAssetTypeFlag){
		callCompositionAggregationAssetTypeFlag = false;
		getCompositionAggregationAssetType();
	}
	
}

//propertiesXMLDataValidations
function propertiesXMLDataValidations(){
	//check paste event
	$("pre.propertiesCustomTextField").on('keydown', function(event){
		//return (this.innerText.length <= maxLength);
		var maxChar = $(this).attr("maxlength");
		
		if((this.innerText.length) == maxChar && event.keyCode != 8) { 
			//alert("in")
			event.preventDefault();
			}
	});
	
	$("pre.propertiesCustomTextField").bind('paste', function(event){
		
		var maxChar = $(this).attr("maxlength");
		var id = $(this).attr("id");
		setTimeout(function(){
			var text = $("#"+id).text().trim();
			 if((text.length) > maxChar) { 
				 text = text.substring(0,maxChar);
				 //$("#"+id).text(text);
				} 
			 var formatted =  formatXml(text);
				formatted = formatted.trim();
				formatted =	hljs.highlightAuto(formatted);
				$("#"+id).html(formatted.value);
		}, 0);
			
	});
	
	/*
	 * $("pre.propertiesCustomTextField").bind('copy cut', function(event){
		//event.preventDefault();
		var id = $(this).attr("id");
		var text = $("#"+id).text().trim();
		var selectedText = window.getSelection().toString();
		
		if(event.type == "cut"){
			text = text.replace(selectedText,'');
			var formatted =  formatXml(text);
			formatted = formatted.trim();
			formatted =	hljs.highlightAuto(formatted);
			$("#"+id).html(formatted.value);
		}
		
		var $tempInput = $("<input>");
	    $("body").append($tempInput);
	    $tempInput.val(selectedText).select(); //select the text
	  	document.execCommand("copy"); 
	    $tempInput.remove(); //remove the temporary input
	});
	
	*/
	
	$("pre.propertiesCustomTextField").on('focusout', function(event){
		
		var id = $(this).attr("id");
		var text = $("#"+id).text().trim();
		
		var formatted =  formatXml(text);
		formatted = formatted.trim();
		formatted =	hljs.highlightAuto(formatted);
		 $("#"+id).html(formatted.value);
			
	});
	
	$(".ui.dropdown").dropdown();
}

//get selection text
function getSelectionText() {
    var text = "";
    if (window.getSelection) {
        text = window.getSelection().toString();
    } else if (document.selection && document.selection.type != "Control") {
        text = document.selection.createRange().text;
    }
    return text;
}


/*************  09/02/18***********************************************************/

function openViewRichTextModal(id){
	
	$("#cancelViewRichText").unbind();
	$("#showAllFieldsList").html("");
	$('#viewRichTextModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	$("#showDetailedFieldsData").html('<div class="ui message">Please select any of the fields.</div>');
	
	var jsonData = $("#hiddenJSON_"+id).text();
	
	var ParamName = $('#assetParamId_'+id).text();
	
	
	jsonData = JSON.parse(jsonData);
		
	var richTextGetData = "";
	//$("#showAllEditFieldsList").html('<div class="ui error message" id="RichTextFieldErrorMsgId" >No field has been added yet.</div>');
	if(jsonData.isArray == 0){
		$('#ViewRichTextParamName').text("View Rich Text - "+ParamName);
		$("#viewRTFContent").parent().removeClass("fullscreen");
		$("#viewRTFGrid").removeClass("grid");//css("background","green !important");//
		$("#viewRTFLeftPnl").hide();//viewRTFLeftPnl
		
		
		var withTagValue = jsonData.rich_text_data.with_tag;
		var withOutTagValue = jsonData.rich_text_data.without_tag;
		var getDataMini = decodeURIComponent(withOutTagValue);
		
		withTagValue = decodeURIComponent(withTagValue);
		
		
		if(withTagValue.length > 0){
			//if(getDataMini.length > 350){
			if(getDataMini.length > 80){
				 getDataMini = getDataMini.substring(0,80) + "...";//getDataMini.substring(0,350) + "...";
			 } 
			
			 	richTextGetData += '<div class="ui segment richTextFieldList"  style="width:100%; cursor:pointer;display:none;" onclick="showFullData(this)"><customRTFtag></customRTFtag>';
				richTextGetData += '<div class="fullData" style="display:none;">'+withTagValue+'</div>';
				richTextGetData += '</div>';
				
				$("#showAllFieldsList").html(richTextGetData);
				
				$(".richTextFieldList").children("customRTFtag").text(getDataMini);
				
				$(".ui.segment.richTextFieldList").click();
				
		}else{
			$("#showAllFieldsList").html('<div class="ui message">No data has been added yet !</div>');
			
			$("#showDetailedFieldsData").html('<div class="ui message">No data has been added yet !</div>');
			
		}
	}else{
		$('#ViewRichTextParamName').text("View Rich Text Array- "+ParamName);
		$("#viewRTFContent").parent().addClass("fullscreen");
		$("#viewRTFGrid").addClass("grid");//css("background","green !important");//
		$("#viewRTFLeftPnl").show();//
		
		
		
		var loop = jsonData.rich_text_data;
		$("#showAllFieldsList").html("");
		
		
		if(loop.with_tag.length > 0){
			$.each(loop.with_tag,function(i){
				
				var withTagValue = loop.with_tag[i].textField;
				var withOutTagValue = loop.without_tag[i].textField;
				var getDataMini = decodeURIComponent(withOutTagValue);
				
				withTagValue = decodeURIComponent(withTagValue);
				
				
				/*alert("withOutTagValue:   "+getDataMini)
				alert("withTagValue:    "+withTagValue)
				*/
				//if(getDataMini.length > 350){
				if(getDataMini.length > 80){
					 getDataMini = getDataMini.substring(0,80) + "...";//getDataMini.substring(0,350) + "...";
				 } 
				var randomId = makeRendomAlphaNumericValue();
				richTextGetData = "";
				richTextGetData += '<div class="ui segment richTextFieldList" id="RTF_Id'+randomId+'" style="width:100%; cursor:pointer;margin-left: 10px;padding-left: 0px !important;font-size: 11px;" onclick="showFullData(this)"><spam class="rtfSNo" style="width: 1em !important;margin-top: 0px;margin-left: 5px;">'+(i+1)+'. </spam><customRTFtag style="margin-left: 7px;"></customRTFtag>'//+getDataMini;
				richTextGetData += '<div class="fullData" style="display:none;">'+withTagValue+'</div>';
				richTextGetData += '</div>';
				
				$("#showAllFieldsList").append(richTextGetData);
				$("#RTF_Id"+randomId).children("customRTFtag").text(getDataMini);
				//$("#showAllFieldsList").(richTextGetData);
			});	
		}else{
			$("#showAllFieldsList").html('<div class="ui  message">No data has been added yet !</div>');
			
			$("#showDetailedFieldsData").html('<div class="ui message">There are no field to select !</div>');
		}
	}
	
	
	$("#cancelViewRichText").on("click",function(){
		$("#showAllFieldsList").html("");
		$('#viewRichTextModal').modal("hide");
	});
}

function showFullData(obj){
	
	//var getData = $("#"+id).html();
	
	//var getData = $(obj).children("div").html();
	var getData = $(obj).children("div.fullData").html();
	
	$(".richTextFieldList").removeClass("richTextFieldListSelected");
	$(obj).addClass("richTextFieldListSelected");
	//richTextFieldListSelected
	
	$("#showDetailedFieldsData").html(getData);
}

//edit Rich Text Area Filds
var RTFDisplayDataHasArray = "";
var RTFDisplayDataHasArrayNull = "";
function editRichTextAreaFields(id, position){
	$("#cancelEditRichText").unbind();
	$("#submitEditRichText").unbind();
	$("#saveChangesNewRichText").unbind();
	$("#addNewRichText").unbind();
	
	$("#submitEditRichText").text();//****Added by aditya 02.03.18
	
	$('#editRichTextModal').modal("destroy");
	
	$('#editRichTextModal').trigger("reset");

	/*$('.ui#editRichTextModal').empty();

	$('.ui#editRichTextModal').modal('clear');*/
	
	
	
	
	$('#editRichTextModal').modal({observeChanges:true}).modal('show').modal('refresh');
	
	$('#editRichTextModal').trigger("reset");
	
	$("#showAllEditFieldsList").html("");
	$(".infoFiledsMessage").show();
	$("#editFieldDiv").hide();
	
	var ParamName = $('#assetParamId_'+id).text();
	
	
	
	var editor = CKEDITOR.instances.editDetailedFieldsDataTextarea;
	if (editor) {
		editor.destroy(true);
	}
	
	CKEDITOR.replace("editDetailedFieldsDataTextarea",{
		toolbar : 'BasicXmlSupport',
	});
	
	
var jsonData = $("#hiddenJSON_"+id).text();
var dd = jsonData;	
	jsonData = JSON.parse(jsonData);
	
	
	if(jsonData.isArray == 0){
		$('#RichTextParamName').html("Edit Rich Text - "+ParamName);
		//alert("isArray=0");
		$("#editRTFContent").parent().removeClass("fullscreen");
		$("#editRTFGrid").removeClass("grid");//css("background","green !important");//
		$("#editRTFGrid").children(".seven.wide.column").hide();//
		$("#saveChangesNewRichText").hide();
		
		var richTextGetData = "";
		var withTagValue = jsonData.rich_text_data.with_tag;
		var withOutTagValue = jsonData.rich_text_data.without_tag;
		var getDataMini = decodeURIComponent(withOutTagValue);
		withTagValue = decodeURIComponent(withTagValue);
		
		
		
		if(withTagValue.length > 0){
			//if(getDataMini.length > 350){
			if(getDataMini.length > 80){
				 getDataMini = getDataMini.substring(0,80) + "...";//getDataMini.substring(0,350) + "...";
			 } 
			//console.log(withTagValue+" === ********* ======== "+withOutTagValue);
	
		   var randomId = makeRendomAlphaNumericValue();
		   richTextGetData += '<div class="ui labeled segment richTextFieldListForEdit" id="RTF_Id'+randomId+'"  title="Click to edit" style="width:100%; cursor:pointer;margin-bottom: -3px; display:none;" onclick="editFullData(this)"><customRTFtag></customRTFtag>';//<div class="appendTextHere"></div>
		   richTextGetData += '<div class="ui label richTextCloseBtn" style="color: #ff0600; display:none;" onclick="removeRichTextSelectedList(this)"><i class="close icon"></i></div><div  style="display:none;">Click here to edit.</div>';				
		   richTextGetData += '<div class="fullDataForEdit" style="display:none;">'+withTagValue+'</div>';
		   richTextGetData += '</div>';
		   
		   $("#showAllEditFieldsList").html(richTextGetData);
			
			$("#RTF_Id"+randomId).children("customRTFtag").text(getDataMini);
			  $("#RTF_Id"+randomId).click();
		   
		}else{
			
			//***Aditya 02.03.18
			$("#submitEditRichText").text("Save");
			//***Aditya 02.03.18 over
			
			var randomId = makeRendomAlphaNumericValue();
			//richTextGetData += '<div class="ui corner labeled segment parentMultiRTF">';
			richTextGetData += '<div class="ui labeled segment richTextFieldListForEdit" id="RTF_Id'+randomId+'" title="Click to edit" style="width:100%; cursor:pointer;margin-bottom: -3px; display:none;" onclick="editFullData(this)"><customRTFtag>Please click here to modify it.</customRTFtag>';
			richTextGetData += '<div class="ui label richTextCloseBtn" style="color: #ff0600; display:none;" onclick="removeRichTextSelectedList(this)"><i class="close icon"></i></div><div  style="display:none;">Click here to edit.</div>';				
			richTextGetData += '<div class="fullDataForEdit" style="display:none;"></div>';
			richTextGetData += '</div>';
			
			//$("#showAllEditFieldsList").html('<div class="ui error message" id="RichTextFieldErrorMsgId" >No field has been added yet.</div>');
			
			
			$("#showAllEditFieldsList").html(richTextGetData);
			 $("#RTF_Id"+randomId).click();
			/*editFullData('RTF_Id'+randomId);*/
		}
		
		
		
		 /*if(getDataMini.length > 350){
			 getDataMini = getDataMini.substring(0,350) + "...";
		 } 
		 console.log(withTagValue+" === ********* ======== "+withOutTagValue);
		
		   var randomId = makeRendomAlphaNumericValue();
		 	richTextGetData += '<div class="ui corner labeled segment richTextFieldList" id="RTF_Id'+randomId+'"  title="Click to edit" style="width:100%; cursor:pointer;margin-bottom: -3px;" onclick="editFullData(this)"><customRTFtag></customRTFtag>';//<div class="appendTextHere"></div>
			richTextGetData += '<div class="ui corner label richTextCloseBtn" style="color: #ff0600; display:none;" onclick="removeRichTextSelectedList(this)"><i class="close icon"></i></div><div  style="display:none;">Click here to edit.</div>';				
			richTextGetData += '<div class="fullData" style="display:none;">'+withTagValue+'</div>';
			richTextGetData += '</div>';*/
		
		
		
		
		$("#addNewRichText").hide();	
		
	}else{
		
		$('#RichTextParamName').html("Edit Rich Text Array - "+ParamName);
		
		$("#editRTFContent").parent().addClass("fullscreen");
		$("#editRTFGrid").addClass("grid");//css("background","green !important");//
		$("#editRTFGrid").children(".seven.wide.column").show();//
		$("#saveChangesNewRichText").show();
		
		
		var loop = jsonData.rich_text_data;
		//alert(loop.length());
		var richTextGetData = "";
		$("#showAllEditFieldsList").html("");
		
		
		if(loop.with_tag.length > 0){
		
			$.each(loop.with_tag,function(i){
				
				var withTagValue = loop.with_tag[i].textField;
				var withOutTagValue = loop.without_tag[i].textField;
				var getDataMini = decodeURIComponent(withOutTagValue);
				withTagValue = decodeURIComponent(withTagValue);
							
				//if(getDataMini.length > 350){
				if(getDataMini.length > 80){
					 getDataMini = getDataMini.substring(0,80) + "...";//getDataMini.substring(0,350) + "...";
				 } 
				
				// console.log(withTagValue+" === *****222**** ======== "+withOutTagValue);
							 
				var randomId = makeRendomAlphaNumericValue();
				richTextGetData = "";
				richTextGetData += '<div class="ui labeled segment parentMultiRTF"><spam class="rtfSNo">'+(i+1)+'. </spam>';
				richTextGetData += '<div class="richTextFieldListForEdit multiRTF" id="RTF_Id'+randomId+'" title="Click to edit" style="width:100%; cursor:pointer;margin-bottom: -3px;" onclick="editFullData(this)"><customRTFtag></customRTFtag>';
				richTextGetData += '<div class="fullDataForEdit" style="display:none;">'+withTagValue+'</div>';
				richTextGetData += '</div><div class="ui label richTextCloseBtn" style="color: #ff0600;" onclick="removeRichTextSelectedList(this)"><i class="close icon"></i></div></div>';
				
				
				//console.log("var richTextGetData :: =======     "+richTextGetData);
				$("#showAllEditFieldsList").append(richTextGetData);
				$("#RTF_Id"+randomId).children("customRTFtag").text(getDataMini);
				
			});
			
		}else{
			/*var randomId = makeRendomAlphaNumericValue();
			richTextGetData += '<div class="ui corner labeled segment parentMultiRTF">';
			richTextGetData += '<div class="richTextFieldList multiRTF" id="RTF_Id'+randomId+'" title="Click to edit" style="width:100%; cursor:pointer;margin-bottom: -3px;" onclick="editFullData(this)"><customRTFtag>Please click here to modify it.</customRTFtag>';
			richTextGetData += '<div class="fullData" style="display:none;"></div>';
			richTextGetData += '</div><div class="ui corner label richTextCloseBtn" style="color: #ff0600;" onclick="removeRichTextSelectedList(this)"><i class="close icon"></i></div></div>';
			
			
			$("#showAllEditFieldsList").append(richTextGetData);*/
			$("#showAllEditFieldsList").html('<div class="ui  message" id="RichTextFieldErrorMsgId" >No field has been added yet !</div>');
		}
		//console.log("var richTextGetData :: =======     "+richTextGetData);
		//$("#showAllEditFieldsList").html(richTextGetData);
		$("#addNewRichText").show();
		
		
	}
	
	
	$("#submitEditRichText").on("click",function(){
		//$("#submitEditRichText").unbind();
		//$("#cancelEditRichText").unbind();
		var tempObj;
		if(jsonData.isArray == 0){
			saveChangesNewRichText();
			
		//	if(tf_n_RTF_validationMsgFlg == false){
			var getDataWithTag = $(".richTextFieldListForEdit").children("div.fullDataForEdit").html();
			var getDataWithOutTag = $(".richTextFieldListForEdit").children("div.fullDataForEdit").text().trim();

				
			if(tf_n_RTF_validationMsgFlg == false){
				tempObj = {
				        
				        "asset_category_name": jsonData.asset_category_name,
				        "assetParamId": jsonData.assetParamId,
				        "assetParamName": jsonData.assetParamName,
				        "isStatic": 0,
				        "isArray":0,
				        "paramTypeId": 7,
				        "paramValue":null,
				        "rich_text_data": {
				        					"with_tag": encodeURIComponent(getDataWithTag),
				        				    "without_tag": encodeURIComponent(getDataWithOutTag)
				           				  }
						};
			
				$("#hiddenJSON_"+jsonData.assetParamId).html(JSON.stringify(tempObj));
				$('#editRichTextModal').modal("hide").modal("destroy");
				$("#input_"+jsonData.assetParamId).html(getDataWithTag);
			}
		}else{
			var getDataWithTagArr = [];
			var getDataWithOutTagArr = [];
			tempObj = {};
			var flag = true;
			
				/*$(".richTextFieldList").each(function(i){
					alert("with TAg:           "+$(this).children("div.fullData").html())
					alert("without TAg:           "+$(this).children("div.fullData").text())
					
					
					getDataWithTagArr.push({
						"textField":	encodeURIComponent($(this).children("div.fullData").html())
						});
					getDataWithOutTagArr.push({
						"textField": encodeURIComponent($(this).children("div.fullData").text())
						});
					
				});*/
				
				for(var i=0; i <($(".richTextFieldListForEdit").length); i++){
					//alert("with TAg:           "+$(".richTextFieldListForEdit").eq(i).children("div.fullDataForEdit").html())
					//alert("without TAg:           "+$(".richTextFieldList").eq(i).children("div.fullData").text())
					
					if($(".richTextFieldListForEdit").eq(i).children("div.fullDataForEdit").text().trim() == ""){
						//alert("false")
						flag = false;
						notifyMessage("Update Multiple Rich Text Field", "Please enter data, Input field(s) can not be empty.", "fail"); 
						
					}else{
						getDataWithTagArr.push({
							"textField":	encodeURIComponent($(".richTextFieldListForEdit").eq(i).children("div.fullDataForEdit").html())
							});
						getDataWithOutTagArr.push({
							"textField": encodeURIComponent($(".richTextFieldListForEdit").eq(i).children("div.fullDataForEdit").text().trim())
							});
					}
						
				}
				
			if(flag){
				
				tempObj = {
				        
				        "asset_category_name": jsonData.asset_category_name,
				        "assetParamId": jsonData.assetParamId,
				        "assetParamName": jsonData.assetParamName,
				        "isStatic": 0,
				        "isArray":1,
				        "paramTypeId": 7,
				        "paramValue":null,
				        "rich_text_data": {
				        					"with_tag": getDataWithTagArr,
				        				    "without_tag": getDataWithOutTagArr
				           				  }
						};
				
				$("#hiddenJSON_"+jsonData.assetParamId).html(JSON.stringify(tempObj));
				$("#showAllEditFieldsList").html("");
				$('#editRichTextModal').modal("hide").modal("destroy");
				$("#input_"+jsonData.assetParamId).html(getDataWithTagArr.length+" value(s)");
			}
				
		}
		
		
		
	});
	
	

}

var richTextSelectedListIdVal="";
function editFullData(obj){
	//var getData = $("#richTextFieldList_"+id).html();//$("#fullData_"+id).html();
	$(".richTextFieldList").removeClass("richTextFieldListSelected");
	$(".richTextFieldListForEdit").removeClass("richTextFieldListSelected");//06.04.18
	$(obj).addClass("richTextFieldListSelected");
	//CKEDITOR.instances["editDetailedFieldsDataTextarea"].setData("Write your data here..");
	$("#editFieldDiv").show();
	$(".infoFiledsMessage").hide();	
	var getData = $(obj).children("div.fullDataForEdit").html();//$(obj).children("div").html();
	
	if($(obj).hasClass("richTextFieldListSelected")){
		CKEDITOR.instances["editDetailedFieldsDataTextarea"].setData(getData);
	}else{
		CKEDITOR.instances["editDetailedFieldsDataTextarea"].setData("Please select any one");
	}
	
		
	richTextSelectedListIdVal = $(obj).attr("id");
	
	
}

var tf_n_RTF_validationMsgFlg = false;
function saveChangesNewRichText(){
	$("#saveChangesNewRichText").unbind();
	
	//trimming white spaces and strings with empty values - chandana 21.02.2020
	var getTextfromCKeditor = $(".cke_contents iframe").contents().find("body").text();
	var trimextfromCKeditor = $.trim(getTextfromCKeditor);
	var ckeditorData = CKEDITOR.instances["editDetailedFieldsDataTextarea"].getData();
	if(getTextfromCKeditor == "" || getTextfromCKeditor == null || trimextfromCKeditor == ""){
		ckeditorData = -1;
	}
	else{
		ckeditorData = ckeditorData;
	}
	/*if(ckeditorData != ""){
	      var data = CKEDITOR.instances['editDetailedFieldsDataTextarea'].dataProcessor.toHtml(ckeditorData);
	      
	      ckeditorData = data;
	    }*/
	
	var modalName = $("#RichTextParamName").text();
	
	if(ckeditorData.length > 0){
		tf_n_RTF_validationMsgFlg = false;
		$("#"+richTextSelectedListIdVal).children("div.fullDataForEdit").html(ckeditorData);
		
		var textData = $("#"+richTextSelectedListIdVal).children("div.fullDataForEdit").text();
		
		if(textData.length > 80){
			textData = textData.substring(0,80) + "...";
		 } 
		
		$("#"+richTextSelectedListIdVal).children("customRTFtag").text(textData);
		
		
		notifyMessage(modalName,"Parameter value has been updated","success");
		
		$('#editRichTextModal').modal('refresh');
	}else{
		tf_n_RTF_validationMsgFlg = true;
		notifyMessage(modalName,"Please enter the value !","fail");
	}
}

var richTextFieldFinalArray = {};
var richTextFieldArray = {};
var richTextFieldArrayHasEnabled = []
function finalSubmitEditRichText(){
	richTextFieldArray = {};
	richTextFieldFinalArray.data = [];
	richTextFieldArray.without_tag = [];
	richTextFieldArray.with_tag = [];
	$(".richTextFieldList").each(function(){
		var id = $(this).attr("id");
		//console.log("hasn't hljsData ");
		
		//console.log(updatedRichTextFieldWithoutTag+" :: updatedRichTextFieldWithoutTag ****** updatedRichTextFieldWithTag :: "+updatedRichTextFieldWithTag);
		//if(updatedRichTextFieldWithoutTag != "" && updatedRichTextFieldWithoutTag.length != 0 && updatedRichTextFieldWithTag != "" && typeof updatedRichTextFieldWithTag != "undefined" && updatedRichTextFieldWithTag.length != 0 ){
			//console.log("createing final rich text array :: ");
			
			//console.log("in finalSubmitEditRichText hasArrayFlagForRichText :: "+hasArrayFlagForRichText);
			if(hasArrayFlagForRichText == false){
				var updatedRichTextFieldWithTag = $(this).children(".editorData").html();
				var updatedRichTextFieldWithoutTag = $(this).children(".editorData").text();
				if(updatedRichTextFieldWithoutTag != "" && updatedRichTextFieldWithoutTag.length != 0 && updatedRichTextFieldWithTag != "" && typeof updatedRichTextFieldWithTag != "undefined" && updatedRichTextFieldWithTag.length != 0 ){
					richTextFieldArrayHasEnabled.push({"without_tag":updatedRichTextFieldWithoutTag, "with_tag":updatedRichTextFieldWithTag});
				}
			}else{
				var updatedRichTextFieldWithTag = $(this).children(".editorData").html();
				var updatedRichTextFieldWithoutTag = $(this).children(".editorData").text();
				
				if(updatedRichTextFieldWithoutTag != "" && updatedRichTextFieldWithoutTag.length != 0 && updatedRichTextFieldWithTag != "" && typeof updatedRichTextFieldWithTag != "undefined" && updatedRichTextFieldWithTag.length != 0 ){
					richTextFieldArray.without_tag.push({"textField":updatedRichTextFieldWithoutTag, "id":id});//.split("\n")[0]
					richTextFieldArray.with_tag.push({"textField":updatedRichTextFieldWithTag, "id":id});//.split("\n")[0]
				}
			}	
		//}
			
	});
	
	if(hasArrayFlagForRichText == true){
		richTextFieldFinalArray.data = (richTextFieldFinalArray.data).concat(richTextFieldArray);
	}	
	
	//richTextFieldFinalArray.data = (richTextFieldFinalArray.data).concat(richTextFieldArray);
	//console.log(JSON.stringify(richTextFieldArrayHasEnabled)+" :: richTextFieldArray : "+JSON.stringify(richTextFieldFinalArray));
	$('#editRichTextModal').modal({observeChanges:true, closable: false }).modal('hide').modal('refresh');
	
	richTextClickFlag = true;
}

var addNewRTFcnt = 0;
/*==============Aditya init===*/
function addNewRichText(){
	
	/*appendData = "";
	appendData += '<div class="ui corner labeled segment richTextFieldList" id="richTextFieldList_'+cnt+'" title="Click to edit" style="width:100%; cursor:pointer;margin-bottom: -3px;" onclick="editFullData(this)">Please click here to modify it.';//<div class="appendTextHere"></div>
	appendData += '<div class="ui corner label richTextCloseBtn" style="color: #ff0600;" onclick="removeRichTextSelectedList(this)"><i class="close icon"></i></div><div class="fullData_'+cnt+'" style="display:none;">Click here to edit.</div>';
	appendData += '</div>';*/
	$("#RichTextFieldErrorMsgId").remove();
	var lengthVal = $(".multiRTF").length;
	var randomIdGenrator = makeRendomAlphaNumericValue();
	$(".richTextFieldListForEdit").removeClass("richTextFieldListSelected");//06.04.18 aditya
	//alert(lengthVal);
	var richTextGetData = '';
	richTextGetData += '<div class="ui labeled segment parentMultiRTF"><spam class="rtfSNo">'+(lengthVal+1)+'. </spam>';
	richTextGetData += '<div class="richTextFieldListForEdit richTextFieldListSelected multiRTF" id="RTF_Id'+randomIdGenrator+'" title="Click to edit" style="width:100%; cursor:pointer;margin-bottom: -3px;" onclick="editFullData(this)"><customRTFtag>Please click here to modify it.</customRTFtag>';
	richTextGetData += '<div  style="display:none;">Click here to edit.</div>';
	richTextGetData += '<div class="fullDataForEdit" style="display:none;"></div>';
	richTextGetData += '</div><div class="ui label richTextCloseBtn" style="color: #ff0600;" onclick="removeRichTextSelectedList(this)"><i class="close icon"></i></div></div>';
	
	$("#showAllEditFieldsList").append(richTextGetData);
	
	$(".infoFiledsMessage").hide();
	richTextSelectedListIdVal = "RTF_Id"+randomIdGenrator;
	$("#editFieldDiv").show();
	CKEDITOR.instances["editDetailedFieldsDataTextarea"].setData("");
	
	addNewRTFcnt++;
	$('#editRichTextModal').modal('refresh');
}

function removeRichTextSelectedList(obj){
	
	if($(obj).parent().children().hasClass("richTextFieldListSelected")){
		$(obj).parent().children().removeClass("richTextFieldListSelected");
		$("#editFieldDiv").hide();
		$(".infoFiledsMessage").show();	
		CKEDITOR.instances["editDetailedFieldsDataTextarea"].setData("Please select any one");
	}
	
	$(obj).parent().remove();
	
	$(".parentMultiRTF").each(function(key, val){
		//console.log("spam text :: "+($(this).children("spam.rtfSNo").text()+". "));
		$(this).children("spam.rtfSNo").text(key+1+". ");
	});
	
	if($(".parentMultiRTF").length == 0){
		//$("#RichTextFieldErrorMsgId").show();
		$("#showAllEditFieldsList").html('<div class="ui  message" id="RichTextFieldErrorMsgId" >No field has been added yet !</div>');
	}

	$('#editRichTextModal').modal('refresh');
	
}

/*=============Aditya over=====*/

/****souradip 22/01/2018*****merge 4 APIs in one API*********************************************************************************/

//get overview, properties, tag & taxonomy data
//backend is not there for Repopro 3.0.0 - Schneider and it is no longer required
function getOverviewPropertiesTagsTaxonomyData(){
	//var url = "/repopro/web/assetInstanceVersionManager/getAivPageDetailsOnLoad?assetInstVersionId="+assetInstanceVersionId+"&userName="+loggedInUserName;
	//console.log(" getOverviewPropertiesTagsTaxonomyData  "+url);
	
	$.ajax({
		
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/getAivPageDetailsOnLoad?assetInstVersionId="+assetInstanceVersionId+"&userName="+loggedInUserName,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
									
					//get overview data
					setTimeout(function(){ 
						$("#showAssetOverViewMessage").removeClass("loading");
					}, 0);
					
					var data = "";
					if(json.result[0].overview.description == null){
						data = "<span id='showAssetOverViewDescription'>No description provided yet</span>";	
					}else{
						data = "<span id='showAssetOverViewDescription'>"+json.result[0].overview.description+"</span>";	
					}
					
					$('#showAssetOverViewOwner').html(json.result[0].overview.owner);
					var time = json.result[0].overview.updatedOn.trim();
					time = time.split(" ");
					$('#showAssetOverViewUpdatedOn').html(time[0]+"T"+time[1]);
					$("#showAssetOverViewMessage").html(data);
					
				
					assetInstanceId = json.result[0].overview.assetInstanceId;
					assetId = json.result[0].overview.assetId;
					assetName = json.result[0].overview.assetName;
					versionable = json.result[0].overview.versionable;
					versionName = json.result[0].overview.versionName;
					if(json.result[0].overview.iconImageName != null){
						var imageType = json.result[0].overview.iconImageName ;
						//imageType = imageType.split(".");
						//assetIconType = imageType[1];
						assetIconType = (json.result[0].overview.iconImageName).substring((json.result[0].overview.iconImageName).lastIndexOf(".") + 1, (json.result[0].overview.iconImageName).length);

					}
					
					appendData = "";
					
					if(assetIconType != "default"){
						
						if(circularThemeColoredIcon){
							appendData += '<div class="bigIconImageCircleStyle_themeCircle" style="font-size: 1.4em; display: block !important; margin-left: -1rem !important;">';
							if(invertAssetIconFlag){
								appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle" src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';
							}else{
								appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle" src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';
							}
						}else{
							appendData += '<div class="bigIconImageCircleStyle" style="font-size: 1.4em; display: block !important; margin-left: -1rem !important;">';
							if(invertAssetIconFlag){
								appendData += '<img class="left floated ui  image bigIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';
							}else{
								appendData += '<img class="left floated ui  image bigIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';
							}
						}
						/*appendData += '<div class="bigIconImageCircleStyle" style="font-size: 1.4em; display: block !important; margin-left: -1rem !important;">';
						appendData += '<img class="left floated ui circular image bigIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';*/
					}else{
						
					}
					
					$("#assetInstanceIcon").html(appendData);
					
					$(".abc").removeClass("themeTextColor itemSelected");
					$("#browserAssetId_"+assetId).addClass("themeTextColor itemSelected");


					$('#breadcrumbData').html('<a class="section" onclick="getHomeDetails(this)">Home</a><i class="right chevron icon divider"></i><a class="section whitespaceNoTrim" onclick="navigateToAssetPage()">Browse - '+assetName+'</a><i class="right chevron icon divider"></i><div class="active section whitespaceNoTrim">'+assetInstanceName+'</div>');

					if(versionable){
						$("#openAddVersionDetailsModal").show();
						$("#assetVersionFloatingMenu").show();
					}else{
						$("#divVersionable").remove();
						$("#openAddVersionDetailsModal").remove();
						$("#assetVersionFloatingMenu").hide();
						$("#assetInstancesVersionHeader").remove();
						$("#assetInstancesVersionSegment").remove();
						$("#versionDivider").remove();
						//$("#floatingScrollerMenu").attr("style","height: 20.2em !important;border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;");
						$("#floatingScrollerMenu").attr("style","height: auto !important;border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;");
						
					}
					/********************************************************************************************************************/
					
					//get properties data
					
					
					setTimeout(function(){ 
						$("#propertiesLoadingSegment").removeClass("loading");
					}, 0);
					
					var custListAssetParamID = "";
					var assetListAssetId = "";
					var assetListAssetParamID = "";
					var userListAssetParamID = "";
					
					if(json.result[0].properties.length == 0){
						$("#noAssetPropertiesData").show();
						$("#propertiesAccordion").hide();
						$("#editPropertiesData").hide();
						$("#expandAllAccordion").hide();
						$("#propSubBtn").remove();
						
						/*$("#noAssetPropertiesData").show();
						$("#propertiesAccordion").hide();
						$("#propSubBtn").remove();
						$("#expandAllAccordion").hide();*/
						
					}else{
                        //var userSelectedData;
						$("#noAssetPropertiesData").hide();
						$("#propertiesAccordion").show();
						$("#editPropertiesData").show();
						assetCategoryList.length = 0;
						assetParamIdList.length = 0;
						
						$.each(json.result[0].properties, function(i) {
							if ($.inArray(json.result[0].properties[i].asset_category_name+"~~"+json.result[0].properties[i].cat_disp, assetCategoryList) == -1){
								assetCategoryList.push(json.result[0].properties[i].asset_category_name+"~~"+json.result[0].properties[i].cat_disp);
							}
						});
						
						$.each(assetCategoryList, function(i) {
							var arr = assetCategoryList[i].split("~~");
							var appendPropertiesData = createPropertiesDataFormat(arr[0],arr[1]);
							$("#propertiesAccordion").append(appendPropertiesData);
						});
							
						//console.log("json.result[0].properties : " + json.result[0].properties);
						$.each(json.result[0].properties, function(i) {
							var propertiesValue = "";
							var inputType = "";
							var listFlag = false;
							var dateFlag = false;
							var textFlag = false;
							var richTextFlag = false;
							var deriveAttrFlag = false;
							
							if(json.result[0].properties[i].paramTypeId == 1){
								inputType = "text";
								textFlag = true;
								var value,valueforInputfield;
								
								if(json.result[0].properties[i].isStatic == 0){
									if(json.result[0].properties[i].paramValue != null)
									value = json.result[0].properties[i].paramValue;
									
								}else{
									if(json.result[0].properties[i].staticValue != null)
									value = json.result[0].properties[i].staticValue;
								}
								if(value == null ){
									value = "";
									
								}
								
								var flag = validateURL(value);
								//var regex = /^\<a.*\>.*\<\/a\>/i;
								
								if(value.startsWith("<a")){
									flag = false;
								}
								propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+json.result[0].properties[i].isStatic+'</span>';
								propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" style="display:none;"></div>';
								//propertiesValue += '<input onclick="propertiesEditLock()" id="input_'+json.result[0].properties[i].assetParamId+'" type="text" value="" placeholder="Maximum characters '+json.result[0].properties[i].paramTextSize+'" maxlength="'+json.result[0].properties[i].paramTextSize+'"></div>';
								
								/*======================= Aditya - 19.2.18 ====================*/
								//propertiesValue += '<textarea  id="input_'+json.result[0].properties[i].assetParamId+'"  value="" placeholder="Maximum characters '+json.result[0].properties[i].paramTextSize+'" maxlength="'+json.result[0].properties[i].paramTextSize+'"  rows="5" ></textarea></div>';
								/*= ====================== Aditya-over ====================*/
								//propertiesValue += '<pre class="propertiesCustomTextField customPreTag" maxlength="'+json.result[0].properties[i].paramTextSize+'"  placeholder="Maximum characters '+json.result[0].properties[i].paramTextSize+'" contenteditable="true"  id="input_'+json.result[0].properties[i].assetParamId+'"></pre></div>';
								if(flag){
									if(value.startsWith("<")){
										var formatted =  formatXml(value);
										formatted = formatted.trim();
										formatted =	hljs.highlightAuto(formatted);
										propertiesValue += '<pre class="showProperties newTextFieldStyle" style="display:flex !important">'+formatted.value+'</pre>';
									}else{
										propertiesValue += '<a class="showProperties" href="'+value+'" target="_blank">'+value+'</a>';
									}
									
									
								}else{
									if(value.startsWith("<a")){
										propertiesValue += '<span class="showProperties" >'+value+'</span>';
									}else{
										var formatted =  formatXml(value);
										formatted = formatted.trim();
										formatted =	hljs.highlightAuto(formatted);
										propertiesValue += '<pre class="showProperties newTextFieldStyle" >'+formatted.value+'</pre>';
									}
								}
								//propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+json.result[0].properties[i].isStatic+'</span>';
								
							}else if(json.result[0].properties[i].paramTypeId == 2){
								inputType = "date";
								dateFlag = true;
								var reversed,pieces,date;
								if(json.result[0].properties[i].isStatic == 0){
									date = json.result[0].properties[i].paramValue;
								}else{
									date = json.result[0].properties[i].staticValue;
								}
							 	if(date == null){
							 		date = "";
							 	}
							 		
							 	propertiesValue += '<div class="ui left icon input editProperties propertiesLockedByOther" style="display:none;">';
							 	propertiesValue += '<input  id="input_'+json.result[0].properties[i].assetParamId+'" class="editProperties" type="text" value="'+date+'" placeholder="dd/mm/yyyy" title="Click to change date" style="cursor:pointer" pattern="[0-9]{2}/[0-9]{2}/[0-9]{4}">';
							 	propertiesValue += ' <i class="calendar icon"></i></div>';
							 		
							 	propertiesValue += '<span class="showProperties" >'+date+'</span>';
							 	propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+json.result[0].properties[i].isStatic+'</span>';
							 	
							}else if(json.result[0].properties[i].paramTypeId == 3){
								inputType = "file";
								var fileName; 
								if(json.result[0].properties[i].isStatic == 0){
									fileName = json.result[0].properties[i].fileName;
								}else{
									fileName = json.result[0].properties[i].apdFileName;
								}
								if(fileName == null){
									fileName = "";
								}
								
								var fileType = fileName.split('.').pop().toLowerCase();
								
							 	
							 	$('#fileForm').append("<input type='file' class='hidden' name='hidden_"+json.result[0].properties[i].assetParamId+"' id='hidden_"+json.result[0].properties[i].assetParamId+"' />");
							 	
							 	propertiesValue += '<label for="input_'+json.result[0].properties[i].assetParamId+'" class="ui icon mini button editProperties propertiesLockedByOther"  style="display:none;">'; 
								propertiesValue += '<i class="file icon"></i> Upload File</label>';
								propertiesValue += '<input id="input_'+json.result[0].properties[i].assetParamId+'" onchange="showUploadedFile(this,'+json.result[0].properties[i].assetParamId+')" style="display: none;" class="upFile" type="file" name="uploadedFile_'+json.result[0].properties[i].assetParamId+'">';
								
							 	if(json.result[0].properties[i].isStatic == 1){
								 	if(fileType == "jpeg" || fileType == "png" || fileType == "jpg"){
								 		propertiesValue += '<image id="paramImage_'+json.result[0].properties[i].assetParamId+'" src="/repopro/images/thumbnailImages/'+json.result[0].properties[i].assetParamId+"_"+fileName+'">';
								 		propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json.result[0].properties[i].assetParamId+'" href="/repopro/images/thumbnailImages/'+json.result[0].properties[i].assetParamId+"_"+fileName+'" download>'+fileName+'</a>';
							 	
								 	}else{
								 		//console.log(JSON.stringify(json.result[0].properties[i]))
								 		propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json.result[0].properties[i].assetParamId+'" onclick="downloadFile('+json.result[0].properties[i].isStatic+',\''+json.result[0].properties[i].assetParamName+'\')">'+fileName+'</a>';
							 	
								 	}	
								 		
							 	}else{	
							 		if(fileType == "jpeg" || fileType == "png" || fileType == "jpg"){	
								 		propertiesValue += '<image id="paramImage_'+json.result[0].properties[i].assetParamId+'" src="/repopro/images/thumbnailImages/'+json.result[0].properties[i].assetInstParamId+"_"+fileName+'">';
								 		propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json.result[0].properties[i].assetParamId+'" href="/repopro/images/thumbnailImages/'+json.result[0].properties[i].assetInstParamId+"_"+fileName+'" download>'+fileName+'</a>';
							 		}else{
							 			propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json.result[0].properties[i].assetParamId+'" onclick="downloadFile('+json.result[0].properties[i].isStatic+',\''+json.result[0].properties[i].assetParamName+'\')">'+fileName+'</a>';
							 		}
							 	}
							 	
							 	propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none; ">'+json.result[0].properties[i].isStatic+'</span>';
							 	propertiesValue += '<span id="oldFileName_'+json.result[0].properties[i].assetParamId+'" style="display:none; ">'+fileName+'</span>';
							 	/*propertiesValue += '<label for="input_'+json.result[0].properties[i].assetParamId+'" class="ui icon mini button editProperties propertiesLockedByOther"  style="float: right;display:none;">'; 
								propertiesValue += '<i class="file icon"></i> Upload File</label>';
								propertiesValue += '<input id="input_'+json.result[0].properties[i].assetParamId+'" onchange="showUploadedFile(this,'+json.result[0].properties[i].assetParamId+')" style="display: none;" class="upFile" type="file" name="uploadedFile_'+json.result[0].properties[i].assetParamId+'">';
								*/
							}else if(json.result[0].properties[i].paramTypeId == 4){
								var value;
								listFlag = true;
								
								if(json.result[0].properties[i].isStatic == 0){
									value = json.result[0].properties[i].paramValue;
								}else{
									value = json.result[0].properties[i].staticValue;
									
								}
								if(value == null ){
									value = "";
								}
								
								if(json.result[0].properties[i].listTypeParamTypeId == 1 ){
	
									inputType = "list";
									/*propertiesValue += getCustomList(json.result[0].properties[i].assetParamId);*/
									var assetParamValue = json.result[0].properties[i].assetParamId +"~~";
									custListAssetParamID += assetParamValue; 
									
									propertiesValue += '<span id="customList_'+json.result[0].properties[i].assetParamId+'"></span>';
									
									if(value == -1 || value == ""){
										propertiesValue += '<span id="custListSelectValue_'+json.result[0].properties[i].assetParamId+'" class="showProperties" style="display:none;"></span>';
									}else{
										var data = value.split("~~");
										var selectedLabels = "";
										$.each(data, function(j){
											selectedLabels += '<div class="ui label">'+data[j]+'</div>';
										});
										
										propertiesValue += '<span  class="showProperties" style="display:none;">'+selectedLabels+'</span>';
										propertiesValue += '<span id="custListSelectValue_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+value+'</span>';
									}
									propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+json.result[0].properties[i].isStatic+'</span>';

								
								}
								
								else if(json.result[0].properties[i].listTypeParamTypeId == 2 ){
								
									inputType = "list";
									
									if(value == -1 || value == ""){
										propertiesValue += '<span id="assetListSelectValue_'+json.result[0].properties[i].assetParamId+'" class="showProperties" style="display:none;"></span>';
									}else{
										var data = value.split("~~");
										var selectedLabels = "";
										$.each(data, function(j){
											selectedLabels += '<div class="ui label">'+data[j]+'</div>';
										});
										propertiesValue += '<span  class="showProperties" style="display:none;">'+selectedLabels+'</span>';
										propertiesValue += '<span id="assetListSelectValue_'+json.result[0].properties[i].assetParamId+'"  style="display:none;">'+value+'</span>';
									}
									
									propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+json.result[0].properties[i].isStatic+'</span>';
									propertiesValue += '<div id="assetList_'+json.result[0].properties[i].assetParamId+'" >';
									propertiesValue += '<select  class="ui search selection dropdown propertiesLockedByOther callAssetListAPI propDropdownWidth"  style="z-index:7 !important" id="input_'+json.result[0].properties[i].assetParamId+'" multiple="">';
									/*propertiesValue += '<option value="">Select</option>';*/
									if(value != ""){
										value = value.split("~~");
										propertiesValue += '<option value="">Select</option>';
										$.each(value, function(i) {
											  propertiesValue += '<option value="'+encodeURIComponent(value[i])+'">'+value[i]+'</option>';
											  listArr.push(encodeURIComponent(value[i]));
										});
									}else{
										propertiesValue += '<option value="">Select</option>';
									}
									
									propertiesValue += '</select></div>';
									setTimeout(function(){
										/*alert("set time out");*/
										$('#input_'+json.result[0].properties[i].assetParamId).dropdown('set selected',listArr);
									}, 0);
									
									
								}
								
								
								else if(json.result[0].properties[i].listTypeParamTypeId == 3 ){
									inputType = "list";
									/*propertiesValue += getActiveUserList(json.result[0].properties[i].assetParamId);*/
									userListAssetParamID += json.result[0].properties[i].assetParamId +"~~"; 
									
									propertiesValue += '<span id="userList_'+json.result[0].properties[i].assetParamId+'"></span>';
									
									if(value == -1 || value == ""){
										propertiesValue += '<span id="userListSelectValue_'+json.result[0].properties[i].assetParamId+'" class="showProperties" style="display:none;"></span>';
									}else{
										var data = value.split("~~");
										var selectedLabels = "";
										$.each(data, function(j){
											selectedLabels += '<div class="ui label">'+data[j]+'</div>';
										});
										propertiesValue += '<span  class="showProperties" style="display:none;">'+selectedLabels+'</span>';
										propertiesValue += '<span id="userListSelectValue_'+json.result[0].properties[i].assetParamId+'"  style="display:none;">'+value+'</span>';
									}
									
									propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+json.result[0].properties[i].isStatic+'</span>';
								}
								
							}else if(json.result[0].properties[i].paramTypeId == 5){
								deriveAttrFlag = true;
								inputType = "derivedAttribute";
								var derivedData;
								if(json.result[0].properties[i].paramValue == null){
									derivedData = "";
								}else{
									derivedData = json.result[0].properties[i].paramValue;
								}
								
								propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+json.result[0].properties[i].isStatic+'</span>';
								propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
								
								/*var formatted =  formatXml(derivedData);
								formatted = formatted.trim();
								formatted =	hljs.highlightAuto(formatted);
								//console.log(" formatted:      "+formatted.value);
								formatted.value = formatted.value.replace(/~~/g,",");
								var derData = formatted.value;*/
								
								//console.log(derivedData)
								derivedData = derivedData.split("`~`");
								//console.log(" derivedData "+derivedData);
								$.each(derivedData,function(e){
									var derviedSplittedValue = derivedData[e].split("~~");
									
									$.each(derviedSplittedValue,function(n){
										//console.log(" derviedSplittedValue "+derviedSplittedValue[n]);
										
										formatted = derviedSplittedValue[n].trim();
										
										
										
										
										propertiesValue += '<div class="ui basic label disabled">';
										
										if(formatted.startsWith("<")){
											formatted =	hljs.highlightAuto(formatted);
											propertiesValue += '<pre>'+formatted.value+'</pre>';
										}else{
											propertiesValue += '<span>'+formatted+'</span>';
										}
										
										
										propertiesValue += '</div>'; 
										
									});
									
									
									
									if(e < (derivedData.length-1)){
										propertiesValue += '<div class="ui divider"></div>';
									}
										
									
								});
								propertiesValue += '</div>';
								
								
								
								
							}else if(json.result[0].properties[i].paramTypeId == 6){
								
								/*inputType = "derivedComputation";
								var derivedData;
								if(json.result[0].properties[i].paramValue == null){
									derivedData = "";
								}else{
									derivedData = json.result[0].properties[i].paramValue;
								}
								propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
								propertiesValue += derivedData;
								propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+json.result[0].properties[i].isStatic+'</span>';
								propertiesValue += '</div>';*/
								
								deriveAttrFlag = true;
								inputType = "derivedAttribute";
								var derivedData;
								if(json.result[i].paramValue == null){
									derivedData = "";
								}else{
									derivedData = json.result[i].paramValue;
								}
								
								propertiesValue += '<span id="isStatic_'+json.result[i].assetParamId+'" style="display:none;">'+json.result[i].isStatic+'</span>';
								propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
								
								/*var formatted =  formatXml(derivedData);
								formatted = formatted.trim();
								formatted =	hljs.highlightAuto(formatted);
								//console.log(" formatted:      "+formatted.value);
								formatted.value = formatted.value.replace(/~~/g,",");
								var derData = formatted.value;*/
								
								//console.log(derivedData)
								derivedData = derivedData.split("`~`");
								//console.log(" derivedData "+derivedData);
								$.each(derivedData,function(e){
									var derviedSplittedValue = derivedData[e].split("~~");
									
									$.each(derviedSplittedValue,function(n){
										//console.log(" derviedSplittedValue "+derviedSplittedValue[n]);
										
										formatted = derviedSplittedValue[n].trim();
										
										
										
										
										propertiesValue += '<div class="ui basic label disabled">';
										
										if(formatted.startsWith("<")){
											formatted =	hljs.highlightAuto(formatted);
											propertiesValue += '<pre>'+formatted.value+'</pre>';
										}else{
											propertiesValue += '<span>'+formatted+'</span>';
										}
										
										
										propertiesValue += '</div>'; 
										
									});
									
									
									
									if(e < (derivedData.length-1)){
										propertiesValue += '<div class="ui divider"></div>';
									}
										
									
								});
								propertiesValue += '</div>';
								
								
							}else if(json.result[0].properties[i].paramTypeId == 7){  //souradip 06/02/18
								inputType = "richText";
								richTextFlag = true;
								var value,valueforInputfield;
								
								if(json.result[0].properties[i].isStatic == 0){
									if(json.result[0].properties[i].paramValue != null)
									value = json.result[0].properties[i].paramValue;
									
								}else{
									if(json.result[0].properties[i].staticValue != null)
									value = json.result[0].properties[i].staticValue;
								}
								if(value == null ){
									value = "";
								}
								
								
								
								propertiesValue += '<span id="isStatic_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+json.result[0].properties[i].isStatic+'</span>';
								
								
							/*	if(value.startsWith("<pre")){
									propertiesValue += '<div class="showProperties" id="showProperties_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+value+'</div>';
								}else{
									var formatted =  formatXml(value);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);
									propertiesValue += '<pre class="showProperties" id="showProperties_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+formatted.value+'</pre>';
								}*/
									
								/*propertiesValue += '<div  class="ui stacked  segment showProperties richTextCustomView" style="min-height:5em;">Total No of fields:  6';
								propertiesValue += '<div class="ui inverted dimmer" style="z-index:1;"><div class="content"><div class="center">';
								propertiesValue += '<div class="ui primary mini button" onclick="openViewRichTextModal('+json.result[0].properties[i].assetParamId+')">Show All Fields</div>';
								propertiesValue += '</div></div></div>';
								propertiesValue += '</div>';
								
								propertiesValue += '<div  id="showProperties_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+value+'</div>';
								*/
								
								propertiesValue += '<div class="showProperties" id="showProperties_'+json.result[0].properties[i].assetParamId+'" style="display:none;">'+value+'</div>';
								/*--------------Aditya 19.02.18-----------*/
								//propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" >';
								propertiesValue += '<div class="ui fluid editProperties propertiesLockedByOther" >';
								/*--------------Aditya 19.02.18 over-----------*/
								
								//propertiesValue += '<input onclick="propertiesEditLock()" id="input_'+json.result[0].properties[i].assetParamId+'" type="text" value="" placeholder="Maximum characters '+json.result[0].properties[i].paramTextSize+'" maxlength="'+json.result[0].properties[i].paramTextSize+'"></div>';
								//propertiesValue += '<textarea  id="input_'+json.result[0].properties[i].assetParamId+'"  value=""  rows="5" cols="50"></textarea></div>';
								//console.log(json.result[0].properties[i].paramTextSize)
								//propertiesValue += '<pre class="propertiesCustomTextField customPreTag" maxlength="'+json.result[0].properties[i].paramTextSize+'"  placeholder="Maximum characters '+json.result[0].properties[i].paramTextSize+'"  id="input_'+json.result[0].properties[i].assetParamId+'">'+value+'</pre></div>';
								propertiesValue += '<div class="ui segment richTextCustomView customPreTag" >';
								
								/*if(value.length > 300){
									var displayRTFData = value.substring(0,300) + "..."
								}else{
									var displayRTFData = value;
								}*/
								propertiesValue += '<div class="richTextBackendData" style="min-height:5em; " id="input_'+json.result[0].properties[i].assetParamId+'"  maxlength="'+json.result[0].properties[i].paramTextSize+'">'+json.result[i].rtfCount+' value(s)</div>';
								
								/*propertiesValue += '<div class="richTextEditedData"  id="inputEdited_'+json.result[0].properties[i].assetParamId+'">'+value+'</div>';*/
								propertiesValue += '<div class="ui inverted blurring dimmer" style="z-index:1;"> <div class="content"> <div class="center">'; 
								propertiesValue += '<div class="ui primary mini button" onclick="editRichTextArea('+json.result[0].properties[i].assetParamId+')">Edit rich text</div>';
								propertiesValue += '</div> </div></div>';
								propertiesValue += '</div></div>';
								
								
							}
							
							
							
							
							assetParamIdList.push(json.result[0].properties[i].assetParamId);
							var appendPropertiesData = loadPropertiesData(json.result[0].properties[i].cat_disp, json.result[0].properties[i].param_disp, json.result[0].properties[i].assetParamName, json.result[0].properties[i].assetParamId, propertiesValue, inputType,json.result[0].properties[i].description);
							$("#parameterTbody_"+json.result[0].properties[i].cat_disp).append(appendPropertiesData);
							
							
							
							$(".parameterInfo").popup();
							$('.upFile').on('change', function(t){
								var parId = $(this).attr('id');
								parId = parId.split('_');
								parId = parId[1];
								$('#hidden_'+parId).val($(this).val());
							});
							
							
							if(textFlag){
								if(json.result[0].properties[i].isStatic == 0){
									
									value = json.result[0].properties[i].paramValue;
									
								}else{
									
									value = json.result[0].properties[i].staticValue;
								}
								if(value == null ){
									value = "";
									
								}
								/*hljs.configure({
									lang : "xml",
									useBR: true
								});
								
								var formatted =  formatXml(value);
								formatted = formatted.trim();
								formatted =	hljs.highlightAuto(formatted);*/
								
								$("#input_"+json.result[0].properties[i].assetParamId).val(value);
								
							}
							
							if(dateFlag){
								$("#input_"+json.result[0].properties[i].assetParamId).datepicker({
								      changeMonth: true,
								      changeYear: true,
								      showWeek: true,
								      firstDay: 1,
								      dateFormat: "dd/mm/yy",
								      showButtonPanel: true,
								      beforeShow: function(input, inst) {
									        // Swathi -- Handle datepicker position before showing it.
									        // It's not supported by Datepicker itself (for now) so we need to use its internal variables.
									        var calendar = inst.dpDiv;
									        setTimeout(function() {
									            calendar.position({
									                my: 'right top',
									                at: 'right bottom',
									                collision: 'none',
									                of: input
									            });
									        }, 1);
									    }
								//end of code
								 });
							}
							
							if(listFlag){
								$("#input_"+json.result[0].properties[i].assetParamId).dropdown();
								$("#input_"+json.result[0].properties[i].assetParamId).parent().addClass("editProperties").attr("onclick","getAssetList("+json.result[0].properties[i].mappedAssetId+","+json.result[0].properties[i].assetParamId+")");
								$("#desc_"+json.result[0].properties[i].cat_disp+"_"+json.result[0].properties[i].param_disp).css("overflow","visible");
							}
							
							
							if(richTextFlag){
								
								$(".richTextCustomView").dimmer({
									  on: 'hover'
								});
								
								if(json.result[0].properties[i].isStatic == 0){

									value = json.result[0].properties[i].paramValue;

								}else{

									value = json.result[0].properties[i].staticValue;
								}
								
								if(value == null ){
									value = "";

								}
								
								/*if(value.startsWith("<pre")){
									var formatted = $("#showProperties_"+json.result[0].properties[i].assetParamId+" pre").text();
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);
									 $("#showProperties_"+json.result[0].properties[i].assetParamId+" pre").html(formatted.value);
								}*/
								
								
								/*var id = "input_"+json.result[0].properties[i].assetParamId;
								
								var editor = CKEDITOR.instances.id;
								if (editor) {
									editor.destroy(true);
								}
								
								CKEDITOR.replace(id, {
									toolbar : 'Basic',
									height : "10em"
								});
								
								if(json.result[0].properties[i].isStatic == 0){

									value = json.result[0].properties[i].paramValue;

								}else{

									value = json.result[i].staticValue;
								}
								
								if(value == null ){
									value = "";

								}
								
								var formatted =  formatXml(value);
								formatted = formatted.trim();
								formatted =	hljs.highlightAuto(formatted);

								//CKEDITOR.instances[id].setData(value);
								$("#"+id).html(formatted.value)*/
							}
							
							
				});
						
						if(custListAssetParamID != ""){
							custListAssetParamID = custListAssetParamID.substr(0, custListAssetParamID.lastIndexOf("~~"));
							getCustomList(custListAssetParamID);
						}
						
						/*if(assetListAssetId != ""){
							assetListAssetId = assetListAssetId.substr(0, assetListAssetId.lastIndexOf("~~"));
							assetListAssetParamID = assetListAssetParamID.substr(0, assetListAssetParamID.lastIndexOf("~~"));
							
							getAssetList(assetListAssetId,assetListAssetParamID)
							
						}*/
						
						

						if(userListAssetParamID != ""){
							
							var userListArr = [];
							userListAssetParamID = userListAssetParamID.substr(0, userListAssetParamID.lastIndexOf("~~"));
							userListAssetParamID = userListAssetParamID.split("~~");
							
							var userList = getActiveUserList(userListAssetParamID[0]);
							
							$.each(userListAssetParamID, function(i){
								var dropdownData = createListDropdown(userListAssetParamID[i],userList);
								$("#userList_"+userListAssetParamID[i]).html(dropdownData);
								var selectedData = $("#userListSelectValue_"+userListAssetParamID[i]).text().trim();
								
								if(selectedData == "" || selectedData == null){
									$("#input_"+userListAssetParamID[i]).dropdown();
								}else{
									selectedData = selectedData.split("~~");
								/*alert(jQuery.type(selectedData));*/
								$.each(selectedData,function(i){
									userListArr.push(encodeURIComponent(selectedData[i]));
								});
								/*alert("  user list selectedData"+userListArr);*/
								$("#input_"+userListAssetParamID[i]).dropdown("set selected",userListArr);
								}
								$("#input_"+userListAssetParamID[i]).parent().addClass("editProperties");//.attr("onclick","propertiesEditLock()");
							
							});
						
						}

					}
					
					
					
					
					
					/********************************************************************************************************************/
					//get tags data
					
					setTimeout(function(){ 
						$("#tagLoadingSegment").removeClass("loading");
					}, 0);
					$('#addNewTagSegment').html("");
					
					$("#noTagDataShow").hide();
					$('#addNewTagSegment').show();
					if(JSON.stringify(json.result[0].tags.tagNames) == "{}"){
						$("#addNewTagSegment").hide();
						$("#noTagDataShow").show();
					}else{
							$.each(json.result[0].tags.tagNames, function(key,value){
								var tagData = loadTagData(value);
								$('#addNewTagSegment').append(tagData);
								autoId++;						
							});
					}
					
					/********************************************************************************************************************/
					//get taxonomy data
					setTimeout(function(){ 
						$("#addNewTaxonomySegment").removeClass("loading");
					}, 10);
						
					
					if(json.result[0].taxonomy.length == 0){
						$("#addNewTaxonomySegment").html("No taxonomies added yet")
					}else{
						$.each(json.result[0].taxonomy, function(i) {
							$('#addNewTaxonomySegment').append('<a class="ui label" onclick="navigateToClickedTaxonomy('+json.result[0].taxonomy[i].taxonomyId+',\''+json.result[0].taxonomy[i].taxonomyName+'\')" id="taxonomyName_'+json.result[0].taxonomy[i].taxonomyId+'_'+json.result[0].taxonomy[i].taxonomyName.replace(/ /g,"_")+'" style="margin-bottom:0.5em;"><span style="display:none;">'+json.result[0].taxonomy[i].taxonomyId+'</span><i class="fork icon"></i>'+json.result[0].taxonomy[i].taxonomyName+'</a>');
							// HEMA
							taxFromBackend.push({"taxId":json.result[0].taxonomy[i].taxonomyId, "taxName":json.result[0].taxonomy[i].taxonomyName});
						});
						
					}
					/********************************************************************************************************************/
					
					
					//call other functions
					setTimeout(function(){	
						checkCompositionAggregationAssetType();
						getCompositionAggregationAssetType(); 
						getSiblingsOfChildAssetInstance();
					},0);
				
			}else{
				$('#loadContent').load("noAssetInstance.html");
			}
			checkAccessForUserOnSuccess();
			$(".editProperties").hide();
			$(".showProperties").show();
		}
	});
}

//add new instance data

function createNewInstance(){
	var newInstanceName = $("#editAssetInstName").val().trim();
	var tagData = $("#addNewTagName").val().trim();
	var taxonomyData = "";
	
	$("#addNewTaxonomySegment > div").each(function(){
		var id = $(this).attr("id");
		id = id.split("_");
		taxonomyData = id[1]+",";
		
	}); 
	taxonomyData = taxonomyData.replace(/,\s*$/, "");
	
	var messageData = CKEDITOR.instances['assetOverViewMessageTextArea'].getData();
	
	/*if(messageData != ""){
        var data = CKEDITOR.instances['assetOverViewMessageTextArea'].dataProcessor.toHtml(messageData);
        messageData = data;
      }*/
	
	savePropertiesData();
	/*var prepertiesData = $("#hiddenFormDataValue").val();
	$("#hiddenQueryParamValueAddInstance").val(prepertiesData);*/
	
	var addRelationshipIds = [];
	var addDestAivIds = [];
	$("#assignedRelationships > a").each(function(){
		var id = $(this).attr("id");
		id = id.split("_");
		
		addRelationshipIds.push(id[2]);
		addDestAivIds.push(id[1]);
	});
	
	var obj = {
			"assetId": assetId, 
			"userId": loggedInUserId,
			"activeFlag": loggedInUserActiveFlag,
			"assetName": assetName,
			"userName": loggedInUserName,
			"versionName":"1.0",
			"assetInstName": newInstanceName,
			"description": messageData,
			"TaxonomyIds": taxonomyData,
			"tagNames": tagData,
			"addRelationshipIds": addRelationshipIds,
			"addDestAivIds": addDestAivIds, 
	};
	
	$("#hiddenQueryParamValue").val(JSON.stringify(obj));
	
	
	$("#addNewSubmitButton").click();
	
}


//submit properties data 
function formDataSubmitAddNewInstance(){
		
	
	var xhr = "";
	
		$('#showAllDataInCustomizedLayout').submit(function(e){
			
			xhr = "";
			xhr = new XMLHttpRequest();
			xhr.open("POST","/repopro/web/assetInstance/createAssetInstance");
			xhr.onload = function(event){
					var json = JSON.parse(event.target.responseText);

					if(json.status == "SUCCESS"){
						
						localStorage.removeItem("editAIVPageFlag");
						localStorage.setItem("editAIVPageFlag", false);
						
						getAssetInstances(json.result[0].assetInstVersionId,json.result[0].assetInstName);
						
					   }else{
					     // alert("error");
					   }
			 };
			 
			var formData = new FormData(document.getElementById("showAllDataInCustomizedLayout"));
			xhr.send(formData);
			//window.close();
			return false;
		
		});
		
		

}

//add new instance ends
var getcallSuccess = false;
/********************** edit instance ****************************/
function editAIVPage(){
	$('#showHideLoader').addClass('active');
	var flag = false;
	if(globalSettingDetailsFlag){
		flag = getLockStatus();
		if(flag){
			if(lockedBySameUser){
				flag = false;
			}else{
				notifyMessage("Lock Asset Instance","Instance "+assetInstanceName+" is already locked","fail");
			}
		}
		else{
			lockAssetInstance();
		}
	}
	
	if(flag == false){
		//chandana 07-06-2019 (keyboard shotcut disabled)
	    	$(document).keyup(function(event) {
	    		  if(event.which === 32) {
	    		  	event.preventDefault();
	    		  }
	    		});
	    	
		editingEnabled = true;
		$("#editAIVPage").addClass("disabled");
		$("#assetRevisionHistoryTab").addClass("AIVDisabled");
		$("#assetVersionTab").addClass("AIVDisabled");
		$("#assetDiscussionTab").addClass("AIVDisabled");
		
		
		//floating buttons
		floatingButtonFlag = true;
		$("#assetInstancesFloatingButton").show();
		$("#assetInstancesFloatingButton").html("");
		var encodedAssetInstName= encodeURIComponent(assetInstanceName);
		encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
		
		
			$("#assetInstancesFloatingButton").html('<div><button class="ui primary mini  button" id="updateAIV" onclick="updateAIVPage()">Update</button>'
					   +'<button class="ui cancel themeSecondary mini button" id="cancelInstance" onClick="getAssetInstances('+assetInstanceVersionId+',\''+encodedAssetInstName+'\')">Cancel</button></div>');

		//instance name
		//var assetInstname = $("#assetInstanceTitle").attr("title").trim();
		//$("#editAssetInstName").val(assetInstname);
		//$("#assetInstanceTitle").hide();
		//$("#editAssetInstNameInputField").show();
		//$("#deleteNewlyCreatedInstance").hide();
		//$("#assetInstanceVersionIdTitle").hide();
		//$("#divVersionable").css("visibility","hidden");
		//$("#editAssetInstName").parent().removeClass("error");
		
		$("#editAssetInstName").hide();
		$("#assetInstanceTitle").show();
		$("#divVersionable").css("visibility","visible");
		$("#multiUseDropdown").css("visibility","hidden");
		
		//workflow
		$('#workflowDropdownParent').css("visibility","hidden");
		
		$("#updateAssetInstName").remove();
		$("#noChangeAssetInstName").remove();
		
		if($("#aivTags").hasClass("APINotCalledAIVPage")){
			if(!$("#aivTags").hasClass("hidden")){
				getTagData();
				$("#aivTags").removeClass("APINotCalledAIVPage");
				
				setTimeout(function(){
					//tags
					$("#addNewTagInputFields").toggle('blind');
					$("#addNewTagName").val("");
					$("#addNewTagName").parent().removeClass("error");
					$(".deleteTagClass").show();
					
					$("#saveTagName").remove();
					$("#cancelTagName").remove();
				},10)
			}
		}else{
			//tags
			$("#addNewTagInputFields").toggle('blind');
			$("#addNewTagName").val("");
			$("#addNewTagName").parent().removeClass("error");
			$(".deleteTagClass").show();
			
			$("#saveTagName").remove();
			$("#cancelTagName").remove();
		}
		
			
		if($("#aivTaxonomy").hasClass("APINotCalledAIVPage")){
		
			if(!$("#aivTaxonomy").hasClass("hidden")){
				getTaxonomyDataOnLoad();
				$("#aivTaxonomy").removeClass("APINotCalledAIVPage");
				
				setTimeout(function(){
					//taxonomy
					$("#openAssignTaxonomyModalButton").show();
				},10)
			}
		}else{
			//taxonomy
			$("#openAssignTaxonomyModalButton").show();
		} 
			//asset visualization -chandana - 06/11/2019
		
		if($("#assetVisualizationTab").hasClass("APINotCalledAIVPage")){
			
			if(!$("#assetVisualizationTab").hasClass("hidden")){
				getAssetVisualization();
				$("#assetVisualizationTab").removeClass("APINotCalledAIVPage");
				
				setTimeout(function(){
					//asset visualization
					$("#uploadSwaggerFileinAIVpage").show();
					$('#lastUpdatedFile').html(uploadedFileNameOnEdit)
					$('#noAssetVisualizationSegment').hide();
					$('#renderHTMLCode').show();
					$('#assetVisualizationSegment').attr("style","min-height: 0em !important;");
				},10)
			}
		}else{
			
			//asset visualization
			$("#uploadSwaggerFileinAIVpage").show();
			$('#noAssetVisualizationSegment').hide();
			$('#lastUpdatedFile').html(uploadedFileNameOnEdit)
			$('#renderHTMLCode').show();
			$('#assetVisualizationSegment').attr("style","min-height: 0em !important;");
		} 
			
		
		if($("#assetOverviewTab").hasClass("APINotCalledAIVPage")){
			if(!$("#assetOverviewTab").hasClass("hidden")){
				
				
				
				getAssetInstanceOverview();
				$("#assetOverviewTab").removeClass("APINotCalledAIVPage");
				
				var myVar = setInterval(function(){ 
					if(getcallSuccess){
						clearInterval(myVar);
						//overview
						$("#showAssetOverViewMessage").hide();
						$("#showAssetOverViewMessageButton").addClass("hideElement");
						$("#editAssetOverViewMessage").show();
						var editor = CKEDITOR.instances.msgBoardAdminMsgTextArea;
					    if (editor) {
					        editor.destroy(true); 
					    }   
					    CKEDITOR.replace('assetOverViewMessageTextArea');
					    var getData = $("#showAssetOverViewDescription").html();
					    CKEDITOR.instances['assetOverViewMessageTextArea'].setData(getData);
						
						$("#cancelAssetOverViewMessage").remove();
						$("#saveAssetOverViewMessageButton").remove();
					}
					
				}, 500);
				
				
				
				/*setTimeout(function(){
					//overview
					$("#showAssetOverViewMessage").hide();
					$("#showAssetOverViewMessageButton").addClass("hideElement");
					$("#editAssetOverViewMessage").show();
					var editor = CKEDITOR.instances.msgBoardAdminMsgTextArea;
				    if (editor) {
				        editor.destroy(true); 
				    }   
				    CKEDITOR.replace('assetOverViewMessageTextArea');
				    var getData = $("#showAssetOverViewDescription").html();
				    CKEDITOR.instances['assetOverViewMessageTextArea'].setData(getData);
					
					$("#cancelAssetOverViewMessage").remove();
					$("#saveAssetOverViewMessageButton").remove();
				},200);*/
			}
		}else{
			//overview
			$("#showAssetOverViewMessage").hide();
			$("#showAssetOverViewMessageButton").addClass("hideElement");
			$("#editAssetOverViewMessage").show();
			var editor = CKEDITOR.instances.msgBoardAdminMsgTextArea;
		    if (editor) {
		        editor.destroy(true); 
		    }   
		    CKEDITOR.replace('assetOverViewMessageTextArea');
		    var getData = $("#showAssetOverViewDescription").html();
		    CKEDITOR.instances['assetOverViewMessageTextArea'].setData(getData);
			
			$("#cancelAssetOverViewMessage").remove();
			$("#saveAssetOverViewMessageButton").remove();
		}
		
		if($("#assetPropertiesTab").hasClass("APINotCalledAIVPage")){
			if(!$("#assetPropertiesTab").hasClass("hidden")){
				getPropertiesData();
				$("#assetPropertiesTab").removeClass("APINotCalledAIVPage");
				
				setTimeout(function(){

					//properties
					$(".editProperties").show();
					$(".showProperties").hide();
					
					$(".showProperties.newTextFieldStyle").show();
					$(".editTextdimmerButtonStyle").show();
					$(".showOrEditButton").removeClass("showText").text("Edit text");
					$(".textFieldMsg").text("Click on Edit button to edit the values.");
					
					
					
					$("#editPropertiesDataEditButton").addClass("hideElement");
					$("#propSubBtn,#propCancelBtn").show();
					
					
					$(".showOrEditButton").popup({
						 inline     : true,
						 variation : 'inverted',
						 html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on edit button to edit the values !</spam></div>'
					 });
					
					$("#propSubBtn").remove();
					$("#propCancelBtn").remove();
				},10)
				
			}
		}else{

			//properties
			$(".editProperties").show();
			$(".showProperties").hide();
			
			$(".showProperties.newTextFieldStyle").show();
			$(".editTextdimmerButtonStyle").show();
			$(".showOrEditButton").removeClass("showText").text("Edit text");
			$(".textFieldMsg").text("Click on Edit button to edit the values.");
			
			
			
			$("#editPropertiesDataEditButton").addClass("hideElement");
			$("#propSubBtn,#propCancelBtn").show();
			
			
			$(".showOrEditButton").popup({
				 inline     : true,
				 variation : 'inverted',
				 html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on edit button to edit the values !</spam></div>'
			 });
			
			$("#propSubBtn").remove();
			$("#propCancelBtn").remove();
		} 
			
		if($("#assetRelationshipAndRevRelationshipTab").hasClass("APINotCalledAIVPage")){
			if(!$("#assetRelationshipAndRevRelationshipTab").hasClass("hidden")){
				getReverseRelationships();
				$("#assetRelationshipAndRevRelationshipTab").removeClass("APINotCalledAIVPage");
				
				setTimeout(function(){
					//relationship
					editRelationshipTreeData();
					$("#cancelAssignedRelationships").remove();
					$("#updateAssignedRelationships").remove();
				},10)
			}
		}else{
			//relationship
			editRelationshipTreeData();
			$("#cancelAssignedRelationships").remove();
			$("#updateAssignedRelationships").remove();
		}
		// Asset Visiualization
		
		
		
				
		

	}
	
	setTimeout(function(){
		$('#showHideLoader').removeClass('active');
	},10);

	
}

//update AIV page
function updateAIVPage(){

	var flag = true;
	
		//instance name validation 
	
		if(editAIVPageFlag == "true"){
			$("#editAssetInstName").parent().removeClass("error");
			$(".errInstName").hide();
			
			var newAssetInstName = $("#editAssetInstName").val().trim();
			
			if(newAssetInstName == "" || newAssetInstName  == null){
				$("#editAssetInstName").parent().addClass("error");
				$(".errInstName").html("Please provide the instance name").show();
				//scrollToError("editAssetInstName");
				//notifyMessage("Rename Instance","Please provide the instance name","fail");
				flag = false;
		  		//return false;
			}else{
					
				var iChars = "`!%^*=[];{}|<>?~";
				  
				  for (var i = 0; i < newAssetInstName.length; i++){
				  	if (iChars.indexOf(newAssetInstName.charAt(i)) != -1){
				  		$("#editAssetInstName").parent().addClass("error");
				  		$(".errInstName").html("Special characters except ':'\"+#$/\&(),-_.@' are not allowed").show();
				  		//scrollToError("editAssetInstName");
				  		//notifyMessage("Rename Instance","Special characters except ':'\"+#$/\&(),-_.@' are not allowed","fail");
				  		flag = false;
				  		//return false;
				  	}
				  }
			}
			if(newAssetInstName == assetInstanceName){
				newAssetInstName = "";
			}
		}else{
			var newAssetInstName = "";
		}
				
		//send empty if no files selected in asset visualisation tab - chandana - 12.12.19
		if($('#uploadNewHTMLfile').val() == "" || $('#uploadNewHTMLfile').val() == null ){
			$('#uploadSwaggerFileBtn').attr('name',"");
		}else{
			$('#uploadSwaggerFileBtn').attr('name','uploadedJarSupportFile');
		}
		
		
		//tags validation 
			if($('#aivTags').is(":visible")) {
			
						$("#addNewTagName").parent().parent().removeClass("error");
						$(".errTagList").hide();
						
						var tagFlag = true;
						var getTagName;
						var tagNames = "";
						//var getNewTagName = $("#addNewTagName").val().trim();
						
						//-------Chandana------//
					
						var getNewTagName = $("#addNewTagName").val().replace(/ ^\b \b /,"");
						var diffTagName = getNewTagName.split(",");
						diffTagName = Array.from(new Set(diffTagName));
						
						diffTagName = diffTagName.map(function (el) {
							return el.trim();
							});
						diffTagName = Array.from(new Set(diffTagName));
						diffTagName = diffTagName.filter(function(v){return v!==''});
						diffTagName.reverse();
						
							$.each(diffTagName,function(i){
								var tagName = (diffTagName[i]).trim();
								var regex = /^[a-zA-Z0-9- \-\_]*$/;
								if(regex.test(tagName) == false){
										tagFlag = false;
										flag = false;
										$("#addNewTagName").parent().parent().addClass("error");
										$(".errTagList").html("Please use only alphanumeric characters, space, \"-\" and \"_\" in tags").show();
										//scrollToError("aivTags");
										//return false;
										//notifyMessage("Add new Tag","Please use only alphanumeric characters, space, \"-\" and \"_\" in tags","fail");
									
								}
							});
							
							
								
							$.each(diffTagName,function(i){	
								var tagName = (diffTagName[i]).trim();
								$("#addNewTagSegment > a").each(function(key){
									var data = $(this).find('span').text();
										if(data == tagName){
											tagFlag = false;
											flag = false;
											$("#addNewTagName").parent().parent().addClass("error");
											$(".errTagList").html("Tag name '"+tagName+"' already added").show();
											//scrollToError("aivTags");
											//notifyMessage("Add new Tag","Tag name '"+tagName+"' already added","fail");
											//return false;
										}
									});	
								});
							
								if(tagFlag){
									$.each(diffTagName,function(i){	
										var tagName = (diffTagName[i]).trim();
										if(!tagName == null || tagName != ""){	
											appendData = loadTagData(tagName);
											$("#addNewTagSegment").append(appendData);
											autoId++;
											$("#noTagDataShow").hide();
											$("#addNewTagSegment").show();
										}
									});
									
									
									
									$("#addNewTagName").val("");
							
									$("#addNewTagSegment > a").each(function(key){
										key++;
										getTagName = $(this).find('span').text();
										
										tagNames += getTagName+",";
									});
									tagNames = tagNames.replace(/,\s*$/, "");
									$(".deleteTagClass").show();
								}
				var showTagFlag = true;
			}else{
				var showTagFlag = false;
				var tagNames = "";
			}
			
			
		//taxonomy 	validation	
			
			if($('#aivTaxonomy').is(":visible")) {
				var taxonomyData = "";
				$("#addNewTaxonomySegment > a").each(function(){
						var id = $(this).attr("id");
						id = id.split("_");
						taxonomyData += id[1]+",";
								
					}); 
				
				taxonomyData = taxonomyData.replace(/,\s*$/, "");	
				var taxonomyShowFlag = true;
			}else{
				var taxonomyShowFlag = false;
				var taxonomyData = "";
			}
			
					
		//overview validation
			if($('#assetOverviewTab').is(":visible")) {
				$(".errOverView").hide();	
				
				//trimming white spaces and strings with empty values - chandana 21.02.2020
				var getTextfromCKeditor = $(".cke_contents iframe").contents().find("body").text();
				var trimextfromCKeditor = $.trim(getTextfromCKeditor);
				var messageData = CKEDITOR.instances['assetOverViewMessageTextArea'].getData();
				if(getTextfromCKeditor == "" || getTextfromCKeditor == null || trimextfromCKeditor == ""){
					messageData = '';
				}
				else{
					messageData = messageData;
				}
				/*if(messageData != ""){
			        var data = CKEDITOR.instances['assetOverViewMessageTextArea'].dataProcessor.toHtml(messageData);
			        messageData = data;
			      }*/
				 
				if(messageData == "" || messageData == null){
					$(".errOverView").html("Please provide a description").show();	
					//scrollToError("assetOverviewTab");
					flag = false;
					//return false;
				}
			}else{
				var messageData = "";
			}	
			
		//properties validations
			if($('#assetPropertiesTab').is(":visible")) {
				var propFlag = savePropertiesData();
				if(propFlag == false){
					flag = false;
				}
				var parameterList = [];
				parameterList = $("#hiddenFormDataValue").val();
				
				if(parameterList == "[]"){
					parameterList = "";
				}
				//console.log(parameterList)
				
			}else{
				var parameterList = "";
			}	
			
		//relationship validation
			if($('#assetRelationshipAndRevRelationshipTab').is(":visible")) {
				updateAssignedRelationships();
				var addRelationshipIds = [];
				var addDestAivIds = [];
				var removeRelationshipIds = [];
				var removeDestAivIds = [];
				
				var hiddenRelationshipData = JSON.parse($("#hiddenRelationshipData").val());
				
				addRelationshipIds = hiddenRelationshipData.addRelationshipIds;
				addDestAivIds = hiddenRelationshipData.addDestAssetInstVersionIds;
				removeRelationshipIds = hiddenRelationshipData.removedRelationshipIds;
				removeDestAivIds = hiddenRelationshipData.removedDestAssetInstVersionIds;
				
			}else{
				var addRelationshipIds = [];
				var addDestAivIds = [];
				var removeRelationshipIds = [];
				var removeDestAivIds = [];
			}		
					
					
		if(flag){
			$('#showHideLoader').addClass('active');
			if(editAIVPageFlag == "true"){
				if(addChildAIVFlag == "true"){
					//add new child instance fro parent instance
					var parentData = localStorage.getItem("addChildObject");
					parentData = JSON.parse(parentData);
					var addFlag = true;
					var obj = {
							"addFlag": addFlag,
							"assetId": assetId,
							"userId": loggedInUserId,
							"activeFlag": loggedInUserActiveFlag,
							"assetName": assetName,
							"userName": loggedInUserName,
							"versionName":"1.0",
							"assetInstName": encodeURIComponent(newAssetInstName),
							"description": messageData,
							/*"TaxonomyIds": taxonomyData,
							"tagNames": tagNames,*/
							"addRelationshipIds":addRelationshipIds,
							"addDestAivIds":addDestAivIds,
							"removeRelationshipIds":[],
							"removeDestAivIds":[],
							"parameterList": parameterList,
							"parentAssetInstVersionId": parentData.parentAssetInstVersionId,
							"parentAssetId": parentData.parentAssetId,
							"parentVersionName": parentData.parentVersionName,
							"parentAssetInstName": encodeURIComponent(parentData.parentAssetInstName),
							"owner": parentData.owner
						};
					
					
				}else{
					//add new instance
					var addFlag = true;
					var obj = {
							"addFlag": addFlag,
							"assetId": assetId,
							"userId": loggedInUserId,
							"activeFlag": loggedInUserActiveFlag,
							"assetName": assetName,
							"userName": loggedInUserName,
							"versionName":"1.0",
							"assetInstName": encodeURIComponent(newAssetInstName),
							"description": messageData,
							/*"TaxonomyIds": taxonomyData,
							"tagNames": tagNames,*/
							"addRelationshipIds":addRelationshipIds,
							"addDestAivIds":addDestAivIds,
							"removeRelationshipIds":[],
							"removeDestAivIds":[],
							"parameterList": parameterList
						};
				}
				/*console.log("obj"+JSON.stringify(obj));
				conole.log($("#assetInstanceDetails").val(JSON.stringify(obj)))*/
			}else{
				
				//edit existing instance
				var addFlag = false;
				
				var obj = {
						"addFlag": addFlag,
						"assetId": assetId,
						"userId": loggedInUserId,
						"activeFlag": loggedInUserActiveFlag,
						"assetName": assetName,
						"userName": loggedInUserName,
						"versionName": versionName,
						"assetInstName": encodeURIComponent(assetInstanceName),
						/*"TaxonomyIds": taxonomyData,
						"tagNames": tagNames,*/
						"addRelationshipIds":addRelationshipIds,
						"addDestAivIds": addDestAivIds,
						"removeRelationshipIds": removeRelationshipIds,
						"removeDestAivIds": removeDestAivIds,
						"assetInstanceId": assetInstanceId,
						"assetInstVersionId": assetInstanceVersionId,
						"newAssetInstanceName": encodeURIComponent(newAssetInstName),
						"newDescription": messageData,
						"parameterList": parameterList
					};
				
			}
			
			if(showTagFlag){
				obj["tagNames"] = tagNames;
			}
			
			if(taxonomyShowFlag){
				obj["TaxonomyIds"] = taxonomyData;
			}
			
			
				$("#assetInstanceDetails").val(JSON.stringify(obj));
				var url = "";
				if(editAIVPageFlag == "true"){
					if(addChildAIVFlag == "true"){
						url = "/repopro/web/assetInstance/updateChildAssetInstance";
					}else{
						url = "/repopro/web/assetInstance/updateAssetInstance";
					}
				}else{
					url = "/repopro/web/assetInstance/updateAssetInstance";
				}
				
				//console.log(JSON.stringify(obj))
				xhr = "";
				xhr = new XMLHttpRequest();
					
				xhr.open("POST",url);
				xhr.onload = function(event){
					$('#showHideLoader').removeClass('active');
						var json = JSON.parse(event.target.responseText);
						//console.log(JSON.stringify(json))
						if(json.status == "SUCCESS"){
							
							localStorage.removeItem("editAIVPageFlag");
							localStorage.setItem("editAIVPageFlag", false);
							if(editAIVPageFlag == "true"){
								notifyMessage("Create Asset Instance","Asset Instance successfully created","success");
							}else{
								notifyMessage("Update Asset Instance","Asset Instance successfully updated","success");
								if($("#lockUnlockAssetInstance").hasClass("lock")){
									//$("#lockStatusMessage").html("");
									setTimeout(function(){
										//unlockInstance();
										lockUnlockAssetInstance();
										$("#editBtnAfterLock").addClass("disabled");
									},1500);
								}
							}
							getAssetInstances(json.result[0].assetInstVersionId,json.result[0].assetInstName);
							
						}else{
							var message = json.message;
							var lockFlag = false;
							
							if(message == "ASSET_INSTANCE_ALREADY_EXIST"){
								message = "Asset instance name aready exists. Please provide some other name."
								$("#editAssetInstName").parent().addClass("error");
							}else if(message == "ASSET_INSTANCE_VERSION_ALREADY_UNLOCKED"){
								message = "Asset instance already unlocked.";
								lockFlag = true;
							}else if(message == "ASSET_INSTANCE_VERSION_ALREADY_LOCKED"){
								message = "Asset instance locked by other user.";
								lockFlag = true;
							}else if(message == "LOCK_TIME_EXPIRED"){
								message = "Lock time has expired.";
								lockFlag = true;
							}
							
							if(editAIVPageFlag == "true"){
								notifyMessage("Create Asset Instance",message,"fail");
							}else{
								notifyMessage("Update Asset Instance",message,"fail");
								if(lockFlag){
									getAssetInstances(assetInstanceVersionId,assetInstanceName);
								}
							}
						      
						}
						
				 };
				 
				var formData = new FormData(document.getElementById("showAllDataInCustomizedLayout"));
				xhr.send(formData);
				//window.close();
				return false;
			
			
		}else{
			if(editAIVPageFlag == "true"){
				notifyMessage("Create Asset Instance Failed","Please address the highlighted errors","fail");
			}else{
				notifyMessage("Update Asset Instance Failed","Please address the highlighted errors","fail");
			}
		}
					
				
			
	
	
}


function toggleEditAfterLock(){
	editAIVPage();
	$("#editBtnAfterLock").addClass("disabled");
}

function scrollToError(href){
	$("html, body").animate({
        scrollTop: $("#"+href).offset().top-150
    }, 500);
}

/******************* edit instance ends ***********************/

/*****souradip***8.5.18*****/
//toggle Graph Table view
var buildRelTableFlag = true;
function toggleGraphTable(obj){
	$(".relCommonItem").removeClass("active");
	$(obj).addClass('active');
	if($(obj).hasClass("graphView")){
		$("#treeGraphView").show();
		$("#treeTableView").hide();
		
	}else{
		$("#treeGraphView").hide();
		$("#treeTableView").show();
		if(buildRelTableFlag){
			buildRelTableFlag = false;
			createRelTable();
		}
		
	}
}

//create relationship table
function createRelTable(){
	var json = JSON.parse(localStorage.getItem("relTableObj"));
	
	if((json.isEnd) == 1){
		$("#relationshipAIVTable").show();
		$("#noRelationshipAIVTable").hide();
		$("#relationshipAIVTable tbody").html("");
		//console.log(JSON.stringify(json))
		$.each(json.children,function(i){
			var instName = (json.children[i].name).split("~"); 
			var encodedAssetInstName= encodeURIComponent(instName[0]);
			encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
			var imageName = "default";
			if(typeof json.children[i].icon != "undefined"){
				var imageType = json.children[i].icon ;
				/*imageType = imageType.split(".");
				imageName = imageType[1];*/
				imageName = (json.children[i].icon).substring((json.children[i].icon).lastIndexOf(".") + 1, (json.children[i].icon).length);
			}
			
			
			
			appendData = "";
			appendData += '<tr>';
			
			var icon = "";
			var assetId = json.children[i].childAssetId;
			if(imageName == "default"){
				if(circularThemeColoredIcon){
					icon += '<div class="mediumIconImageCircleStyle_asset_themeCircle">';
					if(invertAssetIconFlag){
						icon += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png"></div>';
					}else{
						icon += '<image class="ui  image mediumIconImageStyle_themeCircle"  src="/repopro/semantic/images/defaultAssetIcon.svg"></div>';
					}
				}else{
					icon += '<div class="mediumIconImageCircleStyle_asset">';
					if(invertAssetIconFlag){
						icon += '<image class="ui  image mediumIconImageStyle invertImageColor" style="margin-top: 16% !important;" src="/repopro/semantic/images/inverted_defaultAssetIcon.png"></div>';
					}else{
						icon += '<image class="ui  image mediumIconImageStyle" style="margin-top: 16% !important;" src="/repopro/semantic/images/defaultAssetIcon.svg"></div>';
					}
				}
				
			}else{
				if(circularThemeColoredIcon){
					icon += '<div class="mediumIconImageCircleStyle_asset_themeCircle">';
					if(invertAssetIconFlag){
						icon += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" data-src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'"></div>';
					}else{
						icon += '<image class="ui  image mediumIconImageStyle_themeCircle"  !important;" src="/repopro/semantic/images/defaultAssetIcon.svg" data-src="/repopro/assetImages/'+assetId+'.'+imageName+'"></div>';
					}
				}else{
					icon += '<div class="mediumIconImageCircleStyle_asset">';
					if(invertAssetIconFlag){
						icon += '<image class="ui  image mediumIconImageStyle invertImageColor" style="margin-top: 16% !important;"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png" data-src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'"></div>';
					}else{
						icon += '<image class="ui  image mediumIconImageStyle" style="margin-top: 16% !important;" src="/repopro/semantic/images/defaultAssetIcon.svg" data-src="/repopro/assetImages/'+assetId+'.'+imageName+'"></div>';
					}
				}
			}
			
			appendData += '<td>'+icon+'<a  class="tableViewAssetStyle" onclick="legendAssetGridPage('+json.children[i].childAssetId+',\''+json.children[i].assetName+'\')">'+json.children[i].assetName+'</a></td>';
			appendData += '<td><a style="cursor:pointer;" onclick="getAssetInstances('+json.children[i].assetInstanceVersionId+',\''+encodedAssetInstName+'\')">'+(json.children[i].name).replace("~","_")+'</a></td>';
			appendData += '<td>'+json.children[i].relationShip+'</td>';
			
			if(json.children[i].colour == "red"){
				appendData += '<td>Aggregation</td>';
	    	  }else if(json.children[i].colour == "blue"){
	    		appendData += '<td >Association</td>';
	    	  }else if(json.children[i].colour == "grey"){
	    		appendData += '<td >Composition</td>';  
	    	  }else if(json.children[i].colour == "green"){
	    		appendData += '<td >Classification</td>';
	    	  }
			
			appendData += '</tr>';
			$("#relationshipAIVTable tbody").append(appendData);
			lazyLoadingImage();
		});
		
	}else{
		$("#relationshipAIVTable").hide();
		$("#noRelationshipAIVTable").show();
		
	}
		
		
}

/*****ends*****/

//d3 code souradip
var heightParam = 1000;
var relTableData = true;
function getRelationTreeData(assetInstVersionId){
	var relationId = "";
	$.each(relationNameList,function(i){
		relationId += relationNameList[i]+"!";
	});
	relationId = relationId.replace(/!$/, "");
	
	$.ajax({
		type : "GET",
		url : "/repopro/web/relationship/relation/loaddependencies?assetName="+encodeURIComponent(assetName)+"&assetInstanceVersionId="+assetInstVersionId+"&relationId="+relationId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			
			$("#relationshipLoadingSegment").removeClass("loading");
			
			if(json.status == "SUCCESS"){
				
			var val = json.result[0];
			
			/*val = JSON.stringify(val).replace(/\\\\\\"/g, '');
			val = val.replace(/\\/g, '');
			val =  val.replace(/^[^"]*"(.*)"[^"]*$/, '$1');*/
			
			val = decodeURIComponent(val);
			
			if(relTableData){
				relTableData = false;
				localStorage.removeItem("relTableObj");
				localStorage.setItem("relTableObj", val);
			}
			
			globalTreeValue =  val;
			checkAccessForUserOnSuccess();
			//console.log(val)
		/*	var height = (heightParam * ((JSON.parse(globalTreeValue).children.length / 10))) - margin.top - margin.bottom;
			alert(height);
			d3.select("#relationshipTree").select("svg").select("g").attr("width", svgWidth + "%").attr("height", height);*/
		}
		}
	});
	
	
}


//get Relation Name Id
var relationNameList = [];
function getRelationNameId(assetInstVersionId){
	relationNameList.length = 0;
	$.ajax({
		type : "GET",
		url : "/repopro/web/relationship/getrelationNameId?assetInstVersionId="+assetInstVersionId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$.each(json.result,function(i){
					if(jQuery.inArray(json.result[i].description+"-"+json.result[i].fwdRelId, relationNameList) == -1){
						relationNameList.push(json.result[i].description+"-"+json.result[i].fwdRelId);
					}
					
				});
			}
		}
	});
	//console.log(relationNameList)
	getRelationTreeData(assetInstVersionId);
}



var margin = {top: 20, right: 100, bottom: 20, left: 300},
    width = 960 - margin.right - margin.left,
    height = heightParam - margin.top - margin.bottom,
    svgWidth = 500;

var nodeId = 0,
    duration = 750;
var heightRatio = 80;

var root;



var tree = d3.layout.tree()
	.separation(function(a, b) { return ((a.parent == root) && (b.parent == root)) ? 1.5 : 3; })
    .size([height, svgWidth]);

var diagonal = d3.svg.diagonal()
    .projection(function(d) { return [d.y, d.x]; });
;

var svg = d3.select("#relationshipTree").append("svg")
	.attr("id","svgDraggable")
    .attr("width", svgWidth + "%")
    .attr("height", height + margin.top + margin.bottom)
    .style("zoom","125%")
     /*.call(d3.behavior.zoom().on("zoom", function () {
    svg.attr("transform", "translate(" + d3.event.translate + ")" + " scale(" + d3.event.scale + ")") //zoom and drag
  }))*/
    .append("g")
    .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    
legendList = [];	
	

//Add tooltip div
var div = d3.select("body").append("div")
.attr("class", "tooltip")
.style("display", "none");

//add zoom functionality
var zoom = function() {
    var scale = d3.event.scale,
        translation = d3.event.translate,
        tbound = -height * scale,
        bbound = height * scale,
        lbound = (-width + margin.right) * scale,
        rbound = (width - margin.left) * scale;
    // limit translation to thresholds
    translation = [
        Math.max(Math.min(translation[0], rbound), lbound),
        Math.max(Math.min(translation[1], bbound), tbound)
    ];

    svg.attr("transform", "translate(" + translation + ")" + " scale(" + scale + ")");
}


/* d3.json("flare.json", function(error, flare) {
  if (error) throw error;
 */
  //root = flare;
function setup(){

	if(root.children) {

		var noOfChildren = root.children.length;
		var count = 0;
		
		for(var i=0;i<noOfChildren;i++) {
			if(root.children[i].isEnd=="0") {
				count += 1;
			}
		}
		if(count==noOfChildren) {
			assignHeight(noOfChildren);
		}
		if(noOfChildren>height/20){
			assignHeight(noOfChildren);
		}

	} else {
		assignHeight(1);
	}
	
  root.x0 = height / 2;
  root.y0 = 0;
  if(typeof root.children !== "undefined"){
	  root.children.forEach(checkChild);
	  root.children.forEach(collapse);
	  root.children = getRelationship(root.children);
  } 
  update(root);
  $( "#svgDraggable" ).draggable();
  
}


   function collapse(d) {
    if (d.children) {
      d._children = d.children;
      d._children.forEach(collapse);
      d.children = null;
    }
  }
 

//});

//d3.select(self.frameElement).style("height", "800px");


function assignHeight(noOfChildren) {

	if((noOfChildren * heightRatio) < (heightParam - margin.top - margin.bottom)) {
		height = (noOfChildren * heightRatio);
	}
	if(noOfChildren>height/20){
		height = (noOfChildren * 20);
	}
	
	var el = document.getElementById("relationshipTree");
	el.style.height = height + 100 + "px"; 
	tree.size([height, svgWidth]);
	d3.select("#relationshipTree").select("svg").attr("height", height + 100);
}

function update(source) {

  // Compute the new tree layout.
  var nodes = tree.nodes(root).reverse(),
      links = tree.links(nodes);


  // Normalize for fixed-depth.
  nodes.forEach(function(d) { d.y = d.depth * 175; });

  // Update the nodes…
  var node = svg.selectAll("g.node")
      .data(nodes, function(d) { return d.id || (d.id = ++nodeId); });

  // Enter any new nodes at the parent's previous position.
  var nodeEnter = node.enter().append("g")
      .attr("class", "node")
      .attr("transform", function(d) { return "translate(" + source.y0 + "," + source.x0 + ")"; })
      .on("click", click);

	nodeEnter.append("circle")
      .attr("r", function(d){return (d.isRelation) ? 1e-6 : 12;})//1e-6)
      .style("fill", function(d) { return d._children ? "#93d1ff" : (d.children ? "#93d1ff" : "#fff");})
      .style("cursor",function(d){return d._children ? "pointer" : (d.children ? "default" : "default");});

    nodeEnter
      .append("image")
      .attr("id", "asset")
      .attr("x", "-6")
      .attr("y", "-6") 
      .attr("width", "12")
      .attr("height", "12")
      .style("cursor",function(d){return d._children ? "pointer" : (d.children ? "default" : "default");})
      .attr("xlink:href", function(d) {
    	  if (d.isRelation) { 
    		  return "" ; 
    	  }
    	  else {
	    	 var imageUrl = "";
	    	 var imageName = d.icon;
	    	 var assetId;
	    	 if(d.childAssetId != undefined){
	    		 assetId = d.childAssetId;
	    	 }else{
	    		 assetId = d.parentAssetId;
	    	 }
	    	 if(imageName == null || imageName == ""){
	    		 imageUrl = "/repopro/semantic/images/defaultAssetIcon.svg";
	    	 }else{
	    		/* var type = imageName.split(".");*/
	    		 var type = (imageName).substring((imageName).lastIndexOf(".") + 1, (imageName).length);
	    		 //Chandana - 12/09/2019 - uppercase broken image 
	    		 if (type == 'PNG' || type == 'JPEG' || type == 'JPG'){
	    			 type = type.toLowerCase()
	    			}
	        	 imageUrl = "/repopro/assetImages/"+assetId+"."+type;
	    	 }
	    	 
	    	 return  imageUrl;
    	  }
      });

  var textNode = nodeEnter.append("text")
  .attr("x", function(d) {
    	  if(d.isRelation)
    		return 1;
    	  else  
			return d.children || d._children ? -20 : 20;
   	  })
      .attr("dy", function(d){
    	  if(!(d.children || d._children)) {
    		  return ".35em";
    	  } else if(d.parent) {
    		  var mean = (d.parent.children.length / 2);
    		  if(d.index < mean) {
    			  return "-.35em";    			  
    		  } else if(d.index >= mean) {
    			  return ".9em";
    		  }
    	  }
    	  if(d.isRelation)
      		return -4;
      })
/*      .attr("x", function(d) { return d.children || d._children ? -20 : 20; })
      .attr("dy", ".35em")*/
      .attr("text-anchor", function(d) { return d.children || d._children ? "end" : "start"; })
      .style("cursor","pointer")
      .html(function(d) { 
    	
    	  if(jQuery.inArray(d.assetName, legendList) == -1){
    		  if(d.assetName != undefined){
    			  legendList.push(d.assetName);
    			  var imageName = "default";
    			  if(d.icon != null){
    				  var imageType = d.icon;
    				  //imageType = imageType.split(".");
    				 // imageName = imageType[1];
    				  imageName = (d.icon).substring((d.icon).lastIndexOf(".") + 1, (d.icon).length);

    			  }
    			 
	    			  appendData = "";
	    			  /*appendData = '<a style="cursor: pointer;" onclick="legendAssetGridPage('+d.childAssetId+',\''+d.assetName+'\')">'+d.assetName+'</a>';*/
	    			  appendData += '<a class="ui image label" style="font-size: 9px;word-break: break-all; margin-top:0.5em; margin-left:0.5em;background:none;" onclick="legendAssetGridPage('+d.childAssetId+',\''+d.assetName+'\')">';
	    			  
	    			 
	    			  if(imageName == "default"){
	    				 
	    				  if(circularThemeColoredIcon){
	    					  appendData += '<div class="ui right spaced  image smallIconImageCircleStyle_themeCircle " style="font-size: 8px;">';
	    					  if(invertAssetIconFlag){
	    						  appendData += '<img class="smallIconImageStyle invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png">'; 
	    					  }else{
	    						  appendData += '<img class="smallIconImageStyle"  src="/repopro/semantic/images/defaultAssetIcon.svg">'; 
	    					  }
	    				  }else{
	    					  appendData += '<div class="ui right spaced  image smallIconImageCircleStyle smallIconImageCircleRemove" style="font-size: 8px;">';
	    					  if(invertAssetIconFlag){
	    						  appendData += '<img class="smallIconImageStyle invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png">'; 
	    					  }else{
	    						  appendData += '<img class="smallIconImageStyle"  src="/repopro/semantic/images/defaultAssetIcon.svg">'; 
	    					  } 
	    				  }
	    				  
	    			  }else{
	    					if (imageName == 'PNG' || imageName == 'JPEG' || imageName == 'JPG'){
	    						imageName = imageName.toLowerCase()
	    					}

	    				  if(circularThemeColoredIcon){
	    					  appendData += '<div class="ui right spaced  image smallIconImageCircleStyle_themeCircle " style="font-size: 8px;">'; 
	    					  
	    					  if(invertAssetIconFlag){
	    						  appendData += '<img class="smallIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" data-src="/repopro/assetImages/inverted_'+d.childAssetId+'.'+imageName+'">';  
	    					  }else{
	    						  appendData += '<img class="smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg" data-src="/repopro/assetImages/'+d.childAssetId+'.'+imageName+'">';
	    					  }
	    				  }else{
	    					  appendData += '<div class="ui right spaced  image smallIconImageCircleStyle smallIconImageCircleRemove" style="font-size: 8px;">';
	    					  
	    					  if(invertAssetIconFlag){
	    						  appendData += '<img class="smallIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" data-src="/repopro/assetImages/inverted_'+d.childAssetId+'.'+imageName+'">';
	    					  }else{
	    						  appendData += '<img class="smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg" data-src="/repopro/assetImages/'+d.childAssetId+'.'+imageName+'">';
	    					  }
	    				  }
	    				  
	    			  }
	    			  
	    			  
	    			  appendData += '</div><span>'+d.assetName+'</span></a>';
	    			  
	    			  $("#legendListContents").append(appendData);
	    			  $("#legendListLinkNoData").hide();
	    			  $("#legendListLink").show();
	    			  lazyLoadingImage();
    		  }
    	  }
    	  
    	  if(legendList.length == 0){
    		  $("#legendListLinkNoData").hide();
    		  //$("#legendListLinkNoData").show().html("There are no legends.");
    		  $("#legendListLink").hide();
    	  }
    	 
    	/* var assetInstName = d.name; 
    	 var assetInstNameMini = d.name;
    	 if(assetInstNameMini.length > 15){
    		 assetInstNameMini = assetInstNameMini.substring(0,15) + "..";
    	 } 
    	 assetInstName = assetInstName.split("~");
    	 var assetInstVarsionId  = d.assetInstanceVersionId;
    	 var encodedAssetInstName= encodeURIComponent(assetInstName[0]);
    		encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
    	 var returnData = "";
    	 if(assetInstVarsionId != undefined){
    		 returnData = '<a class="d3AnchorStyle"  onclick="getAssetInstances('+assetInstVarsionId+',\''+encodedAssetInstName+'\')">'+(assetInstNameMini).replace("~","_")+'</a>';
    	 }else{
    		 returnData = "<a style='cursor:default;'>"+(assetInstNameMini).replace("~","_")+"</a>";
    	 } 
    	 	
      	
    	 return returnData;*/
      })
      .style("fill-opacity", 1e-6)
      .on("mouseover", mouseover)
      .on("mousemove", function(d){mousemove(d);})
      .on("mouseout", mouseout);

  textNode.append("a")
  .attr("class", function(d) {
 	 var assetInstVarsionId  = d.assetInstanceVersionId;
 	 
	  if(assetInstVarsionId != undefined){
	  	return "d3AnchorStyle"; 
	  } else {
		  return "d3AnchorNoDataStyle";
	  }})
	  .text(function(d) {
		  var assetInstNameMini = d.name;
	    	 if(assetInstNameMini.length > 15){
	    		 assetInstNameMini = assetInstNameMini.substring(0,15) + "..";
	    	 }
		  return (assetInstNameMini).replace("~","_");
		  })
		  .attr("onclick", function(d){
			  var assetInstName = d.name; 
		    	 assetInstName = assetInstName.split("~");
		    	 var assetInstVarsionId  = d.assetInstanceVersionId;
		    	 var encodedAssetInstName= encodeURIComponent(assetInstName[0]);
		    		encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
			  if(assetInstVarsionId != undefined){
			  return 'getAssetInstances('+assetInstVarsionId+',\''+encodedAssetInstName+'\')';
			  }
		  })
		  ;
  
  
  // Transition nodes to their new position.
  var nodeUpdate = node.transition()
      .duration(duration)
      .attr("transform", function(d) { return "translate(" + d.y + "," + d.x + ")"; })
      .style("cursor",function(d){return d._children ? "pointer" : (d.children ? "default" : "default");});

   nodeUpdate.select("circle")
      .attr("r", function(d){return (d.isRelation) ? 1e-6 : 12;})//1e-6)
      .style("fill", function(d) { return d._children ? "#93d1ff" : (d.children ? "#fff" : "#fff"); });

   nodeUpdate
      .select("asset")
      .attr("x", "-15")
      .attr("y", "-15") 
      .attr("width", "30")
      .attr("height", "30")
      .attr("xlink:href", function(d) {
    	  if (d.isRelation) { 
    		  return "" ; 
    	  }
    	  else {
	    	 var imageUrl = "";
	     	 var imageName = d.icon;
	     	 var assetId;
	     	 if(d.childAssetId != undefined){
	     		 assetId = d.childAssetId;
	     	 }else{
	     		 assetId = d.parentAssetId;
	     	 }
	     	 if(imageName == null || imageName == ""){
	     		 imageUrl = "/repopro/semantic/images/defaultAssetIcon.svg";
	     	 }else{
	     		 /*var type = imageName.split(".");*/
	     		var type = (imageName).substring((imageName).lastIndexOf(".") + 1, (imageName).length);
	     		 //Chandana - 12/09/2019 - uppercase broken image 
	    		 if (type == 'PNG' || type == 'JPEG' || type == 'JPG'){
	    			 type = type.toLowerCase()
	    			}
	         	 imageUrl = "/repopro/assetImages/"+assetId+"."+type;
	     	 }
	     	 
	     	 return  imageUrl;
    	  }
     	});


  nodeUpdate.select("text")
      .style("fill-opacity", 1);

  // Transition exiting nodes to the parent's new position.
  var nodeExit = node.exit().transition()
      .duration(duration)
      .attr("transform", function(d) { return "translate(" + source.y + "," + source.x + ")"; })
      .remove();

  nodeExit.select("circle")
      .attr("r", function(d){return (d.isRelation) ? 1e-6 : 12;});//1e-6)

  nodeExit.select("text")
      .style("fill-opacity", 1e-6);
  // Update the links…
  var link = svg.selectAll("path.link")
      .data(links, function(d) { return d.target.id; });

  // Enter any new links at the parent's previous position.
  link.enter().insert("path", "g")
      .attr("class", "link")
      .attr("id", function(d) { 
    	  /*var relName = d.target.relationShip.replace(/ /g, "_");
    	  var parentName = d.source.name.replace(/ /g, "_");
    	  return d.target.assetInstanceVersionId+"_"+relName+"_"+parentName+"_"+d.source.id+"_"+d.target.id;*/
    	  return d.target.name;
    	  
       })
      .attr("d", function(d) {
        var o = {x: source.x0, y: source.y0};
        return diagonal({source: o, target: o});
      })
      .style("stroke",function(d) {  
    	  var color;
    	  if(d.target.colour == "red"){
    		  color = "#DB2828" ; 
    	  }else if(d.target.colour == "blue"){
    		  color = "#2185D0" ; 
    	  }else if(d.target.colour == "grey"){
    		  color = "#767676" ;  
    	  }else if(d.target.colour == "green"){
    		  color = "#5ecc78" ; 
    	  }
    	  return color;
    	 
      });
  
  
 /* nodeEnter.append("text").attr("cursor", "default").style("font", "12px sans-serif")
  .attr("font", "sans-serif").append("textPath").attr("text-anchor", "start")
  .attr("xlink:href", function (d, i) {
  return "#"+d.name;
  })
  
  .text(function (d) {
  return d.name;
  });*/

/*  
  link.append("text")
  .attr("font-family", "Arial, Helvetica, sans-serif")
  .attr("fill", "Black")
  .style("font", "normal 12px Arial")
  .attr("transform", function(d) {
      return "translate(" +
          ((d.source.y + d.target.y)/2) + "," + 
          ((d.source.x + d.target.x)/2) + ")";
  })   
  .attr("dy", ".35em")
  .attr("text-anchor", "middle")
  .text(function(d) {
      console.log(d.target.relationShip);
       return d.target.relationShip;
  });*/
  
 
  
  // Transition links to their new position.
  link.transition()
      .duration(duration)
      .attr("d", diagonal);
 
  
  // Transition exiting nodes to the parent's new position.
  link.exit().transition()
      .duration(duration)
      .attr("d", function(d) {
        var o = {x: source.x, y: source.y};
        return diagonal({source: o, target: o});
      })
      .remove();
  
  
//Update the link text
  var linktext = svg.selectAll("g.link")
      .data(links, function (d) {
      return d.target.id;
  });
  
  linktext.enter()
  .insert("g")
  .attr("class", "link")
  .append("text")
  .attr("dx", "90")
  .attr("dy", ".5em")
  //.attr("text-anchor", "middle")
  .append("textPath").attr("text-anchor", "start")
  .attr("xlink:href", function (d, i) {
	  /*var relName = d.target.relationShip.replace(/ /g, "_");
	  var parentName = d.source.name.replace(/ /g, "_");
      return "#"+d.target.assetInstanceVersionId+"_"+relName+"_"+parentName+"_"+d.source.id+"_"+d.target.id;*/
	  return d.target.name;
  })/*
  .text(function (d) {
  //console.log(d.target.name);
	  var relNameMini = d.target.relationShip;
 	 if(relNameMini.length > 15){
 		relNameMini = relNameMini.substring(0,15) + "..";
 	 } 
  return relNameMini;
})*/
	.on("mouseover", mouseover)
    .on("mousemove", function(d){mousemoveRelName(d);})
    .on("mouseout", mouseout)
    .style("cursor","default");

// Transition link text to their new positions

linktext.transition()
  .duration(duration)
  .attr("transform", function (d) {
  return "translate(10,0)";
});


 //Transition exiting link text to the parent's new position.
    linktext.exit().transition()
        .remove();
  
  
  

  // Stash the old positions for transition.
  nodes.forEach(function(d) {
    d.x0 = d.x;
    d.y0 = d.y;
  });
  
  
  /*d3.select("svg")
  .call(d3.behavior.zoom()
  .scaleExtent([0.5, 5])
  .on("zoom", zoom));*/
  
  //onclick zoom 23/10/17
  var zoomfactor = 1;

  var zoomlistener = d3.behavior.zoom()
  .on("zoom", redraw);

  d3.select("#zoomin").on("click", function (){
	  svgWidth = svgWidth + (svgWidth * 0.2);
	    height = height + (height * 0.3);
     zoomfactor = zoomfactor + 0.2;
     zoomlistener.scale(zoomfactor).event(d3.select("svg"));
  });

  d3.select("#zoomout").on("click", function (){
	  
	  svgWidth = svgWidth - (svgWidth * 0.2);
		if(svgWidth<100)
			svgWidth = 100;
	     height = height - (height * 0.3);
	    if(height<(800 - margin.top - margin.bottom))
	    	height = 800 - margin.top - margin.bottom;
	    if((zoomfactor - 0.2)>0.5){
	    	zoomfactor = zoomfactor - 0.2;
	    	zoomlistener.scale(zoomfactor).event(d3.select("svg"));
	    }
  });

  function redraw() {
	  d3.select("body").select("svg").attr("width", svgWidth + "%").attr("height", height);

	  svg.attr("transform","translate(" + margin.left + "," + margin.top + ")" + " scale(" + d3.event.scale + ")")
	  ;
  } 
}

function mouseover() {
    div.transition()
    .duration(300)
    .style("display", "block");
}

function mousemove(d) {
    div
    .html( function(e){

    	var data = "<b>"+(d.name).replace("~","_")+"</b>";
    	return data;
    })
    .style("left", (d3.event.pageX + 12) + "px")
    .style("top", (d3.event.pageY + 12) + "px");
}

function mousemoveRelName(d){
	div
    .html( function(e){
    	
    	var data = "<b>"+(d.target.relationShip).replace("~","_")+"</b>";
    	return data;
    })
    .style("left", (d3.event.pageX + 12) + "px")
    .style("top", (d3.event.pageY + 12) + "px");
}

function mouseout() {
    div.transition()
    .duration(300)
    .style("display", "none");
}

// Toggle children on click.
function click(d) {
	if(!d.isRelation) {
	  if (d.children) {
	    d._children = d.children;
	    d.children = null;
	  } else {
	
		var path = d.name;
		var currentNode = d;
		while(currentNode.parent) {
			if(!currentNode.parent.isRelation)
				path = currentNode.parent.name + "." + path;
			currentNode = currentNode.parent;
		}
		
			if(d._children[0].child) {
				
				getRelationNameId(d.assetInstanceVersionId)

				var children = getData(path).children;
				d._children = getRelationship(children);
				//d._children = getData(path).children;
				svgWidth = svgWidth + 100;
				d3.select("body").select("svg").attr("width", svgWidth + "%");
			}
	  
		
	
		d.children = d._children;
	    d._children = null;
	  }
	  update(d);
  }
}

function getRelationship(element) {
	//alert(" egt erlatop");
	var childs = [{}];
	for(var i=0;i<element.length;i++) {
		var flag = false;
		for(var j=0;j<childs.length;j++) {
			if(element[i].relationShip == childs[j].name) {
				element[i].index = i;
				childs[j].children.push(element[i]);
				flag = true;
			}
		}
		if(!flag) {
			
			element[i].index = i;
			
			childs.push({"isRelation":true, "name":element[i].relationShip, "children":[element[i]], "colour": element[i].colour});
		}
	}

	childs.shift();

	return childs;

}


function getData(key) {
	var data = JSON.parse(globalTreeValue);
	var result;

	if(!key) {
		result = data;
	} else {

		var keys = key.split(".");

		var testData = data;

		for(i = 0;i<keys.length;i++) {

			if(testData.name == keys[i]) {

 				for(j = 0;j < testData.children.length;j++) {
					if(testData.children[j].name == keys[i+1]) {
						testData = testData.children[j];
					}
				}
			}
		}
		result = testData;
		
	}
	if(typeof result.children !== "undefined"){
		for(i = 0; i< result.children.length; i++) {
			if(result.children[i].children) {
				result.children[i].children = [{"child":true}];
			}
		}	
	
	 	result.children.forEach(checkChild);
		result.children.forEach(collapse);
	}
	return result;
}

function checkChild(d){
	if(d.isEnd=="1") {
		
		d.children = [{"child":true}];
		
	}
}


/******* Combined API calls for AIV Page *******/
/******* 18.06.2018 *******/

function getAllAssetInstanceDataCombinedAPI(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstance/getAivBasicDetails?userName="+loggedInUserName+"&assetInstanceName="+encodeURIComponent(assetInstanceName)+"&assetInstVersionId="+assetInstanceVersionId,
		dataType : "json",
		async: false,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			
			//console.log(JSON.stringify(json));
			
			if(json.status == "SUCCESS"){
				if(json.message == "ASSET_INSTANCE_ACCESS_DEINED"){
					
					//access denied for the use
					if(loggedInUserName == "roleAnonymous"){
						$('#loadContent').load("AccessDenied.html");
					}else{
						$('#loadContent').load("AccessDeniedForLoggedinUser.html");
					}
					
				}else if(json.message == "ASSET_INSTANCE_NOT_FOUND"){
					
					getFlagForAssetExists = false;
					$('#loadContent').load("noAssetInstance.html");
					
				}else{
					/* instnce exists and user have view access */
					
					//get user access rights
					getUserAccessRightsCombinedAPI(json.result[0].userAccessRights);
					
					
					//get All Asset Instance Details
					getAllAssetInstanceDetailsCombinedAPI(json.result[0].aivDetailsList);
					
					//get Asset Instance Version List Sidebar
					getAssetInstanceVersionListSidebar();
					
					//Check CompositionAggregation AssetType to hide add version button
					if(json.result[0].destAccessFlag){
						 $("#openAddVersionDetailsModal").remove();
					 }else{
						 $("#openAddVersionDetailsModal").show(); 
					 }
					
					//remove loader from AIv page instance list sidebar
					$("#assetInstanceSideBar").html("");
					$("#assetInstanceSideBar").html('<center class="quickBrowse aivSidebarHdr" style="color: #ffffff !important; font-weight: 900;    background-color: rgba(106, 106, 106, 0.788235294117647) !important;">Quick Browse</center><div id="childListAssetInstance"></div>');
					
					
					// get siblings of child asset instance
					if((json.result[0].siblingsOfChildAssetInstance ).length != 0){
						getSiblingsOfChildAssetInstanceCombinedAPI(json.result[0].siblingsOfChildAssetInstance);
					}
					
					//get Child Name For Asset Instance
					if((json.result[0].childInstanceNameList).length == 0){
						
						if(siblingsOfChildAssetInstance.length == 0){
							$("#childListAssetInstance").html("<div class='item selectedAivsideAINames letterSpacingHeader whitespaceNoTrim'>"+assetInstanceName+"</div>");
						}else{
							appendData = "";
							appendData+= "<div class='item selectedAivsideAINames letterSpacingHeader'>"+assetInstanceName+"</div>";
							$.each(siblingsOfChildAssetInstance, function(i) {
								var siblingInstance = siblingsOfChildAssetInstance[i];
								siblingInstance = siblingInstance.split("~~");
								appendData+= '<a class="item selectedAivsideAINames letterSpacingHeader" onclick="getAssetInstances('+siblingInstance[1]+',\''+siblingInstance[0]+'\')">'+siblingInstance[0]+'</a>';
							});
							$("#childListAssetInstance").html(appendData);
						}
						
					}else{
						getChildNameForAssetInstanceCombinedAPI(json.result[0].childInstanceNameList);
					}
					
					
					
					
					
					//get instance rating
					if((json.result[0].aivRatingList).length == 0){
						appendData = "";
						appendData += '<i class="star  empty icon starIconSpacing"></i>';
						appendData += '<i class="star  empty icon starIconSpacing"></i>';
						appendData += '<i class="star  empty icon starIconSpacing"></i>';
						appendData += '<i class="star  empty icon starIconSpacing"></i>';
						appendData += '<i class="star  empty icon starIconSpacing"></i>';
						//appendData += '0 <i class="user icon"></i>';
						$("#ratingCompressedData").html(appendData);
					}else{
						//get rating data on load 
						getRatingDataOnLoadCombinedAPI(json.result[0].aivRatingList);
					}
					
					//check global settings
					//console.log(JSON.stringify(json.result[0].lockUnlockStatus))
					if(json.result[0].globalSetting[0].globalLockSettingFlag == 1){
						globalSettingDetailsFlag = true;
						//get Lock/Unlock Status
						getLockStatusCombinedAPI(json.result[0].lockUnlockStatus);
					}else{
						globalSettingDetailsFlag = false;
						$("#lockUnlockAssetInstance").remove();
						$("#lockUnlockAssetInstanceBtn").remove();
						$("#editBtnAfterLock").hide();
					}
					
					
					
					
					
					
					//get Customized Layout
					if(loggedInUserName == "roleAnonymous"){
						/*getAivDetailsCombinedAPI();
						getAssetInstanceOverviewCombinedAPI();
						getTagDataCombinedAPI();
						getTaxonomyDataOnLoadCombinedAPI();
						getPropertiesDataCombinedAPI();
						getRelationNameIdCombinedAPI();
						root = getData();
						setup();
						createFilterList();
						getReverseRelationshipsCombinedAPI();
						getRevisionHistory();
						getCommentsData();
						getAssetInstanceVersionsCombinedAPI();*/
						
						getRelationNameId(localStorage.getItem("assetInsVersionId"));
						root = getData();
						setup();
						createFilterList();
						smoothScrollAIVPage();
						loadElementsOnScroll();
						
					}else{
						/*getAivDetailsCombinedAPI();
						$('.customizedLayout').removeClass("APINotCalledAIVPage");*/
						
						getCustomizedLayoutDataCombinedAPI(JSON.stringify(json.result[0].customizedSectionData));
					}
					
					
					
					
				}
			}
			
			
			
		}
	
	});
	
	//get Asset Instance Version List Sidebar
	
}




//get user access rights
function getUserAccessRightsCombinedAPI(json){
	
	if(loggedInUserName !== "admin"){
						/*** Swathi- Workflow access- 30.03.2020 ***/
						if(json[0].viewFlag == true){
							$("#workflowDropdownParent").addClass("disabled");							
						}
						if(json[0].deleteFlag == true){
							$(".deleteAccess").show();
							userDeleteAccessFlag = true;
						}else{
							$(".deleteAccess").remove();
							userDeleteAccessFlag = false;
						}
							
						if(json[0].editFlag == true){
							//$(".editProperties").show();
							//$(".showProperties").hide();
							$(".editAccess").show();
							userEditAccessFlag = true;
							$("#workflowDropdownParent").removeClass("disabled"); // Workflow 
						}else{
							//$(".editProperties").hide();
							//$(".showProperties").show();
							$(".editAccess").remove();
							userEditAccessFlag = false;
							$(".downloadAccess").attr('style',"pointer-events:none;");
							//$("#showAssetOverViewMessage").attr("style","pointer-events: none;");
						}
						
						
						if(json[0].adminFlag == true){
							$(".adminAccess").show();
							userAdminFlag = true;
							$("#workflowDropdownParent").removeClass("disabled");
						}else{
							$(".adminAccess").remove();
							userAdminFlag = false;
						}
						
						//getLockStatus();
						
						/*if(loggedInUserName != "roleAnonymous"){	
							if(json.result[0].viewFlag == true){
								$("#fileForm").show();
								$("#expandAllAccordion").show();
								$("#noAssetPropertiesData").hide();
								
							}else{
								$("#fileForm").remove();
								$("#expandAllAccordion").remove();
								$("#noAssetPropertiesData").show();
							}
						}	*/
			
	}
}

//get All Asset Instance Details
function getAllAssetInstanceDetailsCombinedAPI(json){
	
	setTimeout(function(){ 
		$("#showAssetOverViewMessage").removeClass("loading");
	}, 50);

	
		//$('#showHideLoader').removeClass('active');
		/*var data = "";
		if(json.result[0].description == null){
			data = "<span id='showAssetOverViewDescription'>No description provided yet</span>";	
		}else{
			data = "<span id='showAssetOverViewDescription'>"+json.result[0].description+"</span>";	
		}*/
		$('#showAssetOverViewOwner').html(json[0].owner);
		var time = json[0].updatedOn.trim();
		time = time.split(" ");
		$('#showAssetOverViewUpdatedOn').html(time[0]+"T"+time[1]);
		//$("#showAssetOverViewMessage").html(data);
	
		//Chandana 04-06-2019 
		var createdTime = json[0].createdOn.trim();
		createdTime = createdTime.split(" ");
		$('#showAssetOverViewCreatedOn').html(createdTime[0]+"T"+createdTime[1]);

		assetInstanceId = json[0].assetInstanceId;
		assetId = json[0].assetId;
		assetName = json[0].assetName;
		versionable = json[0].versionable;
		versionName = json[0].versionName;
		assetIconType = "default";
		if(json[0].iconImageName != null){
			var imageType = json[0].iconImageName ;
			/*imageType = imageType.split(".");
			assetIconType = imageType[1];*/
			assetIconType = ( json[0].iconImageName).substring(( json[0].iconImageName).lastIndexOf(".") + 1, ( json[0].iconImageName).length);
		}

		appendData = "";

		if(assetIconType != "default"){
			//Chandana - 12/09/2019 - uppercase broken image 
			if (assetIconType == 'PNG' || assetIconType == 'JPEG' || assetIconType == 'JPG'){
				assetIconType = assetIconType.toLowerCase()
				}
				if(circularThemeColoredIcon){
				appendData += '<div class="bigIconImageCircleStyle_themeCircle" style="font-size: 1.4em; display: block !important;">';
				if(invertAssetIconFlag){
					appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" data-src="/repopro/assetImages/inverted_'+assetId+'.'+assetIconType+'" ></div>';
				}else{
					appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg"  data-src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';
				}
			}else{
				appendData += '<div class="bigIconImageCircleStyle" style="font-size: 1.4em; display: block !important; margin-left: -1rem !important;">';
				if(invertAssetIconFlag){
					appendData += '<img class="left floated ui  image bigIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" data-src="/repopro/assetImages/inverted_'+assetId+'.'+assetIconType+'" ></div>';
				}else{
					appendData += '<img class="left floated ui  image bigIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg" data-src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';
				}
			}
			/*appendData += '<div class="bigIconImageCircleStyle" style="font-size: 1.4em; display: block !important; margin-left: -1rem !important;">';
	appendData += '<img class="left floated ui circular image bigIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+assetIconType+'" ></div>';*/
		}else{
			if(circularThemeColoredIcon){
				appendData += '<div class="bigIconImageCircleStyle_themeCircle" style="font-size: 1.4em; display: block !important;">';
				if(invertAssetIconFlag){
					appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" ></div>';
				}else{
					appendData += '<img class="left floated ui  image bigIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg" ></div>';
				}
			}else{
				appendData += '<div class="bigIconImageCircleStyle" style="font-size: 1.4em; display: block !important; margin-left: -1rem !important;">';
				if(invertAssetIconFlag){
					appendData += '<img class="left floated ui  image bigIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png" ></div>';
				}else{
					appendData += '<img class="left floated ui  image bigIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg" ></div>';
				}
			}
		}

		$("#assetInstanceIcon").html(appendData);

		$(".abc").removeClass("themeTextColor itemSelected");
		$("#browserAssetId_"+assetId).addClass("themeTextColor itemSelected");


		$('#breadcrumbData').html('<a class="section" onclick="getHomeDetails(this)">Home</a><i class="right chevron icon divider"></i><a class="section whitespaceNoTrim" onclick="navigateToAssetPage()">Browse - '+assetName+'</a><i class="right chevron icon divider"></i><div class="active section whitespaceNoTrim">'+assetInstanceName+'</div>');

		if(versionable){
			$("#openAddVersionDetailsModal").show();
			$("#assetVersionFloatingMenu").show();
			$("#assetVersionFloat").show();

		}else{
			$("#divVersionable").css({"visibility":"hidden","margin-left":"-4.4em"}); // css by chandana 22-4-2019
			$("#openAddVersionDetailsModal").remove();
			$("#assetVersionFloatingMenu").hide();
			$("#assetVersionFloat").hide();
			$("#assetInstancesVersionHeader").remove();
			$("#assetInstancesVersionSegment").remove();
			$("#versionDivider").remove();
			//$("#floatingScrollerMenu").attr("style","height: 20.2em !important;border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;");
			$("#floatingScrollerMenu").attr("style","height: auto !important;border-radius: 0px 0.28571429rem 0.28571429rem 0px !important;");
		}

		var assetInstanceVersionArr = [];
		appendData = "";
		$.each(json[0].versionList, function(j) {

			var id = (json[0].versionList[j]).split(":");

			assetInstanceVersionArr.push(id[1]);
			$(".versionDropdown").show();

			if(id[1] == assetInstanceVersionId){
				$("#selectedVersionId").val('');
				$("#selectedVersionId").html(versionName);
				$("#divVersionable").show();
			}else{
				var encodedAssetInstName= encodeURIComponent(assetInstanceName);
				encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
				//appendData += '<div class="ui label" style="margin-left: 0.75em;"><a  onclick="getAssetInstances('+id[1]+',\''+encodedAssetInstName+'\')">'+id[0] +'</a></div>';
				appendData += '<div class="item" data-text="'+id[0]+'" onclick="getAssetInstances('+id[1]+',\''+encodedAssetInstName+'\')">'+id[0]+'</div>';
			}


		});

		$("#versionDropdown").html(appendData);
		if(assetInstanceVersionArr.length == "1"){
			$(".versionDropdown").hide();
		}




		/*

		();
		();
		loadGlobalSettingDetails();*/
		
		checkAccessForUserOnSuccess();

}


//get siblings of child asset instance
function getSiblingsOfChildAssetInstanceCombinedAPI(json){
	siblingsOfChildAssetInstance.length = 0; 

	$.each(json, function(i) {
		var data = (json[i].assetInstName)+"~~"+(json[i].assetInstVersionId);
		siblingsOfChildAssetInstance.push(data);
	});
	
}


//get Child Name For Asset Instance
function getChildNameForAssetInstanceCombinedAPI(json){
	
	appendData = "";
	appendData += '<div class="ui vertical fluid accordion " style="font-size:10px;">';
	appendData += '<div class="item">';
	appendData += '<a class="title active" ><i class="dropdown icon" style="float: left;"></i><span>'+assetInstanceName+'</span></a>';
	appendData += '<div class="content menu active" id="assetInstanceChilds">';
	appendData += '</div></div></div>';
	
	$("#childListAssetInstance").html(appendData);
	
	$.each(json, function(i) {
		var assetInstName = json[i].assetInstName;
		var encodedAssetInstName= encodeURIComponent(assetInstName);
		encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
		appendData = '<a class="item" style="margin-left:2.5em;" onclick="getAssetInstances('+json[i].destAssetInstVersionId+',\''+encodedAssetInstName+'\')">'+assetInstName+'<span style="font-size: 9px;"> ['+json[i].assetName+']</span></a>';
		$("#assetInstanceChilds").append(appendData);
	});
	
	$('.ui.accordion').accordion({
		exclusive: false
	 });
	
	
}


//get rating data on load 
function getRatingDataOnLoadCombinedAPI(json){

	var averageRating = json[0].avgRating;
	var totalCount = json[0].totalCount;
	appendData = "";
	
	for(var i= 0; i < Math.floor ( averageRating ); i++){
		appendData += '<i class="star icon starIconSpacing"></i>';
	}
	if(averageRating !== 5){	
		if( averageRating - Math.floor ( averageRating ) < 0.4){
			appendData += '<i class="star  empty icon starIconSpacing"></i>';
		}else{
			appendData += '<i class="star half empty icon starIconSpacing"></i>';
		}
		for(var i = 0; i < (4 - Math.floor ( averageRating )); i++){
			appendData += '<i class="star  empty icon starIconSpacing"></i>';
		}
	}
	//	appendData += totalCount+' <i class="user icon"></i>';
	
	$("#ratingCompressedData").html(appendData);
	
}

//check lock status
function getLockStatusCombinedAPI(json){
	
	if(json[0].lockedBy == "" || json[0].lockedBy == null){
		$("#lockUnlockAssetInstance").removeClass("lock").addClass("unlock").parent().attr("data-tooltip","Click to Lock and Edit");
		lockFlag = false;
		$("#editBtnAfterLock").addClass("disabled");
	}else{
		$("#lockUnlockAssetInstance").removeClass("unlock").addClass("lock").parent().attr("data-tooltip","Click to Unlock");
		if(json[0].lockedBy == loggedInUserName){
			$(".lockEditing").removeClass("disabled");
			$(".propertiesLockedByOther").removeClass("disabled");
			lockedBySameUser = true;
			if(editingEnabled){
				$("#editBtnAfterLock").addClass("disabled");
			}else{
				$("#editBtnAfterLock").removeClass("disabled");
			}
			
		}else{
			$(".lockEditing").addClass("disabled");
			$(".propertiesLockedByOther").addClass("disabled");
			if(userAdminFlag == false){
				$("#lockUnlockAssetInstance").attr("onclick","").parent().addClass("disabled").css("pointer-events","none");
			}else{
				$("#lockUnlockAssetInstance").show();
			}
			lockedBySameUser = false;
			$("#editBtnAfterLock").addClass("disabled");
		}
		
		
		

		lockFlag = true;
		
			
			
			var countDownDate = new Date(json[0].lockTime).getTime();
			var now = new Date().getTime();
			 var distance = countDownDate - now;
			 $("#lockStatusMessage").html(" | <i>Locked By: </i> <b>"+json[0].lockedBy+"| </b><i>Unlock Time:</i> <b> "+json[0].lockTime).show()+"</b>"; 
			 if (distance < 0) {
			        clearInterval(countdownTimerInterval);
			        //$("#lockStatusMessageCountdown").html("EXPIRED");
			        $(".lockEditing").removeClass("disabled");
			        setTimeout(function(){
			        	//$("#lockStatusMessage").html("");
			        		 unlockInstance();
			        	
			        }, 100);
			       return false; 	
			    }
			
			
	}
	
}



//get Customized Layout
function getCustomizedLayoutDataCombinedAPI(json){
	
		json = JSON.parse(json);
			
		//console.log("json  res "+json.result[0].sectionVisibility);
	
		var data1 = json[0].sectionVisibility.split(",");
		var arrengedArray = [];
		var floatingBarArray = [];
	
	
		//console.log("data1 "+data1);
	
		$.each(data1, function(i) {
			var CheckedOrUnchecked  = data1[i].split("~~")[1];
			var tabsName  = data1[i].split("~~")[0];
			//console.log("CheckedOrUnchecked "+CheckedOrUnchecked+"  tabsName "+tabsName);
			if(tabsName == "Overview"){
				arrengedArray.push("assetOverviewTab");
				floatingBarArray.push("#assetOverview");
			}else if(tabsName == "Tags"){
				arrengedArray.push("aivTags");
				floatingBarArray.push("#assetTag");
			}else if(tabsName == "Taxonomies"){
				arrengedArray.push("aivTaxonomy");
				floatingBarArray.push("#assetTaxonomies");
			}else if(tabsName == "Properties"){
				arrengedArray.push("assetPropertiesTab");
				floatingBarArray.push("#assetProperties");
			}else if(tabsName == "Relationships & Reverse Relationships"){
				arrengedArray.push("assetRelationshipAndRevRelationshipTab");
				floatingBarArray.push("#assetRelationships");
				if(CheckedOrUnchecked == "checked"){
					getRelationNameId(localStorage.getItem("assetInsVersionId"));
					//getRelationNameIdCombinedAPI();
					root = getData();
					setup();
					createFilterList();
				}
	
			}else if(tabsName == "Revision History"){
				arrengedArray.push("assetRevisionHistoryTab");
				floatingBarArray.push("#assetRevisionHistory");
			}else if(tabsName == "Discussion"){
				arrengedArray.push("assetDiscussionTab");
				floatingBarArray.push("#assetDiscussion");
			}else if(tabsName == "Versions"){
				arrengedArray.push("assetVersionTab");
				floatingBarArray.push("#assetVersion");
			}else if(tabsName == "Asset Visualization"){
				//Swathi- Code to Asset Visualization - 04.11.2019
				arrengedArray.push("assetVisualizationTab");
				floatingBarArray.push("#assetVisualization");
			}
	
		});
	
	
		var arrengedOrderHtml = []; 
		var arrengedOrderFloatingMenu = [];
		//alert("before cust")
		$.each(arrengedArray,function(j){
			$(".customizedLayout").each(function(h){
				if(arrengedArray[j] == $(this).attr("id")){
					/*var id = $(this).attr("id");
					var htmlData = $("#"+id)html();*/
					//alert($(this).html())
					/*console.log(this);
					console.log($(this).html());*/
	
					//check for IE browser
					if (!!navigator.userAgent.match(/Trident\/7\./)){
						if(arrengedArray[j] != "assetRelationshipAndRevRelationshipTab"){
							arrengedOrderHtml.push('<div class="customizedLayout APINotCalledAIVPage"  id="'+$(this).attr("id")+'">'+$(this).html()+'</div>');
							$(this).remove();
						}else{
							arrengedOrderHtml.push('assetRelationshipCustomeIdKey');
						}
	
					}else{
						arrengedOrderHtml.push(this); //other browsers
					}
	
	
	
					//arrengedOrderHtml.push(this);
				}
			});
		});
		
	
	
		//$("#showAllDataInCustomizedLayout").html("");
	
		if (!!navigator.userAgent.match(/Trident\/7\./)){
	
			var htmlBeforeRel = [];
			var htmlAfterRel = [];
			var indexVAL = arrengedOrderHtml.indexOf("assetRelationshipCustomeIdKey");
			$.each(arrengedOrderHtml,function(a){
				if(a < indexVAL){
					htmlBeforeRel.push(arrengedOrderHtml[a]);
				}else if(a > indexVAL){
					htmlAfterRel.push(arrengedOrderHtml[a]);
				}
			});
	
			htmlBeforeRel.reverse();
	
			$.each(htmlBeforeRel,function(a){
				$("#showAllDataInCustomizedLayout").prepend(htmlBeforeRel[a]);
			});
	
			$.each(htmlAfterRel,function(a){
				$("#showAllDataInCustomizedLayout").append(htmlAfterRel[a]);
			});
	
	
	
		}else{
			$("#showAllDataInCustomizedLayout").html("");
			$.each(arrengedOrderHtml,function(a){
				$("#showAllDataInCustomizedLayout").append(arrengedOrderHtml[a]);
			});
		}
	
	
	
		$.each(floatingBarArray,function(j){
			$("#floatingScrollerMenu > span").each(function(h){
				if(floatingBarArray[j] == $(this).children().attr("href")){
					arrengedOrderFloatingMenu.push("<span>"+$(this).html()+"</span>");
				}
			});
		});
	
		$("#floatingScrollerMenu").html("");
	
	
	
		$.each(arrengedOrderFloatingMenu,function(a){
			$("#floatingScrollerMenu").append(arrengedOrderFloatingMenu[a]);
	
		});
	
	
	
	
		$('.ui.accordion').accordion({
			exclusive: false
		});
	
		$('.ui.dropdown').dropdown();
	
		var flag = true;
	
		$.each(data1, function(i) {
			var CheckedOrUnchecked  = data1[i].split("~~")[1];
			var tabsName  = data1[i].split("~~")[0];
			//console.log("CheckedOrUnchecked "+CheckedOrUnchecked+"  tabsName "+tabsName);
			if(tabsName == "Overview"){
	
				if(CheckedOrUnchecked == "checked"){
					//getAssetInstanceOverviewCombinedAPI();
					$("#assetOverviewTab").show();
					$("#assetOverviewFloat").show();
					flag = false;
				}else{
					$("#assetOverviewTab").hide().addClass("hidden");
					$("#assetOverviewFloat").hide();
				}
			}else if(tabsName == "Tags"){
	
				if(CheckedOrUnchecked == "checked"){
					//getTagDataCombinedAPI();
					$("#aivTags").show();
					$("#assetTagFloat").show();
	
					flag = false;
				}else{
					$("#aivTags").hide().addClass("hidden");
					$("#assetTagFloat").hide();
				}
			}else if(tabsName == "Taxonomies"){
	
				if(CheckedOrUnchecked == "checked"){
					//getTaxonomyDataOnLoadCombinedAPI();
					$("#aivTaxonomy").show();
					$("#assetTaxonomiesFloat").show();
					flag = false;
				}else{
					$("#aivTaxonomy").hide().addClass("hidden");
					$("#assetTaxonomiesFloat").hide();
				}
			}else if(tabsName == "Properties"){
	
	
				if(CheckedOrUnchecked == "checked"){
					//getPropertiesDataCombinedAPI();
					$("#assetPropertiesTab").show();
					$("#assetPropertiesFloat").show();
					flag = false;
				}else{
					$("#assetPropertiesTab").hide().addClass("hidden");
					$("#assetPropertiesFloat").hide();
				}
			}else if(tabsName == "Relationships & Reverse Relationships"){
	
				if(CheckedOrUnchecked == "checked"){
					//checkRelationshipAssets();
					//for relationship
					/*alert("after html cust")
						getRelationNameId(localStorage.getItem("assetInsVersionId"));
						root = getData();
						setup();
						createFilterList();*/
	
					//root = getData();
					//setup();
					//for reverse relationship
					//getReverseRelationshipsCombinedAPI();
	
					$("#assetRelationshipAndRevRelationshipTab").show();
					$("#assetRelationshipsFloat").show();
					flag = false;
				}else{
					$("#assetRelationshipAndRevRelationshipTab").hide().addClass("hidden");
					$("#assetRelationshipsFloat").hide();
				}
			}else if(tabsName == "Revision History"){
	
				if(CheckedOrUnchecked == "checked"){
					//getRevisionHistory();
					$("#assetRevisionHistoryTab").show();
					$("#assetRevisionHistoryFloat").show();
					flag = false;
				}else{
					$("#assetRevisionHistoryTab").hide().addClass("hidden");
					$("#assetRevisionHistoryFloat").hide();
				}
			}else if(tabsName == "Discussion"){
	
	
				if(CheckedOrUnchecked == "checked"){
					//getCommentsData();
					$("#assetDiscussionTab").show();
					$("#assetDiscussionFloat").show();
					flag = false;
				}else{
					$("#assetDiscussionTab").hide().addClass("hidden");
					$("#assetDiscussionFloat").hide();
				}
			}else if(tabsName == "Versions"){
	
				if(CheckedOrUnchecked == "checked"){
					//getAssetInstanceVersionsCombinedAPI();
					$("#assetVersionTab").show();
	
					if(versionable){
						$("#assetVersionFloat").show();
					}else{
	
						$("#assetVersionFloat").hide();
					}
					flag = false;	
	
				}else{
					$("#assetVersionTab").hide().addClass("hidden");
					$("#assetVersionFloat").hide();
				}
			}else if(tabsName == "Asset Visualization"){
				//Swathi- Code to Asset Visualization - 04.11.2019
				if(CheckedOrUnchecked == "checked"){
					$("#assetVisualizationTab").show();
					$("#assetVisualizationFloat").show();
					flag = false;
				}else{
					$("#assetVisualizationTab").hide().addClass("hidden");
					$("#assetVisualizationFloat").hide();
				}
			}
	
		});
	
	
		if(flag){
			$("#showAllDataInCustomizedLayout").append('<div class="ui message" style="display:block !important;margin-top: 3em;" >All customizable actions are disabled.</div>');
		}
	
		$(".deleteTagClass").hide();
	
		formDataSubmit();
		smoothScrollAIVPage();
		//$('.customizedLayout').addClass("APINotCalledAIVPage");
		loadElementsOnScroll();
		$("#treeTabSegment").tab();
	
	
		if(globalSettingDetailsFlag){
			$("#editAIVPage").remove();
	
		}else{
			$("#editBtnAfterLock").remove();
		}
	
		$("#combinedBtns").show();
	
		$("#showAllDataInCustomizedLayout").append('<input type="hidden" id="assetInstanceDetails" name="assetInstanceDetails">');
		$("#showAllDataInCustomizedLayout").append(	'<input type="hidden" id="hiddenFormDataValue" name="hiddenFormDataValue">');
		$("#showAllDataInCustomizedLayout").append(	'<input type="hidden" id="hiddenRelationshipData" name="hiddenRelationshipData">');
		//$("#showAllDataInCustomizedLayout").append('<input id="editNewSubmitButton" type="submit" style="display: none;" value="Submit" formnovalidate="formnovalidate">');
		
		// BOC Hema 08.Mar.2019 Directs to ldap mapping parameter count
		if(localStorage.getItem("ldapMappingCountLink") == "true"){
			window.history.replaceState({}, "", "/repopro/index.html");
			if (!$("#assetPropertiesTab").hasClass("hidden")) {
				//if($("#assetPropertiesTab").hasClass("APINotCalledAIVPage")){
					getPropertiesData();
					//console.log("load");
					//$("#assetPropertiesTab").removeClass("APINotCalledAIVPage");

				//}

			}	     
		}
		//EOC	


}

var AIVDetailsJSON = "";
//get all aiv data
function getAivDetailsCombinedAPI(){
	
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstance/getAivDetails?assetName="+assetName+"&assetInstName="+assetInstanceName+"&assetInstVersionId="+assetInstanceVersionId+"&userName="+loggedInUserName+"&versionName="+versionName,
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			AIVDetailsJSON = json;
			console.log('Combined API ' + url);
		}
	});
	
}

//get Relation Name Id 
function getRelationNameIdCombinedAPI(){
	relationNameList.length = 0;
	var json = AIVDetailsJSON.result[0].relationships;
	
	$.each(json,function(i){
		if(jQuery.inArray(json[i].description+"-"+json[i].fwdRelId, relationNameList) == -1){
			relationNameList.push(json[i].description+"-"+json[i].fwdRelId);
		}

	});
	getRelationTreeDataCombinedAPI();
		
}

//get Relation Tree Data
function getRelationTreeDataCombinedAPI(){
	
	var relationId = "";
	$.each(relationNameList,function(i){
		relationId += relationNameList[i]+"!";
	});
	relationId = relationId.replace(/!$/, "");
	
	var json = AIVDetailsJSON.result[0].onloadrelationships;

	$("#relationshipLoadingSegment").removeClass("loading");

	var val = json[0];
	val = decodeURIComponent(val);

	if(relTableData){
		relTableData = false;
		localStorage.removeItem("relTableObj");
		localStorage.setItem("relTableObj", val);
	}

	globalTreeValue =  val;
	checkAccessForUserOnSuccess();
	
	
}

//get overview data
function getAssetInstanceOverviewCombinedAPI(){
	
	var json = AIVDetailsJSON.result[0].overview;
	setTimeout(function(){ 
		$("#showAssetOverViewMessage").removeClass("loading");
	}, 50);

	var data = "";
	if(json[0].description == null){
		data = "<span id='showAssetOverViewDescription'>No description provided yet</span>";	
	}else{
		data = "<span id='showAssetOverViewDescription'>"+json[0].description+"</span>";	
	}

	$("#showAssetOverViewMessage").html(data);

	checkAccessForUserOnSuccess();
}


//get tags data
function getTagDataCombinedAPI(){
	
	var json = AIVDetailsJSON.result[0].tags;
	
	setTimeout(function(){ 
		$("#tagLoadingSegment").removeClass("loading");
	}, 50);
	
	$('#addNewTagSegment').html("");
	$("#noTagDataShow").hide();
	$('#addNewTagSegment').show();
	
	if(json.length != 0){
		
		$.each(json, function(i) {
			$.each(json[i].tagNames, function(key,value){
				var tagData = loadTagData(value);
				$('#addNewTagSegment').append(tagData);
				autoId++;						
			});
		});
			
		
	}else{
		$("#addNewTagSegment").hide();
		$("#noTagDataShow").show();
	}
	
	checkAccessForUserOnSuccess();
	
}


//get taxonomy data
function getTaxonomyDataOnLoadCombinedAPI(){
	
	var json = AIVDetailsJSON.result[0].taxonomy;
	
	taxFromBackend.length = 0;
	
	setTimeout(function(){ 
		$("#addNewTaxonomySegment").removeClass("loading");
	}, 50);


	if(json.length == 0){
		$("#addNewTaxonomySegment").html("No taxonomies added yet")
	}else{
		$.each(json, function(i) {
			$('#addNewTaxonomySegment').append('<a class="ui label" onclick="navigateToClickedTaxonomy('+json[i].taxonomyId+',\''+json[i].taxonomyName+'\')" id="taxonomyName_'+json[i].taxonomyId+'_'+json[i].taxonomyName.replace(/ /g,"_")+'" style="margin-bottom:0.5em;"><span style="display:none;">'+json[i].taxonomyId+'</span><i class="fork icon"></i>'+json[i].taxonomyName+'</a>');
			// HEMA
			taxFromBackend.push({"taxId":json[i].taxonomyId, "taxName":json[i].taxonomyName});
		});

	}

	checkAccessForUserOnSuccess();
		
	
	
}



//get Reverse Relationships
function getReverseRelationshipsCombinedAPI(){
	
	var json = AIVDetailsJSON.result[0].reverseRelationship;
	
	setTimeout(function(){ 
		$("#reverseRelationshipsLoadingContent").removeClass("loading");
	}, 50);
	$('#showReverseRelationships').html('');
	


	
		if(json.length == 0){
			$("#showReverseRelationships").html('<div class="ui message" style="background-color: #ffffff !important;">No backward relationships found for '+assetInstanceName+'</div>');
			$("#showReverseRelationshipsLegends").hide();
			$("#noRevRelLegendData").show();
		}
		else {
			$("#showReverseRelationshipsLegends .header").show();
			$("#noRevRelLegendData").hide();
			$.each(json, function(i) {
				var imageName = "default";
				if(json[i].iconImageName != null){
					var imageType = json[i].iconImageName;
					/*imageType = imageType.split(".");
					imageName = imageType[1];*/
					imageName = (json[i].iconImageName).substring((json[i].iconImageName).lastIndexOf(".") + 1, (json[i].iconImageName).length);
				}


				var reverseRelationshipsData = loadReverseRelationships(json[i].srcAssetInstanceVersionId , json[i].assetInstName, json[i].relName, json[i].versionName,json[i].versionable,imageName,json[i].assetId);
				$('#showReverseRelationships').append(reverseRelationshipsData);
				lazyLoadingImage();

				if(jQuery.inArray(json[i].assetName, reverseRelLegendList) == -1){
					reverseRelLegendList.push(json[i].assetName);
					appendData = "";
					/* appendData += '<img class="ui mini spaced image" src="/repopro/semantic/images/defaultAssetIcon.svg"><a style="cursor: pointer;" onclick="legendAssetGridPage('+json[i].assetId+',\''+json[i].assetName+'\')">'+json[i].assetName+'</a>';*/

					appendData += '<a class="ui image label" style="font-size: 9px;word-break: break-all; margin-top:0.5em; margin-left:0.5em;background:none;" onclick="legendAssetGridPage('+json[i].assetId+',\''+json[i].assetName+'\')">';




					if(imageName == "default"){

						if(circularThemeColoredIcon){
							appendData += '<div class="ui right spaced  image smallIconImageCircleStyle_themeCircle " style="font-size:8px;">';
							if(invertAssetIconFlag){
								appendData += '<img class="smallIconImageStyle invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png">'; 
							}else{
								appendData += '<img class="smallIconImageStyle"  src="/repopro/semantic/images/defaultAssetIcon.svg">'; 
							}
						}else{
							appendData += '<div class="ui right spaced  image smallIconImageCircleStyle smallIconImageCircleRemove" style="font-size:8px;">';
							if(invertAssetIconFlag){
								appendData += '<img class="smallIconImageStyle invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png">'; 
							}else{
								appendData += '<img class="smallIconImageStyle"  src="/repopro/semantic/images/defaultAssetIcon.svg">'; 
							}
						}

					}else{
						if (imageName == 'PNG' || imageName == 'JPEG' || imageName == 'JPG'){
							imageName = imageName.toLowerCase()
						}

						if(circularThemeColoredIcon){
							appendData += '<div class="ui right spaced  image smallIconImageCircleStyle_themeCircle " style="font-size:8px;">'; 
							if(invertAssetIconFlag){
								appendData += '<img class="smallIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png"  data-src="/repopro/assetImages/inverted_'+json[i].assetId+'.'+imageName+'">';  
							}else{
								appendData += '<img class="smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg"  data-src="/repopro/assetImages/'+json[i].assetId+'.'+imageName+'">'; 
							}
						}else{
							appendData += '<div class="ui right spaced  image smallIconImageCircleStyle smallIconImageCircleRemove" style="font-size:8px;">'; 
							if(invertAssetIconFlag){
								appendData += '<img class="smallIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png"  data-src="/repopro/assetImages/inverted_'+json[i].assetId+'.'+imageName+'">';
							}else{
								appendData += '<img class="smallIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg"  data-src="/repopro/assetImages/'+json[i].assetId+'.'+imageName+'">';
							}
						}



					}


					appendData += '</div><span>'+json[i].assetName+'</span></a>';

					$("#reverseRelationshipsLegendList").append(appendData);
					lazyLoadingImage();
				}

			});
			//$("#showReverseRelationshipsLegends").hide();	
		} 
	
	
}


//get Asset Instance Versions
function getAssetInstanceVersionsCombinedAPI(){
	
	var json = AIVDetailsJSON.result[0].versionDetails;
	
	
	setTimeout(function(){ 
		$("#assetInstancesVersionSegment").removeClass("loading");
	}, 50);
	

		
		if(json.length == 0){
			$("#noAssetInstancesVersionData").show();
			$("#assetInstancesVersionTable").hide();
			
		}else{
			
			$("#noAssetInstancesVersionData").hide();
			$("#assetInstancesVersionTable").show();
			versionList = [];
			apenDdData = "";	
			var versionData = "";
			$.each(json, function(i) {
				if(json[i].viewAccessFlag){
					versionList.push(json[i].versionName);
				}
				if(loggedInUserName == "roleAnonymous"){
					$("#compareVersionTh").remove();
				}
				if(json[i].assetInstVersionId != assetInstanceVersionId){
					//alert(json[i].versionName)
					var encodedAssetInstName= encodeURIComponent(assetInstanceName);
					encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
					
					apenDdData += '<div class="item" data-text="'+json[i].versionName+'" onclick="getAssetInstances('+json[i].assetInstVersionId+',\''+encodedAssetInstName+'\')">'+json[i].versionName+'</div>';
				}
				
				versionData += loadAssetInstanceVersions(json[i].versionName , json[i].versionNotes, json[i].assetInstVersionId,json[i].editAccessFlag ,json[i].deleteAccessFlag,json[i].viewAccessFlag);
				
			});
			$("#assetInstancesVersionTable table tbody").html(versionData);
			
			if(loggedInUserName == "roleAnonymous"){
				$(".guestUserAccess").remove();
			}
			
		} 
	
	checkAccessForUserOnSuccess();
	
}


//get Properties Data
function getPropertiesDataCombinedAPI(){
	
	var json = AIVDetailsJSON.result[0].properties;

	
	getPropertiesTextData = [];
	getPropertiesRichTextData=[];
	
	 
	 $("#propertiesAccordion").html("");
	// console.log("/repopro/web/assetInstanceVersionManager/getAssetInstancePropertiesDetails?userName="+userName+"&assetName="+encodeURIComponent(assetName)+"&assetInstanceVersionId="+assetInstanceVersionId)
	 
				
				setTimeout(function(){ 
					$("#propertiesLoadingSegment").removeClass("loading");
				}, 50);
				
				var custListAssetParamID = "";
				var assetListAssetId = "";
				var assetListAssetParamID = "";
				var userListAssetParamID = "";
				var multiSelectFlag = ""; //harish
				
				
				/*if(json.status == "SUCCESS"){*/
				
					if(json.length == 0){
						$("#noAssetPropertiesData").show();
						$("#propertiesAccordion").hide();
						$("#propSubBtn").remove();
						$("#expandAllAccordion").remove();
						$("#editPropertiesDataEditButton").remove();
					}else{
							$("#noAssetPropertiesData").hide();
							$("#propertiesAccordion").show();
							$("#editPropertiesData").show();
							assetCategoryList.length = 0;
							assetParamIdList.length = 0;
							
							/*************Aditya 20Feb**************/
							/*console.log("Aditya 21Feb json :: "+JSON.stringify(json));
							var r_count=0;
							$.each(json, function(key, val){
								if(val.paramTypeId == 7 && val.rTFwithOutTags != null && val.rTFwithOutTags != ""){
									$.each(val.rTFwithOutTags, function(index, value){
										getPropertiesRichTextData.push({"value" : value, "id":"richTextFieldList_"+r_count});
										r_count++;
									});
									
								}else if(val.paramTypeId == 1 && val.isStatic == 0 && val.textDataList !=null  && val.textDataList != ""){
									console.log((val.textDataList).length+" :: else condition :: "+val.textDataList);
									$.each(val.textDataList, function(index, value){
										getPropertiesTextData.push(value);
									});
								}
								
								//-------21Feb
									if(val.paramTypeId == 7 && val.hasArray == 0){
										hasArrayFlagForRichText = false;
									}
									if(val.paramTypeId == 7 && val.hasArray == 1){
										hasArrayFlagForRichText = true;
									}
									
									if(val.paramTypeId == 1 && val.hasArray == 0){
										hasArrayFlagForText = false;
									}
									if(val.paramTypeId == 1 && val.hasArray == 1){
										hasArrayFlagForText = true;
									}
								//-------21Feb over
							});*/
							
							//console.log(JSON.stringify(getPropertiesTextData)+" :: getPropertiesTextData === getPropertiesRichTextData :: "+JSON.stringify(getPropertiesRichTextData));
							/**************Aditya over***************/
							
							
							$.each(json, function(i) {
								if ($.inArray(json[i].asset_category_name+"~~"+json[i].cat_disp, assetCategoryList) == -1){
									assetCategoryList.push(json[i].asset_category_name+"~~"+json[i].cat_disp);
								}
							});
							
							$.each(assetCategoryList, function(i) {
								var arr = assetCategoryList[i].split("~~");
								var appendPropertiesData = createPropertiesDataFormat(arr[0],arr[1]);
								$("#propertiesAccordion").append(appendPropertiesData);
							});
								
							$.each(json, function(i) {
								var propertiesValue = "";
								var inputType = "";
								var listFlag = false;
								var dateFlag = false;
								var textFlag = false;
								var richTextFlag = false;
								var deriveAttrFlag = false;
								var fileFlag = false;
								
								if(loggedInUserName != "roleAnonymous"){
									if(json[i].editAccessFlag == false){
										if(json[i].paramTypeId != 5 && json[i].paramTypeId != 6){
											$(".readOnlyMeta_"+json[i].cat_disp).show();
										}
									}
								}
								
								if(json[i].paramTypeId == 1){
									
									inputType = "text";
									textFlag = true;
									var value,valueforInputfield;
									
									if(json[i].isStatic == 0){
										if(json[i].paramValue != null)
										value = json[i].paramValue;
										
									}else{
										if(json[i].staticValue != null)
										value = json[i].staticValue;
									}
									if(value == null ){
										value = "";
										
									}
									
									
									
									var flag = validateURL(value);
									//var regex = /^\<a.*\>.*\<\/a\>/i;
									
									if(value.startsWith("<a")){
										flag = false;
									}
									/*propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
									propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" style="display:none;"></div>';*/
									
									//===Aditya 20feb
									propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
									propertiesValue += '<span id="hasArray_'+json[i].assetParamId+'" style="display:none;">'+json[i].hasArray+'</span>';
									propertiesValue += '<span id="hiddenJSON_'+json[i].assetParamId+'" style="display:none;"></span>';
									propertiesValue += '<span id="isMandatory_'+json[i].assetParamId+'" style="display:none;">'+json[i].mandatory+'</span>';
									propertiesValue += '<span id="isEditable_'+json[i].assetParamId+'" style="display:none;">'+json[i].editAccessFlag+'</span>';
									
									propertiesValue += '<span id="maxLength_'+json[i].assetParamId+'" style="display:none;">'+json[i].paramTextSize+'</span>';
									
									propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" style="display:none;">';
									if(json[i].isStatic == 0){
										if(json[i].hasArray == 0){
											propertiesValue += '<textarea class="mandetoryFieldValidation"  id="input_'+json[i].assetParamId+'"  value="" placeholder="Maximum characters '+json[i].paramTextSize+'" maxlength="'+json[i].paramTextSize+'"  rows="5" ></textarea></div>';
										}else{
											propertiesValue += '</div>';
										}
										
									}else{
										propertiesValue += '<textarea class="mandetoryFieldValidation"  id="input_'+json[i].assetParamId+'"  value="" placeholder="Maximum characters '+json[i].paramTextSize+'" maxlength="'+json[i].paramTextSize+'"  rows="5" ></textarea></div>';
									
									}
									//=======Aditya over
									
									//propertiesValue += '<input onclick="propertiesEditLock()" id="input_'+json[i].assetParamId+'" type="text" value="" placeholder="Maximum characters '+json[i].paramTextSize+'" maxlength="'+json[i].paramTextSize+'"></div>';
									
									/*======================= Aditya ====================*/
									//propertiesValue += '<textarea  id="input_'+json[i].assetParamId+'"  value="" placeholder="Maximum characters '+json[i].paramTextSize+'" maxlength="'+json[i].paramTextSize+'"  rows="5" ></textarea></div>';
									/*= ====================== Aditya-over ====================*/
									
									//propertiesValue += '<pre class="propertiesCustomTextField customPreTag" maxlength="'+json[i].paramTextSize+'"  placeholder="Maximum characters '+json[i].paramTextSize+'" contenteditable="true"  id="input_'+json[i].assetParamId+'"></pre></div>';
									if(flag){
										if(value.startsWith("<")){
											/*var formatted =  formatXml(value);
											formatted = formatted.trim();
											formatted =	hljs.highlightAuto(formatted);
											propertiesValue += '<pre class="showProperties" >'+formatted.value+'</pre>';*/
											propertiesValue += '<div class="showProperties" >'+value+'</div>';
											
										}else{
											propertiesValue += '<a class="showProperties" href="'+value+'" target="_blank">'+value+'</a>';
										}
										
										
									}else{
										if(value.startsWith("<a")){
											propertiesValue += '<span class="showProperties" >'+value+'</span>';
										}else{
											/*var formatted =  formatXml(value);
											formatted = formatted.trim();
											formatted =	hljs.highlightAuto(formatted);*/
											
											if(json[i].isStatic == 0){
												
												
												if(json[i].hasArray == 0){
													/*propertiesValue += '<pre class="showProperties" >'+formatted.value+'</pre>';*/
													propertiesValue += '<div class="showProperties" >'+value+'</div>';
												}else{
													propertiesValue += '<pre class="ui segment showProperties newTextFieldStyle customPreTag mandetoryFieldValidation" style="overflow: visible !important;">';//<p>';//+formatted.value+'</p>';
													
													if(json[i].textDataList != null){
														var textDataListLength = (json[i].textDataList).length;
														/*propertiesValue += '<div class="ui list">'
														$.each(json[i].textDataList, function(key, val){
															var value = decodeURIComponent(val);
															if(value.length < 30){
																propertiesValue += '<a class="item" style="color: #525658;">'+value+'</a>';
															}else{
																propertiesValue += '<a class="item" style="color: #525658;">'+value.substring(0,30) +'...'+'</a>';
															}
															
															
														});
														propertiesValue += '</div>';*/
													}
													propertiesValue += '<div class="center"><div class="ui icon text_field_msg_class" style="margin-top: -2rem;margin-left: 0.6rem;"><div class="text_info_and_button"  style="display: none;"><i class="info circle icon teal"></i>';
													propertiesValue += '<span class="textFieldMsg" style="color: #525658; font-family: sans-serif;font-weight: 500; font-size: 12px;">Click on Show button to view the values. </span> </div></div>';
													propertiesValue += '<div class="countDisp" style="margin-left: 1rem !important;" id="textCount_'+json[i].assetParamId+'">'+json[i].textCount+' value(s)</div></div>';
													propertiesValue += '<button class="ui mini button showOrEditButton showText" style="margin-top: 2rem;" data-title="" id="editTextButton_'+json[i].assetParamId+'" onclick="editText('+json[i].assetParamId+')">Show text</button>'; //<!-- CHANDANA 04-06-2019 KEYBOARD CONTROLS DIV TO BUTTON -->
													propertiesValue += '</pre>';
													//propertiesValue += '</p>';
													/*========= Aditya 19.02.18 ======================*/
													/*propertiesValue += '<div class="ui inverted blurring dimmer editTextdimmerButtonStyle" style="z-index:1;"><div class="content">';
													propertiesValue += '<div class="center">';
													propertiesValue += '<div class="ui icon text_field_msg_class"><div class="text_info_and_button"><span class="" style="color: #525658;font-size: 12px;"><i class="info circle icon"></i>Click on </span> ';
													propertiesValue += '<div class="ui primary mini button showOrEditButton showText" id="editTextButton_'+json[i].assetParamId+'" onclick="editText('+json[i].assetParamId+')">Show Text</div>';
													propertiesValue += '<span class="textFieldMsg" style="color: #525658;font-size: 12px;"> to view the values. </span> </div>';
													
													if(json[i].textDataList != null){
														
														propertiesValue += '<div class="ui list" style="overflow-y: scroll;background: #f3f3f3;height: 2rem;">'
														$.each(json[i].textDataList, function(key, val){
															var value = decodeURIComponent(val);
															if(value.length < 30){
																propertiesValue += '<a class="item" style="color: #525658;font-size: 11px;">'+value+'</a>';
															}else{
																propertiesValue += '<a class="item" style="color: #525658;font-size: 11px;">'+value.substring(0,30) +'...'+'</a>';
															}
														});
														propertiesValue += '</div>';
													}
													
													
													propertiesValue += '</div></div></div></pre>';*/
													
													/*propertiesValue += '<div class="ui inverted blurring dimmer editTextdimmerButtonStyle" style="z-index:1;"><div class="content"><div class="center">'; 
													propertiesValue += '<div class="ui primary mini button showOrEditButton showText" id="editTextButton_'+json[i].assetParamId+'" onclick="editText('+json[i].assetParamId+')">Show Text</div>';
													propertiesValue += '</div></div></div></pre>';*/
													/*============ Aditya Over =====================*/
												}
												
												
											}else{
												/*propertiesValue += '<pre class="showProperties" >'+formatted.value+'</pre>';*/
												propertiesValue += '<div class="showProperties" >'+value+'</div>';
											}
											
											
										}
									}
									//propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
									propertiesValue += '<div class="ui  pointing red basic label errMandetoryField errMandetory_'+json[i].assetParamId+'" style="display:none;">Please provide value</div>';
								}else if(json[i].paramTypeId == 2){
									inputType = "date";
									dateFlag = true;
									var reversed,pieces,date;
									if(json[i].isStatic == 0){
										date = json[i].paramValue;
									}else{
										date = json[i].staticValue;
									}
								 	if(date == null){
								 		date = "";
								 	}
								 		
								 	propertiesValue += '<div class="ui left icon right action input editProperties propertiesLockedByOther" style="display:none;">';
								 	propertiesValue += '<input readonly id="input_'+json[i].assetParamId+'" class="editProperties" type="text" value="'+date+'" placeholder="dd/mm/yyyy" title="Click to change date" style="cursor:pointer" >';
								 	propertiesValue += ' <i class="calendar icon"></i>';
								 	propertiesValue += '<div class="ui icon button" title="Clear date field" onclick="$(\'#input_'+json[i].assetParamId+'\').val(\'\');"> <i class="close icon"></i> </div>';	
								 	propertiesValue += '</div>';
								 		
								 	propertiesValue += '<span class="showProperties" >'+date+'</span>';
								 	propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
								 	propertiesValue += '<span id="isMandatory_'+json[i].assetParamId+'" style="display:none;">'+json[i].mandatory+'</span>';
								 	propertiesValue += '<span id="isEditable_'+json[i].assetParamId+'" style="display:none;">'+json[i].editAccessFlag+'</span>';
								 	propertiesValue += '<br><div class="ui  pointing red basic label errMandetoryField errMandetory_'+json[i].assetParamId+'" style="display:none;">Please provide value</div>';
								 	
								}else if(json[i].paramTypeId == 3){
									inputType = "file";
									fileFlag = true;
									var fileName; 
									if(json[i].isStatic == 0){
										fileName = json[i].fileName;
									}else{
										fileName = json[i].apdFileName;
									}
									if(fileName == null){
										fileName = "";
									}
									
									var fileType = fileName.split('.').pop().toLowerCase();
									
								 	
								 	$('#fileForm').append("<input type='file' class='hidden' name='hidden_"+json[i].assetParamId+"' id='hidden_"+json[i].assetParamId+"' />");
								 	
								 	propertiesValue += '<label for="input_'+json[i].assetParamId+'" class="ui icon mini button editProperties propertiesLockedByOther fileUpload uploadBtn_'+json[i].assetParamId+'" tabindex = "0" style="display:none;">'; 
									propertiesValue += '<i class="file icon"></i> Upload File</label>';
									propertiesValue += '<input id="input_'+json[i].assetParamId+'" onchange="showUploadedFile(this,'+json[i].assetParamId+')" style="display: none;" class="upFile" type="file" name="uploadedFile_'+json[i].assetParamId+'">';
									
								 	if(json[i].isStatic == 1){
									 	if(fileType == "jpeg" || fileType == "png" || fileType == "jpg"){
									 		propertiesValue += '<image id="paramImage_'+json[i].assetParamId+'" src="/repopro/images/thumbnailImages/'+json[i].assetParamId+"_"+fileName+'">';
									 		propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json[i].assetParamId+'" href="/repopro/images/thumbnailImages/'+json[i].assetParamId+"_"+fileName+'" download>'+fileName+'</a>';
								 	
									 	}else{
									 		//console.log(JSON.stringify(json[i]))
									 		propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json[i].assetParamId+'" onclick="downloadFile('+json[i].isStatic+',\''+json[i].assetParamName+'\')">'+fileName+'</a>';
								 	
									 	}	
									 		
								 	}else{	
								 		if(fileType == "jpeg" || fileType == "png" || fileType == "jpg"){	
									 		propertiesValue += '<image id="paramImage_'+json[i].assetParamId+'" src="/repopro/images/thumbnailImages/'+json[i].assetInstParamId+"_"+fileName+'">';
									 		propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json[i].assetParamId+'" href="/repopro/images/thumbnailImages/'+json[i].assetInstParamId+"_"+fileName+'" download>'+fileName+'</a>';
								 		}else{
								 			propertiesValue += '<a class="downloadAccess" style="margin-left: 1em; cursor: pointer;" id="fileName_'+json[i].assetParamId+'" onclick="downloadFile('+json[i].isStatic+',\''+json[i].assetParamName+'\')">'+fileName+'</a>';
								 		}
								 	}
								 	
								 	propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none; ">'+json[i].isStatic+'</span>';
								 	propertiesValue += '<span id="isMandatory_'+json[i].assetParamId+'" style="display:none;">'+json[i].mandatory+'</span>';
								 	propertiesValue += '<span id="isEditable_'+json[i].assetParamId+'" style="display:none;">'+json[i].editAccessFlag+'</span>';
								 	propertiesValue += '<span id="oldFileName_'+json[i].assetParamId+'" style="display:none; ">'+fileName+'</span>';
								 	/*propertiesValue += '<label for="input_'+json[i].assetParamId+'" class="ui icon mini button editProperties propertiesLockedByOther"  style="float: right;display:none;">'; 
									propertiesValue += '<i class="file icon"></i> Upload File</label>';
									propertiesValue += '<input id="input_'+json[i].assetParamId+'" onchange="showUploadedFile(this,'+json[i].assetParamId+')" style="display: none;" class="upFile" type="file" name="uploadedFile_'+json[i].assetParamId+'">';
									*/
								 	propertiesValue += '<br><div class="ui  pointing red basic label errMandetoryField errMandetory_'+json[i].assetParamId+'" style="display:none;">Please provide value</div>';
								}else if(json[i].paramTypeId == 4){
									var value;
									listFlag = true;
									
									if(json[i].isStatic == 0){
										value = json[i].paramValue;
									}else{
										value = json[i].staticValue;
										
									}
									if(value == null ){
										value = "";
									}
									
									if(json[i].listTypeParamTypeId == 1 ){
										inputType = "list";
										/*propertiesValue += getCustomList(json[i].assetParamId);*/
										var assetParamValue = json[i].assetParamId +"~~";
										custListAssetParamID += assetParamValue; 
										
										propertiesValue += '<span id="customList_'+json[i].assetParamId+'"></span>';
										
										if(value == -1 || value == ""){
											propertiesValue += '<span id="custListSelectValue_'+json[i].assetParamId+'" class="showProperties" style="display:none;"></span>';
										}else{
											
											var data = value.split("~~");
											var selectedLabels = "";
											$.each(data, function(j){
												selectedLabels += '<div class="ui label listShowPropertiesLabelStyle">'+data[j]+'</div>';
											});
											
											propertiesValue += '<span  class="showProperties" style="display:none;">'+selectedLabels+'</span>';
											propertiesValue += '<span id="custListSelectValue_'+json[i].assetParamId+'"  style="display:none;">'+value+'</span>';
											
										}
										propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
										propertiesValue += '<span id="isMandatory_'+json[i].assetParamId+'" style="display:none;">'+json[i].mandatory+'</span>';
										propertiesValue += '<span id="isEditable_'+json[i].assetParamId+'" style="display:none;">'+json[i].editAccessFlag+'</span>';
										propertiesValue += '<span id="isMultiple_'+json[i].assetParamId+'" style="display:none;">'+json[i].singleMultipleFlag+'</span>'; //harish
										//propertiesValue += '<br><div class="ui  pointing red basic label errMandetoryField errMandetory_'+json[i].assetParamId+'" style="display:none;">Please provide value</div>';
									}else if(json[i].listTypeParamTypeId == 2 ){
										
										inputType = "list";
										
										if(value == -1 || value == ""){
											propertiesValue += '<span id="assetListSelectValue_'+json[i].assetParamId+'" class="showProperties" style="display:none;"></span>';
										}else{
											
											var data = value.split("~~");
											var selectedLabels = "";
											$.each(data, function(j){
												selectedLabels += '<div class="ui label listShowPropertiesLabelStyle">'+data[j]+'</div>';
											});
											
											propertiesValue += '<span class="showProperties" style="display:none;">'+selectedLabels+'</span>';
											propertiesValue += '<span id="assetListSelectValue_'+json[i].assetParamId+'"  style="display:none;">'+value+'</span>';
										
										}
										
										propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
										propertiesValue += '<span id="isMandatory_'+json[i].assetParamId+'" style="display:none;">'+json[i].mandatory+'</span>';
										propertiesValue += '<span id="isEditable_'+json[i].assetParamId+'" style="display:none;">'+json[i].editAccessFlag+'</span>';
										propertiesValue += '<span id="isMultiple_'+json[i].assetParamId+'" style="display:none;">'+json[i].singleMultipleFlag+'</span>'; //harish
										
										
										propertiesValue += '<div id="assetList_'+json[i].assetParamId+'" >';
										if(json[i].singleMultipleFlag == false || json[i].singleMultipleFlag == "false") {
											propertiesValue += '<select  class="ui search selection dropdown propertiesLockedByOther callAssetListAPI propDropdownWidth"  id="input_'+json[i].assetParamId+'" multiple="">';
											propertiesValue += '<option value="">Select</option>';
										}
										if(json[i].singleMultipleFlag == true || json[i].singleMultipleFlag == "true") {
											propertiesValue += '<select  class="ui search selection dropdown propertiesLockedByOther callAssetListAPI propDropdownWidth"  id="input_'+json[i].assetParamId+'" >';
											propertiesValue += '<option value="">Select</option>';
											propertiesValue += '<option value="-1">Select</option>';
										}
										if(value != ""){
											//harish
											/*propertiesValue += '<option value="">Select</option>';*/
											if(json[i].singleMultipleFlag == false || json[i].singleMultipleFlag == "false") {
											value = value.split("~~");
											$.each(value, function(j) {
												  propertiesValue += '<option value="'+encodeURIComponent(value[j])+'">'+value[j]+'</option>';
												  listArr.push(encodeURIComponent(value[j]));
											});
											}
											if(json[i].singleMultipleFlag == true || json[i].singleMultipleFlag == "true") {
												 propertiesValue += '<option value="'+encodeURIComponent(value)+'">'+value+'</option>';
											}
										}else{
											propertiesValue += '<option value="">Select</option>';
										}
										propertiesValue += '</select></div>';
										setTimeout(function(){
											/*alert("set time out");*/
											//harish
											if(json[i].singleMultipleFlag == false || json[i].singleMultipleFlag == "false")
												$('#input_'+json[i].assetParamId).dropdown('set selected',listArr);
											if(json[i].singleMultipleFlag == true || json[i].singleMultipleFlag == "true")
												$('#input_'+json[i].assetParamId).dropdown('set selected',value);
										}, 0);
										
										
									}else if(json[i].listTypeParamTypeId == 3 ){
										
										inputType = "list";
										/*propertiesValue += getActiveUserList(json[i].assetParamId);*/
										userListAssetParamID += json[i].assetParamId +"~~";
										multiSelectFlag += json[i].singleMultipleFlag + "~~";  //harish
										
										propertiesValue += '<span id="userList_'+json[i].assetParamId+'"></span>';
										
										if(value == -1 || value == ""){
											propertiesValue += '<span id="userListSelectValue_'+json[i].assetParamId+'" class="showProperties" style="display:none;"></span>';
										}else{
											
											var data = value.split("~~");
											var selectedLabels = "";
											$.each(data, function(j){
												selectedLabels += '<div class="ui label listShowPropertiesLabelStyle">'+data[j]+'</div>';
											});
											
											propertiesValue += '<span  class="showProperties" style="display:none;">'+selectedLabels+'</span>';
											
											propertiesValue += '<span id="userListSelectValue_'+json[i].assetParamId+'"  style="display:none;">'+value+'</span>';
										
										}
										
										propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
										propertiesValue += '<span id="isMandatory_'+json[i].assetParamId+'" style="display:none;">'+json[i].mandatory+'</span>';
										propertiesValue += '<span id="isEditable_'+json[i].assetParamId+'" style="display:none;">'+json[i].editAccessFlag+'</span>';
										propertiesValue += '<span id="isMultiple_'+json[i].assetParamId+'" style="display:none;">'+json[i].singleMultipleFlag+'</span>'; //harish
										
									}
									propertiesValue += '<br><div class="ui  pointing red basic label errMandetoryField errMandetory_'+json[i].assetParamId+'" style="display:none;">Please provide value</div>';
									
								}else if(json[i].paramTypeId == 5){
									/*deriveAttrFlag = true;
									inputType = "derivedAttribute";
									var derivedData;
									if(json[i].paramValue == null){
										derivedData = "";
									}else{
										derivedData = json[i].paramValue;
									}
									
									var formatted =  formatXml(derivedData);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);
							
									formatted.value = formatted.value.replace(/~~/g,",");
									//console.log(" formatted "+JSON.stringify(formatted));
									
									propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
									propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
									propertiesValue += '<pre>'+formatted.value+'</pre>';
									
									propertiesValue += '</div>';*/
									
									deriveAttrFlag = true;
									inputType = "derivedAttribute";
									var derivedData;
									if(json[i].paramValue == null){
										derivedData = "";
									}else{
										derivedData = json[i].paramValue;
									}
									
									propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
									propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
									
									/*var formatted =  formatXml(derivedData);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);
									//console.log(" formatted:      "+formatted.value);
									formatted.value = formatted.value.replace(/~~/g,",");
									var derData = formatted.value;*/
									
									
									
									
									
									if (derivedData.indexOf('`!!`') != -1) {
										var data = derivedData.split('`!!`');
										derivedData = data[1];
									}
									//console.log(derivedData)
									derivedData = derivedData.split("`~`");
									//console.log(" derivedData "+derivedData);
									$.each(derivedData,function(e){
										var derviedSplittedValue = derivedData[e].split("~~");
										
										$.each(derviedSplittedValue,function(n){
											//console.log(" derviedSplittedValue "+derviedSplittedValue[n]);
											
											formatted = derviedSplittedValue[n].trim();
											propertiesValue += '<div class="ui basic label disabled">';
											
											/*if(formatted.startsWith("<")){
												formatted =	hljs.highlightAuto(formatted);
												propertiesValue += '<pre>'+formatted.value+'</pre>';
											}else{*/
												propertiesValue += '<span>'+formatted+'</span>';
											//}
											
											
											propertiesValue += '</div>'; 
											
										});
										
										
										
										if(e < (derivedData.length-1)){
											propertiesValue += '<div class="ui divider"></div>';
										}
											
										
									});
									propertiesValue += '</div>';
									
									
									
								}else if(json[i].paramTypeId == 6){
									inputType = "derivedComputation";
									var derivedData;
									if(json[i].paramValue == null){
										derivedData = "";
									}else{
										derivedData = json[i].paramValue;
									}
									propertiesValue += '<div class="deriveAttrPropertiesViewStyle">';
									propertiesValue += derivedData;
									propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
									propertiesValue += '</div>';
								}else if(json[i].paramTypeId == 7){  //souradip 06/02/18
									inputType = "richText";
									richTextFlag = true;
									var value,valueforInputfield;
									
									if(json[i].isStatic == 0){
										if(json[i].paramValue != null)
										value = json[i].paramValue;
										
									}else{
										if(json[i].staticValue != null)
										value = json[i].staticValue;
									}
									if(value == null ){
										value = "";
									}
									
									
									
									propertiesValue += '<span id="isStatic_'+json[i].assetParamId+'" style="display:none;">'+json[i].isStatic+'</span>';
									propertiesValue += '<span id="isMandatory_'+json[i].assetParamId+'" style="display:none;">'+json[i].mandatory+'</span>';
									propertiesValue += '<span id="isEditable_'+json[i].assetParamId+'" style="display:none;">'+json[i].editAccessFlag+'</span>';
									propertiesValue += '<span id="hasArray_'+json[i].assetParamId+'" style="display:none;">'+json[i].hasArray+'</span>';
									propertiesValue += '<span id="hiddenJSON_'+json[i].assetParamId+'" style="display:none;"></span>';
									propertiesValue += '<span id="dataForText_'+json[i].assetParamId+'" style="display:none;"></span>';
									
									/*	if(value.startsWith("<pre")){
										propertiesValue += '<div class="showProperties" id="showProperties_'+json[i].assetParamId+'" style="display:none;">'+value+'</div>';
									}else{
										var formatted =  formatXml(value);
										formatted = formatted.trim();
										formatted =	hljs.highlightAuto(formatted);
										propertiesValue += '<pre class="showProperties" id="showProperties_'+json[i].assetParamId+'" style="display:none;">'+formatted.value+'</pre>';
									}*/
									
									
									
									//*****************Aditya02.03.18
									/*propertiesValue += '<div  class="ui stacked  segment showProperties richTextCustomView " style="min-height:5em;">Total No of fields: '+json[i].rtfCount;
									propertiesValue += '<div class="ui inverted dimmer" style="z-index:1;"><div class="content"><div class="center">';
									propertiesValue += '<div class="ui primary mini button" onclick="openViewRichTextModal('+json[i].assetParamId+')">Show All Fields</div>';
									propertiesValue += '</div></div></div>';
									propertiesValue += '</div>';
									*/
									propertiesValue += '<div  class="ui segment showProperties richTextCustomView " style="min-height:5.2rem !important;">';
									propertiesValue += '<div class="center"><div class="ui icon text_field_msg_class" style="margin-top: -0.5rem;display:none;"><div class="text_info_and_button"  style="display: none;"><i class="info circle icon teal"></i>';
									propertiesValue += '<span class="richTextFieldMsg" style="color: #525658 !important; font-family: sans-serif;font-weight: 500 !important; font-size: 12px !important;">Click on Show button to view the values. </span> </div></div>';
									if(json[i].hasArray == 0){
										
										propertiesValue += '<div class="countDispForSingleRichText">'+value+'</div>';
										
										propertiesValue += '</div>';//margin-left: 26.5rem;
										propertiesValue += '<button class="ui mini button rtfBtnShow" id="rtfBtn_'+json[i].assetParamId+'" style="margin-top: 1rem !important;" data-title=""  onclick="openViewRichTextModal('+json[i].assetParamId+')">Show all fields</button></div>';
										
									}else{
										propertiesValue += '<div class="countDisp">'+json[i].rtfCount+' value(s)</div>';
										
										propertiesValue += '</div>';//margin-left: 26.5rem;
										propertiesValue += '<button class="ui mini button rtfBtnShow" id="rtfBtn_'+json[i].assetParamId+'" style="margin-top: 2rem !important;" data-title=""  onclick="openViewRichTextModal('+json[i].assetParamId+')">Show all fields</button></div>';
										
									}
									
									/*propertiesValue += '</div>';
									propertiesValue += '<div class="ui mini button rtfBtn" id="rtfBtn_'+json[i].assetParamId+'" style="margin-left: 26.5rem;margin-top: -0.5rem !important;" data-title=""  onclick="openViewRichTextModal('+json[i].assetParamId+')">Show All Fields</div></div>';
									*///*******Aditya over
									
									propertiesValue += '<div  id="showProperties_'+json[i].assetParamId+'" style="display:none;">'+value+'</div>';
									
									
									
									//propertiesValue += '<div class="showProperties" id="showProperties_'+json[i].assetParamId+'" style="display:none;">'+value+'</div>';
									
									
									
									
									propertiesValue += '<div class="ui fluid input editProperties propertiesLockedByOther" >';

									//******Commented by aditya 02.03.18
									/*propertiesValue += '<div class="ui segment richTextCustomView customPreTag mandetoryFieldValidation" style="min-height:7em;">';
									propertiesValue += '<div class="richTextBackendData" style="min-height:5em; " id="input_'+json[i].assetParamId+'"  maxlength="'+json[i].paramTextSize+'">Total No of fields: '+json[i].rtfCount+'</div>';
									propertiesValue += '<div class="ui inverted blurring dimmer " style="z-index:1;"> <div class="content"> <div class="center">'; 
									propertiesValue += '<div class="ui primary mini button" id="editTextButton_'+json[i].assetParamId+'" onclick="editRichTextAreaFields('+json[i].assetParamId+')">Edit Rich Text</div>';
									propertiesValue += '</div> </div></div>';
									propertiesValue += '</div></div>';*/
									//******Commented over by aditya 02.03.18
									
									propertiesValue += '<div class="ui segment richTextCustomView customPreTag mandetoryFieldValidation" style="min-height:5.2rem!important;color: #606365 !important;padding-left: 1rem !important;">';
									propertiesValue += '<div class="center"><div class="ui icon text_field_msg_class" style="display: none;"><div class="text_info_and_button"  style="display: none;"><i class="info circle icon teal"></i>';
									propertiesValue += '<span class="richTextFieldMsg" style="color: #606365 !important; font-family: sans-serif;font-weight: 500 !important; font-size: 12px !important;">Click on Edit button to edit the values. </span> </div></div>';

									if(json[i].hasArray == 0){
										propertiesValue += '<div class="richTextBackendData countDispForSingleRichText" id="input_'+json[i].assetParamId+'"  maxlength="'+json[i].paramTextSize+'">'+value+'</div>';
										
										propertiesValue +='</div>';//margin-left: 25.3rem;
										propertiesValue += '<button class="ui mini button rtfBtnEdit" style="margin-top: 1rem !important;" data-title="" id="editTextButton_'+json[i].assetParamId+'" onclick="editRichTextAreaFields('+json[i].assetParamId+')">Edit rich text</button>';
										
									}else{
										propertiesValue += '<div class="richTextBackendData countDisp" id="input_'+json[i].assetParamId+'"  maxlength="'+json[i].paramTextSize+'">'+json[i].rtfCount+' value(s)</div>';
										
										propertiesValue +='</div>';//margin-left: 25.3rem;
										propertiesValue += '<button class="ui mini button rtfBtnEdit" style="margin-top: 2rem !important;" data-title="" id="editTextButton_'+json[i].assetParamId+'" onclick="editRichTextAreaFields('+json[i].assetParamId+')">Edit rich text</button>';
									}
									
									
									propertiesValue += '</div></div>';
									
									propertiesValue += '<div class="ui  pointing red basic label errMandetoryField errMandetory_'+json[i].assetParamId+'" style="display:none;">Please provide value</div>';
								}
								
								
								
								
								assetParamIdList.push(json[i].assetParamId);
								var appendPropertiesData = loadPropertiesData(json[i].cat_disp, json[i].param_disp, json[i].assetParamName, json[i].assetParamId, propertiesValue, inputType,json[i].description,json[i].mandatory);
								$("#parameterTbody_"+json[i].cat_disp).append(appendPropertiesData);
								
								//check category wise access for the user
								if(json[i].editAccessFlag == false){
									//$("#desc_"+json[i].cat_disp+"_"+json[i].param_disp).addClass("propertiesAIVNoEditAccess");
									if(textFlag){
										if(json[i].hasArray == 0){
											$("#input_"+json[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										}else{
											$("#editTextButton_"+json[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										}
									}else if(richTextFlag){
										$("#editTextButton_"+json[i].assetParamId).addClass("propertiesAIVNoEditAccess");
									}else if(listFlag){
										$("#customList_"+json[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										$("#userList_"+json[i].assetParamId).addClass("propertiesAIVNoEditAccess");
	 									$("#assetList_"+json[i].assetParamId).addClass("propertiesAIVNoEditAccess");
									}else if(dateFlag){
										$("#input_"+json[i].assetParamId).parent().addClass("propertiesAIVNoEditAccess");
									}else if(fileFlag){
										$("#input_"+json[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										$(".uploadBtn_"+json[i].assetParamId).addClass("propertiesAIVNoEditAccess");
										
									}/*else{
										$("#input_"+json[i].assetParamId).addClass("propertiesAIVNoEditAccess");
									}*/
								}
								
								var descriptionMini = json[i].description;
								
								if(descriptionMini != null){
									if(descriptionMini.length > 300){
										descriptionMini = descriptionMini.substring(0,300) + "...";
									 }
								}
								
								$("#param_desc_"+json[i].assetParamId).attr("data-html",descriptionMini);
								
								
								$(".parameterInfo").popup();
								$('.upFile').on('change', function(t){
									var parId = $(this).attr('id');
									parId = parId.split('_');
									parId = parId[1];
									$('#hidden_'+parId).val($(this).val());
								});
								
								
								if(textFlag){
									var multiData = [];
									 
									if(json[i].isStatic == 1){
										value = json[i].staticValue;
										
									}else{
										if(json[i].hasArray == 0){
											value = json[i].paramValue;
										}else{
											//multiData = json[i].textDataList;
											
											if(json[i].textDataList != null){
												$.each(json[i].textDataList,function(j){
													multiData.push(encodeURIComponent(json[i].textDataList[j]));
													
												});
											}
											
										}
									}
									if(value == null ){
										value = "";
										
									}
									
									
									
									if(multiData == null ){
										multiData = [];
										
									}
									
									var tempObj;
									
									if(json[i].isStatic == 0){
										if(json[i].hasArray == 1){
											tempObj = {
													"asset_category_name": json[i].asset_category_name,
											        "assetParamId": json[i].assetParamId,
											        "assetParamName": json[i].assetParamName,
											        "isStatic": 0,
											        "isArray" : 1,
											        "paramTypeId": 1,
										            "paramValue": null,
											        "text_data" : multiData
											};
										}
									}
									
								$("#hiddenJSON_"+json[i].assetParamId).html(JSON.stringify(tempObj));
									
									/*hljs.configure({
										lang : "xml",
										useBR: true
									});
									
									var formatted =  formatXml(value);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);*/
									
									$("#input_"+json[i].assetParamId).val(value);
									
								}
								
								if(dateFlag){
									
									$("#input_"+json[i].assetParamId).datepicker({
									      changeMonth: true,
									      changeYear: true,
									      showWeek: true,
									      firstDay: 1,
									      dateFormat: "dd/mm/yy",
									      showButtonPanel: true,
									      yearRange: '1900:2999',
									      beforeShow: function(input, inst) {
										        //Swathi-- Handle datepicker position before showing it.
										        // It's not supported by Datepicker itself (for now) so we need to use its internal variables.
										        var calendar = inst.dpDiv;										        
										        setTimeout(function() {
										            calendar.position({
										                my: 'right top',
										                at: 'right bottom',
										                collision: 'none',
										                of: input
										            });
										        }, 1);
										    }
									//end of code
									 });
								}
								
								if(listFlag){
									$("#input_"+json[i].assetParamId).dropdown();
									$("#input_"+json[i].assetParamId).parent().addClass("editProperties").attr("onclick","getAssetList("+json[i].mappedAssetId+","+json[i].assetParamId+")");
									$("#desc_"+json[i].cat_disp+"_"+json[i].param_disp).css("overflow","visible");
									
								}
								
								
								if(richTextFlag){
									/*$("#rtfBtn"+json[i].assetParamId).popup({*/
									$(".rtfBtnShow").popup({
										inline     : true,
										variation : 'inverted',
										html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on show button to view the values !</spam></div>'
									});
									//********Aditya 02.03.18
									/*$(".richTextCustomView").dimmer({
										  on: 'hover'
									});*/
									
									
									
									/*if(json[i].isStatic == 0){

										value = json[i].paramValue;

									}else{

										value = json[i].staticValue;
									}
									
									if(value == null ){
										value = "";

									}*/
									
									var onlyText = "";
									var arrWithTag = [];
									var arrWithoutTag = [];
									
									if(json[i].hasArray == 0){
										value = json[i].paramValue;
										$("#dataForText_"+json[i].assetParamId).html(value);
										onlyText = $("#dataForText_"+json[i].assetParamId).text();
										$("#dataForText_"+json[i].assetParamId).html("");
										
										
									}else{
										
										if(json[i].rTFwithOutTags != null && json[i].rTFwithTags != null){
											$.each(json[i].rTFwithOutTags,function(s){
												arrWithoutTag.push({
													"textField": encodeURIComponent(json[i].rTFwithOutTags[s])
												});
												
											});
											
											$.each(json[i].rTFwithTags,function(s){
												arrWithTag.push({
													"textField": encodeURIComponent(json[i].rTFwithTags[s])
												});
												
											});
										}
										
										
										
										
										
									}
										
									
									if(value == null ){
										value = "";
										
									}
									
									var tempObj;
									
									if(json[i].hasArray == 1){
										tempObj = {
												
												"asset_category_name": json[i].asset_category_name,
										        "assetParamId": json[i].assetParamId,
										        "assetParamName": json[i].assetParamName,
										        "isStatic": 0,
										        "isArray":1,
										        "paramTypeId": 7,
										        "paramValue":null,
										        "rich_text_data": {
										        	"with_tag": arrWithTag,
										        	"without_tag": arrWithoutTag
										        } 
										};
									}else{
										tempObj = {
										        
										        "asset_category_name": json[i].asset_category_name,
										        "assetParamId": json[i].assetParamId,
										        "assetParamName": json[i].assetParamName,
										        "isStatic": 0,
										        "isArray":0,
										        "paramTypeId": 7,
										        "paramValue":null,
										        "rich_text_data": {
										        					"with_tag": encodeURIComponent(value),
										        				    "without_tag": encodeURIComponent(onlyText)
										           				  }
												};
									}
									
									
									
									$("#hiddenJSON_"+json[i].assetParamId).html(JSON.stringify(tempObj));
									
									
									
									
									
									
									/*if(value.startsWith("<pre")){
										var formatted = $("#showProperties_"+json[i].assetParamId+" pre").text();
										formatted = formatted.trim();
										formatted =	hljs.highlightAuto(formatted);
										 $("#showProperties_"+json[i].assetParamId+" pre").html(formatted.value);
									}*/
									
									
									/*var id = "input_"+json[i].assetParamId;
									
									var editor = CKEDITOR.instances.id;
									if (editor) {
										editor.destroy(true);
									}
									
									CKEDITOR.replace(id, {
										toolbar : 'Basic',
										height : "10em"
									});
									
									if(json[i].isStatic == 0){

										value = json[i].paramValue;

									}else{

										value = json[i].staticValue;
									}
									
									if(value == null ){
										value = "";

									}
									
									var formatted =  formatXml(value);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);

									//CKEDITOR.instances[id].setData(value);
									$("#"+id).html(formatted.value)*/
								}
								
								
					});
							
							if(custListAssetParamID != ""){
								custListAssetParamID = custListAssetParamID.substr(0, custListAssetParamID.lastIndexOf("~~"));
								getCustomList(custListAssetParamID);
							}
							
							/*if(assetListAssetId != ""){
								assetListAssetId = assetListAssetId.substr(0, assetListAssetId.lastIndexOf("~~"));
								assetListAssetParamID = assetListAssetParamID.substr(0, assetListAssetParamID.lastIndexOf("~~"));
								
								getAssetList(assetListAssetId,assetListAssetParamID)
								
							}*/
							
							

							if(userListAssetParamID != ""){
								var userListArr = [];
								userListAssetParamID = userListAssetParamID.substr(0, userListAssetParamID.lastIndexOf("~~"));
								userListAssetParamID = userListAssetParamID.split("~~");
								multiSelectFlag = multiSelectFlag.split("~~"); //harish
								var userList = getActiveUserList(userListAssetParamID[0]);
								
								$.each(userListAssetParamID, function(i){
									var dropdownData = createListDropdown(userListAssetParamID[i],userList,multiSelectFlag[i]); //harish
									$("#userList_"+userListAssetParamID[i]).html(dropdownData);
									var selectedData = $("#userListSelectValue_"+userListAssetParamID[i]).text().trim();

									if(selectedData == "" || selectedData == null){
										$("#input_"+userListAssetParamID[i]).dropdown();
									}else{
										userListArr.length = 0;
										selectedData = selectedData.split("~~");
										/*alert(jQuery.type(selectedData));*/
										$.each(selectedData,function(i){
											userListArr.push(encodeURIComponent(selectedData[i]));
										});
										/*alert("  user list selectedData"+userListArr);*/
										$("#input_"+userListAssetParamID[i]).dropdown("set selected",userListArr);
									}
									$("#input_"+userListAssetParamID[i]).parent().addClass("editProperties");//.attr("onclick","propertiesEditLock()");
								});
							}
							
							
					}

				/*}else{
					if(json.message == "DATA_FROM_DB_NOT_FOUND"){
						$("#noAssetPropertiesData").show();
						$("#propertiesAccordion").hide();
						$("#editPropertiesData").hide();
						$("#expandAllAccordion").hide();
					}
				}
				*/
				
				$(".rtfBtnEdit").popup({
					 inline     : true,
					 variation : 'inverted',
					 html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on edit button to edit the values !</spam></div>'
				 });
				
				checkAccessForUserOnSuccess();
				$(".editProperties").hide();
				$(".showProperties").show();
			
	 
	 /********commented by Aditya
	  $('.newTextFieldStyle').dimmer({
	    on: 'hover'
	  });*/
	 
	$(".showOrEditButton").popup({
		 inline     : true,
		 variation : 'inverted',
		 html: '<div class="ui icon"> <i class="info circle icon"></i><spam style="color: white; font-family: sans-serif;font-weight: 400 !important; font-size: 11px !important;">Click on show button to view the values !</spam></div>'
	 });
	
}


//open Edit LDAP User Modal
function openEditLDAPUserModal(paramId){
	
	$("#closeLDAPUserList").unbind();
	$("#updateLDAPUserList").unbind();
	$("#searchLDAPUser").unbind();
	$("#searchedLdapUserInput").val('');
	$("#addedUserListLDAP").html('');
	
	$('#editLDAPUserListModal').modal('destroy');
	$('#editLDAPUserListModal').trigger("reset");
	$('#editLDAPUserListModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');	
	
	$("#searchedLDAPUserResults").html('<div class="ui message">Please search for the user. </div>');
	var paramName = $("#assetParamId_"+paramId).text();
	
	$("#editLDAPUserListParamName").html(paramName);
	
	var isSingleList = $("#isMultiple_"+paramId).text();
	if(isSingleList == "true"){
		$("#editLDAPMessage").text("Add single value for this parameter");
	}else{
		$("#editLDAPMessage").text("Add multiple value(s) for this parameter");
	}
	
	var addedList = $("#hiddenJSON_"+paramId).text();

	if(addedList == "" || addedList == null){
		$("#addListErrorMessages").show();
		$("#addedUserListLDAP").hide();
	}else{
		$("#addListErrorMessages").hide();
		$("#addedUserListLDAP").show();
		
		addedList = addedList.split('~~');	
		$("#addedUserListLDAP").html('');

		$.each(addedList, function(i){
			var data = addedList[i];
			data = data.split("(");
			var name = data[0];
			var id = (data[1]).replace(")","");
			var appendData = createLdapDataForAdd(id,name);
			$("#addedUserListLDAP").append(appendData);
		});
	}
	
	
	$("#searchLDAPUser").on('click',function(){
		
		$("#searchLDAPUser").addClass('loading');
		
		var searchedUser = $("#searchedLdapUserInput").val().trim();
		
		if(searchedUser != ""){
			var json = searchLDAPUser(searchedUser);
			
			appendData = "";
			
			if (json.status == "SUCCESS") {
				if(json.result == "" || json.result == null){
					$("#searchedLDAPUserResults").html('<div class="ui error message">User could not be found. </div>');
				}else{
					$("#searchedLDAPUserResults").html('');
					
					appendData = "";
					
					$.each(json.result, function(i) {
						appendData = loadLdapDataInGrid(json.result[i].userId, json.result[i].firstName, json.result[i].lastName,isSingleList);
						$("#searchedLDAPUserResults").append(appendData);
						//check already added. If yes hide/disable user.
						$(".addedLDAPLoop").each(function(){
							
							var data = $(this).attr("id");
							data = data.split("_");
							var id = data[1];
							if(id == json.result[i].userId){
								$("#userLDAP_"+json.result[i].userId).addClass('browserDisableDropdown');
							}
						});
					});
					
				}
			}else {	
				notifyMessage("Search LDAP Users",json.message,"fail");		
			}
			
		}else{
			notifyMessage("Search LDAP Users", "Please provide some search content", "warning");
		}
		
		setTimeout(function(){
			$("#searchLDAPUser").removeClass('loading');
		},0);
		
	});
	
	$("#updateLDAPUserList").on('click',function(){
		
		var userListLDAP = "";
		
		$(".addedLDAPLoop").each(function(){
			var data = $(this).attr("id");
			data = data.split("_");
			var id = data[1];
			var name = $("#LDAPUserNameAdded_"+id).text();
			
			userListLDAP += name+"("+id+")~~";
		});
		userListLDAP = userListLDAP.slice(0,-2);
		
		$("#hiddenJSON_"+paramId).html(userListLDAP);
		
		if(isSingleList == "true"){
			$("#ldapUserCount_"+paramId).html(userListLDAP);
		}else{
			if(userListLDAP == ""){
				$("#ldapUserCount_"+paramId).html("0 value(s)");
			}else{
				var data = userListLDAP.split("~~");
				$("#ldapUserCount_"+paramId).html(data.length+" value(s)");
			}
		}
		
		$('#editLDAPUserListModal').modal('hide');
		
	});
	
	$("#closeLDAPUserList").on("click",function(){
		$('#editLDAPUserListModal').modal('hide');
	});
			
	
}



// load Ldap Data In Grid
function loadLdapDataInGrid(userId, firstName, lastName,isSingleList){
	
	appendData = "";
	appendData += '<div class="ui basic fluid label userListLoop raisedLabelStyle"  id="userLDAP_'+userId+'">'
	appendData += '<span id="LDAPUserName_'+userId+'">'+firstName+' '+lastName+'</span>';
	appendData += '<div class="detail">('+userId+')</div>';
	appendData += '<div class="detail" style="float: right;">';
	appendData += '<i class=" add icon deleteEditIcon" onclick="addLDAPValue(\''+userId+'\',\''+isSingleList+'\')"></i>';
	appendData += '</div></div>';
	
	return appendData;
}

//add LDAP Value
function addLDAPValue(userId,isSingleList){
	
	$("#addListErrorMessages").hide();
	var name = $("#LDAPUserName_"+userId).text().trim();
	
	$("#addedUserListLDAP").show();
	
	appendData = "";
	appendData = createLdapDataForAdd(userId,name);
	
	if(isSingleList == "true"){
		$("#addedUserListLDAP").html(appendData);
		$(".userListLoop").removeClass('browserDisableDropdown');
	}else{
		$("#addedUserListLDAP").append(appendData);
	}
	$("#userLDAP_"+userId).addClass('browserDisableDropdown');
	
}

//create Ldap Data For Add
function createLdapDataForAdd(userId,name){
	appendData = "";
	appendData += '<div class="ui basic fluid label addedLDAPLoop raisedLabelStyle"  id="userLDAPAdded_'+userId+'">'
	appendData += '<span id="LDAPUserNameAdded_'+userId+'">'+name+'</span>';
	appendData += '<div class="detail">('+userId+')</div>';
	appendData += '<div class="detail" style="float: right;">';
	appendData += '<i class=" delete icon deleteEditIcon" onclick="removeLDAPValueFromAddList(\''+userId+'\')"></i>';
	appendData += '</div></div>';
	
	return appendData;
	
}

//removeLDAPValueFromAddList
function removeLDAPValueFromAddList(userId){
	
	$("#userLDAPAdded_"+userId).remove();
	$("#userLDAP_"+userId).removeClass('browserDisableDropdown');
	if($("#addedUserListLDAP").html() == ""){
		$("#addedUserListLDAP").hide();
		$("#addListErrorMessages").show();
	}
}


//get LADP User Details
function getLADPUserDetails(event){
	var x = event.which || event.keyCode;
	if(x == 13){
		$("#searchLDAPUser").click();
	}
}



//search LDAP User
function searchLDAPUser(searchedUser){
	var json;
	$.ajax({
		type : "GET",
		url : '/repopro/web/ldapmanager/getallldapusers?uid='+searchedUser,
		contentType : "application/json",
		dataType : "json",
		async : false,
		cache: false,
		complete : function(data) {
			 json = JSON.parse(data.responseText);
		}
	});
	
	return json;
}


//openEditLDAPUserModal

function viewLDAPUserListModal(assetParamId){
	
	$("#closeLDAPUserListViewModal").unbind();
	
	$('#viewMultiLDAPUserList').modal('destroy');
	
	//editLDAPUserListModal
	$('#viewMultiLDAPUserList').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	var paramName = $("#assetParamId_"+assetParamId).text();
	$("#viewLDAPUserListParamName").html(paramName);
	
	var addedList = $("#hiddenJSON_"+assetParamId).text();
	
	if(addedList == "" || addedList == null){
		$("#viewModalDataLDAPUserContent").html('<div class="ui message">No user added yet.</div>');
	}else{
		addedList = addedList.split('~~');	
		$("#viewModalDataLDAPUserContent").html('');
		
		$.each(addedList, function(i){
			var data = addedList[i];
			data = data.split("(");
			var name = data[0];
			var id = (data[1]).replace(")","");
			/*alert("data " + data[1]);
			alert("id" + id)*/
			var appendData = loadViewDataForLDAPUserList(name,id);
			$("#viewModalDataLDAPUserContent").append(appendData);
		});
	}
	
	
	$("#closeLDAPUserListViewModal").on("click",function(){
		$('#viewMultiLDAPUserList').modal('hide');
	});
}


//Chandana LDAP Mapping
//openEditLDAPUserModal

function viewLDAPUserListModalMapping(assetParamId){
	$("#closeLDAPUserListViewModalMapping").unbind();
	$('#viewMultiLDAPUserListMapping').modal('destroy');
	$('#viewMultiLDAPUserListMapping').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	var paramName = $("#assetParamId_"+assetParamId).text();
	$("#viewLDAPMappingUserListParamName").html(paramName);
	var show_multi_appenData = "";
	
	var arr1 = [], arr2 = [], arr3 = [], arr4 = [], arr5 = [], arr6 = [];
	var count = 0;
	var first_Td = "", second_Td = "", third_Td = "", fourth_Td = "", fifth_Td = "", sixth_Td = "" ;
		$('#showMultipleSelectData_'+assetParamId).find('tr').each(function(index, tr) {
			first_Td = $(tr).find('td:eq(0)').text();
			first_Td = first_Td.split("$");
			
			second_Td = $(tr).find('td:eq(1)').text();
			second_Td = second_Td.split("$");
			
			third_Td = $(tr).find('td:eq(2)').text();
			third_Td = third_Td.split("$");
			
			fourth_Td = $(tr).find('td:eq(3)').text();
			fourth_Td = fourth_Td.split("$");
			
			
			fifth_Td = $(tr).find('td:eq(4)').text();
			fifth_Td = fifth_Td.split("$");
			
			sixth_Td = $(tr).find('td:eq(5)').text();
			sixth_Td = sixth_Td.split("$");
			
			if(first_Td[0] != ""){
				arr1.push(first_Td[0]); 
				count = arr1.length;
			}
			
			if(second_Td != ""){
				arr2.push(second_Td[0]);
				count = arr2.length;
			}
			
			if(third_Td != ""){
				arr3.push(third_Td[0]);
				count = arr3.length;
			}
			
			if(fourth_Td != ""){
				arr4.push(fourth_Td[0]);
				count = arr4.length;
			}
			
			if(fifth_Td != ""){
				arr5.push(fifth_Td[0]);
				count = arr5.length;
			}
			
			if(sixth_Td != ""){
				arr6.push(sixth_Td[0]);
				count = arr6.length;
			}
			
		});
		
		if(count > 0){
			for(var h=0; h<count; h++){

				show_multi_appenData += "<tr>";
				if(arr1[h] != undefined){
					show_multi_appenData += "<td>"+arr1[h]+"<span id='' class='hidden'>$"+first_Td[1]+"</td>";
				}
				if(arr2[h] != undefined){
					show_multi_appenData += '<td>'+arr2[h]+"<span id='' class='hidden'>$"+second_Td[1]+"</td>";
				}
				if(arr3[h] != undefined){
					show_multi_appenData += '<td>'+arr3[h]+"<span id='' class='hidden'>$"+third_Td[1]+"</td>";
				}
				if(arr4[h] != undefined){
					show_multi_appenData += '<td>'+arr4[h]+"<span id='' class='hidden'>$"+fourth_Td[1]+"</td>";
				}
				if(arr5[h] != undefined){
					show_multi_appenData += '<td>'+arr5[h]+"<span id='' class='hidden'>$"+fifth_Td[1]+"</td>";
				}

				if(arr6[h] != undefined){
					show_multi_appenData += '<td>'+arr6[h]+"<span id='' class='hidden'>$"+sixth_Td[1]+"</td>";
				}
				show_multi_appenData += '</tr>';
				$('#viewModalDataLDAPUserContentMapping').html("");
				$('#viewModalDataLDAPUserContentMapping').append(show_multi_appenData);

			}

		}
		else {
			show_multi_appenData = "";
			$("#viewModalDataLDAPUserContentMapping").html('<div class="ui message">No user added yet.</div>');
		}
	
	$("#closeLDAPUserListViewModalMapping").on("click",function(){
		$('#viewMultiLDAPUserListMapping').modal('hide');
	});
}


//load View Data For LDAP User List
function loadViewDataForLDAPUserList(name,id){

	appendData = "";
	appendData += '<div class="ui basic fluid label raisedLabelStyle" >'+name;
	appendData += '<div class="detail">('+id+')</div>';
	appendData += '</div>';

	return appendData;
}


// Chandana //
//load View Data For LDAP User List
function loadViewDataForLDAPUserListMapping(name,id){
/*alert("name " + name + "id" + id);*/
	appendData = "";
//	appendData += '<div class="ui basic fluid label raisedLabelStyle" >'+name;
//	appendData += '<div class="detail">('+id+')</div>';
//	appendData += '</div>';
	
	appendData += '<tr><td> '+name+' </td>';
	appendData += '<td class="detail">'+id+'</td>';
	appendData += '</tr>';

	return appendData;
}


var addParamList ='' ;
var addParameterDropdown ='';
var paramNamesinAlertDropdown = '';
var typeName = '';
var alertlistTypeName = '';
var alerParamRuleId = '';
var ruleArr = [];
var operatorArr = [];
var alertArr = [];
var getParamRuleId = '';
var getParamRuleValue = '';
var getParamRuleOperatorValue = '';
var getParamRuleParam1Value = '';
var alertParamTypeId ='';
var assetAlertParamId = '';
var alertListTypeParamTypeId = '';
var getAlertScheduler = '';
var getAlertInputData = '';
var firstAlertData = false;
var appendDeleteIcon = '';
var alertTypeName = '';

var updateMsgFlag = false; //setting the update msg flag

////////////////////////////////////////////////////////////////////////////////////////////////

//create filter modal //alerting - chandana 26.02.2020
var append_listofParameters;
function AlertingModal(){
	$('#openAlertingModal').modal('destroy');
	$('.SaveAlertData').unbind();
	$('#btnCancelAlerting').unbind();
	$('#openAlertingModal').modal({observeChanges : true}).modal('show').modal('refresh');
	
	 $('#tbl_defineParameterRules tbody').empty();
	 
	 $('#alertScheduler').dropdown('restore defaults'); 
	 createRow_new();
	 setTimeout(function(){ 
		 getRuleBasedIdforAlert_New();
		}, 1000);
	 showParamLoader();
	 load_state();
	 $('#addRuleSetBtn').show();
	  $('#updateRuleSetBtn').hide();
	 
	 keypress_alert();
	 
	//refreshTable();
	
	//getRuleBasedIdforAlert();
	
	/*if(loggedInUserName == "roleAnonymous"){
		$("#displaySaveFilter").hide();
		$("#btnSaveFilter").hide();
	}
	else{
		$("#displaySaveFilter").show();
		$("#btnSaveFilter").show();
	}*/
	/*$("#hiddenSaveFilter").hide();
	$("#savedFilterDiv").hide();
	$("#inputFilterSelector").hide();
	$("#noBrowserData").hide();
	
	refreshTable();*/

	//$("#noBrowserData").hide();

	
}

//refresh the table content -//alerting - chandana 26.02.2020
/*function refreshTable(){
	 $('#tbl_defineParameterRules tbody').empty();
	 $('#alertScheduler').dropdown('restore defaults'); 
	 //createRow();
   
}*/

//alerting - chandana 26.02.2020
/*var append_listofParameters;*/
/*function //createRow(){
	var newRowContent = "";

	newRowContent += '<tr style="outline: thin solid lightgrey" id="rowDataParamId_0">';
	newRowContent += '<td><select class="ui dropdown" id="showListofParameters" onchange="showOperatorsOnParamSelection(this);"><option value="">Select Parameter</option></select></td>';
	newRowContent += '<td><select class="ui dropdown" id="showListofOperators"><option value="">Select Operator</option></select></td>';
	newRowContent += '<td><div class="ui icon input"><input type="text" placeholder="Enter Value" id="enterValue"> <i class="info circle icon link" data-content="Use /, as a delimeter" data-variation="small"></i></div></td>';
	newRowContent += '<td><label class="themeTextColor" onclick="clearFilledData()">Clear</label></td>';
	newRowContent += '<td><label class="themeTextColor">Delete</label></td>';
	newRowContent += '</tr>';
	
	newRowContent += '<td><select class="ui dropdown" id="showListofParameters" onchange="showOperatorsOnParamSelection(this);" style="min-width: 10em;">';
	newRowContent += '<option value="selectParam">[Select Parameter]</option>';	
	newRowContent += '</select></td>';
	
	//operator dropdown
	newRowContent += '<td class="popuptabletr ddOptionSelector" style="vertical-align:top;">';
	newRowContent += '<select class="ui dropdown dropdownCssForFilter" id="showListofOperators">';
	newRowContent += '</select></td>';
	


	//Text
	newRowContent += '<td class="popuptabletr inputValueSelector" id="inputAlertField_0" style="display: none;vertical-align:top;">';
	newRowContent += '<div class="ui icon input focus" style="width: 195px;">';
	newRowContent += '<input type="text" id="inputAlertTextField_0" placeholder="Enter Text" class="customizeTextBox"> <i data-html ="hi" style="margin-left:1em;cursor:pointer;color: rgba(0,0,0,0.5);" data-html="" data-variation="wide" data-position="right center" class="info circle icon alertingInfo"></i>';
	newRowContent += '</div></td>';

	
	newRowContent += '<td class="popuptabletr posRemoveIcon" style="vertical-align:top;"><span class="remove icon" style="color: #F54C48 !important;    cursor: pointer;" onclick="refreshTable(this)" style="cursor: pointer;">Clear all</span></td></tr>';
	$("#tbl_defineParameterRules tbody").append(newRowContent);
	
	showParamLoader();
	$('#showListofParameters').empty();
	$('#showListofParameters').append('<option value="Select Parameter" id="Select Parameter">[Select Parameter]</option>');
	$('#showListofParameters').append(append_listofParameters);
	$('.ui.dropdown').dropdown();
	getRuleBasedIdforAlert_New();
	getRuleBasedIdforAlert();
	
}*/

//dynamically load asset param list- alerting - chandana 26.02.2020
var listofParamArray = [];

function showParamLoader(){	
	
	//listofParamArray.length = 0;
	/*var url = "http://localhost:7070/repopro/web/assetType/getParamListWithNotiFyEnabled?userName="+loggedInUserName+"&assetId="+assetId;
	console.log("load saved filter url  "+url)*/
	$(".parameterInfo").popup();
	append_listofParameters = "";
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetType/getParamListWithNotiFyEnabled?userName="+loggedInUserName+"&assetId="+assetId,
		dataType : "json",
		async: false,
		complete : function(data) {
		
			var json = JSON.parse(data.responseText);
			//console.log(JSON.stringify(json));
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null || json.result == []){
					$('.noteAlertMessage').show();
					$('.nodataWrapper').show();
					$('#NoAlertData').html('No data to display');
					$('#schedulerDD').hide();
					$('#alertDataInputs').hide();
					$('.SaveAlertData').show().attr('disabled',true);
					$("#updateParameterRule").hide();
				}
				else {
					//console.log(JSON.stringify(json));
					
					append_listofParameters="";
					
					$.each(json.result, function(i){
						$('#showListofOperators').addClass('disabled');
						$('#enterValue').attr('disabled',true);
						listofParamArray.push(json.result[i].assetParamName);
						//console.log(listofParamArray);
						append_listofParameters += '<option value="'+ json.result[i].assetParamId +'" class="'+json.result[i].typeName+'" id="'+json.result[i].assetParamId+'_'+json.result[i].paramTypeId+'_'+json.result[i].typeName+'_'+json.result[i].listTypeParamTypeId+'" data-typeName="'+json.result[i].listTypeName+'" data-mapId="'+json.result[i].mappedAssetId+'">'+ json.result[i].assetParamName +'</option> ' ;
						
						
					});
					//load_state();

				}
			}
		}
	});
	if(add_update_paramRule_Flag == false){
		$('.SaveAlertData').hide();
		$("#updateParameterRule").show();
	}
	else{
		$('.SaveAlertData').show();
		$("#updateParameterRule").hide();
	}
}


//load state

var append_states = "";

var listofstate = [];


function load_state(){
	
	$.ajax({
		
		type : "GET",
		url: "/repopro/web/assetType/getAllStatesOfWorkflow?assetId="+assetId,
		
		//url : "/repopro/web/assetType/getParamListWithNotiFyEnabled?userName="+loggedInUserName+"&assetId="+assetId,
		dataType : "json",
		async: false,
		complete : function(data) {
		
			var json = JSON.parse(data.responseText);
			//console.log(JSON.stringify(json));
			if(json.status == "SUCCESS"){
				
				if(json.result == "" || json.result == null || json.result == []){
					
				}
				else {
					
					//console.log(JSON.stringify(json));
					append_states = "";
					
					$.each(json.result, function(i){
						
						listofstate.push(json.result[i]);
						
						//console.log(listofstate);
						
						append_states += '<option value="'+ json.result[i] +'"  >'+ json.result[i] +'</option>' ;
						
						//console.log(append_states);
						
					});

				}
			}
		}
	});
}


//keypress
function keypress_alert(){
	$('.trash,#rulelist_tbl .rulese-view span,#addRuleBtn,#rulelist_tbl .rulese-view .trash').keypress(function (e) {
			 var key = e.which;
			 if(key == 13)  // the enter key code
			  {
			    $(this).click();
			    return false;  
			  }
			});  
	}

//vishnu aleriting enhancement 22/04/2020


function createRow_new(){
//	count ++;
	
	count = 0;
	var logicalrow_index = count;
	

    var deletemsg = "";
	deletemsg = "<p id='alertDelMsg' class='delPopUp' tabindex='0'>Are you sure you want to delete the parameter rule ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeAlertDeletepopUp()' tabindex='0'>No</button><button class='right floated ui primary mini button' tabindex='0' onclick='delete_rule_row(this)'>Yes</button> ";
	
	var newRowContent = "";

	newRowContent += '<tr  id="'+count+'">';
	newRowContent += '<td class="listofparameters"><select class="ui dropdown" id="showListofParameters_'+count+'" onchange="showOperatorsOnParamSelection(this);"><option value="">Select</option></select><div class="ui top pointing red basic label errShowListparam errtooltip" style="display:none;"></div></td>';
	newRowContent += '<td class="showoperator"><select class="ui dropdown disableAction" id="showListofOperators_'+count+'"><option value="">Select Operator</option></select><div class="ui top pointing red basic label errAlertShowOperator errtooltip" style="display:none;"></div></td>';
	newRowContent += '<td class="entervaluetd"><div class="ui icon input disableAction"><input type="text" placeholder="Enter Value" id="enterValue_'+count+'" autocomplete="off"> <span data-tooltip="Use /, as a delimeter to seperate multiple strings" data-position="bottom right"><i class="info circle icon link" ></i></span></div><div class="ui top pointing red basic label errAlertEnterText errtooltip" style="display:none;"></div></td>';
	newRowContent += '<td class="statedrop" style="display:none;"><select class="ui dropdown" id="showListofStates_'+count+'"><option value="">Select state</option></select><div class="ui top pointing red basic label errAlertShowState errtooltip" style="display:none;"></div> </td>';
	newRowContent += '<td ><i class="trash alternate icon disableAction" tabindex="0" data-html="'+deletemsg+'" id="deleteparamRuleId_'+count+'" onclick="showDeleteAlertingPopup('+count+')"></i></td>';
	newRowContent += '</tr>';
	
	
	$("#tbl_defineParameterRules tbody").append(newRowContent);
	

	//$('#showListofParameters_'+count).empty();
	
	showParamLoader();
	load_state();
	
	//$('#showListofParameters_'+count).append('<option value="Select Parameter" id="Select Parameter">Select</option>');
	
	$('#showListofParameters_'+count).append('<option class="header" disabled>Metadata</option>');
	$('#showListofParameters_'+count).append(append_listofParameters);
	$('#showListofParameters_'+count).append('<option class="header" disabled>Asset workflow</option>');
	$('#showListofParameters_'+count).append('<option class="state" id="0_0_workflow_0" value="0">State</option>');
	
	$('#showListofStates_'+count).append(append_states);
	
	count ++;
	
	$('.ui.dropdown').dropdown();
	
	keypress_alert();
	
	
	
	
}


function addRuleRow_new(){
	
	var tbody = $("#tbl_defineParameterRules tbody");


	 //var rulesetbody = $("#rulelist_tbl tbody");

	 
	 
	if (tbody.children().length == 0) {
		
		createRow_new();
		
	}
	else{
	var new_row = "";
	var logical_row = "" ;
	
//	
//	var rowcount=tbody.children().length;
//	var newcount=rowcount+1;
	
	//console.log(newcount);
	
	//newcount ++
	
	logical_row += '<tr id="'+count+'"><td class=""><select class="ui dropdown" id="paramRulelogicalOperators_'+count+'">';
	logical_row += '<option value="And">And</option>';
	logical_row += '<option value="Or">Or</option>';
	logical_row += '</select></td></tr>';
	
	$('#tbl_defineParameterRules tbody').append(logical_row);
	
	var logicalrow_index = count;
	
	count ++;
	
   var deletemsg = "";
   deletemsg = "<p id='alertDelMsg' class='delPopUp' tabindex='0'>Are you sure you want to delete the parameter rule ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeAlertDeletepopUp()'>No</button><button class='right floated ui primary mini button' onclick='delete_rule_row(this)'>Yes</button> ";
	
	new_row += '<tr  id="'+count+'">';
	new_row += '<td class="listofparameters"><select class="ui dropdown" id="showListofParameters_'+count+'" onchange="showOperatorsOnParamSelection(this);"><option value="">Select</option></select><div class="ui top pointing red basic label errShowListparam errtooltip" style="display:none;"></div></td>'
	new_row += '<td><select class="ui dropdown disableAction" id="showListofOperators_'+count+'" ><option value="">Select Operator</option></select><div class="ui top pointing red basic label errAlertShowOperator errtooltip" style="display:none;"></div></td>'
	new_row += '<td class="entervaluetd"><div class="ui input icon disableAction"><input type="text" placeholder="Enter value" id="enterValue_'+count+'" autocomplete="off"><span data-tooltip="Use /, as a delimeter to seperate multiple strings" data-position="bottom right"><i class="info circle icon link" ></i></span></div><div class="ui top pointing red basic label errAlertEnterText errtooltip" style="display:none;"></div></td>'	
	new_row += '<td class="statedrop" style="display:none;"><select class="ui dropdown " id="showListofStates_'+count+'"><option value="">Select State</option><option value="">Value1</option><option value="">Select State</option></select><div class="ui top pointing red basic label errAlertShowState errtooltip" style="display:none;"></div> </td>';
	new_row += '<td><i class="trash alternate icon " tabindex="0" data-html="'+deletemsg+'" id="deleteparamRuleId_'+count+'" onclick="showDeleteAlertingPopup('+count+')"></i></td>'	
	new_row += '</tr>';
	
	
	
	$('#tbl_defineParameterRules tbody').append(new_row);
	//$('#showListofParameters_'+count).append('<option value="Select Parameter" id="Select Parameter">Select</option>');
	$('#showListofParameters_'+count).append('<option class="header" disabled>Metadata</option>');
	$('#showListofParameters_'+count).append(append_listofParameters);
	$('#showListofParameters_'+count).append('<option class="header" disabled>Asset workflow</option>');
	$('#showListofParameters_'+count).append('<option class="state" id="0_0_workflow_0" value="0">State</option>');
	
	$('#showListofStates_'+count).append(append_states);
	
	$('#deleteparamRuleId_0').removeClass('disableAction');
	//$('#deleteparamRuleId_'+count).removeClass('disableAction');

	count ++;
	
	$('.ui.dropdown').dropdown();
	
	}
	
	keypress_alert();

}

//validation local save

function validation_save() {
    var rulename = $('#alertRuleName').val();
    var scheduler = $('#alertScheduler').dropdown('get text');
    var newscheduler = scheduler[0];
    var error_count = 0
 
    if (rulename == "" || rulename == null) {
        $('#alertRuleName').parent().addClass('error');
        $(".errAlertRulename").html("Please enter rule name").show();
 
    } else if (/^[a-zA-Z0-9- ]*$/.test(rulename) == false) {
		$('#alertRuleName').parent().addClass("error"); 
	    $(".errAlertRulename").html('Please use only alphanumeric character for rule name.').show();  
	}else {
        $('#alertRuleName').parent().removeClass('error');
        $(".errAlertRulename").hide();
    }
 
    if (newscheduler == "Select Repeat") {
        $('#alertScheduler').parent().addClass('error');
        $(".errAlertScheduler").html("please select repeat type").show();
    } else {
        $('#alertScheduler').parent().removeClass('error');
        $(".errAlertScheduler").hide();
    }
 
    var rulesteprows = $('#tableBody').children();
	
	for (j = 0; j < rulesteprows.length; j += 2) {
 
        var parameterName = $('#showListofParameters_' + rulesteprows[j].id).dropdown('get text');
        var operatorName = $('#showListofOperators_' + rulesteprows[j].id).dropdown('get text');
        var enterValue = $('#enterValue_' + rulesteprows[j].id).val();
 
        var statename = $('#showListofStates_' + rulesteprows[j].id).dropdown('get text');
 
        var sliceParameter = parameterName[0];
        var sliceOperator = operatorName[0];
        var slicestatename = statename[0];
 
        if (sliceParameter == "Select") {
            $('#showListofParameters_' + rulesteprows[j].id).parent().addClass('error');
            $('#enterValue_' + rulesteprows[j].id).parent().addClass('error');
            $('#showListofStates_' + rulesteprows[j].id).parent().addClass('error');
            error_count++;
 
        } else {
            $('#showListofParameters_' + rulesteprows[j].id).parent().removeClass('error');
            if (sliceParameter == "State") {
                if (slicestatename == "Select state") {
                    $('#showListofStates_' + rulesteprows[j].id).parent().addClass('error');
                    error_count++;
                } else {
                    $('#showListofStates_' + rulesteprows[j].id).parent().removeClass('error');
                }
            } else {
                if (enterValue == "") {
                    $('#enterValue_' + rulesteprows[j].id).parent().addClass('error');
                    error_count++;
                } else {
                    $('#enterValue_' + rulesteprows[j].id).parent().removeClass('error');
                }
            }
        }
 
        if (sliceOperator == "Select Operator") {
            $('#showListofOperators_' + rulesteprows[j].id).parent().addClass('error');
            error_count++;
        } else {
            $('#showListofOperators_' + rulesteprows[j].id).parent().removeClass('error');
        }
 
        if (j + 1 < rulesteprows.length) {
            var trimLogicalselectvalue = $('#paramRuleLogicalselectvalue_' + parseInt(rulesteprows[parseInt(j) + 1].id)).dropdown('get text');
            var sliceLogicalselect = trimLogicalselectvalue[0];
        }
 
    }
    //console.log('error_count');
    //console.log(error_count);
    //console.log('rulesteprows');
    //console.log(rulesteprows.length);
 
    if (rulename == "" || rulename == null || newscheduler == "Select Repeat" || error_count > 0) {
    	$(".errAlertRuleset").html("Please fill the empty fields").show();	
        return false;
    }
 
    else {
    	 $(".errAlertRuleset").hide();
        return true;
    }
 
}


var rulearray_Obj = {};

var ruleindex = 100;

var editRuleId = '';


function rulename_existenceCheck(rulenameTocheck) {

    var exsitence = false;

    const ruleIdArray = Object.keys(rulearray_Obj);

    for (k = 0; k < ruleIdArray.length; k++) {

        if (rulearray_Obj[ruleIdArray[k]]['basic']['rulename'] == rulenameTocheck) {

            if (editRuleId != '') {
                if (ruleIdArray[k] == editRuleId) {
                    exsitence = false;
                } else {
                    exsitence = true;
                }
            } else {
                exsitence = true;
            }

            break;
        }
    }
    return exsitence;
}


function add_rule() {
 if (validation_save()){
	 
	var rulename_existence = rulename_existenceCheck($('#alertRuleName').val());
	
    if (!rulename_existence) {
    	
        var idToprocced;
        if (editRuleId == '') {
            idToprocced = 'rule_' + ruleindex;
            ruleindex++;
        } else {
            idToprocced = editRuleId;
        }
        localadd_rules(idToprocced);
        
    } else {
    	$('#alertRuleName').parent().addClass('error');
		$(".errAlertRulename").html("Rule name already exists").show();
    }
	
 }
 var rulesetbody = $("#rulelist_tbl tbody");

 if (rulesetbody.children().length == 0) {
    $('#saveParameterRule').addClass('disabled');
 }else{
	 $('#saveParameterRule').removeClass('disabled');
 }
 
 $('#updateRuleSetBtn').hide(); 
	$('#addRuleSetBtn').show();
 
}

	
 function localadd_rules(ruleid){
		 
		 //alert ('add rule');
		 
		 var rulesteprows = $('#tableBody').children();
		   
		 if (!rulearray_Obj[ruleid]) {
			 
		        rulearray_Obj[ruleid] = {};
		        rulearray_Obj[ruleid]['basic'] = {};
		        
		    }
		    
		    rulearray_Obj[ruleid]['rulesteps'] = []; 
		 
		    var trimScheduler = $('#alertScheduler').dropdown('get text');
		    
		    rulearray_Obj[ruleid]['basic']['scheduler'] = trimScheduler[0];
		    
		    rulearray_Obj[ruleid]['basic']['rulename'] = $('#alertRuleName').val();
		    
		    
		    //console.log(rulearray_Obj[rulename]);
		    
		    if (rulearray_Obj[ruleid]['basic']['paramRuleId']) {
		    	
		    	//console.log(rulearray_Obj[ruleid]['basic']['paramRuleId']);
		    	
		    	rulearray_Obj[ruleid]['basic']['action'] = "update";
		    	
		    	    } else {
		    	    	
		    	rulearray_Obj[ruleid]['basic']['action'] = "add";
		    	
		    	    }
		    
				for( j = 0; j < rulesteprows.length;j += 2 ){ 
					
					var rulestepObj = {};
				    
					var trimParameter = $('#showListofParameters_'+rulesteprows[j].id).dropdown('get text');  
					var trimOperator = $('#showListofOperators_'+rulesteprows[j].id).dropdown('get text');
					var trimScheduler = $('#alertScheduler').dropdown('get text');
					var stateValue = $('#showListofStates_'+rulesteprows[j].id).dropdown('get text');
					
					rulestepObj['paramRuleValue'] = $('#showListofParameters_'+rulesteprows[j].id+' option:selected').attr('id');
					rulestepObj['paramRuleOperatorValue'] = trimOperator[0];
					
					if(trimParameter[0] == "State"){
					
						rulestepObj['paramRuleParam1Value'] = stateValue[0];
						
					}else{
						
						rulestepObj['paramRuleParam1Value'] = $('#enterValue_'+rulesteprows[j].id).val();
						
					}
					
					
					rulestepObj['scheduler'] = trimScheduler[0];
					rulestepObj['ParamdisplayName'] = trimParameter[0];
					
					
					
					if(  j+1 < rulesteprows.length){
						var trimLogicalselectvalue = $('#paramRulelogicalOperators_'+parseInt(rulesteprows[ parseInt(j)+1].id)).dropdown('get text');
						
						rulestepObj['paramRulelogicalOperators'] = trimLogicalselectvalue[0];
						
				          // rulestepObj['paramRuleLogicalselectvalue'] = $('#paramRuleLogicalselectvalue_'+parseInt(rulesteprows[ parseInt(j)+1].id)).dropdown('get text');
				        
				        } else{
						
				        	rulestepObj['paramRulelogicalOperators'] ="";	
					}
					
					rulearray_Obj[ruleid]['rulesteps'].push(rulestepObj);  
					//rulearray_Obj[rulename]
				   
				  // console.log(rulestepObj);
				   
				
				}
				
			
		 
		
		
		
		$('#alertScheduler').dropdown('clear');
		$('#alertRuleName').val('');
		
		
		//console.log(rulearray_Obj);

		//right side listing
		load_rule_list();
		
		$('#tbl_defineParameterRules tbody').empty();
		
		editRuleId='';
		
		createRow_new();
	 
	
	}
 

 function load_rule_list() {
	    count = 0;
	    $('#rulelist_tbl tbody').empty();
	 
	    //console.log(rulearray_Obj);
	    for (const ruleid in rulearray_Obj) {
	        if (rulearray_Obj.hasOwnProperty(ruleid)) {
	            if (rulearray_Obj[ruleid]['basic']['action'] != "delete") {
	                var deletemsg = "";
	                deletemsg = "<p id='alertDelMsg' class='delPopUp'>Are you sure you want to delete the parameter rule set?</p><button class='right floated ui cancel themeSecondary mini button' tabindex='0' id='"+ ruleid +"' onclick='closeAlertDeletepopUp(this)'>No</button><button tabindex='0' class='right floated ui primary mini button' id='"+ ruleid +"'   onclick='delete_rule_ruleset(this)'>Yes</button> ";
	                              
	                var rulestring = '<tr><td style="padding-left:0;padding-right:0"><div class="rulese-view"><span tabindex="0" id="' + ruleid + '" onclick="trigger_recreate(this)">' + rulearray_Obj[ruleid]['basic']['rulename'] + ' </span><i class="trash alternate icon" tabindex="0" data-html="' + deletemsg + '" id="' + ruleid + '" onclick="showDeleteAlertingPopup_Ruleset(this)"></i> </div></td></tr>';
	                	 
	                $('#rulelistbody').append(rulestring);
	                
	                
	            }
	 
	        }
	 
	    }
	    count++;
	    
	    keypress_alert();
	}

 
 function delete_rule_row(obj){
		
	 
	 var rowLen = $("#tbl_defineParameterRules tbody tr").length;
	 
	 //$('#deleteparamRuleId_0').addClass('disableAction');
	 //console.log(rowLen);
	 
	// console.log($(obj).closest('tr').is(':first-child'));
	 
	    if ((rowLen <= 1)) {
	        notifyMessage("Delete Filter","Please provide at least one filtering criterion","failure");
	    }
	    else if($(obj).closest('tr').is(':first-child')){
	    	//console.log('if');
	    	
	        $(obj).closest('tr').next().remove();
	        $(obj).closest('tr').remove();
	    }  
	    else {
	    	//console.log('else');
	        $(obj).closest('tr').prev().remove();
	        $(obj).closest('tr').remove();
	    }
		
	}

 function delete_rule_ruleset(value) {
	 
	    var ruleId_todelete = value.id;
	 
	    
	    var rulesetbody = $("#rulelist_tbl tbody");

	    //console.log(ruleId_todelete);
	    
	    //console.log(rulearray_Obj[ruleId_todelete]);
	    
	    //console.log(rulearray_Obj[ruleId_todelete]['basic']);
	    
	    if (rulearray_Obj[ruleId_todelete]['basic']['paramRuleId']) {
	 
	        
	    	//ruleObj['actionForRuleSet'] = rulearray_Obj[rule]['basic']['action'];
	    	
	    	rulearray_Obj[ruleId_todelete]['basic']['action'] = "delete";
	    	
	        //console.log(rulearray_Obj);
	        
	        load_rule_list(); 
	        //createRow_new();
	        updateMsgFlag = false;
	        notifyMessage("Delete rule","Rule set has been deleted successfully","success");
	        
	    } else {
	    	//console.log(rulearray_Obj);
	        delete rulearray_Obj[ruleId_todelete];
	        
	        load_rule_list(); 
	        
	       
	    }
	    
	    
	    $('#tbl_defineParameterRules tbody').empty();
	    $('#alertRuleName').val('');
	    $('#alertScheduler').dropdown('clear');
	    createRow_new();
	 
	}

//function delete_rule_row_recreate(rulestep_index,logical_index){
//	
//	$('table#tbl_defineParameterRules tr#'+logical_index).remove();
//	 $('table#tbl_defineParameterRules tr#'+rulestep_index).remove();
//	
//	
//}


 function recreate_rule_step(ruleId){

	//console.log('recreate');
		
	$('#tbl_defineParameterRules tbody').empty();

	//console.log(element.id);

	//var rulename = 'rule1';


	count = 0;

	var ruleArray = rulearray_Obj[ruleId]['rulesteps'];


		$('#alertRuleName').val(rulearray_Obj[ruleId]['basic']['rulename']);
		$('#alertScheduler').dropdown('set selected',rulearray_Obj[ruleId]['basic']['scheduler']);
		
		
	var logicalrow_index = 0;



	for(k= 0; k< ruleArray.length;k++){

	   
		//$('#alertScheduler').dropdown('set selected',ruleArray[k]['scheduler']);
		
		
		
		
		var deletemsg = "";
	    deletemsg = "<p id='alertDelMsg' class='delPopUp'>Are you sure you want to delete the parameter rule ?</p><button class='right floated ui cancel themeSecondary mini button' tabindex='0' onclick='closeAlertDeletepopUp(this)'>No</button><button class='right floated ui primary mini button' tabindex='0' onclick='delete_rule_row(this)'>Yes</button> ";
		
	    var new_row = "";
	    	
	    if( ruleArray[k]['ParamdisplayName'] == "State"){
			
	    	new_row = '<tr id="'+count+'"><td class="listofparameters"><select class="ui dropdown"   id="showListofParameters_'+count+'" onchange="showOperatorsOnParamSelection(this);"><option id="'+ruleArray[k]['paramRuleValue']+'" >'+ruleArray[k]['ParamdisplayName']+'</option></select></td><td><select class="ui dropdown"   id="showListofOperators_'+count+'"  ><option value="'+ruleArray[k]['paramRuleOperatorValue']+'"> '+ruleArray[k]['paramRuleOperatorValue']+'</option></select></td><td class="entervaluetd" style="display:none;"><div class="ui input icon"><input type="text" value="'+ruleArray[k]['paramRuleParam1Value']+'"  id="enterValue_'+count+'" ><span data-tooltip="Use /, as a delimeter to seperate multiple strings" data-position="bottom right"><i class="info circle icon link" ></i></span></div></td><td class="statedrop"><select class="ui dropdown"   id="showListofStates_'+count+'"><option id="'+ruleArray[k]['paramRuleParam1Value']+'">'+ruleArray[k]['paramRuleParam1Value']+'</option> </select></td><td> <i class="trash alternate icon" tabindex="0"  id="deleteparamRuleId_'+count+'" data-html="'+deletemsg+'"  onclick="showDeleteAlertingPopup('+count+')"></i></td></tr>';
			
		}else{
			
			new_row = '<tr id="'+count+'"><td class="listofparameters"><select class="ui dropdown"   id="showListofParameters_'+count+'" onchange="showOperatorsOnParamSelection(this);"><option id="'+ruleArray[k]['paramRuleValue']+'" >'+ruleArray[k]['ParamdisplayName']+'</option></select></td><td><select class="ui dropdown"   id="showListofOperators_'+count+'"  ><option value="'+ruleArray[k]['paramRuleOperatorValue']+'"> '+ruleArray[k]['paramRuleOperatorValue']+'</option></select></td><td class="entervaluetd"><div class="ui input icon"><input type="text" value="'+ruleArray[k]['paramRuleParam1Value']+'"  id="enterValue_'+count+'" ><span data-tooltip="Use /, as a delimeter to seperate multiple strings" data-position="bottom right"><i class="info circle icon link" ></i></span></div></td><td class="statedrop" style="display:none;"><select class="ui dropdown" id="showListofStates_'+count+'"><option id="'+ruleArray[k]['paramRuleParam1Value']+'">'+ruleArray[k]['paramRuleParam1Value']+' </option>  </select></td><td> <i class="trash alternate icon" tabindex="0"  id="deleteparamRuleId_'+count+'" data-html="'+deletemsg+'"  onclick="showDeleteAlertingPopup('+count+')"></i></td></tr>';
			
		}
	  // var new_row = '<tr id="'+count+'"><td><select class="ui dropdown"   id="showListofParameters_'+count+'" onchange="showOperatorsOnParamSelection(this);"><option id="'+ruleArray[k]['paramRuleValue']+'" >'+ruleArray[k]['ParamdisplayName']+'</option></select></td><td><select class="ui dropdown"   id="showListofOperators_'+count+'" ><option value="'+ruleArray[k]['paramRuleOperatorValue']+'"> '+ruleArray[k]['paramRuleOperatorValue']+'</option></select></td><td class="entervaluetd"><div class="ui input icon"><input type="text" value="'+ruleArray[k]['paramRuleParam1Value']+'"  id="enterValue_'+count+'" ><span data-tooltip="Use /, as a delimeter to seperate multiple strings" data-position="bottom right"><i class="info circle icon link" ></i></span></div></td><td> <i class="trash alternate icon" tabindex="0"  id="deleteparamRuleId_'+count+'" data-html="'+deletemsg+'"  onclick="showDeleteAlertingPopup(this)"></i></td></tr>';
	   
	   
	$('#tbl_defineParameterRules tbody').append(new_row);

	//$('#showListofParameters_'+count).append('<option value="Select Parameter" id="Select Parameter">Select</option>');
	$('#showListofParameters_'+count).append('<option value="Select Parameter" id="Select Parameter">Select</option>');
	$('#showListofParameters_'+count).append('<option class="header" disabled>Metadata</option>');
	$('#showListofParameters_'+count).append(append_listofParameters);
	$('#showListofParameters_'+count).append('<option class="header" disabled style="color:red;">Asset Workflow</option>');
	$('#showListofParameters_'+count).append('<option class="state" id="0_0_workflow_0" value="0">State</option>');
	$('#showListofStates_'+count).append(append_states);
	
	//console.log(ruleArray[k]['paramRuleValue']);
	
	
	
	var editparam= ruleArray[k]['paramRuleValue'];
	var editoperator = editparam.toString().split('_');
	var trimeditoperator=editoperator[2];
	
	//append operator value on edit;
	
	switch (trimeditoperator) {
    case 'list': {
        $('#showListofOperators_'+count).append('<option value="=">=</option><option value="!=">!=</option>');
        break;
    }
    case 'date': {
        $('#showListofOperators_'+count).append('<option value="=">=</option><option value="!=">!=</option><option value="<"><</option><option value=">">></option><option value="<="><=</option><option value=">=">>=</option>');
		
		$("#enterValue_"+count).datepicker({
			 dateFormat: 'dd/mm/yy' 
			});
		$('#enterValue_'+count).parent('.ui.icon').append( '<i class="calendar icon"></i>' );
		$('#enterValue_'+count).css('padding-left','25px');
		$('#enterValue_'+count).next().hide();
        break;
    }
	case 'text': {
        $('#showListofOperators_'+count).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option>');
        break;
    }
	
	case 'rich text': {
        $('#showListofOperators_'+count).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
        break;
    }
    
	case 'ldapmapping': {
        $('#showListofOperators_'+count).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
        break;
    }
	
	case 'derived asset list': {
        $('#showListofOperators_'+count).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
        break;
    }
	
	case 'derived computation': {
        $('#showListofOperators_'+count).append('<option value="=">=</option><option value="!=">!=</option>');
        break;
    }
	
	case 'workflow': {
        $('#showListofOperators_'+count).append('<option value="=">=</option><option value="!=">!=</option>');
        break;
    }
	
	case 'derived attribute': {
        $('#showListofOperators_'+count).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
        break;
    }
	
	}
	
	$('.ui.dropdown').dropdown();

	count++;


					if(ruleArray[k]['paramRulelogicalOperators']){

							var logical_row = '<tr id="'+count+'"><td><select class="ui dropdown"  id="paramRulelogicalOperators_'+count+'" ><option value="'+ruleArray[k]['paramRulelogicalOperators']+'">'+ruleArray[k]['paramRulelogicalOperators']+'</option><option value="Or">Or</option><option value="And">And</option></select></td></tr>';
	            
	            
	      $('#tbl_defineParameterRules tbody').append(logical_row);  
	      
	      logicalrow_index = count;
	      
	      
	    
	      
	      count++;
	      
	            
					}
					
		           //console.log(listofParamArray);
					
			    	var ParamNameFlag = false;
			    	
			        var paramNameGetval = ruleArray[k]['ParamdisplayName'];
			        
			    				    
			    	//console.log(paramNameGetval);
			    				    	
			        for(i=0;i<=listofParamArray.length ; i++){
			    				    	
			    		   if (listofParamArray[i] == paramNameGetval){
			    			
			    			  ParamNameFlag = true;
			    			   
			    			 break;
			    			
			    			}else{		    			
			    				ParamNameFlag = false ;
			    				
			    			 }
			    		   
			    	}
			        
			        if(!ParamNameFlag){
				    	   //console.log(paramNameGetval);
				    	   //console.log('disable');
				    	   disableRow(paramNameGetval); 
				    	   
			        }
			       
			        
					    
					
	}


	//$('#showListofParameters_'+count).append('<option value="Select Parameter" id="Select Parameter">Select</option>');
	//$('#showListofParameters_'+count).append(append_listofParameters);
	//$('#showListofParameters_'+count).append('<option class="state" id="0_0_workflow_0" value="0">State</option>');
	

	count++;

	//selected ruleset
	$(".rulese-view").removeClass("selected-ruleset");
	$('#'+ruleId).parent('div').addClass("selected-ruleset"); 

	//console.log(rulearray_Obj);

	editRuleId = ruleId;
	$('#updateRuleSetBtn').show(); 
	$('#addRuleSetBtn').hide();
	
	
    //$('#addRuleSetBtn').hide();

	keypress_alert();

	}

 function disableRow(elementName) {
	 
	    var rulesteprows = $('#tableBody').children();
	 
	    
	    for (j = 0; j < rulesteprows.length; j += 2) {
	 
	    	var trimParameter = $('#showListofParameters_'+rulesteprows[j].id).dropdown('get text');
	    	
	    	//console.log(trimParameter);
	    	
	        if (elementName == trimParameter[0] ) {
	            //console.log('test');
	       	
	        	$('#tableBody tr#'+j).addClass('disableAction');
	        	
	        }
	        if( elementName == "State" ){
	        	$('#tableBody tr#'+j).removeClass('disableAction');
	        }
	        
	    }
	 
	}
 
// save ruleset 
var assetId ="";
function save_rule_new(){


	var rqbody = [];
	 
	    for (const rule in rulearray_Obj) {
	        if (rulearray_Obj.hasOwnProperty(rule)) {
	            var ruleObj = {};
	            ruleObj['paramRuleName'] = rulearray_Obj[rule]['basic']['rulename'];
	            //ruleObj['assetName'] = assetName;
	            ruleObj['assetId'] = assetId;
	            ruleObj['userName'] = loggedInUserName;
	            ruleObj['aivId'] = assetInstanceVersionId;
	            
	            
	            if (rulearray_Obj[rule]['basic']) {
	            	if(rulearray_Obj[rule]['basic']['paramRuleId']){
	            		ruleObj['paramRuleId'] = rulearray_Obj[rule]['basic']['paramRuleId'];
	            	}
	                ruleObj['scheduler'] = rulearray_Obj[rule]['basic']['scheduler'];
	                ruleObj['actionForRuleSet'] = rulearray_Obj[rule]['basic']['action'];
	                
	            }
	            
	            for (var i = 0; i < rulearray_Obj[rule]['rulesteps'].length; i++) {
	 
	                if (i == 0) {
	                    ruleObj['paramRuleValue'] = rulearray_Obj[rule]['rulesteps'][i]['paramRuleValue'];
	                    //ruleObj['scheduler'] = rulearray_Obj[rule][i]['scheduler'];
	                    ruleObj['paramRuleOperatorValue'] = rulearray_Obj[rule]['rulesteps'][i]['paramRuleOperatorValue'];
	                    ruleObj['paramRuleParam1Value'] = rulearray_Obj[rule]['rulesteps'][i]['paramRuleParam1Value'];
	                    ruleObj['paramRulelogicalOperators'] = rulearray_Obj[rule]['rulesteps'][i]['paramRulelogicalOperators'];
	                } else {
	                    ruleObj['paramRuleValue'] = ruleObj['paramRuleValue'] + "~~" + rulearray_Obj[rule]['rulesteps'][i]['paramRuleValue'];
	                    //ruleObj['scheduler'] = rulearray_Obj[rule][i]['scheduler'];
	                    ruleObj['paramRuleOperatorValue'] = ruleObj['paramRuleOperatorValue'] + "~~" + rulearray_Obj[rule]['rulesteps'][i]['paramRuleOperatorValue'];
	                    ruleObj['paramRuleParam1Value'] = ruleObj['paramRuleParam1Value'] + "~~" + rulearray_Obj[rule]['rulesteps'][i]['paramRuleParam1Value'];
	                    if(rulearray_Obj[rule]['rulesteps'][i]['paramRulelogicalOperators'] ){
	                        ruleObj['paramRulelogicalOperators'] = ruleObj['paramRulelogicalOperators'] + "~~" + rulearray_Obj[rule]['rulesteps'][i]['paramRulelogicalOperators'];
	                    } 
	                }
	            }
	            rqbody.push(ruleObj);
	        }
	        
	    }
	 
	    //console.log(rqbody);
	    
	    save_Rule(rqbody);
	    


	}
function save_Rule(rulearray){
	 $.ajax({
	    	
	    	type: "POST",
	    	url: "/repopro/web/assetType/addAivParamRule",
	    	contentType : "application/json",
	    	//dataType : "json",
	    	data : JSON.stringify(rulearray),
	    	async: false,
	    	complete:function(data){
	    		var json = JSON.parse(data.responseText);
	    		if(json.status == "SUCCESS"){
	    			//notifyMessage("Alerting","Parameter rule is created successfully","success");
	    			$('#openAlertingModal').modal('hide'); 
	    			$('#openAlertingModal').parent().css("display", "none !important");
	    			if(updateMsgFlag == true){
	    			notifyMessage("Alerting","Rule sets are created successfully","success");
	    			}
	    			else{
	    			notifyMessage("Alerting","Rule sets are updated successfully","success");	
	    			}
	    		}
	    	else {
	    	    	if(updateMsgFlag == true){
	    			notifyMessage("Alerting","Error attempting to create rule sets","fail");
	    			return false;
	    			}
	    			else{
	    			notifyMessage("Alerting","Error attempting to update rule sets","fail");	
	    			return false;
	    			}
	    			/*notifyMessage("Alerting",json.message,"fail")
	    			return false;*/
	    		}
	    	}
	    });

}


//ruleset search

$("#search_ruleset").keyup(function() {
	

    var value = $(this).val().toLowerCase();
    
       //console.log(value.length);
    
    
       $("#rulelistbody tr").filter(function() {
    	   
         $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
         
         
       });
      
       //var x= $("#rulelistbody tr").length();
       //console.log(x);
       var len = $('#rulelistbody tr td:contains("'+value+'")').length;
       
       if( len <= 0 &&  value.length >0 ){
    	   $("#rulelist_tbl p").remove();
    	   $("#rulelistbody ").append("<p class='no-data'>No data found</p>");
       }else{
    	   $("#rulelist_tbl p").remove(); 
    	   //console.log('search');
       }
       

	    
  });



//alerting - chandana 26.02.2020


function checkActive(obj){
	 $('#openAlertingModal').modal({observeChanges : true}).modal('refresh');
	setTimeout(function(){
		if($(obj).hasClass('active')){
			$(obj).next().removeAttr('style');
		}
	}, 500);
}


function saveParameterRule(){
//alert('assetInstanceVersionId' + assetInstanceVersionId + "getParamRuleId : " + getParamRuleId +  "getParamRuleValue : " + getParamRuleValue  +  "getParamRuleOperatorValue : " + getParamRuleOperatorValue + "getParamRuleParam1Value : " + getParamRuleParam1Value + "loggedInUserName : " + loggedInUserName);

var getParamvalueFromSelectedOption = $("#showListofParameters option:selected").attr('id');
if(getParamvalueFromSelectedOption == null || getParamvalueFromSelectedOption == "" || getParamvalueFromSelectedOption == undefined || getParamvalueFromSelectedOption == "undefined"){
	
}
else{
	var splitIds = getParamvalueFromSelectedOption.split('_');
	var id1 = splitIds[0];
	var id2 = splitIds[1];
	var id3 = splitIds[2];
	var id4 = splitIds[3];
	} 

//$('#emailAlertSaveID').unbind();
var cstm = $("#ddFilterParamSelector option:selected").attr('id');
var alertParamSelector = $('#showListofParameters').val();
var alertParamOperator =  $('#showListofOperators').val();
var sendAlertInputData = $('#inputAlertTextField_0').val();
var scheduler = $('#alertScheduler').val();


//alert(alertParamSelector + alertParamOperator);
var flag = true;

//validation
if(alertParamSelector == "Select Parameter"){
	$('#showListofParameters').parent().addClass('error');
	//$('#errAlertParam').show();
	flag = false;
}else{
	$('#showListofParameters').parent().removeClass('error');
	$('#errAlertParam').hide();
}

if(alertParamOperator == 'Select Operator' || alertParamOperator == "" || alertParamOperator == "null" || alertParamOperator == null  ){
	$('#showListofOperators').parent().addClass('error');
	//$('#errAlertOperator').show();
	flag = false;
}else{
	$('#showListofOperators').parent().removeClass('error');
//	$('#errAlertOperator').hide();
}

if(sendAlertInputData == ''){
	$('#inputAlertTextField_0').parent().addClass('error');
//	$('#errAlertInputData').show();
	flag = false;
}else{
	$('#inputAlertTextField_0').parent().removeClass('error');
	//$('#errAlertInputData').hide();
}


if(scheduler == 'Select Repeat' || scheduler == ''){
	$('#alertScheduler').parent().addClass('error');
	$('#errAlertSchedular').show();
	flag = false;
}else{
	$('#alertScheduler').parent().removeClass('error');
	$('#errAlertSchedular').hide();
}

 if(flag == false){
		$('#openAlertingModal').modal('show');
		return false;
	}
 else {
	$('#openAlertingModal').modal('hide');  //.modal('hide dimmer');
	$('#openAlertingModal').parent().css("display", "none !important");
	 
	 if(firstAlertData != true){
		obj = {
				"paramRuleId":getParamRuleId,
				//"paramRuleValue":getParamvalueFromSelectedOption,
				"paramRuleValue":id1+'_'+id2+'_'+id3+'_'+id4,
				"paramRuleOperatorValue": alertParamOperator,
				"paramRuleParam1Value":sendAlertInputData,
				"assetName":assetName ,
				"userName":loggedInUserName ,
				"aivId" : assetInstanceVersionId,
				"scheduler" : scheduler 
		};
		var url = "http://localhost:7070/repopro/web/assetType/updateAivParamRule";
		
		$.ajax({
			type: "PUT",
			url: "/repopro/web/assetType/updateAivParamRule",
			contentType : "application/json",
			dataType : "json",
			data : JSON.stringify(obj),
			async: false,
			complete:function(data){
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage("Alerting","Parameter rule updated successfully","success");
									
				}
			else {
					notifyMessage("Alert",json.message,"fail")
					flag = false;
				}	

			}
		});
	 }
	 else{
		 obj = {
				 //"paramRuleValue":getParamvalueFromSelectedOption,
					"paramRuleValue":id1+'_'+id2+'_'+id3+'_'+id4,
					"paramRuleOperatorValue": alertParamOperator,
					"paramRuleParam1Value":sendAlertInputData,
					"assetName":assetName ,
					"userName":loggedInUserName ,
					"aivId" : assetInstanceVersionId,
					"scheduler" : scheduler 
			};
			
			$.ajax({
				type: "POST",
				url: "/repopro/web/assetType/addAivParamRule",
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				complete:function(data){
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						notifyMessage("Add alert","Alert Notification added","success");
										
					}
				else {
						notifyMessage("Alert",json.message,"fail")
						flag = false;
					}	

				}
			});
		 
	 }

 }
	if(flag == false){
    	$('#openAlertingModal').modal('show');
		return false;
     }
     else{
    	 $('#openAlertingModal').modal('hide'); //.modal('hide dimmer');
    	 $('#openAlertingModal').parent().css("display", "none !important");
     }
	$('.ui.dropdown').dropdown();
}



function saveParameterRule_New(){
	
	//vishnu 260320
	//select operator
	var operatorSelect =$('#showListofOperators').dropdown('get text');
    var newoperatorSelect = operatorSelect[0];
	

//select parameter
	var getparamRuleDrop = $('#showListofParameters').dropdown('get text');
	var getparamRuleDrop2 = getparamRuleDrop[0];
	

//select scheduler
	var repeatAlertSelect =$('#alertScheduler').dropdown('get text');
	var newrepeatAlertSelect = repeatAlertSelect[0];
	
// enter value
	var addParamtext = $('#enterValue').val();
	
	//validation
	
	
	if (getparamRuleDrop2 == "[Select Parameter]" ){
		$('#showListofParameters').parent().addClass('error');
		$(".errShowListparam").html("Please select parameter").show();
	}
	else{

		$('#showListofParameters').parent().removeClass('error');
	$(".errShowListparam").hide();
	}
	
	if(newoperatorSelect == "Select Operator"){
		$('#showListofOperators').parent().addClass('error');
		$(".errAlertShowOperator").html("Please select operator").show();
	}
	else{
		$('#showListofOperators').parent().removeClass('error');
		$(".errAlertShowOperator").hide();	
	}
	if(newrepeatAlertSelect == "Select Repeat"){
		$('#alertScheduler').parent().addClass('error');
		$(".errAlertScheduler").html("Please select scheduler").show();
	}
	else{
		$('#alertScheduler').parent().removeClass('error');
		$(".errAlertScheduler").hide();
	}
	
	if(addParamtext == ""){
		$("#enterValue").parent().addClass('error');
		$(".errAlertEnterText").html("Please enter value").show();
	}
	else{
		$("#enterValue").parent().removeClass('error');
		$(".errAlertEnterText").hide();
	}
	

if(getparamRuleDrop2 != "[Select Parameter]"  &&  newoperatorSelect != "Select Operator"  &&  newrepeatAlertSelect != "Select Repeat"  && addParamtext != "" ){
	
	//save alert
	
var getParamvalueFromSelectedOption = $("#showListofParameters option:selected").attr('id');
var $repeatAlerting = $('#alertScheduler').val();
var $operator = $('#showListofOperators').val();
var textValue = $('#enterValue').val();

var $obj = {
		"paramRuleValue":getParamvalueFromSelectedOption,
		"paramRuleOperatorValue":$operator,
		"paramRuleParam1Value":textValue,
		"assetName":assetName, 
		"userName":loggedInUserName,
		"aivId":assetInstanceVersionId,
		"scheduler":$repeatAlerting
		}
//console.log("save " + JSON.stringify($obj));

$.ajax({
	
	type: "POST",
	url: "/repopro/web/assetType/addAivParamRule",
	contentType : "application/json",
	dataType : "json",
	data : JSON.stringify($obj),
	async: false,
	complete:function(data){
		var json = JSON.parse(data.responseText);
		if(json.status == "SUCCESS"){
			//notifyMessage("Alerting","Parameter rule is created successfully","success");
			$('#openAlertingModal').modal('hide'); 
			$('#openAlertingModal').parent().css("display", "none !important");
			notifyMessage("Alerting","Parameter rule is created successfully","success");
		}
	else {
			notifyMessage("Alerting",json.message,"fail")
			return false;
		}
	}
});
	


	
}

	}


var definedParmRuleId ;
var add_update_paramRule_Flag = true;

function getRuleBasedIdforAlert_New(){
	
	definedParmRuleId="";
	
	$.ajax({
	type : "GET",
		url : "/repopro/web/assetType/getAivParamRuleSets?userName="+loggedInUserName+"&aivId="+assetInstanceVersionId,
		//url : "/repopro/web/assetType/getAivParamRule?userName=admin&aivId=64",
		
		dataType : "json",
		async : false,
		complete : function(data) {	
			
			var json = JSON.parse(data.responseText);
			
			var response = json.result;
			
			//console.log("get call : " + JSON.stringify(json));
			
			if (json.status == "SUCCESS") {
				if ( json.result == "" || json.result == null || json.result == [] ){
					
					updateMsgFlag = true;
					
					$('#updateParameterRule').hide();
					$('#saveParameterRule').show();
					
					$('.errAlertRuleset').hide();
					$('#alertScheduler').parent().removeClass('error');
					$('#alertRuleName').parent().removeClass('error');
					$('.errtooltip').hide();
					$('#alertScheduler').dropdown('clear');
					$('#alertRuleName').val('');
					add_update_paramRule_Flag = true;
					 
					
					 
					 //disable save
					$('#saveParameterRule').addClass('disabled');
					 var rulesetbody = $("#rulelist_tbl tbody");

					 if (rulesetbody.children().length == 0) {
					    $('#saveParameterRule').addClass('disabled');
					 }else{
						 $('#saveParameterRule').removeClass('disabled');
					 }
				}
				else{
					$('#alertScheduler').parent().removeClass('error');
					definedParmRuleId = json.result[0].paramRuleId;
					//$('#updateParameterRule').show();
					$('#saveParameterRule').show();
					$('#enterValue').blur();
					$('.errAlertRuleset').hide();
					$('.errAlertRulename').hide();
					$('.errAlertScheduler').hide();
					$('#alertScheduler').dropdown('clear');
					$('#alertRuleName').val('');
					$('#alertRuleName').parent().removeClass('error');
					
					
					rulearray_Obj = {};
					
					$('#rulelist_tbl tbody').empty();
					 
					count=0;
					
				    updateMsgFlag = false;
					
					    for (i = 0; i < response.length; i++) {
					    	
					    	var localruleid = 'rule_' + ruleindex;
					        ruleindex++;
					        
					        rulearray_Obj[localruleid] = {}

					        rulearray_Obj[localruleid]['basic'] = {};
					        rulearray_Obj[localruleid]['rulesteps'] = [];
					        
					        rulearray_Obj[localruleid]['basic']['paramRuleId'] = response[i].paramRuleId;
					        rulearray_Obj[localruleid]['basic']['rulename'] = response[i].paramRuleName;
					        rulearray_Obj[localruleid]['basic']['action'] ="noChange";
					    	
					    	//rulearray_Obj[response[i].paramRuleName] = {}

					        //rulearray_Obj[response[i].paramRuleName]['basic'] = {};
					       // rulearray_Obj[response[i].paramRuleName]['rulesteps'] = [];

					        //rulearray_Obj[response[i].paramRuleName]['basic']['paramRuleId'] = response[i].paramRuleId;
					        //rulearray_Obj[response[i].paramRuleName]['basic']['action'] ="noChange";
					        
//					        var nameid=response[i].paramRuleName;
//					        console.log(nameid);
					        
					        var deletemsg = "";
						    deletemsg = "<p id='alertDelMsg' class='delPopUp'>Are you sure you want to delete the parameter rule set?</p><button class='right floated ui cancel themeSecondary mini button'  onclick='closeAlertDeletepopUp(this)'>No</button><button class='right floated ui primary mini button' id='"+localruleid+"' onclick='delete_rule_ruleset(this)'>Yes</button> "; 
							
					    	
					        var rulestring = '<tr><td><div class="rulese-view"><span tabindex="0" id='+localruleid+'  onclick="trigger_recreate(this)"> ' + response[i].paramRuleName+' </span><i tabindex="0" class="trash alternate icon" data-html="'+deletemsg+'" id="deleteparamRuleId_'+count+'" onclick="showDeleteAlertingPopup_Ruleset(this)"></i></div></td></tr>';
					        $('#rulelistbody').append(rulestring);
					        count++
					        
					               
					        
					    }
					
					    
					    
					   // var noData = "";
					    
					    //noData += '<tr class="notfound"><td>No data found</td></tr>'
					    
					   // $('#rulelistbody').append(noData);
					    
					   // console.log(rulearray_Obj);
					    
					   // trigger_recreate(response[0].paramRuleName);
//					 if(response.length > 0){
//					 loaddefault_rule(response[0]);
//					 
//					 }   

					
				}
			}
			else {
				//alert ('get method failed');
		}
		}
	
	});
	keypress_alert();
}
// enhancement 15052020


//var paramRuleName = "";

function trigger_recreate(value) {

    //console.log(rulename);
	
    //console.log(value);
	
    var ruleId =value.id;
    
    //var rulename = value.id;
    
    //console.log(ruleId);
    //rulename = value;
    
   

    //console.log(rulearray_Obj);
    //console.log(rulearray_Obj[ruleId]['basic']['paramRuleId']);
    //console.log(rulearray_Obj[ruleId]['rulesteps'].length);
    
    if (rulearray_Obj[ruleId]['basic']['paramRuleId'] && rulearray_Obj[ruleId]['rulesteps'].length < 1) {

    	//console.log("test");
    	var rulenameTofetch = rulearray_Obj[ruleId]['basic']['rulename'];
    	
    	//console.log("test");
    //  console.log(ruleId);
        $.ajax({
        	type : "GET",
        	url : "/repopro/web/assetType/getAivParamRuleByRuleName?userName="+loggedInUserName+"&aivId="+assetInstanceVersionId+"&ruleName="+rulenameTofetch,
        		//url : "/repopro/web/assetType/getAivParamRule?userName=admin&aivId=64",
        		
        		dataType : "json",
        		async : false,
        		complete : function(data) {	
        			
        			var json = JSON.parse(data.responseText);
        			
        			//console.log("get call : " + JSON.stringify(json));
        			//var response = json.result;
        			
        			if (json.status == "SUCCESS") {
        				
        			if ( json.result != "" || json.result != null || json.result != [] ){
        				
        				var response = json.result[0];
        				//console.log(response);
        				
        				 var rulesteps = response.paramRuleValue.split("~~");

        		            rulearray_Obj[ruleId]['basic']['scheduler'] = response.scheduler;

        		            for (i = 0; i < rulesteps.length; i++) {

        		                var rulestepObj = {};

        		                rulestepObj['paramRuleValue'] = response.paramRuleValue.split("~~")[i];
        		                rulestepObj['paramRuleOperatorValue'] = response.paramRuleOperatorValue.split("~~")[i];
        		                rulestepObj['paramRuleParam1Value'] = response.paramRuleParam1Value.split("~~")[i];
        		                rulestepObj['ParamdisplayName'] = response.paramName.split("~~")[i];

        		                if (rulesteps.length > 1 && rulesteps.length - 1 !== i) {

        		                    rulestepObj['paramRulelogicalOperators'] = response.paramRulelogicalOperators.split("~~")[i];
        		                }
        		                
        		             
        		                rulearray_Obj[ruleId]['rulesteps'].push(rulestepObj);
        		                
        		            }
        		            
        		            
    		                
        		            
        		            recreate_rule_step(ruleId);
        				
        			}else{
        				
        				
        			}
        			}
        			else{
        				//alert ('get method failed');
        			}
        		}
        });




    } else {
        // local saved item
    	recreate_rule_step(ruleId);
    }

   
	
}






//show operator onload
function showOperatorsOnParamSelection(obj){
	var res = $(obj).closest('tr').attr('id');
	//res = data.split('_')[1];
	assetParamName = $(obj).children(':selected').text();
	assetParamId = $(obj).children(':selected').val();
	paramListTypeName = $(obj).children(':selected').attr('data-typeName');
	paramTypeName = $(obj).children(':selected').attr('class');
	mapId = $(obj).children(':selected').attr('data-mapid');

	/*alert("assetParamName : " + assetParamName + " assetParamId : " + assetParamId + " paramListTypeName : " + paramListTypeName + " paramTypeName : " + paramTypeName + " mapId : " + mapId);*/
	
//	alert("paramTypeName : " + paramTypeName);
	
	$('#showListofOperators_'+res).empty();
	$('#showListofOperators_'+res).dropdown('clear');
	//$('#alertScheduler').dropdown('clear');
	
	
	//$('#showListofOperators_'+res).html('');
	
		
		if(assetParamName == "Select"){
		$('#showListofOperators_'+res).empty();
		$('#enterValue_'+res).closest('.entervaluetd').show();
		$('#showListofStates_'+res).closest('.statedrop').hide();
		
		$('#showListofOperators_'+res).dropdown('clear');
		$('#enterValue_'+res).parent('div.ui').addClass('disableAction');
		$('#showListofOperators_'+res).parent('div.dropdown').addClass('disableAction');
		//$('#deleteparamRuleId_'+res).addClass('disableAction');
		//$('.entervaluetd').append('<span data-tooltip="Use /, as a delimeter to seperate multiple strings" data-position="top right"></span>');
		//$('.entervaluetd span').append('<i class="info circle icon link" style="top: 0px !important;" ></i>');
		$('#enterValue_'+res).prop("placeholder", "Enter value");
		$('#enterValue_'+res).val("");
		$('#enterValue_'+res).css('padding-left','12px');
		$("#enterValue_"+res).siblings('.calendar').remove();
		
	}
	
		else if (paramTypeName == "list") {

			//if(paramListTypeName == "ldapuserlist"){
				
				//$('#inputAlertField_'+res).addClass('ldapText');
			$('#showListofOperators_'+res).closest('div').removeClass('disabled');
			$('#enterValue_'+res).closest('.entervaluetd').show();
			$('#showListofStates_'+res).closest('.statedrop').hide();
			//$(".entervaluetd .ui.icon.input i.calendar").remove();
			$('#enterValue_'+res).attr('disabled',false);
			$('#enterValue_'+res).attr('readonly',false);
			$('#enterValue_'+res).val("");
			$('#enterValue_'+res).prop("placeholder", "Enter value");
			$("#enterValue_"+res). datepicker("destroy");
			$('#enterValue_'+res).css('padding-left','12px');
			$("#enterValue_"+res).siblings('.calendar').remove();
			$('#enterValue_'+res).parent('div.ui').removeClass('disableAction');
			$('#showListofOperators_'+res).parent('div.dropdown').removeClass('disableAction');
			//$('#deleteparamRuleId_'+res).removeClass('disableAction');

				$('#showListofOperators_'+res).append('<option value="=">=</option><option value="!=">!=</option>');
				setTimeout(function(){
					$('#showListofOperators_'+res).dropdown('set selected',"=");
				}, 300);
			//}
			/*else{
				//$('#dropdownInput_'+res).css('display','block');
				//$('#dropdownInput_'+res).addClass('dropDownList');
				//$('#ddListParamValue_'+res).dropdown('clear');
				$('#showListofOperators').append('<option value="=">=</option><option value="!=">!=</option>');
				setTimeout(function(){
					$('showListofOperators').dropdown('set selected',"=");
				}, 300);


			}*/



		}else if (paramTypeName == "text") {

			/*$('#inputAlertField_'+res).css('display','block');
			$('#inputAlertField_'+res).addClass("textBoxValue");*/

			$('#showListofOperators_'+res).closest('div').removeClass('disabled');
			$('#enterValue_'+res).closest('.entervaluetd').show();
			$('#showListofStates_'+res).closest('.statedrop').hide();
			//$(".entervaluetd .ui.icon.input i.calendar").remove();
			$('#enterValue_'+res).attr('disabled',false);
			$('#enterValue_'+res).attr('readonly',false);
			$('#enterValue_'+res).val("");
			$('#enterValue_'+res).prop("placeholder", "Enter value");
			$("#enterValue_"+res). datepicker("destroy");
			$('#enterValue_'+res).css('padding-left','12px');
			$('#enterValue_'+res).parent('div.ui').removeClass('disableAction');
			$('#showListofOperators_'+res).parent('div.dropdown').removeClass('disableAction');
			//$('#deleteparamRuleId_'+res).removeClass('disableAction');

			$("#enterValue_"+res).siblings('.calendar').remove();
			$('#showListofOperators_'+res).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option>');
			setTimeout(function(){
				$('#showListofOperators_'+res).dropdown('set selected',"=");
			}, 300);

		}
	   else if (paramTypeName == "date") {

			/*$('#inputAlertField_'+res).css('display','block');
			$('#inputAlertField_'+res).addClass("dateBoxValue");*/
		   $('#enterValue_'+res).closest('.entervaluetd').show();
			$('#showListofStates_'+res).closest('.statedrop').hide();
		   $('#showListofOperators_'+res).closest('div').removeClass('disabled');
			$('#enterValue_'+res).attr('disabled',false);
			$('#enterValue_'+res).val("");
			//$('i.calendar.icon').show();
			$('#enterValue_'+res).parent('.ui.icon').append( '<i class="calendar icon"></i>' );
			$('#enterValue_'+res).css('padding-left','25px');
			//$('#enterValue').prop("type", "date")
			$('#enterValue_'+res).prop("placeholder", "dd/mm/yyyy");
			$('#enterValue_'+res).next().hide();
			$('#enterValue_'+res).attr('readonly',true);
			$('#enterValue_'+res).parent('div.ui').removeClass('disableAction');
			$('#showListofOperators_'+res).parent('div.dropdown').removeClass('disableAction');
			//$('#deleteparamRuleId_'+res).removeClass('disableAction');

			$("#enterValue_"+res).datepicker({
				 dateFormat: 'dd/mm/yy' 
				});
			//$("#alertScheduler").dropdown('clear');
			$('#showListofOperators_'+res).append('<option value="=">=</option><option value="!=">!=</option><option value="<"><</option><option value=">">></option><option value="<="><=</option><option value=">=">>=</option>');
			setTimeout(function(){
				$('#showListofOperators_'+res).dropdown('set selected',"=");
			}, 300);


		}
		else if (paramTypeName == "rich text" || paramTypeName == "richtext") {
			/*$('#inputAlertField_'+res).css('display','block');
			$('#inputAlertField_'+res).addClass("richTextValue");*/
			$('#showListofOperators_'+res).closest('div').removeClass('disabled');
			//$(".entervaluetd .ui.icon.input i.calendar").remove();
			$('#enterValue_'+res).closest('.entervaluetd').show();
			$('#showListofStates_'+res).closest('.statedrop').hide();
			$('#enterValue_'+res).attr('disabled',false);
			$('#enterValue_'+res).attr('readonly',false);
			$('#enterValue_'+res).val("");
			$('#enterValue_'+res).prop("placeholder", "Enter value");
			$("#enterValue_"+res). datepicker("destroy");
			$('#enterValue_'+res).css('padding-left','12px');
			$("#enterValue_"+res).siblings('.calendar').remove();
			$('#enterValue_'+res).parent('div.ui').removeClass('disableAction');
			$('#showListofOperators_'+res).parent('div.dropdown').removeClass('disableAction');
			//$('#deleteparamRuleId_'+res).removeClass('disableAction');

			$('#showListofOperators_'+res).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#showListofOperators_'+res).dropdown('set selected',"like");
			}, 300);
		}

	   else if(paramTypeName == "ldapmapping") {
			/*$('#inputAlertField_'+res).css('display','block');
			$('#inputAlertField_'+res).addClass("ldapMappingText");*/

		   $('#showListofOperators_'+res).closest('div').removeClass('disabled');
		    //$(".entervaluetd .ui.icon.input i.calendar").remove();
		   $('#enterValue_'+res).closest('.entervaluetd').show();
			$('#showListofStates_'+res).closest('.statedrop').hide();
			$('#enterValue_'+res).attr('disabled',false);
			$('#enterValue_'+res).attr('readonly',false);
			$('#enterValue_'+res).val("");
			$('#enterValue_'+res).prop("placeholder", "Enter value");
			$("#enterValue_"+res). datepicker("destroy");
			$("#enterValue_"+res).siblings('.calendar').remove();
			$('#enterValue_'+res).css('padding-left','12px');
			$('#enterValue_'+res).parent('div.ui').removeClass('disableAction');
			$('#showListofOperators_'+res).parent('div.dropdown').removeClass('disableAction');
			//$('#deleteparamRuleId_'+res).removeClass('disableAction');

		   $('#showListofOperators_'+res).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#showListofOperators_'+res).dropdown('set selected',"like");
			}, 300);
		}
		else if(paramTypeName == "derived asset list") {
			//$('#inputAlertField_'+res).css('display','block');
			$('#showListofOperators_'+res).closest('div').removeClass('disabled');
			//$(".entervaluetd .ui.icon.input i.calendar").remove();
			$('#enterValue_'+res).closest('.entervaluetd').show();
			$('#showListofStates_'+res).closest('.statedrop').hide();
			$('#enterValue_'+res).attr('disabled',false);
			$('#enterValue_'+res).attr('readonly',false);
			$('#enterValue_'+res).val("");
			$('#enterValue_'+res).prop("placeholder", "Enter value");
			$("#enterValue_"+res). datepicker("destroy");
			$('#enterValue_'+res).css('padding-left','12px');
			$("#enterValue_"+res).siblings('.calendar').remove();
			$('#enterValue_'+res).parent('div.ui').removeClass('disableAction');
			$('#showListofOperators_'+res).parent('div.dropdown').removeClass('disableAction');
			//$('#deleteparamRuleId_'+res).removeClass('disableAction');

			$('#showListofOperators_'+res).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#showListofOperators_'+res).dropdown('set selected',"like");
			}, 300);
		}

		else if(paramTypeName == "derived attribute") {
			//$('#inputAlertField_'+res).css('display','block');
			$('#showListofOperators_'+res).closest('div').removeClass('disabled');
			//$(".entervaluetd .ui.icon.input i.calendar").remove();
			$('#enterValue_'+res).closest('.entervaluetd').show();
			$('#showListofStates_'+res).closest('.statedrop').hide();
			$('#enterValue_'+res).attr('disabled',false);
			$('#enterValue_'+res).attr('readonly',false);
			$('#enterValue_'+res).val("");
			$('#enterValue_'+res).prop("placeholder", "Enter value");
			$("#enterValue_"+res).datepicker("disable");
			$("#enterValue_"+res).attr("disabled",false);
			$('#enterValue_'+res).css('padding-left','12px');
			$("#enterValue_"+res).siblings('.calendar').remove();
			$('#enterValue_'+res).parent('div.ui').removeClass('disableAction');
			$('#showListofOperators_'+res).parent('div.dropdown').removeClass('disableAction');
			//$('#deleteparamRuleId_'+res).removeClass('disableAction');

			$('#showListofOperators_'+res).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#showListofOperators_'+res).dropdown('set selected',"like");
			}, 300);
		}

		else if(paramTypeName == "derived computation") {
			//$('#inputAlertField_'+res).css('display','block');
			$('#showListofOperators_'+res).closest('div').removeClass('disabled');
			//$(".entervaluetd .ui.icon.input i.calendar").remove();
			$('#enterValue_'+res).closest('.entervaluetd').show();
			$('#showListofStates_'+res).closest('.statedrop').hide();
			$('#enterValue_'+res).attr('disabled',false);
			$('#enterValue_'+res).attr('readonly',false);
			$('#enterValue_'+res).val("");
			$('#enterValue_'+res).prop("placeholder", "Enter value");
			$("#enterValue_"+res).datepicker("disable");
			$("#enterValue_"+res).attr("disabled",false);
			$('#enterValue_'+res).css('padding-left','12px');
			$("#enterValue_"+res).siblings('.calendar').remove();
			$('#enterValue_'+res).parent('div.ui').removeClass('disableAction');
			$('#showListofOperators_'+res).parent('div.dropdown').removeClass('disableAction');
			//$('#deleteparamRuleId_'+res).removeClass('disableAction');

			$('#showListofOperators_'+res).append('<option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#showListofOperators_'+res).dropdown('set selected',"=");
			}, 300);

		}
		
		else if(assetParamName == "State") {
			//$('#inputAlertField_'+res).css('display','block');
			$('#showListofOperators_'+res).closest('div').removeClass('disabled');
			//$(".entervaluetd .ui.icon.input i.calendar").remove();
			//$('#enterValue_'+res).parent('.entervaluetd').hide();
			$('#enterValue_'+res).closest('.entervaluetd').hide();
			$('#showListofStates_'+res).closest('.statedrop').show()
			$('#enterValue_'+res).attr('disabled',false);
			$('#enterValue_'+res).attr('readonly',false);
			$('#enterValue_'+res).val("");
			$('#enterValue_'+res).prop("placeholder", "Enter value");
			$("#enterValue_"+res).datepicker("disable");
			$("#enterValue_"+res).attr("disabled",false);
			$('#enterValue_'+res).css('padding-left','12px');
			$("#enterValue_"+res).siblings('.calendar').remove();
			$('#enterValue_'+res).parent('div.ui').removeClass('disableAction');
			$('#showListofOperators_'+res).parent('div.dropdown').removeClass('disableAction');
			//$('#deleteparamRuleId_'+res).removeClass('disableAction');

			$('#showListofOperators_'+res).append('<option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#showListofOperators_'+res).dropdown('set selected',"=");
			}, 300);

		}

}

// update Alert vishnu-17032020
function updateAlert_New(){
	
	var getparamRuleDrop = $('#showListofParameters').dropdown('get text');
	var getparamRuleval = getparamRuleDrop[0];
	//var getparamRuleDrop2 = getparamRuleDrop.join('').substring(0,4);
	var getParamvalueFromSelectedOption = $("#showListofParameters option:selected").attr('id');
	
	var operatorSelect =$('#showListofOperators').dropdown('get text');
	var newoperatorSelect = operatorSelect[0];
	var $operator = newoperatorSelect;
	
	var repeatAlertSelect =$('#alertScheduler').dropdown('get text');
	var newrepeatAlertSelect = repeatAlertSelect[0];
	var $repeatAlerting = newrepeatAlertSelect;

	var textValue = $('#enterValue').val();
	//alert(definedParmRuleId);
	if( getparamRuleval == "[Select Parameter]" ){
		$('#showListofParameters').parent().addClass('error');
		$(".errShowListparam").html("Please select parameter").show();
	}
	else{
		$('#showListofParameters').parent().removeClass('error');
		$(".errShowListparam").hide();
	}
	if( newoperatorSelect ==  "Select Operator" ){
		$('#showListofOperators').parent().addClass('error');
		$(".errAlertShowOperator").html("Please select operator").show();
	}
	else{
		$('#showListofOperators').parent().removeClass('error');
		$(".errAlertShowOperator").hide();
	}
	if( textValue == "" ){
		$("#enterValue").parent().addClass('error');
		$(".errAlertEnterText").html("Please enter value").show();
	}
	else{
		$("#enterValue").parent().removeClass('error');
		$(".errAlertEnterText").hide();
	}
	if( newrepeatAlertSelect == "Select Repeat" ){
		$('#alertScheduler').parent().addClass('error');
		$(".errAlertScheduler").html("Please select scheduler").show();
	}
	else{

		$('#alertScheduler').parent().removeClass('error');
		$(".errAlertScheduler").hide();	
	}
	
	 if( getparamRuleval != "[Select Parameter]"  &&  newoperatorSelect != "Select Operator"  && newrepeatAlertSelect != "Select Repeat"  && textValue != ""  ){
			
		
	//update
		var $obj = {
				"paramRuleId":definedParmRuleId,
				"paramRuleValue":getParamvalueFromSelectedOption,
				"paramRuleOperatorValue":$operator,
				"paramRuleParam1Value":textValue,
				"assetName":assetName, 
				"userName":loggedInUserName,
				"aivId":assetInstanceVersionId,
				"scheduler":$repeatAlerting
				}
//		alert("paramRuleId" + definedParmRuleId + "paramRuleValue" + getParamvalueFromSelectedOption + "paramRuleOperatorValue" + $operator + "paramRuleParam1Value" + textValue +
//				"assetName" + assetName + "userName" + loggedInUserName + 	"aivId" + assetInstanceVersionId + "scheduler" + $repeatAlerting 
		//);
	//	console.log("update : " + JSON.stringify($obj));
		
		$.ajax({
			type: "PUT",
			url: "/repopro/web/assetType/updateAivParamRule",
			contentType : "application/json",
			dataType : "json",
			data : JSON.stringify($obj),
			async: false,
			complete:function(data){
				var json = JSON.parse(data.responseText);
//				console.log("update call : " + JSON.stringify(json));
				if(json.status == "SUCCESS"){
					
					$('#openAlertingModal').modal('hide'); 
					$('#openAlertingModal').parent().css("display", "none !important");
					notifyMessage("Alerting","Parameter rule is updated successfully","success");
				}
			else {
					notifyMessage("Alerting",json.message,"fail")
					return false;
				}	

			}
		});

		
	}
		
}




changeParameterFlag = false;
//Show opertor based on parameter -chandana 14.02.2020

/*$("#emailAlertParameterList").on('change', function() {
    alert('sd');
});*/
var remindFlag = false;

//alerting - chandana 26.02.2020
var getOperatorValueFromAPI;
// get Rule based on id
function getRuleBasedIdforAlert(){
	// constructAlertData();
	$(".parameterInfo").popup();
	 $.ajax({
			type : "GET",
			url : "/repopro/web/assetType/getAivParamRule?userName="+loggedInUserName+"&aivId="+assetInstanceVersionId,
			dataType : "json",
			async : false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				//console.log("get call : " + JSON.stringify(json));
				if (json.status == "SUCCESS") {
					
					if(json.result[0].paramRuleId == "0" || json.result[0].paramRuleId == 0){
						firstAlertData = true;
						//alert('no previous data' + firstAlertData);
						$('#deleteAlertDataIcon').hide();
					
					
						
						
					}else{
						getOperatorValueFromAPI = true;
						$.each(json.result, function(i) {
						 getParamRuleValue = json.result[i].paramRuleValue;
					//	getParamRuleValue = getParamRuleValue.split('_');
					//	getParamRuleValue = getParamRuleValue[2];
						
						 getParamRuleOperatorValue = json.result[i].paramRuleOperatorValue;
						
						 getParamRuleId = json.result[i].paramRuleId;
						
						 getParamRuleParam1Value = json.result[i].paramRuleParam1Value;
						
						 getAlertScheduler = json.result[i].scheduler;
						 
						 getAlertInputData = json.result[i].paramRuleParam1Value;
							 
							var loadParamName = [];
							var arr = [];
							var len = "";
							

							if(getParamRuleValue.length != 0){
								var paramsVariable = getParamRuleValue.split('~'); 
								len = paramsVariable.length;
							}
							getParamRuleOperatorValue = getParamRuleOperatorValue.split('~');
							
							arr = getAlertInputData.split('~');
							getAlertInputData = getAlertInputData.split('~');
							
							var k = 0;
							var flag = true;
							
							if(flag == true && remindFlag == false){
								if(len != 0){
									$('#tbl_defineParameterRules tbody').empty();
									for (var i = 0; i <len; i++) {	
										var appendData = "";
										
										appendData += '<tr style="outline: thin solid lightgrey" id="loadrowDataId_'+i+'">';
										appendData += '<td class="popuptabletr ddFilterParamSelector" style="vertical-align:top;">';
										appendData += '<select class="ui dropdown"  id="filterDropdownValues_'+i+'" style="min-width: 10em;">';
										appendData += '<option value="selectParam">[ Select Parameter ]</option></select>';	 
										appendData += '</td>';
										appendData += '<div class="ui up pointing red basic label valid null"	style="display: none;" id="errAlertParam">Please select parameter</div>';
										appendData += '<td class="popuptabletr ddOptionSelector" style="vertical-align:top;">';
										appendData += '<select class="ui dropdown dropdownCssForFilter" id="opertorDropdownValues_'+i+'">';
										appendData += '</select>';
										appendData += '</td>';

										//Input data fields
										appendData += '<td class="popuptabletr inputValueSelector" id="inputAlertField_'+i+'" style="display: none;vertical-align:top;">';
										appendData += '<div class="ui icon input focus" style="width: 195px;">';
										appendData += '<input type="text" id="inputAlertTextField_'+i+'" placeholder="Enter Text" class="customizeTextBox"><i data-html ="hi" style="margin-left:1em;cursor:pointer;color: rgba(0,0,0,0.5);" data-html="" data-variation="wide" data-position="right center" class="info circle icon alertingInfo"></i>';
										appendData += '</div></td>';

									
										
										appendData += '<td class="popuptabletr posRemoveIcon" style="vertical-align:top;"><i class="remove icon" onclick="deleteFilterParameter(this, '+getParamRuleId+')" style="cursor: pointer;"></i></td>';
										appendData += '</tr>'; 	
										
										
										$('#tbl_defineParameterRules tbody').append(appendData);
										showParamLoader();
										
										var valNew = paramsVariable[i].toString().split('_');
										var mapId = valNew[1];
										var loadParamType = valNew[2];
										var loadTypeListName = valNew[3];
										
										$('#loadFileInput_'+i).removeClass("fileValue");
										$('#loadInputFilterText_'+i).removeClass("textBoxValue");
										$('#loadInputDate_'+i).removeClass("dateBoxValue");
										$('#loadDropdownInput_'+i).removeClass("dropDownList");
										$('#loadInputRichText_'+i).removeClass("richTextValue");
										$('#loadInputLdapText_'+i).removeClass("ldapText");
										$('#loadInputLdapMappingText_'+i).removeClass("ldapMappingText");
										
										
										if(loadParamType == "list"){ 
											if(loadTypeListName == 1){
												loadTypeListName = "customlist";
											}else if(loadTypeListName == 2){
												loadTypeListName = "assetlist"
											}
											else if(loadTypeListName == 4){
												loadTypeListName = "ldapuserlist"
											}else{
												loadTypeListName = "nativeuserlist"
											}
											$('#loadInputFilterText_'+i).css('display','none');
											$('#loadInputDate_'+i).css('display','none');
											$('#loadInputRichText_'+i).css('display','none');
											
											if(loadTypeListName == "ldapuserlist"){
												//$('#loadDropdownInput_'+i).css('display','none');
												//$('#loadDdListParamValue_'+i).css('display','none');
												$('#inputAlertField_'+i).css('display','block');
												$('#inputAlertField_'+i).addClass("ldapText");
												$('#inputAlertTextField_'+i).val(getAlertInputData[i]);
											}
											else{
												$('#inputAlertField_'+i).css('display','block');
												//$('#inputAlertField_'+i).addClass("ldapText");
												$('#inputAlertTextField_'+i).val(getAlertInputData[i]);
												
												$('#loadDdListParamValue_'+i).html('<option value="'+ encodeURIComponent(getAlertInputData[i]) +'">'+ getAlertInputData[i] +'</option>');
											
												//paramListLoader(i,valNew[0],loadTypeListName,mapId);
												//console.log("listDropdownData "+listDropdownData);
				
											
												//console.log(" ddListDropdownData "+ddListDropdownData);
											//	$('#loadDdListParamValue_'+i).append(ddListDropdownData);
											}
									
											//ddAppendAssetParametersList = "";
											$('#opertorDropdownValues_'+i).append('<option value="=">=</option><option value="!=">!=</option>');

										}
										else if(loadParamType == "text"){

											
											$('#inputAlertField_'+i).css('display','block');
											//$('#inputAlertField_'+i).addClass("ldapText");
											$('#inputAlertTextField_'+i).val(getAlertInputData[i]);
										
											$('#opertorDropdownValues_'+i).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option><option value="Between">Between</option>');
										}
										
										else if(loadParamType == "Date" || loadParamType == "date"){
										
										
											
											$('#inputAlertField_'+i).css('display','block');
											//$('#inputAlertField_'+i).addClass("ldapText");
											$('#inputAlertTextField_'+i).val(getAlertInputData[i]);
											
											
											
											$('#opertorDropdownValues_'+i).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option><option value="Between">Between</option>');
										 
										}
										else if(loadParamType == "rich text"){

											
											$('#inputAlertField_'+i).css('display','block');
											//$('#inputAlertField_'+i).addClass("ldapText");
											$('#inputAlertTextField_'+i).val(getAlertInputData[i]);
											
											$('#opertorDropdownValues_'+i).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
										}
										
										else if(loadParamType == "ldapmapping"){
											
											$('#inputAlertField_'+i).css('display','block');
											//$('#inputAlertField_'+i).addClass("ldapText");
											$('#inputAlertTextField_'+i).val(getAlertInputData[i]);
											
											$('#opertorDropdownValues_'+i).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
										}
										
										else if(loadParamType == "derived asset list"){
											
											$('#inputAlertField_'+i).css('display','block');
											//$('#inputAlertField_'+i).addClass("ldapText");
											$('#inputAlertTextField_'+i).val(getAlertInputData[i]);
											
											$('#opertorDropdownValues_'+i).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
										}
										
										else if(loadParamType == "derived attribute"){
											
											$('#inputAlertField_'+i).css('display','block');
											//$('#inputAlertField_'+i).addClass("ldapText");
											$('#inputAlertTextField_'+i).val(getAlertInputData[i]);
											
											$('#opertorDropdownValues_'+i).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
										}
										
										else if(loadParamType == "derived computation"){
											
											$('#inputAlertField_'+i).css('display','block');
											//$('#inputAlertField_'+i).addClass("ldapText");
											$('#inputAlertTextField_'+i).val(getAlertInputData[i]);
											
											$('#opertorDropdownValues_'+i).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
										}
										
										
										
										$('#filterDropdownValues_'+i).empty();
										$('#filterDropdownValues_'+i).append(append_listofParameters);
										$('#filterDropdownValues_'+i).dropdown('set selected',valNew[0]);
										$('#alertScheduler').dropdown('set selected',getAlertScheduler[i]);
										
										if(getParamRuleOperatorValue[i] == "is null"){
											$('#opertorDropdownValues_'+i).dropdown('set selected',"is Empty");
										}
										else if(getParamRuleOperatorValue[i] == "is not null"){
											$('#opertorDropdownValues_'+i).dropdown('set selected',"is Not Empty");
										}
										else{
											$('#opertorDropdownValues_'+i).dropdown('set selected',getParamRuleOperatorValue[i]);
										}
										if(i != 0){
											$('#selectLogicOpId_'+(i-1)).dropdown('set selected',logicalSelectValue[i-1]);
										}
										
										$('#filterDropdownValues_'+i).change(function(){
											ddLoadFilterParameter(this);
									    });
										$('.ui.dropdown').dropdown();
									}
								}
								else{
									$('#tbl_SelectFilterParam tbody').empty();
									 //createRow();
								}

							
							}
							
							
						
					
						});
						
					}
				}
		
			
			}				
	
});

}
//--** Chandana- 13.02.2020 Email Alerting**--//

function closeAlertModal(){
	$('#emailAlertSaveID').unbind();
	$('#deleteAlertDataIcon').hide();
}
//** Chandana-26.11.19 delete alert data*

function deleteSavedAlertData(obj, getParamRuleId){

	$("#trash_"+getParamRuleId)
	.popup({
		on: 'click',
		position: 'top right',
		closable : true,
		inline : true
	})
	.popup('show');
	$('.delZindex').parent().attr("style",'margin-right: 0.5em !important; z-index: 1200 !important; top : -7em');
}

//** Chandana-26.11.19 close delete alert popup
function closeDeleteAlertingPopup(getParamRuleId){
		$("#trash_"+getParamRuleId).popup('hide');
}


// delete alert 24032020



/*Delete SavedAlertData -vishnu 23.03.2020*/
function showDeleteAlertingPopup(id){
	
	//console.log(element.id);
	
	//console.log(id);
	
	$("#deleteparamRuleId_"+id)
	.popup({
		on: 'click',
		//lastResort: 'right center',
		position   : 'bottom right',
		closable : true,
		inline : true
	})
	.popup('show');
	
//	$('#alertDelMsg').parent('div').attr('tabindex', '0');
//	$('#alertDelMsg').parent('div').focus();
	
	}

function showDeleteAlertingPopup_Ruleset(element){
	
	//console.log(element.id);
	
	
	$(element)
	.popup({
		on: 'click',
		//lastResort: 'right center',
		position   : 'bottom right',
		closable : true,
		inline : true
	})
	.popup('show');
	
//	$('#alertDelMsg').parent('div').attr('tabindex', '0');
//	$('#alertDelMsg').parent('div').focus();
	
	}

	
function closeAlertDeletepopUp(){
	$('.ui.popup').popup('hide all');
}


function deleteAlertRule(){
	
	$.ajax({
		type : "DELETE",
		url : "/repopro/web/assetType/DeleteAivParamRule?paramRuleId="+definedParmRuleId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			//$("#trash_"+definedParmRuleId).popup('hide');
			if(json.status == "FAILURE"){
				notifyMessage("Alerting",json.result,"fail");
//				$("#updateParameterRule").hide();
//				$("#saveParameterRule").show();
			}
			else {
				//remindFlag = true;
				//showParamLoader();
				//$('#showListofParameters').empty();
				//$('#showListofParameters').append('<option value="Select Parameter" id="Select Parameter">[Select Parameter]</option>');
				//$('#showListofParameters').append(append_listofParameters);
				 //$('#alertScheduler').dropdown('restore defaults'); 
//				$("#updateParameterRule").hide();
//				$("#saveParameterRule").show();
				//$('#openAlertingModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');	
				notifyMessage("Alerting","Parameter rule has been deleted successfully","success");
				//030420
				
				$("#tbl_defineParameterRules tbody").empty();
				createRow_new();
				//$('#updateParameterRule').hide();
				$('#saveParameterRule').show();
				var parameterSelect =$('#showListofParameters').dropdown('get text');
			    var newparameterSelect = parameterSelect[0];
			    if(newparameterSelect == "[Select Parameter]"){
			    	$('#deleteparamRuleId,#clearParamRuleId').addClass('disableClick');
			    }else{
			    	$('#deleteparamRuleId,#clearParamRuleId').removeClass('disableClick');
			    }
			    $('.errtooltip').hide();
				$('#enterValue,#showListofParameters,#showListofOperators,#alertScheduler').closest('div').removeClass('error');
			}

		}

	});
	$("#deleteparamRuleId").popup('hide');
}
function clearFilledData(){
	//$('#showListofOperators').empty();
	$('#showListofParameters').dropdown('clear');
	$('#showListofOperators').dropdown('clear'); 
	$('#enterValue').val('');
	$(".entervaluetd .ui.icon.input i").remove();
	$('#enterValue').prop('placeholder','Enter value');
	$('#alertScheduler').dropdown('clear');
	$('#showListofOperators').attr('disabled',true); 
	$('#enterValue').attr('disabled',true);
	$('.errtooltip').hide();
	$('#enterValue,#showListofParameters,#showListofOperators,#alertScheduler').closest('div').removeClass('error');
}


/*** Customize Layout modal***/

function customizeLayout(obj){
	
	/* if (!!navigator.userAgent.match(/Trident\/7\./)){
		$('#showHideLoader').addClass('active');
		setTimeout(function(){
			$('#loadContent').load("assetInstances.html");
		},100);
	} */
	$('#showHideLoader').addClass('active');
	$("#customLayoutId").unbind();
	
	//$('#customLayoutModel').unbind();
	
	$('#customLayoutModel').modal({ 
		/* detachable:false, */
		observeChanges : true,
		closable : false
	}).modal('show').modal('refresh');

	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/getCustomizedSectionData?userName="+loggedInUserName,
		dataType : "json",
		async : false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			//console.log("customizeLayout :: "+JSON.stringify(json.result));
			
			if(json.result[0].sectionVisibility != "" && json.result[0].sectionVisibility != null && json.result[0].sectionVisibility.length != 0){
				var item_list_data =  (json.result[0].sectionVisibility).split(",");
				//console.log("customLayoutItemListArray :: "+item_list_data);
				var custom_layout_data="", custom_layout_status_switches="";
				custom_layout_data = "";
				$.each(item_list_data, function(key, value){
					var itemListLabelChecked = value.split("~~")[1];
					
					if(value.split("~~")[0] == "Versions"){
						
						if(versionable){
							
							if(itemListLabelChecked == "checked"){
								custom_layout_data += '<tr class="customLayoutTableRow sortableSegmentCursor " ><td class="customLayoutTableData customlabelData">'+value.split("~~")[0]+'</td>'+
					    		'<td class="two wide column customLayoutTableData"><div class="ui checkbox toggle customLayoutStatusList" id="customLayoutStatusId_'+key+'">'+
					    		'<input id="statusId_'+key+'" type="checkbox" name="status_'+key+'" checked="checked" onchange="cutomStatusMethodCallBack()"><label class="Label" style="padding-top: 0px !important;">Show</label></div></td>'+
					    		'<td class="customLayoutTableData" style="width:1rem;"><i class="bars icon"></i></td></tr>';//style="cursor:default!important;
							}else{
								custom_layout_data += '<tr class="customLayoutTableRow sortableSegmentCursor " ><td class="customLayoutTableData customlabelData">'+value.split("~~")[0]+'</td>'+
					    		'<td class="two wide column customLayoutTableData"><div class="ui checkbox toggle customLayoutStatusList" id="customLayoutStatusId_'+key+'">'+
					    		'<input id="statusId_'+key+'" type="checkbox" name="status_'+key+'" onchange="cutomStatusMethodCallBack()"><label class="customLayoutModelLabel" style="padding-top: 0px !important;">Hide</label></div></td>'+
					    		'<td class="customLayoutTableData" style="width:1rem;"><i class="bars icon"></i></td></tr>';//style="cursor:default!important;
							}
						}else{
							
							if(itemListLabelChecked == "checked"){
								custom_layout_data += '<tr class="customLayoutTableRow sortableSegmentCursor " style="display:none !important;"><td class="customLayoutTableData customlabelData">'+value.split("~~")[0]+'</td>'+
					    		'<td class="two wide column customLayoutTableData"><div class="ui checkbox toggle customLayoutStatusList" id="customLayoutStatusId_'+key+'">'+
					    		'<input id="statusId_'+key+'" type="checkbox" name="status_'+key+'" checked="checked" onchange="cutomStatusMethodCallBack()"><label class="customLayoutModelLabel" style="padding-top: 0px !important;">Show</label></div></td>'+
					    		'<td class="customLayoutTableData" style="width:1rem;"><i class="bars icon"></i></td></tr>';
							}else{
								custom_layout_data += '<tr class="customLayoutTableRow sortableSegmentCursor " style="display:none !important;"><td class="customLayoutTableData customlabelData">'+value.split("~~")[0]+'</td>'+
					    		'<td class="two wide column customLayoutTableData"><div class="ui checkbox toggle customLayoutStatusList" id="customLayoutStatusId_'+key+'">'+
					    		'<input id="statusId_'+key+'" type="checkbox" name="status_'+key+'" onchange="cutomStatusMethodCallBack()"><label class="customLayoutModelLabel" style="padding-top: 0px !important;">Hide</label></div></td>'+
					    		'<td class="customLayoutTableData" style="width:1rem;"><i class="bars icon"></i></td></tr>';//style="cursor:default!important;
							}
						}
					}else{
						if(itemListLabelChecked == "checked"){
							custom_layout_data += '<tr class="customLayoutTableRow sortableSegmentCursor " ><td class="customLayoutTableData customlabelData">'+value.split("~~")[0]+'</td>'+
				    		'<td class="two wide column customLayoutTableData"><div class="ui checkbox toggle customLayoutStatusList" id="customLayoutStatusId_'+key+'">'+
				    		'<input id="statusId_'+key+'" type="checkbox" name="status_'+key+'" checked="checked" onchange="cutomStatusMethodCallBack()"><label class="customLayoutModelLabel" style="padding-top: 0px !important;">Show</label></div></td>'+
				    		'<td class="customLayoutTableData" style="width:1rem;"><i class="bars icon"></i></td></tr>';//style="cursor:default!important;
						}else{
							custom_layout_data += '<tr class="customLayoutTableRow sortableSegmentCursor " ><td class="customLayoutTableData customlabelData">'+value.split("~~")[0]+'</td>'+
				    		'<td class="two wide column customLayoutTableData"><div class="ui checkbox toggle customLayoutStatusList" id="customLayoutStatusId_'+key+'">'+
				    		'<input id="statusId_'+key+'" type="checkbox" name="status_'+key+'" onchange="cutomStatusMethodCallBack()"><label class="customLayoutModelLabel" style="padding-top: 0px !important;">Hide</label></div></td>'+
				    		'<td class="customLayoutTableData" style="width:1rem;"><i class="bars icon"></i></td></tr>';//style="cursor:default!important;
						}
					}
					
					
				});
				
			}
			
			
			
			//console.log("custom_layout_data : " + custom_layout_data);
			if(custom_layout_data != ""){
				//$("#customLayout").hide();
				//console.log("b4 : " + $("#customLayout").html());
				$("#customLayout").html(custom_layout_data);
				
				//console.log("after : " + $("#customLayout").html());
				//$('.ui.sticky').sticky();

				/*  $(".customLayoutTableRow").each(function(key, value) {
					$(this).fadeIn(key*300);//show('blind',(key*1000) );//
				}); */
				initCustomDraggableFunction();
			}else{
				console.log("Custom layout model is getting load....");
			} 
			
			$('#showHideLoader').removeClass('active');
		}});
	
	//var item_list_data=['item_list-1','item_list-2','item_list-3','item_list-4','item_list-5','item_list-6','item_list-7','item_list-8','item_list-9'];
	//var custom_layout_data="", custom_layout_status_switches="";
	
	 
	/* $.each(item_list_data, function(key, value){
						
		
    	custom_layout_data += '<tr class="customLayoutTableRow" style="display:none !important;"><td class="customLayoutTableData customlabelData">'+value+'</td>'+
    		'<td class="two wide column customLayoutTableData"><div class="ui slider checkbox customLayoutStatusList" id="customLayoutStatusId_'+key+'">'+
    		'<input id="statusId_'+key+'" type="checkbox" name="status_'+key+'" onchange="cutomStatusMethodCallBack()"><label class="customLayoutModelLabel">Off</label></td></tr>'
    		
	
	}); */
	
	
	
	
	/* $('#customLayoutModel').modal({ 
		blurring: true,
		observeChanges : true,
		closable : false
	}).modal('refresh').modal('show');
	
	if(custom_layout_data != ""){
		//$("#customLayout").hide();
		$("#customLayout").html(custom_layout_data);
		//$('.ui.sticky').sticky();

		$(".customLayoutTableRow").each(function(key, value) {
			$(this).fadeIn(key*1000);//show('blind',(key*1000) );//
		})
		
		initCustomDraggableFunction();
	}else{
		console.log("Custom layout model is getting load....");
	} */
}
var customLayoutObj = {};
//var customLayoutArray = [];

//custom layout model initialize function, basically for drag and drop function
function initCustomDraggableFunction(){
	$("#customLayout").sortable({
		//items: "li:not(.class_name_here)",
		start: function(e, ui) {
			//write logic here while initiating for the shorting
		},stop: function(e, ui){
	    	
	    	//calling this function here to get the updated array after shorting of the list.
	    	cutomStatusMethodCallBack();
		}
	}).disableSelection();
	//$('.message.customLayoutMsg').hide();
	
	
	//to display the message box 
	$('.message.customLayoutMsg .close').closest('.message').transition('show');
	
	//function to close the message box
	$('.message.customLayoutMsg .close')
	  .on('click', function() {
	    $(this)
	      .closest('.message')
	      .transition('hide');
	  });
}

/* this function will call on each and every switch buttons(custom layout model) click event to set the corresponding 
label status */
var dataPos = "";
var dataStatus = "";
function cutomStatusMethodCallBack(){
	customLayoutObj = {};
	//customLayoutObj = [];//customLayoutArray = [];customLayoutArray
	dataPos = "";
	dataStatus = "";
	//var indexVal = $('#customListDataCommonStyle_'+index_val).index()
	$(".customLayoutTableRow").each(function(key, value) {
		var labelName = $(this).children("td.customlabelData").text();//$(this).text();
		var labelStatus ="";
		var $this =  $(this).children("td.customLayoutTableData").children(".customLayoutStatusList");
		//console.log($this.text()+" :: checked :: "+$this.checkbox('is checked'));
		
		if($this.checkbox('is checked')){
			labelStatus = "checked";
			$($this).children(".customLayoutModelLabel").text("Show");
		}else{
			labelStatus = "unchecked";
			$($this).children(".customLayoutModelLabel").text("Hide");
		}
		if($(".customLayoutTableRow").length == (key+1)){
			dataPos += labelName+"~~"+key;
    		dataStatus +=  labelName+"~~"+labelStatus;
		}else{
			dataPos += labelName+"~~"+key+",";
    		dataStatus +=  labelName+"~~"+labelStatus+",";
		}
		
		//customLayoutObj.formData.push({"labelName":labelName, "index_val":key, "status":labelStatus});  
    });
	//console.log(dataPos +" :: dataPos ==  dataStatus :: "+dataStatus);
	//customLayoutObj.push({"sectionPosition":dataPos, "sectionVisibility":dataStatus});
	customLayoutObj = {"sectionPosition":dataPos, "sectionVisibility":dataStatus}; 
	//console.log("formData :: "+JSON.stringify(customLayoutObj));
}


//close customLayout Model
function closeCustomLayout(){
	$('#customLayoutModel').modal({ 
		//blurring: true,
		detachable:false,
		observeChanges : true,
		closable : false
	}).modal('hide').modal('destroy');
}

//final approval button of the cutom layout model
function customizationDone(){
	cutomStatusMethodCallBack();
	/*var customLayoutObj1 = {
		"sectionPosition": "Tags~~0,Taxonomies~~1,Overview~~2,Properties~~3,Relationships~~4,Revision History~~5,Discussion~~6,Versions~~7,Reverse Relationships~~8",
		"sectionVisibility": "Tags~~checked,Taxonomies~~unchecked,Overview~~checked,Properties~~unchecked,Relationships~~checked,Revision History~~checked,Discussion~~checked,Versions~~checked,Reverse Relationships~~checked"
	};   */
	//customLayoutObj = $.unique(customLayoutObj);
			
	//console.log("final customLayoutArray :: "+JSON.stringify(customLayoutObj));
	$.ajax({
		type: "PUT",
       	url: "/repopro/web/assetInstanceVersionManager/updateCustomizedSectionData?userName="+loggedInUserName,
       	contentType : "application/json",
		dataType : "json",
		data : JSON.stringify(customLayoutObj),
		async: false,
		cache:false,
		complete:function(data){
			
			var json = JSON.parse(data.responseText);
			//console.log("customizeLayout :: "+JSON.stringify(json.status));	
			
			if(json.status == "SUCCESS"){
				/* alert("successfully updated"); */
				notifyMessage("Customize layout", "Successfully updated", "success"); 
				$('#customLayoutModel').modal({ 
					//blurring: true,
					detachable:false,
					observeChanges : true,
					closable : false
				}).modal('hide').modal('destroy');
				
				setTimeout(function(){
					window.location.reload(true);// location.reload();//modified by aditya 15.03.18
				},800)
					
				
			}
		}
	});
}



//copy URL
function openCopyURLModal(){
	
	//copyLinkModal
	$("#cancelCopyLink").unbind();

	$('#copyLinkModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	$("#copyLink").attr("data-tooltip", "Copy to clipboard");
	var origin   = window.location.origin; 
	var assetNameModified = assetName.replace(/ /g, "+");
	var url = origin +'/repopro/view/'+assetName+'/'+assetInstanceVersionId;
	var Copyurl = origin +'/repopro/view/'+assetNameModified+'/'+assetInstanceVersionId;
	$("#copyLinkField").val(url);	
	$("#copyLink").on("click",function(){
		$('#copyLinkModal').append('<input  name="myfieldname" id="copyLinkUrl" />');
		$('#copyLinkUrl').val(Copyurl);
		$("#copyLinkUrl").select();
		document.execCommand("copy");
		$("#copyLink").attr("data-tooltip","Copied: "+url);
		$("#copyLinkUrl").remove();
		
	});
	  
	
}


// Chandana LDAP multi user list modal

//open Edit LDAP User Modal

function openEditLDAPMappingUserModal(paramId){
	$("#closeLDAPMappingUserList").unbind();
	$("#updateLDAPMappingUserList").unbind();
	$("#searchLDAPMappingUser").unbind();
	$("#searchedLdapMappingUserInput").val('');
	$("#addedUserMappingListLDAP").html('');
	
	$('#editLDAPMappingUserListModal').modal('destroy');
	$('#editLDAPMappingUserListModal').trigger("reset");
	$('#editLDAPMappingUserListModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');	
	
	$("#searchedLDAPMappingUserResults").html('<div class="ui message">Please search for the user. </div>');
	var paramName = $("#assetParamId_"+paramId).text();
	
	$("#editLDAPMappingUserListParamName").html(paramName);
	var isSingleList = $("#isMultiple_"+paramId).text();
	
	// SINGLE LIST
	if(isSingleList == "true"){
		$("#iconAlter").removeClass("users icon");
		$("#iconAlter").addClass("user icon");
		$("#editLDAPMappingMessage").text("Add single value for this parameter");
	}
	else{
		$("#iconAlter").removeClass("user icon");
		$("#iconAlter").addClass("users icon");
		$("#editLDAPMappingMessage").text("Add multiple value(s) for this parameter");
	}
	
	var first_Td = "", second_Td = "", third_Td = "", fourth_Td = "", fifth_Td = "", sixth_Td = "";
	var arr1 = [], arr2 = [], arr3 = [], arr4 = [], arr5 = [], arr6 = [], count = 0, edit_singleMulti_appendData = "";
		
	if(isSingleList == "true"){
		first_Td = "", second_Td = "", third_Td = "", fourth_Td = "", fifth_Td = "", sixth_Td = "";
		
		$('#ldapMappingSingleListData_'+paramId).find('tr').each(function(index, tr) {
			first_Td = $(tr).find('td:eq(0)').text();
			first_Td = first_Td.split("$");
			
			second_Td = $(tr).find('td:eq(1)').text();
			second_Td = second_Td.split("$");
			
			third_Td = $(tr).find('td:eq(2)').text();
			third_Td = third_Td.split("$");
			
			fourth_Td = $(tr).find('td:eq(3)').text();
			fourth_Td = fourth_Td.split("$");
			
			fifth_Td = $(tr).find('td:eq(4)').text();
			fifth_Td = fifth_Td.split("$");
			
			sixth_Td = $(tr).find('td:eq(5)').text();
			sixth_Td = sixth_Td.split("$");

			if(first_Td != ""){
				arr1.push(first_Td[0]); 
				count = arr1.length;
			}

			if(second_Td != ""){
				arr2.push(second_Td[0]);
				count = arr2.length;
			}

			if(third_Td != ""){
				arr3.push(third_Td[0]);
				count = arr3.length;
			}

			if(fourth_Td != ""){
				arr4.push(fourth_Td[0]);
				count = arr4.length;
			}

			if(fifth_Td != ""){
				arr5.push(fifth_Td[0]);
				count = arr5.length;
			}

			if(sixth_Td != ""){
				arr6.push(sixth_Td[0]);
				count = arr6.length;
			}


		});
	}else{
		first_Td = "", second_Td = "", third_Td = "", fourth_Td = "", fifth_Td = "", sixth_Td = "";
		
		$('#edit_multiTableTable_'+paramId).find('tr').each(function(index, tr) {
			first_Td = $(tr).find('td:eq(0)').text();
			first_Td = first_Td.split("$");
			
			second_Td = $(tr).find('td:eq(1)').text();
			second_Td = second_Td.split("$");
			
			third_Td = $(tr).find('td:eq(2)').text();
			third_Td = third_Td.split("$");
			
			fourth_Td = $(tr).find('td:eq(3)').text();
			fourth_Td = fourth_Td.split("$");
			
			fifth_Td = $(tr).find('td:eq(4)').text();
			fifth_Td = fifth_Td.split("$");
			
			sixth_Td = $(tr).find('td:eq(5)').text();
			sixth_Td = sixth_Td.split("$");

			if(first_Td != ""){
				arr1.push(first_Td[0]); 
				count = arr1.length;
			}

			if(second_Td != ""){
				arr2.push(second_Td[0]);
				count = arr2.length;
			}

			if(third_Td != ""){
				arr3.push(third_Td[0]);
				count = arr3.length;
			}

			if(fourth_Td != ""){
				arr4.push(fourth_Td[0]);
				count = arr4.length;
			}

			if(fifth_Td != ""){
				arr5.push(fifth_Td[0]);
				count = arr5.length;
			}

			if(sixth_Td != ""){
				arr6.push(sixth_Td[0]);
				count = arr6.length;
			}


		});
	}
			
			if(count > 0){
				for(var h=0; h<count; h++){
					edit_singleMulti_appendData += "<tr class='addedLDAPLoopMapping' id='userLDAPMappingAdded_"+arr1[h]+"'>";
					
					// USER ID  
					if(arr1[h] == "undefined" || arr1[h] == undefined || arr1[h] == "" || arr1[h] == null || arr1[h] == "null"){
						edit_singleMulti_appendData += "<td class='hidden'>"+arr1[h]+"<span>$"+first_Td[1]+"</td>";
					}else{
						edit_singleMulti_appendData += "<td>"+arr1[h]+"<span class='hidden'>$"+first_Td[1]+"</td>";
					}
					
					if(arr2[h] == "undefined" || arr2[h] == undefined || arr2[h] == "" || arr2[h] == null || arr2[h] == "null"){
						edit_singleMulti_appendData += '<td class="hidden">'+arr2[h]+"<span>$"+second_Td[1]+"</td>";
					}else{
						edit_singleMulti_appendData += '<td>'+arr2[h]+"<span class='hidden'>$"+second_Td[1]+"</td>";
					}
					
					if(arr3[h] == "undefined" || arr3[h] == undefined || arr3[h] == "" || arr3[h] == null || arr3[h] == "null"){
						edit_singleMulti_appendData += '<td class="hidden">'+arr3[h]+"<span>$"+third_Td[1]+"</td>";
					}else{
						edit_singleMulti_appendData += '<td>'+arr3[h]+"<span class='hidden'>$"+third_Td[1]+"</td>";
					}
					
					if(arr4[h] == "undefined" || arr4[h] == undefined || arr4[h] == "" || arr4[h] == null || arr4[h] == "null"){
						edit_singleMulti_appendData += '<td class="hidden">'+arr4[h]+"<span>$"+fourth_Td[1]+"</td>";
					}
					else{
						edit_singleMulti_appendData += '<td>'+arr4[h]+"<span class='hidden'>$"+fourth_Td[1]+"</td>";
					}
					
					if(arr5[h] == "undefined" || arr5[h] == undefined || arr5[h] == "" || arr5[h] == null || arr5[h] == "null"){
						edit_singleMulti_appendData += '<td class="hidden">'+arr5[h]+"<span>$"+fifth_Td[1]+"</td>";
					}else{
						edit_singleMulti_appendData += '<td>'+arr5[h]+"<span class='hidden'>$"+fifth_Td[1]+"</td>";
					}
					
					if(arr6[h] == "undefined" || arr6[h] == undefined || arr6[h] == "" || arr6[h] == null || arr6[h] == "null"){
						edit_singleMulti_appendData += '<td class="hidden">'+arr6[h]+"<span>$"+sixth_Td[1]+"</td>";
					}else{
						edit_singleMulti_appendData += '<td>'+arr6[h]+"<span class='hidden'>$"+sixth_Td[1]+"</td>";
					}
					
					edit_singleMulti_appendData += '<td><div class="detail" style="float: right;">';
					edit_singleMulti_appendData += '<i class=" delete icon deleteEditIcon" onclick="removeLDAPMappingValueFromAddList(\''+arr1[h]+'\');"></i>';
					edit_singleMulti_appendData += '</div></td>';
						
					edit_singleMulti_appendData += '</tr>';
					$("#addListMappingErrorMessages").hide();
					$("#addedUserMappingListLDAP").show();
					$('#addedUserMappingListLDAP').html("");
					$('#addedUserMappingListLDAP').append(edit_singleMulti_appendData);

				}

			}
			else {
				edit_singleMulti_appendData = "";
				$("#addListMappingErrorMessages").show();
				$("#addedUserMappingListLDAP").hide();
			}
			
	
	$("#searchLDAPMappingUser").on('click',function(){
		
		$("#searchLDAPMappingUser").addClass('loading');
		
		var searchedUser = $("#searchedLdapMappingUserInput").val().trim();
		
		if(searchedUser != ""){
			var json = searchLDAPMappingUser(searchedUser,paramName);
			
			appendData = "";
			
			if (json.status == "SUCCESS") {
				if(json.result == "" || json.result == null){
					$("#searchedLDAPMappingUserResults").html('<div class="ui error message">User could not be found. </div>');
				}else{
					$("#searchedLDAPMappingUserResults").html('');
					
					appendData = "";
					var firstName = "", department = "", emailId = "", userId = "", fullName = "", lastName = "";
					
					$.each(json.result, function(i) {
						
						//check if any field is null
						if(json.result[i].userId != null){
							userId = json.result[i].userId;
						}
						
						if(json.result[i].firstName != null){
							firstName = json.result[i].firstName;
						}
						
						if(json.result[i].lastName != null){
							lastName = json.result[i].lastName;
						}
						
						if(json.result[i].fullName != null){
							fullName = json.result[i].fullName;
						}
						
						if(json.result[i].dept != null){
							department = json.result[i].dept;
						}
						
						if(json.result[i].email != null){
							emailId = json.result[i].email;
						}
						
						var userAttributeId = "", firstNameAttributeId = "", lastNameAttributeId = "", fullNameAttributeId = "", emailAttributeId = "", departmentAttributeId = "";
						userAttributeId = json.result[i].userIdAttributeId;
						firstNameAttributeId = json.result[i].firstNameAttributeId;
						lastNameAttributeId = json.result[i].lastNameAttributeId;
						fullNameAttributeId = json.result[i].fullNameAttributeId;
						emailAttributeId = json.result[i].emailAttributeId;
						departmentAttributeId = json.result[i].deptAttributeId;
						
						//console.log("right side userAttributeId : " + userId + "firstName : " + firstName + " lastName : " + lastName + " fullName : " +fullName + " department : " + department + " emailId : " + emailId + " isSingleList : " + isSingleList);
						appendData = loadLdapMappingDataInGrid(userId,firstName,lastName,fullName,department,emailId,isSingleList, userAttributeId, firstNameAttributeId, lastNameAttributeId, fullNameAttributeId, emailAttributeId, departmentAttributeId);
						$("#searchedLDAPMappingUserResults").append(appendData);
						//check already added. If yes hide/disable user.
						$(".addedLDAPLoopMapping").each(function(){
							var data = $(this).attr("id");
							data = data.split("_");
							var id = data[1];
							if(id == json.result[i].userId){
								$("#userLDAPMapping_"+json.result[i].userId).addClass('browserDisableDropdown');
							}
						});
					});
					
				}
			}else {	
				notifyMessage("Search LDAP Users",json.message,"fail");		
			}
			
		}else{
			notifyMessage("Search LDAP Users", "Please provide some search content", "warning");
		}
		
		setTimeout(function(){
			$("#searchLDAPMappingUser").removeClass('loading');
		},0);
		
	});
	
	var userListLDAPMapping = "";
	$("#updateLDAPMappingUserList").on('click',function(){
		append_userListLDAPMappingData = "";
	
		$("#addedUserMappingListLDAP").find('tr').each(function(index, tr){
			
			var update_userid = $(tr).find('td:eq(0)').text();
			update_userid = update_userid.split("$");
			var userAttrId = update_userid[1];
			
			var update_firstName = $(tr).find('td:eq(1)').text();
			update_firstName = update_firstName.split("$"); 
			var firstNameAttrId = update_firstName[1];
			
			var update_lastName = $(tr).find('td:eq(2)').text();
			update_lastName = update_lastName.split("$"); 
			var lastNameAttrId = update_lastName[1];
			
			var update_fullName = $(tr).find('td:eq(3)').text();
			update_fullName = update_fullName.split("$");
			var fullNameAttrId = update_fullName[1];
			
			var update_emailId = $(tr).find('td:eq(4)').text();
			update_emailId = update_emailId.split("$");
			var emailAttrId = update_emailId[1];
			
			var update_department = $(tr).find('td:eq(5)').text();
			update_department = update_department.split("$");
			var deptAttrId = update_department[1];
			
			//console.log("update_userid : " + update_userid[0] + " update_firstName : " + update_firstName[0] + " update_lastName : " + update_lastName[0] + " update_fullName : " + update_fullName[0] + " update_emailId : " + update_emailId[0] + " update_department : " + update_department[0])
		
			append_userListLDAPMappingData += '<tr>';
			if(update_userid[0] == "undefined" || update_userid[0] == undefined || update_userid[0] == "" || userAttrId == 0 || userAttrId == "0"){
				append_userListLDAPMappingData += '<td class="hidden">'+update_userid[0]+'<span>$'+userAttrId+'</span></td>';
			}else{
				append_userListLDAPMappingData += '<td>'+update_userid[0]+'<span class="hidden">$'+userAttrId+'</span></td>';
				
			}
			
			if(update_firstName[0] == "undefined" || update_firstName[0] == undefined || update_firstName[0] == "" || firstNameAttrId == 0 || firstNameAttrId == "0"){
				append_userListLDAPMappingData += '<td class="hidden">'+update_firstName[0]+'<span>$'+firstNameAttrId+'</span></td>';
			}else{
				append_userListLDAPMappingData += '<td>'+update_firstName[0]+'<span class="hidden">$'+firstNameAttrId+'</span></td>';
				
			}
			
			if(update_lastName[0] == "undefined" || update_lastName[0] == undefined || update_lastName[0] == "" || lastNameAttrId == 0 || lastNameAttrId == "0"){
				append_userListLDAPMappingData += '<td class="hidden">'+update_lastName[0]+'<span>$'+lastNameAttrId+'</span></td>';
			}else{
				append_userListLDAPMappingData += '<td>'+update_lastName[0]+'<span class="hidden">$'+lastNameAttrId+'</span></td>';
				
			}
			
			if(update_fullName[0] == "undefined" || update_fullName[0] == undefined || update_fullName[0] == "" || fullNameAttrId == 0 || fullNameAttrId == "0"){
				append_userListLDAPMappingData += '<td class="hidden">'+update_fullName[0]+'<span>$'+fullNameAttrId+'</span></td>';
			}else{
				append_userListLDAPMappingData += '<td>'+update_fullName[0]+'<span class="hidden">$'+fullNameAttrId+'</span></td>';
				
			}
			
			if(update_emailId[0] == "undefined" || update_emailId[0] == undefined || update_emailId[0] == "" || emailAttrId == 0 || emailAttrId == "0"){
				append_userListLDAPMappingData += '<td class="hidden">'+update_emailId[0]+'<span>$'+emailAttrId+'</span></td>';
			}else{
				append_userListLDAPMappingData += '<td>'+update_emailId[0]+'<span class="hidden">$'+emailAttrId+'</span></td>';
				
			}
			
			if(update_department[0] == "undefined" || update_department[0] == undefined || update_department[0] == "" || deptAttrId == 0 || deptAttrId == "0"){
				append_userListLDAPMappingData += '<td class="hidden">'+update_department[0]+'<span>$'+deptAttrId+'</span></td>';
			}else{
				append_userListLDAPMappingData += '<td>'+update_department[0]+'<span class="hidden">$'+deptAttrId+'</span></td>';
				
			}
			
			append_userListLDAPMappingData += '</tr>';
			
		});
		
		//console.log("append_userListLDAPMappingData : " + append_userListLDAPMappingData);
		if(isSingleList == "true"){
			$('#ldapMappingSingleListData_'+paramId).html("");
			$('#ldapMappingSingleListData_'+paramId).html(append_userListLDAPMappingData);
			
			var singleSelectTableRowCount = $('#ldapMappingSingleListData_'+paramId).find('tr').length;
			if(singleSelectTableRowCount > 0){
				$('#ldapMappingSingleListData_'+paramId).show();
			}else{
				$('#ldapMappingSingleListData_'+paramId).hide();
			}
			
		}else{
			$('#edit_multiTableTable_'+paramId).html("");
			$('#edit_multiTableTable_'+paramId).append(append_userListLDAPMappingData);
			
			var multipleSelectTableRowCount = $('#edit_multiTableTable_'+paramId).find('tr').length;
			$('#ldapUserCountMulti_'+paramId).html(multipleSelectTableRowCount+" value(s)");
			
		}
		
		$('#editLDAPMappingUserListModal').modal('hide');
	});
	
	$("#closeLDAPMappingUserList").on("click",function(){
		$('#editLDAPMappingUserListModal').modal('hide');
	});
			
	
}


//load Ldap Data In Grid             
function loadLdapMappingDataInGrid(userId, firstName, lastName, fullName, department, emailId, isSingleList, userAttributeId, firstNameAttributeId, lastNameAttributeId, fullNameAttributeId, emailAttributeId, departmentAttributeId){
	appendData = "";
	//alert("userId : " + userId + "firstName : " + firstName + " lastName : " + lastName + " fullName : " +fullName + " department : " + department + " emailId : " + emailId + " isSingleList : " + isSingleList);

	
	appendData +='<tr class="userListLoop" id="userLDAPMapping_'+userId+'">';
	
	if(userId == "" || userId == null || userId == "null" || userId == undefined || userId == "undefined"){
		appendData += '<td id="userId_'+userId+'" class="hidden">'+userId+'<span>$'+userAttributeId+'</span></td>';
	}
	else{
		appendData += '<td id="userId_'+userId+'" class="collapsing">'+userId+'</td><td class="hidden">$'+userAttributeId+'</td>';
	}
	
	if(firstName == "" || firstName == null || firstName == "null" || firstName == undefined || firstName == "undefined"){
		appendData += '<td id="LDAPMappingUserName_'+userId+'" class="hidden"><span>$'+firstNameAttributeId+'</span></td>';
		
	}
	else{
		appendData += '<td id="LDAPMappingUserName_'+userId+'" >'+firstName+'<span class="hidden">$'+firstNameAttributeId+'</span></td>';
	}
	
	if(lastName == "" || lastName == null || lastName == "null" || lastName == undefined || lastName == "undefined"){
		appendData += '<td id="LDAPMappingLastName_'+userId+'" class="hidden">'+lastName+'<span>$'+lastNameAttributeId+'</span></td>';
	}
	else{
		appendData += '<td id="LDAPMappingLastName_'+userId+'">'+lastName+'<span class="hidden">$'+lastNameAttributeId+'</span></td>';
	}
	
	
	if(fullName == "" || fullName == null || fullName == "null" || fullName == undefined || fullName == "undefined"){
		appendData += '<td id="fullName_'+userId+'" class="hidden">'+fullName+'<span>$'+fullNameAttributeId+'</span></td>';
	}
	else{
		appendData += '<td id="fullName_'+userId+'">'+fullName+'<span class="hidden">$'+fullNameAttributeId+'</span></td>';
	}
	
	if(emailId == "" || emailId == null || emailId == "null" || emailId == undefined || emailId == "undefined"){
		appendData += '<td id="ldapEmailId_'+userId+'" class="hidden">'+emailId+'<span>$'+emailAttributeId+'</span></td>';
	}
	else{
		appendData += '<td id="ldapEmailId_'+userId+'">'+emailId+'<span class="hidden">$'+emailAttributeId+'</span></td>';
	}
	
	if( department == "" || department == null || department == "null" || department == undefined || department == "undefined"){
		appendData += '<td id="ldapDept_'+userId+'" class="hidden">'+department+'<span>$'+departmentAttributeId+'</span></td>';
	}
	else{
		appendData += '<td id="ldapDept_'+userId+'">'+department+'<span class="hidden">$'+departmentAttributeId+'</span></td>';
	}
	appendData +='<td class="collapsing">';
	appendData +='<div class="ui fitted">';
	appendData +='<i class=" add icon deleteEditIcon" onclick="addLDAPMappingValue(\''+userId+'\',\''+firstName+'\',\''+lastName+'\',\''+fullName+'\',\''+department+'\',\''+emailId+'\',\''+isSingleList+'\',\''+userAttributeId+'\',\''+firstNameAttributeId+'\',\''+lastNameAttributeId+'\',\''+fullNameAttributeId+'\',\''+emailAttributeId+'\',\''+departmentAttributeId+'\')"></i>';
	appendData +='</div>';
	appendData +='</td>';
	appendData +='</tr>';


	
	return appendData;
}

//add LDAP Value
function addLDAPMappingValue(userId, firstName, lastName, fullName, department, emailId, isSingleList, userAttributeId, firstNameAttributeId, lastNameAttributeId, fullNameAttributeId, emailAttributeId, departmentAttributeId){
	$("#addListMappingErrorMessages").hide();
	
	$("#addedUserMappingListLDAP").show();
	
	appendData = "";
	appendData = createLdapMappingDataForAdd(userId, firstName, lastName, fullName, department, emailId, userAttributeId, firstNameAttributeId, lastNameAttributeId, fullNameAttributeId, emailAttributeId, departmentAttributeId);	
	
	if(isSingleList == "true"){
		$("#addedUserMappingListLDAP").html(appendData);
		$(".userListLoop").removeClass('browserDisableDropdown');
	}else{
		$("#addedUserMappingListLDAP").append(appendData);
	}
	$("#userLDAPMapping_"+userId).addClass('browserDisableDropdown');
	
}

function createLdapMappingDataForAdd(userId, firstName, lastName, fullName, department, emailId, userAttributeId, firstNameAttributeId, lastNameAttributeId, fullNameAttributeId, emailAttributeId, departmentAttributeId) {
	
	appendData = "";
	appendData += '<tr class="addedLDAPLoopMapping"  id="userLDAPMappingAdded_'+userId+'">';
	
	if(userId != null && userId != ""){
		appendData += '<td>'+userId+'<span class="hidden">$'+userAttributeId+'</span></td>';
	}else {
		appendData += '<td class="hidden">'+userId+'<span>$'+userAttributeId+'</span></td>';
	}
	
	if(firstName != null && firstName != ""){
		appendData += '<td>'+firstName+'<span class="hidden">$'+firstNameAttributeId+'</span></td>';
	}else{
		appendData += '<td class="hidden">'+firstName+'<span>$'+firstNameAttributeId+'</span></td>';
	}

	if(lastName != null && lastName != ""){
		appendData += '<td>'+lastName+'<span class="hidden">$'+lastNameAttributeId+'</span></td>';
	}else{
		appendData += '<td class="hidden">'+lastName+'<span>$'+lastNameAttributeId+'</span></td>';
	}
	
	if(fullName != null && fullName != ""){
		appendData += '<td>'+fullName+'<span class="hidden">$'+fullNameAttributeId+'</span></td>';
	}
	else{
		appendData += '<td class="hidden">'+fullName+'<span>$'+fullNameAttributeId+'</span></td>';
	}
	
	if(emailId != null && emailId != ""){
		appendData += '<td>'+emailId+'<span class="hidden">$'+emailAttributeId+'</span></td>';
	}else{
		appendData += '<td class="hidden">'+emailId+'<span>$'+emailAttributeId+'</span></td>';
	}
	
	if(department != null && department != ""){
		appendData += '<td>'+department+'<span class="hidden">$'+departmentAttributeId+'</span></td>';
	}else{
		appendData += '<td class="hidden">'+department+'<span>$'+departmentAttributeId+'</span></td>';
	}
	
	
	
	appendData += '<td><div class="detail" style="float: right;"><i class=" delete icon deleteEditIcon" onclick="removeLDAPMappingValueFromAddList(\''+userId+'\')"></i></td>';
	appendData += '</tr>';
	
	return appendData;
}
//removeLDAPValueFromAddList
function removeLDAPMappingValueFromAddList(userId){
	
	$("#userLDAPMappingAdded_"+userId).remove();
	$("#userLDAPMapping_"+userId).removeClass('browserDisableDropdown');
	
	var tableRowCount = $('#addedUserMappingListLDAP tr').length;
	
	if(tableRowCount == 0){
		$("#addedUserMappingListLDAP").hide();
		$("#addListMappingErrorMessages").show();
		//arr_UpdatedLdapMapping.length = 0;
	}else {
		$("#addedUserMappingListLDAP").show();
		$("#addListMappingErrorMessages").hide();
	}
}


//get LADP User Details
/*function getLADPMappingUserDetails(event){
	var x = event.which || event.keyCode;
	if(x == 13){
		$("#searchLDAPMappingUser").click();openEditLDAPMappingUserModal
	}
}*/
//Keypress event on search input in ldapmapping modal
function getLADPMappingUserDetails(event){
	var x = event.which || event.keyCode;
	if(x == 13){
		$("#searchLDAPMappingUser").click();
	}
}


//search LDAP User
function searchLDAPMappingUser(searchedUser,paramName){
	var json;
	$.ajax({
		type : "GET",
	    url : "/repopro/web/ldapmanager/getallldapusersByMappingId?uid="+searchedUser+"&assetName="+encodeURIComponent(assetName)+"&paramName="+paramName,
		contentType : "application/json",
		dataType : "json",
		async : false,
		cache: false,
		complete : function(data) {
			 json = JSON.parse(data.responseText);
			// console.log(JSON.stringify(json));
		}
	});
	
	return json;
}



/*getfirst  workflow status on load -chandana 05.02.2020 */

function getFirstWorkflowStatus(){
	//alert(assetInstanceVersionId)

	$.ajax({
		type : "GET",
		url: "/repopro/web/workflow/retFirstState?aivId="+assetInstanceVersionId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					$("#noWorkflow").show();
					$("#workflowDropdown").hide();
				}else{
					$("#noWorkflow").hide();
					$("#workflowDropdown").show();
				var currentState = '';
				
				currentState = json.result[0].nextStates;
				var currentStateOutput = Object.values( currentState );
				
				$('#fistStatusofWorkflow').text('');
				$('#fistStatusofWorkflow').text(currentStateOutput);
			}
			}
			else{
				
			}
		}
	});
}

/*getall workflow status on load -chandana 05.02.2020 */
var nextStateOutput = '';
var nextState = '';
var appendNextStateOption = '';
var appendNextStateOption1 = '';
var number = '';
function getAllWorkflowStatus(){
	$.ajax({
		type : "GET",
		url: "/repopro/web/workflow/retNextState?aivId="+assetInstanceVersionId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
				}
				else{
					nextState = json.result[0].nextStates;
					var nextStateOutput = Object.values( nextState );
					var nextStatekeyOutput = Object.keys( nextState );
					$("#getMenus").dropdown('clear');
					$("#getMenus").html('');
					appendNextStateOption1 ="";
					for (const [key, value] of Object.entries(nextState)) {
						 // appendNextStateOption += '<div class="item workFlowStates" onclick="nextState('+key+')">'+value+'.'+key+'</div>';
						  appendNextStateOption1 += '<div class="item" onclick="nextWorkState('+key+')">'+value+'</div>';
						}
			
				}
				$('#getMenus').append(appendNextStateOption1);
			
			}
		}
	});
}

function nextWorkState(key){
	var getSelectedWorkflow = $('#getMenus').find(":selected").val();	
	$("#getMenus").hide(); // hide the dropdown
		$.ajax({
			type : "PUT",
			url: "/repopro/web/workflow/updateInstanceState?aivId="+assetInstanceVersionId+"&updatedState="+key,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null){						
						 $("#getMenus").hide(); // hide the dropdown	
						$("#assetInstanceMainLoaderSegment").click();
						notifyMessage("Update Asset Instance State","Asset Instance state updated","success");						
						getFirstWorkflowStatus();
						getAllWorkflowStatus();
					}
					else{
						
					}
				}
			}
		});		
}



