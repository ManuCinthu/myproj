paramData = "";
useCaseName = "";
enteredData = "";

tableHeaders = [];
searchResultCount = 0;

//get Advanced  Search Result
function getAdvancedSearchResult(){
	//console.log("/repopro/web/customSearch/customSearchByUsecaseDetails?usecase="+useCaseName+"&parameters="+encodeURIComponent(paramData)+"&userName="+loggedInUserName)
	/*var data = encodeURIComponent(paramData);
	console.log("data:   "+data)
	console.log( decodeURIComponent(data))*/
	 $.ajax({
			type : "GET",
			url : "/repopro/web/customSearch/customSearchByUsecaseDetails?usecase="+useCaseName+"&parameters="+encodeURIComponent(paramData)+"&userName="+loggedInUserName,
			dataType : "json",
			async: false,
			cache:false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				//console.log(JSON.stringify(json.result))
				if(json.status == "SUCCESS"){
					if(json.result == null || json.result == ""){
						$("#cardAdvancedSearchResult").hide();
						$('#assetInstancesFloatingIcons').html("");
						$("#assetInstancesFloatingIcons").hide();
						$("#noAdvancedSearchResultGridData").show().html('<div class="ui negative message">No matching results found.</div>');
						
					}else{
						$("#cardAdvancedSearchResult").show();
						$("#noAdvancedSearchResultGridData").hide();
						tableHeaders.length = 0;
						
						
						
						$.each(json.result,function(i){
							 var count = 0;
							appendData = "";
							appendData += '<div class="ui raised fluid card" >';
							
							var eachResultData = (json.result[i]).split("~~");
							var versionID = "";
							$.each(eachResultData,function(i){
								var paramData = eachResultData[i];
								paramData = paramData.split(":~:");
								var key = paramData[0];
								var value = paramData[1];
								if(count == 0){
									versionID = value;
								}else if(count == 1){
											if(value == null || value == "null"){
												value = "";
											}
											key = key.replace(/_/g," ");
											key = key.toLowerCase().replace(/\b[a-z]/g, function(letter) {
											    return letter.toUpperCase();
											});
											
											appendData += '<div class="content">';
											appendData += '<div class="description">';
											appendData += '<div class="ui grid" style="margin-left:1em;">';
											appendData += '<div class="three wide column" ><span>'+key+'</span></div>';
											appendData += '<div class="twelve wide column"><a onclick="getAssetInstances('+versionID+',\''+value+'\')">'+value+'</a></div>';
											appendData += '<div class="one wide column meta"><i class="chevron down link icon" style="float:right;" onclick="showHideContent('+searchResultCount+')"></i></div>';
											appendData += '</div></div></div>';
											count++;
											return false;
								}
								count++;
								
							});
							
							appendData += '<div class="content extraSearchContent" style="border-top: none !important; display:none;" id="extraContent_'+searchResultCount+'">';
							appendData += '<div class="description">';
							appendData += '<div class="ui grid" style="margin-left:1em;">';
							
							count = 0;
							
							$.each(eachResultData,function(i){
								var paramData = eachResultData[i];
								paramData = paramData.split(":~:");
								var key = paramData[0];
								var value = paramData[1];
								
								if(count != 1){
									if(value == null || value == "null"){
										value = "";
									}
									key = key.replace(/_/g," ");
									key = key.toLowerCase().replace(/\b[a-z]/g, function(letter) {
									    return letter.toUpperCase();
									});
									appendData += '<div class="three wide column" ><span>'+key+'</span></div>';
									appendData += '<div class="thirteen wide column meta">'+value+'</div>';
									
								}
								count++;
								
							});
							
							
							appendData += '</div></div></div></div>';
							$("#cardAdvancedSearchResult").append(appendData);
							searchResultCount++;
							
						});
						
						$("#advancedSearchResultCount").html(searchResultCount+"  Result(s)");
						
						
					}
				} 
			}
		});
}


//show Hide Content 
function showHideContent(id){
	$("#extraContent_"+id).toggle("blind");
	
}

//expand All Search Result
function expandAllSearchResult(){
	$(".extraSearchContent").show();
	/*$("#expandAllSearchResult").hide();
	$("#compressAllSearchResult").show();*/
}

//compress All Search Result
function compressAllSearchResult(){
	$(".extraSearchContent").hide();
	/*$("#expandAllSearchResult").show();
	$("#compressAllSearchResult").hide();*/
}


