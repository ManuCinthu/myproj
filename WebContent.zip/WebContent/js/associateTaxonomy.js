appendData = "";
infiniteScrollFlag = true;
countNoOfData = 0;
formRange = 0;
function loadAssociatedTaxonomy(taxonomyId){
	//url = "http://localhost:6060/repopro/web/taxonomy/getAssetInstancesTaxonomy?userName="+loggedInUserName+"&taxonomyId="+taxonomyId;
	//console.log("url "+url);
	/*localStorage.setItem("searchValue", globalSearchValue);
	localStorage.setItem("searchDdValue", globalSearchDd);*/
	$.ajax({
		type : "GET",
		url : "/repopro/web/taxonomy/getAssetInstancesTaxonomy?userName="+loggedInUserName+"&taxonomyId="+taxonomyId,
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null || json.result == []){
					if(countNoOfData == 0){
						$("#noTaxonomyDetails").show();
						$('#noTaxonomyDetails').html('<div class="ui message">No instances to display !</div>'); 
						$("#associateTaxonomyGrid").hide();
						infiniteScrollFlag = false;
					}
					else{
						$('#associateTaxoLoadingId').css('display', 'none');
						infiniteScrollFlag = false;
					}
				}
				else{
					$('#noTaxonomyDetails').hide();
					$('#associateTaxonomyGrid').show();
					$('#associateTaxonomyTableTbody').html("");
					$.each(json.result, function(i) {
						appendData = getAssociateTaxonomyDetails(json.result[i].assetId,json.result[i].assetName,json.result[i].assetInstVersionId,json.result[i].assetInstanceName,json.result[i].versionName,json.result[i].overview);
						//console.log("  appendData "+appendData);
						$('#associateTaxonomyTableTbody').append(appendData);
						//$('#associateTaxonomyTableTbody').children("td").addClass("associateTaxOverflow");
						//console.log("td data :: "+($('#associateTaxonomyTableTbody').children("td").text()));
						countNoOfData++;
					});
					
					formRange = formRange + 20;
				}
				$('#associateTaxoLoadingId').css('display', 'none');
			}else{
				$('#associateTaxoLoadingId').css('display', 'none');
				$("#noTaxonomyDetails").show();
				$("#associateTaxonomyGrid").hide();
				infiniteScrollFlag = false;
			}
		}
	});
	$('#associateTaxoLoadingId').css('display', 'none');
}
function getAssociateTaxonomyDetails(assetId,assetName,versionId,assetInstanceName,versionName,overview){
	
	//console.log(" overview "+overview);
	var encodedAssetInstName= encodeURIComponent(assetInstanceName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	
	
	appendData = '';
	appendData += '<tr>';
	appendData += '<td class="two wide center aligned" onclick="navigateToBrowseGridPage('+assetId+',\''+assetName+'\')"><a style="cursor: pointer;">'+assetName+'</a></td>';
	appendData += '<td class="two wide center aligned">'+versionId+'</td>';
	appendData += '<td class="three wide center aligned" style="cursor: pointer;" onclick="navigateToAssetInstancePage('+assetId+',\''+assetName+'\','+versionId+',\''+encodedAssetInstName+'\');"><a  style="cursor: pointer;">'+assetInstanceName+'</a></td>';
	appendData += '<td class="two wide center aligned">'+versionName+'</td>';

	/*var hasTableTag = isTableTag(overview);
	if(hasTableTag == false){
		//console.log(" hasTableTag "+hasTableTag);
		appendData += '<td class="eight wide aligned sidebarSubMenuOverviewSize" style="overflow-x: auto;">';
	}else{
		appendData += '<td class="eight wide aligned sidebarSubMenuOverviewSize">';
	}
	
	if(overview == null){
		overview = "";
	}
	//console.log("overview   "+overview);
	appendData += overview+'</td>';*/
	
	//*******souradip 16.03.18
	
	if(overview == null){
		overview = "";
	}
	
	
		//console.log(overview)
	
		
	
	appendData += '<td class="seven wide aligned browseByTaxChromeFirefoxCss" >'+overview+'</td>';
	
	
	
	/*appendData += '<td class="eight wide aligned">'+overview+'</td>';*/
	appendData += '</tr>';
	
	//console.log(appendData)
	return appendData;
}

function navigateToBrowseGridPage(assetId,assetName){
	
	if ($('#contentPushable').hasClass('sidebarPushable')){
		$('#contentPushable').removeClass('push-right-ctm');
	}
	
	 $("html, body").animate({scrollTop: 0}, 10);
	 localStorage.setItem("browserAssetName", assetName);
	 localStorage.setItem("browserAssetId", assetId);
	// $(".browserMainItem1").click();
	 $(".browserAllAssetsSubMenu").click();
	 $("#browserAssetId_"+assetId).click();
	// $('#loadContent').load('browser.html'); 
}

function navigateToAssetInstancePage(assetId,assetName,versionId,encodedAssetInstName){
	if ($('#contentPushable').hasClass('sidebarPushable')){
		$('#contentPushable').removeClass('push-right-ctm');
	}
	$("html, body").animate({scrollTop: 0}, 10);
	 /*localStorage.setItem("browserAssetName", assetName);
	 localStorage.setItem("browserAssetId", assetId);*/
	 //$(".browserMainItem1").click();
	 $(".browserAllAssetsSubMenu ").click();
	 $("#browserAssetId_"+assetId).addClass('themeTextColor itemSelected');
	 getAssetInstances(versionId,encodedAssetInstName);
}
//check if the desc has tble tag 
function isTableTag(str){
    return /^\<table.*\>.*\<\/table\>/i.test(str);
}