//load all Leader Board Ranks
appendData = "";
highestPoint = "";
countUsers	= 0;
lowerRange = 0;
higherRange = 19;
infiniteScrollFlag = true;
function loadLeaderBoardRanks(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/gameDetails/pointList?from="+lowerRange+"&to="+higherRange+"&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$.each(json.result, function(i) {
					if(JSON.stringify(json.result[i].mapPointList) == "{}"){
						
						if(countUsers == 0){
							$('#leaderBoardGrid').hide();
							$('#noleaderBoardData').show();
							$('#noleaderBoardData').html('<div class="ui message">Leader board details not yet available</div>'); 
							$("#exportViewAllLeaderboardData").hide();
						}
						else{
							$('#loadingId').css('display', 'none');
							infiniteScrollFlag = false;
						}
						
					}
					else{
						$('#noleaderBoardData').hide();
						$('#leaderBoardGrid').show();
						$.each(json.result[i].mapPointList, function(key, value) {
							var key = key.split("~");
							if(countUsers < 1){
								highestPoint = key[0];
							}
							var percentValue = (key[0]/highestPoint)*100;
							
							if(typeof key[3] != "null"){
								imageType = key[3].split(".");
							}
							
							appendData =  getAllLeaderBoardRanks(key[0], key[1], key[2], imageType[1], value, percentValue,key[4]);
							$('#leaderBoardGrid table tbody').append(appendData);
							$('#progress_'+countUsers).progress();
							countUsers++;

						});
					}
				});
				lowerRange = lowerRange + 20;
				higherRange = higherRange + 20;
			}
			else{
				$('#loadingId').css('display', 'none');
			}
			$('#showHideLoader').removeClass('active');
		}
	});
	$('#loadingId').css('display', 'none');
}

function exportLeaderboardDetails() {
	var con = confirm("Please confirm to start the export");
	if(con == true){
		window.location.href = '/repopro/web/export/exportInExcelGamificationPoints?userName='+loggedInUserName;
		notifyMessage("Leaderboard Export","Export process has started. You will receive the file through mail.","success");
	}else return false;
}


function  getAllLeaderBoardRanks(points, name, userId, imageType, rank, percentValue,encyImgId){
	//Chandana broken image issue
	if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
		imageType = imageType.toLowerCase()
	}
		appendData = '';
		appendData += '<tr>';
		appendData += '<td class="two wide center aligned">';
		appendData += '<div class="ui image">';
		if(typeof imageType == "undefined"){
			appendData += '<img id="userId_'+userId+'" class="ui tiny circular image" src="/repopro/semantic/images/avatar/defaultUserImage.png">';
		}else{//Swathi- encryption- 07.01.2020
			if((encyImgId == 1) && (name != loggedInUserFullName) && (loggedMapRoleFlag == 0)){
				appendData += '<img id="userId_'+userId+'" class="ui tiny circular image" src="/repopro/semantic/images/avatar/defaultUserImage.png">';
			} else {
			appendData += '<img id="userId_'+userId+'" class="ui tiny circular image" src="/repopro/profileImages/'+userId+'.'+imageType+'">';
			}
		}
		appendData += '</div></td>';
		appendData += '<td class="ten wide left aligned">';
		appendData += '<h4 class="ui header">'+rank+'. <span class="leaderBoardNameLink" onclick="getUserSpecificPointDetails('+userId+',true)">'+name+'</span></h4>';
		appendData += '<div class="ui small indicating progress" data-percent="'+percentValue+'" id="progress_'+countUsers+'">';
		appendData += '<div class="bar"></div>';
		appendData += '</div></td>';
		appendData += '<td class="two wide center aligned">';
		appendData += '<div class="ui large orange  circular label">'+points+'</div></td>';
		appendData += '</tr>';
		return appendData;
	
}
