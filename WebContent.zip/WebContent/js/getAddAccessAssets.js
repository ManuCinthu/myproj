

//get asset list
function getAddAccessAssetList(){
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetType/fetchallassetsdetails?userName="+loggedInUserName,
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.message == "ASSETS_NOT_FOUND"){
					$("#addAccessAssetList").html('<div class="ui visible message"><p>You do not have add access for any asset</p></div>');
				}else{
					
					$.each(json.result,function(i){
						var assetIconType = "default";
						if(json.result[i].iconImageName != null){
							var imageType = json.result[i].iconImageName ;
							//imageType = imageType.split(".");
							//assetIconType = imageType[1];
							assetIconType = (json.result[i].iconImageName).substring((json.result[i].iconImageName).lastIndexOf(".") + 1, (json.result[i].iconImageName).length);

						}
						//console.log(assetIconType)
						var assetData = loadAssetListData(json.result[i].assetId,json.result[i].assetName,assetIconType,json.result[i].description);
						$("#addAccessAssetListTbody").append(assetData);
					});
					
				}
			}
		}
	});
}

//load Asset List Data
function loadAssetListData(assetId,assetName,imageName,description){
	//Chandana - 13-9-2019 removing case sensitive - Broken image
	if (imageName == 'PNG' || imageName == 'JPEG' || imageName == 'JPG'){
		imageName = imageName.toLowerCase()
	}
	/*
	appendData = "";
	
	appendData += '<div class="sixteen wide column">';
	appendData += '<div class="ui segments"> <div class="ui segment" style="overflow: hidden;">';
	
	
	
	if(imageName == "default"){
		if(circularThemeColoredIcon){
			appendData += '<div class="mediumIconImageCircleStyle_asset_themeCircle browsePageStyle">';
			if(invertAssetIconFlag){
				appendData += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				appendData += '<image class="ui  image mediumIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}else{
			appendData += '<div class="mediumIconImageCircleStyle browsePageStyle mediumIconImageCircleRemove">';
			if(invertAssetIconFlag){
				appendData += '<image class="ui  image mediumIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				appendData += '<image class="ui  image mediumIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}
		
	}else{
		
		if(circularThemeColoredIcon){
			appendData += '<div class="mediumIconImageCircleStyle_asset_themeCircle browsePageStyle ">';
			if(invertAssetIconFlag){
				appendData += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor" src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'">';
			}else{
				appendData += '<image class="ui  image mediumIconImageStyle_themeCircle" src="/repopro/assetImages/'+assetId+'.'+imageName+'">';
			}
		}else{
			appendData += '<div class="mediumIconImageCircleStyle browsePageStyle mediumIconImageCircleRemove">';
			if(invertAssetIconFlag){
				appendData += '<image class="ui  image mediumIconImageStyle invertImageColor" src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'">';
			}else{
				appendData += '<image class="ui  image mediumIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+imageName+'">';
			}
		}
		
		
	}
	appendData += '</div>';
	
	appendData += '<span style="margin-left: 1.5em;vertical-align: sub;">'+assetName+'</span>';
	appendData += '<button class="ui right floated labeled icon primary mini button" onclick="addAssetInstance('+assetId+',\''+assetName+'\')">';
	appendData += '<i class="add icon"></i> Create Instance';
	appendData += '</button>';
	appendData += '</div>';
	appendData += '</div></div>';*/
	
	
	appendData = "";
	
	appendData += '<tr>';
	appendData += '<td>';
	
	
	if(imageName == "default"){
		if(circularThemeColoredIcon){
			appendData += '<div class="mediumIconImageCircleStyle_asset_themeCircle browsePageStyle">';
			if(invertAssetIconFlag){
				appendData += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				appendData += '<image class="ui  image mediumIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}else{
			appendData += '<div class="mediumIconImageCircleStyle browsePageStyle mediumIconImageCircleRemove">';
			if(invertAssetIconFlag){
				appendData += '<image class="ui  image mediumIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				appendData += '<image class="ui  image mediumIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}
		
	}else{
		
		if(circularThemeColoredIcon){
			appendData += '<div class="mediumIconImageCircleStyle_asset_themeCircle browsePageStyle ">';
			if(invertAssetIconFlag){
				appendData += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor" src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'">';
			}else{
				appendData += '<image class="ui  image mediumIconImageStyle_themeCircle" src="/repopro/assetImages/'+assetId+'.'+imageName+'">';
			}
		}else{
			appendData += '<div class="mediumIconImageCircleStyle browsePageStyle mediumIconImageCircleRemove">';
			if(invertAssetIconFlag){
				appendData += '<image class="ui  image mediumIconImageStyle invertImageColor" src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'">';
			}else{
				appendData += '<image class="ui  image mediumIconImageStyle" src="/repopro/assetImages/'+assetId+'.'+imageName+'">';
			}
		}
	}
	
	appendData += '</div>';
	
	
	appendData += '<span class= "whitespaceNoTrim" style="margin-left: 1.5em; vertical-align: sub;">'+assetName+'</span></td>';
	if(description == null){
		description = "";
	}
	appendData += '<td>'+description+'</td>';
	appendData += '<td class="center aligned">';
	appendData += '<button class="ui basic button " onclick="addAssetInstance('+assetId+',\''+assetName+'\')"><i class="add icon" ></i> Create</button>';
	appendData += '</td>';
	appendData += '</tr>';
	
	return appendData;
}


//add Asset Instance
function addAssetInstance(assetId,assetName){
	
	localStorage.removeItem("browserAssetName");
	localStorage.setItem("browserAssetName", assetName);
	
	localStorage.removeItem("browserAssetId");
	localStorage.setItem("browserAssetId", assetId);
	
	localStorage.removeItem("fromAddAccessPage");
	localStorage.setItem("fromAddAccessPage", true);
	
	localStorage.removeItem("editAIVPageFlag");
	localStorage.setItem("editAIVPageFlag", true);
	
	//set add child AIV page false
	localStorage.removeItem("addChildAIVPage");
	localStorage.setItem("addChildAIVPage", false);
	
	//$(".addInstanceSidebar").removeClass("menuColor themeTextColor");
	
	getAssetInstances(0,"newInstance");
}


