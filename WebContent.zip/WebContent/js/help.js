var loggedInUserName = localStorage.getItem("loggedInUserName");
var loggedInUserEmail = localStorage.getItem("loggedInUserEmail");
function loadHelpContent(){
	$.ajax({
		type: "GET",
		url: "/repopro/web/helpcontents",
		dataType: "json",
		async: "false",
		complete: function(data){
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){;
				$("#loadHelpContentData").html(json.result[0].help_Content);
			}
			
		}
	});
	$('#showHideLoader').removeClass('active');
}
//get contact details
function contactUsDetails(){
	
	
	$('#submitDetails').unbind();
	$('#resetContactDetails').unbind();

	
	 $("#contactDetailsContent").parent().removeClass("error"); 
	 $("#errcontactDetailsContent").hide(); 
 
	$("#contantDetailsHelpContent").modal('destroy');
	$("#contantDetailsHelpContent").modal('setting', 'closable', false).modal('show');
	$("#contactDetailsContent").val('');
	
	$("#contactDetailsUserName").val(loggedInUserName);
	$("#contactDetailsEmailId").val(loggedInUserEmail);
	
	if(loggedInUserName != "roleAnonymous"){
		$("#contactDetailsEmailId").attr("disabled",true);
	}
	

$("#submitDetails").on('click',function(){
	var contactDetailsUserName = $("#contactDetailsUserName").val().trim();
	var contactDetailsEmailId = $("#contactDetailsEmailId").val().trim();
	var contactDetailsCategory = $("#contactDetailsCategory").find(":selected").text();
	var contactDetailsContent = $("#contactDetailsContent").val().trim();
	var flag = true;
	
	
	if(contactDetailsUserName == null || contactDetailsUserName == ""){
		 $("#contactDetailsUserName").parent().addClass("error"); 
		 $("#errContactDetailsUserName").show();  
		  flag = false;
	}
	else{
		$("#contactDetailsEmailId").parent().removeClass("error"); 
		$("#errContactDetailsUserName").hide(); 
	}
	
	 if(contactDetailsEmailId == null || contactDetailsEmailId == ""){
		 $('#contactDetailsEmailId').parent().addClass("error"); 
		 $("#errContactDetailsEmailId").html("Please enter Email ID").show();  
		  flag = false;
	}
	else{
		 
		if(loggedInUserName == "roleAnonymous"){
			var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			 if(regex.test(contactDetailsEmailId)){
				 $('#contactDetailsEmailId').parent().removeClass("error"); 
					$("#errContactDetailsEmailId").hide();
			 }else{
				$('#contactDetailsEmailId').parent().addClass("error"); 
				$("#errContactDetailsEmailId").html(contactDetailsEmailId+' is an invalid email id').show();
				flag = false;
			 }
		}else{
			$('#contactDetailsEmailId').parent().removeClass("error"); 
			$("#errContactDetailsEmailId").hide();
		}
			
		 
	}
	 
	 
	 if(contactDetailsCategory == null || contactDetailsCategory == ""){
		 $('#contactDetailsCategory').parent().addClass("error"); 
		  $("#errContactDetailsCategory").show();  
		  flag = false;
	}
	else{
		$('#contactDetailsCategory').parent().removeClass("error"); 
		$("#errContactDetailsCategory").hide(); 
	}
	 

	 if(contactDetailsContent == null || contactDetailsContent == ""){
		 $('#contactDetailsContent').parent().addClass("error"); 
		  $("#errcontactDetailsContent").show();  
		  flag = false;
	}
	else{
		$('#contactDetailsContent').parent().removeClass("error"); 
		$("#errcontactDetailsContent").hide(); 
	}
	 if(flag == false){
		 $('#contantDetailsHelpContent').modal('show');
		 return false;
	 }
	 else{
		 $('#contantDetailsHelpContent').modal('hide'); //.modal('hide dimmer');
		 $('#contantDetailsHelpContent').parent().css("display", "none !important");
		 
		 
		 contactDetailsContent = encodeURIComponent(contactDetailsContent);
		 var url = "http://localhost:8080/repopro/web/contactUs/submitContactUs?name="+contactDetailsUserName+"&email="+contactDetailsEmailId+"&category="+contactDetailsCategory+"&content="+contactDetailsContent;
		 $.ajax({
		       type: "POST",
		       url: "/repopro/web/contactUs/submitContactUs?name="+contactDetailsUserName+"&email="+contactDetailsEmailId+"&category="+contactDetailsCategory+"&content="+contactDetailsContent,
		       contentType : "application/json",
				dataType : "json",
				async: false,
				complete:function(data){	
				appenddata = "";
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						notifyMessage("Contact Details","Your query has been raised successfully ! We will get back to you shortly !","success");
					}
					else {
							notifyMessage("Contact Details",json.message,"fail");
					}
				}
		  });
	 }
});

}

//user manual
function downloadUserManual(){
	if (confirm('Are you sure you want to download RepoPro User manual ?')){
		//window.location.href= '/repopro/doc/RepoPro_manual_18_6.pdf';
		window.open(
				'/repopro/doc/RepoPro User Manual.pdf',
				  '_blank'
				);
	}
}
