//Souro - BOC
appendData = "";
globalAssetInstanceVersionId = "";
selectedList = [];
formRange = 0;
countNoOfData = 0;
infiniteScrollFlag = true;
callApplyFunction = false;
browserSearchFlag = false;
filterExportSearchflag = false;
alertFlag  = false;
noDataFlag = false;
noDataFlag_applyFilter = false;
setAddAccessFlag = true;
checkCompositionAggregationAssetType_Flag = false;
showAivDetails = "";
showGroupDetails = "";
var browserAssetName = localStorage.getItem("browserAssetName");
browserAssetName = browserAssetName.replace(/\"/g, "");
var browserAssetId = localStorage.getItem("browserAssetId");
flag = "";
var count = 0;
var res;
var selOp;
var paramDetailsList = [];
removeFlag = false;
editApplyFilterFlag = false;
applyShowHide = false;
filterSearchForApply = true;
var imageName = "default";
var adminFlag;
applyOperators = "";
applyAssetParamNames = "";
applyParam1 = "";
applyParam2 = "";
applyLogicalSelect = "";
applyTax = "";
var searchString1;
var searchString2;
var getAIVids = [];
var getCountofInstances = "";
var countOnNoButton = true;
var countOnNoSearchButton = true;
var defaultFilterName ;
var loadfilterFlag = false;
var individualCheckFlag = false;
var individualSearchCheckFlag = false;
var showCheckboxCheckedFlag = false;
var defaultFilterFlag = 0;
var loadedFilterName = "";
var loadBrowseFilterFlag = false;
var duserName; 
var dassetName; 
var dassetId; 
var doperators; 
var dparam1Value;
var dparam2Value;
var dassetParamNames;
var dlogicalSelect;
var dtaxId ;
var nameFilterFlag = 0;
var saveConfirmationflag = false;
var defaultString ;
var defaultFilterId;
var eParam1; 
var eParam2;
var eParam3 ;
var eParam4;
var eParam5; 
var etax;

var deleteFlagDefaultLoad  ;
// get show hide column list for AivDetails and GroupDetails

function getAivGroupDetails() {
	var sessionVal = sessionStorage.getItem("removeDefault");
	if(sessionVal == "false"){
		defaultFilterNameAjax();
		//loadBrowseFilterFlag = true;
	} else if(sessionVal == "true"){
		loadBrowseFilterFlag = false;
		$("#clearFilterButton").hide();
		$("#clickFilterMsg").hide();
		$("#defaultFilterMessage").hide();
		$("#noFilterclickMsg").show();
		$("#noDefaultFilterMessage").show();
	}	
	
	$('#headingName').html("Browse - " + browserAssetName + " Instances");
	$('#headingName').parent().show();
		
	url = "http://localhost:8080/repopro/web/showHideColumn/getShowHideColumn?assetId="+browserAssetId+"&userName="+loggedInUserName;
	//console.log("getAivGroupDetails  "+url);
	$.ajax({
		type : "GET",
		url : "/repopro/web/showHideColumn/getShowHideColumn?assetId="+browserAssetId+"&userName="+loggedInUserName,	
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				adminFlag = json.result[0].adminFalg;
				
				//Get count of instances on page load -  browse page -
				if(adminFlag == true){
					$.ajax({ 
						type : "GET",
						url :"/repopro/web/assetInstanceVersionManager/getAssetInstanceBrowseGridForTotalCount?userName="+loggedInUserName+"&assetName="+encodeURIComponent(browserAssetName)+"&assetId="+browserAssetId,
						dataType : "json",
						async: false,
						complete : function(data) {
							var json = JSON.parse(data.responseText);
							if(json.status == "SUCCESS"){
								getCountofInstances = json.paramValues.count; 
								getAIVids = json.paramValues.AivIds; 
							}
						}
					});
				}
				
				if(json.result[0].showAivDetails == null || JSON.stringify(json.result[0].showAivDetails) == "{}"){
					showAivDetails = "";
				}
				else{
					$.each(json.result[0].showAivDetails, function(key,value){
						showAivDetails = value;
					});
				}
	
				if(json.result[0].showGroupDetails == null || JSON.stringify(json.result[0].showGroupDetails) == "{}"){
					showGroupDetails = "";
				}
				else{
					$.each(json.result[0].showGroupDetails, function(key,value){
						
						showGroupDetails = value;
					});
				}
				
				
				$.each(json.result[0].showParamDetails, function(key,value){
					paramDetailsList.push(value);
				});
				//console.log("  paramDetailsList  "+paramDetailsList);
			}
		}
	});
	// Swathi- 09.12.2019 - Default filter

	addAssetInstanceAccess();
	checkCompositionAggregationAssetType();
	if(loadfilterFlag == true){
		nameFilterflag = 1;
		applyFilter();
	} else{
		loadBrowserAssets();
	};	
}

//get all asset instances for the asset
var appenddData = "";
var floatingIconsShowHideFlag = false;
function loadBrowserAssets(){
	$("#noDataBrowserAssetData_BrowseSearch").hide();
	$("#browserAssetGrid_BrowseSearch").hide();
	var url;
	floatingIconsShowHideFlag = false;
	//console.log("formRange " + formRange + " countNoOfData " + countNoOfData + " infiniteScrollFlag : " + infiniteScrollFlag + "appendadata : " + appenddData);
	url = "/repopro/web/assetInstanceVersionManager/getAssetInstanceBrowseGrid?userName="+loggedInUserName+"&assetName="+browserAssetName+"&assetId="+browserAssetId+"&from="+formRange;
	$.ajax({ 
		type : "GET",
		url : url,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				
				if(json.result == "" || json.result == null || json.result == "[]"){
					if(countNoOfData == 0){
						noDataFlag = true;
						$("#noDataBrowserAssetData").show();
						$('.ManagebulkAccess').hide();
						$("#viewDefaultFilterDiv").hide(); // swathi
						if(loggedInUserName != "admin"){
							$("#dataToBeDisplayed").html(" ");
							$("#dataToBeDisplayed").html("There are no instance to be displayed.");
							//$('#assetInstancesFloatingIcons span').hide();
							if (loggedInUserName == "roleAnonymous") {
								$('#assetInstancesFloatingIcons').hide();
							}else {
								floatingIconsShowHideFlag = true;
							}
							
						}else{
							$("#dataToBeDisplayed").html(" ");
							$("#dataToBeDisplayed").html("There are no instances added.");
							
							floatingIconsShowHideFlag = true;
						}
						infiniteScrollFlag = false;
						$("#browserAssetGrid").hide();
						$("#browserInstances").hide();
						$('#removeFilter').hide();
						$('#searchBrowseGridTextBoxDiv').hide(); // Hema 21 Feb 2018 Hide Filter Icon
					}
					else{
						$('#loadingMoreAssetDetails').css('display', 'none');
						infiniteScrollFlag = false;
						
					}
					//console.log(JSON.stringify(json.result)+" :: here in loadBrowserAssets..in if child");
				}
				else{			
					$("#noDataBrowserAssetData").hide();
					$("#browserAssetGrid").show();
					$('#searchBrowseGridTextBoxDiv').show(); // Hema 21 Feb 2018 Show Filter Icon
					$("#viewDefaultFilterDiv").show(); // swathi- default filter
					if(countNoOfData == 0){
						if(json.result[0].iconImageName != null){
							var imageType  = json.result[0].iconImageName;
							/*imageType = imageType.split(".");
							imageName = imageType[1];*/
							
							imageName = (json.result[0].iconImageName).substring((json.result[0].iconImageName).lastIndexOf(".") + 1, (json.result[0].iconImageName).length);
						}
					}
					/*var appenddData = "";*/
					//appenddData = "";
					$.each(json.result, function(i) {
						//console.log("json.result[i].paramNameWithValues : " + JSON.stringify(json.result[i].paramNameWithValues));
						var paramNameWithValues = "";
						if(json.result[i].paramNameWithValues == null){
							paramNameWithValues = "No Data";
						}
						else{
							$.each(json.result[i].paramNameWithValues, function(key, value) {
								//console.log(' load browser value '+value);
								var deriveFlag = false;
								var deriveId = "";
								if(value != null){
									if(value.indexOf("^^DA^^") != -1){
									    deriveFlag = true;
									    var data = value.split("~");
									    var data1  = (data[3]).split("`@`");
									    //console.log("data1 : " + data1);
									    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
									    getDeriveAttrData(data[1],data1[0]);
									}
									
									if(value.indexOf("^^DC^^") != -1){
									    deriveFlag = true;
									    var data = value.split("~");
									    var data1  = (data[3]).split("`@`");
									    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
									    getDerivedComputationData(data[1],data1[0]);
									}
									
									// BOC Hema 14.Mar.2019- Auto Complete
									if(value.indexOf("^^AC^^") != -1){
									    deriveFlag = true;
									    var data = value.split("~");
									    var data1  = (data[3]).split("`@`");
									    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
									    getAutoCompleteData(data[1],data1[0]);
									}
									//EOC
								}
								
								paramNameWithValues += getParamNameWithValues(key, value ,deriveFlag, deriveId,json.result[i].assetInstVersionId, json.result[i].assetInstName);
							});

						}
						
						//browseGrid = 1;
						/*if(tempFlagToShowData == true){
							appenddData += getAssetInstData(json.result[i].assetInstVersionId, json.result[i].assetInstName, json.result[i].versionName, json.result[i].description, paramNameWithValues, json.result[i].showHideParamCount,json.result[i].assetInstId,json.result[i].versionable,json.result[i].deleteAccessFlag);
							tempFlagToShowData = false;
						}
						else {*/
							//var getCountofInstances = getCountofInstances;
							appenddData = getAssetInstData(json.result[i].assetInstVersionId, json.result[i].assetInstName, json.result[i].versionName, json.result[i].description, paramNameWithValues, json.result[i].showHideParamCount,json.result[i].assetInstId,json.result[i].versionable,json.result[i].deleteAccessFlag, json.result[i].deleteInstanceFlag);  //Chandana 10-06-2019 (flag has been refered)
						//}
							
							
							
							
						if(removeFlag == false){
							$("#removeFilter").hide();
							
						}else{
							$("#removeFilter").show();
							
						}
						//if(tempFlagToShowData != true){
							$("#browseTable").append(appenddData);
						//}
						countNoOfData++;
						
					});

					//console.log("appenddData : " + appenddData);
					/*if(tempFlagToShowData == true){
						$("#browseTable tbody").html(appenddData);
					}*/
					formRange = formRange + 20;

				}
				$('#loadingMoreAssetDetails').css('display', 'none');

			}
			else{
				$('#loadingMoreAssetDetails').css('display', 'none');
				$("#noDataBrowserAssetData").show();
				$('.ManagebulkAccess').hide();
				$("#browserAssetGrid").hide();
				$("#removeFilter").hide();
				$("#viewDefaultFilterDiv").hide(); // swathi
			}
			
			$('#showHideLoader').removeClass('active');
			//scrollVisible(0);
			//checkCompositionAggregationAssetType();//loadBrowserAssets
			//addAssetInstanceAccess();
		}
	});
	//handling float icons when asset has 0 instances- chandana 06.02.2020
	if(noDataFlag == true && $('#noDataBrowserAssetData').is(':visible')){
		setFloatingIconsBtns();
	}
//	console.log( "ids" + getCountofInstances + getAIVids )
}
//Swathi- code for default filter-15-10-2019
function defaultFilterNameAjax() {

	$.ajax({
				type : "GET",
				url : "/repopro/web/assetType/getDefaultFilterSearch?assetName="
						+ browserAssetName + "&userName=" + loggedInUserName,
				dataType : "json",
				async : false,
				complete : function(data) {
					var json = JSON.parse(data.responseText);
					if (json.message == "FILTER_SEARCH_DATA_FETCHED") {
						//$('#removeDefault').show(); 
						$("#defaultfilterName").text(json.result[0].searchName);
						$("#defaultfilterName1").text(json.result[0].searchName);
						defaultFilterName = json.result[0].searchName;
						defaultFilterId = json.result[0].searchId;
						duserName = json.result[0].userName;
						dassetName = json.result[0].assetName;
						dassetId = json.result[0].assetId;
						doperators = json.result[0].operatorsValue;
						dparam1Value = json.result[0].param1Value;
						dparam1Value = dparam1Value.replace(/undefined/g," ");
						dparam2Value = json.result[0].param2Value;
						dparam2Value = dparam2Value.replace(/undefined/g," ");
						dassetParamNames = json.result[0].paramsValue;
						dlogicalSelect = json.result[0].logicalSelectValue;
						dlogicalSelect = dlogicalSelect.replace(/undefined/g," ");
						dtaxId =json.result[0].taxValue;
						if(dtaxId !=null){
							dtaxId = dtaxId.split("~");					
							var taxParameter = "";
							associateTaxNameArr.length = 0;
							$.each(dtaxId,function(q){
								taxParameter = dtaxId[q].split(":")[0];
								associateTaxNameArr.push(taxParameter);
							});	
							dtaxId= associateTaxNameArr.toString();
							dtaxId =dtaxId.replace(/,/g,'~~');	
						}else{
							dtaxId ='';
						}
						var str = '';
						defaultString = str.concat(dassetParamNames,doperators,dlogicalSelect,dparam1Value,dparam2Value,dtaxId);
						//console.log("deafult string:::"+defaultString);					
						$("#noFilterclickMsg").hide();
						$("#clickFilterMsg").show();
						$("#clearFilterButton").show();
						$("#noDefaultFilterMessage").hide();
						$("#defaultFilterMessage").show();
						loadfilterFlag = true;
						loadBrowseFilterFlag= true;
					} else {
						//$('#removeDefault').hide(); 
						$("#clickFilterMsg").hide();
						$("#clearFilterButton").hide();
						//$("#noFilterclickMsg").html("<i class='info circle icon '></i> No Filter applied");
						$("#noFilterclickMsg").show();
						$("#noDefaultFilterMessage").show();
						$("#defaultFilterMessage").hide();
						loadfilterFlag = false;
						loadBrowseFilterFlag =  false;
					}

				}
			});
}


function getParamNameWithValues(key, value, deriveFlag, deriveId,assetInstanceVersionId, assetInstName){
	var encodedAssetInstName= encodeURIComponent(assetInstName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	key = key.split("~");
	if(value == "`null`"){
		value = "";
	}
	appendData = "";
	if(deriveFlag){
		appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span id="deriveData_'+deriveId+'"><span class="ui active mini inline loader"></span></span></p>';
	}
	else{
		//console.log("value: " + value);
		value = value.split("`@`");
		listData1 = value[0];
		dataTypeForParam = value[1];
		staticOrNonstatic = value[2];
			if(listData1 != "`null`"  && listData1 != ""){
				if(dataTypeForParam == "5"){
		
					var dataForDervied = listData1.replace(/`~`/g,",");
					var valueForDervied = dataForDervied.replace(/~~/g,",");
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+valueForDervied+'</span></p>';

				}
				
				// BOC Hema 06.Mar.2019 Ldap Mapping
				else if(dataTypeForParam == "9"){
					
					var customData = callCustomizableFunctionToCheckIfPropertiesIsCheckedInAIV();
					
					listData = listData1.split("``");
					listData2 = listData[0].split("~~");
					//console.log("listData2 : " + listData2);
					if(value[2] == "1"){ 
						//multiple Ldap Mapping
						var paramId = value[3], ldapMappingCountLink = "true", ldapMappingHref = "#paramTR_"+paramId;
						if(listData2 == ""){
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span></span></p>';
						}
						else {
						if(customData == "checked"){
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span style="cursor:pointer;"><a href="#paramTR_'+paramId+'" onclick="showAIVpageOnMultiLdapMappingCountClick('+assetInstanceVersionId+',\''+encodedAssetInstName+'\',\''+ldapMappingCountLink+'\',\''+ldapMappingHref+'\')" style="text-decoration: underline;">'+listData2.length+'</a></span></p>';
						}
						else {
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData2.length+'</span></p>';
						}
						}
					}else {
						//single Ldap Mapping
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i>';
						//console.log("listData : " + listData);
						if(listData2 != ""){
							appendData += '<table class="ui celled table"><tbody><tr>';
							$.each(listData, function( index, value ) {
								//console.log( index + ": " + value );
								appendData += '<td>'+value+'</td>';
							});

							appendData += '</tr></tbody></table></p>';
						}
					}
				}
				//EOC
				else if(dataTypeForParam == "7" || dataTypeForParam == "1"){
					
					
					if(dataTypeForParam == "1"){
						var startWithXml = listData1.startsWith("<");
						if(startWithXml){
							if(staticOrNonstatic == "1"){
								listData = listData1.split("~~");
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
								
							}else{
								var startWithAnchor = listData1.startsWith("<a>");
								//console.log("  startWithAnchor "+startWithAnchor);
								if(!startWithAnchor){
									/*var formatted =  formatXml(listData1);
									formatted = formatted.trim();
									formatted =	hljs.highlightAuto(formatted);
									appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key+' : </i><pre>'+formatted.value+'</pre></p>';*/
									appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
								
								}else{
									appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
								}
							}
								
							
						}else{
							if(staticOrNonstatic == "1"){
								listData = listData1.split("~~");
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
								
							}else{
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
							}
						}
					}else{
						if(staticOrNonstatic == "1"){
							listData = listData1.split("~~");
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
							
						}else{
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
						}
					}
				}else{
					listData1 = listData1.replace(/~~/g,",");
					var flag = validateURL(listData1);
					if(flag){
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><a href="'+listData1+'" target="_blank">'+listData1+'</a></p>';
					}else{
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData1+'</span></p>';
					
					}
					
				}
			}else{

				appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span></span></p>';

			}
	}
	return appendData;
}

function getParamNameWithValues_showMoreParam(key, value, deriveFlag, deriveId,assetInstanceVersionId,encodedAssetInstName){

	//console.log(' key '+key);
	key = key.split("~");
	//console.log(" getParamNameWithValues   "+value);
	if(value == "`null`"){
		value = "";
	}
	appendData = "";
	if(deriveFlag){
		appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span id="deriveData_'+deriveId+'"><span class="ui active mini inline loader"></span></span></p>';
	}
	else{
		value = value.split("`@`");
		listData1 = value[0];
		dataTypeForParam = value[1];
		staticOrNonstatic = value[2];

		if(listData1 != "`null`"  && listData1 != ""){
			if(dataTypeForParam == "5"){
	
				var derivedMultiValue = listData1.split("`!!`")[0];
				var derviedDataValue = listData1.split("`!!`")[1];
				if(derivedMultiValue == "0"){
					var derData = "";
					var dataAppend = "";
					
					derviedDataValue = derviedDataValue.split("`~`");
					$.each(derviedDataValue,function(k){
						derData = derviedDataValue[k].replace(/~~/g,",");
						dataAppend += '<div style="overflow-x: auto;">'+derData+'</div>';
					});
					//console.log(' after  derData  '+derData);
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+dataAppend+'</span></p>';
					
				}
				else{

					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+derivedMultiValue+'</span></p>';

				}				
			}
			else if(dataTypeForParam == "8"){
	
				var derivedMultiValue = listData1.split("`!!`")[0];
				var derviedDataValue = listData1.split("`!!`")[1];
				if(derivedMultiValue == "0"){
					var derData = "";
					var dataAppend = "";
					
					derviedDataValue = derviedDataValue.split("`~`");
					$.each(derviedDataValue,function(k){
						derData = derviedDataValue[k].replace(/~~/g,",");
						dataAppend += '<div style="overflow-x: auto;">'+derData+'</div>';
					});
					//console.log(' after  derData  '+derData);
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+dataAppend+'</span></p>';
					
				}
				else{

					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+derivedMultiValue+'</span></p>';

				}				
			}
			
			// BOC Hema 06.Mar.2019 Ldap Mapping
			else if(dataTypeForParam == "9"){
				var customData = callCustomizableFunctionToCheckIfPropertiesIsCheckedInAIV();
				
				listData = listData1.split("``");
				listData2 = listData[0].split("~~");
				if(value[2] == "1"){ 
					//multiple Ldap Mapping
					var paramId = value[3], ldapMappingCountLink = "true", ldapMappingHref = "#paramTR_"+paramId;
					
					if(listData2 == ""){
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span></span></p>';
					}
					else {
					if(customData == "checked"){
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span><a href="#paramTR_'+paramId+'" onclick="showAIVpageOnMultiLdapMappingCountClick('+assetInstanceVersionId+',\''+encodedAssetInstName+'\',\''+ldapMappingCountLink+'\',\''+ldapMappingHref+'\')" style="text-decoration: underline;">'+listData2.length+'</a></span></p>';
					}else {
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData2.length+'</span></p>';
					}
					}
					}else {
					//single Ldap Mapping
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i>';
					
					if(listData2 != ""){
						appendData += '<table class="ui celled table"><tbody><tr>';
						$.each(listData, function( index, value ) {
								appendData += '<td>'+value+'</td>';
						});

						appendData += '</tr></tbody></table></p>';
					}
				}
			}
			//EOC
			
			else if(dataTypeForParam == "7" || dataTypeForParam == "1"){
				
				
				if(dataTypeForParam == "1"){
					var startWithXml = listData1.startsWith("<");
					if(startWithXml){
						if(staticOrNonstatic == "1"){
							listData = listData1.split("~~");
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
							
						}else{
							var startWithAnchor = listData1.startsWith("<a>");
							//console.log("  startWithAnchor "+startWithAnchor);
							if(!startWithAnchor){
							/*	var formatted =  formatXml(listData1);
								formatted = formatted.trim();
								formatted =	hljs.highlightAuto(formatted);
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key+' : </i><pre>'+formatted.value+'</pre></p>';*/
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
							}else{
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
							}
						}
						
					}else{
						if(staticOrNonstatic == "1"){
							listData = listData1.split("~~");
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
							
						}else{
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
						}
					}
				}else{
					if(staticOrNonstatic == "1"){
						listData = listData1.split("~~");
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
						
					}else{
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
					}
				}

			}else{
				listData1 = listData1.replace(/~~/g,",");
				var flag = validateURL(listData1);
				if(flag){
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><a href="'+listData1+'" target="_blank">'+listData1+'</a></p>';
				}else{
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData1+'</span></p>';
				}
				
			}
		}else{

				appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span></span></p>';

			}
	}
	return appendData;
}

function replaceAll(str, term, replacement) {
    return str.replace(new RegExp(escapeRegExp(term), 'g'), replacement);
  }

//get asset instance data
function getAssetInstData(assetInstanceVersionId, assetInstName, versionName, description, paramNameWithValues, showHideParamCount,assetInstId,versionable,deleteAccessFlag, deleteInstanceFlag){
	var encodedAssetInstName= encodeURIComponent(assetInstName);	
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	//Swathi- 22-10-2019- Bulk Access
	if(showCheckboxCheckedFlag == true && $('.bulkAccess:checked').length < 1 ){ 
		$(".ManagebulkAccess").addClass('disableEdit');
	} else if($('.bulkAccess:checked').length >=1) {
		$(".ManagebulkAccess").removeClass('disableEdit');
	}
	//Chandana 10-06-2019 (1.change content if asset is mapped with relationship tree - browse load)
	var data1 = "";
	
	data1 = "<p id='customDelMsg_"+assetInstanceVersionId+"' class='delPopUp'></p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteAssetPopup("+assetInstanceVersionId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteAsset(this,"+assetInstanceVersionId+")'>Yes</button> ";

	
	//chandana 19-9-2019 - bulk access adding check box to every td
	appendData = "";
	appendData += '<tr id="trAssetVersion_'+assetInstanceVersionId+'">';
	//swathi - code to add data on scroll - 26-09-2019
	if(showGroupDetails == "~" && selectAllFlagChecked == true){
		appendData += '<td class="four wide top aligned"><div class="ui checkbox" ><input type="checkbox" checked id="checkboxId_'+assetInstanceVersionId+'" name="checkbox" class="bulkAccess" onclick="checkSelectAllUserInBrowseBulk(this)"><label></label></div></td>';
	}
	else  if(showGroupDetails == "~"){ 
			
		appendData += '<td class="four wide top aligned"><div class="ui checkbox" ><input type="checkbox" id="checkboxId_'+assetInstanceVersionId+'" name="checkbox" class="bulkAccess" onclick="checkSelectAllUserInBrowseBulk(this)"><label></label></div></td>';
	}
	appendData += '<td class="four wide top aligned"><span id="assetInstanceId_'+assetInstanceVersionId+'" style="display: none;">'+assetInstId+'</span>';
	appendData += '<span id="versionable_'+assetInstanceVersionId+'" style="display: none;">'+versionable+'</span>';
	
	var icon = "";
	
	/*if(imageName == "default"){
		icon = '<image class="ui  image mediumIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
	}else if(typeof imageName == "undefined"){
		icon = '<image class="ui  image mediumIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
	}else{
		icon = '<image class="ui  image mediumIconImageStyle" src="/repopro/assetImages/'+browserAssetId+'.'+imageName+'">';
	}*/
	//Chandana - 13-9-2019 Broken image
	if (imageName == 'PNG' || imageName == 'JPEG' || imageName == 'JPG'){
		imageName = imageName.toLowerCase()
	}
	if(imageName == "default"){
		if(circularThemeColoredIcon){
			icon += '<div class="mediumIconImageCircleStyle_asset_themeCircle browsePageStyle">';
			if(invertAssetIconFlag){
				icon += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				icon += '<image class="ui  image mediumIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}else{
			icon += '<div class="mediumIconImageCircleStyle browsePageStyle mediumIconImageCircleRemove">';
			if(invertAssetIconFlag){
				icon += '<image class="ui  image mediumIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				icon += '<image class="ui  image mediumIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}
		
	}else{
		
		if(circularThemeColoredIcon){
			icon += '<div class="mediumIconImageCircleStyle_asset_themeCircle browsePageStyle ">';
			if(invertAssetIconFlag){
				icon += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor" src="/repopro/assetImages/inverted_'+browserAssetId+'.'+imageName+'">';
			}else{
				icon += '<image class="ui  image mediumIconImageStyle_themeCircle" src="/repopro/assetImages/'+browserAssetId+'.'+imageName+'">';
			}
		}else{
			icon += '<div class="mediumIconImageCircleStyle browsePageStyle mediumIconImageCircleRemove">';
			if(invertAssetIconFlag){
				icon += '<image class="ui  image mediumIconImageStyle invertImageColor" src="/repopro/assetImages/inverted_'+browserAssetId+'.'+imageName+'">';
			}else{
				icon += '<image class="ui  image mediumIconImageStyle" src="/repopro/assetImages/'+browserAssetId+'.'+imageName+'">';
			}
		}
		
		
	}
	

	appendData += '<div>'+icon+'</div><a style="cursor: pointer; margin-left: 1.5em; vertical-align: -moz-middle-with-baseline;vertical-align: -webkit-baseline-middle;" class= "whitespaceNoTrim" id="assetInstName_'+assetInstanceVersionId+'" onclick="getAssetInstances('+assetInstanceVersionId+',\''+encodedAssetInstName+'\')" class="gridImageTextSpacing">'+ assetInstName +'</a>';
	
	if(versionable){
		appendData += '<span  style="margin-left: 0.5em; color:#999999;font-size: 12px;vertical-align: -moz-middle-with-baseline;vertical-align: -webkit-baseline-middle;"><i>v<span id="assetInstVersionName_'+assetInstanceVersionId+'">'+versionName+'</span></span>';
	}
	appendData += '</div>';
		
	if(showAivDetails == "`"){
		appendData += '<p class="assetInstVersionStyle"><span id="assetInstId_'+assetInstanceVersionId+'" style="color: #999999 !important; margin-left: 0.9em;">'+assetInstanceVersionId+'</span></p>';
	}
	//souradip 20.12.17
	
	appendData +=  '</td>';	
	
	/*if(showGroupDetails == "~"){
		appendData += '<p style="cursor: pointer;font-size: 12px; padding-left: 4.2em; padding-top: 0.2em;"><a class="sidebarSubMenuItemSize" onclick="openGroupDetailsAssetInstAccessModal('+assetInstanceVersionId+')">Manage Access</a></p></td>';
	}*/
	var hasTableTag = isTableTag(description);
	if(hasTableTag == false){
		//console.log(" hasTableTag "+hasTableTag);
		appendData += '<td class="six wide top aligned">';
	}else{
		appendData += '<td class="six wide top aligned">';
	}
	
	if(description == null){
		description = "";
	}
	appendData += '<div id="assetInstDescription" style="max-height: 15em;overflow: auto;">'+description+'</div></td>';
	if(paramNameWithValues == "No Data"){
		appendData += '<td class="five wide top aligned"></td>';
	}
	else{
		appendData += '<td class="five wide top aligned " style="padding-top: 1.5em !important;"><div style="overflow: auto;"><span id="firstThreeParamNameWithValues_'+assetInstanceVersionId+'">'+paramNameWithValues+'</span>';
		appendData += '<div id="showMoreData_'+assetInstanceVersionId+'" style="display: none; margin-top:0.8em;"></div>';
		if(showHideParamCount > 3){
			appendData += '<p style="cursor: pointer;"><a id="showHideMoreData_'+assetInstanceVersionId+'" onclick="showMoreParam('+assetInstanceVersionId+',\''+encodedAssetInstName+'\')">'; 
			appendData += '<span class="sidebarSubMenuItemSize">Show more <i class="chevron right small icon"></i></span>'; 
			appendData += '<span class="sidebarSubMenuItemSize" style="display: none;">Hide<i class="chevron left small icon"></i></span></a></p>';
		}
		appendData += '</div></td>';
	}
	
	
	if(showGroupDetails == "~"){
		var data = '';
		//chandana - Adding checkbox in the table header
		var bulkdata = '';
		var ManagebulkAccess = '';
		bulkdata += '<div class="ui mini negative message" style="width: 35%; margin: 1em 0em 0em 40em;text-align: center;" id="showMessageOnSelectCheckbox"><i class="close icon" onclick="closeMessage()"></i><div class="header"> All <span id="numberOfInstances"> </span>  /  <span id="totalNumOfInstances">'+getCountofInstances+' </span>  instances are selected.</div></div> '
		//bulkdata += '<div class="sub header" onclick = "selecAllforBulkAccess('+assetInstanceVersionId+')"><i class="right clone outline icon"></i>Select all <span id="countOfInstances">'+getCountofInstances+' </span> instances of <span id="assetNameBulkAccess"> </span></div>';
		ManagebulkAccess +='<a class="ui" onclick ="manageAllSelectedAccess()" style="cursor: pointer;"><i class="right edit icon"></i> Manage Access for selected</a>';
		
		$('.ManagebulkAccess').html(ManagebulkAccess)
		$('#MessageBox').html(bulkdata);
		
		//$('#countOfInstances').html(getCountofInstances)
		
		//bulkdata +='<div style="margin: -3em 26em -3.5em 1em">	<h5 class="ui header bulkAccessHeader"><span><i class="clone outline icon"></i></span><div class="content" onclick = "selecAllforBulkAccess('+assetInstanceVersionId+')";>Select all </div><span style="float: right;margin: -1.5em 1em;margin-top:0.1em";><i class="edit icon"></i><div class="content" onclick = "";>Manage Access for selected</div></span></h5></div>'
		data += '<tr><th class="one wide" id=""><div class="ui checkbox"><input type="checkbox" id="selectAllInstancesCheckbox" name="selectallcheckbox" class="selectAllCheckBox" onclick = "selecAllforBulkAccess('+assetInstanceVersionId+')"><label></label></div></th>';
		data += '<th class="four wide" style="padding-left: 44px;" id="browserAssetNameHeader"></th>';
		data += '<th class="five wide">Overview</th>';
		data += '<th class="four wide">Properties</th>';
		data += '<th class="one wide" id="showManageAccess">Manage Access</th>';
		data += '<th class="one wide" id="browserDeleteHeader">Delete</th></tr>';
		
		
		$("#browseTableHeaderTr").html(data);
		data = '';
		//Swathi -  code to disable edit icon on scroll- 27-09-2019
		if(selectAllFlagChecked == true){
			appendData += '<td class="one wide top aligned"><span><i class="edit icon deleteEditIcon editManageAccess disableEdit" onclick="openGroupDetailsAssetInstAccessModal('+assetInstanceVersionId+')"></i></span></td>';
		}
		else if($('.bulkAccess:checked').length >= 1){			
			appendData += '<td class="one wide top aligned"><span><i class="edit icon deleteEditIcon editManageAccess disableEdit" onclick="openGroupDetailsAssetInstAccessModal('+assetInstanceVersionId+')"></i></span></td>';
		}else {
			
			appendData += '<td class="one wide top aligned"><span><i class="edit icon deleteEditIcon editManageAccess" onclick="openGroupDetailsAssetInstAccessModal('+assetInstanceVersionId+')"></i></span></td>';
		}
	}else{
		var data = '';
		data += '<tr><th class="four wide" style="padding-left: 44px;" id="browserAssetNameHeader"></th>';
		data += '<th class="five wide">Overview</th>';
		data += '<th class="five wide">Properties</th>';
		data += '<th class="one wide" id="browserDeleteHeader">Delete</th></tr>';
		
		$("#browseTableHeaderTr").html(data);
		data = '';
	}
	$("#browserAssetNameHeader").html(browserAssetName);

	if(deleteAccessFlag){
		//console.log('true')
		var assetInstanceName1 = assetInstName.replace(/\"/g, "");
		appendData += '<td class="one wide top aligned"><a><i class="trash icon deleteEditIcon" id="trash_'+assetInstanceVersionId+'" data-html="'+data1+'" onclick="openDeleteAssetPopup('+assetInstanceVersionId+',\''+assetInstanceName1+'\')"></i></a></td>';
	}
	else {
		//console.log('false')
		appendData += '<td class="one wide top aligned disabled"><span><i class="trash icon" id="trash_'+assetInstanceVersionId+'"></i></span></td>';
	}
	
	appendData += '</tr>';
	// Swathi - code to get count 
	if(selectAllFlagChecked == true ){	
		
		if(individualCheckFlag == true) {
			 var numberofUnchecked = $(".bulkAccess:not(:checked)").length;
			 numberOfChecked = getCountofInstances - numberofUnchecked;
			 $('#numberOfInstances').text(numberOfChecked);			 
		} else {
			$('#selectAllInstancesCheckbox').attr('checked','checked');
			$('#numberOfInstances').text(getCountofInstances);
		}
		
	} else {
		 var numberOfChecked = $('.bulkAccess:checked').length;			 
		 $('#numberOfInstances').text(numberOfChecked);
	}

	return appendData;
}

//SOC bulk access
//Chandana - 17-9-2019 (Check box selection)

function selecAllforBulkAccess (assetInstanceVersionId){
	 $('.bulkAccess').prop("checked", true);
	 $(".bulkAccess").click(function(){

			if($(".bulkAccess").length == $(".bulkAccess:checked").length) {
				$(".selectAllCheckBox").attr("checked", "checked");
			} else {
				$(".selectAllCheckBox").removeAttr("checked");
			}

		});
	 if($('.selectAllCheckBox').prop("checked") == false) {
		  $('.bulkAccess:checkbox').attr('checked',false);
		  $('.ManagebulkAccess').addClass('disableEdit');
		  $('.editManageAccess').removeClass('disableEdit');
		  countOnNoButton = true;
		  selectAllFlagChecked = false;
	}
	 if ($('.bulkAccess:checked').length == $('.bulkAccess').length) {
			$('.ManagebulkAccess ').removeClass('disableEdit');
			$('.editManageAccess').addClass('disableEdit');
			$('#exportToExcelIcon').hide();
			$('#menu-twitter').hide();
			$('#openConfirmationofSelectAllModal').modal('setting', 'closable', false).modal('show');
			$('#showInsCount').text(getCountofInstances);
			$("#showAssetNameonConfirmModal").text(browserAssetName);
			$("#getAssetNameonConfirm").text(browserAssetName);
		}else{
			 $('.bulkAccess').prop("checked", false);
			$('#exportToExcelIcon').show();
			$('#menu-twitter').show();
			$('.editManageAccess').removeClass('disableEdit');
			$('#MessageBox').hide();
		}
	 

}
//Checkbox enable and disable - Chandana - 23-09-2019
function checkSelectAllUserInBrowseBulk(obj)
{
	 $('#numberOfInstances').text('');
	if (false == $(obj).prop('checked')) {
		$(".selectAllCheckBox").prop('checked', false);
		individualCheckFlag = true;
	}
	if ($('.bulkAccess:checked').length == $('.bulkAccess').length) {
		$(".selectAllCheckBox").prop('checked', true);
		$('#openConfirmationofSelectAllModal').modal('setting', 'closable', false).modal('show');
		$('#showInsCount').text(getCountofInstances);
		$("#showAssetNameonConfirmModal").text(browserAssetName);
		$('.editManageAccess').addClass('disableEdit');
	}else{
		$('#exportToExcelIcon').show();
		$('#menu-twitter').show();
		$('.editManageAccess').removeClass('disableEdit');
	}
	
	// Enable the Manage bulk access if more than one checkboxes are checked - Chandana - 23-09-2019
	 var numberOfChecked = $('.bulkAccess:checked').length;	
	 if(numberOfChecked >= 1){
		 $('#exportToExcelIcon').hide();		 
		 $('#menu-twitter').hide();
		 $('.ManagebulkAccess').removeClass('disableEdit');
		 $('.editManageAccess').addClass('disableEdit');
		 $('#MessageBox').show();			 
	 }
	 else if(numberOfChecked < 1){
		 $('.ManagebulkAccess').addClass('disableEdit');
		 $('#MessageBox').hide();// Swathi- Bug fix- REPO-726
	 }
	 // Swathi- Code for counting number of unchecked checkbox - 26-09-2019
	 if(countOnNoButton == true) {
		 var numberOfChecked = $('.bulkAccess:checked').length;			 
		 $('#numberOfInstances').text(numberOfChecked);
	 } else {
		 var numberofUnchecked = $(".bulkAccess:not(:checked)").length;
		 if(numberofUnchecked >=1) {
			 $(".bulkAccess:checkbox:not(:checked)").each(function() {
			      numberOfChecked = getCountofInstances - numberofUnchecked;
			      $('#numberOfInstances').text(numberOfChecked);
			 }); 
		 }
	 }
};


// Manage access modal for select all checkbox - - chandana-18-09-2019
function manageAllSelectedAccess(allCheckedIds){
	setTimeout(function(){ 
		$('#showHideLoader').addClass('active');
	}, 1000);
	$('#MessageBox').hide();
    $('#openConfirmationofSelectAllModal').modal('destroy'); //Closing confirmation modal
    //$('#ShowManageAccessforSelectAll').unbind();
	$('#btnsubmitAssetInstanceAccess').unbind();
	$('#btncancelAssetInstanceAccess').unbind();
	$('#openShowGrpAssetInstanceAccessModal').modal('destroy');
	$('#openShowGrpAssetInstanceAccessModal').modal('setting', 'closable', false).modal('show').modal('refresh');
	$("#openShowGrpAssetInstanceAccessModalInstanceName").text(browserAssetName);
	
	var checkboxlength = $('.bulkAccess:checked').length;
	
	//on cancel uncheck checked checkboxes (modal close) -  Chandana - 23-09-2019
	
	$('#btncancelAssetInstanceAccess').click(function(){
		$('.bulkAccess').prop('checked', false);
		$('.editManageAccess').removeClass('disableEdit');
		countOnNoButton = true;
		countOnNoSearchButton = true;
	});
	var allCheckedIds = [];
	var allUncheckarray = [];
	//var uncheckedCheckBoxLength = $(".bulkAccess:not(:checked)").length;
	
	//Swathi - 13.11.2019--execute follow function only when selectall flag is true
	if(selectAllFlagChecked == true){
		if($('.selectAllCheckBox').prop("checked") == true) { // when all checkboxes are checked- Chandana
			 allCheckedIds = JSON.parse('['+getAIVids+']');				
		} else  { // when one of the checkbox is unchecked after selecting SelctAll checkobx
			$(".bulkAccess:not(:checked)").each(function() {
				 if ($(this).prop('checked')== false){ 
		          var getUncheckedIds =  $(this).attr("id");
		          getUncheckedIds = getUncheckedIds.split('_');
		          getUncheckedIds = getUncheckedIds[1];
		          allUncheckarray.push(getUncheckedIds)
		        }	       
		    });
			var tempIds = JSON.parse("[" + getAIVids + "]");
			for (var i = 0; i< tempIds.length; i++) {
				for (var j = 0; j <= allUncheckarray.length; j++) {
					if (tempIds[i] == allUncheckarray[j]) {
					tempIds.splice(i, 1);
					}
				}
			}
			allCheckedIds = JSON.parse('['+tempIds+']');
		}
		
	} else {// chandana -- normal scenario when multiple checkboxes are checked
		 $(".bulkAccess:checkbox").each(function() {
		        if ($(this).is(":checked")) {
		          var getIds =  $(this).attr("id");
		          getIds = getIds.split('_');
		          allCheckedIds.push(getIds[1]);
		        } 		       
		    });
	}	
	
    //Call to construct table - Chandana - 23-09-2019
    var groupIdList = [];
   //alert("length" + allCheckedIds.length +"------"+allCheckedIds);
	$.ajax({ 
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/viewGroupsWithMultipleAIAccess?aivId="+allCheckedIds,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){				
				setTimeout(function(){ 
					$('#showHideLoader').removeClass('active');
				}, 1000);				
				$("#gridAssetInstanceAccess table tbody").html("");
				$.each(json.result, function(i) {
					groupIdList.push(json.result[i].groupId);
					var getAssetInstanceAccessData = loadAssetInstanceAccessData(json.result[i].groupId, json.result[i].groupName, json.result[i].editAccess, json.result[i].viewAccess, json.result[i].deleteAccess);
					$("#gridAssetInstanceAccess table tbody").append(getAssetInstanceAccessData);
				});
			}
		}
	});

	//table edit - swathi 23-09-2019
    $('#gridAssetInstanceAccess table tbody tr').each(function(i){

		var $tds = $(this).find('td'),
		groupId = $tds.eq(0).attr("id"),
		groupId = groupId.split("_")[1];
		groupId = parseInt(groupId);

		$('input[id=editCB_'+groupId+']').on('click',function(){
			$('input[id=viewCB_'+groupId+']').prop("checked", true );
		});
		$('input[id=viewCB_'+groupId+']').on('click',function(){
			if(!$('input[id=viewCB_'+groupId+']').is(':checked')){
				$('input[id=editCB_'+groupId+']').prop("checked", false );
				$('input[id=deleteCB_'+groupId+']').prop("checked", false );
			}
		});
		$('input[id=deleteCB_'+groupId+']').on('click',function(){
			$('input[id=viewCB_'+groupId+']').prop("checked", true );
		});
	});
    
    
 // Save Button on the Modal - swathi
    var groupWiseArr = [];
    $("#btnsubmitAssetInstanceAccess").on('click', function(){
    groupWiseArr.length = 0;
    $.each(groupIdList,function(i){
    var editFlag , viewFlag , deleteFlag;
    if($("#editCB_"+groupIdList[i]).prop("checked")){
    editFlag = 1;
    }else{
    editFlag = 0;
    }

    if($("#viewCB_"+groupIdList[i]).prop("checked")){
    viewFlag = 1;
    }else{
    viewFlag = 0;
    }
    if($("#deleteCB_"+groupIdList[i]).prop("checked")){
    deleteFlag = 1;
    }else{
    deleteFlag = 0;
    }
    groupWiseArr.push({"aivIds":allCheckedIds,"groupId":groupIdList[i],"editAccess":editFlag,"viewAccess":viewFlag,"deleteAccess":deleteFlag});
    });
    $.ajax({
    type: "PUT",
    url: "/repopro/web/assetInstanceVersionManager/saveGroupsAccessMultipleAISubmit",
    contentType : "application/json",
    dataType : "json",
    data : JSON.stringify(groupWiseArr),
    async: false,
    complete:function(data){	
    appenddata = "";
    var json = JSON.parse(data.responseText);
    if(json.status == "SUCCESS"){
    notifyMessage("Update Asset Instance Access","Asset Instance Access Updated","success");
    $('#openShowGrpAssetInstanceAccessModal').dimmer('hide').modal('hide others').modal('hide'); 
    }
    else {
    notifyMessage("Update Asset Instance Access",json.message,"fail");
    }
    }

    });	
    //Default state - chandana
    $('.editManageAccess').removeClass('disableEdit');
	$('.bulkAccess').prop('checked', false);
	$('#exportToExcelIcon').show();
	$(".selectAllCheckBox").removeAttr("checked");
	$('.ManagebulkAccess').addClass('disableEdit');
	// swathi- scroll default state- 27-09-2019
	selectAllFlagChecked = false;
	countOnNoButton = true;
	$('#menu-twitter').show();// Swathi
    });
    
  //Manage access modal on close - Chandana
    $('#btncancelAssetInstanceAccess').click(function(){
      	//$('#ShowManageAccessforSelectAll').unbind();
    	$('#openConfirmationofSelectAllModal').modal('destroy'); //Closing confirmation modal
  
    	$('.editManageAccess').removeClass('disableEdit');
    	$('.bulkAccess').prop('checked', false);
    	$('#exportToExcelIcon').show();
    	$(".selectAllCheckBox").removeAttr("checked");
    	$('.ManagebulkAccess').addClass('disableEdit');
    	// swathi- scroll default state- 27-09-2019
    	selectAllFlagChecked = false;
    	countOnNoButton = true;
    	countOnNoSearchButton = true;
    	$('#menu-twitter').show();// Swathi- Bug fix REPO-715
    	
    });
}



//Show Manage access modal on confirmation - 20-9-2019
var selectAllFlagChecked = false;
$('#ShowManageAccessforSelectAll').click(function(){
	$('#openConfirmationofSelectAllModal').modal('destroy'); //Closing confirmation modal
	$('#btnsubmitAssetInstanceAccess').unbind();
	$('#btncancelAssetInstanceAccess').unbind();
	$('#openShowGrpAssetInstanceAccessModal').modal('destroy');
	
	$('.ManagebulkAccess').removeClass('disableEdit');
	$('#exportToExcelIcon').hide();
	$('#MessageBox').show();
	$('#numberOfInstances').text("");
	$('#numberOfInstances').text(getCountofInstances);
	
	/*if ($('.bulkAccess:checked').length == $('.bulkAccess').length) {
		 $('#numberOfInstances').text(getCountofInstances);
	 }*/
	//Showing instance count - chandana - 23-9-2019
	/*$.ajax({ 
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/getAssetInstanceBrowseGridForTotalCount?userName="+loggedInUserName+"&assetName="+encodeURIComponent(browserAssetName)+"&assetId="+browserAssetId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				var NOI = json.paramValues.count;
				if ($('.bulkAccess:checked').length == $('.bulkAccess').length) {
				$('#totalNumOfInstances').text(NOI);
				$('#numberOfInstances').text(NOI);
				}
			}
		}
	});*/
	
	$("#showAssetNameonConfirmModal").text(browserAssetName);
	$("#getAssetNameonConfirm").text(browserAssetName);
	selectAllFlagChecked = true;
	countOnNoButton = false;
});

//close message box on click - chandana
function closeMessage(){
	$('#MessageBox').hide();
	};

//Confirmation modal - Cancel to uncheck all checkboxes and close the modal - chandana-18-09-2019
$('#CancelManageAccessforSelectAll').click(function(){
	$('.editManageAccess').removeClass('disableEdit');
	$('.bulkAccess').prop('checked', false);
	$('#exportToExcelIcon').show();
	$(".selectAllCheckBox").removeAttr("checked");
	$('.ManagebulkAccess').addClass('disableEdit');
	$('#MessageBox').hide();
	countOnNoButton = true;
	
});


//for unchecking all checked box on modal close(key press event) - chandana - 18-9-2019
$(document).keydown(function(event) { 
	  if (event.keyCode == 27 && localStorage.getItem("pageName") == 'browser') { 
		  if($('#openConfirmationofSelectAllModal').is(":visible") || $('#openShowGrpAssetInstanceAccessModal').is(":visible")){
	      $('#openConfirmationofSelectAllModal').hide();
		  $('#openConfirmationofSelectAllModal').modal('destroy');
		  $('.bulkAccess').prop('checked', false);
		  $('.selectAllCheckBox').prop('checked', false);
		  $('.ManagebulkAccess').addClass('disableEdit');
		  $('.editManageAccess').removeClass('disableEdit');
		  $('#exportToExcelIcon').show();
		  $('#menu-twitter').show();
		  $('#MessageBox').hide();
	  }
	  }
	});

// EOD of bulk access

//show more parameter
function showMoreParam(assetInstanceVersionId, assetInstName){
	if(!$("#showMoreData_"+assetInstanceVersionId).hasClass("showData")){
		var userName;

		if(loggedInUserName == "roleAnonymous"){
			userName = "roleAnonymous";
		}
		else{
			userName = loggedInUserName;
		}
		url =  "/repopro/web/assetInstanceVersionManager/getParametersDetailsForAssetInstanceVersion?userName="+userName+"&assetName="+browserAssetName+"&assetId="+browserAssetId+"&assetInstanceVersionId="+assetInstanceVersionId
		//console.log(" showMoreParam url "+url);
		$.ajax({ 
			type : "GET",
			url : "/repopro/web/assetInstanceVersionManager/getParametersDetailsForAssetInstanceVersion?userName="+userName+"&assetName="+browserAssetName+"&assetId="+browserAssetId+"&assetInstanceVersionId="+assetInstanceVersionId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(json.paramValues == "" || json.paramValues == null){
						notifyMessage("Show More Params","empty","fail");
					}
					else{
						var paramNameWithValues = "";
						var repeatingDataCount = $("#firstThreeParamNameWithValues_"+assetInstanceVersionId+"> .instanceParamValuesInGrid").length - 1;
						var count = 0;
						$.each(json.paramValues, function(key,value) {
							if(count>repeatingDataCount){
								var deriveFlag = false;
								var deriveId = "";
								if(value != null){
									if(value.indexOf("^^DA^^") != -1){
									    deriveFlag = true;
									    var data = value.split("~");
									    //console.log(data);
									    var data1  = (data[3]).split("`@`");
									    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
									    getDeriveAttrData(data[1],data1[0]);
									}
									if(value.indexOf("^^DC^^") != -1){
									    deriveFlag = true;
									    var data = value.split("~");
									    var data1  = (data[3]).split("`@`");
									    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
									    getDerivedComputationData(data[1],data1[0]);
									}

									// BOC Hema 14.Mar.2019- Auto Complete
									if(value.indexOf("^^AC^^") != -1){
									    deriveFlag = true;
									    var data = value.split("~");
									    var data1  = (data[3]).split("`@`");
									    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
									    getAutoCompleteData(data[1],data1[0]);
									}
									//EOC
								}
								paramNameWithValues = getParamNameWithValues_showMoreParam(key, value,deriveFlag,deriveId,assetInstanceVersionId,assetInstName);
								$("#showMoreData_"+assetInstanceVersionId).append(paramNameWithValues);
							}
							count++;
						});
					}

				}
				else{
					notifyMessage("Show More Parameters","No more parameters","fail");
				}
			}
		});


	}

	$("#showMoreData_"+assetInstanceVersionId).toggle().addClass("showData");
	$('span','#showHideMoreData_'+assetInstanceVersionId).toggle();	
}

//show or hide the columns based on user choice -------------- Kavya - BOC
function showHideColumnModal(){
	var userId = 1;
	var list = [];
	$('#submitSelectedFields').unbind();
	$('#cancelSelectedFields').unbind();
	$('#showHideColumnsModal').modal('destroy');
	//$('#showHideColumnsModal').modal('setting', 'closable', false).modal('show');
	$('#showHideColumnsModal').modal({observeChanges : true}).modal('show').modal('refresh'); /*Hema 01.Dec.2017*/
	/*url = "http://localhost:8080/repopro/web/showHideColumn/getShowHideColumn?assetId="+browserAssetId+"&userId="+loggedInUserId+"&userName="+loggedInUserName;
	console.log(" url "+url)*/
	$.ajax({
		type : "GET",
		url : "/repopro/web/showHideColumn/getShowHideColumn?assetId="+browserAssetId+"&userId="+loggedInUserId+"&userName="+loggedInUserName,	
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$.each(json.result[0].showParamDetails, function(key,value){
					list.push(value);
				});
			}
		}
	});
	/*urlAll = "http://localhost:8080/repopro/web/showHideColumn/getShowHideColumnList?assetId="+browserAssetId+"&userName="+loggedInUserName;
	console.log(" urlAll "+urlAll)*/
	$.ajax({
		type : "GET",
		url : "/repopro/web/showHideColumn/getShowHideColumnList?assetId="+browserAssetId+"&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				appendData = "";	
				appendData += "<tr>";
				
				if(adminFlag == true){
					if(showGroupDetails == null || showGroupDetails == "" || showGroupDetails == undefined){
						appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllFields(this);' id='grpId_"+browserAssetId+"' type='checkbox' class='browserAppFunction grpDetailsFunction' value='"+showGroupDetails+"'><label><span style='font-size:11px;'>Associated Groups</span></label></div></td>";
					}else{
						appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllFields(this);' id='grpId_"+browserAssetId+"' type='checkbox' class='browserAppFunction grpDetailsFunction' value='"+showGroupDetails+"'  checked='checked'><label><span style='font-size:11px;'>Associated Groups</span></label></div></td>";
					}
				}

				appendData += "</tr>";
				appendData += "<tr>";
				if(loggedInUserName != "roleAnonymous"){
					if(showAivDetails == null || showAivDetails == "" || showAivDetails == undefined){
						appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllFields(this);' type='checkbox' id='aivDetails_"+browserAssetId+"' class='browserAppFunction associateDetailsFunction' value='"+showAivDetails+"'><label><span style='font-size:11px;'>"+browserAssetName+" Id</span></label></div></td>";
					}else{
						appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllFields(this);' type='checkbox' id='aivDetails_"+browserAssetId+"' class='browserAppFunction associateDetailsFunction' value='"+showAivDetails+"'  checked='checked'><label><span style='font-size:11px;'>"+browserAssetName+" Id</span></label></div></td>";
					}
				}
				appendData += "</tr>";
				$.each(json.result[0].showParamDetails, function(key, value){
					appendData += "<tr>";
					appendData += "<td class='hidden' id='showParamDetailsId_"+key+"'>"+key+"</td>";
					
					if ($.inArray(value, list) != -1)
					{	
						//console.log("  value "+value);
						value1 = value.replace(/ /g,"_");
						appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllFields(this);' type='checkbox'  id='browserAppFunctionName_"+key+"' class='browserAppFunction checkParamDetails' value='"+value1+"' checked='checked'><label><span style='font-size:11px;'>"+value+"</span></label></div></td>";
					}
					else{

						value1 = value.replace(/ /g,"_");
						appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllFields(this);' type='checkbox'  id='browserAppFunctionName_"+key+"' class='browserAppFunction checkParamDetails' value='"+value1+"'><label><span style='font-size:11px;'>"+value+"</span></label></div></td>";
					}
					appendData += "<td></tr>";
				});
				$("#showHideColumnDropdown").html(appendData);
			}
		}
	});


	if ($('.browserAppFunction:checked').length == $('.browserAppFunction').length){

		$("#selectAllFieldsDisplayed").attr('checked', true);
	}
	else{

		$("#selectAllFieldsDisplayed").attr('checked', false); 
	}

	//suren
	$("#selectAllFieldsDisplayed").on('click', function(r){
		if($(this).is(':checked')){
			$('.browserAppFunction').attr('checked',true);
		}
		else {	
			$('.browserAppFunction').attr('checked',false);
		}
	});

}

//check select all when all check box are checked
function checkSelectAllFields(obj){

	if(false == $(obj).prop('checked')){ 
		$("#selectAllFieldsDisplayed").prop('checked', false); 
		//Swathi- 22-10-2019- Bulk Access
		selectAllFlagChecked = false;
		selectAllOnSearchFlagChecked = false;
		countOnNoButton = true;
		countOnNoSearchButton = true;
		showCheckboxCheckedFlag = true;
	}
	if ($('.browserAppFunction:checked').length == $('.browserAppFunction').length ){
		$("#selectAllFieldsDisplayed").prop('checked', true);
		//Swathi- 22-10-2019- Bulk Access
		selectAllFlagChecked = false;
		selectAllOnSearchFlagChecked = false;
		countOnNoButton = true;
		countOnNoSearchButton = true;
	}
}

//save user selected list of fields to be displayed
var hideManage;
var saveFromShowHide ;
function saveSelectedFields(){
	
	setTimeout(function(){ 
		$('#showHideLoader').addClass('active');
	}, 0);
	
	var arr;
	var value;
	var obj1 = {};
	var obj2 = {};
	var obj3 = {};
	var obj;
	var count_checked = $(".browserAppFunction:checked").length; // count the checked rows

	$.each($("input[class='browserAppFunction checkParamDetails']:checked"), function() {
		var itm = $(this);
		var data = $(this).attr('id');
		var arr = data.split('_')[1];
		var value = $(this).val().trim().replace("_",' ');
		obj1[arr] = value;
	});

	if($('.browserAppFunction.grpDetailsFunction').is(':checked')){
		var data = $('.browserAppFunction.grpDetailsFunction').attr('id');
		var arr = data.split('_')[1];
		var value = "~";
		obj2[arr] = value;
		$('.ManagebulkAccess ').show();
		hideManage =0;
	}else{
		obj2 = {};
		$('.ManagebulkAccess ').hide();
		$('#MessageBox').hide();
		hideManage =1;
	}

	if($('.browserAppFunction.associateDetailsFunction').is(':checked')){
		var data = $('.browserAppFunction.associateDetailsFunction').attr('id');
		var arr = data.split('_')[1];
		var value = "`";
		obj3[arr] = value;
	}else{
		obj3 = {};
	}


	obj = {
			"assetId":browserAssetId,
			"showAivDetails": obj3,
			"showGroupDetails": obj2,
			"showParamDetails": obj1,     
			"userId": loggedInUserId
	}
//	$('#showHideLoader').removeClass('active');
	//console.log("obj "+JSON.stringify(obj));
	$.ajax({
		type : "POST",
		url : "/repopro/web/showHideColumn/addShowHideColumnList",
		contentType : "application/json",
		Accept : "application/json",
		dataType : "json",
		async : false,
		data : JSON.stringify(obj),
		complete : function(data) {		

			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				
				setTimeout(function(){ 
					$('#showHideLoader').removeClass('active');
				}, 1500);
				notifyMessage("Show / Hide","Show/Hide settings updated","success");
				
			}
			else{
				
				setTimeout(function(){ 
					$('#showHideLoader').removeClass('active');
				}, 2000);
				
				notifyMessage("Show / Hide",json.message,"fail")
			}
			$('#showHideColumnsModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
			$('#showHideColumnsModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
			$("html, body").animate({scrollTop: 0}, 10);
			if(applyShowHide == false){				
				formRange = 0;
				countNoOfData = 0;
				$("#browseTable").html("");
				$("#browseTable").html('<thead id="browseTableHeaderTr" class="browseTableHeaderTr"><tr><th class="four wide" style="padding-left: 52px;" id="browserAssetNameHeader">'+browserAssetName+'</th><th class="six wide">Overview</th><th class="five wide">Properties</th><th class="one wide" id="browserDeleteHeader">Delete</th></tr></thead>');
				if(filterSearchForApply == true){
					getAivGroupDetails();
				}
				else{
					if($('#grpId_'+browserAssetId).is(':checked')){
						showGroupDetails = "~";
					}
					else {	
						
						showGroupDetails = "";
					}
					if($('#aivDetails_'+browserAssetId).is(':checked')){
						showAivDetails = "`";
					}
					else {	
						showAivDetails = "";
					}
					
					saveFromShowHide = true;
					browseGridFilteredData();
				}
				
			}
			else{
				if($('#grpId_'+browserAssetId).is(':checked')){
					showGroupDetails = "~";
				}
				else {	
					showGroupDetails = "";
				}
				if($('#aivDetails_'+browserAssetId).is(':checked')){
					showAivDetails = "`";
				}
				else {	
					showAivDetails = "";
				}
				if(filterSearchForApply == false){
					setCountAndRangeValue();
				}else{
					saveFromShowHide = true;
					browseGridFilteredData_applyFilter();
				}
				
			}
			
			
		}
	});
	//$('#filterBrowseGridInputField').val('');
}
//dynamically load asset param list
var ddAppendParameters;
var listofParamArray = [];
function showParamLoader(){	
	//listofParamArray.length = 0;
	url = "http://localhost:8080/repopro/web/assetType/getParamList?assetId="+browserAssetId+"&userName="+loggedInUserName;
	//console.log("showParamLoader url "+url)
	ddAppendParameters = "";
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetType/getParamList?assetId="+browserAssetId+"&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$.each(json.result, function(i){
					if(json.result[i].hasStaticValue != true){
						if(json.result[i].paramTypeId != "5" && json.result[i].paramTypeId != "6" && json.result[i].paramTypeId != "8"){
							listofParamArray.push(json.result[i].assetParamName);
							ddAppendParameters += '<option value="'+ json.result[i].assetParamId +'" class="'+json.result[i].typeName+'" id="'+json.result[i].assetParamId+'_'+json.result[i].typeName+'_'+json.result[i].listTypeParamTypeId+'" data-typeName="'+json.result[i].listTypeName+'" data-mapId="'+json.result[i].mappedAssetId+'">'+ json.result[i].assetParamName +'</option>';	 
						}
					}
				});
			}
		}
	});
}

function createRow(){
	var newRowContent;
	newRowContent += '<tr style="outline: thin solid lightgrey" id="rowDataId_0"><td class="popuptabletr ddFilterParamSelector" style="vertical-align:top;">';
	newRowContent += '<select class="ui dropdown" id="filterDropdownValues_0" onchange="ddFilterParameter(this);" style="min-width: 10em;">';
	newRowContent += '<option value="selectParam">[Select Parameter]</option>';	
	newRowContent += '</select></td>';
	
	//operator dropdown
	newRowContent += '<td class="popuptabletr ddOptionSelector" style="vertical-align:top;">';
	newRowContent += '<select class="ui dropdown dropdownCssForFilter" id="opertorDropdownValues_0" onchange="showBetweenInputs(this);">';
	newRowContent += '</select></td>';
	


	//Text
	newRowContent += '<td class="popuptabletr inputValueSelector" id="inputFilterText_0" style="display: none;vertical-align:top;">';
	newRowContent += '<div class="ui input focus" style="width: 195px;">';
	newRowContent += '<input type="text" id="inputTextField_0" placeholder="Enter Text" class="customizeTextBox">';
	newRowContent += '</div>';
	newRowContent += '<div id="dynamicDataBetween_0" style="display: none;margin-left: 1.85em;">';
	newRowContent += '<span>and</span>';
	newRowContent += '<div class="ui input focus" style="width: 195px;margin-left: 2em;">';
	newRowContent += '<input type="text" id="inputBetweenField_0" placeholder="Enter Text" class="customizeTextBox">';
	newRowContent += '</div></div></td>';

	//Date
	newRowContent += '<td class="popuptabletr inputDateSelector" id="inputDate_0" style="display: none;vertical-align:top;">';
	newRowContent += '<div class="ui input focus datePickerCssForFirefox" style="  width: 195px;">';
	newRowContent += '<input type="text" id="inputTextDate_0" placeholder="Select Date" readonly="true" class="customizeDateBox"></div>';
	newRowContent += '<div id="dynamicDateBetween_0" style="display: none;margin-left: 2em;">';
	newRowContent += '<span>and</span>';
	newRowContent += '<div class="ui input focus datePickerCssForFirefox" style="width: 195px;margin-left: 2em;">';
	newRowContent += '<input type="text" id="inputBetweenDate_0" placeholder="Select Date" readonly="true" class="customizeDateBox">';
	newRowContent += '</div>';
	newRowContent += '</div></td>';

	// List 
	newRowContent += '<td id="dropdownInput_0" class="popuptabletr ddParamValueSelector" style="display: none;vertical-align:top;">';
	newRowContent += '<select class="ui dropdown" id="ddListParamValue_0" style="width: 10em;">';
	newRowContent += '</select></td>';
	
	//Ldap 
	newRowContent += '<td class="popuptabletr inputLdapTextSelector" id="inputLdapText_0" style="display: none;vertical-align:top;">';
	newRowContent += '<div class="ui input focus" style="width: 160px;">';
	newRowContent += '<input type="text" id="inputLdapTextField_0" placeholder="Enter Text" class="customizeTextBox">';
	newRowContent += '</div></td>';
	
	// File
	newRowContent += '<td class="popuptabletr fileSelector" id="fileInput_0" style="display: none;vertical-align:top;">';
	newRowContent += '<div class="ui input focus"  style="width: 100px;margin-left: 2em;">';
	newRowContent += '<input type="text" id="inputFile_0" placeholder="File Type">';
	newRowContent += '</div></td>';
	
	//Rich text
	newRowContent += '<td class="popuptabletr inputRichTextSelector" id="inputRichText_0" style="display: none;vertical-align:top;">';
	newRowContent += '<div class="ui input focus" style="width: 160px;">';
	newRowContent += '<input type="text" id="inputRichTextField_0" placeholder="Enter Text" class="customizeTextBox">';
	newRowContent += '</div></td>';
	
	//BOC Hema 07.Mar.2019 Ldap Mapping
	newRowContent += '<td class="popuptabletr inputLdapMappingTextSelector" id="inputLdapMappingText_0" style="display: none;vertical-align:top;">';
	newRowContent += '<div class="ui input focus" style="width: 160px;">';
	newRowContent += '<input type="text" id="inputLdapMappingTextField_0" placeholder="Enter Text" class="customizeTextBox">';
	newRowContent += '</div></td>';
	//EOC
	
	
	newRowContent += '<td class="popuptabletr posRemoveIcon" style="vertical-align:top;"><i class="remove icon" onclick="deleteFilterParameter(this)" style="cursor: pointer;"></i></td></tr>';
	$("#tbl_SelectFilterParam tbody").append(newRowContent);
	showParamLoader();
	$('#filterDropdownValues_0').empty();
	$('#filterDropdownValues_0').append('<option value="Select Parameter" id="Select Parameter">[Select Parameter]</option>');
	$('#filterDropdownValues_0').append(ddAppendParameters);
	$('.ui.dropdown').dropdown();
}

//var ddAppendParameters = "";
//create filter modal
function createFilterModal(){
	$('#createFilterParams').modal('destroy');
	 $('#btnCancelFilter').unbind();
	/*$('#createFilterParams').modal('setting', 'closable', false).modal('show');*/
	$('#createFilterParams').modal({observeChanges : true}).modal('show').modal('refresh');
	if(loggedInUserName == "roleAnonymous"){
		$("#displaySaveFilter").hide();
		$("#btnSaveFilter").hide();
	}
	else{
		$("#displaySaveFilter").show();
		$("#btnSaveFilter").show();
	}
	//$('#createFilterParams').addClass("visible active");
	$("#hiddenSaveFilter").hide();
	$("#savedFilterDiv").hide();
	$("#inputFilterSelector").hide();
	$("#noBrowserData").hide();
	
	
	refreshTable();
	//$("#noBrowserData").hide();
	/*onloadDisplaySaveFilters();
	$('#savedFilterdd').html("");
	$('#savedFilterdd').append(ddloadSavedFilterName);*/
	
}



//onclick on plus btn dynamically add row
function addFilterParameter(){
	count++;
	appendData = "";
	appendData += '<tr id="rowOperatorId_'+count+'"><td class="andOrPara popuptabletr"><select class="ui dropdown dropdownCssForFilter">';
	appendData += '<option value="And">And</option>';
	appendData += '<option value="Or">Or</option>';
	appendData += '</select></td></tr>';
	appendData += '<tr id="rowDataId_'+count+'">';
	appendData += '<td class="popuptabletr ddFilterParamSelector" style="vertical-align:top;">';
	appendData += '<select class="ui dropdown"  id="filterDropdownValues_'+count+'" onchange="ddFilterParameter(this);" style="min-width: 10em;">';
	appendData += '<option value="selectParam">[Select Parameter]</option>';	 
	appendData += '</td>';
	
	//operator dropdown
	appendData += '<td class="popuptabletr ddOptionSelector" style="vertical-align:top;">';
	appendData += '<select class="ui dropdown dropdownCssForFilter" id="opertorDropdownValues_'+count+'" style="min-width: 10em;" onchange="showBetweenInputs(this);">';
	appendData += '</select></td>';

	
	// textBox
	appendData += '<td class="popuptabletr inputValueSelector" id="inputFilterText_'+count+'" style="display: none;vertical-align:top;">';
	appendData += '<div class="ui input focus" style="width: 195px;">';
	appendData += '<input type="text" id="inputTextField_'+count+'" placeholder="Enter Text" class="customizeTextBox">';
	appendData += '</div>';
	appendData += '<div id="dynamicDataBetween_'+count+'" style="display: none;margin-left: 1.85em;">';
	appendData += '<span>and</span>';
	appendData += '<div class="ui input focus" style="width: 195px;margin-left: 2em;">';
	appendData += '<input type="text" id="inputBetweenField_'+count+'" placeholder="Enter Text" class="customizeTextBox">';
	appendData += '</div></div></td>';

	// Date
	appendData += '<td class="popuptabletr inputDateSelector" id="inputDate_'+count+'" style="display: none;vertical-align:top;">';
	appendData += '<div class="ui input focus" style="  width: 195px;">';
	appendData += '<input type="text" id="inputTextDate_'+count+'" placeholder="Select Date" readonly="true" class="customizeDateBox"></div>';
	appendData += '<div id="dynamicDateBetween_'+count+'" style="display: none;margin-left: 2em;">';
	appendData += '<span>and</span>';
	appendData += '<div class="ui input focus" style="width: 195px;margin-left: 2em;">';
	appendData += '<input type="text" id="inputBetweenDate_'+count+'" placeholder="Select Date" readonly="true" class="customizeDateBox"></i>';
	appendData += '</div>';
	appendData += '</div></td>';
	
	// List
	appendData += '<td class="popuptabletr ddParamValueSelector" style="display: none;vertical-align:top;" id="dropdownInput_'+count+'">';
	appendData += '<select class="ui dropdown" id="ddListParamValue_'+count+'" style="width: 10em;">';
	appendData += '</select></td>';
	
	//Ldap
	appendData += '<td class="popuptabletr inputLdapTextSelector" id="inputLdapText_'+count+'" style="display: none;vertical-align:top;">';
	appendData += '<div class="ui input focus" style="width: 160px;">';
	appendData += '<input type="text" id="inputLdapTextField_'+count+'" placeholder="Enter Text" class="customizeTextBox">';
	appendData += '</div></td>';
	
	
	// File
	appendData += '<td class="popuptabletr fileSelector" id="fileInput_'+count+'" style="display: none;vertical-align:top;">';
	appendData += '<div class="ui input focus"  style="width: 100px;margin-left: 2em;">';
	appendData += '<input type="text" id="inputFile_'+count+'" placeholder="File Type">';
	appendData += '</div></td>';
	
	//Rich text
	appendData += '<td class="popuptabletr inputRichTextSelector" id="inputRichText_'+count+'" style="display: none;vertical-align:top;">';
	appendData += '<div class="ui input focus" style="width: 160px;">';
	appendData += '<input type="text" id="inputRichTextField_'+count+'" placeholder="Enter Text" class="customizeTextBox">';
	appendData += '</div></td>';
	
	//BOC Hema 07.Mar.2019 Ldap Mapping
	appendData += '<td class="popuptabletr inputLdapMappingTextSelector" id="inputLdapMappingText_'+count+'" style="display: none;vertical-align:top;">';
	appendData += '<div class="ui input focus" style="width: 160px;">';
	appendData += '<input type="text" id="inputLdapMappingTextField_0" placeholder="Enter Text" class="customizeTextBox">';
	appendData += '</div></td>';
	//EOC
	
	appendData += '<td class="popuptabletr posRemoveIcon" style="vertical-align:top;"><i class="remove icon" onclick="deleteFilterParameter(this)" style="cursor: pointer;"></i></td>';
	appendData += '</tr>'; 
	$('#tbl_SelectFilterParam tbody').append(appendData);
	showParamLoader();
	$('#filterDropdownValues_'+count).append(ddAppendParameters);
	/*ddAppendParameters = "";*/
	$('.ui.dropdown').dropdown();
}

//delete the next and that particular row
function deleteFilterParameter(obj){
	var rowLen = $("#tbl_SelectFilterParam tbody tr").length;
	if ((rowLen <= 1)) {
		notifyMessage("Delete Filter","Please provide at least one filtering criterion","failure");
	}
	else if($(obj).closest('tr').is(':first-child')){
		$(obj).closest('tr').next().remove();
		$(obj).closest('tr').remove();
	}	
	else {
		$(obj).closest('tr').prev().remove();
		$(obj).closest('tr').remove();
	}
} 
var ddAppendAssetParametersList = "";
var firstParamValue;
var listDropdownData = [];
//load the asset param list based on asset param name
function paramListLoader(id,assetParamName,paramListTypeName,mapId){
	listDropdownData.length = 0;
	ddAppendAssetParametersList = "";
	paramLoader =  "/repopro/web/assetType/getFilterList?assetName="+browserAssetName+"&paramName="+assetParamName+"&listName="+paramListTypeName+"&userName="+loggedInUserName+"&MappedAssetId="+mapId;
	//console.log("http://localhost:8080"+paramLoader);
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetType/getFilterList?assetName="+browserAssetName+"&paramName="+assetParamName+"&listName="+paramListTypeName+"&userName="+loggedInUserName+"&MappedAssetId="+mapId,
		dataType : "json",
		async: false,
		complete : function(data) {
			
			var json = JSON.parse(data.responseText);
			
			if(json.status == "SUCCESS"){
				/*if(json.result == "" || json.result == null){
					alert(" asset instance does  not have access");
				}
				else{*/
				//console.log(JSON.stringify(json.result));
				if(JSON.stringify(json.result) != "[]"){
					$.each(json.result, function(i){
						firstParamValue = json.result[0].paramValue;
						/*var listDDValue = json.result[i].paramValue;*/
						var value = json.result[i].paramValue;
						listDropdownData.push(value);
						ddAppendAssetParametersList += '<option value="'+ encodeURIComponent(value) +'">'+ value +'</option>';	 
					});
				}else{
					firstParamValue = "";
				}
				/*}*/
				
			}
			//console.log("listDropdownData "+JSON.stringify(listDropdownData));
		}
	});
}

//static create text box, list  and date
function ddFilterParameter(obj){
	var data = $(obj).closest('tr').attr('id');
	res = data.split('_')[1];
	assetParamName = $(obj).children(':selected').text();
	assetParamId = $(obj).children(':selected').val();
	paramListTypeName = $(obj).children(':selected').attr('data-typeName');
	paramTypeName = $(obj).children(':selected').attr('class');
	mapId = $(obj).children(':selected').attr('data-mapid');
	
	
	$('#inputFilterText_'+res).removeClass("textBoxValue");
	$('#inputDate_'+res).removeClass("dateBoxValue");
	$('#fileInput_'+res).removeClass("fileValue");
	$('#dropdownInput_'+res).removeClass("dropDownList");
	$('#inputRichText_'+res).removeClass("richTextValue");
	$('#inputLdapText_'+res).removeClass('ldapText');
	$('#inputLdapMappingText_'+res).removeClass('ldapMappingText'); // added Hema 07.Mar.2019
	
	$("#inputTextField_"+res).val('');
	$("#inputBetweenField_"+res).val('');
	$("#inputTextDate_"+res).val('');
	$("#inputBetweenDate_"+res).val('');
	$('#inputLdapTextField_'+res).val('');
	$('#inputRichTextField_'+res).val('');
	$('#inputLdapMappingTextField_'+res).val(''); // added Hema 07.Mar.2019
	
	$('#opertorDropdownValues_'+res).html('');
	$('#ddListParamValue_'+res).html('');
	
	
	$('#dropdownInput_'+res).css('display','none');
	$('#inputDate_'+res).css('display','none');
	$('#inputFilterText_'+res).css('display','none');
	$('#inputRichText_'+res).css('display','none');
	$('#inputLdapText_'+res).css('display','none');
	$('#dynamicDateBetween_'+res).css('display','none');
	$('#dynamicDataBetween_'+res).css('display','none');
	$('#inputLdapMappingText_'+res).css('display','none'); // added Hema 07.Mar.2019
	
	
	
	
	if(assetParamName == "[Select Parameter]"){
		$('#opertorDropdownValues_'+res).empty();
		$('#opertorDropdownValues_'+res).dropdown('clear');
		//$('#inputFilterText_'+res).css('display','none');
		//$('#inputDate_'+res).css('display','none');
		//$('#dropdownInput_'+res).css('display','none');
		$('#dynamicDataBetween_'+res).css('display','none');
		$('#dynamicDateBetween_'+res).css('display','none');
		
		
	}
	else if (paramTypeName == "list") {
		
		if(paramListTypeName == "ldapuserlist"){
			$('#inputLdapText_'+res).css('display','block');
			$('#dropdownInput_'+res).css('display','none');
			$('#inputLdapText_'+res).addClass('ldapText');
			$('#opertorDropdownValues_'+res).append('<option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#opertorDropdownValues_'+res).dropdown('set selected',"=");
			}, 300);
		}
		else{
			$('#dropdownInput_'+res).css('display','block');
			$('#inputLdapText_'+res).css('display','none');
			$('#dropdownInput_'+res).addClass('dropDownList');
			$('#ddListParamValue_'+res).dropdown('clear');
			$('#opertorDropdownValues_'+res).append('<option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#opertorDropdownValues_'+res).dropdown('set selected',"=");
			}, 300);
			
			paramListLoader(res,assetParamName,paramListTypeName,mapId);
			$('#ddListParamValue_'+res).append(ddAppendAssetParametersList);
			
			setTimeout(function(){
				$('#ddListParamValue_'+res).dropdown('set selected',encodeURIComponent(firstParamValue));
			}, 100);	
		}
		
		
		
	}else if (paramTypeName == "text") {
		
		$('#inputFilterText_'+res).css('display','block');
		$('#inputFilterText_'+res).addClass("textBoxValue");

		$('#opertorDropdownValues_'+res).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option><option value="Between">Between</option>');
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"=");
		}, 300);
		
	}
	else if (paramTypeName == "date") {

		$('#inputDate_'+res).css('display','block');
		$('#inputDate_'+res).addClass("dateBoxValue");

		$('#opertorDropdownValues_'+res).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option><option value="Between">Between</option>');
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"=");
		}, 300);
		
	
		
		$('#inputTextDate_'+res).datepicker({
			showOn: "button",
			buttonImage: "/repopro/semantic/images/icon_calender.png",
			buttonImageOnly: false,
			buttonText: "Select date",
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			/* maxDate: '0',*/
			onClose: function( selectedDate ) {
				/*** Chandana ***/
			$('#inputBetweenDate_'+res).datepicker( "option", "minDate", selectedDate );
			if (event.which === 13) {
        		setCountAndRangeValue()
        		event.preventDefault();
			}
			}
			});
		
			$('#inputBetweenDate_'+res).datepicker({
			showOn: "button",
			buttonImage: "/repopro/semantic/images/icon_calender.png",
			buttonImageOnly: false,
			buttonText: "Select date",
			dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			/* maxDate: '0',*/
			onClose: function( selectedDate ) {
			$('#inputTextDate_'+res).datepicker( "option", "maxDate", selectedDate );
			if (event.which === 13) {
        		setCountAndRangeValue()
        		event.preventDefault();
			}
			}
			});

	
	}else if (paramTypeName == "file") {
		
		$('#fileInput_'+res).addClass("fileValue");
		$('#opertorDropdownValues_'+res).append('<option value="is null">is Empty</option><option value="is not null">is Not Empty</option>');
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"is Empty");
		}, 300);
	
		
	}else if (paramTypeName == "rich text" || paramTypeName == "richtext") {//REPO-722 fix
		$('#inputRichText_'+res).css('display','block');
		$('#inputRichText_'+res).addClass("richTextValue");

		$('#opertorDropdownValues_'+res).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"like");
		}, 300);
	}
	// BOC Hema 07.Mar.2019 ldap mapping show textbox and operator dropdown
	else if(paramTypeName == "ldapmapping") {
		$('#inputLdapMappingText_'+res).css('display','block');
		$('#dropdownInput_'+res).css('display','none');
		$('#inputLdapMappingText_'+res).addClass('ldapMappingText');
		$('#opertorDropdownValues_'+res).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"like");
		}, 300);
	}
	// EOC

}

function showBetweenInputs(obj){

	var data = $(obj).attr('id');
	res = data.split('_')[1];
	var value = $(obj).find(':selected').text();
	var paramFilterID = $(obj).closest('tr').find('td:nth-child(1)').find('select').attr('id');
	var paramTypeName = $('#'+paramFilterID).children(':selected').attr('class');

	if (paramTypeName == "text") {
		if(value == "Between"){
			$("#dynamicDataBetween_"+res).css('display', 'inline-block');
		}else{
			$("#dynamicDataBetween_"+res).hide();
		}
	}
	else if(paramTypeName == "date"){
		if(value == "Between"){
			$("#dynamicDateBetween_"+res).css('display', 'inline-block');
		}else{
			$("#dynamicDateBetween_"+res).hide();
		}
	}

}

function loadShowBetweenInputs(obj){

	var data = $(obj).attr('id');
	res = data.split('_')[1];
	var value = $(obj).find(':selected').text();
	var paramFilterID = $(obj).closest('tr').find('td:nth-child(1)').find('select').attr('id');
	var paramTypeName = $('#'+paramFilterID).children(':selected').attr('class');

	if (paramTypeName == "text") {
		if(value == "Between"){
			$("#loadDynamicDataBetween_"+res).css('display', 'inline-block');
		}else{
			$("#loadDynamicDataBetween_"+res).hide();
		}
	}
	else if(paramTypeName == "date"){
		if(value == "Between"){
			$("#loadDynamicDateBetween_"+res).css('display', 'inline-block');
		}else{
			$("#loadDynamicDateBetween_"+res).hide();
		}
	}

}


function ddLoadFilterParameter(obj){
	var data = $(obj).closest('tr').attr('id');
	res = data.split('_')[1];

	assetParamId = $(obj).children(':selected').val();
	assetParamName = $(obj).children(':selected').text();
	paramListTypeName = $(obj).children(':selected').attr('data-typeName');
	paramTypeName = $(obj).children(':selected').attr('class');
	mapId = $(obj).children(':selected').attr('data-mapid');
	
	$('#loadFileInput_'+res).removeClass('fileValue');
	$('#loadInputFilterText_'+res).removeClass('textBoxValue');
	$('#loadInputDate_'+res).removeClass('dateBoxValue');
	$('#loadDropdownInput_'+res).removeClass('dropDownList');
	$('#loadInputRichText_'+res).removeClass('richTextValue');
	$('#loadInputLdapText_'+res).removeClass('ldapText');
	$('#loadInputLdapMappingText_'+res).removeClass('ldapMappingText'); // added by Hema 07.Mar.2019
	
	$('#loadInputFilterText_'+res).css('display','none');
	$('#loadInputDate_'+res).css('display','none');
	$('#loadDropdownInput_'+res).css('display','none');
	$('#loadFileInput_'+res).css('display','none');
	$('#loadInputRichText_'+res).css('display','none');
	$('#loadInputLdapText_'+res).css('display','none');
	$('#loadDynamicDateBetween_'+res).css('display','none');
	$('#loadDynamicDataBetween_'+res).css('display','none');
	$('#loadInputLdapMappingText_'+res).css('display','none'); // added by Hema 07.Mar.2019
	
	$('#loadOpertorDropdownValues_'+res).html('');

	if (paramTypeName == "list") {
		
		if(paramListTypeName == "ldapuserlist"){
			$('#loadInputLdapText_'+res).css('display','block');
			$('#loadDropdownInput_'+res).css('display','none');
			$('#loadInputLdapText_'+res).addClass('ldapText');
			$('#loadInputLdapTextField_'+res).val('');
		}else{
			$('#loadInputLdapText_'+res).css('display','none');
			$('#loadDropdownInput_'+res).css('display','block');	
			$('#loadDropdownInput_'+res).addClass("dropDownList");
			$('#loadDdListParamValue_'+res).dropdown('clear');
			paramListLoader(res,assetParamName,paramListTypeName,mapId);
		    $('#loadDdListParamValue_'+res).empty();
			//console.log("  ddAppendAssetParametersList  "+ddAppendAssetParametersList);
			$('#loadDdListParamValue_'+res).append(ddAppendAssetParametersList);
			setTimeout(function(){
				$('#loadDdListParamValue_'+res).dropdown('set selected',encodeURIComponent(firstParamValue));
			}, 100);
		}
		
		$('#loadOpertorDropdownValues_'+res).append('<option value="=">=</option><option value="!=">!=</option>');
		setTimeout(function(){
			$('#loadOpertorDropdownValues_'+res).dropdown('set selected',"=");
		}, 300);
		
	}

	else if(paramTypeName == "text"){

		$('#loadInputFilterText_'+res).addClass("textBoxValue");
		$('#loadInputFilterText_'+res).css('display','block');
		$('#loadOpertorDropdownValues_'+res).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option><option value="Between">Between</option>');
		setTimeout(function(){
			$('#loadOpertorDropdownValues_'+res).dropdown('set selected',"=");
		}, 300);
		$('#loadinputTextField_'+res).val('');
		$('#loadInputBetweenField_'+res).val('');
		
	}
	else if(paramTypeName == "date"){

			$('#loadOpertorDropdownValues_'+res).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option><option value="Between">Between</option>');
			setTimeout(function(){
				$('#loadOpertorDropdownValues_'+res).dropdown('set selected',"=");
			}, 300);
			$('#loadInputDate_'+res).css('display','block');
			$('#loadInputDate_'+res).addClass("dateBoxValue");
			$('#loadinputTextDate_'+res).val('');
			$('#loadInputBetweenDate_'+res).val('');
			

			$('#loadinputTextDate_'+res).datepicker({
			    showOn: "button",
		        buttonImage: "/repopro/semantic/images/icon_calender.png",
		        buttonImageOnly: false,
		        buttonText: "Select date",
		        dateFormat: 'dd/mm/yy',
		        changeMonth: true,
		        changeYear: true,
		        maxDate: '0',      // Chandana -keypress event
		        onClose: function( selectedDate ) {
		        	if (event.which === 13) {
		        		$('#loadInputBetweenDate_'+res).datepicker( "option", "minDate", selectedDate );
		        		setCountAndRangeValue()
			        	event.preventDefault();
		        	}
			       
			        }
		    });
		    $('#loadInputBetweenDate_'+res).datepicker({
		    	showOn: "button",
		        buttonImage: "/repopro/semantic/images/icon_calender.png",
		        buttonImageOnly: false,
		        buttonText: "Select date",
		        dateFormat: 'dd/mm/yy',
		        changeMonth: true,
		        changeYear: true,
		        maxDate: '0',   // Chandana -keypress event
		        onClose: function( selectedDate ) {
		        	if (event.which === 13) {
		        		$('#loadinputTextDate_'+res).datepicker( "option", "maxDate", selectedDate );
		        		setCountAndRangeValue()
			        	event.preventDefault();
		        	}			       
			        }
		    });
			
		}
		else if(paramTypeName == "file"){

			$('#loadFileInput_'+res).addClass('fileValue');
			$('#loadOpertorDropdownValues_'+res).append('<option value="is null">is Empty</option><option value="is not null">is Not Empty</option>');
			setTimeout(function(){
				$('#loadOpertorDropdownValues_'+res).dropdown('set selected',"is Empty");
			}, 300);
		}
		else if (paramTypeName == "rich text" || paramTypeName == "richtext") {//bug- 722 fix
			$('#loadInputRichText_'+res).css('display','block');
			$('#loadInputRichText_'+res).addClass("richTextValue");
			$('#loadOpertorDropdownValues_'+res).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#loadOpertorDropdownValues_'+res).dropdown('set selected',"like");
			}, 300);
			$('#loadInputRichTextField_'+res).val('');
			
		}
		// BOC Hema 07.Mar.2019 ldap mapping show textbox and operator dropdown
		else if(paramTypeName == "ldapmapping") {
			$('#loadInputLdapMappingText_'+res).css('display','block');
			$('#loadDropdownInput_'+res).css('display','none');
			$('#loadInputLdapMappingText_'+res).addClass('ldapMappingText');
			$('#loadInputLdapMappingTextField_'+res).val('');
		}
	// EOC
	
}

//create new filter
var addTaxo;
var appendTax = "";
var param1= "";
var param2 ="";
var param3 ="";
var param4 ="";
var TaxId = "";
var TaxName = "";
var param5 ="";
function saveCreatedFilter(){
	$('#submitSavedFilter').unbind();
	$("#noBrowserData").hide();
	
	$("#addSavedFilter").val('');
	
	addTaxo = $("#addNewTaxonomySegment a").length;
	addTaxo = $("#addNewTaxonomySegment a").length;
	 appendTax = "";
	 param1= "";
	 param2 ="";
	 param3 ="";
	 param4 ="";
	 TaxId = "";
	 TaxName = "";

	
	validateSaveParamValues();//Hema- Save filter validation
	
	if(flag == false){
		$("#noBrowserData").show();
		$('#createFilterParams').modal('setting', 'closable', false).modal('show');
		$("#inputFilterSelector").hide();
		$(".modalOverflow").animate({
			  scrollTop: 0
			  }, 10);
	}else{
		$("#noBrowserData").hide();
		$("#inputFilterSelector").show();
		$('#createFilterParams').modal('setting', 'closable', false).modal('show');

		//submit the filter
		$('#submitSavedFilter').on('click', function(){
			var saveFilterName = $("#addSavedFilter").val().trim();
			if(saveFilterName == "" || saveFilterName == null){
				$(".errAddFilterName").hide(); 
				notifyMessage("Save Filter","Please enter the filter name","failure");
				$("#inputFilterSelector").show();
			}
			else if(/^[a-zA-Z0-9- ]*$/.test(saveFilterName) == false){
				$('#addSavedFilter').parent().addClass("error"); 
				$("#inputFilterSelector .errAddFilterName ").html('Please do not use special characters for filter name').show();  
			}
			else{
				$('#addSavedFilter').parent().removeClass("error"); 
				$(".errAddFilterName").hide(); 
				//$("#inputFilterSelector").hide();
				validateSaveParamValues(); //Hema- Save filter validation
				if(flag == false){
					$("#noBrowserData").show();
					$('#createFilterParams').modal('setting', 'closable', false).modal('show');
					//$("#inputFilterSelector").hide();
					$(".modalOverflow").animate({
						  scrollTop: 0
						  }, 10);
				} else {
					$("#noBrowserData").hide();
					//$("#inputFilterSelector").show();
					$('#createFilterParams').modal('setting', 'closable', false).modal('show');

					/*	param1 = param1.substring(0, param1.length-1);
					param2 = param2.substring(0, param2.length-1);
					param3 = param3.substring(0, param3.length-1);
					param4 = param4.substring(0, param4.length-1);
					param5 = param5.substring(0, param5.length-1);
					console.log(" cfsdfparam1 "+param1+"  param2 "+param2+"   param3 "+param3)*/
				//	console.log(" save filter param4 "+param4+"  param5 "+param5);
					
					var encodedParam1Value= encodeURIComponent(param4);
					//console.log(' save filter encodedParam1Value '+encodedParam1Value);
					/*encodedParam1Value = encodedParam1Value.replace(/'/g, "\\'");
					encodedParam1Value = encodedParam1Value.replace(/"/g, '\\"');*/
					//console.log(" encodedParam1Value "+encodedParam1Value); 
					
					var encodedParam2Value= encodeURIComponent(param5);
					//console.log(' save filter encodedParam2Value '+encodedParam2Value);
					/*encodedParam2Value = encodedParam1Value.replace(/'/g, "\\'");
					encodedParam2Value = encodedParam1Value.replace(/"/g, '\\"');*/
					//console.log(" encodedParam1Value "+encodedParam1Value); 
					
					// Swathi- Save default filter vlaue- 10-10-2019
					if ($("#defaultFilterCheck").is(':checked')) {
						defaultFilterFlag = 1;					
						
					} else {
						defaultFilterFlag = 0;
					} 
					
					var obj = {};
					//console.log("  save d filerte "+param3);
					obj = {
							"searchName":saveFilterName,
							"paramsValue":param1,
							"operatorsValue":param2,
							"param1Value":encodedParam1Value,
							"logicalSelectValue":param3,
							"assetName":browserAssetName,
							"param2Value":encodedParam2Value,
							"taxValue":appendTax,
							/*"publicValue":"0",*/
							"userName": loggedInUserName,
							"defaultUserFilterView" : defaultFilterFlag
					};
					
					//console.log("saveCreatedFilter  obj "+JSON.stringify(obj));
					$.ajax({
						type: "POST",
						url: "/repopro/web/assetType/addFilterSearch",
						contentType : "application/json",
						dataType : "json",
						data : JSON.stringify(obj),
						async: false,
						complete:function(data){	
							appenddata = "";
							var json = JSON.parse(data.responseText);
							if(json.status == "SUCCESS"){
								$("#inputFilterSelector").hide();
								notifyMessage("Save Filter","Filter saved","success");
								nameFilterFlag =0;
								//swathi- Default filter - 02.01.2020
								if ($("#defaultFilterCheck").is(':checked')) {
									$("#defaultfilterName").text(saveFilterName);
									$("#defaultfilterName1").text(saveFilterName);
									sessionStorage.setItem('removeDefault', 'false');
									$("#clickFilterMsg").show();
									$("#noFilterclickMsg").hide();
									$("#defaultFilterMessage").show();
									$("#noDefaultFilterMessage").hide();
									$("#clearFilterButton").show();
									defaultFilterFlag = 1;
									$("#browseTable tbody").empty();
									defaultFilterNameAjax();
									var getSavedFilterList = onloadDisplaySaveFilters();
									 $('#savedFilterdd').dropdown('clear');
									$('#savedFilterdd').append(getSavedFilterList);
									formRange = 0;
									countNoOfData = 0;
									$("#browseTable tbody").empty();
									applyFilter();
									nameFilterflag = 1;	
									$("#defaultFilterCheck").prop("checked", false );// REPO-630 fix
									
								}
							}
							else {
								$("#inputFilterSelector").hide();
								notifyMessage("Save Filter",json.message,"fail");
								$("#defaultFilterCheck").prop("checked", false );// REPO-630 fix
							}	

						}
					});
						$('#savedFilterdd option').each(function(e){
							 if(!$(this).hasClass("selectOneData")){
								 $(this).remove();
							 }
						 });						 						
						 $("#savedFilterdd").dropdown('clear');		
					
					 var getSavedFilterList = onloadDisplaySaveFilters();
				     $('#savedFilterdd').append(getSavedFilterList);	
				}
				    
			}
		});
	}
}

 
//display the list saved filters
function onloadDisplaySaveFilters(){
	ddloadSavedFilterName = "";
	var firstSelectedData = "";
	$.ajax({
		type: "GET",
		url: "/repopro/web/assetType/getFilterSearch?assetName="+browserAssetName+"&userName="+loggedInUserName,
		dataType: "json",
		async: false,
		complete:function(data){
			var json = JSON.parse(data.responseText);
			//Swathi- Bug Fix - REPO-616
			if(json.message == "FILTER_SEARCH_DATA_NOT_FOUND"){
				$("#actionClassSelcted").addClass("disableAction");
			} else{
				$("#actionClassSelcted").removeClass("disableAction");
			}
			//console.log(json.result);
			//if(json.result != "" || json.result != null || json.result != [] || json.result != undefined){
				if(json.status == "SUCCESS"){
					firstSelectedData = json.result[0].searchName;
					$.each(json.result, function(i) {
						if (json.result[i].defaultUserFilterView == 1) {
							ddloadSavedFilterName += '<option value="'+ json.result[i].searchId +'">'+ json.result[i].searchName +'[Default Filter]</option>';
						} else {
							ddloadSavedFilterName += '<option value="'+ json.result[i].searchId +'">'+ json.result[i].searchName +'</option>';
						}
						//if(ddloadSavedFilterName)
					});					
				}
				
			//}
		}
	});	
	return ddloadSavedFilterName;
}


//load saved filter name
function loadSavedFilter(){
	//$('#createFilterParams').modal({observeChanges : true}).modal('refresh');
	// Swathi code for default	
	var ddSavedFilterName1 = $("#savedFilterdd option:selected").text();
	var ddSavedFilterName;
	nameFilterFlag = 2;
	if (loadfilterFlag == true) {
		ddSavedFilterName = defaultFilterName;
		nameFilterFlag = 1;
	} else{
		if(ddSavedFilterName1 != "--Select One--"){
			if(ddSavedFilterName1.includes("[Default Filter]")){
				ddSavedFilterName = ddSavedFilterName1.replace(/ *\[[^)]*\] */g, "");	
				nameFilterFlag = 1;
				loadBrowseFilterFlag = true;				
				
			} else{
				ddSavedFilterName = ddSavedFilterName1;
			}
			
		}	else{
			ddSavedFilterName = ddSavedFilterName1;
		}
	}
	
	if(flag == false){
		$("#noBrowserData").show();
		$('#createFilterParams').modal('setting', 'closable', false).modal('show');
		$("#inputFilterSelector").hide();
		$(".modalOverflow").animate({
			  scrollTop: 0
			  }, 10);
	}else{
		$("#noBrowserData").hide();
		$("#inputFilterSelector").show();
		$('#createFilterParams').modal('setting', 'closable', false).modal('show');

		//submit the filter
		$('#submitSavedFilter').on('click', function(){


			var saveFilterName = $("#addSavedFilter").val().trim();
			if(saveFilterName == "" || saveFilterName == null){
				notifyMessage("Save Filter","Please enter the filter name","failure");
				$("#inputFilterSelector").show();
			}
			else if(/^[a-zA-Z0-9- ]*$/.test(saveFilterName) == false){
				$('#addSavedFilter').parent().addClass("error"); 
				$(".errAddFilterName ").html('Please do not use special characters for category name').show();  
			}
			else{
				$('#addSavedFilter').parent().removeClass("error"); 
				$(".errAddFilterName").hide(); 
				$("#inputFilterSelector").hide();

			/*	param1 = param1.substring(0, param1.length-1);
				param2 = param2.substring(0, param2.length-1);
				param3 = param3.substring(0, param3.length-1);
				param4 = param4.substring(0, param4.length-1);
				param5 = param5.substring(0, param5.length-1);
				console.log(" cfsdfparam1 "+param1+"  param2 "+param2+"   param3 "+param3)*/
			//	console.log(" save filter param4 "+param4+"  param5 "+param5);
				
				var encodedParam1Value= encodeURIComponent(param4);
				//console.log(' save filter encodedParam1Value '+encodedParam1Value);
				/*encodedParam1Value = encodedParam1Value.replace(/'/g, "\\'");
				encodedParam1Value = encodedParam1Value.replace(/"/g, '\\"');*/
				//console.log(" encodedParam1Value "+encodedParam1Value); 
				
				var encodedParam2Value= encodeURIComponent(param5);
				//console.log(' save filter encodedParam2Value '+encodedParam2Value);
				/*encodedParam2Value = encodedParam1Value.replace(/'/g, "\\'");
				encodedParam2Value = encodedParam1Value.replace(/"/g, '\\"');*/
				//console.log(" encodedParam1Value "+encodedParam1Value); 
				
				// Swathi- Save default filter vlaue- 10-10-2019
				if ($("#defaultFilterCheck").is(':checked')) {
					defaultFilterFlag = 1;					
					
				} else {
					defaultFilterFlag = 0;
				} 
				
				var obj = {};
				//console.log("  save d filerte "+param3);
				obj = {
						"searchName":saveFilterName,
						"paramsValue":param1,
						"operatorsValue":param2,
						"param1Value":encodedParam1Value,
						"logicalSelectValue":param3,
						"assetName":browserAssetName,
						"param2Value":encodedParam2Value,
						"taxValue":appendTax,
						/*"publicValue":"0",*/
						"userName": loggedInUserName,
						"defaultUserFilterView" : defaultFilterFlag
				};
				
				//console.log("saveCreatedFilter  obj "+JSON.stringify(obj));
				$.ajax({
					type: "POST",
					url: "/repopro/web/assetType/addFilterSearch",
					contentType : "application/json",
					dataType : "json",
					data : JSON.stringify(obj),
					async: false,
					complete:function(data){	
						appenddata = "";
						var json = JSON.parse(data.responseText);
						if(json.status == "SUCCESS"){
							notifyMessage("Save Filter","Filter saved","success");
							nameFilterFlag =0;
							//swathi- Default filter - 02.01.2020
							if ($("#defaultFilterCheck").is(':checked')) {
								$("#defaultfilterName").text(saveFilterName);
								$("#defaultfilterName1").text(saveFilterName);
								$("#clickFilterMsg").show();
								$("#noFilterclickMsg").hide();
								$("#defaultFilterMessage").show();
								$("#noDefaultFilterMessage").hide();
								$("#clearFilterButton").show();
								nameFilterFlag = 4;
								applyFilter();
								
							}
						}
						else {
							notifyMessage("Save Filter",json.message,"fail")
						}	

					}
				});

				$('#savedFilterdd option').each(function(e){
					 if(!$(this).hasClass("selectOneData")){
						 $(this).remove();
					 }
				 });
				 var getSavedFilterList = onloadDisplaySaveFilters();
			     $('#savedFilterdd').append(getSavedFilterList);
				
			}
		});
	}
}

 
//display the list saved filters
function onloadDisplaySaveFilters(){
	ddloadSavedFilterName = "";
	var firstSelectedData = "";
	$.ajax({
		type: "GET",
		url: "/repopro/web/assetType/getFilterSearch?assetName="+browserAssetName+"&userName="+loggedInUserName,
		dataType: "json",
		async: false,
		complete:function(data){										
			var json = JSON.parse(data.responseText);
			//console.log(json.result);
			//if(json.result != "" || json.result != null || json.result != [] || json.result != undefined){
				if(json.status == "SUCCESS"){
					firstSelectedData = json.result[0].searchName;
					$.each(json.result, function(i) {
						if (json.result[i].defaultUserFilterView == 1) {
							ddloadSavedFilterName += '<option value="'+ json.result[i].searchId +'">'+ json.result[i].searchName +'[Default Filter]</option>';
						} else {
							ddloadSavedFilterName += '<option value="'+ json.result[i].searchId +'">'+ json.result[i].searchName +'</option>';
						}
					});					
				}
			//}
		}
	});	
	return ddloadSavedFilterName;
}


//load saved filter name
function loadSavedFilter(){
	//$('#createFilterParams').modal({observeChanges : true}).modal('refresh');
	// Swathi code for default	
	var ddSavedFilterName1 = $("#savedFilterdd option:selected").text();
	var ddSavedFilterName = ddSavedFilterName1.replace(/ *\[[^)]*\] */g, "");	
	closeDefault = 1;
	nameFilterFlag = 2;
	if (loadfilterFlag == true) {
		ddSavedFilterName = defaultFilterName;
		nameFilterFlag = 1;
	}

	 if(ddSavedFilterName == "--Select One--"){
		 notifyMessage("Load Filter","Invalid Input","fail");
	 }
	 else{
			
		 closeDefault = 1;
		 sessionStorage.setItem('removeDefault', 'false');
		 loadedFilterName = ddSavedFilterName;	
//		 $("#defaultfilterName1").html(loadedFilterName);
			var url = "http://localhost:8080/repopro/web/assetType/getFilterSearchForLoad?assetName="+browserAssetName+"&searchName="+ddSavedFilterName+"&userName="+loggedInUserName;
			//console.log("load saved filter url  "+url)
			$.ajax({
				type: "GET",
				url: "/repopro/web/assetType/getFilterSearchForLoad?assetName="+browserAssetName+"&searchName="+ddSavedFilterName+"&userName="+loggedInUserName,
				dataType: "json",
				async: false,
				complete:function(data){
					var json = JSON.parse(data.responseText);
					var paramsValue = json.result[0].paramsValue;
					var param1Value = json.result[0].param1Value;
					var param2Value = json.result[0].param2Value;
					var opertorSelector = json.result[0].operatorsValue;
					var logicalSelectValue = json.result[0].logicalSelectValue;
					//console.log(" logicalSelectValue  "+logicalSelectValue);
					var taxonomyValue = json.result[0].taxValue;
					taxonomyValue1 = taxonomyValue.split("~");
					var taxParameter = "";
					associateTaxNameArr.length = 0;
					$.each(taxonomyValue1,function(q){
						taxParameter = taxonomyValue1[q].split(":")[1];
						associateTaxNameArr.push(taxParameter);
					});
				/*	taxParameter = taxParameter.substring(0, taxParameter.length-1);*/
					/*associateTaxNameArr.push(taxParameter);*/
					//var paramsVariable = [];
					var loadParamName = [];
					var arr = [];
					//var taxData = [];
					var len = "";
					var taxLength = "";
					
					
					if(paramsValue.length != 0){
						var paramsVariable = paramsValue.split('~'); 
						len = paramsVariable.length;
					}
					opertorSelector = opertorSelector.split('~');
					logicalSelectValue = logicalSelectValue.split('~');
					var length =logicalSelectValue.length;
					if(taxonomyValue.length != 0){
						var taxData = taxonomyValue.split('~'); 
						taxLength = taxData.length;
					}
					
					
					arr = param1Value.split('~');
					param1Value = param1Value.split('~');
					param2Value = param2Value.split('~');
					
					
					var k = 0;
					var flag = true;
					// BOC- Swathi - Code to display defalutFilter message
					
					if (json.result[0].defaultUserFilterView == 1) {						
//						$("#defaultFilterMessage").show();
//						$("#noDefaultFilterMessage").hide();
					} else if($("#defaultFilterMessage").is(":visible")){
						$("#defaultFilterMessage").show();
						$("#noDefaultFilterMessage").hide();
					} else {						
						$("#defaultFilterMessage").hide();
						$("#noDefaultFilterMessage").show();
					}
					loadfilterFlag = true;
					// EOC - Swathi
					if(len != 0 && taxLength == 0){
						$.each(paramsVariable, function(i) {
							var name = paramsVariable[i].split('_')[0];
							if ($.inArray(name , listofParamArray) == -1)
							{	
								// is in array
								alert("Asset details have been modified after this filter was saved. This filter is invalid now.");
								refreshTable();
								flag = false;
							}
						});
					}else if(len != 0 && taxLength != 0){
						$.each(paramsVariable, function(i) {
							var name = paramsVariable[i].split('_')[0];
							//console.log("name "+name+" listofParamArray "+listofParamArray)
							if ($.inArray(name , listofParamArray) == -1)
							{	
								// is in array
								alert("Asset details have been modified after this filter was saved. This filter is invalid now.");
								refreshTable();
								flag = false;
							}
						});
					}
			
					

				
					if(flag == true){
						if(len != 0){
							$('#tbl_SelectFilterParam tbody').empty();
							for (var i = 0; i <len; i++) {	
								var appendData = "";
								if(i != 0){
									appendData += '<tr id="loadRowOperatorId_'+(i-1)+'"><td class="andOrPara popuptabletr">';
									appendData += '<select class="ui dropdown dropdownCssForFilter" id="selectLogicOpId_'+(i-1)+'">';
									appendData += '<option value="And">And</option>';
									appendData += '<option value="Or">Or</option>';
									appendData += '</select></td></tr>';
								}
								appendData += '<tr style="outline: thin solid lightgrey" id="loadrowDataId_'+i+'">';
								appendData += '<td class="popuptabletr ddFilterParamSelector" style="vertical-align:top;">';
								appendData += '<select class="ui dropdown"  id="loadfilterDropdownValues_'+i+'" style="min-width: 10em;">';
								appendData += '<option value="selectParam">[ Select Parameter ]</option></select>';	 
								appendData += '</td>';
								appendData += '<td class="popuptabletr ddOptionSelector" style="vertical-align:top;">';
								appendData += '<select class="ui dropdown dropdownCssForFilter" id="loadOpertorDropdownValues_'+i+'" onchange="loadShowBetweenInputs(this);">';
								appendData += '</select>';
								appendData += '</td>';

								//Text
								appendData += '<td class="popuptabletr inputValueSelector" id="loadInputFilterText_'+i+'" style="display: none;vertical-align:top;">';
								appendData += '<div class="ui input focus" style="width: 195px;">';
								appendData += '<input type="text" id="loadinputTextField_'+i+'" placeholder="Enter Text" class="customizeTextBox">';
								appendData += '</div>';
								appendData += '<div id="loadDynamicDataBetween_'+i+'" style="display: none;margin-left: 1.85em;">';
								appendData += '<span>and</span>';
								appendData += '<div class="ui input focus" style="width: 195px;margin-left: 2em;">';
								appendData += '<input type="text" id="loadInputBetweenField_'+i+'" placeholder="Enter Text" class="customizeTextBox">';
								appendData += '</div></div></td>';

								//Date
								appendData += '<td class="popuptabletr inputDateSelector" id="loadInputDate_'+i+'" style="display: none;vertical-align:top;">';
								appendData += '<div class="ui input focus" style="  width: 195px;">';
								appendData += '<input type="text" id="loadinputTextDate_'+i+'" placeholder="Select Date" readonly="true" class="customizeDateBox"></div>';
								appendData += '<div id="loadDynamicDateBetween_'+i+'" style="display: none;margin-left: 1.5em;">';
								appendData += '<span>and</span>';
								appendData += '<div class="ui input focus" style="width: 195px;margin-left: 2em;">';
								appendData += '<input type="text" id="loadInputBetweenDate_'+i+'" placeholder="Select Date" readonly="true" class="customizeDateBox">';
								appendData += '</div>';
								appendData += '</div></td>';

								//List
								appendData += '<td class="popuptabletr ddParamValueSelector"  id="loadDropdownInput_'+i+'" style="display: none;vertical-align:top;">';
								appendData += '<select class="ui dropdown" id="loadDdListParamValue_'+i+'" style="width: 10em;display: none;">';
								appendData += '<option value="selectParam">[ Select Parameter ]</option></select>';	 
								appendData += '</select>';	 
								appendData += '</td>';
								
								//Ldap
								appendData += '<td class="popuptabletr inputLdapTextSelector" id="loadInputLdapText_'+i+'" style="display: none;vertical-align:top;">';
								appendData += '<div class="ui input focus" style="width: 160px;">';
								appendData += '<input type="text" id="loadInputLdapTextField_'+i+'" placeholder="Enter Text" class="customizeTextBox">';
								appendData += '</div></td>';

									
								// File
								appendData += '<td class="popuptabletr fileSelector" id="loadFileInput_'+i+'" style="display: none;vertical-align:top;">';
								appendData += '<div class="ui input focus"  style="width: 100px;margin-left: 2em;">';
								appendData += '<input type="text" id="loadInputFile_'+i+'" placeholder="File Type">';
								appendData += '</div></td>';
								
								//Rich text
								appendData += '<td class="popuptabletr inputRichTextSelector" id="loadInputRichText_'+i+'" style="display: none;vertical-align:top;">';
								appendData += '<div class="ui input focus" style="width: 160px;">';
								appendData += '<input type="text" id="loadInputRichTextField_'+i+'" placeholder="Enter Text" class="customizeTextBox">';
								appendData += '</div></td>';
								
								//BOC Hema 07.Mar.2019 Ldap Mapping
								appendData += '<td class="popuptabletr inputLdapMappingTextSelector" id="loadInputLdapMappingText_'+i+'" style="display: none;vertical-align:top;">';
								appendData += '<div class="ui input focus" style="width: 160px;">';
								appendData += '<input type="text" id="loadInputLdapMappingTextField_'+i+'" placeholder="Enter Text" class="customizeTextBox">';
								appendData += '</div></td>';
								// EOC

								appendData += '<td class="popuptabletr posRemoveIcon" style="vertical-align:top;"><i class="remove icon" onclick="deleteFilterParameter(this)" style="cursor: pointer;"></i></td>';
								appendData += '</tr>'; 	
								
								
								$('#tbl_SelectFilterParam tbody').append(appendData);
								showParamLoader();
								
								var valNew = paramsVariable[i].toString().split('_');
								var mapId = valNew[1];
								var loadParamType = valNew[3];
								var loadTypeListName = valNew[4];
								
								$('#loadFileInput_'+i).removeClass("fileValue");
								$('#loadInputFilterText_'+i).removeClass("textBoxValue");
								$('#loadInputDate_'+i).removeClass("dateBoxValue");
								$('#loadDropdownInput_'+i).removeClass("dropDownList");
								$('#loadInputRichText_'+i).removeClass("richTextValue");
								$('#loadInputLdapText_'+i).removeClass("ldapText");
								$('#loadInputLdapMappingText_'+i).removeClass("ldapMappingText");
								
								
								if(loadParamType == "list"){ 
									if(loadTypeListName == 1){
										loadTypeListName = "customlist";
									}else if(loadTypeListName == 2){
										loadTypeListName = "assetlist"
									}
									else if(loadTypeListName == 4){
										loadTypeListName = "ldapuserlist"
									}else{
										loadTypeListName = "nativeuserlist"
									}
									$('#loadInputFilterText_'+i).css('display','none');
									$('#loadInputDate_'+i).css('display','none');
									$('#loadInputRichText_'+i).css('display','none');
									
									if(loadTypeListName == "ldapuserlist"){
										$('#loadDropdownInput_'+i).css('display','none');
										$('#loadDdListParamValue_'+i).css('display','none');
										$('#loadInputLdapText_'+i).css('display','block');
										$('#loadInputLdapText_'+i).addClass("ldapText");
										$('#loadInputLdapTextField_'+i).val(param1Value[i]);
									}
									else{
										$('#loadInputLdapText_'+i).css('display','none');
										$('#loadDropdownInput_'+i).css('display','block');
										$('#loadDdListParamValue_'+i).css('display','block');
										$('#loadDropdownInput_'+i).addClass("dropDownList");
										$('#loadDdListParamValue_'+i).empty();
										
										$('#loadDdListParamValue_'+i).html('<option value="'+ encodeURIComponent(param1Value[i]) +'">'+ param1Value[i] +'</option>');
										paramListLoader(i,valNew[0],loadTypeListName,mapId);
										//console.log("listDropdownData "+listDropdownData);
		
										var ddListDropdownData = "";
										$.each(listDropdownData,function(l){
											if(listDropdownData[l] != param1Value[i]){
												ddListDropdownData += '<option value="'+ encodeURIComponent(listDropdownData[l]) +'">'+ listDropdownData[l] +'</option>';	 
											}
										});
										//console.log(" ddListDropdownData "+ddListDropdownData);
										$('#loadDdListParamValue_'+i).append(ddListDropdownData);
									}
							
									//ddAppendAssetParametersList = "";
									$('#loadOpertorDropdownValues_'+i).append('<option value="=">=</option><option value="!=">!=</option>');

								}
								else if(loadParamType == "text"){

									$('#loadInputFilterText_'+i).addClass("textBoxValue");
									$('#loadInputFilterText_'+i).css('display','block');
									$('#loadInputDate_'+i).css('display','none');
									$('#loadDropdownInput_'+i).css('display','none');
									$('#loadInputRichText_'+i).css('display','none');
									$('#loadinputTextField_'+i).val(param1Value[i]);
									if(opertorSelector[i] == "Between"){
										$('#loadDynamicDataBetween_'+i).css('display', 'inline-block');
										$('#loadInputBetweenField_'+i).val(param2Value[i]);
									}else{
										$('#loadDynamicDataBetween_'+i).css('display','none');
									}
									$('#loadOpertorDropdownValues_'+i).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option><option value="Between">Between</option>');
								}
								else if(loadParamType == "date"){
									
									$('#loadInputDate_'+i).css('display','block');
									$('#loadInputDate_'+i).addClass("dateBoxValue");
									$('#loadDropdownInput_'+i).css('display','none');
									$('#loadInputFilterText_'+i).css('display','none');
									$('#loadInputRichText_'+i).css('display','none');
									$('#loadinputTextDate_'+i).val(param1Value[i]);
									if(opertorSelector[i] == "Between"){
										$('#loadDynamicDateBetween_'+i).css('display','inline-block');
										$('#loadInputBetweenDate_'+i).val(param2Value[i]);
									}else{
										$('#loadDynamicDateBetween_'+i).css('display','none');
									}
									$('#loadOpertorDropdownValues_'+i).append('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option><option value="Between">Between</option>');
									$('#loadinputTextDate_'+i).datepicker({  // Chandana -keypress event
										  showOn: "button",
									      buttonImage: "/repopro/semantic/images/icon_calender.png",
									      buttonImageOnly: false,
									      buttonText: "Select date",
									      dateFormat:"dd/mm/yy"   ,
									      onClose: function(selectedDate) {
									    		 if (event.which === 13) {
									 	            $('#inputBetweenDate_'+res).datepicker( "option", "minDate", selectedDate );
									 	            setCountAndRangeValue()
									 	            event.preventDefault();
									 	            
									 	            }
									    		 
									      }
									}); 
									
							
								//	$('#loadinputTextDate_'+i).parent().find('img').css("width","25px").css("height","25px");
									$('#loadinputTextDate_'+i).parent().find('img').css("width","15px").css("height","15px");
									$('#loadInputBetweenDate_'+i).datepicker({
										  showOn: "button",
									      buttonImage: "/repopro/semantic/images/icon_calender.png",
									      buttonImageOnly: false,
									      buttonText: "Select date",
									      dateFormat:"dd/mm/yy",    // Chandana -keypress event
									      onClose: function(selectedDate) {
									    		 if (event.which === 13) {
									 	            $('#inputBetweenDate_'+res).datepicker( "option", "maxDate", selectedDate );
									 	            setCountAndRangeValue()
									 	            event.preventDefault();
									 	            
									 	            }
									    		 
									      }
									}); 
									$('#loadInputBetweenDate_'+i).parent().find('img').css("width","15px").css("height","15px");
								}
								else if(loadParamType == "file"){
									$('#loadFileInput_'+i).addClass("fileValue");
									$('#loadOpertorDropdownValues_'+i).append('<option value="is null">is Empty</option><option value="is not null">is Not Empty</option>');
								}
								else if(loadParamType == "rich text" || loadParamType == "richtext"){//bug 722 fix

									$('#loadInputRichText_'+i).css('display','block');
									$('#loadInputRichText_'+i).addClass("richTextValue");
									$('#loadInputFilterText_'+i).css('display','none');
									$('#loadInputDate_'+i).css('display','none');
									$('#loadDropdownInput_'+i).css('display','none');
									$('#loadInputRichTextField_'+i).val(param1Value[i]);
									$('#loadOpertorDropdownValues_'+i).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
								}
								
								// BOC Hema 07.Mar.2019 Ldap Mapping
								else if(loadParamType == "ldapmapping"){
									$('#loadDropdownInput_'+i).css('display','none');
									$('#loadDdListParamValue_'+i).css('display','none');
									$('#loadInputLdapMappingText_'+i).css('display','block');
									$('#loadInputLdapMappingText_'+i).addClass("ldapMappingText");
									$('#loadInputLdapMappingTextField_'+i).val(param1Value[i]);
									$('#loadOpertorDropdownValues_'+i).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
								}
								// EOC
								//$('#loadfilterDropdownValues_'+i).prepend("<option value='"+valNew[0]+"' id='"+paramsValue[i]+"' selected='selected'>"+valNew[0]+"</option>");
								
								$('#loadfilterDropdownValues_'+i).empty();
								$('#loadfilterDropdownValues_'+i).append(ddAppendParameters);
								$('#loadfilterDropdownValues_'+i).dropdown('set selected',valNew[0]);
								
								if(opertorSelector[i] == "is null"){
									//$('#loadOpertorDropdownValues_'+i).prepend("<option value='"+opertorSelector[i]+"'  selected='selected'>is Empty</option>");
									$('#loadOpertorDropdownValues_'+i).dropdown('set selected',"is Empty");
								}
								else if(opertorSelector[i] == "is not null"){
									//$('#loadOpertorDropdownValues_'+i).prepend("<option value='"+opertorSelector[i]+"'  selected='selected'>is Not Empty</option>");
									$('#loadOpertorDropdownValues_'+i).dropdown('set selected',"is Not Empty");
								}
								else{
									//$('#loadOpertorDropdownValues_'+i).prepend("<option value='"+opertorSelector[i]+"'  selected='selected'>"+opertorSelector[i]+"</option>");
									//console.log("    opi "+opertorSelector[i]);
									$('#loadOpertorDropdownValues_'+i).dropdown('set selected',opertorSelector[i]);
								}
								if(i != 0){
									//$('#selectLogicOpId_'+(i-1)).prepend("<option value='"+logicalSelectValue[i-1]+"' selected='selected'>"+logicalSelectValue[i-1]+"</option>");
									//console.log("   logicalSelectValue[i-1]  "+logicalSelectValue[i-1]);
									$('#selectLogicOpId_'+(i-1)).dropdown('set selected',logicalSelectValue[i-1]);
								}
								
								$('#loadfilterDropdownValues_'+i).change(function(){
									ddLoadFilterParameter(this);
							    });
								$('.ui.dropdown').dropdown();
							}
						}
						else{
							$('#tbl_SelectFilterParam tbody').empty();
							 createRow();
						}


					// Display Taxonomy - hema
					$('#addNewTaxonomySegment').html("");

					
					var taxVariables = "";
					taxVariables = taxonomyValue.split('~'); 

					var taxLength = taxVariables.length;

					for (var h = 0; h < taxVariables.length; h++) {
						var values = "";
						values = taxVariables[h].split(':'); 
						$('#addNewTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+values[0]+'_'+values[1].replace(/ /g,"_")+'" id="taxonomyName_'+values[0]+'_'+values[1]+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+values[1]+' <i class="delete icon" onclick="deleteTaxonomy('+values[0]+',\''+values[1]+'\')"></i></a>');
					}
					
					}
				}
			});
	 }
	 
}

//refresh the filter name
function clearSavedFilter(){
	$("#addSavedFilter").val("");
}


//update the filter
/*var taxIdNameAppend = "";*/
var callApplyFilter;
function updateFilter(){
	//var filterValue1 = $("#savedFilterdd").children(':selected').text();
	var filterValue1 = $("#savedFilterdd option:selected").text();
	var filterValue = filterValue1.replace(/ *\[[^)]*\] */g, "");
	var addTaxo = $("#addNewTaxonomySegment a").length;
	var filterId = $("#savedFilterdd").children(':selected').val();
	var param1= "";
	var param2 ="";
	var param3 ="";
	var param4 ="";
	var param5 ="";
	var flag = true;
	var taxIdNameAppend = "";
	
	//Swathi - Code to directly update the default values from the Confirmation message box-10.12.2019
	if(saveConfirmationflag == true){
		filterId= defaultFilterId;
		filterValue= defaultFilterName;
		param1= eParam1;
		param2= eParam2;		
		param3= eParam3;
		param4= eParam4;
		param5= eParam5;
		taxIdNameAppend=etaxIdName;
		flag= true;
		if(flag == false){
			$('#createFilterParams').modal('setting', 'closable', false).modal('show');
			$("#inputFilterSelector").hide();

		}else{
			$("#noBrowserData").hide();
			
			var encodedParam4Value= encodeURIComponent(param4);	
			//console.log('  encodedParam4Value '+encodedParam4Value);
			var encodedParam5Value= encodeURIComponent(param5);
			var obj = {
					"searchId":filterId,
					"searchName":filterValue,
					"paramsValue":param1,
					"operatorsValue":param2,
					"param1Value":encodedParam4Value,
					"logicalSelectValue":param3,
					"assetName":browserAssetName,
					"param2Value":encodedParam5Value,
					"taxValue":taxIdNameAppend,
					"userName":loggedInUserName,
					"defaultUserFilterView" : defaultFilterFlag
			};
			//console.log(" update  obj  "+JSON.stringify(obj));
			var url = "http://localhost:9090/repopro/web/assetType/updateFilterSearch";
			//console.log("update url "+url)
			$.ajax({
				type: "PUT",
				url: "/repopro/web/assetType/updateFilterSearch",
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				complete:function(data){
					appenddata = "";
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						notifyMessage("Update Filter",json.message,"success");
						$('#showHideLoader').removeClass('active');						
					}
					else {
						notifyMessage("Update Filter","Error attempting to update","fail");
					}
				}
			});
			
		}
		$('#showHideLoader').removeClass('active');
		//Swathi-DefaultFilterView - 30-10-2019
		onloadDisplaySaveFilters();

	} else {
		if(filterValue == "--Select One--"){
		notifyMessage("Update Filter","Please select an option","fail");
		flag = false;
		callApplyFilter = false;
		}
		else{			
		if ( $('#tbl_SelectFilterParam > tbody > tr').length == 1 ) {
			param1= "";
			param2 ="";
			param3 ="";
			param4 ="";
			param5 ="";
			TaxId = "";
			taxIdNameAppend = "";
			flag = true;


			var $paramRows = $('#tbl_SelectFilterParam > tbody  > tr');
			var paramSelector = $paramRows.find('td.ddFilterParamSelector').find(':selected').attr("id");
			var optionSelector = $paramRows.find('td.ddOptionSelector').find(':selected').val();
			var logicalSelector = $paramRows.find('td.andOrPara').find(':selected').val();
			var inputValSelector = $paramRows.find('td.inputValueSelector').find("input[type='text']").val();
			var ddParamValSelector = $paramRows.find('td.ddParamValueSelector').find(':selected').val();
			/*console.log(" paramSelector "+paramSelector+" optionSelector  "+optionSelector);
			console.log(" logicalSelector "+logicalSelector+" inputValSelector  "+inputValSelector+"  ddParamValSelector  "+ddParamValSelector);*/


			if(paramSelector == "Select Parameter" && addTaxo == 0){
				param1 = "";
				taxIdNameAppend = "";
				$("#noBrowserData").show().html("Please provide the filter criteria");
				flag = false;
				callApplyFilter = false;
			}

			else if(paramSelector == "Select Parameter" && addTaxo != 0){
				param1 = "";
				$('.assignTax a').each(function(i){
					var taxData = $(this).attr('id');
					taxData = taxData.split('_');
					TaxId = taxData[1];
					TaxName = taxData[2];
					taxIdNameAppend += TaxId+":"+TaxName+"~";

				})
				taxIdNameAppend = taxIdNameAppend.substring(0, taxIdNameAppend.length-1);
			}
			
			
			else if(paramSelector != "Select Parameter" && addTaxo == 0){
				taxIdNameAppend = "";
				if(paramSelector != undefined || paramSelector != null){
					param1 = param1 + paramSelector + "~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
					flag = false;
					callApplyFilter = false;
				}

				if(optionSelector != undefined || optionSelector != null){
					param2 = param2 + optionSelector + "~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
					callApplyFilter = false;
				}

				if(logicalSelector != undefined || logicalSelector != null){
					param3 = param3 + logicalSelector + "~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
					callApplyFilter = false;
				}

				if($paramRows.find('td.ddParamValueSelector').hasClass('dropDownList')){
					var ddParamValSelector  = $paramRows.find('td.ddParamValueSelector').find(':selected').text();
					if(ddParamValSelector != undefined){
						param4 = param4 + ddParamValSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						callApplyFilter = false;
						flag = false;
					}
					param5 = param5 + "undefined" + "~";
				}
				else if($paramRows.find('td.inputLdapTextSelector').hasClass('ldapText')){
					var ldapValSelector  = $paramRows.find('td.inputLdapTextSelector').find("input[type='text']").val().trim();
					if(ldapValSelector != undefined){
						param4 = param4 + ldapValSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					param5 = param5 + "undefined" + "~";
				}
				else if($paramRows.find('td.inputValueSelector').hasClass('textBoxValue')){
					var inputValSelector  = $paramRows.find('td.inputValueSelector').find("input[type='text']").val().trim();
					if(inputValSelector != "" && inputValSelector != undefined){
						param4 = param4 + inputValSelector + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $paramRows.find('td.inputValueSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~";
						}else{
							$("#noBrowserData").show();
							flag = false;
							callApplyFilter = false;
						}
					}
					else{
						param5 = param5 + "undefined" + "~";
					}
					
				}
				else if($paramRows.find('td.inputDateSelector').hasClass('dateBoxValue')){

					var dateValSelector  =  $paramRows.find('td.inputDateSelector').find("input[type='text']").val();
					if(dateValSelector != "" && dateValSelector != undefined){
						param4 = param4 + dateValSelector + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $paramRows.find('td.inputDateSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~";
						}else{
							$("#noBrowserData").show();
							flag = false;
							callApplyFilter = false;
						}
					}
					else{
						param5 = param5 + "undefined" + "~";
					}
				}
				else if($paramRows.find('td.fileSelector').hasClass('fileValue')){
					param4 = param4 + "undefined" + "~";
					param5 = param5 + "undefined" + "~";
				}
				else if($paramRows.find('td.inputRichTextSelector').hasClass('richTextValue')){
					var richTextValSelector  = $paramRows.find('td.inputRichTextSelector').find("input[type='text']").val().trim();
					//console.log(" richTextValSelector "+richTextValSelector);
					if(richTextValSelector != "" && richTextValSelector != undefined){
						param4 = param4 + richTextValSelector + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					param5 = param5 + "undefined" + "~";
				}
				
				// BOC HEma 07.Mar.2019 Ldap Mapping
				else if($paramRows.find('td.inputLdapMappingTextSelector').hasClass('ldapMappingText')){
					var ldapMappingValSelector  = $paramRows.find('td.inputLdapMappingTextSelector').find("input[type='text']").val().trim();
					if(ldapMappingValSelector != undefined){
						param4 = param4 + ldapMappingValSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					param5 = param5 + "undefined" + "~";
				}
				// EOC
			}
			
			else if(paramSelector != "Select Parameter" && addTaxo != 0){

				$("#noBrowserData").hide();

				if(paramSelector != undefined || paramSelector != null){
					param1 = param1 + paramSelector + "~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
					flag = false;
					callApplyFilter = false;
				}

				if(optionSelector != undefined || optionSelector != null || optionSelector != ""){
					param2 = param2 + optionSelector + "~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
					callApplyFilter = false;
				}
				if(logicalSelector != undefined || logicalSelector != null){
					param3 = param3 + logicalSelector + "~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
					callApplyFilter = false;
				}
				if($paramRows.find('td.ddParamValueSelector').hasClass('dropDownList')){
					var ddParamValSelector  = $paramRows.find('td.ddParamValueSelector').find(':selected').text();
					if(ddParamValSelector != undefined){
						param4 = param4 + ddParamValSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					param5 = param5 + "undefined" + "~";
				}
				//Ldap
				else if($paramRows.find('td.inputLdapTextSelector').hasClass('ldapText')){
					var ldapValSelector  = $paramRows.find('td.inputLdapTextSelector').find("input[type='text']").val().trim();
					//console.log(" update ldapValSelector  ");
					if(ldapValSelector != undefined){
						param4 = param4 + ldapValSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					param5 = param5 + "undefined" + "~";
				}
				
				else if($paramRows.find('td.inputValueSelector').hasClass('textBoxValue')){
					var inputValSelector  = $paramRows.find('td.inputValueSelector').find("input[type='text']").val().trim();
					if(inputValSelector != "" && inputValSelector != undefined){
						param4 = param4 + inputValSelector + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $paramRows.find('td.inputValueSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~";
						}else{
							$("#noBrowserData").show();
							flag = false;
							callApplyFilter = false;
						}
					}
					else{
						param5 = param5 + "undefined" + "~";
					}
				}
				else if($paramRows.find('td.inputDateSelector').hasClass('dateBoxValue')){

					var dateValSelector  =  $paramRows.find('td.inputDateSelector').find("input[type='text']").val();
					if(dateValSelector != "" && dateValSelector != undefined){
						param4 = param4 + dateValSelector + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $paramRows.find('td.inputDateSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~";
						}else{
							$("#noBrowserData").show();
							flag = false;
							callApplyFilter = false;
						}
					}
					else{
						param5 = param5 + "undefined" + "~";
					}

				}
				else if($paramRows.find('td.fileSelector').hasClass('fileValue')){
					param4 = param4 + "undefined" + "~";
					param5 = param5 + "undefined" + "~";
				}
				else if($paramRows.find('td.inputRichTextSelector').hasClass('richTextValue')){
					var richTextValSelector  = $paramRows.find('td.inputRichTextSelector').find("input[type='text']").val().trim();
					//console.log(" richTextValSelector "+richTextValSelector);
					if(richTextValSelector != "" && richTextValSelector != undefined){
						param4 = param4 + richTextValSelector + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					param5 = param5 + "undefined" + "~";
				}

				// BOC Hema 07.Mar.2019 Ldap Mapping
				else if($paramRows.find('td.inputLdapMappingTextSelector').hasClass('ldapMappingText')){
					var ldapMappingValSelector  = $paramRows.find('td.inputLdapMappingTextSelector').find("input[type='text']").val().trim();
					//console.log(" update ldapValSelector  ");
					if(ldapMappingValSelector != undefined){
						param4 = param4 + ldapMappingValSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					param5 = param5 + "undefined" + "~";
				}
				// EOC
				
				$('.assignTax a').each(function(i){
					var taxData = $(this).attr('id');
					taxData = taxData.split('_');
					TaxId = taxData[1];
					TaxName = taxData[2];
					taxIdNameAppend += TaxId+":"+TaxName+"~";

				});
				taxIdNameAppend = taxIdNameAppend.substring(0, taxIdNameAppend.length-1);
			}
			param1 = param1.substring(0, param1.length-1);
			param2 = param2.substring(0, param2.length-1);
			param3 = param3.substring(0, param3.length-1);
			param4 = param4.substring(0, param4.length-1);
			param5 = param5.substring(0, param5.length-1);
			/*console.log(" param1 "+param1+"  param2 "+param2+"   param3 "+param3)
			console.log(" param4 "+param4+" param5 "+param5);*/
		}
		
		
		else{
			param1= "";
			param2 ="";
			param3 ="";
			param4 ="";
			param5 ="";
			TaxId = "";
			taxIdNameAppend = "";
			flag = true;
			
			$('#tbl_SelectFilterParam > tbody  > tr').each(function() {

				$(this).find('td.ddFilterParamSelector').each(function() {
					var paramSelector = $(this).find(':selected').attr("id");
					if(paramSelector != "Select Parameter"){
						param1 = param1 + paramSelector + "~";
						$("#noBrowserData").hide();
					}
					else{
						notifyMessage("update filter","Please select an option","fail");
						$("#noBrowserData").css("display","block");
						flag = false;
						callApplyFilter = false;
					}
				});
				var optionSelector = "";
				$(this).find('td.ddOptionSelector').each(function() {
					optionSelector = $(this).find(':selected').text();
					if(optionSelector != undefined){
						param2 = param2 + optionSelector + "~";
						$("#noBrowserData").hide();
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
				});

				$(this).find('td.andOrPara').each(function() {
					var logicalSelector  = $(this).find(':selected').val();
					if(logicalSelector != undefined){
						param3 = param3 + logicalSelector + "~";
						$("#noBrowserData").hide();
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}

				});

				if($(this).find('td.ddParamValueSelector').hasClass('dropDownList')){
					$(this).find('td.ddParamValueSelector').each(function() {
						var ddParamValSelector = $(this).find(':selected').text();
						if(ddParamValSelector != undefined){
							param4 = param4 + ddParamValSelector + "~";
						}
						else{
							$("#noBrowserData").show();
							flag = false;
							callApplyFilter = false;
						}
					});
					param5 = param5 + "undefined" + "~";
				}
				//Ldap
				else if($(this).find('td.inputLdapTextSelector').hasClass('ldapText')){
					$(this).find('td.inputLdapTextSelector').each(function() {
						var ldapValSelector  = $(this).find("input[type='text']").val().trim();
						//console.log(" else   update ldapValSelector  ");
						if(ldapValSelector != undefined){
							param4 = param4 + ldapValSelector + "~";
						}
						else{
							$("#noBrowserData").show();
							flag = false;
							callApplyFilter = false;
						}
					});
				
					param5 = param5 + "undefined" + "~";
				}
				else if($(this).find('td.inputValueSelector').hasClass('textBoxValue')){
					$(this).find('td.inputValueSelector').each(function() {
						var inputValSelector  = $(this).find("input[type='text']").val();
						if(inputValSelector != "" && inputValSelector != undefined){
							param4 = param4 + inputValSelector + "~";
						}else{
							$("#noBrowserData").show();
							flag = false;
							callApplyFilter = false;
						}
						if(optionSelector == "Between"){
							var inputTwoValue = $(this).find( "div:eq(1)" ).find("input[type='text']").val().trim();
							if(inputTwoValue != "" && inputTwoValue != undefined){
								param5 = param5 + inputTwoValue + "~";
							}else{
								$("#noBrowserData").show();
								flag = false;
								callApplyFilter = false;
							}
						}
						else{
							param5 = param5 + "undefined" + "~";
						}
					});
				}
				else if($(this).find('td.inputDateSelector').hasClass('dateBoxValue')){

					var dateValSelector  =  $(this).find('td.inputDateSelector').find("input[type='text']").val();
					if(dateValSelector != "" && dateValSelector != undefined){
						param4 = param4 + dateValSelector + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $(this).find('td.inputDateSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~";
						}else{
							$("#noBrowserData").show();
							flag = false;
							callApplyFilter = false;
						}
					}else{
						param5 = param5 + "undefined" + "~";
					}
				}
				else if($(this).find('td.fileSelector').hasClass('fileValue')){
					param4 = param4 + "undefined" + "~";
					param5 = param5 + "undefined" + "~";
				}
				else if($(this).find('td.inputRichTextSelector').hasClass('richTextValue')){
					var richTextValSelector  = $(this).find('td.inputRichTextSelector').find("input[type='text']").val().trim();
					//console.log(" richTextValSelector "+richTextValSelector);
					if(richTextValSelector != "" && richTextValSelector != undefined){
						param4 = param4 + richTextValSelector + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
						callApplyFilter = false;
					}
					param5 = param5 + "undefined" + "~";
				}
				
				// BOC Hema 07.Mar.2019 Ldap Mapping
				else if($(this).find('td.inputLdapMappingTextSelector').hasClass('ldapMappingText')){
					$(this).find('td.inputLdapMappingTextSelector').each(function() {
						var ldapMappingValSelector  = $(this).find("input[type='text']").val().trim();
						//console.log(" else   update ldapValSelector  ");
						if(ldapMappingValSelector != undefined){
							param4 = param4 + ldapMappingValSelector + "~";
						}
						else{
							$("#noBrowserData").show();
							flag = false;
							callApplyFilter = false;
						}
					});
				
					param5 = param5 + "undefined" + "~";
				}

			});
			if(addTaxo == 0 ){
				appendTax = "";
			}else{
				$('.assignTax a').each(function(i){
					var taxData = $(this).attr('id');
					taxData = taxData.split('_');
					TaxId = taxData[1];
					TaxName = taxData[2];
					taxIdNameAppend += TaxId+":"+TaxName+"~";

				})
				taxIdNameAppend = taxIdNameAppend.substring(0, taxIdNameAppend.length-1);
				//console.log(' more than one param  appendTax'+appendTax);
			}

			param1 = param1.substring(0, param1.length-1);
			param2 = param2.substring(0, param2.length-1);
			param3 = param3.substring(0, param3.length-1);
			param4 = param4.substring(0, param4.length-1);
			param5 = param5.substring(0, param5.length-1);
		}
	}
	
	if(flag == false){
		$('#createFilterParams').modal('setting', 'closable', false).modal('show');
		$("#inputFilterSelector").hide();

	}else{
		$("#noBrowserData").hide();
		
		var encodedParam4Value= encodeURIComponent(param4);	
		//console.log('  encodedParam4Value '+encodedParam4Value);
		var encodedParam5Value= encodeURIComponent(param5);
		var obj = {
				"searchId":filterId,
				"searchName":filterValue,
				"paramsValue":param1,
				"operatorsValue":param2,
				"param1Value":encodedParam4Value,
				"logicalSelectValue":param3,
				"assetName":browserAssetName,
				"param2Value":encodedParam5Value,
				"taxValue":taxIdNameAppend,
				"userName":loggedInUserName,
				"defaultUserFilterView" : defaultFilterFlag
		};
		//console.log(" update  obj  "+JSON.stringify(obj));
		var url = "http://localhost:9090/repopro/web/assetType/updateFilterSearch";
		//console.log("update url "+url)
		$.ajax({
			type: "PUT",
			url: "/repopro/web/assetType/updateFilterSearch",
			contentType : "application/json",
			dataType : "json",
			data : JSON.stringify(obj),
			async: false,
			complete:function(data){
				appenddata = "";
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					callApplyFilter = true;
					nameFilterFlag = 2;
					loadedFilterName = filterValue;
					loadfilterFlag = false;
					loadBrowseFilterFlag = false;	
					notifyMessage("Update Filter",json.message,"success");
					$('#showHideLoader').removeClass('active');
					
				}
				else {
					callApplyFilter = false;
					notifyMessage("Update Filter","Error attempting to update","fail");
					
				}
			}
		});

	}

	$('#showHideLoader').removeClass('active');
	//Swathi-DefaultFilterView - 30-10-2019
	onloadDisplaySaveFilters();
	}
}

//delete the saved filter

function deleteFilter(){
	var filterId = $("#savedFilterdd option:selected").val();
	var filterDeleted;
	if(filterId == "" || filterId == null){
		notifyMessage("Delete Filter","Please select the saved filter","fail");
	} 
	else{
		var filterDelete = $("#savedFilterdd option:selected").text();
		filterDeleted = filterDelete.replace(/ *\[[^)]*\] */g, "");
		var loadedFilterName1 = $("#defaultfilterName1").text();
		$.ajax({
			type: "DELETE",
			url: "/repopro/web/assetType/deleteFilterSearch?searchId="+filterId,
			dataType: "json",
			complete:function(data){										
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage("Delete Filter","Filter deleted","success");
					//Swathi- Default filter- 24.01.2020
					if(filterId == defaultFilterId){
						loadBrowseFilterFlag = false;
						formRange = 0;
						countNoOfData = 0;
						loadfilterFlag = false;
						$("#browseTable tbody").empty();		
						loadBrowserAssets();
						$("#searchBrowseGridTextBoxDiv_applyFilter").hide();
						$("#noDefaultFilterMessage").show();
						$("#noFilterclickMsg").show();
						$("#clearFilterButton").hide();
						$("#clickFilterMsg").hide();
						$("#defaultFilterMessage").hide();
						$('#tbl_SelectFilterParam tbody').empty();
						$('#addNewTaxonomySegment').empty();
						associateTaxNameArr.length = 0;
						createRow();
						applyShowHide = false;
						callApplyFunction = false;
						// code to for remove icon and edit icon
						setFloatingIconsBtns();
						defaultFilterNameAjax();// swathi-default filter- 30-10-2019
						
					} else if(filterDeleted == loadedFilterName1 || filterDeleted == loadedFilterName){// Handling scenarios when user deletes load filter and Applied filter.
						$('#tbl_SelectFilterParam tbody').empty();
						$('#addNewTaxonomySegment').empty();
						associateTaxNameArr.length = 0;
						createRow();
						$("#searchBrowseGridTextBoxDiv_applyFilter").hide();
						$("#noDefaultFilterMessage").show();
						$("#noDefaultFilterMessage").show();
						$("#noFilterclickMsg").show();
						$("#clearFilterButton").hide();
						$("#clickFilterMsg").hide();
						$("#defaultFilterMessage").hide();
						// to load default filter values
						loadBrowseFilterFlag = true;
						deleteFlagDefaultLoad = true;
						defaultFilterNameAjax();
						viewDefaultFilter();
						//	getAivGroupDetails();
						
						
					}
					nameFilterFlag=0;
					//closeDefault = 0;
					
					if($('#savedFilterdd option').length == "1"){
						$('#savedFilterdd').html("");						
					}
					else{
						$('#savedFilterdd option').each(function(e){
							 if(!$(this).hasClass("selectOneData")){
								 $(this).remove();
							 }
						 });				 				
						
					}
					 $("#savedFilterdd").dropdown('clear');
					 var getSavedFilterList = onloadDisplaySaveFilters();
				     $('#savedFilterdd').append(getSavedFilterList);
				     
				     
				     
				   //Swathi- Default filter- 17.12.2019
					if($('#savedFilterdd option').length == "1"){
						var defaultFilter = $("#savedFilterdd option").text();
						if(defaultFilter.includes("[Default Filter]")){
							$('#removeDefault').show(); 
						} else{
							$('#removeDefault').hide();
						}
					}
					//sessionStorage.setItem('removeDefault', 'true');
					/*loadBrowseFilterFlag = false;
					loadfilterFlag = false;
					flag= false;*/
				
					
				}
				else {
					notifyMessage("Delete Filter","Error attempting to delete filter","fail")
				}
			}
		}); 
	}
	$('#actionClassSelcted .text').html('Actions');
}
//refresh the table content
function refreshTable(){
	
	 $('#tbl_SelectFilterParam tbody').empty();
	 $('#addNewTaxonomySegment').empty();
	 associateTaxNameArr.length = 0;
	 createRow();
     $('#savedFilterdd option').each(function(e){
		 if(!$(this).hasClass("selectOneData")){
			 $(this).remove();
		 }
	 });
     $('#savedFilterdd').dropdown('clear');
	 var getSavedFilterList = onloadDisplaySaveFilters();
     $('#savedFilterdd').append(getSavedFilterList);
     nameFilterFlag = 3;
     //loadBrowseFilterFlag = false;
}

function setCountAndRangeValue(){
	countNoOfData = 0;
	formRange = 0;
	var flag = true;
	$("#browseTable tbody").empty();
	$('#showHideBrowseGridSearchIcon').hide();
	selectAllOnSearchFlagChecked = false; 
	selectAllFlagChecked = false;
	//swathi- returning to default state of bulk access -27-09-2019
	$('.ManagebulkAccess').addClass('disableEdit');
	$('.editManageAccess').removeClass('disableEdit');
	$('#MessageBox').hide();
	$('.bulkAccessonSearch').prop('checked', false);
	$('#exportToExcelIcon').show();
	$(".selectAllCheckBoxonSearch").removeAttr("checked");
	countOnNoButton = true;
	countOnNoSearchButton = true;
	/*//Chandana 24-09-2019 - aligment of manage access for selected header
	$('#menuIconLeftSide').click(function(){
		if ($('#contentPushable').hasClass('sidebarPushable') && $('#searchBrowseGridTextBoxDiv_applyFilter').is(":visible")){
			$('.ManagebulkAccess').attr("style","margin: -0.7em -10em 0em 0em !important;");
		}else{
			 $('.ManagebulkAccess').attr("style","margin: -0.7em -10em 0em 10em !important;");
		}
		
	})
	if ($('#contentPushable').hasClass('sidebarPushable')) {
		$('.ManagebulkAccess').attr("style","margin: -0.7em -10em 0em 0em !important;");
		}else{
			 $('.ManagebulkAccess').attr("style","margin: -0.7em -10em 0em 10em !important;");
		}*/
	
	//loadBrowseFilterFlag = false;
	//Swathi- Bug fix - REPO-639
	if(hideManage ==1){
		$('.ManagebulkAccess ').hide();
	} else{
		$('.ManagebulkAccess ').show();
	}
	applyFilter();	
}
//apply the filter
var etaxIdName;
function applyFilter(){
	$("#filterBrowseGridInputField_applyFilter").val("");
	$("#noDataBrowserAssetData_BrowseSearch").hide();
	$("#browserAssetGrid_BrowseSearch").hide();
	$("#viewDefaultFilterDiv").show(); // swathi - default
	//Chandana -  returning to default state of bulk access - 24-09-2019	
	applyShowHide = true;
	callApplyFunction = true;
	removeFlag = true;
	filterSearchForApply = false;
	var addTaxo = $("#addNewTaxonomySegment a").length;
	var appendTax = "";
	var param1= "";
	var param2 ="";
	var param3 ="";
	var param4;
	var param5;
	var TaxId = "";
	var url;
	applyOperators = "";
	applyAssetParamNames = "";
	applyParam1 = "";
	applyParam2 = "";
	applyLogicalSelect = "";
	applyTax = "";
	etaxIdName = "";
	if ( $('#tbl_SelectFilterParam > tbody > tr').length == 1 ) {
		appendTax = "";
		param1= "";
		param2 ="";
		param3 ="";
		param4 ="";
		param5 ="";
		TaxId = "";
		flag = true;

		var $paramRows = $('#tbl_SelectFilterParam > tbody  > tr');
		var paramSelector = $paramRows.find('td.ddFilterParamSelector').find(':selected').attr("id");
		var optionSelector = $paramRows.find('td.ddOptionSelector').find(':selected').val();
		var logicalSelector = $paramRows.find('td.andOrPara').find(':selected').val();
		var inputValSelector = $paramRows.find('td.inputValueSelector').find("input[type='text']").val();
		var ddParamValSelector = $paramRows.find('td.ddParamValueSelector').find(':selected').text();
		
		if(paramSelector == "Select Parameter" && addTaxo == 0){ 
			param1 = "";
			addTaxo = "";
			$("#noBrowserData").show();
			flag = false;
		}
		else if(paramSelector == "Select Parameter" && addTaxo != 0){
			var taxIdNameAppend = '';
			param1 = "";
			$('.assignTax a').each(function(i){
				var taxData = $(this).attr('id');
				taxData = taxData.split('_');
				TaxId = taxData[1];
				appendTax += TaxId +"~~";
				
				TaxName = taxData[2];
				taxIdNameAppend += TaxId+":"+TaxName+"~";
			})
			appendTax = appendTax.substring(0, appendTax.length-2);
			//Swathi- To store taxonomy value
			etaxIdName = taxIdNameAppend;
			etaxIdName = etaxIdName.substring(0, etaxIdName.length-1);
			clearFlag =0;//swathi

		}
		else if(paramSelector != "Select Parameter" && addTaxo == 0){
			appendTax = "";

			if(paramSelector != undefined || paramSelector != null){
				param1 = param1 + paramSelector + "~~";
				$("#noBrowserData").hide();
				clearFlag =0;//swathi
			}else{
				$("#noBrowserData").show();
				flag = false;
			}				
			if(optionSelector != undefined || optionSelector != null || optionSelector != ""){
				param2 = param2 + optionSelector + "~~";
				$("#noBrowserData").hide();
				clearFlag =0;//swathi
			}else{
				$("#noBrowserData").show();
			}
			
			if(logicalSelector != undefined || logicalSelector != null){
				param3 = param3 + logicalSelector + "~~";
				$("#noBrowserData").hide();
				clearFlag =0;//swathi
			}else{
				$("#noBrowserData").show();
			}

			if($paramRows.find('td.ddParamValueSelector').hasClass('dropDownList')){
				var ddParamValSelector  = $paramRows.find('td.ddParamValueSelector').find(':selected').text();
				if(ddParamValSelector != undefined ){
					param4 = param4 + ddParamValSelector + "~~";
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + " " + "~~";
			}
			else if($paramRows.find('td.inputLdapTextSelector').hasClass('ldapText')){
				var ldapValSelector  = $paramRows.find('td.inputLdapTextSelector').find("input[type='text']").val().trim();
				if(ldapValSelector != undefined && ldapValSelector != ""){//Swathi
					param4 = param4 + ldapValSelector + "~~";
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + " " + "~~";
			}
			else if($paramRows.find('td.inputValueSelector').hasClass('textBoxValue')){
				var inputValSelector  = $paramRows.find('td.inputValueSelector').find("input[type='text']").val().trim();
				if(inputValSelector != "" && inputValSelector != undefined){
					param4 = param4 + inputValSelector + "~~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				if(optionSelector == "Between"){
					var inputTwoValue = $paramRows.find('td.inputValueSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
					if(inputTwoValue != "" && inputTwoValue != undefined){
						param5 = param5 + inputTwoValue + "~~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
				}
				else{
					param5 = param5 + " " + "~~";
				}
			}
			else if($paramRows.find('td.inputDateSelector').hasClass('dateBoxValue')){

				var dateValSelector  =  $paramRows.find('td.inputDateSelector').find("input[type='text']").val();
				if(dateValSelector != "" && dateValSelector != undefined){
					param4 = param4 + dateValSelector + "~~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				if(optionSelector == "Between"){
					var inputTwoValue = $paramRows.find('td.inputDateSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
					if(inputTwoValue != "" && inputTwoValue != undefined){
						param5 = param5 + inputTwoValue + "~~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
				}
				else{
					param5 = param5 + " " + "~~";
				}
			}
			else if($paramRows.find('td.fileSelector').hasClass('fileValue')){
				param4 = param4 + " " + "~~";
				param5 = param5 + " " + "~~";
			}
			else if($paramRows.find('td.inputRichTextSelector').hasClass('richTextValue')){
				var richTextValSelector  = $paramRows.find('td.inputRichTextSelector').find("input[type='text']").val().trim();
				//console.log(" richTextValSelector "+richTextValSelector);
				if(richTextValSelector != "" && richTextValSelector != undefined){
					param4 = param4 + richTextValSelector + "~~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + " " + "~~";
			}
			
			// BOC Hema 07.Mar.2019 ldap Mapping
			else if($paramRows.find('td.inputLdapMappingTextSelector').hasClass('ldapMappingText')){
				var ldapMappingValSelector  = $paramRows.find('td.inputLdapMappingTextSelector').find("input[type='text']").val().trim();
				if(ldapMappingValSelector != "" && ldapMappingValSelector != undefined){
					param4 = param4 + ldapMappingValSelector + "~~";
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + " " + "~~";
			}
			// EOC
			//console.log(" 1-----   param1  "+param1+" param2  "+param2+" param3  "+param3+" param4  "+param4+" param5  "+param5)
		}
		else if(paramSelector != "Select Parameter" && addTaxo != 0){

				$("#noBrowserData").hide();

				if(paramSelector != undefined || paramSelector != null){
					param1 = param1 + paramSelector + "~~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
					flag = false;
				}

				if(optionSelector != undefined || optionSelector != null || optionSelector != ""){
					param2 = param2 + optionSelector + "~~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
				}
				if(logicalSelector != undefined || logicalSelector != null){
					param3 = param3 + logicalSelector + "~~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();

				}
				if($paramRows.find('td.ddParamValueSelector').hasClass('dropDownList')){
					var ddParamValSelector  = $paramRows.find('td.ddParamValueSelector').find(':selected').text();
					if(ddParamValSelector != undefined ){
						param4 = param4 + ddParamValSelector + "~~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}
					
					param5 = param5 + " " + "~~";
					
				}
				else if($paramRows.find('td.inputLdapTextSelector').hasClass('ldapText')){
					var ldapValSelector  = $paramRows.find('td.inputLdapTextSelector').find("input[type='text']").val().trim();
					if(ldapValSelector != undefined && ldapValSelector != ""){//Swathi
						param4 = param4 + ldapValSelector + "~~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}
					param5 = param5 + " " + "~~";
				}
				else if($paramRows.find('td.inputValueSelector').hasClass('textBoxValue')){
					var inputValSelector  = $paramRows.find('td.inputValueSelector').find("input[type='text']").val().trim();
					if(inputValSelector != "" && inputValSelector != undefined){
						param4 = param4 + inputValSelector + "~~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $paramRows.find('td.inputValueSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~~";
						}else{
							$("#noBrowserData").show();
							flag = false;
						}
					}
					else{
						param5 = param5 + " " + "~~";
					}
				}
				else if($paramRows.find('td.inputDateSelector').hasClass('dateBoxValue')){

					var dateValSelector  =  $paramRows.find('td.inputDateSelector').find("input[type='text']").val();
					if(dateValSelector != "" && dateValSelector != undefined){
						param4 = param4 + dateValSelector + "~~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $paramRows.find('td.inputDateSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~~";
						}else{
							$("#noBrowserData").show();
							flag = false;
						}
					}
					else{
						param5 = param5 + " " + "~~";
					}
				}
				else if($paramRows.find('td.fileSelector').hasClass('fileValue')){
					param4 = param4 + " " + "~~";
					param5 = param5 + " " + "~~";
				}
				else if($paramRows.find('td.inputRichTextSelector').hasClass('richTextValue')){
					var richTextValSelector  = $paramRows.find('td.inputRichTextSelector').find("input[type='text']").val().trim();
					//console.log(" richTextValSelector "+richTextValSelector);
					if(richTextValSelector != "" && richTextValSelector != undefined){
						param4 = param4 + richTextValSelector + "~~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
					param5 = param5 + " " + "~~";
				} 
				
				// BOC Hema 07.Mar.2019 ldap Mapping
				else if($paramRows.find('td.inputLdapMappingTextSelector').hasClass('ldapMappingText')){
					var ldapMappingValSelector  = $paramRows.find('td.inputLdapMappingTextSelector').find("input[type='text']").val().trim();
					if(ldapMappingValSelector != "" && ldapMappingValSelector != undefined){
						param4 = param4 + ldapMappingValSelector + "~~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}
					param5 = param5 + " " + "~~";
				}
				//EOC
				var taxIdNameAppend = '';
				$('.assignTax a').each(function(i){
					var taxData = $(this).attr('id');
					taxData = taxData.split('_');
					TaxId = taxData[1];
					appendTax += TaxId +"~~";
				
					TaxName = taxData[2];
					taxIdNameAppend += TaxId+":"+TaxName+"~";
					
				})
				appendTax = appendTax.substring(0, appendTax.length-2);
				etaxIdName = taxIdNameAppend;
				etaxIdName = etaxIdName.substring(0, etaxIdName.length-1);
			}
	}
	else{
		var appendTax = "";
		var param1= "";
		var param2 ="";
		var param3 ="";
		var param4 ="";
		var param5 ="";
		var TaxId = "";
		flag = true;
		$("#noBrowserData").hide();

		$('#tbl_SelectFilterParam > tbody  > tr').each(function() {
			
			$(this).find('td.ddFilterParamSelector').each(function() {
				var paramSelector = $(this).find(':selected').attr("id");
				if(paramSelector != undefined){
					param1 = param1 + paramSelector + "~~";
					$("#noBrowserData").hide();
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
			});

			var optionSelector = "";
			$(this).find('td.ddOptionSelector').each(function() {
				optionSelector = $(this).find(':selected').val();
				if(optionSelector != undefined){
					param2 = param2 + optionSelector + "~~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
					//flag = false;
				}
			});


			$(this).find('td.andOrPara').each(function() {
				var logicalSelector  = $(this).find(':selected').val();
				if(logicalSelector != undefined){
					param3 = param3 + logicalSelector + "~~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
					//flag = false;
				}

			});

			if($(this).find('td.ddParamValueSelector').hasClass('dropDownList')){
				
				$(this).find('td.ddParamValueSelector').each(function() {
					var ddParamValSelector  = $(this).find(':selected').text();
					if(ddParamValSelector != undefined ){
						param4 = param4 + ddParamValSelector + "~~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}		
				});
				param5 = param5 + " " + "~~";
			}
			else if($(this).find('td.inputLdapTextSelector').hasClass('ldapText')){
				$(this).find('td.inputLdapTextSelector').each(function() {
					var ldapValSelector  = $(this).find("input[type='text']").val().trim();
					if(ldapValSelector != undefined && ldapValSelector != "" ){//Swathi
						param4 = param4 + ldapValSelector + "~~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}		
				});
				param5 = param5 + " " + "~~";
			}
			
			else if($(this).find('td.inputValueSelector').hasClass('textBoxValue')){				
				
				$(this).find('td.inputValueSelector').each(function() {
					var inputValSelector  = $(this).find("input[type='text']").val();
					if(inputValSelector != undefined && inputValSelector != ""){
						param4 = param4 + inputValSelector + "~~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $(this).find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~~";
						}else{
							$("#noBrowserData").show();
							flag = false;
						}
					}
					else{
						param5 = param5 + " " + "~~";
					}
					
				});
			}
			else if($(this).find('td.inputDateSelector').hasClass('dateBoxValue')){
				
				$(this).find('td.inputDateSelector').each(function() {
					var dateValSelector  = $(this).find("input[type='text']").val();
					if(dateValSelector != "" && dateValSelector != undefined){
						param4 = param4 + dateValSelector + "~~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $(this).find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~~";
						}else{
							$("#noBrowserData").show();
							flag = false;
						}
					}
					else{
						param5 = param5 + " " + "~~";
					}
				});
			}
			else if($(this).find('td.fileSelector').hasClass('fileValue')){
				param4 = param4 + " " + "~~";
				param5 = param5 + " " + "~~";
			}
			
			else if($(this).find('td.inputRichTextSelector').hasClass('richTextValue')){
				var richTextValSelector  = $(this).find('td.inputRichTextSelector').find("input[type='text']").val().trim();
				//console.log(" richTextValSelector "+richTextValSelector);
				if(richTextValSelector != "" && richTextValSelector != undefined){
					param4 = param4 + richTextValSelector + "~~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + " " + "~~";
			}
			
			// BOC Hema 07.Mar.2019 Ldap mapping
			else if($(this).find('td.inputLdapMappingTextSelector').hasClass('ldapMappingText')){
				$(this).find('td.inputLdapMappingTextSelector').each(function() {
					var ldapMappingValSelector  = $(this).find("input[type='text']").val().trim();
					if(ldapMappingValSelector != "" && ldapMappingValSelector != undefined){
						param4 = param4 + ldapMappingValSelector + "~~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}		
				});
				param5 = param5 + " " + "~~";
			}
			
		});


		var TaxId = "";
		var appendTax = "";
		var taxIdNameAppend = '';
		$('.assignTax a').each(function(i){
			var taxData = $(this).attr('id');
			taxData = taxData.split('_');
			TaxId = taxData[1];
			appendTax += TaxId +"~~";			
			TaxName = taxData[2];
			taxIdNameAppend += TaxId+":"+TaxName+"~";
		});		
		
		appendTax = appendTax.substring(0, appendTax.length-2);		
		etaxIdName = taxIdNameAppend;
		etaxIdName = etaxIdName.substring(0, etaxIdName.length-1);
	}	
	// Swathi- Default filter- store entered values to variables for strting matching
	 eOParam1 = param1.toString();
	 eOParam2 = param2.toString();
	 eOParam3 = param3.toString();
	 eOParam4 = param4.toString();	
	 eOParam5 = param5.toString();	
	 eOtax = appendTax.toString();
	
	eParam1 = eOParam1.substring(0, param1.length-2);
	eParam2 = eOParam2.substring(0, param2.length-2);
	eParam3 = eOParam3.substring(0, param3.length-2);
	eParam4 = eOParam4.substring(0, param4.length-2);	
	eParam5 = eOParam5.substring(0, param5.length-2);
	/*eParam3 = eParam3.replace(/ /g,"undefined");
	eParam5 = eParam5.replace(/ /g,"undefined");*/
	
	eParam1 = eParam1.replace(/~~/g,"~");
	eParam2 = eParam2.replace(/~~/g,"~");
	eParam3 = eParam3.replace(/~~/g,"~");
	eParam4 = eParam4.replace(/~~/g,"~");
	eParam5 = eParam5.replace(/~~/g,"~");	
	
	var str = '';
	var enteredString = str.concat(eParam1,eParam2,eParam3,eParam4,eParam5,eOtax);
	//Swathi- 09.12.2019-- Code to display default filter page if loadBrowseFilterFlag is true else load filtered page 
	var sessionVal1 = sessionStorage.getItem("removeDefault");
	//Adding flag != false - Flag is set to false under empty input scenarios, hence restricting to enter the default value scenario
	if(loadBrowseFilterFlag == true && sessionVal1 == "false" && flag != false){	
		defaultString = defaultString;
		defaultFilterName = defaultFilterName;
		var tilt = "~~";
		dassetParamNames = dassetParamNames;
		// Removing extra tilts
		dassetParamNames = dassetParamNames.replace(/~~$/, '');
		
		dassetParamNames = dassetParamNames.replace(/~/g,"~~");
		// Removing extra tilts
		if(dassetParamNames.includes("~~~~")){
			dassetParamNames = dassetParamNames.replace("~~~~","~~");
		}
		dassetParamNames = dassetParamNames.concat(tilt);
		// Removing extra tilts
		if(dassetParamNames.includes("~~~~")){
			dassetParamNames = dassetParamNames.replace("~~~~","~~");
		}
		
		
		doperators = doperators;
		doperators = doperators.replace(/~~$/, '');// Removing extra tilts	
		doperators = doperators.replace(/~/g,"~~");	
		// Removing extra tilts
		if(doperators.includes("~~~~")){
			doperators = doperators.replace("~~~~","~~");
		}
		doperators = doperators.concat(tilt);
		// Removing extra tilts
		if(doperators.includes("~~~~")){
			doperators = doperators.replace("~~~~","~~");
		}
		
		
		dlogicalSelect= dlogicalSelect;
		dlogicalSelect = dlogicalSelect.replace(/~~$/, '');// Removing extra tilts
		
		dlogicalSelect = dlogicalSelect.replace(/~/g,"~~");
		// Removing extra tilts
		if(dlogicalSelect.includes("~~~~")){
			dlogicalSelect = dlogicalSelect.replace("~~~~","~~");
		}
		dlogicalSelect = dlogicalSelect.concat(tilt);
		// Removing extra tilts
		if(dlogicalSelect.includes("~~~~")){
			dlogicalSelect = dlogicalSelect.replace("~~~~","~~");
		}
		
		
		dparam1Value = dparam1Value;
		dparam1Value= dparam1Value.replace(/~~$/, '');	// Removing extra tilts
		
		dparam1Value = dparam1Value.replace(/~/g,"~~");
		// Removing extra tilts
		if(dparam1Value.includes("~~~~")){
			dparam1Value= dparam1Value.replace("~~~~","~~");
		}
		dparam1Value = dparam1Value.concat(tilt);
		// Removing extra tilts
		if(dparam1Value.includes("~~~~")){
			dparam1Value= dparam1Value.replace("~~~~","~~");
		}
		
		dparam2Value = dparam2Value;
		dparam2Value = dparam2Value.replace(/~~$/, '');	// Removing extra tilts
		
		dparam2Value = dparam2Value.replace(/undefined/g," ");
		dparam2Value = dparam2Value.replace(/~/g,"~~");
		// Removing extra tilts
		if(dparam2Value.includes("~~~~")){
			dparam2Value = dparam2Value.replace("~~~~","~~");
		}
		dparam2Value = dparam2Value.concat(tilt);
		// Removing extra tilts
		if(dparam2Value.includes("~~~~")){
			dparam2Value = dparam2Value.replace("~~~~","~~");
		}
		
		param1= dassetParamNames;  
		param2= doperators;     
		param3= dlogicalSelect; 
		param4= dparam1Value;  
		param5= dparam2Value; 
		appendTax = dtaxId; 
		nameFilterFlag = 1;
		
	} 
	//EOC- Default filter
	if(flag == false){		
		$("#noBrowserData").show();
		$('#createFilterParams').modal('setting', 'closable', false).modal('show');
		//Swathi- restricting to enter the default value loop - Bug Fix- REPO-695, REPO-706, REPO-696(Empty Fields scenario)
		sessionStorage.setItem('removeDefault', 'true');
		loadfilterFlag = false;
		loadBrowseFilterFlag = false; //End - default filter
		getAivGroupDetails(); 
		$("#removeFilter").hide();
		if(editApplyFilterFlag){
		   $("#searchBrowseGridTextBoxDiv").hide();
		} else{
			 $("#searchBrowseGridTextBoxDiv_applyFilter").hide();
		}
		//$("#searchBrowseGridTextBoxDiv").hide();
		callApplyFunction = false;
		applyShowHide = false; 
		
	}else{
		$("#noBrowserData").hide();	
		
		//swathi- BOC - Default filter - To  show the confirmation box on click of Apply button- 10.12.2019	
		var filter = $("#savedFilterdd option:selected").text();
		
		if((nameFilterFlag == 1) ){
			if(defaultString != enteredString && enteredString != "" ){
				$('#openConfirmationofSaveDefault').modal('setting', 'closable', false).modal('show');
				$("#clickFilterMsg").show();
				$("#noFilterclickMsg").hide();
				$("#defaultFilterMessage").show();
				$("#noDefaultFilterMessage").hide();
				param1= eOParam1;  
				param2= eOParam2;     
				param3= eOParam3; 
				param4= eOParam4;  
				param5= eOParam5; 
				appendTax = eOtax; 
				//nameFilterFlag = 0;
			} else {
				param1= dassetParamNames;  
				param2= doperators;     
				param3= dlogicalSelect; 
				param4= dparam1Value;  
				param5= dparam2Value; 
				appendTax = dtaxId; 
				$("#defaultfilterName").text(defaultFilterName);
				$("#defaultfilterName1").text(defaultFilterName);
				$("#clickFilterMsg").show();
				$("#noFilterclickMsg").hide();
				$("#defaultFilterMessage").show();
				$("#noDefaultFilterMessage").hide();
				//nameFilterFlag = 0;
			}
		} else if(nameFilterFlag == 2){
			$("#clickFilterMsg").show();
			$("#noFilterclickMsg").hide();
			$("#defaultFilterMessage").show();
			$("#noDefaultFilterMessage").hide();
			$("#defaultfilterName").text(loadedFilterName);	
			$("#defaultfilterName1").text(loadedFilterName);
		}   else if(defaultFilterName == filter && defaultFilterName != "" ){
			$("#defaultfilterName").text(defaultFilterName);
			$("#defaultfilterName1").text(defaultFilterName);
		
		} else{
			param1= eOParam1;  
			param2= eOParam2;     
			param3= eOParam3; 
			param4= eOParam4;  
			param5= eOParam5; 
			appendTax = eOtax; 
			$("#defaultfilterName").text("Unnamed");
			$("#defaultfilterName1").text("Unnamed");		
			$("#clickFilterMsg").show();
			$("#noFilterclickMsg").hide();
			$("#defaultFilterMessage").show();
			$("#noDefaultFilterMessage").hide();
			//nameFilterFlag = 0;
		}
			
		param1 = param1.substring(0, param1.length-2);
		param2 = param2.substring(0, param2.length-2);
		param3 = param3.substring(0, param3.length-2);
		param4 = param4.substring(0, param4.length-2);
		param5 = param5.substring(0, param5.length-2);
		
		//var encodedAssetParamNames = encodeURIComponent(param1);
		
		var encodedParam1Value= encodeURIComponent(param4);
		encodedParam1Value = encodedParam1Value.replace(/'/g, "\\'");
		encodedParam1Value = encodedParam1Value.replace(/"/g, '\\"');
		//console.log("  encodedParam1Value "+encodedParam1Value);
		
		var encodedParam2Value= encodeURIComponent(param5);
		encodedParam2Value = encodedParam2Value.replace(/'/g, "\\'");
		encodedParam2Value = encodedParam2Value.replace(/"/g, '\\"');
		//console.log("  encodedParam2Value "+encodedParam2Value);	
		
		
		var encodedOperatorValue= encodeURIComponent(param2);
		encodedOperatorValue = encodedOperatorValue.replace(/'/g, "\\'");
		encodedOperatorValue = encodedOperatorValue.replace(/"/g, '\\"');
		applyOperators = param2;
		applyAssetParamNames = param1;
		applyParam1 = encodedParam1Value;
		applyParam2 = encodedParam2Value;
		applyLogicalSelect = param3;
		applyTax = appendTax;
		
		url = "/repopro/web/assetInstanceVersionManager/getAssetInstanceByFilter?userName="+loggedInUserName+"&assetName="+encodeURIComponent(browserAssetName)+"&assetId="+browserAssetId+"&operators="+encodedOperatorValue+"&assetParamNames="+param1+"&param1Values="+encodedParam1Value+"&param2Values="+encodedParam2Value+"&logicalSelect="+param3+"&taxonomyNames="+appendTax+"&from="+formRange;
		//console.log("apply filter http://localhost:8080"+url);
		
		if(adminFlag == true){
		$.ajax({ 
			type : "GET",
			url : "/repopro/web/assetInstanceVersionManager/totalCountOfInstancesByFilter?userName="+loggedInUserName+"&assetName="+encodeURIComponent(browserAssetName)+"&assetId="+browserAssetId+"&operators="+encodedOperatorValue+"&assetParamNames="+param1+"&param1Values="+encodedParam1Value+"&param2Values="+encodedParam2Value+"&logicalSelect="+param3+"&taxonomyNames="+appendTax,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					getCountofInstances = "";
					getCountofInstances = json.paramValues.count; 
					getAIVids = [];
					getAIVids = json.paramValues.AivIds; 
				}
			}
		});
		}
		
		$.ajax({ 
			type : "GET",
			url : url,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					/*$('#createFilterParams').modal('hide');  //.modal('hide dimmer');
					$('#createFilterParams').parent().css("display", "none !important");*/
					$('#createFilterParams').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
					if(json.result == "" || json.result == null || json.result == []){
						//checkCompositionAggregationAssetType(); // added by hema 0n 29.Mar.2018 applyFilter
						if(countNoOfData == 0){
							noDataFlag_applyFilter = true;
							$("#searchBrowseGridTextBoxDiv_applyFilter").hide();
							$("#noDataBrowserAssetData").show();
							$('.ManagebulkAccess').hide();
							$("#noDataBrowserAssetData").html('<div class="ui negative message" style="margin-top:3em;"><div class="header">No records to show</div></div>');						
							$("#browserAssetGrid").hide();
							$("#browserInstances").hide();
							$("#filterSearchTbody").hide();
							//$("#browserAssetGrid_BrowseSearch").hide();
							$("#noDataBrowserAssetData_BrowseSearch").hide();
							//callApplyFunction = false;
							infiniteScrollFlag = false;
							$("#removeFilter").show();
							$("#clearFilterButton").show();
							//$("#viewDefaultFilterDiv").hide();// Swathi- code to show defaultfilter
							//$("#removeFilter").css("bottom", "2em");
							
						}
						else{
							//callApplyFunction = false;
							infiniteScrollFlag = false;
							$('#loadingMoreAssetDetails').css('display', 'none');
						}
						
						
					}
					else{
						if((loadBrowseFilterFlag == false) && (alertFlag == false)){
							notifyMessage('Apply Filter','Filter applied','success');
						}
						noDataFlag_applyFilter = false;
						infiniteScrollFlag = true;
						$("#noDataBrowserAssetData").hide();
						$("#searchBrowseGridTextBoxDiv_applyFilter").show();
						$("#browserAssetGrid").show();
						$("#browserInstances").show();
						$("#viewDefaultFilterDiv").show(); // swathi -default
						$("#clearFilterButton").show();		
						$.each(json.result, function(i) {
							var paramNameWithValues = "";
							if(json.result[i].paramNameWithValues == null){
								paramNameWithValues = "No Data";
							}
							else{
								$.each(json.result[i].paramNameWithValues, function(key, value) {
									var deriveFlag = false;
									var deriveId = "";
									if(value != null){
										if(value.indexOf("^^DA^^") != -1){
										    deriveFlag = true;
										    var data = value.split("~");
										    //console.log(data);
										    var data1  = (data[3]).split("`@`");
										    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
										    getDeriveAttrData(data[1],data1[0]);
										}
										if(value.indexOf("^^DC^^") != -1){
										    deriveFlag = true;
										    var data = value.split("~");
										    var data1  = (data[3]).split("`@`");
										    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
										    getDerivedComputationData(data[1],data1[0]);
										}
										
										// BOC Hema 14.Mar.2019- Auto Complete
										if(value.indexOf("^^AC^^") != -1){
										    deriveFlag = true;
										    var data = value.split("~");
										    var data1  = (data[3]).split("`@`");
										    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
										    getAutoCompleteData(data[1],data1[0]);
										}
										//EOC
									}
									
									paramNameWithValues += getParamNameWithValues(key, value,deriveFlag,deriveId,json.result[i].assetInstVersionId, json.result[i].assetInstName);
								});
							}

							appendData = getAssetInstData(json.result[i].assetInstVersionId, json.result[i].assetInstName, json.result[i].versionName, json.result[i].description, paramNameWithValues, json.result[i].showHideParamCount,json.result[i].assetInstId,json.result[i].versionable,json.result[i].deleteAccessFlag,json.result[i].deleteInstanceFlag); //Chandana 10-06-2019 (flag has been refered)
							if(removeFlag == false){
								$("#removeFilter").hide();

							}else{
								$("#removeFilter").show();
							}
							$("#browseTable").append(appendData);
							countNoOfData++;
						});

						formRange = formRange + 20;
					}
					$('#loadingMoreAssetDetails').css('display', 'none');
					
				}
				else{
					//callApplyFunction = false;
					infiniteScrollFlag = false;
					$('#createFilterParams').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
					/*$('#createFilterParams').modal('hide'); //.modal('hide dimmer');
					$('#createFilterParams').parent().css("display", "none !important");*/
					$('#loadingMoreAssetDetails').css('display', 'none');
					$("#noDataBrowserAssetData").show();
					$('.ManagebulkAccess').hide();
					$("#noDataBrowserAssetData").html('<div class="ui negative message"><div class="header">No filters applied</div>');
					$("#browserAssetGrid").hide();
					$("#browserInstances").hide();
					$("#removeFilter").show();
					//$("#removeFilter").css("bottom", "2em");
					
					//$("#viewDefaultFilterDiv").hide();// swathi- default filter
					$("#clickFilterMsg").hide();
					$("#clearFilterButton").hide();
				}
			}
		});
		$("#browserAssetGrid > h3").html('');
		$('#floatingActionBtn').hide();
		$('#appliedEditRemove').show();
		setFloatingIconsForApplyFilter();
		/*checkCompositionAggregationAssetType(); // commented by hema 0n 29.Mar.2018 */
		$("#searchBrowseGridTextBoxDiv").hide();
		$('#showHideLoader').removeClass('active');	// Swathi- REPO-716 fix
		$("#showHideLoader").hide(); // swathi- default filter first time load
		//$("#searchBrowseGridTextBoxDiv_applyFilter").show();
		//filterSearchForApply = true;
	}	
}
function showAppliedData(){	
	//Swathi- BOC -Code for default filter- 10.12.2019
	$("#defaultFilterCheck").prop("checked", false );// REPO-630 fix
	 $("#actionClassSelcted .text").text("Actions"); 
	
	if(loadBrowseFilterFlag == true){
		viewDefaultFilter();
	}else{
		$('#filterName').text("Edit ");
		filterExportSearchflag = false;
		if($("#searchBrowseGridTextBoxDiv").is(":visible")){
			editApplyFilterFlag = true;
		} else{
			editApplyFilterFlag = false;
		}
		
		$('#createFilterParams').modal('show');
	}	
}

function removeAppliedData(){
	//Swathi- BOC -Code for default filter- 10.12.2019
	sessionStorage.setItem('removeDefault', 'true');
	loadBrowseFilterFlag = false;
	$("#createFilterParams").remove();
	$('#loadContent').load('browser.html');	
}

//Kavya EOC


//open Asset Instance Access Modal -- Hema
var assetInstanceAccessGroupList = [];
var AssetInstanceNewId = "";
function openGroupDetailsAssetInstAccessModal(assetInstanceVersionId){
	
	 assetInstanceAccessGroupList.length = 0;
	$('#btnsubmitAssetInstanceAccess').unbind();  //add submit button id
	$('#btncancelAssetInstanceAccess').unbind();
	$('#openShowGrpAssetInstanceAccessModal').modal('destroy');
	$('#openShowGrpAssetInstanceAccessModal').modal('setting', 'closable', false).modal('show').modal('refresh');
	
	if($("#browserAssetGrid").is(":visible")){
		var instanceName = $("#assetInstName_"+assetInstanceVersionId).text();
	}else{
		var instanceName = $("#assetInstName1_"+assetInstanceVersionId).text();
	}
	$("#openShowGrpAssetInstanceAccessModalInstanceName").text(instanceName);
	AssetInstanceNewId = assetInstanceVersionId;
	$.ajax({
		type : "GET",
		url : '/repopro/web/assetInstanceVersionManager/viewGroupsWithSingleAIAccess?userName='+loggedInUserName+'&aivId='+AssetInstanceNewId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$("#gridAssetInstanceAccess table tbody").html("");
				$.each(json.result, function(i) {
					assetInstanceAccessGroupList.push(json.result[i].groupId);
					var getAssetInstanceAccessData = loadAssetInstanceAccessData(json.result[i].groupId, json.result[i].groupName, json.result[i].editAccess, json.result[i].viewAccess, json.result[i].deleteAccess);
					$("#gridAssetInstanceAccess table tbody").append(getAssetInstanceAccessData);
				});

			}

		}
	});

	$('#gridAssetInstanceAccess table tbody tr').each(function(i){

		var $tds = $(this).find('td'),
		groupId = $tds.eq(0).attr("id"),
		groupId = groupId.split("_")[1];
		groupId = parseInt(groupId);

		$('input[id=editCB_'+groupId+']').on('click',function(){
			$('input[id=viewCB_'+groupId+']').prop("checked", true );
		});
		$('input[id=viewCB_'+groupId+']').on('click',function(){
			if(!$('input[id=viewCB_'+groupId+']').is(':checked')){
				$('input[id=editCB_'+groupId+']').prop("checked", false );
				$('input[id=deleteCB_'+groupId+']').prop("checked", false );
			}
		});
		$('input[id=deleteCB_'+groupId+']').on('click',function(){
			$('input[id=viewCB_'+groupId+']').prop("checked", true );
		});
	});
	
	var categoryWiseArr = [];
	$("#btnsubmitAssetInstanceAccess").on('click', function(){
		categoryWiseArr.length = 0;
		$.each(assetInstanceAccessGroupList,function(i){
			var editFlag , viewFlag , deleteFlag;
			if($("#editCB_"+assetInstanceAccessGroupList[i]).prop("checked")){
				editFlag = 1;
			}else{
				editFlag = 0;
			}
	
			if($("#viewCB_"+assetInstanceAccessGroupList[i]).prop("checked")){
				viewFlag = 1;
			}else{
				viewFlag = 0;
			}
			if($("#deleteCB_"+assetInstanceAccessGroupList[i]).prop("checked")){
				deleteFlag = 1;
			}else{
				deleteFlag = 0;
			}
	
			categoryWiseArr.push({"assetInstversionId":AssetInstanceNewId,"groupId":assetInstanceAccessGroupList[i],"editAccess":editFlag,"viewAccess":viewFlag,"deleteAccess":deleteFlag});
	
		});
	
		$.ajax({
			type: "PUT",
			url: "/repopro/web/assetInstanceVersionManager/saveGroupsAccessSingleAISubmit?aivId="+AssetInstanceNewId,
			contentType : "application/json",
			dataType : "json",
			data : JSON.stringify(categoryWiseArr),
			async: false,
			complete:function(data){	
				appenddata = "";
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage("Update Asset Instance Access","Asset Instance Access Updated","success");
					 $('#openShowGrpAssetInstanceAccessModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
					/*$('#openShowGrpAssetInstanceAccessModal').modal('hide'); //.modal('hide dimmer');
					$('#openShowGrpAssetInstanceAccessModal').parent().css("display", "none !important");*/
				}
				else {
					notifyMessage("Update Asset Instance Access",json.message,"fail");
				}
			}
	
		});	
		
});
	
}

//load Asset Instance Access Data
function loadAssetInstanceAccessData(groupId, groupName, editAccess, viewAccess, deleteAccess){
	appendData = "";
	appendData += '<tr>';
	if(groupName != "group-admin" || groupName != "role-admin" || groupName != "Guest"){
		appendData += '<td class="left aligned whitespaceNoTrim" id="groupName_'+groupId+'">'+groupName+'</td>';
	}
	appendData += '<td class="center aligned"><div class="ui checkbox">';
	if(editAccess == 0){
		appendData += '<input type="checkbox" id="editCB_'+groupId+'" name="example" class="eidtCB"><label></label>';
	}
	else if(editAccess == 1){
		appendData += '<input type="checkbox" id="editCB_'+groupId+'" name="example" checked class="eidtCB"><label></label>';
	}
	else{
		appendData += '<input type="checkbox" id="editCB_'+groupId+'" name="example" checked class="eidtCB greyCheckBox"><label></label>';
	}
	appendData += '</div></td>';
	appendData += '<td class="center aligned"><div class="ui checkbox">';
	if(viewAccess == 0){
		appendData += '<input type="checkbox" id="viewCB_'+groupId+'" name="example" class="viewCB"><label></label>';
	}else if(viewAccess == 1){
		appendData += '<input type="checkbox" id="viewCB_'+groupId+'" name="example" checked class="viewCB"><label></label>';
	}else {
		appendData += '<input type="checkbox" id="viewCB_'+groupId+'" name="example" checked class="viewCB greyCheckBox"><label></label>';
	}
	appendData += '</div></td>';
	appendData += '<td class="center aligned"><div class="ui checkbox">';
	if(deleteAccess == 0){
		appendData += '<input type="checkbox" id="deleteCB_'+groupId+'" name="example" class="deleteCB"><label></label>';
	}else  if(deleteAccess == 1){
		appendData += '<input type="checkbox" id="deleteCB_'+groupId+'" name="example" checked class="deleteCB"><label></label>';
	}else {
		appendData += '<input type="checkbox" id="deleteCB_'+groupId+'" name="example" checked class="deleteCB greyCheckBox"><label></label>';
	}
	appendData += '</div></td>';
	appendData += '</tr>';
	return appendData;

}

//update Asset Instance Access Data
/*var categoryWiseArr = [];
function submitAssetInstanceAccessData(){
	categoryWiseArr.length = 0;
	$.each(assetInstanceAccessGroupList,function(i){
		var editFlag , viewFlag , deleteFlag;
		if($("#editCB_"+assetInstanceAccessGroupList[i]).prop("checked")){
			editFlag = 1;
		}else{
			editFlag = 0;
		}

		if($("#viewCB_"+assetInstanceAccessGroupList[i]).prop("checked")){
			viewFlag = 1;
		}else{
			viewFlag = 0;
		}
		if($("#deleteCB_"+assetInstanceAccessGroupList[i]).prop("checked")){
			deleteFlag = 1;
		}else{
			deleteFlag = 0;
		}

		categoryWiseArr.push({"assetInstversionId":AssetInstanceNewId,"groupId":assetInstanceAccessGroupList[i],"editAccess":editFlag,"viewAccess":viewFlag,"deleteAccess":deleteFlag});

	});

	$.ajax({
		type: "PUT",
		url: "/repopro/web/assetInstanceVersionManager/saveGroupsAccessSingleAISubmit?aivId="+AssetInstanceNewId,
		contentType : "application/json",
		dataType : "json",
		data : JSON.stringify(categoryWiseArr),
		async: false,
		complete:function(data){	
			appenddata = "";
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				notifyMessage("Update Asset Instance Access","Asset instance access details updated","success");
				$('#openShowGrpAssetInstanceAccessModal').modal('hide'); //.modal('hide dimmer');
				$('#openShowGrpAssetInstanceAccessModal').parent().css("display", "none !important");
			}
			else {
				notifyMessage("Update Asset Instance Access",json.message,"fail");
			}
		}

	});	

}*/

function ExportBrowseGrid(){
	$('#browseAssetGridExport').attr('href','/repopro/web/export/exportBrowseGrid/admin?assetName='+sessionStorage.getItem("browserAssetName")+'&assetId='+browserAssetId+'&userId='+loggedInUserId);
}


$('#displayTaxonomy').on('click',function(){
	displayTaxonomy();
})


var chckExistingTaxNameFlag = false;
var associateTaxNameArr = [];
var browser_taxTreeFlag = true;
function displayTaxonomy(){
	
	if(browser_taxTreeFlag){
		browser_taxTreeFlag = false;
		jQuery.ajax({
			type : "GET",
			url : "/repopro/web/taxonomy/getAssetTaxonomy?assetId="+browserAssetId,
			dataType : "json",
			contentType : 'application/json',
			async : false,
			complete : function(data) {
				json = JSON.parse(data.responseText);
				if(json.result == "" || json.result == null){
					$('.noTaxonomyData').show().html('<div class="ui warning message" id="noAssetTaxonomy"><p style="text-align: center !important;">There are no assigned taxonomies added yet</p></div>');
					$('#treeContainer').hide();
				}
				else {
					/*$.each(json.result, function(i) {
							$('#addNewTaxonomySegment').append('<a class="ui label" id="taxonomyName_'+json.result[i].taxonomyId+'_'+json.result[i].taxonomyName.replace(/ /g,"_")+'" style="margin-bottom:0.5em;"><span style="display:none;">'+json.result[i].taxonomyId+'</span><i class="fork icon"></i>'+json.result[i].taxonomyName+'</a>');
							taxFromBackend.push({"taxId":json.result[i].taxonomyId, "taxName":json.result[i].taxonomyName});
						});*/
					$('.noTaxonomyData').hide();
					$('#treeContainer').show();
					$('#tree1').show();
					$('#tree1').tree({
						data : json.result,
						autoOpen : false
					});
					
					
					jQuery('.jqtree-title').each(function(e){
						var item = jQuery(this);
						item.css('display','inline-block');
						var valTax = jQuery(this).text();
						var valTax1 = valTax.split("|");
						var val = valTax1[0];
						var val1 = valTax1[1];
						jQuery(this).text(val);
						item.parent().append("<span id="+val1+" class='someCls'></span>");
						jQuery(this).addClass('treeViewElement');
						$('#addNewTaxonomySegment').append("");
						jQuery(this).unbind('click');
						//associateTaxNameArr.length = 0;
						jQuery(this).on("click",function(h){
							for (var j = 0; j < associateTaxNameArr.length; j++) {
								if(associateTaxNameArr[j] == val){
									chckExistingTaxNameFlag = true;
									break;
								}
							}
							if(chckExistingTaxNameFlag == false){
								associateTaxNameArr.push(val);
								associateTaxNameArr = $.unique(associateTaxNameArr);
								$('#addNewTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\')"></i></a>');
							}
							else {
								notifyMessage("Assign Taxonomy","Taxonomy " + val +" is already assigned","fail");
								chckExistingTaxNameFlag = false;
							}
						})
						jQuery(this).css('pointer','cursor');
					});
				}
			}
		});
}
	jQuery("#hideTaxId").change(function(e){
		//to get unused taxonomies
		var taxinList = new Array;
		jQuery.ajax({
			url: '/repopro/web/taxonomy/getTaxonomiesUsedByAssets',
			dataType: "json",
			async: false,
			success: function(data)
			{
				// actually here success is error portion and error is success (sending response in opposite way)

			}, 

			error: function(err){
				var json = JSON.parse(err.responseText);
				var taxonIds = "";
				var taxonIdsSplitted = "";
				$.each(json.result, function(i) {
					taxonIds = json.result[i].label;
					taxonIdsSplitted = taxonIds.split('|');
					taxonIdsSplitted = taxonIdsSplitted[1];
					taxinList.push(parseInt(taxonIdsSplitted));

				})

				if(jQuery('#hideTaxId').is(':checked')){
					jQuery('.jqtree-title').each(function(e){
						var taxId = jQuery(this).next().attr('id');
						if(jQuery.inArray(parseInt(taxId),taxinList) == -1){
							jQuery(this).parent().parent().hide();
							jQuery(this).parent().parent().css('background-position','0 -1766px');

							if(jQuery(this).parent().parent().parent().parent().children().find('li').css('display') == 'none'){
								jQuery(this).parent().parent().parent().parent().children().find('a').hide();
							}
						}else{
							jQuery(this).parent().parent().show();
							jQuery(this).parent().parent().css('background-position','0 -1766px');
							jQuery(this).parent().parent().parent().parent().children().find('a').show();
						}
					});
				}
				else{
					jQuery('.jqtree-title').each(function(e){
						jQuery(this).parent().parent().show();
						jQuery(this).parent().parent().css('background-position','');
						jQuery(this).parent().parent().parent().parent().children().find('a').show();
					});
				}
			}
		});

	});
}

//delete taxonomy
function deleteTaxonomy(id,val){
	$(".taxonomyNameClass_"+id+"_"+val.replace(/ /g,"_")).remove();
	associateTaxNameArr.splice( $.inArray(val,associateTaxNameArr) ,1 );
	chckExistingTaxNameFlag = false;
}
//souradip
//add Asset Instance
function addAssetInstance(){
	/*$.ajax({
		type : "POST",
		url : "/repopro/web/assetInstance/addNewAssetInstance?assetId="+browserAssetId+"&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				localStorage.removeItem("editAIVPageFlag");
				localStorage.setItem("editAIVPageFlag", true);
			
				//getAssetInstances(json.result[0].assetInstVersionId,json.result[0].assetInstName);

			}

		}
	});*/
	//$('#loadContent').load("addNewAssetInstance.html");
	localStorage.removeItem("editAIVPageFlag");
	localStorage.setItem("editAIVPageFlag", true);
	getAssetInstances(0,"newInstance");
}

//Popup to delete asset
function openDeleteAssetPopup(versionId,assetInstanceName1){
	$("#trash_"+versionId)
	.popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	}).popup('show');
	//position of delete popup when side bar is open - #705 -chandana 20.02.2020
	if ($('#contentPushable').hasClass('sidebarPushable')) {
		$("#trash_"+versionId)
		.popup({
			on: 'click',
			position : 'left center',
			closable : true
		}).popup('show');
		//$('.delPopUp').parent().addClass('left bottom').removeClass('top')/*.css({'top' : '304.25px !important','bottom':'auto !important','left':'auto !important','right':'13em !important', })*/;

	}

	//Chandana - 13.01.2020 - changing pop up content based on get call
	$.ajax({
		type:"GET",
		url:"/repopro/web/assetInstanceVersionManager/checkForDeletionOfMappedInstanceVersion?aivId="+versionId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			data1 = "";
			$('#customDelMsg_'+versionId).html("");
			//$("#trash_"+versionId).popup('hide');
			if(json.result == "true"){
			//	$("#trash_"+versionId).popup('show');
			//	$('#customDelMsg_'+versionId).hide();
				//$('#customDelMsg_'+versionId).show();
				$('#customDelMsg_'+versionId).html('This asset instance  '+assetInstanceName1.replace(/\"/g, "")+' was mapped in the relationship with other asset instance. Still Do you want to delete?');
			}else{
				//$("#trash_"+versionId).popup('show');
				//$('#customDelMsg_'+versionId).hide();
				//$('#customDelMsg_'+versionId).show();
				$('#customDelMsg_'+versionId).html('Are you sure you want to delete  '+assetInstanceName1.replace(/\"/g, "")+' ?');
			}
			
		}
	});
}

//close the delete popup
function closeDeleteAssetPopup(versionId){
	$("#trash_"+versionId).popup('hide');
}
function deleteAsset(obj,versionId){
	var assetInstanceId = $("#assetInstanceId_"+versionId).text();
	var assetInstanceName = $("#assetInstName_"+versionId).text();
	var versionable = $("#versionable_"+versionId).text();
	var versionNameFromTable = $("#assetInstVersionName_"+versionId).text();
	var checkboxChecked = $("#checkboxId_"+versionId).prop("checked");
	var url = "";
	if(versionable == "true"){
		url = "/repopro/web/assetInstanceVersionManager/deleteAssetInstanceVersions/?assetInstanceId="+assetInstanceId+"&assetInstName="+encodeURIComponent(assetInstanceName)+"&assetId="+browserAssetId+"&assetName="+browserAssetName+"&userId="+loggedInUserId+"&userName="+loggedInUserName+"&versionableFlag=1&assetInstanceVersionId="+versionId+"&versionName="+versionNameFromTable;
	}
	else{
		url = "/repopro/web/assetInstanceVersionManager/deleteAssetInstanceVersions/?assetInstanceId="+assetInstanceId+"&assetInstName="+encodeURIComponent(assetInstanceName)+"&assetId="+browserAssetId+"&assetName="+browserAssetName+"&userId="+loggedInUserId+"&userName="+loggedInUserName+"&versionableFlag=0&assetInstanceVersionId="+versionId+"&versionName="+versionNameFromTable;
	}
	//console.log("url"+url);
	
	$.ajax({
		type: "DELETE",
		url: url,
		dataType: "json",
		complete:function(data){
			closeDeleteAssetPopup(versionId);
			var json = JSON.parse(data.responseText);
			if(json.status == "FAILURE"){
				notifyMessage("Delete Instance ",json.message+" : "+json.result,"fail");
			}
			else {
				if(json.result != ""){
					notifyMessage("Delete Instance",json.message+" : "+json.result,"fail");
				} 
				else{	
					notifyMessage("Delete Instance","Asset Instance  '"+assetInstanceName+"' deleted.","success");
					$('#trAssetVersion_'+versionId).remove();
					//Swathi- Bug fix REPO-857
					getCountofInstances = getCountofInstances -1;
					$("#totalNumOfInstances").html(getCountofInstances);
					$("#showInsCount").html(getCountofInstances);
					if(checkboxChecked == true){
						var checked = parseInt($("#numberOfInstances").text());
						if(checked>0){
							checked= checked-1;
							$("#numberOfInstances").text(checked);
						}
						if(checked == 0){
							$("#MessageBox").hide();
						}else{
							$("#MessageBox").show();
						}
					}
										
					/*Hema 27.Sep.2017*/
					var rowCount = $('#browseTable >tbody >tr').length;
					if(rowCount == 0){
						noDataFlag = true; 
						floatingIconsShowHideFlag = true;
						$("#noDataBrowserAssetData").show();
						$('.ManagebulkAccess').hide();
						$("#browserAssetGrid").hide();
						$("#browserInstances").hide();
						$("#browseExport").parent().hide();
						$("#browserFilter").parent().hide();
						$("#browserShowHide").parent().hide();
						checkCompositionAggregationAssetType();//deleteAsset
						$('#showHideBrowseGridSearchIcon').hide(); // Hema 21 Feb 2018 Hide Filter Icon
						$("#viewDefaultFilterDiv").hide(); // swathi
						$("#searchBrowseGridTextBoxDiv").hide();// Swathi- REPO-799 fix
						$("#searchBrowseGridTextBoxDiv_applyFilter").hide();// Swathi- REPO-799 fix
						$("#MessageBox").hide();// Swathi
					}
					else {
						$('#showHideBrowseGridSearchIcon').show(); // Hema 21 Feb 2018 Hide Filter Icon
					}
				}
			}
		}
	});   
}

function exportToExcel(){
	var con = confirm("Please confirm to start the export");
	if(con == true){
		notifyMessage(""+browserAssetName+"s Export","Export process has started. You will receive the file through mail.","success");
		if(browserSearchFlag == true){
			$('#browseExport').attr('href','/repopro/web/export/exportBrowseGridSearchData/'+loggedInUserName+'?assetName='+encodeURIComponent(browserAssetName)+'&assetId='+browserAssetId+'&userId='+loggedInUserId+'&value='+searchString);
		}else{
			$('#browseExport').attr('href','/repopro/web/export/exportBrowseGrid/'+loggedInUserName+'?assetName='+encodeURIComponent(browserAssetName)+'&assetId='+browserAssetId+'&userId='+loggedInUserId+'&tokenName='+localStorage.getItem('tokenGen'));
		
		}
		
	} else{
		$('#browseExport').attr('href','');
		return false;
	}
	/*$('#browseExport').click(function(){
		notifyMessage("","COMING SOON","success");
	});*/
} 
function applyFilterExportToExcel(param1,param2,param3,param4,param5,appendTax){
	
	var con = confirm("Please confirm to start the export");
	if(con == true){
		notifyMessage(""+browserAssetName+"s Export","Export process has started. You will receive the file through mail.","success");
		//var url = '/repopro/web/export/filterSearchExport?userName='+loggedInUserName+'&assetName='+encodeURIComponent(browserAssetName)+'&assetId='+browserAssetId+'&operators='+param2+'&assetParamNames='+param1+'&param1Values='+param4+'&param2Values='+param5+'&logicalSelect='+param3+'&taxonomyNames='+appendTax+'&value='+searchString_applyFilter;
		//console.log(" filtereeddwed  url "+url);
		if(filterExportSearchflag){
			//console.log('/repopro/web/export/filterSearchExport?userName='+loggedInUserName+'&assetName='+encodeURIComponent(browserAssetName)+'&assetId='+browserAssetId+'&operators='+param2+'&assetParamNames='+param1+'&param1Values='+param4+'&param2Values='+param5+'&logicalSelect='+param3+'&taxonomyNames='+appendTax+'&value='+searchString_applyFilter);
			$('#menu-twitter').attr('href','/repopro/web/export/filterSearchExport?userName='+loggedInUserName+'&assetName='+encodeURIComponent(browserAssetName)+'&assetId='+browserAssetId+'&operators='+param2+'&assetParamNames='+param1+'&param1Values='+param4+'&param2Values='+param5+'&logicalSelect='+param3+'&taxonomyNames='+appendTax+'&value='+searchString_applyFilter);

		}else{
			var url = '/repopro/web/export/exportCreateFilter?userName='+loggedInUserName+'&assetName='+encodeURIComponent(browserAssetName)+'&assetId='+browserAssetId+'&userId='+loggedInUserId+'&operators='+param2+'&assetParamNames='+param1+'&param1Values='+param4+'&param2Values='+param5+'&logicalSelect='+param3+'&taxonomyNames='+appendTax+'&tokenName='+localStorage.getItem('tokenGen');
			//console.log(" applyFilterExportToExcel  url "+url);
			$('#menu-twitter').attr('href','/repopro/web/export/exportCreateFilter?userName='+loggedInUserName+'&assetName='+encodeURIComponent(browserAssetName)+'&assetId='+browserAssetId+'&userId='+loggedInUserId+'&operators='+param2+'&assetParamNames='+param1+'&param1Values='+param4+'&param2Values='+param5+'&logicalSelect='+param3+'&taxonomyNames='+appendTax+'&tokenName='+localStorage.getItem('tokenGen'));
		}
	} /*else return false;*/
	else{
		$('#menu-twitter').attr('href','');
		return false;
	}
}
//Hema hide/show add instance icon for logged in user
function addAssetInstanceAccess(){
	var url = "/repopro/web/assetInstance/getAssetLevelAddAccessForLoginUser?userName="+loggedInUserName+"&assetName="+browserAssetName;
	//console.log(' addAssetInstanceAccess  url'+url);
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstance/getAssetLevelAddAccessForLoginUser?userName="+loggedInUserName+"&assetName="+browserAssetName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				
				if(json.result[0].addAccessFlag == false){
					setAddAccessFlag = false;
				}
				else{
					setAddAccessFlag = true;
				}
			}
		}
	});
	//checkCompositionAggregationAssetType();
}
//check Composition and Aggregation Asset Type
function checkCompositionAggregationAssetType(){
	var flag = false;
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstance/getdestAssetAccessForCompositionAndAggregationType?assetId="+browserAssetId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$.each(json.result,function(i){
					if(json.result[i].fwdRelId == 1 || json.result[i].fwdRelId == 5){
						flag = true;
						checkCompositionAggregationAssetType_Flag = true;
					}else{
						flag = false;
						checkCompositionAggregationAssetType_Flag = false;
					}
				});
			}
		}
	});
/*	if(callApplyFunction){
		alert(" if cond callApplyFunction "+callApplyFunction);
		setFloatingIconsForApplyFilter();
	}else{
		alert(" else cond callApplyFunction "+callApplyFunction);*/
		setFloatingIconsBtns();
	/*}*/
	
}
function setFloatingIconsBtns(){
	if (loggedInUserName == "roleAnonymous") {
		if(noDataFlag == true){
			$('#assetInstancesFloatingIcons').html("");
			$('#assetInstancesFloatingIcons').hide();
		}else{
			$('#assetInstancesFloatingIcons').html("");					
			$('#assetInstancesFloatingIcons').html('<span href="#" class="floatIcons" style="cursor:pointer;" id="menu-share"><i class="big sidebar icon"></i></span> <ul class="floatingIconsUL"><li><a title="Add Filter" href="#" id="browserFilter" onclick="createFilterModal()"><i class="filter icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"></i></a></li></ul>'); 
		}
	}
	else if(loggedInUserName == "admin"){
		/*if(setAddAccessFlag == true){*/
		if(checkCompositionAggregationAssetType_Flag == true){
			if(noDataFlag == true){
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').hide();
			}
			else{
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span href="#" class="floatIcons" style="cursor:pointer;" id="menu-share"><i class="big sidebar icon"></i></span> <ul class="floatingIconsUL"><li id="showHideIcon"><a title="Show/Hide Data" style="cursor:pointer;" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"  data-position="left center"></i></a></li id="addFilterIcon"><li><a title="Add Filter" href="#" id="browserFilter" onclick="createFilterModal()"><i class="filter icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"></i></a></li><li onclick="return exportToExcel()" id="exportToExcelIcon"><a title="Export Data" href="#" id="browseExport"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i> </a></li> </ul>'); 
			}
				
		}
		else{
			if(noDataFlag == true){
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span href="#" class="floatIcons" style="cursor:pointer;" id="menu-share"><i class="big sidebar icon"></i></span> <ul class="floatingIconsUL"><li id="addNewInstanceShow"><a title="Add New Instance" style="cursor:pointer;" id="menu-facebook" onclick="addAssetInstance()"> <i class="add icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left:0.2em !important;"  data-position="left center"></i></a></li></ul>');  
			}
			else{
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span href="#" class="floatIcons" style="cursor:pointer;" id="menu-share"><i class="big sidebar icon"></i></span> <ul class="floatingIconsUL"><li id="addNewInstanceShow"><a title="Add New Instance" style="cursor:pointer;" id="menu-facebook" onclick="addAssetInstance()"> <i class="add icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left:0.2em !important;"  data-position="left center"></i></a></li><li id="showHideIcon"><a title="Show/Hide Data" style="cursor:pointer;" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"  data-position="left center"></i></a></li><li><a title="Add Filter" href="#" id="browserFilter" onclick="createFilterModal()"><i class="filter icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"></i></a></li><li onclick="return exportToExcel()" id="exportToExcelIcon"><a title="Export Data" href="#" id="browseExport"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i> </a></li> </ul>');  
			}
		}
		/*}*/
	}
	else{
		if(setAddAccessFlag == true){
			if(checkCompositionAggregationAssetType_Flag == true){
				if(noDataFlag == true){
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').hide();
				}
				else{
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').html('<span href="#" class="floatIcons" style="cursor:pointer;" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li id="showHideIcon"><a title="Show/Hide Data" style="cursor:pointer;" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"  data-position="left center"></i></a></li id="addFilterIcon"><li><a title="Add Filter" href="#" id="browserFilter" onclick="createFilterModal()"><i class="filter icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"></i></a></li><li onclick="return exportToExcel()" id="exportToExcelIcon"><a title="Export Data" id="browseExport"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i> </a></li> </ul>'); 
				}
			}
			else{
				if(noDataFlag == true){
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').html('<span href="#" class="floatIcons" style="cursor:pointer;" id="menu-share"><i class="big sidebar icon"></i></span> <ul class="floatingIconsUL"><li id="addNewInstanceShow"><a title="Add New Instance" style="cursor:pointer;" id="menu-facebook" onclick="addAssetInstance()"> <i class="add icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left:0.2em !important;"  data-position="left center"></i></a></li></ul>');  

				}
				else{
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').html('<span href="#" class="floatIcons" style="cursor:pointer;" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li id="addNewInstanceShow"><a title="Add New Instance" style="cursor:pointer;" id="menu-facebook" onclick="addAssetInstance()"> <i class="add icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left:0.2em !important;"  data-position="left center"></i></a></li><li id="showHideIcon"><a title="Show/Hide Data" style="cursor:pointer;" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"  data-position="left center"></i></a></li><li><a title="Add Filter" href="#" id="browserFilter" onclick="createFilterModal()"><i class="filter icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"></i></a></li><li onclick="return exportToExcel()" id="exportToExcelIcon"><a title="Export Data" id="browseExport"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i> </a></li> </ul>');  
				}

			}
			
		}
		else{
			if(noDataFlag == true){
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').hide();
			}
			else{
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span href="#" class="floatIcons" style="cursor:pointer;" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li id="showHideIcon"><a title="Show/Hide Data" style="cursor:pointer;" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"  data-position="left center"></i></a></li id="addFilterIcon"><li><a title="Add Filter" href="#" id="browserFilter" onclick="createFilterModal()"><i class="filter icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"></i></a></li><li onclick="return exportToExcel()" id="exportToExcelIcon"><a title="Export Data" id="browseExport"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i> </a></li> </ul>'); 
			}
		}
	}

}
function setFloatingIconsForApplyFilter(){
	if (loggedInUserName == "roleAnonymous") {
		$('#assetInstancesFloatingIcons').html("");
		$('#assetInstancesFloatingIcons').html('<span  class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li></ul>');
		
	}
	else if(loggedInUserName == "admin"){
		
		if(checkCompositionAggregationAssetType_Flag == true){
			if(noDataFlag_applyFilter == true){
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span  class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li></ul>');
			}
			else{
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li><a title="Show/Hide Data" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li onclick="return applyFilterExportToExcel(\''+applyAssetParamNames+'\',\''+applyOperators+'\',\''+applyLogicalSelect+'\',\''+applyParam1+'\',\''+applyParam2+'\',\''+applyTax+'\')"><a title="Export Data" href="#" id="menu-twitter"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i></a></li></ul>');				
			}
		}
		else{
			if(noDataFlag_applyFilter == true){
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span  class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li id="addNewInstanceShow"><a title="Add New Instance" style="cursor:pointer;" id="menu-facebook" onclick="addAssetInstance()"><i class="add icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left:0.2em !important;" data-position="left center"></i></a></li><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li></ul>');
			}
			else{
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li id="addNewInstanceShow"><a title="Add New Instance" style="cursor:pointer;" id="menu-facebook" onclick="addAssetInstance()"><i class="add icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left:0.2em !important;" data-position="left center"></i></a></li><li><a title="Show/Hide Data" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li onclick="return applyFilterExportToExcel(\''+applyAssetParamNames+'\',\''+applyOperators+'\',\''+applyLogicalSelect+'\',\''+applyParam1+'\',\''+applyParam2+'\',\''+applyTax+'\')"><a title="Export Data" href="#" id="menu-twitter"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i></a></li></ul>');				
			}
		}
	}
	else{
		if(setAddAccessFlag == true){
			if(checkCompositionAggregationAssetType_Flag == true){
				if(noDataFlag_applyFilter == true){
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').html('<span  class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li></ul>');
				}
				else{
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').html('<span class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li><a title="Show/Hide Data" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li onclick="return applyFilterExportToExcel(\''+applyAssetParamNames+'\',\''+applyOperators+'\',\''+applyLogicalSelect+'\',\''+applyParam1+'\',\''+applyParam2+'\',\''+applyTax+'\')"><a title="Export Data" href="#" id="menu-twitter"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i></a></li></ul>');
				}
			}
			else{
				if(noDataFlag_applyFilter == true){
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').html('<span  class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li id="addNewInstanceShow"><a title="Add New Instance" style="cursor:pointer;" id="menu-facebook" onclick="addAssetInstance()"><i class="add icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left:0.2em !important;" data-position="left center"></i></a></li><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li></ul>');
				}
				else{
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').html('<span class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li id="addNewInstanceShow"><a title="Add New Instance" style="cursor:pointer;" id="menu-facebook" onclick="addAssetInstance()"><i class="add icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left:0.2em !important;" data-position="left center"></i></a></li><li><a title="Show/Hide Data" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li onclick="return applyFilterExportToExcel(\''+applyAssetParamNames+'\',\''+applyOperators+'\',\''+applyLogicalSelect+'\',\''+applyParam1+'\',\''+applyParam2+'\',\''+applyTax+'\')"><a title="Export Data" href="#" id="menu-twitter"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i></a></li></ul>');}

			}
		}
		else{
			if(noDataFlag_applyFilter == true){
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span  class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li></ul>');			}
			else{
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').html('<span class="floatIcons" id="menu-share"><i class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li><a title="Show/Hide Data" id="browserShowHide" onclick="showHideColumnModal()"> <i class="unhide icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Edit Filter" id="browserShowAppliedData" onclick="showAppliedData()"><i class="edit icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li><a title="Remove Filter" id="removeAppliedFilter" onclick="removeAppliedData()"><i class="remove icon popupIcon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"  data-position="left center"></i></a></li><li onclick="return applyFilterExportToExcel(\''+applyAssetParamNames+'\',\''+applyOperators+'\',\''+applyLogicalSelect+'\',\''+applyParam1+'\',\''+applyParam2+'\',\''+applyTax+'\')"><a title="Export Data" href="#" id="menu-twitter"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;"></i></a></li></ul>');
			}
		}
	}
}

function checkActive(obj){
	 $('#createFilterParams').modal({observeChanges : true}).modal('refresh');
	setTimeout(function(){
		if($(obj).hasClass('active')){
			$(obj).next().removeAttr('style');
		}
	}, 500);
}



//get derive attribute data
function  getDeriveAttrData(id,paramName){
	url = "/repopro/web/assetInstanceVersionManager/getDerivedAttributeValues?userName="+loggedInUserName+"&assetInstanceVersionId="+id+"&assetName="+browserAssetName+"&parameterName="+paramName,
	//console.log("getDeriveAttrData paramName "+paramName+"  url "+url);
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstanceVersionManager/getDerivedAttributeValues?userName="+loggedInUserName+"&assetInstanceVersionId="+id+"&assetName="+browserAssetName+"&parameterName="+paramName,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			console.log("DErIVED : " + JSON.stringify(json));
			if(json.status == "SUCCESS"){
				var derivedMultiValue = json.result[0].split("`!!`")[0];
				console.log("derivedMultiValue : " + JSON.stringify(derivedMultiValue));
				var derviedDataValue = json.result[0].split("`!!`")[1];
				
				console.log("derviedDataValue  "+derviedDataValue);
				var name = paramName.replace(/ /g,"_");
				if(derivedMultiValue == "0"){
					//console.log("tutu "+derivedMultiValue);
					var derData = "";
					var dataAppend = "";
					derviedDataValue = derviedDataValue.split("`~`");
					//console.log("getDeriveAttrData derviedDataValue   "+derviedDataValue);
					$.each(derviedDataValue,function(k){
						
						derData = derviedDataValue[k].replace(/~~/g,",");
						dataAppend += '<div style="overflow-x: auto;">'+derData+'</div>';
					});
					//console.log('derData '+derData);
					/*console.log('dataAppend '+dataAppend);*/
					
					$("#deriveData_"+id+"_"+name).html(dataAppend);
					
				}else{
					//console.log("tutu susu"+derivedMultiValue);
					
					$("#deriveData_"+id+"_"+name).html(derivedMultiValue);

				}
	
			}
		}
	});
}

//get Derived Computation Data 
function  getDerivedComputationData(id,paramName){
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstanceVersionManager/getDerivedComputationValues?userName="+loggedInUserName+"&assetInstanceVersionId="+id+"&assetName="+browserAssetName+"&parameterName="+paramName,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				var name = paramName.replace(/ /g,"_");
				$("#deriveData_"+id+"_"+name).html(json.result[0]);
			}
		}
	});
}


//Hema guest user access
function guestUserAccess(){
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstance/getAssetAccessForGuestUser?assetId="+browserAssetId+"&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result[0].guestflag == true){
					getAivGroupDetails();
				}
				else {
					$('#loadContent').load("AccessDenied.html");
					}
				}
				
			}
		});
}


//check if the desc has tble tag 
function isTableTag(str){
    return /^\<table.*\>.*\<\/table\>/i.test(str);
}
	

/*HEMA --------- BOC------------*/
/*function showBrowseGridTextBoxToBeSearchedDiv(){
	$('#showHideBrowseGridSearchIcon').hide();
	$('#searchBrowseGridTextBoxDiv').show(750);
}

// Hide Text Box on Click of Close Icon And Show Filter Icon
function showBrowseGridSearchIcon(){
	$('#searchBrowseGridTextBoxDiv').hide(750);
	setTimeout(function(){
		$('#showHideBrowseGridSearchIcon').show();
	}, 900)

}*/

var searchString = "";
var searchAppendata = "";
var tempFlagToShowData = false;
formRange1 = 0;
countNoOfData1 = 0;
infiniteScrollFlag1 = true;
noDataFlag1 = false;
removeFlag1 = false;
function browseGridFilteredData(){
	// Swathi- Manage Bulk Access - checking whether Search box contains value - If yes then restore values to default else make browse page remains as it is
	searchString1 = $('#filterBrowseGridInputField').val().trim();
	if(((searchString1 != "") && (searchString1 != undefined))|| saveFromShowHide == true){// Code should execute while coming from show/hide column Modal
		setTimeout(function(){ 
			$('#showHideLoader').addClass('active');
		}, 100);
		formRange1 = 0;
		countNoOfData1 = 0;
		infiniteScrollFlag1 = true;
		infiniteScrollFlag = false;
		noDataFlag1 = false;
		removeFlag1 = false;
		filterSearchForApply = false;
		browserSearchFlag = true;
		searchAppendata = "";
		$("#filterSearchTbody").html(" ");
		//Chandana -  returning to default state of bulk access - 24-09-2019
		$('#MessageBox').hide();
		$('.editManageAccess').removeClass('disableEdit');
		$('.bulkAccessonSearch').prop('checked', false);
		$('#exportToExcelIcon').show();
		$(".selectAllCheckBoxonSearch").removeAttr("checked");
		$('.ManagebulkAccess').addClass('disableEdit');
		//swathi count value- 01/10/2019
		selectAllFlagChecked = false;
		selectAllOnSearchFlagChecked = false;
		if($(".ManagebulkAccess").length != 0 && hideManage !=1){
			$(".ManagebulkAccess").show();
		} else{
			$(".ManagebulkAccess").hide();
		}
		saveFromShowHide = false;// Once code executes restoring to default
		showFilteredBrowseGrid();
		 countOnNoButton = true;
		 countOnNoSearchButton = true;
	}
	
}
function browseGridFilteredData_applyFilter(){
	//Swathi- Manage Bulk Access - checking whether Search box contains value
	searchString2 = $('#filterBrowseGridInputField_applyFilter').val().trim();
	if(((searchString2 != "") && (searchString2 != undefined)) ||saveFromShowHide == true){// Code should execute while coming from show/hide column Modal
		setTimeout(function(){ 
			$('#showHideLoader').addClass('active');
		}, 100);
		formRange1 = 0;
		countNoOfData1 = 0;
		infiniteScrollFlag1 = true;
		infiniteScrollFlag = false;
		noDataFlag1 = false;
		removeFlag1 = false;
		filterSearchForApply = true;
		filterExportSearchflag = true;
		searchAppendata = "";
		$("#filterSearchTbody").html(" ");
		$("#searchBrowseGridTextBoxDiv").hide();
		//Chandana -  returning to default state of bulk access - 24-09-2019
		$('#MessageBox').hide();
		$('.editManageAccess').removeClass('disableEdit');
		$('.bulkAccessonSearch').prop('checked', false);
		$('#menu-twitter').show();
		$(".selectAllCheckBoxonSearch").removeAttr("checked");
		$('.ManagebulkAccess').addClass('disableEdit');
		//swathi count value- 01/10/2019
		selectAllOnSearchFlagChecked = false;
		selectAllFlagChecked = false;
		countOnNoButton = true;
		countOnNoSearchButton = true;
		alertFlag = true; // remove of Filter applied notification
		if($(".ManagebulkAccess").length != 0 && hideManage !=1){
			$(".ManagebulkAccess").show();
		} else {
			$(".ManagebulkAccess").hide();
		}
		saveFromShowHide = false;// Once code executes restoring to default
		showFilteredBrowseGrid();
	}
		
}

function showFilteredBrowseGrid(){
	setTimeout(function(){ 
		$('#showHideLoader').removeClass('active');
	}, 2000);
	
	$('#showHideBrowseGridSearchIcon').hide();
	
	$("#noDataBrowserAssetData").hide();
	$("#browserAssetGrid").hide();
	
	searchString = "";
	searchString1 = $('#filterBrowseGridInputField').val().trim();//.trim() added by aditya 06.03.18
	searchString2 = $('#filterBrowseGridInputField_applyFilter').val().trim();

	//browserAssetName = encodeURIComponent(browserAssetName);
	searchString = encodeURIComponent(searchString1);
	searchString_applyFilter = encodeURIComponent(searchString2);
	var filterSearchData = " ";
	if(filterSearchForApply == true){
		
		filterSearchData = searchString_applyFilter;
		var url = "/repopro/web/assetInstanceVersionManager/filterSearch?userName="+loggedInUserName+"&assetName="+encodeURIComponent(browserAssetName)+"&assetId="+browserAssetId+"&operators="+encodeURIComponent(applyOperators)+"&assetParamNames="+encodeURIComponent(applyAssetParamNames)+"&param1Values="+applyParam1+"&param2Values="+applyParam2+"&logicalSelect="+applyLogicalSelect+"&taxonomyNames="+applyTax+"&from="+formRange1+"&value="+searchString_applyFilter; 
		
	}else{
		
		filterSearchData = searchString;
		var url = "/repopro/web/assetInstanceVersionManager/filterBrowseGrid?value="+searchString+"&userName="+loggedInUserName+"&assetName="+browserAssetName+"&assetId="+browserAssetId+"&from="+formRange1;
	}
	
	//console.log("filter : " + url);
	
	/*var getCountofInstances = "";*/
	if(filterSearchForApply == true){
		//show count only for admin user
		if(adminFlag == true){
	$.ajax({ 
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/filterSearchCount?userName="+loggedInUserName+"&assetName="+encodeURIComponent(browserAssetName)+"&assetId="+browserAssetId+"&operators="+encodeURIComponent(applyOperators)+"&assetParamNames="+encodeURIComponent(applyAssetParamNames)+"&param1Values="+applyParam1+"&param2Values="+applyParam2+"&logicalSelect="+applyLogicalSelect+"&taxonomyNames="+applyTax+"&from="+formRange1+"&value="+searchString_applyFilter,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				getCountofInstances = "";
				getCountofInstances = json.paramValues.count; 
				getAIVids = [];
				getAIVids = json.paramValues.AivIds;
			}
		}
	});
		}
	}else{
		if(adminFlag == true){
		$.ajax({ 
			type : "GET",
			url : "/repopro/web/assetInstanceVersionManager/filterBrowseGridCount?value="+searchString+"&userName="+loggedInUserName+"&assetName="+encodeURIComponent(browserAssetName)+"&assetId="+browserAssetId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					getCountofInstances = "";
					getCountofInstances = json.paramValues.count; 
					getAIVids = [];
					getAIVids = json.paramValues.AivIds;
				}
			}
		});
	}
	}
	// ajax call
	if(filterSearchData != ""){
		$.ajax({ 
			type : "GET",
			url : url,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){

					if(json.result == "" || json.result == null || json.result == "[]"){
						$('#showHideLoader').removeClass('active');
						if(countNoOfData1 == 0 ){
							noDataFlag1 = true;
							$("#noDataBrowserAssetData_BrowseSearch").show();
							$('.ManagebulkAccess').hide();
							$("#browserAssetGrid_BrowseSearch").hide();
							$("#browserShowHide").hide();
							$("#browseExport").hide();
							$("#menu-twitter").hide();
							$('#removeFilter').hide();
							infiniteScrollFlag1 = false;
							$("#viewDefaultFilterDiv").hide(); // swathi
						}
						else{
							$('#loadingMoreAssetDetails_BrowseSearch').css('display', 'none');
							infiniteScrollFlag1 = false;
						}
					}
					else{
						setTimeout(function(){
							$('#showHideLoader').removeClass('active');
						}, 100);
						
						$("#noDataBrowserAssetData_BrowseSearch").hide();
						$("#browserAssetGrid_BrowseSearch").show();
						$("#browseTableHeaderTr_BrowseSearch").show();
						$("#filterSearchTbody").show();
						$("#browserShowHide").show();
						$("#browseExport").show();
						$("#viewDefaultFilterDiv").show(); // swathi -default
						if(countNoOfData1 == 0){
							if(json.result[0].iconImageName != null){
								var imageType  = json.result[0].iconImageName;
								/*imageType = imageType.split(".");
								imageName = imageType[1];*/
								imageName = (json.result[0].iconImageName).substring((json.result[0].iconImageName).lastIndexOf(".") + 1, (json.result[0].iconImageName).length);
								//Chandana - 13-9-2019 Broken image
								if (imageName == 'PNG' || imageName == 'JPEG' || imageName == 'JPG'){
									imageName = imageName.toLowerCase()
								}
							}
						}
						
						
						$.each(json.result, function(i) {
							var paramNameWithValues = "";
							if(json.result[i].paramNameWithValues == null){
								paramNameWithValues = "No Data";
							}
							else{
								
								$.each(json.result[i].paramNameWithValues, function(key, value) {
									var deriveFlag = false;
									var deriveId = "";
									if(value != null){
										if(value.indexOf("^^DA^^") != -1){
										    deriveFlag = true;
										    var data = value.split("~");
										    var data1  = (data[3]).split("`@`");
										    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
										    getDeriveAttrData1(data[1],data1[0]);
										}
										
										if(value.indexOf("^^DC^^") != -1){
										    deriveFlag = true;
										    var data = value.split("~");
										    var data1  = (data[3]).split("`@`");
										    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
										    getDerivedComputationData1(data[1],data1[0]);
										}
										
										// BOC Hema 14.Mar.2019- Auto Complete
										if(value.indexOf("^^AC^^") != -1){
										    deriveFlag = true;
										    var data = value.split("~");
										    var data1  = (data[3]).split("`@`");
										    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
										    getAutoCompleteData1(data[1],data1[0]);
										}
										//EOC
									}
									paramNameWithValues += getParamNameWithValues1(key, value ,deriveFlag, deriveId,json.result[i].assetInstVersionId, json.result[i].assetInstName);
								});

							}
							//var appenddData = "";
							searchAppendata = getAssetInstData1(json.result[i].assetInstVersionId, json.result[i].assetInstName, json.result[i].versionName, json.result[i].description, paramNameWithValues, json.result[i].showHideParamCount,json.result[i].assetInstId,json.result[i].versionable,json.result[i].deleteAccessFlag, json.result[i].deleteInstanceFlag); //Chandana 10-06-2019 (flag has been refered)
							$("#filterSearchTbody").append(searchAppendata);
							if(removeFlag1 == false){
								$("#removeFilter").hide();
								
							}else{
								$("#removeFilter").show();
							}
							countNoOfData1++;
						});
						formRange1 = formRange1 + 21;

					}

				}
				else{
				
					$("#noDataBrowserAssetData_BrowseSearch").show();
					$("#browserAssetGrid_BrowseSearch").hide();
					$("#removeFilter").hide();
					$("#viewDefaultFilterDiv").hide(); // swathi
				}
				/*$('#showHideLoader').removeClass('active');*/
				//$('#loadingMoreAssetDetails_BrowseSearch').css('display', 'none');
			}
		});
		//scrollVisible(1)
	}
	else {
		formRange = 0;
		countNoOfData = 0;
		infiniteScrollFlag = true;
		infiniteScrollFlag1 = false;
		appenddData = "";
		//tempFlagToShowData = true;
		$('#showHideBrowseGridSearchIcon').hide();
		$("#browseTable tbody").html("");
		//alert("callApplyFunction:   "+callApplyFunction)
		if(callApplyFunction){
			setCountAndRangeValue();
			$('#showHideLoader').removeClass('active');	
			$("#filterSearchTbody").hide();
			
		}else{
			//loadBrowserAssets();
			clearBrowseTextBox();
		}

	}
	
}

//get asset instance data
function getAssetInstData1(assetInstanceVersionId, assetInstName, versionName, description, paramNameWithValues, showHideParamCount,assetInstId,versionable,deleteAccessFlag, deleteInstanceFlag){

	var encodedAssetInstName= encodeURIComponent(assetInstName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	//Swathi- 22-10-2019- Bulk Access
	if(showCheckboxCheckedFlag == true && $('.bulkAccessonSearch:checked').length < 1 ){ 
		$(".ManagebulkAccess").addClass('disableEdit');
	} else if($('.bulkAccessonSearch:checked').length >=1) {
		$(".ManagebulkAccess").removeClass('disableEdit');
	} 
	//Chandana 10-06-2019 (2. change content if asset is mapped in relationship tree - search browse)
	var data1 = "";

	
	data1 = "<p id='customDelMsg1_"+assetInstanceVersionId+"' class='delPopUp'></p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteAssetPopup1("+assetInstanceVersionId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteAsset1(this,"+assetInstanceVersionId+")'>Yes</button> ";

	
	/*if(deleteInstanceFlag == true){
		var data1 = "<p>This asset instance '"+assetInstName.replace(/\"/g, "")+"'  was mapped in the relationship with other asset instance. Still Do you want to delete?</p><button class='right floated ui cancel mini button' onclick='closeDeleteAssetPopup1("+assetInstanceVersionId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteAsset1(this,"+assetInstanceVersionId+")'>Yes</button> ";

	}
	else{
		var data1 = "<p>Are you sure you want to delete "+assetInstName.replace(/\"/g, "")+" ?</p><button class='right floated ui cancel mini button' onclick='closeDeleteAssetPopup1("+assetInstanceVersionId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteAsset1(this,"+assetInstanceVersionId+")'>Yes</button> ";

	}*/
	searchAppendata = "";
	searchAppendata += '<tr id="trAssetVersion1_'+assetInstanceVersionId+'">';
	// Swathi - Add checked checkbox on scroll - 26-09-2019
	if(showGroupDetails == "~" && selectAllOnSearchFlagChecked == true){
		searchAppendata += '<td class="four wide top aligned"><div class="ui checkbox" ><input type="checkbox" checked id="checkboxIdonSearch_'+assetInstanceVersionId+'" name="checkbox" class="bulkAccessonSearch" onclick="checkSelectAllUseronSearchBulk(this)"><label></label></div></td>';
	} //Chandana - 20-09-2019 - Adding checkbox
	else if(showGroupDetails == "~"){
		searchAppendata += '<td class="four wide top aligned"><div class="ui checkbox"><input type="checkbox" id="checkboxIdonSearch_'+assetInstanceVersionId+'" name="checkbox" class="bulkAccessonSearch" onclick="checkSelectAllUseronSearchBulk(this)"><label></label></div></td>';
		}
	searchAppendata += '<td class="four wide top aligned">';
	searchAppendata += '<span id="assetInstanceId1_'+assetInstanceVersionId+'" style="display: none;">'+assetInstId+'</span>';
	searchAppendata += '<span id="versionable1_'+assetInstanceVersionId+'" style="display: none;">'+versionable+'</span>';
	var icon = "";
	if(imageName == "default"){
		if(circularThemeColoredIcon){
			icon += '<div class="mediumIconImageCircleStyle_asset_themeCircle browsePageStyle">';
			if(invertAssetIconFlag){
				icon += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				icon += '<image class="ui  image mediumIconImageStyle_themeCircle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}else{
			icon += '<div class="mediumIconImageCircleStyle browsePageStyle mediumIconImageCircleRemove">';
			if(invertAssetIconFlag){
				icon += '<image class="ui  image mediumIconImageStyle invertImageColor" src="/repopro/semantic/images/inverted_defaultAssetIcon.png">';
			}else{
				icon += '<image class="ui  image mediumIconImageStyle" src="/repopro/semantic/images/defaultAssetIcon.svg">';
			}
		}
		
	}else{
		
		if(circularThemeColoredIcon){
			icon += '<div class="mediumIconImageCircleStyle_asset_themeCircle browsePageStyle ">';
			if(invertAssetIconFlag){
				icon += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor" src="/repopro/assetImages/inverted_'+browserAssetId+'.'+imageName+'">';
			}else{
				icon += '<image class="ui  image mediumIconImageStyle_themeCircle" src="/repopro/assetImages/'+browserAssetId+'.'+imageName+'">';
			}
		}else{
			icon += '<div class="mediumIconImageCircleStyle browsePageStyle mediumIconImageCircleRemove">';
			if(invertAssetIconFlag){
				icon += '<image class="ui  image mediumIconImageStyle invertImageColor" src="/repopro/assetImages/inverted_'+browserAssetId+'.'+imageName+'">';
			}else{
				icon += '<image class="ui  image mediumIconImageStyle" src="/repopro/assetImages/'+browserAssetId+'.'+imageName+'">';
			}
		}
		
		
	}
	

	searchAppendata += '<div>'+icon+'</div><a style="cursor: pointer; margin-left: 1.5em; vertical-align: -moz-middle-with-baseline;vertical-align: -webkit-baseline-middle;" id="assetInstName1_'+assetInstanceVersionId+'" onclick="getAssetInstances('+assetInstanceVersionId+',\''+encodedAssetInstName+'\')" class="gridImageTextSpacing">'+ assetInstName +'</a>';
	
	if(versionable){
		searchAppendata += '<span  style="margin-left: 0.5em; color:#999999;font-size: 12px;vertical-align: -moz-middle-with-baseline;vertical-align: -webkit-baseline-middle;"><i>v<span id="assetInstVersionName1_'+assetInstanceVersionId+'">'+versionName+'</span></span>';
	}
	searchAppendata += '</div>';
		
	if(showAivDetails == "`"){
		searchAppendata += '<p class="assetInstVersionStyle"><span id="assetInstId1_'+assetInstanceVersionId+'" style="color: #999999 !important;margin-left: 0.9em;">'+assetInstanceVersionId+'</span></p>';
	}
	//souradip 20.12.17
	
	searchAppendata +=  '</td>';	
	
	/*if(showGroupDetails == "~"){
		appendData += '<p style="cursor: pointer;font-size: 12px; padding-left: 4.2em; padding-top: 0.2em;"><a class="sidebarSubMenuItemSize" onclick="openGroupDetailsAssetInstAccessModal('+assetInstanceVersionId+')">Manage Access</a></p></td>';
	}*/
	var hasTableTag = isTableTag(description);
	if(hasTableTag == false){
		searchAppendata += '<td class="six wide top aligned sidebarSubMenuOverviewSize" style="overflow-x: auto;">';
	}else{
		searchAppendata += '<td class="six wide top aligned sidebarSubMenuOverviewSize">';
	}
	
	if(description == null){
		description = "";
	}
	searchAppendata += '<div id="assetInstDescription1" style="max-height: 15em;overflow: auto;">'+description+'</div></td>';
	//alert('2');
	if(paramNameWithValues == "No Data"){
		searchAppendata += '<td class="five wide top aligned"></td>';
	}
	else{
		searchAppendata += '<td class="five wide top aligned" style="padding-top: 1.5em !important;"><div style="overflow: auto;"><span id="firstThreeParamNameWithValues1_'+assetInstanceVersionId+'">'+paramNameWithValues+'</span>';
		searchAppendata += '<div id="showMoreData1_'+assetInstanceVersionId+'" style="display: none; margin-top:0.8em;"></div>';
		if(showHideParamCount > 3){
			searchAppendata += '<p style="cursor: pointer;"><a id="showHideMoreData1_'+assetInstanceVersionId+'" onclick="showMoreParam1('+assetInstanceVersionId+',\''+encodedAssetInstName+'\')">'; 
			searchAppendata += '<span class="sidebarSubMenuItemSize">Show more <i class="chevron right small icon"></i></span>'; 
			searchAppendata += '<span class="sidebarSubMenuItemSize" style="display: none;">Hide<i class="chevron left small icon"></i></span></a></p>';
		}
		searchAppendata += '</div></td>';
	}
	if(showGroupDetails == "~"){
		//chandana - Adding checkbox in the table header
		var bulkdata = '';
		var ManagebulkAccess = '';
		bulkdata += '<div class="ui mini negative message" style="width: 35%; margin: 1em 0em 0em 40em;text-align: center;" id="showMessageOnSelectCheckbox"><i class="close icon" onclick="closeMessage()"></i><div class="header"> All <span id="numberOfInstances"> </span>  /  <span id="totalNumOfInstances">'+getCountofInstances+' </span>  instances are selected.</div></div> '

		//bulkdata += '<div class="sub header" onclick = "selecAllforBulkAccess('+assetInstanceVersionId+')"><i class="right clone outline icon"></i>Select all<span id="noOfselectedInstances"> </span>/ <span id="countOfInstances">'+getCountofInstances+' </span> instances of <span id="assetNameBulkAccess"> </span></div>';
		ManagebulkAccess +='<a class="ui" onclick ="manageAllSelectedAccessforSearch()" style="cursor: pointer;"><i class="right edit icon"></i> Manage Access for selected</a>';
		
		$('.ManagebulkAccess').html(ManagebulkAccess)
		$('#MessageBox').html(bulkdata);
		var data = '';
		data += '<tr><th class="one wide" id=""><div class="ui checkbox"><input type="checkbox" name="selectAllCheckBoxonSearch" class="selectAllCheckBoxonSearch" onclick = "selectAllCheckBoxonSearch('+assetInstanceVersionId+')"><label></label></div></th>';
		data += '<th class="four wide" style="padding-left: 44px;" id="browserAssetNameHeader1"></th>';
		data += '<th class="five wide">Overview</th>';
		data += '<th class="five wide">Properties</th>';
		data += '<th class="one wide" id="showManageAccess1">Manage Access</th>';
		data += '<th class="one wide" id="browserDeleteHeader1">Delete</th></tr>';
		
		$("#browseTableHeaderTr_BrowseSearch").html(data);
		data = '';
		//Swathi -  code to disable edit icon on scroll- 27-09-2019
		if(selectAllOnSearchFlagChecked == true) {
			searchAppendata += '<td class="one wide top aligned"><span><i class="edit icon deleteEditIcon editManageAccess disableEdit" onclick="openGroupDetailsAssetInstAccessModal('+assetInstanceVersionId+')"></i></span></td>';
		}else if($('.bulkAccessonSearch:checked').length >= 1){			
			searchAppendata += '<td class="one wide top aligned"><span><i class="edit icon deleteEditIcon editManageAccess disableEdit" onclick="openGroupDetailsAssetInstAccessModal('+assetInstanceVersionId+')"></i></span></td>';
		}else {
			searchAppendata += '<td class="one wide top aligned"><span><i class="edit icon deleteEditIcon editManageAccess" onclick="openGroupDetailsAssetInstAccessModal('+assetInstanceVersionId+')"></i></span></td>';
		}
		
	}else{
		
		var data = '';
		data += '<tr><th class="four wide" style="padding-left: 44px;" id="browserAssetNameHeader1"></th>';
		data += '<th class="five wide">Overview</th>';
		data += '<th class="five wide">Properties</th>';
		data += '<th class="one wide" id="browserDeleteHeader">Delete</th></tr>';
		
		$("#browseTableHeaderTr_BrowseSearch").html(data);
		data = '';
	}
	$("#browserAssetNameHeader1").html(browserAssetName);

	if(deleteAccessFlag){
		//console.log('true')
		searchAppendata += '<td class="one wide top aligned"><a><i class="trash icon deleteEditIcon" id="trash1_'+assetInstanceVersionId+'" data-html="'+data1+'" onclick="openDeleteAssetPopup1('+assetInstanceVersionId+' ,\''+encodedAssetInstName+'\')"></i></a></td>';
	}
	else {
		//console.log('false')
		searchAppendata += '<td class="one wide top aligned disabled"><span><i class="trash icon" id="trash1_'+assetInstanceVersionId+'"></i></span></td>';
	}
	
	searchAppendata += '</tr>';	
	
	// Swathi - code to get count bulk access
	if(selectAllOnSearchFlagChecked == true){
		if(individualSearchCheckFlag == true) {
			 var numberofUnchecked = $(".bulkAccessonSearch:not(:checked)").length;
			 numberOfChecked = getCountofInstances - numberofUnchecked;
			 $('#numberOfInstances').text(numberOfChecked);			 
		} else {
			$('#selectAllCheckBoxonSearch').attr('checked','checked');
			$('#numberOfInstances').text(getCountofInstances);
		}
		
	} else {
		 var numberOfChecked = $('.bulkAccessonSearch:checked').length;			 
		 $('#numberOfInstances').text(numberOfChecked);
	}
	return searchAppendata;
}

//SOC - bulk access on search
function selectAllCheckBoxonSearch (assetInstanceVersionId){
	 $('.bulkAccessonSearch').prop("checked", true);
	 $(".bulkAccessonSearch").click(function(){

			if($(".bulkAccessonSearch").length == $(".bulkAccessonSearch:checked").length) {
				$(".selectAllCheckBoxonSearch").attr("checked", "checked");
			} else {
				$(".selectAllCheckBoxonSearch").removeAttr("checked");
			}

		});
	 if($('.selectAllCheckBoxonSearch').prop("checked") == false) {
		  $('.bulkAccessonSearch:checkbox').attr('checked',false);
		  $('.ManagebulkAccess').addClass('disableEdit');
		  $('.editManageAccess').removeClass('disableEdit');
		  selectAllOnSearchFlagChecked = false;
		  countOnNoSearchButton = true; 
	}
	 if ($('.bulkAccessonSearch:checked').length == $('.bulkAccessonSearch').length) {
			$('.ManagebulkAccess ').removeClass('disableEdit');
			$('.editManageAccess').addClass('disableEdit');
			$('#exportToExcelIcon').hide();
			$('#menu-twitter').hide();
			$('#openConfirmationofSelectAllModal').modal('setting', 'closable', false).modal('show');
			$('#showInsCount').text(getCountofInstances);
			$("#showAssetNameonConfirmModal").text(browserAssetName);
			$("#getAssetNameonConfirm").text(browserAssetName);
			//alert('all checkboxs are checked')
		}else{
			 $('.bulkAccessonSearch').prop("checked", false);
			$('#exportToExcelIcon').show();
			 $('#menu-twitter').show();
			$('.editManageAccess').removeClass('disableEdit');
			$('#MessageBox').hide();
		}
	 

}
//Checkbox enable and disable - Chandana - 23-09-2019
function checkSelectAllUseronSearchBulk(obj)
{
	 $('#numberOfInstances').text('');
	if (false == $(obj).prop('checked')) {
		$(".selectAllCheckBoxonSearch").prop('checked', false);
		individualSearchCheckFlag = true;
	}
	if ($('.bulkAccessonSearch:checked').length == $('.bulkAccessonSearch').length) {
		$(".selectAllCheckBoxonSearch").prop('checked', true);
		$('#openConfirmationofSelectAllModal').modal('setting', 'closable', false).modal('show');
		$('#showInsCount').text(getCountofInstances);
		$("#showAssetNameonConfirmModal").text(browserAssetName);
		$('.editManageAccess').addClass('disableEdit');
		//alert('all checkboxs are checked')
	}else{
		$('#exportToExcelIcon').show();
		$('.editManageAccess').removeClass('disableEdit');
	}
	
	// Enable the Manage bulk access if more than one checkboxes are checked - Chandana - 23-09-2019
	 var numberOfChecked = $('.bulkAccessonSearch:checked').length;	
	 if(numberOfChecked >= 1){
		 $('#exportToExcelIcon').hide();
		 $('#menu-twitter').hide();
		 $('.ManagebulkAccess').removeClass('disableEdit');
		 $('.editManageAccess').addClass('disableEdit');
		 $('#MessageBox').show();
		 $(numberOfChecked).each(function() {
			 $('#numberOfInstances').text(numberOfChecked);
			 });		 
	 }else if(numberOfChecked < 1){
		 $('.ManagebulkAccess').addClass('disableEdit');
		 $('#MessageBox').hide();// Swathi- REPO-726 fix
	 }
	// Swathi- Code for counting number of unchecked checkbox - 26-09-2019
	 if(countOnNoSearchButton == true) {
		 var numberOfChecked = $('.bulkAccessonSearch:checked').length;			 
		 $('#numberOfInstances').text(numberOfChecked);
	 } else {
		 var numberofUnchecked = $(".bulkAccessonSearch:not(:checked)").length;
		 if(numberofUnchecked >=1) {
			 $(".bulkAccessonSearch:checkbox:not(:checked)").each(function() {
			      numberOfChecked = getCountofInstances - numberofUnchecked;
			      $('#numberOfInstances').text(numberOfChecked);
			 }); 
		 }
	 }
};

//Manage access modal for select all checkbox - - chandana-18-09-2019
function manageAllSelectedAccessforSearch(allCheckedIds){
	$('#MessageBox').hide();
    $('#openConfirmationofSelectAllModal').modal('destroy'); //Closing confirmation modal
    //$('#ShowManageAccessforSelectAll').unbind();
	$('#btnsubmitAssetInstanceAccess').unbind();
	$('#btncancelAssetInstanceAccess').unbind();
	$('#openShowGrpAssetInstanceAccessModal').modal('destroy');
	$('#openShowGrpAssetInstanceAccessModal').modal('setting', 'closable', false).modal('show').modal('refresh');
	$("#openShowGrpAssetInstanceAccessModalInstanceName").text(browserAssetName);
	
	
	var checkboxlength = $('.bulkAccessonSearch:checked').length;
	
	//on cancel uncheck checked checkboxes (modal close) -  Chandana - 23-09-2019
	
	$('#btncancelAssetInstanceAccess').click(function(){
		$('.bulkAccessonSearch').prop('checked', false);
		$('.editManageAccess').removeClass('disableEdit');
		 countOnNoButton = true;
		countOnNoSearchButton = true;
	});
	var allCheckedIds = [];
	var allUncheckarray1 = [];	
	
	//Swathi - 13.11.2019--execute follow function only when selectall flag is true
	if(selectAllOnSearchFlagChecked == true){
		if($('.selectAllCheckBoxonSearch').prop("checked") == true) { // when all checkboxes are checked
			allCheckedIds = JSON.parse('['+getAIVids+']');				
		} else  { // when one of the checkbox is unchecked after selecting SelctAll checkobx
			$(".bulkAccessonSearch:not(:checked)").each(function() {
				 if ($(this).prop('checked')== false){ 
		          var getUncheckedIds =  $(this).attr("id");
		          getUncheckedIds = getUncheckedIds.split('_');
		          getUncheckedIds = getUncheckedIds[1];
		          allUncheckarray1.push(getUncheckedIds)
		        }	       
		    });
			var tempIds = JSON.parse("[" + getAIVids + "]");
			for (var i = 0; i< tempIds.length; i++) {
				for (var j = 0; j <= allUncheckarray1.length; j++) {
					if (tempIds[i] == allUncheckarray1[j]) {
					tempIds.splice(i, 1);
					}
				}
			}
			allCheckedIds = JSON.parse('['+tempIds+']');
		}
		
	} else {// chandana -- normal scenario when multiple checkboxes are checked
		 $(".bulkAccessonSearch:checkbox").each(function() {
		        if ($(this).is(":checked")) {
		          var getIds =  $(this).attr("id");
		          getIds = getIds.split('_');
		          allCheckedIds.push(getIds[1]);
		        } 		       
		    });
	}	
	
    //Call to construct table - Chandana - 23-09-2019
    var groupIdList = [];
   // alert("length" + allCheckedIds.length +"------"+allCheckedIds);
	$.ajax({ 
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/viewGroupsWithMultipleAIAccess?aivId="+allCheckedIds,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$("#gridAssetInstanceAccess table tbody").html("");
				$.each(json.result, function(i) {
					groupIdList.push(json.result[i].groupId);
					var getAssetInstanceAccessData = loadAssetInstanceAccessData(json.result[i].groupId, json.result[i].groupName, json.result[i].editAccess, json.result[i].viewAccess, json.result[i].deleteAccess);
					$("#gridAssetInstanceAccess table tbody").append(getAssetInstanceAccessData);
				});
			}
		}
	});

	//table edit - swathi 23-09-2019
    $('#gridAssetInstanceAccess table tbody tr').each(function(i){

		var $tds = $(this).find('td'),
		groupId = $tds.eq(0).attr("id"),
		groupId = groupId.split("_")[1];
		groupId = parseInt(groupId);

		$('input[id=editCB_'+groupId+']').on('click',function(){
			$('input[id=viewCB_'+groupId+']').prop("checked", true );
		});
		$('input[id=viewCB_'+groupId+']').on('click',function(){
			if(!$('input[id=viewCB_'+groupId+']').is(':checked')){
				$('input[id=editCB_'+groupId+']').prop("checked", false );
				$('input[id=deleteCB_'+groupId+']').prop("checked", false );
			}
		});
		$('input[id=deleteCB_'+groupId+']').on('click',function(){
			$('input[id=viewCB_'+groupId+']').prop("checked", true );
		});
	});
    
    
 // Save Button on the Modal - swathi
    var groupWiseArr = [];
    $("#btnsubmitAssetInstanceAccess").on('click', function(){
    groupWiseArr.length = 0;
    $.each(groupIdList,function(i){
    var editFlag , viewFlag , deleteFlag;
    if($("#editCB_"+groupIdList[i]).prop("checked")){
    editFlag = 1;
    }else{
    editFlag = 0;
    }

    if($("#viewCB_"+groupIdList[i]).prop("checked")){
    viewFlag = 1;
    }else{
    viewFlag = 0;
    }
    if($("#deleteCB_"+groupIdList[i]).prop("checked")){
    deleteFlag = 1;
    }else{
    deleteFlag = 0;
    }

    groupWiseArr.push({"aivIds":allCheckedIds,"groupId":groupIdList[i],"editAccess":editFlag,"viewAccess":viewFlag,"deleteAccess":deleteFlag});
    });

    $.ajax({
    type: "PUT",
    url: "/repopro/web/assetInstanceVersionManager/saveGroupsAccessMultipleAISubmit",
    contentType : "application/json",
    dataType : "json",
    data : JSON.stringify(groupWiseArr),
    async: false,
    complete:function(data){	
    appenddata = "";
    var json = JSON.parse(data.responseText);
    if(json.status == "SUCCESS"){
    notifyMessage("Update Asset Instance Access","Asset Instance Access Updated","success");
    $('#openShowGrpAssetInstanceAccessModal').dimmer('hide').modal('hide others').modal('hide'); 
    }
    else {
    notifyMessage("Update Asset Instance Access",json.message,"fail");
    }
    }

    });	
    //Default state - chandana
    $('.editManageAccess').removeClass('disableEdit');
	$('.bulkAccessonSearch').prop('checked', false);
	$('#exportToExcelIcon').show();
	$(".selectAllCheckBoxonSearch").removeAttr("checked");
	$('.ManagebulkAccess').addClass('disableEdit');
	// swathi- scroll default state- 27-09-2019
	selectAllOnSearchFlagChecked = false;
	countOnNoButton = true;
	countOnNoSearchButton = true;
    });
    
  //Manage access modal on close - Chandana
    $('#btncancelAssetInstanceAccess').click(function(){
      	//$('#ShowManageAccessforSelectAll').unbind();
    	$('#openConfirmationofSelectAllModal').modal('destroy'); //Closing confirmation modal
    	$('.editManageAccess').removeClass('disableEdit');
    	$('.bulkAccessonSearch').prop('checked', false);
    	$('#exportToExcelIcon').show();
    	$(".selectAllCheckBoxonSearch").removeAttr("checked");
    	$('.ManagebulkAccess').addClass('disableEdit');
    	// swathi- scroll default state- 27-09-2019
    	selectAllOnSearchFlagChecked = false;
    	countOnNoButton = true;
    	countOnNoSearchButton = true;
    	$('#menu-twitter').show();// Swathi- Bug fix REPO-715
    	
    });
}

//Show Manage access modal on confirmation - 20-9-2019

var selectAllOnSearchFlagChecked = false;
$('#ShowManageAccessforSelectAll').click(function(){

	$('#btnsubmitAssetInstanceAccess').unbind();
	$('#btncancelAssetInstanceAccess').unbind();
	$('#openShowGrpAssetInstanceAccessModal').modal('destroy');
	$('#openConfirmationofSelectAllModal').modal('hide'); //Closing confirmation modal
	$('.ManagebulkAccess').removeClass('disableEdit');
	$('#exportToExcelIcon').hide();
	$('#MessageBox').show();
	

	$("#showAssetNameonConfirmModal").text(browserAssetName);
	$("#getAssetNameonConfirm").text(browserAssetName);
	selectAllOnSearchFlagChecked = true;
	countOnNoSearchButton = false; 
});

//close message box on click - chandana
function closeMessage(){
	$('#MessageBox').hide();
	};

//Confirmation modal - Cancel to uncheck all checkboxes and close the modal - chandana-18-09-2019
$('#CancelManageAccessforSelectAll').click(function(){
	$('.editManageAccess').removeClass('disableEdit');
	$('.bulkAccessonSearch').prop('checked', false);
	$('#exportToExcelIcon').show();
	$(".selectAllCheckBoxonSearch").removeAttr("checked");
	$('.ManagebulkAccess').addClass('disableEdit');
	countOnNoSearchButton = true;
});

//for unchecking all checked box on modal close(key press event) - chandana - 18-9-2019
$(document).keydown(function(event) { 
	  if (event.keyCode == 27 && localStorage.getItem("pageName") == 'browser') { 
		  if($('#openConfirmationofSelectAllModal').is(":visible") || $('#openShowGrpAssetInstanceAccessModal').is(":visible")){
			  $('#openConfirmationofSelectAllModal').hide();
			  $('#openConfirmationofSelectAllModal').modal('destroy');
			  $('.bulkAccessonSearch').prop('checked', false);
			  $('.selectAllCheckBoxonSearch').prop('checked', false);
			  $('.ManagebulkAccess').addClass('disableEdit');
			  $('.editManageAccess').removeClass('disableEdit');
			  $('#exportToExcelIcon').show();
			  $('#menu-twitter').show();
			  $('#MessageBox').hide();
		  }
	     
	  }
	});

//get derive attribute data
function  getDeriveAttrData1(id,paramName){
	//console.log("getDeriveAttrData1 url "+"/repopro/web/assetInstanceVersionManager/getDerivedAttributeValues?userName="+loggedInUserName+"&assetInstanceVersionId="+id+"&assetName="+browserAssetName+"&parameterName="+paramName);
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstanceVersionManager/getDerivedAttributeValues?userName="+loggedInUserName+"&assetInstanceVersionId="+id+"&assetName="+browserAssetName+"&parameterName="+paramName,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){

				var derivedMultiValue1 = json.result[0].split("`!!`")[0];
				var derviedDataValue1 = json.result[0].split("`!!`")[1];
				//console.log("derviedDataValue  "+derviedDataValue);
				var name = paramName.replace(/ /g,"_");
				if(derivedMultiValue1 == "0"){
					var derData1 = "";
					var dataAppend1 = "";
					derviedDataValue1 = derviedDataValue1.split("`~`");
					$.each(derviedDataValue1,function(k){
						
						derData1 = derviedDataValue1[k].replace(/~~/g,",");
						dataAppend1 += '<div style="overflow-x: auto;">'+derData1+'</div>';
					});
					
					$("#deriveData1_"+id+"_"+name).html(dataAppend1);
					
				}else{
					
					$("#deriveData1_"+id+"_"+name).html(derivedMultiValue1);

				}

			}
		}
	});
}

//get Derived Computation Data 
function  getDerivedComputationData1(id,paramName){
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetInstanceVersionManager/getDerivedComputationValues?userName="+loggedInUserName+"&assetInstanceVersionId="+id+"&assetName="+browserAssetName+"&parameterName="+paramName,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				var name = paramName.replace(/ /g,"_");
				$("#deriveData1_"+id+"_"+name).html(json.result[0]);
			}
		}
	});
}
function getParamNameWithValues1(key, value, deriveFlag, deriveId,assetInstanceVersionId, assetInstName){
	var encodedAssetInstName= encodeURIComponent(assetInstName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	
	key = key.split("~");
	if(value == "`null`"){
		value = "";
	}
	appendData = "";
	if(deriveFlag){
		appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span id="deriveData1_'+deriveId+'"><span class="ui active mini inline loader"></span></span></p>';
	}
	else{
	
		value = value.split("`@`");
		listData1 = value[0];
		dataTypeForParam = value[1];
		staticOrNonstatic = value[2];
		if(listData1 != "`null`"  && listData1 != ""){
			if(dataTypeForParam == "5"){
	
				var dataForDervied = listData1.replace(/`~`/g,",");
				var valueForDervied = dataForDervied.replace(/~~/g,",");
				appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+valueForDervied+'</span></p>';

			}
			
			// BOC Hema 06.Mar.2019 Ldap Mapping
			else if(dataTypeForParam == "9"){
				var customData = callCustomizableFunctionToCheckIfPropertiesIsCheckedInAIV();
				listData = listData1.split("``");
				listData2 = listData[0].split("~~");
				if(value[2] == "1"){ 
					//multiple Ldap Mapping
					var paramId = value[3], ldapMappingCountLink = "true", ldapMappingHref = "#paramTR_"+paramId;
					if(listData2 == ""){
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span></span></p>';
					}
					else {
					if(customData == "checked"){
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span><a href="#paramTR_'+paramId+'" onclick="showAIVpageOnMultiLdapMappingCountClick('+assetInstanceVersionId+',\''+encodedAssetInstName+'\',\''+ldapMappingCountLink+'\',\''+ldapMappingHref+'\')" style="text-decoration: underline;">'+listData2.length+'</a></span></p>';
					}
					else {
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData2.length+'</span></p>';
					}
				}
					
				}else {
					//single Ldap Mapping
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i>';
					if(listData2 != ""){
						appendData += '<table class="ui celled table"><tbody><tr>';
						$.each(listData, function( index, value ) {
							appendData += '<td>'+value+'</td>';
						});

						appendData += '</tr></tbody></table></p>';
					}
				}
			}
			//EOC
			
			else if(dataTypeForParam == "7" || dataTypeForParam == "1"){
				
				
				if(dataTypeForParam == "1"){
					var startWithXml = listData1.startsWith("<");
					if(startWithXml){
						if(staticOrNonstatic == "1"){
							listData = listData1.split("~~");
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
						}else{
							var startWithAnchor = listData1.startsWith("<a>");
							//console.log("  startWithAnchor "+startWithAnchor);
							if(!startWithAnchor){
								/*var formatted =  formatXml(listData1);
								formatted = formatted.trim();
								formatted =	hljs.highlightAuto(formatted);
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key+' : </i><pre>'+formatted.value+'</pre></p>';
							*/
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
							}else{
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
							}
						}
							
					}else{
						if(staticOrNonstatic == "1"){
							listData = listData1.split("~~");
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
							
						}else{
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
						}
					}
				}else{
					if(staticOrNonstatic == "1"){
						listData = listData1.split("~~");
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
						
					}else{
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div> class="showMoreOverflow"'+listData1+'</div></p>';
					}
				}

			}else{
				listData1 = listData1.replace(/~~/g,",");
				var flag = validateURL(listData1);
				if(flag){
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><a href="'+listData1+'" target="_blank">'+listData1+'</a></p>';
				}else{
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData1+'</span></p>';
				}
				
			}
		}else{

				appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span></span></p>';

			}
	}
	return appendData;
}
//get Parameter Name With Values - after search
function getParamNameWithValues1__showMoreParam(key, value, deriveFlag, deriveId,assetInstanceVersionId,encodedAssetInstName){
	
	//console.log(' key '+key);
	key = key.split("~");
	//console.log(value)
	if(value == "`null`"){
		value = "";
	}
	appendData = "";
	if(deriveFlag){
		appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span id="deriveData1_'+deriveId+'"><span class="ui active mini inline loader"></span></span></p>';
	}else{
		value = value.split("`@`");
		listData1 = value[0];
		dataTypeForParam = value[1];
		staticOrNonstatic = value[2];
	//	alert('showmore' + value)
		if(listData1 != "`null`"  && listData1 != ""){
			if(dataTypeForParam == "5"){
	
				var derivedMultiValue = listData1.split("`!!`")[0];
				var derviedDataValue = listData1.split("`!!`")[1];

				if(derivedMultiValue == "0"){
					var derData = "";
					var dataAppend = "";
					
					derviedDataValue = derviedDataValue.split("`~`");
					$.each(derviedDataValue,function(k){
						derData = derviedDataValue[k].replace(/~~/g,",");
						dataAppend += '<div style="overflow-x: auto;">'+derData+'</div>';
					});
					//console.log(' after  derData  '+derData);
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+dataAppend+'</span></p>';
					
				}

				else{

					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+derivedMultiValue+'</span></p>';

				}	
			}
			else if(dataTypeForParam == "8"){
	
				var derivedMultiValue = listData1.split("`!!`")[0];
				var derviedDataValue = listData1.split("`!!`")[1];

				if(derivedMultiValue == "0"){
					var derData = "";
					var dataAppend = "";
					
					derviedDataValue = derviedDataValue.split("`~`");
					$.each(derviedDataValue,function(k){
						derData = derviedDataValue[k].replace(/~~/g,",");
						dataAppend += '<div style="overflow-x: auto;">'+derData+'</div>';
					});
					//console.log(' after  derData  '+derData);
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+dataAppend+'</span></p>';
					
				}

				else{

					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+derivedMultiValue+'</span></p>';

				}	
			}
			
			// BOC Hema 06.Mar.2019 Ldap Mapping
			else if(dataTypeForParam == "9"){
				var customData = callCustomizableFunctionToCheckIfPropertiesIsCheckedInAIV();
				listData = listData1.split("``");
				listData2 = listData[0].split("~~");
				if(value[2] == "1"){ 
					//multiple Ldap Mapping
					var paramId = value[3], ldapMappingCountLink = "true", ldapMappingHref = "#paramTR_"+paramId;
					if(listData2 == ""){
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span></span></p>';
					}
					else {
					if(customData == "checked"){
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span><a href="#paramTR_'+paramId+'" style="text-decoration:underline;" onclick="showAIVpageOnMultiLdapMappingCountClick('+assetInstanceVersionId+',\''+encodedAssetInstName+'\',\''+ldapMappingCountLink+'\',\''+ldapMappingHref+'\')">'+listData2.length+'</a></span></p>';
					}
					else {
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData2.length+'</span></p>';
					}
				}
				}else {
					//single Ldap Mapping
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">';
					
					if(listData2 != ""){
						appendData += '<table class="ui celled table"><tbody><tr>';
						$.each(listData, function( index, value ) {
							console.log( index + ": " + value );
							appendData += '<td>'+value+'</td>';
						});

						appendData += '</tr></tbody></table></div></p>';
					}
					
				}
			}
			//EOC
			
			else if(dataTypeForParam == "7" || dataTypeForParam == "1"){
				
				
				if(dataTypeForParam == "1"){
					var startWithXml = listData1.startsWith("<");
					if(startWithXml){
						if(staticOrNonstatic == "1"){
							listData = listData1.split("~~");
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
							
						}else{
							var startWithAnchor = listData1.startsWith("<a>");
							//console.log("  startWithAnchor "+startWithAnchor);
							if(!startWithAnchor){
								/*var formatted =  formatXml(listData1);
								formatted = formatted.trim();
								formatted =	hljs.highlightAuto(formatted);
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key+' : </i><pre>'+formatted.value+'</pre></p>';
							*/
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
							}else{
								appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
							}
						}
						
					}else{
						if(staticOrNonstatic == "1"){
							listData = listData1.split("~~");
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
							
						}else{
							appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
						}
					}
				}else{
					if(staticOrNonstatic == "1"){
						listData = listData1.split("~~");
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData.length+'</span></p>';
						
					}else{
						appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><div class="showMoreOverflow">'+listData1+'</div></p>';
					}
				}

			}else{
				listData1 = listData1.replace(/~~/g,",");
				var flag = validateURL(listData1);
				if(flag){
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><a href="'+listData1+'" target="_blank">'+listData1+'</a></p>';
				}else{
					appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span>'+listData1+'</span></p>';
				}
				
			}
		}else{
				//console.log("else ");
				appendData += '<p class="instanceParamValuesInGrid" style="margin-top: 0em !important; font-size:12px !important;"><i style="color:#999999 !important;">'+key[0]+' : </i><span></span></p>';

			}
		/*}*/
	}
	
	//console.log("  getParamNameWithValues1 appendData  "+appendData)
	return appendData;
	
	//<div class="ui active mini inline loader"></div>
}
function openDeleteAssetPopup1(versionId, assetInstName){
	$("#trash1_"+versionId)
	.popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	})
	.popup('show');
	//position of delete popup when side bar is open - #705 -chandana 20.02.2020
	if ($('#contentPushable').hasClass('sidebarPushable')) {
		$("#trash1_"+versionId)
		.popup({
			on: 'click',
			position: 'left center',
			closable : true
		})
		.popup('show');
		//$('.delPopUp').parent().addClass('left center').removeClass('top').css({'top' : '304.25px !important','bottom':'auto !important','left':'auto !important','right':'13em !important', });
	}
	//Chandana - 13.01.2020 - (change content if asset is mapped in relationship tree - search browse)
	$.ajax({
		type:"GET",
		url:"/repopro/web/assetInstanceVersionManager/checkForDeletionOfMappedInstanceVersion?aivId="+versionId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			data1 = "";
			$('#customDelMsg1_'+versionId).html("");
			if(json.result == "true"){
				$('#customDelMsg1_'+versionId).html('This asset instance  '+assetInstName.replace(/\"/g, "")+' was mapped in the relationship with other asset instance. Still Do you want to delete?');
			}else{
				$('#customDelMsg1_'+versionId).html('Are you sure you want to delete  '+assetInstName.replace(/\"/g, "")+' ?');
			}
			
		}
	});
}
function closeDeleteAssetPopup1(versionId){
	$("#trash1_"+versionId).popup('hide');
}
//show more parameter for search data
function showMoreParam1(assetInstanceVersionId, assetInstName){
	if(!$("#showMoreData1_"+assetInstanceVersionId).hasClass("showData")){
		var userName;

		if(loggedInUserName == "roleAnonymous"){
			userName = "roleAnonymous";
		}
		else{
			userName = loggedInUserName;
		}
		url =  "/repopro/web/assetInstanceVersionManager/getParametersDetailsForAssetInstanceVersion?userName="+userName+"&assetName="+browserAssetName+"&assetId="+browserAssetId+"&assetInstanceVersionId="+assetInstanceVersionId;
		//console.log("search  showMoreParam url "+url);
		$.ajax({ 
			type : "GET",
			url : "/repopro/web/assetInstanceVersionManager/getParametersDetailsForAssetInstanceVersion?userName="+userName+"&assetName="+browserAssetName+"&assetId="+browserAssetId+"&assetInstanceVersionId="+assetInstanceVersionId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){

					if(json.paramValues == "" || json.paramValues == null){
						notifyMessage("Show More Params","empty","fail");
					}
					else{
						var paramNameWithValues1 = "";
						var repeatingDataCount = $("#firstThreeParamNameWithValues1_"+assetInstanceVersionId+"> .instanceParamValuesInGrid").length - 1;
						var count = 0;
						$.each(json.paramValues, function(key,value) {
							//console.log(" value "+value);
							if(count>repeatingDataCount){
								var deriveFlag = false;
								var deriveId = "";
								if(value != null){
									if(value.indexOf("^^DA^^") != -1){
									    deriveFlag = true;
									    var data = value.split("~");
									    //console.log(data);
									    var data1  = (data[3]).split("`@`");
									    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
									    getDeriveAttrData1(data[1],data1[0]);
									}
									
									if(value.indexOf("^^DC^^") != -1){
									    deriveFlag = true;
									    var data = value.split("~");
									    var data1  = (data[3]).split("`@`");
									    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
									    getDerivedComputationData1(data[1],data1[0]);
									}
									// BOC Hema 14.Mar.2019- Auto Complete
									if(value.indexOf("^^AC^^") != -1){
									    deriveFlag = true;
									    var data = value.split("~");
									    var data1  = (data[3]).split("`@`");
									    deriveId = data[1]+"_"+data1[0].replace(/ /g,"_");
									    getAutoCompleteData1(data[1],data1[0]);
									}
									//EOC
								}

								paramNameWithValues1 = getParamNameWithValues1__showMoreParam(key, value,deriveFlag,deriveId,assetInstanceVersionId,assetInstName);
								
								$("#showMoreData1_"+assetInstanceVersionId).append(paramNameWithValues1);
							}
							count++;
						});
					}

				}
				else{
					notifyMessage("Show More Parameters","No more parameters","fail");
				}
			}
		});

	}

	$("#showMoreData1_"+assetInstanceVersionId).toggle().addClass("showData");
	$('span','#showHideMoreData1_'+assetInstanceVersionId).toggle();	
}

function clearBrowseTextBox(){
	//Swathi- Retaining manage bulk access header
	if($(".ManagebulkAccess").length != 0 && hideManage !=1){
		$(".ManagebulkAccess").show();
	} else {
		$(".ManagebulkAccess").hide();
	}
	// Swathi- Manage Bulk Access - checking whether Search box contains value - If yes then restore values to default else make browse page remains as it is
	searchString1 = $('#filterBrowseGridInputField').val().trim();
	if(((searchString1 != "") && (searchString1 != undefined)) || $("#noDataBrowserAssetData_BrowseSearch").is(":visible")){// should execute when no matching records found scenario, hence checking for that message div is visible
	$('#filterBrowseGridInputField').val('');
	formRange = 0;
	countNoOfData = 0;
	infiniteScrollFlag = true;
	appenddData = "";	
	//tempFlagToShowData = true;
	$('#showHideBrowseGridSearchIcon').hide();
	$("#browserShowHide").show();
	$("#browseExport").show();
	$("#browseTable tbody").html("");
	//Chandana -  returning to default state of bulk access - 24-09-2019
	$('#MessageBox').hide();
	$('.editManageAccess').removeClass('disableEdit');
	$('.bulkAccessonSearch').prop('checked', false);
	$('#exportToExcelIcon').show();
	$(".selectAllCheckBoxonSearch").removeAttr("checked");
	$('.ManagebulkAccess').addClass('disableEdit');
	// Swathi- code to clear selectall - 27-09-2019
	$(".selectAllCheckBox").prop('checked', false);
	//selectAllOnSearchFlagChecked = false; 
	selectAllFlagChecked = false;
	infiniteScrollFlag1 = false; 
	loadBrowserAssets();
	countOnNoButton = true;
	countOnNoSearchButton = true;
	filterSearchForApply = true; // Repo- 911 fix
	}
}
function clearBrowseTextBox_applyFilter(){
	//Swathi- Retaining manage bulk access header
	if($(".ManagebulkAccess").length != 0 && hideManage !=1){
		$(".ManagebulkAccess").show();
	} else {
		$(".ManagebulkAccess").hide();
	}
	//Swathi- Manage Bulk Access - checking whether Search box contains value
	searchString2 = $('#filterBrowseGridInputField_applyFilter').val().trim();
	if(((searchString2 != "") && (searchString2 != undefined)) || $("#noDataBrowserAssetData_BrowseSearch").is(":visible")){	// should execute when no matching records found scenario, hence checking for that message div is visible
	$('#filterBrowseGridInputField_applyFilter').val('');
	$("#menu-twitter").show();
	$("#noDataBrowserAssetData_BrowseSearch").hide();
	$("#browserAssetGrid_BrowseSearch").hide();
	$("#browseTable tbody").html("");
	//Chandana -  returning to default state of bulk access - 24-09-2019
	$('#MessageBox').hide();
	$('.editManageAccess').removeClass('disableEdit');
	$('.bulkAccessonSearch').prop('checked', false);
	$("#menu-twitter").show();
	$(".selectAllCheckBoxonSearch").removeAttr("checked");
	$('.ManagebulkAccess').addClass('disableEdit');
	// Swathi- code to clear selectall - 27-09-2019
	infiniteScrollFlag1 = false;
	$(".selectAllCheckBox").prop('checked', false);
	selectAllOnSearchFlagChecked = false; 
	selectAllFlagChecked = false;
	countOnNoButton = true;
	countOnNoSearchButton = true;
	flag = true;	
	if(nameFilterFlag == 1){
		loadBrowseFilterFlag = true;
	}
	alertFlag = true; // remove of Filter applied notification
	setCountAndRangeValue();
	filterSearchForApply = true; //repo-911 fix
	}
}

function deleteAsset1(obj,versionId){
	var assetInstanceId = $("#assetInstanceId1_"+versionId).text();
	var assetInstanceName = $("#assetInstName1_"+versionId).text();
	var versionable = $("#versionable1_"+versionId).text();
	var versionNameFromTable = $("#assetInstVersionName1_"+versionId).text();
	var checkboxChecked = $("#checkboxIdonSearch_"+versionId).prop("checked");
	var url = "";
	if(versionable == "true"){
		url = "/repopro/web/assetInstanceVersionManager/deleteAssetInstanceVersions/?assetInstanceId="+assetInstanceId+"&assetInstName="+encodeURIComponent(assetInstanceName)+"&assetId="+browserAssetId+"&assetName="+browserAssetName+"&userId="+loggedInUserId+"&userName="+loggedInUserName+"&versionableFlag=1&assetInstanceVersionId="+versionId+"&versionName="+versionNameFromTable;
	}
	else{
		url = "/repopro/web/assetInstanceVersionManager/deleteAssetInstanceVersions/?assetInstanceId="+assetInstanceId+"&assetInstName="+encodeURIComponent(assetInstanceName)+"&assetId="+browserAssetId+"&assetName="+browserAssetName+"&userId="+loggedInUserId+"&userName="+loggedInUserName+"&versionableFlag=0&assetInstanceVersionId="+versionId+"&versionName="+versionNameFromTable;
	}
	//console.log("del  url "+url);

	$.ajax({
		type: "DELETE",
		url: url,
		dataType: "json",
		complete:function(data){
			closeDeleteAssetPopup(versionId);
			var json = JSON.parse(data.responseText);
			if(json.status == "FAILURE"){
				notifyMessage("Delete Instance ",json.message+" : "+json.result,"fail");
			}
			else {
				if(json.result != ""){
					notifyMessage("Delete Instance",json.message+" : "+json.result,"fail");
				} 
				else{	
					notifyMessage("Delete Instance","Asset Instance  '"+assetInstanceName+"' deleted.","success");
					$('#trAssetVersion1_'+versionId).remove();
					//Swathi- Bug fix REPO-857
					getCountofInstances = getCountofInstances -1;
					$("#totalNumOfInstances").html(getCountofInstances);
					$("#showInsCount").html(getCountofInstances);
					if(checkboxChecked == true){
						var checked = parseInt($("#numberOfInstances").text());
						if(checked>0){
							checked= checked-1;
							$("#numberOfInstances").text(checked);
						}
					}
										
					/*Hema 27.Sep.2017*/
					var rowCount = $('#browseTable_BrowseSearch >tbody >tr').length;
					if(rowCount == 0){
						$("#noDataBrowserAssetData").show();
						$('.ManagebulkAccess').hide();
						$("#browserAssetGrid").hide();
						$("#browserInstances").hide();
						$("#browseExport").parent().hide();
						$("#browserFilter").parent().hide();
						$("#browserShowHide").parent().hide();
						noDataFlag = true; 
						floatingIconsShowHideFlag = true;
						checkCompositionAggregationAssetType();//deleteAsset1
						$('#showHideBrowseGridSearchIcon').hide(); // Hema 21 Feb 2018 Hide Filter Icon
						$('#browseTableHeaderTr_BrowseSearch').hide();					
						$("#viewDefaultFilterDiv").hide();	// swathi
						$("#searchBrowseGridTextBoxDiv").hide();// Swathi- REPO-799 fix
						$("#searchBrowseGridTextBoxDiv_applyFilter").hide();// Swathi- REPO-799 fix
						$("#MessageBox").hide();// Swathi
					}
					else {
						$('#browseTableHeaderTr_BrowseSearch').show();
						$('#showHideBrowseGridSearchIcon').show(); // Hema 21 Feb 2018 Hide Filter Icon
					}
				}
			}
		}
	});   
}
/*EOC*/
function showSavedFilterDiv(){
	$("#savedFilterDiv").show();
	$("#div_saved").show();
	$("#displaySaveFilter").hide();
	$("#hiddenSaveFilter").show();
	$('#createFilterParams').modal({observeChanges : true}).modal('refresh');
	// Swathi- default filter- Bug fix- REPO-638,633
	 $("#actionClassSelcted .text").text("Actions"); 
	 var defaultFilter = $("#savedFilterdd option:selected").text();
		if(defaultFilter.includes("[Default Filter]")){
			$('#removeDefault').show(); 
		} else{
			$('#removeDefault').hide();
		}
		
	    

		
}
function hideSavedFilterDiv(){
	 $("#displaySaveFilter").show();
	 $("#savedFilterDiv").hide();
	 $("#div_saved").hide();
	 $("#hiddenSaveFilter").hide();
	 $('#createFilterParams').modal({observeChanges : true}).modal('refresh');
	 
}


function callCustomizableFunctionToCheckIfPropertiesIsCheckedInAIV(){
	var customData = "";
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetInstanceVersionManager/getCustomizedSectionData?userName="+loggedInUserName,
		dataType : "json",
		async : false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			//console.log("customizeLayout :: "+JSON.stringify(json.result));
			if(json.result[0].sectionVisibility != "" && json.result[0].sectionVisibility != null && json.result[0].sectionVisibility.length != 0){
				var item_list_data =  (json.result[0].sectionVisibility).split(",");
				var custom_layout_data="", custom_layout_status_switches="";
				custom_layout_data = "";
				$.each(item_list_data, function(key, value){
					var itemListLabelChecked = value.split("~~")[0];
					
					if(itemListLabelChecked == "Properties"){
						customData = value.split("~~")[1];
					}
					
				});
				
			}
		
		}});
	
	
	return customData;
	}



// BOC Hema 14. Mar.2019 auto complete
//get derive attribute data
function  getAutoCompleteData(id,paramName){
	var url = "/repopro/web/assetInstanceVersionManager/getDerivedAttributeForAssetListValues?userName="+loggedInUserName+"&assetInstanceVersionId="+id+"&assetName="+browserAssetName+"&parameterName="+paramName;
	console.log("Derived Attr 8 " + url);
	$.ajax({
		type : "GET",
		url: url,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				var derivedMultiValue = json.result[0].split("`!!`")[0];
				var derviedDataValue = json.result[0].split("`!!`")[1];
				//console.log("derviedDataValue  "+derviedDataValue);
				var name = paramName.replace(/ /g,"_");
				if(derivedMultiValue == "0"){
					//console.log("tutu "+derivedMultiValue);
					var derData = "";
					var dataAppend = "";
					derviedDataValue = derviedDataValue.split("`~`");
					//console.log("getDeriveAttrData derviedDataValue   "+derviedDataValue);
					$.each(derviedDataValue,function(k){
						
						derData = derviedDataValue[k].replace(/~~/g,",");
						dataAppend += '<div style="overflow-x: auto;">'+derData+'</div>';
					});
					//console.log('derData '+derData);
					/*console.log('dataAppend '+dataAppend);*/
					
					$("#deriveData_"+id+"_"+name).html(dataAppend);
					
				}else{
					//console.log("tutu susu"+derivedMultiValue);
					
					$("#deriveData_"+id+"_"+name).html(derivedMultiValue);

				}
	
			}
		}
	});
}

function  getAutoCompleteData1(id,paramName){
	var url = "/repopro/web/assetInstanceVersionManager/getDerivedAttributeForAssetListValues?userName="+loggedInUserName+"&assetInstanceVersionId="+id+"&assetName="+browserAssetName+"&parameterName="+paramName;
	//console.log("getDeriveAttrData paramName "+paramName+"  url "+url);
	$.ajax({
		type : "GET",
		url: url,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			console.log("getAutoCompleteData 1 : " + JSON.stringify(json));
			if(json.status == "SUCCESS"){
				var derivedMultiValue1 = json.result[0].split("`!!`")[0];
				var derviedDataValue1 = json.result[0].split("`!!`")[1];
				//console.log("derviedDataValue  "+derviedDataValue);
				var name = paramName.replace(/ /g,"_");
				if(derivedMultiValue1 == "0"){
					//console.log("tutu "+derivedMultiValue);
					var derData1 = "";
					var dataAppend1 = "";
					derviedDataValue1 = derviedDataValue1.split("`~`");
					//console.log("getDeriveAttrData derviedDataValue   "+derviedDataValue);
					$.each(derviedDataValue1,function(k){
						
						derData1 = derviedDataValue1[k].replace(/~~/g,",");
						dataAppend1 += '<div style="overflow-x: auto;">'+derData1+'</div>';
					});
					//console.log('derData '+derData);
					/*console.log('dataAppend '+dataAppend);*/
					
					$("#deriveData1_"+id+"_"+name).html(dataAppend1);
					
				}else{
					//console.log("tutu susu"+derivedMultiValue);
					
					$("#deriveData1_"+id+"_"+name).html(derivedMultiValue1);

				}
	
			}
		}
	});
}

//Swathi - Default filter
function viewDefaultFilter() {
	$("#defaultFilterCheck").prop("checked", false );// REPO-630 fix
	$("#actionClassSelcted .text").text("Actions"); // Swathi
	if(loadBrowseFilterFlag == false){
		showAppliedData();
		if($("#paramContent").hasClass('active')){
			$("#paramContent div").removeClass('hidden');
			$("#paramContent").attr("style","overflow:visible");
		}	
		
	}else {
		$('#removeDefault').show(); 
		loadfilterFlag = true;
		nameFilterFlag = 1;
		createFilterModal();
		$("#paramDiv").addClass("active");
		$("#paramContent").addClass("active");
		if($("#paramContent").hasClass('active')){
			$("#paramContent div").removeClass('hidden');
			$("#paramContent").attr("style","overflow:visible");
		}			
		loadSavedFilter();	
		
	}
	
}

// Swathi - Default filter
function updateDefaultFilter() {
	nameFilterflag = 0;// reset the flag value
	callApplyFilter = true;
	var sessionVal = sessionStorage.getItem("removeDefault");
	var filterValue1 = $("#savedFilterdd option:selected").text();
	var filterValue = filterValue1.replace(/ *\[[^)]*\] */g, "");
	if(filterValue == "--Select One--"){
		notifyMessage("Update Filter","Please select an option","fail");
	} else{
			defaultFilterFlag = 1;
			updateFilter();	
			formRange = 0;
			countNoOfData = 0;
			$("#browseTable tbody").empty();
			loadBrowseFilterFlag = true;	
			if(callApplyFilter == true){
				defaultFilterNameAjax();
				applyFilter();	
				nameFilterflag = 1;
				var getSavedFilterList = onloadDisplaySaveFilters();
				 $('#savedFilterdd').dropdown('clear');				
				$('#savedFilterdd').append(getSavedFilterList);
				$('#actionClassSelcted .text').html('Actions');
				$('#removeDefault').show();	
				
			}	else{				
				$('#actionClassSelcted .text').html('Actions');
				loadBrowseFilterFlag = false;	
				loadfilterFlag = false;
				$("#searchBrowseGridTextBoxDiv_applyFilter").hide();
				$("#noDefaultFilterMessage").show();
				$("#noDefaultFilterMessage").show();
				$("#noFilterclickMsg").show();
				$("#clearFilterButton").hide();
				$("#clickFilterMsg").hide();
				$("#defaultFilterMessage").hide();
				formRange = 0;
				countNoOfData = 0;				
				$("#browseTable tbody").empty();		
				loadBrowserAssets();
			}
			 
		
	}
	
		
}

//Swathi - Default filter
function loadSavedFilterOriginal(){	
	loadfilterFlag = false;
	loadBrowseFilterFlag = false;	
	loadSavedFilter();	
	$('#actionClassSelcted .text').html('Actions');
}

//Swathi - Default filter
function removeFilterData() {
	sessionStorage.setItem('removeDefault', 'true');
	loadBrowseFilterFlag = false;
	$("#createFilterParams").remove();
	$('#loadContent').load('browser.html');	
	
}
//Swathi- Confirmation Modal- on Yes save default values - 10.12.2019
$('#SaveDefaultValues').click(function(){
	$('#openConfirmationofSaveDefault').modal('hide').modal('hide dimmer');
	$('#openConfirmationofSaveDefault').modal('destroy'); //Closing confirmation modal
	saveConfirmationflag = true;
	defaultFilterFlag = 1;
	$("#defaultfilterName").text(defaultFilterName);
	$("#defaultfilterName1").text(defaultFilterName);
	updateFilter();		
	defaultFilterNameAjax();
	$('#showHideLoader').removeClass('active');	
	nameFilterFlag = 1;
});

//Swathi - Default filter
var closeDefault;
function removeDefaultFilter(){	
	defaultFilterFlag = 0;
	updateFilter();
	defaultFilterNameAjax();
	$('#removeDefault').hide(); 
	if($('#savedFilterdd option').length == "1"){
		$('#savedFilterdd').html("");
		$("#savedFilterdd").dropdown('clear');
	}
	else{
		$('#savedFilterdd option').each(function(e){
			 if(!$(this).hasClass("selectOneData")){
				 $(this).remove();
			 }
		 });						 						
		 $("#savedFilterdd").dropdown('clear');		
	}
	
	
	$('#tbl_SelectFilterParam tbody').empty();
	
	var getSavedFilterList = onloadDisplaySaveFilters();
	defaultFilterNameAjax();
	refreshTable();
	closeDefault = 0;
	nameFilterFlag = 0;		
	$("#searchBrowseGridTextBoxDiv_applyFilter").hide();
	$("#noDefaultFilterMessage").show();
	$("#noDefaultFilterMessage").show();
	$("#noFilterclickMsg").show();
	$("#clearFilterButton").hide();
	$("#clickFilterMsg").hide();
	$("#defaultFilterMessage").hide();
	$('#actionClassSelcted .text').html('Actions');
	applyShowHide = false;
	callApplyFunction = false;
	formRange = 0;
	countNoOfData = 0;
	refreshTable();
	$("#browseTable tbody").empty();		
	loadBrowserAssets();
	// code to for remove icon and edit icon
	setFloatingIconsBtns();
}

//Swathi- Confirmation Modal- on click of No  - 10.12.2019
$('#ApplyNoSave').click(function(){
	$('#openConfirmationofSaveDefault').modal('hide').modal('hide dimmer');
	$('#openConfirmationofSaveDefault').modal('destroy'); //Closing confirmation modal
	saveConfirmationflag = false;
	$("#defaultfilterName").text("Unnamed");
	$("#defaultfilterName1").text("Unnamed");
	loadBrowseFilterFlag = false;
	nameFilterFlag = 3;	
});

//Swathi - Parameter modal close
function closenow(){
	if(closeDefault == 0){
		formRange = 0;
		countNoOfData = 0;
		refreshTable();
		$("#browseTable tbody").empty();		
		loadBrowserAssets();
		closeDefault = 1;
	} else{
		if(deleteFlagDefaultLoad == true){
			formRange = 0;
			countNoOfData = 0;
			getAivGroupDetails();
			deleteFlagDefaultLoad = false;
		}
	}
	$('#actionClassSelcted .text').html('Actions');
}
function clearParamTable(){
	$("#searchBrowseGridTextBoxDiv_applyFilter").hide();
	$("#noDefaultFilterMessage").show();
	$("#noFilterclickMsg").show();
	$("#clearFilterButton").hide();
	$("#clickFilterMsg").hide();
	$("#defaultFilterMessage").hide();	
	sessionStorage.setItem('removeDefault', 'true');
	loadBrowseFilterFlag = false;
	loadfilterFlag = false;
	flag= false;
	$("#defaultfilterName1").html('');
	closeDefault = 0;	
	applyShowHide = false;
	callApplyFunction = false;
	formRange = 0;
	countNoOfData = 0;
	$("#browseTable tbody").empty();		
	loadBrowserAssets();
	// code to for remove icon and edit icon
	setFloatingIconsBtns();
	refreshTable();
	$('#actionClassSelcted .text').html('Actions');
	if($('#inputFilterSelector').length !=0){
		$("#inputFilterSelector .errAddFilterName ").hide();
		$("#defaultFilterCheck").prop("checked", false);
		$('#inputFilterSelector').hide();
	}
			
}

$(window).keydown(
		function(event) {
			if (event.keyCode == 27) {
				if($('#createFilterParams').is(":visible")){
					closenow();
				}				
			}
});

$(window).keydown(
		function(event) {
			if (event.keyCode == 27) {
				if($('#openConfirmationofSaveDefault').is(":visible")){
					$("#ApplyNoSave").click();
				}				
			}
});

function validateSaveParamValues(){
	if ( $('#tbl_SelectFilterParam > tbody > tr').length == 1 ) {
		appendTax = "";
		param1= "";
		param2 ="";
		param3 ="";
		param4 ="";
		param5 ="";
		TaxId = "";
		TaxName = "";
		flag = true;


		var $paramRows = $('#tbl_SelectFilterParam > tbody  > tr');
		var paramSelector = $paramRows.find('td.ddFilterParamSelector').find(':selected').attr("id");
		var optionSelector = $paramRows.find('td.ddOptionSelector').find(':selected').val();
		var logicalSelector = $paramRows.find('td.andOrPara').find(':selected').val();
		var inputValSelector = $paramRows.find('td.inputValueSelector').find("input[type='text']").val();
		var ddParamValSelector = $paramRows.find('td.ddParamValueSelector').find(':selected').val();
		/*console.log(" paramSelector "+paramSelector+" optionSelector  "+optionSelector);
		console.log(" logicalSelector "+logicalSelector+" inputValSelector  "+inputValSelector+"  ddParamValSelector  "+ddParamValSelector);*/


		if(paramSelector == "Select Parameter" && addTaxo == 0){
			param1 = "";
			appendTax = "";
			$("#noBrowserData").show().html("Please provide the filter criteria");
			flag = false;
		}
		
		
		else if(paramSelector == "Select Parameter" && addTaxo != 0){
			param1 = "";
			$('.assignTax a').each(function(i){
				var taxData = $(this).attr('id');
				taxData = taxData.split('_');
				TaxId = taxData[1];
				TaxName = taxData[2];
				appendTax += TaxId+":"+TaxName+"~";

			})
			appendTax = appendTax.substring(0, appendTax.length-1);

		}
		
		
		else if(paramSelector != "Select Parameter" && addTaxo == 0){
			appendTax = "";
			if(paramSelector != undefined || paramSelector != null){
				param1 = param1 + paramSelector + "~";
				$("#noBrowserData").hide();
			}else{
				$("#noBrowserData").show();
				flag = false;
			}

			if(optionSelector != undefined || optionSelector != null){
				param2 = param2 + optionSelector + "~";
				$("#noBrowserData").hide();
			}else{
				$("#noBrowserData").show();
			}

			if(logicalSelector != undefined || logicalSelector != null){
				param3 = param3 + logicalSelector + "~";
				$("#noBrowserData").hide();
			}else{
				$("#noBrowserData").show();
			}

			if($paramRows.find('td.ddParamValueSelector').hasClass('dropDownList')){
				var ddParamValSelector  = $paramRows.find('td.ddParamValueSelector').find(':selected').text();
				if(ddParamValSelector != undefined){
					param4 = param4 + ddParamValSelector + "~";
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + "undefined" + "~";
			}
			//Ldap
			else if($paramRows.find('td.inputLdapTextSelector').hasClass('ldapText')){
				var ldapValueSelector  = $paramRows.find('td.inputLdapTextSelector').find("input[type='text']").val().trim();
				if(ldapValueSelector != undefined && ldapValueSelector != ""){//Swathi -empty fields
					param4 = param4 + ldapValueSelector + "~";
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + "undefined" + "~";
				//console.log('save filter param4  '+param4)
			}
			
			else if($paramRows.find('td.inputValueSelector').hasClass('textBoxValue')){
				var inputValSelector  = $paramRows.find('td.inputValueSelector').find("input[type='text']").val().trim();
				if(inputValSelector != "" && inputValSelector != undefined){
					param4 = param4 + inputValSelector + "~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				if(optionSelector == "Between"){
					var inputTwoValue = $paramRows.find('td.inputValueSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
					if(inputTwoValue != "" && inputTwoValue != undefined){
						param5 = param5 + inputTwoValue + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
				}
				else{
					param5 = param5 + "undefined" + "~";
				}
				
			}
			else if($paramRows.find('td.inputDateSelector').hasClass('dateBoxValue')){

				var dateValSelector  =  $paramRows.find('td.inputDateSelector').find("input[type='text']").val();
				if(dateValSelector != "" && dateValSelector != undefined){
					param4 = param4 + dateValSelector + "~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				if(optionSelector == "Between"){
					var inputTwoValue = $paramRows.find('td.inputDateSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
					if(inputTwoValue != "" && inputTwoValue != undefined){
						param5 = param5 + inputTwoValue + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
				}
				else{
					param5 = param5 + "undefined" + "~";
				}
			}
			else if($paramRows.find('td.fileSelector').hasClass('fileValue')){
				param4 = param4 + "undefined" + "~";
				param5 = param5 + "undefined" + "~";
			}
			else if($paramRows.find('td.inputRichTextSelector').hasClass('richTextValue')){
				var richTextValSelector  = $paramRows.find('td.inputRichTextSelector').find("input[type='text']").val().trim();
				//console.log(" richTextValSelector "+richTextValSelector);
				if(richTextValSelector != "" && richTextValSelector != undefined){
					param4 = param4 + richTextValSelector + "~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + "undefined" + "~";
			}
			// BOC HEma 07.Mar.2019 Ldap Mapping
			else if($paramRows.find('td.inputLdapMappingTextSelector').hasClass('ldapMappingText')){
				var ldapMappingValueSelector  = $paramRows.find('td.inputLdapMappingTextSelector').find("input[type='text']").val().trim();
				if(ldapMappingValueSelector != undefined && ldapMappingValueSelector != ""){//Swathi- Empty fields
					param4 = param4 + ldapMappingValueSelector + "~";
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + "undefined" + "~";
				//console.log('save filter param4  '+param4)
			}
			//EOC
		}
		
		else if(paramSelector != "Select Parameter" && addTaxo != 0){

			$("#noBrowserData").hide();

			if(paramSelector != undefined || paramSelector != null){
				param1 = param1 + paramSelector + "~";
				$("#noBrowserData").hide();
			}else{
				$("#noBrowserData").show();
				flag = false;
			}

			if(optionSelector != undefined || optionSelector != null || optionSelector != ""){
				param2 = param2 + optionSelector + "~";
				$("#noBrowserData").hide();
			}else{
				$("#noBrowserData").show();
			}
			if(logicalSelector != undefined || logicalSelector != null){
				param3 = param3 + logicalSelector + "~";
				$("#noBrowserData").hide();
			}else{
				$("#noBrowserData").show();
			}
			if($paramRows.find('td.ddParamValueSelector').hasClass('dropDownList')){
				var ddParamValSelector  = $paramRows.find('td.ddParamValueSelector').find(':selected').text();
				if(ddParamValSelector != undefined ){
					param4 = param4 + ddParamValSelector + "~";
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + "undefined" + "~";
			}
			else if($paramRows.find('td.inputLdapTextSelector').hasClass('ldapText')){
				var ldapValueSelector  = $paramRows.find('td.inputLdapTextSelector').find("input[type='text']").val().trim();
				if(ldapValueSelector != undefined && ldapValueSelector != ""){//Swathi Empty fields
					param4 = param4 + ldapValueSelector + "~";
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + "undefined" + "~";
				//console.log('save filter param4  '+param4)
			}
			else if($paramRows.find('td.inputValueSelector').hasClass('textBoxValue')){
				var inputValSelector  = $paramRows.find('td.inputValueSelector').find("input[type='text']").val().trim();
				if(inputValSelector != "" && inputValSelector != undefined){
					param4 = param4 + inputValSelector + "~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				if(optionSelector == "Between"){
					var inputTwoValue = $paramRows.find('td.inputValueSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
					if(inputTwoValue != "" && inputTwoValue != undefined){
						param5 = param5 + inputTwoValue + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
				}
				else{
					param5 = param5 + "undefined" + "~";
				}
			}
			else if($paramRows.find('td.inputDateSelector').hasClass('dateBoxValue')){

				var dateValSelector  =  $paramRows.find('td.inputDateSelector').find("input[type='text']").val();
				if(dateValSelector != "" && dateValSelector != undefined){
					param4 = param4 + dateValSelector + "~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				if(optionSelector == "Between"){
					var inputTwoValue = $paramRows.find('td.inputDateSelector').find( "div:eq(1)" ).find("input[type='text']").val().trim();
					if(inputTwoValue != "" && inputTwoValue != undefined){
						param5 = param5 + inputTwoValue + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
				}
				else{
					param5 = param5 + "undefined" + "~";
				}

			}
			else if($paramRows.find('td.fileSelector').hasClass('fileValue')){
				param4 = param4 + "undefined" + "~";
				param5 = param5 + "undefined" + "~";
			}
			else if($paramRows.find('td.inputRichTextSelector').hasClass('richTextValue')){
				var richTextValSelector  = $paramRows.find('td.inputRichTextSelector').find("input[type='text']").val().trim();
				//console.log(" richTextValSelector "+richTextValSelector);
				if(richTextValSelector != "" && richTextValSelector != undefined){
					param4 = param4 + richTextValSelector + "~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + "undefined" + "~";
			}
			
			// BOC HEma 07.Mar.2019 Ldap Mapping
			else if($paramRows.find('td.inputLdapMappingTextSelector').hasClass('ldapMappingText')){
				var ldapMappingValueSelector  = $paramRows.find('td.inputLdapMappingTextSelector').find("input[type='text']").val().trim();
				if(ldapMappingValueSelector != undefined && ldapMappingValueSelector != ""){//Swathi Empty fields
					param4 = param4 + ldapMappingValueSelector + "~";
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + "undefined" + "~";
				//console.log('save filter param4  '+param4)
			}
			//EOC

			$('.assignTax a').each(function(i){
				var taxData = $(this).attr('id');
				taxData = taxData.split('_');
				TaxId = taxData[1];
				TaxName = taxData[2];
				appendTax += TaxId+":"+TaxName+"~";

			});
			appendTax = appendTax.substring(0, appendTax.length-1);
		}
		param1 = param1.substring(0, param1.length-1);
		param2 = param2.substring(0, param2.length-1);
		param3 = param3.substring(0, param3.length-1);
		param4 = param4.substring(0, param4.length-1);
		param5 = param5.substring(0, param5.length-1);
		/*console.log(" dasghddwedfinside "+param1+"  param2 "+param2+"   param3 "+param3)*/
		//console.log(" param4 "+param4);
	}
	else{
		
		appendTax = "";
		param1= "";
		param2 ="";
		param3 ="";
		param4 ="";
		param5 ="";
		TaxId = "";
		TaxName = "";
		flag = true;


		$('#tbl_SelectFilterParam > tbody  > tr').each(function() {

			$(this).find('td.ddFilterParamSelector').each(function() {
				var paramSelector = $(this).find(':selected').attr("id");
				if(paramSelector != undefined){
					param1 = param1 + paramSelector + "~";
					$("#noBrowserData").hide();
				}
				else{
					$("#noBrowserData").show();
					flag = false;
				}      
			});
			var optionSelector = "";
			$(this).find('td.ddOptionSelector').each(function() {
				optionSelector = $(this).find(':selected').val();
				if(optionSelector != undefined){
					param2 = param2 + optionSelector + "~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
				}
			});

			$(this).find('td.andOrPara').each(function() {
				var logicalSelector  = $(this).find(':selected').text();
				//console.log(' logicalSelector '+logicalSelector);
				if(logicalSelector != undefined){
					param3 = param3 + logicalSelector + "~";
					$("#noBrowserData").hide();
				}else{
					$("#noBrowserData").show();
				}
			});

			if($(this).find('td.ddParamValueSelector').hasClass('dropDownList')){
				$(this).find('td.ddParamValueSelector').each(function() {
					var ddParamValSelector  = $(this).find(':selected').text();
					if(ddParamValSelector != undefined ){
						param4 = param4 + ddParamValSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}
				});
				param5 = param5 + "undefined" + "~";
			}
			else if($(this).find('td.inputLdapTextSelector').hasClass('ldapText')){
				$(this).find('td.inputLdapTextSelector').each(function() {
					var ldapValueSelector  = $(this).find("input[type='text']").val().trim();
					if(ldapValueSelector != undefined && ldapValueSelector !=""){//Swathi Empty fields
						param4 = param4 + ldapValueSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}
				});

				param5 = param5 + "undefined" + "~";
				//console.log('else  ghhh  save filter param4  '+param4)
			}
			
			
			
			else if($(this).find('td.inputValueSelector').hasClass('textBoxValue')){
				$(this).find('td.inputValueSelector').each(function() {
					var inputValSelector  = $(this).find("input[type='text']").val().trim();
					if(inputValSelector != "" && inputValSelector != undefined){
						param4 = param4 + inputValSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}
					if(optionSelector == "Between"){
						var inputTwoValue = $(this).find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~";
						}
						else{
							$("#noBrowserData").show();
							flag = false;
						}
					}
					else{
						param5 = param5 + "undefined" + "~";
					}
				});
			}
			else if($(this).find('td.inputDateSelector').hasClass('dateBoxValue')){
				$(this).find('td.inputDateSelector').each(function() {
					var dateValSelector  = $(this).find("input[type='text']").val();
					if(dateValSelector != "" && dateValSelector != undefined){
						param4 = param4 + dateValSelector + "~";
					}else{
						$("#noBrowserData").show();
						flag = false;
					}
					
					if(optionSelector == "Between"){
						var inputTwoValue = $(this).find( "div:eq(1)" ).find("input[type='text']").val().trim();
						if(inputTwoValue != "" && inputTwoValue != undefined){
							param5 = param5 + inputTwoValue + "~";
						}else{
							$("#noBrowserData").show();
							flag = false;
						}
					}
					else{
						param5 = param5 + "undefined" + "~";
					}
				});
			}
			else if($(this).find('td.fileSelector').hasClass('fileValue')){
				param4 = param4 + "undefined" + "~";
				param5 = param5 + "undefined" + "~";
			}
			else if($(this).find('td.inputRichTextSelector').hasClass('richTextValue')){
				var richTextValSelector  = $(this).find('td.inputRichTextSelector').find("input[type='text']").val().trim();
				//console.log(" richTextValSelector "+richTextValSelector);
				if(richTextValSelector != "" && richTextValSelector != undefined){
					param4 = param4 + richTextValSelector + "~";
				}else{
					$("#noBrowserData").show();
					flag = false;
				}
				param5 = param5 + "undefined" + "~";
			}
			
			// BOC Hema 07.Mar.2019 Ldap Mapping
			else if($(this).find('td.inputLdapMappingTextSelector').hasClass('ldapMappingText')){
				$(this).find('td.inputLdapMappingTextSelector').each(function() {
					var ldapMappingValueSelector  = $(this).find("input[type='text']").val().trim();
					if(ldapMappingValueSelector != undefined && ldapMappingValueSelector != ""){//Swathi Empty fields
						param4 = param4 + ldapMappingValueSelector + "~";
					}
					else{
						$("#noBrowserData").show();
						flag = false;
					}
				});

				param5 = param5 + "undefined" + "~";
				//console.log('else  ghhh  save filter param4  '+param4)
			}
			// EOC
			
		});
		//console.log(" param1 "+param1+"  param2 "+param2+"   param3 "+param3)
		//console.log(" param4 "+param4+"  param5 "+param5)
		if(addTaxo == 0 ){
			appendTax = "";
		}else{
			$('.assignTax a').each(function(i){
				var taxData = $(this).attr('id');
				taxData = taxData.split('_');
				TaxId = taxData[1];
				TaxName = taxData[2];
				appendTax += TaxId+":"+TaxName+"~";

			})
			appendTax = appendTax.substring(0, appendTax.length-1);
			//console.log(' more than one param  appendTax'+appendTax);
		}
		param1 = param1.substring(0, param1.length-1);
		param2 = param2.substring(0, param2.length-1);
		param3 = param3.substring(0, param3.length-1);
		param4 = param4.substring(0, param4.length-1);
		param5 = param5.substring(0, param5.length-1);
		/*console.log(" dasghddwedfinside "+param1+"  param2 "+param2+"   param3 "+param3)
		console.log(" param4 "+param4+"  param5 "+param5)*/
	}
}

//Swathi - Default filter
function removeDefaultFilter(){
	//$('#openConfirmationofSaveDefault').modal('destroy'); //Closing confirmation modal
	defaultFilterFlag = 0;
	updateFilter();
	defaultFilterNameAjax();
	$('#removeDefault').hide(); 
	$("#savedFilterdd").html('');	
	refreshTable();
	loadBrowseFilterFlag = false;
	closeDefault = 0;
	//$('#loadContent').load('browser.html');	
	
}

//Swathi - Default filter
var closeDefault;
function removeDuplicates(str){	
	let last = "~";
	let result = "";
	for(let i = 0; i < str.length; i++){
	  let char = str.charAt(i);
	  if(char !== last){
	    result += char;
	    //last = char;
	  }
	}
	return result;
}

//Swathi- Confirmation Modal- on click of No  - 10.12.2019
$('#ApplyNoSave').click(function(){
	$('#openConfirmationofSaveDefault').modal('hide').modal('hide dimmer');
	$('#openConfirmationofSaveDefault').modal('destroy'); //Closing confirmation modal
	saveConfirmationflag = false;
	$("#defaultfilterName").text("Unnamed");
	$("#defaultfilterName1").text("Unnamed");
});

function closenow(){
	if(closeDefault == 0){
		$('#loadContent').load('browser.html');
		closeDefault = 1;
	}
	
}
