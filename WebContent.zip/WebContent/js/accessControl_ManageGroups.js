//load group data from database 
function loadGroupsDetails(){
	appendData = "";
	$.ajax({
		type : "GET",
		url : "/repopro/web/groupmanager/getallgroups",
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result.length == 2){
					$('#groupsGrid').hide();
					$('#noGridDataGroups').show();
					$('#noGridDataGroups').html('<div class="ui message">No groups added yet</div>'); 
				}else {
					$('#noGridDataGroups').hide();
					$('#groupsGrid').show();
					$('#groupsGrid table tbody').html("");
					$.each(json.result, function(i) {
						appendData = getGroupDetails(json.result[i].groupId,json.result[i].groupName,json.result[i].description,json.result[i].groupUserFlag);
						$('#groupsGrid table tbody').append(appendData);
						if(json.result[i].groupName == "group-admin" || json.result[i].groupName == "Guest"){
							$("#trAccessGrp_"+json.result[i].groupId).addClass("hidden");
						}
					});


				}
			}
			$('#showHideLoader').removeClass('active');
		}
	});
}

//append access group details to table
function getGroupDetails(groupId, groupName, groupDescription,groupFlag) {
	var data = "<p>Are you sure you want to delete "+groupName+" ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteGroupPopup("+groupId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteGroup(this,"+groupId+")'>Yes</button> ";
	appendData = "";
	appendData += '<tr id="trAccessGrp_'+groupId+'">';
	appendData += '<td class="hidden" id="groupId_'+ groupId +'">' + groupId + '</td>';
	appendData += '<td class="whitespaceNoTrim" id="groupName_'+groupId+'">';
	appendData += '<div><div class="mediumIconImageCircleStyle"><i class="users icon sidebarIcons widgetIconColor" style="margin-top: 0.4em;margin-left: 0.7em !important;"></i></div><span style="vertical-align: -webkit-baseline-middle;" class="gridImageTextSpacing">'+groupName+'</span></div></td>';
	appendData += '<td class= "whitespaceNoTrim" id="groupDescription_'+groupId+'">'+ groupDescription + '</td>';
/*	appendData += '<td class="center aligned"><i class="configure icon deleteEditIcon" title="Click here to view" id="showAssociatedRoles_'+groupId+'" onclick="openAssociatedRoles('+groupId+')"></i></td>';
*/	appendData += '<td><a><i class="edit icon deleteEditIcon" onclick="openEditGroup(this,'+groupId+')"></i></a></td>';
	if(groupFlag == true){
		appendData += '<td class="disabled disableDeleteIcon"><span data-tooltip="Cannot delete this group. Group is associated with user(s)." data-position="left center"><i class="trash icon" id="trash_'+groupId+'" data-html="'+data+'"></i></span></td>';
	}
	else {
		appendData += '<td><a><i class="trash icon deleteEditIcon" id="trash_'+groupId+'" data-html="'+data+'" onclick="openDeleteGroupPopup('+groupId+')"></i></a></td>';
	}
	appendData += '</tr>';
	return appendData;
}

//Add Group modal
function openAddGroup(){
	/*$("#addGroupDescription").attr('maxlength','100');
	$("#addGroupDescriptionCounter").html('Maximum Characters: 100');*/
	$('#submitAddedGroups').unbind();
	$('#cancelAddedGroups').unbind();
	$(".errAddGroupName").hide();
	$('#addGroupName').parent().removeClass("error");
	$(".errAddGroupDescription").hide();
	$('#addGroupDescription').parent().removeClass("error"); 
	$('#addGroup').modal('setting', 'closable', false).modal('show');
	appendAddGroup = "";
	$("#addGroupName").val("");
	$("#addGroupDescription").val("");

	//Count Characters Remaining
	/*addEventListener('input',function () {
		var charactersS = 100 - $('#addGroupDescription').val().length;
		$('#addGroupDescriptionCounter').html('Characters Remaining: ' + charactersS);
	});*/

	// submit added group
	$('#submitAddedGroups').on('click', function(){
		var addGroupName = $("#addGroupName").val().trim();
		var addGroupDescription = $("#addGroupDescription").val().trim(); 
		var flag = true;	
		$(".errAddGroupName").hide();
		$('#addGroupName').parent().removeClass("error");

		$(".errAddGroupDescription").hide(); 
		$('#addGroupDescription').parent().removeClass("error"); 

		if(addGroupName == null || addGroupName == ""){
			$('#addGroupName').parent().addClass("error"); 
			$(".errAddGroupName").html('Please provide group name').show();  
			flag = false;
		}
		else{
			var regex = /^[a-zA-Z0-9- \-\_]*$/;
			if (regex.test(addGroupName) == false) {
				$('#addGroupName').parent().addClass("error"); 
				$(".errAddGroupName").html("Please use only alphanumeric characters, space, \"-\" and \"_\" in group name.").show();  
				flag = false; 
			}
			else{
				$('#addGroupName').parent().removeClass("error"); 
				$(".errAddGroupName").hide();
			}
		}

		if(addGroupDescription == null || addGroupDescription == ""){
			$('#addGroupDescription').parent().addClass("error"); 
			$(".errAddGroupDescription").show();  
			flag = false;
		}
		else{
			$('#addGroupDescription').parent().removeClass("error"); 
			$(".errAddGroupDescription").hide(); 
		}
		if(flag == false){
			$('#addGroup').modal('show');
			return false;
		}
		else {
			var obj = {
					"groupName": addGroupName,
					"description": addGroupDescription
			};
			$.ajax({
				type: "POST",
				url: "/repopro/web/groupmanager/addgroup",
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				cache: false,
				complete:function(data){	
					appenddata = "";
					var json = JSON.parse(data.responseText);
					var groupId = "";
					if(json.status == "SUCCESS"){
						/*appendData = getGroupDetails(json.result[0].groupId, addGroupName, addGroupDescription);
						$('#groupsGrid table tbody').append(appendData);*/
						loadGroupsDetails();
						notifyMessage("Add Group","Group "+addGroupName+" added","success");
						$('#addGroupName').parent().removeClass("error"); 
						$(".errAddGroupName").hide();
					}
					else {
						$('#addGroupName').parent().addClass("error"); 
						$(".errAddGroupName").html("Group by this name already exists").show();  
						flag = false;

					}	

				}
			});
		}
		if(flag == false){
			$('#addGroup').modal('show');
			return false;
		}
		else{
			$('#addGroup').modal('hide'); //.modal('hide dimmer');
			$('#addGroup').parent().css("display", "none !important");
		}
		$("html, body").animate({
			scrollTop: 0
		}, 10);
	}); 
}

//Edit Group Modal
var addedGrpRolesIds = [] ;
function openEditGroup(obj, groupId){
	/*$("#editGroupDescription").attr('maxlength','100');
	$("#editGroupDescriptionCounter").html('Maximum Characters: 100');*/
	$('#submitEditAssociateGroups').unbind();
	$('#cancelEditAssociateGroups').unbind();
	
	$('#editGroupName').parent().removeClass("error"); 
	$(".errEditGroupName").hide();
	$('#editGroupDescription').parent().removeClass("error"); 
	$(".errEditGroupDescription").hide();
	$('#editGroup').modal('destroy');
	$('#editGroup').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	var groupName = $("#groupName_"+groupId).text();
	var groupDescription = $("#groupDescription_"+groupId).text();
	$("#editGroupName").val(groupName);
	$("#editGroupDescription").val(groupDescription); 

	/*Added By Hema BOC*/
	$('#GroupName').text(groupName);
	/*EOC*/  
	
	//Count Characters Remaining
	/*addEventListener('input',function () {
		var charactersS = 100 - $('#editGroupDescription').val().length;
		$('#editGroupDescriptionCounter').html('Characters Remaining: ' + charactersS);
	});*/
	
	// show Associated Functions
	$.ajax({
		type: "GET",
		url: "/repopro/web/groupmanager/getallgrouproles/"+groupId,
		dataType: "json",
		async: false,
		cache: false,
		complete:function(data){										
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$('#gridAssociatedRoles table tbody').html("");
				$.each(json.result, function(i) {
					appenData = getAssociatedGrpDetails(json.result[i].roleId,json.result[i].roleName,json.result[i].mappedWithGroup);
					$('#gridAssociatedRoles table tbody').append(appenData);
				});


			}
		}
	});

	if ($('.groupRoles:checked').length == $('.groupRoles').length ){
		$("#selectAllAssociatedGroups").prop('checked', true);
	}
	else{
		$("#selectAllAssociatedGroups").prop('checked', false); 
	}

	// submit edited groups
	$('#submitEditAssociateGroups').on('click', function(){
		var editGroupName = $("#editGroupName").val().trim();
		var editGroupDescription = $("#editGroupDescription").val().trim(); 
		var flag = true;	

		if(editGroupName == null || editGroupName == ""){
			$('#editGroupName').parent().addClass("error"); 
			$(".errEditGroupName").html('Please enter group name').show();  
			flag = false;
		}
		/*else {
			if (/^[a-zA-Z0-9- ]*$/.test(editGroupName) == false) {
				$('#editGroupName').parent().addClass("error"); 
				$(".errEditGroupName").html('Group Name can not contain special characters.').show();  
				flag = false;
			}
			else{				
				$('#editGroupName').parent().removeClass("error"); 
				$(".errEditGroupName").hide(); 
			}
		}*/

		if(editGroupDescription == null || editGroupDescription == ""){
			$('#editGroupDescription').parent().addClass("error"); 
			$(".errEditGroupDescription").show();  
			flag = false;
		}
		else{
			$('#editGroupDescription').parent().removeClass("error"); 
			$(".errEditGroupDescription").hide(); 

		}
		if(flag == false){
			$('#editGroup').modal('show');
			return false;
		}
		else {
			addedGrpRolesIds.length = 0;
			$('input[class="groupRoles"]').each(function(k) {
				var itm = $(this);
				var data = $(this).attr('id');
				var arr = data.split('_'); 
				if ($(this).is(":checked")) {
					addedGrpRolesIds.push(arr[1]);
				} 
			});
			var obj = {
					"groupId": groupId,
					"groupName": editGroupName,
					"description": editGroupDescription,
					"associatedRoleIds":addedGrpRolesIds
			};

			$.ajax({
				type: "PUT",
				url: "/repopro/web/groupmanager/updategroup",
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				cache: false,
				complete:function(data){	
					appenddata = "";
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
/*						$('#groupName_'+groupId).html('<i class="users icon sidebarIcons widgetIconColor" style="margin-right: 0.8em;"></i>'+editGroupName);
*/						/*$('#groupName_'+groupId).html('<div><div class="mediumIconImageCircleStyle"><i class="users icon sidebarIcons widgetIconColor" style="margin-top: 0.4em;margin-left: 0.7em !important;"></i></div><span style="margin-left: 0.8em;vertical-align: -webkit-baseline-middle;">'+editGroupName+'</span></div>');
						$('#groupDescription_'+groupId).html(editGroupDescription);*/
						loadGroupsDetails();
						notifyMessage("Update Group",editGroupName+" updated","success");
					}
					else {
						if(editGroupName != groupName){
							$('#editGroupName').parent().addClass("error"); 
							$(".errEditGroupName").html(json.result).show();  
							flag = false;	
						}
						else{
							notifyMessage("Update Group",json.status,"fail");
						}
					}
				}

			});
		}
		if(flag == false){
			$('#editGroup').modal('show');
			return false;
		}
		else{
			$('#editGroup').modal('hide'); //.modal('hide dimmer');
			$('#editGroup').parent().css("display", "none !important");
		}
	}); 
	
}

//delete group confirmation popup
function openDeleteGroupPopup(groupId){
	$("#trash_"+groupId)
	.popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	})
	.popup('show');
}

//close delete group popup
function closeDeleteGroupPopup(groupId){
	$("#trash_"+groupId).popup('hide');
}


//delete group
function deleteGroup(obj, groupId){
	$.ajax({
		type: "DELETE",
		url: "/repopro/web/groupmanager/deletegroup/"+groupId,
		dataType: "json",
		async: false,
		cache: false,
		complete:function(data){										
			var json = JSON.parse(data.responseText);
			if(json.status == "FAILURE"){
				notifyMessage("Delete Group",json.message,"fail");
			}
			else {
				if(json.result != ""){
					notifyMessage("Delete Group",json.result,"fail");
				} 
				else{	
					notifyMessage("Delete Group","Group deleted","success");
					$('#trAccessGrp_'+groupId).remove();
					
					var rowCount = $('#tableGroups tr').length;
					if(rowCount == "3"){
						$('#groupsGrid').hide();
						$('#noGridDataGroups').show();
						$('#noGridDataGroups').html('<div class="ui message">No groups added yet</div>'); 
					}else {
						$('#groupsGrid').show();
						$('#noGridDataGroups').hide();
					}
					
				}
				closeDeleteGroupPopup(groupId);	
			}
		}
	});   
}


//get Associated Role Details for group
function getAssociatedGrpDetails(roleId,roleName,chkboxMappedWithGroup){
	appenData = "";
	if(roleName != "Guest"){
	appenData += "<tr>";
	appenData += "<td class='hidden' id='roleId_"+roleId+"'>"+roleId+"</td>";
	if(chkboxMappedWithGroup == true){
		appenData += "<td><div class='ui checkbox'><input onClick='checkSelectAllRole(this)' type='checkbox' id='associatedRoleName_"+roleId+"' class='groupRoles' checked><label>"+roleName+"</label></div></td>";
	}
	else {
		appenData += "<td><div class='ui checkbox'><input onClick='checkSelectAllRole(this)' type='checkbox'  id='associatedRoleName_"+roleId+"' class='groupRoles'><label>"+roleName+"</label></div></td>";	
	}
	appenData += "</tr>";
	}
	return appenData;
}

//check uncheck All Roles for group 
function selectAllFunction_Group(){
	if(selectAllAssociatedGroups.checked){
		$('.groupRoles').prop('checked',true);
	}
	else {
		$('.groupRoles').prop('checked',false);
	}
}

//check select all when all check box are checked
function checkSelectAllRole(obj){
	if(false == $(obj).prop('checked')){ 
		$("#selectAllAssociatedGroups").prop('checked', false); 
	}
	if ($('.groupRoles:checked').length == $('.groupRoles').length ){
		$("#selectAllAssociatedGroups").prop('checked', true);
	}
}

