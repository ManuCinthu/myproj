
// load guest access data from database 
function loadGlobalSettingDetails(){ 
		$.ajax({
			type : "GET",
			url : "/repopro/web/globalsettings",
			dataType : "json",
			async: false,
			cache: false,
			complete : function(data) {
				
					var json = JSON.parse(data.responseText);
						if(json.result[0].globalLdapSettingFlag == 1){
							$("#radioBtn_LDAP").prop('checked',true); 
							$("#radioBtn_NativeDB").prop('checked',false);
						}
						else{
							$("#radioBtn_LDAP").prop('checked',false);
							$("#radioBtn_NativeDB").prop('checked',true);
						}
						if(json.result[0].globalLockSettingFlag == 1){
							$('#chk_EnblConcurrentEditLck').prop('checked',true); 
							 $('#lockRelease').prop('disabled', false);
						}else{
							$('#chk_EnblConcurrentEditLck').prop('checked',false); 
							$('#lockRelease').prop('disabled', true);
						}
						if(json.result[0].ssoFlag == 1){
							$('#chk_SAML').prop('checked',true); 
						}else{
							$('#cchk_SAML').prop('checked',false); 
						}
						
						if(json.result[0].circularImage == 1){
							$('#themeCircle').prop('checked',true); 
						}else{
							$('#themeCircle').prop('checked',false); 
						}
						
						if(json.result[0].invertedImage == 1){
							$('#invertImage').prop('checked',true); 
						}else{
							$('#invertImage').prop('checked',false); 
						}
						if(json.result[0].crossSiteScriptProtection == 1){
							$("#chk_crossBrowserScripting").prop('checked',true); 
							//$("#radioBtn_NativeDB").prop('checked',false);
						}
						else{
							$("#chk_crossBrowserScripting").prop('checked',false);
							//$("#radioBtn_NativeDB").prop('checked',true);
						}
						
						//----------guest access -- Chandana 12/8/2019-----------//
						if(json.result[0].guestAccess == 1){
							$("#chk_guestAccessPermission").prop('checked',true); 
						}
						else{
							$("#chk_guestAccessPermission").prop('checked',false);
						}
						
						
					/*	if(json.result[0].mechanism == "Native"){
							$("#ddSelectRestAPIMech").dropdown('set selected',"Native");
						}
						else{
							$("#ddSelectRestAPIMech").dropdown('set selected',"oAuth");
						}*/
						
						if(json.result[0].mechanism == "Native"){
							$("#radioBtn_restNative").prop('checked',true); 
							$("#radioBtn_restoAuth").prop('checked',false);
						}
						else{
							$("#radioBtn_restNative").prop('checked',false);
							$("#radioBtn_restoAuth").prop('checked',true);
						}
						
						$('#lockRelease').val(json.result[0].lockTime);
						$('#showHideLoader').removeClass('active');
			}
		});
}

//check the radio button and display lock time
$('#chk_EnblConcurrentEditLck').on('change', function() {
    var isChecked = $(this).is(':checked');
    if(isChecked) {
    	 $('#lockRelease').prop('disabled', false);
    } else {
    	 $('#lockRelease').prop('disabled', true);
    }
});

//save the changes and store in db
function saveGlobalSettingData(){
	
	var ldapSettingFlag = "";
	var lockSettingFlag = "";
	var crossBrowserScripting = "";
	var themeCircleFlag,invertImageFlag;
	var guestAccess = "";
	
	var flag = true;
	$(".errLockReleaseTime").hide();
	$(".errGlobalLockTime").hide();
	 
	if($("#radioBtn_LDAP").is(':checked')){
		ldapSettingFlag = 1;
	}else {
		ldapSettingFlag = 0;
	}
	
	if($("#chk_EnblConcurrentEditLck").is(':checked')){
		lockSettingFlag = 1;
	}else {
		lockSettingFlag = 0;
	}
	
	if($("#chk_SAML").is(':checked')){
		SAMLFlag = 1;
	}else {
		SAMLFlag = 0;
	}
	
	if($("#themeCircle").is(':checked')){
		themeCircleFlag = 1;
	}else {
		themeCircleFlag = 0;
	}
	
	if($("#invertImage").is(':checked')){
		invertImageFlag = 1;
	}else {
		invertImageFlag = 0;
	}
	
	if($("#chk_crossBrowserScripting").is(':checked')){
		crossBrowserScripting = 1;
	}else {
		crossBrowserScripting = 0;
	}
	
	if($("#chk_guestAccessPermission").is(':checked')){
		guestAccess = 1;
	}else {
		guestAccess = 0;
	}
	
	
	
	var globalLocktime = $('#lockRelease').val().trim();
	var specialCharRegexStr2 = /^[0-9]*(?:\\d{1,4})?$/;
	var lockTimeIsValid = specialCharRegexStr2.test(globalLocktime);
	
	if(lockSettingFlag == 1){	
			if(globalLocktime == null || globalLocktime == ""){
				$('#lockRelease').parent().addClass("error"); 
				$("#errIdGlobalLockTime").show();  
				$(".errLockReleaseTime").hide();
				flag = false;
			}
			else if(!lockTimeIsValid){
				$('#lockRelease').parent().addClass("error"); 
				$(".errLockReleaseTime").show().html('Please enter only positive whole number');
				$("#errIdGlobalLockTime").hide(); 
				flag = false;
			}else if(globalLocktime == 0){
				$('#lockRelease').parent().addClass("error"); 
				$("#errIdGlobalLockTime").show().html('Please provide valid lock release time');  
				flag = false;
			}else{
				 $('#lockRelease').parent().removeClass("error"); 
				 $("#errIdGlobalLockTime").hide();
				 $(".errLockReleaseTime").hide();
				 flag = true;
			}
	}else{
		$(".errLockReleaseTime").hide();
		$(".errGlobalLockTime").hide();
	}
	//var selectedData = $('#ddSelectRestAPIMech :selected').text();
	var selectedData = "";
	if($("#radioBtn_restNative").is(':checked')){
		selectedData = "Native";
	}else {
		selectedData = "oAuth";
	}
	//alert("selectedData   "+selectedData);
	
	if(flag){
		var data = {
				 "globalLdapSettingFlag": ldapSettingFlag,
		         "globalLockSettingFlag": lockSettingFlag,
		         "lockTime": globalLocktime,
		         "ssoFlag" : SAMLFlag,
		         "circularImage":themeCircleFlag,
		         "invertedImage":invertImageFlag,
		         "crossSiteScriptProtection":crossBrowserScripting,
		         "guestAccess" : guestAccess,
		         "mechanism":selectedData
			} 
	//  console.log(" data "+JSON.stringify(data));
	  $.ajax({
	       type: "PUT",
	       url : "/repopro/web/globalsettings",
	       contentType : "application/json",
			dataType : "json",
			data : JSON.stringify(data),
			async: false,
			cache: false,
			complete:function(data){
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(themeCircleFlag == 1){
						circularThemeColoredIcon = true;
					}else{
						circularThemeColoredIcon = false;
					}
					
					if(invertImageFlag == 1){
						invertAssetIconFlag = true;
					}else{
						invertAssetIconFlag = false;
					}
					
					notifyMessage("Global Setting","Global settings updated","success");
				}
				else {
					notifyMessage("Global Setting","Error attempting to update global settings","fail");
				}
			}
	  });
	}
  }
