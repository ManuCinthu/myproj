deptFlag = true;
//show change password field
	function showChangePasswordFields() {
		$('#changePasswordVisible').toggle("slow");
		$('#changePasswordVisible').toggleClass("passwordFieldVisible");
	}

	//edit user profile modal
	var addedUserFunctionIds1 = [] ;
	function editUserDetails(userId,pageName) {
		$('#editUser').modal("destroy");
		var contactTopPosition = $("#userInfoInputFields").position().top;
		$(".modalOverflow").animate({scrollTop: contactTopPosition});
		
		$('#submitEditedUsers').unbind();
		$('#cancelEditedUsers').unbind();
		
		$("#uploadUserImage").val("");

		$('#editUserFullName').parent().removeClass("error");
		$(".errEditUserFullName").hide();

		$('#editUserEmail').parent().removeClass("error");
		$(".errEditUserEmail").hide();

		$('#editUserDepartment').parent().removeClass("error");
		$(".errEditUserDepartment").hide();

		$('#uploadUserImage').parent().removeClass("error");
		$(".errEditUserProfilePicture").hide();

		$('#editUserOldPassword').parent().removeClass("error");
		$(".errEditUserOldPassword").hide();

		$('#editUserNewPassword').parent().removeClass("error");
		$(".errEditUserNewPassword").hide();

		$('#editUserConfirmNewPassword').parent().removeClass("error");
		$(".errEditUserConfirmNewPassword").hide();
		
		$('#uploadUserImage').parent().parent().removeClass("error");
		$(".errEditUserProfilePicture").hide();
		
		$("#encryptImage").attr( "disabled", "disabled" );//Swathi- Encryption
		$("#encryptAll").attr("disabled", "disabled");

		if ($('#changePasswordVisible').hasClass('passwordFieldVisible')) {
			$('#changePasswordVisible').toggle("slow");
			$('#changePasswordVisible').removeClass("passwordFieldVisible");
		}
		//$('#changePasswordVisible').hide();
		
		$('#editUser').modal({
			/*detachable : false,*/
			observeChanges : true,
			closable : false
		}).modal('show').modal('refresh');

		$('.popup-button1').popup({
			on: 'hover',
			inline: true
		});
		
		$("#uploadUserImageBtn1").on('change', function() {
			$("#uploadUserImage").val(this.value);
			//Swathi-encrytption 
		    var imgPath =  $("#uploadUserImage").val(this.value);
			   if(imgPath != "" || imgPath != undefined){
				   $("#encryptImage").removeAttr("disabled", "disabled");
				   $("#encryptAll").removeAttr( "disabled", "disabled" );	
				   // code to deselect
				   if ($('.encryptRed:checked').length == $('.encryptRed').length) {
						$("#encryptAll").attr("checked",true);
					} else{
						$("#encryptAll").attr("checked",false);
					}
				} else{		
					$("#encryptImage").attr( "disabled", "disabled" );
					$("#encryptAll").attr("disabled", "disabled");
				}
			//EOC
		});
		$("#editUserEmail").val("");
		getLoggedInUserDetails();
		if(pageName == "homePage"){
			$("#editUserName").val(loggedInUserName);
			$("#editUserFullName").val(loggedInUserFullName);
			$("#editUserEmail").val(loggedInUserEmailId);
			$("#editUserDepartment").val(loggedInUserDepartment);
			if(loggedInUserImageName != null){
				$("#uploadUserImage").val(loggedInUserImageName);
				  $("#encryptImage").removeAttr("disabled", "disabled");
				  $("#encryptAll").removeAttr("disabled", "disabled");// Swathi - REPO-718
			}else{
				$("#uploadUserImage").val("");				
				$("#encryptImage").attr( "disabled", "disabled" );
			}
			//Swathi- Encryption- 27.12.2019
			if(logEncFullname == "1"){
				$("#encryptFullName").attr("checked",true);
			}else{
				$("#encryptFullName").attr("checked",false);
			}
			if(logEncEmail == "1"){
				$("#encryptEmailId").attr("checked",true);
			}else{
				$("#encryptEmailId").attr("checked",false);
			}
			if(logEncDept == "1"){
				$("#encryptDepartment").attr("checked",true);
			}else{
				$("#encryptDepartment").attr("checked",false);
			}
			if(logEncImg == "1"){
				$("#encryptImage").attr("checked",true);
				$("#encryptAll").removeAttr("disabled", "disabled");
			}else{
				$("#encryptImage").attr("checked",false);
			}
			if((logEncEmail == "1") && (logEncDept == "1") && (logEncImg == "1") && (logEncFullname == "1")){
				$("#encryptAll").attr("checked",true);
				$("#encryptAll").removeAttr("disabled", "disabled");
			} else {
				$("#encryptAll").attr("checked",false);
			}
			// EOC
			userId = loggedInUserId;
			if(loggedInUserName != "admin"){
				if(loggedInUserAccessFlag){
					$("#gridUserAssociatedFunctions").attr("style","pointer-events: auto; opacity:1; margin-top: 3em;");
				}else{
					$("#gridUserAssociatedFunctions").attr("style","pointer-events: none; opacity:0.5; margin-top: 3em; display:none;");
				}
			}else{
				$("#gridUserAssociatedFunctions").attr("style","pointer-events: none; opacity:0.5; margin-top: 3em; display:none;");
			}
			
			/*$("#changePassordButton").show();
			$("#changePassordDivider").show();*/
			
			if(loggedInUserldapFlag){
				$("#changePassordDivider").hide();
				$("#changePassordButton").hide();
			}else{
				$("#changePassordDivider").show();
				$("#changePassordButton").show();
			}
		}
		
		
		
		
		$('#editUserOldPassword').val('');
		$('#editUserNewPassword').val('');
		$('#editUserConfirmNewPassword').val('');
		$('#uploadUserImageBtn1').val('');
		appendData = "";
		$.ajax({
			type: "GET",
			url: "/repopro/web/user/getAllUserGroups?userId="+userId,
			dataType: "json",
			async: false,
			cache: false,
			complete:function(data){										
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					$('#gridUserAssociatedFunctions table tbody').html("");
					$.each(json.result, function(i) {
						appendData = getUserAssociatedFunctionsDetails(json.result[i].groupId,json.result[i].groupName,json.result[i].mappedWithUser);
						$('#gridUserAssociatedFunctions table tbody').append(appendData);
					});
					
				}
			}
		});	
		
		if ($('.userFunction:checked').length == $('.userFunction').length ){
			$("#selectAllUserAssociatedFunctions").prop('checked', true);
		}
		else{
			$("#selectAllUserAssociatedFunctions").prop('checked', false); 
		}

		/*// submit edited roles
			$('#submitEditedUsers').on('click',function() {
							var editUserName = loggedInUserName;
							var editUserFullName = $("#editUserFullName").val().trim();
							var editUserEmailId = $("#editUserEmail").val().trim();
							var editUserDepartment = $("#editUserDepartment").val().trim();

							var userImage = $('input[id="uploadUserImageBtn1"]').get(0).files[0];

							var flag = true;

							if (editUserFullName == null || editUserFullName == "") {
								$('#editUserFullName').parent().addClass("error");
								$(".errEditUserFullName").html('Please provide full name').show();
								flag = false;
							} else {
								var regex = /^[a-zA-Z- /./-]*$/;
								if (regex.test(editUserFullName) == false) {
									$('#editUserFullName').parent().addClass("error");
									$(".errEditUserFullName").html("Please use only alphabets, dot and hyphen for full name").show();
									flag = false;
								} else {
									$('#editUserFullName').parent().removeClass("error");
									$(".errEditUserFullName").hide();
								}
							}

							if (editUserEmailId == null || editUserEmailId == "") {
								$('#editUserEmail').parent().addClass("error");
								$(".errEditUserEmail").html('Please provide email id').show();
								flag = false;
							} else {
								 var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
								 if(regex.test(editUserEmailId)){
									 $('#editUserEmail').parent().removeClass("error");
									 $(".errEditUserEmail").hide();
								 }else{
									$('#editUserEmail').parent().addClass("error");
									$(".errEditUserEmail").html(editUserEmailId+' is an invalid email id').show();
									flag = false;
								 }
								

							}

							if (editUserDepartment == null || editUserDepartment == "") {
								$('#editUserDepartment').parent().addClass("error");
								$(".errEditUserDepartment").show();
								flag = false;
							} else {
								 var iChars = "`!%^*=[];{}|<>?~";
								 //alert(" addUserDepartment  "+addUserDepartment.length);
								  for (var i = 0; i < editUserDepartment.length; i++){
								  	if (iChars.indexOf(editUserDepartment.charAt(i)) != -1){
								  		$("#editUserDepartment").parent().addClass("error");
								  		$(".errEditUserDepartment").show();
								  		$(".errEditUserDepartment").html("Special characters except ':'\"+#$/\&(),-_.@' are not allowed");  
								  		flag = false;
								  		deptFlag = false;
								  	}
								  }
								  if(deptFlag){
									  $('#editUserDepartment').parent().removeClass("error");
									  $(".errEditUserDepartment").hide();
								  }

							}

							if ($("#changePasswordVisible").hasClass("passwordFieldVisible")) {
								var editUserOldPassword = $("#editUserOldPassword").val().trim();
								var editUserNewPassword = $("#editUserNewPassword").val().trim();
								var editUserConfirmNewPassword = $("#editUserConfirmNewPassword").val().trim();

								if (editUserOldPassword == null || editUserOldPassword == "") {
									$('#editUserOldPassword').parent().addClass("error");
									$(".errEditUserOldPassword").html('Please provide password').show();
									flag = false;
								} else {
									$('#editUserOldPassword').parent().removeClass("error");
									$(".errEditUserOldPassword").hide();

								}

								if (editUserNewPassword == null || editUserNewPassword == "") {
									$('#editUserNewPassword').parent().addClass("error");
									$(".errEditUserNewPassword").html('Please provide new password').show();
									flag = false;
								} else {
									if(editUserNewPassword.length > 7 && editUserNewPassword.match(/[a-z]/) && editUserNewPassword.match(/[A-Z]/) && editUserNewPassword.match(/\d/) && editUserNewPassword.match(/[!@#$%^&*]/)){
										$('#editUserNewPassword').parent().removeClass("error");
										$(".errEditUserNewPassword").hide();
									}else{
										$('#editUserNewPassword').parent().addClass("error");
										$(".errEditUserNewPassword").html('Password must be <br/> at least 8 characters long,<br/>include one lowercase letter,<br/> include one uppercase letter,<br/> include one number,<br/> include one special character !@#$%^&*').show();
										flag = false;
									}
									

								}

								if (editUserConfirmNewPassword == null || editUserConfirmNewPassword == "") {
									$('#editUserConfirmNewPassword').parent().addClass("error");
									$(".errEditUserConfirmNewPassword").html('Please confirm password').show();
									flag = false;

								} else {
									if (editUserConfirmNewPassword != editUserNewPassword) {
										$('#editUserConfirmNewPassword').parent().addClass("error");
										$(".errEditUserConfirmNewPassword").html('Passwords do not match').show();
										flag = false;
									} else {
										$('#editUserConfirmNewPassword').parent().removeClass("error");
										$(".errEditUserConfirmNewPassword").hide();
									}

								}

							} else {
								var editUserOldPassword = "";
								var editUserNewPassword = "";
							}

							if(typeof userImage == "undefined"){      
								userImage = null;     
							}      
							if (userImage != null) {
						//	if (typeof userImage != "undefined") {
								var uploadImageSize = userImage.size / 1024;
								if (uploadImageSize > 1024) {
									$('#uploadUserImage').parent().parent().addClass("error");
									$(".errEditUserProfilePicture").html('Image size should not exceed 1 MB').show();
									flag = false;
								} else if (userImage.type == "image/jpeg" || userImage.type == "image/png") {
									$('#uploadUserImage').parent().parent().removeClass("error");
									$(".errEditUserProfilePicture").hide();
								} else {
									$('#uploadUserImage').parent().parent().addClass("error");
									$(".errEditUserProfilePicture").html('Please upload image file of type png or jpeg ').show();
									flag = false;
								}

								var formData = new FormData();
								formData.append('userImage', userImage);
							}
							
							
							
							if (flag == false) {
								$('#editUser').modal('show');
								return false;
							} else {
								addedUserFunctionIds1.length = 0;
						    	 $('input[class="userFunction"]').each(function(k) {
						    		 var itm = $(this);
						    		 var data = $(this).attr('id');
						    		 var arr = data.split('_'); 
						    		 if ($(this).is(":checked")) {
						    			 addedUserFunctionIds1.push(arr[1]);
						    		 } 
						    		 
						    	 });
								$.ajax({
										type : "PUT",
										url : "/repopro/web/user/updateUser/?userName="+ loggedInUserName+"&uName="+ editUserName+ "&newPassword="+ encodeURIComponent(editUserNewPassword) +"&fullName="+ editUserFullName+ "&emailId="+ editUserEmailId +"&department="+ encodeURIComponent(editUserDepartment) +"&userId="+ userId +"&oldPassword="+ encodeURIComponent(editUserOldPassword)+ "&addedGroupIds="+ addedUserFunctionIds1,
 											contentType : "application/json",
											dataType : "json",
											data : formData,
											async : false,
											processData : false,
											contentType : false,
											cache: false,
											complete : function(data) {
												appenddata = "";
												var json = JSON.parse(data.responseText);
												if (json.status == "SUCCESS") {
													$('#fullName_' + userId).html(editUserFullName);
													$('#email_' + userId).html(editUserEmailId);
													$('#dept_' + userId).html(editUserDepartment);
													$("#loggedinUserFullnameInCard").html(editUserFullName);
													notifyMessage("Update Profile","Profile updated","success");
													 if($('input[name="uploadUserImageBtn"]').get(0).files[0]){
															var reader = new FileReader();
															
														    reader.onload = function(e) {
														      $('#loggedInUserImage').attr('src', e.target.result);
														    }
						
								   							 reader.readAsDataURL($('input[name="uploadUserImageBtn"]').get(0).files[0]);
													} 
													getLoggedInUserDetails();
													//loadHomePage();	
													    
												} else {
													if (json.message == 'Password or userName entered is invalid,Cannot update user password data') {
														$('#editUserOldPassword').parent().addClass("error");
														$(".errEditUserOldPassword").html('Password entered for the User Name "'+ loggedInUserName + '" is invalid').show();
														flag = false;
													} else {
														$('#editUserOldPassword').parent().removeClass("error");
														$(".errEditUserOldPassword").hide();
														notifyMessage("Update Profile",json.message,"fail");
													}

												}
											}
										});

							}
							if (flag == false) {
								$('#editUser').modal('show');
								return false;
							} else {
								$('#editUser').modal('hide'); //.modal('hide dimmer');
								$('#editUser').parent().css("display", "none !important");
							}

						});*/

	}
	//get Associated Functions Details for user
	function getUserAssociatedFunctionsDetails(groupId, groupName,chkboxMappedWithUser) {
		appendData = "";
		if(groupName != "Guest"){
		appendData += "<tr>";
		appendData += "<td class='hidden' id='functionId_"+groupId+"'>"+ groupId + "</td>";
		if (chkboxMappedWithUser == true) {
			appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllUser(this)' type='checkbox' id='userAssociatedFunctionName_"+ groupId+"' class='userFunction' checked><label>"+groupName+"</label></div></td>";
		} else {
			appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllUser(this)' type='checkbox'  id='userAssociatedFunctionName_"+ groupId+"' class='userFunction'><label>"+ groupName+"</label></div></td>";
		}
		appendData += "</tr>";
		}
		return appendData;
	}
	//check uncheck All Functions for user 
	function selectAllFunction_Role() {
		if (selectAllUserAssociatedFunctions.checked) {
			$('.userFunction').prop('checked', true);
		} else {
			$('.userFunction').prop('checked', false);
		}
	}

	//check select all when all check box are checked
	function checkSelectAllUser(obj) {
		if (false == $(obj).prop('checked')) {
			$("#selectAllUserAssociatedFunctions").prop('checked', false);
		}
		if ($('.userFunction:checked').length == $('.userFunction').length) {
			$("#selectAllUserAssociatedFunctions").prop('checked', true);
		}
	}


	
	// Hema 28.Aug.2018
	
	function validateForm(){
		var editUserName = loggedInUserName;
		var editUserFullName = $("#editUserFullName").val();
		var editUserEmailId = $("#editUserEmail").val().trim();
		var editUserDepartment = $("#editUserDepartment").val().trim();

		var userImage = $('input[id="uploadUserImageBtn1"]').get(0).files[0];

		var flag = true;

		if (editUserFullName == null || editUserFullName == "") {
			$('#editUserFullName').parent().addClass("error");
			$(".errEditUserFullName").html('Please provide full name').show();
			flag = false;
		} else {
			var regex = /^[a-zA-Z- /./-]*$/;
			if (regex.test(editUserFullName) == false) {
				$('#editUserFullName').parent().addClass("error");
				$(".errEditUserFullName").html("Please use only alphabets, dot and hyphen for full name").show();
				flag = false;
			} else {
				$('#editUserFullName').parent().removeClass("error");
				$(".errEditUserFullName").hide();
			}
		}

		if (editUserEmailId == null || editUserEmailId == "") {
			$('#editUserEmail').parent().addClass("error");
			$(".errEditUserEmail").html('Please provide email Id').show();
			flag = false;
		} else {
			var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			if(regex.test(editUserEmailId)){
				$('#editUserEmail').parent().removeClass("error");
				$(".errEditUserEmail").hide();
			}else{
				$('#editUserEmail').parent().addClass("error");
				$(".errEditUserEmail").html('Please enter valid email Id').show();
				flag = false;
			}


		}

		if (editUserDepartment == null || editUserDepartment == "") {
			$('#editUserDepartment').parent().addClass("error");
			$(".errEditUserDepartment").show();
			flag = false;
		} else {
			var iChars = "`!%^*=[];{}|<>?~";
			//alert(" addUserDepartment  "+addUserDepartment.length);
			for (var i = 0; i < editUserDepartment.length; i++){
				if (iChars.indexOf(editUserDepartment.charAt(i)) != -1){
					$("#editUserDepartment").parent().addClass("error");
					$(".errEditUserDepartment").show();
					$(".errEditUserDepartment").html("Special characters except ':'\"+#$/\&(),-_.@' are not allowed");  
					flag = false;
					deptFlag = false;
				}
			}
			if(deptFlag){
				$('#editUserDepartment').parent().removeClass("error");
				$(".errEditUserDepartment").hide();
			}

		}

		if ($("#changePasswordVisible").hasClass("passwordFieldVisible")) {
			
			var editUserOldPassword = $("#editUserOldPassword").val().trim();
			var editUserNewPassword = $("#editUserNewPassword").val().trim();
			var editUserConfirmNewPassword = $("#editUserConfirmNewPassword").val().trim();

			if (editUserOldPassword == null || editUserOldPassword == "") {
				$('#editUserOldPassword').parent().addClass("error");
				$(".errEditUserOldPassword").html('Please provide password').show();
				flag = false;
			} else {
				$('#editUserOldPassword').parent().removeClass("error");
				$(".errEditUserOldPassword").hide();

			}

			
			if (editUserNewPassword == null || editUserNewPassword == "") {
				$('#editUserNewPassword').parent().addClass("error");
				$(".errEditUserNewPassword").html('Please provide new password').show();
				flag = false;
			} else {
				if(editUserNewPassword.length > 7 && editUserNewPassword.match(/[a-z]/) && editUserNewPassword.match(/[A-Z]/) && editUserNewPassword.match(/\d/) && editUserNewPassword.match(/[!@#$%^&*]/)){
					$('#editUserNewPassword').parent().removeClass("error");
					$(".errEditUserNewPassword").hide();
				}else{
					$('#editUserNewPassword').parent().addClass("error");
					$(".errEditUserNewPassword").html('Password must be <br/> at least 8 characters long,<br/>include one lowercase letter,<br/> include one uppercase letter,<br/> include one number,<br/> include one special character').show();
					flag = false;
				}
				

			}

			if (editUserConfirmNewPassword == null || editUserConfirmNewPassword == "") {
				$('#editUserConfirmNewPassword').parent().addClass("error");
				$(".errEditUserConfirmNewPassword").html('Please confirm password').show();
				flag = false;

			} else {
				if (editUserConfirmNewPassword != editUserNewPassword) {
					$('#editUserConfirmNewPassword').parent().addClass("error");
					$(".errEditUserConfirmNewPassword").html('Passwords do not match').show();
					flag = false;
				} else {
					$('#editUserConfirmNewPassword').parent().removeClass("error");
					$(".errEditUserConfirmNewPassword").hide();
				}

			}
			console.log("  editUserNewPassword "+editUserNewPassword+" editUserConfirmNewPassword  "+editUserConfirmNewPassword+"  editUserOldPassword "+editUserOldPassword);
		} else {
			var editUserOldPassword = "";
			var editUserNewPassword = "";
		}

		if(typeof userImage == "undefined"){      
			userImage = null;     
		}      
		if (userImage != null) {
			//	if (typeof userImage != "undefined") {
			var uploadImageSize = userImage.size / 1024;
			if (uploadImageSize > 1024) {
				$('#uploadUserImage').parent().parent().addClass("error");
				$(".errEditUserProfilePicture").html('Image size should not exceed 1 MB').show();
				flag = false;
			} else if (userImage.type == "image/jpeg" || userImage.type == "image/png") {
				$('#uploadUserImage').parent().parent().removeClass("error");
				$(".errEditUserProfilePicture").hide();
			} else {
				$('#uploadUserImage').parent().parent().addClass("error");
				$(".errEditUserProfilePicture").html('Please upload image file of type png or jpeg ').show();
				flag = false;
			}

			var formData = new FormData();
			formData.append('userImage', userImage);
		}



		if (flag == false) {
			$('#editUser').modal('show');
			return false;
		} else {

			$('#submitEditedGrpDataProfile').click();
			return true;

		}

	}
	
	function saveGrpDetails(){
		addedUserFunctionIds1.length = 0;
   	 $('input[class="userFunction"]').each(function(k) {
   		 var itm = $(this);
   		 var data = $(this).attr('id');
   		 var arr = data.split('_'); 
   		 if ($(this).is(":checked")) {
   			 addedUserFunctionIds1.push(arr[1]);
   		 } 
   		 
   	 });
   	 
   	var editUserName = loggedInUserName;
	var editUserFullName = $("#editUserFullName").val().trim();
	var editUserEmailId = $("#editUserEmail").val().trim();
	var editUserDepartment = $("#editUserDepartment").val().trim();

	var userImage = $('input[id="uploadUserImageBtn1"]').get(0).files[0];
	
	var editUserOldPassword = $("#editUserOldPassword").val().trim();
	var editUserNewPassword = $("#editUserNewPassword").val().trim();
	//SOC- Swathi- Encrpytion checkbox value on click of Update- 23.12.2019
	var encryptUserFullName=0 ;
	var encryptUserEmailId=0;
	var encryptUserDept=0;
	var encryptImg=0;
	 if($('#encryptFullName').prop("checked") == true) {	
		encryptUserFullName="1";
	} else {
		encryptUserFullName="0";
	}
	if($("#encryptEmailId").prop("checked") == true){
		encryptUserEmailId="1";
	} else {
		encryptUserEmailId="0";
	}
	if($("#encryptDepartment").prop("checked") == true){
		encryptUserDept="1";
	} else {
		encryptUserDept="0";
	}
	if($("#encryptImage").prop("checked") == true){
		encryptImg="1";
	} else {
		encryptImg="0";
	}
	//EOC - Swathi- Encryption
	var manageEditedUserObj = {
			"userName" : loggedInUserName,
			"uName": editUserName,
			"fullName": editUserFullName,
			"emailId": editUserEmailId,
			"department": encodeURIComponent(editUserDepartment),
			"oldPassword": encodeURIComponent(editUserOldPassword),
			"newPassword":encodeURIComponent(editUserNewPassword),
			"editedUserId": loggedInUserId,
			"addedUserFunctionIds1": addedUserFunctionIds1.toString(),
			"encryptFullName":encryptUserFullName,//Encrption checkbox values
			"encryptEmailId":encryptUserEmailId,
			"encryptDepartment":encryptUserDept,
			"encryptImage":encryptImg
			
	};
	
	//console.log("addedUserFunctionIds1 : " + addedUserFunctionIds1 + " string : "+ addedUserFunctionIds1.toString());
	
 $('#hiddenInput_EditProfile').val(JSON.stringify(manageEditedUserObj));
	}
	

/*$('#editUserNewPassword').keypress(function(event){
		
       if(event.keyCode == 13){
    	   validateForm();
        }
     });

$('#editUserConfirmNewPassword').keypress(function(event){
		
       if(event.keyCode == 13){
    	  // validateForm();
   	       var setPasswordFlag = true;	
    	   var editUserNewPassword = $("#editUserNewPassword").val().trim();
    	   var editUserOldPassword = $("#editUserOldPassword").val().trim();
		   var editUserConfirmNewPassword = $("#editUserConfirmNewPassword").val().trim();
    	  // console.log(' editUserNewPassword  '+editUserNewPassword+'  editUserOldPassword '+editUserOldPassword+' editUserConfirmNewPassword '+editUserConfirmNewPassword);
		   if (editUserNewPassword == null || editUserNewPassword == "") {
				$('#editUserNewPassword').parent().addClass("error");
				$(".errEditUserNewPassword").html('Please provide new password').show();
				setPasswordFlag = false;
			} else {
				if(editUserNewPassword.length > 7 && editUserNewPassword.match(/[a-z]/) && editUserNewPassword.match(/[A-Z]/) && editUserNewPassword.match(/\d/) && editUserNewPassword.match(/[!@#$%^&*]/)){
					$('#editUserNewPassword').parent().removeClass("error");
					$(".errEditUserNewPassword").hide();
				}else{
					$('#editUserNewPassword').parent().addClass("error");
					$(".errEditUserNewPassword").html('Password must be <br/> at least 8 characters long,<br/>include one lowercase letter,<br/> include one uppercase letter,<br/> include one number,<br/> include one special character !@#$%^&*').show();
					setPasswordFlag = false;
				}
			}
		   
		   
		   
		   if (editUserConfirmNewPassword == null || editUserConfirmNewPassword == "") {
    			$('#editUserConfirmNewPassword').parent().addClass("error");
    			$(".errEditUserConfirmNewPassword").html('Please confirm password').show();
    			setPasswordFlag = false;

    		} else {
    			if (editUserConfirmNewPassword != editUserNewPassword) {
    				$('#editUserConfirmNewPassword').parent().addClass("error");
    				$(".errEditUserConfirmNewPassword").html('Passwords do not match').show();
    				setPasswordFlag = false;
    			} else {
    				$('#editUserConfirmNewPassword').parent().removeClass("error");
    				$(".errEditUserConfirmNewPassword").hide();
    			}

    		}
    	   
    	   if (setPasswordFlag == false) {
	   			$('#editUser').modal('show');
	   			return false;
	   		} else {
	   			$('#submitEditedGrpDataProfile').click();
	   			return true;
	
	   		}
        }
     });
*/
	
// BOC - Swathi- Encryption- Encrypt all option - 24.12.2019
$("#encryptAll").click(function(){
	if($("#encryptAll").prop("checked")== true){
		$(".encryptRed").not(':disabled').attr("checked",true);
	} else {
		$(".encryptRed").attr("checked",false);
	}
	
});

$(".encryptRed").click(function(){
	if($(".encryptRed").prop("checked")== false){
		$("#encryptAll").attr("checked",false);
	}
	if ($('.encryptRed:checked').length == $('.encryptRed').length) {
		$("#encryptAll").attr("checked",true);
	} else{
		$("#encryptAll").attr("checked",false);
	}
})
//EOC- Swathi
	
	
	
	
	
	
	
	