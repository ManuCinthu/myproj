function checkForNoAssets(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetType/getAllAssetNames?userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null || json.result == "[]"){
					$('#exportTab').hide();
				}else{
					 $('#exportTab').show();
				}
			} 
		}
	});
}	

// import tab click
$('#importTab').on('click',function(){
		$.tab('change tab', 'first');
		$('.menu .item').removeClass('active tabsActiveColor');
		$(this).addClass('active tabsActiveColor');
	})
	

//import excel file and get the name of the file
function importExcelFile(){
	document.getElementById("importExcelFileBtn").onchange = function () {
	    document.getElementById("importExcelFileName").value = this.value;
	};
}
function importExcelFileFunction(){
	$("#importExcelFileFunction").unbind();
	$('#importExcelFileName').parent().parent().removeClass("error");
	$(".errImportDiv").hide();
	//alert("import");
	var importFile = $('input[id="importExcelFileBtn"]').get(0).files[0];
	var flag = true;
	
		if(importFile == undefined){
			$('#importExcelFileName').parent().parent().addClass("error");
			$(".errImportDiv").html('Please upload the file to import.').show();
			flag = false;
		}
		else {
			$('#importExcelFileName').parent().parent().removeClass("error");
			$(".errImportDiv").hide();
		}
		
		if (typeof importFile != "undefined") {
			var ext = (importFile.name).split('.').pop().toLowerCase();
			
			var importFileSize = importFile.size / 1024;
			if($.inArray(ext, ['xlsx','zip']) > -1){
				$('#importExcelFileName').parent().parent().removeClass("error");
				$(".errImportDiv").hide();
			}else{
				$('#importExcelFileName').parent().parent().addClass("error");
				$(".errImportDiv").html('Please upload file type of ".zip" or ".xlsx"').show();
				flag = false;
			}

		}
		if(flag == false){
			return false;
		}else{
			var fullImport = false;
			var incrementalUpdate = false;
			var incrementalInsert = false;
			var callModal = false;
			var radValStatic = "";
			var url = "";

			
			
			if($('#fullImport').is(':checked')){
				fullImport = true;
				callModal = true;
			}

			if($('#incrementalUpdate').is(':checked')){
				incrementalUpdate = true;
				callModal = true;
			}
			if($('#incrementalInsert').is(':checked')){
				incrementalInsert = true;
				callModal = false;
			}
			
			if(callModal == false){
				url = "/repopro/web/import/importExcelSheet?userName=admin&radioVal=incInsert";
				$("#importExcelFileFunction").addClass("disabled");
				$("#importStartedMessage").show();
				importUploadedFile(url);
			}else{
				var openModal = false;
				
				$.ajax({
					type : "GET",
					url : "/repopro/web/globalsettings",
					dataType : "json",
					async: false,
					complete : function(data) {
						
						var json = JSON.parse(data.responseText);
						if(json.result[0].globalLockSettingFlag == 1){
							openModal = true;
						}
					}
				});
				if(openModal){
					$("#importInstLockModal123").modal("destroy");
					$("#submitLockOkBtn").unbind();
					
					$.ajax({
						type : "GET",
						url : "/repopro/web/import/lockingUsers",
						dataType : "json",
						async: false,
						complete : function(data) {
							var json = JSON.parse(data.responseText);
							$("#printDataForLock").html(json.result[0]);
						}
					});
					
					$("#importInstLockModal").modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
					
					
					$("#submitLockOkBtn").on("click",function(i){
						//$("#importExcelFileName").val('');
						var radValStatic = "";
						if($('#skipLocked').is(':checked')){
							radValStatic = "new";
						}else{
							radValStatic = "exist";
						}
						//alert(radValStatic);
						if(fullImport){
							url = "/repopro/web/import/importExcelSheet?userName=admin&radioVal=usual&radValStatic="+radValStatic;
							
						}else if(incrementalUpdate){
							//alert("radValStatic ::" +radValStatic);
							url = "/repopro/web/import/importExcelSheet?userName=admin&radioVal=incUpdate&radValStatic="+radValStatic;
							
						}
						$("#importInstLockModal").modal("hide");
						
						setTimeout(function(){ 
							$("#importExcelFileFunction").addClass("disabled");
							$("#importStartedMessage").show();
							importUploadedFile(url);
						}, 100);
							
						
						
						
					});
					
				}else{
					if(fullImport){
						url = "/repopro/web/import/importExcelSheet?userName=admin&radioVal=usual";
						
					}else if(incrementalUpdate){
						url = "/repopro/web/import/importExcelSheet?userName=admin&radioVal=incUpdate";
						
					}
					$("#importExcelFileFunction").addClass("disabled");
					$("#importStartedMessage").show();
					importUploadedFile(url);
					
				}
				
				
			}
			
			
		}
		
		
}

// import uploadedData
function importUploadedFile(url){
	var importFile = $('input[id="importExcelFileBtn"]').get(0).files[0];
	var formData = new FormData();
	formData.append('importdata', importFile);
	
	
	
	$.ajax({
		type: "POST",
		url: url,
		contentType : "application/json",
		dataType : "json",
		data : formData,
		async: true,
		processData: false,
		contentType: false,
		complete:function(data){	
			appenddata = "";
			var json = JSON.parse(data.responseText);
			console.log(JSON.stringify(json.result))
			if(json.status == "SUCCESS"){
				$("#importExcelFileFunction").removeClass("disabled");
				$("#importStartedMessage").hide();
				//notifyMessage("Import",json.message,"success");
			}
			else {
				$("#importExcelFileFunction").removeClass("disabled");
				$("#importStartedMessage").hide();
				//notifyMessage("Import",json.message,"fail");
			}
		}

	});
	
	
}

$('#exportTab').on('click',function(){
	$.tab('change tab', 'second');
	$('.menu .item').removeClass('active tabsActiveColor');
	$(this).addClass('active tabsActiveColor');
	loadAllActiveUsers();
	exportTabDownloadStatusFlagCheck();
});

//load all active users in dropdown 
function loadAllActiveUsers(){
	var getActiveUser = [];
	$.ajax({
		type : 'GET',
		url : '/repopro/web/user/getAllActiveUsers',
		dataType : 'json',
		async : false,
		complete : function(data) {
		var json = JSON.parse(data.responseText);
		getActiveUser.length = 0;
		if (json.status == "SUCCESS") {
			$.each(json.result, function(i) {
				getActiveUser.push({"userId" : json.result[i].userId,"userName" : json.result[i].userName});
		});		
		
		} else {
				
		}
		
		var appendActiveUsersOptions = '';
		$('#ddloadAllActiveUsers').html("");
		for (var h = 0; h < getActiveUser.length; h++) {
			appendActiveUsersOptions += '<option value="'+ getActiveUser[h].userId + '">' + getActiveUser[h].userName + '</option>';
		}
		
		$('#ddloadAllActiveUsers').prepend('<option value="">Select Users</option>');
		$('#ddloadAllActiveUsers').append(appendActiveUsersOptions);
		
			}
	});
}

//Export To Excel
function exportTabDownloadStatusFlagCheck(){
		$.ajax({
		type : "GET",
		url: "/repopro/web/export/exportTab/"+loggedInUserName,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			console.log("json12345 : "  + JSON.stringify(json));
			if(json.status == "SUCCESS"){
				if(json.result == 0){
					//$('#exportLoader').removeClass('active');
					$('#fullExport').attr('disabled',false);
					$('#fullExportLinkClick').hide();
					$('#downloadLink').hide();
				}
				else if(json.result == 1){
					//$('#exportLoader').addClass('active');
					$('#fullExport').attr('disabled',true);
					$('#fullExportLinkClick').show();
					$('#downloadLink').hide();
				}
				else {
					$('#fullExport').attr('disabled',false);
					$('#fullExportLinkClick').hide();
					$('#downloadLink').show();
					/*$('#fullExportLinkClick').text("Download Now!!");*/
					
					$('#downloadLink').on('click',function(){
						window.location.href = '/repopro/web/export/downloadFile';
					})
					
				}
			}
		}
	});
}

$('#fullExport').on('click',function(){
	exportToExcel();
});

function exportToExcel(){
	var con = confirm("Please confirm to start the export");
	if(con == true){
		$.ajax({
			type : "GET",
			url: "/repopro/web/export/exportInExcel/"+loggedInUserName,
			dataType : "json",
			async: true,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				$('#fullExport').attr('disabled',true);
				$('#fullExportLinkClick').show();
				$('#downloadLink').hide();
				
				/*$('#exportTab').click();
					$.tab('change tab', 'second');
					$('.menu .item').removeClass('active tabsActiveColor');
					$(this).addClass('active tabsActiveColor');*/
			}
				
		});
	}else return false
	//$('#fullExport').attr('href','/repopro/web/export/exportInExcel/'+loggedInUserName);
}


//check For Import Status
function checkForImportStatus(){
	$.ajax({
		type : "GET",
		url: "/repopro/web/import/uploadProgress",
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.result[0] == 0){
				$("#importStartedMessage").hide();
				$("#importExcelFileFunction").removeClass("disabled");
				
			}else{
				$("#importStartedMessage").show();
				$("#importExcelFileFunction").addClass("disabled");
				
			}
			
		}
	});
}
