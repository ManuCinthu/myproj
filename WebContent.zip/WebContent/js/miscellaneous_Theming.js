	// load font and frame colors 
	var fontColor = "";
	var frameColor = "";
	var fontColorFlag = true;
	var frameColorFlag = true;
	//var logoImgformData = "";
	var backgroundformData = "";
	var headerFormData = "";
	var faviconFormData = "";
	
	
	 var getThemeColor = '';
	 var getHeadingColor = '';
	 var getPrimaryButtonColor = '';
	 var getSecondaryButtonColor = '';
	 var getPrimaryTextColor = '';
	 var getSecondaryTextColor = '';
	 var getLogoImage = "";
	 var getFaviconLogo = "";
	 var getLoginPageLogo  = "";
	 var getBackgroundImage = "";
	 
	 var appendData ='';
	
	
	
	
	//get all color and image details  - chandana - 17.06.2020
	function loadThemeDetails(){
		$.ajax({
			type : "GET",    
			url : "/repopro/web/customimagesmanager/getallThemeConfiguration",
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				//console.log("json : " + JSON.stringify(json));
				if(json.result[0] != null){

				       getThemeColor = json.result[0].themecolor;
					   getHeadingColor = json.result[0].headingcolor;
					   getPrimaryButtonColor = json.result[0].primary_Buttoncolor;
					   getSecondaryButtonColor = json.result[0].secondary_Buttoncolor;
					   getPrimaryTextColor = json.result[0].primary_Button_text_color;
					   getSecondaryTextColor = json.result[0].secondary_Button_text_color;
					   getLogoImage = json.result[0].logo_filename;
					   getFaviconLogo = json.result[0].favicon_filename;
					   getLoginPageLogo  = json.result[0].loginPageLogo_filename;
					   getBackgroundImage = json.result[0].backgroundimg_filename;
					 
 
					   $('#headerLogoImageFileName').val(getLogoImage);
					   $('#faviconLogoImageFileName').val(getFaviconLogo);
					   $('#LoginlogoImageFileName').val(getLoginPageLogo);
					   $('#backgroundImageFile').val(getBackgroundImage);
					   
					   
					   if(getLogoImage == null || getLogoImage == "null" || getLogoImage == "" ){
                       }
                       else{
					 //header logo image
					   var getLogoType = '';
					   getLogoType =  getLogoImage.substr( (getLogoImage.lastIndexOf('.') +1) );
					   
					   if (getLogoType == 'PNG' || getLogoType == 'JPEG' || getLogoType == 'JPG'){
						   getLogoType = getLogoType.toLowerCase()
						}
					   
					   	var changeHeaderLogo = '/repopro/semantic/images/login_Imgs/logoimage.'+getLogoType+'';
						$('#logoImg').attr('src','')
						$('#logoImg').attr('src',changeHeaderLogo)
						
						 $('#logoImg').error(function() {
							    $('#logoImg').attr('src','')
								$('#logoImg').attr('src','/repopro/semantic/images/white_Logo.png');
							});
                       }
						
					   if(getFaviconLogo == null || getFaviconLogo == "null" || getFaviconLogo == "" ){
                       }
                       else{
						//favicon image
						   var getFaviconType = '';
						   getFaviconType =  getFaviconLogo.substr( (getFaviconLogo.lastIndexOf('.') +1) );
						   
						   if (getFaviconType == 'PNG' || getFaviconType == 'JPEG' || getFaviconType == 'JPG'){
							   getFaviconType = getLogoType.toLowerCase()
							}
						   
						   	var changeFaviconLogo = '/repopro/semantic/images/login_Imgs/themefavicon.'+getFaviconType+'';
							//$('#favicon').attr('href','')
						//	$('#favicon').attr('href',changeFaviconLogo)
						   $("#favicon").attr('href','/repopro/semantic/images/login_Imgs/themefavicon.'+getFaviconType+'');
						   
						   
							$('#favicon').error(function() {
									$("#favicon").attr('href','/repopro/semantic/images/client_favicon.png');
								});
                       }
						   
						  
					  
						
						
					$('#themeColor').parent().find('#colorUL li').each(function(){
						var color1 = $(this).attr('name');
						var color2 = $(this).attr('class');
						
						if(color2 = 'active'){
							$(this).removeClass('active');
						}
						if(color1 == getThemeColor){
							$(this).addClass('active')
						}
						
						if(getThemeColor == "#e74a46" || getThemeColor == "#0e76a8" || getThemeColor == "#6bd7ed" || getThemeColor == "#d400ff" || getThemeColor == "#000000" || getThemeColor == "#4b0606"){
							 }
						 else{
								$('#themeColor').parent().find('#colorUL li.customColorFromPicker').show().addClass('active').attr({style:"background-color: '' !important;", name :'' , title:''});

								$('#themeColor').parent().find('#colorUL li.customColorFromPicker').show().addClass('active').attr({style:"background-color: "+getThemeColor+" !important;", name : getThemeColor , title:getThemeColor});

							}
						
					 
				 });
					
					
					$('#headingColor').parent().find('#colorUL li').each(function(){
						var colorH1 = $(this).attr('name');
						var colorH2 = $(this).attr('class');
						if(colorH2 = 'active'){
							$(this).removeClass('active');
						}
						if(colorH1 == getHeadingColor){
							$(this).addClass('active');
						}
					
						 if(getHeadingColor == "#e74a46" || getHeadingColor == "#0e76a8" || getHeadingColor == "#6bd7ed" || getHeadingColor == "#d400ff" || getHeadingColor == "#000000" || getHeadingColor == "#4b0606"){
							 }
						 else{
								$('#headingColor').parent().find('#colorUL li.customColorFromPicker').show().addClass('active').attr({style:"background-color: "+getHeadingColor+" !important;", name : getHeadingColor , title:getHeadingColor});

							}
					});
					
					
					
					$('#primaryButton').parent().find('#colorUL li').each(function(){
						var colorP1 = $(this).attr('name');
						var colorP2 = $(this).attr('class');
						
						if(colorP2 = 'active'){
							$(this).removeClass('active');
						}
						if(colorP1 == getPrimaryButtonColor){
							$(this).addClass('active')
						}
						if(getPrimaryButtonColor == "#e74a46" || getPrimaryButtonColor == "#0e76a8" || getPrimaryButtonColor == "#6bd7ed" || getPrimaryButtonColor == "#d400ff" || getPrimaryButtonColor == "#000000" || getPrimaryButtonColor == "#4b0606"){
						 }
					 else{
							$('#primaryButton').parent().find('#colorUL li.customColorFromPicker').show().addClass('active').attr({style:"background-color: "+getPrimaryButtonColor+" !important;", name : getPrimaryButtonColor , title:getPrimaryButtonColor});

						}
					});
					$('#secondaryButton').parent().find('#colorUL li').each(function(){
						var colorS1 = $(this).attr('name');
						var colorS2 = $(this).attr('class');
						
						if(colorS2 = 'active'){
							$(this).removeClass('active');
						}
						if(colorS1 == getSecondaryButtonColor){
							$(this).addClass('active')
						}
						if(getSecondaryButtonColor == "#e0e1e2" || getSecondaryButtonColor == "#0e76a8" || getSecondaryButtonColor == "#6bd7ed" || getSecondaryButtonColor == "#d400ff" || getSecondaryButtonColor == "#000000" || getSecondaryButtonColor == "#4b0606"){
						 }
					 else{
							$('#secondaryButton').parent().find('#colorUL li.customColorFromPicker').show().addClass('active').attr({style:"background-color: "+getSecondaryButtonColor+" !important;", name : getSecondaryButtonColor , title:getSecondaryButtonColor});

						}
					});
					
					$('#primaryText').parent().find('#colorUL li').each(function(){
						var colorPT1 = $(this).attr('name');
						var colorPT2 = $(this).attr('class');
						
						if(colorPT2 = 'active'){
							$(this).removeClass('active');
						}
						if(colorPT1 == getPrimaryTextColor){
							$(this).addClass('active')
						}
						if(getPrimaryTextColor == "#ffffff" || getPrimaryTextColor == "#0e76a8" || getPrimaryTextColor == "#6bd7ed" || getPrimaryTextColor == "#d400ff" || getPrimaryTextColor == "#000000" || getPrimaryTextColor == "#4b0606"){
						 }
					 else{
							$('#primaryText').parent().find('#colorUL li.customColorFromPicker').show().addClass('active').attr({style:"background-color: "+getPrimaryTextColor+" !important;", name : getPrimaryTextColor , title:getPrimaryTextColor});

						}
					
					});
					$('#secondaryText').parent().find('#colorUL li').each(function(){
						var colorST1 = $(this).attr('name');
						var colorST2 = $(this).attr('class');
						
						if(colorST2 = 'active'){
							$(this).removeClass('active');
						}
						if(colorST1 == getSecondaryTextColor){
							$(this).addClass('active')
						}
						if(getSecondaryTextColor == "#ffffff" || getSecondaryTextColor == "#0e76a8" || getSecondaryTextColor == "#6bd7ed" || getSecondaryTextColor == "#d400ff" || getSecondaryTextColor == "#000000" || getSecondaryTextColor == "#4b0606"){
						 }
					 else{
							$('#secondaryText').parent().find('#colorUL li.customColorFromPicker').show().addClass('active').attr({style:"background-color: "+getSecondaryTextColor+" !important;", name : getSecondaryTextColor , title:getSecondaryTextColor});

						}
						
					});
					
				
				}
				
				$('#showHideLoader').removeClass('active');
			}
		});
		
	}
	
	
	var changeLogoFlag = false;
	var changeFeviconFlag = false;
	var changeLoginLogoFlag = false;
	var changeBGFlag = false;
	var upLogoFileonEdit, upFeviconOnEdit, upLoginLogoOnEdit, upBgOnEdit='';
	// Upload header logo Image file
	$('#headerLogoImageFileNameFor').on('change',function(){
		changeLogoFlag = true;
		$('#headerLogoImageFileName').attr('name','logoimage');
		document.getElementById("headerLogoImageFileName").value = this.value;
	})
	
	// Upload favicon logo Image file
	$('#faviconLogoImageFileNameFor').on('change',function(){
		changeFeviconFlag = true;
		 $('#faviconLogoImageFileName').attr('name','faviconimage');
		document.getElementById("faviconLogoImageFileName").value = this.value; 
	})
	
		
	// Upload Logo Image Filename
	$('#logoImageFileNameForLoginPage').on('change',function(){
		changeLoginLogoFlag = true;
		 $('#LoginlogoImageFileName').attr('name','loginPageLogo');
		document.getElementById("LoginlogoImageFileName").value = this.value;
	})
	
	// Upload Background Image file
	$('#backgroundImageFileFor').on('change',function(){
		changeBGFlag = true;
		 $('#backgroundImageFile').attr('name','backgroundimage');
		document.getElementById("backgroundImageFile").value = this.value;
	})



	 
	 
	 
	 //Save theme details  - chandana 10.06.2020
	 
	 function SaveThemingDetails(){
		 
		 var flag = true;
		 var formData = new FormData();
		 
		 getThemeColor 			     = $('#themeColor').parent().find('ul li.active').attr('name');
		 getHeadingColor 			 = $('#headingColor').parent().find('ul li.active').attr('name');
		 getPrimaryButtonColor 		 = $('#primaryButton').parent().find('ul li.active').attr('name');
		 getSecondaryButtonColor	 = $('#secondaryButton').parent().find('ul li.active').attr('name');
		 getPrimaryTextColor         = $('#primaryText').parent().find('ul li.active').attr('name');
		 getSecondaryTextColor  	 = $('#secondaryText').parent().find('ul li.active').attr('name');
		
		 var saveLogoImage = '';
		 var saveFaviconLogo = '';
		 var saveLoginPageLogo = '';
		 var saveBackgroundImage = '';
		// alert('Save theme Details' + getThemeColor + getHeadingColor + getPrimaryButtonColor + getSecondaryButtonColor +getPrimaryTextColor + getSecondaryTextColor );
		 
		 	
		    formData.append("themecolor",getThemeColor);
			formData.append("headingcolor",getHeadingColor);
			formData.append("Primary_Buttoncolor",getPrimaryButtonColor);
			formData.append("Secondary_Buttoncolor",getSecondaryButtonColor);
			formData.append("Primary_Button_text_color",getPrimaryTextColor);
			formData.append("Secondary_Button_text_color",getSecondaryTextColor);
			
		
			if(changeLogoFlag != true && getLogoImage != '' ){
				formData.append('logoimage', getLogoImage);
			}
			else{
				saveLogoImage = $('input[id="headerLogoImageFileNameFor"').get(0).files[0];
				formData.append('logoimage', saveLogoImage);
				
				//Validation of header logo image file
				if (typeof saveLogoImage != "undefined") {
					var uploadImageSize = saveLogoImage.size / 1024;
					if (uploadImageSize > 1024) {
						$('#headerLogoImageFileName').parent().parent().addClass("error");
						$(".headerLogoImgFileErr").html('Image size should not exceed 1 MB').show();
						flag = false;
					} else if(saveLogoImage == "" || saveLogoImage == null){
						$('#headerLogoImageFileName').parent().parent().addClass("error");
						$(".headerLogoImgFileErr").html('Please upload a file').show();
						flag = false;
					}
					else if (saveLogoImage.type == "image/jpeg" || saveLogoImage.type == "image/png") {
						$('#headerLogoImageFileName').parent().parent().removeClass("error");
						$(".headerLogoImgFileErr").hide();
					} else {
						$('#headerLogoImageFileName').parent().parent().addClass("error");
						$(".headerLogoImgFileErr").html('Please upload image file of type png or jpeg ').show();
						flag = false;
					}

				}
				 else if(saveLogoImage == "" || saveLogoImage == null){
					$('#headerLogoImageFileName').parent().parent().addClass("error");
					$(".headerLogoImgFileErr").html('Please upload a file').show();
					flag = false;
				}
				
			}
			
			if(changeFeviconFlag != true && getFaviconLogo != ''){
				
				formData.append('faviconimage', getFaviconLogo);
			}
			else{				
				saveFaviconLogo = $('input[id="faviconLogoImageFileNameFor"').get(0).files[0];
				formData.append('faviconimage', saveFaviconLogo);
				
				// validation for favicon Image
				if (typeof saveFaviconLogo != "undefined") {
					var uploadImageSize = saveFaviconLogo.size / 1024;
					if (uploadImageSize > 1024) {
						$('#faviconLogoImageFileName').parent().parent().addClass("error");
						$(".faviconImgFileErr").html('Image size should not exceed 1 MB').show();
						flag = false;
					} else if(saveFaviconLogo == "" || saveFaviconLogo == null){
						$('#faviconLogoImageFileName').parent().parent().addClass("error");
						$(".faviconImgFileErr").html('Please upload a file').show();
						flag = false;
					}
					else if (saveFaviconLogo.type == "image/jpeg" || saveFaviconLogo.type == "image/png") {
						$('#faviconLogoImageFileName').parent().parent().removeClass("error");
						$(".faviconImgFileErr").hide();
					} else {
						$('#faviconLogoImageFileName').parent().parent().addClass("error");
						$(".faviconImgFileErr").html('Please upload image file of type png or jpeg ').show();
						flag = false;
					}

				}else if(saveFaviconLogo == "" || saveFaviconLogo == null){
					$('#faviconLogoImageFileName').parent().parent().addClass("error");
					$(".faviconImgFileErr").html('Please upload a file').show();
					flag = false;
				}
			}
			
			if(changeLoginLogoFlag != true && getLoginPageLogo != ''){
				
				formData.append('loginPageLogo', getLoginPageLogo);
			}
			else{				
				saveLoginPageLogo = $('input[id="logoImageFileNameForLoginPage"').get(0).files[0];
				formData.append('loginPageLogo', saveLoginPageLogo);
				
				//validation for login page logo image
				if (typeof saveLoginPageLogo != "undefined") {
					var uploadImageSize = saveLoginPageLogo.size / 1024;
					if (uploadImageSize > 1024) {
						$('#LoginlogoImageFileName').parent().parent().addClass("error");
						$(".logoFileNameErr").html('Image size should not exceed 1 MB').show();
						flag = false;
					} else if(saveLoginPageLogo == "" || saveLoginPageLogo == null){
						$('#LoginlogoImageFileName').parent().parent().addClass("error");
						$(".logoFileNameErr").html('Please upload a file').show();
						flag = false;
					}
					else if (saveLoginPageLogo.type == "image/jpeg" || saveLoginPageLogo.type == "image/png") {
						$('#LoginlogoImageFileName').parent().parent().removeClass("error");
						$(".logoFileNameErr").hide();
					} else {
						$('#LoginlogoImageFileName').parent().parent().addClass("error");
						$(".logoFileNameErr").html('Please upload image file of type png or jpeg ').show();
						flag = false;
					}

				}else if(saveLoginPageLogo == "" || saveLoginPageLogo == null){
						$('#LoginlogoImageFileName').parent().parent().addClass("error");
						$(".logoFileNameErr").html('Please upload a file').show();
						flag = false;
					}
			}
			if(changeBGFlag != true && getBackgroundImage != ''){
				
				formData.append('backgroundimage', getBackgroundImage);
			}else{
				saveBackgroundImage = $('input[id="backgroundImageFileFor"').get(0).files[0];
				formData.append('backgroundimage', saveBackgroundImage);
				
				// validation for login page background image file
				if (typeof saveBackgroundImage != "undefined") {
					var uploadImageSize = saveBackgroundImage.size / 1024;
					if (uploadImageSize > 1024) {
						$('#backgroundImageFile').parent().parent().addClass("error");
						$(".backgrounImgFileErr").html('Image size should not exceed 1 MB').show();
						flag = false;
					} else if(saveBackgroundImage == "" || saveBackgroundImage == null){
						$('#backgroundImageFile').parent().parent().addClass("error");
						$(".backgrounImgFileErr").html('Please upload a file').show();
						flag = false;
					}
					else if (saveBackgroundImage.type == "image/jpeg" || saveBackgroundImage.type == "image/png") {
						$('#backgroundImageFile').parent().parent().removeClass("error");
						$(".backgrounImgFileErr").hide();
					} else {
						$('#backgroundImageFile').parent().parent().addClass("error");
						$(".backgrounImgFileErr").html('Please upload image file of type png or jpeg ').show();
						flag = false;
					}

				}else if(saveBackgroundImage == "" || saveBackgroundImage == null){
					$('#backgroundImageFile').parent().parent().addClass("error");
					$(".backgrounImgFileErr").html('Please upload a file').show();
					flag = false;
				}
			}
			
			
			if(flag == false){
				return true;
			}
			else {
				$('.logoFileNameErr, .backgrounImgFileErr, .headerLogoImgFileErr, .faviconLogoImageFileName').hide();
				$('#LoginlogoImageFileName, #backgroundImageFile, #headerLogoImageFileName, #faviconLogoImageFileName').parent().parent().removeClass('error');
				
				$.ajax({
					url :'/repopro/web/customimagesmanager/allthemecolors',
					type : 'PUT',
					contentType : false,
					processData : false,
					data : formData,
					complete : function(data){
						var json = JSON.parse(data.responseText);
					//	console.log(JSON.stringify(json))
					if(json.status == "SUCCESS"){
						 
						notifyMessage("Theme Details","Theme Details are saved successfully","success");
						setTimeout(function(){
							window.location.reload(true);
					    	//window.location.href = 'login.html';
							getHomeDetails(this);
						},2000);
					}
					
					},
					error : function(data){
						notifyMessage("Theme Details","Error attempting to update theme details","fail");
					}
				});
				
				
				
				
			}
			
	 }