appendData = "";
range = 0;
infiniteScrollFlag = true;
userCount = 0;
//deptFlag = true;
editDeptFlag = true;
userExportFlag = false;
//load user details
function loadUserDetails(){
	$('#usersGrid_filterSearch').hide();
	$('#noUserDataInDB1_filterSearch').hide();
	$('#usersGrid').show();
	$.ajax({
		type : "GET",
		url : "/repopro/web/user/userForGrid?userName="+loggedInUserName+"&from="+range,
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			$('#tableUsers_filterSearch tbody').empty();
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					if(userCount == 0){
						$('#usersGrid').hide();
						$('#searchManageUserTextBoxDiv').hide(); // Hema 21 Feb 2018 Hide Filter Icon
						$('#noUserDataInDB1').show();
						$('#noUserDataInDB1').html('<div class="ui message">No users added yet</div>'); 
						$('#exportUserDataToExcel').remove();
					}else{
						infiniteScrollFlag = false;
						$('#loadingId').css('display', 'none');
					}
				
				}else {
						$('#noUserDataInDB1').hide();
						$('#searchManageUserTextBoxDiv').show(); // Hema 21 Feb 2018 Hide Filter Icon
						$('#usersGrid').show();
					$.each(json.result, function(i) {
						    //console.log(" json.result  "+JSON.stringify(json.result[i].imageName));
							var imageType = "";
							
							if(json.result[i].imageName != null){
								//imageType = (json.result[i].imageName).split('.');
								imageType = (json.result[i].imageName).substring((json.result[i].imageName).lastIndexOf(".") + 1, (json.result[i].imageName).length);								
								//Chandana - 13-9-2019 Broken image for uppercase
								if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
									imageType = imageType.toLowerCase()
								}
							}
							else{
								
								imageType = "default";
							}
							
							appendData = getUserDetails(json.result[i].userId,json.result[i].userName,json.result[i].fullName,json.result[i].emailId,json.result[i].department,imageType,json.result[i].lockStatus,json.result[i].native,json.result[i].imageName,json.result[i].encryptFullName,json.result[i].encryptEmailId,json.result[i].encryptDepartment,json.result[i].encryptImage);
							$('#tableUsers tbody').append(appendData);
							userCount++;
							var userId = json.result[i].userId;
							if(userId == 1){
								$("#trTable"+userId).remove();
							}
							if(json.result[i].activeFlag == 'Active' || json.result[i].activeFlag == 1){
								$("#enableDisableUser_"+userId).prop('checked',true);
								$('#userName_'+userId).parent().removeClass('disabled');
								$('#userIcon_'+userId).removeClass('disabled');
								$('#fullName_'+userId).removeClass('disabled');
								$('#email_'+userId).removeClass('disabled');
								$('#dept_'+userId).removeClass('disabled');
								$('#configureUser_'+userId).removeClass('disabled');
								$('#configureUserIcon_'+userId).removeClass('disabled');
								$('#editUser_'+userId).removeClass('disabled');
								$('#editUserIcon_'+userId).removeClass('disabled');
								$('#accountStatus_'+userId).removeClass('disabled');
								$('#accountStatus_'+userId).removeClass('disabled');
								$('#accountStatus_'+userId).find("i").removeClass('disabled');
								$('#accountStatus_'+userId).find("b").css("opacity", "1");
								$('#accountStatus_'+userId).find("button").removeClass('disabled');
	
							}
							else{
								$("#enableDisableUser_"+userId).prop('checked',false);
								$('#userName_'+userId).parent().addClass('disabled');
								$('#userIcon_'+userId).addClass('disabled');
								$('#fullName_'+userId).addClass('disabled');
								$('#email_'+userId).addClass('disabled');
								$('#dept_'+userId).addClass('disabled');
								$('#configureUser_'+userId).addClass('disabled');
								$('#configureUserIcon_'+userId).addClass('disabled');
								$('#editUser_'+userId).addClass('disabled');
								$('#editUserIcon_'+userId).addClass('disabled');
								$('#accountStatus_'+userId).addClass('disabled');
								$('#accountStatus_'+userId).find("i").addClass('disabled');
								$('#accountStatus_'+userId).find("b").css("opacity", "0.45");
								$('#accountStatus_'+userId).find("button").addClass('disabled');
							}
							
						
					});
					range = range + 20;
					
				}
				
			}
			else{
				infiniteScrollFlag = false;
				$('#loadingId').css('display', 'none');
			}
			$('#showHideLoader').removeClass('active');
		}
	});
	$('#loadingId').css('display', 'none');
	scrollVisible(0);
}

//get user details
function getUserDetails(userId,userName,fullName,emailId,department,imageType,lockStatus,native,fullImageName, eName,eEmail,eDept,eImg){	
	var userPage = "userPage";
	appendData  = '';
	if(loggedInUserName == "admin"){
		if(lockStatus == "lock"){
			appendData += '<tr id="trTable'+userId+'" class="warning">';
		}else{
			appendData += '<tr id="trTable'+userId+'">';
		}
		
	}else{
		appendData += '<tr id="trTable'+userId+'">';
	}
	appendData += '<td class="one wide hidden" id="userID_'+userId+'">'+userId+'</td>';
	
	if( imageType == "default"){
		appendData += '<td class="two wide"><img id="userIcon_'+userId+'" class="ui avatar image" src="/repopro/semantic/images/avatar/defaultUserImage.png" style="width: 2.1em; height: 2.1em;"><span id="userName_'+userId+'" class="gridImageTextSpacing">'+userName+'</span><span id="fullImageName_'+userId+'" style="display:none;">'+fullImageName+'</span></td>';
	}else{
		appendData += '<td class="two wide"><img id="userIcon_'+userId+'" class="ui avatar image" src="/repopro/profileImages/'+userId+'.'+imageType+'" style="width: 2.1em; height: 2.1em;"><span id="userName_'+userId+'" class="gridImageTextSpacing">'+userName+'</span><span id="fullImageName_'+userId+'" style="display:none;">'+fullImageName+'</span></td>';
	}
		
	
	appendData += '<td  class="three wide loading whitespaceNoTrim" id="fullName_'+userId+'">'+fullName+'</td>';
	appendData += '<td class="three wide" id="email_'+userId+'">'+emailId+'</td>';
	appendData += '<td class="two wide whitespaceNoTrim" id="dept_'+userId+'">'+department+'</td>';
/*	appendData += '<td class="two wide center aligned" id="configureUser_'+userId+'"><i id="configureUserIcon_'+userId+'" class="configure icon deleteEditIcon"></i></td>';
*/	appendData += '<td class="one wide" id="editUser_'+userId+'"><i id="editUserIcon_'+userId+'" class="edit icon deleteEditIcon" onclick="editUserDetailsInUserPage('+userId+',\''+userPage+'\')"></i></td>';
	
	if(loggedInUserName == "admin"){
		if(native){
			if(lockStatus == "lock"){
				appendData += '<td class="two wide" id="accountStatus_'+userId+'">';
				appendData += '<button class="primary ui mini button" onclick="unlockUserAccount('+userId+',\''+userName+'\')">Unlock Account</button>';
				appendData += '</td>';
			}else{
				appendData += '<td class="two wide" id="accountStatus_'+userId+'"><i class="icon green checkmark"></i><b style="color:#5ecc78;">Unlocked</b></td>';
			}
		}else{
			appendData += '<td class="two wide" id="accountStatus_'+userId+'"><b>N/A</b></td>';
		}
		
	}

	appendData += '<td class="one wide">';
	appendData += '<div class="ui fitted slider checkbox sliderCbZIndex">';
	appendData += '<input id="enableDisableUser_'+userId+'" class="checkBoxEnableDisableUser" onclick="enableDisableUser(this)" type="checkbox"> <label></label>';
	appendData += '<div style="display:none;"><span  id="enFullName_'+userId+'" >'+eName+'</span><span id="enEmail_'+userId+'" >'+eEmail+'</span><span id="enDept_'+userId+'">'+eDept+'</span><span id="enImg_'+userId+'">'+eImg+'</span></div></div></td>';
	appendData += '</tr>';
	
	return appendData;
}

//enable / diasable user
function enableDisableUser(obj){
	var data = $(obj).attr('id');
	var arr = data.split('_');
	var obj,content,username;
	
	if(false == $(obj).prop('checked')){
		$('#userName_'+arr[1]).parent().addClass('disabled');
		$('#userIcon_'+arr[1]).addClass('disabled');
		$('#fullName_'+arr[1]).addClass('disabled');
		$('#email_'+arr[1]).addClass('disabled');
		$('#dept_'+arr[1]).addClass('disabled');
		$('#configureUser_'+arr[1]).addClass('disabled');
		$('#configureUserIcon_'+arr[1]).addClass('disabled');
		$('#editUser_'+arr[1]).addClass('disabled');
		$('#editUserIcon_'+arr[1]).addClass('disabled');
		$('#accountStatus_'+arr[1]).addClass('disabled');
		$('#accountStatus_'+arr[1]).find("i").addClass('disabled');
		$('#accountStatus_'+arr[1]).find("b").css("opacity", "0.45");
		$('#accountStatus_'+arr[1]).find("button").addClass('disabled');
		username = $('#userName_'+arr[1]).text();
		content = username+" is disabled";
		obj = {
				"userId":arr[1],
				"activeFlag":0
				};
	}
	else{
		$('#userName_'+arr[1]).parent().removeClass('disabled');
		$('#userIcon_'+arr[1]).removeClass('disabled');
		$('#fullName_'+arr[1]).removeClass('disabled');
		$('#email_'+arr[1]).removeClass('disabled');
		$('#dept_'+arr[1]).removeClass('disabled');
		$('#configureUser_'+arr[1]).removeClass('disabled');
		$('#configureUserIcon_'+arr[1]).removeClass('disabled');
		$('#editUser_'+arr[1]).removeClass('disabled');
		$('#editUserIcon_'+arr[1]).removeClass('disabled');
		$('#accountStatus_'+arr[1]).removeClass('disabled');
		$('#accountStatus_'+arr[1]).find("i").removeClass('disabled');
		$('#accountStatus_'+arr[1]).find("b").css("opacity", "1");
		$('#accountStatus_'+arr[1]).find("button").removeClass('disabled');
		username = $('#userName_'+arr[1]).text();
		content = username+" is enabled";
		obj = {
				"userId":arr[1],
				"activeFlag":1
			};
	}
	
	$.ajax({
		type: "PUT",
		url: "/repopro/web/user/updateUserActiveFlag",
		contentType : "application/json",
		dataType : "json",
		data : JSON.stringify(obj),
		async: false,
		cache: false,
		complete:function(data){	
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				notifyMessage('Enable/Disable User',content,'success');
				
			}
			else{
				notifyMessage('Enable/Disable User',json.message,'fail');
			}
		}
	});
	
	
}



//import export user profile
function importExportUserProfile(){
	$('#importExportUserProfile').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	document.getElementById("uploadFileBtn").onchange = function () {
	    document.getElementById("uploadFile").value = this.value;
	};
	
}


//add user profile
function addUserDetails(){
	$('#editUserInUserPage1').modal("destroy");
	$('#addUser').modal('destroy').modal('refresh');
	
	var contactTopPosition = $("#addUserDesc").position().top;
	$(".modalOverflow").animate({scrollTop: contactTopPosition});
	
	$('#submitAddedUsers').unbind();
	$('#cancelAddedUsers').unbind();
	$('#addUser').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	$('#addUserForm').form('reset');
	
	//chandanda // allow input to select same file
	$('#uploadNewUserImageBtn').val("");
	
	$('#addUserName').parent().removeClass("error"); 
	$(".errAddUserName").hide();
	
	/*Commented by Hema - 11.July.2018*/
	/*$('#addUserPassword').parent().removeClass("error"); 
	$(".errAddUserPassword").hide();*/
	
	$('#addUserFullName').parent().removeClass("error"); 
	$(".errAddUserFullName").hide();
	
	$('#addUserEmail').parent().removeClass("error"); 
	$(".errAddUserEmail").hide();
	
	$('#addUserDepartment').parent().removeClass("error"); 
	$(".errAddUserDepartment").hide();
	
	$('#uploadNewUserImage').parent().parent().removeClass("error");
	$(".errAddUserProfilePicture ").hide();
	
	$('#addUserName').val("");
	//$('#addUserPassword').val(""); /*Commented by Hema - 11.July.2018*/
	$('#addUserFullName').val("");
	$('#addUserEmail').val("");
	$('#addUserDepartment').val("");
	$('#uploadNewUserImage').val("");
	
	$("#encryptImage").attr( "disabled", "disabled" ); //Swathi-encrytption 
	$("#encryptAllC").attr("disabled", "disabled");
	
	$("#uploadNewUserImageBtn").on('change', function () {
	    $("#uploadNewUserImage").val(this.value);
	  //Swathi-encrytption 
	    var imgPath =  $("#uploadNewUserImage").val(this.value);
		   if(imgPath != "" || imgPath != undefined){
			   $("#encryptImage").removeAttr("disabled", "disabled");
			   $("#encryptAllC").removeAttr( "disabled", "disabled" );
			   if ($('.encryptRedC:checked:visible').length == $('.encryptRedC:visible').length) {
					$("#encryptAllC").attr("checked",true);
				}else{
					$("#encryptAllC").attr("checked",false);
				}
			} else{		
				$("#encryptImage").attr( "disabled", "disabled" );
				$("#encryptAllC").attr("disabled", "disabled");
			}
		//EOC
	});
	
	$("#submitAddedUsers").on('click',function(){
		var addUserName = $("#addUserName").val().trim();
		/*var addUserPassword = $("#addUserPassword").val().trim();*/ /*Commented by Hema - 11.July.2018*/
		var addUserFullName = $("#addUserFullName").val().trim();
		var addUserEmail = $("#addUserEmail").val().trim();
		var addUserDepartment = $("#addUserDepartment").val().trim();
		var userImage = $('input[id="uploadNewUserImageBtn"]').get(0).files[0];
		/*var formData = new FormData();
		formData.append('userImage', userImage); */
	    var flag = true;
	    
	  //Swathi- Encrpytion checkbox value on click of Update- 23.12.2019
		var encryptUserFullName=0 ;
		var encryptUserEmailId=0;
		var encryptUserDept=0;
		var encryptImg=0;
		 if($('#encryptFullName').prop("checked") == true) {	
			encryptUserFullName="1";
		} else {
			encryptUserFullName="0";
		}
		if($("#encryptEmailId").prop("checked") == true){
			encryptUserEmailId="1";
		} else {
			encryptUserEmailId="0";
		}
		if($("#encryptDepartment").prop("checked") == true){
			encryptUserDept="1";
		} else {
			encryptUserDept="0";
		}
		if($("#encryptImage").prop("checked") == true){
			encryptImg="1";
		} else {
			encryptImg="0";
		}
	    if(addUserName == null || addUserName == ""){
	    	  $('#addUserName').parent().addClass("error"); 
			  $(".errAddUserName").html("Please provide user name").show();  
				 flag = false;
		}
		else{
			var regex = /^[a-zA-Z0-9-]*$/;
			if (regex.test(addUserName)) {
				$('#addUserName').parent().removeClass("error"); 
				$(".errAddUserName").hide(); 
			}else{
				$('#addUserName').parent().addClass("error"); 
				  $(".errAddUserName").html("Please use alphanumeric characters in the user name").show();  
					 flag = false;
			}
		}
	    
	    // commented by Hema - 11.July.2018 - Not required Once user clicks on Add Button password notifications will be sent to the user. 
	   /* if(addUserPassword == null || addUserPassword == ""){
	    	  $('#addUserPassword').parent().addClass("error"); 
			  $(".errAddUserPassword").html("Please provide password").show();  
				 flag = false;
		}
		else{
			if(addUserPassword.length > 7 && addUserPassword.match(/[A-z]/) && addUserPassword.match(/[A-Z]/) && addUserPassword.match(/\d/) && addUserPassword.match(/[!@#$%^&*]/)){
				$('#addUserPassword').parent().removeClass("error"); 
				$(".errAddUserPassword").hide();
			}else{
				 $('#addUserPassword').parent().addClass("error"); 
				  $(".errAddUserPassword").html("Password must be <br/> at least 8 characters long,<br/>include one lowercase letter,<br/> include one uppercase letter,<br/> include one number,<br/> include one special character !@#$%^&*").show();  
				 flag = false;
			}
			 
			
		}*/
	    
	    if(addUserFullName == null || addUserFullName == ""){
	    	  $('#addUserFullName').parent().addClass("error"); 
			  $(".errAddUserFullName").html("Please provide full name").show();  
				 flag = false;
		}
		else{
			var regex = /^[a-zA-Z- /./-]*$/;
			if (regex.test(addUserFullName)) {
				$('#addUserFullName').parent().removeClass("error"); 
				$(".errAddUserFullName").hide(); 
			}else{
				$('#addUserFullName').parent().addClass("error"); 
				  $(".errAddUserFullName").html("Please use only alphabets, dot and hyphen in the full name field").show();  
					 flag = false;
			} 
			
		}
	    
	    if(addUserEmail == null || addUserEmail == ""){
	    	  $('#addUserEmail').parent().addClass("error"); 
			  $(".errAddUserEmail").html("Please enter Email Id").show();  
				 flag = false;
		}
		else{
			var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			 if(regex.test(addUserEmail)){
				 $('#addUserEmail').parent().removeClass("error");
				 $(".errAddUserEmail").hide();
			 }else{
				$('#addUserEmail').parent().addClass("error");
				$(".errAddUserEmail").html('Please provide a valid email Id').show();
				flag = false;
			 }
			
			
		}
	    
	    if(addUserDepartment == null || addUserDepartment == ""){
	    	  $('#addUserDepartment').parent().addClass("error"); 
	    	  $(".errAddUserDepartment").show();
			  $(".errAddUserDepartment").html("Please enter Department");
				 flag = false;
				 //deptFlag = false;
		}
		else{
			 $(".errAddUserDepartment").hide();
			 $('#addUserDepartment').parent().removeClass("error"); 
			 var iChars = "`!%^*=[];{}|<>?~";
			 //alert(" addUserDepartment  "+addUserDepartment.length);
			  for (var i = 0; i < addUserDepartment.length; i++){
			  	if (iChars.indexOf(addUserDepartment.charAt(i)) != -1){
			  		$("#addUserDepartment").parent().addClass("error");
			  		$(".errAddUserDepartment").show();
			  		$(".errAddUserDepartment").html("Special characters except ':'\"+#$/\&(),-_.@' are not allowed");  
			  		flag = false;
			  		//deptFlag = false;
			  	}
			  }
			  
			/*  if(deptFlag){
				  //alert("deptFlag "+deptFlag);
				  $('#addUserDepartment').parent().removeClass("error"); 
				  $(".errAddUserDepartment").hide();
			  }*/
		}
	    
	    
	    if(typeof userImage == "undefined"){
	    	userImage = null;
	    }
	    
	    
	    
	   
	    var formData = new FormData();
	    if (userImage != null) {
			var uploadImageSize = userImage.size / 1024;
			if (uploadImageSize > 1024) {
				$('#uploadNewUserImage').parent().parent().addClass("error");
				$(".errAddUserProfilePicture ").html('Image size should not exceed 1 MB').show();
				flag = false;
			} else if (userImage.type == "image/jpeg" || userImage.type == "image/png") {
				$('#uploadNewUserImage').parent().parent().removeClass("error");
				$(".errAddUserProfilePicture ").hide();
			} else {
				$('#uploadNewUserImage').parent().parent().addClass("error");
				$(".errAddUserProfilePicture ").html('Please upload image file of type png or jpeg ').show();
				flag = false;
			}

			
			formData.append('userImage', userImage);
		}
	    
	    
	    
	    var imageType = "";
	    var imageName = "";
		if(userImage != null){
			imageName = userImage.name
			imageType = imageName.split('.');
		}
		else {
			imageName = ""; imageType = "";
		}
		//alert("imageType : " + imageType);
	    hiddenVariableForManageUser = "";
	    if(flag == false){
	    	$('#addUser').modal('show');
	    	return false;
	    }
	    else {
	    	var manageUserObj = {
					"userName": loggedInUserName,
					"uName": addUserName,
					"fullName": addUserFullName,
					"emailId": addUserEmail,
					"department": encodeURIComponent(addUserDepartment),
					"encryptFullName":encryptUserFullName,//Encrption checkbox values
					"encryptEmailId":encryptUserEmailId,
					"encryptDepartment":encryptUserDept,
					"encryptImage":encryptImg
			};
	    	//console.log(JSON.stringify(manageUserObj));
	    	//$('#hiddenInput').val(manageUserObj); 
	    	formData.append("hiddenVariableForManageUser", JSON.stringify(manageUserObj));
	    	$.ajax({
	    		type: "POST",
	    		url: "/repopro/web/user/addUser",
	    		//url: "/repopro/web/user/addUser?userName="+loggedInUserName+"&uName="+addUserName+"&password="+encodeURIComponent(addUserPassword)+"&fullName="+addUserFullName+"&emailId="+addUserEmail+"&department="+encodeURIComponent(addUserDepartment), commented by Hema
	    		//url: "/repopro/web/user/addUser?userName="+loggedInUserName+"&uName="+addUserName+"&fullName="+addUserFullName+"&emailId="+addUserEmail+"&department="+encodeURIComponent(addUserDepartment), Hema - removed password query param
	    		contentType : "application/json",
	    		dataType : "json",
	    		data : formData,
	    		async: false,
	    		cache: false,
	    		processData: false,
	    		contentType: false,
	    		complete:function(data){	
	    			appenddata = "";
	    			var json = JSON.parse(data.responseText);
	    			if(json.status == "SUCCESS"){
	    				notifyMessage('Add User','New user added with user name '+addUserName,'success');
	    				
	    				/*$("#uploadNewUserImage").val('');
	    				files = [];*/
	    				$("#addUserForm").get(0).reset();
	    				
	    				/*var rowCount = $('#tableUsers >tbody >tr').length;
	    				var userId = json.result[0].replace('"','');
						if(rowCount < 19){
							 var newUserData = getUserDetails(userId,addUserName,addUserFullName,addUserEmail,addUserDepartment,imageType,"unlock","true",imageName);
							 								//(json.result[i].userId,json.result[i].userName,json.result[i].fullName,json.result[i].emailId,json.result[i].department,imageType[1],json.result[i].lockStatus,json.result[i].native,json.result[i].imageName);
	    				    // console.log("newUserData : " + newUserData);
							 $('#tableUsers tbody').append(newUserData);
	    				     loadUserDetails();
	    				        $("#enableDisableUser_"+userId).prop('checked',true);
								$('#userName_'+userId).removeClass('disabled');
								$('#userIcon_'+userId).removeClass('disabled');
								$('#fullName_'+userId).removeClass('disabled');
								$('#email_'+userId).removeClass('disabled');
								$('#dept_'+userId).removeClass('disabled');
								$('#configureUser_'+userId).removeClass('disabled');
								$('#configureUserIcon_'+userId).removeClass('disabled');
								$('#editUser_'+userId).removeClass('disabled');
								$('#editUserIcon_'+userId).removeClass('disabled');
	    				}*/
	    				
	    				
	    				$('.adminMainItem').click();
	    				$('.accessControlSubMenu').click();
	    				$('#adminAccContrlUsers1').click();
	    				
	    			}
	    			else{
	    				if(json.result == "USER_NAME_EXIST"){
	    					 $('#addUserName').parent().addClass("error"); 
	    					 $(".errAddUserName").html(json.message).show();  
	    					 flag = false;
	    					
	    				}else if(json.result == "EMAIL_EXIST"){
	    					 $('#addUserEmail').parent().addClass("error"); 
	    					 $(".errAddUserEmail").html(json.message).show();  
		    				 flag = false;
		    					
		    			}else{
	    					notifyMessage('Add User',json.message,'fail');
	    					$('#addUserName').parent().removeClass("error"); 
	    					$(".errAddUserName").hide(); 
	    					$('#addUserEmail').parent().removeClass("error"); 
	    					$(".errAddUserEmail").hide(); 
	    				}
	    				
	    			}
	    		}
	    	});

	    }
	    if(flag == false){
	    	$('#addUser').modal('show');
	    	return false;
	    }
	    else{
	    	$('#addUser').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
	    	/*$('#addUser').modal('hide'); //.modal('hide dimmer');
	    	$('#addUser').parent().css("display", "none !important");*/
	    }
		
	});
}

function exportUserdata(){
	var con = confirm("Please confirm to proceed with the export ! ");
	if(con == true){
		notifyMessage("","Export has been started. Please wait until it gets exported!.","success");
		var searchResultValue = $("#filterManageUserInputField").val();
		searchResultValue = encodeURIComponent(searchResultValue);		
		if(userExportFlag == true){			
			$('#exportUserDataToExcel').attr('href','/repopro/web/profileExport/exportfilterUsersAttributes?userName='+loggedInUserName+'&attributeList='+exportAttributeString+'&searchString='+exportSearchString+'&groupIds='+exportGroupList);
		}else{
			$('#exportUserDataToExcel').attr('href','/repopro/web/profileExport/exportProfile');
		}
	} else{
		$('#exportUserDataToExcel').attr('href','');
		return false;
	}
}

function importUserData(){
	$('input[id="uploadUserImageBtn1"]').val(null);//aditya 30.08.18
	$('#btnImportData, #importIdLabel').removeClass('loading');//aditya 30.08.18
	
	$('#btnImportData').unbind();
	$('#btnCancelImporting').unbind();
	$('#importUserModal').modal({observeChanges : true}).modal('show').modal('refresh');

	$('#uploadUserImageName').parent().parent().removeClass("error");
	$(".errEditUserProfilePicture").hide();
	$('#uploadUserImageName').val("");
	$("#uploadUserImageBtn1").on('change', function() {
		$("#uploadUserImageName").val(this.value);
	});
	
	// Ajax Call
	$('#btnImportData').on('click',function(){
		$('#btnImportData').addClass('loading');//aditya 30.08.18
		$("#uploadUserImageBtn1,#btnCancelImporting").attr('disabled', true);//aditya 30.08.18
		$('#btnCancelImporting').removeClass("cancel");//aditya 30.08.18
		
		var userFile = $('input[id="uploadUserImageBtn1"]').get(0).files[0];
		var bgImgext = getExt($('#uploadUserImageName').val());
		var flag = true;
		if(userFile == undefined){
			$('#btnImportData').removeClass('loading');//aditya 30.08.18
			$("#uploadUserImageBtn1, #btnCancelImporting").attr('disabled', false);//aditya 30.08.18
			$('#btnCancelImporting').addClass("cancel");//aditya 30.08.18
			
			$('#uploadUserImageName').parent().parent().addClass("error");
			$(".errEditUserProfilePicture").html('Please upload the file').show();
			flag = false;
		}
		else {
			$('#uploadUserImageName').parent().parent().removeClass("error");
			$(".errEditUserProfilePicture").hide();
		}
	
		if(bgImgext != ""){
			if (bgImgext == "xlsx") {
				$('#uploadUserImageName').parent().parent().removeClass("error");
				$(".errEditUserProfilePicture").hide();
			} else {
				$('#btnImportData').removeClass('loading');//aditya 30.08.18
				$("#uploadUserImageBtn1, #btnCancelImporting").attr('disabled', false);//aditya 30.08.18
				$('#btnCancelImporting').addClass("cancel");//aditya 30.08.18
				
				$('#uploadUserImageName').parent().parent().addClass("error");
				$(".errEditUserProfilePicture").html('Please upload the file of type xlsx').show();
				flag = false;
			}
		}
		
		if(flag == false){
			$('#btnImportData').removeClass('loading');//aditya 30.08.18
			$("#uploadUserImageBtn1, #btnCancelImporting").attr('disabled', false);//aditya 30.08.18
			$('#btnCancelImporting').addClass("cancel");//aditya 30.08.18
			
			return false;
		}
		else {
			$('#btnImportData').addClass('loading');//aditya 30.08.18
			$("#uploadUserImageBtn1, #btnCancelImporting").attr('disabled', true);//aditya 30.08.18
			$('#btnCancelImporting').removeClass("cancel");//aditya 30.08.18
			
			var formData = new FormData();
			formData.append('importdata', userFile);
			$.ajax({
			type : "POST",
			url : "/repopro/web/profileImport/importExcelSheet?userName="+loggedInUserName,
				contentType : "application/json",
				dataType : "json",
				data : formData,
				async : true,
				cache: false,
				processData : false,
				contentType : false,
				complete : function(data) {
					
					appenddata = "";
					var json = JSON.parse(data.responseText);
					if (json.status == "SUCCESS") {
						$('#btnImportData').removeClass('loading');//aditya 30.08.18
						$("#uploadUserImageBtn1, #btnCancelImporting").attr('disabled', false);//aditya 30.08.18
						$('#btnCancelImporting').addClass("cancel");//aditya 30.08.18
						
						notifyMessage("Import XLSX","Import process started, you will be notified through mail.","success");
						$('#importUserModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
						$("#importUserModal").modal('hide'); //.modal('hide dimmer');
						$('#importUserModal').parent().css("display", "none !important");
					} else {
						$('#btnImportData').removeClass('loading');//aditya 30.08.18
						$('#btnCancelImporting').addClass("cancel");//aditya 30.08.18
						$("#uploadUserImageBtn1, #btnCancelImporting").attr('disabled', false);//aditya 30.08.18
						
						notifyMessage("Import XLSX",json.message,"fail");
	
					}
					$('#btnImportData').removeClass('loading');//aditya 30.08.18
					$('#btnCancelImporting').addClass("cancel");//aditya 30.08.18
					$("#uploadUserImageBtn1, #btnCancelImporting").attr('disabled', false);//aditya 30.08.18
				}
			
			});
		}
	});
	
	
}

//method to get file extension
function getExt(filename) {
	var dot_pos = filename.lastIndexOf(".");
	if (dot_pos == -1) {
		return "";
	}
	return filename.substr(dot_pos + 1).toLowerCase();
}


//edit user modal ---Souradip 17/10/17
//show change password field
function showChangePasswordFieldsInUserPage() {
	$('#changePasswordVisible').toggle("slow");
	$('#changePasswordVisible').toggleClass("passwordFieldVisible");
}

//edit user profile modal
var addedUserFunctionIds1 = [] ;
var globaluserId = "";
function editUserDetailsInUserPage(userId,pageName) {
	globaluserId = "";
	globaluserId = userId;
	//alert("edit userId : " + userId);
	//console.log("userId:   "+userId);
	$('#addUser').modal('destroy');
	$('#editUserInUserPage1').modal("destroy");
	
	var contactTopPosition = $("#editUserDesc").position().top;
	$(".modalOverflow").animate({scrollTop: contactTopPosition});
	
	$('#submitEditedUsersInUserPage').unbind();
	$('#cancelEditedUsersInUserPage').unbind();

	$('#editUserFullNameInUserPage').parent().removeClass("error");
	$(".errEditUserFullNameInUserPage").hide();

	$('#editUserEmailInUserPage').parent().removeClass("error");
	$(".errEditUserEmailInUserPage").hide();

	$('#editUserDepartmentInUserPage').parent().removeClass("error");
	$(".errEditUserDepartmentInUserPage").hide();

	$('#uploadUserImageInUserPage').parent().removeClass("error");
	$(".errEditUserProfilePictureInUserPage").hide();

	$('#editUserOldPasswordInUserPage').parent().removeClass("error");
	$(".errEditUserOldPasswordInUserPage").hide();

	$('#editUserNewPasswordInUserPage').parent().removeClass("error");
	$(".errEditUserNewPasswordInUserPage").hide();

	$('#editUserConfirmNewPasswordInUserPage').parent().removeClass("error");
	$(".errEditUserConfirmNewPasswordInUserPage").hide();
	
	$('#uploadUserImageInUserPage').parent().parent().removeClass("error");
	$(".errEditUserProfilePictureInUserPage").hide();

	if ($('#changePasswordVisibleInUserPage').hasClass('passwordFieldVisible')) {
		$('#changePasswordVisibleInUserPage').toggle("slow");
		$('#changePasswordVisibleInUserPage').removeClass("passwordFieldVisible");
	}
	//$('#changePasswordVisible').hide();
	
	$('#editUserInUserPage1').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	//allow to select same file // chandana 22/01/2020
	$('#uploadUserImageBtnInUserPage1').val('');
	
	$("#encryptImageEdit").removeAttr("disabled", "disabled");	//Swathi-encrytption 
	$("#encryptAll").attr("disabled", "disabled");	//Swathi-encrytption 
	$('.popup-button1').popup({
		on: 'hover',
		inline: true
	});

	$("#uploadUserImageBtnInUserPage1").on('change', function() {
		$("#uploadUserImageInUserPage").val(this.value);
		//Swathi-encrytption 
	    var imgPath =  $("#uploadUserImageInUserPage").val(this.value);
		   if(imgPath != "" || imgPath != undefined){
			   $("#encryptImageEdit").removeAttr( "disabled", "disabled" );	
			   $("#encryptAll").removeAttr( "disabled", "disabled" );
			   // Code to deselect Encrypt all checkobx
			   if ($('.encryptRed:checked:visible').length == $('.encryptRed:visible').length) {
					$("#encryptAll").attr("checked",true);
				}else{
					$("#encryptAll").attr("checked",false);
				}
			} else{	
				$("#encryptImageEdit").attr("disabled", "disabled");
				$("#encryptAll").attr("disabled", "disabled");
			}
		//EOC
		
	});
	
	
	
	var userName;
	if(pageName == "homePage"){
		$("#editUserNameInUserPage").val(loggedInUserName);
		$("#editUserFullNameInUserPage").val(loggedInUserFullName);
		$("#editUserEmailInUserPage").val(loggedInUserEmailId);
		$("#editUserDepartmentInUserPage").val(loggedInUserDepartment);
		userId = loggedInUserId;
		$("#gridUserAssociatedFunctionsInUserPage").attr("style","pointer-events: none; opacity:0.5; margin-top: 3em;");
		$("#changePassordButtonInUserPage").show();
		$("#changePassordDividerInUserPage").show();
		var fullImageName = $("#fullImageName_"+ userId).text();
		if(fullImageName == null || fullImageName == "null"){
			fullImageName = "";
		}
		//Swathi- Encryption
		if(fullImageName == ""){
			 $("#encryptImageEdit").attr( "disabled", "disabled" );	
			 $("#encryptAll").attr("disabled", "disabled");
		}else{
			$("#encryptImageEdit").removeAttr("disabled", "disabled");	
			$("#encryptAll").removeAttr( "disabled", "disabled" );	
		}
	}else{
		$("#changePassordButtonInUserPage").hide();
		$("#changePassordDividerInUserPage").hide();
		$("#gridUserAssociatedFunctionsInUserPage").attr("style","pointer-events: auto; opacity:1; margin-top: 3em;");
		userName = $('#userName_' + userId).text();
		var userFullName = $('#fullName_' + userId).text();
		var userEmailId = $('#email_' + userId).text();
		var userDepartment = $('#dept_' + userId).text();
		var fullImageName = $("#fullImageName_"+ userId).text();
		if(fullImageName == null || fullImageName == "null"){
			fullImageName = "";
		}
		//Swathi- Encryption
		if(fullImageName == ""){
			 $("#encryptImageEdit").attr( "disabled", "disabled" );
			 $("#encryptAll").attr("disabled", "disabled");
		}else{
			$("#encryptImageEdit").removeAttr("disabled", "disabled");	
			 $("#encryptAll").removeAttr( "disabled", "disabled" );	
		}
		
		//Swathi- Encryption- 26.12.2019
		
		var eName = $('#enFullName_' + userId).text();
		var eEmailId = $('#enEmail_' + userId).text();
		var eDepartment = $('#enDept_' + userId).text();
		var enImg = $('#enImg_' + userId).text();
		
		$("#editUserNameInUserPage").val(userName);
		$("#editUserFullNameInUserPage").val(userFullName);
		$("#editUserEmailInUserPage").val(userEmailId);
		$("#editUserDepartmentInUserPage").val(userDepartment);
		if(eName == "1"){
			$("#encryptFullNameEdit").attr("checked",true);
		}else{
			$("#encryptFullNameEdit").attr("checked",false);
		}
		if(eEmailId == "1"){
			$("#encryptEmailIdEdit").attr("checked",true);
		}else{
			$("#encryptEmailIdEdit").attr("checked",false);
		}
		if(eDepartment == "1"){
			$("#encryptDepartmentEdit").attr("checked",true);
		}else{
			$("#encryptDepartmentEdit").attr("checked",false);
		}
		if(enImg == "1"){
			$("#encryptImageEdit").attr("checked",true);
			$("#encryptAll").removeAttr( "disabled", "disabled" );	
		}else{
			$("#encryptImageEdit").attr("checked",false);
		}		
		if((eName == "1") && (eEmailId == "1") && (eDepartment == "1") && (enImg == "1")){
			$("#encryptAll").attr("checked",true);
			$("#encryptAll").removeAttr( "disabled", "disabled" );	
			
		} else {
			$("#encryptAll").attr("checked",false);
		}
		
	}
	
	/*Added By Hema BOC*/
	$('#UserNameSpan').text(userName);
	/*EOC*/ 
	
	$('#uploadUserImageInUserPage').val(fullImageName);
	$('#editUserOldPasswordInUserPage').val('');
	$('#editUserNewPasswordInUserPage').val('');
	$('#editUserConfirmNewPasswordInUserPage').val('');
	$('#uploadUserImageBtn1InUserPage').val('');
	appendData = "";
	$.ajax({
		type: "GET",
		url: "/repopro/web/user/getAllUserGroups?userId="+userId,
		dataType: "json",
		async: false,
		cache: false,
		complete:function(data){										
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$('#gridUserAssociatedFunctionsInUserPage table tbody').html("");
				
				$.each(json.result, function(i) {
					appendData = getUserAssociatedFunctionsDetailsInUserPage(json.result[i].groupId,json.result[i].groupName,json.result[i].mappedWithUser);
					$('#gridUserAssociatedFunctionsInUserPage table tbody').append(appendData);
				});
				
			}
		}
	});	
	
	if ($('.userFunction:checked').length == $('.userFunction').length ){
		$("#selectAllUserAssociatedFunctionsInUserPage").prop('checked', true);
	}
	else{
		$("#selectAllUserAssociatedFunctionsInUserPage").prop('checked', false); 
	}

	// submit edited roles
		/*$('#submitEditedUsersInUserPage').on('click',function() {
						var editUserName = $("#editUserNameInUserPage").val().trim();
						var editUserFullName = $("#editUserFullNameInUserPage").val().trim();
						var editUserEmailId = $("#editUserEmailInUserPage").val().trim();
						var editUserDepartment = $("#editUserDepartmentInUserPage").val().trim();

						var userImage = $('input[id="uploadUserImageBtnInUserPage1"]').get(0).files[0];

						var flag = true;

						if (editUserFullName == null || editUserFullName == "") {
							$('#editUserFullNameInUserPage').parent().addClass("error");
							$(".errEditUserFullNameInUserPage").html('Please enter full name').show();
							flag = false;
						} else {
							var regex = /^[a-zA-Z- /./-]*$/;
							if (regex.test(editUserFullName) == false) {
								$('#editUserFullNameInUserPage').parent().addClass("error");
								$(".errEditUserFullNameInUserPage").html("Please use only alphabets, hyphen and dot in the full name field").show();
								flag = false;
							} else {
								$('#editUserFullNameInUserPage').parent().removeClass("error");
								$(".errEditUserFullNameInUserPage").hide();
							}
						}

						if (editUserEmailId == null || editUserEmailId == "") {
							$('#editUserEmailInUserPage').parent().addClass("error");
							$(".errEditUserEmailInUserPage").html('Please enter Email ID').show();
							flag = false;
						} else {
							 var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
							 if(regex.test(editUserEmailId)){
								 $('#editUserEmailInUserPage').parent().removeClass("error");
								 $(".errEditUserEmailInUserPage").hide();
							 }else{
								$('#editUserEmailInUserPage').parent().addClass("error");
								$(".errEditUserEmailInUserPage").html(editUserEmailId+' is an invalid email id').show();
								flag = false;
							 }
							

						}

						if (editUserDepartment == null || editUserDepartment == "") {
							$('#editUserDepartmentInUserPage').parent().addClass("error");
							$(".errEditUserDepartmentInUserPage").show();
							editDeptFlag = false;
							flag = false;
						} else {
							
							 var iChars = "`!%^*=[];{}|<>?~";
							 //alert(" addUserDepartment  "+addUserDepartment.length);
							  for (var i = 0; i < editUserDepartment.length; i++){
							  	if (iChars.indexOf(editUserDepartment.charAt(i)) != -1){
							  		$("#editUserDepartmentInUserPage").parent().addClass("error");
							  		$(".errEditUserDepartmentInUserPage").show();
							  		$(".errEditUserDepartmentInUserPage").html("Special characters except ':'\"+#$/\&(),-_.@' are not allowed");  
							  		flag = false;
							  		editDeptFlag = false;
							  	}
							  }
							  if(editDeptFlag){
								  $('#editUserDepartmentInUserPage').parent().removeClass("error");
									$(".errEditUserDepartmentInUserPage").hide();
							  }

						}

						if ($("#changePasswordVisibleInUserPage").hasClass("passwordFieldVisible")) {
							var editUserOldPassword = $("#editUserOldPasswordInUserPage").val().trim();
							var editUserNewPassword = $("#editUserNewPasswordInUserPage").val().trim();
							var editUserConfirmNewPassword = $("#editUserConfirmNewPasswordInUserPage").val().trim();

							if (editUserOldPassword == null || editUserOldPassword == "") {
								$('#editUserOldPasswordInUserPage').parent().addClass("error");
								$(".errEditUserOldPasswordInUserPage").html('Please Enter Password.').show();
								flag = false;
							} else {
								$('#editUserOldPasswordInUserPage').parent().removeClass("error");
								$(".errEditUserOldPasswordInUserPage").hide();

							}

							if (editUserNewPassword == null || editUserNewPassword == "") {
								$('#editUserNewPasswordInUserPage').parent().addClass("error");
								$(".errEditUserNewPasswordInUserPage").html('Please Enter New Password.').show();
								flag = false;
							} else {
								if(editUserNewPassword.length > 7 && editUserNewPassword.match(/[A-z]/) && editUserNewPassword.match(/[A-Z]/) && editUserNewPassword.match(/\d/) && editUserNewPassword.match(/[!@#$%^&*]/)){
									$('#editUserNewPasswordInUserPage').parent().removeClass("error");
									$(".errEditUserNewPasswordInUserPage").hide();
								}else{
									$('#editUserNewPasswordInUserPage').parent().addClass("error");
									$(".errEditUserNewPasswordInUserPage").html('Password must be <br/> at least 8 characters long,<br/>include one lowercase letter,<br/> include one uppercase letter,<br/> include one number,<br/> include one special character !@#$%^&*').show();
									flag = false;
								}
								

							}

							if (editUserConfirmNewPassword == null || editUserConfirmNewPassword == "") {
								$('#editUserConfirmNewPasswordInUserPage').parent().addClass("error");
								$(".errEditUserConfirmNewPasswordInUserPage").html('Please confirm password').show();
								flag = false;

							} else {
								if (editUserConfirmNewPassword != editUserNewPassword) {
									$('#editUserConfirmNewPasswordInUserPage').parent().addClass("error");
									$(".errEditUserConfirmNewPasswordInUserPage").html('Passwords do not match').show();
									flag = false;
								} else {
									$('#editUserConfirmNewPasswordInUserPage').parent().removeClass("error");
									$(".errEditUserConfirmNewPasswordInUserPage").hide();
								}

							}

						} else {
							var editUserOldPassword = "";
							var editUserNewPassword = "";
						}
						
						if (typeof userImage == "undefined"){
							userImage = null;
						}
						
						
						var formData = new FormData();
						if (userImage != null) {
							if(userImage != null){
							var uploadImageSize = userImage.size / 1024;
							if (uploadImageSize > 1024) {
								$('#uploadUserImageInUserPage').parent().parent().addClass("error");
								$(".errEditUserProfilePictureInUserPage").html('Image size should not exceed 1 MB').show();
								flag = false;
							} else if (userImage.type == "image/jpeg" || userImage.type == "image/png") {
								$('#uploadUserImageInUserPage').parent().parent().removeClass("error");
								$(".errEditUserProfilePictureInUserPage").hide();
							} else {
								$('#uploadUserImageInUserPage').parent().parent().addClass("error");
								$(".errEditUserProfilePictureInUserPage").html('Please upload image file of type png or jpeg ').show();
								flag = false;
							}

							
							
							formData.append('userImage', userImage);
							}
						}
						else {
							formData = "";
						}
						
						
						
						if (flag == false) {
							$('#editUserInUserPage1').modal('show');
							return false;
						} else {
							addedUserFunctionIds1.length = 0;
					    	 $('input[class="userFunction"]').each(function(k) {
					    		 var itm = $(this);
					    		 var data = $(this).attr('id');
					    		 var arr = data.split('_'); 
					    		 if ($(this).is(":checked")) {
					    			 addedUserFunctionIds1.push(arr[1]);
					    		 } 
					    		 
					    	 });
					    	 
					    	 console.log("addedUserFunctionIds1 : " + addedUserFunctionIds1 + " string : "+ addedUserFunctionIds1.toString());
					    		var manageEditedUserObj = {
					    				"userName" : loggedInUserName,
										"uName": editUserName,
										"newPassword":encodeURIComponent(editUserNewPassword),
										"fullName": editUserFullName, 
										"emailId": editUserEmailId,
										"department": encodeURIComponent(editUserDepartment),
										"editedUserId": userId,
										"oldPassword": encodeURIComponent(editUserOldPassword),
										"hiddenVariableForManageEditedUser":addedUserFunctionIds1
										
					    		};
					    		
					    		$('#hiddenInput_Edit').val(JSON.stringify(manageEditedUserObj));
					    		//formData.append("hiddenVariableForManageUser", JSON.stringify(manageUserObj));
					    		//formData.append('hiddenVariableForManageEditedUser', JSON.stringify(manageEditedUserObj));
					
					    		$.each(manageEditedUserObj, function(key, value){
					    			formData.append(key, value);
				    			})
				    			
							//alert(addedUserFunctionIds1);
					    		
					    		$.ajax({
									type : "PUT",
									url: "/repopro/web/user/updateUser",
									url: "/repopro/web/user/updateUser/?addedGroupIds="+ addedUserFunctionIds1,
									//url : "/repopro/web/user/updateUser/?userName="+ loggedInUserName+"&uName="+ editUserName+ "&newPassword="+ encodeURIComponent(editUserNewPassword) +"&fullName="+ editUserFullName+ "&emailId="+ editUserEmailId +"&department="+ encodeURIComponent(editUserDepartment) +"&userId="+ userId +"&oldPassword="+ encodeURIComponent(editUserOldPassword)+ "&addedGroupIds="+ addedUserFunctionIds1,
											contentType : "application/json",
										dataType : "json",
										data : formData,
										async : false,
										cache: false,
										processData : false,
										contentType : false,
										complete : function(data) {
											appenddata = "";
											var json = JSON.parse(data.responseText);
											if (json.status == "SUCCESS") {
												$('#fullName_' + userId).html(editUserFullName);
												$('#email_' + userId).html(editUserEmailId);
												$('#dept_' + userId).html(editUserDepartment);
												notifyMessage("Update Profile","Profile updated successfully","success");
												
												if($('input[id="uploadUserImageBtnInUserPage1"]').get(0).files[0]){
													var reader = new FileReader();
													
												    reader.onload = function(e) {
												      $('#userIcon_'+userId).attr('src', e.target.result);
												    }
				
						   							 reader.readAsDataURL($('input[id="uploadUserImageBtnInUserPage1"]').get(0).files[0]);
												} 
												
												//location.reload(true);
												
												
											} else {
												if (json.message == 'Password or user name entered is invalid, cannot update user password data') {
													$('#editUserOldPasswordInUserPage').parent().addClass("error");
													$(".errEditUserOldPasswordInUserPage").html('Password entered for the user name "'+ loggedInUserName + '" is invalid').show();
													flag = false;
												} else {
													$('#editUserOldPasswordInUserPage').parent().removeClass("error");
													$(".errEditUserOldPasswordInUserPage").hide();
													notifyMessage("Update Profile",json.message,"fail");
												}

											}
										}
									});

						}
						if (flag == false) {
							$('#editUserInUserPage1').modal('show');
							return false;
						} else {
							$('#editUserInUserPage1').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
							$('#editUserInUserPage1').modal('hide'); //.modal('hide dimmer');
							$('#editUserInUserPage1').parent().css("display", "none !important");
						}

					});*/

}
//get Associated Functions Details for user
function getUserAssociatedFunctionsDetailsInUserPage(groupId, groupName,chkboxMappedWithUser) {
	appendData = "";
	if(groupName != "Guest"){
	appendData += "<tr>";
	appendData += "<td class='hidden' id='functionId_"+groupId+"'>"+ groupId + "</td>";
	if (chkboxMappedWithUser == true) {
		appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllUserInUserPage(this)' type='checkbox' id='userAssociatedFunctionName_"+ groupId+"' class='userFunction' checked><label>"+groupName+"</label></div></td>";
	} else {
		appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllUserInUserPage(this)' type='checkbox'  id='userAssociatedFunctionName_"+ groupId+"' class='userFunction'><label>"+ groupName+"</label></div></td>";
	}
	appendData += "</tr>";
	}
	return appendData;
}
//check uncheck All Functions for user 

$(function(){

	// add multiple select / deselect functionality
	$("#selectAllUserAssociatedFunctionsInUserPage").click(function () {
		  $('.userFunction').attr('checked', this.checked);
	});

	// if all checkbox are selected, check the selectall checkbox
	// and viceversa
	$(".userFunction").click(function(){

		if($(".userFunction").length == $(".userFunction:checked").length) {
			$("#selectAllUserAssociatedFunctionsInUserPage").attr("checked", "checked");
		} else {
			$("#selectAllUserAssociatedFunctionsInUserPage").removeAttr("checked");
		}

	});
});

//check select all when all check box are checked
function checkSelectAllUserInUserPage(obj) {
	if (false == $(obj).prop('checked')) {
		$("#selectAllUserAssociatedFunctionsInUserPage").prop('checked', false);
	}
	if ($('.userFunction:checked').length == $('.userFunction').length) {
		$("#selectAllUserAssociatedFunctionsInUserPage").prop('checked', true);
	}
}

//souradip 10/11/17
//unlock User Account 
function unlockUserAccount(userId,userName){
	$.ajax({
		type : "PUT",
		url : '/repopro/web/user/updateLockStatus?userName='+userName,
			contentType : "application/json",
			dataType : "json",
			async : false,
			cache: false,
			complete : function(data) {
				appenddata = "";
				var json = JSON.parse(data.responseText);
				if (json.status == "SUCCESS") {
					
					notifyMessage("Unlock Profile","Profile with username '"+userName+"' is unlocked","success");
					$("#accountStatus_"+userId).html('<i class="icon green checkmark"></i><b style="color:#5ecc78;">Unlocked</b>');
					$("#trTable"+userId).removeClass("warning");
					
				} else {
					
					notifyMessage("Unlock Profile",json.message,"fail");
					
				}
			}
		});
}

//load data to hide and show ldap icon -- Hema 04.Dec.2017
function loadldapActiveInactiveFlag(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/globalsettings",
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
		var json = JSON.parse(data.responseText);
			if(json.result[0].globalLdapSettingFlag == 1){
				$('#showHideImportUserDataToExcelIcon').hide();
				$('#showHideLdapIcon').show();
			}
			else{
				$('#showHideLdapIcon').hide();
				$('#showHideImportUserDataToExcelIcon').show();
			}
		}
	});
}


/*open Ldap modal save the checked data -- Hema 04.Dec.2017*/
function addUsersFromLdap(){
	$('#addUsersFromLdapModal').modal('destroy');
	$('#ldapGrid143').hide();
	$('#noLdapSearchFound').hide();
	$('#searchLdapUsers123').val("");
 	$('#saveCheckedLdapDataButton').unbind();
	$('#cancelBtnLdapData').unbind();
	
	
	
	$('#addUsersFromLdapModal').modal({observeChanges : true}).modal('refresh').modal('show');                //.modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	 //$('#addUsersFromLdapModal').modal({detachable : false,observeChanges : true}).modal('refresh').modal('show');
	
	$('#searchLdapData').on('click', function(){
		var searchedEmpId = $('#searchLdapUsers123').val(); 
		$("input[id='selectAllUserIdChk']").prop("checked", false);
		$("input[class='chkClass']").prop("checked", false);
		
		if(searchedEmpId.trim() == "" || searchedEmpId.trim() == null){
			$('.searchTextErr ').show();
			$('#searchLdapUsers123').parent().addClass('error');
			return false;
		}
		else {
			$('.searchTextErr ').hide();
			$('#searchLdapUsers123').parent().removeClass('error');
		$.ajax({
			type : "GET",
			url : '/repopro/web/ldapmanager/getallldapusers?uid='+searchedEmpId.trim(),
			contentType : "application/json",
			dataType : "json",
			async : false,
			cache: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				appendData = "";
				if (json.status == "SUCCESS") {
					if(json.result == "" || json.result == null){
						$('#noLdapSearchFound').show();
						$('#ldapGrid143').hide();
					}
					else{
						$('#noLdapSearchFound').hide();
						$('#ldapGrid143').show();
						$.each(json.result, function(i) {
						showLdapDataInGrid(json.result[i].userId, json.result[i].firstName, json.result[i].lastName, json.result[i].email, json.result[i].dept);
						});
						$('#ldapUsersTable tbody').html("");
						$('#ldapUsersTable tbody').append(appendData);
					}

				} else {	
					notifyMessage("Search Users By Name",json.message,"fail");		
				}
			}
		});
		}
		
		
	});
	
	$("#saveCheckedLdapDataButton").on("click",function(){
		//<!-- CHANDANA 04-06-2019 KEYBOARD CONTROLS -->
		if($('#saveCheckedLdapDataButton').hasClass('disabled')){
			$("#saveCheckedLdapDataButton").blur(); 
			return false;
		}
		
		 var arrSaveCheckedLdapData = [];
		 var userId = ""; 
	     var firstname = ""; 
	     var lastname = ""; 
	     var emailId = "";
	     var dept = "";
	    	 
		$('#ldapUsersTable .chkClass').each(function(i, chk) {
		    if (chk.checked) {
		    	var currentRow = $(this).closest("tr"); 
		         userId = currentRow.find("td:eq(1)").text(); 
		         firstname = currentRow.find("td:eq(2)").text(); 
		         lastname = currentRow.find("td:eq(3)").text(); 
		         emailId = currentRow.find("td:eq(4)").text();
		         dept = currentRow.find("td:eq(5)").text();
		         
		         arrSaveCheckedLdapData.push({"userId":userId,
		 	    	"firstName": firstname,    		 
		 	    	"lastName":lastname, 
		 	    	"email":emailId,
		 	    	"dept":dept})
		    }
		   
		  });
		//console.log("arrSaveCheckedLdapData : " + JSON.stringify(arrSaveCheckedLdapData));
		$.ajax({
			type: "POST",
			url: "/repopro/web/ldapmanager/addUserFromLDAP",
			contentType : "application/json",
			dataType : "json",
			data : JSON.stringify(arrSaveCheckedLdapData),
			async: false,
			cache: false,
			complete:function(data){	
				var json = JSON.parse(data.responseText);
				$('#searchLdapUsers123').val("");
				if(json.status == "SUCCESS"){
					$('#addUsersFromLdapModal').dimmer('hide').modal('hide others').modal('hide').remove(); //.modal('hide dimmer');
					/*$('#addUsersFromLdapModal').modal('hide');
					$('#addUsersFromLdapModal').parent().css("display", "none !important");*/
					//loadUserDetails();
					notifyMessage('Add User from LDAP',json.result,'success');
					arrSaveCheckedLdapData.length = 0;
					$('.adminMainItem').click();
					$('.accessControlSubMenu').click();
					$('#adminAccContrlUsers1').click();
				}else if(json.message == 'Email already exists'){
					notifyMessage('Add User from LDAP',json.result,'fail');
				}else if(json.message == 'User name already exists'){
					notifyMessage('Add User from LDAP',json.result,'fail');	
				}else{
					notifyMessage('Add User from LDAP',json.message,'fail');
				}
			}
		});
	});
	
	
}

/*search users by name -- Hema 04.Dec.2017*/
/*function searchUsersByName(){
	$("input[id='selectAllUserIdChk']").prop("checked", false);
	$("input[class='chkClass']").prop("checked", false);
	

	var SearchedText = "";
	//$('#searchLdapUsers123').val("");
	
	
	SearchedText = $('#searchLdapUsers123').val(); //.trim();
	
	if(SearchedText == "" || SearchedText == null){
		$('.searchTextErr ').show();
		$('#searchLdapUsers123').parent().addClasss('error');
		return false;
	}
	else {
		$('.searchTextErr ').hide();
		$('#searchLdapUsers123').parent().removeClass('error');
	$.ajax({
		type : "GET",
		url : '/repopro/web/ldapmanager/getallldapusers?uid='+SearchedText,
		contentType : "application/json",
		dataType : "json",
		async : false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			appendData = "";
			if (json.status == "SUCCESS") {
				if(json.result == "" || json.result == null){
					$('#noLdapSearchFound').show();
					$('#ldapGrid143').hide();
				}
				else{
					$('#noLdapSearchFound').hide();
					$('#ldapGrid143').show();
					$.each(json.result, function(i) {
					showLdapDataInGrid(json.result[i].userId, json.result[i].firstName, json.result[i].lastName, json.result[i].email, json.result[i].dept);
					});
					$('#ldapUsersTable tbody').html("");
					$('#ldapUsersTable tbody').append(appendData);
				}

			} else {	
				notifyMessage("Search Users By Name",json.message,"fail");		
			}
		}
	});
	}
}*/

/* load the searched data -- Hema 04.Dec.2017*/
function showLdapDataInGrid(userId, firstName, lastName, emailId, dept){
	appendData += '<tr id="trLDAP_'+userId+'">';
	appendData += '<td class="one wide"><div class="ui checkbox"><input type="checkbox" id="chk_'+userId+'" onclick="chkAllLdapCheckboxes()" class="chkClass"> <label></label></div></td>';
	appendData += '<td class="two wide" id="userID_'+userId+'">'+userId+'</td>';
	appendData += '<td class="three wide" id="firstName_'+userId+'">'+firstName+'</td>';
	appendData += '<td class="three wide" id="lastName_'+userId+'">'+lastName+'</td>';
	appendData += '<td class="four wide" id="email_'+userId+'">'+emailId+'</td>';
    appendData += '<td class="three wide" id="dept_'+userId+'">'+dept+'</td>';
    appendData += '</tr>';
    return appendData;
}

// check or uncheck all checkboxes in ldap modal -- Hema 04.Dec.2017 
function chkAllLdapCheckboxes(){
	var checkedCount = "";
	var totalCount = "";
	$('.chkClass').each(function(i) {
		totalCount = i + 1;
		if ($(this).is(':checked')) {
			checkedCount = $("input[class='chkClass']:checked").length;
		}
	});
	
	if(checkedCount >= 1){
		$('#saveCheckedLdapDataButton').removeClass('disabled');
	}else{
		$('#saveCheckedLdapDataButton').addClass('disabled');
	}
	
	if (totalCount == checkedCount) {
		$("input[id='selectAllUserIdChk']").prop("checked", true);
	} else {
		$("input[id='selectAllUserIdChk']").prop("checked", false);
	}
}

// check all user Id if select all checkbox is checked - 05.Dec.2017
function chkAllUserId(){
	var chk = document.getElementById('selectAllUserIdChk');
	if (chk.checked) {
	$("input[class='chkClass']").prop("checked", true);
	$('#saveCheckedLdapDataButton').removeClass('disabled');
	}
	else{
		$("input[class='chkClass']").prop("checked", false);
		$('#saveCheckedLdapDataButton').addClass('disabled');
	}
}

/*Save checked data and send to backend -- Hema 04.Dec.2017*/
function saveCheckedLdapData(){
	 var arrSaveCheckedLdapData = [];
	 var userId = ""; 
     var firstname = ""; 
     var lastname = ""; 
     var emailId = "";
     var dept = "";
    	 
	$('#ldapUsersTable .chkClass').each(function(i, chk) {
	    if (chk.checked) {
	    	var currentRow = $(this).closest("tr"); 
	         userId = currentRow.find("td:eq(1)").text(); 
	         firstname = currentRow.find("td:eq(2)").text(); 
	         lastname = currentRow.find("td:eq(3)").text(); 
	         emailId = currentRow.find("td:eq(4)").text();
	         dept = currentRow.find("td:eq(5)").text();
	         
	         arrSaveCheckedLdapData.push({"userId":userId,
	 	    	"firstName": firstname,    		 
	 	    	"lastName":lastname, 
	 	    	"email":emailId,
	 	    	"dept":dept})
	    }
	   
	  });
	//console.log("arrSaveCheckedLdapData : " + JSON.stringify(arrSaveCheckedLdapData));
	$.ajax({
		type: "POST",
		url: "/repopro/web/ldapmanager/addUserFromLDAP",
		contentType : "application/json",
		dataType : "json",
		data : JSON.stringify(arrSaveCheckedLdapData),
		async: false,
		cache: false,
		complete:function(data){	
			var json = JSON.parse(data.responseText);
			$('#searchLdapUsers123').val("");
			if(json.status == "SUCCESS"){
				$('#addUsersFromLdapModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
				/*$('#addUsersFromLdapModal').modal('hide');
				$('#addUsersFromLdapModal').parent().css("display", "none !important");*/
				//loadUserDetails();
				notifyMessage('Add User from LDAP',json.result,'success');
				arrSaveCheckedLdapData.length = 0;
				$('.adminMainItem').click();
				$('.accessControlSubMenu').click();
				$('#adminAccContrlUsers1').click();
			}else if(json.message == 'Email already exists'){
				notifyMessage('Add User from LDAP',json.result,'fail');
			}else if(json.message == 'User name already exists'){
				notifyMessage('Add User from LDAP',json.result,'fail');	
			}else{
				notifyMessage('Add User from LDAP',json.message,'fail');
			}
		}
	});
}

/*Hema Filter manage users BOC */
//Search TextBox show
function showManageUserTextBoxToBeSearchedDiv(){
	$('#showHideManageUserSearchIcon').hide();
	$('#searchManageUserTextBoxDiv').show(750);
}

function showManageUserSearchIcon(){
	$('#searchManageUserTextBoxDiv').hide(750);
	setTimeout(function(){
		$('#showHideManageUserSearchIcon').show();
	}, 900)
	
}

// Show filtered asset lists in a grid
var searchedRange;
var userCount1;

function initialiseSearchUserData(){
	//alert('initialiseSearchData')
	//Swathi- 12.06.2020-  Customized user attribute search
	var searchedManageUserText = $('#filterManageUserInputField').val().trim();
	if(searchedManageUserText == "" || searchedManageUserText == null || searchedManageUserText == undefined){
		//$('#filterManageUserInputField').parent().addClass("error"); 
	    $("#errSearchVal").show();  
	}else{
		//$('#filterManageUserInputField').parent().removeClass("error"); 
		$("#errSearchVal").hide(); 
		infiniteScrollFlag = false;
		range1 = 0;
		infiniteScrollFlag1 = true;
		userCount1 = 0;
		userExportFlag = true;
		$('#tableUsers_filterSearch tbody').html("");
		showFilteredManageUsers();
	}
	
}

var exportAttributeString ;
var exportSearchString ;
var exportGroupList ;
function showFilteredManageUsers(){
	//alert(" showFilteredManageUsers rangevalue     "+range1);
	$('#noUserDataInDB1').hide();
	$('#usersGrid').hide();
	$('#usersGrid_filterSearch').show();
	var searchedManageUserText = $('#filterManageUserInputField').val();
	var url = "/repopro/web/user/filteredUsersForGrid?userName="+loggedInUserName+"&serachString="+encodeURIComponent(searchedManageUserText)+"&from="+range1;
	//Swathi-  User serach attribute-22.06.2020
	var searchURL = "/repopro/web/user/filteredUsersForGrid?userName="+loggedInUserName+"&serachString="+encodeURIComponent(searchedManageUserText)+"&from="+range1;
	var filterURL = "/repopro/api/user/filterUsersAttributesForGrid?userName="+loggedInUserName+"&attributeList="+attributeString+"&searchString="+encodeURIComponent(searchedManageUserText)+"&groupIds="+groupString+"&from="+range1;
	
	$.ajax({
			type : "GET",
			url : filterURL,
			dataType : "json",
			async: false,
			cache: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				 if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null){
						if(userCount1 == 0){
							infiniteScrollFlag1 = false;
							$('#noUserDataInDB1_filterSearch').show();
							$('#tableUsers_filterSearch').hide();
							$('#noUserDataInDB1_filterSearch').html('<div class="ui negative message">No matching result found.</div>');
							//$('#exportUserDataToExcel').remove();
						}else{
							infiniteScrollFlag1 = false;
							$('#loadingId_filterSearch').css('display', 'none');
						}
					
					}else {
							/*alert("elsse   ");*/
							$('#noUserDataInDB1_filterSearch').hide();
							$('#usersGrid_filterSearch').show();
							$('#tableUsers_filterSearch').show();
							$("#tableUsers tbody").empty();
							// console.log(" (json.result  "+JSON.stringify(json.result));
						
							$.each(json.result, function(i) {
							   
								var imageType = "";
								if(json.result[i].imageName != null){
									//imageType = (json.result[i].imageName).split('.');
									imageType = (json.result[i].imageName).substring((json.result[i].imageName).lastIndexOf(".") + 1, (json.result[i].imageName).length);
								}
								else{
									imageType = "default";
								}
								
								appendData = getUserDetails(json.result[i].userId,json.result[i].userName,json.result[i].fullName,json.result[i].emailId,json.result[i].department,imageType,json.result[i].lockStatus,json.result[i].native,json.result[i].imageName,json.result[i].encryptFullName,json.result[i].encryptEmailId,json.result[i].encryptDepartment,json.result[i].encryptImage);
								$('#tableUsers_filterSearch tbody').append(appendData);
								//console.log("len   "+$('#tableUsers_filterSearch tbody').length);
								userCount1++;
								var userId = json.result[i].userId;
								if(userId == 1){
									$("#trTable"+userId).remove();
								}
								if(json.result[i].activeFlag == 'Active' || json.result[i].activeFlag == 1){
									$("#enableDisableUser_"+userId).prop('checked',true);
									$('#userName_'+userId).parent().removeClass('disabled');
									$('#userIcon_'+userId).removeClass('disabled');
									$('#fullName_'+userId).removeClass('disabled');
									$('#email_'+userId).removeClass('disabled');
									$('#dept_'+userId).removeClass('disabled');
									$('#configureUser_'+userId).removeClass('disabled');
									$('#configureUserIcon_'+userId).removeClass('disabled');
									$('#editUser_'+userId).removeClass('disabled');
									$('#editUserIcon_'+userId).removeClass('disabled');
									$('#accountStatus_'+userId).removeClass('disabled');
									$('#accountStatus_'+userId).removeClass('disabled');
									$('#accountStatus_'+userId).find("i").removeClass('disabled');
									$('#accountStatus_'+userId).find("b").css("opacity", "1");
									$('#accountStatus_'+userId).find("button").removeClass('disabled');
		
								}
								else{
									$("#enableDisableUser_"+userId).prop('checked',false);
									$('#userName_'+userId).parent().addClass('disabled');
									$('#userIcon_'+userId).addClass('disabled');
									$('#fullName_'+userId).addClass('disabled');
									$('#email_'+userId).addClass('disabled');
									$('#dept_'+userId).addClass('disabled');
									$('#configureUser_'+userId).addClass('disabled');
									$('#configureUserIcon_'+userId).addClass('disabled');
									$('#editUser_'+userId).addClass('disabled');
									$('#editUserIcon_'+userId).addClass('disabled');
									$('#accountStatus_'+userId).addClass('disabled');
									$('#accountStatus_'+userId).find("i").addClass('disabled');
									$('#accountStatus_'+userId).find("b").css("opacity", "0.45");
									$('#accountStatus_'+userId).find("button").addClass('disabled');
								}
								
							
						});
						range1 = range1 + 20;
						
					}
					exportAttributeString = attributeString;
					exportSearchString = searchedManageUserText;
					exportGroupList = groupString;
					
				}
				else{
					//alert(" user failure");
					infiniteScrollFlag1 = false;
					$('#loadingId_filterSearch').css('display', 'none');
				}
				$('#showHideLoader').removeClass('active');
			}
		});
		$('#loadingId_filterSearch').css('display', 'none');
		scrollVisible(1);
	/*}else{
			//alert("else     gugf")
		   $('#selectAssetInstanceSubscriptionDropdown').dropdown('restore defaults');
		    console.log(" else part "); 
			range = 0; userCount = 0; infiniteScrollFlag : true;
		    loadUserDetails();
	}*/

}

function clearFilterUserTextBox(){
	$('#filterManageUserInputField').val("");	
	range = 0; userCount = 0; infiniteScrollFlag : true;
	userExportFlag = false;
	location.reload(true);
    //loadUserDetails();
	
}
/*EOC*/

var editUserOldPassword = "";
var editUserNewPassword = "";
var editUserConfirmNewPassword = "";

function validateForm(){
	
	editUserOldPassword = "";
	editUserNewPassword = "";
	editUserConfirmNewPassword = "";
	
		var editUserName = $("#editUserNameInUserPage").val().trim();
		var editUserFullName = $("#editUserFullNameInUserPage").val().trim();
		var editUserEmailId = $("#editUserEmailInUserPage").val().trim();
		var editUserDepartment = $("#editUserDepartmentInUserPage").val().trim();

		var userImage = $('input[id="uploadUserImageBtnInUserPage1"]').get(0).files[0];

		var flag = true;

		if (editUserFullName == null || editUserFullName == "") {
			$('#editUserFullNameInUserPage').parent().addClass("error");
			$(".errEditUserFullNameInUserPage").html('Please enter full name').show();
			flag = false;
		} else {
			var regex = /^[a-zA-Z- /./-]*$/;
			if (regex.test(editUserFullName) == false) {
				$('#editUserFullNameInUserPage').parent().addClass("error");
				$(".errEditUserFullNameInUserPage").html("Please use only alphabets, hyphen and dot in the full name field").show();
				flag = false;
			} else {
				$('#editUserFullNameInUserPage').parent().removeClass("error");
				$(".errEditUserFullNameInUserPage").hide();
			}
		}

		if (editUserEmailId == null || editUserEmailId == "") {
			$('#editUserEmailInUserPage').parent().addClass("error");
			$(".errEditUserEmailInUserPage").html('Please enter Email ID').show();
			flag = false;
		} else {
			 var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			 if(regex.test(editUserEmailId)){
				 $('#editUserEmailInUserPage').parent().removeClass("error");
				 $(".errEditUserEmailInUserPage").hide();
			 }else{
				$('#editUserEmailInUserPage').parent().addClass("error");
				$(".errEditUserEmailInUserPage").html('Please provide a valid email Id').show();
				flag = false;
			 }
			

		}

		if (editUserDepartment == null || editUserDepartment == "") {
			$('#editUserDepartmentInUserPage').parent().addClass("error");
			$(".errEditUserDepartmentInUserPage").show();
			editDeptFlag = false;
			flag = false;
		} else {
			
			 var iChars = "`!%^*=[];{}|<>?~";
			 //alert(" addUserDepartment  "+addUserDepartment.length);
			  for (var i = 0; i < editUserDepartment.length; i++){
			  	if (iChars.indexOf(editUserDepartment.charAt(i)) != -1){
			  		$("#editUserDepartmentInUserPage").parent().addClass("error");
			  		$(".errEditUserDepartmentInUserPage").show();
			  		$(".errEditUserDepartmentInUserPage").html("Special characters except ':'\"+#$/\&(),-_.@' are not allowed");  
			  		flag = false;
			  		editDeptFlag = false;
			  	}
			  }
			  if(editDeptFlag){
				  $('#editUserDepartmentInUserPage').parent().removeClass("error");
					$(".errEditUserDepartmentInUserPage").hide();
			  }

		}

		if ($("#changePasswordVisibleInUserPage").hasClass("passwordFieldVisible")) {
			var editUserOldPassword = $("#editUserOldPasswordInUserPage").val().trim();
			var editUserNewPassword = $("#editUserNewPasswordInUserPage").val().trim();
			var editUserConfirmNewPassword = $("#editUserConfirmNewPasswordInUserPage").val().trim();

			if (editUserOldPassword == null || editUserOldPassword == "") {
				$('#editUserOldPasswordInUserPage').parent().addClass("error");
				$(".errEditUserOldPasswordInUserPage").html('Please Enter Password.').show();
				flag = false;
			} else {
				$('#editUserOldPasswordInUserPage').parent().removeClass("error");
				$(".errEditUserOldPasswordInUserPage").hide();

			}

			if (editUserNewPassword == null || editUserNewPassword == "") {
				$('#editUserNewPasswordInUserPage').parent().addClass("error");
				$(".errEditUserNewPasswordInUserPage").html('Please Enter New Password.').show();
				flag = false;
			} else {
				if(editUserNewPassword.length > 7 && editUserNewPassword.match(/[A-z]/) && editUserNewPassword.match(/[A-Z]/) && editUserNewPassword.match(/\d/) && editUserNewPassword.match(/[!@#$%^&*]/)){
					$('#editUserNewPasswordInUserPage').parent().removeClass("error");
					$(".errEditUserNewPasswordInUserPage").hide();
				}else{
					$('#editUserNewPasswordInUserPage').parent().addClass("error");
					$(".errEditUserNewPasswordInUserPage").html('Password must be <br/> at least 8 characters long,<br/>include one lowercase letter,<br/> include one uppercase letter,<br/> include one number,<br/> include one special character !@#$%^&*').show();
					flag = false;
				}
				

			}

			if (editUserConfirmNewPassword == null || editUserConfirmNewPassword == "") {
				$('#editUserConfirmNewPasswordInUserPage').parent().addClass("error");
				$(".errEditUserConfirmNewPasswordInUserPage").html('Please confirm password').show();
				flag = false;

			} else {
				if (editUserConfirmNewPassword != editUserNewPassword) {
					$('#editUserConfirmNewPasswordInUserPage').parent().addClass("error");
					$(".errEditUserConfirmNewPasswordInUserPage").html('Passwords do not match').show();
					flag = false;
				} else {
					$('#editUserConfirmNewPasswordInUserPage').parent().removeClass("error");
					$(".errEditUserConfirmNewPasswordInUserPage").hide();
				}

			}

		} else {
			var editUserOldPassword = "";
			var editUserNewPassword = "";
		}
		
		if (typeof userImage == "undefined"){
			userImage = null;
		}
		
		
		var formData = new FormData();
		if (userImage != null) {
			if(userImage != null){
			var uploadImageSize = userImage.size / 1024;
			if (uploadImageSize > 1024) {
				$('#uploadUserImageInUserPage').parent().parent().addClass("error");
				$(".errEditUserProfilePictureInUserPage").html('Image size should not exceed 1 MB').show();
				flag = false;
			} else if (userImage.type == "image/jpeg" || userImage.type == "image/png") {
				$('#uploadUserImageInUserPage').parent().parent().removeClass("error");
				$(".errEditUserProfilePictureInUserPage").hide();
			} else {
				$('#uploadUserImageInUserPage').parent().parent().addClass("error");
				$(".errEditUserProfilePictureInUserPage").html('Please upload image file of type png or jpeg ').show();
				flag = false;
			}

			
			
			//formData.append('userImage', userImage);
			}
		}
		/*else {
			formData = "";
		}*/
		
		
		
		if (flag == false) {
			$('#editUserInUserPage1').modal('show');
			return false;
		} else {
			$('#submitEditedGrpData').click();
			return true;
		}
			
		

}

var addedUserFunctionIds1 = [];
function saveGrpDetails(){
	addedUserFunctionIds1.length = 0;
	 $('input[class="userFunction"]').each(function(k) {
		 var itm = $(this);
		 var data = $(this).attr('id');
		 var arr = data.split('_'); 
		 if ($(this).is(":checked")) {
			 addedUserFunctionIds1.push(arr[1]);
		 } 
		 
	 });
	 
	//Swathi- Encrpytion checkbox value on click of Update- 23.12.2019
		var encryptUserFullName=0 ;
		var encryptUserEmailId=0;
		var encryptUserDept=0;
		var encryptImg=0;
		 if( $('#encryptFullNameEdit').prop("checked") == true ) {	
			encryptUserFullName="1";
		} else {
			encryptUserFullName="0";
		}
		if( $("#encryptEmailIdEdit").prop("checked") == true){
			encryptUserEmailId="1";
		} else {
			encryptUserEmailId="0";
		}
		if ($("#encryptDepartmentEdit").prop("checked") == true){
			encryptUserDept="1";
		} else {
			encryptUserDept="0";
		}
		if($("#encryptImageEdit").prop("checked") == true){
			encryptImg="1";
		} else {
			encryptImg="0";
		}
	 
	 	var editUserName = $("#editUserNameInUserPage").val().trim();
		var editUserFullName = $("#editUserFullNameInUserPage").val().trim();
		var editUserEmailId = $("#editUserEmailInUserPage").val().trim();
		var editUserDepartment = $("#editUserDepartmentInUserPage").val().trim();

		var userImage = $('input[id="uploadUserImageBtnInUserPage1"]').get(0).files[0];
		
		
		
		var manageEditedUserObj = {
				"userName" : loggedInUserName,
				"uName": editUserName,
				"fullName": editUserFullName,
				"emailId": editUserEmailId,
				"department": encodeURIComponent(editUserDepartment),
				"oldPassword": encodeURIComponent(editUserOldPassword),
				"newPassword":encodeURIComponent(editUserNewPassword),
				
				"editedUserId": globaluserId,
				"addedUserFunctionIds1":addedUserFunctionIds1.toString(),
				"encryptFullName":encryptUserFullName,//Encrption checkbox values
				"encryptEmailId":encryptUserEmailId,
				"encryptDepartment":encryptUserDept,
				"encryptImage":encryptImg
		};
		
		//console.log("addedUserFunctionIds1 : " + addedUserFunctionIds1 + " string : "+ addedUserFunctionIds1.toString());
		
	 $('#hiddenInput_Edit').val(JSON.stringify(manageEditedUserObj));
}

//BOC - Swathi- Encryption- Encrypt all option - 24.12.2019
$("#encryptAll").click(function(){
	if($("#encryptAll").prop("checked")== true){
		$(".encryptRed").not(':disabled').attr("checked",true);
	} else {
		$(".encryptRed").attr("checked",false);
	}
	
});

$(".encryptRed").click(function(){
	if($(".encryptRed").prop("checked")== false){
		$("#encryptAll").attr("checked",false);
	}
	if ($('.encryptRed:checked:visible').length == $('.encryptRed:visible').length) {
		$("#encryptAll").attr("checked",true);
	} else{
		$("#encryptAll").attr("checked",false);
	}
});

$("#encryptAllC").click(function(){
	if($("#encryptAllC").prop("checked")== true){
		$(".encryptRedC").not(':disabled').attr("checked",true);
		
	} else {
		$(".encryptRedC").attr("checked",false);
	}
	
});

$(".encryptRedC").click(function(){
	if($(".encryptRedC").prop("checked")== false){
		$("#encryptAllC").attr("checked",false);
	}
	if ($('.encryptRedC:checked:visible').length == $('.encryptRedC:visible').length) {
		$("#encryptAllC").attr("checked",true);
	}else{
		$("#encryptAllC").attr("checked",false);
	}
});
//EoC- Swathi

/** Swathi- Get all group names - 12.06.2020**/
//load group data from database 
var appendData ;
function loadGroupsDetails(){
	appendData = "";
	$.ajax({
		type : "GET",
		url : "/repopro/web/groupmanager/getallgroups",
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			appendData = '<optgroup label="Group Names" id="Group Names">';
			$.each(json.result,function(i){
				appendData += '<option value="'+ json.result[i].groupId+'">'+json.result[i].groupName +'</option>';
			});
		}
	});
}

var attributeString ="";
var groupString = "";
function applyFilterVal(){
	var val = $("#filterBy").val();
	var attributeList =[];
	var groupList = [];
	if(val != null){
		for(i=0;i<val.length;i++){
			switch(val[i]) {
			  case "000001":
				  attributeList.push("UserName");
			   	break;
			  case "000002":
				  attributeList.push("FullName");
			    break;
			  case "000003":
				  attributeList.push("EmailId");
			    break;
			  case "000004":
				  attributeList.push("Department");
			    break;
			  case "000005":
				  attributeList.push("IncludeInActiveUser");
			    break;		  
			  default:
				  groupList.push(val[i]);		 
			}
		}
	}
	
	$(".userdrop button span").css("opacity", "1");
	$("#usersGrid").click();	
	if((attributeList.length == 0 && groupList.length !=0) ||(attributeList.length == 1 && attributeList ==  "IncludeInActiveUser") ){
		attributeList = [];
		attributeList.push("UserName","FullName", "EmailId","Department", "IncludeInActiveUser");
	}
	 attributeString = attributeList.join();
	 groupString = groupList.join();
}

$( "#filterBy" ).change(function() {
	$(".userdrop button span").css("opacity", "0");
});