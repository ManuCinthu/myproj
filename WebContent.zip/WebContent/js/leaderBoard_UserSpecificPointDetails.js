appendData = "";
formRange = 0;
dataCount = 0;
infiniteScrollFlag = true;
leaderBoardHeaderName = true;
userId = '';
function  loadLeaderBoardViewDetailsUserSpecific(){
	//$("#viewAllLeaderBoardTable").hide();
	//$('#showHideLoader').removeClass('active');
	$("#viewLeaderBoardUserSpecificDetails").show();
	//setTimeout(function(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/gameDetails/gamificationDetailsByUserId?userId="+userId+"&from="+formRange+"&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					if(dataCount == 0){
						$('#leaderBoardUserSpecificGridViewAll').hide();
						$('#noLeaderBoardUserSpecificGridData').show();
						$('#noLeaderBoardUserSpecificGridData').html('<div class="ui message">Leader board details not yet available</div>'); 
						//$("#menu-share").hide();
						//$("#exportDetailsLeaderboard").hide();
						$('#leaderBoardUserSpecificloadingId').css('display', 'none');
						infiniteScrollFlag = false;
						leaderBoardHeaderName = false;
						
						//$('#assetInstancesFloatingIcons').html("");
					}else{
						infiniteScrollFlag = false;
						leaderBoardHeaderName = false;
						$('#leaderBoardUserSpecificloadingId').css('display', 'none');
					}
				}else{
					$('#noLeaderBoardUserSpecificGridData').hide();
					$('#leaderBoardUserSpecificGridViewAll').show();
					if(leaderBoardHeaderName == true){
						$('#headingName').append(" - <b>"+json.result[0].fullName+"</b>");
						leaderBoardHeaderName = false;
					}
					
					$.each(json.result, function(i) {
						appendData = getLeaderBoardDetailsUserSpecific(json.result[i].activityTimestamp,json.result[i].fullName,json.result[i].action,json.result[i].field,json.result[i].assetName,json.result[i].assetInstanceName,json.result[i].assetInstanceVersionName,json.result[i].points,json.result[i].userId,json.result[i].assetInstanceVersionId);
						$('#tableLeaderBoardUserSpecific tbody').append(appendData);
						dataCount++;
						
					});
				}
				formRange = formRange + 20;
				
			}else{
				//$('#assetInstancesFloatingIcons').html("");
				infiniteScrollFlag = false;
				$('#leaderBoardUserSpecificloadingId').css('display', 'none');
			}
			$('#showHideLoader').removeClass('active');
		}
	});
	//}, 3000);
	$('#leaderBoardUserSpecificloadingId').css('display', 'none');
}

function getLeaderBoardDetailsUserSpecific(date,fullname,action,field,assetName,assetInstanceName,versionName,points,userId,assetInstanceVersionId){
	//var date = date.split(" ")[0];
	var encodedAssetInstName= encodeURIComponent(assetInstanceName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	
	appendData = '';
	appendData += '<tr>';
	appendData += '<td class="one wide hidden">'+userId+'</td>';
	/*appendData += '<td class="two wide"><i id="userIcon_1" class="circular inverted teal user icon accessGrpIcon"></i>'+fullname+'</td>';*/
	appendData += '<td class="two wide">'+date+'</td>';
	appendData += '<td class="two wide">'+action+'</td>';
	appendData += '<td class="one wide">'+field+'</td>';
	appendData += '<td class="two wide">'+assetName+'</td>';
	appendData += '<td class="three wide"><a style="cursor:pointer;" onclick="getAssetInstances('+assetInstanceVersionId+',\''+encodedAssetInstName+'\')">'+assetInstanceName+'</a></td>';
	appendData += '<td class="two wide center aligned">'+versionName+'</td>';
	appendData += '<td class="one wide center aligned">'+points+'</td>';
	appendData += '</tr>';
	return appendData;
}
