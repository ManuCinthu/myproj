appendData = "";
formRange = 0;
/*higherRange = 19;*/
dataCount = 0;
infiniteScrollFlag = true;
function loadLeaderBoardViewDetails(){
	$("#viewAllLeaderBoardTable").hide();
	$("#viewLeaderBoardDetails").show();
	
	$.ajax({
		type : "GET",
		url : "/repopro/web/gameDetails/pointDetails?from="+formRange+"&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			
			if(json.status == "SUCCESS"){
				
				if(json.result == "" || json.result == null){
					if(dataCount == 0){
						$('#leaderBoardGridViewAll').hide();
						$('#noLeaderBoardGridData').show();
						$('#noLeaderBoardGridData').html('<div class="ui message">Leader board details not yet available</div>'); 
						$("#menu-share").hide();
						$("#exportDetailsLeaderboard").hide();
						$('#leaderBoardloadingId').css('display', 'none');
						infiniteScrollFlag = false;
						
						$('#assetInstancesFloatingIcons').html("");
					}else{
						infiniteScrollFlag = false;
						$('#leaderBoardloadingId').css('display', 'none');
					}
				}else{
					$('#noLeaderBoardGridData').hide();
					$('#leaderBoardGridViewAll').show();
					
					$.each(json.result, function(i) {
						appendData = getLeaderBoardDetails(json.result[i].activityTimestamp,json.result[i].fullName,json.result[i].action,json.result[i].field,json.result[i].assetName,json.result[i].assetInstanceVersionId,json.result[i].assetInstanceName,json.result[i].assetInstanceVersionName,json.result[i].points,json.result[i].userId,json.result[i].imageName,json.result[i].encryptImage );
						$('#leaderBoardGridViewAll table tbody').append(appendData);
						dataCount++;
					});
				}
				formRange = formRange + 20;
				
			}else{
				$('#assetInstancesFloatingIcons').html("");
				infiniteScrollFlag = false;
				$('#leaderBoardloadingId').css('display', 'none');
			}
		}
	});
	$('#leaderBoardloadingId').css('display', 'none');
}

function exportDetailsLeaderBoard() {
	var con = confirm("Please confirm to start the export");
	if(con == true){
		window.location.href = '/repopro/web/export/exportInExcelGamificationPointViewDetails?userName='+loggedInUserName;
		notifyMessage("Leaderboard Export","Export process has started. You will receive the file through mail","success");
	}else return false;
}

function getLeaderBoardDetails(date,fullname,action,field,assetName,versionId,assetInstanceName,versionName,points,userId,userImg, encImg){
	//var date = date.split(" ")[0];
	
	var encodedAssetInstName= encodeURIComponent(assetInstanceName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");

	appendData = '';
	appendData += '<tr>';
	appendData += '<td class="one wide hidden">'+userId+'</td>';
	appendData += '<td class="two wide">';
	appendData += '<div class="ui left floated image">';
	if(userImg == null){
		appendData += '<img id="userId_'+userId+'" class="ui mini circular image" src="/repopro/semantic/images/avatar/defaultUserImage.png" style="margin-left: 2em;">';
	}else{
		
		/*var imageType = userImg.split(".");
		imageType = imageType[1];*/
		imageType = (userImg).substring((userImg).lastIndexOf(".") + 1, (userImg).length);
		if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
			imageType = imageType.toLowerCase()
		}
		if((encImg==1) && (fullname != loggedInUserFullName) && (loggedMapRoleFlag == 0)){//Swathi- Encryption- 07.01.2020
			appendData += '<img id="userId_'+userId+'" class="ui mini circular image" src="/repopro/semantic/images/avatar/defaultUserImage.png" style="margin-left: 2em;">';
		} else{
		appendData += '<img id="userId_'+userId+'" class="ui mini circular image" src="/repopro/profileImages/'+userId+'.'+imageType+'" style="margin-left: 2em;">';
	}
	}
	
	appendData += '</div><div style="text-align: left;">'+fullname+'</div></td>';
	/*appendData += '<td class="two wide"><i id="userIcon_1" class="circular inverted teal user icon accessGrpIcon"></i>'+fullname+'</td>';*/
	appendData += '<td class="two wide">'+date+'</td>';
	appendData += '<td class="two wide center aligned">'+action+'</td>';
	appendData += '<td class="one wide center aligned">'+field+'</td>';
	appendData += '<td class="two wide center aligned">'+assetName+'</td>';
/*	appendData += '<td class="three wide center aligned">'+assetInstanceName+'</td>';
*/	appendData += '<td class="three wide center aligned"><a  style="cursor: pointer;" onclick="getAssetInstances('+versionId+',\''+encodedAssetInstName+'\')">'+assetInstanceName+'</a></td>';
	appendData += '<td class="two wide center aligned">'+versionName+'</td>';
	appendData += '<td class="one wide center aligned">'+points+'</td>';
	appendData += '</tr>';
	return appendData;
}