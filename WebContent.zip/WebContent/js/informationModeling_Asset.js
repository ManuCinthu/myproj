// load data on load
	appendData = "";
	function loadAssetData(){
		
		$.ajax({
			type : "GET",
			url : "/repopro/web/assetType/getallassets",
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null){
						$('#assetGrid').hide();
						$('#noAssetGridData').show();
						$('#noAssetGridData').html('<div class="ui message">No assets added yet</div>'); 
					}else {
						$('#noAssetGridData').hide();
						$('#assetGrid').show();
						$('#assetGrid table tbody').html("");
							$.each(json.result, function(i) {
								var imageName = "default";
								if(json.result[i].iconImageName != null){
									var imageType = json.result[i].iconImageName;
									imageName = (json.result[i].iconImageName).substring((json.result[i].iconImageName).lastIndexOf(".") + 1, (json.result[i].iconImageName).length);
									//Chandana broken image issue - 13-9-2019
									if (imageName == 'PNG' || imageName == 'JPEG' || imageName == 'JPG'){
										imageName = imageName.toLowerCase()
									}	
								}
								
								appendData = getAssetDetails(json.result[i].assetId,json.result[i].assetName,json.result[i].description,json.result[i].flagForAssetUsageInRule,imageName,json.result[i].flagForAssetUsageInAssetListRule);
								$('#assetGrid table #assetGridTbody').append(appendData);
							});

							}
						}
						$('#showHideLoader').removeClass('active');
					}
				});
	}

	//append asset data to grid 
	function getAssetDetails(assetId,assetName,description,flagForAssetUsageInRule,imageName,flagForAssetUsageInAssetListRule){
		
		var data = "<p>Are you sure you want to delete "+assetName+" ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeAssetGridPopup("+assetId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteAsset(this,"+assetId+")'>Yes</button> ";
		appendData = "";
		appendData += '<tr id="trManageRole'+assetId+'">';
		appendData += '<td class="hidden" id="assetId_'+ assetId +'">' + assetId + '</td>';
		appendData += '<td class= "whitespaceNoTrim" id="assetName_'+assetId+'">';
		var icon = "";
		
		
		if(imageName == "default"){
			if(circularThemeColoredIcon){
				icon += '<div class="mediumIconImageCircleStyle_asset_themeCircle">';
				if(invertAssetIconFlag){
					icon += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png"></div>';
				}else{
					icon += '<image class="ui  image mediumIconImageStyle_themeCircle"  src="/repopro/semantic/images/defaultAssetIcon.svg"></div>';
				}
			}else{
				icon += '<div class="mediumIconImageCircleStyle_asset">';
				if(invertAssetIconFlag){
					icon += '<image class="ui  image mediumIconImageStyle invertImageColor" style="margin-top: 16% !important;" src="/repopro/semantic/images/inverted_defaultAssetIcon.png"></div>';
				}else{
					icon += '<image class="ui  image mediumIconImageStyle" style="margin-top: 16% !important;" src="/repopro/semantic/images/defaultAssetIcon.svg"></div>';
				}
			}
			
			/*icon += '<div class="mediumIconImageCircleStyle mediumIconImageCircleRemove">';
			icon += '<image class="ui circular image mediumIconImageStyle" style="margin-top: 16% !important;" src="/repopro/semantic/images/defaultAssetIcon.svg"></div>';
			*/
		}
		else{
			if(circularThemeColoredIcon){
				icon += '<div class="mediumIconImageCircleStyle_asset_themeCircle">';
				if(invertAssetIconFlag){
					icon += '<image class="ui  image mediumIconImageStyle_themeCircle invertImageColor"  src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'"></div>';
				}else{
					icon += '<image class="ui  image mediumIconImageStyle_themeCircle"  !important;" src="/repopro/assetImages/'+assetId+'.'+imageName+'"></div>';
				}
			}else{
				icon += '<div class="mediumIconImageCircleStyle_asset">';
				if(invertAssetIconFlag){
					icon += '<image class="ui  image mediumIconImageStyle invertImageColor" style="margin-top: 16% !important;" src="/repopro/assetImages/inverted_'+assetId+'.'+imageName+'"></div>';
				}else{
					icon += '<image class="ui  image mediumIconImageStyle" style="margin-top: 16% !important;" src="/repopro/assetImages/'+assetId+'.'+imageName+'"></div>';
				}
			}
			/*icon += '<div class="mediumIconImageCircleStyle_asset">';
			icon += '<image class="ui  image mediumIconImageStyle" style="margin-top: 16% !important;" src="/repopro/assetImages/'+assetId+'.'+imageName+'"></div>';
		*/
		}

		appendData += '<div>'+icon+'<span style="margin-left: 1.5em;vertical-align: -webkit-baseline-middle;">'+assetName+'</span></div>';
		appendData += '<td class= "whitespaceNoTrim" id="assetDescription_'+assetId+'">'+ description + '</td>';
		appendData += '<td class=""><a><i class="edit icon deleteEditIcon" onclick="editManageAsset('+assetId+',\''+assetName+'\')"></i></a></td>';
		if(flagForAssetUsageInRule == true || flagForAssetUsageInAssetListRule == true){
			appendData += '<td class="disabled disableDeleteIcon" ><span  data-tooltip="Cannot delete this asset. Asset parameter used in rule." data-position="left center"><i class="trash icon" id="trash_'+assetId+'"></i></span></td>';
		}
		else {
			appendData += '<td class=""><a><i class="trash icon deleteEditIcon" id="trash_'+assetId+'" data-html="'+data+'" onclick="openDeleteAssetPopup('+assetId+')"></i></a></td>';
		}
		appendData += '</tr>';
		return appendData;
	}


//kavya
/*function editManageAsset(assetId,assetName){
	localStorage.removeItem("editAsset");
	localStorage.setItem("editAsset","editAsset");
	localStorage.setItem("editAssetId",assetId);
	localStorage.setItem("editAssetName",assetName);
	$('#showHideLoader').addClass('active');
	$('#loadContent').load('informationModeling_Asset_CreateNewAsset.html');
	$('#headingName').html("Edit Asset");
	$('#headingName').parent().show();
	$("html, body").animate({scrollTop: 0}, 10);
	$('#breadcrumbData').html('<a class="section" onclick="getHomeDetails(this)">Home</a><i class="right chevron icon divider"></i>'+
			'<a class="section" onClick="getAssetsDetails()">Assets</a><i class="right chevron icon divider"></i><div class="active section">Edit Asset</div>');
	
}*/


//delete role confirmation popup
function openDeleteAssetPopup(assetId){
	$("#trash_"+assetId)
	.popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	})
	.popup('show');
}
//close delete role popup
function closeDeleteAssetPopup(assetId){
		$("#trash_"+assetId).popup('hide');
}

function deleteAsset(obj,assetId){
	var assetName = $('#assetName_'+assetId).text();
	$.ajax({
	   	type: "DELETE", 
	       url: "/repopro/web/assetType/deleteasset/"+assetId+"/"+assetName+"?userId="+loggedInUserId,
	       dataType: "json",
	       complete:function(data){										
				var json = JSON.parse(data.responseText);
				
				if(json.status == "FAILURE"){
					notifyMessage("Delete Asset", json.result, "fail");
				}
				else {
					notifyMessage("Delete Asset", "Asset deleted", "success");
					$('#trManageRole'+assetId).remove();
					loadQuickSearchDropdown();
					
					var rowCount = $('#tableAsset tr').length;
					if(rowCount == "1"){
						$('#assetGrid').hide();
						$('#noAssetGridData').show();
						$('#noAssetGridData').html('<div class="ui message">No assets added yet</div>'); 
					}else {
						$('#assetGrid').show();
						$('#noAssetGridData').hide();
					}
					//alert(rowCount);
					getBrowserAllAssets(this, 0);
				}
				closeDeleteAssetPopup(assetId);
	       }
  });
}

//close delete group popup
function closeAssetGridPopup(assetId){
	$("#trash_"+assetId).popup('hide');
}












