	formRange = 0;
	infiniteScrollFlag = false;
	selectedAssetID = "";
	countNoOfData = 0;
	setInstanceScrollFlag = true;
	// asset tab click
	$('#tab_Asset').on('click',function(){
		$.tab('change tab', 'first');
		$('.menu .item').removeClass('active tabsActiveColor');
		$(this).addClass('active tabsActiveColor');
		$('#ddAssets').html("");
		$('#showHideLoader').addClass('active');
		$('#searchAssetSubscriptionTextBoxDiv').show();
		$('#filterAssetSubscriptionInputField').val("");
		//$('#showHideAssetSubscriptionSearchIcon').show();
		
		var appendAssetDropdownOptions_Lists = "";
		
		/*appendAssetDropdownOptions_Lists += '<select class="ui dropdown subUnsubscribeDropdown" id="selectAssetSubscriptionDropdown">';*/
		appendAssetDropdownOptions_Lists += '<option value="Select Actions">All Assets</option>';
		appendAssetDropdownOptions_Lists += '<option value="Subscribed">Subscribed Assets</option>';
		appendAssetDropdownOptions_Lists += '<option value="Unsubscribed">Unsubscribed Assets</option>';
		/*appendAssetDropdownOptions_Lists += '</select>';*/
		
		
		$('#selectAssetSubscriptionDropdown').html(appendAssetDropdownOptions_Lists); 
		$('.subUnsubscribeDropdown').dropdown();
		
		loadSubscriptionAssetData();
	})
	
	// display asset data on load 
	var appendData = "";
	var dd_AssetInstance = [];
	function loadSubscriptionAssetData(){
		$('#manageAssetSubscriptionGrid_FilterAssetSubscription').hide();
		$('#noGridData_FilterAssetSubscription').hide();
		$.ajax({
			type : "GET", 
			url : "/repopro/web/assetType/getAllAssetsForSubscription?userId="+loggedInUserId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				appendData = "";
				dd_AssetInstance.length = 0;
				if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null){
						$('#manageAssetSubscriptionGrid').hide();
						$('.notifyMeChk').show();
						$('#noGridData').show();
						$('#noGridData').html('<div class="ui message" style="text-align:center;">No assets to display</div>');
						$('#searchAssetSubscriptionTextBoxDiv').hide(); // Hema 21 Feb 2018 Hide Filter Icon
					}else {
						$('#noGridData').hide();
						$('.notifyMeChk').show();
						$('#manageAssetSubscriptionGrid').show();
						$('#searchAssetSubscriptionTextBoxDiv').show(); // Hema 21 Feb 2018 Hide Filter Icon
						$('#manageAssetSubscriptionGrid table tbody').html("");
						$.each(json.result, function(i) {
							appendData = getAssetDetails(json.result[i].assetId, json.result[i].assetName, json.result[i].subscriptionFlag, json.result[i].notifyFlag, json.result[i].iconImageName);
							$('#manageAssetSubscriptionGrid table tbody').append(appendData);
							dd_AssetInstance.push({"assetId":json.result[i].assetId,"assetName":json.result[i].assetName});
						});				
						
					}
				}
				$('#showHideLoader').removeClass('active');
			}
		});
	}
	
	function getAssetDetails(assetId, assetName, subscribeUnsubscribeFlag, notifyFlag, iconImageName){
		
		if(notifyFlag == true){
			$('#chkboxnotifyFlag').attr('checked',true);
		}else {
			$('#chkboxnotifyFlag').attr('checked',false);
		}
		appendData ="";
		appendData +="<tr>";
		appendData +="<td class='one wide hidden' id='assetId_"+assetId+"'>"+assetId+"</td>";
		
		appendData += "<td class='eleven wide' id='assetName_"+assetId+"'>";
		
		if(iconImageName == null || iconImageName == ""){
			if(circularThemeColoredIcon){
				appendData += "<div class='mediumIconImageCircleStyle_asset_themeCircle' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle invertImageColor' src='/repopro/semantic/images/inverted_defaultAssetIcon.png'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle' src='/repopro/semantic/images/defaultAssetIcon.svg'></div>";
				}
			}else{
				appendData += "<div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle invertImageColor' src='/repopro/semantic/images/inverted_defaultAssetIcon.png'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle' src='/repopro/semantic/images/defaultAssetIcon.svg'></div>";
				}
			}
			
			
		
		}else{
			var imgExtension = iconImageName.split('.');
			//Chandana broken image issue - 13-9-2019
			if (imgExtension[1] == 'PNG' || imgExtension[1] == 'JPEG' || imgExtension[1] == 'JPG'){
				imgExtension[1] = imgExtension[1].toLowerCase()
			}
			
			if(circularThemeColoredIcon){
				appendData += "<div class='mediumIconImageCircleStyle_asset_themeCircle' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle invertImageColor' src='/repopro/assetImages/inverted_"+assetId+"."+imgExtension[1]+"'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle' src='/repopro/assetImages/"+assetId+"."+imgExtension[1]+"'></div>";
				}
			}else{
				appendData += "<div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle invertImageColor' src='/repopro/assetImages/inverted_"+assetId+"."+imgExtension[1]+"'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle' src='/repopro/assetImages/"+assetId+"."+imgExtension[1]+"'></div>";
				}
			}
			
			
		}
		appendData += "<span class='whitespaceNoTrim gridImageTextSpacing'>"+assetName+"<span></td>";
		appendData +="<td class='four wide'>";
		if(subscribeUnsubscribeFlag == "subscribed"){
			appendData +="<div class='toggleCheckBoxColor ui toggle checkbox'>";
			appendData +="<input type='checkbox' checked id='assetSubscribeUnsubscribeToggle_"+assetId+"' onclick='assetSubscribeUnSubscribe(this)' class='subUnsub'>";
			appendData +="<label></label>";
			appendData +="</div>";
		}
		else if(subscribeUnsubscribeFlag == "unsubscribed"){
			appendData +="<div class='toggleCheckBoxColor ui toggle checkbox'>";
			appendData +="<input type='checkbox' id='assetSubscribeUnsubscribeToggle_"+assetId+"' onclick='assetSubscribeUnSubscribe(this)' class='subUnsub'>";
			appendData +="<label></label>";
			appendData +="</div>";
		}
		appendData +="</td>";
		appendData +="</tr>";
		return appendData;
	}
	
	function assetSubscribeUnSubscribe(obj){
		var data = $(obj).attr('id');
		var assetId = data.split('_');
		var assetName = $('#assetName_'+assetId[1]).text();
		var subscribeUnsubscribeAsset = "";
		var messageBody;
		if(false == $(obj).prop('checked')){
			subscribeUnsubscribeAsset = "unsubscribe";
			messageBody = "Unsubscribed from " + assetName
		}
		else {
			subscribeUnsubscribeAsset = "subscribe";
			messageBody = "Subscribed to " + assetName 
		}
		$.ajax({
			type : "PUT",
			url : "/repopro/web/subscription/assetsubscription?userId="+loggedInUserId+"&assetId="+assetId[1]+"&subscriptionFlag="+subscribeUnsubscribeAsset,
			contentType : "application/json",
			Accept : "application/json",
			dataType : "json",
			async : false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage("Asset Subscriptions",messageBody,"success");
				}
				else {
					notifyMessage("Asset Subscriptions",json.message+"!","fail");
				}
			}
		});
	}
	
	// asset instance tab click
	$('#tab_AssetInstance').on('click',function(){
		
		$.tab('change tab', 'second');
		$('.menu .item').removeClass('active tabsActiveColor');
		$(this).addClass('active tabsActiveColor');
		$('#AssetInstances_noData').hide();
		$('#manageAssetInstancesSubscriptionGrid').hide();
		$('#searchAssetInstSubscriptionTextBoxDiv').hide();
		$('#manageAssetInstancesSubscriptionGrid_FilterSearch').hide();// added by aditya 16.03.18
		$('#AssetInstances_noData_FilterSearch').hide(); 
		//$('#ddAssets').dropdown({'set selected': "default"});
		//$('#searchAssetInstSubscriptionTextBoxDiv').hide(570);
		//$('#searchAssetInstSubscriptionTextBoxDiv').css({'overflow':'hidden'});
		var appendAssetDropdownOptions = "";

		appendAssetDropdownOptions += '<select class="ui dropdown ddAssetInstance" id="ddAssets" onchange="getAssetInstance(this.value)"><option value="" >Select Asset</option>';
	
		
		for(var h = 0; h < dd_AssetInstance.length; h++){
			appendAssetDropdownOptions += '<option value="'+ dd_AssetInstance[h].assetId + '">' + dd_AssetInstance[h].assetName + '</option>';
		}
		//$('#ddAssets').html('');
		//$('#ddAssets').prepend('<option value="">Select Asset</option>');
		//$('#ddAssets').append(appendAssetDropdownOptions);
		appendAssetDropdownOptions += '</select>';
		$('#selectInstDiv').html(appendAssetDropdownOptions);
		
		$('#ddAssets').dropdown();
		/*setTimeout(function () {
			$('#ddAssets').dropdown('set selected', 'Select Asset');
		}, 1);
		$('#ddAssets').prepend('<option value="Select Asset">Select Asset</option>');*/
	
	})	
	
	// taxonomy tab click
	taxTreeFlag = true;
	$('#tab_Taxonomy').on('click',function(){
		$("#hideTaxId").attr("checked", false);//aditya 02.04.18
		$('#showHideLoader').addClass('active');
		$.tab('change tab', 'third');
		$('.menu .item').removeClass('active tabsActiveColor');
		$(this).addClass('active tabsActiveColor');
		$('#AssetInstances_noData').hide();
		$('#manageAssetInstancesSubscriptionGrid').hide();
		$('#manageAssetSubscriptionGrid').hide();
		$('#noGridData').hide();
		//$('#showHideTaxonomySearchIcon').show();
		$('#searchTaxonomyTextBoxDiv').show();
		
	
		
		/* Hema 20 Feb 2018 BOC*/
		$('#showHideTaxonomySearchIcon').css({'visibility':'visible'});
		$('#tree2_Filter').hide();  /*#searchTaxonomyTextBoxDiv, */
		/* EOC*/
		
		// load tree
		var flag = true;
		$('#showHideLoader').removeClass('active');
		
		/* Hema 20 Feb 2018 BOC*/
		/*if(taxTreeFlag){
			taxTreeFlag = false;*/
			
			displayTaxonomiesOnLoad();
		//}
	
			/* EOC*/
	
		//to get unused taxonomies
		jQuery("#hideTaxId").change(function(e){
			if(jQuery('#hideTaxId').is(':checked')){
				$('#tree1').tree("destroy");
				showAllUnusedData();
				
			}else{
				displayTaxonomiesOnLoad();
			}
			
		/*	var taxinList = new Array;
			jQuery.ajax({
				url: '/repopro/web/taxonomy/getTaxonomiesUsedByAssets',
				dataType: "json",
				async: false,
				success: function(data){
					//var json = JSON.parse(data.responseText);
					console.log("SUCCESS : " + JSON.stringify(data));
					var json = JSON.parse(data.responseText);
					
					// actually here success is error portion and error is success (sending response in opposite way)
					var taxonIds = "";
					var taxonIdsSplitted = "";
					$.each(json.result, function(i) {
						taxonIds = json.result[i].label;
						taxonIdsSplitted = taxonIds.split('|');
						taxonIdsSplitted = taxonIdsSplitted[1];
						taxinList.push(parseInt(taxonIdsSplitted));
	
					})
					console.log("taxinList : " + taxinList);
					if(jQuery('#hideTaxId').is(':checked')){
						jQuery('.jqtree-title').each(function(e){
							var taxId = jQuery(this).next().attr('id');
							if(jQuery.inArray(parseInt(taxId),taxinList) == -1){
								jQuery(this).parent().parent().hide();
								jQuery(this).parent().parent().css('background-position','0 -1766px');
	
								if(jQuery(this).parent().parent().parent().parent().children().find('li').css('display') == 'none'){
									jQuery(this).parent().parent().parent().parent().children().find('a').hide();
								}
							}else{
								jQuery(this).parent().parent().show();
								jQuery(this).parent().parent().css('background-position','0 -1766px');
								jQuery(this).parent().parent().parent().parent().children().find('a').show();
							}
						});
					}
					else{
						jQuery('.jqtree-title').each(function(e){
							jQuery(this).parent().parent().show();
							jQuery(this).parent().parent().css('background-position','');
							jQuery(this).parent().parent().parent().parent().children().find('a').show();
						});
					}
					
					
	
				}, 
	
				error: function(err){
				
				}
			});*/
	
		});
		
		       jQuery(".jqtree-element").mouseover(function(e){
			   jQuery( this ).find( "span.spanClassTest" ).css('display','inline-block');
			   });
			   jQuery(".jqtree-element").mouseout(function(e){
			   jQuery( this ).find( "span.spanClassTest" ).css('display','none');
			   });
		 
	});
	
	function displayTaxonomiesOnLoad(){
		$('#tree1').tree("destroy");
		$('#tree2_Filter').tree("destroy");
		jQuery.ajax({
			type : "GET",
			url : '/repopro/web/taxonomy/getAllTaxonomiesWithSubcription?userId='+loggedInUserId,
			dataType : "json",
			contentType : 'application/json',
			async : false,
			cache : false,
			complete : function(data) {
				json = JSON.parse(data.responseText);
				$('#loadingDivTree').hide();	
				
				if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null){
						$('#tree1').hide();
						$('#searchTaxonomyTextBoxDiv').hide(); // hide filter Icon If no data present to display - Hema 20 Feb 2018
						$('#noTaxonomyData').show();
						$('#noTaxonomyData').html('<div class="ui message">There are no taxonomy added yet.</div>'); 
					}else {
						$('#noTaxonomyData').hide();
						$('#searchTaxonomyTextBoxDiv').show(); // show filter Icon If data is present - Hema 20 Feb 2018
						$('#tree1').show();
						$('#tree1').tree({
							data : json.result,
							autoOpen : false
						});
		
						var subscribeUnsubscribe = "";
						jQuery('.jqtree-title').each(function(e){
							var item = jQuery(this);
							item.css('display','inline-block');
							var valTax = jQuery(this).text();
							var valTax1 = valTax.split("|");
							var val = valTax1[0];
							var val1 = valTax1[1];
							subscribeUnsubscribe = valTax1[2];
							jQuery(this).text(val);
							item.parent().append("<span id="+val1+" class='someCls'></span>");
							if(subscribeUnsubscribe == "Yes"){
								item.parent().append("<span class='spanClassTest' style='display:none;'><i class='blue feed icon subscribe' onclick='subUnscribeValues(this,\""+val1+"\",\""+val+"\");' style='font-size:1.4em !important'></i></span>");
							}
							else {
								item.parent().append("<span class='spanClassTest' style='display:none;'><i class='grey feed icon unsubscribe' onclick='subUnscribeValues(this,\""+val1+"\",\""+val+"\");' style='font-size:1.4em !important'></i></span>");	
							}
							/* $(this).hover(function (h) {
							
							
							  });*/
							jQuery(this).addClass('showMode');
							jQuery(this).addClass('treeViewElement');
							jQuery(this).css('pointer','cursor');
							// $(this).prepend('<a class="jqtree_common noChildNodes"></a>');
						});
						
					}

				/*jQuery(".jqtree-title").hover(
									function() {
										if (flag == true) 
											if(subscribeUnsubscribe == "Yes"){
												jQuery(this).append("<span class='spanClassTest'><i class='blue feed icon subscribe' onclick='subUnscribeValues(this);' style='font-size:1.4em !important'></i></span>");
											}
											else {
												jQuery(this).append("<span class='spanClassTest'><i class='feed icon unsubscribe' onclick='subUnscribeValues(this);' style='font-size:1.4em !important'></i></span>");	
											}
											flag = false;
											jQuery(this).find("span:last").show();
									},
									function() {
										jQuery(this).find("span:last").remove();
										flag = true;

									});*/
					
				}
			}
		});
		
		jQuery(".jqtree-element").mouseover(function(e){
			   jQuery( this ).find( "span.spanClassTest" ).css('display','inline-block');
			   });
			   jQuery(".jqtree-element").mouseout(function(e){
			   jQuery( this ).find( "span.spanClassTest" ).css('display','none');
			   });
			   
	}
	
	//load data on selection of dropdown 
	function getAssetInstance(obj){
		//$('#selectAssetInstanceSubscriptionDropdown').dropdown('restore defaults'); //Added by aditya 16.03.18
		$('#selectAssetInstanceSubscriptionDropdown').hide();
		var drpDwnSubScrptn = '<select class="ui dropdown subUnsubscribeInstanceDropdown" id="selectAssetInstanceSubscriptionDropdown" onchange="AssetInstanceSubscriptionDropdownCallBack()">'+
		'<option value="Select Actions">All Assets Instance</option>'+
		'<option value="Subscribed">Subscribed Assets Instance</option>'+
		'<option value="Unsubscribed">Unsubscribed Assets Instance</option></select>';
		
		$("#sbScrptnDrpDwn").html(drpDwnSubScrptn);
		$('#filterAssetInstSubscriptionInputField').val("");
		//console.log("default val :: "+($('#selectAssetInstanceSubscriptionDropdown').dropdown('restore defaults')));
		var assetId = obj;
		if(assetId == "Select Asset"){
			$('#AssetInstances_noData').hide();
			$('#manageAssetInstancesSubscriptionGrid').hide();
			//$('#showHideAssetInstSubscriptionSearchIcon').hide();
			infiniteScrollFlag = false;
		}
		else {
			selectedAssetID	 = assetId;
			infiniteScrollFlag = true;
			countNoOfData = 0;
			formRange = 0;
			$('#manageAssetInstancesSubscriptionGrid').css('display', 'block').css('margin-top','2em');
			$('#manageAssetInstancesSubscriptionGrid table tbody').html("");
			//$('#showHideAssetInstSubscriptionSearchIcon').show();
			$('#searchAssetInstSubscriptionTextBoxDiv').show();
			loadAssetInstanceData(assetId);
		} 
		/*** Code for whitespace no trim ***/
		$("#ddAssets").parent().css("white-space", "pre-wrap");
	}
	
	
	//call the data and append
	function loadAssetInstanceData(selectedAssetID){
		$('#loadingId').show();
		$('#manageAssetInstancesSubscriptionGrid_FilterSearch').hide();
		$('#AssetInstances_noData_FilterSearch').hide();
		$('#selectAssetInstanceSubscriptionDropdown').dropdown();
		$.ajax({
			type : "GET",
			url : "/repopro/web/assetInstance/getallassetinstances?assetId="+selectedAssetID+"&userId="+loggedInUserId+"&from="+formRange,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				//console.log("json : " + JSON.stringify(json.result));
				appendData = "";
				if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null){
						if(countNoOfData == 0){
							$('#loadingId').css('display', 'none');
							infiniteScrollFlag = false;
							$('#manageAssetInstancesSubscriptionGrid').hide();
							$('#searchAssetInstSubscriptionTextBoxDiv').hide(); // Hema 21 Feb 2018 Hide Filter Icon
							$('#AssetInstances_noData').show();
							$('#AssetInstances_noData').html('<div class="ui message" style="text-align:center;">No asset instances to display</div>'); 
	
						}else{
							$('#loadingId').css('display', 'none');
							infiniteScrollFlag = false;
						}	
	
					}else {
						$('#AssetInstances_noData').hide();
						$('#manageAssetInstancesSubscriptionGrid').show();
						$('#searchAssetInstSubscriptionTextBoxDiv').show(); // Hema 21 Feb 2018 Hide Filter Icon
						
						$.each(json.result, function(i) {
							//if(setInstanceScrollFlag == true){
							appendData = createTbodyAssetInstances(selectedAssetID, json.result[i].assetInstanceId, json.result[i].assetInstanceName, json.result[i].subscriptionFlag, json.result[0].iconImageName);
							$('#manageAssetInstancesSubscriptionGrid table tbody').append(appendData);
							/*}
							else {
								appendData += createTbodyAssetInstances(selectedAssetID, json.result[i].assetInstanceName, json.result[i].subscriptionFlag, json.result[0].iconImageName);
							}*/
							countNoOfData++;
						});
						/*if(setInstanceScrollFlag == false){
						$('#manageAssetInstancesSubscriptionGrid table tbody').html(appendData);
						setInstanceScrollFlag = true;
						}*/
						formRange = formRange + 20;
	
						$('#loadingId').css('display', 'none');
						//$('#loadingId').show();
					}
				}
	
			}
		});
		//scrollVisible(0);
	}
	
	function createTbodyAssetInstances(assetId,assetInstanceId,assetName,subscribeUnsubscribeFlag, iconImageName){
		appendData ="";
		appendData +="<tr>";
		appendData +="<td class='one wide hidden' id='assetId_"+assetInstanceId+"'>"+assetInstanceId+"</td>";
		/*if(iconImageName == null || iconImageName == ""){
			appendData +="<td class='eleven wide' id='assetName_"+assetInstanceId+"'><div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'><img class='ui circular image mediumIconImageStyle' src='/repopro/semantic/images/defaultAssetIcon.svg'></div><span class='gridImageTextSpacing'>"+assetName+"</span></td>";
		}
		else{
			var imgExtension = iconImageName.split('.');
			appendData +="<td class='eleven wide' id='assetName_"+assetInstanceId+"'><div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'><img class='ui circular image mediumIconImageStyle' src='/repopro/assetImages/"+assetId+"."+imgExtension[1]+"'></div><span class='gridImageTextSpacing'>"+assetName+"</span></td>";
		}*/
		
		appendData += "<td class='eleven wide whitespaceNoTrim' id='assetName_"+assetId+"'>";
		
		if(iconImageName == null || iconImageName == ""){
			if(circularThemeColoredIcon){
				appendData += "<div class='mediumIconImageCircleStyle_asset_themeCircle' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle invertImageColor' src='/repopro/semantic/images/inverted_defaultAssetIcon.png'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle' src='/repopro/semantic/images/defaultAssetIcon.svg'></div>";
				}
			}else{
				appendData += "<div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle invertImageColor' src='/repopro/semantic/images/inverted_defaultAssetIcon.png'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle' src='/repopro/semantic/images/defaultAssetIcon.svg'></div>";
				}
			}
			
			
		
		}else{
			var imgExtension = iconImageName.split('.');
			//Chandana broken image issue - 13-9-2019
			if (imgExtension[1] == 'PNG' || imgExtension[1] == 'JPEG' || imgExtension[1] == 'JPG'){
				imgExtension[1] = imgExtension[1].toLowerCase()
			}
			
			if(circularThemeColoredIcon){
				appendData += "<div class='mediumIconImageCircleStyle_asset_themeCircle' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle invertImageColor' src='/repopro/assetImages/inverted_"+assetId+"."+imgExtension[1]+"'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle' src='/repopro/assetImages/"+assetId+"."+imgExtension[1]+"'></div>";
				}
			}else{
				appendData += "<div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle invertImageColor' src='/repopro/assetImages/inverted_"+assetId+"."+imgExtension[1]+"'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle' src='/repopro/assetImages/"+assetId+"."+imgExtension[1]+"'></div>";
				}
			}
			
			
		}
		
		appendData += "<span class='gridImageTextSpacing' id='assetInstanceName_"+assetInstanceId+"'>"+assetName+"<span></td>";
		
		appendData +="<td class='four wide'>";
		if(subscribeUnsubscribeFlag == "subscribed"){
			appendData +="<div class='toggleCheckBoxColor ui toggle checkbox'>";
			appendData +="<input type='checkbox' checked id='assetInstanceSubscribeUnsubscribeToggle_"+assetInstanceId+"' onclick='assetInstanceSubscribeUnSubscribe(this)' class='assetSubUnsub'>";
			appendData +="<label></label>";
			appendData +="</div>";
		}
		else if(subscribeUnsubscribeFlag == "unsubscribed"){
			appendData +="<div class='toggleCheckBoxColor ui toggle checkbox'>";
			appendData +="<input type='checkbox' id='assetInstanceSubscribeUnsubscribeToggle_"+assetInstanceId+"' onclick='assetInstanceSubscribeUnSubscribe(this)' class='assetSubUnsub'>";
			appendData +="<label></label>";
			appendData +="</div>";
		}
		appendData +="</td>";
		appendData +="</tr>";
		return appendData;
	}
	
	function assetInstanceSubscribeUnSubscribe(obj){
		
		var data = $(obj).attr('id');
		var assetInstanceId = data.split('_');
		var assetInstName = $('#assetInstanceName_'+assetInstanceId[1]).text();
		var subscribeUnsubscribeAssetInstance = "";
		var messageBody;
		if(false == $(obj).prop('checked')){
			subscribeUnsubscribeAssetInstance = "unsubscribe";
			messageBody = "Unsubscribed from " + assetInstName  
		}
		else{
			subscribeUnsubscribeAssetInstance = "subscribe";
			messageBody = "Subscribed to " + assetInstName 
		}
	
		$.ajax({
			type : "PUT",
			url : "/repopro/web/subscription/assetinstancesubscription?userId="+loggedInUserId+"&assetInstanceId="+assetInstanceId[1]+"&subscriptionFlag="+subscribeUnsubscribeAssetInstance,
			contentType : "application/json",
			Accept : "application/json",
			dataType : "json",
			async : false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage("Asset Instance Subscriptions",messageBody,"success");
				}
				else {
					notifyMessage("Asset Instance Subscriptions",json.message+"!","fail");
				}
			}
		});
	}
	
	//subscribe or unsubscribe 
	function subUnscribeValues(obj, taxId, taxName){
		var url = "";
		var notifyMessageTopic = "";
		var notifyMessageBody = "";
	
		if($(obj).hasClass('blue')){
			$(obj).removeClass("blue").addClass("grey");
			url = '/repopro/web/subscription/taxonomysubscription?userId='+loggedInUserId+'&taxonomyId='+taxId+'&subscriptionFlag=unsubscribe';
			notifyMessageTopic = "Taxonomy Subscriptions";
			notifyMessageBody = "Unsubscribed from the taxonomy " + taxName;
		}else{
			$(obj).removeClass("grey").addClass("blue");
			url = '/repopro/web/subscription/taxonomysubscription?userId='+loggedInUserId+'&taxonomyId='+taxId+'&subscriptionFlag=subscribe';
			notifyMessageTopic = "Taxonomy Subscriptions";
			notifyMessageBody = "Subscribed to the taxonomy " + taxName;
		}
	
		$.ajax({
			type : "PUT",
			url : url,
			dataType : "json",
			cache : false,
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					notifyMessage(notifyMessageTopic,notifyMessageBody,"success");
				}else{
					notifyMessage(notifyMessageTopic,"Error attempting to subscribe / unsubscribe to "+taxName,"fail")
				}
			}
		});
	}
	
	// notify user when new asset is created
	function notifyUserWhenNewAssetCreated(){
		var checkedNotifyValue = 0;
		if($('#chkboxnotifyFlag').is(':checked')){
			checkedNotifyValue = 1;
		}
		else {
			checkedNotifyValue = 0;
		}
		
		$.ajax({
			type : "PUT",
			url : "/repopro/web/user/updateSubscriptionFlag?userId="+loggedInUserId+"&flag="+checkedNotifyValue,
			dataType : "json",
			cache : false,
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(checkedNotifyValue == 1){
						notifyMessage("Asset Subscriptions","Subscribed for new asset creation notifications","success");
					}
					else {
						notifyMessage("Asset Subscriptions","Unsubscribed from new asset creation notifications!","success");
					}
					
				}else{
					notifyMessage("Asset Subscriptions",json.message,"fail");
				}
			}
		});
		
	}
	
	/*Hema Filter asset BOC -------------  Search TextBox show */
	/*function showAssetSubscriptionTextBoxToBeSearchedDiv(){
		$('#showHideAssetSubscriptionSearchIcon').hide();
		$('#searchAssetSubscriptionTextBoxDiv').show(570);
		$('.subUnsubscribeDropdown').dropdown();
		$('#searchAssetSubscriptionTextBoxDiv').css({'overflow':'visible'});
		$('#filterAssetSubscriptionInputField').val("");
	}

	function showAssetSubscriptionSearchIcon(){
		$('#searchAssetSubscriptionTextBoxDiv').hide(570);
		setTimeout(function(){
			$('#showHideAssetSubscriptionSearchIcon').show();
		}, 900)

	}*/

	$("#selectAssetSubscriptionDropdown").change(function(){
		var subUnsubscribeValue1 = $('.subUnsubscribeDropdown option:selected').val();
		$(this).dropdown('set selected',subUnsubscribeValue1);
		$('#manageAssetSubscriptionGrid_FilterAssetSubscription table tbody').html("");
		showFilteredAssetSubscriptions();
	});
	
	// Show filtered assets in a grid
	var subUnsubscribeValue = "";
	var searchString = "";
	function showFilteredAssetSubscriptions(){
		subUnsubscribeValue = "";
		subUnsubscribeValue = $('.subUnsubscribeDropdown option:selected').val();
		var subscriptionFlag;
		if(subUnsubscribeValue == "Subscribed"){
			subscriptionFlag = "true"
		}
		else if(subUnsubscribeValue == "Unsubscribed"){
			subscriptionFlag = "false"
		}
		else {
			subscriptionFlag = ""
		}
		searchString = "";
		searchString = $('#filterAssetSubscriptionInputField').val().trim();;
		
		$('#noGridData').hide();
		$('#manageAssetSubscriptionGrid').hide();
		
		// ajax call
		if(searchString != "" || subscriptionFlag != ""){
		$.ajax({
			type : "GET", 
			url : "/repopro/web/assetType/getAllFilteredAssetsForSubscription?userId="+loggedInUserId+"&searchString="+encodeURIComponent(searchString)+"&subscriptionFlag="+subscriptionFlag+"&userName="+loggedInUserName,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				//console.log("json ------------ : " + JSON.stringify(json));
				appendData = "";
				if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null){
						$('#manageAssetSubscriptionGrid_FilterAssetSubscription').hide();
						$('.notifyMeChk').show();
						$('#noGridData_FilterAssetSubscription').show();
						$('#noGridData_FilterAssetSubscription').html('<div class="ui message" style="text-align:center;">No assets to display</div>');
					}else {
						$('#noGridData_FilterAssetSubscription').hide();
						$('.notifyMeChk_FilterAssetSubscription').show();
						$('#manageAssetSubscriptionGrid_FilterAssetSubscription').show();
						$('#manageAssetSubscriptionGrid_FilterAssetSubscription table tbody').html("");
						$.each(json.result, function(i) {
							appendData = getAssetDetails(json.result[i].assetId, json.result[i].assetName, json.result[i].subscriptionFlag, json.result[i].notifyFlag, json.result[i].iconImageName);
							$('#manageAssetSubscriptionGrid_FilterAssetSubscription table tbody').append(appendData);
						});				
						
					}
				}
				$('#showHideLoader').removeClass('active');
			}
		});
		}
		else {
			//$('#selectAssetSubscriptionDropdown').dropdown('restore defaults');
			loadSubscriptionAssetData();
		}
		
	}

	
	// Filter asset Instance :  show Text box on filter Icon Click
	/*function showAssetInstSubscriptionTextBoxToBeSearchedDiv(){
		$('#showHideAssetInstSubscriptionSearchIcon').hide();
		$('#searchAssetInstSubscriptionTextBoxDiv').show(570);
		$('.subUnsubscribeInstanceDropdown').dropdown();
		$('#searchAssetInstSubscriptionTextBoxDiv').css({'overflow':'visible'});
		$('#filterAssetInstSubscriptionInputField').val("");
	}

	// Hide Text Box on Click of Close Icon And Show Filter Icon
	function showAssetInstSubscriptionSearchIcon(){
		$('#searchAssetInstSubscriptionTextBoxDiv').hide(570);
		setTimeout(function(){
			$('#showHideAssetInstSubscriptionSearchIcon').show();
		}, 900)

	}*/

	
	//$("#selectAssetInstanceSubscriptionDropdown").change(function(){
	function AssetInstanceSubscriptionDropdownCallBack(){
		var subUnsubscribeValue1 = $('#selectAssetInstanceSubscriptionDropdown option:selected').val();
		$("#selectAssetInstanceSubscriptionDropdown").dropdown('set selected',subUnsubscribeValue1);
		
		formRange1 = 0;
		countNoOfData1 = 0;
		infiniteScrollFlag = false;
		infiniteScrollFlag1 = true;
		$('#manageAssetInstancesSubscriptionGrid_FilterSearch table tbody').html("");
		showFilteredAssetInstSubscription();
	//});
	}
	
	
	// Show filtered assets - asset instance tab - in a grid
	var AssetInstance_searchString = "";
	var AssetInstance_subUnsubscribeValue="";
	formRange1 = 0;
	countNoOfData1 = 0;
	infiniteScrollFlag1 = false;
	
	function showFilteredAssetInstSubscriptionCall(){
		formRange1 = 0;
		countNoOfData1 = 0;
		infiniteScrollFlag = false;
		infiniteScrollFlag1 = true;
		$('#manageAssetInstancesSubscriptionGrid_FilterSearch table tbody').html("");
		showFilteredAssetInstSubscription();
	}
	
	function showFilteredAssetInstSubscription(){
		$('#manageAssetInstancesSubscriptionGrid').hide();
		$('#AssetInstances_noData').hide();
		
		/*formRange1 = 0;
		countNoOfData1 = 0;
		infiniteScrollFlag1 = false;*/
		
		var AssetId = $('#ddAssets option:selected').val();
		AssetInstance_searchString = "";
		AssetInstance_searchString = $('#filterAssetInstSubscriptionInputField').val().trim();
		
		
		AssetInstance_subUnsubscribeValue = "";
		AssetInstance_subUnsubscribeValue = $('#selectAssetInstanceSubscriptionDropdown option:selected').val();
		var subscriptionFlag = "";
		if(AssetInstance_subUnsubscribeValue == "Subscribed"){
			subscriptionFlag = 'true';
		}
		else if(AssetInstance_subUnsubscribeValue == "Unsubscribed"){
			subscriptionFlag = 'false';
		}
		else {
			subscriptionFlag = '';
		}
		
		var url = "/repopro/web/assetInstance/getAllFilteredAssetInstancesForSubscription?userName="+loggedInUserName+"&assetId="+AssetId+"&userId="+loggedInUserId+"&searchString="+encodeURIComponent(AssetInstance_searchString)+"&subscriptionFlag="+subscriptionFlag+"&from="+formRange1;
		console.log("url : " + url);
		if(AssetInstance_searchString != "" || subscriptionFlag != ""){
			$("#loadingId_FilterSearch").show();
			$.ajax({
				type : "GET",
				url : url,
				dataType : "json",
				async: false,
				complete : function(data) {
					var json = JSON.parse(data.responseText);
					//console.log("json INSTANCE DATA: " + JSON.stringify(json));
					appendData = "";
					if(json.status == "SUCCESS"){
						if(json.result == "" || json.result == null){
							if(countNoOfData1 == 0){

								$('#loadingId_FilterSearch').css('display', 'none');
								infiniteScrollFlag1 = false;
								$('#manageAssetInstancesSubscriptionGrid_FilterSearch').hide();
								$('#AssetInstances_noData_FilterSearch').show();
								$('#AssetInstances_noData_FilterSearch').html('<div class="ui message" style="text-align:center;">No asset instances to display</div>'); 
		
							}else{
								$('#loadingId_FilterSearch').css('display', 'none');
								infiniteScrollFlag1 = false;
							}	
		
						}else {
							
							infiniteScrollFlag1 = true;
							$('#AssetInstances_noData_FilterSearch').hide();
							$('#manageAssetInstancesSubscriptionGrid_FilterSearch').show();
/*							$('#manageAssetInstancesSubscriptionGrid_FilterSearch').show();
*/							
							$.each(json.result, function(i) {
								appendData = createTbodyAssetInstances_FilterSearch(AssetId, json.result[i].assetInstanceId, json.result[i].assetInstanceName, json.result[i].subscriptionFlag, json.result[0].iconImageName);
								$('#manageAssetInstancesSubscriptionGrid_FilterSearch table tbody').append(appendData);
								countNoOfData1++;
								
								
								
							});
							
							//$('#manageAssetInstancesSubscriptionGrid_FilterSearch table tbody').html("");
							//$('#manageAssetInstancesSubscriptionGrid_FilterSearch table tbody').html(appendData);
							
							formRange1 = formRange1 + 20;
		
							$('#loadingId_FilterSearch').css('display', 'none');

						}
					}
		
				}
			});
			//scrollVisible(1);
			}
			else {
				//$('#selectAssetInstanceSubscriptionDropdown').dropdown('restore defaults');
				formRange = 0; countNoOfData = 0; 
				infiniteScrollFlag = true; 
				appendData = "";
				infiniteScrollFlag1 = false;
				setInstanceScrollFlag = false;
				$('#manageAssetInstancesSubscriptionGrid table tbody').html("");
				loadAssetInstanceData(selectedAssetID);
			}
			
		
	}
	
function createTbodyAssetInstances_FilterSearch(assetId, assetInstanceId, assetName,subscribeUnsubscribeFlag, iconImageName){
		appendData ="";
		appendData +="<tr>";
		appendData +="<td class='one wide hidden' id='assetId_"+assetInstanceId+"'>"+assetInstanceId+"</td>";
		/*appendData += "<td class='eleven wide' id='assetName_"+assetInstanceId+"'>";
		
		
		if(iconImageName == null || iconImageName == ""){
			appendData += "<div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'>";
			appendData += "<img class='ui  image mediumIconImageStyle' src='/repopro/semantic/images/defaultAssetIcon.svg'></div>";
		}
		else{
			var imgExtension = iconImageName.split('.');
			
			appendData += "<div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'>";
			appendData += "<img class='ui  image mediumIconImageStyle' src='/repopro/assetImages/"+assetId+"."+imgExtension[1]+"'></div>";
		}
		
		appendData +="<td class='four wide'>";
		appendData += "<span style='margin-left: 2em !important;'>"+assetName+"</span></td>";*/
		
appendData += "<td class='eleven wide' id='assetName_"+assetId+"'>";
		
		if(iconImageName == null || iconImageName == ""){
			if(circularThemeColoredIcon){
				appendData += "<div class='mediumIconImageCircleStyle_asset_themeCircle' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle invertImageColor' src='/repopro/semantic/images/inverted_defaultAssetIcon.png'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle' src='/repopro/semantic/images/defaultAssetIcon.svg'></div>";
				}
			}else{
				appendData += "<div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle invertImageColor' src='/repopro/semantic/images/inverted_defaultAssetIcon.png'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle' src='/repopro/semantic/images/defaultAssetIcon.svg'></div>";
				}
			}
			
			
		
		}else{
			var imgExtension = iconImageName.split('.');
			//Chandana - 13-9-2019 Broken image
			if (imgExtension[1] == 'PNG' || imgExtension[1] == 'JPEG' || imgExtension[1] == 'JPG'){
				imgExtension[1] = imgExtension[1].toLowerCase()
			}
			if(circularThemeColoredIcon){
				appendData += "<div class='mediumIconImageCircleStyle_asset_themeCircle' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle invertImageColor' src='/repopro/assetImages/inverted_"+assetId+"."+imgExtension[1]+"'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle_themeCircle' src='/repopro/assetImages/"+assetId+"."+imgExtension[1]+"'></div>";
				}
			}else{
				appendData += "<div class='mediumIconImageCircleStyle mediumIconImageCircleRemove' style='margin-left: 20px;'>";
				if(invertAssetIconFlag){
					appendData += "<img class='ui image mediumIconImageStyle invertImageColor' src='/repopro/assetImages/inverted_"+assetId+"."+imgExtension[1]+"'></div>";
				}else{
					appendData += "<img class='ui image mediumIconImageStyle' src='/repopro/assetImages/"+assetId+"."+imgExtension[1]+"'></div>";
				}
			}
			
			
		}
		
		appendData += "<span class='gridImageTextSpacing' id='assetInstanceName_"+assetInstanceId+"'>"+assetName+"<span></td>";
		
		appendData +="<td class='four wide'>";
		if(subscribeUnsubscribeFlag == "subscribed"){
			appendData +="<div class='toggleCheckBoxColor ui toggle checkbox'>";
			appendData +="<input type='checkbox' checked id='assetInstanceSubscribeUnsubscribeToggle_"+assetInstanceId+"' onclick='assetInstanceSubscribeUnSubscribe(this)' class='assetSubUnsub'>";
			appendData +="<label></label>";
			appendData +="</div>";
		}
		else if(subscribeUnsubscribeFlag == "unsubscribed"){
			appendData +="<div class='toggleCheckBoxColor ui toggle checkbox'>";
			appendData +="<input type='checkbox' id='assetInstanceSubscribeUnsubscribeToggle_"+assetInstanceId+"' onclick='assetInstanceSubscribeUnSubscribe(this)' class='assetSubUnsub'>";
			appendData +="<label></label>";
			appendData +="</div>";
		}
		appendData +="</td>";
		appendData +="</tr>";
		return appendData;
	}
	
// Taxonomy 
/*function showTaxonomyTextBoxToBeSearchedDiv(){
	$('#showHideTaxonomySearchIcon').css({'visibility':'hidden'});
	$('#searchTaxonomyTextBoxDiv').show(570);
	$('#selectTaxonomyDropdown').dropdown();
	$('#searchTaxonomyTextBoxDiv').css({'overflow':'visible'});
	$('#filterTaxonomyInputField').val("");
}

// Hide Text Box on Click of Close Icon And Show Filter Icon
function showTaxonomySearchIcon(){
	$('#searchTaxonomyTextBoxDiv').hide(570);
	setTimeout(function(){
		$('#showHideTaxonomySearchIcon').css({'visibility':'visible'});
	}, 900)

}*/

$("#selectTaxonomyDropdown").change(function(){
	var subUnsubscribeValue1 = $('#selectTaxonomyDropdown option:selected').val();
	$(this).dropdown('set selected',subUnsubscribeValue1);
	showFilteredTaxonomy();
});

var taxonomy_subUnsubscribeValue = "";
function showFilteredTaxonomy(){
	$('#tree1').hide();
	//$('#showHideTaxonomySearchIcon').hide();
	
	var hideUnusedTaxFlag = false;
	if($('#hideTaxId').is(':checked')){
		hideUnusedTaxFlag = true;
	}else{
		hideUnusedTaxFlag = false;
	}
	
	
	//*****Edited by aditya 09.03.18
	var filterChar = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;
	var searchedTaxValue = filterChar.test( $('#filterTaxonomyInputField').val());//$('#filterTaxonomyInputField').val().trim();
	
	if(searchedTaxValue == true){
		searchedTaxValue = "";
	}else{
		searchedTaxValue =  $('#filterTaxonomyInputField').val();
	}
	//****Aditya over
	
	//var flag = true;
	$('#showHideLoader').removeClass('active');

	taxonomy_subUnsubscribeValue = "";
	taxonomy_subUnsubscribeValue = $('#selectTaxonomyDropdown option:selected').val();

	var subscriptionFlag = "";
	if(taxonomy_subUnsubscribeValue == "Subscribed"){
		subscriptionFlag = 'true';
	}
	else if(taxonomy_subUnsubscribeValue == "Unsubscribed"){
		subscriptionFlag = 'false';
	}
	else {
		subscriptionFlag = '';
	}

		if(searchedTaxValue != "" || subscriptionFlag != ""){
		$('#tree1').tree("destroy");
		$('#tree2_Filter').tree("destroy");
		jQuery.ajax({
			type : "GET",
			url : '/repopro/web/taxonomy/getFilteredTaxonomyForManageSubscription?userName='+loggedInUserName+'&searchString='+encodeURIComponent(searchedTaxValue)+'&subscriptionFlag='+subscriptionFlag+'&hideUnusedTaxFlag='+hideUnusedTaxFlag,
			dataType : "json",
			contentType : 'application/json',
			async : false,
			cache : false,
			complete : function(data) {
				json = JSON.parse(data.responseText);
				//console.log("json tax FILTER : " + JSON.stringify(json));
				$('#loadingDivTree').hide();	
				
				if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null){
						$('#tree2_Filter').hide();
						$('#showHideTaxonomySearchIcon').hide(); // hide filter Icon If no data present to display
						$('#noTaxonomyData').show();
						$('#noTaxonomyData').html('<div class="ui message">There are no taxonomy to display.</div>'); 
						
					}else {
						$('#noTaxonomyData').hide();
						$('#showHideTaxonomySearchIcon').show(); // show filter Icon If data is present
						$('#tree2_Filter').show();
						$('#tree2_Filter').tree({
							data : json.result,
							autoOpen : false
						});
		
						
						var subscribeUnsubscribe = "";
						jQuery('.jqtree-title').each(function(e){
							var item = jQuery(this);
							item.css('display','inline-block');
							var valTax = jQuery(this).text();
							var valTax1 = valTax.split("|");
							var val = valTax1[0];
							var val1 = valTax1[1];
							subscribeUnsubscribe = valTax1[2];
							jQuery(this).text(val);
							item.parent().append("<span id="+val1+" class='someCls'></span>");
							if(subscribeUnsubscribe == "Yes"){
								item.parent().append("<span class='spanClassTest' style='display:none;'><i class='blue feed icon subscribe' onclick='subUnscribeValues(this,\""+val1+"\",\""+val+"\");' style='font-size:1.4em !important'></i></span>");
							}
							else {
								item.parent().append("<span class='spanClassTest' style='display:none;'><i class='grey feed icon unsubscribe' onclick='subUnscribeValues(this,\""+val1+"\",\""+val+"\");' style='font-size:1.4em !important'></i></span>");	
							}
							jQuery(this).addClass('showMode');
							jQuery(this).addClass('treeViewElement');
							jQuery(this).css('pointer','cursor');
						});
						
					}
					
				}
			}
		});
		
		 jQuery(".jqtree-element").mouseover(function(e){
			   jQuery( this ).find( "span.spanClassTest" ).css('display','inline-block');
			   });
			   jQuery(".jqtree-element").mouseout(function(e){
			   jQuery( this ).find( "span.spanClassTest" ).css('display','none');
			   });
			   
		}
		else {
			$('#showHideTaxonomySearchIcon').css({'visibility':'hidden'});
			displayTaxonomiesOnLoad();
		}
	//}	
}

function clearFilterAssetTextBox(){
	$('#filterAssetSubscriptionInputField').val("");
	//$('#selectAssetSubscriptionDropdown').dropdown('restore defaults');
	//loadSubscriptionAssetData();
	showFilteredAssetSubscriptions();
}

function clearAssetInstTextBox(){
	//$('#selectAssetInstanceSubscriptionDropdown').dropdown('restore defaults');
	$('#filterAssetInstSubscriptionInputField').val("");
	formRange = 0; 
	countNoOfData = 0;
	infiniteScrollFlag : true;
	appendData = "";
	 formRange1 = 0;
	 countNoOfData1 = 0;
	 infiniteScrollFlag1 = false;
	 $('#manageAssetInstancesSubscriptionGrid_FilterSearch table tbody').html("");
	 setInstanceScrollFlag = false;
	 showFilteredAssetInstSubscription();
	 
	 /*	setInstanceScrollFlag = false;
		showFilteredAssetInstSubscription();*/
	 //loadAssetInstanceData(selectedAssetID);

}

function clearTaxonomyTextBox(){
	$('#showHideTaxonomySearchIcon').css({'visibility':'hidden'});
	$('#selectTaxonomyDropdown').dropdown('restore defaults');
	$('#filterTaxonomyInputField').val("");
	displayTaxonomiesOnLoad();
}

// show unused data
function showAllUnusedData(){
	$('#tree1').tree("destroy");
	$('#tree2_Filter').tree("destroy");
	var url = '/repopro/web/taxonomy/getAllTaxonomiesWithSubcriptionUsedByAsset?userName='+loggedInUserName;
	jQuery.ajax({
		type : "GET",
		url : url,
		dataType : "json",
		contentType : 'application/json',
		async : false,
		cache : false,
		complete : function(data) {
			json = JSON.parse(data.responseText);
			//console.log("json : " + JSON.stringify(json));
			$('#loadingDivTree').hide();	
			
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					$('#tree1').hide();
					$('#showHideTaxonomySearchIcon').hide(); // hide filter Icon If no data present to display - Hema 20 Feb 2018
					$('#noTaxonomyData').show();
					$('#noTaxonomyData').html('<div class="ui message">There are no taxonomy added yet.</div>'); 
				}else {
					$('#noTaxonomyData').hide();
					$('#showHideTaxonomySearchIcon').show(); // show filter Icon If data is present - Hema 20 Feb 2018
					$('#tree1').show();
					$('#tree1').tree({
						data : json.result,
						autoOpen : false
					});
	
					var subscribeUnsubscribe = "";
					jQuery('.jqtree-title').each(function(e){
						var item = jQuery(this);
						item.css('display','inline-block');
						var valTax = jQuery(this).text();
						var valTax1 = valTax.split("|");
						var val = valTax1[0];
						var val1 = valTax1[1];
						subscribeUnsubscribe = valTax1[2];
						jQuery(this).text(val);
						item.parent().append("<span id="+val1+" class='someCls'></span>");
						if(subscribeUnsubscribe == "Yes"){
							item.parent().append("<span class='spanClassTest' style='display:none;'><i class='blue feed icon subscribe' onclick='subUnscribeValues(this,\""+val1+"\",\""+val+"\");' style='font-size:1.4em !important'></i></span>");
						}
						else {
							item.parent().append("<span class='spanClassTest' style='display:none;'><i class='grey feed icon unsubscribe' onclick='subUnscribeValues(this,\""+val1+"\",\""+val+"\");' style='font-size:1.4em !important'></i></span>");	
						}
						jQuery(this).addClass('showMode');
						jQuery(this).addClass('treeViewElement');
						jQuery(this).css('pointer','cursor');
					});
					
				}

				
			}
		}
	});
	
	jQuery(".jqtree-element").mouseover(function(e){
		   jQuery( this ).find( "span.spanClassTest" ).css('display','inline-block');
		   });
		   jQuery(".jqtree-element").mouseout(function(e){
		   jQuery( this ).find( "span.spanClassTest" ).css('display','none');
		   });
}
/*    HEMA --------------- EOC*/