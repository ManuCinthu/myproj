//load relationship data from database 
var appendData12 = "";
infiniteScrollFlag = true;
countNoOfData = 0;
formRange = 0;

//load relationship data from database 
function loadRelationshipDetails(){
	//alert("leo==");
	$('#relationshipGrid_filterSearch').hide();
	$('#noRelationGridData_filterSearch').hide();
	$('#relationshipGrid').show();
	//console.log("http://localhost:8080"+"/repopro/web/relationship/relationshipView?from="+formRange);
	$.ajax({
		type : "GET",
		url : "/repopro/web/relationship/relationshipView?from="+formRange,
		dataType : "json",
		async: false,
		complete : function(data) {
			/*console.log(" data responseText "+data.responseText);*/
			//alert("data -->  "+jQuery.type(data)+" data.responseText -->"+jQuery.type(data.responseText)+"   JSON.parse(data.responseText) -->"+jQuery.type(JSON.parse(data.responseText)));
			var json = JSON.parse(data.responseText);
			//console.log(" json "+JSON.stringify(json));
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null || json.result == []){
					if(countNoOfData == 0){
						$('#noRelationGridData').show();
						$('#searchManageRelationshipTextBoxDiv').hide();
						$('#noRelationGridData').html('<div class="ui message">No relationships added yet</div>'); 
						$("#relationshipGrid").hide();
						infiniteScrollFlag = false;
					}
					else{
						$('#relationLoadingId').css('display', 'none');
						infiniteScrollFlag = false;
					}
				}
				else{
					
					$('#noRelationGridData').hide();
					$('#relationshipGrid').show();
					$.each(json.result, function(i) {
						
						appendData12 = getRelationshipDetails(json.result[i].srcAssetId,json.result[i].srcAssetName,json.result[i].destAssetId,json.result[i].destAssetName,json.result[i].fwdRelId,json.result[i].fwdRelationType,json.result[i].bwdRelationType,json.result[i].assetRelId,json.result[i].description,json.result[i].relationMappedFlag);
						$('#tableRelationship tbody').append(appendData12);
						countNoOfData++;
						
					});
	
					formRange = formRange + 20;
					
				}
				$('#relationLoadingId').css('display', 'none');
			}
			else{
				$('#relationLoadingId').css('display', 'none');
				
			}
			$('#showHideLoader').removeClass('active');
		}
	});
	$('#relationLoadingId').css('display', 'none');
	scrollVisible(0);
}

function getRelationshipDetails(srcAssetId,srcAssetName,destAssetId,destAssetName,fwdRelId,fwdRelationType,bwdRelationType,assetRelId,description,relationFlag){

/*	var data = "<p>Are you sure you want to delete "+srcAssetName+" ?</p><button class='right floated ui cancel mini button' onclick='closeDeleteRelationPopup("+assetRelId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteRelation("+assetRelId+")'>Yes</button>";
*/	var data = "<p>You are about to delete the Asset Relationship. Sure to proceed ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteRelationPopup("+assetRelId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteRelation("+assetRelId+")'>Yes</button>";
	appendData = "";
	appendData += '<tr id="relationshipRow_'+assetRelId+'">';
	appendData += '<td class="one wide hidden">'+assetRelId+'</td>';
	appendData += '<td class="three wide" id="description_'+assetRelId+'">';
	appendData += '<div><div class="mediumIconImageCircleStyle"><i class="sitemap icon sidebarIcons widgetIconColor" style="padding-left: 0.8em !important;padding-top: 0.4em;"></i></div><span style="margin-left: 0.8em;vertical-align: -webkit-baseline-middle;">'+description+'</span></div></td>';
	appendData += '<td class="three wide whitespaceNoTrim" id="srcAsstId_'+assetRelId+'">'+srcAssetName+'</td>';
	appendData += '<td class="three wide whitespaceNoTrim" id="destAssetId_'+assetRelId+'">'+destAssetName+'</td>';
	appendData += '<td class="two wide whitespaceNoTrim" id="fwdRelId_'+assetRelId+'">'+fwdRelationType+'</td>';
	appendData += '<td class="two wide hidden" id="bwdRelId_'+assetRelId+'">'+bwdRelationType+'</td>';
	appendData += '<td class="one wide"><i class="edit icon deleteEditIcon" onclick="openEditRelationship(this,'+assetRelId+','+srcAssetId+','+destAssetId+','+fwdRelId+')"></i></td>';
	if(relationFlag == true){
		appendData += '<td class="disabled disableDeleteIcon"><span data-tooltip="Cannot delete this relationship. Instance level relationship exists." data-position="left center"><i class="trash icon" id="trash_'+assetRelId+'" ></i></span></td>';
	}
	else {
		appendData += '<td class=""><a><i class="trash icon deleteEditIcon" id="trash_'+assetRelId+'" data-html="'+data+'" onclick="openDeleteRelationPopup('+assetRelId+')"></i></a></td>';
	}
	appendData += '</tr>';
	return appendData;
	
}


//delete role confirmation popup
function openDeleteRelationPopup(assetRelId){
	$("#trash_"+assetRelId)
	.popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	})
	.popup('show');
}
//close delete role popup
function closeDeleteRelationPopup(assetRelId){
		$("#trash_"+assetRelId).popup('hide');
}

//create list of asset name
var appendAssets = "";
function createRelationAssetName(){
	     $.ajax({
		type : "GET",
		url : "/repopro/web/assetType/getallassets?userId="+loggedInUserId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			
			if(json.status == "SUCCESS"){
				appendAssets = "";
				$.each(json.result, function(i) {
					appendAssets += '<option value="'+json.result[i].assetId+'">'+json.result[i].assetName+'</option>';
				}); 
			}
		}
	});
}

//delete  relation confirmation popup
function openDeleteRelationshipPopup(assetRelId){
	$("#trash_"+assetRelId).popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	}).popup('show');
}

//close delete group popup
function closeDeleteRelationPopup(assetRelId){
	$("#trash_"+assetRelId).popup('hide');
}

//add new Relationship
function openAddRelationship(){
	var obj = {};
	
	$('#submitAddedRelationship').unbind();
	$('#cancelAddedRelationship').unbind();
	
	$('#addRelationship').modal('destroy');
	//$('#addRelationship').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	
	createRelationAssetName();
	$("#addRelationshipName").val("");
	$('#addRelationType').prop('selectedIndex',0);
	$('#addRelationType').dropdown('clear');
	$('#addSourceAsset').dropdown('clear');
	$('#addDestinationAsset').dropdown('clear');
	$('#addSourceAsset').html('');
	$('#addDestinationAsset').html('');
	$("#addSourceAsset").prepend('<option value="">Select Source Asset Name</option>');
	$("#addDestinationAsset").prepend('<option value="">Select Destination Asset Name</option>');
	$("#addSourceAsset").append(appendAssets);
	$("#addDestinationAsset").append(appendAssets);
	$('#addRelationship').modal('setting', 'closable', false).modal('show');
	
	$('.assetInfoPopup').popup({
		inline : true,
	});
	
	
	$("#errRelationName").hide();
	$('#addRelationshipName').parent().removeClass("error");
	$("#errIdRelationType").hide();
	$('#addRelationType').parent().removeClass("error");  
	$("#errIdSrcName").hide();
	$('#addSourceAsset').parent().removeClass("error");  
	$("#errIdDescName").hide();
	$('#addDestinationAsset').parent().removeClass("error");

	//submit the added relation
	$('#submitAddedRelationship').on('click', function(){
		
		var sourceAssetId = $("#addSourceAsset").find(":selected").val();
		var destAssetId = $("#addDestinationAsset").find(":selected").val();
		var relationType = $("#addRelationType").find(":selected").val();
		var relationName = $("#addRelationshipName").val().trim();
		
		var sourceAssetText = $("#addSourceAsset").find(":selected").text();
		var destAssetText = $("#addDestinationAsset").find(":selected").text();
		var relationTypeText = $("#addRelationType").find(":selected").text();
		var bwdRelationText = relationTypeText+" by";
		
		var flag = true;
		
		if(relationName == null || relationName == ""){
			$('#addRelationshipName').parent().addClass("error"); 
			$("#errRelationName").show();  
			flag = false;
		}
		else{
			if (/^[a-zA-Z0-9- ]*$/.test(relationName) == false) {
				$('#addRelationshipName').parent().addClass("error"); 
			    $("#errRelationName").html('Please use only alphanumeric character for relationship name.').show();  
				flag = false;
			}
			else{
				$('#addRelationshipName').parent().removeClass("error"); 
				$("#errRelationName").hide(); 
			}
	
		}
		//kavya

		if($('#addRelationType option:selected').text() == "Select Relationship Type"){
			$("#errIdRelationType").show();
			$('#addRelationType').parent().addClass("error"); 
			flag = false;
		}
		 else {
			 $("#errIdRelationType").hide();
			 $('#addRelationType').parent().removeClass("error");  
		 }
		
		if($('#addSourceAsset option:selected').text() == "Select Source Asset Name"){
			$("#errIdSrcName").show();
			$('#addSourceAsset').parent().addClass("error"); 
			flag = false;
		}
		 else {
			 $("#errIdSrcName").hide();
			 $('#addSourceAsset').parent().removeClass("error");  
		 }
		if($('#addDestinationAsset option:selected').text() == "Select Destination Asset Name"){
			$("#errIdDescName").show();
			$('#addDestinationAsset').parent().addClass("error"); 
			flag = false;
		}
		 else {
			 $("#errIdDescName").hide();
			 $('#addDestinationAsset').parent().removeClass("error");  
		 }
		
		if(relationTypeText == "classification" && sourceAssetId == destAssetId){
			notifyMessage("Add Relation","Classification relationship can be provided only between two different assets","fail");
			flag = false;
		}
		
		if(flag == false){
			$('#addRelationship').modal('show');
			return false;
		}
		else {
			$('#addRelationship').modal('hide');  //.modal('hide dimmer');
			$('#addRelationship').parent().css("display", "none !important");
			obj = {
					"srcAssetId":sourceAssetId,
					"destAssetId":destAssetId,
					"fwdRelId":relationType,
					"description":relationName
			};
			var url = "http://localhost:8080/repopro/web/relationship/addRelationship";
			
			$.ajax({
				type: "POST",
				url: "/repopro/web/relationship/addRelationship",
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				complete:function(data){
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						notifyMessage("Add Relationship","Relation added","success");
						if($('#tableRelationship tbody tr').length == 0){
							$("#relationshipTableHeader").show();
							$("#noRelationGridData").hide();
						}
					/*	$('#relationshipGrid').show();
						appendData = getRelationshipDetails(sourceAssetId,sourceAssetText,destAssetId,destAssetText,relationType,relationTypeText,bwdRelationText,json.result[0].assetRelId,relationName,json.result[0].relationMappedFlag);
						//$('#tableRelationship tbody').append(appendData);
						loadRelationshipDetails();
						$('#relationshipGrid').show();
						appendData = getRelationshipDetails(sourceAssetId,sourceAssetText,destAssetId,destAssetText,relationType,relationTypeText,bwdRelationText,json.result[0].assetRelId,relationName,json.result[0].relationMappedFlag);
						$('#tableRelationship tbody').prepend(appendData);*/
						formRange = 0;
						countNoOfData = 0;
						infiniteScrollFlag = true;
						//appendData1 = "";
						$('#tableRelationship tbody').html("");
						loadRelationshipDetails();
						
						
					}
				else {
						notifyMessage("Relationship",json.message,"fail")
						flag = false;
					}	

				}
			});
		}
		if(flag == false){
	    	$('#addRelationship').modal('show');
			return false;
	     }
	     else{
	    	 $('#addRelationship').modal('hide'); //.modal('hide dimmer');
	    	 $('#addRelationship').parent().css("display", "none !important");
	     }
	});
	$('.ui.dropdown').dropdown();
}

//edit Relationship
function openEditRelationship(obj,assetRelId,srcAsstId,destAssetId,fwdRelId){
	
	
	$('#submitEditedRelationship').unbind();
	$('#cancelEditedRelationship').unbind();

	$('#editRelationship').modal('destroy');
	$('#editRelationship').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	$('.assetInfoPopup').popup({
		inline : true,
	});
	
	createRelationAssetName();
	
	
	//$('#editRelationType').dropdown('clear');
	$("#editSourceAsset").html('');
	$("#editDestinationAsset").html('');
	$("#editSourceAsset").append(appendAssets);
	$("#editDestinationAsset").append(appendAssets);
	
	
	$("#errEditRelationName").hide();
	$('#editRelationshipName').parent().removeClass("error");
	$("#errEditRelationType").hide();
	$('#editRelationType').parent().removeClass("error");  
	$("#errEditSourceAsset").hide();
	$('#editSourceAsset').parent().removeClass("error");  
	$("#errEditDestinationAsset").hide();
	$('#editDestinationAsset').parent().removeClass("error");
	
	

	var srcAsstName = $("#srcAsstId_"+assetRelId).text();
	var destAssetName = $("#destAssetId_"+assetRelId).text();
	var fwdRelNAme = $("#fwdRelId_"+assetRelId).text();
	var desc =  $("#description_"+assetRelId).text();
	$("#editRelationshipName").val(desc);
	
	/*Added By Hema BOC*/
	$('#relationShipName').text(desc);
	/*EOC*/ 
	
	$("#editRelationType").dropdown('set selected',fwdRelNAme);
	
	//$('#editRelationType').prop('selectedIndex',0);
	setTimeout(function(){ 
		$("#editSourceAsset").dropdown('set selected',srcAsstName);
		$('#editDestinationAsset').dropdown('set selected',destAssetName);

	}, 100);

	
	//submit the edited relation
	$('#submitEditedRelationship').on('click', function(){
		
		var sourceAssetId = $("#editSourceAsset").find(":selected").val();
		var destAssetId = $("#editDestinationAsset").find(":selected").val();
		var relationType = $("#editRelationType").find(":selected").val();
		var relationName = $("#editRelationshipName").val().trim();
		
		var sourceAssetText = $("#editSourceAsset").find(":selected").text();
		var destAssetText = $("#editDestinationAsset").find(":selected").text();
		var relationTypeText = $("#editRelationType").find(":selected").text();
		var bwdRelationType = relationTypeText+" by";
		
		var flag = true;
		 
		 if(relationName == null || relationName == ""){
				$('#editRelationshipName').parent().addClass("error"); 
				$("#errEditRelationName").show();  
				flag = false;
			}
			else{
				if (/^[a-zA-Z0-9- ]*$/.test(relationName) == false) {
					$('#editRelationshipName').parent().addClass("error"); 
				    $("#errEditRelationName").html('Please use only alphanumeric character for relationship name.').show();  
					flag = false;
				}
				else{
					$('#editRelationshipName').parent().removeClass("error"); 
					$("#errEditRelationName").hide(); 
				}
			}
		 
		 if($('#editRelationType option:selected').text() == "Select Relationship Type"){
				$("#errEditRelationType").show();
				$('#editRelationType').parent().addClass("error"); 
				flag = false;
			}
			 else {
				 $("#errEditRelationType").hide();
				 $('#editRelationType').parent().removeClass("error");  
			 }
			
			if($('#editSourceAsset option:selected').text() == "Select Source Asset Name"){
				$("#errEditSourceAsset").show();
				$('#editSourceAsset').parent().addClass("error"); 
				flag = false;
			}
			 else {
				 $("#errEditSourceAsset").hide();
				 $('#editSourceAsset').parent().removeClass("error");  
			 }
			
			if($('#editDestinationAsset option:selected').text() == "Select Destination Asset Name"){
				$("#errEditDestinationAsset").show();
				$('#editDestinationAsset').parent().addClass("error"); 
				flag = false;
			}
			 else {
				 $("#errEditDestinationAsset").hide();
				 $('#editDestinationAsset').parent().removeClass("error");  
			 }
			
			if(relationTypeText == "classification" && sourceAssetId == destAssetId){
				notifyMessage("Edit Relation","Classification relationship can be provided only between two different assets","fail");
				flag = false;
			}

		if(flag == false){
			$('#editRelationship').modal('show');
			return false;
		}
		else {
			var obj = {
					"srcAssetId":sourceAssetId,
					"destAssetId":destAssetId,
					"fwdRelId":relationType,
					"description":relationName,
					"assetRelId":assetRelId
			};
			
			var url = "/repopro/web/relationship/updateRelationship/"+desc;
			$.ajax({
				type: "PUT",
				url: "/repopro/web/relationship/updateRelationship/"+desc,
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				complete:function(data){	
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						notifyMessage("Edit Relationship","Relationship updated","success");
						$('#srcAsstId_'+assetRelId).html(sourceAssetText);
						$('#destAssetId_'+assetRelId).html(destAssetText);
						$('#fwdRelId_'+assetRelId).html(relationTypeText);
						$('#bwdRelId_'+assetRelId).html(bwdRelationType);
						$('#description_'+assetRelId).html('<div><div class="mediumIconImageCircleStyle"><i class="sitemap icon sidebarIcons widgetIconColor" style="padding-left: 0.8em !important;padding-top: 0.4em;"></i></div><span style="margin-left: 0.8em;vertical-align: -webkit-baseline-middle;">'+relationName+'</span></div>');
					}
					else {
						notifyMessage("Edit Relationship",json.message,"fail")
						flag = false;
					}	
				}
			});
		}
		if(flag == false){
	    	$('#editRelationship').modal('show');
			return false;
	     }
	     else{
	    	 $('#editRelationship').modal('hide'); //.modal('hide dimmer'); 
	    	 $('#editRelationship').parent().css("display", "none !important");
	     }
	});
	$('.ui.dropdown').dropdown();
	
	/*** Code for whitespace no trim ***/
	$("#editSourceAsset").parent().css("white-space", "pre-wrap");
	var g = $("#editSourceAsset").next(".menu").attr('class');
}

//Delete relation
function deleteRelation(assetRelId){
	var desc = $('#description_'+assetRelId).text();
	$.ajax({
		type : "DELETE",
		url : "/repopro/web/relationship/deleteRelationship/"+assetRelId+"/"+desc,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			$("#trash_"+assetRelId).popup('hide');
			if(json.status == "FAILURE"){
				notifyMessage("Relationship",json.result,"fail");
			}
			else {
				if($('#tableRelationship tbody tr').length == 1){
					$('#relationshipTableHeader').hide();
					$('#searchManageRelationshipTextBoxDiv').hide()
					$('#noRelationGridData').show();
					$('#noRelationGridData').html('<div class="ui message">No relationships added yet</div>'); 
				}
				$('#relationshipRow_'+assetRelId).remove();
				notifyMessage("Relationship","Relationship deleted","success");
			}

		}

	});
	
 }

function initialiseSearchRelationData(){
	//alert(' initialiseSearchRelationData ');
	formRange1 = 0;
	infiniteScrollFlag1 = true;
	countNoOfData1 = 0;
	$('#tableRelationship_filterSearch tbody').html("");
	showFilteredRelationshipData();
}

//load search filtered data 
function showFilteredRelationshipData(){
	
	//alert('show Filtered relayion');
	var searchedManageRelationshipText = $('#filterManageRelationshipInputField').val().trim();
	var url = "/repopro/web/relationship/relationshipViewFilter?userName="+loggedInUserName+"&searchString="+encodeURIComponent(searchedManageRelationshipText)+"&from="+formRange1;
	console.log("url  "+url);
	$('#noRelationGridData').hide();
	$('#relationshipGrid').hide();
	$('#relationshipGrid_filterSearch').show();
	
	if(searchedManageRelationshipText != ""){
		$.ajax({
			type : "GET",
			url : "/repopro/web/relationship/relationshipViewFilter?userName="+loggedInUserName+"&searchString="+encodeURIComponent(searchedManageRelationshipText)+"&from="+formRange1,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(json.result == "" || json.result == null || json.result == []){
						if(countNoOfData1 == 0){
							$('#noRelationGridData_filterSearch').show();
							$('#noRelationGridData_filterSearch').html('<div class="ui message">No matching results found.</div>'); 
							$("#relationshipGrid_filterSearch").hide();
							infiniteScrollFlag1 = false;
						}
						else{
							$('#relationLoadingId_filterSearch').css('display', 'none');
							infiniteScrollFlag1 = false;
						}
					}
					else{
						
						$('#noRelationGridData_filterSearch').hide();
						$('#relationshipGrid_filterSearch').show();
						
						$.each(json.result, function(i) {
							appendData1 = getRelationshipDetails_filterSearch(json.result[i].srcAssetId,json.result[i].srcAssetName,json.result[i].destAssetId,json.result[i].destAssetName,json.result[i].fwdRelId,json.result[i].fwdRelationType,json.result[i].bwdRelationType,json.result[i].assetRelId,json.result[i].description,json.result[i].relationMappedFlag);
							$('#tableRelationship_filterSearch tbody').append(appendData1);
							countNoOfData1++;
						});
						formRange1 = formRange1 + 20;
						
					}
					$('#relationLoadingId_filterSearch').css('display', 'none');
				}
				else{
					$('#relationLoadingId_filterSearch').css('display', 'none');
				}
				$('#showHideLoader').removeClass('active');
			}
		});
		$('#relationLoadingId_filterSearch').css('display', 'none');
		scrollVisible(1);
	}else{
		   // alert("else");
		 	formRange = 0; countNoOfData = 0; infiniteScrollFlag = true;
		 	infiniteScrollFlag1 = false;
		 	$('#relationshipGrid_filterSearch').hide();
		 	$('#tableRelationship tbody').html('');
		 	appendData12 = "";
		 	//console.log("appendData12  "+appendData12);
		 	loadRelationshipDetails();
	}	
}
function getRelationshipDetails_filterSearch(srcAssetId,srcAssetName,destAssetId,destAssetName,fwdRelId,fwdRelationType,bwdRelationType,assetRelId,description,relationFlag){

	/*	var data = "<p>Are you sure you want to delete "+srcAssetName+" ?</p><button class='right floated ui cancel mini button' onclick='closeDeleteRelationPopup("+assetRelId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteRelation("+assetRelId+")'>Yes</button>";
	*/	var data = "<p>You are about to delete the Asset Relationship. Sure to proceed ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteRelationPopup_filterSearch("+assetRelId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteRelation_filterSearch("+assetRelId+")'>Yes</button>";
		appendData = "";
		appendData += '<tr id="relationshipRow_filterSearch_'+assetRelId+'">';
		appendData += '<td class="one wide hidden">'+assetRelId+'</td>';
		appendData += '<td class="three wide" id="description_filterSearch_'+assetRelId+'">';
		appendData += '<div><div class="mediumIconImageCircleStyle"><i class="sitemap icon sidebarIcons widgetIconColor" style="padding-left: 0.8em !important;padding-top: 0.4em;"></i></div><span style="vertical-align: -webkit-baseline-middle;" class="gridImageTextSpacing">'+description+'</span></div></td>';
		appendData += '<td class="three wide" id="srcAsstId_filterSearch_'+assetRelId+'">'+srcAssetName+'</td>';
		appendData += '<td class="three wide" id="destAssetId_filterSearch_'+assetRelId+'">'+destAssetName+'</td>';
		appendData += '<td class="two wide" id="fwdRelId_filterSearch_'+assetRelId+'">'+fwdRelationType+'</td>';
		appendData += '<td class="two wide hidden" id="bwdRelId_filterSearch_'+assetRelId+'">'+bwdRelationType+'</td>';
		appendData += '<td class="one wide center aligned"><i class="edit icon deleteEditIcon" onclick="openEditRelationship_filterSearch(this,'+assetRelId+','+srcAssetId+','+destAssetId+','+fwdRelId+')"></i></td>';
		if(relationFlag == true){
			appendData += '<td class="center aligned disabled disableDeleteIcon"><span data-tooltip="Cannot delete this relationship.  Instance level relationship exists." data-position="left center"><i class="trash icon" id="trash_filterSearch_'+assetRelId+'" ></i></span></td>';
		}
		else {
			appendData += '<td class="center aligned"><a><i class="trash icon deleteEditIcon" id="trash_filterSearch_'+assetRelId+'" data-html="'+data+'" onclick="openDeleteRelationPopup_filterSearch('+assetRelId+')"></i></a></td>';
		}
		appendData += '</tr>';
		return appendData;
		
}


//delete role confirmation popup
function openDeleteRelationPopup_filterSearch(assetRelId){
	$("#trash_filterSearch_"+assetRelId)
	.popup({
		on: 'click',
		lastResort: 'bottom left',
		closable : true
	})
	.popup('show');
}
//close delete role popup
function closeDeleteRelationPopup_filterSearch(assetRelId){
		$("#trash_filterSearch_"+assetRelId).popup('hide');
}
//Filter Edit Relation ship
function openEditRelationship_filterSearch(obj,assetRelId,srcAsstId,destAssetId,fwdRelId){
	//alert(" edit relation for filter");
	
	$('#submitEditedRelationship_filterSearch').unbind();
	$('#cancelEditedRelationship_filterSearch').unbind();

	$('#editRelationship_filterSearch').modal('destroy');
	$('#editRelationship_filterSearch').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
	$('.assetInfoPopup').popup({
		inline : true,
	});
	
	createRelationAssetName();
	
	//$('#editRelationType').dropdown('clear');
	$("#editSourceAsset_filterSearch").html('');
	$("#editDestinationAsset_filterSearch").html('');
	$("#editSourceAsset_filterSearch").append(appendAssets);
	$("#editDestinationAsset_filterSearch").append(appendAssets);
	
	
	$("#errEditRelationName_filterSearch").hide();
	$('#editRelationshipName_filterSearch').parent().removeClass("error");
	$("#errEditRelationType_filterSearch").hide();
	$('#editRelationType_filterSearch').parent().removeClass("error");  
	$("#errEditSourceAsset_filterSearch").hide();
	$('#editSourceAsset_filterSearch').parent().removeClass("error");  
	$("#errEditDestinationAsset_filterSearch").hide();
	$('#editDestinationAsset_filterSearch').parent().removeClass("error");
	
	

	var srcAsstName = $("#srcAsstId_filterSearch_"+assetRelId).text();
	var destAssetName = $("#destAssetId_filterSearch_"+assetRelId).text();
	var fwdRelNAme = $("#fwdRelId_filterSearch_"+assetRelId).text();
	var desc =  $("#description_filterSearch_"+assetRelId).text();
	$("#editRelationshipName_filterSearch").val(desc);
	$("#editRelationType_filterSearch").dropdown('set selected',fwdRelNAme);
	
	//$('#editRelationType').prop('selectedIndex',0);
	setTimeout(function(){ 
		$("#editSourceAsset_filterSearch").dropdown('set selected',srcAsstName);
		$('#editDestinationAsset_filterSearch').dropdown('set selected',destAssetName);

	}, 100);

	$('#relationShipName_filterSearch').text(desc);
	//submit the edited relation
	$('#submitEditedRelationship_filterSearch').on('click', function(){
		
		var sourceAssetId = $("#editSourceAsset_filterSearch").find(":selected").val();
		var destAssetId = $("#editDestinationAsset_filterSearch").find(":selected").val();
		var relationType = $("#editRelationType_filterSearch").find(":selected").val();
		var relationName = $("#editRelationshipName_filterSearch").val().trim();
		
		var sourceAssetText = $("#editSourceAsset_filterSearch").find(":selected").text();
		var destAssetText = $("#editDestinationAsset_filterSearch").find(":selected").text();
		var relationTypeText = $("#editRelationType_filterSearch").find(":selected").text();
		var bwdRelationType = relationTypeText+" by";
		
		var flag = true;
		 
		 if(relationName == null || relationName == ""){
				$('#editRelationshipName').parent().addClass("error"); 
				$("#errEditRelationName").show();  
				flag = false;
			}
			else{
				if (/^[a-zA-Z0-9- ]*$/.test(relationName) == false) {
					$('#editRelationshipName_filterSearch').parent().addClass("error"); 
				    $("#errEditRelationName_filterSearch").html('Please use only alphanumeric character for relationship name.').show();  
					flag = false;
				}
				else{
					$('#editRelationshipName_filterSearch').parent().removeClass("error"); 
					$("#errEditRelationName_filterSearch").hide(); 
				}
			}
		 
		 if($('#editRelationType_filterSearch option:selected').text() == "Select Relationship Type"){
				$("#errEditRelationType_filterSearch").show();
				$('#editRelationType_filterSearch').parent().addClass("error"); 
				flag = false;
			}
			 else {
				 $("#errEditRelationType_filterSearch").hide();
				 $('#editRelationType_filterSearch').parent().removeClass("error");  
			 }
			
			if($('#editSourceAsset_filterSearch option:selected').text() == "Select Source Asset Name"){
				$("#errEditSourceAsset_filterSearch").show();
				$('#editSourceAsset_filterSearch').parent().addClass("error"); 
				flag = false;
			}
			 else {
				 $("#errEditSourceAsset_filterSearch").hide();
				 $('#editSourceAsset_filterSearch').parent().removeClass("error");  
			 }
			
			if($('#editDestinationAsset_filterSearch option:selected').text() == "Select Destination Asset Name"){
				$("#errEditDestinationAsset_filterSearch").show();
				$('#editDestinationAsset_filterSearch').parent().addClass("error"); 
				flag = false;
			}
			 else {
				 $("#errEditDestinationAsset_filterSearch").hide();
				 $('#editDestinationAsset_filterSearch').parent().removeClass("error");  
			 }
			
			if(relationTypeText == "classification" && sourceAssetId == destAssetId){
				notifyMessage("Edit Relation","Classification relationship can be provided only between two different assets","fail");
				flag = false;
			}

		if(flag == false){
			$('#editRelationship_filterSearch').modal('show');
			return false;
		}
		else {
			var obj = {
					"srcAssetId":sourceAssetId,
					"destAssetId":destAssetId,
					"fwdRelId":relationType,
					"description":relationName,
					"assetRelId":assetRelId
			};
			
			var url = "/repopro/web/relationship/updateRelationship/"+desc;
			$.ajax({
				type: "PUT",
				url: "/repopro/web/relationship/updateRelationship/"+desc,
				contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				complete:function(data){	
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						notifyMessage("Edit Relationship","Relationship updated","success");
						$('#srcAsstId_filterSearch_'+assetRelId).html(sourceAssetText);
						$('#destAssetId_filterSearch_'+assetRelId).html(destAssetText);
						$('#fwdRelId_filterSearch_'+assetRelId).html(relationTypeText);
						$('#bwdRelId_filterSearch_'+assetRelId).html(bwdRelationType);
						$('#description_filterSearch_'+assetRelId).html('<div><div class="mediumIconImageCircleStyle"><i class="sitemap icon sidebarIcons widgetIconColor" style="padding-left: 0.8em !important;padding-top: 0.4em;"></i></div><span style="margin-left: 0.8em;vertical-align: -webkit-baseline-middle;">'+relationName+'</span></div>');
					}
					else {
						notifyMessage("Edit Relationship",json.message,"fail")
						flag = false;
					}	
				}
			});
		}
		if(flag == false){
	    	$('#editRelationship_filterSearch').modal('show');
			return false;
	     }
	     else{
	    	 $('#editRelationship_filterSearch').modal('hide'); //.modal('hide dimmer'); 
	    	 $('#editRelationship_filterSearch').parent().css("display", "none !important");
	     }
	});
	$('.ui.dropdown').dropdown();
}

//Delete relation
function deleteRelation_filterSearch(assetRelId){
	//alert("delete relation filter search");
	var desc = $('#description_filterSearch_'+assetRelId).text();
	$.ajax({
		type : "DELETE",
		url : "/repopro/web/relationship/deleteRelationship/"+assetRelId+"/"+desc,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			$("#trash_"+assetRelId).popup('hide');
			if(json.status == "FAILURE"){
				notifyMessage("Relationship",json.result,"fail");
			}
			else {
				if($('#tableRelationship_filterSearch tbody tr').length == 1){
					$('#relationshipGrid_filterSearch').hide();
					$('#relationshipTableHeader_filterSearch').hide();
					$('#noRelationGridData_filterSearch').show();
					$('#noRelationGridData_filterSearch').html('<div class="ui message">No matching results found.</div>'); 
				}
				$('#relationshipRow_filterSearch_'+assetRelId).remove();
				notifyMessage("Relationship","Relationship deleted","success");
			}

		}

	});
	
 }
function clearFilterTextBox(){
	$('#filterManageRelationshipInputField').val("");
	//alert("clear");
	formRange = 0; countNoOfData = 0; infiniteScrollFlag = true;
 	infiniteScrollFlag1 = false;
 	$('#relationshipGrid_filterSearch').hide();
 	$('#tableRelationship tbody').html('');
 	appendData12 = "";
 	loadRelationshipDetails();
}
