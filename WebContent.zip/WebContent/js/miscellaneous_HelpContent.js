// get help content data
var helpContentId = "";
function loadHelpContentDetails(){
	helpContentId = "";
	$.ajax({
			type: "GET",
			url: "/repopro/web/helpcontents",
			dataType: "json",
			async: "false",
			cache: false,
			complete: function(data){
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(json.result != "" || json.result != null){
						$('#showHelpContentMessage').html(json.result[0].help_Content);
						CKEDITOR.replace('helpContentTextArea');
						CKEDITOR.instances['helpContentTextArea'].setData(json.result[0].help_Content);
						$("#showHelpContentMessageButton").click();
					}
				}
				
			}
	});
	$('#showHideLoader').removeClass('active');
}

//update the help content data
function saveHelpContentData(){

	//trimming white spaces and strings with empty values - chandana 21.02.2020 - #708
	var getTextfromCKeditor = $(".cke_contents iframe").contents().find("body").text();
	var trimextfromCKeditor = $.trim(getTextfromCKeditor);
		var helpContentData = CKEDITOR.instances['helpContentTextArea'].getData();
		if(getTextfromCKeditor == "" || getTextfromCKeditor == null || trimextfromCKeditor == ""){
			helpContentData = "";
		}
		else{
			helpContentData = helpContentData;
		}
		/*if(helpContentData != ""){
			var data = CKEDITOR.instances['helpContentTextArea'].dataProcessor.toHtml(helpContentData);

			helpContentData = data;

		}*/
		var createdOn = getCurrentDateAndTime();
		var createdBy = "admin";
		
		
		if(helpContentData == "" || helpContentData == null){
			notifyMessage("Help Contents","Please provide the help contents","warning");
		}else{
			var obj = {
					"created_By": createdBy,
				    "created_On": createdOn,
				    "help_Content": helpContentData
				};
		  $.ajax({
		       type: "POST",
		       url: "/repopro/web/helpcontents",
		       contentType : "application/json",
				dataType : "json",
				data : JSON.stringify(obj),
				async: false,
				cache: false,
				complete:function(data){
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					//$("#showHelpContentMessage").show();
					//$("#showHelpContentMessageButton").removeClass("hideElement");
					//$("#showHelpContentMessage").html(helpContentData);
					$("#editHelpContentMessage").show();
					notifyMessage("Help Contents","Help contents updated","success");
				}
				else {
					notifyMessage("Help Contents","Error attempting to update help contents","fail");
				}	
					
				}
		  });
		}
	}
//get current date and time
function getCurrentDateAndTime(){
	var dt = new Date();
	var dateTime =dt.getFullYear() + "-" + (dt.getMonth()+1) + "-" + dt.getDate() + " " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
	return dateTime;
}

$("#showHelpContentMessageButton").on("click",function(){
	$("#showHelpContentMessage").hide();
	$("#showHelpContentMessageButton").addClass("hideElement");
	$("#editHelpContentMessage").show();
	var editor = CKEDITOR.instances.helpContentTextArea;
    if (editor) {
        editor.destroy(true); 
    }   
    CKEDITOR.replace('helpContentTextArea');
    CKEDITOR.instances['helpContentTextArea'].setData($("#showHelpContentMessage").html());
});