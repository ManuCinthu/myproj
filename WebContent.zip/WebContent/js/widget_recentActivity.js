function loadFirstTenRecentActivity(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/recentActivity/getRecentActivity?userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					$("#showAllRecentActivity").hide();
					$('#loadRecentActivityData').html('<div class="ui message">No recent activity details yet</div>'); 
				}else{
					$("#showAllRecentActivity").show();
					$.each(json.result, function(i) {
						appendData = getRecentActivityDetails(json.result[i].description,json.result[i].date,json.result[i].user_id,decodeURIComponent(json.result[i].assetInstName),json.result[i].user_image,json.result[i].assetInstVersionId,json.result[i].encryptImage,json.result[i].userName);
						$('#loadRecentActivityData').append(appendData);
					});	

				}
			}
		}
	});
}


function getRecentActivityDetails(description,date,userId,assetInstName,userImg,assetInstVersionId, encImg,uName){	
	var desc = description.split(";");
	var abc = "delete";
	var assetName = assetInstName;
		if(desc[1] == "deleted"){
			desc[1] = "<span class = 'deleteClass'>"+desc[1]+"</span>";
			desc[3] = "<span style='color: #a0a0a0;'>"+desc[3]+"</span>";
		}else{
			var encodedAssetInstName= encodeURIComponent(assetInstName);
			encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
			//Swathi - Colour to distinguish the action - 10-09-2019
			if(desc[1] == "created") {
				desc[1] = "<span class = 'createClass'>"+desc[1]+"</span>";	
			} else if(desc[1] == 'updated') {
				desc[1] = "<span class = 'updateClass'>"+desc[1]+"</span>";	
			} 			
			desc[3] = '<a onclick="getAssetInstances('+assetInstVersionId+',\''+encodedAssetInstName+'\')" style="color: #4183C4;">'+assetInstName+'</a>';
		}
	
	/*Hema 27.Sep.2017*/
	if(desc[4] == undefined){
		desc[4] = "";
	}	
	var recentDetails  = desc[0] +" "+desc[1]+" "+desc[2]+" "+desc[3]+" "+desc[4];
	appendData = "";
	appendData += '<div class="ui small feed">';
	appendData += '<div class="event">';
	appendData += '<div class="label">';
	if(userImg == null){
		if(desc[0] == "admin"){
		appendData += '<img class="ui avatar image" id="userImage_'+userId+'" src="/repopro/semantic/images/avatar/defaultUserImage.png" style="margin-top: 29%;">';
	}
		/*else if(desc[0] == "Harika E N"){*/
		else{
			appendData += '<img class="ui avatar image" id="userImage_'+userId+'" src="/repopro/semantic/images/avatar/molly.png" style="margin-top: 29%;">';
		}
	}
	else{
		/*var imageType = userImg.split(".");
		imageType = imageType[1];*/
		imageType = (userImg).substring((userImg).lastIndexOf(".") + 1, (userImg).length);
		//Chandana - 13-9-2019 Broken image
		if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
			imageType = imageType.toLowerCase()
		}
		if((encImg == 1) && (uName != loggedInUserFullName) && (loggedMapRoleFlag == 0)){//Swathi- Encryption-06.01.2019
			appendData += '<img class="ui avatar image" id="userImage_'+userId+'" src="/repopro/semantic/images/avatar/defaultUserImage.png" style="margin-top: 29%;">';
		}else{
			appendData += '<img class="ui avatar image" id="userImage_'+userId+'" src="/repopro/profileImages/'+userId+'.'+imageType+'">';
		}
		
	}
	appendData += '</div>';
	appendData += '<div class="content cardContentTextColour cardHeaderContentSpacing whitespaceNoTrim">'+recentDetails+'<div class="date feedDatePadding">'+date+'</div>';
	appendData += '</div></div>';
	return appendData;
}