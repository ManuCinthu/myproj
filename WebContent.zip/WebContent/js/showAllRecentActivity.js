appendData = "";
infiniteScrollFlag = true;
countNoOfData = 0;
formRange = 0;
function loadRecentActivityShowAllDetails(){
	//url = "http://localhost:6060/repopro/web/recentActivity/recentActivityDetails?userName="+loggedInUserName+"&from="+formRange;
   //console.log(" url  "+url)
	$.ajax({
		type : "GET",
		url : "/repopro/web/recentActivity/recentActivityDetails?userName="+loggedInUserName+"&from="+formRange,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null || json.result == []){
					//$('.recentActivityFloatingIcon').css('display', 'none');
					if(countNoOfData == 0){
						$("#noRecentData").show();
						$('#noRecentData').html('<div class="ui message">No recent activity details yet</div>'); 
						$("#recentGridViewAll").hide();
						infiniteScrollFlag = false;
					}
					else{
						$('#recentActivityloadingId').css('display', 'none');
						infiniteScrollFlag = false;
					}
				}
				else{
					//console.log(" loggedInUserName "+loggedInUserName);
					if(loggedInUserName != "roleAnonymous"){
						$('#assetInstancesFloatingIcons').html('');
						$('#assetInstancesFloatingIcons').html('<span href="#" class="floatIcons" id="menu-share"><i style="margin-top:0.6em;margin-left:0.2em;" class="big sidebar icon"></i></span> <ul class="floatingIconsUL"><li onclick="return recentActivityExportToExcel()"><a href="#" title="Export Data" id="menu-google-plus"> <i class="upload icon popupIcon" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em;"></i></a></li></ul>');
					}
					$('#noRecentData').hide();
					$('#recentGridViewAll').show();
					$.each(json.result, function(i) {
						appendData = getRecentActivityDetails(json.result[i].activityId,json.result[i].date,json.result[i].userName,json.result[i].action,json.result[i].assetName,decodeURIComponent(json.result[i].assetInstName),json.result[i].assetInstanceVersionName,json.result[i].user_id,json.result[i].user_image,json.result[i].assetInstVersionId,json.result[i].encryptImage);
						$('#recentGridViewAll table tbody').append(appendData);
						countNoOfData++;
					});
					
					formRange = formRange + 20;
				}
				$('#recentActivityloadingId').css('display', 'none');
				//$('.recentActivityFloatingIcon').css('display', 'none');
			}
			
			else{
				$('#recentActivityloadingId').css('display', 'none');
				$('.recentActivityFloatingIcon').hide();
			}
			$('#showHideLoader').removeClass('active');
		}
	});
	$('#recentActivityloadingId').css('display', 'none');
}
function getRecentActivityDetails(activityId,date,fullName,action,assetName,assetInstanceName,versionName ,userId,userImg,assetInstVersionId, encImg){	
	var encodedAssetInstName= encodeURIComponent(assetInstanceName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	appendData = '';
	appendData += '<tr>';
	appendData += '<td class="two wide center aligned hidden">'+activityId+'</td>';
	appendData += '<td class="two wide center aligned">';
	appendData += '<div class="ui left floated image">';
	if(userImg == null){
		appendData += '<img id="userId_'+userId+'" class="ui mini circular image" src="/repopro/semantic/images/avatar/defaultUserImage.png" style="margin-left: 2em;">';
	}else{
		var imageType = userImg.split(".");
		imageType = imageType[1];
		//Chandana - 13-9-2019 Broken image
		if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
			imageType = imageType.toLowerCase()
		}
		if((encImg== 1) && (fullName != loggedInUserFullName) && (loggedMapRoleFlag == 0)){//Swathi- Encryption
			appendData += '<img id="userId_'+userId+'" class="ui mini circular image" src="/repopro/semantic/images/avatar/defaultUserImage.png" style="margin-left: 2em;">';
		} else{
			appendData += '<img id="userId_'+userId+'" class="ui mini circular image" src="/repopro/profileImages/'+userId+'.'+imageType+'" style="margin-left: 2em;">';
		}
		
	}
	appendData += '</div><div style="text-align: left; margin-top: 0.7em;">'+fullName+'</div></td>';
	appendData += '<td class="two wide center aligned">'+date+'</td>';
	//Swathi - Colour to distinguish the action - 10-09-2019
	if(action == "created") {
		appendData += '<td class="two wide center aligned createClass">'+action+'</td>';	
	} else if(action == 'updated') {
		appendData += '<td class="two wide center aligned updateClass">'+action+'</td>';
	} else if(action == "deleted"){
		appendData += '<td class="two wide center aligned deleteClass">'+action+'</td>';
	}
	
	appendData += '<td class="two wide center aligned">'+assetName+'</td>';
	if(assetInstVersionId != ""){
		appendData += '<td class="three wide center aligned"><a style="cursor: pointer;" onclick="getAssetInstances('+assetInstVersionId+',\''+encodedAssetInstName+'\')">'+assetInstanceName+'</a></td>';
	}else{
		appendData += '<td class="three wide center aligned">N/A</td>';
	}
	if(versionName != ""){
		appendData += '<td class="two wide center aligned">'+versionName+'</td>';
	}
	else{
		appendData += '<td class="two wide center aligned">N/A</td>';
	}
	
	appendData += '</tr>';
	
	return appendData;
}

function recentActivityExportToExcel(){
	var con = confirm("Please confirm to start the export");
	if(con == true){
		notifyMessage("","Export process has started. You will receive the file through mail.","success");
		$('#menu-google-plus').attr('href','/repopro/web/export/exportRecentActivity?userName='+loggedInUserName+'&tokenName='+localStorage.getItem('tokenGen'));
	} else {
		$('#menu-google-plus').attr('href','');
		return false;
	}

}