//get First Ten Leader Board Ranks
appendData = "";
function loadFirstTenLeaderBoardRanks(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/gameDetails/pointList?from=0&to=10&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			//console.log(" data "+JSON.parse(data.responseText))
			var json = JSON.parse(data.responseText);
			//console.log("  json "+JSON.stringify(json));
			if(json.status == "SUCCESS"){
				$('#loadLeaderBoardRankList').html("");
				$.each(json.result, function(i) {
					var count = 0;
					if(JSON.stringify(json.result[i].mapPointList) == "{}"){
						$('#loadLeaderBoardRankList').html('<div class="ui message">Leader board details not yet available</div>'); 
						$("#showAllLeaderBoard").hide();
					}
					else{
						$.each(json.result[i].mapPointList, function(key, value) {
							if(count < 10){
								var key = key.split("~");
								if(key[3] !== null){
									var imageType = key[3].split(".");
								}
								count++;
								var rankList =  getFirstTenLeaderBoardRanks(key[0], key[1], key[2],imageType[1],value,key[4]);
								$('#loadLeaderBoardRankList').append(rankList);
								
							}
							else{
								return false;
							}
						});

					}

				});

			}
		}
	});
}


function  getFirstTenLeaderBoardRanks(points, name, userId, imageType, rank,encImg){
if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
	imageType = imageType.toLowerCase()
}
	appendData = "";
	appendData += '<div class="middle aligned label " id="labelDataPaddingForLeaderBoard">';
	appendData += '<div class="left floated" style="padding-top:4px !important;">';
	appendData += '<span class="leaderBoardBackEndRank">'+rank+'</span></div>';

	if(typeof imageType == "undefined"){
		appendData += '<img id="userId_'+userId+'" class="ui avatar image" src="/repopro/semantic/images/avatar/defaultUserImage.png">';
	}else{
		if((encImg == 1) && (name != loggedInUserFullName) && (loggedMapRoleFlag == 0)){//Swathi- Encryption-07.01.2020
			appendData += '<img id="userId_'+userId+'" class="ui avatar image" src="/repopro/semantic/images/avatar/defaultUserImage.png">';
		} else {
		appendData += '<img id="userId_'+userId+'" class="ui avatar image" src="/repopro/profileImages/'+userId+'.'+imageType+'">';
		}
	}
	appendData += '<a id="backendLinkStyle" class="cardAnchorTextColor cardHeaderContentSpacing" onclick="getUserSpecificPointDetails('+userId+',false)" style="color: #4183C4;">'+name+'</a>';
	appendData += '<div class="right floated" style="padding-top:4px !important;">';
	appendData += '<span class="meta" id="metaPointSize" style="font-size: 14px !important;">'+points+'</span>';
	appendData += '</div></div>';
	return appendData;

}


