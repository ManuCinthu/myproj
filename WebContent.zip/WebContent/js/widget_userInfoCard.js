appendData = "";
//load My Favourites data  
function loadMyFavouritesDetails(){
	
	if(loggedInUserId != ""){
		$.ajax({
			type : "GET",
			url : "/repopro/web/favourite/id?userId="+loggedInUserId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				$('#myFavouriteWidget').html("");
				if(json.status == "SUCCESS"){
					$('#myFavouritesOnCard').html("");
					if(json.result == "" || json.result == null){
						$("#noFavourite").show();
					}else{
						$("#noFavourite").hide();
						$.each(json.result, function(i) {
							var favName = json.result[i].favName;
							var arr = favName.split("~");
							//var assetInstVersionName = arr[1].split("(");
							appendData = getMyFavouritesDetails(json.result[i].assetInstanceVersionId,json.result[i].assetInstName,json.result[i].assetName);
	
							$('#myFavouritesOnCard').append(appendData);
							var data = "<span style ='white-space:pre;'>"+json.result[i].assetInstName+" </span><span style='margin-left:0.5em; font-size:12px;color: #999999 !important; white-space:pre-wrap'>["+json.result[i].assetName+"]</span>";
							$("#assetInstanceId_"+json.result[i].assetInstanceVersionId).attr("data-html",data);
							$('.myFavLabelStyle').popup();
						});
	
					}
				}
				
			}
		});
	}
		
	
}

//get My Favourite data  
function getMyFavouritesDetails(assetInstanceId, assetInstanceName, assetName) {
	var encodedAssetInstName= encodeURIComponent(assetInstanceName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	var assetInstNameMini = assetInstanceName;
	 if(assetInstNameMini.length > 23){
		 assetInstNameMini = assetInstNameMini.substring(0,23) + "..";
	 } 
	 
	appendData = "";
	appendData += '<a class="ui label myFavLabelStyle letterSpacingHeader whitespaceNoTrim" style="font-size:9px !important;" id="assetInstanceId_'+assetInstanceId+'" style="min-width: 10em;" onclick="getAssetId('+assetInstanceId+',\''+encodedAssetInstName+'\')"><i class="star icon"></i>'+assetInstNameMini+'</a>';
	/*appendData += '<a class="myFavLabelStyle adminContentClass"  id="assetInstanceId_'+assetInstanceId+'" style="min-width: 10em;" onclick="getAssetId('+assetInstanceId+',\''+encodedAssetInstName+'\')"><i class="star icon"></i>'+assetInstNameMini+'</a><br>';*/
	return appendData;
}

//load Asset Instances Page
function getAssetId(assetInsId,assetInstanceName){
	getAssetInstances(assetInsId,assetInstanceName);
}

// display User Rank
function loadUserRank(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/gameDetails/userRank?userId="+loggedInUserId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(JSON.stringify(json.result[0].mapPointList) == "{}"){
				//$('#rankCount').parent().hide();
				$('#loggedInUserRank').css({
		            'pointer-events' : 'none',
		            'opacity' : '0.4'
		        });
				$('#loggedInUserRank').removeAttr("onclick");
				$("#rankCount").html("Unranked");
			}
			else {
			$.each(json.result[0].mapPointList, function(key,value) {
				$('#rankCount').text(value);
				$("#loggedinUserIdInCard").html(loggedInUserName);
			});
		}
		}
	});
}

