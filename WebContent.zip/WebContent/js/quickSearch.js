/*globalSearchValue = "";
globalSearchDd = "";*/
var arr = [];
function getImageInfo(){
	
	//alert("get info");
	if(loggedInUserName == "guest"){
		url = "/repopro/web/quickStat/getQuickStat?userName=roleAnonymous";
	}
	else{
		url = "/repopro/web/quickStat/getQuickStat?userName="+loggedInUserName;
	}
	$.ajax({
		type : "GET", 
		url : url,
		dataType : "json",
		async: true,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			appendData = "";
			if(json.status == "SUCCESS"){
				if(json.result != "" || json.result != null){
					var attr = [];
					var object = {}; 
					$.each(json.result, function(k) {
						object[json.result[k].assetId] = json.result[k].iconImageName;
						
					});
					attr.push(object);
					//console.log(" array  "+JSON.stringify(attr));
				 
					var len = json.result.length;
					$.each(json.result, function(k) {
					    arr.push({
					    	assetId: json.result[k].assetId,
					    	iconImageName: json.result[k].assetIconImageName
					    });
					});
					//console.log(" arr "+JSON.stringify(arr));
					/*console.log(" arr "+JSON.stringify(arr[0]));*/
					loadSearchedElements();
				}
			}
		}
	});
	
}
var assetTaxonomy = "";
var assetDetails = "";
var appendProfileDetails = "";
var quickSearchJSONData = "";
var JSONLength = 0;
var JSONRange = 20;
function loadSearchedElements(){
	//alert(" loadSearchedElements ");
	//souradip*************12.03.18
	$('#showHideLoader').removeClass('active');
	
	
	globalSearchValue = localStorage.getItem("searchValue");
	globalSearchDd = localStorage.getItem("searchDdValue");

	var encodedSearchValue = encodeURIComponent(globalSearchValue);
	//encodedSearchValue = encodedSearchValue.replace(/'/g, "\\'");
	encodedSearchValue = encodedSearchValue.replace(/"/g, '\\"');
	encodedSearchValue = encodedSearchValue.replace(/\\/g, "\\\\");
	var encodedGlobalSearchDd = encodeURIComponent(globalSearchDd);
	var url;
	if(loggedInUserName == "guest"){
		url = "/repopro/web/search/quickSearchUI?searchString="+encodedSearchValue+"&options="+encodedGlobalSearchDd+"&userName="+loggedInUserName;
	}
	else if(loggedInUserName == "admin"){
		url = "/repopro/web/search/quickSearchUI?searchString="+encodedSearchValue+"&options="+encodedGlobalSearchDd+"&userName="+loggedInUserName; 
	}else{
		url = "/repopro/web/search/quickSearchUI?searchString="+encodedSearchValue+"&options="+encodedGlobalSearchDd+"&userName="+loggedInUserName;
	}
	
	
	$.ajax({
		type : "GET",
		url : url,
		dataType : "json",
		async: true,
		complete : function(data) {	
			
			var json = JSON.parse(data.responseText);
			appendData = "";
			assetInstanceAppendData = "";
			assetTaxonomy = "";
			assetDetails = "";
			appendProfileDetails = "";
			quickSearchCallFlag = true;
			//console.log("json data : " + JSON.stringify(json.result));
			if(json.result == "" || json.result == null){
				$('#assetInstancesFloatingIcons').html("");
				$('#assetInstancesFloatingIcons').hide();
				$('#manageAssetInstanceQS, #manageTaxonomyQS, #manageAssetQS, #manageProfilesQS').hide();
				/*$('#searchDivider').html("<div class='ui negative message'>No matching results found</div>");*/
				$('#noSearchResFound').show();
				$("#quickSearchIcon").removeAttr("disabled");			}
			else{
				$('#noSearchResFound').hide();
				if(loggedInUserName != "roleAnonymous"){
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').show();
					$('#assetInstancesFloatingIcons').html('<span class="floatIcons" id="menu-share"><i style="margin-top:0.6em;margin-left:0.2em;" class="big sidebar icon"></i></span><ul class="floatingIconsUL"><li><a title="Export Data" id="searchAnchortag" onclick="return searchExportExcel()"><i class="upload icon" data-content="New User" data-variation="small" style="font-size: 1.5em !important; padding-top: 0.5em !important;padding-left: 0.2em !important;cursor: pointer;"  data-position="left center"></i></a></li></ul>');				
				}
				else{
					$('#assetInstancesFloatingIcons').html("");
					$('#assetInstancesFloatingIcons').hide();
				}
				$("#quickSearchHeader > span").html(json.result[0].totalCount+"  results");
				$('#manageAssetInstanceQS, #manageTaxonomyQS, #manageAssetQS, #manageProfilesQS').show();
				
				$('#quickSearchManageAssetInstancesDiv').html('');
				$('#quickSearchManageAssetDiv').html('');
				$('#quickSearchManageTaxonomyDiv').html('');
				$('#quickSearchManageProfilesDiv').html('');
				
				quickSearchJSONData = json.result[0].searchResponse;
				JSONLength = quickSearchJSONData.length;
				
				$.each(json.result[0].searchResponse, function(i) {
					//console.log(json.result[0].searchResponse[i].searchBy);
					if(i <= 20){
						//console.log(i);
						// Hema 28.Mar.2018 BOC
						if(json.result[0].searchResponse[i].searchBy == "Asset Instance"  || json.result[0].searchResponse[i].searchBy == "Parameters" || json.result[0].searchResponse[i].searchBy == "Tagging"){
							assetInstanceAppendData = getSearchDetails(json.result[0].searchResponse[i].assetInstName,json.result[0].searchResponse[i].assetName,json.result[0].searchResponse[i].assetInstVersionId,json.result[0].searchResponse[i].assetInstDescription,json.result[0].searchResponse[i].versionName,json.result[0].searchResponse[i].paramMap,json.result[0].searchResponse[i].assetDescription,json.result[0].searchResponse[i].assetId,json.result[0].searchResponse[i].searchBy,json.result[0].searchResponse[i].taxonomyName);
							//console.log("  assetInstanceAppendData "+assetInstanceAppendData);
							$('#quickSearchManageAssetInstancesDiv').append(assetInstanceAppendData);
						}
						else if(json.result[0].searchResponse[i].searchBy == "Asset"){
							assetDetails = getAssetDetails(json.result[0].searchResponse[i].assetName, json.result[0].searchResponse[i].assetDescription,json.result[0].searchResponse[i].taxonomyName);
							$('#quickSearchManageAssetDiv').append(assetDetails); 
						}
						else if(json.result[0].searchResponse[i].searchBy == "Taxonomy"){
							assetTaxonomy = getTaxonomyDetails(json.result[0].searchResponse[i].assetId,json.result[0].searchResponse[i].assetInstName,json.result[0].searchResponse[i].assetName,json.result[0].searchResponse[i].assetDescription,json.result[0].searchResponse[i].assetInstVersionId,json.result[0].searchResponse[i].assetInstDescription,json.result[0].searchResponse[i].taxonomyId,json.result[0].searchResponse[i].taxonomyName,json.result[0].searchResponse[i].versionName);
							$('#quickSearchManageTaxonomyDiv').append(assetTaxonomy); 
						
						}
						else if(json.result[0].searchResponse[i].searchBy == "Profile"){
							
							appendProfileDetails = getProfileDetails(json.result[0].searchResponse[i].userName,json.result[0].searchResponse[i].fullName,json.result[0].searchResponse[i].emailId,json.result[0].searchResponse[i].department,json.result[0].searchResponse[i].imageName,json.result[0].searchResponse[i].userId, json.result[0].searchResponse[i].encryptImage);
							//alert("  appendProfileDetails "+appendProfileDetails);
							$('#quickSearchManageProfilesDiv').append(appendProfileDetails); 
						}
					}else{
						return false;
					}
					//console.log(" appendData  "+appendData);
					/*$('#searchDivider').append(appendData);*/
					/* Hema 28.Mar.2018 EOC */					
				});
				//alert(" after each function");
				$("#quickSearchIcon").removeAttr("disabled");
				
				if($('#quickSearchManageAssetInstancesDiv').html() == ""){
					$('#manageAssetInstanceQS').hide();
				}else{
					$('#manageAssetInstanceQS').show();
				}
				
				if($('#quickSearchManageAssetDiv').html() == ""){
					$('#manageAssetQS').hide();
				}else{
					$('#manageAssetQS').show();
				}
				
				if($('#quickSearchManageTaxonomyDiv').html() == ""){
					$('#manageTaxonomyQS').hide();
				}else{
					$('#manageTaxonomyQS').show();
				}
				
				if($('#quickSearchManageProfilesDiv').html() == ""){
					$('#manageProfilesQS').hide();
				}else{
					$('#manageProfilesQS').show();
				}
				
				/*if(assetInstanceAppendData == ""){
					$('#manageAssetInstanceQS').hide();
				}
				if(assetDetails == ""){
					$('#manageAssetQS').hide();
				}
				if(assetTaxonomy == ""){
					$('#manageTaxonomyQS').hide();
				}
				if(appendProfileDetails == ""){
					$('#manageProfilesQS').hide();
				}*/
				
				// Hema 28.Mar.2018 BOC
				//console.log("globalSearchDd " + globalSearchDd);
				/*if(globalSearchDd == "Taxonomy"){
					$('#manageAssetInstanceQS, #manageAssetQS, #manageProfilesQS').hide();
					$('#manageTaxonomyQS').show();
				}
				
				else if(globalSearchDd == "Tags"){
					$('#manageAssetInstanceQS').show();
					$('#manageTaxonomyQS, #manageAssetQS, #manageProfilesQS').hide();
				}
				else if(globalSearchDd == "Keyword"){
					$('#manageAssetInstanceQS, #manageTaxonomyQS, #manageAssetQS').show();
				}*/
				/* Hema 28.Mar.2018 EOC */		
				
				
			}
			//souradip*************12.03.18
			//$('#showHideLoader').removeClass('active');
			$("#headingNameLoader").hide();
			
		}
	});
}

stopVisibleFunction = true;
//load Quick Search Data when Visible
function loadQuickSearchDataOnVisible(){
	$('#showHideLoader').removeClass('active');
	if(quickSearchJSONData != ""){
		//JSONLength ;JSONRange ;
		//console.log(JSONLength+"  _true1_  "+JSONRange);
			$.each(quickSearchJSONData, function(i) {
				
				if(i < (JSONLength + 1)){
					if(i > (JSONRange + 20)){
						return false;
					}
					if(JSONRange < i){
						//console.log("after"+ i);
						if(quickSearchJSONData[i].searchBy == "Asset Instance"  || quickSearchJSONData[i].searchBy == "Parameters" || quickSearchJSONData[i].searchBy == "Tagging"){
							assetInstanceAppendData = getSearchDetails(quickSearchJSONData[i].assetInstName,quickSearchJSONData[i].assetName,quickSearchJSONData[i].assetInstVersionId,quickSearchJSONData[i].assetInstDescription,quickSearchJSONData[i].versionName,quickSearchJSONData[i].paramMap,quickSearchJSONData[i].assetDescription,quickSearchJSONData[i].assetId,quickSearchJSONData[i].searchBy,quickSearchJSONData[i].taxonomyName);
							$('#quickSearchManageAssetInstancesDiv').append(assetInstanceAppendData);
						}
						else if(quickSearchJSONData[i].searchBy == "Asset"){
							assetDetails = getAssetDetails(quickSearchJSONData[i].assetName, quickSearchJSONData[i].assetDescription,quickSearchJSONData[i].taxonomyName);
							$('#quickSearchManageAssetDiv').append(assetDetails); 
						}
						else if(quickSearchJSONData[i].searchBy == "Taxonomy"){
							assetTaxonomy = getTaxonomyDetails(quickSearchJSONData[i].assetId,quickSearchJSONData[i].assetInstName,quickSearchJSONData[i].assetName,quickSearchJSONData[i].assetDescription,quickSearchJSONData[i].assetInstVersionId,quickSearchJSONData[i].assetInstDescription,quickSearchJSONData[i].taxonomyId,quickSearchJSONData[i].taxonomyName,quickSearchJSONData[i].versionName);
							$('#quickSearchManageTaxonomyDiv').append(assetTaxonomy); 
						}
						else if(quickSearchJSONData[i].searchBy == "Profile"){
							appendProfileDetails = getProfileDetails(quickSearchJSONData[i].userName,quickSearchJSONData[i].fullName,quickSearchJSONData[i].emailId,quickSearchJSONData[i].department,quickSearchJSONData[i].imageName,quickSearchJSONData[i].userId,quickSearchJSONData[i].encryptImage);
							$('#quickSearchManageProfilesDiv').append(appendProfileDetails); 
						}
						
						
					}
					
				}else{
					stopVisibleFunction = false;
					return false;
				}
	
			});
			
			
			if($('#quickSearchManageAssetInstancesDiv').html() == ""){
				$('#manageAssetInstanceQS').hide();
			}else{
				$('#manageAssetInstanceQS').show();
			}
			
			if($('#quickSearchManageAssetDiv').html() == ""){
				$('#manageAssetQS').hide();
			}else{
				$('#manageAssetQS').show();
			}
			
			if($('#quickSearchManageTaxonomyDiv').html() == ""){
				$('#manageTaxonomyQS').hide();
			}else{
				$('#manageTaxonomyQS').show();
			}
			
			if($('#quickSearchManageProfilesDiv').html() == ""){
				$('#manageProfilesQS').hide();
			}else{
				$('#manageProfilesQS').show();
			}
			
			JSONRange = JSONRange + 20;	

	}
		
}



function searchExportExcel(){
	
	searchString = localStorage.getItem("searchValue");
	globalSearchDd = localStorage.getItem("searchDdValue");
	var encodedSearchValue = encodeURIComponent(searchString);
	//encodedSearchValue = encodedSearchValue.replace(/'/g, "\\'");
	encodedSearchValue = encodedSearchValue.replace(/"/g, '\\"');
	encodedSearchValue = encodedSearchValue.replace(/\\/g, "\\\\");
	var con = confirm("Please confirm to start the export");
	if(con == true){
		notifyMessage("","Export process has started.","success");
		$('#searchAnchortag').attr("href","/repopro/web/export/exportQuickSearch?searchString="+encodedSearchValue+"&options="+globalSearchDd+"&userName="+loggedInUserName+"&tokenName="+localStorage.getItem("tokenGen"));
		//url = '/repopro/web/export/exportQuickSearch?searchString='+encodedSearchValue+'&options='+globalSearchDd+'&userName='+loggedInUserName+'&tokenName='+sessionStorage.getItem('tokenGen');
		/*console.log(" url "+url)*/
	} else {
		$('#searchAnchortag').attr("href","");
		return false;
	}

}

function getSearchDetails(assetInstName,assetName,assetInstVersionId,assetInstanceDesc,versionName,paramMap,assetDesc,assetId,searchBy,taxName){
	var encodedAssetInstName= encodeURIComponent(assetInstName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	
	appendData = "";
	$.each(arr, function(j) {
		if(arr[j].assetId == assetId){	
			appendData += '<div class="ui raised card minCardHeight quickSeachRes textFlow" style="width: 100% !important;"><span id="quickSearchAssetId_'+assetId+'" class="hidden"></span>';
			if(assetInstName != null && versionName != null){
				appendData += '<div class="content">';
				appendData += '<div class="header themeTextColor quickSearchHeaderCss"  style="cursor: pointer;padding: 2px;">';
				
				if(arr[j].iconImageName == null || arr[j].iconImageName == ""){
					if(circularThemeColoredIcon){
						appendData += '<div class="mediumIconImageCircleStyle_asset_themeCircle" style="font-size: 0.6em;">';
						if(invertAssetIconFlag){
							appendData += '<img class="mediumIconImageStyle invertImageColor" style="font-size: 7px;margin-top: 0.4em;"  id="quickSearchAssetImage_'+assetId+'"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png" ></div>';
						}else{
							appendData += '<img class="mediumIconImageStyle" style="font-size: 7px;margin-top: 0.4em;"  id="quickSearchAssetImage_'+assetId+'"  src="/repopro/semantic/images/defaultAssetIcon.svg" ></div>';
						}
						
					}else{
						appendData += '<div class="mediumIconImageCircleStyle_asset" style="font-size: 0.6em;">';
						if(invertAssetIconFlag){
							appendData += '<img class="mediumIconImageStyle invertImageColor" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png" ></div>';
						}else{
							appendData += '<img class="mediumIconImageStyle" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/semantic/images/defaultAssetIcon.svg" ></div>';
						}
					}
					
					
					appendData += '<span class="quickSearchHeaderStyle" onclick="getAssetInstances('+assetInstVersionId+',\''+encodedAssetInstName+'\')">'+assetInstName;
				}
				else{
					//var imgExtension = arr[j].iconImageName.split('.');
					var imgExtension = (arr[j].iconImageName).substring((arr[j].iconImageName).lastIndexOf(".") + 1, (arr[j].iconImageName).length);
					//Chandana - 13-9-2019 Broken image
					if (imgExtension == 'PNG' || imgExtension == 'JPEG' || imgExtension == 'JPG'){
						imgExtension = imgExtension.toLowerCase()
					}
					if(circularThemeColoredIcon){
						appendData += '<div class="mediumIconImageCircleStyle_asset_themeCircle" style="font-size: 0.6em;">';
						if(invertAssetIconFlag){
							appendData += '<img class="mediumIconImageStyle invertImageColor" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/assetImages/inverted_'+assetId+'.'+imgExtension+'" style="font-size: 7px;margin-top: 0.4em;"></div>';
						}else{
							appendData += '<img class="mediumIconImageStyle" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/assetImages/'+assetId+'.'+imgExtension+'" style="font-size: 7px;margin-top: 0.4em;"></div>';
						}
						
					}else{
						appendData += '<div class="mediumIconImageCircleStyle_asset" style="font-size: 0.6em;">';
						if(invertAssetIconFlag){
							appendData += '<img class="mediumIconImageStyle invertImageColor" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/assetImages/inverted_'+assetId+'.'+imgExtension+'" ></div>';
						}else{
							appendData += '<img class="mediumIconImageStyle" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/assetImages/'+assetId+'.'+imgExtension+'" ></div>';
						}
						
					}
					
					
					appendData += '<span class="quickSearchHeaderStyle"  onclick="getAssetInstances('+assetInstVersionId+',\''+encodedAssetInstName+'\')">'+assetInstName;
				}
				
				
				appendData += '</span></div></div>';
			}
			appendData += '<div class="content">';
			appendData += '<div class="ui grid" style="margin-left: 1em;">';


			if(assetName != null){
				appendData += '<div class="two wide column headerItalic removePaddingForSearch"><div class="quicksearchFontSize">AssetName:</div></div>';
				appendData += '<div class="fourteen wide column quicksearchFontSize removePaddingForSearch">'+assetName+'</div>';
			}

			if(assetInstanceDesc != null){
				appendData += '<div class="two wide column headerItalic removePaddingForSearch"><div class="quicksearchFontSize">Asset Instance Description:</div></div>';
				appendData += '<div class="fourteen wide column quicksearchFontSize removePaddingForSearch">'+assetInstanceDesc+'</div>';
			}
			
			
			if(assetInstVersionId != null){
				appendData += '<div class="two wide column headerItalic removePaddingForSearch"><div class="quicksearchFontSize">Version Id:</div></div>';
				appendData += '<div class="fourteen wide column quicksearchFontSize removePaddingForSearch">'+assetInstVersionId+'</div>';
			}
			if(versionName != null){
				appendData += '<div class="two wide column headerItalic removePaddingForSearch"><div class="quicksearchFontSize" style=" padding-bottom: 1rem !important;">Version Name:</div></div>';
				appendData += '<div class="fourteen wide column quicksearchFontSize removePaddingForSearch">'+versionName+'</div>';
			}
			if(taxName != null){
				/*appendData += '<div class="ui grid">';*/
				appendData += '<div class="two wide column removePaddingForSearch"><div class="quicksearchFontSize" style=" padding-bottom: 1rem !important;"></div></div>';
				appendData += '<div class="fourteen wide column removePaddingForSearch"><div class="quicksearchFontSize" style=" padding-bottom: 1rem !important;">This Asset Instance is mapped with '+taxName+'.</div></div>';
				/*appendData += '</div>';	*/
			}
			if(paramMap != null){
				
				appendData += '<div class="two wide column headerItalic removePaddingForSearch"><div class="quicksearchFontSize" style=" padding-bottom: 1rem !important;">Metadata:</div></div><div class="fourteen wide column wrapValue">';
				$.each(paramMap, function(key, value) {

					key = key.split("`~`");
					if(key[1] == 1){
						/*alert("1 "+value);
						alert(jQuery.type(value));*/
						appendData += '<div class="fourteen wide column" style=" padding-bottom: 1rem !important;">';
						appendData += '<span class="two wide column quicksearchFontSize">'+key[0]+':</span>';
						var textData  = " ";
						$.each( value, function(q) {
							textData = textData + value[q] + ",";
						});
						textData = textData.substring(0, textData.length-1);
						//console.log(" abc "+textData);
						appendData += '<span class="fourteen wide column quicksearchFontSize" style=" padding-bottom: 1rem !important;">'+textData+'</span>';
						appendData += '</div>'
					}
					else if(key[1] == 7){
						/*alert("7 "+value);
						alert(jQuery.type(value));*/
						appendData += '<div class="fourteen wide column">';
						appendData += '<span class="two wide column quicksearchFontSize">'+key[0]+':</span>';
						/*$.each( value, function(p) {*/
							/*var formatted =  formatXml(value[p]);
							formatted = formatted.trim();
							formatted =	hljs.highlightAuto(formatted);*/
							appendData += '<span class="fourteen wide column removePaddingForSearch quicksearchFontSize" style=" padding-bottom: 1rem !important;"><div style="max-height: 15em !important;overflow-y: auto;">'+value+'</div></span>';
						/*});*/
						appendData += '</div>'
						
						
					}else if(key[1] == 4){
						/*alert("7 "+value);
						alert(jQuery.type(value));*/
						value = value.replace(/~~/g,",");
						appendData += '<div class="fourteen wide column quicksearchFontSize">'+key[0]+'  :  '+value+'</div>';
						
					}
					else if(key[1] == 2){
						// changes for date
						/*alert("1 "+value);
						alert(jQuery.type(value));*/
						appendData += '<div class="fourteen wide column" style=" padding-bottom: 1rem !important;">';
						appendData += '<span class="two wide column quicksearchFontSize">'+key[0]+':</span>';
						var dateType  = " ";
						$.each( value, function(q) {
							dateType = dateType + value[q] + ",";
						});
						dateType = dateType.substring(0, dateType.length-1);
						//console.log(" abc "+textData);
						appendData += '<span class="fourteen wide column quicksearchFontSize" style=" padding-bottom: 1rem !important;">'+dateType+'</span>';
						appendData += '</div>'
					}
					else if(key[1] == 3){
						// changes for date
						/*alert("1 "+value);
						alert(jQuery.type(value));*/
						appendData += '<div class="fourteen wide column" style=" padding-bottom: 1rem !important;">';
						appendData += '<span class="two wide column quicksearchFontSize">'+key[0]+':</span>';
						var fileType  = " ";
						$.each( value, function(q) {
							fileType = fileType + value[q] + ",";
						});
						fileType = fileType.substring(0, fileType.length-1);
						//console.log(" abc "+textData);
						appendData += '<span class="fourteen wide column quicksearchFontSize" style=" padding-bottom: 1rem !important;">'+fileType+'</span>';
						appendData += '</div>'
					}
					else if(key[1] == 9){
						$.each( value, function(q) {
							if (value[q].indexOf("~~") > -1)
							{
								value[q] = value[q].replace(/~~/g,",");
							}
						});
						appendData += '<div class="fourteen wide column quicksearchFontSize">'+key[0]+'  :  '+value+'</div>';
						
					}
					
					else{
						/*alert("else");
						alert(jQuery.type(value));*/
						
						appendData += '<div class="fourteen wide column quicksearchFontSize">'+key[0]+'  :  '+value+'</div>';
					}
					
				});

			}
			appendData += '</div></div></div>';
	
		}
	});
	
	return appendData;
}
function getTaxonomyDetails(assetId,assetInstName,assetName,assetDescription,assetInstVersionId,assetInstanceDesc,taxId,taxName,versionName){

	var encodedAssetInstName= encodeURIComponent(assetInstName);
	encodedAssetInstName = encodedAssetInstName.replace(/'/g, "\\'");
	
	
    //console.log(" assetId  "+assetId+" assetInstName "+assetInstName+" assetName "+assetName+" assetInstanceDesc "+assetInstanceDesc);
    //console.log(" assetInstVersionId  "+assetInstVersionId+" versionName "+versionName);

    appendData = "";
	appendData += '<div class="ui raised card minCardHeight quickSeachRes textFlow" style="width: 100% !important;">';
	$.each(arr, function(m) {
		//console.log(" arr "+arr.length);
		if(arr[m].assetId == assetId){
			//alert(" if ");
			if(assetInstName != null  && versionName != null){
				appendData += '<div class="content">';
				appendData += '<div class="header themeTextColor quickSearchHeaderCss"  style="cursor: pointer;padding: 2px;">';
				/*if(arr[m].iconImageName == null || arr[m].iconImageName == ""){
					appendData += '<img id="quickSearchAssetImage_'+assetId+'" class="ui avatar image" src="/repopro/semantic/images/avatar/defaultUserImage1.png" style="margin-right: 11px; width: 1.1em; height: 1.1em;"><span onclick="getAssetInstances('+assetInstVersionId+',\''+encodedAssetInstName+'\')">'+assetInstName;
				}
				else{
					var imgExtension = arr[m].iconImageName.split('.');
					appendData += '<img id="quickSearchAssetImage_'+assetId+'" class="ui avatar image" src="/repopro/assetImages/'+assetId+'.'+imgExtension[1]+'" style="margin-right: 11px; width: 1.1em; height: 1.1em;"><span onclick="getAssetInstances('+assetInstVersionId+',\''+encodedAssetInstName+'\')">'+assetInstName;

				}*/	
				
				if(arr[m].iconImageName == null || arr[m].iconImageName == ""){
					if(circularThemeColoredIcon){
						appendData += '<div class="mediumIconImageCircleStyle_asset_themeCircle" style="font-size: 0.6em;">';
						if(invertAssetIconFlag){
							appendData += '<img class="mediumIconImageStyle invertImageColor" style="font-size: 7px;margin-top: 0.4em;"  id="quickSearchAssetImage_'+assetId+'"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png" ></div>';
						}else{
							appendData += '<img class="mediumIconImageStyle" style="font-size: 7px;margin-top: 0.4em;"  id="quickSearchAssetImage_'+assetId+'"  src="/repopro/semantic/images/defaultAssetIcon.svg" ></div>';
						}
						
					}else{
						appendData += '<div class="mediumIconImageCircleStyle_asset" style="font-size: 0.6em;">';
						if(invertAssetIconFlag){
							appendData += '<img class="mediumIconImageStyle invertImageColor" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/semantic/images/inverted_defaultAssetIcon.png" ></div>';
						}else{
							appendData += '<img class="mediumIconImageStyle" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/semantic/images/defaultAssetIcon.svg" ></div>';
						}
					}
					
					
					appendData += '<span class="quickSearchHeaderStyle" onclick="getAssetInstances('+assetInstVersionId+',\''+encodedAssetInstName+'\')">'+assetInstName;
				}
				else{
					//var imgExtension = arr[m].iconImageName.split('.');
					var imgExtension = (arr[j].iconImageName).substring((arr[j].iconImageName).lastIndexOf(".") + 1, (arr[j].iconImageName).length);
					if (imgExtension == 'PNG' || imgExtension == 'JPEG' || imgExtension == 'JPG'){
						imgExtension = imgExtension.toLowerCase()
					}
					if(circularThemeColoredIcon){
						appendData += '<div class="mediumIconImageCircleStyle_asset_themeCircle" style="font-size: 0.6em;">';
						if(invertAssetIconFlag){
							appendData += '<img class="mediumIconImageStyle invertImageColor" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/assetImages/inverted_'+assetId+'.'+imgExtension+'" style="font-size: 7px;margin-top: 0.4em;"></div>';
						}else{
							appendData += '<img class="mediumIconImageStyle" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/assetImages/'+assetId+'.'+imgExtension+'" style="font-size: 7px;margin-top: 0.4em;"></div>';
						}
						
					}else{
						appendData += '<div class="mediumIconImageCircleStyle_asset" style="font-size: 0.6em;">';
						if(invertAssetIconFlag){
							appendData += '<img class="mediumIconImageStyle invertImageColor" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/assetImages/inverted_'+assetId+'.'+imgExtension+'" ></div>';
						}else{
							appendData += '<img class="mediumIconImageStyle" id="quickSearchAssetImage_'+assetId+'"  src="/repopro/assetImages/'+assetId+'.'+imgExtension+'" ></div>';
						}
						
					}
					
					
					appendData += '<span class="quickSearchHeaderStyle"  onclick="getAssetInstances('+assetInstVersionId+',\''+encodedAssetInstName+'\')">'+assetInstName;
				}
				
				appendData += '</span></div></div>';
			}
			appendData += '<div class="content">';
			appendData += '<div class="ui grid" style="margin-left: 1em;">';

			if(assetName != null){
				appendData += '<div class="three wide column removePaddingForSearch"><div class="quicksearchFontSize">Asset Name:</div></div>';
				appendData += '<div class="thirteen wide column quicksearchFontSize removePaddingForSearch">'+assetName+'</div>';
			}
			if(assetDescription != null){
				appendData += '<div class="three wide column removePaddingForSearch"><div class="quicksearchFontSize">Asset Description:</div></div>';
				appendData += '<div class="thirteen wide column quicksearchFontSize removePaddingForSearch">'+assetDescription+'</div>';
			}

			if(assetInstanceDesc != null){
				appendData += '<div class="three wide column removePaddingForSearch"><div class="quicksearchFontSize">Description:</div></div>';
				appendData += '<div class="thirteen wide column quicksearchFontSize removePaddingForSearch">'+assetInstanceDesc+'</div>';
			}
			if(assetInstVersionId != null){
				appendData += '<div class="three wide column removePaddingForSearch"><div class="quicksearchFontSize">Version Id:</div></div>';
				appendData += '<div class="thirteen wide column quicksearchFontSize removePaddingForSearch">'+assetInstVersionId+'</div>';
			}
			if(versionName != null){
				appendData += '<div class="three wide column removePaddingForSearch"><div class="quicksearchFontSize">Version Name:</div></div>';
				appendData += '<div class="thirteen wide column quicksearchFontSize removePaddingForSearch">'+versionName+'</div>';
			}
			appendData += '</div>';	
		}
	});
	
	if(assetId == null){
		appendData += '<div class="content" style="min-height: 5em;">';
		appendData += '<div class="ui grid" style="margin-left: 1em;">';
	    appendData += '<div class="three wide column removePaddingForSearch">';
	    appendData += '<div class="quicksearchFontSize">Tax Id:</div>';
	    appendData += '</div>';
		appendData += '<div class="thirteen wide column quicksearchFontSize removePaddingForSearch">'+taxId+'</div>';		
		appendData += '<div class="three wide column removePaddingForSearch">';
	    appendData += '<div class="quicksearchFontSize">Tax Name:</div>';
	    appendData += '</div>';
		appendData += '<div class="thirteen wide column quicksearchFontSize removePaddingForSearch">'+taxName+'</div>';
		appendData += '</div>';
		appendData += '</div>';
		
	}else{
		appendData += '<div class="ui grid" style="margin-left: 1em;">';
		appendData += '<div class="three wide column removePaddingForSearch"><div class="quicksearchFontSize" style=" padding-bottom: 1rem !important;"></div></div>';
		appendData += '<div class="sixteen wide column removePaddingForSearch"><div class="quicksearchFontSize" style=" padding-bottom: 1rem !important;">This asset is mapped with '+taxName+'.</div></div>';
		appendData += '</div>';	
	}
	
	appendData += '</div>';	
	return appendData;
}
function getProfileDetails(userName,fullName,email,dept,imageName,userId, encImgId){
	if(imageName != null){
		var imageType  = imageName.split(".");
		imageType = imageType[1];
		if (imageType == 'PNG' || imageType == 'JPEG' || imageType == 'JPG'){
			imageType = imageType.toLowerCase()
		}
		appendData = "";
		appendData += '<div class="ui raised card" style="width: 100% !important;">';
		appendData += '<div class="content">';
		appendData += '<div class="right floated author">';
		if(typeof imageType == "undefined" || imageType == null){
			appendData += '<img id="userId_'+userId+'" class="ui mini circular image" src="/repopro/semantic/images/avatar/defaultUserImage.png">';	
		}
		else{	
			//Swathi- Encryption - 02.01.2020
			if((encImgId == 1) && (userName !=loggedInUserName) && (loggedMapRoleFlag == 0)){
				appendData += '<img id="userId_'+userId+'" class="ui mini circular image" src="/repopro/semantic/images/avatar/defaultUserImage.png">';	
			} else{
				appendData += '<img id="userId_'+userId+'" class="ui mini circular image" src="/repopro/profileImages/'+userId+'.'+imageType+'">';
			}
			
		}
		appendData += '</div>';
		appendData += '<div class="header themeTextColor quickSearchHeaderCss" style="padding: 2px;"><i class="search icon" style="margin-right:0.5em;"></i>'+userName+'</div>';
		appendData += '</div>';
		appendData += ' <div class="content minCardHeight ">';
		appendData += '<div class="ui grid" style="margin-left: 1em;">';
		appendData += ' <div class="two wide column headerItalic removePaddingForSearch"><div class="quicksearchFontSize">Full Name:</div></div>';
		appendData += ' <div class="fourteen wide column quicksearchFontSize removePaddingForSearch">'+fullName +'</div>';
		appendData += ' <div class="two wide column headerItalic removePaddingForSearch"><div class="quicksearchFontSize">Email:</div></div>';
		appendData += '<div class="fourteen wide column quicksearchFontSize removePaddingForSearch">'+email+'</div>';
		appendData += '<div class="two wide column headerItalic"><div class="quicksearchFontSize">Department:</div></div>';
		appendData += '<div class="fourteen wide column quicksearchFontSize">'+dept+'</div>';
		appendData += '</div></div></div>';

		return appendData;
	}
	else{
		appendData = "";
		appendData += '<div class="ui raised card" style="width: 100% !important;">';
		appendData += '<div class="content">';
		appendData += '<div class="right floated author">';
		appendData += '</div>';
		appendData += '<div class="header themeTextColor quickSearchHeaderCss" style="padding: 2px;"><i class="search icon" style="margin-right:0.5em;"></i>'+userName+'</div>';
		appendData += '</div>';
		appendData += ' <div class="content minCardHeight">';
		appendData += '<div class="ui grid" style="margin-left: 1em;">';
		appendData += ' <div class="two wide column headerItalic removePaddingForSearch"><div class="quicksearchFontSize">Full Name:</div></div>';
		appendData += ' <div class="fourteen wide column quicksearchFontSize removePaddingForSearch">'+fullName +'</div>';
		appendData += ' <div class="two wide column headerItalic removePaddingForSearch"><div class="quicksearchFontSize">Email:</div></div>';
		appendData += '<div class="fourteen wide column quicksearchFontSize removePaddingForSearch">'+email+'</div>';
		appendData += '<div class="two wide column headerItalic"><div class="quicksearchFontSize">Department:</div></div>';
		appendData += '<div class="fourteen wide column quicksearchFontSize">'+dept+'</div>';
		appendData += '</div></div></div>';

		return appendData;
	}
}
function displayExtraContent(){
	$("#showHideExtraParams").slideToggle(1000);
}

// Hema 28.Mar.2018 BOC
function getAssetDetails(assetName,assetDescription,taxName){
	appendData = "";
	appendData += '<div class="ui raised card minCardHeight quickSeachRes textFlow" style="width: 100% !important;">';
	appendData += '<div class="content" style="min-height: 5em;">';
	appendData += '<div class="ui grid" style="margin-left: 1em;">';
    appendData += '<div class="three wide column removePaddingForSearch">';
    appendData += '<div class="quicksearchFontSize">Asset Name:</div>';
    appendData += '</div>';
	appendData += '<div class="thirteen wide column quicksearchFontSize removePaddingForSearch">'+assetName+'</div>';		
	appendData += '<div class="three wide column removePaddingForSearch">';
    appendData += '<div class="quicksearchFontSize">Asset Description:</div>';
    appendData += '</div>';
	appendData += '<div class="thirteen wide column quicksearchFontSize removePaddingForSearch">'+assetDescription+'</div>';
	if(taxName != null){
		/*appendData += '<div class="ui grid">';*/
		appendData += '<div class="three wide column removePaddingForSearch"><div class="quicksearchFontSize" style=" padding-bottom: 1rem !important;"></div></div>';
		appendData += '<div class="thirteen wide column removePaddingForSearch"><div class="quicksearchFontSize" style=" padding-bottom: 1rem !important;">This asset is mapped with '+taxName+'.</div></div>';
		/*appendData += '</div>';	*/
	}
	
	
	appendData += '</div>';
	appendData += '</div>';
	appendData += '</div>';	
	return appendData;
	
}
// EOC




