//load guest access data from database 
function loadGuestAccessDetails(){
	appendData = "";
	$.ajax({
		type : "GET",
		url : "/repopro/web/guestAccess",
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result == "" || json.result == null){
					$('#GuestAccessGrid').hide();
					$('#noGridData').show();
					$('#noGridData').html('<div class="ui teal message"><i class="hourglass empty icon"></i>No roles added yet</div>'); 
				}else {
					$('#noGridData').hide();
					$('#GuestAccessGrid').show();
					$('#GuestAccessGrid table tbody').html("");
					$.each(json.result, function(i) {
						appendData = getGuestAccessDetails(json.result[i].assetId,json.result[i].assetName,json.result[i].description, json.result[i].guestflag);
						$('#GuestAccessGrid table tbody').append(appendData);
					});		
				}
			}

		}
	});
}

//appending table body to guest access grid on load 	
function getGuestAccessDetails(guestAssetId,guestAssetName,guestAssetDescription, guestflag){
	var guestAssetName = guestAssetName;
	appendData = "";
	appendData += '<tr id="trManageguestAsset'+guestAssetId+'">';
	appendData += '<td class="hidden" id="guestAssetId_'+ guestAssetId +'">' + guestAssetId + '</td>';

	if(guestflag == true){
		appendData += '<td id="guestAssetName_'+guestAssetId+'">' + guestAssetName + '</td>';
		appendData += '<td id="guestAssetDescription_'+guestAssetId+'">'+ guestAssetDescription + '</td>';
		appendData += '<td class="two wide center aligned" id="guestAssettoggle_1">';
		appendData += '<div class="ui fitted slider checkbox">';
		appendData += '<input checked id="enableDisableGuest_'+guestAssetId+'" class="checkBoxEnableDisableGuest" onclick="SaveGuestAsset(this,\''+guestAssetName+'\')" type="checkbox"><label></label>';
		appendData += '</div>';	

	}
	else if(guestflag == false){
		appendData += '<td id="guestAssetName_'+guestAssetId+'" class="disabled">' + guestAssetName + '</td>';
		appendData += '<td id="guestAssetDescription_'+guestAssetId+'" class="disabled">'+ guestAssetDescription + '</td>';
		appendData += '<td class="two wide center aligned" id="guestAssettoggle_1">';
		appendData += '<div class="ui fitted slider checkbox">';
		appendData += '<input id="enableDisableGuest_'+guestAssetId+'" class="checkBoxEnableDisableGuest" onclick="SaveGuestAsset(this,\''+guestAssetName+'\',\''+guestAssetId+'\')" type="checkbox"><label></label>';
		appendData += '</div>';	

	}

	appendData += '</td>';
	appendData += '</tr>';
	return appendData;
}

//save guest access data 
function SaveGuestAsset(obj, guestAssetName,guestAssetId){
	var GuestAssetCheckbox = "";
	if($(obj).is(":checked")){
		GuestAssetCheckbox = true;	
		$('#guestAssetName_'+guestAssetId).removeClass('disabled');
		$('#guestAssetDescription_'+guestAssetId).removeClass('disabled');
	}
	else {
		GuestAssetCheckbox = false;
		$('#guestAssetName_'+guestAssetId).addClass('disabled');
		$('#guestAssetDescription_'+guestAssetId).addClass('disabled');
	}

	var data = {
			"assetName" : guestAssetName,
			"guestflag" : GuestAssetCheckbox	
	} 

	$.ajax({
		type: "PUT",
		url: "/repopro/web/guestAccess/saveGuestAccess",
		contentType : "application/json",
		dataType : "json",
		data : JSON.stringify(data),
		async: false,
		cache: false,
		complete:function(data){
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				notifyMessage("Save Guest Asset","Guest assets are saved successfully.","success");	
			}
			else {
				notifyMessage("Save Guest Asset",json.message,"fail");
			}
		}
	});
}
