// load role data from database 
appendData = "";
	function loadRolesDetails(){
		$.ajax({
			type : "GET",
			url : "/repopro/web/roledetails/rolelist",
			dataType : "json",
			async: false,
			cache: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(json.result.length == 2){
						$('#rolesGrid').hide();
						$('#noGridData').show();
						$('#noGridData').html('<div class="ui message">No roles added yet</div>'); 
					}
					else {
						$('#noGridData').hide();
						$('#rolesGrid').show();
						$('#rolesGrid table tbody').html("");
							$.each(json.result, function(i) {
								appendData = getRoleDetails(json.result[i].roleId,json.result[i].roleName,json.result[i].description,json.result[i].groupRoleFlag);
								$('#rolesGrid table tbody').append(appendData);
								if(json.result[i].roleName == "role-admin" || json.result[i].roleName == "Guest"){
									$("#trManageRole"+json.result[i].roleId).addClass("hidden");
								}
							});

						}
					}
				$('#showHideLoader').removeClass('active');
				}
			});
	}

	function getRoleDetails(roleId, roleName, roleDescription,roleFlag) {
		var data = "<p>Are you sure you want to delete "+roleName+" ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteRolePopup("+roleId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteRole(this,"+roleId+")'>Yes</button> ";
		appendData = "";
		appendData += '<tr id="trManageRole'+roleId+'">';
		appendData += '<td class="hidden" id="roleId_'+ roleId +'">' + roleId + '</td>';
		appendData += '<td class= "whitespaceNoTrim" id="roleName_'+roleId+'">';
		appendData += '<div><div class="mediumIconImageCircleStyle"><i class="user icon sidebarIcons widgetIconColor" style="margin-top: 0.4em;margin-left: 0.7em !important;"></i></div><span class="gridImageTextSpacing">'+roleName+'</span></div></td>';
		appendData += '<td class= "whitespaceNoTrim" id="roleDescription_'+roleId+'">'+ roleDescription + '</td>';
		appendData += '<td><a><i class="edit icon deleteEditIcon" onclick="openEditRole(this,'+roleId+')"></i></a></td>';
		if(roleFlag == true){
			appendData += '<td class="disabled disableDeleteIcon"><span data-tooltip="Cannot delete this role. Role is associated with group(s)." data-position="left center"><i class="trash icon" id="trash_'+roleId+'" ></i></span></td>';
		}
		else {
			appendData += '<td><a><i class="trash icon deleteEditIcon" id="trash_'+roleId+'" data-html="'+data+'" onclick="openDeleteRolePopup('+roleId+')"></i></a></td>';
		}
		appendData += '</tr>';
		return appendData;
	}
	
	// Add role
		function openAddRole(){
			/*$("#addRoleDescription").attr('maxlength','100');
			$("#addRoleDescriptionCounter").html('Maximum Characters: 100');*/
			$('#submitAddedRoles').unbind();  //add submit button id
	        $('#cancelAddedRoles').unbind();
	        $(".errAddRoleName").hide();
	        $('#addRoleName').parent().removeClass("error");
	        $(".errAddRoleDescription").hide();
	        $('#addRoleDescription').parent().removeClass("error"); 
			$('#addRole').modal('setting', 'closable', false).modal('show');
			appendAddGroup = "";
			$("#addRoleName").val("");
			$("#addRoleDescription").val("");
			
			//Count Characters Remaining
			/*addEventListener('input',function () {
				var charactersS = 100 - $('#addRoleDescription').val().length;
				$('#addRoleDescriptionCounter').html('Characters Remaining: ' + charactersS);
			});*/
			
			// submit added group
			$('#submitAddedRoles').on('click', function(){
				 var addRoleName = $("#addRoleName").val().trim();
			     var addRoleDescription = $("#addRoleDescription").val().trim(); 
			     var flag = true;	
			     $(".errAddRoleName").hide();
			     $('#addRoleName').parent().removeClass("error");
			     
			     if(addRoleName == null || addRoleName == ""){
			    	$('#addRoleName').parent().addClass("error"); 
				    $(".errAddRoleName").html('Please provide role name').show();  
					flag = false;
				}
				else{
					var regex = /^[a-zA-Z0-9- \-\_]*$/;
					if (regex.test(addRoleName) == false) {
						$('#addRoleName').parent().addClass("error"); 
					    $(".errAddRoleName").html("Please use only alphanumeric characters, space, \"-\" and \"_\" in role name.").show();  
						flag = false;
					}
					else{
						$('#addRoleName').parent().removeClass("error"); 
						$(".errAddRoleName").hide(); 
					}
					
				}
		     
		     if(addRoleDescription == null || addRoleDescription == ""){
		    	  $('#addRoleDescription').parent().addClass("error"); 
				  $(".errAddRoleDescription").show();  
				  flag = false;
			}
			else{
				$('#addRoleDescription').parent().removeClass("error"); 
				$(".errAddRoleDescription").hide(); 
			}
		     if(flag == false){
		        $('#addRole').modal('show');
				return false;
		     }
		     else {
		    	var obj = {
		    			  "roleName": addRoleName,
		    			  "description": addRoleDescription
						};
		    	//console.log(" obj "+JSON.stringify(obj));
				  $.ajax({
				       type: "POST",
				       url: "/repopro/web/roledetails",
				       contentType : "application/json",
						dataType : "json",
						data : JSON.stringify(obj),
						async: false,
						cache: false,
						complete:function(data){	
						appenddata = "";
						var json = JSON.parse(data.responseText);
						var roleId = "";
						if(json.status == "SUCCESS"){
								
								//appendData = getRoleDetails(json.result[0].roleId, addRoleName, addRoleDescription);
								
								//$('#rolesGrid table tbody').append(appendData);
								loadRolesDetails();
								$('#addRoleName').parent().removeClass("error");
								$(".errAddRoleName").hide();
								notifyMessage("Add Role","Role added","success")
							}
						else {
								$('#addRoleName').parent().addClass("error"); 
								if(json.message = "ROLE BY THIS NAME ALREADY EXISTS, PLEASE PROVIDE DIFFERENT NAME"){
									 $(".errAddRoleName").html("Role name already exists").show(); 
								}else {
									$(".errAddRoleName").html(json.message).show(); 
								}
								flag = false;
							}	
						}
				  });
		    	
			}
		     if(flag == false){
		    	$('#addRole').modal('show');
				return false;
		     }
		     else{
		    	 $('#addRole').modal('hide'); //.modal('hide dimmer'); 
		    	 $('#addRole').parent().css("display", "none !important");
		     }
			$("html, body").animate({
					 scrollTop: 0
					 }, 10);
		     }); 	
	}
	var addedFunctionIds = [] ;
	// Edit Role 
	function openEditRole(obj, roleId){
		/*$("#editRoleDescription").attr('maxlength','100');
		$("#editRoleDescriptionCounter").html('Maximum Characters: 100');*/
		//cancelAssociatedFunctionsRole
		$('#editRole').modal('destroy');
		$("#editRole").nextAll().remove();
		
		
		$('#submitEditAssociatedRole').unbind();
		$('#cancelAssociatedFunctionsRole').unbind();
		$('#editRoleName').parent().removeClass("error"); 
		$(".errEditRoleName").hide();
		$('#editRoleDescription').parent().removeClass("error"); 
		$(".errEditRoleDescription").hide(); 
		var roleName = $("#roleName_"+roleId).text();
		var roleDescription = $("#roleDescription_"+roleId).text();
		$("#editRoleName").val(roleName);
		$("#editRoleDescription").val(roleDescription); 
		$('#editRole').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	
		
	
		
		/*Added By Hema BOC*/
		$('#RoleName').text(roleName);
		/*EOC*/  
		
		//Count Characters Remaining
		/*addEventListener('input',function () {
			var charactersS = 100 - $('#editRoleDescription').val().length;
			$('#editRoleDescriptionCounter').html('Characters Remaining: ' + charactersS);
		});
		*/
		appendData = "";
		$.ajax({
			type: "GET",
			url: "/repopro/web/roledetails/"+roleId,
			dataType: "json",
			async: false,
			cache: false,
			complete:function(data){										
				var json = JSON.parse(data.responseText);
				//console.log("  role id "+roleId+"json   "+JSON.stringify(json));
				if(json.status == "SUCCESS"){
					
					$('#gridAssociatedFunctions table tbody').html("");
					$.each(json.result, function(i) {
						appendData = getAssociatedFunctionsDetails(json.result[i].functionId,json.result[i].functionName,json.result[i].mappedWithRole);
						$('#gridAssociatedFunctions table tbody').append(appendData);
						
						
						if(json.result[i].functionId == 22 || json.result[i].functionId == 24){
							$("#functionId_"+json.result[i].functionId).parent().hide();
						}
					});
					
					
					
				}
			}
		});	
		
		// Select all roles on load of edit role modal - chandana 31.01.2020 #670
		var getHiddenRowsValue = $('#tableAssociatedFunctions tr').filter(function() {
		    return $(this).css('display') == 'none';
		}).length;
		var roleFunctionTrLength = '';
		
		if(getHiddenRowsValue > 0){
			roleFunctionTrLength = $('.roleFunction').length - 2;
			roleFunctionTrLength = roleFunctionTrLength ;
		}
		else{
			roleFunctionTrLength = $('.roleFunction').length; 
		}
		
		if ($('.roleFunction:checked:visible').length == roleFunctionTrLength ){
			$("#selectAllAssociatedFunctionsRoles").prop('checked', true);
		}
		else{
			$("#selectAllAssociatedFunctionsRoles").prop('checked', false); 
		}
		
		
		// submit edited roles
		$('#submitEditAssociatedRole').on('click', function(){
			 var editRoleName = $("#editRoleName").val().trim();
		     var editRoleDescription = $("#editRoleDescription").val().trim(); 
		     var flag = true;	
		     
		     if(editRoleName == null || editRoleName == ""){
		    	$('#editRoleName').parent().addClass("error"); 
			    $(".errEditRoleName").html('Please provide role name').show();  
				flag = false;
			}/*else{
				var regex = /^[a-zA-Z0-9- \-\_]*$/;
				if (regex.test(editRoleName) == false) {
					$('#editRoleName').parent().addClass("error"); 
				    $(".errEditRoleName").html("Please use only alphanumeric characters, space, \"-\" and \"_\" in role name.").show();  
					flag = false;
				}
				else{				
					$('#editRoleName').parent().removeClass("error"); 
					$(".errEditRoleName").hide(); 
				}
			}*/
	     
	     if(editRoleDescription == null || editRoleDescription == ""){
	    	  $('#editRoleDescription').parent().addClass("error"); 
			  $(".errEditRoleDescription").show();  
				 flag = false;
		}
		else{
			$('#editRoleDescription').parent().removeClass("error"); 
			$(".errEditRoleDescription").hide(); 
			
		}
	     if(flag == false){
	        $('#editRole').modal('show');
			return false;
	     }
	     else {
	    	 addedFunctionIds.length = 0;
	    	 $('input[class="roleFunction"]').each(function(k) {
	    		 var itm = $(this);
	    		 var data = $(this).attr('id');
	    		 var arr = data.split('_'); 
	    		 if ($(this).is(":checked")) {
	    			 addedFunctionIds.push(arr[1]);
	    		 } 
	    	 });
	    	  var obj = {
	    			  "roleName": editRoleName,
	    			  "description": editRoleDescription,
	    			  "associateFunctionIds":addedFunctionIds
					};
	    	  //console.log("edit obj "+JSON.stringify(obj));
			  $.ajax({
			       type: "PUT",
			       url: "/repopro/web/roledetails/"+roleId,
			       contentType : "application/json",
					dataType : "json",
					data : JSON.stringify(obj),
					async: false,
					cache: false,
					complete:function(data){	
					appenddata = "";
						var json = JSON.parse(data.responseText);
						
						if(json.status == "SUCCESS"){
/*							$('#roleName_'+roleId).html('<i class="user icon sidebarIcons widgetIconColor" style="margin-right: 0.8em;"></i>'+editRoleName);
*/							//$('#roleName_'+roleId).html('<div><div class="mediumIconImageCircleStyle"><i class="user icon sidebarIcons widgetIconColor" style="margin-top: 0.4em;margin-left: 0.7em !important;"></i></div><span style="margin-left: 0.8em;">'+editRoleName+'</span></div>');
							//$('#roleDescription_'+roleId).html(editRoleDescription);
							 loadRolesDetails();
							 updateAccessControl();//Swathi - Bug Fix- REPO-690
							notifyMessage("Edit Role",editRoleName+" updated","success");
						}
						else {
								if(editRoleName != roleName){
									$('#editRoleName').parent().addClass("error"); 
							    	$(".errEditRoleName").html(json.result).show();  
									flag = false;	
								}
								else{
									notifyMessage("Edit Role",json.message,"fail")
								
								}
						}
					}
			  });
			 
	     }
	     if(flag == false){
		    	$('#editRole').modal('show');
				return false;
		     }
		     else{
		    	 $('#editRole').modal('hide'); //.modal('hide dimmer');
		    	 $('#editRole').parent().css("display", "none !important");
		     }
	     
	     }); 	
	}
	
	//delete role confirmation popup
	function openDeleteRolePopup(roleId){
		$("#trash_"+roleId)
		.popup({
			on: 'click',
			lastResort: 'bottom left',
			closable : true
		})
		.popup('show');
	}
	//close delete role popup
	function closeDeleteRolePopup(roleId){
			$("#trash_"+roleId).popup('hide');
	}
	
	
	//delete role details
	function deleteRole(obj, roleId){
		 $.ajax({
			   	type: "DELETE",
			       url: "/repopro/web/roledetails/"+roleId,
			       dataType: "json",
			       async: false,
			       cache: false,
			       complete:function(data){										
						var json = JSON.parse(data.responseText);
						
						if(json.status == "FAILURE"){
							notifyMessage("Delete Role",json.message,"fail")
							
						}
						else {
							if(json.result != ""){
								notifyMessage("Delete Role",json.result,"success");
							} 
							else{	
								$('#trManageRole'+roleId).remove();
								notifyMessage("Delete Role","Role deleted","success");
								
								var rowCount = $('#tableGroups tr').length;
								if(rowCount == "3"){
									$('#rolesGrid').hide();
									$('#noGridData').show();
									$('#noGridData').html('<div class="ui message">No roles added yet</div>'); 
								}else {
									$('#rolesGrid').show();
									$('#noGridData').hide();
								}
								
							}
						}
						closeDeleteRolePopup(roleId);
			       }
		  });   
	}
	


	//get Associated Functions Details for role
	function getAssociatedFunctionsDetails(functionId,functionName,chkboxMappedWithRole){
		appendData = "";
		appendData += "<tr>";
		appendData += "<td class='hidden' id='functionId_"+functionId+"'>"+functionId+"</td>";
		if(chkboxMappedWithRole == true){
			appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllRole(this)' type='checkbox' id='associatedFunctionName_"+functionId+"' class='roleFunction' checked><label>"+functionName+"</label></div></td>";
		}
		else {
			appendData += "<td><div class='ui checkbox'><input onClick='checkSelectAllRole(this)' type='checkbox'  id='associatedFunctionName_"+functionId+"' class='roleFunction'><label>"+functionName+"</label></div></td>";	
		}
		appendData += "</tr>";
		return appendData;
	}

	//check uncheck All Functions for Role 
	function selectAllFunction_Role(){
		if(selectAllAssociatedFunctionsRoles.checked){
			$('.roleFunction').prop('checked',true);
		}
		else {
			$('.roleFunction').prop('checked',false);
		}
	}

	//check select all when all check box are checked
	function checkSelectAllRole(obj){
		// Swathi- 10-10-2019 - REPO-544
		var n  =  $('.roleFunction:visible').length; 
		var m = $('.roleFunction:visible:checked').length
		if(false == $(obj).prop('checked')){ 
			$("#selectAllAssociatedFunctionsRoles").prop('checked', false); 
		}
		if (n == m ){
			$("#selectAllAssociatedFunctionsRoles").prop('checked', true);
		}
	}
	
	//Swathi - Bug Fix- REPO-690
	function updateAccessControl(){ 		
		if($("#adminAccContrlUsers1").length == 0){								
			$(".subItemsAccessControl").append(' <a	class="item sidebarHeaderColor menuColor" id="adminAccContrlUsers1" onclick="getUsersDetails(this);"><i	class="add user icon sidebarIcons"></i><span class="sidebarItemSpacing letterSpacingHeader">Users</span> </a>');
			$("#adminAccContrlUsers1").show();
		}
		if($("#adminAccContrlRoles").length == 0){								
			$(".subItemsAccessControl").append('<a class="item sidebarHeaderColor menuColor" id="adminAccContrlRoles" onclick="getRolesDetails(this);"><i class="user icon sidebarIcons"></i><span class="sidebarItemSpacing letterSpacingHeader">Roles</span> </a> ');
			$("#adminAccContrlUsers1").show();
		}
		if($("#adminAccContrlGroups1").length == 0){								
			$(".subItemsAccessControl").append('<a class="item sidebarHeaderColor menuColor" id="adminAccContrlGroups1" onclick="getGroupsDetails(this);"><i class="users icon sidebarIcons"></i> <span class="sidebarItemSpacing letterSpacingHeader">Groups</span> </a>');
			$("#adminAccContrlUsers1").show();
		}		
		
		$.ajax({
			type: "GET",
			url: "/repopro/web/roledetails/getAllRoleFunctionsByUserName?userName="+loggedInUserName,
			dataType: "json",
			async: false,
			complete:function(data){										
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					var informationModelingCount = 0;
					var accessControlCount = 0;
					$.each(json.result, function(i) {
						var functionName = (json.result[i].functionName).toLowerCase();
						 if(functionName == "manage users"){
								if(json.result[i].mappedWithRole == false){
									$("#adminAccContrlUsers1").remove();
									accessControlCount++;
								}
						}else if(functionName == "manage roles"){
								if(json.result[i].mappedWithRole == false){
									$("#adminAccContrlRoles").remove();
									accessControlCount++;
								}
						}else if(functionName == "manage groups"){							
								if(json.result[i].mappedWithRole == false){
									$("#adminAccContrlGroups1").remove();
									accessControlCount++;
								}
						}else if(functionName == "import/export excel"){
							if(json.result[i].mappedWithRole == false){
								$(".importExportToExcel").parent().remove();
							}
						}									 
						if(json.result[i].instanceCreation == false){
							$(".addInstanceSidebar").parent().remove();
						}
						
						
					});
					var hideAdminIconCount = 0;
					
					if(accessControlCount == 3){
						$(".accessControlSubMenu").parent().remove();	
						hideAdminIconCount++;
					} 
					if(hideAdminIconCount == 2){
						$(".adminMainItem").parent().remove();
					}
					
				}
			}
		});
	}

