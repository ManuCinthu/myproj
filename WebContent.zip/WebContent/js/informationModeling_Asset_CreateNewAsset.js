appendData = "";
autoIdCreator = Math.floor((Math.random() * 1000000) + 1);
autoParameterIdCreator = Math.floor((Math.random() * 1000000) + 1);
autoIdCreatorForCategoryWiseAccess = Math.floor((Math.random() * 1000000) + 1);
cardIdList = [];
var regex = new RegExp('^[0-9]+$');
var defaultAccessFlag =  true;
var defaultAddAccessFlag = true;
var draggedList = [];
var prevCatId = "";
var afterCatId = "";
var assetName = "";
var localSaveManageAssetFlag = true;
//make segments sortable
function makeSegmentsSortable(){

	$( "div.droptrue" ).sortable({
		connectWith: ".droptrue",
		tolerance: "pointer",
		placeholder: "sortableSegmentPlaceholder",
		receive : function(event,ui){
			var paramLength_After = $(this).find('.paramCount').length; // changed class from "divParamValues" to paramCount (hema 18.Sep.2018)
			if(paramLength_After == 10){
				$(this).find('.divParamValues').parent().parent().parent().find('.primary').attr('disabled',true);
				
			 }
			else if(paramLength_After > 10){
				ui.sender.sortable("cancel");
			}
			 else{
				 $(this).find('.divParamValues').parent().parent().parent().find('.primary').attr('disabled',false);
			 }
		
		},
		 
	        
	 stop : function(event,ui){
		 var paramLength_Before = $(this).find('.paramCount').length;
		 if(paramLength_Before == 10){
			 $(this).find('.divParamValues').parent().parent().parent().find('.primary').attr('disabled',true);
		 }
		 else if(paramLength_Before > 10){
			 ui.sender.sortable("cancel");
		 }
		 else{
			 $(this).find('.divParamValues').parent().parent().parent().find('.primary').attr('disabled',false);
		 }
	 }
	}); 
	$( "div.droptrue" ).bind('sortstart', function(event, ui) {
		prevCatId = $(ui.item).parent().attr('id');
		$('.sortableSegmentPlaceholder').html('<center style="margin-top:0.6em !important;">Move here</center>');
	}).bind('sortstop', function(event, ui) {
		afterCatId = $(ui.item).parent().attr('id');
		var fullParamId = $(ui.item).attr('id');
		var paramId = fullParamId.split("_");
		paramId = paramId[1];
		if(prevCatId != afterCatId){
			var fullId = afterCatId.split("_");
			afterCatId = fullId[1];
			var catName = $('#assetCategoryCardHeaderLabel_'+afterCatId).text();
			draggedList.push({"catName": catName, "paramId": paramId});
		}
	});


	if(cardIdList.length == 0){
		$( "#availableParameter" ).disableSelection();
	}
	else{
		$( "#availableParameter,"+cardIdList ).disableSelection();
	}

	$( "#assetCategoryGrid" ).sortable({
		handle: ".assetCategoryCardHeader",
		tolerance: "pointer"
	});
	$( "#assetCategoryGrid" ).disableSelection();

}

//load asset visulisation in dropdown
function loadVisualisationDropdown(){
	var addOption = '';
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetrepresentationmanager/getallrepresentations",
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				$.each(json.result, function(i) {
					//alert(json.result[i].representationName);
					representationName = json.result[i].representationName;
					var repId = json.result[i].assetRepresentationId;
					//console.log(representationName);
					addOption += '<option value="'+representationName+'" id="repId'+repId+'" name="'+representationName+'" >'+representationName+'</option>';
					
					
				});
				$('#selectAssetVisualisationOption').append(addOption);
			
			}
		}
	});
}
// load Assets to display in dropdown 
 function loadAssetInDropdown(){
	 var assetsArr = [];
	 $.ajax({
			type : 'GET',
			url : "/repopro/web/assetType/getallassets?userId="+loggedInUserId,
			dataType : 'json',
			async : false,
			complete : function(data) {
			var json = JSON.parse(data.responseText);
			if (json.status == "SUCCESS") {
				assetsArr.length = 0;
			$.each(json.result, function(i) {
				assetsArr.push({
						"assetName" : json.result[i].assetName,
						"assetId" : json.result[i].assetId
					});
				});
			}
			else {
				//error
			}
			
			mappedAssetIdlength = assetsArr.length;
			var appendAssetOptions = '';
			$('#ddMappedAsset').html("");
			for (var h = 0; h < assetsArr.length; h++) {
				appendAssetOptions += '<option value="'+ assetsArr[h].assetId + '">' + assetsArr[h].assetName + '</option>';
			}
			
			// add param modal - Add mapped assets to dropdown
			$('#ddMappedAsset').prepend('<option value="">Select Mapped Asset</option>');
			$('#ddMappedAsset').append(appendAssetOptions);
			
			// edit param modal - Add mapped assets to dropdown
			$('#edit_ddMappedAsset').prepend('<option value="">Select Mapped Asset</option>');
			$('#edit_ddMappedAsset').append(appendAssetOptions);
			
		}
					
		});
 }

//show Add Category Input Field
function showAddCategoryInputField(){
	//$('input[id=addNewAssetCategoryName]').focus();
	$("#addNewAssetCategoryName").val("");
	//$("#addNewAssetCategoryName").addClass('focus');
	$("#addCategoryIcon").toggle();
	$("#addCategoryInputField").toggle();
	$("#addNewAssetCategoryName").focus();
}

//add new category
function addNewAssetCategory(){
	var newAssetCategoryName = $("#addNewAssetCategoryName").val().trim();
	var catFlag = false;
	var setFlag = true;
	if(newAssetCategoryName == null || newAssetCategoryName == ""){
		notifyMessage("Edit Asset","Please provide category name","fail");
		setFlag = false;
	}
	var iChars = "`!@#$%^&*()+=-[]\\\';,./{}|\":<>?~`";
	for (var i = 0; i < newAssetCategoryName.length; i++) {
		if (iChars.indexOf(newAssetCategoryName.charAt(i)) != -1) {
			notifyMessage("Edit Asset","Please use alphabetical and numeric characters only for category name","fail");
			setFlag = false;
		}
	}
	
	/*if(categoryArr.length == 0){
		categoryArr.push(newAssetCategoryName.toLowerCase());
		//catFlag = true;
	}
	else{*/
	
	if(newAssetCategoryName != ""){
		for(var h=0; h < categoryArr.length; h++){
			if(categoryArr[h] == newAssetCategoryName.toLowerCase()){
				
				catFlag = true;
				setFlag = false;
				break;
			}
		}
		if(catFlag == true){
			// dont add
			notifyMessage("Edit Asset","This category name already exists","fail");
		}
		else{
			/*categoryArr.push(newAssetCategoryName);*/
		}
	}
	//}
	
	
	if(setFlag == false){
		return false;
	}
	else{
		var deleteCategory = "0";
		categoryArr.push(newAssetCategoryName);
		var data = "<p>Are you sure you want to delete "+newAssetCategoryName+" ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeCategoryPopup("+autoIdCreator+")'>No</button><button class='right floated ui primary mini button' onclick='deleteAssetCategoryCard("+autoIdCreator+","+deleteCategory+")'>Yes</button> ";
		appendData = '';
		appendData += '<div class="sixteen wide column categoryClass" id="assetCategoryCard_'+autoIdCreator+'">';
		appendData += '<div class="ui card assetCategoryCardSize">';
		appendData += '<div class="content assetCategoryCardHeader">';
		appendData += '<i class="tags icon"></i>';
		appendData += '<label>';
		appendData += '<a id="assetCategoryCardHeaderLabel_'+autoIdCreator+'" title="Click to Edit Category Name" onclick="editAssetCategoryName('+autoIdCreator+')" class="assetCategoryEditableCardHeader editable">'+newAssetCategoryName+'</a>';
		appendData += '<span id="assetCategoryCardHeaderEdit_'+autoIdCreator+'" style="display: none !important;">';
		appendData += '<input id="assetCategoryCardHeaderEditInput_'+autoIdCreator+'" value="'+newAssetCategoryName+'" type="text" style="width: 30%; height: 2.3em;" placeholder="Enter Category Name (Max 50 Chars)" maxlength="50">';
		appendData += '<a title="Save" onclick="saveEditedAssetCategoryName('+autoIdCreator+')"><i class="circular inverted small green checkmark icon" style="margin-left: 0.5em; margin-bottom: -1em;"></i></a>';
		appendData += '<a title="Cancle" onclick="cancelEditedAssetCategoryName('+autoIdCreator+')"><i class="circular inverted small red remove icon" style="margin-left: 0.5em; margin-bottom: -1em;"></i></a>';
		appendData += '</span><span class="actionForCategoryAttr" style="display:none;">ADD</span></label>';
		appendData += '<div class="right floated meta addNew">';
		appendData += '<button class="ui mini primary button" style="font-size:9px !important; margin-right:1em !important;" title="Add Parameter" id="addRemoveCategoryIcon_'+autoIdCreator+'" onclick="openAddAssetParameterModal('+autoIdCreator+'); return false">';
		appendData += 'Add Parameter</button>';
		/*appendData += '<a class="deleteAssetCategoryStyle" title="Delete" onclick="deleteAssetCategoryCard('+autoIdCreator+')"><i class="trash icon"></i></a>';*/
		appendData += '<a class="deleteAssetCategoryStyle"><i class="trash icon deleteEditIcon" id="catDeleteId_'+autoIdCreator+'" data-html="'+data+'" onclick="openCategoryPopup('+autoIdCreator+')"></i></a>';
		appendData += '<a onclick="hideAssetCategoryCardContent('+autoIdCreator+')"><i class="chevron down icon"></i></a>';
		appendData += '</div></div>';
		appendData += '<div class="content assetCategoryCardContent" id="assetCategoryCardContent_'+autoIdCreator+'">';
		appendData += '<div class="droptrue" id="availableCategory_'+autoIdCreator+'" style="min-height: 14em !important;"></div>';
		appendData += '</div></div></div>';

		$("#assetCategoryGrid").append(appendData);
		$("#addNewAssetCategoryName").val("");

		cardIdList.push("#availableCategory_"+autoIdCreator);
		makeSegmentsSortable(); 
		showAddCategoryInputField();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
		autoIdCreator = Math.floor((Math.random() * 1000000) + 1);
		//notifyMessage("Add New Category",newAssetCategoryName + " is added!","success");
	}
}

//category confirmation popup - open 
function openCategoryPopup(catId){
	$("#catDeleteId_"+catId).popup({on: 'click',lastResort: 'bottom left',closable : true}).popup('show');
}

//category confirmation popup - close 
function closeCategoryPopup(catId){
	$("#catDeleteId_"+catId).popup('hide');
}

//delete category
function deleteAssetCategoryCard(categoryId,deleteCategory){
	if(deleteCategory == "0"){
		$("#assetCategoryCard_"+categoryId).remove();
	}else{
		$("#assetCategoryCard_"+categoryId).hide().addClass('deleteCategory');
	}
	$("#catDeleteId_"+categoryId).popup('hide');
	var categoryName = $('#assetCategoryCardHeaderLabel_'+categoryId).text();
	categoryArr.splice($.inArray(categoryName, categoryArr),1);
	}
//hide category
function hideAssetCategoryCardContent(Id){
	$("#assetCategoryCardContent_"+Id).toggle();
}

//edit category name
var edit_CategoryName = "";
var oldCatName = "";
function editAssetCategoryName(categoryId){
	oldCatName = $("#assetCategoryCardHeaderLabel_"+categoryId).text();
	$("#assetCategoryCardHeaderLabel_"+categoryId).hide();
	$("#assetCategoryCardHeaderEdit_"+categoryId).show();
	edit_CategoryName = $("#assetCategoryCardHeaderEditInput_"+categoryId).val().trim();
	
	edit_oldCatId = categoryId;
	if(edit_CategoryName == ""){
		edit_CategoryName = $("#assetCategoryCardHeaderLabel_"+categoryId).text(); 	
		$("#assetCategoryCardHeaderEditInput_"+categoryId).val(edit_CategoryName);
	}
	else {
		edit_CategoryName = $("#assetCategoryCardHeaderEditInput_"+categoryId).val().trim(); 
	}
	
	$("#assetCategoryCardHeaderEditInput_"+categoryId).keypress(function(e) {
	    if(e.which == 13) {
	    	 e.preventDefault();
	    	saveEditedAssetCategoryName(categoryId)
	    	return false;
	    }
	});
	
}

//save edited category name
function saveEditedAssetCategoryName(categoryId){
	var newCategoryName = $("#assetCategoryCardHeaderEditInput_"+categoryId).val().trim(); 
	var catFlag = false;
	var setFlag = true;
	//var oldCatName = $("#assetCategoryCardHeaderLabel_"+categoryId).text();
	if(newCategoryName == null || newCategoryName == ""){
		notifyMessage("Edit Asset","Please provide a category name","fail");
		setFlag = false;
	}
	
	var iChars = "`!@#$%^&*()+=-[]\\\';,./{}|\":<>?~`";
	for (var i = 0; i < newCategoryName.length; i++) {
		if (iChars.indexOf(newCategoryName.charAt(i)) != -1) {
			notifyMessage("Edit Asset","Please use alphabetical and numeric characters only for category name","fail");
			setFlag = false;
		}
	}
	
	if(newCategoryName == edit_CategoryName){
		$("#assetCategoryCardHeaderEdit_"+categoryId).hide();
	    $("#assetCategoryCardHeaderLabel_"+categoryId).html(newCategoryName).show();
	    return false;
	}
	
	if(newCategoryName != "" || newCategoryName != edit_CategoryName){
		for(var h=0; h < categoryArr.length; h++){
			if(categoryArr[h] == newCategoryName.toLowerCase()){
				//if(categoryArr[h] != oldCatName){
					catFlag = true;
					setFlag = false;
					break;
				//}
					
			
			}
		}
		if(catFlag == true){
			notifyMessage("Edit Asset","Category by this name already exists","fail");
		}
	}
	
	
	
	if(setFlag == false){
		return false;
	}
	else{
		$("#assetCategoryCardHeaderEdit_"+categoryId).hide();
	    $("#assetCategoryCardHeaderLabel_"+categoryId).html(newCategoryName).show();
	    /*** Swathi Angadi 03.07.2019***/
		  //  categoryArr.push(newCategoryName);
		    for(var h=0; h < categoryArr.length; h++){
				if(categoryArr[h] == oldCatName.toLowerCase()){
					categoryArr[h] = newCategoryName;
				}
			}
		    
		   // categoryArr.splice(oldCatName , 1);
		    /*** End of code ***/
		    
	  
	    
	    notifyMessage("Add New Category",newCategoryName + " is added!","success");
	}
}

//cancel edited category name
function cancelEditedAssetCategoryName(categoryId){
	$("#assetCategoryCardHeaderLabel_"+categoryId).show();
	$("#assetCategoryCardHeaderEdit_"+categoryId).hide();
}


//add parameters
 arrParameters = [];
function openAddAssetParameterModal(categoryId){
	$('#edit_AssetParameterModal').modal('destroy');
	//window.close();
	//self.close();
	$("#mandatoryYesField").show();//Aditya 30.03.18
	//$('#addParaCloseIcon').hide(); <!-- hema 06.04.2018 -->
	$('#addAssetParameterModal').modal('destroy');
	$("#submitAddedAssetParameter").unbind();
	$("#cancelAddedAssetParameter").unbind();
	
	$('#importantYes').prop("disabled", false);
	$('#isArrayCheckbox').prop("disabled", false);
	$('#emailSchedulerYes').prop("disabled", false);// Swathi- Email scheduler
	
	
	
	$('.emailScheduler').show();
	$('#emailSchedulerYes').prop("disabled", false);// Swathi- Alerting
	
	$('#addAssetParameterModal').modal('setting', 'closable', false).modal({ observeChanges: true }).modal('show').modal('refresh'); // aditya added .modal({ observeChanges: true }) 06.03.18
	////Add css to focus the checkboxes on keypress
	if($('input[type="checkbox"]')){
    	$('input[type="checkbox"]').css('display','block');
    }
	
	$('input[type="checkbox"]').attr('tabindex', '0');
	
	 /*hema 06.04.2018*/ 
	// IE and Firefox modal close Icon 
	/*if (!!navigator.userAgent.match(/Trident\/7\./)){
		setTimeout(function(){
			$('#addParaCloseIcon').show();
			
			$("#addParaCloseIcon").removeClass("semanticModalCloseIConForIEafterAdd");
			$("#addParaCloseIcon").addClass("semanticModalCloseIConForIE");
			
		},800);
	}else{
		$('#addParaCloseIcon').show();
	}*/
	
	$(".assetInfoPopup").popup();
	$('.ui.top.pointing').hide();
	$('.paramErr').hide();
	$('.paramRemoveErr').parent().removeClass("error");
	$('#paramTypeErr').prev().removeClass('error');
	
	
	$('.ui.checkbox').checkbox();
	
/*	$('#addNewParameter').animate({
		  scrollTop: 0
	  }, 10);*/
	$('#form_addAssetParameter').form('clear'); 
	$('.radioBtnClass').prop('checked',true);
	$('#changeAddEditPArameterHeader').html("");
	$('#changeAddEditPArameterHeader').html('Add Parameter');
	$('.listTypeParam, .customListItemParam, .derivedAttrParam, .derivedComputationParam, .mappedAssetParam, .sizeParam, .singleMultipleParam, .derivedAttrForAssetListParam,.dd_ldapMappedListOfNames').hide(); //harish
	$('#ddsingleMultipleType').dropdown('set selected','Single Select List');
	$("#paramNameErr").hide();
	$('#assetParameterName').parent().removeClass("error");  
	
	$('.hasStaticViewParam, .importantParam').show();
	$('.ldapMappingAttributes').hide();
	
	//$('#mandatoryYes').attr('checked',true);
	
	$('.assetInfoPopup').popup({
        inline: true,
      });
	
	if(ddParamType == 1){
	if ($('#hasStaticValueYes').is(':checked')) {
		$('.isArrayParam').hide();	
	}else {
		$('.isArrayParam').show();	
	}
	}
	$('#hasStaticValueYes').removeClass('hidden');
	
	if(ddParamType == 3){
		$("#edit_emailSchedulerYes").attr("disabled", true);
		$('.edit_emailSchedulerYes').addClass("disabled");
	}
	
	$('#submitAddedAssetParameter').on('click', function(){
		 /*hema 06.04.2018*/ 
		/*if (!!navigator.userAgent.match(/Trident\/7\./)){//Aditya 29.03.18
			$("#addParaCloseIcon").removeClass("semanticModalCloseIConForIE");
			$("#addParaCloseIcon").addClass("semanticModalCloseIConForIEafterAdd");
		}*/
		
		
		var paramFlag = false;
		var specialCharRegexStr = /^[a-zA-Z0-9\s]+$/;
		var assetParameterName = $("#assetParameterName").val().trim();
		var paramDesc = $('#paramDesc').val().trim();
		paramDesc = escape(paramDesc);
		var ddParamType = $('#ddParamType option:selected').val();
		var defaultViewChecked;
		var isArray = 0;
		if ($("input[id='defaultViewYes']").is(':checked')) {
			defaultViewChecked = 1;
		}
		else {
			defaultViewChecked = 0;
		}
		
		var hasStaticValueYes = "";
		if ($("input[id='hasStaticValueYes']").is(':checked')) {
			hasStaticValueYes = true;
		}
		else {
			hasStaticValueYes = false;
		}

		var importantYes = "";
		if ($("input[id='importantYes']").is(':checked')) {
			importantYes = true;
		}
		else {
			importantYes = false;
		} 
		
		var mandatoryParam = "";
		
		if ($("input[id='mandatoryYes']").is(':checked')) {
			mandatoryParam = true;
		}
		else {
			mandatoryParam = false;
		} 
		//Swathi- Email scheduler
		var emailSchedulerYes = "";
		if ($("input[id='emailSchedulerYes']").is(':checked')) {
			emailSchedulerYes = true;
		}
		else {
			emailSchedulerYes = false;
		} 
		
		var listSize = $('#listSize').val().trim();
		var derivedAttribute = $('#derivedAttribute').val().trim();
		var derivedComputation = $('#derivedComputation').val().trim();
		var listType = $("#listType :selected").val();
		var singleMultipleListType = $("#ddsingleMultipleType :selected").val(); //harish
		var derivedAttrForAssetList = $('#derivedAttrForAssetList').val().trim(); //derived attribute for asset list value 26.Feb.2019 Hema
		if(listType == 1){
			$('#listType option:selected').text('Custom List');
		}
		else if(listType == 2){
			$('#listType option:selected').text('Asset List');
		}
		else if (listType == 3){
			$('#listType option:selected').text('Native User List');
		}
		else if (listType == 4){
			$('#listType option:selected').text('Ldap User List');
		}
		
		else {
			$('#listType option:selected').text('Select List Type');
		}
		var custListItems = $('#custListItems').val().trim();
		var customListSpclChar = specialCharRegexStr.test(custListItems);
		
		var ddMappedAsset = $('#ddMappedAsset option:selected').val();
		var inptUserNameIsValid = specialCharRegexStr.test(assetParameterName);
		
		var ldapMappingNameId = $('#dd_LdapMappedList option:selected').val();
		
		var setFlag = true;
		
		//$("#addNewParameter").removeAttr("style");
		
		if(assetParameterName == null || assetParameterName == ""){
			$("#paramSpclChar").hide();
			$("#paramNameErr").html('Please select parameter name').show();
			$('#assetParameterName').parent().addClass("error"); 
			setFlag = false;
			
		}
		else if (!inptUserNameIsValid){
			$("#paramNameErr").hide();
			$("#paramSpclChar").html("Please enter only alphanumerical values").show();
			$('#assetParameterName').parent().addClass("error");  
			setFlag = false;
		}
		
		else {
			$("#paramNameErr").hide();
			$("#paramSpclChar").hide();
			$('#assetParameterName').parent().removeClass("error");  
		}
		
		// check param duplications
		if(assetParameterName != ""){
			var addedFlag = false;
			for(p=0; p < arrParameters.length; p++){
				if(arrParameters[p] == assetParameterName.toLowerCase()){
					addedFlag = true;
					break;
				}
			}
			if(!addedFlag){
				/*$("#paramNameErr").hide();
				$('#assetParameterName').parent().removeClass("error");  */
				
			}
			else {
				setFlag = false;
				$("#paramNameErr").html('This parameter has been already added').show();
				$('#assetParameterName').parent().addClass("error");
			}
		}
		
		
		if(paramDesc == null || paramDesc == ""){
			$('#paramDescErr').html('Please provide parameter description').show();
			$('#paramDesc').parent().addClass("error");  
			setFlag = false;
		}
		else {
			$("#paramDescErr").hide();
			$('#paramDesc').parent().removeClass("error");  
		}
		
		 if($('#ddParamType option:selected').text() == "Select Parameter Type"){
			$("#paramTypeErr").show();
			$('#ddParamType').parent().addClass("error"); 
			setFlag = false;
		}
		 else {
			 $("#paramTypeErr").hide();
			 $('#ddParamType').parent().removeClass("error");  
		 }
		 // Text
		 if(ddParamType == 1){
			 var regex = new RegExp('^[0-9]+$');
			 if(listSize == "" || listSize == null){
					 $('#listSizeErr').html('Please enter text size').show();
					 $('#listSize').parent().addClass("error");  
						setFlag = false; 
			 }
			 else if(!regex.test(listSize) ) {
				 $('#listSizeErr').html('Please enter only positive integers').show();
				 $('#listSize').parent().addClass("error");  
					setFlag = false; 
				}
			 else {
				 	$('#listSizeErr').hide();
					$('#listSize').parent().removeClass("error");  
			 }
			 
			 if(hasStaticValueYes == true){
				 isArray = 0;
			 }
			 else {
				 if ($("input[id='isArrayCheckbox']").is(':checked')) {
					isArray = 1;
				}
				else {
					isArray = 0;
				}
			 }
			 ldapMappingNameId = "";
		 }
		 
		 
		
		 if(ddParamType == 4){
			 //harish
			 if(singleMultipleListType == ""){
				 $('#singleMultipleTypeErr').html('Please select one param').show();
				 $('#ddsingleMultipleType').parent().addClass("error");  
				 setFlag = false; 
			 }
			 else {
				 $('#singleMultipleTypeErr').hide();
				 $('#ddsingleMultipleType').parent().removeClass("error"); 
			 }
		 
			 if(listType == "" || listType == null){
				 $("#custListTypeErr").html('Please select list type').show();
				 $('#listType').parent().addClass("error");  
				 setFlag = false;
			 }
			 else {
				 $("#custListTypeErr").html('').hide();
				 $('#listType').parent().removeClass("error");  
			 }

			 if(listType == 1){
				
				 var iChars = "#^&+,~`";
				  
				  for (var i = 0; i < custListItems.length; i++){
				  	if (iChars.indexOf(custListItems.charAt(i)) != -1){
				  		 $('#customlistTextBoxErr').html('Please do not use #^&+,~` characters in custom list').show();
						 $('#custListItems').parent().addClass("error");  
						 setFlag = false; 
				  		 return false;
				  	}
				  }
				  
				 if(custListItems == null || custListItems == ""){
					 $('#customlistTextBoxErr').html('Please provide the custom list').show();
					 $('#custListItems').parent().addClass("error");  
					 setFlag = false;  
				 }
				 else {
					 var  empty_val_flag = 0;
					 var sameNameCheck = custListItems.split('\n');
					 
					 var tarr = [];
					 for (var i = 0; i < sameNameCheck.length; i++) {
						 tarr.push(sameNameCheck[i].trim());
					 }
					 
					 var recipientsArray = tarr.sort(); 
					 
					 for (var i = 0; i < sameNameCheck.length; i++) {
						 if(sameNameCheck[i] == ""){
							  empty_val_flag = 1;
						  }
						  if(i == (sameNameCheck.length-1)){
							  if(empty_val_flag == 1){
								  $('#customlistTextBoxErr').html('Please provide the custom list').show();
								  $('#custListItems').parent().addClass("error");   
								  return false;
							  }							  
						  }
						 }

					 if (arrHasDuplicate( recipientsArray ) ){
						 $('#customlistTextBoxErr').html('There are some duplicate values in custom list, please check').show();
						 $('#custListItems').parent().addClass("error");  
							setFlag = false;
					 }
					 else{
						 $("#customlistTextBoxErr").hide();
						 $('#custListItems').parent().removeClass("error");
					 }
					 if(setFlag == true){
						 for (var i = 0; i < sameNameCheck.length; i++) {
							  if(sameNameCheck[i] == ""){
								  empty_val_flag = 1;
							  }
							  if(i == (sameNameCheck.length-1)){
								  if(empty_val_flag == 1){
									  $('#customlistTextBoxErr').html('Please provide the custom list').show();
									  $('#custListItems').parent().addClass("error");   
									  setFlag = false;
										 
								  } 
							  }
							 if(sameNameCheck[i].trim() == null || sameNameCheck[i].trim() == ""){
								 $('#customlistTextBoxErr').html('Please provide the custom list').show();
								  $('#custListItems').parent().addClass("error");   
									setFlag = false;  
							 }
						  }
							 if ( arrHasDuplicate( recipientsArray ) ){
								 $('#customlistTextBoxErr').html('There are some duplicate values in custom list, please check').show();
								 $('#custListItems').parent().addClass("error"); 
									setFlag = false;
							 }
							 else{
								 /*$("#customlistTextBoxErr").hide();
								 $('#custListItems').parent().removeClass("error");*/
							 }
					 }
					 
				 }
				
			 }
			 if(listType == 2){
				 if(ddMappedAsset == ""){
					 $('#ddMappedAssetErr').html('Please select mapped asset').show();
					 $('#ddMappedAsset').parent().addClass("error");  
					 setFlag = false; 
				 }
				 else {
					 $('#ddMappedAssetErr').hide();
					 $('#ddMappedAsset').parent().removeClass("error"); 
				 }
				 
			 }
			 ldapMappingNameId = "";

		 }
		 
		 // derived attribute validation
		 var oldAssetName = editAssetName;
		 var newAssetName = $('#assetName').text();
		 if(ddParamType == 5){
			 var derivedAttr = $('#derivedAttribute').val().trim();
			 if(derivedAttr == ""){
				 $('#derivedAttrErr').html('Please enter derived attribute').show();
				 $('#derivedAttribute').parent().parent().addClass("error");  
				 setFlag = false;  
			 }
			 else {
				 $('#derivedAttrErr').hide();
				 $('#derivedAttribute').parent().parent().removeClass("error");  
				 
				 var obj = {
						 "assetParamName":assetParameterName,
						 "derivedAttributeComputation":derivedAttr
				 }
				 $.ajax({
					 type: "POST", 
					 url: "/repopro/web/assetType/validationForDerivedPattern?mainAssetName="+oldAssetName+"&oldAssetName="+newAssetName,
					 contentType : "application/json",
					 dataType : "json",
					 data : JSON.stringify(obj),
					 async: false,
					 complete:function(data){									
						 var json = JSON.parse(data.responseText);
						 if(json.result != ""){
							 setFlag = false;  
							 $('#derivedAttrErr').html(json.result).show();
							 $('#derivedAttribute').parent().addClass("error");
						 }
					 }
				 });
			 }
			 listSize = "";
			 listType = 0;
			 custListItems = "";
			 ddMappedAsset = 0;
			 derivedComputation = "";
			 isArray = 0;
			 derivedAttrForAssetList = "";
			 hasStaticValueYes=false;
			 importantYes = false;
			 mandatoryParam=false;
			 ldapMappingNameId = "";
			 emailSchedulerYes = false;

		 }else{
			 derivedAttribute = "";
		 }
		 
		 // derived computation validation
		 if(ddParamType == 6){
			 var derivedComp = $('#derivedComputation').val().trim();
			 if(derivedComp == ""){
				 $('#derivedComputationErr').html('Please provide derived computation').show();
				 $('#derivedComputation').parent().parent().addClass("error");  
				 setFlag = false;  
			 }
			 else {
				 $('#derivedComputationErr').hide();
				 $('#derivedComputationErr').parent().parent().removeClass("error");  
				 
				 var obj = {
						 "assetParamName":assetParameterName,
						 "derivedAttributeComputation":derivedComp
				 }
				 $.ajax({
					 type: "POST", 
					 url: "/repopro/web/assetType/validationForDerivedComputationPattern?mainAssetName="+oldAssetName+"&oldAssetName="+newAssetName,
					 contentType : "application/json",
					 dataType : "json",
					 data : JSON.stringify(obj),
					 async: false,
					 complete:function(data){									
						 var json = JSON.parse(data.responseText);
						 if(json.result != ""){
							 setFlag = false;  
							 $('#derivedComputationErr').html(json.result).show();
							 $('#derivedComputation').parent().parent().addClass("error");
						 }
					 }
				 });
			 }
			 listSize = "";
			 listType = 0;
			 custListItems = "";
			 ddMappedAsset = 0;
			 derivedAttribute = "";
			 isArray = 0;
			 derivedAttrForAssetList = "";
			 hasStaticValueYes=false;
			 importantYes = false;
			 mandatoryParam=false;
			 ldapMappingNameId = "";
			 emailSchedulerYes = false;
		 }
		 else {
			 derivedComputation  = "";
		 }
		 
		 // Rich text
		 if(ddParamType == 7){
			 $('.hasStaticViewParam').hide();
			 hasStaticValueYes = false;
			 if ($("input[id='isArrayCheckbox']").is(':checked')) {
				 isArray = 1;
			 }
			 else {
				 isArray = 0;
			 }
			 ldapMappingNameId = "";
		 }
		 
		 // derived attribute for asset list - 26.Feb.2019 Hema
		 if(ddParamType == 8){
			 if(derivedAttrForAssetList == ""){
				 $('#derivedAttrForAssetListErr').html('Please enter derived attribute for asset list ').show();
				 $('#derivedAttrForAssetList').parent().parent().addClass("error");  
				 setFlag = false;  
			 }
			 else {
				 $('#derivedAttrForAssetListErr').hide();
				 $('#derivedAttrForAssetList').parent().parent().removeClass("error");  
				 
				 var obj = {
						 "assetParamName":assetParameterName,
						 "derivedAssetListRule":derivedAttrForAssetList
				 }
				 $.ajax({
					 type: "POST", 
					 url: "/repopro/web/assetType/validationForDerivedPatternForAssetList?mainAssetName="+oldAssetName+"&oldAssetName="+newAssetName+"&userName="+loggedInUserName,
					 contentType : "application/json",
					 dataType : "json",
					 data : JSON.stringify(obj),
					 async: false,
					 complete:function(data){									
						 var json = JSON.parse(data.responseText);
						 if(json.result != ""){
							 setFlag = false;  
							 $('#derivedAttrForAssetListErr').html(json.result).show();
							 $('#derivedAttrForAssetList').parent().addClass("error");
						 }
					 }
				 });
			 }
			 listSize = "";
			 listType = 0;
			 custListItems = "";
			 ddMappedAsset = 0;
			 derivedComputation = "";
			 isArray = 0;
			 derivedAttribute = "";
			 hasStaticValueYes=false;
			 importantYes = false;
			 mandatoryParam=false;
			 ldapMappingNameId = "";
			 emailSchedulerYes = false;
		 }else{
			 derivedAttrForAssetList = "";
		 }
		 
		 
		// BOC ldap mapping name - mapped id from dropdown - Hema 28.Feb.2019 
			
			
		 if(ddParamType == 9){
			
			 if(singleMultipleListType == ""){
				 $('#singleMultipleTypeErr').html('Please select one param').show();
				 $('#ddsingleMultipleType').parent().addClass("error");  
				 setFlag = false; 
			 }
			 else {
				 $('#singleMultipleTypeErr').hide();
				 $('#ddsingleMultipleType').parent().removeClass("error"); 
			 }
			 
			 if(ldapMappingNameId == ""){
				 $('#ldapMappedListErr').html('Please select mapped name').show();
				 $('#dd_LdapMappedList').parent().addClass("error");  
				 setFlag = false; 
			 }
			 else {
				 $('#ldapMappedListErr').hide();
				 $('#dd_LdapMappedList').parent().removeClass("error"); 
			 }
			 
		 }else {
			 ldapMappingNameId = "";
		 }
		 
		 if(ddParamType == 2 || ddParamType == 3){
			 ldapMappingNameId = "";
		 }
		 
		 /*EOC*/
		 if(ddParamType == 3){
			 emailSchedulerYes = false;
		 }
		 
		 if(setFlag == false){
			 return true;
		 }
		else {  
			arrParameters.push(assetParameterName.toLowerCase());
			var addParamFlag = 'trueFlag';
			//globalParamId++;
			//console.log("add ------ assetParameterName : " + assetParameterName + " paramDesc : " + paramDesc + " ddParamType : " + ddParamType + " defaultViewChecked : " + defaultViewChecked + " hasStaticValueYes : " + hasStaticValueYes + " importantYes : " + importantYes + " listSize : " + listSize + " derivedAttribute : " + derivedAttribute + " derivedComputation : " + derivedComputation + " listType : " + listType + " custListItems : " + custListItems + " ddMappedAsset : " + ddMappedAsset);
			var data = "<p>Are you sure you want to delete "+assetParameterName+" ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeParamPopup("+autoParameterIdCreator+")'>No</button><button class='right floated ui primary mini button' onclick='paramDelete(this,"+autoParameterIdCreator+","+categoryId+")'>Yes</button> ";
			appendData = '';
			appendData += '<div class="ui segment sortableSegmentCursor divParamValues paramCount" id="parameterId_'+autoParameterIdCreator+'"><span class="assetParamName" id="parameterName_'+autoParameterIdCreator+'">'+assetParameterName+'</span>';
			appendData += '<pre style="display:none;" class="paramDescription"><textarea>'+paramDesc+'</textarea></pre>';
			appendData += '<span style="display:none;" class="paramTypeDD">'+ddParamType+'</span>';
			appendData += '<span style="display:none;" class="defaultViewChecked">'+defaultViewChecked+'</span>';
			appendData += '<span style="display:none;" class="hasStaticValueYes">'+hasStaticValueYes+'</span>';
			appendData += '<span style="display:none;" class="importantYes">'+importantYes+'</span>';
			
			appendData += '<span style="display:none;" class="mandatoryParam">'+mandatoryParam+'</span>'; 
			appendData += '<span style="display:none;" class="listSize">'+listSize+'</span>';
			appendData += '<span style="display:none;" class="derivedAttribute">'+derivedAttribute+'</span>';
			appendData += '<span style="display:none;" class="derivedComputation">'+derivedComputation+'</span>';
			appendData += '<span style="display:none;" class="listType">'+listType+'</span>';
			appendData += '<span style="display:none;" class="custListItems">'+custListItems+'</span>';
			appendData += '<span style="display:none;" class="ddMappedAsset">'+ddMappedAsset+'</span>';
			appendData += '<span style="display:none;" class="isArrayCheckbox">'+isArray+'</span>';
			appendData += '<span style="display:none;" class="singleMultipleListType">'+singleMultipleListType+'</span>'; //harish
			appendData += '<span style="display:none;" class="actionForParameter">ADD</span>';
			appendData += '<span style="display:none;" class="derivedAttribute_AutoComplete">'+derivedAttrForAssetList+'</span>';
			appendData += '<span style="display:none;" class="ldapMappingNameListId">'+ldapMappingNameId+'</span>';
			//Swathi- Email Scheduler- 28.01.2020
			appendData += '<span style="display:none;" class=" emailSchedulerYes">'+emailSchedulerYes+'</span>';
			appendData += '<a style="float: right!important;"><i class="trash icon deleteEditIcon" id="paramId_'+autoParameterIdCreator+'" data-html="'+data+'" onclick="openParamPopup('+autoParameterIdCreator+')"></i></a>';
			
			/*if(listType == 1){
				custListItems = custListItems.replace(/\n/g, "~~");
				custListItems += "~~";
			}*/
			
			if(listType == 1){
				custListItems = custListItems.replace(/\n/g, "&&");
				var custData = custListItems.split("&&");
				custListItems = "";
				$.each(custData,function(i){
					custListItems += ((custData[i]).trim())+"&&"; 
				});
				
				custListItems = encodeURIComponent(custListItems);
				custListItems = custListItems.replace(/'/g, "\\'");
			}
			
			if(ddParamType == 5){
				derivedAttribute = derivedAttribute.replace(/\n/g, "&&");
				derivedAttribute += "&&";
			}
			
			if(ddParamType == 6){
				derivedComputation = derivedComputation.replace(/\n/g, "&&");
				derivedComputation += "&&";
			}
			
			if(ddParamType == 8){
				derivedAttrForAssetList = derivedAttrForAssetList.replace(/\n/g, "&&");
				derivedAttrForAssetList += "&&";
			}
			
			//souradip 13/03/18
			var sendFlag = false;
			appendData += '<a style="float: right!important; margin-right:0.8em !important;" title="Edit"><i class="edit icon deleteEditIcon" onclick="passAllEditedParameterValues(this,\''+addParamFlag+'\',\''+assetParameterName+'\',\''+paramDesc+'\',\''+ddParamType+'\',\''+defaultViewChecked+'\','+hasStaticValueYes+','+importantYes+','+mandatoryParam+','+emailSchedulerYes+',\''+listSize+'\',\''+derivedAttribute+'\',\''+derivedComputation+'\',\''+listType+'\',\''+singleMultipleListType+'\',\''+custListItems+'\',\''+ddMappedAsset+'\',\''+categoryId+'\',\''+autoParameterIdCreator+'\',\''+isArray+'\', \''+sendFlag+'\', \''+true+'\', \''+derivedAttrForAssetList+'\', \''+ldapMappingNameId+'\');"></i></a>'; //harish
			appendData += '</div>';
         	$("#availableCategory_"+categoryId).append(appendData);
         	
         	
         	$('#addAssetParameterModal').dimmer('hide').modal('hide others').modal({ observeChanges: true }).modal('hide'); //.modal('hide dimmer'); // aditya added .modal({ observeChanges: true }) 06.03.18
         	/*$('#addAssetParameterModal').modal('hide');  //.modal('hide dimmer');
			$('#addAssetParameterModal').parent().css("display", "none !important");*/
		}
		 
		// globalParamId++;
		 autoParameterIdCreator = Math.floor((Math.random() * 1000000) + 1);
		 
		 
		// add only 10 parameter -- Hema 20.Dec.2017
		 $('#assetCategoryCardContent_'+categoryId).each(function(i){
			 var addedParamLength = $(this).find('.paramCount').length;
			 if(addedParamLength == 10){
				 $('#addRemoveCategoryIcon_'+categoryId).attr('disabled',true);
			 }else{
				 $('#addRemoveCategoryIcon_'+categoryId).attr('disabled',false); 
			 }
		 });
		 
		//console.log("final submit hasStaticValue :: "+hasStaticValueYes); 
		 
	});
		
}

function arrHasDuplicate( A ) {                          // finds any duplicate array elements using the fewest possible comparison
	var i, j, n;
	n=A.length;
                                                     // to ensure the fewest possible comparisons
	for (i=0; i<n; i++) {                        // outer loop uses each item i at 0 through n
		for (j=i+1; j<n; j++) {              // inner loop only compares items j at i+1 to n
			if (A[i] == A[j]) return true;
	}	}
	return false;
}

// load Edited data into paramater modal
var gloablParamName = "";
var assetParameterName;
var paramDesc;
var ddParamType;
var defaultViewChecked;
var hasStaticValueYes;
var importantYes;

var listSize;
var derivedAttribute;
var derivedComputation;
var listType;
var custListItems;
var ddMappedAsset;
var derivedAttr;
var derivedComp;
var derivedAttrForAssetList_AutoComplete = "";
var mandatoryParam;
var hasArrayFlagData = "",paramTypeVal="", hasDisabledVal="",hasStaticValueFlag="";
var enableDisable = "", isArrayData="", singlemultiType="";
var edit_ldapMappingNameId = ""; 
var emailSchedulerYes;

function passAllEditedParameterValues(objthis,addEditParamFlag,assetParameterName,paramDesc,ddParamType,defaultViewChecked,hasStaticValueYes,importantYes,mandatoryParam,emailSchedulerYes,listSize,derivedAttribute,derivedComputation,listType,singleMultipleListType,custListItems,ddMappedAsset,categoryId,parameterId,isArray, hasArrayFlag, multiSelectFlag, derivedAttrForAssetList_AutoComplete, ldapMappingNameId, flagForParameterUsageInRule, flagForParameterUsageInAssetListRule){ //harish
	
	$('#addAssetParameterModal').modal('destroy');
	paramTypeVal = ddParamType;
	hasDisabledVal = hasArrayFlag;
	var multiflag = multiSelectFlag; //harish
	singlemultiType = singleMultipleListType;
	isArrayData = isArray;
	
	//console.log("hasDisabledVal: "+hasDisabledVal);
	
	//console.log("multiflag :: "+multiflag);
	
	custListItems = decodeURIComponent(custListItems); 
	gloablParamName = assetParameterName;
	paramDesc = unescape(paramDesc);
	hasStaticValueFlag = hasStaticValueYes;
	$(".semanticModalCloseIConForIEafterAdd").unbind();
	
	//$('#editParamModalIcon').hide();
	$("#edit_submitAddedAssetParameter").unbind();
	$("#edit_cancelAddedAssetParameter").unbind();
	$('#edit_AssetParameterModal').modal('setting', 'closable', false).modal({observeChanges:true}).modal('show'); // aditya added .modal({observeChanges:tru 06.03.18
	$('#form_editAssetParameter').form('clear');
	$('.paramErr').hide();
	$('#edit_assetParameterName').val(assetParameterName);
	$('#edit_paramDesc').val(paramDesc);
	
	// IE and Firefox modal close Icon 
	/*if (!!navigator.userAgent.match(/Trident\/7\./)){
		setTimeout(function(){
			$('#editParamModalIcon').show();
			$("#editParamModalIcon").removeClass("semanticModalCloseIConForIEafterAdd");
			$("#editParamModalIcon").addClass("semanticModalCloseIConForIE");
		},800);
	}else{
		$('#editParamModalIcon').show();
	}*/
	
	
	/*Added By Hema BOC*/
	$('#parameterName').text(assetParameterName);
	/*EOC*/
	
	
	
	$('.ui.checkbox').checkbox();
	$('.assetInfoPopup').popup({
        inline: true,
      });
	//Add css to focus the checkboxes on keypress
	if($('input[type="checkbox"]').hasClass('hidden')){
    	$('.hidden').css('display','block');
    }
	$('input[type="checkbox"]').attr('tabindex', '0');
	var item = $(objthis);
	// date = 2
	if(ddParamType == 2){
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam').show();
		$('.edit_listTypeParam, .edit_customListItemParam, .edit_derivedAttrParam, .edit_derivedComputationParam, .edit_mappedAssetParam, .edit_sizeParam, .edit_derivedAttrForAssetListParam').hide();
		
		$('#edit_ddParamType').dropdown('set selected','Date');
		
		if(defaultViewChecked == 1){
			$('#edit_defaultViewYes').prop('checked',true);
		}
		else {
			$('#edit_defaultViewYes').prop('checked',false);
		}
		
		if(hasStaticValueYes == 1){
			$('#edit_hasStaticValueYes').prop('checked',true);
			//$('.edit_importantParam').hide();
			$('#edit_importantYes').prop("disabled", true);
		}
		else {
			$('#edit_hasStaticValueYes').prop('checked',false);
			//$('.edit_importantParam').show();
			$('#edit_importantYes').prop("disabled", false);
		}
		if(importantYes == true){
			$('#edit_importantYes').prop('checked',true);
		}
		else if(importantYes == false){
			$('#edit_importantYes').prop('checked',false);	
		}
		
		//Swathi- Email scheduler
		if(emailSchedulerYes == true){
			$('#edit_emailSchedulerYes').prop('checked',true);
		}
		else if(emailSchedulerYes == false){
			$('#edit_emailSchedulerYes').prop('checked',false);	
		}// EOc
		if(mandatoryParam == true){
			$('#edit_mandatoryYes').prop('checked',true);
		}
		else {
			 $('#edit_mandatoryYes').prop('checked',false);	
		}
	}
	// list = 4
	else if(ddParamType == 4){
		$('#edit_ddParamType').dropdown('set selected','List');
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam, .edit_listTypeParam, .edit_customListItemParam, .edit_singleMultipleParam').show(); //harish
		$('.edit_sizeParam, .edit_mappedAssetParam, .edit_derivedAttrParam, .edit_derivedComputationParam, .edit_derivedAttrForAssetListParam').hide();
		//harish
		if(singleMultipleListType == 0){
			$('#edit_ddsingleMultipleType').dropdown('set selected','Single Select List');
		} 
		else if(singleMultipleListType == 1){
			$('#edit_ddsingleMultipleType').dropdown('set selected','Multiple Select List');
		}
		

		if(listType == 1){
			$('#edit_listType').dropdown('set selected','Custom List');
			custListItems = custListItems.substring(0, custListItems.lastIndexOf("&&"));
			var newString = custListItems.replace(/&&/g, "\n");
			$('#edit_custListItems').val(newString);
		}
		else if(listType == 2){
			$('#edit_listType').dropdown('set selected','Asset List');
			$('#edit_ddMappedAsset').dropdown('set selected',ddMappedAsset);
		}
	
		else if(listType == 3){
			$('#edit_listType').dropdown('set selected','Native User List');
		}
		else if(listType == 4){
			$('.edit_customListItemParam').hide();
			$('#edit_listType').dropdown('set selected','Ldap User List');
		}
		
		if(defaultViewChecked == 1){
			$('#edit_defaultViewYes').prop('checked',true);
		}
		else {
			$('#edit_defaultViewYes').prop('checked',false);
		}
		
		if(hasStaticValueYes == true){
			$('#edit_hasStaticValueYes').prop('checked',true);
			//$('.edit_importantParam').hide();
			$('#edit_importantYes').prop("disabled", true);
		}
		else {
			$('#edit_hasStaticValueYes').prop('checked',false);
			//$('.edit_importantParam').show();
			$('#edit_importantYes').prop("disabled", false);
		}
		if(importantYes == true){
			$('#edit_importantYes').prop('checked',true);
		}
		else if(importantYes == false){
			$('#edit_importantYes').prop('checked',false);	
		}
		if(mandatoryParam == true){
			$('#edit_mandatoryYes').prop('checked',true);
		}
		else if(mandatoryParam == false){
			$('#edit_mandatoryYes').prop('checked',false);	
		}
		//Swathi- Email scheduler		
		if(emailSchedulerYes == true){
			$('#edit_emailSchedulerYes').prop('checked',true);
		}
		else if(emailSchedulerYes == false){
			$('#edit_emailSchedulerYes').prop('checked',false);	
		}
		
	}
	// text = 1
	else if(ddParamType == 1){
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam, .edit_sizeParam, .edit_isArray').show();
		$('.edit_derivedAttrParam, .edit_listTypeParam, .edit_mappedAssetParam, .edit_derivedComputationParam, .edit_customListItemParam, .edit_listTypeParam, .edit_derivedAttrForAssetListParam').hide();
	
		$('#edit_ddParamType').dropdown('set selected','Text');
		$('#edit_listSize').val(listSize);
		
		if(defaultViewChecked == 1){
			$('#edit_defaultViewYes').prop('checked',true);
		}
		else {
			$('#edit_defaultViewYes').prop('checked',false);
		}
		
		if(hasStaticValueYes == true){
			$('#edit_hasStaticValueYes').prop('checked',true);
			/*$('.edit_importantParam').hide();
			$('.edit_isArrayParam').hide();*/
			
			//Added by aditya 22.03.18	
			$('#edit_importantYes').prop("disabled", true);
			$('#edit_isArrayCheckbox').prop("disabled", true);
			//console.log("in if disabled");
			$('#edit_isArrayCheckbox').prop('checked',false);
		}
		else {
			$('#edit_hasStaticValueYes').prop('checked',false);
			$('.edit_importantParam').show();
			$('.edit_isArrayParam').show();
			//console.log("in if enabled");
			//Added by aditya 22.03.18			
			$('#edit_importantYes').prop("disabled", false);
			$('#edit_isArrayCheckbox').prop("disabled", false);
			
			if(isArray == 1){
				$('#edit_isArrayCheckbox').prop('checked',true);
			}else{
				$('#edit_isArrayCheckbox').prop('checked',false);
			}
		}
		if(importantYes == true){
			$('#edit_importantYes').prop('checked',true);
		}
		else if(importantYes == false){
			$('#edit_importantYes').prop('checked',false);
		}
		if(mandatoryParam == true){
			$('#edit_mandatoryYes').prop('checked',true);
		}
		else if(mandatoryParam == false){
			$('#edit_mandatoryYes').prop('checked',false);	
		}
		//Swathi- Email scheduler
		if(emailSchedulerYes == true){
			$('#edit_emailSchedulerYes').prop('checked',true);
		}
		else if(emailSchedulerYes == false){
			$('#edit_emailSchedulerYes').prop('checked',false);
		}
	}
	
	else if(ddParamType == 7){
		$('.edit_defaultViewParam, .edit_importantParam, .edit_isArrayParam').show();
		$('.edit_derivedComputationParam, .edit_mappedAssetParam, .edit_derivedAttrParam, .edit_sizeParam, .edit_listTypeParam, .edit_customListItemParam, .edit_hasStaticViewParam, .edit_derivedAttrForAssetListParam').hide();
		
		$('.edit_isArrayParam').show();	
		
		//Added by aditya 22.03.18					
		$('#edit_isArrayCheckbox').prop("disabled", false);
		
		$('#edit_ddParamType').dropdown('set selected','Rich Text');
		
		if(defaultViewChecked == 1){
			$('#edit_defaultViewYes').prop('checked',true);
		}
		else {
			$('#edit_defaultViewYes').prop('checked',false);
		}
		hasStaticValueYes = false;
		if(isArray == 1){
			$('#edit_isArrayCheckbox').prop('checked',true);
		}else{
			$('#edit_isArrayCheckbox').prop('checked',false);
		}
		
		/*if(hasStaticValueYes == true){
			$('#edit_hasStaticValueYes').prop('checked',true);
			$('.edit_importantParam').hide();
			
			$('.edit_isArrayParam').hide();
			//$('#edit_isArrayCheckbox').prop('checked',false);
		}
		else {
			$('#edit_hasStaticValueYes').prop('checked',false);
			$('.edit_importantParam').show();
			
			$('.edit_isArrayParam').show();	
		}*/
		
		
		
		
		/*if(isArray == 1){
			$('.edit_isArrayParam').show();
			$('#edit_isArrayCheckbox').prop('checked',true);
		}else{
			$('.edit_isArrayParam').hide();
			$('#edit_isArrayCheckbox').prop('checked',false);
		}*/
		
		if(importantYes == true){
			$('#edit_importantYes').prop('checked',true);
		}
		else if(importantYes == false){
			$('#edit_importantYes').prop('checked',false);
		}
		if(mandatoryParam == true){
			$('#edit_mandatoryYes').prop('checked',true);
		}
		else {
			$('#edit_mandatoryYes').prop('checked',false);	
		}
		//Swathi- Email scheduler
		if(emailSchedulerYes == true){
			$('#edit_emailSchedulerYes').prop('checked',true);
		}
		else if(emailSchedulerYes == false){
			$('#edit_emailSchedulerYes').prop('checked',false);
		}
	}
	
	// file = 3
	else if(ddParamType == 3){
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam').show();
		$('.edit_derivedComputationParam, .edit_mappedAssetParam, .edit_derivedAttrParam, .edit_sizeParam, .edit_listTypeParam, .edit_customListItemParam, .edit_derivedAttrForAssetListParam').hide();
		
		$('#edit_ddParamType').dropdown('set selected','File');
		
		if(defaultViewChecked == 1){
			$('#edit_defaultViewYes').prop('checked',true);
		}
		else {
			$('#edit_defaultViewYes').prop('checked',false);
		}
		
		if(hasStaticValueYes == true){
			$('#edit_hasStaticValueYes').prop('checked',true);
			//$('.edit_importantParam').hide();
			$('#edit_importantYes').prop("disabled", true);
		}
		else {
			$('#edit_hasStaticValueYes').prop('checked',false);
			//$('.edit_importantParam').show();
			$('#edit_importantYes').prop("disabled", false);
		}
		if(importantYes == true){
			$('#edit_importantYes').prop('checked',true);
		}
		else if(importantYes == false){
			$('#edit_importantYes').prop('checked',false);
		}
		if(mandatoryParam == true){
			$('#edit_mandatoryYes').prop('checked',true);
		}
		else {
			$('#edit_mandatoryYes').prop('checked',false);	
		}
		
		//Swathi - Email Scheduler -11.02.2020
		$("#edit_emailSchedulerYes").attr("disabled", true);
		$('.edit_emailSchedulerYes').addClass("disabled");
		$("label[for='edit_email_lbl']").addClass('changeLableColor');
	}
	// derived attribute = 5
	else if(ddParamType == 5){
		$('.edit_defaultViewParam, .edit_derivedAttrParam').show();
		$('.edit_hasStaticViewParam, .edit_importantParam, .edit_sizeParam, .edit_listTypeParam, .edit_customListItemParam, .edit_derivedComputationParam, .edit_mappedAssetParam, .edit_manadatoryParam, .edit_derivedAttrForAssetListParam').hide();
	
		$('#edit_ddParamType').dropdown('set selected','Derived Attribute');
		
		derivedAttribute = derivedAttribute.substring(0, derivedAttribute.lastIndexOf("&&"));
		var newString2 = derivedAttribute.replace(/&&/g, "\n");
		$('#edit_derivedAttribute').val(newString2);
		
		if(defaultViewChecked == 1){
			$('#edit_defaultViewYes').prop('checked',true);
		}
		else {
			$('#edit_defaultViewYes').prop('checked',false);
		}
		if(mandatoryParam == true){
			$('#edit_mandatoryYes').prop('checked',true);
		}
		else if(mandatoryParam == false){
			$('#edit_mandatoryYes').prop('checked',false);	
		}
		//Swathi- Email scheduler
		if(emailSchedulerYes == true){
			$('#edit_emailSchedulerYes').prop('checked',true);
		}
		else if(emailSchedulerYes == false){
			$('#edit_emailSchedulerYes').prop('checked',false);	
		}// EOc
	}
	// derived computation = 6
	else if(ddParamType == 6){
		$('.edit_defaultViewParam, .edit_derivedComputationParam').show();
		$('.edit_hasStaticViewParam, .edit_importantParam, .edit_sizeParam, .edit_listTypeParam, .edit_customListItemParam, .edit_derivedAttrParam, .edit_mappedAssetParam, .edit_manadatoryParam, .edit_derivedAttrForAssetListParam').hide();
		
		$('#edit_ddParamType').dropdown('set selected','Derived Computation');
		
		derivedComputation = derivedComputation.substring(0, derivedComputation.lastIndexOf("&&"));
		var newString1 = derivedComputation.replace(/&&/g, "\n");
		$('#edit_derivedComputation').val(newString1);
		
		/*$('#edit_derivedComputation').val(derivedComputation);*/
		if(defaultViewChecked == 1){
			$('#edit_defaultViewYes').prop('checked',true);
		}
		else {
			$('#edit_defaultViewYes').prop('checked',false);
		}
		if(mandatoryParam == true){
			$('#edit_mandatoryYes').prop('checked',true);
		}
		else if(mandatoryParam == false){
			$('#edit_mandatoryYes').prop('checked',false);	
		}
		//Swathi- Email scheduler
		if(emailSchedulerYes == true){
			$('#edit_emailSchedulerYes').prop('checked',true);
		}
		else if(emailSchedulerYes == false){
			$('#edit_emailSchedulerYes').prop('checked',false);	
		}// EOc
	
	}
	
	// derived attribute for asset list _ auto complete
	else if(ddParamType == 8){
		$('.edit_defaultViewParam, .edit_derivedAttrForAssetListParam').show();
		$('.edit_hasStaticViewParam, .edit_importantParam, .edit_sizeParam, .edit_listTypeParam, .edit_customListItemParam, .edit_derivedComputationParam, .edit_mappedAssetParam, .edit_manadatoryParam, .edit_derivedAttrParam').hide();
	
		$('#edit_ddParamType').dropdown('set selected','Derived Attribute For Asset List');
		
		derivedAttrForAssetList_AutoComplete = derivedAttrForAssetList_AutoComplete.substring(0, derivedAttrForAssetList_AutoComplete.lastIndexOf("&&"));
		var newString3 = derivedAttrForAssetList_AutoComplete.replace(/&&/g, "\n");
		$('#edit_derivedAttrForAssetList').val(newString3);
		
		if(defaultViewChecked == 1){
			$('#edit_defaultViewYes').prop('checked',true);
		}
		else {
			$('#edit_defaultViewYes').prop('checked',false);
		}
		if(mandatoryParam == true){
			$('#edit_mandatoryYes').prop('checked',true);
		}
		else if(mandatoryParam == false){
			$('#edit_mandatoryYes').prop('checked',false);	
		}
		//Swathi- Email scheduler
		if(emailSchedulerYes == true){
			$('#edit_emailSchedulerYes').prop('checked',true);
		}
		else if(emailSchedulerYes == false){
			$('#edit_emailSchedulerYes').prop('checked',false);	
		}// EOc
	}
	
	// ldap mapping name list Id
	else if(ddParamType == 9){
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam, .edit_singleMultipleParam, .edit_dd_ldapMappedListOfNames').show();
		$('.edit_sizeParam, .edit_mappedAssetParam, .edit_derivedAttrParam, .edit_derivedComputationParam, .edit_derivedAttrForAssetListParam, .edit_listTypeParam').hide();
		$("#edit_mandatoryYes").show();
		
		$('.edit_hasStaticViewParam').addClass("disabled");
		$("#edit_hasStaticValueYes").attr("disabled", true);
		$("label[for='edit_is_static_val']").addClass('changeLableColor');
		
		$('#edit_ddParamType').dropdown('set selected','LDAP Attribute Mapping');
		
		if(singleMultipleListType == 0){
			$('#edit_ddsingleMultipleType').dropdown('set selected','Single Select List');
		} 
		else if(singleMultipleListType == 1){
			$('#edit_ddsingleMultipleType').dropdown('set selected','Multiple Select List');
		}
		
		if(mandatoryParam == true){
			$('#edit_mandatoryYes').prop('checked',true);
		}
		else if(mandatoryParam == false){
			$('#edit_mandatoryYes').prop('checked',false);	
		}
		
		if(defaultViewChecked == 1){
			$('#edit_defaultViewYes').prop('checked',true);
		}
		else {
			$('#edit_defaultViewYes').prop('checked',false);
		}
		
		if(importantYes == true){
			$('#edit_importantYes').prop('checked',true);
		}
		else if(importantYes == false){
			$('#edit_importantYes').prop('checked',false);
		}
		
		$('#edit_dd_LdapMappedList').dropdown('set selected',ldapMappingNameId);
		
		loadLdapAttributes(ldapMappingNameId);
		
		//Swathi- Email scheduler
		if(emailSchedulerYes == true){
			$('#edit_emailSchedulerYes').prop('checked',true);
		}
		else if(emailSchedulerYes == false){
			$('#edit_emailSchedulerYes').prop('checked',false);	
		}// EOc
	}
	
	//enableDisable = $("#edit_importantYes").is(':disabled');
	$('#edit_hasStaticValueYes').removeClass('hidden');
	
	//Submit Edited Parameter
	
	
	$('#edit_submitAddedAssetParameter').on('click',function(){
		/*if (!!navigator.userAgent.match(/Trident\/7\./)){//Aditya 29.03.18
			$("#editParamModalIcon").removeClass("semanticModalCloseIConForIE");
			$("#editParamModalIcon").addClass("semanticModalCloseIConForIEafterAdd");
		}*/
		
		
		assetParameterName = "";
		assetParameterName = $("#edit_assetParameterName").val().trim();
		
		paramDesc = "";
		paramDesc = $('#edit_paramDesc').val().trim();
		//paramDesc = paramDesc.replace(/"/g, '\ ');
		paramDesc = escape(paramDesc);
		ddParamType = "";
		ddParamType = $('#edit_ddParamType option:selected').val();
		defaultViewChecked = 0;
		if ($("input[id='edit_defaultViewYes']").is(':checked')) {
			defaultViewChecked = 1;
		}
		else {
			defaultViewChecked = 0;
		}
		
		
		hasStaticValueYes = "";
		if ($("input[id='edit_hasStaticValueYes']").is(':checked')) {
			hasStaticValueYes = true;
		}
		else {
			hasStaticValueYes = false;
		}

		importantYes = "";
		if ($("input[id='edit_importantYes']").is(':checked')) {
			importantYes = true;
		}
		else {
			importantYes = false;
		} 
		
		mandatoryParam = "";
		if ($("input[id='edit_mandatoryYes']").is(':checked')) {
			mandatoryParam = true;
		}
		else {
			mandatoryParam = false;
		} 
		
		
		//Swathi- Email scheduler
		var emailSchedulerYes = "";
		if ($("input[id='edit_emailSchedulerYes']").is(':checked')) {
			emailSchedulerYes = true;
		}
		else {
			emailSchedulerYes = false;
		} 
		
		 listSize = "";
		 derivedAttribute = "";
		 derivedComputation = "";
		 listType = "";
		 custListItems = "";
		 ddMappedAsset = "";
		 derivedAttr = "";
		 derivedComp = "";
		 derivedAttrForAssetList_AutoComplete = "";
		
		listSize = $('#edit_listSize').val().trim();
		derivedAttribute = $('#edit_derivedAttribute').val().trim();
		derivedComputation = $('#edit_derivedComputation').val().trim();
		listType = $('#edit_listType option:selected').val();
		singleMultipleListType =  $('#edit_ddsingleMultipleType option:selected').val(); //harish
		
		custListItems = $('#edit_custListItems').val().trim();
		ddMappedAsset = $('#edit_ddMappedAsset option:selected').val();
		specialCharRegexStr = /^[a-zA-Z0-9\s]+$/;
		inptUserNameIsValid = specialCharRegexStr.test(assetParameterName);
		
		 /*BOC ldap mapping name - mapped id from dropdown - Hema 27.Feb.2019 */
		derivedAttrForAssetList_AutoComplete = $('#edit_derivedAttrForAssetList').val().trim();
	
		/*EOC*/
		
		 /*BOC ldap mapping name - mapped id from dropdown - Hema 28.Feb.2019 */
	 	edit_ldapMappingNameId = "";
	 	edit_ldapMappingNameId = $('#edit_dd_LdapMappedList option:selected').val();
	 	/*EOC*/
	 	
		var setFlag = true;
		
		//$('#addNewParameter').removeAttr("style");
		
		if(assetParameterName == null || assetParameterName == ""){
			$("#edit_paramSpclChar").hide();
			$("#edit_paramNameErr").html('Please select parameter name').show();
			$('#edit_assetParameterName').parent().addClass("error"); 
			setFlag = false;
			
		}
		else if (!inptUserNameIsValid){
			$("#edit_paramNameErr").hide();
			$("#edit_paramSpclChar").html("Please enter only alphanumerical values").show();
			$('#edit_assetParameterName').parent().addClass("error");  
			setFlag = false;
		}
		
		else {
			$("#edit_paramNameErr").hide();
			$("#edit_paramSpclChar").hide();
			$('#edit_assetParameterName').parent().removeClass("error");  
		}
		
		// check param duplications BOC
		for(var h = 0; h < arrParameters.length; h++){
			if(arrParameters[h] == gloablParamName){
				delete arrParameters[h]; // removes same parameter name and adds up remaining parameter names
			}
			//console.log("duplicates : " + arrParameters);
		}
		
		// delete arrParameters[h]; - adds up null values so $.grep is used to remove null values
		arrParameters = $.grep(arrParameters,function(n){
	        return(n);
	        arrParameters.push(n);
	    });
		
		if(assetParameterName != ""){
			var addedFlag = false;
			for(p=0; p < arrParameters.length; p++){
				if(arrParameters[p] == assetParameterName.toLowerCase()){
					addedFlag = true;
					index = p;	
					break;
				}
			}
			
			if(gloablParamName == assetParameterName){
				addedFlag = false;
			}

			if(!addedFlag){
				//$("#edit_paramNameErr").hide();
				//$('#edit_assetParameterName').parent().removeClass("error");  
				
			}
			else {
				setFlag = false;
				$("#edit_paramNameErr").html('This parameter has been already added').show();
				$('#edit_assetParameterName').parent().addClass("error");
			}
		}
		// EOC to check duplication of parameter name 
		
		if(paramDesc == null || paramDesc == ""){
			$('#edit_paramDescErr').html('Please provide parameter description').show();
			$('#edit_paramDesc').parent().addClass("error");  
			setFlag = false;
		}
		else {
			$("#edit_paramDescErr").hide();
			$('#edit_paramDesc').parent().removeClass("error");  
		}
		
		 if($('#edit_ddParamType option:selected').text() == "Select Parameter Type"){
			$("#edit_sparamTypeErr").show();
			$('#edit_ddParamType').parent().addClass("error"); 
			setFlag = false;
		}
		 else {
			 $("#edit_sparamTypeErr").hide();
			 $('#edit_ddParamType').parent().removeClass("error");  
		 }
		 
		 var regex = new RegExp('^[0-9]+$');
		 
		 //text size
		 if(ddParamType == 1){
			 if(listSize == "" || listSize == null){
					 $("#edit_listSizeErr").html('Please provide text size').show();
					 $('#edit_listSize').parent().addClass("error");  
						setFlag = false; 
			 }
			 else if(!regex.test(listSize) ) {
				 $("#edit_listSizeErr").html('Please enter only positive integers').show();
				 $('#edit_listSize').parent().addClass("error");  
					setFlag = false; 
				}
			 
			 else {
				 	$("#edit_listSizeErr").hide();
					$('#edit_listSize').parent().removeClass("error");  
			 }
			 
			 
			 if(hasStaticValueYes == true){
				 isArray = 0;
			 }
			 else {
				 if ($("input[id='edit_isArrayCheckbox']").is(':checked')) {
					 isArray = 1;
				 }
				 else {
					 isArray = 0;
				 }
			 }
			 custListItems = ""; 
			 listType = 0;
			 ddMappedAsset = 0;
			 derivedAttribute = "";
			 derivedComputation = "";
			 derivedAttrForAssetList_AutoComplete = "";
			 edit_ldapMappingNameId = "";
		 }
		 
		 // rich text
		 if(ddParamType == 7){
			 custListItems = ""; 
			 listSize = "";
			 listType = 0;
			 ddMappedAsset = 0;
			 derivedAttribute = "";
			 derivedComputation = "";
			 derivedAttrForAssetList_AutoComplete = "";
			 edit_ldapMappingNameId = "";
			 
			 if ($("input[id='edit_isArrayCheckbox']").is(':checked')) {
				 isArray = 1;
			 }
			 else {
				 isArray = 0;
			 }
			 
			 
		 }
		 
		 
		 // date
		 if(ddParamType == 2){
			 custListItems = ""; 
			 listSize = "";
			 listType = 0;
			 ddMappedAsset = 0;
			 derivedAttribute = "";
			 derivedComputation = "";
			 isArray = 0;
			 derivedAttrForAssetList_AutoComplete = "";
			 edit_ldapMappingNameId = "";
		 }
		 
		 // file
		 if(ddParamType == 3){
			 custListItems = ""; 
			 listSize = "";
			 listType = 0;
			 ddMappedAsset = 0;
			 derivedAttribute = "";
			 derivedComputation = "";
			 isArray = 0;
			 derivedAttrForAssetList_AutoComplete = "";
			 edit_ldapMappingNameId = "";
		 }
		 
		 // list type
		 if(ddParamType == 4){
			 if(listType == "" || listType == null){
				 $("#edit_custListTypeErr").html('Please select list type').show();
				 $('#edit_listType').parent().addClass("error");  
					setFlag = false;
			 }
			 else {
				  $("#edit_custListTypeErr").html('').hide();
				  $('#edit_listType').parent().removeClass("error");  
			 }
			 
			 // custom list
			 if(listType == 1){
				 $("#edit_customlistTextBoxErr").hide();
				 $('#edit_custListItems').parent().removeClass("error");
				 
				 var iChars = "#^&+,~`";
				  
				  for (var i = 0; i < custListItems.length; i++){
				  	if (iChars.indexOf(custListItems.charAt(i)) != -1){
				  		 $('#edit_customlistTextBoxErr').html('Please do not use #^&+,~` characters in custom list').show();
						 $('#edit_custListItems').parent().addClass("error");  
						 setFlag = false;
				  		 return false;
				  	}
				  }
				  
				 if(custListItems == null || custListItems == ""){
					 $('#edit_customlistTextBoxErr').html('Please provide the custom list').show();
					 $('#edit_custListItems').parent().addClass("error");  
						setFlag = false;  
				 }
				 else {
					 var empty_val_flag = 0;
					 var sameNameCheck = custListItems.split('\n');
					 var tarr = [];
					 for (var i = 0; i < sameNameCheck.length; i++) {
						 tarr.push(sameNameCheck[i].trim());
					 }
					 var recipientsArray = tarr.sort(); 
					 
					 for (var i = 0; i < sameNameCheck.length; i++) {
					 if(sameNameCheck[i] == ""){
						  empty_val_flag = 1;
					  }
					  if(i == (sameNameCheck.length-1)){
						  if(empty_val_flag == 1){
							  $('#edit_customlistTextBoxErr').html('Please provide the custom list').show();
							  $('#edit_custListItems').parent().addClass("error");  
							  return false;
						  }
					  }
					 }
					 
					 if ( arrHasDuplicate( recipientsArray ) ){
						 $('#edit_customlistTextBoxErr').html('There are duplicate values in custom list, please check').show();
						 $('#edit_custListItems').parent().addClass("error");  
							setFlag = false;
					 }
					 else{
						 $("#edit_customlistTextBoxErr").hide();
						 $('#edit_custListItems').parent().removeClass("error");
					 }
					 
					 if(setFlag == true){
						  for (var i = 0; i < sameNameCheck.length; i++) {
							  if(sameNameCheck[i] == ""){
								  empty_val_flag = 1;
							  }
							  if(i == (sameNameCheck.length-1)){
								  if(empty_val_flag == 1){
									  $('#edit_customlistTextBoxErr').html('Please provide the custom list').show();
									  $('#edit_custListItems').parent().addClass("error");  
									  setFlag = false;
								  }
							  }
							 if(sameNameCheck[i].trim() == null || sameNameCheck[i].trim() == ""){
								 $('#edit_customlistTextBoxErr').html('Please provide the custom list').show();
								 $('#edit_custListItems').parent().addClass("error");  
									setFlag = false;  
							 }
						  }
							 if ( arrHasDuplicate( recipientsArray ) ){
								 $('#edit_customlistTextBoxErr').html('There are duplicate values in custom list, please check').show();
								 $('#edit_custListItems').parent().addClass("error");  
									setFlag = false;
							 }
							 else{
								 /*$("#edit_customlistTextBoxErr").hide();
								 $('#edit_custListItems').parent().removeClass("error");*/
							 }
					 }
				 }
				 
				 listSize = "";
				 ddMappedAsset = 0;
				 derivedAttribute = "";
				 derivedComputation = "";
				 isArray = 0;
				 derivedAttrForAssetList_AutoComplete = "";
				 edit_ldapMappingNameId = "";
			 }
			 
			 // asset list
			 if(listType == 2){
				 if(ddMappedAsset == ""){
					 $('#edit_ddMappedAssetErr').html('Please select the mapped asset').show();
					 $('#edit_ddMappedAsset').parent().addClass("error");  
					 setFlag = false; 
				 }
				 else {
					 $('#edit_ddMappedAssetErr').hide();
					 $('#edit_ddMappedAsset').parent().removeClass("error"); 
				 }
				 
				 listSize = "";
				 derivedAttribute = "";
				 derivedComputation = "";
				 custListItems = "";
				 isArray = 0;
				 derivedAttrForAssetList_AutoComplete = "";
				 edit_ldapMappingNameId = "";
			 }
			 
			 // user list
			 if(listType == 3){
				 listSize = "";
				 ddMappedAsset = 0;
				 derivedAttribute = "";
				 derivedComputation = "";
				 custListItems = "";
				 isArray = 0;
				 derivedAttrForAssetList_AutoComplete = "";
				 edit_ldapMappingNameId = "";
			 }
			
			 
		 }
		 
		// validation  for update  static value
		 if(ddParamType != 5 || ddParamType != 6 || ddParamType != 8){
			 var flag;
			 if(hasStaticValueYes){
				 flag = 1; 
			 }else{
				 flag = 0;
			 }
			 
			 $.ajax({
				 type: "POST", 
				// url: "/repopro/web/assetType/validateChangetoStaticforMappedDerivedParam?isStatic="+flag+"&assetParamName="+assetParameterName+"&assetName="+editAssetName,
				 url: "/repopro/web/assetType/validateChangetoStaticforMappedDerivedParam?isStatic="+flag+"&assetParamName="+assetParameterName+"&assetName="+editAssetName+"&parameterId="+parameterId+"&paramTypeId="+ddParamType+"&listTypeParamTypeId="+listType,
				 contentType : "application/json",
				 dataType : "json",
				 data : JSON.stringify(obj),
				 async: false,
				 complete:function(data){									
					 var json = JSON.parse(data.responseText);
					 if(json.result != ""){
						 setFlag = false;  
						 notifyMessage("Edit Asset",json.result[0],"fail");
					 }
				 }
			 });
			 
		 }
		 		
		 // derived attribute validation
		 var oldAssetName = editAssetName;
		 var newAssetName = $('#assetName').text();
		 if(ddParamType == 5){
			 derivedAttr = $('#edit_derivedAttribute').val().trim();
			 if(derivedAttr == ""){
				 $('#edit_derivedAttrErr').html('Please provide the derived attribute').show();
				 $('#edit_derivedAttribute').parent().parent().addClass("error");  
				 setFlag = false;  
			 }
			 else {
				 $('#edit_derivedAttrErr').hide();
				 $('#edit_derivedAttribute').parent().parent().removeClass("error");  
				 
				 var obj = {
						 "assetParamName":assetParameterName,
						 "derivedAttributeComputation":derivedAttr
				 }
				 $.ajax({
					 type: "POST", 
					 url: "/repopro/web/assetType/validationForDerivedPattern?mainAssetName="+oldAssetName+"&oldAssetName="+newAssetName,
					 contentType : "application/json",
					 dataType : "json",
					 data : JSON.stringify(obj),
					 async: false,
					 complete:function(data){									
						 var json = JSON.parse(data.responseText);
						 if(json.result != ""){// modified by Gomathi - 16/03/2018
							 setFlag = false; 
							 if(json.result == 'Parameter already used in rule! So cannot change parameter type!'){
								 notifyMessage("Edit Parameter",json.result , "fail");
							 }else{
							 $('#edit_derivedAttrErr').html(json.result).show();
							 $('#edit_derivedAttribute').parent().addClass("error");
							 }
						 }
					 }
				 });
			 }
			 
			 listSize = "";
			 listType = 0;
			 custListItems = "";
			 ddMappedAsset = 0;
			 derivedComputation = "";
			 isArray = 0;
			 derivedAttrForAssetList_AutoComplete = "";
			 edit_ldapMappingNameId = "";
		 }else{
			 derivedAttribute = "";
		 }
		 
		 // derived computation validation
		 if(ddParamType == 6){
			 derivedComp = $('#edit_derivedComputation').val().trim();
			 if(derivedComp == ""){
				 $('#edit_derivedComputationErr').html('Please provide the computation derivation').show();
				 $('#edit_derivedComputation').parent().parent().addClass("error");  
				 setFlag = false;  
			 }
			 else {
				 $('#edit_derivedComputationErr').hide();
				 $('#edit_derivedComputation').parent().parent().removeClass("error");  
				 
				 var obj = {
						 "assetParamName":assetParameterName,
						 "derivedAttributeComputation":derivedComp
				 }
				 $.ajax({
					 type: "POST", 
					 url: "/repopro/web/assetType/validationForDerivedComputationPattern?mainAssetName="+oldAssetName+"&oldAssetName="+newAssetName,
					 contentType : "application/json",
					 dataType : "json",
					 data : JSON.stringify(obj),
					 async: false,
					 complete:function(data){									
						 var json = JSON.parse(data.responseText);
						 if(json.result != ""){// modified by Gomathi - 16/03/2018
							 setFlag = false;  
							 if(json.result == 'Parameter already used in rule! So cannot change parameter type!'){
								 notifyMessage("Edit Parameter",json.result , "fail");
							 }else{
							 $('#edit_derivedComputationErr').html(json.result).show();
							 $('#edit_derivedComputation').parent().parent().addClass("error");
							 }
						 }
					 }
				 });
			 }
			 listSize = "";
			 listType = 0;
			 custListItems = "";
			 ddMappedAsset = 0;
			 derivedAttribute = "";
			 isArray = 0;
			 derivedAttrForAssetList_AutoComplete = "";
			 edit_ldapMappingNameId = "";
			 
		 }else {
			 derivedComputation  = "";
		 }
		 
		 
		 // derived attribute for asset list - 26.Feb.2019 Hema
		 if(ddParamType == 8){
			 if(derivedAttrForAssetList_AutoComplete == ""){
				 $('#edit_derivedAttrForAssetListErr').html('Please enter derived attribute for asset list ').show();
				 $('#edit_derivedAttrForAssetList').parent().parent().addClass("error");  
				 setFlag = false;  
			 }
			 else {
				 $('#edit_derivedAttrForAssetListErr').hide();
				 $('#edit_derivedAttrForAssetList').parent().parent().removeClass("error");  
				 
				 var obj = {
						 "assetParamName":assetParameterName,
						 "derivedAssetListRule":derivedAttrForAssetList_AutoComplete
				 }
				 $.ajax({
					 type: "POST", 
					 url: "/repopro/web/assetType/validationForDerivedPatternForAssetList?mainAssetName="+oldAssetName+"&oldAssetName="+newAssetName+"&userName="+loggedInUserName,
					 contentType : "application/json",
					 dataType : "json",
					 data : JSON.stringify(obj),
					 async: false,
					 complete:function(data){									
						 var json = JSON.parse(data.responseText);
						 if(json.result != ""){
							 setFlag = false;  
							 if(json.result == 'Parameter already used in rule! So cannot change parameter type!'){
								 notifyMessage("Edit Parameter",json.result , "fail");
							 }else{
								 $('#edit_derivedAttrForAssetListErr').html(json.result).show();
								 $('#edit_derivedAttrForAssetList').parent().addClass("error");
							 }
						 }
					 }
				 });
			 }
			 listSize = "";
			 listType = 0;
			 custListItems = "";
			 ddMappedAsset = 0;
			 derivedComputation = "";
			 isArray = 0;
			 derivedAttribute = "";
			 edit_ldapMappingNameId = "";
		 }else{
			 derivedAttrForAssetList_AutoComplete = "";
		 }
		 
		 // ldap mapping validations
		 if(ddParamType == 9){
			 if(singleMultipleListType == ""){
				 $('#edit_singleMultipleTypeErr').html('Please select one param').show();
				 $('#edit_ddsingleMultipleType').parent().addClass("error");  
				 setFlag = false; 
			 }
			 else {
				 $('#edit_singleMultipleTypeErr').hide();
				 $('#edit_ddsingleMultipleType').parent().removeClass("error"); 
			 }
			 
			 if(edit_ldapMappingNameId == ""){
				 $('#edit_ldapMappedListErr').html('Please select mapped name').show();
				 $('#edit_dd_LdapMappedList').parent().addClass("error");  
				 setFlag = false; 
			 }
			 else {
				 $('#edit_ldapMappedListErr').hide();
				 $('#edit_dd_LdapMappedList').parent().removeClass("error"); 
			 }
			 
		 }else {
			 edit_ldapMappingNameId = "";
		 }
		 
		 
		 if(setFlag == false){
			 return true;
		 }
		else {
			arrParameters.push(assetParameterName.toLowerCase());
			var editParamFlag = 'falseFlag';
			if(addEditParamFlag == 'trueFlag'){
				//autoParameterIdCreator = Math.floor((Math.random() * 1000000) + 1);
				//parameterId = autoParameterIdCreator;
				var paramId = $(objthis).parent().parent().attr('id');
				var paramIdArr = paramId.split("_");
				parameterId = paramIdArr[1];
				
			}
			else if(addEditParamFlag == 'falseFlag'){
				//$(objthis).closest("div").remove();
			}
		    //console.log("edit ------ assetParameterName : " + assetParameterName + " paramDesc : " + paramDesc + " ddParamType : " + ddParamType + " defaultViewChecked : " + defaultViewChecked + " hasStaticValueYes : " + hasStaticValueYes + " importantYes : " + importantYes + " listSize : " + listSize + " derivedAttribute : " + derivedAttribute + " derivedComputation : " + derivedComputation + " listType : " + listType + " custListItems : " + custListItems + " ddMappedAsset : " + ddMappedAsset);
			var data = "<p>Are you sure you want to delete "+assetParameterName+" ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeParamPopup("+parameterId+")'>No</button><button class='right floated ui primary mini button' onclick='paramDelete(this,"+parameterId+","+categoryId+")'>Yes</button> ";
			appendData = "";
			//appendData += '<div class="ui segment sortableSegmentCursor divParamValues" id="parameterId_'+parameterId+'">;
			appendData += '<span class="assetParamName">'+assetParameterName+'</span>';
			appendData += '<pre style="display:none;" class="paramDescription"><textarea>'+paramDesc+'</textarea>'+paramDesc+'</pre>';
			appendData += '<span style="display:none;" class="paramTypeDD">'+ddParamType+'</span>';
			appendData += '<span style="display:none;" class="defaultViewChecked">'+defaultViewChecked+'</span>';
			appendData += '<span style="display:none;" class="hasStaticValueYes">'+hasStaticValueYes+'</span>';
			appendData += '<span style="display:none;" class="importantYes">'+importantYes+'</span>';
			
			appendData += '<span style="display:none;" class="mandatoryParam">'+mandatoryParam+'</span>';
			
			appendData += '<span style="display:none;" class="listSize">'+listSize+'</span>';
			appendData += '<span style="display:none;" class="derivedAttribute">'+derivedAttribute+'</span>';
			appendData += '<span style="display:none;" class="derivedComputation">'+derivedComputation+'</span>';
			appendData += '<span style="display:none;" class="listType">'+listType+'</span>';
			appendData += '<span style="display:none;" class="singleMultipleListType">'+singleMultipleListType+'</span>'; //harish
			appendData += '<span style="display:none;" class="custListItems abc">'+custListItems+'</span>';
			appendData += '<span style="display:none;" class="ddMappedAsset">'+ddMappedAsset+'</span>';
			appendData += '<span style="display:none;" class="isArrayCheckbox">'+isArray+'</span>';
			
			// BOC - Hema - Ldap mapping Name & derived attribute for asset_Auto Complete
			appendData += '<span style="display:none;" class="derivedAttribute_AutoComplete">'+derivedAttrForAssetList_AutoComplete+'</span>';
			appendData += '<span style="display:none;" class="ldapMappingNameListId">'+edit_ldapMappingNameId+'</span>';
			//Swathi- Email scheduler
			appendData += '<span style="display:none;" class=" emailSchedulerYes">'+emailSchedulerYes+'</span>';
			
			if($(objthis).parent().parent().find('.actionForParameter').text() == "ADD"){
				appendData += '<span style="display:none;" class="actionForParameter">ADD</span>';
			}else{
				appendData += '<span style="display:none;" class="actionForParameter">UPDATE</span>';
			}
			
			
			/*appendData += '<a style="float: right!important;" title="Delete"><i class="trash icon deleteEditIcon" onclick="paramDelete(this)"></i></a>';*/
			if(flagForParameterUsageInRule == "true" || flagForParameterUsageInAssetListRule == "true"){
				appendData += '<a style="float: right!important;"><i class="trash icon deleteEditIcon catParamDeleteIcon" id="paramId_'+parameterId+'"></i></a>';
			}
			else {
				appendData += '<a style="float: right!important;"><i class="trash icon deleteEditIcon" id="paramId_'+parameterId+'" data-html="'+data+'" onclick="openParamPopup('+parameterId+')"></i></a>';
			}
			
			if(listType == 1){
				custListItems = custListItems.replace(/\n/g, "&&");
				var custData = custListItems.split("&&");
				custListItems = "";
				$.each(custData,function(i){
					custListItems += ((custData[i]).trim())+"&&";  
				});
				custListItems = encodeURIComponent(custListItems);
				custListItems = custListItems.replace(/'/g, "\\'");
			}
					
			if(ddParamType == 5){
				derivedAttribute = derivedAttribute.replace(/\n/g, "&&");
				derivedAttribute += "&&";
			}
			
			if(ddParamType == 6){
				derivedComputation = derivedComputation.replace(/\n/g, "&&");
				derivedComputation += "&&";
			}
			
			if(ddParamType == 8){
				derivedAttrForAssetList_AutoComplete = derivedAttrForAssetList_AutoComplete.replace(/\n/g, "&&");
				derivedAttrForAssetList_AutoComplete += "&&";
			}
			
			
			appendData += '<a style="float: right!important; margin-right:0.8em !important;"><i class="edit icon deleteEditIcon" onclick="passAllEditedParameterValues(this,\''+editParamFlag+'\',\''+assetParameterName+'\',\''+paramDesc+'\',\''+ddParamType+'\',\''+defaultViewChecked+'\','+hasStaticValueYes+','+importantYes+','+mandatoryParam+','+emailSchedulerYes+',\''+listSize+'\',\''+derivedAttribute+'\',\''+derivedComputation+'\',\''+listType+'\',\''+singleMultipleListType+'\',\''+custListItems+'\',\''+ddMappedAsset+'\',\''+categoryId+'\',\''+parameterId+'\',\''+isArray+'\',\''+hasArrayFlag+'\',\''+multiSelectFlag+'\', \''+derivedAttrForAssetList_AutoComplete+'\',\''+edit_ldapMappingNameId+'\',\''+flagForParameterUsageInRule+'\',\''+flagForParameterUsageInAssetListRule+'\');"></i></a>'; //harish
		//	appendData += '</div>';
			
			$("#parameterId_"+parameterId).html(appendData);
			$('#edit_AssetParameterModal').dimmer('hide').modal('hide others').modal({observeChanges:true}).modal('hide'); //.modal('hide dimmer');   // aditya added .modal({observeChanges:true}) 06.03.18
			/*$('#edit_AssetParameterModal').modal('hide'); //.modal('hide dimmer');
			$('#edit_AssetParameterModal').parent().css("display", "none !important");*/
		}

	});
	
	
	
	
		//souradip 5.7.18
		if(editAsset == "editAsset"){
			$("#form_editAssetParameter").on("keypress",function(event){
				if(disableFlagAPIIncall){
					event.preventDefault();
				} 
			});
			
			if(disableFlagAPIIncall){


				$("#editAssetParameterLoader").show();
				$("#edit_submitAddedAssetParameter").addClass("disabled");
				var intervalFunction = setInterval(function(){ 

					if(disableFlagAPIIncall == false){

						$("#editAssetParameterLoader").hide();
						$("#edit_submitAddedAssetParameter").removeClass("disabled");

						var json = enableOrDisableSingleMultiSelectListAndIsArrayJSON;

						$.each(json.result[0].categories, function(i) {
							//gloablParamName

							$.each(json.result[0].categories[i].listOfAssetParamDefs, function(j){
								if(json.result[0].categories[i].listOfAssetParamDefs[j].assetParamName == gloablParamName){

									multiSelectFlag = json.result[0].categories[i].listOfAssetParamDefs[j].multiSelectFlag;
									hasArrayFlag = json.result[0].categories[i].listOfAssetParamDefs[j].hasArrayFlag;
									mappingFlag = json.result[0].categories[i].listOfAssetParamDefs[j].mappingFlag;
									
									//aditya added 07.03.18
									if(hasArrayFlag == true){
										//console.log("hasArrayFlag last - 1 :: "+hasArrayFlag);
										$(".edit_isArrayParam").addClass("disabled");//.attr("disabled", true);
									}else{
										//console.log("hasArrayFlag last -2 :: "+hasArrayFlag);
										$(".edit_isArrayParam").removeClass("disabled");//.attr("disabled", false);
									}
									//harish
									if(multiSelectFlag == false){
										$(".edit_singleMultipleParam").addClass("disabled");//.attr("disabled", true);
									}else{
										$(".edit_singleMultipleParam").removeClass("disabled");//.attr("disabled", false);
									}
									
									// Hema 19.Mar.2019 
									if(mappingFlag == true){
										$(".edit_dd_ldapMappedListOfNames").addClass("disabled");//.attr("disabled", true);
										if($(".edit_dd_ldapMappedListOfNames").hasClass("disabled")){
											$('#edit_dd_LdapMappedList').parent().attr('tabindex', '-1');
											$('#edit_ddsingleMultipleType').parent().attr('tabindex', '-1');
										}
									}else{
										$(".edit_dd_ldapMappedListOfNames").removeClass("disabled");//.attr("disabled", false);
									}
								}
							});

						});

						clearInterval(intervalFunction);

					}
				}, 1000);
			}else{
				$("#editAssetParameterLoader").hide();
				$("#edit_submitAddedAssetParameter").removeClass("disabled");

				var json = enableOrDisableSingleMultiSelectListAndIsArrayJSON;
				
				
				$.each(json.result[0].categories, function(i) {
					//gloablParamName
					
					$.each(json.result[0].categories[i].listOfAssetParamDefs, function(j){
						if(json.result[0].categories[i].listOfAssetParamDefs[j].assetParamName == gloablParamName){

							
							multiSelectFlag = json.result[0].categories[i].listOfAssetParamDefs[j].multiSelectFlag;
							hasArrayFlag = json.result[0].categories[i].listOfAssetParamDefs[j].hasArrayFlag;
							mappingFlag = json.result[0].categories[i].listOfAssetParamDefs[j].mappingFlag;
							
							
							//aditya added 07.03.18
							if(hasArrayFlag == true){
								//console.log("hasArrayFlag last - 1 :: "+hasArrayFlag);
								$(".edit_isArrayParam").addClass("disabled");//.attr("disabled", true);
							}else{
								//console.log("hasArrayFlag last -2 :: "+hasArrayFlag);
								$(".edit_isArrayParam").removeClass("disabled");//.attr("disabled", false);
							}
							//harish
							if(multiSelectFlag == false){
								$(".edit_singleMultipleParam").addClass("disabled");//.attr("disabled", true);
							}else{
								$(".edit_singleMultipleParam").removeClass("disabled");//.attr("disabled", false);
							}
							
							// Hema 19.Mar.2019 
							if(mappingFlag == true){
								$(".edit_dd_ldapMappedListOfNames").addClass("disabled");//.attr("disabled", true);
										if($(".edit_dd_ldapMappedListOfNames").hasClass("disabled")){
											$('#edit_dd_LdapMappedList').parent().attr('tabindex', '-1');
											$('#edit_ddsingleMultipleType').parent().attr('tabindex', '-1');
										}
							}else{
								$(".edit_dd_ldapMappedListOfNames").removeClass("disabled");//.attr("disabled", false);
							}
							
						}
					});

				});


			}
		}
	
	
		
	
	
	//$(".edit_importantParam").show();//Aditya added 21.05.18
}

// Edit Paramaeter Modal - param type dropdown change
var edit_ddParamType = "";
function edit_showParamTypes(value){
	//console.log(paramTypeVal+" ::: text val :: "+hasDisabledVal);
	$('.paramErr').hide();
	$('.paramRemoveErr').parent().parent().removeClass("error");
	$('.paramRemoveErr').parent().removeClass("error");
	$('.paramRemoveErr').removeClass("error");
	//$('#edit_hasStaticValueYes').prop('checked',true);
	$('.edit_hasStaticViewParam').removeClass("disabled");
	$("#edit_hasStaticValueYes").attr("disabled", false); 
	$('.edit_emailSchedulerYes').removeClass("disabled");
	$("#edit_emailSchedulerYes").attr("disabled", false);
	$("label[for='edit_email_lbl']").removeClass('changeLableColor');
	edit_ddParamType = value;
	$("label[for='edit_is_static_val']").removeClass('changeLableColor');//05.04.18 Aditya
	$('.ui.checkbox > input[type="checkbox"]#edit_isArrayCheckbox').attr("checked",false);
	
	/*if (!!navigator.userAgent.match(/Trident\/7\./)){//aditya 29.03.18
			$("#editParamModalIcon").removeClass("semanticModalCloseIConForIEafterAdd");
			$("#editParamModalIcon").addClass("semanticModalCloseIConForIE");
	}*/
	/*$('#edit_importantYes').prop("disabled", false);
	$('#edit_isArrayCheckbox').prop("disabled", false);*/
	
	$('.edit_ldapMappingAttributes').hide();
	
	// date = 2
	if(edit_ddParamType == 2){
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam, .edit_manadatoryParam').show();
		$('.edit_listTypeParam, .edit_customListItemParam, .edit_derivedAttrParam, .edit_derivedComputationParam, .edit_mappedAssetParam, .edit_sizeParam, .edit_isArrayParam, .edit_singleMultipleParam, .edit_derivedAttrForAssetListParam, .edit_dd_ldapMappedListOfNames').hide(); //harish
		$(".edit_emailSchedulerYes ").show(); //Swathi- Email Scheduler
	}
	// list = 4
	else if(edit_ddParamType == 4){
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam, .edit_listTypeParam, .edit_manadatoryParam, .edit_singleMultipleParam').show(); //harish
		$('.edit_sizeParam, .edit_mappedAssetParam, .edit_derivedAttrParam, .edit_derivedComputationParam, .edit_isArrayParam, .edit_derivedAttrForAssetListParam, .edit_dd_ldapMappedListOfNames').hide();
		
		// Hema 06.Jul.2018 - removed single multiple dropdown disabled issue - Discussed with Harish.
		$(".edit_singleMultipleParam").removeClass("disabled");
		$('#edit_ddsingleMultipleType').dropdown('set selected','Single Select List');
		
		$(".edit_emailSchedulerYes ").show(); //Swathi- Email Scheduler
		
		var listType_dd = $('#edit_listType :selected').val();
		if(listType_dd == 1){
			$('.edit_customListItemParam').show();
		}
		else if(listType_dd == 2){
			$('.edit_mappedAssetParam').show();
		}
		
	}
	// text = 1
	else if(edit_ddParamType == 1){
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam, .edit_sizeParam, .edit_manadatoryParam, .edit_isArrayParam').show();
		$('.edit_derivedAttrParam, .edit_listTypeParam, .edit_mappedAssetParam, .edit_derivedComputationParam, .edit_customListItemParam, .edit_listTypeParam, .edit_singleMultipleParam, .edit_derivedAttrForAssetListParam, .edit_dd_ldapMappedListOfNames').hide();// harish
		$(".edit_emailSchedulerYes ").show(); //Swathi- Email Scheduler
	}
	
	//rich text
	else if(edit_ddParamType == 7){
		$('.edit_defaultViewParam, .edit_importantParam, .edit_manadatoryParam, .edit_isArrayParam,.edit_hasStaticViewParam').show();
		$('.edit_derivedComputationParam, .edit_mappedAssetParam, .edit_derivedAttrParam, .edit_sizeParam, .edit_listTypeParam, .edit_customListItemParam, .edit_singleMultipleParam, .edit_derivedAttrForAssetListParam, .edit_dd_ldapMappedListOfNames').hide(); //harish
		$('#edit_hasStaticValueYes').prop('checked',false);
		$('.edit_hasStaticViewParam').addClass("disabled");
		$("#edit_hasStaticValueYes").attr("disabled", true);
		$("label[for='edit_is_static_val']").addClass('changeLableColor');//05.04.18 Aditya
		$(".edit_emailSchedulerYes ").show(); //Swathi- Email Scheduler
	}
	
	// file = 3
	else if(edit_ddParamType == 3){
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam, .edit_manadatoryParam').show();
		$('.edit_derivedComputationParam, .edit_mappedAssetParam, .edit_derivedAttrParam, .edit_sizeParam, .edit_listTypeParam, .edit_customListItemParam, .edit_isArrayParam, .edit_singleMultipleParam, .edit_derivedAttrForAssetListParam, .edit_dd_ldapMappedListOfNames').hide(); //harish
		$(".edit_emailSchedulerYes").hide(); //Swathi- Email Scheduler
		$("#edit_emailSchedulerYes").prop("checked", false);
		
	}
	// derived attribute = 5
	else if(edit_ddParamType == 5){
		$('.edit_defaultViewParam, .edit_derivedAttrParam').show();
		$(".edit_emailSchedulerYes ").show(); //Swathi- Email Scheduler
		$('.edit_hasStaticViewParam, .edit_importantParam, .edit_listTypeParam, .edit_customListItemParam, .edit_derivedComputationParam, .edit_mappedAssetParam, .edit_sizeParam, .edit_manadatoryParam, .edit_isArrayParam, .edit_singleMultipleParam, .edit_derivedAttrForAssetListParam, .edit_dd_ldapMappedListOfNames').hide(); //harish
		$('.derivedAttrPopup').popup({
	        inline: true,
	      });
	}
	// derived computation = 6 
	else if(edit_ddParamType == 6){
		$('.edit_defaultViewParam, .edit_derivedComputationParam').show();
		$(".edit_emailSchedulerYes ").show(); //Swathi- Email Scheduler
		$('.edit_hasStaticViewParam, .edit_importantParam, .edit_sizeParam, .edit_listTypeParam, .edit_customListItemParam, .edit_derivedAttrParam, .edit_mappedAssetParam, .edit_manadatoryParam, .edit_isArrayParam, .edit_singleMultipleParam, .edit_derivedAttrForAssetListParam, .edit_dd_ldapMappedListOfNames').hide(); //harish
		$('.derivedCompPopup').popup({
	        inline: true,
	      });
	}
	//BOC ----- derived attribute for asset list = 8 - Hema - 27.Feb.2019
	else if(edit_ddParamType == 8){
		$(".emailScheduler").show(); //Swathi- Email Scheduler
		$('.edit_defaultViewParam, .edit_derivedAttrForAssetListParam').show();
		$('.edit_hasStaticViewParam, .edit_importantParam, .edit_sizeParam, .edit_listTypeParam, .edit_customListItemParam, .edit_derivedAttrParam, .edit_mappedAssetParam, .edit_manadatoryParam, .edit_isArrayParam, .edit_singleMultipleParam, .edit_derivedComputationParam, .edit_dd_ldapMappedListOfNames').hide(); //harish
		$('.derivedAttrForAssetPopup').popup({
	        inline: true,
	      });
	}
	
	else if(edit_ddParamType == 9){
		$('.edit_defaultViewParam, .edit_importantParam, .edit_manadatoryParam, .edit_singleMultipleParam, .edit_dd_ldapMappedListOfNames').show(); //harish
		$('.edit_sizeParam, .edit_mappedAssetParam, .edit_derivedAttrParam, .edit_derivedComputationParam, .edit_isArrayParam, .edit_derivedAttrForAssetListParam, .edit_listTypeParam, .edit_customListItemParam').hide();
		$(".edit_emailSchedulerYes ").show(); //Swathi- Email Scheduler
		
		$('#edit_hasStaticValueYes').prop('checked',false);
		$('.edit_hasStaticViewParam').addClass("disabled");
		$("#edit_hasStaticValueYes").attr("disabled", true);
		$("label[for='edit_is_static_val']").addClass('changeLableColor');
		$('#edit_importantYes').prop("disabled", false);
		$("label[for='edit_imprtnt_lbl']").removeClass("changeLableColor");
		
		$(".edit_singleMultipleParam").removeClass("disabled");
		$('#edit_ddsingleMultipleType').dropdown('set selected','Single Select List');
		
		
		$('.edit_dd_ldapMappedListOfNames').removeClass('disabled');
		
		var selectedMappingId = $('#edit_dd_LdapMappedList').val();
		if(selectedMappingId != ""){
			loadLdapAttributes(selectedMappingId);
		}
		
	}
	
	// EOC
	
	// added by aditya to hide the important field 06.03.18
	//console.log("edit_hasStaticValueYes   checked :: "+($("#edit_hasStaticValueYes").is(":checked")));
	if($("#edit_hasStaticValueYes").is(":checked")){
		//$(".edit_importantParam").hide();
		$('#edit_importantYes').prop("disabled", true);//22.03.18
		$("label[for='edit_imprtnt_lbl']").addClass("changeLableColor");//Aditya added 24.05.18
		//console.log("it's checked");
	}
	//console.log(paramTypeVal +" :: paramTypeVal == edit_ddParamType :: "+ edit_ddParamType);
	//console.log(paramTypeVal+" :: paramTypeVal == edit_ddParamType :: "+edit_ddParamType+" :: hasDisabledVal :: "+hasDisabledVal)
	//if((paramTypeVal == edit_ddParamType) && (hasDisabledVal == "true")){//edit_isArrayParam //disabled
	if((paramTypeVal == edit_ddParamType)){	
		/*if((hasDisabledVal == "true") || ($('div.toggleCheckBoxColor.ui.toggle.checkbox > input[type="checkbox"]#edit_hasStaticValueYes').is(":checked"))){
			$('#edit_isArrayCheckbox').prop("disabled", true);
			$(".edit_isArrayParam").addClass("disabled");
			console.log("adding");
		}else{
			console.log("removing");
			$('#edit_isArrayCheckbox').prop("disabled", false);
			$(".edit_isArrayParam").removeClass("disabled");
		}*/
		var json = enableOrDisableSingleMultiSelectListAndIsArrayJSON;
		
		if (editAsset == "editAsset") {
			$.each(json.result[0].categories, function(i) {
				//gloablParamName
				
				$.each(json.result[0].categories[i].listOfAssetParamDefs, function(j){
					if(json.result[0].categories[i].listOfAssetParamDefs[j].assetParamName == gloablParamName){
						
						multiSelectFlag = json.result[0].categories[i].listOfAssetParamDefs[j].multiSelectFlag;
						//harish
						if(multiSelectFlag == false){
							$(".edit_singleMultipleParam").addClass("disabled");//.attr("disabled", true);
						}else{
							$(".edit_singleMultipleParam").removeClass("disabled");//.attr("disabled", false);
						}
					}
				});
				
			});
		}
		

		if(singlemultiType == 0){
			$('#edit_ddsingleMultipleType').dropdown('set selected','Single Select List');
		} 
		else if(singlemultiType == 1){
			$('#edit_ddsingleMultipleType').dropdown('set selected','Multiple Select List');
		}
		if(hasStaticValueFlag == "1" || hasStaticValueFlag == "true"){
			$('.toggleCheckBoxColor.ui.toggle.checkbox > input[type="checkbox"]#edit_hasStaticValueYes').attr("checked",true);
			
			$('#edit_isArrayCheckbox').prop("disabled", true);
			$(".edit_isArrayParam").addClass("disabled");
			$("#edit_importantYes").prop("disabled", true);
			$("label[for='edit_imprtnt_lbl']").addClass('changeLableColor');
			$('.toggleCheckBoxColor.ui.toggle.checkbox > input[type="checkbox"]#edit_importantYes').attr("checked",false);
		}else{
			//console.log("removing");
			$('#edit_isArrayCheckbox').prop("disabled", false);
			$(".edit_isArrayParam").removeClass("disabled");
			$("#edit_importantYes").prop("disabled", false);
			$("label[for='edit_imprtnt_lbl']").removeClass('changeLableColor');
		}
	//console.log("adding");
		
		
		if(isArrayData == "1"){
			$('.ui.checkbox > input[type="checkbox"]#edit_isArrayCheckbox').attr("checked",true);
		}else{
			$('.ui.checkbox > input[type="checkbox"]#edit_isArrayCheckbox').attr("checked",false);
		}
		
		//console.log("adding --- 1");
			
	}else{
		//console.log("removing-2");
		//$("label[for='edit_imprtnt_lbl']").removeClass('changeLableColor');
		
		//if condition written by aditya 24.05.18
		if(edit_ddParamType == "7"){
			$("label[for='edit_imprtnt_lbl']").removeClass('changeLableColor');
			$("#edit_importantYes").prop("disabled", false);
		}
		$('#edit_isArrayCheckbox').prop("disabled", false);
		$(".edit_isArrayParam").removeClass("disabled");
		//$("#edit_importantYes").prop("disabled", false); // commented by aditya 24.05.18, logic:- if it Has Static Value is checked then it should be disabled. 
		$('.toggleCheckBoxColor.ui.toggle.checkbox > input[type="checkbox"]#edit_importantYes').attr("checked",false);
	//	console.log("removing --- 1");
	}
}

//Edit Paramaeter Modal - list type dropdown change
var edit_globalListType = "";
function edit_ddListType(val){
	$('.paramErr').hide();
	$('.paramRemoveErr').parent().parent().removeClass("error");
	$('.paramRemoveErr').parent().removeClass("error");
	$('.paramRemoveErr').removeClass("error");
	
	if(val == 1){
		$('.edit_customListItemParam').show();
		$('.edit_mappedAssetParam').hide();
	}
	else if(val == 3){
		$('.edit_defaultViewParam, .edit_hasStaticViewParam, .edit_importantParam').show();
		$('.edit_customListItemParam, .edit_mappedAssetParam').hide();
	}
	else if(val == 2){
		$('.edit_mappedAssetParam').show();
		$('.edit_derivedAttrParam, .edit_derivedComputationParam, .edit_customListItemParam').hide();
	}
	else if(val == 4){
		$('.edit_customListItemParam, .edit_mappedAssetParam').hide();
	}
}


// add asset - open taxonomy modal
var addedTaxonomyArr = [];
var add_chckExistingTaxNameFlag = true;
var add_taxTreeFlag = true;
var add_temporaryStorageArray = [];

function openAssignTaxonomyModal(){
	add_temporaryStorageArray = [];
	$("#btnSubmitAssignTaxonomy").unbind();
	$("#btnCancelAssignTaxonomy").unbind();
	$("#editAssignTaxonomyModal").hide();
	$('#addAssignTaxonomyModal').modal('setting', 'closable', false).modal('show');
	$('#add_form_assignTaxonomy').form('clear');
	//$('#addNewTaxonomySegment').hide();
	//addedTaxonomyArr.length = 0;
	
	/*if(taxIdsArr.length != 0){
		$('#addNewTaxonomySegment').show();
	}
	else {
		$('#addNewTaxonomySegment').hide();
	}*/
	

	//if(edit_taxTreeFlag){
	//edit_taxTreeFlag = false;
	$('#tree1').tree("destroy");
	jQuery.ajax({
		type : "GET",
		url : "/repopro/web/taxonomy/getTaxonomy",
		dataType : "json",
		contentType : 'application/json',
		async : false,
		complete : function(data) {
			json = JSON.parse(data.responseText);
			if(json.result == "" || json.result == null){
				//$('.addResourcePanel').hide();
				$('#noTaxAdded').html('<div class="ui message" style="text-align:center;">No taxonomies added yet</div>');
				$('#btnSubmitAssignTaxonomy').attr('disabled',true);
				$('#addNewTaxonomySegment, #Catroot').hide();
			}
			else {
				$('#noTaxAdded').css('display','none');
				$('#btnSubmitAssignTaxonomy').attr('disabled',false);
				$('#addNewTaxonomySegment, #Catroot').show();
				$('#Catroot').css('display','block');
				$('#loadingDivTree').hide();
				$('#tree1').show();
				$('#tree1').tree({
					data : json.result,
					autoOpen : false
				});
			}

			jQuery('.jqtree-title').each(function(e){
				
				 var item = jQuery(this);
				  item.css('display','inline-block');
				  var valTax = jQuery(this).text();
				  var valTax1 = valTax.split("|");
				  var val = valTax1[0];
				  var val1 = valTax1[1];
				  
				  jQuery(this).text(val);
				  item.parent().append("<span id="+val1+" class='someCls'></span>");
				  jQuery(this).addClass('treeViewElement');
				  editAddTax = 0;
				  $('#addNewTaxonomySegment').html('');
				  $('#addNewTaxonomySegment').append("");
				  jQuery(this).unbind('click');
				

				// show taxonomies that are already assigned and saved in database
				 addedTaxonomyArr = $.unique(addedTaxonomyArr);
				 

				 if(addedTaxonomyArr.length == 0){
					$('#addNewTaxonomySegment').hide();
					$('#noTaxAdded').show();
					$('#btnSubmitAssignTaxonomy').attr('disabled',true);
				}else {
					$('#noTaxAdded').hide();
					$('#addNewTaxonomySegment').show();
					$('#btnSubmitAssignTaxonomy').attr('disabled',false);
					
					for (var i = 0; i < addedTaxonomyArr .length; i++) {	
						$('#addNewTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+addedTaxonomyArr[i].taxId+'_'+addedTaxonomyArr[i].taxName.replace(/ /g,"_")+'" id="taxonomyName_'+addedTaxonomyArr[i].taxId+'_'+addedTaxonomyArr[i].taxName+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+addedTaxonomyArr[i].taxName+'<i class="delete icon" onclick="deleteTaxonomy('+addedTaxonomyArr[i].taxId+',\''+addedTaxonomyArr[i].taxName+'\',\''+editAddTax+'\')"></i></a>');
					}
				}
				// check left side taxonomies with right side assigned taxonomies (onclick)
				
				 add_temporaryStorageArray.splice.apply(add_temporaryStorageArray, [2, 0].concat(addedTaxonomyArr));
				 add_temporaryStorageArray = $.unique(add_temporaryStorageArray);

				jQuery(this).on("click",function(){
					var loop_complete_flag = false;
					//console.log(val1+" :: clicked here add_temporaryStorageArray   :: "+JSON.stringify(add_temporaryStorageArray));
					$('#noTaxAdded').hide();
					$('#addNewTaxonomySegment').show();
					$('#btnSubmitAssignTaxonomy').attr('disabled',false);
					
					for (var j = 0; j < add_temporaryStorageArray.length; j++) {
						
						if(add_temporaryStorageArray[j].taxId == val1){
							chckExistingTaxNameFlag = true;
							//break;
						}
						
						if(j == (add_temporaryStorageArray.length - 1)){
							//console.log("Loop completed : "+j);
							loop_complete_flag = true;
						}
					}
					
					if(add_temporaryStorageArray.length > 0){
						if(chckExistingTaxNameFlag == false && loop_complete_flag == true){
							add_temporaryStorageArray.push({"taxId" : val1, "taxName" : val});
							add_temporaryStorageArray = $.unique(add_temporaryStorageArray);
							$('#addNewTaxonomySegment').append("");
							$('#addNewTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\',\''+editAddTax+'\')"></i></a>');
						}
						else {
							notifyMessage("Add Asset","The taxonomy " + val +" is already added","fail");
							chckExistingTaxNameFlag = false;
						}
					}else{
						add_temporaryStorageArray.push({"taxId" : val1, "taxName" : val});
						add_temporaryStorageArray = $.unique(add_temporaryStorageArray);
						$('#addNewTaxonomySegment').append("");
						$('#addNewTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\',\''+editAddTax+'\')"></i></a>');					
					}
					
					
				});

				jQuery(this).css('pointer','cursor');

			});
		}
	});
	
}

//delete taxonomy
function deleteTaxonomy(id,val,editAddTax){
	if(editAddTax == 1){
		jQuery.ajax({
			type : "GET",
			url : "/repopro/web/assetInstanceVersionManager/queryAIVDetailsForassociatedTaxonomyAction?assetName="+editAssetName+"&taxId="+id,
			dataType : "json",
			contentType : 'application/json',
			async : false,
			complete : function(data) {
			json = JSON.parse(data.responseText);
			if(json.result == 'true'){
				notifyMessage("Edit Asset","This taxonomy cannot be deleted as it is mapped to an instance","fail");
			}
			else {
				chckExistingTaxNameFlag = false;
				$(".taxonomyNameClass_"+id+"_"+val.replace(/ /g,"_")).remove();
				/*associateTaxNameArr.splice( $.inArray(val,associateTaxNameArr) ,1 );*/
				//editTaxIdsArr.splice( $.inArray(val,editTaxIdsArr) ,1 );
				
				/*pushAllTaxonomies.splice($.inArray(id, pushAllTaxonomies),1);*/
				
				/*var index;
				for(var j=0; j<pushAllTaxonomies.length; j++){
					if(pushAllTaxonomies[j].taxId == id){
						index = j;							
						break;
					}									
				}
				pushAllTaxonomies.splice(index, 1);*/
				
				edit_temporaryStorageArray.splice( $.inArray(val,edit_temporaryStorageArray) ,1 );
				//console.log("3  :add:  " +JSON.stringify(add_temporaryStorageArray));  //add_temporaryStorageArray
				
				var index1, loop_brk = false;
				for(var j=0; j<edit_temporaryStorageArray.length; j++){
					if(edit_temporaryStorageArray[j].taxId == id){
						index1 = j;
						loop_brk = true;
						break;
					}									
				}
				
				if(loop_brk == true){
					edit_temporaryStorageArray.splice(index1, 1);
				}
				
				
				if ($('#editNewTaxonomySegment').children('a').length == 0) {
					$('#editNewTaxonomySegment').hide();
					$('#edit_NoTaxonomies').show();
					//$('#btnEditSubmitAssignTaxonomy').attr('disabled',true);
				}
				else {
					$('#editNewTaxonomySegment').show();
					$('#edit_NoTaxonomies').hide();
					//$('#btnEditSubmitAssignTaxonomy').attr('disabled',false);
				}
			}
			}
		});
		
		
	}
	else if(editAddTax == 0){
		add_chckExistingTaxNameFlag = true;
		$(".taxonomyNameClass_"+id+"_"+val.replace(/ /g,"_")).remove();
		//addedTaxonomyArr.splice( $.inArray(val,addedTaxonomyArr) ,1 );
		
		//add_temporaryStorageArray.splice( $.inArray(val,add_temporaryStorageArray) ,1 );
		
		//console.log("1  :addedTaxonomyArr:  " +JSON.stringify(addedTaxonomyArr));  //add_temporaryStorageArray
		
		
		
		
		
		
		/*var index;
		for(var j=0; j<addedTaxonomyArr.length; j++){
			if(addedTaxonomyArr[j].taxId == id){
				index = j;							
				break;
			}									
		}
		console.log("index val :: "+index);
		addedTaxonomyArr.splice(index, 1);
		
		console.log("2 :addedTaxonomyArr:  " +JSON.stringify(addedTaxonomyArr));
		*/
		
		
		
		add_temporaryStorageArray.splice( $.inArray(val,add_temporaryStorageArray) ,1 );
		//console.log("3  :add:  " +JSON.stringify(add_temporaryStorageArray));  //add_temporaryStorageArray
		
		var index1, loop_brk = false;
		for(var j=0; j<add_temporaryStorageArray.length; j++){
			if(add_temporaryStorageArray[j].taxId == id){
				index1 = j;
				loop_brk = true;
				break;
			}									
		}
		
		if(loop_brk == true){
			add_temporaryStorageArray.splice(index1, 1);
		}
		
		
		//console.log("4 :add:  " +JSON.stringify(add_temporaryStorageArray));
		
		
		//addedTaxonomyArr.splice( $.inArray(val,addedTaxonomyArr) ,1 );
		
		if ($('#addNewTaxonomySegment').children('a').length == 0) {
			$('#addNewTaxonomySegment').hide();
			$('#add_NoTaxonomies').show();
			//$('#btnSubmitAssignTaxonomy').attr('disabled',true);
		}
		else {
			$('#addNewTaxonomySegment').show();
			$('#add_NoTaxonomies').hide();
			//$('#btnSubmitAssignTaxonomy').attr('disabled',false);
		}
		
	}
	
}

// add asset - save taxonomy
var taxIdsArr = [];
function submitTaxonomyData(){
	//<!-- CHANDANA 04-06-2019 KEYBOARD CONTROLS -->
	if($('#btnSubmitAssignTaxonomy').hasClass('disabled')){
		$("#btnSubmitAssignTaxonomy").blur(); 
		return false;
	}
	taxIdsArr.length = 0;
	var TaxId = "";
	var TaxName = "";
	addedTaxonomyArr.length = 0;
	$('.assignTax a').each(function(i){
		var taxData = $(this).attr('id');
		taxData = taxData.split('_');
		TaxId = taxData[1];
		TaxName = taxData[2];
		
		//addedTaxonomyArr.push(taxData[2]);
		addedTaxonomyArr.push({"taxId" : taxData[1], "taxName": taxData[2]});
		addedTaxonomyArr = $.unique(addedTaxonomyArr);
		//taxIdsArr.push({TaxId : TaxName});
		
		var keyValuePair = {};
		keyValuePair[TaxId]=TaxName; // set your dynamic values
		taxIdsArr.push(keyValuePair);
		
		
	});
	//console.log("submit addedTaxonomyArr ::: "+JSON.stringify(addedTaxonomyArr));
	
	$('#addAssignTaxonomyModal').modal('hide'); //.modal('hide dimmer');
	$('#addAssignTaxonomyModal').parent().css("display", "none !important");
}

var ddParamType = "";
function showParamTypes(value){
	
	//$("#addParaCloseIcon").removeClass("semanticModalCloseIConForIEafterAdd");
	//$("#addParaCloseIcon").addClass("semanticModalCloseIConForIE");
	$('.paramErr').hide();
	$('.paramRemoveErr').parent().parent().removeClass("error");
	$('.paramRemoveErr').parent().removeClass("error");
	$('.paramRemoveErr').removeClass("error");
	$('.hasStaticViewParam').removeClass("disabled");
	$("#hasStaticValueYes").attr("disabled", false);
	$('.isArrayParam').hide();
	
	$('#importantYes').prop("disabled", false);
	$('#isArrayCheckbox').prop("disabled", false);
	
	$('#emailSchedulerYes').prop("disabled", false);// Swathi- email scheduler
	
	$('#isArrayCheckbox').attr('checked', false);//05.04.18: aditya
	$("label[for='is_imprtnt']").removeClass('changeLableColor');//05.04.18: aditya
	$("label[for='is_static_val']").removeClass('changeLableColor');//05.04.18
	
	$('.ldapMappingAttributes').hide();
	
	if($("#hasStaticValueYes").is(":checked")){
		//$('.importantParam').hide();
		//$('#importantYes').prop("disabled", true);
		$('#importantYes').prop("disabled", true);//22.03.18
		
		
		//console.log("it's checked");
	}
	
		ddParamType = value;
		// date = 2
		if(value == 2){
			$('.defaultViewParam, .hasStaticViewParam, .importantParam').show();
			$('.listTypeParam, .customListItemParam, .derivedAttrParam, .derivedComputationParam, .mappedAssetParam, .sizeParam, .singleMultipleParam, .derivedAttrForAssetListParam, .dd_ldapMappedListOfNames').hide(); //harish
			$("#mandatoryYesField").show();
			$(".emailScheduler").show(); //Swathi- Email Scheduler
		}
		// list = 4
		else if(value == 4){
			$('.defaultViewParam, .hasStaticViewParam, .importantParam, .listTypeParam, .singleMultipleParam').show(); //harish
			$('.sizeParam, .mappedAssetParam, .derivedAttrParam, .derivedComputationParam, .derivedAttrForAssetListParam, .dd_ldapMappedListOfNames').hide();
			$("#mandatoryYesField").show();
			$(".emailScheduler").show(); //Swathi- Email Scheduler
			var listType_dd = $('#listType :selected').val();
			if(listType_dd == 1){
				$('.customListItemParam').show();
			}
			else if(listType_dd == 2){
				$('.mappedAssetParam').show();
			}
			
		}
		// text = 1
		else if(value == 1){
			$('.defaultViewParam, .hasStaticViewParam, .importantParam, .sizeParam').show();
			$('.derivedAttrParam, .listTypeParam, .mappedAssetParam, .derivedComputationParam, .customListItemParam, .listTypeParam, .singleMultipleParam, .derivedAttrForAssetListParam, .dd_ldapMappedListOfNames').hide(); //harish
			$("#mandatoryYesField").show();
			$(".emailScheduler").show(); //Swathi- Email Scheduler
			if ($('#hasStaticValueYes').is(':checked')) {
				$('.isArrayParam').show();
				$('#isArrayCheckbox').prop("disabled", true);
			}else {
				$('.isArrayParam').show();	
				$('#isArrayCheckbox').prop("disabled", false);
			}
		}
		// file = 3
		else if(value == 3){
			$('.defaultViewParam, .hasStaticViewParam, .importantParam').show();
			$('.derivedComputationParam, .mappedAssetParam, .derivedAttrParam, .sizeParam, .listTypeParam, .customListItemParam, .singleMultipleParam, .derivedAttrForAssetListParam, .dd_ldapMappedListOfNames').hide(); //harish
			$("#mandatoryYesField").show();
			$(".emailScheduler").hide(); //Swathi- Email Scheduler
			$('#emailSchedulerYes').prop('checked',false);//Swathi- Email Scheduler
			
		}
		// derived attribute = 5
		else if(value == 5){
			
			$('.defaultViewParam, .derivedAttrParam').show();
			$('.hasStaticViewParam, .importantParam, .sizeParam, .listTypeParam, .customListItemParam, .derivedComputationParam, .mappedAssetParam, .singleMultipleParam, .derivedAttrForAssetListParam, .dd_ldapMappedListOfNames').hide(); //harish
			$('.derivedAttrPopup').popup({
		        inline: true,
		      });
			$("#mandatoryYesField").hide();
			$(".emailScheduler").show(); //Swathi- Email Scheduler
		}
		// derived computation = 6
		else if(value == 6){
			
			$('.defaultViewParam, .derivedComputationParam').show();
			$('.hasStaticViewParam, .importantParam, .sizeParam, .listTypeParam, .customListItemParam, .derivedAttrParam, .mappedAssetParam, .singleMultipleParam, .derivedAttrForAssetListParam, .dd_ldapMappedListOfNames').hide(); //harish
			$('.derivedCompPopup').popup({
		        inline: true,
		      });
			$("#mandatoryYesField").hide();
			$(".emailScheduler").show(); //Swathi- Email Scheduler
		}
		
		// rich text = 7
		else if(value == 7){
			$('.defaultViewParam, .importantParam,.hasStaticViewParam,.isArrayParam, #mandatoryYesField').show();
			$('#hasStaticValueYes').prop('checked',false);
			$('.hasStaticViewParam').addClass("disabled");
			$("#hasStaticValueYes").attr("disabled", true);
			$('.sizeParam, .listTypeParam, .customListItemParam, .mappedAssetParam, .derivedAttrParam, .derivedComputationParam, .singleMultipleParam, .derivedAttrForAssetListParam, .dd_ldapMappedListOfNames').hide(); //harish
			
			$("label[for='is_static_val']").addClass('changeLableColor');//05.04.18 Aditya
			$(".emailScheduler").show(); //Swathi- Email Scheduler
		}
		
		// derived attribute for asset list = 8
		else if(value == 8){
			$('.defaultViewParam, .derivedAttrForAssetListParam').show();
			$('.hasStaticViewParam, .importantParam, .sizeParam, .listTypeParam, .customListItemParam, .derivedComputationParam, .mappedAssetParam, .singleMultipleParam, .derivedAttrParam, .dd_ldapMappedListOfNames').hide();
			$("#mandatoryYesField").hide();
			$('.derivedAttrForAssetPopup').popup({
		        inline: true,
		      });
			$(".emailScheduler").show(); //Swathi- Email Scheduler
		}
		
		// ldap mapping
		else if(value == 9){
			$('.defaultViewParam, .hasStaticViewParam, .importantParam, .singleMultipleParam, .dd_ldapMappedListOfNames').show();
			$('.sizeParam, .mappedAssetParam, .derivedAttrParam, .derivedComputationParam, .derivedAttrForAssetListParam, .listTypeParam, .customListItemParam').hide();
			$("#mandatoryYesField").show();
			$('.hasStaticViewParam').addClass("disabled");
			$("#hasStaticValueYes").attr("disabled", true);
			$("label[for='is_static_val']").addClass('changeLableColor');
			$("label[for='is_imprtnt']").removeClass("changeLableColor");
			$('#importantYes').prop("disabled", false);
			
			$(".emailScheduler").show(); //Swathi- Email Scheduler
			
			var selectedMappingId = $('#dd_LdapMappedList').val();
			if(selectedMappingId != ""){
				loadLdapAttributes(selectedMappingId);
			}
			
			
			
		}
		
		// added by aditya to hide the important field 06.03.18
		//console.log("checked :: "+($("#hasStaticValueYes").is(":checked")));
		
	}

var add_globalListType = "";
function ddListType(val){
		$('.paramErr').hide();
		$('.paramRemoveErr').parent().parent().removeClass("error");
		$('.paramRemoveErr').parent().removeClass("error");
		$('.paramRemoveErr').removeClass("error");
		add_globalListType = val;
		if(val == 1){
			$('#custListItems').val('');
			$('.customListItemParam').show();
			$('.mappedAssetParam').hide();
		}
		else if(val == 3){
			$('.defaultViewParam, .hasStaticViewParam, .importantParam').show();
			$('.customListItemParam, .mappedAssetParam').hide();
		}
		else if(val == 2){
			$('.mappedAssetParam').show();
			$('.derivedAttrParam, .derivedComputationParam, .customListItemParam').hide();
		}
		else if(val == 4){
			$('.customListItemParam, .mappedAssetParam').hide();
		}
}

	
// Group Details Modal
	appendData = "";
	var groupAccessForAsset = [];
	var editGroupAccessForAsset = [];
	var saveLocalGroupAccessForAsset = [];
	var saveLocalAddGroupAccessForAsset = [];
	function openDefaultAccessInstanceModal(){
		$('#btnEditDefaultAccessSubmit').unbind();  //add submit button id
        $('#btnDefaultAccessSubmit').unbind();
        $('#groupDetailsModal').modal({observeChanges : true, closable : false}).modal('refresh').modal('show');
        
       /* $("#btnDefaultAccessCancel").unbind();*/
        //$('#groupDetailsModal').modal('setting', 'closable', false).modal('show');
        loadDefaultAccessForNewlyCreatedInstance();
	}
	
// default access data
	function getDefaultAccess(groupId,groupName){
		appendData = "";
		
		if(groupName == "group-admin" || groupName == "Guest"){
			appendData += '<tr id="trGroupId'+groupId+'" class="hidden">';
		}
		else {
			appendData += '<tr id="trGroupId'+groupId+'">';
		}
		
		appendData += '<td class="hidden" id="GroupId_'+ groupId +'">' + groupId + '</td>';
		appendData += '<td id="groupName_'+groupId+'">' + groupName + '</td>';
		appendData += '<td class="center aligned"><div class="ui checkbox"><input type="checkbox" id="addAccess_'+groupId+'" class="addAccessCheckbox" checked><label></label></div></td>';
		appendData += '<td class="center aligned disabled cssForDisablingData"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;"><input type="checkbox" id="hideOrShow_'+groupId+'" class="hideOrShowCheckbox" checked disabled><label></label></div></td>';
		appendData += '<td class="center aligned disabled cssForDisablingData"><span id="addModalreadOnlyEdit_'+groupId+'" style="display: block;"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;">';
		appendData += '<input type="checkbox" id="editAccess_'+groupId+'" class="editAccessCheckbox" checked disabled><label></label></div>';
		appendData += '</span><span style="display:none;" id="addModalreadOnlyEdit_NotApplicable_'+groupId+'">N/A</span></td>';
		/*if(loggedInUserName == "admin"){
			
		appendData += '<td class="center aligned disabled cssForDisablingData"><div class="ui checkbox"  id="addModalDeleteAcces_'+groupId+'"><input type="checkbox" id="deleteAccess_'+groupId+'" class="deleteAccessCheckbox" checked disabled>';
		appendData += '<label></label></div><span style="display:none;" id="addModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';
		
		}else{*/
			appendData += '<td class="center aligned"><div class="ui checkbox"  id="addModalDeleteAcces_'+groupId+'"><input type="checkbox" id="deleteAccess_'+groupId+'" class="deleteAccessCheckbox">';
			appendData += '<label></label></div><span style="display:none;" id="addModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';
		/*}*/

		appendData += '</tr>';
		return appendData;
	}

//kavya -- get category and parameter data
var globalParamId = "";
function getNewAssetCategory(categoryId,categoryName,flagForCategoryRuleUsage,flagForCategoryUsageInAssetListRule,listOfAssetParamDefs){
	//console.log("listOfAssetParamDefs  : " + JSON.stringify(listOfAssetParamDefs));
	appendData = '';
	var deleteCategory = "1";
	var data = "<p>Are you sure you want to delete "+categoryName+" ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeCategoryPopup("+categoryId+")'>No</button><button class='right floated ui primary mini button' onclick='deleteAssetCategoryCard("+categoryId+","+deleteCategory+")'>Yes</button> ";
	if(categoryName != "DUMMY_CATEGORY"){
	appendData += '<div class="sixteen wide column categoryClass" id="assetCategoryCard_'+categoryId+'">';
	appendData += '<div class="ui card assetCategoryCardSize">';
	appendData += '<div class="content assetCategoryCardHeader">';
	appendData += '<i class="tags icon"></i>';
	appendData += '<label>';
	appendData += '<a id="assetCategoryCardHeaderLabel_'+categoryId+'"  data-index='+categoryId+' title="Click to Edit Category Name" onclick="editAssetCategoryName('+categoryId+')" class="assetCategoryEditableCardHeader editable">'+categoryName+'</a>';
	appendData += '<span id="assetCategoryCardHeaderEdit_'+categoryId+'" style="display: none !important;">';
	appendData += '<input id="assetCategoryCardHeaderEditInput_'+categoryId+'" value="'+categoryName+'" type="text" style="width: 30%; height: 2.3em;" maxlength="50" placeholder="Enter Category Name (Max 50 Chars)">';
	appendData += '<a title="Save" onclick="saveEditedAssetCategoryName('+categoryId+')"><i class="circular inverted small green checkmark icon" style="margin-left: 0.5em; margin-bottom: -1em;"></i></a>';
	appendData += '<a title="Cancle" onclick="cancelEditedAssetCategoryName('+categoryId+')"><i class="circular inverted small red remove icon" style="margin-left: 0.5em; margin-bottom: -1em;"></i></a>';
	appendData += '</span></label>';
	appendData += '<div class="right floated meta load">';
	appendData += '<button class="ui mini primary button" style="font-size: 9px !important; margin-right: 1em !important;" title="Add Parameter" id="addRemoveCategoryIcon_'+categoryId+'" onclick="openAddAssetParameterModal('+categoryId+'); return false">';
	appendData += 'Add Parameter</button>';
	if(flagForCategoryRuleUsage == true || flagForCategoryUsageInAssetListRule == true){
		appendData += '<a class="catParamDeleteIcon" title="Delete" ><i class="trash icon"></i></a>';	
	}
	else {
		appendData += '<a class="deleteAssetCategoryStyle"><i class="trash icon deleteEditIcon" id="catDeleteId_'+categoryId+'" data-html="'+data+'" onclick="openCategoryPopup('+categoryId+')"></i></a>';
	}
	appendData += '<a onclick="hideAssetCategoryCardContent('+categoryId+')"><i class="chevron down icon"></i></a>';
	appendData += '</div></div>';
	appendData += '<div class="content assetCategoryCardContent" id="assetCategoryCardContent_'+categoryId+'">';
	appendData += '<div class="droptrue" id="availableCategory_'+categoryId+'" style="min-height: 14em !important;"></div>';
	appendData += '</div></div></div>';
	}
	$("#assetCategoryGrid").append(appendData);

	var ddappendData = "";
	var addParamFlag = 'falseFlag';
	
	var paramloadlength;
	
	$.each(listOfAssetParamDefs, function(k) {
		var customListValuess = "";
		var derivedAttributeComputationValues = "";
		var derivedAttributeForAssetAutoComplete = "";
		arrParameters.push(listOfAssetParamDefs[k].assetParamName.toLowerCase());
		var data = "<p>Are you sure you want to delete "+listOfAssetParamDefs[k].assetParamName+" ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeParamPopup("+listOfAssetParamDefs[k].assetParamId+")'>No</button><button class='right floated ui primary mini button' onclick='paramDelete(this,"+listOfAssetParamDefs[k].assetParamId+","+categoryId+")'>Yes</button> ";
		ddappendData += '<div class="ui segment sortableSegmentCursor divParamValues paramCount" id="parameterId_'+listOfAssetParamDefs[k].assetParamId+'"><span class="assetParamName">'+listOfAssetParamDefs[k].assetParamName+'</span>';
		ddappendData += '<pre style="display:none;" class="paramDescription"><textarea>'+listOfAssetParamDefs[k].description+'</textarea></pre>';
		ddappendData += '<span style="display:none;" class="paramTypeDD">'+listOfAssetParamDefs[k].paramTypeId+'</span>';
		ddappendData += '<span style="display:none;" class="defaultViewChecked">'+listOfAssetParamDefs[k].defaultView+'</span>';
		ddappendData += '<span style="display:none;" class="hasStaticValueYes">'+listOfAssetParamDefs[k].is_static+'</span>';
		ddappendData += '<span style="display:none;" class="importantYes">'+listOfAssetParamDefs[k].hasImportantValue+'</span>';
		ddappendData += '<span style="display:none;" class="mandatoryParam">'+listOfAssetParamDefs[k].hasMandatoryValue+'</span>';
		ddappendData += '<span style="display:none;" class="listSize">'+listOfAssetParamDefs[k].size+'</span>';
		ddappendData += '<span style="display:none;" class="derivedAttribute">'+listOfAssetParamDefs[k].derivedAttributeComputation+'</span>';
		ddappendData += '<span style="display:none;" class="derivedComputation">'+listOfAssetParamDefs[k].derivedAttributeComputation+'</span>';
		ddappendData += '<span style="display:none;" class="isArrayCheckbox">'+listOfAssetParamDefs[k].hasArray+'</span>';
		ddappendData += '<span style="display:none;" class="listType">'+listOfAssetParamDefs[k].listTypeParamTypeId+'</span>';
		ddappendData += '<span style="display:none;" class="singleMultipleListType">'+listOfAssetParamDefs[k].listType+'</span>'; //harish
		
		ddappendData += '<span style="display:none;" class="derivedAttribute_AutoComplete">'+listOfAssetParamDefs[k].derivedAssetListRule+'</span>';
		ddappendData += '<span style="display:none;" class="ldapMappingNameListId">'+listOfAssetParamDefs[k].ldapMappingId+'</span>';

		ddappendData += '<span style="display:none;" class=" emailSchedulerYes">'+listOfAssetParamDefs[k].notifyOnRuleValidate+'</span>';
		
		if(listOfAssetParamDefs[k].customListValues != null){
			$.each(listOfAssetParamDefs[k].customListValues, function(d){
				customListValuess += listOfAssetParamDefs[k].customListValues[d].value+"&&";
				
			});
			
		}
		if(listOfAssetParamDefs[k].derivedAttributeComputation != null){
			$.each(listOfAssetParamDefs[k].derivedAttributeComputation, function(d){
				derivedAttributeComputationValues += listOfAssetParamDefs[k].derivedAttributeComputation[d].replace(/\n/g, "&&");
			});
			derivedAttributeComputationValues += "&&";
		}
		
		if(listOfAssetParamDefs[k].derivedAssetListRule != null){
			$.each(listOfAssetParamDefs[k].derivedAssetListRule, function(d){
				derivedAttributeForAssetAutoComplete += listOfAssetParamDefs[k].derivedAssetListRule[d].replace(/\n/g, "&&");
			});
			derivedAttributeForAssetAutoComplete += "&&";
		}
		
		ddappendData += '<span style="display:none;" class="custListItems">'+listOfAssetParamDefs[k].customListValuess+'</span>';
		ddappendData += '<span style="display:none;" class="ddMappedAsset">'+listOfAssetParamDefs[k].mappedAssetId+'</span>';
		ddappendData += '<span style="display:none;" class="actionForParameter">NO CHANGES</span>';
		if(listOfAssetParamDefs[k].flagForParameterUsageInRule == true || listOfAssetParamDefs[k].flagForParameterUsageInAssetListRule == true){
			ddappendData += '<a style="float: right!important;" title="Delete" class="catParamDeleteIcon"><i class="trash icon"></i></a>';
		}
		else {
			ddappendData += '<a style="float: right!important;"><i class="trash icon deleteEditIcon" id="paramId_'+listOfAssetParamDefs[k].assetParamId+'" data-html="'+data+'" onclick="openParamPopup('+listOfAssetParamDefs[k].assetParamId+')"></i></a>';
		}
		
		
		customListValuess = encodeURIComponent(customListValuess);
		customListValuess = customListValuess.replace(/'/g, "\\'");
		
		var param_desc = escape(listOfAssetParamDefs[k].description);
		ddappendData += '<a style="float: right!important; margin-right:0.8em !important;" title="Edit"><i class="edit icon deleteEditIcon" onclick="passAllEditedParameterValues(this,\''+addParamFlag+'\',\''+listOfAssetParamDefs[k].assetParamName+'\',\''+param_desc+'\',\''+listOfAssetParamDefs[k].paramTypeId+'\',\''+listOfAssetParamDefs[k].defaultView+'\','+listOfAssetParamDefs[k].is_static+','+listOfAssetParamDefs[k].hasImportantValue+','+listOfAssetParamDefs[k].hasMandatoryValue+','+listOfAssetParamDefs[k].notifyOnRuleValidate+',\''+listOfAssetParamDefs[k].size+'\',\''+derivedAttributeComputationValues+'\',\''+derivedAttributeComputationValues+'\',\''+listOfAssetParamDefs[k].listTypeParamTypeId+'\',\''+listOfAssetParamDefs[k].listType+'\',\''+customListValuess+'\',\''+listOfAssetParamDefs[k].mappedAssetId+'\',\''+categoryId+'\',\''+listOfAssetParamDefs[k].assetParamId+'\',\''+listOfAssetParamDefs[k].hasArray+'\',\''+listOfAssetParamDefs[k].hasArrayFlag+'\',\''+listOfAssetParamDefs[k].multiSelectFlag+'\',\''+derivedAttributeForAssetAutoComplete+'\',\''+listOfAssetParamDefs[k].ldapMappingId+'\',\''+listOfAssetParamDefs[k].flagForParameterUsageInRule+'\',\''+listOfAssetParamDefs[k].flagForParameterUsageInAssetListRule+'\');"></i></a>'; //harish
		ddappendData += '</div>';
		
		globalParamId = listOfAssetParamDefs[k].assetParamId;
	});
	$("#availableCategory_"+categoryId).append(ddappendData);
	
	// add only 10 parameter -- Hema 20.Dec.2017
	 $('#assetCategoryCardContent_'+categoryId).each(function(i){
		 var addedParamLength = $(this).find('.paramCount').length;
		 if(addedParamLength == 10){
			 $('#addRemoveCategoryIcon_'+categoryId).attr('disabled',true);
		 }else{
			 $('#addRemoveCategoryIcon_'+categoryId).attr('disabled',false); 
		 }
	 });
}

//Kavya -- default access data -- Edit MODAL
function getEditDefaultAccess(groupId,groupName,addAccess,hideShow_access,editAccess,viewAccess,deleteAccess){

	appendData = "";
	appendData += '<tr id="trEditModalGroupId'+groupId+'">';
	appendData += '<td class="hidden" id="editModalGroupId_'+ groupId +'">' + groupId + '</td>';
	appendData += '<td id="editModalgroupName_'+groupId+'">' + groupName + '</td>';

	if(addAccess == "0"){
		if(hideShow_access == "0"){
			appendData += '<td class="center aligned"><div class="ui checkbox"><input type="checkbox" id="editModalAddAccess_'+groupId+'" class="editModalAddAccessCheckbox AddCheckbox" disabled><label></label></div></td>';
		}
		else{
			appendData += '<td class="center aligned"><div class="ui checkbox"><input type="checkbox" id="editModalAddAccess_'+groupId+'" class="editModalAddAccessCheckbox visibilityCheckbox"><label class="centerAlign"></label></div></td>';
		}
		
	}else{
		appendData += '<td class="center aligned"><div class="ui checkbox"><input type="checkbox" id="editModalAddAccess_'+groupId+'" class="editModalAddAccessCheckbox EditableCheckbox" checked><label></label></div></td>';
	}
	
	
	
	if(hideShow_access == "0"){
		appendData += '<td class="center aligned "><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;"><input type="checkbox" id="editModalHideOrShowAccess_'+groupId+'" class="editModalAddAccessCheckbox AddCheckbox"><label></label></div></td>';
	}else{
		if(addAccess == "1"){ // Swathi - Grey checkbox issue- fixed
			appendData += '<td class="center aligned disabled cssForDisablingData"><div class="ui toggle checkbox accessDenied" style="width: 45px !important;"><input type="checkbox" id="editModalHideOrShowAccess_'+groupId+'" class="editModalAddAccessCheckbox visibilityCheckbox" checked disabled><label class="centerAlign"></label></div></td>';

		}else{
			appendData += '<td class="center aligned"><div class="ui toggle checkbox accessDenied" style="width: 45px !important;"><input type="checkbox" id="editModalHideOrShowAccess_'+groupId+'" class="editModalAddAccessCheckbox EditableCheckbox" checked><label></label></div></td>';
		}
	}
	
	
	if(editAccess == "0"){
		if(hideShow_access == "0"){
			appendData += '<td class="center aligned" style="height:5em !important"><span id="editModalreadOnlyEdit_'+groupId+'" style="display: none;"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;"><input type="checkbox" id="editModalEditAccess_'+groupId+'" class="editModalEditAccessCheckbox"><label></label></div></span><span style="display:block;" id="editModalreadOnlyEdit_NotApplicable_'+groupId+'">N/A</span></td>';
		}
		else{
			appendData += '<td class="center aligned" style="height:5em !important"><span id="editModalreadOnlyEdit_'+groupId+'" style="display: block;"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;"><input type="checkbox" id="editModalEditAccess_'+groupId+'" class="editModalEditAccessCheckbox"><label></label></div></span><span style="display:none;" id="editModalreadOnlyEdit_NotApplicable_'+groupId+'">N/A</span></td>';

		}
	}else{
		if(addAccess == "1"){
			appendData += '<td class="center aligned disabled cssForDisablingData" style="height:5em !important"><span id="editModalreadOnlyEdit_'+groupId+'" style="display: block;"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;"><input type="checkbox" id="editModalEditAccess_'+groupId+'" class="editModalEditAccessCheckbox" checked disabled><label></label></div></span><span style="display:none;" id="editModalreadOnlyEdit_NotApplicable_'+groupId+'">N/A</span></td>';

		}else{
			appendData += '<td class="center aligned" style="height:5em !important"><span id="editModalreadOnlyEdit_'+groupId+'" style="display: block;"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;"><input type="checkbox" id="editModalEditAccess_'+groupId+'" class="editModalEditAccessCheckbox" checked><label></label></div></span><span style="display:none;" id="editModalreadOnlyEdit_NotApplicable_'+groupId+'">N/A</span></td>';
		}
		
	}

	if(deleteAccess == "0"){
		if(hideShow_access == "0"){
			appendData += '<td class="center aligned"><div class="ui checkbox" id="editModalDeleteAccesCheckbox_'+groupId+'" style="display:none;"><input type="checkbox" id="editModalDeleteAccess_'+groupId+'" class="editModalDeleteAccessCheckbox"><label></label></div><span style="display:block;" id="editModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';
		}
		else{
			appendData += '<td class="center aligned"><div class="ui checkbox" id="editModalDeleteAccesCheckbox_'+groupId+'" style="display: inline-block;"><input type="checkbox" id="editModalDeleteAccess_'+groupId+'" class="editModalDeleteAccessCheckbox"><label></label></div><span style="display:none;" id="editModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';

		}
	}else{
		/*if(loggedInUserName == "admin"){*/
			/*if(addAccess == "1"){
				appendData += '<td class="center aligned disabled cssForDisablingData"><div class="ui checkbox" id="editModalDeleteAccesCheckbox_'+groupId+'" style="display: inline-block;"><input type="checkbox" id="editModalDeleteAccess_'+groupId+'" class="editModalDeleteAccessCheckbox" checked disabled><label></label></div><span style="display:none;" id="editModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';

			}else{*/
				appendData += '<td class="center aligned"><div class="ui checkbox" id="editModalDeleteAccesCheckbox_'+groupId+'" style="display: inline-block;"><input type="checkbox" id="editModalDeleteAccess_'+groupId+'" class="editModalDeleteAccessCheckbox" checked><label></label></div><span style="display:none;" id="editModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';
			/*}*/
		/*}else{
			appendData += '<td class="center aligned"><div class="ui checkbox" id="editModalDeleteAccesCheckbox_'+groupId+'" style="display: inline-block;"><input type="checkbox" id="editModalDeleteAccess_'+groupId+'" class="editModalDeleteAccessCheckbox" checked><label></label></div><span style="display:none;" id="editModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';

		}*/

	}
	appendData += '</tr>';

	return appendData;
}

//Kavya -- default access data -- ADD MODAL
function getAddDefaultAccess(groupId,groupName,addAccess,hideShow_access,editAccess,viewAccess,deleteAccess){
	//console.log('getAddDefaultAccess');
	appendData = "";
	if(groupName == "group-admin" || groupName == "Guest"){
		appendData += '<tr id="trGroupId'+groupId+'" class="hidden">';
	}
	else {
		appendData += '<tr id="trGroupId'+groupId+'">';
	}

	appendData += '<td class="hidden" id="GroupId_'+ groupId +'">' + groupId + '</td>';
	appendData += '<td id="groupName_'+groupId+'">' + groupName + '</td>';
	if(addAccess == "0"){
		if(hideShow_access == "0"){
			appendData += '<td class="center aligned"><div class="ui checkbox"><input type="checkbox" id="addAccess_'+groupId+'" class="addAccessCheckbox" disabled><label></label></div></td>';

		}else{
			appendData += '<td class="center aligned"><div class="ui checkbox"><input type="checkbox" id="addAccess_'+groupId+'" class="addAccessCheckbox"><label></label></div></td>';
		}
	}else{
		appendData += '<td class="center aligned"><div class="ui checkbox"><input type="checkbox" id="addAccess_'+groupId+'" class="addAccessCheckbox" checked><label></label></div></td>';
	}

	if(hideShow_access == "0"){
		appendData += '<td class="center aligned"><div class="ui toggle checkbox" style="width: 45px !important;"><input type="checkbox" id="hideOrShow_'+groupId+'" class="editAccessCheckbox"><label></label></div></td>';
	}else{
		if(addAccess == "1"){
			appendData += '<td class="center aligned disabled cssForDisablingData"><div class="ui toggle checkbox" style="width: 45px !important;"><input type="checkbox" id="hideOrShow_'+groupId+'" class="editAccessCheckbox" checked disabled><label></label></div></td>';

		}else{
			appendData += '<td class="center aligned"><div class="ui toggle checkbox" style="width: 45px !important;"><input type="checkbox" id="hideOrShow_'+groupId+'" class="editAccessCheckbox" checked><label></label></div></td>';
		}

	}
	
	if(editAccess == "0"){
		if(hideShow_access == "0"){
		
			appendData += '<td class="center aligned"><span id="addModalreadOnlyEdit_'+groupId+'" style="display: none;"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;">';
			appendData += '<input type="checkbox" id="editAccess_'+groupId+'" class="editAccessCheckbox"><label></label></div>';
			appendData += '</span>';
			appendData += '<span style="display:block;" id="addModalreadOnlyEdit_NotApplicable_'+groupId+'">N/A</span></td>';
		
		
		}
		else{
			appendData += '<td class="center aligned"><span id="addModalreadOnlyEdit_'+groupId+'" style="display: block;"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;">';
			appendData += '<input type="checkbox" id="editAccess_'+groupId+'" class="editAccessCheckbox"><label></label></div>';
			appendData += '</span>';
			appendData += '<span style="display:none;" id="addModalreadOnlyEdit_NotApplicable_'+groupId+'">N/A</span></td>';
		
		}
		

	}else{

		if(addAccess == "1"){		
			appendData += '<td class="center aligned disabled cssForDisablingData"><span id="addModalreadOnlyEdit_'+groupId+'" style="display: block;"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;">';
			appendData += '<input type="checkbox" id="editAccess_'+groupId+'" class="editAccessCheckbox" checked disabled><label></label></div>';
			appendData += '</span>';
			appendData += '<span style="display:none;" id="addModalreadOnlyEdit_NotApplicable_'+groupId+'">N/A</span></td>';
			
		}else{
		    appendData += '<td class="center aligned"><span id="addModalreadOnlyEdit_'+groupId+'" style="display: block;"><div class="toggleCheckBoxColor ui toggle checkbox" style="width: 45px !important;">';
			appendData += '<input type="checkbox" id="editAccess_'+groupId+'" class="editAccessCheckbox" checked><label></label></div>';
			appendData += '</span>';
			appendData += '<span style="display:none;" id="addModalreadOnlyEdit_NotApplicable_'+groupId+'">N/A</span></td>';

		}

	}

	if(deleteAccess == "0"){
		if(hideShow_access == "0"){
			
			appendData += '<td class="center aligned"><div class="ui checkbox"  id="addModalDeleteAcces_'+groupId+'" style="display: none;"><input type="checkbox" id="deleteAccess_'+groupId+'" class="deleteAccessCheckbox">';
			appendData += '<label></label></div><span style="display:block;" id="addModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';
		
		
		}
		else{
			appendData += '<td class="center aligned"><div class="ui checkbox"  id="addModalDeleteAcces_'+groupId+'" style="display: inline-block;"><input type="checkbox" id="deleteAccess_'+groupId+'" class="deleteAccessCheckbox">';
			appendData += '<label></label></div><span style="display:none;" id="addModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';
		
		}

	}else{
		/*if(loggedInUserName == "admin"){*/
			/*if(addAccess == "1"){
				appendData += '<td class="center aligned"><div class="ui checkbox"  id="addModalDeleteAcces_'+groupId+'" style="display: inline-block;"><input type="checkbox" id="deleteAccess_'+groupId+'" class="deleteAccessCheckbox" checked >';
				appendData += '<label></label></div><span style="display:none;" id="addModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';
			}else{*/
				appendData += '<td class="center aligned"><div class="ui checkbox"  id="addModalDeleteAcces_'+groupId+'" style="display: inline-block;"><input type="checkbox" id="deleteAccess_'+groupId+'" class="deleteAccessCheckbox" checked>';
				appendData += '<label></label></div><span style="display:none;" id="addModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';	
			/*}*/
		/*}else{
			
			appendData += '<td class="center aligned"><div class="ui checkbox"  id="addModalDeleteAcces_'+groupId+'" style="display: inline-block;"><input type="checkbox" id="deleteAccess_'+groupId+'" class="deleteAccessCheckbox" checked>';
			appendData += '<label></label></div><span style="display:none;" id="addModaldeleteAccess_NotApplicable_'+groupId+'">N/A</span></td>';	
			
		}*/
		
	}
	appendData += '</tr>';
	return appendData;
}


//kavya --- associate Taxonomy for edit 
var editAddTax;
var chckExistingTaxNameFlag = false;
var arrTaxDetails = [];
var edit_taxTreeFlag = true;
assignedTaxonomy = [];
var edit_temporaryStorageArray = [];
function openEditedAssignTaxonomyModal(){
	edit_temporaryStorageArray = [];
	$("#addAssignTaxonomyModal").hide();
	$("#btnEditSubmitAssignTaxonomy").unbind();
	$("#btnEditCancelAssignTaxonomy").unbind();
	$('#editAssignTaxonomyModal').modal({observeChanges : true, closable : false}).modal('refresh').modal('show');
	$('#edit_form_assignTaxonomy').form('clear');
	

	//if(edit_taxTreeFlag){
		//edit_taxTreeFlag = false;
	$('#tree2').tree("destroy");
		jQuery.ajax({
		type : "GET",
		url : "/repopro/web/taxonomy/getTaxonomy",
		dataType : "json",
		contentType : 'application/json',
		async : false,
		complete : function(data) {
			json = JSON.parse(data.responseText);
			if(json.result == "" || json.result == null){
				$('#btnEditSubmitAssignTaxonomy').attr('disabled',true);
				//$('.addResourcePanel').hide();
				$('#editNewTaxonomySegment').hide();
				$('.noTaxonomiesAdded').show();
			}
			else {
				$('#btnEditSubmitAssignTaxonomy').attr('disabled',false);
				$('#editNewTaxonomySegment').show();
				$('.noTaxonomiesAdded').hide();
				$('#loadingDivTree').hide();
				$('#tree2').show();
				jQuery('#tree2').tree({
					data : json.result,
					autoOpen : false
				});
			}
			
			jQuery('.jqtree-title').each(function(e){
				var item = jQuery(this);
				item.css('display','inline-block');
				var valTax = jQuery(this).text();
				var valTax1 = valTax.split("|");
				var val = valTax1[0];
				var val1 = valTax1[1];
				
				jQuery(this).text(val);
				item.parent().append("<span id="+val1+" class='someCls'></span>");
				jQuery(this).addClass('treeViewElement');
				$('#editNewTaxonomySegment').html('');
				$('#editNewTaxonomySegment').append("");
				jQuery(this).unbind('click');
				editAddTax = 1;
				
				// show taxonomies that are already assigned and saved in database
				pushAllTaxonomies = $.unique(pushAllTaxonomies);
				if(pushAllTaxonomies.length == 0){
					$('#editNewTaxonomySegment').hide();
					$('#edit_NoTaxonomies').show();
					$('#btnEditSubmitAssignTaxonomy').attr('disabled',true);
				}else {
					$('#edit_NoTaxonomies').hide();
					$('#editNewTaxonomySegment').show();
					$('#btnEditSubmitAssignTaxonomy').attr('disabled',false);
					for (var i = 0; i < pushAllTaxonomies .length; i++) {	
						$('#editNewTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+pushAllTaxonomies[i].taxId+'_'+pushAllTaxonomies[i].taxName.replace(/ /g,"_")+'" id="taxonomyName_'+pushAllTaxonomies[i].taxId+'_'+pushAllTaxonomies[i].taxName+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+pushAllTaxonomies[i].taxName+'<i class="delete icon" onclick="deleteTaxonomy('+pushAllTaxonomies[i].taxId+',\''+pushAllTaxonomies[i].taxName+'\',\''+editAddTax+'\')"></i></a>');
					}
				}
				// check left side taxonomies with right side assigned taxonomies (onclick)
				//var temporaryStorageArray = [];
				edit_temporaryStorageArray.splice.apply(edit_temporaryStorageArray, [2, 0].concat(pushAllTaxonomies));
				edit_temporaryStorageArray = $.unique(edit_temporaryStorageArray);
				
				jQuery(this).on("click",function(){
					var loop_complete_flag = false;
					$('#edit_NoTaxonomies').hide();
					$('#editNewTaxonomySegment').show();
					$('#btnEditSubmitAssignTaxonomy').attr('disabled',false);
					
					for (var j = 0; j < edit_temporaryStorageArray.length; j++) {

						if(edit_temporaryStorageArray[j].taxId == val1){
							chckExistingTaxNameFlag = true;
							//break;
						}

						if(j == (edit_temporaryStorageArray.length - 1)){
							//console.log("Loop completed : "+j);
							loop_complete_flag = true;
						}
					}

					if(edit_temporaryStorageArray.length > 0){
						if(chckExistingTaxNameFlag == false && loop_complete_flag == true){
							edit_temporaryStorageArray.push({"taxId" : val1, "taxName" : val});
							edit_temporaryStorageArray = $.unique(edit_temporaryStorageArray);
							$('#editNewTaxonomySegment').append("");
							$('#editNewTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\',\''+editAddTax+'\')"></i></a>');
						}
						else {
							notifyMessage("Add Asset","The taxonomy " + val +" is already added","fail");
							chckExistingTaxNameFlag = false;
						}
					}else{
						edit_temporaryStorageArray.push({"taxId" : val1, "taxName" : val});
						edit_temporaryStorageArray = $.unique(edit_temporaryStorageArray);
						$('#editNewTaxonomySegment').append("");
						$('#editNewTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\',\''+editAddTax+'\')"></i></a>');					
					}
					
					
				/*	for (var j = 0; j < edit_temporaryStorageArray.length; j++) {
						if(edit_temporaryStorageArray[j].taxId == val1){
							chckExistingTaxNameFlag = true;
							break;
						}
						}
					if(chckExistingTaxNameFlag == false){
						edit_temporaryStorageArray.push({"taxId" : val1, "taxName" : val});
						edit_temporaryStorageArray = $.unique(edit_temporaryStorageArray);
						$('#editNewTaxonomySegment').append("");
						$('#editNewTaxonomySegment').append('<a class="ui label taxonomyNameClass_'+val1+'_'+val.replace(/ /g,"_")+'" id="taxonomyName_'+val1+'_'+val+'" style="margin-bottom:0.5em;"><i class="fork icon"></i>'+val+' <i class="delete icon" onclick="deleteTaxonomy('+val1+',\''+val+'\',\''+editAddTax+'\')"></i></a>');
					}
					else {
						notifyMessage("Edit Asset","The taxonomy " + val +" is already added","fail");
						chckExistingTaxNameFlag = false;
					}*/
				});
				
				jQuery(this).css('pointer','cursor');
				
			});
		}
	});		
}

//kavya -- submit edited taxonomy data
function submitEditedTaxonomyData(){
	editTaxIdsArr.length = 0;
	pushAllTaxonomies.length = 0;
	var TaxId = "";
	var TaxName = "";
	$('.assignTax a').each(function(i){
		var taxData = $(this).attr('id');
		taxData = taxData.split('_');		
		TaxId = taxData[1];
		TaxName = taxData[2];
		//taxIdsArr.push({TaxId : TaxName});

		var keyValuePair = {};
		keyValuePair[TaxId]=TaxName; // set your dynamic values
		editTaxIdsArr.push(keyValuePair);
		pushAllTaxonomies.push({"taxId" : TaxId, "taxName": TaxName});
		
	})
	
	
	$('#editAssignTaxonomyModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
	/*$('#editAssignTaxonomyModal').modal('hide');  //.modal('hide dimmer');
	$('#editAssignTaxonomyModal').parent().css("display", "none !important");*/
}

//kavya -- category access for edit modal 
var categoryObj = {};
var categoriesWithAccess = [];
var categoryObjArr = [];
var manageAssetFlag = true;
function openManageAssetModal(){
	$('#btnManageAccessSave').unbind();  
	$('#btnManageAccessCancel').unbind();
	$('#categoryWiseManageAccessModal').modal('setting', 'closable', false).modal('show');
	manageAssetFlag = false;
	loadManageAssetData();	
}


//save edited asset details
function saveEditAssetDetails(){
	assetDescription = "";
	$('#addAssetParameterModal').modal('destroy');
	$('#addAssignTaxonomyModal').modal('destroy');
	var categoriesArr = [];
	var listOfAssetParamDefsArr = [];
	var assetVisualizationArr = [];
	 
	categoriesArr.length = 0;
	var edit_listType = 0;
	var ddMappedAsset = 0;
	var listSize = 0;
	var actionForCategory = "";
	 var isArray = 0;
	 var edit_singlemultiple=""; //harish
	 var dd_ldapMappingListId = 0;
	 
	
	// asset name and description
	assetName = $('#assetName').val().trim();
	
	//trimming white spaces and strings with empty values - chandana 21.02.2020 - #708
	var getTextfromCKeditor = $(".cke_contents iframe").contents().find("body").text();
	var trimextfromCKeditor = $.trim(getTextfromCKeditor);
	assetDescription = CKEDITOR.instances['assetDescriptionTextarea'].getData();
	if(getTextfromCKeditor == "" || getTextfromCKeditor == null || trimextfromCKeditor == ""){
		assetDescription = "";
	}
	else{
		assetDescription = assetDescription;
	}
	/*if(assetDescription != ""){
		var data = CKEDITOR.instances['assetDescriptionTextarea'].dataProcessor.toHtml(assetDescription);

		assetDescription = data;

	}*/
	$('#versionableCheckbox').removeAttr("disabled");
	$('#guestAccessCheckbox').removeAttr("disabled");
	$('#manageWorkflowCheckbox').removeAttr("disabled");
		// Versionable value
		var versionableFlag = "";
		if($('#versionableCheckbox').is(':checked')){
			versionableFlag = true;
		}
		else {
			versionableFlag = false;
		}
		
		// Guest Access value
		var guestAccessFlag = "";
		if($('#guestAccessCheckbox').is(':checked')){
			guestAccessFlag = true;
		}
		else {
			guestAccessFlag = false;
		}
		
		// Manage Workflow value- Swathi
		var enableWorkflow = "";
		if($('#manageWorkflowCheckbox').is(':checked')){
			enableWorkflow = true;
		}
		else {
			enableWorkflow = false;
		}
		// rating Desc
		var ratingDescTextarea = $('#ratingDescTextarea').text();

		//Icon
		/*var logoImgformData = new FormData();
		$('#logoImageFileNameFor').on('change',function(){
			document.getElementById("uploadAssetIcon").value = this.value;
			var getLogoImage = $('input[name="uploadAssetIconButton"').get(0).files[0];
			logoImgformData.append('iconImageName', getLogoImage);
		})
		*/
		// edit loop category and parameter values
		var catPosition = 0;
		$('.categoryClass').each(function(i){
		var count = i+1;
		var paraPosition = 0;
		listOfAssetParamDefsArr.length = 0;
		var assetCategoryCardId = $(this).attr('id');
		assetCategoryCardId = assetCategoryCardId.split('_');
		var categoryName = $("#assetCategoryCardHeaderLabel_"+assetCategoryCardId[1]).text();
		if($(this).find('span.actionForCategoryAttr').text() == ""){
	 		actionForCategory = "UPDATE";
	 	}
	 	if($(this).find('span.actionForCategoryAttr').text() == "ADD"){
	 		actionForCategory = "ADD";
	 	}
	 	if($('#assetCategoryCard_'+assetCategoryCardId[1]).hasClass('deleteCategory')){
	 		actionForCategory = "DELETE";
	 		actionForParameter = "DELETE";
	 	}
	 	
		$(this).find('.divParamValues').each(function() { 
			var paramId = $(this).attr('id');
			paramId = paramId.split('_');
		     assetParameterNameParam = $(this).find('span.assetParamName').text();
		     paramDesc =  $(this).find('.paramDescription textarea').val();
		     paramDesc = unescape(paramDesc);
		     defaultViewChecked = $(this).find('span.defaultViewChecked').text();
		     defaultViewChecked = parseInt(defaultViewChecked);
		     hasStaticValueYes = $(this).find('span.hasStaticValueYes').text();
		     hasStaticValueYes = (hasStaticValueYes == 'true' || hasStaticValueYes == '1')?1:0;
		     importantYes = $(this).find('span.importantYes').text();
		     importantYes = (importantYes == 'true')?true:false;
		     mandatoryYes = $(this).find('span.mandatoryParam').text();
		     mandatoryYes = (mandatoryYes == 'true')?true:false;
		     emailSchedulerYes = $(this).find('span.emailSchedulerYes').text();
		     emailSchedulerYes = (emailSchedulerYes == 'true')?true:false;
		     
		    isArray = $(this).find('span.isArrayCheckbox').text();
		     edit_listType = $(this).find('span.listType').text();
			    if(edit_listType == "Select List Type" || edit_listType == "" || edit_listType == null || edit_listType == 'NaN'){
			    	edit_listType = 0;
			    }
			    else {
			    	edit_listType = $(this).find('span.listType').text();
			    }
				//harish
			    edit_singlemultiple = $(this).find('span.singleMultipleListType').text();
			    if(edit_singlemultiple == "Select Parameter Type" || edit_singlemultiple == "" || edit_singlemultiple == null || edit_singlemultiple == 'NaN'){
			    	edit_singlemultiple = 0;
			    }
			    else {
			    	edit_singlemultiple = $(this).find('span.singleMultipleListType').text();
			    }
		   
		     ddMappedAsset = $(this).find('span.ddMappedAsset').text();
		    if(ddMappedAsset == "Select Mapped Asset" || ddMappedAsset == ""){
		    	ddMappedAsset = 0;
		    }
		    else {
		    	ddMappedAsset = $(this).find('span.ddMappedAsset').text();
		    }
		    
		    ddMappedAsset = parseInt(ddMappedAsset);
		    var userlistDD = $('#listType option:selected').val();
		    var custListItems = $(this).find('span.custListItems').text();
		    
		    
		     listSize = $(this).find('span.listSize').text(); 
		     if(listSize == null || listSize == ""){
		    	 listSize = 0;
		     }else{
		    	 listSize = parseInt(listSize);
		     }
		     currentdate = new Date(); 
		     derivedAttributeORcomputation = "";
		     derivedAttrForAssetAutoComplete_AddEdit = "";
		     datetime = currentdate.getFullYear() + "-"
		    			  	+(currentdate.getMonth()+1)  + "-" 
				            + currentdate.getDate() + "  "  
				            + currentdate.getHours() + ":"  
				            + currentdate.getMinutes() + ":" 
				            + currentdate.getSeconds();
		   /* var dateToEpoch =  Epoch(datetime);*/
		    
		    paramTypeDD = $(this).find('span.paramTypeDD').text();
		     
		    if(paramTypeDD == "Select Parameter Type" || paramTypeDD == "" || paramTypeDD == null){
		    	paramTypeDD = 0;
		    }
		    else {
		    	paramTypeDD = $(this).find('span.paramTypeDD').text();
		    }
		    if(paramTypeDD == 5){
		    	derivedAttributeORcomputation = $(this).find('span.derivedAttribute').text();
		    }
		    else if(paramTypeDD == 6){
		    	derivedAttributeORcomputation = $(this).find('span.derivedComputation').text();
		    }
		    derivedAttributeORcomputation = derivedAttributeORcomputation.trim();
		    
		    /* derived attribute for asset - auto complete - BOC*/
		    if(paramTypeDD == 8){
		    	derivedAttrForAssetAutoComplete_AddEdit = $(this).find('span.derivedAttribute_AutoComplete').text();
		    }
		    
		    derivedAttrForAssetAutoComplete_AddEdit = derivedAttrForAssetAutoComplete_AddEdit.trim();
		    /* EOC*/
		    
		    /*BOC Ldap mapping name - Hema - 28.Feb.2019 */
		    if(paramTypeDD == 9){
		    	dd_ldapMappingListId = $(this).find('span.ldapMappingNameListId').text();
		    	dd_ldapMappingListId = parseInt(dd_ldapMappingListId);
		    }
		    else {
		    	dd_ldapMappingListId = 0;
		    }
		    
		    var actionForParameter = "UPDATE";
		 	if($(this).hasClass('deleteParam')){
		 		actionForParameter = "DELETE";
		 		edit_listType = 0;
		 	}
		 	else {
		 		actionForParameter = $(this).find('span.actionForParameter').text();
		 	}
		 	
		 	if($('#assetCategoryCard_'+assetCategoryCardId[1]).hasClass('deleteCategory')){
		 		actionForCategory = "DELETE";
		 		actionForParameter = "DELETE";
		 	}
		 	
		 	edit_listType = parseInt(edit_listType);
		 	paramTypeDD = parseInt(paramTypeDD);
		 	actionForParameter = actionForParameter.toString();
		 	
		    listOfAssetParamDefsArr.push({
		    	  "actionForParameter":actionForParameter, 
				  "assetParamName":assetParameterNameParam,
				  "description":paramDesc,
				  "defaultView":defaultViewChecked,
				  "is_static":hasStaticValueYes,
				  "hasImportantValue":importantYes,
				  "hasMandatoryValue":mandatoryYes,
				  "lastUpdatedTime":datetime,
				  "listTypeParamTypeId":edit_listType,
				  "singlemultiple":edit_singlemultiple, //harish
				  "mappedAssetId":ddMappedAsset,
				  "modifyByUserId":loggedInUserId,
				  "derivedAttributeComputation":derivedAttributeORcomputation,
				  "paramTypeId":paramTypeDD,
				  "size":listSize,
				  "displayPosition":paraPosition,
				  "custListItems":custListItems,
				  "assetParamId":paramId[1],
				  "assetCategoryId":assetCategoryCardId[1],
				  "isArray":isArray,
				  "derivedAssetListRule":derivedAttrForAssetAutoComplete_AddEdit,
				  "ldapMappingId":dd_ldapMappingListId,
				  "notifyOnRuleValidate": emailSchedulerYes
			    });
		    paraPosition++;
		});
		
		 categoriesArr.push({
			 "actionForCategory":actionForCategory,
			 "categoryAction":actionForCategory,
			 "categoryName":categoryName, 
			 "disp_position":catPosition,
			 "listOfAssetParamDefs":listOfAssetParamDefsArr.slice(),
			 "AssetId":editAssetId,
			 "userName":loggedInUserName,
			 "categoryId":assetCategoryCardId[1]
		 });
		 catPosition++;
	})
	var getAVoption =  $('#selectAssetVisualisationOption option:selected').val();
	//alert(getAVoption)
		assetVisualizationArr.push({
			"AssetrepName" : getAVoption,
		});
		
	var catPara = {
			 "description":assetDescription,
			 "categories":categoriesArr.slice(),
			 "assetAssignedTaxonomies":editTaxIdsArr,
			 "groupAccessForAsset":editGroupAccessForAsset, // Default access for newly created Instances 
			 "categoriesWithAccess":categoryAccessStr, // category wise
			 "draggedParams":draggedList, // dragged catname and paramid
			 "assetVisualization" : assetVisualizationArr.slice() // adding dropdown values (AV)
		}
	
		$('#hiddenInput').val(JSON.stringify(catPara)); 

		var value = $('#hiddenInput').val(); 
		value = JSON.parse(value);
		//console.log("EDIT : " + JSON.stringify(value));
}


//Add Asset Details
function saveAddAssetDetails(){
	$('#addAssetParameterModal').modal('destroy');
	$('#editAssignTaxonomyModal').modal('destroy');
	var categoriesArr = [];
	var assetVisualizationArr = [];
	var listOfAssetParamDefsArr = [];
	categoriesArr.length = 0;
	listOfAssetParamDefsArr.length = 0;
	var logoImgformData = new FormData();
	assetDescription = "";
	// asset name and description
	var assetName = $('#assetName').val();
	
	//trimming white spaces and strings with empty values - chandana 21.02.2020 - #708	
	var getTextfromCKeditor = $(".cke_contents iframe").contents().find("body").text();
	var trimextfromCKeditor = $.trim(getTextfromCKeditor);
	assetDescription = CKEDITOR.instances['assetDescriptionTextarea'].getData();
	if(getTextfromCKeditor == "" || getTextfromCKeditor == null || trimextfromCKeditor == ""){
		assetDescription = "";
	}
	else{
		assetDescription = assetDescription;
	}
	/*if(assetDescription != ""){
		var data = CKEDITOR.instances['assetDescriptionTextarea'].dataProcessor.toHtml(assetDescription);

		assetDescription = data;

	}*/
	// Versionable value
	var versionableFlag = "";
     if($('#versionableCheckbox').is(':checked')){
    	 versionableFlag = true;
     }
     else {
    	 versionableFlag = false;
     }
	
     // Guest Access value
     var guestAccessFlag = "";
     if($('#guestAccessCheckbox').is(':checked')){
    	 guestAccessFlag = true;
     }
     else {
    	 guestAccessFlag = false;
     }
     
 	// Manage Workflow value- Swathi
	var enableWorkflow = "";
	if($('#manageWorkflowCheckbox').is(':checked')){
		enableWorkflow = true;
	}
	else {
		enableWorkflow = false;
	}
     // rating Desc
     var ratingDescTextarea = $('#ratingDescTextarea').text();
     
   /*  //Icon
     var logoImgformData =  new FormData();
     $('#logoImageFileNameFor').on('change',function(){
 		document.getElementById("uploadAssetIcon").value = this.value;
 		var getLogoImage = $('input[i="uploadAssetIconButton"').get(0).files[0];
 		logoImgformData.append('iconImageName', getLogoImage);
 	})*/
     
     
	var assetParameterNameParam = "";
    var paramDesc =  "";
    var defaultViewChecked = 0;
    var hasStaticValueYes = false;
    var importantYes = false;
    var listType = 0;
    var ddMappedAsset = 0;
    var paramTypeDD = "";
    var listSize = 0; 
    var currentdate = ""; 
    var derivedAttributeORcomputation = "";
    var datetime = 0;
    var mandatoryYes = true; 
    var isArray = 0;
    var singlemultiple=""; //harish
    var derivedAttrForAssetAutoComplete_AddEdit = "";
    var dd_ldapMappingListId = 0;
    var emailSchedulerYes = false;
	// add loop category and parameter values
    var catPosition = 0;
	$('.categoryClass').each(function(i){
		var count = i+1;
		//var categoryName = $("#assetCategoryCardHeaderLabel_"+count).text();
		//souradip
		var categoryName = $(this).find("a").text();
		listOfAssetParamDefsArr.length = 0;
		var paraPosition = 0;
		$(this).find('.divParamValues').each(function() { 
		     assetParameterNameParam = $(this).find('span.assetParamName').text();
		     paramDesc =  $(this).find('.paramDescription textarea').val();
		     paramDesc = unescape(paramDesc);
		     defaultViewChecked = $(this).find('span.defaultViewChecked').text();
		     defaultViewChecked = parseInt(defaultViewChecked);
		     hasStaticValueYes = $(this).find('span.hasStaticValueYes').text();
		     hasStaticValueYes = (hasStaticValueYes == 'true' || hasStaticValueYes == '1')?1:0;
		     importantYes = $(this).find('span.importantYes').text();
		     importantYes = (importantYes == 'true')?true:false;
		     mandatoryYes = $(this).find('span.mandatoryParam').text();
		     mandatoryYes = (mandatoryYes == 'true')?true:false;
		     
		     emailSchedulerYes = $(this).find('span.emailSchedulerYes').text();
		     emailSchedulerYes = (emailSchedulerYes == 'true')?true:false;
		     
		     isArray = $(this).find('span.isArrayCheckbox').text();
		     //console.log("save -------- isArray : " + isArray);
		     listType = $(this).find('span.listType').text();
			    if(listType == "Select List Type" || listType == "" || listType == null){
			    	listType = 0;
			    }
			    else {
			    	listType = $(this).find('span.listType').text();
			    }
		    listType = parseInt(listType);
			//harish
		    singlemultiple = $(this).find('span.singleMultipleListType').text();
		    
		 //   singlemultiple = $('#ddsingleMultipleType option:selected').val();
		    if(singlemultiple == "Select Parameter Type" || singlemultiple == "" || singlemultiple == null){
		    	singlemultiple = 0;
		    }
		    else {
		    	singlemultiple = $(this).find('span.singleMultipleListType').text();
		    }
		    
		     ddMappedAsset = $(this).find('span.ddMappedAsset').text();
		    if(ddMappedAsset == "Select Mapped Asset" || ddMappedAsset == ""){
		    	ddMappedAsset = 0;
		    }
		    else {
		    	ddMappedAsset = $(this).find('span.ddMappedAsset').text();
		    }
		    
		    ddMappedAsset = parseInt(ddMappedAsset);
		    var userlistDD = $('#listType option:selected').val();
		    var custListItems = $(this).find('span.custListItems').text();
		    
		     paramTypeDD = $(this).find('span.paramTypeDD').text();
		     listSize = $(this).find('span.listSize').text(); 
		     if(listSize == null || listSize == ""){
		    	 listSize = 0;
		     }else{
		    	 listSize = parseInt(listSize);
		     }
		     currentdate = new Date(); 
		     derivedAttributeORcomputation = "";
		     derivedAttrForAssetAutoComplete_AddEdit = "";
		     datetime = currentdate.getFullYear() + "-"
		    			  	+(currentdate.getMonth()+1)  + "-" 
				            + currentdate.getDate() + "  "  
				            + currentdate.getHours() + ":"  
				            + currentdate.getMinutes() + ":" 
				            + currentdate.getSeconds();
		    /*var dateToEpoch =  Epoch(datetime);*/
		    if(paramTypeDD == 5){
		    	derivedAttributeORcomputation = $(this).find('span.derivedAttribute').text();
		    }
		    else if(paramTypeDD == 6){
		    	derivedAttributeORcomputation = $(this).find('span.derivedComputation').text();
		    }
		    derivedAttributeORcomputation = derivedAttributeORcomputation.trim();
		    
		   /* derived attribute for asset - auto complete - BOC*/
		    if(paramTypeDD == 8){
		    	derivedAttrForAssetAutoComplete_AddEdit = $(this).find('span.derivedAttribute_AutoComplete').text();
		    }
		    
		    derivedAttrForAssetAutoComplete_AddEdit = derivedAttrForAssetAutoComplete_AddEdit.trim();
		    /* EOC*/
		    
		    /*BOC Ldap mapping name - Hema - 28.Feb.2019 */
		    if(paramTypeDD == 9){
		    	dd_ldapMappingListId = $(this).find('span.ldapMappingNameListId').text();
		    	dd_ldapMappingListId = parseInt(dd_ldapMappingListId);
		    }else{
		    	dd_ldapMappingListId = 0;
		    }
		    /*EOC*/
		    
		 	paramTypeDD = parseInt(paramTypeDD);
		    listOfAssetParamDefsArr.push({
		    	  "actionForParameter":"ADD", 
				  "assetParamName":assetParameterNameParam,
				  "description":paramDesc,
				  "defaultView":defaultViewChecked,
				  "is_static":hasStaticValueYes,
				  "hasImportantValue":importantYes,
				  "hasMandatoryValue":mandatoryYes,
				  "lastUpdatedTime":datetime,
				  "singlemultiple":singlemultiple, //harish
				  "listTypeParamTypeId":listType,
				  "mappedAssetId":ddMappedAsset,
				  "modifyByUserId":loggedInUserId,
				  "derivedAttributeComputation":derivedAttributeORcomputation,
				  "paramTypeId":paramTypeDD,
				  "size":listSize,
				  "displayPosition":paraPosition,
				  "custListItems":custListItems,
				  "isArray":isArray,
				  "derivedAssetListRule":derivedAttrForAssetAutoComplete_AddEdit,
				  "ldapMappingId":dd_ldapMappingListId,
				  "notifyOnRuleValidate": emailSchedulerYes
			    });
		    paraPosition++;
		});
		 categoriesArr.push({
		//	 "description":assetDescription,
			 "actionForCategory" : "ADD", 
			 "categoryAction":"ADD", 
			 "categoryName":categoryName, 
			 "disp_position":catPosition,
			 "listOfAssetParamDefs":listOfAssetParamDefsArr.slice(),
			 "userName":loggedInUserName
		 });
		 catPosition++;
	})
	
	var getAVoption =  $('#selectAssetVisualisationOption option:selected').val();
	//alert(getAVoption)
		assetVisualizationArr.push({
			"AssetrepName" : getAVoption,
		});
	
	var catPara = {
		 "description":assetDescription,
		 "categories":categoriesArr.slice(),
		 "assetAssignedTaxonomies":taxIdsArr,
		 "groupAccessForAsset":groupAccessForAsset,
		 "categoriesWithAccess":"",
		 "assetVisualization" : assetVisualizationArr.slice() // adding dropdown values (AV)
	}
	$('#hiddenInput').val(JSON.stringify(catPara)); 

	var value = $('#hiddenInput').val(); 
	value = JSON.parse(value);
	//console.log("ADD : " + JSON.stringify(value));
}



//load asset data for edit -- KAvya
var editTaxIdsArr = [];
var categoryArr = [];
pushAllTaxonomies = [];
function loadAssetDataForEdit(){
	categoryArr.length = 0;
	pushAllTaxonomies.length = 0;
	//console.log('hhtp:localhost:8080/repopro/web/assetType/getassetdetails/'+editAssetId);
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetType/getassetdetails/"+editAssetId,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			//console.log("07.03.18 == json LOAD : " + JSON.stringify(json));
			$('#assetName').val(json.result[0].assetName);
			var editor = CKEDITOR.instances.assetDescriptionTextarea;
			if (editor) {
				editor.destroy(true); 
			}   
			CKEDITOR.replace('assetDescriptionTextarea',
					{
				toolbar : 'Basic'
					});
			CKEDITOR.instances['assetDescriptionTextarea'].setData(json.result[0].description);
			$("#assetDescriptionTextarea").val(json.result[0].description);
			if(json.result[0].versionable == true){
				$('#versionableCheckbox').attr('checked',true);
			}
			else {
				$('#versionableCheckbox').attr('checked',false);
			}
			if(json.result[0].guestflag == true){
				$('#guestAccessCheckbox').attr('checked',true);
			}
			else {
				$('#guestAccessCheckbox').attr('checked',false);
			}
			//Swathi- Workflow-09.03.2020
			if(json.result[0].enableWorkflow == true){
				$('#manageWorkflowCheckbox').attr('checked',true);	
				// Workflow diable option , if asset is already assigned to workflow
				if(json.result[0].flagIfWorkflowAssigned== true){
					$('.manageWorkflowCheckboxlabel').addClass("disableClick");
					$(".manageCheck").addClass("disableClick");
				}else{
					$('.manageWorkflowCheckboxlabel').removeClass("disableClick");
					$(".manageCheck").removeClass("disableClick");
				}	
			}
			else {
				$('#manageWorkflowCheckbox').attr('checked',false);			
			}
				
			$("#ratingDescTextarea").html(json.result[0].ratingDescription);
			$("#uploadAssetIcon").val(json.result[0].iconImageName);
			
			if(json.result[0].relFlag == true){
				$('#versionableCheckbox').attr('disabled','disabled');  /*Hema 05.Dec.2017*/
			} else {
				$('#versionableCheckbox').prop("disabled", false);  /*Hema 05.Dec.2017*/
			}
			
			//chandana - adding  options to asset visualization dropdown
			loadVisualisationDropdown();
			var getVisualisationOption = '';
			
				if(json.result[0].assetRepresentation == null){
				
				$('#selectAssetVisualisationOption').dropdown("set selected",'Select');
				
				}else{
				
				getVisualisationOption = json.result[0].assetRepresentation.representationName;
				$('#selectAssetVisualisationOption').dropdown("set selected",getVisualisationOption);
			
				}
			
				var getSelectedOption  = $('#selectAssetVisualisationOption :selected').text();
				//show confirm modal on dropdown change // chandana 24.12.2019
				$("#selectAssetVisualisationOption").change(function(){
			        if(getSelectedOption == getVisualisationOption)
			            {
			        	$('#openConfirmationofSelectDropdownOption').modal('setting', 'closable', false).modal('show');
			        	$('#CancelSelectedDropdownOption').on('click',function(){
			        		$('#selectAssetVisualisationOption').dropdown("set selected",getVisualisationOption);
			        	});
			        	$('#AllowdropdownChange').on('click',function(){
			        		$('#CancelSelectedDropdownOption').unbind();
			        		$('#openConfirmationofSelectDropdownOption').modal('hide');
			        	});
			            }
			        });
				
			// display taxonomies in side div
			$.each(json.result[0].assetAssignedTaxonomies, function(key,value){	
				/*associateTaxIdArr.push(key);
				associateTaxNameArr.push(value);*/
				var keyValuePair = {};
				keyValuePair[key]=value; //Swathi-- REPO-914 fix
				editTaxIdsArr.push(keyValuePair);
				pushAllTaxonomies.push({"taxId" : key, "taxName" : value});
				
			});
			
			$.each(json.result[0].categories, function(i) {
				categoryArr.push(json.result[0].categories[i].categoryName.toLowerCase());
				getNewAssetCategory(json.result[0].categories[i].categoryId,json.result[0].categories[i].categoryName,json.result[0].categories[i].flagForCategoryRuleUsage,json.result[0].categories[i].flagForCategoryUsageInAssetListRule,json.result[0].categories[i].listOfAssetParamDefs);
			});
			$('#showHideLoader').removeClass('active');
			
		}
	})
	$.ajax({
		type : "GET",
		url : "/repopro/web/globalsettings",
		dataType : "json",
		async: false,
		cache: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
						//Chandana -- 12/8/2019 hide and show of guest user 
						if(json.result[0].guestAccess == 0){
							$("#guestAccessPermission").hide();
						}
						else{
							$("#guestAccessPermission").show();
						}	
		}
	});
	
	

}


//param confirmation popup - open 
function openParamPopup(paramId){
	$("#paramId_"+paramId).popup({on: 'click',lastResort: 'bottom left',closable : true}).popup('show');
}

//param confirmation popup - close 
function closeParamPopup(paramId){
	$("#paramId_"+paramId).popup('hide');
}

// delete param
var categoryId_New = "";
function paramDelete(obj,paramId,categoryId){
	$("#parameterId_"+paramId).removeClass('paramCount');
	$("#paramId_"+paramId).parent().parent().hide().addClass('deleteParam');
	$("#paramId_"+paramId).popup('hide');
	var paramName = $('#parameterName_'+paramId).text();
	arrParameters.splice($.inArray(paramName, arrParameters),1);		
	
	// add only 10 parameter -- Hema 20.Dec.2017
	categoryId_New = "";
	$('.categoryClass').each(function(){
		if($(this).attr('id') != undefined){
		categoryId_New = $(this).attr('id');
		categoryId_New = categoryId_New.split("_");
		
		$('#assetCategoryCardContent_'+categoryId_New[1]).each(function(i){
			 var addedParamLength = $(this).find('.paramCount').length;
			 if(addedParamLength == 10){
				 $('#addRemoveCategoryIcon_'+categoryId_New[1]).attr('disabled',true);
			 }
			 else{
				 $('#addRemoveCategoryIcon_'+categoryId_New[1]).attr('disabled',false); 
			 }
		 });
		
		
		}
	})
	
	
	
}

//Epoch
/*function Epoch(date) {
    return Math.round(new Date(date).getTime() / 1000.0);
}
*/
function validateForm(){
	var setFlag = true;
	defaultAccessFlag = true;
	defaultAddAccessFlag = true;
	localSaveManageAssetFlag = true;
	// asset name
	var assetName = $('#assetName').val().trim();
	if(assetName == "" || assetName == null){
		$('.assetNameErr').show();
		$('#assetName').parent().addClass("error");
		setFlag = false;
	} 
	else {
		$('.assetNameErr').hide();
		$('#assetName').parent().removeClass("error");
	}
	
	var iChars = "`!@#$%^&*()+=-[]\\\';,./{}|\":<>?~";
	for (var i = 0; i < assetName.length; i++) {
		if (iChars.indexOf(assetName.charAt(i)) != -1) {
			$('.assetNameErr').html('Please use alphanumeric and underscore characters only for asset name').show();
			$('#assetName').parent().addClass("error");
			setFlag = false;
		}
	}
	
	//trimming white spaces and strings with empty values - chandana 21.02.2020 - #708
	var getTextfromCKeditor = $(".cke_contents iframe").contents().find("body").text();
	var trimextfromCKeditor = $.trim(getTextfromCKeditor);
	var assetDescription = CKEDITOR.instances['assetDescriptionTextarea'].getData();
	if(getTextfromCKeditor == "" || getTextfromCKeditor == null || trimextfromCKeditor == ""){
		assetDescription = "";
	}
	else{
		assetDescription = assetDescription;
	}
	/*if(assetDescription != ""){
		var data = CKEDITOR.instances['assetDescriptionTextarea'].dataProcessor.toHtml(assetDescription);

		assetDescription = data;

	}*/
	// description
	if(assetDescription == "" || assetDescription == null){
		$('.assetDescErr').show();
		$('#assetDescriptionTextarea').parent().addClass("error");
		setFlag = false;
	} 
	else {
		$('.assetDescErr').hide();
		$('#assetDescriptionTextarea').parent().removeClass("error");
	}

	// rating
	var ratingDescTextarea = $('#ratingDescTextarea').val().trim();
	if(ratingDescTextarea == "" || ratingDescTextarea == null){
		$('.ratingDescErr').show();
		$('#ratingDescTextarea').parent().addClass("error");
		setFlag = false;
	} 
	else {
		$('.ratingDescErr').hide();
		$('#ratingDescTextarea').parent().removeClass("error");
	}
	
	// file upload
	
	
	var userImage = $('input[id="uploadAssetIconButton"]').get(0).files[0];	
	
	if (typeof userImage != "undefined") {
		if(userImage != null){
			var uploadImageSize = userImage.size / 1024;
			
			if (uploadImageSize > 1024) {
				$('.assetIconExtension').hide();
				$(".assetIconDoubleExtension").hide();
				$('.asseticonName').hide();
				$('.assetIconSize').show();
				$(".assetIconSpecialName").hide();
				$('#uploadAssetIcon').parent().addClass("error");
				setFlag = false;
			} else if (userImage.type == "image/jpeg" || userImage.type == "image/png") {
				$('.asseticonName').hide();
				$(".assetIconDoubleExtension").hide();
				$('.assetIconSize').hide();
				$('.assetIconExtension').hide();
				$(".assetIconSpecialName").hide();
				$('#uploadAssetIcon').parent().removeClass("error");
			} else {
				$('.asseticonName').hide();
				$('.assetIconSize').hide();
				$(".assetIconDoubleExtension").hide();
				$('.assetIconExtension').show();
				$('#uploadAssetIcon').parent().addClass("error");
				setFlag = false;
			}
			//BOC- Double extension check- REPO-751 fix --Swathi- 28.05.2020
			var ext = userImage.name.split('.');
			var re = new RegExp("^[^<>%$#?*:|]*$");
			var specialchars = re.test(ext[0]);
			if(specialchars == false){
				$('.assetIconExtension').hide();
				$('.asseticonName').hide();
				$('.assetIconSize').hide();
				$(".assetIconDoubleExtension").show();	
				$('#uploadAssetIcon').parent().addClass("error");
				setFlag = false;
			}
			if(ext.length>2 ){
				$('.assetIconExtension').hide();
				$('.asseticonName').hide();
				$('.assetIconSize').hide();
				$(".assetIconDoubleExtension").show();	
				$('#uploadAssetIcon').parent().addClass("error");
				setFlag = false;								
			}
			//EOC
			
		}
	}
	
	/*if($('#uploadAssetIcon').val() == "" || $('#uploadAssetIcon').val() == null){
		$('.assetIconSize').hide();
		$('.assetIconExtension').hide();
		$('.asseticonName').show();
		$('#uploadAssetIcon').parent().addClass("error");
		window.scrollTo(300, 500);
		setFlag = false;
	}
	if($('#uploadAssetIcon').val() != undefined){
	if(assetIconSize > 1000){
		$('.assetIconExtension').hide();
		$('.asseticonName').hide();
		$('.assetIconSize').show();
		$('#uploadAssetIcon').parent().addClass("error");
		window.scrollTo(300, 500);
		setFlag = false;
	}
	else if (assetIconExtension != "PNG" && assetIconExtension != "png" && assetIconExtension != "JPG" && assetIconExtension != "jpg" && assetIconExtension != "JPEG" && assetIconExtension != "jpeg"){
		$('.asseticonName').hide();
		$('.assetIconSize').hide();
		$('.assetIconExtension').show();
		$('#uploadAssetIcon').parent().addClass("error");
		window.scrollTo(300, 500);
		setFlag = false;
	}
	}
	else {
		$('.asseticonName').hide();
		$('.assetIconSize').hide();
		$('.assetIconExtension').hide();
		$('#uploadAssetIcon').parent().removeClass("error");
	}*/
	
	if(setFlag == true){
	var count = 0;
	$('.categoryClass').each(function(){
		var paraCount = 0;
		if(!$(this).hasClass('deleteCategory')){
			count++;
			$(this).find('.divParamValues').each(function() { 
				if(!$(this).hasClass('deleteParam')){
					paraCount++;
				}
			});
			if(paraCount == 0){
				notifyMessage("Edit Asset","Please add at least one parameter","fail");
				setFlag = false;
			}
		}
	});
	
	if(count == 0){
		notifyMessage("Create New Asset","Please add at least one category","fail"); 
		setFlag = false;
	}
	}
	if(setFlag == false){
		$("html, body").animate({scrollTop: 0}, 10);
		return false;
		
	}
	else {
		$('#submitAddEditAssetData').click();
		return true;
	}
}

// For Edit -- Kavya
function loadDefaultAccessForNewlyCreatedInstance(){
	if(editAsset == "editAsset"){
		if(defaultAccessFlag != false){
			$.ajax({
				type : "GET",
				url : "/repopro/web/groupmanager/getallgroupsAccessForEditAsset?assetId="+editAssetId,
				dataType : "json",
				async: false,
				complete : function(data) {
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						if(json.result == "" || json.result == null){
							$('#defaultAccessDiv').hide();
							$('#noGridData').html('<div class="ui message">Default access settings for newly created instances is not configured</div>').show(); 
							$('#btnEditDefaultAccessSubmit').attr('disabled',true);
						}else {
							$('#noGridData').hide();
							$('#btnEditDefaultAccessSubmit').attr('disabled',false);
							$('#defaultAccessDiv').show();
							$('#defaultAccessDiv table tbody').html("");
							var hideShow_access = "";
							
							$.each(json.result, function(i) {
								if(json.result[i].editAccess == 0 && json.result[i].viewAccess == 0){
									hideShow_access = 0;
								}else{
									hideShow_access = 1;
								}
								appendData = getEditDefaultAccess(json.result[i].groupId,json.result[i].groupName,json.result[i].addAccess,hideShow_access,json.result[i].editAccess,json.result[i].viewAccess,json.result[i].deleteAccess);
								$('#defaultAccessDiv table tbody').append(appendData);
							});

						}
					}
				}
			});
		}
		else{
			// else condition for edit asset
			$('#defaultAccessDiv table tbody').html("");
			
			$.each(saveLocalGroupAccessForAsset, function(i) {	
				appendData = getEditDefaultAccess(saveLocalGroupAccessForAsset[i].group_id,saveLocalGroupAccessForAsset[i].group_name,saveLocalGroupAccessForAsset[i].add_access,saveLocalGroupAccessForAsset[i].hideShow_access,saveLocalGroupAccessForAsset[i].edit_access,saveLocalGroupAccessForAsset[i].view_access,saveLocalGroupAccessForAsset[i].delete_access);
				$('#defaultAccessDiv table tbody').append(appendData);
			});
		}
	
		$("#btnEditDefaultAccessSubmit").show();
		$("#btnDefaultAccessSubmit").hide();
		
		
		
	
		$('#defaultAccessDiv table tbody tr').each(function(i){
			
        	var $editTds = $(this).find('td'),
			groupId = $editTds.eq(0).text(),
			groupName = $editTds.eq(1).text();
			groupId = parseInt(groupId);

        	$('input[id=editModalAddAccess_'+groupId+']').on('click',function(){
        		
        		$('input[id=editModalHideOrShowAccess_'+groupId+']').prop("checked", true );
        		$('input[id=editModalEditAccess_'+groupId+']').prop("checked", true );
        		/*if(loggedInUserName == "admin"){
        			$('input[id=editModalDeleteAccess_'+groupId+']').prop("checked", true );
        		}
        		*/
        		
        		if($('input[id=editModalAddAccess_'+groupId+']').is(':checked')){
        			
        			$('input[id=editModalHideOrShowAccess_'+groupId+']').attr("disabled", true);
            		$('input[id=editModalEditAccess_'+groupId+']').attr("disabled", true);
     
            		$('input[id=editModalHideOrShowAccess_'+groupId+']').parent().parent().addClass('disabled cssForDisablingData');
            		$('input[id=editModalEditAccess_'+groupId+']').parent().parent().parent().addClass('disabled cssForDisablingData');
            		/*if(loggedInUserName == "admin"){
            			$('input[id=editModalDeleteAccess_'+groupId+']').attr("disabled", true);
                		$('input[id=editModalDeleteAccess_'+groupId+']').parent().parent().addClass('disabled cssForDisablingData');
            		}*/

        		}
        		else{
        			$('input[id=editModalHideOrShowAccess_'+groupId+']').attr("disabled", false);
            		$('input[id=editModalEditAccess_'+groupId+']').attr("disabled", false);
            		
            		
            		
            		$('input[id=editModalHideOrShowAccess_'+groupId+']').parent().parent().removeClass('disabled cssForDisablingData');
            		$('input[id=editModalEditAccess_'+groupId+']').parent().parent().parent().removeClass('disabled cssForDisablingData');
            		
            		/*if(loggedInUserName == "admin"){
            			$('input[id=editModalDeleteAccess_'+groupId+']').attr("disabled", false);
            			$('input[id=editModalDeleteAccess_'+groupId+']').parent().parent().removeClass('disabled cssForDisablingData');
            		}*/
        		}
			});	
			
        	
        	$('input[id=editModalHideOrShowAccess_'+groupId+']').on('click',function(){
        		
        		if($('input[id=editModalHideOrShowAccess_'+groupId+']').is(':checked')){
        			
        			$('input[id=editModalAddAccess_'+groupId+']').attr("disabled", false);
        			$('span[id=editModalreadOnlyEdit_'+groupId+']').css('display', 'block');
            		$('span[id=editModalreadOnlyEdit_NotApplicable_'+groupId+']').css('display', 'none');
        			
        			
            		$('div[id=editModalDeleteAccesCheckbox_'+groupId+']').css('display', 'inline-block');
            		$('span[id=editModaldeleteAccess_NotApplicable_'+groupId+']').css('display', 'none');
        			
            		
        		}
        		else{
        			
        			$('input[id=editModalAddAccess_'+groupId+']').attr("disabled", true);
        			$('span[id=editModalreadOnlyEdit_'+groupId+']').css('display', 'none');
            		$('span[id=editModalreadOnlyEdit_NotApplicable_'+groupId+']').css('display', 'block');
        			
        			
            		$('div[id=editModalDeleteAccesCheckbox_'+groupId+']').css('display', 'none');
            		$('span[id=editModaldeleteAccess_NotApplicable_'+groupId+']').css('display', 'block');
            		
            
        		}
        		
        	});
        	

        	
        });

		saveDefaultAccessForNewInstance();

		var $editTds = "";
		$('#btnEditDefaultAccessSubmit').on('click',function(){
			defaultAccessFlag = false;
			saveDefaultAccessForNewInstance();
			$('#groupDetailsModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
			/*$('#groupDetailsModal').modal('hide'); //.modal('hide dimmer');
			$('#groupDetailsModal').parent().css("display", "none !important");*/
		});
	}
	// add asset - default access modal
	else {
		 $("#btnDefaultAccessSubmit").show(); 
	     $("#btnEditDefaultAccessSubmit").hide();
	     
	    if(defaultAddAccessFlag != false){
	        $.ajax({
	    			type : "GET",
	    			url : "/repopro/web/groupmanager/getallgroupsAccess",
	    			dataType : "json",
	    			async: false,
	    			complete : function(data) {
	    				var json = JSON.parse(data.responseText);
	    				if(json.status == "SUCCESS"){
	    					if(json.result.length == 2){
	    						$('#defaultAccessDiv').hide();
	    						 $("#btnDefaultAccessSubmit").attr('disabled',true); 
	    						$('#noGridData').html('<div class="ui message">Default access settings for newly created instances is not configured</div>').show();; 
	    					}
	    					else {
	    						
	    						$('#noGridData').hide();
	    						$("#btnDefaultAccessSubmit").attr('disabled',false); 
	    						$('#defaultAccessDiv table tbody').html("");
	    							$.each(json.result, function(i) {
	    								appendData = getDefaultAccess(json.result[i].groupId,json.result[i].groupName);
	    								$('#defaultAccessDiv table tbody').append(appendData);
	    							});
	
	    							}
	    						}
	    					}
	    		});
	    }
	    else{
			$('#defaultAccessDiv table tbody').html("");
			$.each(saveLocalAddGroupAccessForAsset, function(i) {
				appendData = getAddDefaultAccess(saveLocalAddGroupAccessForAsset[i].group_id,saveLocalAddGroupAccessForAsset[i].group_name,saveLocalAddGroupAccessForAsset[i].add_access,saveLocalAddGroupAccessForAsset[i].hideShow_access,saveLocalAddGroupAccessForAsset[i].edit_access,saveLocalAddGroupAccessForAsset[i].view_access,saveLocalAddGroupAccessForAsset[i].delete_access);
				$('#defaultAccessDiv table tbody').append(appendData);
			});
		}
	    
        $('#defaultAccessDiv table tbody tr').each(function(i){
    			
        	 var $tds = $(this).find('td'),
             groupId = $tds.eq(0).text(),
             groupName = $tds.eq(1).text();
             groupId = parseInt(groupId);

             
            	$('input[id=addAccess_'+groupId+']').on('click',function(){
            		//console.log("shgdsahdgh");
            		$('input[id=hideOrShow_'+groupId+']').prop("checked", true );
            		$('input[id=editAccess_'+groupId+']').prop("checked", true );
            		$('input[id=viewAccess_'+groupId+']').prop("checked", true );
            		/*if(loggedInUserName == "admin"){
            			$('input[id=deleteAccess_'+groupId+']').prop("checked", true );
            		}
            		*/
            		
            		if($('input[id=addAccess_'+groupId+']').is(':checked')){
            			
            			
            			$('input[id=hideOrShow_'+groupId+']').attr("disabled", true);
                		$('input[id=editAccess_'+groupId+']').attr("disabled", true);
                		/*$('input[id=hideOrShow_'+groupId+']').parent().parent().addClass('disabled cssForDisablingData');*/
                		$('input[id=hideOrShow_'+groupId+']').parent().parent().addClass('disabled cssForDisablingData');
                		$('input[id=editAccess_'+groupId+']').parent().parent().parent().addClass('disabled cssForDisablingData');
                		/*if(loggedInUserName == "admin"){
                			$('input[id=deleteAccess_'+groupId+']').attr("disabled", true);
                			$('input[id=deleteAccess_'+groupId+']').parent().parent().addClass('disabled cssForDisablingData');
                		}*/
            		}
            		else{
            			$('input[id=hideOrShow_'+groupId+']').attr("disabled", false);
                		$('input[id=editAccess_'+groupId+']').attr("disabled", false);
                		
                		$('input[id=hideOrShow_'+groupId+']').parent().parent().removeClass('disabled cssForDisablingData');
                		$('input[id=editAccess_'+groupId+']').parent().parent().parent().removeClass('disabled cssForDisablingData');
                		
                		
                		/*if(loggedInUserName == "admin"){
                			$('input[id=deleteAccess_'+groupId+']').attr("disabled", false);
                			$('input[id=deleteAccess_'+groupId+']').parent().parent().removeClass('disabled cssForDisablingData');
                		}*/
   
            		}
    			}); 
            	
            	$('input[id=hideOrShow_'+groupId+']').on('click',function(){
            		
            		if($('input[id=hideOrShow_'+groupId+']').is(':checked')){
            	
            			$('input[id=addAccess_'+groupId+']').attr("disabled", false);
            			
            			$('span[id=addModalreadOnlyEdit_'+groupId+']').css('display', 'block');
                		$('span[id=addModalreadOnlyEdit_NotApplicable_'+groupId+']').css('display', 'none');
            			
                		
                		$('div[id=addModalDeleteAcces_'+groupId+']').css('display', 'inline-block');
                		$('span[id=addModaldeleteAccess_NotApplicable_'+groupId+']').css('display', 'none');
            			
     
                	
            		}
            		else{
            			
            			$('input[id=addAccess_'+groupId+']').attr("disabled", true);
            			$('span[id=addModalreadOnlyEdit_'+groupId+']').css('display', 'none');
                		$('span[id=addModalreadOnlyEdit_NotApplicable_'+groupId+']').css('display', 'block');
            			
                		
                		
                		$('div[id=addModalDeleteAcces_'+groupId+']').css('display', 'none');
                		$('span[id=addModaldeleteAccess_NotApplicable_'+groupId+']').css('display', 'block');
                		
            		}
            		
            	});

            });

        
        
    	saveAddDefaultAccessForNewInstance();

    	 var $tds = "";
		$('#btnDefaultAccessSubmit').on('click',function(){
			defaultAddAccessFlag = false;
			saveAddDefaultAccessForNewInstance();
			$('#groupDetailsModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
		});

 }
}

var appData = "";
function loadManageAssetData(){
	 //if(categoryObjArr = 0) ajax add into categoryObjArr and loop categoryObjArr and display in modal
	 //else {loop categoryObjArr and display in modal} 
	//console.log("/repopro/web/assetType/CategoryaccessbyAssetid?assetId="+editAssetId);
	if(localSaveManageAssetFlag != false){
	 $.ajax({
			type : "GET",
			url : "/repopro/web/assetType/CategoryaccessbyAssetid?assetId="+editAssetId,
			dataType : "json",
			async: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				//console.log("json 143 : " + JSON.stringify(json));
				if(json.status == "SUCCESS"){
					var categoryId;
					var categoryValues;
					var categoryName;
					var cnt = 0;
					appData = "";
					if(json.categoryValues == "" || json.categoryValues == null){
						$('#btnManageAccessSave').attr('disabled',true);
						$('.catWiseTable').hide();
						$('.noCatWiseData').show();
					}
					else {
						$('#btnManageAccessSave').attr('disabled',false);
						$('.noCatWiseData').hide();
						$('.catWiseTable').show();
						//console.log("str : " + JSON.stringify(json.categoryValues));
					$.each(json.categoryValues, function(key, value){	
						categoryName = value[cnt].categoryName;

						if(categoryName != "DUMMY_CATEGORY"){
							appData += "<tr id='trCategoryAccess_"+key+"'>"
							appData += "<td class='manageAssetName'>"+categoryName+"</td>";
							appData += "<td>";

							if (!!navigator.userAgent.match(/Trident\/7\./)){
								appData += "<div class='loopCategoryWiseAccessGrid'>";
								/*appData += "<div class='eight wide column div_AssociatedGroups'><b>Associated Groups</b></div>";
								appData += "<div class='four wide column div_Visibility'><b>Visibility</b></div>";
								appData += "<div class='four wide column div_Editable'><b>Editable</b></div>";*/


								$.each(value, function(i){
									var grpId = value[i].groupId; 
									var grpName = value[i].groupName;  
									var mappedWithUser = value[i].mappedWithUser;
									var editAccess = value[i].editAccess;

									//Group Name
									appData += "<div class='getAssociatedGroupName' id='associatedGroupName_"+grpId+"_"+grpName+"_"+autoIdCreatorForCategoryWiseAccess+"' style='width: 57%; margin-top: 1rem;'>"+grpName+"</div>";

									// Visibility - show / hide
									if(mappedWithUser == true){
										appData += "<div class='getShowHideValue' id='getGrpIdForShowHide_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-top: -2rem; margin-right: 24rem; float: right;'>";
										appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor showHideClass' id='div_showHideColumn_"+grpId+"'>";
										appData += "<input type='checkbox' id='showHideChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' class='classForShowHideChck_"+autoIdCreatorForCategoryWiseAccess+"' checked onclick='showNotApplicationLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
										appData += "</div>";
										appData += "</div>";
									}
									else {
										appData += "<div class='getShowHideValue' id='getGrpIdForShowHide_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-top: -2rem; margin-right: 24rem; float: right;'>";
										appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor showHideClass' id='div_showHideColumn_"+grpId+"'>";
										appData += "<input type='checkbox' id='showHideChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' class='classForShowHideChck_"+autoIdCreatorForCategoryWiseAccess+"' onclick='showNotApplicationLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
										appData += "</div>";
										appData += "</div>";
									}


									// Editable - edit / view
									if(value[i].groupName == "Guest"){
										appData += "<div class='getEditViewValue' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-right: -20.5rem; float: right; display: inline; margin-top: -2rem;'>";
										appData += "<div class='editViewClass'id="+grpId+">";
										appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"' style='display:none;'>";
										appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'><label></label>";
										appData += "</div>";
										appData += "<div id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"' style='display: inline;margin-right: 2.5em;'>N/A</div>";
										appData += "</div>";
										appData += "</div>";
									}else {
										if(mappedWithUser == true){
											if(editAccess == 1){
												/*appData += "<p><div class='editViewClass'id="+grpId+"><div class='ui fitted toggle checkbox toggleCheckBoxColor' id='div_viewEditColumn_"+grpId+"'><input type='checkbox' name='example' id='viewEditChck_"+grpId+"' checked><label></label></div><span style='display:none;' id='span_NotApplicable_"+grpId+"'>N/A</span></div></p>";*/
												appData += "<div class='getEditViewValue' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-right: -20.5rem; float: right; display: inline; margin-top: -2rem;'>";
												appData += "<div class='editViewClass'id="+grpId+">";
												appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"'>";
												appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' checked onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
												appData += "</div>";
												appData += "<div style='display:none;' id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</div>";
												appData += "</div>";
												appData += "</div>";


											}else {
												appData += "<div class='getEditViewValue' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-right: -20.5rem; float: right; display: inline; margin-top: -2rem;'>";
												appData += "<div class='editViewClass'id="+grpId+">";
												
												appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"'>";
												appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
												appData += "</div>";
												
												appData += "<div style='display:none;' id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</div>";
												appData += "</div>";
												appData += "</div>";
											}

										}else{
											appData += "<div class='getEditViewValue' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-right: -20.5rem; float: right; display: inline; margin-top: -2rem;'>";
											appData += "<div class='editViewClass'id="+grpId+">";
											//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Read Only</span>";
											appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"' style='display:none;'>";
											appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
											appData += "</div>";
											//appData += "<span class='categoryWiseHideShow' id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Edit</span>";
											appData += "<div id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"' style='display:inline;margin-right: 2.5em;'>N/A</div>";
											appData += "</div>";
											appData += "</div>";
										}
									}
									autoIdCreatorForCategoryWiseAccess = Math.floor((Math.random() * 1000000) + 1);

								});

								appData += "</div>";
							}else{
								appData += "<div class='ui grid loopCategoryWiseAccessGrid'>";
								/*appData += "<div class='eight wide column div_AssociatedGroups'><b>Associated Groups</b></div>";
								appData += "<div class='four wide column div_Visibility'><b>Visibility</b></div>";
								appData += "<div class='four wide column div_Editable'><b>Editable</b></div>";*/

								$.each(value, function(i){
									var grpId = value[i].groupId; 
									var grpName = value[i].groupName;  
									var mappedWithUser = value[i].mappedWithUser;
									var editAccess = value[i].editAccess;

									//Group Name
									appData += "<div class='seven wide column getAssociatedGroupName' id='associatedGroupName_"+grpId+"_"+grpName+"_"+autoIdCreatorForCategoryWiseAccess+"'>"+grpName+"</div>";

									// Visibility - show / hide
									if(mappedWithUser == true){
										appData += "<div class='four wide column getShowHideValue center aligned' id='getGrpIdForShowHide_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
										//appData += "<span class='categoryWiseHideShow' id='catWiseHideAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display: none;'>Hide</span>";
										appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor showHideClass' id='div_showHideColumn_"+grpId+"'>";
										appData += "<input type='checkbox' id='showHideChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' class='classForShowHideChck_"+autoIdCreatorForCategoryWiseAccess+" groupAdmin' checked onclick='showNotApplicationLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
										appData += "</div>";
										//appData += "<span class='categoryWiseHideShow' id='catWiseShowAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>Show</span>";
										appData += "</div>";
									}
									else {
										appData += "<div class='four wide column getShowHideValue center aligned' id='getGrpIdForShowHide_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
										//appData += "<span class='categoryWiseHideShow' id='catWiseHideAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>Hide</span>";
										appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor showHideClass' id='div_showHideColumn_"+grpId+"'>";
										appData += "<input type='checkbox' id='showHideChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' class='classForShowHideChck_"+autoIdCreatorForCategoryWiseAccess+" guestUser' onclick='showNotApplicationLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
										appData += "</div>";
										//appData += "<span class='categoryWiseHideShow' id='catWiseShowAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display: none;'>Show</span>";
										appData += "</div>";
									}


									// Editable - edit / view
									// Editable - edit / view
									if(value[i].groupName == "Guest"){
										appData += "<div class='five wide column getEditViewValue posCatwiseNotApplicable center aligned hideForGuestUserAccess' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
										appData += "<div class='editViewClass' id="+grpId+">";
										/*appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"' style='display:none;'>Read</span>";*/
										appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"' style='display:none;'>";
										appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'><label></label>";
										appData += "</div>";
										/*appData += "<span class='categoryWiseHideShow'id='editCheck_"+grpId+"' style='display:none;'>Edit</span>";*/
										appData += "<span id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</span>";
										appData += "</div>";
										appData += "</div>";
									}
									else{								
										if(mappedWithUser == true){
										if(editAccess == 1){
											/*appData += "<p><div class='editViewClass'id="+grpId+"><div class='ui fitted toggle checkbox toggleCheckBoxColor' id='div_viewEditColumn_"+grpId+"'><input type='checkbox' name='example' id='viewEditChck_"+grpId+"' checked><label></label></div><span style='display:none;' id='span_NotApplicable_"+grpId+"'>N/A</span></div></p>";*/
											appData += "<div class='five wide column getEditViewValue center aligned' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
											appData += "<div class='editViewClass'id="+grpId+">";
											//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Read Only</span>";
											appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"'>";
											appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' checked onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
											appData += "</div>";
											//appData += "<span class='categoryWiseHideShow' id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:inline-block;'>Edit</span>";
											appData += "<span style='display:none;' id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</span>";
											appData += "</div>";
											appData += "</div>";


										}else {
											appData += "<div class='five wide column getEditViewValue center aligned' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
											appData += "<div class='editViewClass'id="+grpId+">";
											//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:inline-block;'>Read Only</span>";
											appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"'>";
											appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
											appData += "</div>";
											//appData += "<span class='categoryWiseHideShow' id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Edit</span>";
											appData += "<span style='display:none;' id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</span>";
											appData += "</div>";
											appData += "</div>";
										}

									}else{
										appData += "<div class='five wide column getEditViewValue posCatwiseNotApplicable center aligned' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
										appData += "<div class='editViewClass'id="+grpId+">";
										//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Read Only</span>";
										appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"' style='display:none;'>";
										appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
										appData += "</div>";
										//appData += "<span class='categoryWiseHideShow' id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Edit</span>";
										appData += "<span id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</span>";
										appData += "</div>";
										appData += "</div>";
									}
									
								}
									autoIdCreatorForCategoryWiseAccess = Math.floor((Math.random() * 1000000) + 1);

								});

								appData += "</div>";

							}
							
							appData += "</td>";
							
		
						}
						
						
					});
					cnt++;
					appData += "</tr>";
					$('#categoryAccessDiv table tbody').html('');
					$('#categoryAccessDiv table tbody').append(appData);
					
					 if (!!navigator.userAgent.match(/Trident\/7\./)){
						 var abc = "<div class='div_AssociatedGroups' style='width: 10rem !important;'><b>Group Name</b></div><div class='div_Visibility' style='width: 10em !important; margin-top: -19px; margin-right: 25em !important; float: right;'><b>Visibility</b></div><div class='div_Editable' style='width: 10em !important; margin-top: -18px; margin-right: 4em !important; float: right;'><b>Edit Access</b></div>";
						 $('#categoryAccessDiv table tbody tr:first .loopCategoryWiseAccessGrid').prepend(abc);
					 }
					 else {
						 var abc = "<div class='seven wide column div_AssociatedGroups headerColorForCatWiseAccess'>Group Name</div><div class='four wide column div_Visibility headerColorForCatWiseAccess center aligned'>Visibility</div><div class='four wide column div_Editable cssForEditable center aligned' style='width: 29.8% !important;'>Edit Access</div>";
						 $('#categoryAccessDiv table tbody tr:first .loopCategoryWiseAccessGrid').prepend(abc);
					 }

					
				}
					
				}
			}
		});
	}
	else{
		var cnt = 0;
		appData = "";
		Object.keys(categoryObj).forEach(function(key){
			    var value = categoryObj[key];
			    var data = value;
			    var jo = $.parseJSON(data);
			    categoryName = jo[cnt].categoryName;
				
			    
			    
				appData += "<tr id='trCategoryAccess_"+key+"'>"
				appData += "<td class='manageAssetName'>"+categoryName+"</td>";
				appData += "<td>";
				
				if (!!navigator.userAgent.match(/Trident\/7\./)){
					appData += "<div class='loopCategoryWiseAccessGrid'>";

					$.each(value, function(i){
						var grpId = jo[i].groupId; 
						var grpName = jo[i].groupName;  
						var mappedWithUser = jo[i].mappedWithUser;
						var editAccess = jo[i].edit_access;

						//Group Name
						appData += "<div class='getAssociatedGroupName' id='associatedGroupName_"+grpId+"_"+grpName+"_"+autoIdCreatorForCategoryWiseAccess+"' style='width: 57%; margin-top: 1rem;'>"+grpName+"</div>";

						// Visibility - show / hide
						if(mappedWithUser == true){
							appData += "<div class='getShowHideValue' id='getGrpIdForShowHide_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-top: -2rem; margin-right: 24rem; float: right;'>";
							//appData += "<span class='categoryWiseHideShow' id='catWiseHideAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display: none;'>Hide</span>";
							appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor showHideClass' id='div_showHideColumn_"+grpId+"'>";
							appData += "<input type='checkbox' id='showHideChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' class='classForShowHideChck_"+autoIdCreatorForCategoryWiseAccess+"' checked onclick='showNotApplicationLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
							appData += "</div>";
							//appData += "<span class='categoryWiseHideShow' id='catWiseShowAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>Show</span>";
							appData += "</div>";
						}
						else {
							appData += "<div class='getShowHideValue' id='getGrpIdForShowHide_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-top: -2rem; margin-right: 24rem; float: right;'>";
							//appData += "<span class='categoryWiseHideShow' id='catWiseHideAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>Hide</span>";
							appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor showHideClass' id='div_showHideColumn_"+grpId+"'>";
							appData += "<input type='checkbox' id='showHideChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' class='classForShowHideChck_"+autoIdCreatorForCategoryWiseAccess+"' onclick='showNotApplicationLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
							appData += "</div>";
							//appData += "<span class='categoryWiseHideShow' id='catWiseShowAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display: none;'>Show</span>";
							appData += "</div>";
						}


						// Editable - edit / view
						if(value[i].groupName == "Guest"){
							appData += "<div class='getEditViewValue' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-right: -20.5rem; float: right; display: inline; margin-top: -2rem;'>";
							appData += "<div class='editViewClass'id="+grpId+">";
							/*appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"' style='display:none;'>Read</span>";*/
							appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"' style='display:none;'>";
							appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'><label></label>";
							appData += "</div>";
							/*appData += "<span class='categoryWiseHideShow'id='editCheck_"+grpId+"' style='display:none;'>Edit</span>";*/
							appData += "<div id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"' style='display: inline;margin-right: 2.5em;'>N/A</div>";
							appData += "</div>";
							appData += "</div>";
						}else {
							if(mappedWithUser == true){
								if(editAccess == 1){
									/*appData += "<p><div class='editViewClass'id="+grpId+"><div class='ui fitted toggle checkbox toggleCheckBoxColor' id='div_viewEditColumn_"+grpId+"'><input type='checkbox' name='example' id='viewEditChck_"+grpId+"' checked><label></label></div><span style='display:none;' id='span_NotApplicable_"+grpId+"'>N/A</span></div></p>";*/
									appData += "<div class='getEditViewValue' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-right: -22.5rem; float: right; display: inline; margin-top: -2rem;'>";
									appData += "<div class='editViewClass'id="+grpId+">";
									//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Read Only</span>";
									appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"'>";
									appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' checked onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
									appData += "</div>";
									//appData += "<span class='categoryWiseHideShow' id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:inline-block;'>Edit</span>";
									appData += "<div style='display:none;' id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</div>";
									appData += "</div>";
									appData += "</div>";


								}else {
									appData += "<div class='getEditViewValue' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-right: -22.5rem; float: right; display: inline; margin-top: -2rem;'>";
									appData += "<div class='editViewClass'id="+grpId+">";
									//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:inline-block;'>Read Only</span>";
									appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"'>";
									appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
									appData += "</div>";
									//appData += "<span class='categoryWiseHideShow' id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Edit</span>";
									appData += "<div style='display:none;' id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</div>";
									appData += "</div>";
									appData += "</div>";
								}

							}else{
								appData += "<div class='getEditViewValue' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='margin-right: -22.5rem; float: right; display: inline; margin-top: -2rem;'>";
								appData += "<div class='editViewClass'id="+grpId+">";
								//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Read Only</span>";
								appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"' style='display:none;'>";
								appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
								appData += "</div>";
								//appData += "<span class='categoryWiseHideShow' id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Edit</span>";
								appData += "<div id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"' style='display: inline;margin-right: 2.5em;'>N/A</div>";
								appData += "</div>";
								appData += "</div>";
							}
						}
						autoIdCreatorForCategoryWiseAccess = Math.floor((Math.random() * 1000000) + 1);

					});

					appData += "</div>";
				}else {
					appData += "<div class='ui grid loopCategoryWiseAccessGrid'>";

					$.each(jo, function(i){
						var grpId = jo[i].groupId; 
						var grpName = jo[i].groupName;  
						var mappedWithUser = jo[i].mappedWithUser;
						var editAccess = jo[i].edit_access;
						//Group Name
						appData += "<div class='seven wide column getAssociatedGroupName' id='associatedGroupName_"+grpId+"_"+grpName+"_"+autoIdCreatorForCategoryWiseAccess+"'>"+grpName+"</div>";

						// Visibility - show / hide
						if(mappedWithUser == true){
							appData += "<div class='four wide column getShowHideValue center aligned' id='getGrpIdForShowHide_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
							//appData += "<span class='categoryWiseHideShow' id='catWiseHideAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display: none;'>Hide</span>";
							appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor showHideClass' id='div_showHideColumn_"+grpId+"'>";
							appData += "<input type='checkbox' id='showHideChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' class='classForShowHideChck_"+autoIdCreatorForCategoryWiseAccess+"' checked onclick='showNotApplicationLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+jo[i].groupName+"\");'><label></label>";
							appData += "</div>";
							//appData += "<span class='categoryWiseHideShow' id='catWiseShowAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>Show</span>";
							appData += "</div>";


						}
						else {
							appData += "<div class='four wide column getShowHideValue center aligned' id='getGrpIdForShowHide_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
							//appData += "<span class='categoryWiseHideShow' id='catWiseHideAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>Hide</span>";
							appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor showHideClass' id='div_showHideColumn_"+grpId+"'>";
							appData += "<input type='checkbox' id='showHideChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' class='classForShowHideChck_"+autoIdCreatorForCategoryWiseAccess+"' onclick='showNotApplicationLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+jo[i].groupName+"\");'><label></label>";
							appData += "</div>";
							//appData += "<span class='categoryWiseHideShow' id='catWiseShowAccess_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display: none;'>Show</span>";
							appData += "</div>";
						}


						// Editable - edit / view
						if(jo[i].groupName == "Guest"){
							appData += "<div class='five wide column getEditViewValue posCatwiseNotApplicable center aligned' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
							appData += "<div class='editViewClass'id="+grpId+">";
							/*appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"' style='display:none;'>Read</span>";*/
							appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"' style='display:none;'>";
							appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'><label></label>";
							appData += "</div>";
							/*appData += "<span class='categoryWiseHideShow'id='editCheck_"+grpId+"' style='display:none;'>Edit</span>";*/
							appData += "<span id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</span>";
							appData += "</div>";
							appData += "</div>";
						}else {
							if(mappedWithUser == true){
								if(editAccess == 1){
									/*appData += "<p><div class='editViewClass'id="+grpId+"><div class='ui fitted toggle checkbox toggleCheckBoxColor' id='div_viewEditColumn_"+grpId+"'><input type='checkbox' name='example' id='viewEditChck_"+grpId+"' checked><label></label></div><span style='display:none;' id='span_NotApplicable_"+grpId+"'>N/A</span></div></p>";*/
									appData += "<div class='five wide column getEditViewValue center aligned' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
									appData += "<div class='editViewClass'id="+grpId+">";
									//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Read Only</span>";
									appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"'>";
									appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' checked onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
									appData += "</div>";
									//appData += "<span class='categoryWiseHideShow' id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:inline-block;'>Edit</span>";
									appData += "<span style='display:none;' id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</span>";
									appData += "</div>";
									appData += "</div>";


								}else {
									appData += "<div class='five wide column getEditViewValue center aligned' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
									appData += "<div class='editViewClass'id="+grpId+">";
									//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:inline-block;'>Read Only</span>";
									appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"'>";
									appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
									appData += "</div>";
									//appData += "<span class='categoryWiseHideShow' id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Edit</span>";
									appData += "<span style='display:none;' id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</span>";
									appData += "</div>";
									appData += "</div>";
								}

							}else{
								appData += "<div class='five wide column getEditViewValue posCatwiseNotApplicable center aligned' id='getGrpIdForEditView_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"'>";
								appData += "<div class='editViewClass'id="+grpId+">";
								//appData += "<span class='categoryWiseHideShow' id='readOnly_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Read Only</span>";
								appData += "<div class='ui fitted toggle checkbox toggleCheckBoxColor classForViewEdit_"+autoIdCreatorForCategoryWiseAccess+"' id='div_viewEditColumn_"+grpId+"' style='display:none;'>";
								appData += "<input type='checkbox' id='viewEditChck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' onclick='readOnlyEditLabel("+grpId+","+autoIdCreatorForCategoryWiseAccess+",\""+value[i].groupName+"\");'><label></label>";
								appData += "</div>";
								//appData += "<span class='categoryWiseHideShow'id='editCheck_"+grpId+"_"+autoIdCreatorForCategoryWiseAccess+"' style='display:none;'>Edit</span>";
								appData += "<span id='span_NotApplicable_"+grpId+"' class='classForNotApplicable_"+autoIdCreatorForCategoryWiseAccess+"'>N/A</span>";
								appData += "</div>";
								appData += "</div>";
							}
						}
						autoIdCreatorForCategoryWiseAccess = Math.floor((Math.random() * 1000000) + 1);

					});

					appData += "</div>";
				}
				appData += "</td>";
				
		});
		 cnt++;
		 appData += "</tr>";
		 $('#categoryAccessDiv table tbody').html('');
		// console.log("appData  second : " + appData);
		 $('#categoryAccessDiv table tbody').append(appData);
		 
		 if (!!navigator.userAgent.match(/Trident\/7\./)){
			 var abc = "<div class='div_AssociatedGroups' style='width: 10rem !important;'><b>Group Name</b></div><div class='div_Visibility' style='width: 10em !important; margin-top: -19px; margin-right: 25em !important; float: right;'><b>Visibility</b></div><div class='div_Editable' style='width: 10em !important; margin-top: -18px; margin-right: 4em !important; float: right;'><b>Edit Access</b></div>";
			 $('#categoryAccessDiv table tbody tr:first .loopCategoryWiseAccessGrid').prepend(abc);
		 }
		 else {
			 var abc = "<div class='seven wide column div_AssociatedGroups headerColorForCatWiseAccess'>Group Name</div><div class='four wide column div_Visibility headerColorForCatWiseAccess center aligned'>Visibility</div><div class='four wide column div_Editable cssForEditable center aligned' style='width: 29.8% !important;'>Edit Access</div>";
			 $('#categoryAccessDiv table tbody tr:first .loopCategoryWiseAccessGrid').prepend(abc);
		 }

	}
	
	 
	 if(manageAssetFlag != false){
		saveManageAsset();
	 }
	 
		//Chandana -- 13/8/2019 hide and show of guest user 
		$.ajax({
			type : "GET",
			url : "/repopro/web/globalsettings",
			dataType : "json",
			async: false,
			cache: false,
			complete : function(data) {
				var json = JSON.parse(data.responseText);
				var hideVisibilityAccessGU = $('.hideForGuestUserAccess').prev();
				var hideGUgroupName = $(hideVisibilityAccessGU).prev();
			
							if(json.result[0].guestAccess == 0){
								$(".hideForGuestUserAccess").hide();
								$(hideVisibilityAccessGU).hide();
								$(hideGUgroupName).hide();
							}
							else{
								$(".hideForGuestUserAccess").show();
								$(hideVisibilityAccessGU).show();
								$(hideGUgroupName).show();
							}	
					}
			});
		
		
	// else {
		/*$('#btnManageAccessSave').on('click',function(){
			localSaveManageAssetFlag = false;
			saveManageAsset();
			$('#categoryWiseManageAccessModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
			$('#categoryWiseManageAccessModal').modal('hide'); //.modal('hide dimmer');
			$('#categoryWiseManageAccessModal').parent().css("display", "none !important");
		});*/
	// }
}

		function saveCategoryWiseAccessData(){
			localSaveManageAssetFlag = false;
			saveManageAsset();
			$('#categoryWiseManageAccessModal').dimmer('hide').modal('hide others').modal('hide'); //.modal('hide dimmer');
		}

  function saveDefaultAccessForNewInstance(){
	  editGroupAccessForAsset.length = 0;
	  saveLocalGroupAccessForAsset.length = 0;
	  
		$('#defaultAccessDiv table tbody tr').each(function(i){
			var $editTds = $(this).find('td'),
			groupId = $editTds.eq(0).text(),
			groupName = $editTds.eq(1).text();
			groupId = parseInt(groupId);
			var addAccess = "";
			var hideShowAccess = "";
			var editAccess = "";
			var viewAccess = "";
			var deleteAccess = "";
			
				// add Access checkbox
				if ($('input[id=editModalAddAccess_'+groupId+']').is(':checked')) {
					addAccess = 1;
					hideShowAccess = 1;
					editAccess = 1;
					viewAccess = 1;
					if ($('input[id=editModalDeleteAccess_'+groupId+']').is(':checked')) {
	           			 deleteAccess = 1;
	           		 }else{
	           			 deleteAccess = 0;
	           		 } 
					/*if(loggedInUserName == "admin"){
						deleteAccess = 1;
					}
					else{
						if ($('input[id=editModalDeleteAccess_'+groupId+']').is(':checked')) {
	            			 deleteAccess = 1;
	            		 }else{
	            			 deleteAccess = 0;
	            		 } 
						
					}*/
					

				} 
				 else{
	    			 addAccess = 0;
	    			 if ($('input[id=editModalHideOrShowAccess_'+groupId+']').is(':checked')) {
	        			 hideShowAccess = 1;
	        			 viewAccess = 1;
	        			 editAccess = 0;
	        			 
	        			 if ($('input[id=editModalEditAccess_'+groupId+']').is(':checked')) {
	            			 editAccess = 1;
	            			 viewAccess = 1;
	            		 } 
	        			 
	        			 if ($('input[id=editModalDeleteAccess_'+groupId+']').is(':checked')) {
	            			 deleteAccess = 1;
	            		 } 
	            		 else{
	            			 deleteAccess = 0;
	            		 }
	        			 
	        			 
	        		 } 
	        		 else{
	        			 hideShowAccess = 0;
	        			 editAccess = 0;//N/a
	        			 viewAccess = 0;//N/a
	        			 deleteAccess = 0;//N/a
	        		 }
    		 }


				editGroupAccessForAsset.push({
					"group_id": groupId,
					"add_access":addAccess,
					"edit_access":editAccess,
					"view_access":viewAccess,
					"delete_access":deleteAccess
				});
				//console.log(" editGroupAccessForAsset  "+JSON.stringify(editGroupAccessForAsset));
				saveLocalGroupAccessForAsset.push({
					"group_id": groupId,
					"group_name":groupName,
					"add_access":addAccess,
					"hideShow_access":hideShowAccess,
					"edit_access":editAccess,
					"view_access":viewAccess,
					"delete_access":deleteAccess
				});
		});
  }
  
  // save data for add asset
  function saveAddDefaultAccessForNewInstance(){
	      groupAccessForAsset.length = 0;
		  saveLocalAddGroupAccessForAsset.length = 0;

	    	$('#defaultAccessDiv table tbody tr').each(function(i){
	    		 var $tds = $(this).find('td'),
	             groupId = $tds.eq(0).text(),
	             groupName = $tds.eq(1).text();
	             var addAccess = "";
	             var hideShowAccess = "";
	             var editAccess = "";
	             var viewAccess = "";
	             var deleteAccess = "";
	             groupId = parseInt(groupId);
	             
	             // add Access checkbox
	    		 if ($('input[id=addAccess_'+groupId+']').is(':checked')) {
	    			 addAccess = 1;
	    			 hideShowAccess = 1;
	    			 editAccess = 1;
	    			 viewAccess = 1;
	    			
    				 if ($('input[id=deleteAccess_'+groupId+']').is(':checked')) {
            			 deleteAccess = 1;
            		 } 
            		 else{
            			 deleteAccess = 0;
            		 }
	    			
	    			 
	    		 } 
	    		 else{
		    			 addAccess = 0;
		    			 if ($('input[id=hideOrShow_'+groupId+']').is(':checked')) {
		        			 hideShowAccess = 1;
		        			 viewAccess = 1;
		        			 editAccess = 0;
		        			 
		        			 if ($('input[id=editAccess_'+groupId+']').is(':checked')) {
		            			 editAccess = 1;
		            			 viewAccess = 1;
		            		 } 
		        			 
		        			 if ($('input[id=deleteAccess_'+groupId+']').is(':checked')) {
		            			 deleteAccess = 1;
		            		 } 
		            		 else{
		            			 deleteAccess = 0;
		            		 }
		        			 
		        			 
		        		 } 
		        		 else{
		        			 hideShowAccess = 0;
		        			 editAccess = 0;//N/a
		        			 viewAccess = 0;//N/a
		        			 deleteAccess = 0;//N/a
		        		 }
	    		 }

	    		 groupAccessForAsset.push({
	    			 "group_id": groupId,
	    			 "add_access":addAccess,
	    			 "edit_access":editAccess,
	    			 "view_access":viewAccess,
	    			 "delete_access":deleteAccess
	     		 });
	    		 
	    		//console.log(" groupAccessForAsset  "+JSON.stringify(groupAccessForAsset));
	         	saveLocalAddGroupAccessForAsset.push({
	    			 "group_id": groupId,
	    			 "group_name": groupName,
	    			 "add_access":addAccess,
	    			 "hideShow_access":hideShowAccess,
	    			 "edit_access":editAccess,
	    			 "view_access":viewAccess,
	    			 "delete_access":deleteAccess
	     		 });
	         	
	    	});
	  }

  var categoryAccessStr = ""; 
  var arr1 = [];
	var arr2 = [];
	var arr3 = [];
	var arr4 = [];
  function saveManageAsset(){
	  	categoriesWithAccess.length = 0;
		categoryObjArr.length = 0;
		categoryObj = {};
		
		arr1.length = 0;
		 arr2.length = 0;
		 arr3.length = 0;
		 arr4.length = 0;
		
		$('#categoryAccessDiv table tbody tr').each(function(i){
			
			categoriesWithAccess.length = 0;
			arr1.length = 0;
			 arr2.length = 0;
			 arr3.length = 0;
			 arr4.length = 0;
			 

			var key =  $(this).attr("id");
			key = key.split("_")[1]

			var categoryName = $(this).find('td.manageAssetName').text();
			var grpId_grpName;
			var grpId = "";
			var grpName = "";
			
			// get grpId and grpName
			$(this).find(".getAssociatedGroupName").each(function(){
				var grpId_grpName = $(this).attr('id');
				grpId_grpName = grpId_grpName.split("_");
				grpId = grpId_grpName[1];
				grpName = grpId_grpName[2];
				arr1.push(grpId);
				arr2.push(grpName);
			});
			
			// get mapped user - show Hide
			var mappedWithUser = false;
			
			var getShowHideValue = $(this).find(".getShowHideValue").attr('id');
			getShowHideValue = getShowHideValue.split("_");
			$(this).find(".getShowHideValue").each(function(){
			//$('#getGrpIdForShowHide_'+getShowHideValue[1]+'_'+getShowHideValue[2]).each(function(){
				var grpId_ShowHide = $(this).attr('id');
				grpId_ShowHide = grpId_ShowHide.split("_");
				//grpId = grpId_ShowHide[1];
				//var autoId = grpId_ShowHide[2];
				if($('#showHideChck_'+grpId_ShowHide[1]+'_'+grpId_ShowHide[2]).is(":checked")){
					mappedWithUser = true;
				}
				else {
					mappedWithUser = false;                 
				}
				arr3.push(mappedWithUser);
				
			});
			
			//console.log("mappedWithUser : " + arr3);
			// get show view access
			
			$(this).find(".getEditViewValue").each(function(){
				var viewEdit;
				var grpId_EditView = $(this).attr('id');
				grpId_EditView = grpId_EditView.split("_");
				//grpId = grpId_EditView[1];
				
				if($('#viewEditChck_'+grpId_EditView[1]+'_'+grpId_EditView[2]).is(":checked")){
					viewEdit = 1;
				}
				else {
					viewEdit = 0;                 
				}
				arr4.push(viewEdit);
				
			});
			
			 //console.log("viewEdit : " + arr4);
			
			//console.log("arr1 : " + arr1);
			$.each(arr1,function(i){
			categoriesWithAccess.push({
				"associatedRoleIds": null,
				"categoryName": categoryName,
				//"description": desc,
				"groupId": arr1[i],
				"groupName": arr2[i],
				"groupRolesId": null,
				"mappedWithUser": arr3[i],
				"roleId": null,
				"edit_access" : arr4[i]
			});
			
			//console.log("one -  :  " + JSON.stringify(categoriesWithAccess.slice()));
			
			categoryObj[key] = JSON.stringify(categoriesWithAccess);
			
		});
		});
		
		// console.log("final two  -  :  " + JSON.stringify(categoryObj));
		 categoryObjArr.push(categoryObj);
		 var b = JSON.stringify(categoryObjArr);
		 categoryAccessStr = "";
		 categoryAccessStr = b.replace(/\\/g, '').replace(/\"\[/g,'[').replace(/\]\"/g,']');
		 //console.log("categoryAccessStr 143_____: " + JSON.stringify(categoryAccessStr));
}
  
  /*$('iframe#iframeForAssetDataIdAttr').load(function() {
	  var json = JSON.parse($("#iframeForAssetDataIdAttr").contents().find("pre").html());
	 // console.log("json : " + JSON.stringify(json));
	  if(json.status == "SUCCESS"){
		   $('#showHideLoader').addClass('active');
		   $("#iframeForAssetDataIdAttr html body pre").html("");
		   $('body').load('index.html');
		   getAssetsDetails(); 
		   setTimeout(function(){
			   if (editAsset == "editAsset") {
				   notifyMessage("Manage Asset","Asset details are updated successfully","success");
			   }else{
				   notifyMessage("Manage Asset","New asset details are created successfully","success"); 
			   }
		   }, 500)
		   $('#showHideLoader').removeClass('active');
	  }
	  else{
		  notifyMessage("Manage Asset",json.result,"fail");
	  }
	  addedTaxonomyArr.length = 0;
	 });*/
  
  
  
  //function hasStaticOnclick(){ // commented by aditya 06.03.18
  function hasStaticOnclick(obj){
	  
	  	//if($(obj).is(":checked")){//
	  if($('.toggleCheckBoxColor.ui.toggle.checkbox > input[type="checkbox"]#hasStaticValueYes').is(":checked") || $("#hasStaticValueYes").is(":checked")){
			$('#isArrayCheckbox').attr('checked', false);
			//console.log("checked in hasStaticOnclick :: "+($(obj).is(":checked"))+ " *** : "+Math.random());
			$("#importantYes").prop("disabled", true);
			$("#isArrayCheckbox").prop("disabled", true);
			
			$("label[for='is_imprtnt']").addClass('changeLableColor');
			$('.toggleCheckBoxColor.ui.toggle.checkbox > input[type="checkbox"]#importantYes').attr("checked",false);
		}else {
			//console.log("checked in hasStaticOnclick :: "+($(obj).is(":checked"))+ " *** : "+Math.random());
			$("label[for='is_imprtnt']").removeClass('changeLableColor');
			//$('#importantParamPerent').show();
			$("#importantYes").prop("disabled", false);
			var paramValueDropdown = $('#ddParamType option:selected').val();
			if(paramValueDropdown == 7 || paramValueDropdown == 1){
				//$('.field.isArrayParam').show();
				$("#isArrayCheckbox").prop("disabled", false);
				
			}else {
				//$('.field.isArrayParam').hide();
				$("#isArrayCheckbox").prop("disabled", true);
			}
		}
	}


	function edit_hasStaticOnclick(){
		
		//console.log("checked in edit_hasStaticOnclick-- 1  :: "+($('div.toggleCheckBoxColor.ui.toggle.checkbox > input[type="checkbox"]#edit_hasStaticValueYes').is(":checked")));
		//if($('ui.toggle.checkbox #edit_hasStaticValueYes').is(":checked")){
		if($('.toggleCheckBoxColor.ui.toggle.checkbox > input[type="checkbox"]#edit_hasStaticValueYes').is(":checked") || $('#edit_hasStaticValueYes').is(":checked")){
			/*$('.edit_importantParam').hide();
			$('.edit_isArrayParam').hide();*/
			//console.log("checked in edit_hasStaticOnclick :: "+($("#edit_hasStaticValueYes").is(":checked")));
			//$('#edit_isArrayCheckbox').attr('checked', false);
			$("#edit_importantYes").prop("disabled", true);
			$("#edit_isArrayCheckbox").prop("disabled", true);
			$("label[for='edit_imprtnt_lbl']").addClass('changeLableColor');
			$('.toggleCheckBoxColor.ui.toggle.checkbox > input[type="checkbox"]#edit_importantYes').attr("checked",false);
			$('.ui.checkbox > input[type="checkbox"]#edit_isArrayCheckbox').attr("checked",false);
			$(".edit_isArrayParam").addClass("disabled");
		}else {
			$("label[for='edit_imprtnt_lbl']").removeClass('changeLableColor');
			/*$('.edit_importantParam').show();
			$('.edit_isArrayParam').show();*/
			$("#edit_importantYes").prop("disabled", false);
			$("#edit_isArrayCheckbox").prop("disabled", false);
			var editParamValueDropdown = $('#edit_ddParamType option:selected').val();
			//Edited by aditya 08.03.18
			//console.log("editParamValueDropdown :: "+editParamValueDropdown);
			//if(editParamValueDropdown == 1){ 
			if(editParamValueDropdown == "1" || editParamValueDropdown == "7"){
				//$('.edit_isArrayParam').show();
				//console.log("m here --1");
				$("#edit_isArrayCheckbox").prop("disabled", false);
				$("#edit_isArrayCheckbox").attr("disabled", false);
				$(".edit_isArrayParam").removeClass("disabled");
			}
			else{
				//console.log("m here --2");
				//$('.edit_isArrayParam').hide();
				$("#edit_isArrayCheckbox").prop("disabled", true);
				$(".edit_isArrayParam").addClass("disabled");
			}
		}
		
	}
	
	// method to get file extension
	function getExt(filename) {
		var dot_pos = filename.lastIndexOf(".");
		if (dot_pos == -1) {
			return "";
		}
		return filename.substr(dot_pos + 1).toLowerCase();
	}
	
	function showNotApplicationLabel(grpId,autoGeneratedId, groupName){
		if(groupName != "Guest"){
			if ($('.classForShowHideChck_'+autoGeneratedId).is(':checked')) {

				$('.classForViewEdit_'+autoGeneratedId).show();
				$('.classForNotApplicable_'+autoGeneratedId).hide();
				$('#getGrpIdForEditView_'+grpId+'_'+autoGeneratedId).removeClass("posCatwiseNotApplicable");

				$('#catWiseHideAccess_'+grpId+'_'+autoGeneratedId).hide();
				$('#catWiseShowAccess_'+grpId+'_'+autoGeneratedId).show();

				if ($('#viewEditChck_'+grpId+'_'+autoGeneratedId).is(':checked')) {

					$('#readOnly_'+grpId+'_'+autoGeneratedId).hide();
					$('#editCheck_'+grpId+'_'+autoGeneratedId).show();

				}else{
					$('#readOnly_'+grpId+'_'+autoGeneratedId).show();
					$('#editCheck_'+grpId+'_'+autoGeneratedId).hide();

				}

				if (!!navigator.userAgent.match(/Trident\/7\./)){   
					//$('#getGrpIdForEditView_'+grpId+'_'+autoGeneratedId).css( {"margin-right" : "-23.5rem !important;" } );
					//$('#getGrpIdForEditView_'+grpId+'_'+autoGeneratedId).addClass("posCatwiseNotApplicable");
					$('#getGrpIdForEditView_'+grpId+'_'+autoGeneratedId).removeClass("posCatwiseNotApplicableForIe");
				}

			} 
			else{

				$('.classForViewEdit_'+autoGeneratedId).hide();
				$('.classForNotApplicable_'+autoGeneratedId).show(); 
				$('#getGrpIdForEditView_'+grpId+'_'+autoGeneratedId).addClass("posCatwiseNotApplicable");

				$('#catWiseHideAccess_'+grpId+'_'+autoGeneratedId).show();
				$('#catWiseShowAccess_'+grpId+'_'+autoGeneratedId).hide();

				$('#readOnly_'+grpId+'_'+autoGeneratedId).hide();
				$('#editCheck_'+grpId+'_'+autoGeneratedId).hide();

				if (!!navigator.userAgent.match(/Trident\/7\./)){   
					//$('.classForNotApplicable_'+autoGeneratedId).css( {"margin-right" : "30px !important;" } );
					//$('#getGrpIdForEditView_'+grpId+'_'+autoGeneratedId).css( {"margin-right" : "-20.5rem;" } );
					$('#getGrpIdForEditView_'+grpId+'_'+autoGeneratedId).removeClass("posCatwiseNotApplicable");
					$('#getGrpIdForEditView_'+grpId+'_'+autoGeneratedId).addClass("posCatwiseNotApplicableForIe");
				}

			}
		}else{
			if ($('.classForShowHideChck_'+autoGeneratedId).is(':checked')) {
				$('#catWiseHideAccess_'+grpId+'_'+autoGeneratedId).hide();
				$('#catWiseShowAccess_'+grpId+'_'+autoGeneratedId).show();
			}else{
				$('#catWiseHideAccess_'+grpId+'_'+autoGeneratedId).show();
				$('#catWiseShowAccess_'+grpId+'_'+autoGeneratedId).hide();
			}
		}
	}
function readOnlyEditLabel(grpId,autoGeneratedId, groupName){
	if ($('#viewEditChck_'+grpId+'_'+autoGeneratedId).is(':checked')) {
		
		$('#readOnly_'+grpId+'_'+autoGeneratedId).hide();
		$('#editCheck_'+grpId+'_'+autoGeneratedId).show();
	
	}else{
		$('#readOnly_'+grpId+'_'+autoGeneratedId).show();
		$('#editCheck_'+grpId+'_'+autoGeneratedId).hide();
		
	}
}

//souradip 5.7.18
//get isArray disable and list type flag
enableOrDisableSingleMultiSelectListAndIsArrayJSON = "";
disableFlagAPIIncall = true;
function getEnableOrDisableSingleMultiSelectListAndIsArray(){
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetType/enableOrDisableSingleMultiSelectListAndIsArray?assetId="+editAssetId,
		dataType : "json",
		async: true,
		complete : function(data) {
			disableFlagAPIIncall = false;
			var json = JSON.parse(data.responseText);
			enableOrDisableSingleMultiSelectListAndIsArrayJSON = json;
			//console.log("souro == json LOAD : " + enableOrDisableSingleMultiSelectListAndIsArrayJSON);
		}
	});
}

// show ldap maaping names list
var ldapMappingNames_Arr = [];
function showListOfMappedNames_AddEdit(){
	ldapMappingNames_Arr.length = 0
	 $.ajax({
			type : 'GET',
			url : "/repopro/web/assetType/getLdapMappingList",
			dataType : 'json',
			async : false,
			complete : function(data) {
			var json = JSON.parse(data.responseText);
			//console.log("json : " + JSON.stringify(json));
			if (json.status == "SUCCESS") {
				ldapMappingNames_Arr.length = 0;
			
				$.each(json.result, function(i) {
				
				ldapMappingNames_Arr.push({
						"mappingName" : json.result[i].mappingName,
						"ldapMappingId" : json.result[i].ldapMappingId
					});
				
				});
			}
			
			var appendLdapMappingListOptions = "";
			
				$('#dd_LdapMappedList').html("");
				for (var h = 0; h < ldapMappingNames_Arr.length; h++) {
					appendLdapMappingListOptions += '<option value="'+ ldapMappingNames_Arr[h].ldapMappingId + '">' + ldapMappingNames_Arr[h].mappingName + '</option>';
				}
				
				// add param modal - Add ldap mapped names to dropdown
				$('#dd_LdapMappedList').prepend('<option value="">Select Mapped Names</option>');
				$('#dd_LdapMappedList').append(appendLdapMappingListOptions);
			
			
				// edit param modal - Add ldap mapped names to dropdown
				$('#edit_dd_LdapMappedList').html("");
				$('#edit_dd_LdapMappedList').prepend('<option value="">Select Mapped Names</option>');
				$('#edit_dd_LdapMappedList').append(appendLdapMappingListOptions);
			
		}
					
		});
}

function loadLdapAttributes(value){
	var append_ldapAttributes = "";
	 $.ajax({
			type : 'GET',
			url : "/repopro/web/assetType/getLdapMappingAttributeList?ldapMappingId="+value,
			dataType : 'json',
			async : false,
			complete : function(data) {
			var json = JSON.parse(data.responseText);
			append_ldapAttributes = "";
			$(json.result).each(function(i){
				//console.log("json : " + json.result[i].attributeDisplayName);
				append_ldapAttributes += "<div class='ui label'>"+json.result[i].attributeDisplayName+"</div>";
			})
			
			// add parameter
			$('.ldapMappingAttributes').show();
			$('#div_ldapMappingAttributes').html("");
			$('#div_ldapMappingAttributes').append(append_ldapAttributes);
			
			// edit parameter
			$('.edit_ldapMappingAttributes').show();
			$('#edit_div_ldapMappingAttributes').html("");
			$('#edit_div_ldapMappingAttributes').append(append_ldapAttributes);
			
			}
	 });

}

/*** Swathi- Generic Triggers ***/
function openGenericTriggerModal() {
	$('#openTriggerModal').modal('destroy');
	$('#openTriggerModal').modal({observeChanges:true, closable: false }).modal('show').modal('refresh');
	//User List Dropdwon
	loadActiveUserList();
	$('#userList').html(appendUserList);
	//$("#userList")
	$('#userList').multiselect({

	  columns: 1,     // how many columns should be use to show options
	  search : true, // include option search box
	
	  // search filter options
	  searchOptions : {
	      delay        : 250,                  // time (in ms) between keystrokes until search happens
	      showOptGroups: false,                // show option group titles if no options remaining
	      searchText   : true,                 // search within the text
	      searchValue  : false,                // search within the value
	      onSearch     : function( element ){} // fires on keyup before search on options happens
	  },
	
	  // plugin texts
	  texts: {
	      placeholder    : 'Select users', // text to use in dummy input
	      search         : 'Search users',         // search input placeholder text
	      selectedOptions: ' Selected',      // selected suffix text
	      selectAll      : 'Select all',     // select all text
	      unselectAll    : 'Unselect all',   // unselect all text
	      noneSelected   : 'None Selected'   // None selected text
	  },
	
	  // general options
	  selectAll          : true, // add select all option
	  selectGroup        : false, // select entire optgroup
	  minHeight          : 200,   // minimum height of option overlay
	  maxHeight          : null,  // maximum height of option overlay
	  maxWidth           : null,  // maximum width of option overlay (or selector)
	  maxPlaceholderWidth: null, // maximum width of placeholder button
	  maxPlaceholderOpts : 1, // maximum number of placeholder options to show until "# selected" shown instead
	  showCheckbox       : true,  // display the checkbox to the user
	  optionAttributes   : [],  // attributes to copy to the checkbox from the option element
	
	  // Callbacks
	  onLoad        : function( element ){},           // fires at end of list initialization
	  onOptionClick : function( element, option ){},   // fires when an option is clicked
	  onControlClose: function( element ){},           // fires when the options list is closed
	  onSelectAll   : function( element, selected ){}, // fires when (un)select all is clicked
	  onPlaceholder : function( element, placeholder, selectedOpts ){}, // fires when the placeholder txt is up<a href="https://www.jqueryscript.net/time-clock/">date</a>d
	});
	$('#userList').multiselect('reload' );
	$(".ms-options ul li label").append("<span class='geekmark'></span> ");
	$(".ms-search").addClass("ui icon input");
	$(".ms-search").append("<i class='search icon'></i>") 
	rulerow = "";
	res = 0;
	createRow();
	
	//Load Rule set
	getAllRuleeSets();
}
var res;
function createRow(){
	var newRowRule;
	var msg = "Use /, as a delimeter to seperate multiple strings";
	var data = "<p>Are you sure you want to delete this parameter rule ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteRulePopup("+res+")'>No</button><button class='right floated ui primary mini button' onclick='deleteSingleRule(this)'>Yes</button>";
	
	//Parameter Dropdwon
	newRowRule += '<tr  id="ruleId_'+res+'"><td class=" parameterSelection" style="vertical-align:top;">';
	newRowRule += '<select class="ui dropdown customSelectRule" id="paramDropdownValues_'+res+'" onchange="ruleParameter(this);" style="min-width: 10em;">';
	newRowRule += '<option value="selectParam">Select</option>';	
	newRowRule += '</select></td>';
	
	//operator dropdown
	newRowRule += '<td class="operatorSelection disableClick" style="vertical-align:top;">';
	newRowRule += '<select class="ui dropdown dropdownCssForFilter" id="opertorDropdownValues_'+res+'">';
	newRowRule += '<option value="selectOperator">Select Operators</option>';
	newRowRule += '</select></td>';

	//Text
	newRowRule += '<td class=" inputValueSelector disableClick" id="inputParamText_'+res+'" style="vertical-align:top;">';
	newRowRule += '<div class="ui icon input " style="width: 195px;">';	
	newRowRule += '<span class="textTooltip" data-tooltip ="Use /, as a delimeter to seperate multiple strings" data-position="bottom center"> <i class="info circle icon"></i></span> <input type="text" id="inputTextField_'+res+'" placeholder="Enter Value" class="customizeTextBox" autocomplete="off">';
	newRowRule += '</div></td>';
	
	//Date
	newRowRule += '<td class=" inputDateSelector" id="inputDate_'+res+'" style="display: none;vertical-align:top;">';
	newRowRule += '<div class="ui icon input focus datePickerCssForFirefox" style="  width: 195px;">';
	newRowRule += '<i class="calendar alternate icon"></i><input type="text" id="inputTextDate_'+res+'" placeholder="Select Date" readonly="true" class="customizeDateBox">';	
	newRowRule += '</div></td>';
	
	//State Dropdown
	newRowRule += '<td class="dropDownValueSelector" id="dropdownState_'+res+'"  style="display: none;vertical-align:top;">';
	newRowRule += '<select class="ui dropdown" id="stateListValue_'+res+'" style="width: 10em;"><option>Select</option>';
	newRowRule += '</select></td>';
	
	newRowRule += '<td class=" rowDelete"><i tabindex="0" id="trash_'+res+'" class="trash alternate icon deleteRule " data-html="'+data+'" onclick="openSingleRuleDeleteModal('+res+')" data-position = "left center" style="cursor: pointer;"></i></td></tr>';

	//newRowRule += '<td class=" rowDelete"><i tabindex = "0" class="trash alternate icon deleteRule" onclick="deleteFilterParameter(this)" style="cursor: pointer;"></i></td></tr>';
	
	$("#ruleTableSection tbody").append(newRowRule);
	loadParamValues();
	$('#paramDropdownValues_'+res).html('');
	$('#paramDropdownValues_'+res).html(appendParameters);
	$('.ui.dropdown').dropdown();
	customSelect(res);	
	paramValueArray.push(0);	
	
	
	//Delete Icon disabling
	var numberofRows = $("#ruleTableSection tbody tr").length;
	if ((numberofRows <= 1)) {
		$(".deleteRule:first-child").addClass("disableClick");
	}else{
		$(".deleteRule:first-child").removeClass("disableClick");
	}
	
	
}

/*** Swathi- 27.04.2020- Code to load all params of asset ***/
var appendParameters;
var listofParamArray = [];
var paramValueArray = [];
var editAssetId = localStorage.getItem('editAssetId');
function loadParamValues(){	
	appendParameters ="";
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetType/getParamList?assetId="+editAssetId+"&userName="+loggedInUserName,
		dataType : "json",
		async: false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				paramValueArray = [];
				appendParameters = "";
				appendParameters = '<option value="Select Parameter" id="Select Parameter">Select</option><optgroup label="Metadata" id="Metadata">'
				$.each(json.result, function(i){					
						if(json.result[i].paramTypeId != "3"){
							listofParamArray.push(json.result[i].assetParamName);
							paramValueArray.push(json.result[i].assetParamId);
							appendParameters += '<option value="'+ json.result[i].assetParamId +'" class="'+json.result[i].typeName+'" id="'+json.result[i].assetParamId+'_'+json.result[i].paramTypeId+'_'+json.result[i].typeName+'_'+json.result[i].listTypeParamTypeId+'" data-typeName="'+json.result[i].listTypeName+'" data-mapId="'+json.result[i].mappedAssetId+'">'+ json.result[i].assetParamName +'</option>';	 
						}					
				});
				appendParameters += '</optgroup><optgroup label="Asset workflow" id="Asset workflow"><option value="0" id= "0_0_workflow_0" >States</option></optgroup>';
			}else{
				appendParameters = ""
			}
		}
	});
}

function ruleParameter(obj){
	var data = $(obj).closest('tr').attr('id');
	res = data.split('_')[1];
	assetParamName = $(obj).children().children(':selected').text().trim();
	assetParamId = $(obj).children().children(':selected').val();
	paramListTypeName = $(obj).children().children(':selected').attr('data-typeName');
	paramTypeName = $(obj).children().children(':selected').attr('class');
	mapId = $(obj).children().children(':selected').attr('data-mapid');
	
	//hide all input fields
	$("#inputParamText_"+res).hide();
	$('#inputDate_'+res).hide();
	$('#dropdownInput_'+res).hide();
	$('#dropdownState_'+res).hide();
	//Remove diable class for operator and input field
	$("#opertorDropdownValues_"+res).parent().parent().removeClass("disableClick");
	$("#ruleId_"+res+" .inputValueSelector").removeClass("disableClick");
	
	$('#opertorDropdownValues_'+res).html('');
	
	if(assetParamName == "Select" || assetParamName == ""){
		$('#opertorDropdownValues_'+res).empty();
		$('#opertorDropdownValues_'+res).dropdown('clear');	
		$("#ruleId_"+res+" .inputValueSelector").show();
		$(".operatorSelection").addClass("disableClick");
		$('#opertorDropdownValues_'+res).html('<option value="selectOperator">Select Operators</option>');
		$("#ruleId_"+res+" .inputValueSelector").addClass("disableClick");
	}else if(assetParamName == "States"){
		$('#dropdownState_'+res).show();		
		$('#opertorDropdownValues_'+res).html('<option value="=">=</option><option value="!=">!=</option>');
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"=");
		}, 100);
		$('#stateListValue_'+res).html("");
		loadStateValueList();
		$('#stateListValue_'+res).html("<option>Select</option>");
		$('#stateListValue_'+res).append(appendState);			
		setTimeout(function(){
				$('#stateListValue_'+res).dropdown('set selected',firstState);
		}, 100);	
	}
	else if (paramTypeName == "list") {	
			$("#ruleId_"+res+" .inputValueSelector").show();	
			$('#opertorDropdownValues_'+res).html('<option value="=">=</option><option value="!=">!=</option>');
			setTimeout(function(){
				$('#opertorDropdownValues_'+res).dropdown('set selected',"=");
			}, 100);				
		
		
	}else if (paramTypeName == "text") {
		$("#ruleId_"+res+" .inputValueSelector").show();
		$('#opertorDropdownValues_'+res).html('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option>');
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"=");
	}, 100);
		
	
	}	else if (paramTypeName == "date") {
		$('#inputDate_'+res).show();
		$('#inputDate_'+res).addClass("dateBoxValue");

		$('#opertorDropdownValues_'+res).html('<option value="=">=</option><option value="!=">!=</option><option value=">">&gt;</option><option value="<">&lt;</option><option value=">=">&gt;=</option><option value="<=">&lt;=</option>');
		
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"=");
		}, 100);
		
		$('#inputTextDate_'+res).datepicker({
			dateFormat: 'dd/mm/yy'
		});
		
					
	}else if (paramTypeName == "rich text" || paramTypeName == "richtext" || paramTypeName == "ldapmapping" || paramTypeName == "derived asset list" || paramTypeName == "derived attribute" ) {
		$("#ruleId_"+res+" .inputValueSelector").show();
		$('#opertorDropdownValues_'+res).append('<option value="like">like</option><option value="not like">not like</option><option value="=">=</option><option value="!=">!=</option>');
		
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"like");
		}, 100);
		
	} else if(paramTypeName == "derived computation"){
		$("#ruleId_"+res+" .inputValueSelector").show();
		$('#opertorDropdownValues_'+res).html('<option value="=">=</option><option value="!=">!=</option>');
		setTimeout(function(){
			$('#opertorDropdownValues_'+res).dropdown('set selected',"=");
		}, 100);
	}
	
	
}
var appendParamValues;
var firstParamValue=[];
function paramvaluesDisplay(id,assetParamName,paramListTypeName,mapId){
	var browserAssetName = localStorage.getItem('browserAssetName');
	//listDropdownData.length = 0;
	appendParamValues = "";	
	$.ajax({
		type : "GET",
		url : "/repopro/web/assetType/getFilterList?assetName="+browserAssetName+"&paramName="+assetParamName+"&listName="+paramListTypeName+"&userName="+loggedInUserName+"&MappedAssetId="+mapId,
		dataType : "json",
		async: false,
		complete : function(data) {			
			var json = JSON.parse(data.responseText);			
			if(json.status == "SUCCESS"){				
				if(JSON.stringify(json.result) != "[]"){
					firstParamValue = json.result[0].paramValue;
					$.each(json.result, function(i){						
						var value = json.result[i].paramValue;
						appendParamValues += '<option value="'+ encodeURIComponent(value) +'">'+ value +'</option>';	 
					});
				}else{
					firstParamValue = "";
				}				
				
			}
		}
	});
}

function addRule(){
	appendData = "";
	appendData += '<tr id="rowOperatorId_'+res+'"><td class="logicalSelection popuptabletr"><select class="ui dropdown dropdownCssForFilter">';
	appendData += '<option value="And">And</option>';
	appendData += '<option value="Or">Or</option>';
	appendData += '</select></td></tr>';
	$("#ruleTableSection tbody").append(appendData);
	res++;
	createRow();
}

//get Active User List
var appendUserList ;
function loadActiveUserList(){
	appendUserList = "";
	$.ajax({
		type : "GET",
		url: "/repopro/web/user/getAllActiveUsers",
		dataType : "json",
		async: false,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			$.each(json.result,function(i){
				appendUserList += '<option value="'+ json.result[i].userId+'">'+json.result[i].userName +'</option>';
			});
		}
	});
	return appendUserList;
}

//get State List
var appendState ;
var firstState;

function loadStateValueList(){
	appendState = "";	
	$.ajax({
		type : "GET",
		url: "/repopro/web/assetType/getAllStatesOfWorkflow?assetId="+editAssetId,
		dataType : "json",
		async: false,
		cache:false,
		complete : function(data) {
			var json = JSON.parse(data.responseText);
			if(JSON.stringify(json.result) != "[]"){
				firstState = json.result[0].paramValue;
				$.each(json.result,function(i){					
					appendState += '<option value="'+ json.result[i]+'">'+json.result[i] +'</option>';
				});
			} else{
				firstState ='';
			}
			
		}
	});
	return appendState;
}

var updateDoneFlag ;
/*** Swathi- Rule Set Save option, Display on the RHS of modal, And perform Clear rule fields- 29.04.2020 ***/
$("#addRuleSet").on('click', function(){
	var saveFlag = true;
	var userFlag = true;
	var repeatFlag = true;
	// Fetching Values	
	var ruleName = $("#ruleName").val().trim();
	var selctedUserIds= [];
	//User Ids
	var selectedUserList=[];
	$("#userList :selected").each(function(){
		var val = $(this).text()+"~~"+$(this).val()+"~~"+$(this)[0].disabled;
		// REPO-1052 fix
		selectedUserList.push(val);
		selctedUserIds .push($(this).val());
		
	});
	var repeatPattern = $("#scheduler").val();
	// validation -  RuleName, Repeat Pattern and user
	if(ruleName == "" || ruleName == undefined || ruleName == null){
		$('#ruleName').parent().addClass("error"); 
		$("#errRuleName").html('Please enter rule name.').show();  
		$("#errRuleName").show(); 
		saveFlag = false;
	}else if (/^[a-zA-Z0-9- ]*$/.test(ruleName) == false) {
		$('#ruleName').parent().addClass("error"); 
	    $("#errRuleName").html('Please use only alphanumeric character for ruleset name.').show();  
	    saveFlag = false;
	}else{
		$('#ruleName').parent().removeClass("error"); 
		$("#errRuleName").hide();
		var test = jQuery.inArray( ruleName.toLowerCase(), ruleSetNames );
		if(test== -1){
			$('#ruleName').parent().removeClass("error"); 
			$("#errRuleName").hide(); 
			saveFlag = true;
		} else if(rulerow != undefined && rulerow !="" ){
			
			if(ruleName != $("#"+rulerow)[0].innerText){
				$('#ruleName').parent().addClass("error"); 
			    $("#errRuleName").html('RuleSet(s) with the same name already exists.').show();  
			    saveFlag = false;
			}else{				
			    $('#ruleName').parent().removeClass("error"); 
				$("#errRuleName").hide(); 
				saveFlag = true;
			}
			
		}else {			
			$('#ruleName').parent().addClass("error"); 
		    $("#errRuleName").html('RuleSet(s) with the same name already exists.').show();  
		    saveFlag = false;
			
		}
	}
	
	//Repeat Pattern
	if(repeatPattern == "" || repeatPattern == undefined || repeatPattern == null){
		$('#scheduler').parent().addClass("error"); 
		$("#errRScheduler").show(); 
		repeatFlag = false;
	}else{
		$('#scheduler').parent().removeClass("error"); 
		$("#errRScheduler").hide();
		repeatFlag = true;
	}
	
	//UserList check
	if(selectedUserList.length == 0){
		$('#userList').parent().addClass("error"); 
		$("#errRUser").show(); 
		userFlag = false;
	}else{
		$('#userList').parent().removeClass("error"); 
		$("#errRUser").hide();
		userFlag = true;
	}
	var parameterType ="" ;
	var logicalOperator = "";
	var inputParamValues = "";
	var relationalOperators = "";
	
	var ruleFlag = true;
	var selectFlag = true;
	var DateFlag =true;
	var TextFlag =true;
	var operatorFlag = true;
	var logicalFlag = true;
	var paramFlag = true;
	$("#ruleTableSection tbody tr").each(function(){		
		//ParamType
		var paramDiv = $(this).find(".parameterSelection :visible");
		
		if(paramDiv.length !=0){
			var paramVal = paramDiv.find(":selected")[0].id;
			if(paramVal !="" && paramVal != "Select Parameter"  && paramVal != undefined && paramVal != null){
				parameterType += paramVal;
				parameterType += '~';
				$(".genericErrorRule").hide();
				paramFlag = true;
				paramDiv.removeClass("error"); 
				
			}else{				
				$(".genericErrorRule").show();
				paramFlag = false;
				paramDiv.addClass("error"); 
			}
		}
		
		
		// Operators
		var operatorDiv  = $(this).find(".operatorSelection");
		var operator =  operatorDiv.find(":selected").val();
		if(operator!= " " && operator!= "selectOperator" && operator != undefined && operator != null ){
			relationalOperators += operator;
			relationalOperators += '~';	
			$(".genericErrorRule").hide();
			operatorFlag = true;
			operatorDiv.children().removeClass("error");
		}else{
			$(".genericErrorRule").show();
			operatorFlag = false;
			operatorDiv.children().addClass("error");
		}
		
		//Logical Operator
		var logicalDiv  = $(this).find(".logicalSelection :visible");
		if(logicalDiv.length !=0){
			var logic = logicalDiv.find(":selected").val();
			if(logic !="" && logic != " " && logic != undefined && logic != null){
				logicalOperator += logic;
				logicalOperator += '~';	
				$(".genericErrorRule").hide();
				logicalFlag = true;
				logicalDiv.children().removeClass("error");
			}else{
				$(".genericErrorRule").show();
				logicalFlag = false;
				logicalDiv.children().addClass("error");
			}
		}else{
			$(".genericErrorRule").hide();
			logicalFlag = true;
			logicalDiv.removeClass("error");
		}
		
		
		// Param entry Values may be input values, dropdwon, date picker
		var inputValues = $(this).find(".inputValueSelector :visible input");
		if(inputValues.val() != "" && inputValues.val() != " " && inputValues.val() != undefined && inputValues.val() != null){
			var text = inputValues.val().trim();
			if(text != " " && text !=""){
				if(text.includes("/,")){
					var array1 = text.split("/,");
					var errFlag = false;
					$.each(array1,function(e){
						if(array1[e].length == 0){
							errFlag = true;						
						}
					});
					if(errFlag==true){
						$(".genericErrorRule").show();
						TextFlag = false;
						inputValues.parent().addClass("error");
					}else{
						inputParamValues += inputValues.val();
						inputParamValues += '~';	
						$(".genericErrorRule").hide();
						TextFlag = true;
						inputValues.parent().removeClass("error");
					}
				}else {
					inputParamValues += inputValues.val();
					inputParamValues += '~';	
					$(".genericErrorRule").hide();
					TextFlag = true;
					inputValues.parent().removeClass("error");
				}
			}else{
				$(".genericErrorRule").show();
				TextFlag = false;
				inputValues.parent().addClass("error");
			}
			
			
		}else{
			$(".genericErrorRule").show();
			TextFlag = false;
			inputValues.parent().addClass("error");
		}
		//Date
		var inputDate = $(this).find(".inputDateSelector :visible input");
		if(inputDate.val() != "" && inputDate.val() != " " && inputDate.val() != undefined && inputDate.val() != null){
			inputParamValues += inputDate.val();
			inputParamValues += '~';	
			$(".genericErrorRule").hide();
			DateFlag = true;
			inputDate.parent().removeClass("error");
		}else{
			$(".genericErrorRule").show();
			DateFlag = false;
			inputDate.parent().addClass("error");
		}
		//State- Dropdwon
		
		var inputSelect = $(this).find(".dropDownValueSelector :selected");
		var inputVisError = $(this).find(".dropDownValueSelector :visible");
		if(inputSelect.val() != "" && inputSelect.val() != "Select" && inputSelect.val() != undefined && inputSelect.val() != null){
			inputParamValues += $(this).find(".dropDownValueSelector :selected").val();
			inputParamValues += '~';	
			$(".genericErrorRule").hide();
			selectFlag = true;
			inputVisError.removeClass("error");
		}else{
			$(".genericErrorRule").show();
			selectFlag = false;
			inputVisError.addClass("error");
		}
		
		if(selectFlag == true || DateFlag==true || TextFlag==true){
			ruleFlag = true;
			$(".genericErrorRule").hide();
		}else{
			ruleFlag = false;
			$(".genericErrorRule").show();
		}
	});
	
	
	
	if(ruleFlag == true && logicalFlag == true && operatorFlag == true &&  paramFlag == true && saveFlag == true && userFlag ==true && repeatFlag == true){
		
		if(rulerow != "" && rulerow !=undefined){
			$("#"+rulerow).parent().remove();
			 var id= rulerow.split("_")[1];
			 var backendRule = false;
			 //checking whether Id is present in autocreated Ids
			 for(i=0;i<savedIDS.length;i++){
				 if(id==savedIDS[i]){
					 backendRule = true;
					 //updateDoneFlag = true;
				 }
			 }
		}
		
		//Storing of values on the RHS		
		parameterType = parameterType.substring(0,parameterType.length-1);
		relationalOperators= relationalOperators.substring(0,relationalOperators.length-1);
		logicalOperator= logicalOperator.substring(0,logicalOperator.length-1);
		inputParamValues= inputParamValues.substring(0,inputParamValues.length-1);
		
		 var autoIdCreator ="";
		 if(backendRule == true){
			 autoIdCreator = id;
			 var actionForRule = "Update";
		 } else{
			 autoIdCreator = Math.floor((Math.random() * 1000000) + 1);
			 var actionForRule = "Add";
			 // Add new rule set name to the array
			 ruleSetNames.push(ruleName.toLowerCase());
		 }	 
		
		alignRuleSetDetails(ruleName,parameterType,logicalOperator,inputParamValues,relationalOperators,repeatPattern,selectedUserList,selctedUserIds,autoIdCreator,actionForRule, true);
		autoIdCreator = Math.floor((Math.random() * 1000000) + 1);	
		//Disabling of Save button
		if($(".ruleSetRow").length == 0){
			$("#saveruleSet").addClass("disableClick");
		}else{
			$("#saveruleSet").removeClass("disableClick");
		}
		
		// Clearing fields
		rulerow ="";
		ClearModalContent();
		res= 0;
		createRow();
		
		$(".ms-options ul li label").append("<span class='geekmark'></span> ");
		$(".ms-search").addClass("ui icon input");
		$(".ms-search").append("<i class='search icon'></i>") 
		//Save button text change
		$("#addRuleSet").text("Add Rule Set");
	}else{
		
	}
	
	
});

function ClearModalContent(){
	$("#ruleTableSection tbody").html('');
	$("#ruleName").val('');
	$("#searchRuleInput").val('');
	//$("#userList").dropdown('clear');
	$("#scheduler").dropdown('clear');
	$("#userList").html();
	loadActiveUserList();
	$('#userList').html(appendUserList);
	$('#userList').multiselect('reload' );
	$(".ms-options ul li label").append("<span class='geekmark'></span> ");
}

//Final Save Rule Set- Modal Save click
function saveRuleSet(){
	if($("#saveruleSet").hasClass("disableClick") == false){
		var interNodes = [];	
		$('.ruleSetRow').each(function(){
			// Altering  values to required format
			var userIds= $(this).find(".selectUserIds").text();
			userIds =userIds.split(',');
			var userListIds = [];
			$.each(userIds, function(i){
				var id= parseInt(userIds[i]);
				userListIds.push(id);
			});
			var assetParamName =  $(this).find(".paramtype").text();
			//assetParamName = assetParamName.substring(0, assetParamName.length-1);
			
			var inputParam = $(this).find(".inputparam").text();
			//inputParam = inputParam.substring(0,inputParam.length-1);
			
			var operators = $(this).find(".relational").text();
			//operators = operators.substring(0,operators.length-1);
			
			var logical = $(this).find(".logical").text();
			//logical = logical.substring(0,logical.length-1);
			var id = $(this).children()[0].id;
			id = id.split("_")[1];
			
			var ruleName=  $(this).find(".rule").text();
			interNodes.push({
				"paramRuleId": id,
				"actionForRule": $(this).find(".actionForRule").text(),
				"paramRuleName": ruleName,
				"assetParamName": assetParamName,
				"param1Value": inputParam,
				"operatorValue": operators,
				"logicalOperator": logical,
				"assetId": editAssetId,
				"scheduler": $(this).find(".repeatPattern").text(),
				"userIds": userListIds,				
				"param2Value": ""
			}); 
		});
		
		$.ajax({
		   	type: "PUT",
		   	url: '/repopro/web/assetType/saveParamRules?assetId='+editAssetId,
		   	contentType : "application/json",
			dataType : "json",
			data : JSON.stringify(interNodes),
			async: false,
			cache:false,
			complete:function(data){	
				var json = JSON.parse(data.responseText);
				if(json.status == "SUCCESS"){
					if(createRuleSetFlag == true){
						notifyMessage("Rule Set","Rule sets created successfully","success");
					}else{
						notifyMessage("Rule Set","Rule sets updated successfully","success");
					}
					
				}
				else {
					if(createRuleSetFlag == true){
						notifyMessage("Rule Set","Error attempting to create rule sets","fail");
					}else{
						notifyMessage("Rule Set","Error attempting to update rule sets","fail");
					}
					
				}
				//Clear the table
				$(".ruleSetGroup").html('');
				$(".ruleSetGroup").html('<div class="noData" style="display:none;padding: 1.5em;">No data found on search</div>');
				ClearModalContent();
				// Hide all error messages
				$(".genericErrorRule").hide();
				$("#errRuleName").hide();
				$("#errRUser").hide();
				$("#errRScheduler").hide();
				$(".triggerDivs").removeClass("error");
				$(".triggerDivs .selection").removeClass("error");
				$(".input").removeClass("error");
				$(".selection").removeClass("error");
				
				//Save button text change
				$("#addRuleSet").text("Add Rule Set");
				//Hide the modal
		    	$('#openTriggerModal').modal('hide');
		    	$('#openTriggerModal').parent().css("display", "none !important");
			}
		});
	} else{
		
	}
	
}

function closeTriggerModal(){
	$(".ruleSetGroup").html('');
	$(".ruleSetGroup").html('<div class="noData" style="display:none;padding: 1.5em;">No data found on search</div>');

	//ClearModalContent();
	
	$("#ruleTableSection tbody").html('');
	$("#ruleName").val('');
	$("#searchRuleInput").val('');
	$("#scheduler").dropdown('clear');
	$("#userList").html();
	/*loadActiveUserList();
	$('#userList').html(appendUserList);*/
	$('#userList').multiselect('reload' );
	$(".ms-options ul li label").append("<span class='geekmark'></span> ");
	
	
	// Hide all error messages
	$(".genericErrorRule").hide();
	$("#errRuleName").hide();
	$("#errRUser").hide();
	$("#errRScheduler").hide();
	$(".triggerDivs").removeClass("error");
	$(".triggerDivs .selection").removeClass("error");
	//Save button text change
	$("#addRuleSet").text("Add Rule Set");
}

/*** get All rule set API **/
var appendRuleSets ="";
var ruleSetNames = [];
var savedIDS = [];
var updateRuleFlag = false;
var createRuleSetFlag = false;
function getAllRuleeSets(){
	$.ajax({
	   	type: "GET",
	   	url: '/repopro/web/assetType/getAllAssetParamRules?assetId='+editAssetId,
	   	contentType : "application/json",
		dataType : "json",
		async: false,
		cache:false,
		complete:function(data){	
			var json = JSON.parse(data.responseText);
			if(json.status == "SUCCESS"){
				if(json.result.length ==0){
					createRuleSetFlag = true;
				}else{
					createRuleSetFlag = false;
				}
				$.each(json.result, function(i) {
					savedIDS.push(json.result[i].paramRuleId);
					var id= json.result[i].paramRuleId;
					/*var user = json.result[i].userList;
					var userId =[];
					var userName = [];
					Object.keys(user).forEach(function eachKey(key) { 
						 userId.push( key);
						 userName.push(user[key]); 
					  });*/
					ruleSetNames.push(json.result[i].paramRuleName.toLowerCase());
					var actionForRule = "No Changes";
					var assetParamName ;
					var logicalOperator;
					var param1Value ;
					var operatorValue;
					var scheduler;
					var userName;
					var userId =[];
					updateRuleFlag = false;
					alignRuleSetDetails (json.result[i].paramRuleName,assetParamName, logicalOperator,param1Value,operatorValue, scheduler,userName, userId,id,actionForRule,updateRuleFlag );
				});
				//Disabling of Save button
				if($(".ruleSetRow").length == 0){
					$("#saveruleSet").addClass("disableClick");
				}else{
					$("#saveruleSet").removeClass("disableClick");
				}
				console.log("saved Ids::"+savedIDS)
			}
			else {				
				
			}
		}
	});
}

//Storing and Display of RuleSet on the RHS
function alignRuleSetDetails(ruleName,parameterType,logicalOperator,inputParamValues,relationalOperators,repeatPattern,selectedUserList,selctedUserIds,autoIdCreator,actionForRule, updateRuleFlag){
	
	var data = "<p>Are you sure you want to delete the "+ ruleName +" rule set ?</p><button class='right floated ui cancel themeSecondary mini button' onclick='closeDeleteWorkflowPopup("+autoIdCreator+")'>No</button><button class='right floated ui primary mini button' onclick='deleteRule("+autoIdCreator+")'>Yes</button>";

	$(".ruleSetGroup").append('<div class="ruleSetRow" tabindex="0" ><span class="editClass" onclick="editRuleSet(this)" id="ruleEdit_'+autoIdCreator+'">'+ruleName+'</span><span style="display:inline-block"><i class="trash alternate icon delteRuleSet" tabindex="0" id="trash_'+autoIdCreator+'" data-html="'+data+'" onclick="openRuleDeletePopup('+autoIdCreator+')" style="cursor: pointer;float:right"></i></span></div>');
	$("#ruleEdit_"+autoIdCreator).append('<span class="paramtype hidden">'+parameterType+'</span>');
	$("#ruleEdit_"+autoIdCreator).append('<span class="logical hidden" >'+logicalOperator+'</span>');
	$("#ruleEdit_"+autoIdCreator).append('<span class=" inputparam hidden">'+inputParamValues+'</span>');
	$("#ruleEdit_"+autoIdCreator).append('<span class="relational hidden" >'+relationalOperators+'</span>');
	$("#ruleEdit_"+autoIdCreator).append('<span class="rule hidden" ">'+ruleName+'</span>');
	$("#ruleEdit_"+autoIdCreator).append('<span class="repeatPattern hidden" >'+repeatPattern+'</span>');
	$("#ruleEdit_"+autoIdCreator).append('<span class="selectUser hidden" >'+selectedUserList+'</span>');
	$("#ruleEdit_"+autoIdCreator).append('<span class="selectUserIds hidden" >'+selctedUserIds+'</span>');
	$("#ruleEdit_"+autoIdCreator).append('<span class="actionForRule hidden" >'+actionForRule+'</span>');
	$("#ruleEdit_"+autoIdCreator).append('<span class="updateRuleFlag hidden" >'+updateRuleFlag+'</span>');
	
	
}

//Delete Rule Row
function deleteFilterParameter(obj){
	var numberofRows = $("#ruleTableSection tbody tr").length;
	if ((numberofRows <= 1)) {
		notifyMessage("Delete Rule","Please provide at least one Rule","failure");
	}
	else if($(obj).closest('tr').is(':first-child')){
		$(obj).closest('tr').next().remove();
		$(obj).closest('tr').remove();
		notifyMessage("Delete Rule","Rule is deleted successfully","success");
	}	
	else {
		$(obj).closest('tr').prev().remove();
		$(obj).closest('tr').remove();
		notifyMessage("Delete Rule","Rule is deleted successfully","success");
	}
	
	//Delete Icon disabling
	var numberofRows = $("#ruleTableSection tbody tr").length;
	if ((numberofRows <= 1)) {
		$(".deleteRule:first-child").addClass("disableClick");
	}else{
		$(".deleteRule:first-child").removeClass("disableClick");
	}
}

//Search RuleSet functionality
$("#searchRuleInput").on("keyup", function() {
 var g = $(this).val().toLowerCase().trim();
 $(".ruleSetGroup .ruleSetRow ").each(function() {
	 var s =$(this).find(".rule").text().toLocaleLowerCase();
     if (s.indexOf(g)!=-1) {
    	 if($(this).hasClass("deleteClass") == false){
    		 $(this).show();
    	 }else{
    		 $(this).hide(); 
    	 }
     } else {
       $(this).hide();
     }
 });
 if($(".ruleSetRow :visible").length == 0 && g !=""){	   
	 $(".noData").show();
 }else{
	 $(".noData").hide();
 }
});

// Edit Rule Set 
var rulerow;
function editRuleSet(obj){
	var ruleName ="";
	var parameterType ="" ;
	var logicalOperator ="";
	var inputParamValues ="";
	var relationalOperators="";
	var repeat = "";
	var finalist = [];
	var userList = ""; 
	 var finalUserobject =[];
	 var disableFlag ;
	 
	 $(".ruleSetRow ").removeClass("editingRule");
	 rulerow = $(obj)[0].id;
	 $("#"+rulerow).parent().addClass("editingRule");
	 var id= rulerow.split("_")[1];
	 var backendRule = false;
	 //checking whether Id is present in saved backednd Ids
	 for(i=0;i<savedIDS.length;i++){
		 if(id==savedIDS[i]){
			 backendRule = true;
		 }
	 }
	 updateDoneFlag =  $("#"+rulerow+" .updateRuleFlag").text();
	 if(backendRule == true && updateDoneFlag == "false"){
		 $.ajax({
			   	type: "GET",
			   	url: '/repopro/web/assetType/getParamRuleDetails?paramRuleId='+id,
			   	contentType : "application/json",
				dataType : "json",
				async: false,
				cache:false,
				complete:function(data){	
					var json = JSON.parse(data.responseText);
					if(json.status == "SUCCESS"){
						ruleName =json.result[0].paramRuleName ;
						parameterType = json.result[0].assetParamName;
						logicalOperator = json.result[0].logicalOperator;
						inputParamValues =json.result[0].param1Value ;
						relationalOperators =json.result[0].operatorValue ;
						repeat = json.result[0].scheduler;
						 //User List Dropdown
						finalist = [];
						userList = json.result[0].userList;
						var userId =[];
						var userName = [];
						Object.keys(userList).forEach(function eachKey(key) { 							
							var name = userList[key];
							var userName = name.split("~~")[0];
							
							if(name.split("~~")[1] == 0){
								disableFlag = true;
							}else{
								disableFlag = false;
							}
							 //finalist.push(name); 
							finalUserobject.push({
								name   : userName,
							    value  : key,
							    checked: true,
							    disabled: disableFlag
							});
						  });
					}
					else {				
						
					}
				}
			});
		 
		 
	 } else{		
		 ruleName = $(obj)[0].innerText;
		 parameterType = $('#'+rulerow+' .paramtype').text();
		 logicalOperator = $('#'+rulerow+' .logical').text();
		 inputParamValues = $('#'+rulerow+' .inputparam').text();
		 relationalOperators = $('#'+rulerow+' .relational').text();
		 repeat = $('#'+rulerow+' .repeatPattern').text();
		 //User List Dropdown
		 finalist = [];
		 userList = $('#'+rulerow+' .selectUser').text();
		 userList = userList.split(',');
		// var result = Object.entries(userList);
		 for(var i = 0; i < userList.length; i++) { 
			var inter = userList[i].split('~~');
			//finalist.push(inter[0]);
			finalUserobject.push({
				name   : inter[0],
			    value  : inter[1],
			    checked: true,
			    disabled : inter[2]
			    
			});
	     } 
		
	 }
	 
		ClearModalContent();
		// Setting values
		$("#ruleName").val(ruleName);
		$("#scheduler").val(repeat).change();
		//$("#userList").dropdown('clear');
				
		/*$("#userList").html();
		loadActiveUserList();
		$('#userList').html(appendUserList);*/
		for(i=0;i<finalUserobject.length;i++){
			var val = finalUserobject[i].value;
			$("#userList option[value='"+val+"']").remove();
		}
		$('#userList').multiselect('reload' );
		
		$("#userList").multiselect('loadOptions',finalUserobject,false,true);
		$(".ms-options ul li label").append("<span class='geekmark'></span> ");
		$(".ms-search").addClass("ui icon input");
		$(".ms-search").append("<i class='search icon'></i>"); 
		for(i=0;i<finalUserobject.length;i++){
			if(finalUserobject[i].disabled == true || finalUserobject[i].disabled == "true"){// REPO-1052 fix
				$(this).prop("disabled", true);
				$('.ms-options li[data-search-term="'+finalUserobject[i].name.toLowerCase()+'"]').addClass("disableClick");
				$('.ms-options li[data-search-term="'+finalUserobject[i].name.toLowerCase()+'"] input').prop("disabled", true);
				$('.ms-options li[data-search-term="'+finalUserobject[i].name.toLowerCase()+'"] input').attr("selected", "selected");
				$("#userList option[value='"+finalUserobject[i].value+"']").prop("disabled",true);
				$("#userList option[value='"+finalUserobject[i].value+"']").attr("selected","selected");
			}
		}
			
		
		//Create the required number of trs based on param length
		var params = parameterType.split('~');
		var numberofParams = params.length;
		res= 0;
		createRow();
		for(var i=1;i<numberofParams;i++){
			if(res<numberofParams && numberofParams >1){
				addRule();		
			}
		}
		
		//Populating the values in the table
		for(i=0;i<numberofParams;i++){
			//Param field
			var param1 = params[i].toString().split("_")[0];
			var test = 1;
			$.each(paramValueArray, function(e){
				if(param1 == paramValueArray[e]){
					test = 0;
				}
			});
			
			$("#paramDropdownValues_"+i).val(param1).change();
			//Input field
			var inputVal = inputParamValues.split("~")[i];
			if(params[i].toString().split("_")[2] == "date"){				
				$("#inputTextDate_"+i).val(inputVal);
			}else if(params[i].toString().split("_")[2] == "workflow"){			
					$("#stateListValue_"+i).val(inputVal).change();				
			}else{
				$("#inputTextField_"+i).val(inputVal);
				
			}

			if(test != 0){				
				notifyMessage("Rule set","Asset details have been modified after this rule set was saved. This rule set is invalid now.","Warning");// Clearing fields
				ClearModalContent();
				res= 0;
				createRow();
			}
			
		}
		//Operator field
		setTimeout(function(){
			for(i=0;i<numberofParams;i++){			
				var rel = relationalOperators.split("~")[i];
				$("#opertorDropdownValues_"+i).val(rel).change();
			}
		},100);
		
		//Logical operator
		for(i=0;i<numberofParams;i++){
			var logical = logicalOperator.split("~")[i];
			$("#rowOperatorId_"+i+" .logicalSelection select").val(logical).change();
			
		} 
	//Save button text change
	$("#addRuleSet").text("Update Rule Set");

}
function openRuleDeletePopup(id){
	if($("#trash_"+id).next().is(":visible") == false){
		$("#trash_"+id)
		.popup({
			on: 'click',
			lastResort: 'bottom left',
			closable : true,
			inline : true,
		})
		.popup('show');
		/***Below code id for displaying of popup message in proper position after scrooling---
		 --- Commenting below code for REPO-1071 fix which is done in css page***/
		/*var scrollheight = $("#ruleTable")[0].scrollTop;
		var elemHeight = $(".popup.scale")[0].style.top
		elemHeight = elemHeight.split("px")[0];
		var topHeight = scrollheight + parseInt(elemHeight);
		$(".popup.scale").css({ top: topHeight  });*/
		
	}
	
}

function deleteRule(id){
	$("#ruleEdit_"+id).parent().hide();
	if(rulerow){
		var editedId = rulerow.split("_")[1];
		if(editedId == id){
			// Clearing fields
			ClearModalContent();
			res= 0;
			createRow();
			$("#addRuleSet").text("Add Rule Set");
		}		
	}
	
	var checkAction = $("#ruleEdit_"+id+"  .actionForRule").text();
	var singleRuleSet = $("#ruleEdit_"+id+"  .rule ").text();
	// Removing the deleteed rule from the array
	ruleSetNames = ruleSetNames.filter(e => e != singleRuleSet.toLowerCase());
	if(checkAction == "Add"){
		$("#ruleEdit_"+id).parent().remove();
	}else{
		$("#ruleEdit_"+ id).parent().addClass("deleteClass");
		$("#ruleEdit_"+ id +"  .actionForRule").text("Delete");
	}
	
	if($(".ruleSetRow").length == 0){
		$("#saveruleSet").addClass("disableClick");
	}else{
		$("#saveruleSet").removeClass("disableClick");
	}
	
}

function closeDeleteWorkflowPopup(id){
	$("#trash_"+id).popup('hide');	
}

$(window).keydown(
		function(event) {
			if (event.keyCode == 27) {
				if($('#openTriggerModal').is(":visible")){
					closeTriggerModal();
				}				
			}
});

function openSingleRuleDeleteModal(id){
	if($("#trash_"+id).next().is(":visible") == false){
		$("#trash_"+id)
		.popup({
			on: 'click',
			lastResort: 'bottom left',
			closable : true,
			inline : true
		})
		.popup('show');
		/*var scrollheight = $("#ruleParamSection .offsetSegment")[0].scrollTop;
		var elemHeight = $(".popup.scale")[0].style.top
		elemHeight = elemHeight.split("px")[0];
		var topHeight = scrollheight + parseInt(elemHeight);
		$(".popup.scale").css({ top: topHeight  });*/
	}
	
}

function closeDeleteRulePopup(id){
	$("#trash_"+id).popup('hide');	
}

function deleteSingleRule(obj){
	var numberofRows = $("#ruleTableSection tbody tr").length;
	if ((numberofRows <= 1)) {
		notifyMessage("Delete Rule","Please provide at least one Rule","failure");
	}
	else if($(obj).closest('tr').is(':first-child')){
		$(obj).closest('tr').next().remove();
		$(obj).closest('tr').remove();
		notifyMessage("Rule Set","Rule is deleted successfully","success");
	}	
	else {
		$(obj).closest('tr').prev().remove();
		$(obj).closest('tr').remove();
		notifyMessage("Rule Set","Rule is deleted successfully","success");
	}
	
	//Delete Icon disabling
	var numberofRows = $("#ruleTableSection tbody tr").length;
	if ((numberofRows <= 1)) {
		$(".deleteRule:first-child").addClass("disableClick");
	}else{
		$(".deleteRule:first-child").removeClass("disableClick");
	}
}
function customSelect(a) { 
    // clear the generated semantic-ui menu
    $('#ruleId_'+a+' .parameterSelection  .menu').html("");
    // add the head items based on the optgroup and the items based on the options
    $('#ruleId_'+a+' .parameterSelection optgroup').each(function (index, element) {
        $('#ruleId_'+a+' .parameterSelection .menu').append('<div class="header">' + element.label + '</div>')
        $(element).children().each(function(i, e){
        	 $('#ruleId_'+a+' .parameterSelection .menu').append('<div class="item" data-value="' + e.value + '">' + e.innerHTML + '</div>');
        })
    })
};