package com.thbs.repopro.assetinstanceversion;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.QuickStats;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

@Path("/quickStat")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class QuickStatManager {
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method getQuickStats
	 * @description to obtain QuickStat data
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/getQuickStat")
	public Response getQuickStats(@QueryParam("userName") String userName) {
		if(log.isTraceEnabled()){
			log.trace("getQuickStats || begin  userName:"+userName);
		}
		QuickStatsDao quickStatsDao = new QuickStatsDao();
		List<QuickStats> quickStatsList = null;
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getQuickStats || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (log.isTraceEnabled()) {
				log.trace("getQuickStats || dao method called : getQuickStats()");
			}

			quickStatsList = quickStatsDao.getQuickStats(userName, conn);

			if (quickStatsList.isEmpty()) {
				retStat = Status.OK;
				retMsg = Constants.QUICKSTATS_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			retStat = Status.OK;
			retMsg = Constants.QUICKSTATS_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			if (log.isDebugEnabled()) {
				log.debug(" getQuickStats  || retrieved " + quickStatsList.size()
						+ " QuickStats data successfully");
			}
		} catch (RepoproException e) {
			log.error("getQuickStats || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getQuickStats || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getQuickStats || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getQuickStats ||userName:"+userName+"exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(quickStatsList))).build();

	}

}
