package com.thbs.repopro.assetinstanceversion;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.RoleDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.DiscussionComment;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class DiscussionCommentDao {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	/**
	 * @method : listAllComments
	 * @param aivId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<DiscussionComment> listAllComments(Long aivId, String userName, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("listAllComments || Begin with aivId : "+ aivId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		DiscussionComment dc = null;
		
		List<DiscussionComment> commentsList = new ArrayList<DiscussionComment>();
		
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("listAllComments || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			boolean userFlag = false;
			if(!userName.equalsIgnoreCase("roleAnonymous")) {
				User user = userDao.retProfileForUserName(userName, conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
				for(UserFunction uf : userfunctionMappedWithRoleId){
					if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
						userFlag = true;
						break;
					}
				}
			}
			
			if(userName.equalsIgnoreCase("admin")) {
				userFlag = true;
			}

			if(userFlag) {
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_COMMENTS_FOR_LOGGED_IN_USER));

				pstmt.setString(Constants.ONE, CommonUtils.encryptionKey);
				pstmt.setLong(Constants.TWO, aivId);

				if (log.isTraceEnabled()) {
					log.trace("listAllComments || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_COMMENTS_FOR_LOGGED_IN_USER));
				}

				rs = pstmt.executeQuery();

				while(rs.next()){
					dc = new DiscussionComment();
					dc.setCommentId(rs.getLong("comment_id"));
					dc.setCommentTimestamp(rs.getTimestamp("comment_timestamp"));
					dc.setUserId(rs.getLong("user_id"));
					dc.setAssetInstanceVersionId(rs.getLong("asset_inst_version_id"));
					dc.setDescription(rs.getString("description"));
					dc.setParentCommentId(rs.getLong("parent_comment_id"));
					dc.setFullName(rs.getString("decrypted_full_name"));
					dc.setImageName(rs.getString("image_name"));
					commentsList.add(dc);
					if(log.isTraceEnabled()){
						log.debug("listAllComments || "+ dc.toString());
					}
				}
			}else {
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_COMMENTS));

				pstmt.setString(Constants.ONE, userName);
				pstmt.setString(Constants.TWO, CommonUtils.encryptionKey);
				pstmt.setString(Constants.THREE, CommonUtils.encryptionKey);
				pstmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
				pstmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
				pstmt.setString(Constants.SIX, CommonUtils.encryptionKey);
				pstmt.setLong(Constants.SEVEN, aivId);


				if (log.isTraceEnabled()) {
					log.trace("listAllComments || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_COMMENTS));
				}

				rs = pstmt.executeQuery();

				while(rs.next()){
					dc = new DiscussionComment();
					dc.setCommentId(rs.getLong("comment_id"));
					dc.setCommentTimestamp(rs.getTimestamp("comment_timestamp"));
					dc.setUserId(rs.getLong("user_id"));
					dc.setAssetInstanceVersionId(rs.getLong("asset_inst_version_id"));
					dc.setDescription(rs.getString("description"));
					dc.setParentCommentId(rs.getLong("parent_comment_id"));
					dc.setFullName(rs.getString("masked_full_name"));
					dc.setImageName(rs.getString("image_name"));
					dc.setEncryptImage(rs.getInt("encrypt_image"));
					dc.setUserName(rs.getString("user_name"));

					commentsList.add(dc);
				}

				if(log.isTraceEnabled()){
					log.debug("listAllComments || "+ dc.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("listAllComments || "+ commentsList.toString());
			}


		} catch (SQLException e) {
			log.error("listAllComments || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.COMMENTS_NOT_FOUND));
		} catch (IOException e) {
			log.error("listAllComments || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("listAllComments || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("listAllComments || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("listAllComments || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("listAllComments || end ");
		}
		return commentsList;
		
	}
	
	/**
	 * @method : addComment
	 * @param dc
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public DiscussionComment addComment(DiscussionComment dc, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("addComment || "+ dc.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("addComment || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_COMMENT));
			
			pstmt.setLong(Constants.ONE, dc.getUserId());
			pstmt.setLong(Constants.TWO, dc.getAssetInstanceVersionId());
			pstmt.setString(Constants.THREE, dc.getDescription());

			if (log.isTraceEnabled()) {
				log.trace("addComment || "+ PropertyFileReader.getInstance().
						getValue(Constants.ADD_COMMENT));
			}
			
			pstmt.execute();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				dc.setCommentId(rs.getLong(1));
				/*dc.setParentCommentId(rs.getLong(6));*/
			}
			
			
		} catch (SQLException e) {
			log.error("addComment || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.COMMENT_NOT_ADDED));
		} catch (IOException e) {
			log.error("addComment || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addComment || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addComment || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addComment || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}

		if(log.isTraceEnabled()){
			log.trace("addComment || end ");
		}
		return dc;
	}
	
	/**
	 * @method : addReply
	 * @param dc
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public DiscussionComment addReply(DiscussionComment dc, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("addReply || "+ dc.toString() + " Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("addReply || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.REPLY_TO_COMMENT));
			
			pstmt.setLong(Constants.ONE, dc.getUserId());
			pstmt.setLong(Constants.TWO, dc.getAssetInstanceVersionId());
			pstmt.setString(Constants.THREE, dc.getDescription());
			pstmt.setLong(Constants.FOUR, dc.getParentCommentId());

			if (log.isTraceEnabled()) {
				log.trace("addReply || "+ PropertyFileReader.getInstance().
						getValue(Constants.REPLY_TO_COMMENT));
			}
			
			pstmt.execute();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				dc.setCommentId(rs.getLong(1));
				/*dc.setParentCommentId(rs.getLong(6));*/
			}
			
			
		} catch (SQLException e) {
			log.error("addReply || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.REPLY_NOT_ADDED));
		} catch (IOException e) {
			log.error("addReply || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addReply || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addReply || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addReply || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}

		if(log.isTraceEnabled()){
			log.trace("addReply || end ");
		}
		return dc;
	}
	public Long getParentCommentId(long userId, long aivId,String desc,Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getParentCommentId || Begin ");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
        Long parentCommentId=null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getParentCommentId || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_PARENT_COMMENT_ID));
			pstmt.setLong(Constants.ONE,userId);
			pstmt.setLong(Constants.TWO, aivId);
			pstmt.setString(Constants.THREE,desc);

			/*if (log.isTraceEnabled()) {
				log.trace("getAssetInstIdByName ));
			}*/
			rs = pstmt.executeQuery();
			while(rs.next()){
				parentCommentId=rs.getLong("parent_comment_id");
			}
			
		}catch (SQLException e) {
			log.error("getParentCommentId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		}catch (PropertyVetoException e) {
			log.error("getParentCommentId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getParentCommentId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getParentCommentId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getParentCommentId || End");
		}
		return parentCommentId;
	}
}
