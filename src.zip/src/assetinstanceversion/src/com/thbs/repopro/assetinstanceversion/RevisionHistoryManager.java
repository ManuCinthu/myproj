package com.thbs.repopro.assetinstanceversion;

import java.net.URLDecoder;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AivRevisionHistory;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.GroupAssetInstVersionAccess;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

@Path("/revisionhistorymanager")
public class RevisionHistoryManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : displayRevisionHistory
	 * @param assetName
	 * @param assetInstVersionId
	 * @return
	 */
	@GET
	@Path("/showallrevisionhistory")
	public Response retAllRevisionHistory(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstVersionId") Long assetInstVersionId) {

		if (log.isTraceEnabled()) {
			log.trace("retAllRevisionHistory || Begin with asset name : " + assetName
					+ " \t asset instance version id : " + assetInstVersionId);
		}

		Connection conn = null;

		List<AivRevisionHistory> revisionHistoryList = new ArrayList<AivRevisionHistory>();

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("retAllRevisionHistory || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			RevisionHistoryDao dao = new RevisionHistoryDao();

			if (log.isTraceEnabled()) {
				log.trace("retAllRevisionHistory || dao method called : retAivRevisionHistory()");
			}
			revisionHistoryList = dao.retAivRevisionHistory(assetInstVersionId, conn);

			log.debug("retAllRevisionHistory || retrieved " + revisionHistoryList.size() + " history successfully");

			retMsg = Constants.REVISION_HISTORY_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("retAllRevisionHistory || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("retAllRevisionHistory || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retAllRevisionHistory || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retAllRevisionHistory || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(revisionHistoryList)))
				.build();
	}

	// ================
	

	// ================
	/**
	 * @method : showRevisionHistoryDetails
	 * @param revHistoryId
	 * @param username
	 * @param assetName
	 * @return
	 */
	@GET
	@Path("/showrevisionhistorydetails")
	public Response showRevisionHistoryDetails(@QueryParam("revHistoryId") Long revHistoryId,
			@QueryParam("username") String username, @QueryParam("assetName") String assetName) {

		if (log.isTraceEnabled()) {
			log.trace("showRevisionHistoryDetails || Begin with : revision history id :" + revHistoryId
					+ "\t username : " + username + " asset name : " + assetName);
		}

		Connection conn = null;

		AivRevisionHistory aivr = new AivRevisionHistory();
		List<AivRevisionHistory> revisionHistoryList = new ArrayList<AivRevisionHistory>();

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("showRevisionHistoryDetails || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			RevisionHistoryDao dao = new RevisionHistoryDao();

			if (log.isTraceEnabled()) {
				log.trace("showRevisionHistoryDetails || dao method called : getRevisionHistoryByRevHistoryId()");
			}
			aivr = dao.getRevisionHistoryByRevHistoryId(revHistoryId, conn);
			String parameterData = "";
			if (aivr != null) {
				if (aivr.getRelationshipData() != null) {
					String relationshipData = aivr.getRelationshipData();
					relationshipData = relationshipData.replaceAll("&<!!>&", "<br>");
					aivr.setRelationshipData(relationshipData);
				}

				if (aivr.getUsedBy() != null) {
					String usedBy = aivr.getUsedBy();
					usedBy = usedBy.replaceAll("&<!!>&", "<br>");
					aivr.setUsedBy(usedBy);
				}

				if (aivr.getParameterData() != null) {
					parameterData = aivr.getParameterData();
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("showRevisionHistoryDetails || dao method called : getParamDefForAssetByGroups()");
			}
			List<AssetParamDef> paramDefForAssetByGroups = dao.getParamDefForAssetByGroups(assetName, username, conn);

			HashMap<String, String> paramData = new HashMap<String, String>();

			if (username.equalsIgnoreCase("admin")) {
				if (parameterData != null && !parameterData.isEmpty()) {
					if (parameterData.contains("&<!!>&")) {
						String[] splitParamData = parameterData.split("&<!!>&");
						for (int i = 0; i < splitParamData.length; i++) {

							for (AssetParamDef apd : paramDefForAssetByGroups) {
								String assetParamName = apd.getAssetParamName().trim();
								String param = splitParamData[i].split(":")[0].trim();
								String value = "";
								try {
									if (splitParamData[i].split(":")[1] != null
											&& splitParamData[i].split(":")[1].isEmpty()) {
										value = "";
									} else {
										value = splitParamData[i].split(":", 2)[1].trim();
									}
								} catch (ArrayIndexOutOfBoundsException e) {
									value = "";
								}

								/*
								 * if(!param.isEmpty() && !value.isEmpty()){
								 * paramData.put(param, value); }
								 * 
								 * aivr.setParameterDataMap(paramData);
								 */
								if (assetParamName.equalsIgnoreCase(param)) {
									if (!param.isEmpty() || !value.isEmpty()) {
										paramData.put(param, value);
									}
									aivr.setParameterDataMap(paramData);
								}

							}
						}
					} else {
						for (AssetParamDef apd : paramDefForAssetByGroups) {
							String assetParamName = apd.getAssetParamName().trim();
							String param = parameterData.split(":")[0].trim();
							String value = "";

							try {
								if (parameterData.split(":")[1] != null && parameterData.split(":")[1].isEmpty()) {
									value = "";
								} else {
									value = parameterData.split(":", 2)[1].trim();
								}
							} catch (ArrayIndexOutOfBoundsException e) {
								value = "";
							}
							/*
							 * paramData.put(param, value);
							 * aivr.setParameterDataMap(paramData);
							 */

							if (!param.isEmpty() || !value.isEmpty()) {
								paramData.put(param, value);
							}
							aivr.setParameterDataMap(paramData);

						}
					}
				}
			} else {
				if (parameterData != null && !parameterData.isEmpty()) {
					if (parameterData.contains("&<!!>&")) {
						String[] splitParamData = parameterData.split("&<!!>&");
						for (int i = 0; i < splitParamData.length; i++) {

							for (AssetParamDef apd : paramDefForAssetByGroups) {
								String assetParamName = apd.getAssetParamName().trim();
								String param = splitParamData[i].split(":")[0].trim();
								String value = "";
								try {
									if (splitParamData[i].split(":")[1] != null
											&& splitParamData[i].split(":")[1].isEmpty()) {
										value = "";
									} else {
										value = splitParamData[i].split(":", 2)[1].trim();
									}
								} catch (ArrayIndexOutOfBoundsException e) {
									value = "";
								}
								if (assetParamName.equalsIgnoreCase(param)) {
									if (!param.isEmpty() || !value.isEmpty()) {
										paramData.put(param, value);
									}
									aivr.setParameterDataMap(paramData);

								}

							}
						}
					} else {
						for (AssetParamDef apd : paramDefForAssetByGroups) {
							String assetParamName = apd.getAssetParamName().trim();
							String param = parameterData.split(":")[0].trim();
							String value = "";

							try {
								if (parameterData.split(":")[1] != null && parameterData.split(":")[1].isEmpty()) {
									value = "";
								} else {
									value = parameterData.split(":", 2)[1].trim();
								}
							} catch (ArrayIndexOutOfBoundsException e) {
								value = "";
							}

							if (!param.isEmpty() || !value.isEmpty()) {
								paramData.put(param, value);
							}
							aivr.setParameterDataMap(paramData);

						}

					}
				}
			}

			if(aivr != null){
				revisionHistoryList.add(aivr);
			}

			log.debug("showRevisionHistoryDetails || retrieved " + revisionHistoryList.size() + " history successfully");

			retMsg = Constants.REVISION_HISTORY_DETAILS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("showRevisionHistoryDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("showRevisionHistoryDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("showRevisionHistoryDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("showRevisionHistoryDetails || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(revisionHistoryList)))
				.build();
	}
	
	
	/***Wrapper function***/
	@GET
	@Path("/showRevisionHistoryDetailsMain")
	public Response showRevisionHistoryDetailsMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstName") String assetInstName, @QueryParam("versionName") String versionName,
			@QueryParam("revId") String revId, @QueryParam("userName") String userName){
		
		if (log.isTraceEnabled()) {
			log.trace("showRevisionHistoryDetailsMain || Begin with : assetName :" + assetName 
					+" \t assetInstName : "+ assetInstName +" \t versionName : "+ versionName 
					+" \t revId : "+ revId + "\t username : " + userName);
		}

		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Response response = null;
		
		boolean viewFlag = false;

		try {
			if (log.isTraceEnabled()) {
				log.trace("showRevisionHistoryDetailsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetInstance assetInstance = new AssetInstance();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(versionName);
			
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			RevisionHistoryDao dao = new RevisionHistoryDao();

			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("showRevisionHistoryDetailsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			
			Long assetInstVersionId = assetInstanceVer.getAssetInstVersionId();
			AivRevisionHistory aivrh = dao.retAivRevHistoryByAivIdAndRevId(assetInstVersionId,revId,conn);
			if (aivrh == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("showRevisionHistoryDetailsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			
			Long aivRevisionHistoryId = aivrh.getAivRevisionHistoryId();
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
			    	viewFlag = true;
				    break;
			    }
		    }

		    if (viewFlag) {
		    	response = this.showRevisionHistoryDetails(aivRevisionHistoryId, userName, assetName);
				return response;
		    } else {
			    retStat = Status.FORBIDDEN;
			    retMsg = Constants.USER_NOT_AUTHORIZED;
			    retScsFlr = Constants.FAILURE;
			    retStatScsFlr = Constants.GET_STATUS_FAILURE;
			    return Response.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
							.build();
		    }
			
		} catch (RepoproException e) {
			log.error("showRevisionHistoryDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("showRevisionHistoryDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("showRevisionHistoryDetailsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("showRevisionHistoryDetailsMain || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
				.build();
		
	}

	/**
	 * @method : displayRevisionHistoryForComparision
	 * @param revHistoryIds
	 * @param assetName
	 * @param username
	 * @return
	 */
	@GET
	@Path("/displayrevisionhistoryforcomparison")
	public Response displayRevisionHistoryForComparision(@QueryParam("revHistoryIds") String revHistoryIds,
			@QueryParam("assetName") String assetName, @QueryParam("username") String username) {

		if (log.isTraceEnabled()) {
			log.trace("displayRevisionHistoryForComparision || Begin with : revision history id :" + revHistoryIds
					+ "\t username : " + username + " asset name : " + assetName);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		AivRevisionHistory aivr = null;
		List<AivRevisionHistory> revisionHistoryList = new ArrayList<AivRevisionHistory>();
		String[] revisionHistoryIds = revHistoryIds.split(",");

		try {
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("displayRevisionHistoryForComparision || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			RevisionHistoryDao dao = new RevisionHistoryDao();

			List<AssetParamDef> paramDefForAssetByGroups = dao.getParamDefForAssetByGroups(assetName, username, conn);

			if (log.isTraceEnabled()) {
				log.trace(
						"displayRevisionHistoryForComparision || dao method called : getRevisionHistoryByRevHistoryId()");
			}
			for (String revHistoryId : revisionHistoryIds) {
				aivr = new AivRevisionHistory();
				aivr = dao.getRevisionHistoryByRevHistoryId(new Long(revHistoryId), conn);
				String parameterData = "";
				if (aivr != null) {
					if (aivr.getRelationshipData() != null) {
						String relationshipData = aivr.getRelationshipData();
						relationshipData = relationshipData.replaceAll("&<!!>&", "<br>");
						aivr.setRelationshipData(relationshipData);
					}

					if (aivr.getUsedBy() != null) {
						String usedBy = aivr.getUsedBy();
						usedBy = usedBy.replaceAll("&<!!>&", "<br>");
						aivr.setUsedBy(usedBy);
					}

					if (aivr.getParameterData() != null) {
						parameterData = aivr.getParameterData();
					}
				}

				if (log.isTraceEnabled()) {
					log.trace(
							"displayRevisionHistoryForComparision || dao method called : getParamDefForAssetByGroups()");
				}

				HashMap<String, String> paramData = new HashMap<String, String>();
				if (username.equalsIgnoreCase("admin")) {
					if (parameterData != null && !parameterData.isEmpty()) {
						if (parameterData.contains("&<!!>&")) {
							String[] splitParamData = parameterData.split("&<!!>&");
							for (int i = 0; i < splitParamData.length; i++) {
								// String splitVal = splitParamData[i];

								for (AssetParamDef apd : paramDefForAssetByGroups) {
									String assetParamName = apd.getAssetParamName().trim();
									String param = splitParamData[i].split(":")[0].trim();
									String value = "";
									// System.out.println(splitParamData[i].split(":")[1]);
									try {
										if (splitParamData[i].split(":")[1] != null
												&& splitParamData[i].split(":")[1].isEmpty()) {
											value = "";
										} else {
											value = splitParamData[i].split(":", 2)[1].trim();
										}
									} catch (ArrayIndexOutOfBoundsException e) {
										value = "";
									}
									/*
									 * paramData.put(param, value);
									 * aivr.setParameterDataMap(paramData);
									 */

									if (assetParamName.equalsIgnoreCase(param)) {
										if (!param.isEmpty() || !value.isEmpty()) {
											paramData.put(param, value);
										}
										aivr.setParameterDataMap(paramData);
									}
								}
							}
						} else {
							for (AssetParamDef apd : paramDefForAssetByGroups) {
								String assetParamName = apd.getAssetParamName().trim();
								String param = parameterData.split(":")[0].trim();
								String value = "";

								try {
									if (parameterData.split(":")[1] != null && parameterData.split(":")[1].isEmpty()) {
										value = "";
									} else {
										value = parameterData.split(":", 2)[1].trim();
									}
								} catch (ArrayIndexOutOfBoundsException e) {
									value = "";
								}

								if (assetParamName.equalsIgnoreCase(param)) {
									if (!param.isEmpty() || !value.isEmpty()) {
										paramData.put(param, value);
									}
									aivr.setParameterDataMap(paramData);
								}
							}

						}
					}
				} else {
					if (parameterData != null && !parameterData.isEmpty()) {
						if (parameterData.contains("&<!!>&")) {
							String[] splitParamData = parameterData.split("&<!!>&");
							for (int i = 0; i < splitParamData.length; i++) {

								for (AssetParamDef apd : paramDefForAssetByGroups) {
									String assetParamName = apd.getAssetParamName().trim();
									String param = splitParamData[i].split(":")[0].trim();
									String value = "";
									try {
										if (splitParamData[i].split(":")[1] != null
												&& splitParamData[i].split(":")[1].isEmpty()) {
											value = "";
										} else {
											value = splitParamData[i].split(":", 2)[1].trim();
										}
									} catch (ArrayIndexOutOfBoundsException e) {
										value = "";
									}

									if (assetParamName.equalsIgnoreCase(param)) {
										if (!param.isEmpty() || !value.isEmpty()) {
											paramData.put(param, value);
										}
										aivr.setParameterDataMap(paramData);
									}

								}
							}
						} else {
							for (AssetParamDef apd : paramDefForAssetByGroups) {
								String assetParamName = apd.getAssetParamName().trim();
								String param = parameterData.split(":")[0].trim();
								String value = "";

								try {
									if (parameterData.split(":")[1] != null && parameterData.split(":")[1].isEmpty()) {
										value = "";
									} else {
										value = parameterData.split(":", 2)[1].trim();
									}
								} catch (ArrayIndexOutOfBoundsException e) {
									value = "";
								}
								if (assetParamName.equalsIgnoreCase(param)) {
									if (!param.isEmpty() || !value.isEmpty()) {
										paramData.put(param, value);
									}
									aivr.setParameterDataMap(paramData);
								}
							}

						}
					}
				}

				// aivr.setParameterData(null);
				if(aivr != null){
					revisionHistoryList.add(aivr);
				}
			}

			log.info("displayRevisionHistoryForComparision || compared history successfully");

			retMsg = Constants.REVISION_HISTORY_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("displayRevisionHistoryForComparision || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("displayRevisionHistoryForComparision || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("displayRevisionHistoryForComparision || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("displayRevisionHistoryForComparision || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(revisionHistoryList)))
				.build();
	}
	
	/***Wrapper function***/
	@GET
	@Path("/displayRevisionHistoryForComparisionMain")
	public Response displayRevisionHistoryForComparisionMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstName") String assetInstName, @QueryParam("versionName") String versionName,
			@QueryParam("revIds") String revIds, @QueryParam("userName") String userName) {
		
		if (log.isTraceEnabled()) {
			log.trace("displayRevisionHistoryForComparisionMain || Begin with : assetName :" + assetName 
					+" \t assetInstName : "+ assetInstName +" \t versionName : "+ versionName 
					+" \t revIds : "+ revIds + "\t username : " + userName);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Response response = null;
		boolean viewFlag = false;
		String[] revisionIds = revIds.split(",");
		List<Long> revHistoryIdsList = new ArrayList<Long>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("displayRevisionHistoryForComparisionMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetInstance assetInstance = new AssetInstance();
			AivRevisionHistory aivrh = new AivRevisionHistory();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(versionName);
			
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			RevisionHistoryDao dao = new RevisionHistoryDao();

			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("displayRevisionHistoryForComparisionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			
			Long assetInstVersionId = assetInstanceVer.getAssetInstVersionId();
			for (String revId : revisionIds){
				aivrh = dao.retAivRevHistoryByAivIdAndRevId(assetInstVersionId,revId,conn);
				if (aivrh == null) {
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("displayRevisionHistoryForComparisionMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
				
				Long aivRevisionHistoryId = aivrh.getAivRevisionHistoryId();
				revHistoryIdsList.add(aivRevisionHistoryId);
			}
			String revHistoryIds = StringUtils.join(revHistoryIdsList, ',');
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
			    	viewFlag = true;
				    break;
			    }
		    }

		    if (viewFlag) {
		    	response = this.displayRevisionHistoryForComparision(revHistoryIds, userName, assetName);
				return response;
		    } else {
			    retStat = Status.FORBIDDEN;
			    retMsg = Constants.USER_NOT_AUTHORIZED;
			    retScsFlr = Constants.FAILURE;
			    retStatScsFlr = Constants.GET_STATUS_FAILURE;
			    return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			
		} catch (RepoproException e) {
			log.error("displayRevisionHistoryForComparisionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("displayRevisionHistoryForComparisionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("displayRevisionHistoryForComparisionMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("displayRevisionHistoryForComparisionMain || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
				.build();
	}
}
