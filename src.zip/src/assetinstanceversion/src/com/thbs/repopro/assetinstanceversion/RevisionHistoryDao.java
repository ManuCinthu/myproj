package com.thbs.repopro.assetinstanceversion;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AdminAccessName;
import com.thbs.repopro.dto.AivRevisionHistory;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class RevisionHistoryDao {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );


	/**
	 * @method : retAivRevisionHistory
	 * @param aivId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AivRevisionHistory> retAivRevisionHistory(Long aivId, Connection conn) 
			throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("retAivRevisionHistory || Begin with aivId : "+ aivId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AivRevisionHistory aivr = null;
		List<AivRevisionHistory> revisionHistoryList = new ArrayList<AivRevisionHistory>();

		try {
			if (log.isTraceEnabled()){
				log.trace("retAivRevisionHistory || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_AIV_REVISION_HISTORY));

			pstmt.setLong(Constants.ONE, aivId);

			if (log.isTraceEnabled()) {
				log.trace("retAivRevisionHistory || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_AIV_REVISION_HISTORY));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				aivr = new AivRevisionHistory();
				aivr.setAivRevisionHistoryId(rs.getLong("aiv_revision_history_id"));
				aivr.setAivId(rs.getLong("aiv_id"));
				aivr.setRevId(rs.getString("rev_id"));
				aivr.setRevisedOn(rs.getTimestamp("revised_on"));
				aivr.setChangedKey(rs.getString("changed_key"));
				aivr.setOverviewData(rs.getString("overview_data"));
				aivr.setRelationshipData(rs.getString("relationship_data"));
				aivr.setParameterData(rs.getString("parameter_data"));
				aivr.setUsedBy(rs.getString("used_by"));
				aivr.setUserId(rs.getLong("user_id"));
				aivr.setUserName(rs.getString("user_name"));
				aivr.setImageName(rs.getString("image_name"));
				aivr.setInstanceRename(rs.getString("instance_rename"));
				aivr.setEncryptImage(rs.getInt("encrypt_image"));
				revisionHistoryList.add(aivr);

				if(log.isTraceEnabled()){
					log.trace("retAivRevisionHistory || "+ aivr.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("retAivRevisionHistory || "+ revisionHistoryList.toString());
			}

		} catch (SQLException e) {
			log.error("retAivRevisionHistory || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.REVISION_HISTORY_NOT_FOUND));
		} catch (IOException e) {
			log.error("retAivRevisionHistory || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("retAivRevisionHistory || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("retAivRevisionHistory || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retAivRevisionHistory || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("retAivRevisionHistory || End");
		}
		return revisionHistoryList;
	}

	/**
	 * @method : getRevisionHistoryByRevHistoryId
	 * @param revHistoryId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AivRevisionHistory getRevisionHistoryByRevHistoryId(Long revHistoryId, Connection conn) 
			throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getRevisionHistoryByRevHistoryId || Begin with revision history id : "+ revHistoryId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AivRevisionHistory aivr = null;

		try {
			if (log.isTraceEnabled()){
				log.trace("getRevisionHistoryByRevHistoryId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_REVISION_HISTORY_BY_REV_HISTORY_ID));

			pstmt.setLong(Constants.ONE, revHistoryId);

			if (log.isTraceEnabled()) {
				log.trace("getRevisionHistoryByRevHistoryId || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_REVISION_HISTORY_BY_REV_HISTORY_ID));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				aivr = new AivRevisionHistory();
				aivr.setAivRevisionHistoryId(rs.getLong("aiv_revision_history_id"));
				aivr.setAivId(rs.getLong("aiv_id"));
				aivr.setRevId(rs.getString("rev_id"));
				aivr.setRevisedOn(rs.getTimestamp("revised_on"));
				aivr.setChangedKey(rs.getString("changed_key"));
				aivr.setOverviewData(rs.getString("overview_data"));
				aivr.setRelationshipData(rs.getString("relationship_data"));
				aivr.setParameterData(rs.getString("parameter_data"));
				aivr.setUsedBy(rs.getString("used_by"));
				aivr.setUserId(rs.getLong("user_id"));
				aivr.setUserName(rs.getString("user_name"));
				aivr.setImageName(rs.getString("image_name"));
				aivr.setInstanceRename(rs.getString("instance_rename"));
				if(log.isTraceEnabled()){
					log.trace("getRevisionHistoryByRevHistoryId || "+ aivr.toString());
				}
			}


		} catch (SQLException e) {
			log.error("getRevisionHistoryByRevHistoryId || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.REVISION_HISTORY_NOT_FOUND));
		} catch (IOException e) {
			log.error("getRevisionHistoryByRevHistoryId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getRevisionHistoryByRevHistoryId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getRevisionHistoryByRevHistoryId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getRevisionHistoryByRevHistoryId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("getRevisionHistoryByRevHistoryId || End");
		}
		return aivr;
	}

	/**
	 * @method : getParamDefForAssetByGroups
	 * @param assetName
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getParamDefForAssetByGroups(String assetName, String userName, 
			Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getParamDefForAssetByGroups || Begin with assetName : "+ assetName 
					+"\t username : "+ userName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;

		AssetParamDef apd = null;
		List<AssetParamDef> paramsList = new ArrayList<AssetParamDef>();

		boolean flag = false;

		AdminAccessName adminAccessName = null;
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();

		try {
			if (log.isTraceEnabled()){
				log.trace("getParamDefForAssetByGroups || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			//checking for admin rights
			pstmt1 = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));

			pstmt1.setString(Constants.ONE, userName);

			if (log.isTraceEnabled()) {
				log.trace("getParametersMatchedWithKeyword || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
			}

			rs1 = pstmt1.executeQuery();

			while (rs1.next()) {
				adminAccessName = new AdminAccessName();
				adminAccessName.setUserName(rs1.getString("user_name"));
				adminAccessName.setGroupName(rs1.getString("group_name"));
				adminAccessName.setRoleName(rs1.getString("role_name"));
				adminAccessNameList.add(adminAccessName);
				if (log.isTraceEnabled()) {
					log.trace("getParametersMatchedWithKeyword || returning resultset for admin check : "
							+ adminAccessName.toString());
				}
			}

			for (AdminAccessName adminAccess : adminAccessNameList) {
				if (adminAccess.getGroupName().equalsIgnoreCase("group-admin")) {
					flag = true;
				}
			}

			if(userName.equalsIgnoreCase("admin")){
				//super admin
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.RET_PARAM_NAMES_FOR_ASSET_BY_ADMIN));

				pstmt.setString(Constants.ONE, assetName);

				if (log.isTraceEnabled()) {
					log.trace("getParamDefForAssetByGroups || "+PropertyFileReader.getInstance().
							getValue(Constants.RET_PARAM_NAMES_FOR_ASSET_BY_ADMIN));
				}

				rs = pstmt.executeQuery();



			}else if(!userName.equalsIgnoreCase("roleAnonymous")){
				//other logged in users
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.RET_PARAM_NAMES_FOR_ASSET_BY_GROUPS));

				pstmt.setString(Constants.ONE, userName);
				pstmt.setString(Constants.TWO, assetName);

				if (log.isTraceEnabled()) {
					log.trace("getParamDefForAssetByGroups || "+PropertyFileReader.getInstance().
							getValue(Constants.RET_PARAM_NAMES_FOR_ASSET_BY_GROUPS));
				}

				rs = pstmt.executeQuery();

			}else if(userName.equalsIgnoreCase("roleAnonymous")){
				//guest user
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.RET_PARAM_NAMES_FOR_ASSET_BY_GROUPS_FOR_GUEST));

				pstmt.setString(Constants.ONE, assetName);
				pstmt.setString(Constants.TWO, "Guest");

				if (log.isTraceEnabled()) {
					log.trace("getParamDefForAssetByGroups || "+PropertyFileReader.getInstance().
							getValue(Constants.RET_PARAM_NAMES_FOR_ASSET_BY_GROUPS_FOR_GUEST));
				}

				rs = pstmt.executeQuery();
			}

			while(rs.next()){
				apd = new AssetParamDef();
				apd.setAssetParamId(rs.getLong("asset_param_id"));
				apd.setAssetParamName(rs.getString("asset_param_name"));
				apd.setAssetCategoryName(rs.getString("asset_category_name"));
				apd.setAssetCategoryId(rs.getLong("asset_category_id"));
				apd.setParamTypeId(rs.getLong("param_type_id"));
				apd.setFileName(rs.getString("fileName"));
				apd.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				apd.setAssetCategoryId(rs.getLong("asset_category_id"));
				apd.setParameter_disp_position(rs.getInt("param_disp"));
				apd.setCategory_disp_position(rs.getInt("cat_disp"));
				apd.setIs_static(rs.getInt("is_static"));
				apd.setListTypeParamTypeId(rs.getLong("list_param_type_id"));
				apd.setMappedAssetId(rs.getLong("mapped_asset_id"));
				apd.setSize(rs.getInt("size"));
				apd.setDescription(rs.getString("parameterdesc"));
				apd.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				apd.setHasArray(rs.getInt("isArray"));
				apd.setListType(rs.getInt("list_type"));
				apd.setDerivedAssetListRule(rs.getString("derived_asset_list"));
				//apd.setParamValue(rs.getString("value"));
				paramsList.add(apd);

				if (log.isTraceEnabled()) {
					log.trace("getParamDefForAssetByGroups || "+ apd.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getParamDefForAssetByGroups || "+ paramsList.toString());
			}


		} catch (SQLException e) {
			log.error("getParamDefForAssetByGroups || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getParamDefForAssetByGroups || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getParamDefForAssetByGroups || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getParamDefForAssetByGroups || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs1);
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closePreparedStatement(pstmt1);
			if (log.isTraceEnabled()) {
				log.trace("getParamDefForAssetByGroups || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		return paramsList;
	}

	/**
	 * @method deleteAivRevHistoryByAivId
	 * @param aivRevisionHistoryBO
	 * @param conn
	 * @throws RepoproException
	 */
	public void deleteAivRevHistoryByAivId(
			AivRevisionHistory aivRevisionHistoryBO, Connection conn)
					throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteAivRevHistoryByAivId || Begin with : "
					+ aivRevisionHistoryBO.toString());
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result;

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAivRevHistoryByAivId || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_AIV_REV_HISTORY_BY_AIVID));

			pstmt.setLong(Constants.ONE, aivRevisionHistoryBO.getAivId());

			if (log.isTraceEnabled()) {
				log.trace("deleteAivRevHistoryByAivId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_AIV_REV_HISTORY_BY_AIVID));
			}

			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("deleteAivRevHistoryByAivId || "
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.AIV_REV_HISTORY_BY_AIVID_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteAivRevHistoryByAivId || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteAivRevHistoryByAivId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteAivRevHistoryByAivId || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {

			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteAivRevHistoryByAivId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("deleteAivRevHistoryByAivId :"
					+ aivRevisionHistoryBO.toString() + "||End");
		}

	}


	/**
	 * @method retAivRevHistoryByAivId
	 * @param AivRevHistId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AivRevisionHistory> retAivRevHistoryByAivId(Long AivRevHistId,
			Connection conn)throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("retAivRevHistoryByAivId || Begin with AivRevHistId : "+ AivRevHistId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AivRevisionHistory aivRevHis = null;
		List<AivRevisionHistory> AivRevHistoryList = new ArrayList<AivRevisionHistory>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retAivRevHistoryByAivId || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_AIV_REVISION_HISTORY_BY_AIV_REV_HIST_ID));

			pstmt.setLong(Constants.ONE, AivRevHistId);

			if (log.isTraceEnabled()) {
				log.trace("retAivRevHistoryByAivId || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_AIV_REVISION_HISTORY_BY_AIV_REV_HIST_ID));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				aivRevHis = new AivRevisionHistory();

				aivRevHis.setAivId(rs.getLong("aiv_id"));
				aivRevHis.setAivRevisionHistoryId(rs.getLong("aiv_revision_history_id"));
				aivRevHis.setChangedKey(rs.getString("changed_key"));
				aivRevHis.setOverviewData(rs.getString("overview_data"));
				aivRevHis.setParameterData(rs.getString("parameter_data"));
				aivRevHis.setRelationshipData(rs.getString("relationship_data"));
				aivRevHis.setRevId(rs.getString("rev_id"));
				aivRevHis.setRevisedOn(rs.getTimestamp("revised_on"));
				aivRevHis.setUsedBy(rs.getString("used_by"));
				aivRevHis.setUserId(rs.getLong("user_id"));


				AivRevHistoryList.add(aivRevHis);

				if(log.isTraceEnabled()){
					log.trace("retAivRevHistoryByAivId || "+ aivRevHis.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("retAivRevHistoryByAivId || "+ AivRevHistoryList.toString());
			}


		} catch (SQLException e) {
			log.error("retAivRevHistoryByAivId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.RET_AIV_REVISION_HISTORY_BY_AIV_REV_HIST_ID_NOT_FOUND));
		} catch (IOException e) {
			log.error("retAivRevHistoryByAivId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("retAivRevHistoryByAivId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("retAivRevHistoryByAivId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retAivRevHistoryByAivId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if(log.isTraceEnabled()){
			log.trace("retAivRevHistoryByAivId || End");
		}
		return AivRevHistoryList;

	}

	/**
	 * @method addRevisionData
	 * @param aivRevHist
	 * @param conn
	 * @throws RepoproException
	 */
	public void addRevisionData(AivRevisionHistory aivRevHist ,Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addRevisionData || " + aivRevHist.toString() + " Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("addRevisionData || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}


			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_REVISION_DATA));

			pstmt.setLong(Constants.ONE, aivRevHist.getAivId());
			pstmt.setString(Constants.TWO, aivRevHist.getRevId());
			pstmt.setTimestamp(Constants.THREE, aivRevHist.getRevisedOn());
			pstmt.setString(Constants.FOUR, aivRevHist.getChangedKey());
			pstmt.setString(Constants.FIVE, aivRevHist.getOverviewData());
			pstmt.setString(Constants.SIX, aivRevHist.getRelationshipData());
			pstmt.setString(Constants.SEVEN, aivRevHist.getParameterData());
			pstmt.setString(Constants.EIGHT, aivRevHist.getUsedBy());
			pstmt.setLong(Constants.NINE, aivRevHist.getUserId());
			pstmt.setString(Constants.TEN, aivRevHist.getInstanceRename());

			if (log.isTraceEnabled()) {
				log.trace("addRevisionData || "
						+ PropertyFileReader.getInstance().getValue(Constants.ADD_REVISION_DATA));
			}

		  pstmt.executeUpdate();
			

			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				aivRevHist.setAivRevisionHistoryId(rs.getLong(1));
			}

		} catch (SQLException e) {
			log.error("addRevisionData || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ADD_REVISION_DATA_NOT_CREATED));
		} catch (IOException e) {
			log.error("addRevisionData || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addRevisionData || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addRevisionData || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addRevisionData || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("addRevisionData || " + aivRevHist.toString() + " End");
		}

	}
	
	
	/**
	 * @method : retAivRevHistoryByAivIdAndRevId
	 * @param aivId
	 * @param revId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AivRevisionHistory retAivRevHistoryByAivIdAndRevId(Long aivId, String revId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("retAivRevHistoryByAivIdAndRevId || Begin with aivId : "+ aivId +" \t revision history id : "+ revId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AivRevisionHistory aivr = null;

		try {
			if (log.isTraceEnabled()){
				log.trace("retAivRevHistoryByAivIdAndRevId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_REVISION_HISTORY_BY_AIV_ID_AND_REV_ID));

			pstmt.setLong(Constants.ONE, aivId);
			pstmt.setString(Constants.TWO, revId);

			if (log.isTraceEnabled()) {
				log.trace("retAivRevHistoryByAivIdAndRevId || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_REVISION_HISTORY_BY_AIV_ID_AND_REV_ID));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				aivr = new AivRevisionHistory();
				aivr.setAivRevisionHistoryId(rs.getLong("aiv_revision_history_id"));
				aivr.setAivId(rs.getLong("aiv_id"));
				aivr.setRevId(rs.getString("rev_id"));
				aivr.setRevisedOn(rs.getTimestamp("revised_on"));
				aivr.setChangedKey(rs.getString("changed_key"));
				aivr.setOverviewData(rs.getString("overview_data"));
				aivr.setRelationshipData(rs.getString("relationship_data"));
				aivr.setParameterData(rs.getString("parameter_data"));
				aivr.setUsedBy(rs.getString("used_by"));
				aivr.setUserId(rs.getLong("user_id"));
				
				if(log.isTraceEnabled()){
					log.trace("retAivRevHistoryByAivIdAndRevId || "+ aivr.toString());
				}
			}


		} catch (SQLException e) {
			log.error("retAivRevHistoryByAivIdAndRevId || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.REVISION_HISTORY_NOT_FOUND));
		} catch (IOException e) {
			log.error("retAivRevHistoryByAivIdAndRevId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("retAivRevHistoryByAivIdAndRevId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("retAivRevHistoryByAivIdAndRevId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retAivRevHistoryByAivIdAndRevId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("retAivRevHistoryByAivIdAndRevId || End");
		}
		return aivr;
	}
}
