package com.thbs.repopro.assetinstanceversion;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.activation.MimetypesFileTypeMap;
import javax.naming.directory.DirContext;
import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.GroupDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.assetinstance.AssetInstanceManager;
import com.thbs.repopro.dto.AddFavourites;
import com.thbs.repopro.dto.AivRevisionHistory;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstRelationship;
import com.thbs.repopro.dto.AssetInstVersionTaxonomy;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceData;
import com.thbs.repopro.dto.AssetInstanceParameter;
import com.thbs.repopro.dto.AssetInstanceValues;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetInstanceVersionRating;
import com.thbs.repopro.dto.AssetInstanceVersionTaxonomy;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.AssetRelationshipDef;
import com.thbs.repopro.dto.Category;
import com.thbs.repopro.dto.FilterData;
import com.thbs.repopro.dto.GamificationDetails;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.GroupAssetAccess;
import com.thbs.repopro.dto.GroupAssetInstVersionAccess;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.dto.NameValue;
import com.thbs.repopro.dto.Parameter;
import com.thbs.repopro.dto.ParameterData;
import com.thbs.repopro.dto.ParameterValues;
import com.thbs.repopro.dto.PossibleValues;
import com.thbs.repopro.dto.RecentActivity;
import com.thbs.repopro.dto.TaggingMaster;
import com.thbs.repopro.dto.TaxonomyMaster;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.gamification.GamificationDao;
import com.thbs.repopro.ldap.LDAPConnection;
import com.thbs.repopro.ldap.LDAPUser;
import com.thbs.repopro.ldap.LDAPUtility;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.recentactivity.RecentActivityDao;
import com.thbs.repopro.relationship.RelationshipDao;
import com.thbs.repopro.relationship.RelationshipManager;
import com.thbs.repopro.subscription.SubscriptionDao;
import com.thbs.repopro.tagging.TaggingManager;
import com.thbs.repopro.taxonomies.TaxonomiesDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.DeleteSrcFolderContent;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;
import com.thbs.repopro.util.RelationshipMyModel;

@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Path("/assetinstanceversion")

public class AssetInstanceVersionRest {
	
	private final static Logger log = LoggerFactory.getLogger("timeBased");
	private	Map<Long, List<TaxonomyMaster>> allTaxs =  null;
	List<Long> associatedTaxId = new ArrayList<Long>();
	
	void recurse(TaxonomyMaster t){

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);
			allTaxs.put(t.getTaxonomyId(), chldrn);
			for(TaxonomyMaster i: chldrn)
				recurse(i);
		}
		catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

	}

	void  recurse1(TaxonomyMaster t){

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);

			for(TaxonomyMaster a: chldrn){

				TaxonomyMaster t1 = new TaxonomyMaster();
				t1.setTaxonomyId(a.getTaxonomyId());
				t1.setTaxonomyName(a.getTaxonomyName());
				recurse1(t1);
				associatedTaxId.add(a.getTaxonomyId());
				associatedTaxId.add(t.getTaxonomyId());

			}
			associatedTaxId.add(t.getTaxonomyId());

		}catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
	}
	
	/*** Wrapper function ***/
	@POST
	@Encoded
	@Path("/add")
	public Response addAssetInstanceVersionsMain(@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetName") String assetName,
		    @QueryParam("copyFromVersion") String copyFromVersion,
		    @QueryParam("assetInstanceVersionName") String versionName,
		    @QueryParam("versionNotes") String versionNotes,
			@Context ServletContext context,@HeaderParam("token") String token) throws RepoproException {
		
		if(assetInstName == null|| assetName == null || copyFromVersion == null || versionName == null || versionNotes == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			copyFromVersion = URLDecoder.decode(copyFromVersion, "UTF-8");copyFromVersion = copyFromVersion.trim();
			versionName = URLDecoder.decode(versionName, "UTF-8");versionName = versionName.trim();
			versionNotes = URLDecoder.decode(versionNotes, "UTF-8");versionNotes = versionNotes.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetInstName.isEmpty()|| assetName.isEmpty() || copyFromVersion.isEmpty() || versionName.isEmpty() || versionNotes.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		if(versionNotes.trim().length()>10000|| versionName.trim().length()>10){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
			     .build();
		}
		
		String[] arr = versionName.trim().split("\\.");
		if(arr.length == 2){
			if (!arr[0].matches("[0-9]+") || !arr[1].matches("[0-9]+")) {
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil
								.getMessage(Constants.INCORRECT_FORMAT)))
								.build();
			}
		}else{
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INCORRECT_FORMAT)))
							.build();
		}
		
		log.trace("addAssetInstanceVersionsMain || Begin");
	
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		Boolean adminFlag = false;
		Boolean editFlag = false;
		Boolean viewFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

/*			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			
			User user = new User();
			if(!userName.equalsIgnoreCase("guest")){
				 user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			int activeFlag = Integer.parseInt(user.getActiveFlag());
			
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			AssetDao assetDao = new AssetDao();
			AssetInstanceDao assetInstDao = new AssetInstanceDao();
			AssetInstanceVersionDao assetInstanceVerDao = new AssetInstanceVersionDao();
			AssetInstance ai = new AssetInstance();
			AssetInstanceVersion aiv = new AssetInstanceVersion();
			AssetInstanceVersion addAssetInstVersiondata = new AssetInstanceVersion();
			addAssetInstVersiondata.setVersionName(versionName);
			addAssetInstVersiondata.setVersionNotes(versionNotes);
			
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceVersionsMain || dao method called : getAssetsByAssetName ");
			}
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			if (assetDef.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("addAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			int versionFlag;

			if (assetDef.isVersionable() == true) {
				versionFlag = 1;
			} else {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_VERSIONABLE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("addAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			// checking for asset relation type
			 RelationshipDao relationshipDao = new RelationshipDao();
			 boolean destFalg = false;
			List<AssetRelationshipDef> ardForDestAsset = new ArrayList<AssetRelationshipDef>();
			ardForDestAsset = relationshipDao.retAssetRelationshipDefByDestAssetId(assetDef.getAssetId(), null);
			for(AssetRelationshipDef ard :ardForDestAsset ){
				if(ard.getFwdRelId() == 1L || ard.getFwdRelId() == 5L){
					destFalg = true;
					break;
				}
			}
			if(destFalg){
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = "For child instance ,version can be added only in parent asset instance";
				retStatScsFlr = Constants.STATUS_FAILURE;

				log.trace("addAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceVersionsMain || dao method called : getAssetInstIdByName ");
			}
			Long assetInstanceId = assetInstDao.getAssetInstIdByName(assetInstName, assetDef.getAssetId(), null);
			
			if (assetInstanceId == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("addAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceVersionsMain || dao method called : findAdminRightsByUserName ");
			}
			  
;			
			if(!copyFromVersion.equalsIgnoreCase("none")){
				
			aiv = assetInstanceVerDao.getAssetinstDetails(assetName, assetInstName, copyFromVersion, null);	
			if(aiv == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.VERSION_NOT_AVAILABLE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("addAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			}
			
			if(adminFlag){
				assetInstName = URLEncoder.encode(assetInstName, "UTF-8");
				assetName = URLEncoder.encode(assetName, "UTF-8");
				response = aivManager.addAssetInstanceVersions(assetInstanceId, assetInstName, assetDef.getAssetId(), assetName, user.getUserId(),
						userName, versionFlag, copyFromVersion, activeFlag, addAssetInstVersiondata, context);
			
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				if(res.getMessage().equalsIgnoreCase("ASSET_INSTANCE_VERSION_NAME_EXIST")){
					json.put("message", res.getMessage());
					json.put("status", Constants.FAILURE);
					json.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("addAssetInstanceVersionsMain || End");
					
					retStat = Status.BAD_REQUEST;
					return Response.status(retStat).entity(json.toString())
							.build();
				}else{
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("addAssetInstanceVersionsMain || End");
				
				return Response.status(retStat).entity(json.toString())
						.build();
				}
			}else{
				
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList1 = new ArrayList<GroupAssetInstVersionAccess>();
			//if(copyFromVersion.equalsIgnoreCase("none")){
				List<AssetInstanceVersion> aivList1 = assetInstanceVerDao.getAssetInstanceVersions(assetInstanceId,null);

				for (AssetInstanceVersion aii : aivList1) {
					
					groupAssetInstVersionAccessList1 = assetInstanceVerDao.retAivAccessRights(aii.getAssetInstVersionId(), userName, null);
					for (int i = 0; i < groupAssetInstVersionAccessList1.size(); i++) {
						if (groupAssetInstVersionAccessList1.get(i).getEditAccess().equals(1L)) {
							editFlag = true;
							break;
						}
					}
			}
				if(!editFlag){
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
				//}
				if(!copyFromVersion.equalsIgnoreCase("none") ){
				
				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceVersionsMain || dao method called : retAivAccessRights ");
				}
				
				groupAssetInstVersionAccessList = assetInstanceVerDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);
	            // for copy from version we need to check view access ,not edit access.
				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
						viewFlag = true;
						break;
					}
				}
				if( !viewFlag){
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
				}
				
			if(editFlag == true ){
				assetInstName = URLEncoder.encode(assetInstName, "UTF-8");
				assetName = URLEncoder.encode(assetName, "UTF-8");
				response = aivManager.addAssetInstanceVersions(assetInstanceId, assetInstName, assetDef.getAssetId(), assetName, user.getUserId(),
						userName, versionFlag, copyFromVersion, activeFlag, addAssetInstVersiondata, context);
			
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				if(res.getMessage().equalsIgnoreCase("ASSET_INSTANCE_VERSION_NAME_EXIST")){
					json.put("message", res.getMessage());
					json.put("status", Constants.FAILURE);
					json.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("addAssetInstanceVersionsMain || End");
					
					retStat = Status.BAD_REQUEST;
					return Response.status(retStat).entity(json.toString())
							.build();
				}else{
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("addAssetInstanceVersionsMain || End");
				
				return Response.status(retStat).entity(json.toString())
						.build();
				}
			
			}
			}
		} catch (RepoproException e) {
			log.error("addAssetInstanceVersionsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addAssetInstanceVersionsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}

		log.trace("addAssetInstanceVersionsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/*** Wrapper function ***/
	@PUT
	@Encoded
	@Path("/update")
	public Response updateAssetInstanceVersionsMain(@QueryParam("assetInstanceName") String assetInstanceName,
			@QueryParam("assetInstanceVersionName") String assetVersionName, 
			@QueryParam("assetName") String assetName,
			@QueryParam("newAssetInstanceVersionName") String versionName,
			@QueryParam("versionNotes") String versionNotes,@HeaderParam("token") String token) {
		
		if(assetInstanceName == null|| assetVersionName == null || assetName == null|| versionName == null || versionNotes == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetInstanceName = URLDecoder.decode(assetInstanceName, "UTF-8");assetInstanceName = assetInstanceName.trim();
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
			versionName = URLDecoder.decode(versionName, "UTF-8");versionName = versionName.trim();
			versionNotes = URLDecoder.decode(versionNotes, "UTF-8");versionNotes = versionNotes.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetInstanceName.isEmpty()|| assetVersionName.isEmpty() || assetName.isEmpty()|| versionName.isEmpty() || versionNotes.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		if(versionNotes.trim().length()>10000|| versionName.trim().length()>10){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
			     .build();
		}
		
		String[] arr = versionName.trim().split("\\.");
		if(arr.length == 2){
			if (!arr[0].matches("[0-9]+") || !arr[1].matches("[0-9]+")) {
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil
								.getMessage(Constants.INCORRECT_FORMAT)))
								.build();
			}
		}else{
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INCORRECT_FORMAT)))
							.build();
		}
		
		log.trace("updateAssetInstanceVersionsMain || Begin");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			// checking for versionabale asset 
			 AssetDao assetDao = new AssetDao();
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			if (assetDef.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("updateAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			if (assetDef.isVersionable() == false) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_VERSIONABLE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("updateAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			AssetInstanceVersion assetInstanceVer = new AssetInstanceVersion();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();

			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
		
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceVersionsMain || dao method called : getAssetinstDetails ");
			}
			
			if(!userName.equalsIgnoreCase("roleAnonymous")){
			
			assetInstanceVer = assetInstVersionDao.getAssetinstDetails(assetName, assetInstanceName, assetVersionName, null);
		
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("updateAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			AssetInstanceVersion updateAssetInstVersiondata = new AssetInstanceVersion();
			updateAssetInstVersiondata.setVersionName(versionName);
			updateAssetInstVersiondata.setVersionNotes(versionNotes);
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			Boolean editFlag = false;
			
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceVersionsMain || dao method called : retAivAccessRights ");
			}
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVer.getAssetInstVersionId(), userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
					editFlag = true;
					break;
				}
			}

			if (editFlag) {
				assetInstanceName = URLEncoder.encode(assetInstanceName, "UTF-8");
				assetName = URLEncoder.encode(assetName, "UTF-8");
				response = aivManager.updateAssetInstanceVersions(assetInstanceVer.getAssetInstanceId(), assetInstanceName, assetInstanceVer.getAssetId(), assetInstanceVer.getVersionName(),
						assetName, userName, assetInstanceVer.getAssetInstVersionId(), updateAssetInstVersiondata);
				MyModel res = (MyModel) response.getEntity();
				JSONObject json = new JSONObject();
				if(res.getMessage().equalsIgnoreCase("ASSET_INSTANCE_VERSION_NAME_EXIST")){
					json.put("message", res.getMessage());
					json.put("status", Constants.FAILURE);
					json.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("addAssetInstanceVersionsMain || End");
					
					retStat = Status.BAD_REQUEST;
					return Response.status(retStat).entity(json.toString())
							.build();
				}else if(res.getMessage().equalsIgnoreCase("NO_CHANGES_TO_UPDATE")){
					json.put("message", res.getMessage());
					json.put("status", Constants.SUCCESS);
					json.put("statusCode", Constants.GET_STATUS_SUCCESS);
					log.trace("addAssetInstanceVersionsMain || End");
					
					retStat = Status.OK;
					return Response.status(retStat).entity(json.toString())
							.build();
				
				}else{
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("updateAssetInstanceVersionsMain || End");
				
				return Response.status(retStat).entity(json.toString())
						.build();
				}
			} else {

				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("updateAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			}
			else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("updateAssetInstanceVersionsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			
			}
			
		} catch (RepoproException e) {
			log.error("updateAssetInstanceVersionsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("updateAssetInstanceVersionsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 
		log.trace("updateAssetInstanceVersionsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/*** Wrapper function ***/
	@DELETE
	@Encoded
	@Path("/delete")
	public Response deleteAssetInstanceVersionsMain(@QueryParam("assetInstanceName") String assetInstName,
	        @QueryParam("assetName") String assetName,
	        @QueryParam("assetInstanceVersionName") String versionName,
	        @HeaderParam("token") String token) throws RepoproException {
		
		if(assetInstName == null|| assetName == null || versionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			versionName = URLDecoder.decode(versionName, "UTF-8");versionName = versionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetInstName.isEmpty()|| assetName.isEmpty() || versionName .isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("deleteAssetInstanceVersionsMain || Begin");
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		User user = new User();
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/			
			if(!userName.equalsIgnoreCase("guest")){
			 user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			} else {
				
				AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
				
				AssetInstanceVersion aiv = new AssetInstanceVersion();
				//User user = new User();
				
			 aiv = 	assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, versionName, null);
			 if (aiv == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("deleteAssetInstanceVersionsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
			 
			 int versionFlag;

				if (aiv.getVersionable() == true) {
					versionFlag = 1;
				} else {
					versionFlag = 0;
				}
			 
			 List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				boolean deleteFlag = false;
				
				if (log.isTraceEnabled()) {
					log.trace("deleteAssetInstanceVersionsMain || dao method called : retAivAccessRights ");
				}
				groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);

				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getDeleteAccess().equals(1L)) {
						deleteFlag = true;
						break;
					}
				}

				if (deleteFlag) {

					AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
					assetInstName = URLEncoder.encode(assetInstName, "UTF-8");
					assetName = URLEncoder.encode(assetName, "UTF-8");
					response = aivManager.deleteAssetInstanceVersions(aiv.getAssetInstanceId(),
							assetInstName, aiv.getAssetId(), assetName, userName, user.getUserId(),
							versionFlag, aiv.getAssetInstVersionId(), versionName);
					
					MyModel res = (MyModel) response.getEntity();				
					JSONObject json = new JSONObject();
					
					json.put("message", res.getMessage());
					json.put("status", res.getStatus());
					json.put("statusCode", res.getStatusCode());
					log.trace("deleteAssetInstanceVersionsMain || End");
					
					return Response.status(retStat).entity(json.toString())
							.build();

				} else {

					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("deleteAssetInstanceVersionsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			
			}
		} catch (RepoproException e) {
			log.error("deleteAssetInstanceVersionsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("deleteAssetInstanceVersionsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 

		log.trace("deleteAssetInstanceVersionsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/getTags")
	public Response getAllTagsMain(@QueryParam("assetName")String assetName,
			@QueryParam("assetInstanceName")String assetInstName,
			@QueryParam("assetInstanceVersionName")String assetVersionName,
			@HeaderParam("token") String token) {
		
		if(assetName == null|| assetVersionName == null || assetInstName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetVersionName.isEmpty() || assetInstName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getAllTagsMain || Begin");
		Connection conn = null;
		Response response = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		boolean viewFlag = false;
		boolean adminFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (log.isTraceEnabled()) {
				log.trace("getAllTagsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			AssetInstanceVersion aiv = new AssetInstanceVersion();
			TaggingManager tagManager = new TaggingManager();
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			
			if(!userName.equalsIgnoreCase("guest")){
				AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
				
				if(assetInstanceVer == null){
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("getAllTagsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				adminFlag = assetInstVersionDao.findAdminRightsByUserName(userName, null);
				long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
				
				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVersionId, userName, null);
			    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
					    viewFlag = true;
					    break;
				    }
			    }

			    if (adminFlag || viewFlag) {
			    	response = tagManager.getAllTags(assetInstanceVersionId);
					MyModel res = (MyModel) response.getEntity();
					List<Object> data = res.getResult();
					JSONObject j1 = null;
					JSONObject json = new JSONObject();
					
					if(data.isEmpty()){
						json.put("message", res.getMessage());
						json.put("status", Constants.SUCCESS);
						json.put("statusCode", Constants.GET_STATUS_SUCCESS);
						log.trace("getAllTagsMain || End");
						return Response.status(Status.OK).entity(json.toString()).build();
					}
					
					List<Object> finaldata = new ArrayList<Object>();
					List<String> tagsList = new ArrayList<String>();
					for (int i = 0; i < data.size(); i++) {
						j1 = new JSONObject();
						TaggingMaster tm = new TaggingMaster();
						tm = (TaggingMaster) data.get(i);
						for(Map.Entry<Long, String> entry : tm.getTagNames().entrySet()){
							tagsList.add(entry.getValue());
						}
						j1.put("tagNames", tagsList);
						finaldata.add(j1);
					}
					json.put("result", finaldata);
					json.put("message", res.getMessage());
					json.put("status", res.getStatus());
					json.put("statusCode", res.getStatusCode());
					log.trace("getAllTagsMain || End");
					
					return Response.status(retStat).entity(json.toString())
							.build();
					
			    } else {
			    	retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
				 	return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
							.build();
			    }
			}
			
			else{
				userName = "roleAnonymous";
				AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);

				aiv = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);

				if (aiv == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("getAllTagsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}

				AssetDao assetDao = new AssetDao();
				AssetInstanceDao assetInstDao = new AssetInstanceDao();
				List<AssetInstance> assetInsatnceList = new ArrayList<AssetInstance>();
				AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);

				if(assetDef.isGuestflag() == true){
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(aiv.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							response = tagManager.getAllTags(assetInstanceVer.getAssetInstVersionId());
							MyModel res = (MyModel) response.getEntity();
							List<Object> data = res.getResult();
							JSONObject j1 = new JSONObject();
							JSONObject json = new JSONObject();
							
							if(data.isEmpty()){
								json.put("message", res.getMessage());
								json.put("status", Constants.SUCCESS);
								json.put("statusCode", Constants.GET_STATUS_SUCCESS);
								log.trace("getAllTagsMain || End");
								return Response.status(Status.OK).entity(json.toString()).build();
							}
							
							List<Object> finaldata = new ArrayList<Object>();
							List<String> tagsList = new ArrayList<String>();
							for (int i = 0; i < data.size(); i++) {
								TaggingMaster tm = new TaggingMaster();
								tm = (TaggingMaster) data.get(i);
								for(Map.Entry<Long, String> entry : tm.getTagNames().entrySet()){
									tagsList.add(entry.getValue());
								}
								j1.put("tagNames", tagsList);
								finaldata.add(j1);
							}
							json.put("result", finaldata);
							json.put("message", Constants.ASSET_INSTANCE_VERSION_ID_TAGS_FETCHED);
							json.put("status", res.getStatus());
							json.put("statusCode", res.getStatusCode());
							log.trace("getAllTagsMain || End");
							
							return Response.status(retStat).entity(json.toString())
									.build();
						}else{
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getAllTagsMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					
					log.trace("getAllTagsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			
			
		} catch (RepoproException e) {
			log.error("getAllTagsMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllTagsMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllTagsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllTagsMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

/***Wrapper function***/

	@POST
	@Encoded
	@Path("/updateTag")
	public Response addTagsMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName, 
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@QueryParam("tagNames") String tagNames, @HeaderParam("token") String token) {
		
		if(assetName == null|| assetVersionName == null || assetInstName == null || tagNames == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
			tagNames = URLDecoder.decode(tagNames, "UTF-8");tagNames = tagNames.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetVersionName.isEmpty() || assetInstName.isEmpty() || tagNames.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("addTagsMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addTagsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			response = this.addTagsMainHelper(assetName, assetInstName, assetVersionName, tagNames, "",token,false, false, conn);
			
			/*MyModelRest modelRest = null;
			int statusCode = 0;
			String statusMessage = "";
			if(response.getEntity() instanceof MyModelRest){
				modelRest = (MyModelRest) response.getEntity();
			}
			if(modelRest != null){
				statusCode = response.getStatus();
				statusMessage = modelRest.getMessage();
			}
			
			if((statusCode == 200) && (Constants.TAGS_SAVED_SUCCESSFULLY.equalsIgnoreCase(statusMessage)||Constants.ASSET_INSTANCE_VERSION_UPDATED_AND_UNLOCKED.equalsIgnoreCase(statusMessage))){
				conn.commit();
			}*/ 
			 
			return response;
			
		} catch (RepoproException e) {
			log.error("addTagsMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("addTagsMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addTagsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("addTagsMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	public Response addTagsMainHelper(String assetName,
			 String assetInstName, String assetVersionName,
			 String tagNames,String unassignTags,String token,boolean commitFlag, boolean compositeFlag, Connection conn)throws RepoproException {
								
		log.trace("addTagsMain || Begin");
		Connection conn1 = null;
		Response response = null;
		TaggingMaster master = new TaggingMaster();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		boolean editFlag = false;
		boolean adminFlag = false;
		UserDao userDao = new UserDao();
		User user1 = new User();
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		assetVersionName = assetVersionName.trim();
		if(tagNames != null){
			tagNames = tagNames.trim();
		}
		if(unassignTags != null){
			unassignTags = unassignTags.trim();
		}
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(conn == null){
				if (log.isTraceEnabled()) {
					log.trace("addTagsMain || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if(!userName.equalsIgnoreCase("guest")){
				user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			TaggingManager tagManager = new TaggingManager();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			Map<Long, String> tagMap = new LinkedHashMap<Long, String>();
			if(tagNames != null){
				if(tagNames.endsWith(",") || tagNames.startsWith(","))
				{
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
			}
			
			List<String> tagsList = new ArrayList<String>();
			if(tagNames != null){
				if(!tagNames.isEmpty()){
					tagsList = Arrays.asList(tagNames.split(","));
				}
			}
			
			Long i=1l;
			boolean tagFlag = false;
			
			for(String tagging : tagsList){
				if(tagging.trim().isEmpty()){
					tagFlag = true;
					break;
				}else{
					tagMap.put(i, tagging);
					i++;
				}
			}
			if(tagFlag){
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.EMPTY_TAG_NAME_NOT_ALLOWED;
				retStatScsFlr = Constants.STATUS_FAILURE;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
			
			if(unassignTags != null){
				if(unassignTags.endsWith(",") || unassignTags.startsWith(",")){
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
			}
			
			List<String> unassignTagsList = new ArrayList<String>();
			if(unassignTags != null){
				if(!unassignTags.isEmpty()){
					unassignTagsList = Arrays.asList(unassignTags.split(","));
				}
			}
			boolean unassignTagFlag = false;
			
			for(String tagging : unassignTagsList){
				if(tagging.trim().isEmpty()){
					unassignTagFlag = true;
					break;
				}
			}
			if(unassignTagFlag){
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.EMPTY_TAG_NAME_NOT_ALLOWED;
				retStatScsFlr = Constants.STATUS_FAILURE;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
			
			List<String> tagList = new ArrayList<String>();
			if(tagNames != null){
				if(!tagNames.isEmpty()){
					tagList = new ArrayList<String>(Arrays.asList(tagNames.split(",")));
				}
				boolean duplicateFlag = false;
				Set<String> duplicate = new HashSet<String>();
				duplicate.addAll(tagList);
				if(duplicate.size()<tagList.size()){
					duplicateFlag = true;
				}
				if(duplicateFlag){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.DUPLICATE_TAGS_NOT_ALLOWED;
					retStatScsFlr = Constants.STATUS_FAILURE;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
							.build();
				}
			}			
			
			List<String> unassignTagList = new ArrayList<String>();
			if(unassignTags != null){
				if(!unassignTags.isEmpty()){
					unassignTagList = new ArrayList<String>(Arrays.asList(unassignTags.split(",")));
				}
				boolean duplicateFlag = false;
				Set<String> duplicate = new HashSet<String>();
				duplicate.addAll(unassignTagList);
				if(duplicate.size()<unassignTagList.size()){
					duplicateFlag = true;
				}
				if(duplicateFlag){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.DUPLICATE_TAGS_NOT_ALLOWED;
					retStatScsFlr = Constants.STATUS_FAILURE;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
							.build();
				}
			}	
			
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();	
			}
			
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			
			if(assetInstanceVer == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("addTagsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
			
			master.setAssetInstanceVersionId(assetInstanceVersionId);
			master.setTagNames(tagMap);
			master.setUserId(user1.getUserId());
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			adminFlag = assetInstVersionDao.findAdminRightsByUserName(userName, conn);
			if(!adminFlag){
				if (log.isTraceEnabled()) {
					log.trace("addTagsMain || dao method called : retAivAccessRights ");
				}
				groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVersionId, userName, conn);

				for (int j = 0; j < groupAssetInstVersionAccessList.size(); j++) {
					if (groupAssetInstVersionAccessList.get(j).getEditAccess().equals(1L)) {
						editFlag = true;
						break;
					}
				}
			}else{
				editFlag = true;
			}
			
			AssetInstanceVersion aiv = assetInstVersionDao.getAssetInstanceVersionDetails(assetInstanceVersionId,conn);

			if(editFlag){
				
				for(String tagg : tagsList){
					//String newRegex = "^((?=[\\w+\\s,-_~]).)*$";
					String newRegex = "^((?=[\\w+\\s-_])(?![\\[\\]\\?\\.\\\\@#^\\+\\=:;<>/]).)*$";
					Pattern pattern = Pattern.compile(newRegex);
					Matcher matcher = pattern.matcher(tagg);
					
					if(!matcher.find()){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_TAGS)))
								.build();
					}
					if(tagg.trim().length()>50){
						   return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
						     .build();
					}
				}
				
				for(String tagg : unassignTagsList){
					//String newRegex = "^((?=[\\w+\\s,-_~]).)*$";
					String newRegex = "^((?=[\\w+\\s-_])(?![\\[\\]\\?\\.\\\\@#^\\+\\=:;<>/]).)*$";
					Pattern pattern = Pattern.compile(newRegex);
					Matcher matcher = pattern.matcher(tagg);
					
					if(!matcher.find()){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_TAGS)))
								.build();
					}
					if(tagg.trim().length()>50){
						   return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
						     .build();
					}
				}
				
				if(aiv.getLockedBy() == null){
					if(compositeFlag == false){
						response = tagManager.addTagsHelper(master,commitFlag,conn);
						MyModel res = (MyModel) response.getEntity();				
						
						log.trace("addTagsMain || End");
						
						return Response.status(retStat)
								.entity(new MyModelRest(res.getStatusCode(), res.getStatus(),
										res.getMessage())).build();
					}else{
						response = assetInstVersionDao.addOrRemoveTags(tagNames, unassignTags, String.valueOf(assetInstanceVersionId), userName, conn);
						MyModelRest res = (MyModelRest) response.getEntity();
						
						if(res.getMessage().equalsIgnoreCase(Constants.TAGS_SAVED_SUCCESSFULLY)){
							retMsg = Constants.TAGS_SAVED_SUCCESSFULLY;
							retScsFlr = Constants.SUCCESS;
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
							return Response.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr,
											retMsg)).build();
						}else{
							return response;
						}					
					}
					

				}else if(aiv.getLockedBy().equalsIgnoreCase(userName)){
					if(compositeFlag == false){
						response = tagManager.addTagsHelper(master,commitFlag,conn);
						MyModel res = (MyModel) response.getEntity();	
						
						/*AssetInstanceVersion aiv2 = new AssetInstanceVersion();
						AssetInstanceVersionDao aivdao = new AssetInstanceVersionDao();
						aiv2.setAssetInstVersionId(aiv.getAssetInstVersionId());
						aiv2.setLockedBy(null);
						aiv2.setLockTime(null);
						aivdao.updateAssetInstanceVersion(aiv2, conn);*/
						
						if(res.getMessage().equalsIgnoreCase(Constants.TAGS_SAVED_SUCCESSFULLY)){
							retMsg = Constants.TAGS_SAVED_SUCCESSFULLY;
							retScsFlr = Constants.SUCCESS;
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
						}
						
						return Response.status(retStat)
								.entity(new MyModelRest(res.getStatusCode(), res.getStatus(), 
										res.getMessage())).build();
					}else{
						response = assetInstVersionDao.addOrRemoveTags(tagNames, unassignTags, String.valueOf(assetInstanceVersionId), userName, conn);
						MyModelRest res = (MyModelRest) response.getEntity();
						
						if(res.getMessage().equalsIgnoreCase(Constants.TAGS_SAVED_SUCCESSFULLY)){
							retMsg = Constants.TAGS_SAVED_SUCCESSFULLY;
							retScsFlr = Constants.SUCCESS;
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
							return Response.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr,
											retMsg)).build();
						}else{
							return response;
						}
					}
				}
				else{
					JSONObject json = new JSONObject();
					
					json.put("message", Constants.ASSET_INSTANCE_VERSION_LOCKED);
					json.put("status", Constants.NOT_AUTHORIZED);
					json.put("statusCode", Constants.FORBIDDEN);
					log.trace("addTagsMain || End");
					retStat = Status.FORBIDDEN;
					return Response.status(retStat).entity(json.toString())
							.build();
				}
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("addTagsMain || End");
				/*return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();*/
			}
			
		} catch (RepoproException e) {
			log.error("addTagsMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("addTagsMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
		} finally {
			if(conn1 != null){
			if (log.isTraceEnabled()) {
				log.trace("addTagsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			}
		}

		log.trace("addTagsMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/retTaxonomy")
	public Response retTaxonomyIdByAssetInstVersionIdMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName, 
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@HeaderParam("token") String token) throws RepoproException {
		
		if(assetName == null|| assetVersionName == null || assetInstName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetVersionName.isEmpty() || assetInstName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("retTaxonomyIdByAssetInstVersionIdMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		boolean adminFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersion aiv = new AssetInstanceVersion();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			AssetDao assetDao = new AssetDao();
			TaxonomiesDao taxonomyDao = new TaxonomiesDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			if (assetDef.getAssetId() == null) {

				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("retTaxonomyIdByAssetInstVersionIdMain || Begin");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();

			}
			
			List<AssetInstanceVersionTaxonomy> aivTaxonomyList = new ArrayList<AssetInstanceVersionTaxonomy>();
			List<Long> taxList = new ArrayList<Long>();
			List<String> taxdata = new ArrayList<String>();
			
			if (log.isTraceEnabled()) {
				log.trace("retTaxonomyIdByAssetInstVersionIdMain || dao method called : getAssetinstDetails ");
			}
			if (!userName.equalsIgnoreCase("roleAnonymous")) {

				aiv = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);

				if (aiv == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("retTaxonomyIdByAssetInstVersionIdMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();

				}
				adminFlag = assetInstVersionDao.findAdminRightsByUserName(userName, null);

				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				
				Boolean viewFlag = false;

				if (log.isTraceEnabled()) {
					log.trace("retTaxonomyIdByAssetInstVersionIdMain || dao method called : retAivAccessRights ");
				}
				groupAssetInstVersionAccessList = assetInstVersionDao
						.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);

				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
						viewFlag = true;
						break;
					}
				}
				if (adminFlag || viewFlag) {
					aivTaxonomyList = assetInstVersionDao.retTaxonomyIdByAssetInstVersionId(aiv.getAssetInstVersionId(), null);
					
					for(AssetInstanceVersionTaxonomy aivt : aivTaxonomyList){
						taxList.add(aivt.getTaxonomyId());
					}
					String taxIds = StringUtils.join(taxList, ',');
					String[] splittaxs = taxIds.split(",");
					
					if(splittaxs!=null){
						Long parentTaxId = 0L;
						Long childtaxId = 0L;
						for(int j = 0; j < splittaxs.length; j++){
							if(!splittaxs[j].isEmpty() && splittaxs[j]!=null){
								if(j<splittaxs.length){
									ArrayList<String> mylist = new ArrayList<String>();
									TaxonomyMaster taxonomy = taxonomyDao.getTaxonomiesByTaxId(Long.parseLong(splittaxs[j]), null);
									childtaxId = taxonomy.getTaxonomyId();
									while(!childtaxId.equals(1L)){
										TaxonomyMaster parentTaxonomy = taxonomyDao.getTaxonomiesByTaxId(childtaxId, null);
										parentTaxId = parentTaxonomy.getParenttaxonomyId();
										mylist.add(parentTaxonomy.getTaxonomyName());
										childtaxId = parentTaxId;
									}
									String taxValue = "";
									for(int i=mylist.size()-1;i>=0;i--){
										taxValue = taxValue + mylist.get(i).concat("/");
									}
									if (taxValue.endsWith("/")) {
										taxValue = taxValue.substring(0, taxValue.length() - "/".length());
								     }
									aivTaxonomyList.get(j).setTaxonomyName(taxValue);
									taxdata.add(taxValue);
								}
							}
						}
					}
					
				     JSONObject j1 = null;
				     JSONObject json = new JSONObject();
				     List<Object> finaldata = new ArrayList<Object>();
				     for (int i = 0; i < aivTaxonomyList.size(); i++) {
				    	 j1 = new JSONObject();
				    	 AssetInstanceVersionTaxonomy aivt = new AssetInstanceVersionTaxonomy();
				    	 aivt = (AssetInstanceVersionTaxonomy) aivTaxonomyList.get(i);
				    	 
				    	 j1.put("taxonomyName", aivt.getTaxonomyName());
				    	 
				    	 finaldata.add(j1);

				     }
				     json.put("result", finaldata);
				     json.put("message", Constants.TAXONOMIES_BY_AIV_ID_FETCHED);
				     json.put("status", Constants.SUCCESS);
				     json.put("statusCode", Constants.GET_STATUS_SUCCESS);

				     log.trace("retTaxonomyIdByAssetInstVersionIdMain || End");
				     return Response.status(retStat).entity(json.toString())
				       .build();
					
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("retTaxonomyIdByAssetInstVersionIdMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}
			else{
				aiv = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);

				if (aiv == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("retTaxonomyIdByAssetInstVersionIdMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}

				AssetInstanceDao assetInstDao = new AssetInstanceDao();
				List<AssetInstance> assetInsatnceList = new ArrayList<AssetInstance>();

				if(assetDef.isGuestflag() == true){
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(aiv.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							aivTaxonomyList = assetInstVersionDao.retTaxonomyIdByAssetInstVersionId(aiv.getAssetInstVersionId(), null);
							
							for(AssetInstanceVersionTaxonomy aivt : aivTaxonomyList){
								taxList.add(aivt.getTaxonomyId());
							}
							String taxIds = StringUtils.join(taxList, ',');
							String[] splittaxs = taxIds.split(",");
							
							if(splittaxs!=null){
								Long parentTaxId = 0L;
								Long childtaxId = 0L;
								for(int j = 0; j < splittaxs.length; j++){
									if(!splittaxs[j].isEmpty() && splittaxs[j]!=null){
										if(j<splittaxs.length){
											ArrayList<String> mylist = new ArrayList<String>();
											TaxonomyMaster taxonomy = taxonomyDao.getTaxonomiesByTaxId(Long.parseLong(splittaxs[j]), null);
											childtaxId = taxonomy.getTaxonomyId();
											while(!childtaxId.equals(1L)){
												TaxonomyMaster parentTaxonomy = taxonomyDao.getTaxonomiesByTaxId(childtaxId, null);
												parentTaxId = parentTaxonomy.getParenttaxonomyId();
												mylist.add(parentTaxonomy.getTaxonomyName());
												childtaxId = parentTaxId;
											}
											String taxValue = "";
											for(int i=mylist.size()-1;i>=0;i--){
												taxValue = taxValue + mylist.get(i).concat("/");
											}
											if (taxValue.endsWith("/")) {
												taxValue = taxValue.substring(0, taxValue.length() - "/".length());
										     }
											aivTaxonomyList.get(j).setTaxonomyName(taxValue);
											taxdata.add(taxValue);
										}
									}
								}
							}
							
							 JSONObject j1 = null;
						     JSONObject json = new JSONObject();
						     List<Object> finaldata = new ArrayList<Object>();
						     for (int i = 0; i < aivTaxonomyList.size(); i++) {
						    	 j1 = new JSONObject();
						    	 AssetInstanceVersionTaxonomy aivt = new AssetInstanceVersionTaxonomy();
						    	 aivt = (AssetInstanceVersionTaxonomy) aivTaxonomyList.get(i);
						    	 
						    	 j1.put("taxonomyName", aivt.getTaxonomyName());
						    	 
						    	 finaldata.add(j1);

						     }
						     json.put("result", finaldata);
						     json.put("message", Constants.TAXONOMIES_BY_AIV_ID_FETCHED);
						     json.put("status", Constants.SUCCESS);
						     json.put("statusCode", Constants.GET_STATUS_SUCCESS);

						     log.trace("retTaxonomyIdByAssetInstVersionIdMain || End");
						     return Response.status(retStat).entity(json.toString())
						       .build();
						}else{
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("retTaxonomyIdByAssetInstVersionIdMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;


					log.trace("retTaxonomyIdByAssetInstVersionIdMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
			}
			 
		} catch (RepoproException e) {
			log.error("retTaxonomyIdByAssetInstVersionIdMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("retTaxonomyIdByAssetInstVersionIdMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 
		log.trace("retTaxonomyIdByAssetInstVersionIdMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/*** Wrapper function ***/
	@PUT
	@Encoded
	@Path("/assignTaxonomy")
	public Response addTaxonomyForAssetInstanceVersionMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName, 
			@QueryParam("assetInstanceVersionName") String versionName, 
			@QueryParam("taxonomyName") String taxonomyName, @HeaderParam("token") String token) {
		
		if(assetName == null|| assetInstName == null || versionName == null || taxonomyName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			versionName = URLDecoder.decode(versionName, "UTF-8");versionName = versionName.trim();
			taxonomyName = URLDecoder.decode(taxonomyName, "UTF-8");taxonomyName = taxonomyName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstName .isEmpty() || versionName.isEmpty() || taxonomyName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("addTaxonomyForAssetInstanceVersionMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyForAssetInstanceVersionMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			response = this.addTaxonomyForAssetInstanceVersionMainHelper(assetName, assetInstName, versionName, taxonomyName, "", token,false,false,conn);
			
			MyModel model = null;
			int statusCode = 0;
			String statusMessage = "";
			if(response.getEntity() instanceof MyModel){
				model = (MyModel) response.getEntity();
			}
			if(model != null){
				statusCode = response.getStatus();
				statusMessage = model.getMessage();
			}
			if(statusMessage.equalsIgnoreCase("SUCCESS")){
				retMsg = Constants.TAXONOMY_ASSIGNED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}else{
				retMsg = model.getMessage();
				retScsFlr = model.getStatus();
				retStatScsFlr = model.getStatusCode();
				return Response
						.status(response.getStatus())
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			/*if((statusCode == 200) && (Constants.TAXONOMY_ASSIGNED_SUCCESSFULLY.equalsIgnoreCase(statusMessage)||Constants.ASSET_INSTANCE_VERSION_UPDATED_AND_UNLOCKED.equalsIgnoreCase(statusMessage))){
				conn.commit();
			}*/
			
			
		} catch (RepoproException e) {
			log.error("addTaxonomyForAssetInstanceVersionMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("addTaxonomyForAssetInstanceVersionMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
		} finally {
			if(conn != null){
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyForAssetInstanceVersionMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		}

		log.trace("addTaxonomyForAssetInstanceVersionMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	public Response addTaxonomyForAssetInstanceVersionMainHelper(String assetName,
			 String assetInstName,  String versionName, 
			 String taxonomyName, String unassignTaxonomy, String token ,boolean commitFlag, boolean compositeFlag, Connection conn)throws RepoproException {
		
		log.trace("addTaxonomyForAssetInstanceVersionMain || Begin");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		boolean editFlag = false;
		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
		Connection conn1 = null;
		allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
		List<AssetInstVersionTaxonomy>   assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
		List<AssetInstVersionTaxonomy>   assetInstunassignList = new ArrayList<AssetInstVersionTaxonomy>();
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		versionName = versionName.trim();
		if(taxonomyName != null){
			taxonomyName = taxonomyName.trim();
		}
		if(unassignTaxonomy != null){
			unassignTaxonomy = unassignTaxonomy.trim();
		}
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		try {
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
				
			}
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}
			if (userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("addTaxonomyForAssetInstanceVersionMain || End");
				return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
			Map<String, String> taxMap = new HashMap<String, String>();
			if (userName != "roleAnonymous") {
				AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
				AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
				TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
				boolean addFlag = false;
				boolean flag1 = false;
				boolean unlockFlag = false;
				AssetDao assetDao = new AssetDao();
				AssetInstanceDao assetInstDao = new AssetInstanceDao();
				AssetInstance ai = new AssetInstance();
				AssetInstanceVersion aiv = new AssetInstanceVersion();
				TaxonomiesDao taxDao = new TaxonomiesDao();
				boolean TaxAssignedForAsset = false;

				AssetDef ad = assetDao.getAssetsByAssetName(assetName, conn);
				if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("addTaxonomyForAssetInstanceVersionMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();

				}
				
				List<TaxonomyMaster> tax = taxDao.getAllTaxonomiesByAssetId(
						ad.getAssetId(), conn);

				if (log.isTraceEnabled()) {
					log.trace("addTaxonomyForAssetInstanceVersionMain || dao method called : getAssetinstDetails ");
				}
				aiv = assetInstVersionDao.getAssetinstDetails(assetName,
						assetInstName, versionName, conn);

				if (aiv == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("addTaxonomyForAssetInstanceVersionMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();

				}

				if (log.isTraceEnabled()) {
					log.trace("addTaxonomyForAssetInstanceVersionMain || dao method called : findAdminRightsByUserName ");
				}

				addFlag = assetInstVersionDao.findAdminRightsByUserName(userName, conn);

				if (!addFlag) {
					List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
					groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, conn);
					for (int j = 0; j < groupAssetInstVersionAccessList.size(); j++) {
						if (groupAssetInstVersionAccessList.get(j).getEditAccess().equals(1L)) {
							editFlag = true;
							break;
						}
					}
				}else{
					editFlag = true;
				}

				AssetInstanceVersion assetInstanceVersion = assetInstVersionDao.getAssetInstanceVersionDetails(aiv.getAssetInstVersionId(),conn);
				if(editFlag){
					if(assetInstanceVersion.getLockedBy() == null){
						flag1 = true;

					}else if(assetInstanceVersion.getLockedBy().equalsIgnoreCase(userName)){
						flag1 = true;
						unlockFlag = true;
					}
					else{
						retMsg = Constants.ASSET_INSTANCE_VERSION_LOCKED;
						retScsFlr = Constants.NOT_AUTHORIZED;
						retStatScsFlr = Constants.FORBIDDEN;
						retStat = Status.FORBIDDEN;
						log.trace("addTaxonomyForAssetInstanceVersionMain || End");
						return Response.status(retStat)
								.entity(new MyModel(retStatScsFlr, retScsFlr,
										retMsg)).build();
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("addTaxonomyForAssetInstanceVersionMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
				}

				if (editFlag && flag1) {
					if (log.isTraceEnabled()) {
						log.trace("addTaxonomyForAssetInstanceVersionMain || dao method called : getTaxonomyIdByName ");
					}
					final List<TaxonomyMaster> tmList = taxonomyDao.getAllTaxonomiesByParentId(1L,conn);
					for(TaxonomyMaster t:tmList){
						recurse(t);
					}
					allTaxs.put((long) 1, tmList);

					allTxs = taxonomyDao.getAllTaxonomiesByAssetId(ad.getAssetId(), conn);

					for(TaxonomyMaster t:allTxs) {
						recurse1(t); 
					}
					Set<Long> hs = new HashSet<Long>();
					hs.addAll(associatedTaxId);
					associatedTaxId.clear();
					associatedTaxId.addAll(hs);

					String[] addedTaxIds = new String[]{};
					String[] addedTaxIds1 = new String[]{};
					AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();
					
					String[] removedTaxIds = new String[]{};
					String[] removedTaxIds1 = new String[]{};

					aiatVo.setAssetName(ai.getAssetName());
					aiatVo.setAssetInstanceName(ai.getAssetInstName());
					aiatVo.setVersionName(ai.getVersionName());
					List<Long> idsForTaxon = new ArrayList<Long>();
					List<Long> unassignidsForTaxon = new ArrayList<Long>();
					
					if(taxonomyName != null){
						if(taxonomyName.endsWith(",") || taxonomyName.startsWith(","))
						{
							return Response
								     .status(Status.BAD_REQUEST)
								     .entity(new MyModel(Constants.STATUS_FAILURE,
								       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
								     .build();
						}
						else
						{
							if(taxonomyName.length() > 0 )
							{
								if(!allTxs.isEmpty())
								{
									addedTaxIds = taxonomyName.split(",");
									List<String> strList = new ArrayList<String>();
									for(String s : addedTaxIds){
										s = s.trim();
										if(strList.contains(s)){
											retMsg = Constants.DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED;
											retScsFlr = Constants.FAILURE;
											retStatScsFlr = Constants.STATUS_FAILURE;
											retStat = Status.BAD_REQUEST;
											log.trace("addTaxonomyForAssetInstanceVersionMain || End");
											return Response.status(retStat)
													.entity(new MyModel(retStatScsFlr, retScsFlr,
															retMsg)).build();
										}else{
											strList.add(s);
										}
									}
									
									Boolean flag2 = true;
									for(int t =0; t< strList.size() && flag2; t++)
									{
										addedTaxIds[t] = addedTaxIds[t].trim();
										List<TaxonomyMaster> tmpTaxList = tmList;
										addedTaxIds1 = addedTaxIds[t].split("/");

										for(int h =0; h< addedTaxIds1.length; h++)
										{
											addedTaxIds1[h] = addedTaxIds1[h].trim();
											for (TaxonomyMaster tm : tax) {
												for (String taxNames : addedTaxIds1) {
													if (tm.getTaxonomyName().equalsIgnoreCase(taxNames)) {
														TaxAssignedForAsset = true;
														break;
													}
												}
											}

											if (!TaxAssignedForAsset) {
												retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_ADD;
												retScsFlr = Constants.FAILURE;
												retStatScsFlr = Constants.GET_STATUS_FAILURE;
												retStat = Status.NOT_FOUND;
												log.trace("addTaxonomyForAssetInstanceVersionMain || End");
												return Response.status(retStat)
														.entity(new MyModel(retStatScsFlr, retScsFlr,
																retMsg)).build();
											}
											
											Boolean flag = false;
											Long taxNextId = null;
											for(TaxonomyMaster tm:tmpTaxList)
											{
												if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
													flag = true;
													taxNextId = tm.getTaxonomyId();
													break;
												}
											}
											if(!flag)
											{
												retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_ADD;
												retScsFlr = Constants.FAILURE;
												retStatScsFlr = Constants.GET_STATUS_FAILURE;
												retStat = Status.NOT_FOUND;
												log.trace("addTaxonomyForAssetInstanceVersionMain || End");
												return Response.status(retStat)
														.entity(new MyModel(retStatScsFlr, retScsFlr,
																retMsg)).build();
											}
											else
											{
												for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
												{
													if(entry.getKey() ==  taxNextId)
													{ 
														tmpTaxList = entry.getValue();
													}
												}
											}
											if(h == addedTaxIds1.length-1)
											{

												Boolean fl = false;
												Boolean f2 = false;

												if(associatedTaxId.contains(taxNextId)){

												}
												else{
													f2 = true;
												}

												for(Long Id:idsForTaxon)
												{
													if(Id.equals(taxNextId))
													{
														fl = true;
														break;
													}

												}
												if(fl)
												{
													//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()); 
												}
												if(f2)
												{
													//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset"); 
												}
												else
												{
													idsForTaxon.add(taxNextId);
												}
											}
										}
									}
								}
								else{
									if (log.isErrorEnabled()) {
										log.error("No taxonomy is associated with "+ai.getAssetName()+" asset");
									}
									
									retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
									retScsFlr = Constants.FAILURE;
									retStatScsFlr = Constants.GET_STATUS_FAILURE;
									retStat = Status.NOT_FOUND;
									log.trace("addTaxonomyForAssetInstanceVersionMain || End");
									return Response.status(retStat)
											.entity(new MyModel(retStatScsFlr, retScsFlr,
													retMsg)).build();
								}
							}

							else
							{
								idsForTaxon = Collections.<Long>emptyList();
							}
							aiatVo.setTaxonIds(idsForTaxon);
							assetInstassignList.add(aiatVo);
						}
					}
					
					///unassign
					if(unassignTaxonomy != null){
						if(unassignTaxonomy.endsWith(",") || unassignTaxonomy.startsWith(","))
						{
							return Response
								     .status(Status.BAD_REQUEST)
								     .entity(new MyModel(Constants.STATUS_FAILURE,
								       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
								     .build();
						}
						else
						{
							if(unassignTaxonomy.length() > 0 )
							{
								if(!allTxs.isEmpty())
								{
									removedTaxIds = unassignTaxonomy.split(",");
									List<String> strList = new ArrayList<String>();
									for(String s : removedTaxIds){
										s = s.trim();
										if(strList.contains(s)){
											retMsg = Constants.DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED;
											retScsFlr = Constants.FAILURE;
											retStatScsFlr = Constants.STATUS_FAILURE;
											retStat = Status.BAD_REQUEST;
											log.trace("addTaxonomyForAssetInstanceVersionMain || End");
											return Response.status(retStat)
													.entity(new MyModel(retStatScsFlr, retScsFlr,
															retMsg)).build();
										}else{
											strList.add(s);
										}
									}
									
									Boolean flag2 = true;
									for(int t =0; t< strList.size() && flag2; t++)
									{
										removedTaxIds[t] = removedTaxIds[t].trim();
										List<TaxonomyMaster> tmpTaxList = tmList;
										removedTaxIds1 = removedTaxIds[t].split("/");

										for(int h =0; h< removedTaxIds1.length; h++)
										{
											removedTaxIds1[h] = removedTaxIds1[h].trim();
											for (TaxonomyMaster tm : tax) {
												for (String taxNames : removedTaxIds1) {
													if (tm.getTaxonomyName().equalsIgnoreCase(taxNames)) {
														TaxAssignedForAsset = true;
														break;
													}
												}
											}

											if (!TaxAssignedForAsset) {
												retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_DELETE;
												retScsFlr = Constants.FAILURE;
												retStatScsFlr = Constants.GET_STATUS_FAILURE;
												retStat = Status.NOT_FOUND;
												log.trace("addTaxonomyForAssetInstanceVersionMain || End");
												return Response.status(retStat)
														.entity(new MyModel(retStatScsFlr, retScsFlr,
																retMsg)).build();
											}
											
											Boolean flag = false;
											Long taxNextId = null;
											for(TaxonomyMaster tm:tmpTaxList)
											{
												if(tm.getTaxonomyName().equalsIgnoreCase(removedTaxIds1[h].trim())){
													flag = true;
													taxNextId = tm.getTaxonomyId();
													break;
												}
											}
											if(!flag)
											{
												retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_DELETE;
												retScsFlr = Constants.FAILURE;
												retStatScsFlr = Constants.GET_STATUS_FAILURE;
												retStat = Status.NOT_FOUND;
												log.trace("addTaxonomyForAssetInstanceVersionMain || End");
												return Response.status(retStat)
														.entity(new MyModel(retStatScsFlr, retScsFlr,
																retMsg)).build();
											}
											else
											{
												for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
												{
													if(entry.getKey() ==  taxNextId)
													{ 
														tmpTaxList = entry.getValue();
													}
												}
											}
											if(h == removedTaxIds1.length-1)
											{

												Boolean fl = false;
												Boolean f2 = false;

												if(associatedTaxId.contains(taxNextId)){

												}
												else{
													f2 = true;
												}

												for(Long Id:unassignidsForTaxon)
												{
													if(Id.equals(taxNextId))
													{
														fl = true;
														break;
													}

												}
												if(fl)
												{
													//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()); 
												}
												if(f2)
												{
													//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset"); 
												}
												else
												{
													unassignidsForTaxon.add(taxNextId);
												}
											}
										}
									}
								}
								else{
									if (log.isErrorEnabled()) {
										log.error("No taxonomy is associated with "+ai.getAssetName()+" asset");
									}
									
									retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
									retScsFlr = Constants.FAILURE;
									retStatScsFlr = Constants.GET_STATUS_FAILURE;
									retStat = Status.NOT_FOUND;
									log.trace("addTaxonomyForAssetInstanceVersionMain || End");
									return Response.status(retStat)
											.entity(new MyModel(retStatScsFlr, retScsFlr,
													retMsg)).build();
								}
							}

							else
							{
								unassignidsForTaxon = Collections.<Long>emptyList();
							}
							aiatVo.setUnassigntaxonIds(unassignidsForTaxon);
							assetInstunassignList.add(aiatVo);
						}
					}
										
					for(int i=0;i<assetInstassignList.size();i++){
						
						if(compositeFlag == false){
							String taxonomies = null;
							taxonomies = StringUtils.join(assetInstassignList.get(i).getTaxonIds(), ',');
							
							/*AssetInstVersionTaxonomy aivt = taxonomiesDao.getTaxonomyDetailsByTaxIdAivId(aiv.getAssetInstVersionId(), taxonomies, null);
							if(aivt != null){
								retMsg = Constants.TAXONOMY_NAME_EXIST;
								retScsFlr = Constants.SUCCESS;
								retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
								log.trace("addTaxonomyForAssetInstanceVersionMain || End");
								return Response.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr,
												retMsg)).build();
							}*/
							
							response = aivManager
									.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
											taxonomies, aiv.getVersionable(),versionName, assetInstName ,commitFlag,conn);
							
							/*if(unlockFlag){
								AssetInstanceVersion aiv2 = new AssetInstanceVersion();
								AssetInstanceVersionDao aivdao = new AssetInstanceVersionDao();
								aiv2.setAssetInstVersionId(aiv.getAssetInstVersionId());
								aiv2.setLockedBy(null);
								aiv2.setLockTime(null);
								aivdao.updateAssetInstanceVersion(aiv2, conn);
								//aivManager.unlockAssetInstanceVersion(userName, aiv.getAssetInstVersionId());
								
								retMsg = Constants.ASSET_INSTANCE_VERSION_UPDATED_AND_UNLOCKED;
								retScsFlr = Constants.SUCCESS;
								retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
								log.trace("addTaxonomyForAssetInstanceVersionMain || End");
								return Response.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr,
												retMsg)).build();
							}*/
							
							//MyModel res	 = (MyModel)response.getEntity();
							//res.getParamValues();
							/*retMsg = Constants.TAXONOMY_ASSIGNED_SUCCESSFULLY;
							retScsFlr = Constants.SUCCESS;
							retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;*/
							log.trace("addTaxonomyForAssetInstanceVersionMain || End");
							return response;
						}else{
							String assignTaxonomies = null;
							for(int k=0;k<assetInstassignList.size();k++){
								assignTaxonomies = StringUtils.join(assetInstassignList.get(k).getTaxonIds(), ',');
							}
							
							String unassignTaxonomies = null;
							for(int k=0;k<assetInstunassignList.size();k++){
								unassignTaxonomies = StringUtils.join(assetInstunassignList.get(k).getUnassigntaxonIds(), ',');
							}
							
							AssetInstanceVersionDao aivdao1 = new AssetInstanceVersionDao();
						   response = aivdao1.addOrRemoveTaxonomy(assignTaxonomies, unassignTaxonomies, String.valueOf(aiv.getAssetInstVersionId()), conn);
														
							/*if(unlockFlag){
								AssetInstanceVersion aiv2 = new AssetInstanceVersion();
								AssetInstanceVersionDao aivdao = new AssetInstanceVersionDao();
								aiv2.setAssetInstVersionId(aiv.getAssetInstVersionId());
								aiv2.setLockedBy(null);
								aiv2.setLockTime(null);
								aivdao.updateAssetInstanceVersion(aiv2, conn);
								
								retMsg = Constants.ASSET_INSTANCE_VERSION_UPDATED_AND_UNLOCKED;
								retScsFlr = Constants.SUCCESS;
								retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
								log.trace("addTaxonomyForAssetInstanceVersionMain || End");
								return Response.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr,
												retMsg)).build();
							}*/
							
							/*MyModel res = (MyModel) response.getEntity();
							if(res.getMessage().equalsIgnoreCase(Constants.TAXONOMY_UPDATED)){
								taxMap = res.getParamValues();
								retMsg = Constants.TAXONOMY_ASSIGNED_SUCCESSFULLY;
								retScsFlr = Constants.SUCCESS;
								retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
								log.trace("addTaxonomyForAssetInstanceVersionMain || End");
								return Response.status(retStat)
										.entity(new MyModel(retStatScsFlr, retScsFlr,
												retMsg)).build();
								return response;
							}else{
								//return response;
								retMsg = res.getMessage();
								retScsFlr = res.getStatus();
								retStatScsFlr = res.getStatusCode();
								log.trace("addTaxonomyForAssetInstanceVersionMain || End");
								return Response.status(response.getStatus())
										.entity(new MyModelRest(retStatScsFlr, retScsFlr,
												retMsg)).build();
							}*/
						   return response;
						}
					}
					
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("addTaxonomyForAssetInstanceVersionMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}

			}

		} catch (RepoproException e) {
			log.error("addTaxonomyForAssetInstanceVersionMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("addTaxonomyForAssetInstanceVersionMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
		} finally {
			if(conn1 != null){
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyForAssetInstanceVersionMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		}

		log.trace("addTaxonomyForAssetInstanceVersionMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/getRevisionHistory")
	public Response retAllRevisionHistoryMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@HeaderParam("token") String token) {
		
		if(assetName == null|| assetInstName == null || assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstName.isEmpty() || assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("retAllRevisionHistoryMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();		
		boolean viewFlag = false;
		boolean adminFlag = false;
		AssetInstanceDao assetInstDao = new AssetInstanceDao(); 
		List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
		AssetDao assetDao = new AssetDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (log.isTraceEnabled()) {
				log.trace("retAllRevisionHistoryMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			RevisionHistoryManager revisionHistoryManager = new RevisionHistoryManager();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();			
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("retAllRevisionHistoryMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
			
			if(!userName.equalsIgnoreCase("guest")){
				adminFlag = assetInstVersionDao.findAdminRightsByUserName(userName, null);

				long assetInstVersionId = assetInstanceVer.getAssetInstVersionId();
				
				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
			    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
				    	viewFlag = true;
					    break;
				    }
			    }

			    if (adminFlag || viewFlag) {
					assetName = URLEncoder.encode(assetName, "UTF-8");
			    	response = revisionHistoryManager.retAllRevisionHistory(assetName, assetInstVersionId);
			    	MyModel res = (MyModel) response.getEntity();
			        List<Object> data = res.getResult();
			        JSONObject j1 = null;
			        JSONObject j2 = null;
			        JSONObject j3 = null;
			        JSONObject json = new JSONObject();
			        List<Object> finaldata = new ArrayList<Object>();
			        for (int i = 0; i < data.size(); i++) {
			        	j1 = new JSONObject();
			        	AivRevisionHistory aivRevisionHistory = new AivRevisionHistory();
			        	aivRevisionHistory = (AivRevisionHistory) data.get(i);

			        	//j1.put("changedKey", aivRevisionHistory.getChangedKey());
			        	j1.put("revisedBy", aivRevisionHistory.getUserName());
			        	j1.put("imageName", aivRevisionHistory.getImageName());
			        	j1.put("overviewData", aivRevisionHistory.getOverviewData());
			        	if(aivRevisionHistory.getParameterData() != null){
			        		String[] parameterData = aivRevisionHistory.getParameterData().split("&<!!>&");
			        		j2= new JSONObject();
			        		for(int j=0;j<parameterData.length;j++){
			        			String paramName = parameterData[j].substring(0,parameterData[j].indexOf(":"));
			        			String paramValue = parameterData[j].substring(parameterData[j].indexOf(":")+1).replace("~~", ",");
			        			if(paramValue.contains("``")) {
									List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramValue.split("``")));
									j2.put(paramName, firstParamValList);
			        			}
			        			else{
			        				j2.put(parameterData[j].substring(0,parameterData[j].indexOf(":")),
			        						parameterData[j].substring(parameterData[j].indexOf(":")+1).replace("~~", ","));

			        			}
			        			

			        			/*if(!parameterData[j].split(":")[1].isEmpty()){
		        					if(parameterData[j].split(":")[1].contains("~~")){
		        						parameterData[j] = parameterData[j].replace("~~", ",");
		        						j2.put(parameterData[j].split(":")[0],parameterData[j].split(":")[1]);
		        					}else{
		        						j2.put(parameterData[j].split(":")[0], parameterData[j].split(":")[1]);
		        					}
			        			}*/

			        			j1.put("parameterData", j2);
			        		}
			        	}
			        	if(aivRevisionHistory.getRelationshipData() != null){
			        		j1.put("relationshipData", aivRevisionHistory.getRelationshipData().split("&<!!>&"));
			        	}
			        	j1.put("revId", aivRevisionHistory.getRevId());
			        	j1.put("revisedOn", aivRevisionHistory.getRevisedOn());
			        	if(aivRevisionHistory.getUsedBy() != null){
			        		j1.put("usedBy", aivRevisionHistory.getUsedBy().split("&<!!>&"));
			        	}
			        	if(aivRevisionHistory.getInstanceRename() != null){
			        		j3 = new JSONObject();
                          String[] rename = aivRevisionHistory.getInstanceRename().split("<!!>");			        	
			        		j3.put("oldName", rename[0]);
			        		j3.put("newName", rename[1]);
			        		j1.put("instanceRename", j3);
			        	}
			        	finaldata.add(j1);
			        }
			        
			        json.put("assetName", assetName);
			        json.put("assetInstanceName", assetInstName);
			        json.put("versionName", assetVersionName);
			        json.put("assetInstanceVersionId", assetInstanceVer.getAssetInstVersionId());
			        json.put("result", finaldata);
			        json.put("message", res.getMessage());
			        json.put("status", res.getStatus());
			        json.put("statusCode", res.getStatusCode());

			        log.trace("retAllRevisionHistoryMain || End");
			        return Response.status(retStat).entity(json.toString())
			          .build();
			    } else {
			    	retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
				 	return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
							.build();
			    }
			}
			else{
				userName = "roleAnonymous";
				AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
				long assetInstVersionId = assetInstanceVer.getAssetInstVersionId();

				if(assetDef.isGuestflag() == true){
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInstanceVer.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							assetName = URLEncoder.encode(assetName, "UTF-8");
							response = revisionHistoryManager.retAllRevisionHistory(assetName, assetInstVersionId);
							MyModel res = (MyModel) response.getEntity();

					        List<Object> data = res.getResult();
					        JSONObject j1 = null;
					        JSONObject j2 = null;
					        JSONObject j3 = null;
					        JSONObject json = new JSONObject();
					        List<Object> finaldata = new ArrayList<Object>();
					        for (int i = 0; i < data.size(); i++) {
					        	j1 = new JSONObject();
					        	AivRevisionHistory aivRevisionHistory = new AivRevisionHistory();
					        	aivRevisionHistory = (AivRevisionHistory) data.get(i);

					        	//j1.put("changedKey", aivRevisionHistory.getChangedKey());
					        	j1.put("revisedBy", aivRevisionHistory.getUserName());
					        	j1.put("imageName", aivRevisionHistory.getImageName());
					        	j1.put("overviewData", aivRevisionHistory.getOverviewData());
					        	if(aivRevisionHistory.getParameterData() != null){
					        		String[] parameterData = aivRevisionHistory.getParameterData().split("&<!!>&");
					        		j2= new JSONObject();
					        		if(parameterData != null) {
					        			for(int j=0;j<parameterData.length;j++){

					        				j2.put(parameterData[j].substring(0,parameterData[j].indexOf(":")),
					        						parameterData[j].substring(parameterData[j].indexOf(":")+1).replace("~~", ","));

					        				/*if(!parameterData[j].split(":")[1].isEmpty()){
				        					if(parameterData[j].split(":")[1].contains("~~")){
				        						parameterData[j] = parameterData[j].replace("~~", ",");
				        						j2.put(parameterData[j].split(":")[0], parameterData[j].split(":")[1]);
				        					}else{
				        						j2.put(parameterData[j].split(":")[0], parameterData[j].split(":")[1]);
				        					}
					        			}*/

					        				j1.put("parameterData", j2);
					        			}
					        		}
					        	}
					        	if(aivRevisionHistory.getRelationshipData() != null){
					        		j1.put("relationshipData", aivRevisionHistory.getRelationshipData().split("&<!!>&"));
					        	}
					        	j1.put("revId", aivRevisionHistory.getRevId());
					        	j1.put("revisedOn", aivRevisionHistory.getRevisedOn());
					        	if(aivRevisionHistory.getUsedBy() != null){
					        		j1.put("usedBy", aivRevisionHistory.getUsedBy().split("&<!!>&"));
					        	}
					        	if(aivRevisionHistory.getInstanceRename() != null){
					        		j3 = new JSONObject();
		                          String[] rename = aivRevisionHistory.getInstanceRename().split("<!!>");			        	
					        		j3.put("oldName", rename[0]);
					        		j3.put("newName", rename[1]);
					        		j1.put("instanceRename", j3);
					        	}
					        	finaldata.add(j1);

					        }
					        
					        json.put("assetName", assetName);
					        json.put("assetInstanceName", assetInstName);
					        json.put("versionName", assetVersionName);
					        json.put("assetInstanceVersionId", assetInstanceVer.getAssetInstVersionId());
					        json.put("result", finaldata);
					        json.put("message", res.getMessage());
					        json.put("status", res.getStatus());
					        json.put("statusCode", res.getStatusCode());

					        log.trace("retAllRevisionHistoryMain || End");
					        return Response.status(retStat).entity(json.toString())
					          .build();
						}else{

							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("retAllRevisionHistoryMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("retAllRevisionHistoryMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
			}
			
		} catch (RepoproException e) {
			log.error("retAllRevisionHistoryMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("retAllRevisionHistoryMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retAllRevisionHistoryMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("retAllRevisionHistoryMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/*** Wrapper function ***/
	//to get overview, owner, last updated///
	@GET
	@Encoded
	@Path("/getAssetInstanceVersionOverview")
	public Response getAssetInstanceVersionDetailsMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName, 
			@HeaderParam("token") String token) {

		if(assetName == null|| assetInstName == null || assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstName.isEmpty() || assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getAssetInstanceVersionDetailsMain || Begin");

		Response response = null;
		AssetInstance assetInstance = new AssetInstance();
		AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}

			Boolean viewFlag = false;
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			AssetInstanceDao assetInstDao = new AssetInstanceDao(); 
			List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
			AssetDao assetDao = new AssetDao();
						
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionDetailsMain || dao method called : getAssetInstanceVersion ");
			}
			
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();			
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);
			
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAssetInstanceVersionDetailsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			long assetInstVersionId = assetInstanceVer.getAssetInstVersionId();

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionDetailsMain || dao method called : retAivAccessRights ");
			} 
			
			if(userName != "roleAnonymous"){
				groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);

				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
						viewFlag = true;
						break;
					}
				}

				if (viewFlag) {
					assetInstName = URLEncoder.encode(assetInstName, "UTF-8");
					response = aivManager.getAssetInstanceVersionDetails(assetInstVersionId,assetInstName);
					MyModel res = (MyModel) response.getEntity();
			        List<Object> data = res.getResult();
			        JSONObject j1 = null;
			        JSONObject json = new JSONObject();
			        List<Object> finaldata = new ArrayList<Object>();
			        for (int i = 0; i < data.size(); i++) {
			        	j1 = new JSONObject();
			        	AssetInstanceVersion aiv = new AssetInstanceVersion();
			        	aiv = (AssetInstanceVersion) data.get(i);
			        	
			        	j1.put("assetInstanceName", aiv.getAssetInstName());
			        	j1.put("assetName", aiv.getAssetName());
			        	j1.put("description", aiv.getDescription());
			        	j1.put("iconImageName", aiv.getIconImageName());
			        	j1.put("owner", aiv.getOwner());
			        	j1.put("createdOn", aiv.getCreatedOn());
			        	j1.put("updatedOn", aiv.getUpdatedOn());
			        	j1.put("versionable", aiv.getVersionable());
			        	if(aiv.getVersionable() == true){
			        		j1.put("versionName", aiv.getVersionName());
			        	}else{
			        		j1.put("versionName", "N/A");
			        	}
			        	j1.put("assetInstanceVersionId", aiv.getAssetInstVersionId());
			        	
			        	finaldata.add(j1);
			        }
			        json.put("result", finaldata);
			        json.put("message", res.getMessage());
			        json.put("status", res.getStatus());
			        json.put("statusCode", res.getStatusCode());

			        log.trace("getAssetInstanceVersionDetailsMain || End");
			        return Response.status(retStat).entity(json.toString())
			          .build();
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getAssetInstanceVersionDetailsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}else{
				AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
				
				if(assetDef.isGuestflag() == true){
				assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInstanceVer.getAssetInstanceId() ,null);
				for(AssetInstance ai : assetInsatnceList){
					if(ai.isPublicAccess() == true){
						assetInstName = URLEncoder.encode(assetInstName, "UTF-8");
						response = aivManager.getAssetInstanceVersionDetails(assetInstVersionId,assetInstName);
						
						MyModel res = (MyModel) response.getEntity();
				        List<Object> data = res.getResult();
				        JSONObject j1 = null;
				        JSONObject json = new JSONObject();
				        List<Object> finaldata = new ArrayList<Object>();
				        for (int i = 0; i < data.size(); i++) {
				        	j1 = new JSONObject();
				        	AssetInstanceVersion aiv = new AssetInstanceVersion();
				        	aiv = (AssetInstanceVersion) data.get(i);
				        	
				        	j1.put("assetInstanceName", aiv.getAssetInstName());
				        	j1.put("assetName", aiv.getAssetName());
				        	j1.put("description", aiv.getDescription());
				        	j1.put("iconImageName", aiv.getIconImageName());
				        	j1.put("owner", aiv.getOwner());
				        	j1.put("updatedOn", aiv.getUpdatedOn());
				        	j1.put("createdOn", aiv.getCreatedOn());
				        	j1.put("versionable", aiv.getVersionable());
				        	if(aiv.getVersionable() == true){
				        		j1.put("versionName", aiv.getVersionName());
				        	}else{
				        		j1.put("versionName", "N/A");
				        	}
				        	j1.put("assetInstanceVersionId", aiv.getAssetInstVersionId());
				        	
				        	finaldata.add(j1);
				        }
				        json.put("result", finaldata);
				        json.put("message", res.getMessage());
				        json.put("status", res.getStatus());
				        json.put("statusCode", res.getStatusCode());

				        log.trace("getAssetInstanceVersionDetailsMain || End");
				        return Response.status(retStat).entity(json.toString())
				          .build();
						
					}else{
						retStat = Status.FORBIDDEN;
						retMsg = Constants.USER_NOT_AUTHORIZED;
						retScsFlr = Constants.NOT_AUTHORIZED;
						retStatScsFlr = Constants.FORBIDDEN;

						log.trace("getAssetInstanceVersionDetailsMain || End");
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}
				}
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;

				log.trace("getAssetInstanceVersionDetailsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				
			}
			}
		} catch (RepoproException e) {
			log.error("getAssetInstanceVersionDetailsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceVersionDetailsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 

		log.trace("getAssetInstanceVersionDetailsMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

	}
	
	
	/***Wrapper function***/
	@PUT
	@Encoded
	@Path("/updateDescription")
	public Response updateAssetInstanceDescriptionMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String versionName,
			@QueryParam("newDescription") String newDescription,
			@HeaderParam("token") String token){
		if(assetName == null|| assetInstName == null || versionName == null || newDescription == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			versionName = URLDecoder.decode(versionName, "UTF-8");versionName = versionName.trim();
			newDescription = URLDecoder.decode(newDescription, "UTF-8");newDescription = newDescription.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstName.isEmpty() || versionName.isEmpty() || newDescription.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		if(newDescription.trim().length()>2500){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
			     .build();
		}
		
		
		log.trace("updateAssetInstanceDescriptionMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescriptionMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			 response = this.updateAssetInstanceDescriptionMainHelper(assetName, assetInstName, versionName, newDescription, token ,false,conn);
			 return response;
			 
		} catch (RepoproException e) {
			log.error("updateAssetInstanceDescriptionMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("updateAssetInstanceDescriptionMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
		} finally {
			if(conn != null){
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescriptionMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		}

		log.trace("updateAssetInstanceDescriptionMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	

	public Response updateAssetInstanceDescriptionMainHelper( String assetName,
			 String assetInstName, String versionName, String newDescription, String token,boolean commitFlag,Connection conn)throws RepoproException{
		
		log.trace("updateAssetInstanceDescriptionMain || Begin");
		Connection conn1 = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstance instance = new AssetInstance();
		AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
		AssetInstance assetInstance = new AssetInstance();
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		versionName = versionName.trim();
		newDescription = newDescription.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescriptionMainHelper || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
			}
			AssetInstanceManager aiManager = new AssetInstanceManager();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			AssetInstanceVersionDao aivDao = new AssetInstanceVersionDao();
			boolean editFlag = false;
			boolean adminFlag = false;
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(versionName);
			assetInstance.setNewDescription("<p>"+newDescription+"</p>");
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response
						.status(retStat).entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg)).build();
			}else{
				AssetDao assetDao =new AssetDao();
				AssetInstanceDao assetInstDao =new AssetInstanceDao();
				/*User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateAssetInstanceDescriptionMainHelper || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}*/
				AssetDef ad = new AssetDef();
				ad = assetDao.getAssetsByAssetName(assetInstance.getAssetName(), conn);
				if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateAssetInstanceDescriptionMainHelper || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				Long assetInstId=assetInstDao.getAssetInstIdByName(assetInstance.getAssetInstName(),ad.getAssetId(), conn);
				if (assetInstId == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateAssetInstanceDescriptionMainHelper || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				instance.setAssetId(ad.getAssetId());
				instance.setAssetName(assetInstance.getAssetName());
				instance.setAssetInstName(assetInstance.getAssetInstName());
				instance.setAssetInstId(assetInstId);
				instance.setVersionName(assetInstance.getVersionName());
				instance.setNewDescription(assetInstance.getNewDescription());
				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(instance, null);
				if (assetInstanceVer == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateAssetInstanceDescriptionMainHelper || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				long assetInstVersionId = assetInstanceVer.getAssetInstVersionId();
				adminFlag = aivDao.findAdminRightsByUserName(userName, null);
				if(!adminFlag){
					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstanceDescriptionMainHelper || dao method called : retAivAccessRights ");
					}
					groupAssetInstVersionAccessList = aivDao.retAivAccessRights(assetInstVersionId, userName, null);

					for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
						if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
							editFlag = true;
							break;
						}
					}
				}else{
					editFlag = true;
				}
				
				AssetInstanceVersion aiv = aivDao.getAssetInstanceVersionDetails(assetInstVersionId,null);
				
				if(editFlag){
					if(aiv.getLockedBy() == null){
						response = aiManager.updateAssetInstanceDescriptionHelper(instance,userName,commitFlag,conn);
						MyModel res = (MyModel) response.getEntity();				
						
						return Response.status(retStat).entity(new MyModelRest(res.getStatusCode(), res.getStatus(), res.getMessage())).build();

					}else if(aiv.getLockedBy().equalsIgnoreCase(userName)){
						response = aiManager.updateAssetInstanceDescriptionHelper(instance,userName,commitFlag,conn);
						/*AssetInstanceVersion aiv2 = new AssetInstanceVersion();
						AssetInstanceVersionDao aivdao = new AssetInstanceVersionDao();
						aiv2.setAssetInstVersionId(assetInstVersionId);
						aiv2.setLockedBy(null);
						aiv2.setLockTime(null);
						aivdao.updateAssetInstanceVersion(aiv2, conn);*/
					//	aivManager.unlockAssetInstanceVersion(userName, assetInstVersionId);
						MyModel res = (MyModel) response.getEntity();
						
						/*if(res.getMessage().equalsIgnoreCase(Constants.ASSET_INSTANCE_DESC_UPDATED)){
							retStat = Status.OK;
							retMsg = Constants.ASSET_INSTANCE_VERSION_UPDATED_AND_UNLOCKED;
							retScsFlr = Constants.SUCCESS;
							retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
							log.trace("updateAssetInstanceDescriptionMainHelper || End");
						}*/
						
						return Response
								.status(retStat)
								.entity(new MyModelRest(res.getStatusCode(), res.getStatus(),res.getMessage())).build();
					}
					else{
						retStat = Status.FORBIDDEN;
						retMsg = Constants.ASSET_INSTANCE_VERSION_LOCKED;
						retScsFlr = Constants.NOT_AUTHORIZED;
						retStatScsFlr = Constants.FORBIDDEN;
						log.trace("updateAssetInstanceDescriptionMainHelper || End");
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("updateAssetInstanceDescriptionMainHelper || End");
					/*return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();*/
				}
				
			}
		} catch (RepoproException e) {
			log.error("updateAssetInstanceDescriptionMainHelper || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
			
		} catch (Exception e) {
			log.error("updateAssetInstanceDescriptionMainHelper || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
		} finally {
			if(conn1 != null){
			DBConnection.closeDbConnection(conn1);
			}
		}
		
		log.trace("updateAssetInstanceDescriptionMainHelper || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
		}

	
	
	/*** Wrapper function ***/
	@GET
	@Encoded
	@Path("/getProperties")
	public Response getAssetInstancePropertiesDetailsMain(
			@QueryParam("assetName") String assetName, 
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@HeaderParam("token") String token) throws RepoproException {

		if(assetName == null || assetInstName == null || assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty() || assetInstName.isEmpty() || assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getAssetInstancePropertiesDetailsMain || Begin");
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			Response response = null;
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancePropertiesDetailsMain || dao method called : getAssetInstanceVersion ");
			}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao
					.getAssetinstDetails(assetName, assetInstName,
							assetVersionName, null);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAssetInstancePropertiesDetailsMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();

			}

			if (userName != "roleAnonymous") {

				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();

				Boolean viewFlag = false;

				if (log.isTraceEnabled()) {
					log.trace("getAssetInstancePropertiesDetailsMain || dao method called : retAivAccessRights ");
				}
				groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(
								assetInstanceVer.getAssetInstVersionId(), userName, null);

				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
						viewFlag = true;
						break;
					}
				}

				if (viewFlag) {
					assetName = URLEncoder.encode(assetName, "UTF-8");
					response = aivManager.getAssetInstancePropertiesDetails(userName, assetName, assetInstanceVer.getAssetInstVersionId());

					MyModel res = (MyModel) response.getEntity();
			        List<Object> data = res.getResult();
			        JSONObject j1 = null;
			        JSONObject json = new JSONObject();
			        List<Object> finaldata = new ArrayList<Object>();
			        for (int i = 0; i < data.size(); i++) {
			        	j1 = new JSONObject();
			        	AssetInstanceVersion aiv = new AssetInstanceVersion();
			        	aiv = (AssetInstanceVersion) data.get(i);
			        	
			        	j1.put("assetCategoryName", aiv.getAsset_category_name());
			        	j1.put("assetParamName", aiv.getAssetParamName());
			        	j1.put("parameterDescription", aiv.getDescription());
			        	
			        	if(aiv.getIsStatic() == 1){
			        		if(aiv.getParamTypeId() == 4){
			        			if(aiv.getStaticValue() != null){
				        		if(aiv.getStaticValue().contains("~~")){
				        			String value = aiv.getStaticValue().replace("~~", ",");
				        			j1.put("parameterValue", value);
				        		}else{
				        			j1.put("parameterValue", aiv.getStaticValue());
				        		}
			        			}
				        	}else if(aiv.getParamTypeId() == 3){
			        			j1.put("parameterValue", aiv.getApdFileName());
			        		}else{
			        			j1.put("parameterValue", aiv.getStaticValue());
			        		}
			        	}else{
			        		if(aiv.getParamTypeId() == 4){
			        			if(aiv.getParamValue() != null){
				        		if(aiv.getParamValue().contains("~~")){
				        			String value = aiv.getParamValue().replace("~~", ",");
				        			j1.put("parameterValue", value);
				        		}else{
				        			j1.put("parameterValue", aiv.getParamValue());
				        		}
			        			}
				        	}
				        	else if(aiv.getParamTypeId() == 1){
				        		if(aiv.getHasArray() == 1){
				        			j1.put("parameterValue", aiv.getTextDataList());
				        		}else{
				        			j1.put("parameterValue", aiv.getParamValue());
				        		}
				        	}
				        	else if(aiv.getParamTypeId() == 7){
				        		if(aiv.getHasArray() == 1){
				        			j1.put("parameterValue", aiv.getRTFwithTags());
				        		}else{
				        			j1.put("parameterValue", aiv.getParamValue());
				        		}
				        	}else if(aiv.getParamTypeId() == 9){

				        		List<String> ldapdata = new ArrayList<String>();
				        		if(aiv.getLdapMappingList()!=null) {
				        			if(!aiv.getLdapMappingList().isEmpty()) {
				        				for(String ldapfinaldata:aiv.getLdapMappingList()) {
				        					ldapdata.add(ldapfinaldata.replace("~~", ","));
				        				}
				        				aiv.setLdapMappingList(ldapdata);
				        				j1.put("parameterValue", aiv.getLdapMappingList());
				        			}
				        		}

				        	}
				        	else if(aiv.getParamTypeId() == 3){
				        		j1.put("parameterValue", aiv.getFileName());
				        	}else if (aiv.getParamTypeId() == 5){

				        		String datas = aiv.getParamValue();
				        		String[] data1	 =  datas.split("`!!`");
				        		String Value = data1[1].toString();
				        		if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
				        			Value = Value.substring(0, Value.length() - 1);
				        		}
				        		if(Value.contains("``")){
				        			Value = Value.replaceAll("``", "|");
				        		}
				        		if(Value.contains("~~")){
				        			Value = Value.replaceAll("~~", ",");
				        		}

				        		if(Value.contains("`~`")){

				        			List<String> strArray = new ArrayList<String>();

				        			strArray= (Arrays.asList(Value.split("`~`")));

				        			j1.put("parameterValue", strArray);
				        		}else{
				        			j1.put("parameterValue", Value.trim());
				        		}
				        	}else if(aiv.getParamTypeId() == 8) {
				        		String derivedAssetListValue = aiv.getParamValue();
								String finalValue = "";
								String[] data1 = derivedAssetListValue.split("`!!`");
								if(data1[0].equalsIgnoreCase("0")) {
									if(data1.length == 2){
		        						finalValue = data1[1];
		        					}else{
		        						finalValue = ""; 
		        					}
								}else {
									if(data1.length == 2){
		        						finalValue = data1[1];
		        					}else{
		        						finalValue = ""; 
		        					}
								}
								if(finalValue.contains("``")){
									finalValue = finalValue.replaceAll("``", "|");
								}
								
								if(finalValue.contains("~~")){
									finalValue = finalValue.replaceAll("~~", ",");
								}
								
								if(finalValue.contains("`~`")){
									List<String> strArray = new ArrayList<String>();
									strArray = (Arrays.asList(finalValue.split("`~`")));
									j1.put("parameterValue", strArray);
								}else{
									j1.put("parameterValue", finalValue);
								}
								
				        	}
				        	else{
				        		j1.put("parameterValue", aiv.getParamValue());
				        	}
			        	}
			        	
			        	finaldata.add(j1);
			        }
			        
			        if(!finaldata.isEmpty()) {
			        	json.put("assetName", assetName);
				        json.put("assetInstanceName", assetInstName);
				        json.put("versionName", assetVersionName);
				        json.put("assetInstanceVersionId", assetInstanceVer.getAssetInstVersionId());
			        }
			        json.put("result", finaldata);
			        json.put("message", res.getMessage());
			        json.put("status", res.getStatus());
			        json.put("statusCode", res.getStatusCode());

			        log.trace("getAssetInstancePropertiesDetailsMain || End");
			        return Response.status(retStat).entity(json.toString())
			          .build();

				} else {

					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getAssetInstancePropertiesDetailsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			} else {
				AssetDao assetDao = new AssetDao();
				AssetInstanceDao assetInstDao = new AssetInstanceDao();
				List<AssetInstance> assetInsatnceList = new ArrayList<AssetInstance>();

				AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);

				if (assetDef.isGuestflag() == true) {
					assetInsatnceList = assetInstDao.getAssetInstancePublicAccessState(
									assetInstanceVer.getAssetInstanceId(), null);
					for (AssetInstance ai : assetInsatnceList) {
						if (ai.isPublicAccess() == true) {
							assetName = URLEncoder.encode(assetName, "UTF-8");
							response = aivManager.getAssetInstancePropertiesDetails(userName, assetName, assetInstanceVer.getAssetInstVersionId());

							MyModel res = (MyModel) response.getEntity();
					        List<Object> data = res.getResult();
					        JSONObject j1 = null;
					        JSONObject json = new JSONObject();
					        List<Object> finaldata = new ArrayList<Object>();
					        for (int i = 0; i < data.size(); i++) {
					        	j1 = new JSONObject();
					        	AssetInstanceVersion aiv = new AssetInstanceVersion();
					        	aiv = (AssetInstanceVersion) data.get(i);
					        	
					        	j1.put("assetCategoryName", aiv.getAsset_category_name());
					        	j1.put("assetParamName", aiv.getAssetParamName());
					        	j1.put("parameterDescription", aiv.getDescription());
					        	
					        	if(aiv.getIsStatic() == 1){
					        		if(aiv.getParamTypeId() == 4){
					        			if(aiv.getStaticValue() != null){
						        		if(aiv.getStaticValue().contains("~~")){
						        			String value = aiv.getStaticValue().replace("~~", ",");
						        			j1.put("parameterValue", value);
						        		}else{
						        			j1.put("parameterValue", aiv.getStaticValue());
						        		}
					        			}
						        	}else if(aiv.getParamTypeId() == 3){
					        			j1.put("parameterValue", aiv.getApdFileName());
					        		}else{
					        			j1.put("parameterValue", aiv.getStaticValue());
					        		}
					        	}else{
					        		if(aiv.getParamTypeId() == 4){
					        			if(aiv.getParamValue() != null){
						        		if(aiv.getParamValue().contains("~~")){
						        			String value = aiv.getParamValue().replace("~~", ",");
						        			j1.put("parameterValue", value);
						        		}else{
						        			j1.put("parameterValue", aiv.getParamValue());
						        		}
					        			}
						        	}
						        	else if(aiv.getParamTypeId() == 1){
						        		if(aiv.getHasArray() == 1){
						        			j1.put("parameterValue", aiv.getTextDataList());
						        		}else{
						        			j1.put("parameterValue", aiv.getParamValue());
						        		}
						        	}
						        	else if(aiv.getParamTypeId() == 7){
						        		if(aiv.getHasArray() == 1){
						        			j1.put("parameterValue", aiv.getRTFwithTags());
						        		}else{
						        			j1.put("parameterValue", aiv.getParamValue());
						        		}
						        	}else if(aiv.getParamTypeId() == 3){
						        		j1.put("parameterValue", aiv.getFileName());
						        	}else if (aiv.getParamTypeId() == 5){
						        		
						        		String datas = aiv.getParamValue();
										String[] data1	 =  datas.split("`!!`");
										String Value = data1[1].toString();
										if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
											Value = Value.substring(0, Value.length() - 1);
										    }
										if(Value.contains("``")){
											Value = Value.replaceAll("``", "|");
										}
										if(Value.contains("~~")){
											Value = Value.replaceAll("~~", ",");
										}
										
										if(Value.contains("`~`")){
											
											List<String> strArray = new ArrayList<String>();
											
											strArray= (Arrays.asList(Value.split("`~`")));
													
											j1.put("parameterValue", strArray);
											}else{
												j1.put("parameterValue", Value.trim());
											}
						        	}else if(aiv.getParamTypeId() == 8) {
						        		String derivedAssetListValue = aiv.getParamValue();
										String finalValue = "";
										String[] data1 = derivedAssetListValue.split("`!!`");
										if(data1[0].equalsIgnoreCase("0")) {
											if(data1.length == 2){
				        						finalValue = data1[1];
				        					}else{
				        						finalValue = ""; 
				        					}
										}else {
											if(data1.length == 2){
				        						finalValue = data1[1];
				        					}else{
				        						finalValue = ""; 
				        					}
										}
										if(finalValue.contains("``")){
											finalValue = finalValue.replaceAll("``", "|");
										}
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}
										
										if(finalValue.contains("`~`")){
											List<String> strArray = new ArrayList<String>();
											strArray = (Arrays.asList(finalValue.split("`~`")));
											j1.put("parameterValue", strArray);
										}else{
											j1.put("parameterValue", finalValue);
										}
										
						        	}
						        	else{
						        		j1.put("parameterValue", aiv.getParamValue());
						        	}
					        	}
					        	
					        	finaldata.add(j1);
					        }
					        
					        if(!finaldata.isEmpty()) {
					        	json.put("assetName", assetName);
						        json.put("assetInstanceName", assetInstName);
						        json.put("versionName", assetVersionName);
						        json.put("assetInstanceVersionId", assetInstanceVer.getAssetInstVersionId());
					        }
					        
					        json.put("result", finaldata);
					        json.put("message", res.getMessage());
					        json.put("status", res.getStatus());
					        json.put("statusCode", res.getStatusCode());

					        log.trace("getAssetInstancePropertiesDetailsMain || End");
					        return Response.status(retStat).entity(json.toString())
					          .build();

						} else {

							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getAssetInstancePropertiesDetailsMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr,
											retScsFlr, retMsg)).build();
						}
					}
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getAssetInstancePropertiesDetailsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}

		} catch (RepoproException e) {
			log.error("getAssetInstancePropertiesDetailsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstancePropertiesDetailsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}

		log.trace("getAssetInstanceVersionDetailsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	@GET
	@Encoded
	@Path("/getPropertiesByAssetInstanceVersionId")
	public Response getAssetInstancePropertiesByAssetInstanceVersionId(@QueryParam("assetInstanceVersionId") String assetInstanceVersionId,
			@HeaderParam("token") String token) throws RepoproException {

		if(assetInstanceVersionId == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetInstanceVersionId = URLDecoder.decode(assetInstanceVersionId, "UTF-8");
			assetInstanceVersionId = assetInstanceVersionId.trim();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetInstanceVersionId.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getAssetInstancePropertiesByAssetInstanceVersionId || Begin");
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			Response response = null;
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();

			if(!assetInstanceVersionId.matches("[0-9]+")){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						.build();
			}			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancePropertiesByAssetInstanceVersionId || dao method called : getAssetInstanceVersion ");
			}
			
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao
					.getAssetInstanceVersionDetails(Long.parseLong(assetInstanceVersionId), null);
			
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAssetInstancePropertiesDetailsMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();

			}

			String assetName = assetInstanceVer.getAssetName();
			String assetInstName = assetInstanceVer.getAssetInstName();
			String assetVersionName = assetInstanceVer.getVersionName();	
			
			if (userName != "roleAnonymous") {

				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();

				Boolean viewFlag = false;

				if (log.isTraceEnabled()) {
					log.trace("getAssetInstancePropertiesByAssetInstanceVersionId || dao method called : retAivAccessRights ");
				}
				groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(
								assetInstanceVer.getAssetInstVersionId(), userName, null);

				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
						viewFlag = true;
						break;
					}
				}

				if (viewFlag) {
					assetName = URLEncoder.encode(assetName, "UTF-8");
					response = aivManager.getAssetInstancePropertiesDetails(userName, assetName, assetInstanceVer.getAssetInstVersionId());

					MyModel res = (MyModel) response.getEntity();
			        List<Object> data = res.getResult();
			        JSONObject j1 = null;
			        JSONObject json = new JSONObject();
			        List<Object> finaldata = new ArrayList<Object>();
			        for (int i = 0; i < data.size(); i++) {
			        	j1 = new JSONObject();
			        	AssetInstanceVersion aiv = new AssetInstanceVersion();
			        	aiv = (AssetInstanceVersion) data.get(i);
			        	
			        	j1.put("assetCategoryName", aiv.getAsset_category_name());
			        	j1.put("assetParamName", aiv.getAssetParamName());
			        	j1.put("parameterDescription", aiv.getDescription());
			        	
			        	if(aiv.getIsStatic() == 1){
			        		if(aiv.getParamTypeId() == 4){
			        			if(aiv.getStaticValue() != null){
			        				if(aiv.getStaticValue().contains("~~")){
			        					String value = aiv.getStaticValue().replace("~~", ",");
			        					j1.put("parameterValue", value);
			        				}else{
			        					j1.put("parameterValue", aiv.getStaticValue());
			        				}
			        			}
				        	}else if(aiv.getParamTypeId() == 3){
			        			j1.put("parameterValue", aiv.getApdFileName());
			        		}else{
			        			j1.put("parameterValue", aiv.getStaticValue());
			        		}
			        	}else{
			        		if(aiv.getParamTypeId() == 4){
			        			if(aiv.getParamValue() != null){
			        				if(aiv.getParamValue().contains("~~")){
			        					String value = aiv.getParamValue().replace("~~", ",");
			        					j1.put("parameterValue", value);
			        				}else{
			        					j1.put("parameterValue", aiv.getParamValue());
			        				}
			        			}
				        	}
				        	else if(aiv.getParamTypeId() == 1){
				        		if(aiv.getHasArray() == 1){
				        			j1.put("parameterValue", aiv.getTextDataList());
				        		}else{
				        			j1.put("parameterValue", aiv.getParamValue());
				        		}
				        	}
				        	else if(aiv.getParamTypeId() == 7){
				        		if(aiv.getHasArray() == 1){
				        			j1.put("parameterValue", aiv.getRTFwithTags());
				        		}else{
				        			j1.put("parameterValue", aiv.getParamValue());
				        		}
				        	}else if(aiv.getParamTypeId() == 9){

				        		List<String> ldapdata = new ArrayList<String>();
				        		if(aiv.getLdapMappingList()!=null) {
				        			if(!aiv.getLdapMappingList().isEmpty()) {
				        				for(String ldapfinaldata:aiv.getLdapMappingList()) {
				        					ldapdata.add(ldapfinaldata.replace("~~", ","));
				        				}
				        				aiv.setLdapMappingList(ldapdata);
				        				j1.put("parameterValue", aiv.getLdapMappingList());
				        			}else {
				        				j1.put("parameterValue", aiv.getLdapMappingList());
				        			}
				        		}

				        	}
				        	else if(aiv.getParamTypeId() == 3){
				        		j1.put("parameterValue", aiv.getFileName());
				        	}else if (aiv.getParamTypeId() == 5){

				        		String datas = aiv.getParamValue();
				        		String[] data1	 =  datas.split("`!!`");
				        		String Value = data1[1].toString();
				        		if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
				        			Value = Value.substring(0, Value.length() - 1);
				        		}
				        		if(Value.contains("``")){
				        			Value = Value.replaceAll("``", "|");
				        		}
				        		if(Value.contains("~~")){
				        			Value = Value.replaceAll("~~", ",");
				        		}

				        		if(Value.contains("`~`")){

				        			List<String> strArray = new ArrayList<String>();

				        			strArray= (Arrays.asList(Value.split("`~`")));

				        			j1.put("parameterValue", strArray);
				        		}else{
				        			j1.put("parameterValue", Value.trim());
				        		}
				        	}else if(aiv.getParamTypeId() == 8) {
				        		String derivedAssetListValue = aiv.getParamValue();
								String finalValue = "";
								String[] data1 = derivedAssetListValue.split("`!!`");
								if(data1[0].equalsIgnoreCase("0")) {
									if(data1.length == 2){
		        						finalValue = data1[1];
		        					}else{
		        						finalValue = ""; 
		        					}
								}else {
									if(data1.length == 2){
		        						finalValue = data1[1];
		        					}else{
		        						finalValue = ""; 
		        					}
								}
								if(finalValue.contains("``")){
									finalValue = finalValue.replaceAll("``", "|");
								}
								
								if(finalValue.contains("~~")){
									finalValue = finalValue.replaceAll("~~", ",");
								}
								
								if(finalValue.contains("`~`")){
									List<String> strArray = new ArrayList<String>();
									strArray = (Arrays.asList(finalValue.split("`~`")));
									j1.put("parameterValue", strArray);
								}else{
									j1.put("parameterValue", finalValue);
								}
								
				        	}
				        	else{
				        		j1.put("parameterValue", aiv.getParamValue());
				        	}
			        	}
			        	
			        	finaldata.add(j1);
			        }
			        
			        if(!finaldata.isEmpty()) {
			        	json.put("assetName", assetName);
				        json.put("assetInstanceName", assetInstName);
				        json.put("versionName", assetVersionName);
				        json.put("assetInstanceVersionId", assetInstanceVer.getAssetInstVersionId());
			        }
			        json.put("result", finaldata);
			        json.put("message", res.getMessage());
			        json.put("status", res.getStatus());
			        json.put("statusCode", res.getStatusCode());

			        log.trace("getAssetInstancePropertiesByAssetInstanceVersionId || End");
			        return Response.status(retStat).entity(json.toString())
			          .build();

				} else {

					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getAssetInstancePropertiesByAssetInstanceVersionId || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			} else {
				AssetDao assetDao = new AssetDao();
				AssetInstanceDao assetInstDao = new AssetInstanceDao();
				List<AssetInstance> assetInsatnceList = new ArrayList<AssetInstance>();

				AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);

				if (assetDef.isGuestflag() == true) {
					assetInsatnceList = assetInstDao.getAssetInstancePublicAccessState(
									assetInstanceVer.getAssetInstanceId(), null);
					for (AssetInstance ai : assetInsatnceList) {
						if (ai.isPublicAccess() == true) {
							assetName = URLEncoder.encode(assetName, "UTF-8");
							response = aivManager.getAssetInstancePropertiesDetails(userName, assetName, assetInstanceVer.getAssetInstVersionId());

							MyModel res = (MyModel) response.getEntity();
					        List<Object> data = res.getResult();
					        JSONObject j1 = null;
					        JSONObject json = new JSONObject();
					        List<Object> finaldata = new ArrayList<Object>();
					        for (int i = 0; i < data.size(); i++) {
					        	j1 = new JSONObject();
					        	AssetInstanceVersion aiv = new AssetInstanceVersion();
					        	aiv = (AssetInstanceVersion) data.get(i);
					        	
					        	j1.put("assetCategoryName", aiv.getAsset_category_name());
					        	j1.put("assetParamName", aiv.getAssetParamName());
					        	j1.put("parameterDescription", aiv.getDescription());
					        	
					        	if(aiv.getIsStatic() == 1){
					        		if(aiv.getParamTypeId() == 4){
					        			if(aiv.getStaticValue() != null){
						        		if(aiv.getStaticValue().contains("~~")){
						        			String value = aiv.getStaticValue().replace("~~", ",");
						        			j1.put("parameterValue", value);
						        		}else{
						        			j1.put("parameterValue", aiv.getStaticValue());
						        		}
					        			}
						        	}else if(aiv.getParamTypeId() == 3){
					        			j1.put("parameterValue", aiv.getApdFileName());
					        		}else{
					        			j1.put("parameterValue", aiv.getStaticValue());
					        		}
					        	}else{
					        		if(aiv.getParamTypeId() == 4){
					        			if(aiv.getParamValue() != null){
						        		if(aiv.getParamValue().contains("~~")){
						        			String value = aiv.getParamValue().replace("~~", ",");
						        			j1.put("parameterValue", value);
						        		}else{
						        			j1.put("parameterValue", aiv.getParamValue());
						        		}
					        			}
						        	}
						        	else if(aiv.getParamTypeId() == 1){
						        		if(aiv.getHasArray() == 1){
						        			j1.put("parameterValue", aiv.getTextDataList());
						        		}else{
						        			j1.put("parameterValue", aiv.getParamValue());
						        		}
						        	}
						        	else if(aiv.getParamTypeId() == 7){
						        		if(aiv.getHasArray() == 1){
						        			j1.put("parameterValue", aiv.getRTFwithTags());
						        		}else{
						        			j1.put("parameterValue", aiv.getParamValue());
						        		}
						        	}else if(aiv.getParamTypeId() == 3){
						        		j1.put("parameterValue", aiv.getFileName());
						        	}else if (aiv.getParamTypeId() == 5){
						        		
						        		String datas = aiv.getParamValue();
										String[] data1	 =  datas.split("`!!`");
										String Value = data1[1].toString();
										if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
											Value = Value.substring(0, Value.length() - 1);
										    }
										if(Value.contains("``")){
											Value = Value.replaceAll("``", "|");
										}
										if(Value.contains("~~")){
											Value = Value.replaceAll("~~", ",");
										}
										
										if(Value.contains("`~`")){
											
											List<String> strArray = new ArrayList<String>();
											
											strArray= (Arrays.asList(Value.split("`~`")));
													
											j1.put("parameterValue", strArray);
											}else{
												j1.put("parameterValue", Value.trim());
											}
						        	}else if(aiv.getParamTypeId() == 8) {
						        		String derivedAssetListValue = aiv.getParamValue();
										String finalValue = "";
										String[] data1 = derivedAssetListValue.split("`!!`");
										if(data1[0].equalsIgnoreCase("0")) {
											if(data1.length == 2){
				        						finalValue = data1[1];
				        					}else{
				        						finalValue = ""; 
				        					}
										}else {
											if(data1.length == 2){
				        						finalValue = data1[1];
				        					}else{
				        						finalValue = ""; 
				        					}
										}
										if(finalValue.contains("``")){
											finalValue = finalValue.replaceAll("``", "|");
										}
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}
										
										if(finalValue.contains("`~`")){
											List<String> strArray = new ArrayList<String>();
											strArray = (Arrays.asList(finalValue.split("`~`")));
											j1.put("parameterValue", strArray);
										}else{
											j1.put("parameterValue", finalValue);
										}
										
						        	}
						        	else{
						        		j1.put("parameterValue", aiv.getParamValue());
						        	}
					        	}
					        	
					        	finaldata.add(j1);
					        }
					        
					        if(!finaldata.isEmpty()) {
					        	json.put("assetName", assetName);
						        json.put("assetInstanceName", assetInstName);
						        json.put("versionName", assetVersionName);
						        json.put("assetInstanceVersionId", assetInstanceVer.getAssetInstVersionId());
					        }
					        
					        json.put("result", finaldata);
					        json.put("message", res.getMessage());
					        json.put("status", res.getStatus());
					        json.put("statusCode", res.getStatusCode());

					        log.trace("getAssetInstancePropertiesByAssetInstanceVersionId || End");
					        return Response.status(retStat).entity(json.toString())
					          .build();

						} else {

							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getAssetInstancePropertiesByAssetInstanceVersionId || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr,
											retScsFlr, retMsg)).build();
						}
					}
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getAssetInstancePropertiesByAssetInstanceVersionId || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}

		} catch (RepoproException e) {
			log.error("getAssetInstancePropertiesByAssetInstanceVersionId || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstancePropertiesByAssetInstanceVersionId || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}

		log.trace("getAssetInstancePropertiesByAssetInstanceVersionId || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	
	@POST
	@Encoded
	@Path("/updateProperties")
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response updateAssetInstancePropertiesRest(
			@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String versionName,
			/*@FormDataParam("object") String formDataValue,*/
			@QueryParam("parameterDetails") String parameterDetails,
			/*@FormDataParam("images")*/FormDataMultiPart formParams ,
			@Context ServletContext context,@HeaderParam("token") String token) {
		
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstancePropertiesRest || begin");
		}

		if(assetName == null|| assetInstName == null || versionName == null || parameterDetails == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			versionName = URLDecoder.decode(versionName, "UTF-8");versionName = versionName.trim();
			parameterDetails = URLDecoder.decode(parameterDetails, "UTF-8");parameterDetails = parameterDetails.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstName.isEmpty() || versionName.isEmpty() || parameterDetails.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		Status retStat = Status.OK;
		String retMsg = null; 
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstancePropertiesRest : " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			Response response = updateAssetInstancePropertiesRestHelper(assetName, assetInstName, versionName, parameterDetails, formParams, context, token, true, true, conn);
			MyModelRest modelRest = null;
			int statusCode = 0;
			String statusMessage = "";
			if(response.getEntity() instanceof MyModelRest){
				modelRest = (MyModelRest) response.getEntity();
			}
			if(modelRest != null){
				statusCode = response.getStatus();
				statusMessage = modelRest.getMessage();				
			}
			
			if(modelRest.getStatus().equalsIgnoreCase("SUCCESS")){
				conn.commit();
			}
			return response;
		}
		catch (RepoproException e) {
			log.error("updateAssetInstancePropertiesRest: SQL Exception  updateAssetInstanceDescription: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}
		catch (Exception e) {
			log.error("updateAssetInstancePropertiesRest: SQL Exception updateAssetInstanceDescription: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstancePropertiesRest : " + Constants.LOG_CONNECTION_CLOSE);
			}
			if(conn != null){
				DBConnection.closeDbConnection(conn);
			}
		}

		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstancePropertiesRest: Exit");
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	public Response updateAssetInstancePropertiesRestHelper(
			String assetName,String assetInstName,String versionName,
			String parameterDetails,FormDataMultiPart formParams ,
			ServletContext context, String token, boolean revHistFlag, boolean responseFlag,
			Connection conn )throws RepoproException{

		/*if(assetName == null|| assetInstName == null || versionName == null || parameterDetails == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(assetName.isEmpty()|| assetInstName.isEmpty() || versionName.isEmpty() || parameterDetails.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}*/

		AssetInstanceVersion aiv = null;
		List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();
		List<String> jsonStr = new ArrayList<String>();
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		User user = new User();
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		versionName = versionName.trim();
		CommonUtils commonUtils = new CommonUtils();
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();
		//String responseMsg = "";
		String userName = "";
		if(parameterDetails != null && !parameterDetails.isEmpty()){
			parameterDetails = parameterDetails.trim();
		}
		AssetDao assetDao = new AssetDao();
		FormDataBodyPart dataMultiPart=null;
		Connection conn1 = null;
		if(parameterDetails != null && !parameterDetails.isEmpty()){
			try{
				//System.out.println(parameterDetails.toString());
				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("updateAssetInstancePropertiesRestHelper || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);

				String jsonStr1 = parameterDetails;
				JSONObject obj1 = new JSONObject(jsonStr1);
				String aivList = obj1.get("propertiesList").toString();
				JSONArray aivListArray = new JSONArray(aivList);
				AssetInstanceVersion aiv2 = new AssetInstanceVersion();
				for (int i = 0; i < aivListArray.length(); i++) {
					Iterator itr = aivListArray.getJSONObject(i).keys();
					while (itr.hasNext()) {
						aiv2 = new AssetInstanceVersion();
						String value = null;
						if(aivListArray.getJSONObject(i).has("assetParamName")){
							aiv2.setAssetParamName(aivListArray.getJSONObject(i).get("assetParamName").toString());
						}else{
							return Response
									.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
											.build();

						}

						//valid parameter check 
						AssetParamDef paramCheck = assetDao.getParamIdForAssetAndParamName(assetName,aiv2.getAssetParamName(),conn);
						if(paramCheck == null || paramCheck.getAssetParamId() == null){
							return Response
									.status(Status.NOT_FOUND)
									.entity(new MyModelRest(Constants.GET_STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_ASSET_PARAM_NAME)))
											.build();
						}
						if(paramCheck.getParamTypeId() == 3){
							if(aivListArray.getJSONObject(i).has("fileName")){
								aiv2.setFileName(aivListArray.getJSONObject(i).get("fileName").toString());
								aiv2.setMandatory(paramCheck.isHasMandatoryValue());
							}else{
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))	.build();
							}
						}else{
							if(paramCheck.getParamTypeId() == 4){
								//if(paramCheck.getListTypeParamTypeId() != 4){
									ArrayList<String> listdata = new ArrayList<String>();  
									aiv2.setMandatory(paramCheck.isHasMandatoryValue());
									if(aivListArray.getJSONObject(i).has("paramValue")){
										value = aivListArray.getJSONObject(i).get("paramValue").toString();
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();
									}

									if(value.length() != 0 && value.startsWith("[")){
										JSONArray valueArray = new JSONArray(value);
										if (valueArray != null) { 
											for (int j=0;j<valueArray.length();j++){ 
												listdata.add(valueArray.getString(j));
											} 
										}
										
										boolean duplicateFlag = false;
										Set<String> duplicate = new HashSet<String>();
										duplicate.addAll(listdata);
										if(duplicate.size()<listdata.size()){
											duplicateFlag = true;
										}
										if(duplicateFlag){
											retStat = Status.BAD_REQUEST;
											retScsFlr = Constants.FAILURE;
											retMsg = "DUPLICATE_DATA_NOT_ALLOWED";
											retStatScsFlr = Constants.STATUS_FAILURE;
											return Response.status(retStat)
													.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
													.build();
										}
										
										if(paramCheck.getListType() == 0){
											if(listdata.size()>1){
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
										}
										String listString = "";
										for(String s : listdata){
											listString += s + "~~";
										}
										if (listString.endsWith("~~")) {
											listString = listString.substring(0, listString.length() - "~~".length());
										}
										aiv2.setParamValue(listString);
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();

									}
								//}
							}else if(paramCheck.getParamTypeId() == 1){
								aiv2.setMandatory(paramCheck.isHasMandatoryValue());
								if(paramCheck.isHasStaticValue() == true){
									if(aivListArray.getJSONObject(i).has("paramValue")){
										String paramVal = "";
										if(globalsetting.getGlobalSettingFlag() == 1){
											paramVal = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
										}
										else{
											paramVal = aivListArray.getJSONObject(i).get("paramValue").toString();
										}
										aiv2.setParamValue(paramVal);	
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();
									}
								}else{

									if(paramCheck.getHasArray() == 1){
										aiv2.setHasArray(paramCheck.getHasArray());
										String textdata1 = null;
										if(aivListArray.getJSONObject(i).has("paramValue")){
											String paramval = "";
											if(globalsetting.getGlobalSettingFlag() == 1){
												paramval = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
											}else{
												paramval = aivListArray.getJSONObject(i).get("paramValue").toString();
											}

											textdata1 = paramval;
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();
										}
										if(textdata1 != null){
											if(textdata1.startsWith("[")){
												JSONArray textdataJsonArray = new JSONArray(textdata1);
												List<String> textDataList = new ArrayList<String>();
												for(int ii=0;ii<textdataJsonArray.length();ii++){
													textDataList.add(textdataJsonArray.getString(ii));
												}
												aiv2.setTextDataList(textDataList);
												// for adding revision history
												String textdata = String.join("~~", aiv2.getTextDataList());
												aiv2.setParamValue(textdata);
											}else{
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
										}
									}else{
										aiv2.setHasArray(paramCheck.getHasArray());

										if(aivListArray.getJSONObject(i).has("paramValue")){
											String paramval = "";
											if(globalsetting.getGlobalSettingFlag() == 1){
												paramval = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
											}else{
												paramval = aivListArray.getJSONObject(i).get("paramValue").toString();
											}
											aiv2.setParamValue(paramval);	
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();
										}
									}
								}
							}else if (paramCheck.getParamTypeId() == 7){
								aiv2.setMandatory(paramCheck.isHasMandatoryValue());
								if(paramCheck.getHasArray() == 1){
									aiv2.setHasArray(paramCheck.getHasArray());
									List<String> listdatawithouttag = new ArrayList<String>();
									List<String> listdatawithtag = new ArrayList<String>();
									String richText = null;
									if(aivListArray.getJSONObject(i).has("paramValue")){
										richText = aivListArray.getJSONObject(i).get("paramValue").toString();
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();
									}
									if(richText != null){
										if(richText.startsWith("[")){
											//	System.out.println("processed");
											JSONArray valueArray1 = new JSONArray(richText);

											if (valueArray1 != null) { 
												for (int j=0;j<valueArray1.length();j++){ 
													String richText1 = "";
													if(globalsetting.getGlobalSettingFlag() == 1){
														richText1 = commonUtils.httpSanitizerForCkEditor(valueArray1.getString(j));
													}else {
														richText1 = valueArray1.getString(j);
													}
													listdatawithtag.add(richText1);
													String textdata = Jsoup.parse(valueArray1.getString(j)).text();

													listdatawithouttag.add(textdata);
												} 
												aiv2.setRTFwithTags(listdatawithtag);
												aiv2.setRTFwithOutTags(listdatawithouttag);
												// for adding revision history
												String textdata = String.join("~~", aiv2.getRTFwithTags());
												aiv2.setParamValue(textdata);
											}
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();
										}
									}

								}else{
									aiv2.setHasArray(paramCheck.getHasArray());

									String richText = "";
									if(aivListArray.getJSONObject(i).has("paramValue")){
										richText = aivListArray.getJSONObject(i).get("paramValue").toString();
										if(globalsetting.getGlobalSettingFlag() == 1){
											richText = commonUtils.httpSanitizerForCkEditor(richText);
										}
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();
									}
									aiv2.setParamValue(richText);
									String textdata = null;
									if (richText != null) { 
										textdata = Jsoup.parse(richText).text();
										aiv2.setRTFPlainText(textdata);
									}
								}
							}else if(paramCheck.getParamTypeId() == 8) {
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.DERIVED_PARAMETERS_NOT_ALLOWED)))
												.build();
							}
							else if(paramCheck.getParamTypeId() == 9) {
								aiv2.setMandatory(paramCheck.isHasMandatoryValue());
								
								try {
									Map<String, Integer> ldapParamValues;
									ldapParamValues = commonUtils.ldapDataconstruction(aivListArray.getJSONObject(i).get("paramValue").toString(), assetName, paramCheck.getAssetParamName(), conn);
									aiv2.setLdapMappingValue(ldapParamValues);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									throw new RepoproException(e.getMessage());
								}
								
							}
							else{
								if(aivListArray.getJSONObject(i).has("paramValue")){
									aiv2.setMandatory(paramCheck.isHasMandatoryValue());
									aiv2.setParamValue(aivListArray.getJSONObject(i).get("paramValue").toString());	
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();
								}
							}

						}
						ListOfAssetInstanceProperties.add(aiv2);
						break;

					}
				}
			}catch(org.json.JSONException e){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
								.build();

			} catch (RepoproException e) {
				e.printStackTrace();
				throw new RepoproException(e.getMessage());
			}
		}

		try {
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();

			LDAPConnection ldapConnection = LDAPConnection.getInstance();
			DirContext dirContext = ldapConnection.getDirContext();
			LDAPUtility ldapUtility = new LDAPUtility();

			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("updateAssetInstancePropertiesRestHelper || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			else{
				user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			Long userId = user.getUserId();
			int activeFlag = Integer.parseInt(user.getActiveFlag());

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstancePropertiesRestHelper: call dao getAssetinstDetails() method");
			}

			aiv = assetInstanceVersionDao.getAssetinstDetails(assetName,assetInstName,versionName,conn);
			if (aiv == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("updateAssetInstancePropertiesRestHelper || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

			Long aivId = aiv.getAssetInstVersionId();
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			boolean editFlag = false;
			boolean flag1 = false;
			boolean unlockFlag = false;
			boolean adminFlag = false;

			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(!adminFlag){
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstancePropertiesRestHelper || dao method called : retAivAccessRights ");
				}
				groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(aivId, userName, conn);

				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
						editFlag = true;
						break;
					}
				}
			}else{
				editFlag = true;
			}
			AssetInstanceVersion assetInstanceVersion = assetInstanceVersionDao.getAssetInstanceVersionDetails(aivId,conn);

			if(editFlag){
				if(assetInstanceVersion.getLockedBy() == null){
					flag1 = true;

				}else if(assetInstanceVersion.getLockedBy().equalsIgnoreCase(userName)){
					flag1 = true;
					unlockFlag = true;
				}
				else{
					retMsg = Constants.ASSET_INSTANCE_VERSION_LOCKED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					retStat = Status.FORBIDDEN;
					log.trace("updateAssetInstancePropertiesRestHelper || End");
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("updateAssetInstancePropertiesRestHelper || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

			if(editFlag && flag1 ){
				if(parameterDetails != null && !parameterDetails.isEmpty()){

					if(formParams != null){
						dataMultiPart = formParams.getField("images");
					}

					try 
					{
						if(dataMultiPart != null){
							InputStream inputstream = dataMultiPart.getEntityAs(InputStream.class);
							String vals = dataMultiPart.getContentDisposition().getFileName();

							if(vals.endsWith(".zip")){
								InputStream fin;
								String nm = null;

								//fin = new FileInputStream(vals);
								fin = dataMultiPart.getEntityAs(InputStream.class);
								BufferedInputStream bin = new BufferedInputStream(inputstream);
								ZipInputStream zin = new ZipInputStream(bin);
								ZipEntry ze = null;
								File file4 = new File(System.getProperty("user.home")+"/RepoProImagesUnzip");
								if (!file4.exists()) 
								{
									if (file4.mkdir()) {
									} else {
										System.out.println("Failed to create directory unzip!");
									}
								}

								while ((ze = zin.getNextEntry()) != null) 
								{
									String filename = ze.getName();

									int idx = filename.replaceAll("\\\\", "/").lastIndexOf("/");
									nm =     idx >= 0 ? filename.substring(idx + 1) : filename;
									/*if(nm.endsWith(".xlsx"))
							{
								excelFile = nm ;
							}*/
									if(nm.trim().isEmpty()) continue;	//a folder, we are not interested
									OutputStream out = new FileOutputStream(System.getProperty("user.home")+"/RepoProImagesUnzip/"+nm);
									byte[] buffer = new byte[8192];
									int len;
									while ((len = zin.read(buffer)) != -1)
									{
										out.write(buffer, 0, len);
									}
									out.close();
								}
								fin.close();
								File folder1 = new File(System.getProperty("user.home")+"/RepoProImagesUnzip/");
								File[] listOfFiles1 = folder1.listFiles();


							} else{ 

								inputstream = dataMultiPart.getEntityAs(InputStream.class);
							}

						}
					}catch (Exception e) 
					{
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();

					} 


					/*if (ListOfAssetInstanceProperties.isEmpty()) {
						log.warn("updateAssetInstancePropertiesRestHelper || version data  not provided to update");
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil
										.getMessage(Constants.INVALID_REQUEST)))
										.build();
					} else {*/
					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstancePropertiesRestHelper || "
								+ ListOfAssetInstanceProperties.toString()
								+ " Begin with assetInstName" + assetInstName
								+ "assetName" + assetName + "userName " + userName);

					}

					SubscriptionDao subscriptionDao = new SubscriptionDao();
					RecentActivityDao recentActivityDao = new RecentActivityDao();
					GamificationDao gamificationDao = new GamificationDao();
					String action = Constants.ACTIVITY_MODIFY;
					AssetInstanceVersion aiv1 = new AssetInstanceVersion();
					String newParamDataForRevision = "";
					String fileText = "";
					GamificationDetails gamePoint = new GamificationDetails();
					int countForParam = 1;
					int paramCount = 0;
					paramCount = paramCount + ListOfAssetInstanceProperties.size();
					NameValue paramValue = new NameValue();
					ParameterValues pv = new ParameterValues();
					String catName = null;
					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstancePropertiesRestHelper || "
								+ Constants.LOG_CONNECTION_OPEN);
					}


					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstancePropertiesRestHelper || called dao method : getParamsDetailByAssetName(): assetName "
								+ assetName); 
					}
					List<AssetParamDef> apd1 = assetDao.getParamsDetailByAssetName(assetName,conn);


					//mandatory check 

					ArrayList<String> frontList = new ArrayList<String>();
					for(AssetInstanceVersion st1 : ListOfAssetInstanceProperties){
						if(st1.isMandatory()){
							frontList.add(st1.getAssetParamName());
						}
					}

					for(AssetParamDef st : apd1){
						if(st.getParamTypeId()!= 5 && st.getParamTypeId()!= 6 ){

							if(st.isHasMandatoryValue()){

								boolean paramAccessFlag = false;
								/*if(!userName.equalsIgnoreCase("admin")){
							         AssetParamDef paramaccess = assetDao.getAssetParamAccess(userName,st.getAssetParamName(),assetName,null);
							         if(paramaccess == null || paramaccess.getAssetParamId() == null){
							          paramAccessFlag = false;
							         }
							        }*/
								if(!userName.equalsIgnoreCase("admin")){
									List<GroupDetails> gd = assetDao.getAssetCategoryEditAccessForPropertiesAivPage(userName,st.getAssetCategoryId(), conn);
									for(GroupDetails gd1 : gd){
										if(gd1.getEditAccess() == 1L){
											paramAccessFlag = true;	
											break;
										}
									}
								}else{
									paramAccessFlag = true;   
								}
								if(paramAccessFlag){

									if(st.isHasStaticValue()){

										AssetParamDef ap = assetDao.getParamIdForAssetAndParamName(
												assetName, st.getAssetParamName(), conn);

										if(ap.getParamTypeId() == 3){
											if(ap.getFileName()== null ||ap.getFileName().equalsIgnoreCase("")){
												if(frontList.isEmpty()){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
												Boolean checkstaticflag = false;
												for(String str : frontList ){
													if(str.equalsIgnoreCase(ap.getAssetParamName())){
														checkstaticflag = true;
														break;
													}
												}
												if(!checkstaticflag){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();

												}

											}

										}else{
											//if(ap.getListTypeParamTypeId() != 4){
												if(ap.getStaticValue() == null || ap.getStaticValue().equalsIgnoreCase("")){

													if(frontList.isEmpty()){
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																		.build();
													}
													Boolean checkstaticflag = false;
													for(String str : frontList ){
														if(str.equalsIgnoreCase(ap.getAssetParamName())){
															checkstaticflag = true;
															break;
														}
													}
													if(!checkstaticflag){
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																		.build();

													}
												}
											//}
										}
									}// end of static loop
									else{
										pv = assetDao.getParameterForAssetInstParamAndVersionId(
												st.getAssetParamName(), aivId, conn);
										if(st.getParamTypeId() == 3){
											if(pv == null || pv.getFileName() == null || pv.getFileName().equalsIgnoreCase("")){
												if(frontList.isEmpty()){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
												Boolean checkingFlag = false;
												for(String str : frontList ){
													if(str.equalsIgnoreCase(st.getAssetParamName())){
														checkingFlag = true;
														break;
													}
												}
												if(!checkingFlag){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
											}

										}else if(st.getParamTypeId() == 1 && st.getHasArray()== 1){
											if(pv == null || pv.getTextDataList() == null|| pv.getTextDataList().isEmpty()){
												if(frontList.isEmpty()){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
												Boolean checkingFlag = false;
												for(String str : frontList ){
													if(str.equalsIgnoreCase(st.getAssetParamName())){
														checkingFlag = true;
														break;
													}
												}
												if(!checkingFlag){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
											}
										}else if(st.getParamTypeId() == 7 && st.getHasArray()== 1){
											if(pv == null ||pv.getRTFwithTags() == null|| pv.getRTFwithTags().isEmpty()){
												if(frontList.isEmpty()){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
												Boolean checkingFlag = false;
												for(String str : frontList ){
													if(str.equalsIgnoreCase(st.getAssetParamName())){
														checkingFlag = true;
														break;
													}
												}
												if(!checkingFlag){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
											}
										}else{
											//if(st.getListTypeParamTypeId() != 4){
												if(pv == null ||pv.getValue() == null|| pv.getValue().equalsIgnoreCase("")){
													if(frontList.isEmpty()){
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																		.build();
													}
													Boolean checkingFlag = false;
													for(String str : frontList ){
														if(str.equalsIgnoreCase(st.getAssetParamName())){
															checkingFlag = true;
															break;
														}
													}
													if(!checkingFlag){
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																		.build();
													}
												}
											//}
										}
									}// end of non-static loop
								}
							}// mandatory
						}//not derived parameters

					}
					//List<String> ldapParamNamesList = new ArrayList<String>();
					//List<String> invalidIdsList = new ArrayList<String>();
					for (AssetInstanceVersion param : ListOfAssetInstanceProperties) {

						for(AssetParamDef apd2 : apd1){
							if(apd2.getAssetParamName().equalsIgnoreCase(param.getAssetParamName().trim())){
								param.setAssetParamId(apd2.getAssetParamId());
								param.setParamTypeId(apd2.getParamTypeId());
								param.setParamTextSize(apd2.getSize());
								param.setListTypeParamTypeId(apd2.getListTypeParamTypeId());
								param.setMappedAssetId(apd2.getMappedAssetId());
								param.setMandatory(apd2.isHasMandatoryValue());
								param.setAsset_category_name(apd2.getAssetCategoryName());
								param.setCategoryId(apd2.getAssetCategoryId());
								if(apd2.isHasStaticValue() == true ){
									param.setIsStatic(1);
								}else{
									param.setIsStatic(0);
								}
								break;
							}
						}

						//category access check

						if(!userName.equalsIgnoreCase("admin")){
							AssetParamDef ap = 	assetDao.getAssetCategoryAccess(userName,param.getAsset_category_name(),assetName,conn);
							if( ap == null || ap.getAssetCategoryId() == null){
								retStat = Status.FORBIDDEN;
								retMsg = Constants.USER_NOT_AUTHORIZED;
								retScsFlr = Constants.NOT_AUTHORIZED;
								retStatScsFlr = Constants.FORBIDDEN;
								log.trace("updateAssetInstancePropertiesRestHelper || End");
								return Response
										.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}

						}
						//edit category access check
						if(!userName.equalsIgnoreCase("admin")){
							List<GroupDetails> gd = assetDao.getAssetCategoryEditAccessForPropertiesAivPage(userName,param.getCategoryId(), conn);
							for(GroupDetails gd1 : gd){
								if(gd1.getEditAccess() == 1L){
									param.setEditAccessFlag(true);	
									break;
								}
							}

							if(param.isEditAccessFlag() == false){
								retStat = Status.FORBIDDEN;
								retMsg = Constants.USER_NOT_AUTHORIZED;
								retScsFlr = Constants.NOT_AUTHORIZED;
								retStatScsFlr = Constants.FORBIDDEN;
								log.trace("updateAssetInstancePropertiesRestHelper || End");
								return Response
										.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}
						}

						// derived attribute and computation check

						if(param.getParamTypeId() == 5 || param.getParamTypeId() == 6){
							return Response
									.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.DERIVED_PARAMETERS_NOT_ALLOWED)))
											.build();
						}

						// mandatory check 

						if(param.getFileName() != null){
							param.setParamValue(param.getFileName());
						}
						if(param.isMandatory()){
							if(param.getParamTypeId() == 1){// text
								if(param.getHasArray() == 1){
									if(param.getTextDataList()== null || param.getTextDataList().isEmpty()){
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, "Provide values for mandatory parameters"))
														.build();
									}
								}else{
									if(param.getParamValue() == null || param.getParamValue().equalsIgnoreCase("")){
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, "Provide values for mandatory parameters"))
														.build();
									}
								}
							}else if (param.getParamTypeId() == 7){// rich text
								if(param.getHasArray() == 1){
									if(param.getRTFwithTags().isEmpty()|| param.getRTFwithTags() == null){
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, "Provide values for mandatory parameters"))
														.build();
									}
								}else{
									if(param.getParamValue() == null || param.getParamValue().equalsIgnoreCase("")){
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, "Provide values for mandatory parameters"))
														.build();
									}
								}
							}else if(param.getParamTypeId() == 3){ // other parameter type

								if(param.getFileName() == null || param.getFileName().equalsIgnoreCase("")){
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, "Provide values for mandatory parameters"))
													.build();
								}
							}else if(param.getParamTypeId() == 9) {
								if(param.getLdapMappingValue() == null || param.getLdapMappingValue().equals("")) {
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, "Provide values for mandatory parameters"))
													.build();
								}
							}
							else{ // other parameter type
								//if(param.getListTypeParamTypeId() != 4){
									if(param.getParamValue() == null || param.getParamValue().equalsIgnoreCase("")){
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, "Provide values for mandatory parameters"))
														.build();
									}
								//}
							}
						}

						if(param.getParamTypeId() == 1){
							if(param.getHasArray() == 1){
								if(param.getTextDataList() != null && !param.getTextDataList().isEmpty()){
									for(String str : param.getTextDataList()){
										if(str.length()>param.getParamTextSize()){
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, "Maxlength exceeded for text parameter"))
															.build();
										}
									}
								}
							}else if(param.getParamValue()!=null && param.getParamValue().length()> param.getParamTextSize()){
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
												Constants.FAILURE, "Maxlength exceeded for text parameter"))
												.build();

							}
						}else if (param.getParamTypeId() == 2){
							if(param.getParamValue().length()!= 0){
								if(param.getParamValue().matches("(^(((0[1-9]|[12][0-8])[/](0[1-9]|1[012]))|((29|30|31)[/](0[13578]|1[02]))|((29|30)[/](0[4,6,9]|11)))[/](19|[2-9][0-9])\\d\\d$)|(^29[/]02[/](19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)")){

									String[] words = param.getParamValue().split("/");
									int num = Integer.parseInt(words[2]);
									if(num >2999){
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();
									}
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();
								}
							}
						}/*else if(param.getParamTypeId() == 3){
                	   if(!param.getParamValue().equalsIgnoreCase(file.getName())){
            			   return Response
                  			     .status(Status.BAD_REQUEST)
                  			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
                  			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
                  			     .build();

                      	   }


                   }*/else if(param.getParamTypeId() == 4){

                	   if(param.getListTypeParamTypeId() == 1){
                		   if(param.getParamValue() != ""){
                			   List<PossibleValues>  possiblevalues = assetDao.getAllPossibleValuesByParamId(param.getAssetParamId() ,conn);
                			   String[] name = null;
                			   name = param.getParamValue().split("~~"); 
                			   for(String n :name){ 
                				   boolean falg = false;
                				   for(PossibleValues values : possiblevalues){
                					   if(n.equals(values.getValue())){
                						   falg = true;
                						   break;
                					   }
                				   }
                				   if(!falg){
                					   return Response
                							   .status(Status.BAD_REQUEST)
                							   .entity(new MyModelRest(Constants.STATUS_FAILURE,
                									   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
                									   .build();
                				   }
                			   }
                		   }
                	   }else if(param.getListTypeParamTypeId() == 2){
                		   String[] name = null;
                		   if(param.getParamValue() != ""){
                			   name = param.getParamValue().split("~~");
                			   for(String value :name){
                				   AssetInstance ai =  assetInstanceDao.retAssetInstance(param.getMappedAssetId(),value,conn);
                				   if(ai.getAssetInstId() == null){
                					   return Response
                							   .status(Status.BAD_REQUEST)
                							   .entity(new MyModelRest(Constants.STATUS_FAILURE,
                									   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
                									   .build();

                				   }
                			   }
                		   }

                	   }else if(param.getListTypeParamTypeId() == 3){
                		   String[] name = null;
                		   if(param.getParamValue() != ""){
                			   name = param.getParamValue().split("~~");
                			   for(String value :name){
                				   User usercheck = userDao.getUserIdByUserName(value,conn); 
                				   if(usercheck.getUserId() == null){
                					   return Response
                							   .status(Status.BAD_REQUEST)
                							   .entity(new MyModelRest(Constants.STATUS_FAILURE,
                									   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
                									   .build();
                				   }
                			   }

                		   }
                	   }else if(param.getListTypeParamTypeId() == 4){ /*ldap userlist*/


                		   //ldapParamNamesList.add(param.getAssetParamName());


                		   if(param.getParamValue() != ""){

                			   List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
                			   
                			   Set<String> duplicate = new HashSet<String>();

                			   String[] names = param.getParamValue().split("~~");
                			   for(int i1=0;i1<names.length;i1++){
                				   duplicate.add(names[i1]);
                			   }
                			   if(duplicate.size()<names.length){
                				   retStat = Status.BAD_REQUEST;
                				   retScsFlr = Constants.FAILURE;
                				   retMsg = "DUPLICATE_DATA_NOT_ALLOWED";
                				   retStatScsFlr = Constants.STATUS_FAILURE;
                				   return Response.status(retStat)
                						   .entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
                			   }

                			   String listString = "";
                			   for(int i=0;i<names.length;i++){
                				   if(names[i].contains("(")){
                					   if(!names[i].endsWith(")")){
                						   return Response.status(Status.BAD_REQUEST)
                								   .entity(new MyModelRest(Constants.STATUS_FAILURE,
                										   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
                					   }

                					   String value = names[i];
                					   String id = value.substring(value.indexOf("(") + 1, value.indexOf(")"));

                    				   listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,id);

                    				   if(listOfLDAPUsers.size() == 0){ //no results
                    					   /*log.warn("updateAssetInstancePropertiesRestHelper || "+ names[i] +"did not retrieve any result");
                    					   invalidIdsList.add(names[i]);*/
                    					   return Response.status(Status.BAD_REQUEST)
                								   .entity(new MyModelRest(Constants.STATUS_FAILURE,
                										   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();

                    				   }else if(listOfLDAPUsers.size() == 1){ //Exact One 1 result

                    					   String fullName = names[i].substring(0, names[i].indexOf("("));
                    					   for(LDAPUser ldapUser : listOfLDAPUsers){
                    						   if(!fullName.equalsIgnoreCase(ldapUser.getFirstName() +" "+ ldapUser.getLastName())){
                    							   return Response.status(Status.BAD_REQUEST)
                    									   .entity(new MyModelRest(Constants.STATUS_FAILURE,
                    											   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
                    						   }
                    						   listString += ldapUser.getFirstName()+" "+ldapUser.getLastName()+"("+ldapUser.getUserId()+")"+ "~~";
                    					   }

                    				   }else if(listOfLDAPUsers.size() > 1){ //multiple results
                    					   return Response.status(Status.BAD_REQUEST)
                								   .entity(new MyModelRest(Constants.STATUS_FAILURE,
                										   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
                    				   }

                				   }else{
                    				   listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,names[i]);

                    				   if(listOfLDAPUsers.size() == 0){ //no results 
                    					   /*log.warn("updateAssetInstancePropertiesRestHelper || "+ names[i] +"did not retrieve any result");
                    					   invalidIdsList.add(names[i]);*/
                    					   return Response.status(Status.BAD_REQUEST)
                								   .entity(new MyModelRest(Constants.STATUS_FAILURE,
                										   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();

                    				   }else if(listOfLDAPUsers.size() == 1){ //Exact One 1 result

                    					   for(LDAPUser ldapUser : listOfLDAPUsers){
                    						   listString += ldapUser.getFirstName()+" "+ldapUser.getLastName()+"("+ldapUser.getUserId()+")"+ "~~";
                    					   }

                    				   }else if(listOfLDAPUsers.size() > 1){ //multiple results
                    					   return Response.status(Status.BAD_REQUEST)
                								   .entity(new MyModelRest(Constants.STATUS_FAILURE,
                										   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
                    				   }
                				   }
                			   }

                			   /*if(!invalidIdsList.isEmpty()) {
                				   String invalidLdapIds = StringUtils.join(invalidIdsList, ',');
                				   responseMsg = " and "+invalidLdapIds+" did not retrieve any result";
                			   }*/
                			   
                			   
                			   /*for(String str : idsList){
                				   
                				   listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,str);

                				   if(listOfLDAPUsers.size() == 0){ //no results 

                				   }else if(listOfLDAPUsers.size() == 1){ //Exact One 1 result

                					   listString += str + "~~";

                				   }else if(listOfLDAPUsers.size() > 1){ //multiple results
                					   return Response.status(Status.BAD_REQUEST)
            								   .entity(new MyModelRest(Constants.STATUS_FAILURE,
            										   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
                				   }

                			   }*/

                			   if (listString.endsWith("~~")) {
                				   listString = listString.substring(0, listString.length() - "~~".length());
                			   }
                			   param.setParamValue(listString);

                			   if(listString.trim().isEmpty()){
                				   if(param.getIsStatic() == 0) {
                					   ParameterValues paramValues = assetDao.getParameterForAssetInstParamAndVersionId(param.getAssetParamName(),aivId,conn);
                    				   if(paramValues != null) {
                    					   param.setParamValue(paramValues.getValue());
                    				   }
                				   }else {
                					   AssetParamDef apd = assetDao.getParamIdForAssetAndParamName(assetName,param.getAssetParamName(),conn);
                					   if(apd != null) {
                						   param.setParamValue(apd.getStaticValue());
                					   }
                				   }
                				   
                			   }
                		   }

                	   }//end of ldap type parameter
                   }
						param.setAssetName(assetName);
						param.setAssetInstVersionId(aivId);
						Boolean flag = false;
						String NewFileName = null;
						String oldFileName = null;
						NameValue nv = null;

						if (param.getParamTypeId() == (Constants.FILE_TYPE)) {
							if(param.getFileName().length()!= 0){
								if(formParams == null){
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();
								}
							}
							if(formParams != null){
								nv = new  NameValue ();
								File file= new File(System.getProperty("user.home")+"/RepoProImagesUnzip/"+param.getParamValue());

								nv.setFileName(file.getName());
								if(!nv.getFileName().equalsIgnoreCase(param.getFileName())){
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();
								}
								try{
									nv.setByteValue(FileUtils.readFileToByteArray(file));
								}catch (Exception e){
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();
								}
								NewFileName = nv.getFileName();
								paramValue.setFileName(nv.getFileName());
								InputStream myInputStream = null ;
								myInputStream = new ByteArrayInputStream(nv.getByteValue()); 
								paramValue.setImage(myInputStream);
								paramValue.setFileMimeType(new MimetypesFileTypeMap().getContentType(file));
							}else{
								NewFileName = "";
								paramValue.setFileName(param.getFileName());
							}
							if (log.isTraceEnabled()) {
								log.trace("updateAssetInstancePropertiesRestHelper || called dao method : getParameterForAssetInstParamAndVersionId() by : assetInstanceVersionId "
										+ aivId
										+ "and AssetParamName "
										+ param.getAssetParamName());
							}
							pv = assetDao
									.getParameterForAssetInstParamAndVersionId(
											param.getAssetParamName(), aivId,
											conn);


							if (log.isTraceEnabled()) {
								log.trace("updateAssetInstancePropertiesRestHelper || called dao method : getParamIdForAssetAndParamName() by : assetName "
										+ assetName
										+ "and AssetParamName "
										+ param.getAssetParamName());
							}

							AssetParamDef apd = assetDao
									.getParamIdForAssetAndParamName(
											assetName,
											param.getAssetParamName(), conn);

							/*if(param.getIsStatic() == 1){
									if(apd != null)
										param.setFileName(apd.getFileName());
								}else{
									if(pv != null)
										param.setFileName(pv.getFileName());
								}*/

							if(NewFileName == null || NewFileName.length()== 0){
								oldFileName = param.getFileName();
							}else{
								oldFileName = NewFileName;
							}

							param.setNewFileName(paramValue.getFileName());

							if (!userName.equalsIgnoreCase("admin") && activeFlag == 1) {

								if (pv != null) {
									if (pv.getFileName() != null && oldFileName.length() != 0 ) {
										if (!pv.getFileName().equalsIgnoreCase(
												oldFileName)
												&& (pv.isImportant() == true)) {

											flag = true;
											gamePoint.setField("Parameter - "
													+ param.getAssetParamName());
											gamePoint.setAction("Updated");

										}
									}
								} else {

									if (oldFileName.length() != 0 
											&& apd.isHasImportantValue() == true) {

										flag = true;
										gamePoint.setField("Parameter - "
												+ param.getAssetParamName());
										gamePoint.setAction("Created");

									}
								}
							}

							if (!NewFileName.isEmpty() || NewFileName.length() != 0) {

								fileText = paramValue.getFileName();

							} else if (param.getFileName() != null
									/* || !param.getFileName().isEmpty() */) {
								fileText = param.getFileName();
							} else {
								fileText = " ";
							}

							if (countForParam == paramCount) {
								if ((param.getParamTypeId() != 5)
										&& param.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision
											+ param.getAssetParamName()
											+ ":"
											+ fileText;

								}
							} else {
								if ((param.getParamTypeId() != 5)
										&& param.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision
											+ param.getAssetParamName()
											+ ":"
											+ fileText + Constants.APPEND_STRING;

								}
							}

							// db

							Boolean UpdateFileinDB = true;
							if (NewFileName.length() == 0
									&& param.getFileName().length() != 0) {
								UpdateFileinDB = false;
							}
							if (UpdateFileinDB) {
								if ((param.getParamTypeId() != 5)
										&& param.getParamTypeId() != 6) {

									if (log.isTraceEnabled()) {
										log.trace("updateAssetInstancePropertiesRestHelper || called helper method : updateParameterForAssetInst() : to update parameter");

									}
									paramValue.setName(param
											.getAssetParamName());

									aivManager.updateParameterForAssetInst(param,
											paramValue, userId, conn);


								}
							}

							// folder

							if (!NewFileName.isEmpty() || NewFileName.length() != 0) {

								String NewFile = null;
								InputStream myInputStream1 = null ;
								myInputStream1 = new ByteArrayInputStream(nv.getByteValue()); 

								if (log.isTraceEnabled()) {
									log.trace("updateAssetInstancePropertiesRestHelper || called helper method : getNameValue()");
								}

								aivManager.getNameValue(param, myInputStream1, paramValue.getFileName(), context, conn);

							}

						}// filetype
						//else if(param.getListTypeParamTypeId() != 4){

							if (!userName.equalsIgnoreCase("admin") && activeFlag == 1) {

								if (log.isTraceEnabled()) {
									log.trace("updateAssetInstancePropertiesRestHelper || called dao method : getParameterForAssetInstParamAndVersionId() by : assetInstanceVersionId "
											+ aivId
											+ "and AssetParamName "
											+ param.getAssetParamName());
								}

								pv = assetDao
										.getParameterForAssetInstParamAndVersionId(
												param.getAssetParamName(), aivId,
												conn);

								if (pv != null) {
									String oldValueImp = "";
									String newValueImp = "";
									if (pv.getParamTypeId() == 1 ){
										if(pv.getHasArray() == 1){
											oldValueImp = pv.getTextDataList().toString();
											newValueImp = param.getTextDataList().toString();
										}else{
											oldValueImp = pv.getValue().toString();
											newValueImp = param.getParamValue().trim().toString();
										}
									}else if(pv.getParamTypeId() == 7){
										if(pv.getHasArray() == 1){
											oldValueImp = pv.getRTFwithTags().toString();
											newValueImp = param.getRTFwithTags().toString();
										}else{
											oldValueImp = pv.getValue().toString();
											newValueImp = param.getParamValue().trim().toString();
										}
									}else if(pv.getParamTypeId() == 9){
										List<String> oldLdapValue = new ArrayList<String>();
										List<String> newLdapValue = new ArrayList<String>();
										List<String> dbvalueList = pv.getLdapMappingMap().keySet().stream().collect(Collectors.toList());
										List<String> uivalueList = param.getLdapMappingValue().keySet().stream().collect(Collectors.toList());

										if(pv.getHasArray() == 1) {
											oldLdapValue = dbvalueList;
											newLdapValue = uivalueList;
										}else {
											oldLdapValue = dbvalueList;
											newLdapValue = uivalueList;
										}
									}else{
										oldValueImp = pv.getValue().trim().toString();
										newValueImp = param.getParamValue().trim().toString();
									}
									int num = oldValueImp.compareTo(newValueImp);
									if ((num < 0 || num > 0) && (pv.isImportant() == true)) {
										// countImp++;
										flag = true;
										gamePoint.setField("Parameter - " + param.getAssetParamName());
										gamePoint.setAction("Updated");
									}
								} else {

									if (log.isTraceEnabled()) {
										log.trace("updateAssetInstancePropertiesRestHelper || called dao method : getParamIdForAssetAndParamName() by : assetName "
												+ assetName
												+ "and AssetParamName "
												+ param.getAssetParamName());
									}

									AssetParamDef apd = assetDao
											.getParamIdForAssetAndParamName(
													assetName,
													param.getAssetParamName(), conn);

									String newValueImp = null;
									List<String> ldapnewvalue = new ArrayList<String>();
									if(apd.getParamTypeId() == 1){
										if(apd.getHasArray() == 1)
											newValueImp = param.getTextDataList().toString();
										else
											newValueImp = param.getParamValue().toString();
									}else if(apd.getParamTypeId() == 7){
										if(apd.getHasArray() == 1)
											newValueImp = param.getRTFwithTags().toString();
										else
											newValueImp = param.getParamValue().toString();	
									}else if(apd.getParamTypeId() == 9) {
										List<String> uivalueList = param.getLdapMappingValue().keySet().stream().collect(Collectors.toList());

										if(apd.getHasArray() == 1) {
											ldapnewvalue = uivalueList;
										}else {
											ldapnewvalue = uivalueList;
										}
										
									}
									else{
										newValueImp = param.getParamValue();
									}

									if ((!newValueImp.isEmpty() && newValueImp != null)
											&& apd.isHasImportantValue() == true) {

										flag = true;
										gamePoint.setField("Parameter - "
												+ param.getAssetParamName());
										gamePoint.setAction("Created");

									}
								}
							}

							if (countForParam == paramCount) {
								if (param.getParamValue() != null) {
									if ((param.getParamTypeId() != 5)
											&& param.getParamTypeId() != 6) {
										newParamDataForRevision = newParamDataForRevision
												+ param.getAssetParamName()
												+ ":"
												+ param.getParamValue();
									}
								}else if(param.getParamTypeId() == 9){
									
									if(!param.getLdapMappingValue().isEmpty()) {
										List<String> uivalueList = param.getLdapMappingValue().keySet().stream().collect(Collectors.toList());

										String listString = "";
										for (String s : uivalueList)
										{
											listString += s + "``";
										}
										if (listString.endsWith("``")) {
											listString = listString.substring(0, listString.length() - 2);
										}
										newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
												+listString;
									}else {
										String listString = "";
										newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
												+listString;
									}
								} 
								else {
									if ((param.getParamTypeId() != 5)
											&& param.getParamTypeId() != 6) {
										newParamDataForRevision = newParamDataForRevision
												+ param.getAssetParamName() + ":";
									}
								}
							} else {
								if (param.getParamValue() != null) {
									if ((param.getParamTypeId() != 5)&& param.getParamTypeId() != 6) {
										newParamDataForRevision = newParamDataForRevision
												+ param.getAssetParamName()
												+ ":"
												+ param.getParamValue()
												+ Constants.APPEND_STRING;
									}
								} else if(param.getParamTypeId() == 9){
									if(!param.getLdapMappingValue().isEmpty()) {
										List<String> uivalueList = param.getLdapMappingValue().keySet().stream().collect(Collectors.toList());

										String listString = "";
										for (String s : uivalueList)
										{
											listString += s + "``";
										}
										if (listString.endsWith("``")) {
											listString = listString.substring(0, listString.length() - 2);
										}
										newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
												+listString + Constants.APPEND_STRING;
									}else {
										newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
												+ Constants.APPEND_STRING;
									}
								}else {
									if ((param.getParamTypeId() != 5)
											&& param.getParamTypeId() != 6) {
										newParamDataForRevision = newParamDataForRevision
												+ param.getAssetParamName()
												+ ":"
												+ Constants.APPEND_STRING;
									}
								}
							}

							if ((param.getParamTypeId() != 5)
									&& param.getParamTypeId() != 6) {
								if (log.isTraceEnabled()) {
									log.trace("updateAssetInstancePropertiesRestHelper || called helper method : updateParameterForAssetInst() : to update parameter");
								}

								aivManager.updateParameterForAssetInst(param, null, userId,
										conn);
							}

						//}

						// gamification point
						//if(param.getListTypeParamTypeId() != 4){
							if (flag == true && !userName.equalsIgnoreCase("admin")
									&& activeFlag == 1) {
								gamePoint.setPoints("1");
								gamePoint.setActivityTimestamp(new Timestamp(Calendar
										.getInstance().getTimeInMillis()).toString());

								gamePoint.setUserId(userId);
								gamePoint.setAssetId(String.valueOf(aiv.getAssetId()));
								gamePoint.setAssetInstanceVersionId(String
										.valueOf(aivId));
								if (aiv.getVersionable() == true) {
									gamePoint.setInstanceDetails(assetName
											+ "~" + assetInstName + "~"
											+ versionName);
								} else {
									gamePoint.setInstanceDetails(assetName
											+ "~" + assetInstName + "~N/A");
								}

								if (log.isTraceEnabled()) {
									log.trace("updateAssetInstancePropertiesRestHelper || dao method called : addGamificationPoint() : "
											+ gamePoint.toString());
								}
								gamificationDao.addGamificationPoint(gamePoint, conn);

							}
						//}
						countForParam++;

					}// for loop
					/*if(!ldapParamNamesList.isEmpty()){
						String ldapParamNames = StringUtils.join(ldapParamNamesList, ',');

						responseMsg = " and skipped "+ ldapParamNames + " parameter(s) since it is of type LDAP userlist.";
					}*/
					// updateAivUpdatedOn

					aiv1.setVersionName(aiv.getVersionName());
					aiv1.setUpdatedOn(new Timestamp(Calendar.getInstance()
							.getTimeInMillis()));

					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstancePropertiesRestHelper || called dao method : updateAivUpdatedOn() by AssetInstanceVersionId: "
								+ aivId + "and" + aiv1.toString());
					}
					assetInstanceVersionDao.updateAivUpdatedOn(aiv1, aivId, conn);
					if(revHistFlag == true){
						// addRevisionData

						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstancePropertiesRestHelper || called helper method : addRevisionData() : to add revision data");
						}

						aivManager.addRevisionData("P", aivId, aiv.getVersionName(), null, null,
								newParamDataForRevision, null, userName, userId,null, conn);
					}
					jsonStr.add(newParamDataForRevision);

					// mail template
					if(revHistFlag == true){
						try {

							List<String> emailIds = subscriptionDao
									.getAllSubscriptionsByAssetInstanceId(
											aiv.getAssetInstanceId(), conn);
							MailTemplateDao mailDao = new MailTemplateDao();
							MailTemplateDao mailTemplateDao = new MailTemplateDao();
							MailConfig mailConfig = mailDao.getMailConfig(conn);
							String mailTemp = null;

							if (aiv.getVersionable() == true) {

								MailTemplate mtVo = mailTemplateDao
										.retMailTemplateByTextName(conn,
												"updatePropertiesForVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assetInstName%",
										instName).replaceAll(
												"%versionName%", aiv.getVersionName());

							} else {

								MailTemplate mtVo = mailTemplateDao
										.retMailTemplateByTextName(conn,
												"updatePropertiesForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assetInstName%",
										instName);
							}

							if (emailIds != null) {
								for (String emailId : emailIds) {
									if (aiv.getVersionable() == true) {

										SendEmail
										.sendTextMail(
												mailConfig,
												emailId,
												MessageUtil
												.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
												MessageUtil
												.getMessage(Constants.EMAIL_HDR)
												+ mailTemp
												+ "\n"
												+ MessageUtil
												.getMessage(Constants.EMAIL_NOTE));
									} else {

										SendEmail
										.sendTextMail(
												mailConfig,
												emailId,
												MessageUtil
												.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
												MessageUtil
												.getMessage(Constants.EMAIL_HDR)
												+ mailTemp
												+ "\n"
												+ MessageUtil
												.getMessage(Constants.EMAIL_NOTE));

									}
								}

							}
						} catch (Exception e) {

						}
					}


					// addRecentActivity
					if(revHistFlag == true){
						RecentActivity recentActivity = new RecentActivity();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar
								.getInstance().getTimeInMillis()));
						recentActivity.setAssetId(String.valueOf(aiv.getAssetId()));
						recentActivity.setAssetInstVersionId(String.valueOf(aivId));
						recentActivity.setUser_id(userId);

						if (aiv.getVersionable() == true) {
							recentActivity.setDescription(user.getFullName() + ";" + action + ";"
									+ assetName + ";" + assetInstName + ";"
									+ "version" + aiv.getVersionName());

							if (log.isTraceEnabled()) {
								log.trace("updateAssetInstancePropertiesRestHelper || dao method called : addRecentActivity() : "
										+ recentActivity.toString());
							}

							recentActivityDao.addRecentActivity(recentActivity, conn);
						} else {
							recentActivity.setDescription(user.getFullName() + ";" + action + ";"
									+ assetName + ";" + assetInstName);

							if (log.isTraceEnabled()) {
								log.trace("updateAssetInstancePropertiesRestHelper || dao method called : addRecentActivity() : "
										+ recentActivity.toString());
							}

							recentActivityDao.addRecentActivity(recentActivity, conn);
						}
					}
					//}
					/*if(unlockFlag){
						AssetInstanceVersion aiv2 = new AssetInstanceVersion();
						aiv2.setAssetInstVersionId(aiv.getAssetInstVersionId());
						aiv2.setLockedBy(null);
						aiv2.setLockTime(null);
						assetInstanceVersionDao.updateAssetInstanceVersion(aiv2, conn);//unlock

						retMsg = Constants.ASSET_INSTANCE_PROPERTIES_UPDATED_AND_UNLOCKED;
						retStat = Status.OK;
						retScsFlr = Constants.SUCCESS;
						retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}*/

					retMsg = Constants.ASSET_INSTANCE_PROPERTIES_UPDATED/*+"`~~`"+responseMsg*/;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
					log.info(" updateAssetInstancePropertiesRestHelper ||"
							+ ListOfAssetInstanceProperties
							+ " Updated asset instance properties details successfully");

				}else{

					List<AssetParamDef> apd1 = assetDao.getParamsDetailByAssetName(assetName,conn);


					//mandatory check 

					ArrayList<String> frontList = new ArrayList<String>();
					for(AssetInstanceVersion st1 : ListOfAssetInstanceProperties){
						if(st1.isMandatory()){
							frontList.add(st1.getAssetParamName());
						}
					}

					for(AssetParamDef st : apd1){
						if(st.getParamTypeId()!= 5 && st.getParamTypeId()!= 6 ){

							if(st.isHasMandatoryValue()){

								/*boolean paramAccessFlag = true;
								if(!userName.equalsIgnoreCase("admin")){
							         AssetParamDef paramaccess = assetDao.getAssetParamAccess(userName,st.getAssetParamName(),assetName,null);
							         if(paramaccess == null || paramaccess.getAssetParamId() == null){
							          paramAccessFlag = false;
							         }
							        }*/
								boolean paramAccessFlag = false;
								if(!userName.equalsIgnoreCase("admin")){
									List<GroupDetails> gd = assetDao.getAssetCategoryEditAccessForPropertiesAivPage(userName,st.getAssetCategoryId(), conn);
									for(GroupDetails gd1 : gd){
										if(gd1.getEditAccess() == 1L){
											paramAccessFlag = true;	
											break;
										}
									}
								}else{
									paramAccessFlag = true;   
								}
								if(paramAccessFlag){

									if(st.isHasStaticValue()){

										AssetParamDef ap = assetDao.getParamIdForAssetAndParamName(
												assetName, st.getAssetParamName(), conn);

										if(ap.getParamTypeId() == 3){
											if(ap.getFileName()== null ||ap.getFileName().equalsIgnoreCase("")){
												if(frontList.isEmpty()){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
												Boolean checkstaticflag = false;
												for(String str : frontList ){
													if(str.equalsIgnoreCase(ap.getAssetParamName())){
														checkstaticflag = true;
														break;
													}
												}
												if(!checkstaticflag){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();

												}

											}

										}else{
											//if(ap.getListTypeParamTypeId() != 4){
												if(ap.getStaticValue() == null || ap.getStaticValue().equalsIgnoreCase("")){

													if(frontList.isEmpty()){
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																		.build();
													}
													Boolean checkstaticflag = false;
													for(String str : frontList ){
														if(str.equalsIgnoreCase(ap.getAssetParamName())){
															checkstaticflag = true;
															break;
														}
													}
													if(!checkstaticflag){
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																		.build();

													}
												}
											//}
										}
									}// end of static loop
									else{
										ParameterValues pv = assetDao.getParameterForAssetInstParamAndVersionId(
												st.getAssetParamName(), aivId, conn);
										if(st.getParamTypeId() == 3){
											if(pv == null||pv.getFileName() == null || pv.getFileName().equalsIgnoreCase("")){
												if(frontList.isEmpty()){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
												Boolean checkingFlag = false;
												for(String str : frontList ){
													if(str.equalsIgnoreCase(st.getAssetParamName())){
														checkingFlag = true;
														break;
													}
												}
												if(!checkingFlag){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
											}
										}else if(st.getParamTypeId() == 1 && st.getHasArray()== 1){
											if(pv == null ||pv.getTextDataList() == null|| pv.getTextDataList().isEmpty()){
												if(frontList.isEmpty()){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
												Boolean checkingFlag = false;
												for(String str : frontList ){
													if(str.equalsIgnoreCase(st.getAssetParamName())){
														checkingFlag = true;
														break;
													}
												}
												if(!checkingFlag){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
											}
										}else if(st.getParamTypeId() == 7 && st.getHasArray()== 1){
											if(pv == null ||pv.getRTFwithTags() == null|| pv.getRTFwithTags().isEmpty()){
												if(frontList.isEmpty()){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
												Boolean checkingFlag = false;
												for(String str : frontList ){
													if(str.equalsIgnoreCase(st.getAssetParamName())){
														checkingFlag = true;
														break;
													}
												}
												if(!checkingFlag){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																	.build();
												}
											}
										}else{
											//if(st.getListTypeParamTypeId() != 4){
												if(pv == null ||pv.getValue() == null|| pv.getValue().equalsIgnoreCase("")){
													if(frontList.isEmpty()){
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																		.build();
													}
													Boolean checkingFlag = false;
													for(String str : frontList ){
														if(str.equalsIgnoreCase(st.getAssetParamName())){
															checkingFlag = true;
															break;
														}
													}
													if(!checkingFlag){
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
																		.build();
													}
												}
											//}
										}
									}// end of non-static loop
								}
							}// mandatory
						}//not derived parameters

					}
					retMsg = Constants.ASSET_INSTANCE_PROPERTIES_UPDATED/*+"`~~`"+responseMsg*/;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

				}
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("updateAssetInstancePropertiesRestHelper || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}


		} catch (RepoproException e) {
			log.error("updateAssetInstancePropertiesRestHelper ||  "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("updateAssetInstancePropertiesRestHelper || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
		} finally {
			if(conn1 != null){
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstancePropertiesRestHelper || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}

			// modified by gomathi 
			if(formParams != null && dataMultiPart != null){
				String filepath = System.getProperty("user.home")+"/RepoProImagesUnzip";
				File directory = new File(filepath);
				//make sure directory exists 
				if(directory.exists()){
					try{
						//To delete artifact inside src folder from user home
						DeleteSrcFolderContent deletesrcFolder = new DeleteSrcFolderContent();
						deletesrcFolder.delete(directory);

					}catch(IOException e){
						e.printStackTrace();
						System.exit(0);
					}
				}

			}
		}
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstancePropertiesRestHelper || End");
		}

		if(responseFlag == true){
			return Response.status(retStat)
					.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		}else{
			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(jsonStr))).build();
		}

	}
	
	/*** Wrapper function ***/
	@GET
	@Encoded
	@Path("/getChildAssetInstances")
	public Response getChildNamesForAssetInstanceMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName, 
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@HeaderParam("token") String token) throws RepoproException {
		
		if(assetName == null|| assetInstName == null || assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstName.isEmpty() || assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getChildNamesForAssetInstanceMain || Begin");
	
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersion aiv = new AssetInstanceVersion();
			AssetDao assetDao = new AssetDao();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			if (assetDef.getAssetId() == null) {

				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getChildNamesForAssetInstanceMain || Begin");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();

			}
          if(userName.equalsIgnoreCase("roleAnonymous")){
			
			if(assetDef.isGuestflag() != true){

				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("getChildNamesForAssetInstanceMain || Begin");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
				
			}
          }
          if (log.isTraceEnabled()) {
				log.trace("getChildNamesForAssetInstanceMain || dao method called : getAssetinstDetails ");
			}
		   aiv =  assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);
          
          if(!userName.equalsIgnoreCase("roleAnonymous")){
			
		   if (aiv == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getChildNamesForAssetInstanceMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			Boolean viewFlag = false;
			
			if (log.isTraceEnabled()) {
				log.trace("getChildNamesForAssetInstanceMain || dao method called : retAivAccessRights ");
			}
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
					viewFlag = true;
					break;
				}
			}

			if (viewFlag) {
				response = aivManager.getChildNamesForAssetInstance(aiv.getAssetId(), aiv.getAssetInstVersionId());
			
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	AssetInstanceVersion assetInstanceVersion = new AssetInstanceVersion();
		        	assetInstanceVersion = (AssetInstanceVersion) data.get(i);
		        	
		        	j1.put("assetInstanceName", assetInstanceVersion.getAssetInstName());
		        	j1.put("assetName", assetInstanceVersion.getAssetName());
		        	if(assetInstanceVersion.getVersionable() == true){
		        		j1.put("assetInstanceVersionName",assetInstanceVersion.getVersionName());
		        	}else{
		        		j1.put("assetInstanceVersionName","N/A");
		        	}
		        	j1.put("assetInstanceVersionId", assetInstanceVersion.getDestAssetInstVersionId());
		        	j1.put("relationshipName",assetInstanceVersion.getRelName());
		        	j1.put("relationshipType",assetInstanceVersion.getRelType());
		        	finaldata.add(j1);
		        }
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getChildNamesForAssetInstanceMain || End");
		        return Response.status(retStat).entity(json.toString())
		          .build();

			} else {

				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("getChildNamesForAssetInstanceMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			} 
          }
          else{
        	  AssetInstanceDao assetInstDao = new AssetInstanceDao();
  			List<AssetInstance> assetInsatnceList = new ArrayList<AssetInstance>();
				
  			if(assetDef.isGuestflag() == true){
				assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(aiv.getAssetInstanceId() ,null);
				for(AssetInstance ai : assetInsatnceList){
					if(ai.isPublicAccess() == true){
						response = aivManager.getChildNamesForAssetInstance(aiv.getAssetId(), aiv.getAssetInstVersionId());
						
						MyModel res = (MyModel) response.getEntity();
				        List<Object> data = res.getResult();
				        JSONObject j1 = null;
				        JSONObject json = new JSONObject();
				        List<Object> finaldata = new ArrayList<Object>();
				        for (int i = 0; i < data.size(); i++) {
				        	j1 = new JSONObject();
				        	AssetInstanceVersion assetInstanceVersion = new AssetInstanceVersion();
				        	assetInstanceVersion = (AssetInstanceVersion) data.get(i);
				        	
				        	j1.put("assetInstanceName", assetInstanceVersion.getAssetInstName());
				        	j1.put("assetName", assetInstanceVersion.getAssetName());
				        	if(assetInstanceVersion.getVersionable() == true){
				        		j1.put("assetInstanceVersionName",assetInstanceVersion.getVersionName());
				        	}else{
				        		j1.put("assetInstanceVersionName","N/A");
				        	}
				        	j1.put("assetInstanceVersionId", assetInstanceVersion.getDestAssetInstVersionId());
				        	j1.put("relationshipName",assetInstanceVersion.getRelName());
				        	j1.put("relationshipType",assetInstanceVersion.getRelType());
				        	
				        	finaldata.add(j1);
				        }
				        json.put("result", finaldata);
				        json.put("message", res.getMessage());
				        json.put("status", res.getStatus());
				        json.put("statusCode", res.getStatusCode());

				        log.trace("getChildNamesForAssetInstanceMain || End");
				        return Response.status(retStat).entity(json.toString())
				          .build();
						
					}else{
						retStat = Status.FORBIDDEN;
						retMsg = Constants.USER_NOT_AUTHORIZED;
						retScsFlr = Constants.NOT_AUTHORIZED;
						retStatScsFlr = Constants.FORBIDDEN;
						log.trace("getChildNamesForAssetInstanceMain || End");
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						
					}
				}
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("getChildNamesForAssetInstanceMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				
			}
			
          }
		
		} catch (RepoproException e) {
			log.error("getChildNamesForAssetInstanceMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getChildNamesForAssetInstanceMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 
		log.trace("getChildNamesForAssetInstanceMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@POST
	@Encoded
	@Path("/updateRelationships")
	public Response saveDependencyMain(
			@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String versionName,
			@QueryParam("addRelationshipData") String addRelationshipData,
			@QueryParam("removeRelationshipData") String removeRelationshipData,
			@HeaderParam("token") String token){
		
		if(assetName == null|| assetInstName == null || versionName == null ){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			versionName = URLDecoder.decode(versionName, "UTF-8");versionName = versionName.trim();
			addRelationshipData = URLDecoder.decode(addRelationshipData, "UTF-8");addRelationshipData = addRelationshipData.trim();
			removeRelationshipData = URLDecoder.decode(removeRelationshipData, "UTF-8");removeRelationshipData = removeRelationshipData.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstName.isEmpty() || versionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		if((addRelationshipData == null && removeRelationshipData == null)){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
							.build();
		}
		if((addRelationshipData != null && removeRelationshipData != null)){
			if(addRelationshipData.isEmpty() && removeRelationshipData.isEmpty()){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
								.build();
			}
		}
		
		log.trace("saveDependencyMain || Begin");
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		versionName = versionName.trim();
		try {
			
			if (log.isTraceEnabled()) {
				log.trace("saveDependencyMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			Response response = this.saveDependencyHelper(assetName, assetInstName, versionName, addRelationshipData, removeRelationshipData, token,conn);
			MyModelRest modelRest = null;
			int statusCode = 0;
			String statusMessage = "";
			if(response.getEntity() instanceof MyModelRest){
				modelRest = (MyModelRest) response.getEntity();
			}
			if(modelRest != null){
				statusCode = response.getStatus();
				statusMessage = modelRest.getMessage();
			}
			
			if((statusCode == 200) && (Constants.ASSET_INSTANCE_DATA_UPDATED.equalsIgnoreCase(statusMessage)||Constants.ASSET_INSTANCE_VERSION_UPDATED_AND_UNLOCKED.equalsIgnoreCase(statusMessage))){
				conn.commit();
			}
			return response;
			
			
		} catch (RepoproException e) {
			log.error("saveDependencyMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("saveDependencyMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("saveDependencyMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("saveDependencyMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();		
		}
	
	
	public Response saveDependencyHelper(
			String assetName,String assetInstName,String versionName,String addRelationshipData,String removeRelationshipData,String token, 
			Connection conn)throws RepoproException{
		
		log.trace("saveDependencyHelper || Begin");
		
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<Long> addDestassetinstversionIds = new ArrayList<Long>();
		List<Long> removeDestassetinstversionIds = new ArrayList<Long>();
		List<Long> addRelationshipIds = new ArrayList<Long>();
		List<Long> removeRelationshipIds = new ArrayList<Long>();
		List<String> addAssetNamesList = new ArrayList<String>();
		List<String> addAssetInstNamesList = new ArrayList<String>();
		List<String> addVersionNamesList = new ArrayList<String>();
		List<String> addRelationshipNameList = new ArrayList<String>();
		List<String> removeAssetNamesList = new ArrayList<String>();
		List<String> removeAssetInstNamesList = new ArrayList<String>();
		List<String> removeVersionNamesList = new ArrayList<String>();
		List<String> removeRelationshipNameList = new ArrayList<String>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		AssetInstanceVersion aiv = new AssetInstanceVersion();
		AssetInstanceVersion assetInstanceVersion = new AssetInstanceVersion();
		AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
		AssetInstanceManager aiManager = new AssetInstanceManager();
		boolean editFlag = false;
		boolean adminFlag = false;
		boolean flag1 = false;
		boolean unlockFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		versionName = versionName.trim();
		if(removeRelationshipData == null){
			removeRelationshipData = "";
		}else {
			if(addRelationshipData == null){
				addRelationshipData = "";
			}
		}
		Connection conn1 = null;
		
       try{
		if(!addRelationshipData.equalsIgnoreCase("")){
			String addString[] = addRelationshipData.split("~");
			List<String> relationshipList = new ArrayList<String>(Arrays.asList(addRelationshipData.split("~")));
			Set<String> duplicate = new HashSet<String>();
			duplicate.addAll(relationshipList);
			if(duplicate.size()<relationshipList.size()){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.DUPLICATE_ASSET_INSTANCE_RELATIONSHIP_DATA)))
								.build();
			}
			for(String y : addString){
				String temp[] = y.split("\\|");
				addAssetNamesList.add(temp[0].trim());
				addAssetInstNamesList.add(temp[1].trim());
				addVersionNamesList.add(temp[2].trim());
				addRelationshipNameList.add(temp[3].trim());
			}
		}
		if(!removeRelationshipData.equalsIgnoreCase("")){
			String removeString[] = removeRelationshipData.split("~");
			List<String> relationshipList = new ArrayList<String>(Arrays.asList(removeRelationshipData.split("~")));
			Set<String> duplicate = new HashSet<String>();
			duplicate.addAll(relationshipList);
			if(duplicate.size()<relationshipList.size()){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.DUPLICATE_ASSET_INSTANCE_RELATIONSHIP_DATA)))
								.build();
			}
			for(String y : removeString){
				String[] temp = y.split("\\|");
				removeAssetNamesList.add(temp[0].trim());
				removeAssetInstNamesList.add(temp[1].trim());
				removeVersionNamesList.add(temp[2].trim());
				removeRelationshipNameList.add(temp[3].trim());
			}
		}
       }catch (Exception e ){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
							.build();
       }
       
       if(!addRelationshipData.equalsIgnoreCase("")){
    	   if(addRelationshipData.endsWith("|") || addRelationshipData.endsWith("~")){
    		   return Response
    				   .status(Status.BAD_REQUEST)
    				   .entity(new MyModelRest(Constants.STATUS_FAILURE,
    						   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
    						   .build();
    	   }
       }
       if(!removeRelationshipData.equalsIgnoreCase("")){
    	   if(removeRelationshipData.endsWith("|") || removeRelationshipData.endsWith("~")){
    		   return Response
    				   .status(Status.BAD_REQUEST)
    				   .entity(new MyModelRest(Constants.STATUS_FAILURE,
    						   Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
    						   .build();
    	   }
       }
		
		
       try {
    	   if(conn == null){
    		   conn1 = DBConnection.getInstance().getConnection();
    		   conn = conn1;
    	   }
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

    	   /*if(token != null){
    		   User userdata = commonUtils.userDetails(token);
    		   User username = userDao.getUserByUserId( userdata.getUserId(), conn);
    		   userName = username.getUserName();
    	   }else{
    		   userName = "guest";
    	   }*/
    	   if (log.isTraceEnabled()) {
    		   log.trace("saveDependencyHelper || " + Constants.LOG_CONNECTION_OPEN);
    	   }

    	   if(addRelationshipData.equalsIgnoreCase("") && removeRelationshipData.equalsIgnoreCase("")){
    		   return Response
    				   .status(Status.BAD_REQUEST)
    				   .entity(new MyModelRest(Constants.STATUS_FAILURE,
    						   Constants.FAILURE,
    						   MessageUtil
    						   .getMessage(Constants.RELATIONSHIP_DATA_NOT_PROVIDED))).build();
    	   }
    	   assetInstanceVersion.setAddAssetNames(addAssetNamesList);
    	   assetInstanceVersion.setAddAssetInstNames(addAssetInstNamesList);
    	   assetInstanceVersion.setAddVersionNames(addVersionNamesList);
    	   assetInstanceVersion.setAddRelationshipNames(addRelationshipNameList);
    	   assetInstanceVersion.setRemoveAssetNames(removeAssetNamesList);
    	   assetInstanceVersion.setRemovedAssetInstNames(removeAssetInstNamesList);
    	   assetInstanceVersion.setRemovedVersionNames(removeVersionNamesList);
    	   assetInstanceVersion.setRemoveRelationshipNames(removeRelationshipNameList);
    	   assetInstanceVersion.setAssetName(assetName);
    	   assetInstanceVersion.setAssetInstName(assetInstName);
    	   assetInstanceVersion.setVersionName(versionName);

    	   if(!userName.equalsIgnoreCase("guest")){
    		   User user = userDao.getUserIdByUserName(userName, conn);
    		   if(user.getUserId() == null){
    			   retStat = Status.UNAUTHORIZED;
    			   retMsg = Constants.USER_NOT_AUTHENTICATED;
    			   retScsFlr = Constants.NOT_AUTHENTICATED;
    			   retStatScsFlr = Constants.UNAUTHORIZED;
    			   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
    		   }
    	   }

    	   if(userName.equalsIgnoreCase("guest"))
    	   {
    		   userName= "roleAnonymous";
    		   retStat = Status.FORBIDDEN;
    		   retMsg = Constants.USER_NOT_AUTHORIZED;
    		   retScsFlr = Constants.NOT_AUTHORIZED;
    		   retStatScsFlr = Constants.FORBIDDEN;
    		   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
    	   }

    	   aiv = assetInstanceVersionDao.getAssetinstDetails(assetInstanceVersion.getAssetName(),assetInstanceVersion.getAssetInstName(),assetInstanceVersion.getVersionName(),conn);
    	   if (aiv == null) {
    		   retStat = Status.NOT_FOUND;
    		   retScsFlr = Constants.FAILURE;
    		   retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
    		   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    		   log.trace("saveDependencyHelper || End");
    		   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    	   }

    	   List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();

    	   adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
    	   if(!adminFlag){
    		   if (log.isTraceEnabled()) {
    			   log.trace("saveDependencyHelper || dao method called : retAivAccessRights ");
    		   }
    		   groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, conn);

    		   for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
    			   if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
    				   editFlag = true;
    				   break;
    			   }
    		   }
    	   }else{
    		   editFlag = true;
    	   }
    	   AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(aiv.getAssetInstVersionId(),conn);

    	   if(editFlag){
    		   if(aiv1.getLockedBy() == null){
    			   flag1 = true;

    		   }else if(aiv1.getLockedBy().equalsIgnoreCase(userName)){
    			   flag1 = true;
    			   unlockFlag = true;
    		   }
    		   else{
    			   retStat = Status.FORBIDDEN;
    			   retMsg = Constants.ASSET_INSTANCE_VERSION_LOCKED;
    			   retScsFlr = Constants.NOT_AUTHORIZED;
    			   retStatScsFlr = Constants.FORBIDDEN;
    			   log.trace("saveDependencyHelper || End");
    			   return Response
    					   .status(retStat)
    					   .entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    		   }
    	   }else{
    		   retStat = Status.FORBIDDEN;
    		   retMsg = Constants.USER_NOT_AUTHORIZED;
    		   retScsFlr = Constants.NOT_AUTHORIZED;
    		   retStatScsFlr = Constants.FORBIDDEN;
    		   log.trace("saveDependencyHelper || End");
    		   return Response
    				   .status(retStat)
    				   .entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    	   }

    	   if(editFlag && flag1){
    		   if(!addRelationshipData.equalsIgnoreCase("")){
    			   int j = 0;
    			   int k = 0;
    			   if(assetInstanceVersion.getAddAssetInstNames().size()>0 && assetInstanceVersion.getAddVersionNames().size()>0){
    				   for(String addAssetInstName : assetInstanceVersion.getAddAssetInstNames())
    				   {
    					   String addVersionName = assetInstanceVersion.getAddVersionNames().get(j);
    					   if(!addAssetInstName.equalsIgnoreCase("") && !addVersionName.equalsIgnoreCase("")){
    						   String addAssetNames = assetInstanceVersion.getAddAssetNames().get(k);
    						   if(!addAssetNames.equalsIgnoreCase("")){
    							   AssetInstanceVersion addAiv = new AssetInstanceVersion();
    							   addAiv = assetInstanceVersionDao.getAssetinstDetails(addAssetNames,addAssetInstName,addVersionName,conn);
    							   if (addAiv == null) {
    								   retStat = Status.NOT_FOUND;
    								   retScsFlr = Constants.FAILURE;
    								   retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
    								   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    								   log.trace("saveDependencyHelper || End");
    								   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    							   }
    							   addDestassetinstversionIds.add(addAiv.getAssetInstVersionId());
    						   }k++;
    					   }j++;
    				   }
    			   }
    			   if (addDestassetinstversionIds.isEmpty()) {
    				   retStat = Status.NOT_FOUND;
    				   retScsFlr = Constants.FAILURE;
    				   retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
    				   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    				   log.trace("saveDependencyHelper || End");
    				   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    			   }
    			   assetInstanceVersion.setAddDestAssetInstVersionIds(addDestassetinstversionIds);
    		   }
    		   if(!removeRelationshipData.equalsIgnoreCase("")){
    			   int l = 0;
    			   int m = 0;
    			   if(assetInstanceVersion.getRemovedAssetInstNames().size()>0 && assetInstanceVersion.getRemovedVersionNames().size()>0){
    				   for(String removeAssetInstName : assetInstanceVersion.getRemovedAssetInstNames())
    				   {
    					   String removeVersionName = assetInstanceVersion.getRemovedVersionNames().get(l);
    					   if(!removeAssetInstName.equalsIgnoreCase("") && !removeVersionName.equalsIgnoreCase("")){
    						   String removeAssetNames = assetInstanceVersion.getRemoveAssetNames().get(m);
    						   if(!removeAssetNames.equalsIgnoreCase("")){
    							   AssetInstanceVersion removeAiv = new AssetInstanceVersion();
    							   removeAiv = assetInstanceVersionDao.getAssetinstDetails(removeAssetNames,removeAssetInstName,removeVersionName,conn);
    							   if (removeAiv == null) {
    								   retStat = Status.NOT_FOUND;
    								   retScsFlr = Constants.FAILURE;
    								   retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
    								   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    								   log.trace("saveDependencyHelper || End");
    								   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    							   }
    							   removeDestassetinstversionIds.add(removeAiv.getAssetInstVersionId());
    						   }m++;
    					   }l++;
    				   }
    			   }
    			   if (removeDestassetinstversionIds.isEmpty()) {
    				   retStat = Status.NOT_FOUND;
    				   retScsFlr = Constants.FAILURE;
    				   retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
    				   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    				   log.trace("saveDependencyHelper || End");
    				   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    			   }
    			   assetInstanceVersion.setRemovedDestAssetInstVersionIds(removeDestassetinstversionIds);
    		   }

    		   RelationshipDao relationshipDao = new RelationshipDao();
    		   AssetRelationshipDef assetRelationshipDef = new AssetRelationshipDef();

    		   if(!addRelationshipData.equalsIgnoreCase("")){
    			   for(String relationshipNames : assetInstanceVersion.getAddRelationshipNames()){
    				   assetRelationshipDef = relationshipDao.retAssetRelDefByrelDescription(relationshipNames,conn);
    				   if (assetRelationshipDef.getAssetRelId() == null) {
    					   retStat = Status.NOT_FOUND;
    					   retScsFlr = Constants.FAILURE;
    					   retMsg = Constants.RELATIONSHIP_NOT_FOUND;
    					   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    					   log.trace("saveDependencyHelper || End");
    					   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    				   }
    				   addRelationshipIds.add(assetRelationshipDef.getAssetRelId());
    			   }
    			   if (addRelationshipIds.isEmpty()) {
    				   retStat = Status.NOT_FOUND;
    				   retScsFlr = Constants.FAILURE;
    				   retMsg = Constants.RELATIONSHIP_NOT_FOUND;
    				   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    				   log.trace("saveDependencyHelper || End");
    				   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    			   }
    			   assetInstanceVersion.setAddRelationshipIds(addRelationshipIds);
    		   }

    		   if(!removeRelationshipData.equalsIgnoreCase("")){
    			   for(String relationshipNames : assetInstanceVersion.getRemoveRelationshipNames()){
    				   assetRelationshipDef = relationshipDao.retAssetRelDefByrelDescription(relationshipNames,conn);
    				   if (assetRelationshipDef.getAssetRelId() == null) {
    					   retStat = Status.NOT_FOUND;
    					   retScsFlr = Constants.FAILURE;
    					   retMsg = Constants.RELATIONSHIP_NOT_FOUND;
    					   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    					   log.trace("saveDependencyHelper || End");
    					   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    				   }
    				   removeRelationshipIds.add(assetRelationshipDef.getAssetRelId());
    			   }

    			   if (removeRelationshipIds.isEmpty()) {
    				   retStat = Status.NOT_FOUND;
    				   retScsFlr = Constants.FAILURE;
    				   retMsg = Constants.RELATIONSHIP_NOT_FOUND;
    				   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    				   log.trace("saveDependencyHelper || End");
    				   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    			   }
    			   assetInstanceVersion.setRemovedRelationshipIds(removeRelationshipIds);
    		   }

    		   assetInstanceVersion.setSrcAssetInstanceVersionId(aiv.getAssetInstVersionId().toString());
    		   assetInstanceVersion.setAssetInstanceId(aiv.getAssetInstanceId());
    		   AssetDao assetDao = new AssetDao();
    		   AssetDef ad = new AssetDef();
    		   ad  = assetDao.getAssetsByAssetName(assetInstanceVersion.getAssetName(), conn);
    		   if (ad.getAssetId() == null) {
    			   retStat = Status.NOT_FOUND;
    			   retScsFlr = Constants.FAILURE;
    			   retMsg = Constants.ASSET_DATA_NOT_FOUND;
    			   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    			   log.trace("saveDependencyHelper || End");
    			   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    		   }
    		   assetInstanceVersion.setAssetId(ad.getAssetId());
    		   
    		   //check duplicates in add and remove relationship list provided by user
    		   if(!addRelationshipData.equalsIgnoreCase("") && !removeRelationshipData.equalsIgnoreCase("")){
    			   boolean duplicateflag = false;
    			   String addString[] = addRelationshipData.split("~");
    			   String removeString[] = removeRelationshipData.split("~");
    			   for(String add:addString){
    				   for(String remove:removeString){
    					   if(add.equalsIgnoreCase(remove)){
    						   duplicateflag=true;
							   break;
    					   }
    				   }
    				   if(duplicateflag == true){
						   break;
					   }
    			   }
    			   if(duplicateflag){
    				   retStat = Status.BAD_REQUEST;
    				   retScsFlr = Constants.FAILURE;
    				   retMsg = Constants.DUPLICATE_ASSET_INSTANCE_RELATIONSHIP_DATA;
    				   retStatScsFlr = Constants.STATUS_FAILURE;
    				   log.trace("saveDependencyHelper || End");
    				   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    			   }
    		   }
    		   
    		 //check for existence of removal relationship data provided by user
    		   List<Long> removedrelIds = new ArrayList<Long>();
    		   List<Long> addrelIds = new ArrayList<Long>();
    		   List<AssetInstRelationship> availableAssetInstRel = new ArrayList<AssetInstRelationship>();
    		   if(!removeRelationshipData.equalsIgnoreCase("")){
    			   availableAssetInstRel = relationshipDao.retFwdRelationsForAnAssetInstanceVersionId(aiv.getAssetInstVersionId(),conn);
    			   boolean NewFlag = true;
    			   if(!availableAssetInstRel.isEmpty()){
    				   for(AssetInstRelationship relData:availableAssetInstRel){
    					   if(relData.getRelationShipName().equalsIgnoreCase("composition")||relData.getRelationShipName().equalsIgnoreCase("Aggregation")){
    						   retStat = Status.BAD_REQUEST;
    						   retScsFlr = Constants.FAILURE;
    						   retMsg = "Child asset instances cannot be unassigned";
    						   retStatScsFlr = Constants.STATUS_FAILURE;
    						   return Response
    								   .status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

    					   }
    					   String removeString[] = removeRelationshipData.split("~");
    					   for(String y : removeString){
    						   String[] temp = y.split("\\|");
    						   if(relData.getAssetName().equalsIgnoreCase(temp[0].trim())&&
    								   relData.getAssetInstanceName().equalsIgnoreCase(temp[1].trim())&&
    								   relData.getVersionName().equalsIgnoreCase(temp[2].trim())&&
    								   relData.getDescrption().equals(temp[3].trim())){
    							   removedrelIds.add(relData.getAssetrelationShipId());
    							   if(removedrelIds.size() == removeRelationshipIds.size()){
    								   NewFlag = false;
    								   break;
    							   }
    							   if(NewFlag == false){
    								   break;
    							   }
    						   }
    					   }
    				   }
    			   }else if(availableAssetInstRel.isEmpty()){
    				   NewFlag = true;
    			   }
    			   if(NewFlag){
    				   retStat = Status.NOT_FOUND;
    				   retScsFlr = Constants.FAILURE;
    				   retMsg = Constants.RELATIONSHIP_NOT_FOUND;
    				   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    				   return Response
    						   .status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    			   }
    		   }
    		   
    		   //check for assigning of duplicate relationship data 
    		   if(!addRelationshipData.equalsIgnoreCase("")){
    			   availableAssetInstRel = relationshipDao.retFwdRelationsForAnAssetInstanceVersionId(aiv.getAssetInstVersionId(),conn);
    			   boolean dupFlag = false;
    			   if(!availableAssetInstRel.isEmpty()){
    				   for(AssetInstRelationship relData:availableAssetInstRel){
						   String addString[] = addRelationshipData.split("~");
						   for(String y : addString){
							   String temp[] = y.split("\\|");
							   if(relData.getAssetName().equalsIgnoreCase(temp[0].trim())&&
									   relData.getAssetInstanceName().equalsIgnoreCase(temp[1].trim())&&
									   relData.getVersionName().equalsIgnoreCase(temp[2].trim())&&
									   relData.getDescrption().equals(temp[3].trim())){
									   dupFlag = true;
									   break;
							   }
						   }
						   if(dupFlag == true){
    						   break;
    					   }
    				   }
    			   }else if(availableAssetInstRel.isEmpty()){
    				   dupFlag = false;
    			   }
    			   if(dupFlag == true){
    				   retStat = Status.BAD_REQUEST;
    				   retScsFlr = Constants.FAILURE;
    				   retMsg = Constants.DUPLICATE_ASSET_INSTANCE_RELATIONSHIP_DATA;
    				   retStatScsFlr = Constants.STATUS_FAILURE;
    				   log.trace("saveDependencyHelper || End");
    				   return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    			   }
    		   }
    		   
    		   //validation of add relationship data existence
    		   List<AssetInstRelationship> assetInstRelationshipList = new ArrayList<AssetInstRelationship>();
    		   List<AssetRelationshipDef> assetRelationshipDefList = new ArrayList<AssetRelationshipDef>();
    		   List<AssetDef> assetNamesList = new ArrayList<AssetDef>();
    		   List<AssetDef> finalAssetNamesList = new ArrayList<AssetDef>();
    		   if(!addRelationshipData.equalsIgnoreCase("")){
    			   assetRelationshipDefList = relationshipDao.getAllAssetRelationshipDef(conn);
    			   for (AssetRelationshipDef assetRelDef : assetRelationshipDefList) {
    				   // To get only mathched assets with given asset
    				   if (assetRelDef.getSrcAssetName().equalsIgnoreCase(assetName)) {
    					   if (!assetNamesList.contains(assetRelDef.getDestAssetName())) {
    						   if (assetRelDef.getFwdRelationType().equalsIgnoreCase("composition")
    								   || assetRelDef.getFwdRelationType().equalsIgnoreCase("aggregation")) {
    							   continue;
    						   } else {
    							   AssetDef assetNames = new AssetDef();
    							   assetNames.setAssetName(assetRelDef.getDestAssetName());
    							   assetNames.setAssetId(assetRelDef.getDestAssetId());
    							   assetNamesList.add(assetNames);
    						   }
    					   }
    				   }
    			   }
    			   AssetInstanceDao assetInstaceDao = new AssetInstanceDao();
    			   AssetDef asset = null;
    			   for (AssetDef assetdata : assetNamesList) {
    				   AssetDef assetData = assetInstaceDao.retAssetDetail(assetdata.getAssetName(), conn);
    				   asset = new AssetDef();
    				   asset.setAssetName(assetData.getAssetName());
    				   asset.setAssetId(assetData.getAssetId());
    				   asset.setVersionable(assetData.isVersionable());
    				   finalAssetNamesList.add(asset);
    			   }
    			   boolean NewAddFlag = true;
    			   Set<String> hashSet = new HashSet<>();
    			   List<String> assetset = new ArrayList<>();
    			   hashSet.addAll(addAssetNamesList);
    			   assetset.clear();
    			   assetset.addAll(hashSet);

    			   List<String> assetNames = new ArrayList<String>();
    			   for(AssetDef assetDetails : finalAssetNamesList) {
    				   String assetInfo = assetDetails.getAssetId()+"~~~"+assetDetails.getAssetName();
    				   assetNames.add(assetInfo);
    			   }

    			   Set<String> assetList = new HashSet<>(assetNames);
    			   List<String> dbAssetList = new ArrayList<String>();
    			   dbAssetList.addAll(assetList);
    			
    			   //check for relationship exists with provided asset
    			   int Count = 0;
    			   boolean destinationflag = false;
    			   for(int i=0;i<dbAssetList.size();i++) {
    				   for(int k=0;k<assetset.size();k++) {
    					   String[] splitAsset = dbAssetList.get(i).split("~~~");
    					   if(splitAsset != null) {
    						   if(splitAsset[1].equalsIgnoreCase(assetset.get(k))){
    							   Count++;
    							   if(Count == assetset.size()){
    								   destinationflag = true;
    								   break;
    							   }
    						   }
    					   }
    				   }
    			   }
    			   if(!destinationflag){
    				   retStat = Status.NOT_FOUND;
    				   retScsFlr = Constants.FAILURE;
    				   retMsg = Constants.RELATIONSHIP_NOT_FOUND;
    				   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    				   return Response
    						   .status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    			   }
    			   
    			 
    			   for(int k=0;k<assetset.size();k++) {
    				   AssetDef assetData = assetInstaceDao.retAssetDetail(assetset.get(k), conn);
    				   assetInstRelationshipList = relationshipDao.retAvailableAssetRelationship(ad.getAssetId(),assetData.getAssetId(),
    						   aiv.getAssetInstanceId(), userName, conn);
    				   if(!assetInstRelationshipList.isEmpty()){
    					   for(AssetInstRelationship assetRel:assetInstRelationshipList){
    						   String addString[] = addRelationshipData.split("~");
    						   for(String y : addString){
    							   String temp[] = y.split("\\|");
    							   if(assetRel.getAssetName().equalsIgnoreCase(temp[0].trim())&&
    									   assetRel.getAssetInstanceName().equalsIgnoreCase(temp[1].trim())&&
    									   assetRel.getVersionName().equalsIgnoreCase(temp[2].trim())&&
    									   assetRel.getDescrption().equals(temp[3].trim())){
    								   addrelIds.add(assetRel.getAssetrelationShipId());
    								   break;
    							   }
    						   }
    					   }
    				   }
    			   }
    				
    			   /*Set<Long> hashSetlist = new HashSet<>(addrelIds);
    			   addrelIds.clear();
    			   addrelIds.addAll(hashSetlist);
    			   Set<Long> hashSetlistfinal = new HashSet<>(addRelationshipIds);
    			   List<Long> assetdata = new ArrayList<>();
    			   assetdata.clear();
    			   assetdata.addAll(hashSetlistfinal);*/
    			   if(addrelIds.size() == addRelationshipIds.size()){
    				   NewAddFlag = false;
    			   }
    			   if(NewAddFlag){
    				   retStat = Status.NOT_FOUND;
    				   retScsFlr = Constants.FAILURE;
    				   retMsg = Constants.RELATIONSHIP_NOT_FOUND;
    				   retStatScsFlr = Constants.GET_STATUS_FAILURE;
    				   return Response
    						   .status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    			   }
    		   }
    		
    		   if(addRelationshipData.equalsIgnoreCase("")){
    			   assetInstanceVersion.setAddDestAssetInstVersionIds(addDestassetinstversionIds);
    		   }
    		   if(removeRelationshipData.equalsIgnoreCase("")){
    			   assetInstanceVersion.setRemovedDestAssetInstVersionIds(removeDestassetinstversionIds);
    		   }
    		   response = aiManager.saveDependencyHelper(assetInstanceVersion,userName,true,conn);
    		   /*if(unlockFlag){
    			   AssetInstanceVersion aivv = new AssetInstanceVersion();
    			   aivv.setAssetInstVersionId(aiv.getAssetInstVersionId());
    			   aivv.setLockedBy(null);
    			   aivv.setLockTime(null);
    			   assetInstanceVersionDao.updateAssetInstanceVersion(aivv, conn);//unlock

    			   log.trace("saveDependencyHelper || End");
    			   retMsg = Constants.ASSET_INSTANCE_VERSION_UPDATED_AND_UNLOCKED;
    			   retStat = Status.OK;
    			   retScsFlr = Constants.SUCCESS;
    			   retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
    			   return Response
    					   .status(retStat)
    					   .entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    		   }*/
    		   retStat = Status.OK;
    		   retMsg = Constants.ASSET_INSTANCE_DATA_UPDATED;
    		   retScsFlr = Constants.SUCCESS;
    		   retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;

    	   } else {
    		   retStat = Status.FORBIDDEN;
    		   retMsg = Constants.USER_NOT_AUTHORIZED;
    		   retScsFlr = Constants.NOT_AUTHORIZED;
    		   retStatScsFlr = Constants.FORBIDDEN;
    		   log.trace("saveDependencyHelper || End");
    		   return Response
    				   .status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
    	   }

       } catch (RepoproException e) {
			log.error("saveDependencyHelper || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("saveDependencyHelper || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			throw new RepoproException(e.getMessage());
		} finally {
			if(conn1 != null){
			if (log.isTraceEnabled()) {
				log.trace("saveDependencyHelper || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		}
		log.trace("saveDependencyHelper || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();		
		}
	
	
	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/getFavouriteStatus")
	public Response getMyFavouriteMain(@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetName") String assetName,
			@HeaderParam("token") String token) {
		
		if(assetInstName == null || assetName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetInstName.isEmpty() || assetName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getMyFavouriteMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		boolean viewFlag = false;
		boolean adminFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (log.isTraceEnabled()) {
				log.trace("getMyFavouriteMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			FavouritesManager favManager = new FavouritesManager();
			User user = new User();
			if(!userName.equalsIgnoreCase("guest")){
				 user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			} else {
				AssetDao assetDao = new AssetDao();
				AssetInstanceDao assetInstDao = new AssetInstanceDao();
				AssetDef ad = new AssetDef();
				ad = assetDao.getAssetsByAssetName(assetName, conn);
				if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("getMyFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
				
				Long assetInstId = assetInstDao.getAssetInstIdByName(assetInstName, ad.getAssetId(), conn);
				if (assetInstId == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("getMyFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
				/*User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("getMyFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}*/
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, null);

				List<AssetInstanceVersion> aivs = assetInstanceVersionDao.getAssetInstanceVersions(assetInstId,conn);

				for(AssetInstanceVersion aiv : aivs){
					List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
					groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);
					for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
						if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
							viewFlag = true;
							break;
						}
					}

					if (adminFlag || viewFlag) {
						response = favManager.getMyFavourite(assetInstId, user.getUserId());
						MyModel res = (MyModel) response.getEntity();
				        List<Object> data = res.getResult();
				        JSONObject j1 = null;
				        JSONObject json = new JSONObject();
				        List<Object> finaldata = new ArrayList<Object>();
				        boolean favFlag = false;
				        
				        if(data.isEmpty()){
				        	j1 = new JSONObject();
				        	j1.put("favouriteFlag", favFlag);
				        	finaldata.add(j1);
				        	
				        	json.put("result", finaldata);
					        json.put("message", res.getMessage());
					        json.put("status", Constants.SUCCESS);
					        json.put("statusCode", res.getStatusCode());
					        log.trace("getMyFavouriteMain || End");
					        return Response.status(retStat).entity(json.toString())
					          .build();
				        }
				        
				        for (int i = 0; i < data.size(); i++) {
				        	j1 = new JSONObject();
				        	AddFavourites addFavourites = new AddFavourites();
				        	addFavourites = (AddFavourites) data.get(i);
				        	
				        	if(addFavourites.getFavouriteflag() == 1){
				        		favFlag = true;
				        	}
				        	j1.put("favouriteFlag", favFlag);
				        	
				        	finaldata.add(j1);
				        }
				        json.put("result", finaldata);
				        json.put("message", res.getMessage());
				        json.put("status", res.getStatus());
				        json.put("statusCode", res.getStatusCode());

				        log.trace("getMyFavouriteMain || End");
				        return Response.status(retStat).entity(json.toString())
				          .build();
					} else {
						retStat = Status.FORBIDDEN;
						retMsg = Constants.USER_NOT_AUTHORIZED;
						retScsFlr = Constants.SUCCESS;
						retStatScsFlr = Constants.FORBIDDEN;
						return Response.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
								.build();
					}
				}
			}
		} catch (RepoproException e) {
			log.error("getMyFavouriteMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getMyFavouriteMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getMyFavouriteMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getMyFavouriteMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/*** Wrapper function ***/
	@PUT
	@Encoded
	@Path("/lock")
	public Response lockAssetInstanceVersionMain(
			@QueryParam("assetName") String assetName, 
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@HeaderParam("token") String token) {
		
		if(assetName == null || assetInstName == null|| assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty() || assetInstName.isEmpty()|| assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("lockAssetInstanceVersionMain || Begin");
		
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		boolean editFlag = false;
		boolean adminFlag = false;
		boolean lockFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;

				log.trace("lockAssetInstanceVersionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			
			if (log.isTraceEnabled()) {
				log.trace("lockAssetInstanceVersionMain || dao method called : getAssetInstanceVersion ");
			}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, null);
		
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("lockAssetInstanceVersionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			long aivId = assetInstanceVer.getAssetInstVersionId();
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			
			if (log.isTraceEnabled()) {
				log.trace("lockAssetInstanceVersionMain || dao method called : retAivAccessRights ");
			}
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aivId, userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
					editFlag = true;
					break;
				}
			}
			adminFlag = assetInstVersionDao.findAdminRightsByUserName(userName, null);
			AssetInstanceVersion aiv = assetInstVersionDao.getAssetInstanceVersionDetails(aivId,null);

			List<GlobalSetting> globalSetting = globalSettingDao.getGlobalSetting(null);
			for(GlobalSetting g : globalSetting){
				if(g.getGlobalLockSettingFlag() == 1){
					lockFlag = true;
					break;
				}
			}

			if(lockFlag){
				if (editFlag || adminFlag) {
					if(aiv.getLockedBy() == null){
						response = aivManager.lockAssetInstanceVersion(userName, aivId);
						MyModel res = (MyModel) response.getEntity();				
						JSONObject json = new JSONObject();
						
						json.put("message", res.getMessage());
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());
						log.trace("lockAssetInstanceVersionMain || End");
						
						return Response.status(retStat).entity(json.toString())
								.build();

					} else {
						retStat = Status.BAD_REQUEST;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.ASSET_INSTANCE_VERSION_ALREADY_LOCKED;
						retStatScsFlr = Constants.STATUS_FAILURE;

						log.trace("lockAssetInstanceVersionMain || End");
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("lockAssetInstanceVersionMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}

			}else{
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retMsg = Constants.ENABLE_CONCURRENT_EDIT_LOCK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("lockAssetInstanceVersionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			
		} catch (RepoproException e) {
			log.error("lockAssetInstanceVersionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("lockAssetInstanceVersionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 
		log.trace("lockAssetInstanceVersionMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/*** Wrapper function ***/
	@PUT
	@Encoded
	@Path("/unlock")
	public Response unlockAssetInstanceVersionMain(
			@QueryParam("assetName") String assetName, 
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@HeaderParam("token") String token) {
		
		if(assetName == null || assetInstName == null|| assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty() || assetInstName.isEmpty()|| assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("unlockAssetInstanceVersionMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		boolean adminFlag = false;
		boolean editFlag = false;
		boolean lockFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;

				log.trace("unlockAssetInstanceVersionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			if (log.isTraceEnabled()) {
				log.trace("unlockAssetInstanceVersionMain || dao method called : getAssetInstanceVersion ");
			}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, null);
		
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("unlockAssetInstanceVersionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			long aivId = assetInstanceVer.getAssetInstVersionId();
			adminFlag = assetInstVersionDao.findAdminRightsByUserName(userName, null);

			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			
			if (log.isTraceEnabled()) {
				log.trace("unlockAssetInstanceVersionMain || dao method called : retAivAccessRights ");
			}
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aivId, userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
					editFlag = true;
					break;
				}
			}
			
			List<GlobalSetting> globalSetting = globalSettingDao.getGlobalSetting(null);
			for(GlobalSetting g : globalSetting){
				if(g.getGlobalLockSettingFlag() == 1){
					lockFlag = true;
					break;
				}
			}
			
			AssetInstanceVersion aiv = assetInstVersionDao.getAssetInstanceVersionDetails(aivId,null);
			
			if(lockFlag){
				if(editFlag){
					if(aiv.getLockedBy() != null){
						if (adminFlag || aiv.getLockedBy().equalsIgnoreCase(userName)) {

							response = aivManager.unlockAssetInstanceVersion(userName, aivId);
							MyModel res = (MyModel) response.getEntity();				
							JSONObject json = new JSONObject();
							
							json.put("message", res.getMessage());
							json.put("status", res.getStatus());
							json.put("statusCode", res.getStatusCode());
							log.trace("unlockAssetInstanceVersionMain || End");
							
							return Response.status(retStat).entity(json.toString())
									.build();

						} else {

							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;
							log.trace("unlockAssetInstanceVersionMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					}else{
						retStat = Status.BAD_REQUEST;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.ASSET_INSTANCE_VERSION_ALREADY_UNLOCKED;
						retStatScsFlr = Constants.STATUS_FAILURE;

						log.trace("unlockAssetInstanceVersionMain || End");
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("unlockAssetInstanceVersionMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				
			}else{
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retMsg = Constants.ENABLE_CONCURRENT_EDIT_LOCK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("unlockAssetInstanceVersionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			

		} catch (RepoproException e) {
			log.error("unlockAssetInstanceVersionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("unlockAssetInstanceVersionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 

		log.trace("unlockAssetInstanceVersionMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/fetchDerivedAttributeValue")
	public Response getDerivedAttributeValuesMain(
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName, 
			@QueryParam("assetName") String assetName,
			@QueryParam("parameterName") String parameterName,
			@HeaderParam("token") String token) throws RepoproException {
		
		if(assetInstName == null || assetVersionName == null|| assetName == null || parameterName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
			parameterName = URLDecoder.decode(parameterName, "UTF-8");parameterName = parameterName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetInstName.isEmpty() || assetVersionName.isEmpty()|| assetName.isEmpty() || parameterName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getDerivedAttributeValuesMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
				
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			AssetDao ad = new AssetDao();
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			if (log.isTraceEnabled()) {
				log.trace("getDerivedAttributeValuesMain || dao method called : getAssetinstDetails ");
			}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getDerivedAttributeValuesMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			//checking parameter type 
			AssetDao assetDao = new AssetDao();
			AssetParamDef paramCheck = assetDao.getParamIdForAssetAndParamName(assetName,parameterName,null);
			if(paramCheck!= null){
				if(paramCheck.getParamTypeId()!= 5){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_DATA;
					retStatScsFlr = Constants.STATUS_FAILURE;

					log.trace("getDerivedAttributeValuesMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}else{
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.INVALID_DATA;
				retStatScsFlr = Constants.STATUS_FAILURE;

				log.trace("getDerivedAttributeValuesMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			if(!userName.equalsIgnoreCase("roleAnonymous")){
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			Boolean viewFlag = false;
			
			if (log.isTraceEnabled()) {
				log.trace("getDerivedAttributeValuesMain || dao method called : retAivAccessRights ");
			}
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVer.getAssetInstVersionId(), userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
					viewFlag = true;
					break;
				}
			}

			if (viewFlag) {
				if(!userName.equalsIgnoreCase("admin")){
					AssetParamDef apd  =  ad.getAssetParamAccess(userName,parameterName,assetName,null);

					if(apd!=null && apd.getAssetParamId() != null){
						assetName = URLEncoder.encode(assetName, "UTF-8");
						response = aivManager.getDerivedAttributeValues(userName, assetInstanceVer.getAssetInstVersionId().toString(), assetName, parameterName);					
						MyModel res = (MyModel) response.getEntity();
						List<Object> data = res.getResult();
						JSONObject j1 = null;
						JSONObject json = new JSONObject();
						List<Object> finaldata = new ArrayList<Object>();
						for (int i = 0; i < data.size(); i++) {
							j1 = new JSONObject();
							//spliting value to remove count
							String datas = data.toString();
							String[] data1	 =  datas.split("`!!`");
							String Value = data1[1].toString();
							if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
								Value = Value.substring(0, Value.length() - 1);
							    }
							
							if(Value.contains("``")){
								Value = Value.replaceAll("``", "|");
							}
							
							if(Value.contains("~~")){
								Value = Value.replaceAll("~~", ",");
							}
							
							if(Value.contains("`~`")){
								
								List<String> strArray = new ArrayList<String>();
								
								strArray= (Arrays.asList(Value.split("`~`")));
										
								j1.put("value", strArray);
								}else{
									j1.put("value", Value.trim());
								}

							finaldata.add(j1);
						}
						json.put("result", finaldata);
						json.put("message", res.getMessage());
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());

						log.trace("getDerivedAttributeValuesMain || End");
						return Response.status(retStat).entity(json.toString())
								.build();

					} else {
						retStat = Status.FORBIDDEN;
						retMsg = Constants.USER_NOT_AUTHORIZED;
						retScsFlr = Constants.NOT_AUTHORIZED;
						retStatScsFlr = Constants.FORBIDDEN;
						log.trace("getDerivedAttributeValuesMain || End");
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}
				} else {
					assetName = URLEncoder.encode(assetName, "UTF-8");
					response = aivManager.getDerivedAttributeValues(userName, assetInstanceVer.getAssetInstVersionId().toString(),
							assetName, parameterName);

					MyModel res = (MyModel) response.getEntity();
					List<Object> data = res.getResult();
					JSONObject j1 = null;
					JSONObject json = new JSONObject();
					List<Object> finaldata = new ArrayList<Object>();
					for (int i = 0; i < data.size(); i++) {
						j1 = new JSONObject();
						
						//spliting value to remove count
						String datas = data.toString();
						String[] data1	 =  datas.split("`!!`");
						String Value = data1[1].toString();
						if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
							Value = Value.substring(0, Value.length() - 1);
						    }
						if(Value.contains("``")){
							Value = Value.replaceAll("``", "|");
						}
						if(Value.contains("~~")){
							Value = Value.replaceAll("~~", ",");
						}
						
						if(Value.contains("`~`")){
						
						List<String> strArray = new ArrayList<String>();
						
						strArray= (Arrays.asList(Value.split("`~`")));
								
						j1.put("value", strArray);
						}else{
							j1.put("value", Value.trim());
						}

						finaldata.add(j1);
					}
					json.put("result", finaldata);
					json.put("message", res.getMessage());
					json.put("status", res.getStatus());
					json.put("statusCode", res.getStatusCode());

					log.trace("getDerivedAttributeValuesMain || End");
					return Response.status(retStat).entity(json.toString())
							.build();

				}
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("getDerivedAttributeValuesMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			}else{
				
				AssetInstanceDao assetInstDao = new AssetInstanceDao(); 
				List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
				AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);

				if(assetDef.isGuestflag() == true){
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInstanceVer.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							AssetParamDef apd  =  ad.getAssetParamAccess(userName,parameterName,assetName,null);

							if(apd!=null && apd.getAssetParamId() != null){
								assetName = URLEncoder.encode(assetName, "UTF-8");
								response = aivManager.getDerivedAttributeValues(userName, assetInstanceVer.getAssetInstVersionId().toString(), assetName, parameterName);

								MyModel res = (MyModel) response.getEntity();
						        List<Object> data = res.getResult();
						        JSONObject j1 = null;
						        JSONObject json = new JSONObject();
						        List<Object> finaldata = new ArrayList<Object>();
						        for (int i = 0; i < data.size(); i++) {
						        	j1 = new JSONObject();
						        
						        	//spliting value to remove count
									String datas = data.toString();
									String[] data1	 =  datas.split("`!!`");
									String Value = data1[1].toString();
									if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
										Value = Value.substring(0, Value.length() - 1);
									    }
									if(Value.contains("``")){
										Value = Value.replaceAll("``", "|");
									}
									if(Value.contains("~~")){
										Value = Value.replaceAll("~~", ",");
									}
									
									if(Value.contains("`~`")){
									
									List<String> strArray = new ArrayList<String>();
									
									strArray= (Arrays.asList(Value.split("`~`")));
											
									j1.put("value", strArray);
									}else{
										j1.put("value", Value.trim());
									}

									finaldata.add(j1);
								}
						        json.put("result", finaldata);
						        json.put("message", res.getMessage());
						        json.put("status", res.getStatus());
						        json.put("statusCode", res.getStatusCode());

						        log.trace("getDerivedAttributeValuesMain || End");
						        return Response.status(retStat).entity(json.toString())
						          .build();
							}else{

								retStat = Status.FORBIDDEN;
								retMsg = Constants.USER_NOT_AUTHORIZED;
								retScsFlr = Constants.NOT_AUTHORIZED;
								retStatScsFlr = Constants.FORBIDDEN;
								log.trace("getDerivedAttributeValuesMain || End");
								return Response
										.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}

						}else{

							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;
							log.trace("getDerivedAttributeValuesMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getDerivedAttributeValuesMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}	
		
		} catch (RepoproException e) {
			log.error("getDerivedAttributeValuesMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getDerivedAttributeValuesMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 
		log.trace("getDerivedAttributeValuesMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/*** Wrapper function ***/
	@GET
	@Encoded
	@Path("/fetchDerivedComputationValue")
	public Response getDerivedComputationValuesMain(
			@QueryParam("assetInstanceName") String assetInstName, 
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@QueryParam("assetName") String assetName, 
			@QueryParam("parameterName") String parameterName,
			@HeaderParam("token") String token) throws RepoproException {
		
		if(assetInstName == null || assetVersionName == null|| assetName == null || parameterName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
			parameterName = URLDecoder.decode(parameterName, "UTF-8");parameterName = parameterName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetInstName.isEmpty() || assetVersionName.isEmpty()|| assetName.isEmpty() || parameterName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getDerivedComputationValuesMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			AssetDao ad = new  AssetDao();
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			if (log.isTraceEnabled()) {
				log.trace("getDerivedComputationValuesMain || dao method called : getAssetinstDetails ");
			}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getDerivedComputationValuesMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
			String assetInstVersionId = Long.toString(assetInstanceVersionId);
			
			//checking parameter type 
			AssetDao assetDao = new AssetDao();
			AssetParamDef paramCheck = assetDao.getParamIdForAssetAndParamName(assetName,parameterName,null);
			if(paramCheck!= null){
				if(paramCheck.getParamTypeId()!= 6){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_DATA;
					retStatScsFlr = Constants.STATUS_FAILURE;

					log.trace("getDerivedAttributeValuesMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}else{
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.INVALID_DATA;
				retStatScsFlr = Constants.STATUS_FAILURE;

				log.trace("getDerivedAttributeValuesMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			if(!userName.equalsIgnoreCase("roleAnonymous")){
				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				Boolean viewFlag = false;

				if (log.isTraceEnabled()) {
					log.trace("getDerivedComputationValuesMain || dao method called : retAivAccessRights ");
				}
				groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVersionId, userName, null);

				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
						viewFlag = true;
						break;
					}
				}

				if (viewFlag) {

					if(!userName.equalsIgnoreCase("admin")){
						AssetParamDef apd  =  ad.getAssetParamAccess(userName,parameterName,assetName,null);

						if(apd!=null && apd.getAssetParamId() != null){
							response = aivManager.getDerivedComputationValues(userName, assetInstVersionId, assetName, parameterName);

							MyModel res = (MyModel) response.getEntity();
							List<Object> data = res.getResult();
							JSONObject j1 = null;
							JSONObject json = new JSONObject();
							List<Object> finaldata = new ArrayList<Object>();
							for (int i = 0; i < data.size(); i++) {
								j1 = new JSONObject();

								j1.put("value", data);

								finaldata.add(j1);
							}
							json.put("result", finaldata);
							json.put("message", res.getMessage());
							json.put("status", res.getStatus());
							json.put("statusCode", res.getStatusCode());

							log.trace("getDerivedComputationValuesMain || End");
							return Response.status(retStat).entity(json.toString())
									.build();
						}else {
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getDerivedComputationValuesMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					}else{
						response = aivManager.getDerivedComputationValues(userName, assetInstVersionId, assetName, parameterName);

						MyModel res = (MyModel) response.getEntity();
						List<Object> data = res.getResult();
						JSONObject j1 = null;
						JSONObject json = new JSONObject();
						List<Object> finaldata = new ArrayList<Object>();
						for (int i = 0; i < data.size(); i++) {
							j1 = new JSONObject();

							j1.put("value", data);

							finaldata.add(j1);
						}
						json.put("result", finaldata);
						json.put("message", res.getMessage());
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());

						log.trace("getDerivedComputationValuesMain || End");
						return Response.status(retStat).entity(json.toString())
								.build();
					}

				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getDerivedComputationValuesMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}else{
				AssetInstanceDao assetInstDao = new AssetInstanceDao(); 
				List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
				AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);

				if(assetDef.isGuestflag() == true){
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInstanceVer.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){

							AssetParamDef apd  =  ad.getAssetParamAccess(userName,parameterName,assetName,null);

							if(apd!=null && apd.getAssetParamId() != null){
								response = aivManager.getDerivedComputationValues(userName, assetInstVersionId, assetName, parameterName);

								MyModel res = (MyModel) response.getEntity();
								List<Object> data = res.getResult();
								JSONObject j1 = null;
								JSONObject json = new JSONObject();
								List<Object> finaldata = new ArrayList<Object>();
								for (int i = 0; i < data.size(); i++) {
									j1 = new JSONObject();

									j1.put("value", data);

									finaldata.add(j1);
								}
								json.put("result", finaldata);
								json.put("message", res.getMessage());
								json.put("status", res.getStatus());
								json.put("statusCode", res.getStatusCode());

								log.trace("getDerivedComputationValuesMain || End");
								return Response.status(retStat).entity(json.toString())
										.build();	
							}else{

								retStat = Status.FORBIDDEN;
								retMsg = Constants.USER_NOT_AUTHORIZED;
								retScsFlr = Constants.NOT_AUTHORIZED;
								retStatScsFlr = Constants.FORBIDDEN;

								log.trace("getDerivedComputationValuesMain || End");
								return Response
										.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}

						}else{

							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getDerivedComputationValuesMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

						}
					}
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getDerivedComputationValuesMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();

				}
			}
		} catch (RepoproException e) {
			log.error("getDerivedComputationValuesMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getDerivedComputationValuesMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}

		log.trace("getDerivedComputationValuesMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	
	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/fetchAllRating")
	public Response getAllRatingMain(
			@QueryParam("assetName")String assetName,
			@QueryParam("assetInstanceName")String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@HeaderParam("token") String token) {
		
		if(assetName == null || assetInstName == null || assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty() || assetInstName.isEmpty() || assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getAllRatingMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		boolean viewFlag = false;
		boolean adminFlag = false;
		AssetDao assetDao = new AssetDao();
		AssetInstanceDao assetInstDao = new AssetInstanceDao();
		List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (log.isTraceEnabled()) {
				log.trace("getAllRatingMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if(!userName.equalsIgnoreCase("guest")){
				User userData = userDao.getUserIdByUserName(userName, null);
				if(userData.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
			}
			
			AssetInstance assetInstance = new AssetInstance();
			RatingManager ratingManager = new RatingManager();

			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			adminFlag = assetInstVersionDao.findAdminRightsByUserName(userName, null);
			
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAllRatingMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			
			long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			
			if(userName.equalsIgnoreCase("roleAnonymous")){
				if(assetDef.isGuestflag() == true){
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInstanceVer.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							response = ratingManager.getAllRating(assetInstanceVersionId);
							MyModel res = (MyModel) response.getEntity();
					        List<Object> data = res.getResult();
					        JSONObject j1 = null;
					        JSONObject json = new JSONObject();
					        List<Object> finaldata = new ArrayList<Object>();
					        double avgRating = 0;
					        
					        for (int i = 0; i < data.size(); i++) {
					        	j1 = new JSONObject();
					        	AssetInstanceVersionRating aivr = new AssetInstanceVersionRating();
					        	aivr = (AssetInstanceVersionRating) data.get(i);
					        	
					        	avgRating = aivr.getAvgRating();
					        	j1.put("rating", aivr.getRating());
					        	j1.put("ratingDescription", aivr.getRatingDescription());
					        	j1.put("totalCount", aivr.getTotalCount());
					        	j1.put("userName", aivr.getUsername());
					        	
					        	finaldata.add(j1);
					        }
					        json.put("averageRating", avgRating);
					        json.put("result", finaldata);
					        json.put("message", res.getMessage());
					        json.put("status", res.getStatus());
					        json.put("statusCode", res.getStatusCode());

					        log.trace("getAllRatingMain || End");
					        return Response.status(retStat).entity(json.toString())
					          .build();
						}else{
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getAllRatingMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getAllRatingMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
			}
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVersionId, userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
			    	viewFlag = true;
				    break;
			    }
		    }

		    if (adminFlag || viewFlag) {
		    	response = ratingManager.getAllRating(assetInstanceVersionId);
		    	MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        double avgRating = 0;
		        
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	AssetInstanceVersionRating aivr = new AssetInstanceVersionRating();
		        	aivr = (AssetInstanceVersionRating) data.get(i);
		        	
		        	avgRating = aivr.getAvgRating();
		        	j1.put("rating", aivr.getRating());
		        	j1.put("ratingDescription", aivr.getRatingDescription());
		        	j1.put("totalCount", aivr.getTotalCount());
		        	j1.put("userName", aivr.getUsername());
		        	
		        	finaldata.add(j1);
		        }
		        json.put("averageRating", avgRating);
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getAllRatingMain || End");
		        return Response.status(retStat).entity(json.toString())
		          .build();
		    } else {
		    	retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			

		} catch (RepoproException e) {
			log.error("getAllRatingMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllRatingMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllRatingMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllRatingMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
/***Wrapper function***/
	@PUT
	@Encoded
	@Path("/updateRating")
	public Response updateRatingMain(
			@QueryParam("assetName")String assetName,
			@QueryParam("assetInstanceName")String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@QueryParam("rating") String rating,
			@QueryParam("ratingDescription") String ratingDescription,
			@HeaderParam("token") String token) {
		
		if(assetName == null || assetInstName == null || assetVersionName == null|| rating == null || ratingDescription == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
			rating = URLDecoder.decode(rating, "UTF-8");rating = rating.trim();
			ratingDescription = URLDecoder.decode(ratingDescription, "UTF-8");ratingDescription = ratingDescription.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty() || assetInstName.isEmpty() || assetVersionName.isEmpty()|| rating.isEmpty() || ratingDescription.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		if(ratingDescription.trim().length()>200){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
			     .build();
		}
		rating = rating.trim();
		if(!rating.matches("[0-5]")){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		
		log.trace("updateRatingMain || Begin");
		Connection conn = null;
		Response response = null;
		AssetInstanceVersionRating instanceVersionRating = new AssetInstanceVersionRating();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		boolean editFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (log.isTraceEnabled()) {
				log.trace("updateRatingMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User userData = userDao.getUserIdByUserName(userName, null);
				if(userData.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			AssetInstance assetInstance = new AssetInstance();
			RatingManager ratingManager = new RatingManager();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("updateRatingMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			
			long assetInstVersionId = assetInstanceVer.getAssetInstVersionId();
			instanceVersionRating.setAssetInstanceVersionId(assetInstVersionId);
			instanceVersionRating.setRating(Integer.parseInt(rating));
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			    return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build(); 
			}
			instanceVersionRating.setUsername(userName);
			instanceVersionRating.setRatingDescription(ratingDescription);
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
			    	editFlag = true;
				    break;
			    }
		    }

		    if (editFlag) {
		    	String newRegex = "^[A-Za-z0-9., ]+$";
				Pattern pattern = Pattern.compile(newRegex);
				Matcher matcher = pattern.matcher(ratingDescription);
				
				if(!matcher.find()){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, "Please use only alphanumeric characters, space, . and , in description"))
							.build();
				}
				
		    	response = ratingManager.updateRating(instanceVersionRating);
		    	MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("updateRatingMain || End");
				
				return Response.status(retStat).entity(json.toString())
						.build();
		    } else {
		    	retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }

			
		} catch (RepoproException e) {
			log.error("updateRatingMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("updateRatingMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateRatingMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("updateRatingMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

/***Wrapper function***/
	@GET
	@Encoded
	@Path("/fetchRatingStatistics")
	public Response getUsersCountMain(@QueryParam("assetName")String assetName,
			@QueryParam("assetInstanceName")String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@HeaderParam("token") String token) {
		
		if(assetName == null || assetInstName == null || assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstName.isEmpty() || assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getUsersCountMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		boolean viewFlag = false;
		boolean adminFlag = false;
		AssetDao assetDao = new AssetDao();
		AssetInstanceDao assetInstDao = new AssetInstanceDao();
		List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (log.isTraceEnabled()) {
				log.trace("getUsersCountMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
			}
			
			AssetInstance assetInstance = new AssetInstance();
			RatingManager ratingManager = new RatingManager();

			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);

			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getUsersCountMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			
			if(userName.equalsIgnoreCase("roleAnonymous")){
				if(assetDef.isGuestflag() == true){
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInstanceVer.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							response = ratingManager.getUsersCount(assetInstanceVer.getAssetInstVersionId());
							MyModel res = (MyModel) response.getEntity();
					        List<Object> data = res.getResult();
					        JSONObject j1 = null;
					        JSONObject json = new JSONObject();
					        List<Object> finaldata = new ArrayList<Object>();
					        double avgRating = 0;
					        
					        for (int i = 0; i < data.size(); i++) {
					        	j1 = new JSONObject();
					        	AssetInstanceVersionRating aivr = new AssetInstanceVersionRating();
					        	aivr = (AssetInstanceVersionRating) data.get(i);
					        	
					        	avgRating = aivr.getAvgRating();
					        	j1.put("count", aivr.getCount());
					        	j1.put("rating", aivr.getRating());
					        	//j1.put("ratingDescription", aivr.getRatingDescription());
					        						        	
					        	finaldata.add(j1);
					        }
					        json.put("averageRating", avgRating);
					        json.put("result", finaldata);
					        json.put("message", res.getMessage());
					        json.put("status", res.getStatus());
					        json.put("statusCode", res.getStatusCode());

					        log.trace("getUsersCountMain || End");
					        return Response.status(retStat).entity(json.toString())
					          .build();
						}else{
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getUsersCountMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getUsersCountMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
			}
			
			adminFlag = assetInstVersionDao.findAdminRightsByUserName(userName, null);

			long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVersionId, userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
			    	viewFlag = true;
				    break;
			    }
		    }

		    if (adminFlag || viewFlag) {
		    	response = ratingManager.getUsersCount(assetInstanceVersionId);
		    	MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        double avgRating = 0;
		       
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	AssetInstanceVersionRating aivr = new AssetInstanceVersionRating();
		        	aivr = (AssetInstanceVersionRating) data.get(i);
		        	
		        	avgRating = aivr.getAvgRating();
		        	j1.put("count", aivr.getCount());
		        	j1.put("rating", aivr.getRating());
		        	//j1.put("ratingDescription", aivr.getRatingDescription());
		        			        	
		        	finaldata.add(j1);
		        }
		        json.put("averageRating", avgRating);
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getUsersCountMain || End");
		        return Response.status(retStat).entity(json.toString())
		          .build();
		    } else {
		    	retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			

		} catch (RepoproException e) {
			log.error("getUsersCountMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getUsersCountMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getUsersCountMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getUsersCountMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/**
	 * @method getFullDependents
	 * @description get asset instance version relationships
	 * @param assetName
	 * @param assetInstaceName
	 * @param versionName
	 * @param userName
	 * @return success Response
	 */
	@GET
	@Encoded
	@Path("/fullRelationships")
	public Response getFullDependents(
			@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstaceName,
			@QueryParam("assetInstanceVersionName") String versionName,
			@HeaderParam("token") String token) {
		
		if(assetName == null || assetInstaceName == null || versionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstaceName = URLDecoder.decode(assetInstaceName, "UTF-8");assetInstaceName = assetInstaceName.trim();
			versionName = URLDecoder.decode(versionName, "UTF-8");versionName = versionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty() || assetInstaceName.isEmpty() || versionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getFullDependents || Start");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<AssetInstanceValues> vosList = new ArrayList<AssetInstanceValues>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		UserDao userDao = new UserDao();
		AssetDao assetDao = new AssetDao();
		AssetInstanceDao assetInstDao = new AssetInstanceDao();
		List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (log.isTraceEnabled()) {
				log.trace("getFullDependents || "+ Constants.LOG_CONNECTION_OPEN);
			}
			//conn = DBConnection.getInstance().getConnection();
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous"; 
			}
			AssetInstance assetInstance = new AssetInstance(); 
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstaceName);
			assetInstance.setVersionName(versionName);
			AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, null);
			if(aiv == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("getFullDependents || End");
				return Response
						.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr,retMsg)).build();
			}
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			if(userName.equalsIgnoreCase("roleAnonymous")){
				if(assetDef.isGuestflag() == true){
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(aiv.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							List<AssetInstanceData> instances = retFwdDependentsForGuest(assetInstance,userName,null);
							AssetInstanceValues vos = new AssetInstanceValues();
							vos.setAssetInstanceData(instances);
							vosList.add(vos);
							retStat = Status.OK;
							retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED;
							retScsFlr = Constants.SUCCESS;
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
							return Response
									.status(retStat)
									.entity(new RelationshipMyModel(retStatScsFlr, retScsFlr, retMsg,
											new ArrayList<Object>(vosList))).build();
						}else{

							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getFullDependents || End");
							return Response
									.status(retStat)
									.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getFullDependents || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
			}
			boolean viewFlag = false;
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
			    	viewFlag = true;
				    break;
			    }
		    }
		    if(viewFlag){
		    	List<AssetInstanceData> instances = retFwdDependentsForRest(assetInstance,userName,null);

		    	AssetInstanceValues vos = new AssetInstanceValues();
		    	vos.setAssetInstanceData(instances);
		    	vosList.add(vos);
		    	
				/*JSONObject json = new JSONObject();
				List<Object> list = new ArrayList<Object>();

				for(int l = 0 ; l < vosList.size() ; l++){
					for(int i = 0 ; i < vosList.get(0).getAssetInstance().size() ; i++){
						JSONObject item = new JSONObject();
						item.put("assetInstanceName",vosList.get(0).getAssetInstance().get(i).getAssetInstName());
						item.put("assetName", vosList.get(0).getAssetInstance().get(i).getAssetName());
						item.put("versionable", vosList.get(0).getAssetInstance().get(i).isVersionable());
						item.put("assetInstanceVersionName", vosList.get(0).getAssetInstance().get(i).getVersionName());

						List<AssetInstance> data = new ArrayList<AssetInstance>();
						data.addAll(vosList.get(0).getAssetInstance().get(i).getAssetInstance());
						List<Object> assetInstanceList = new ArrayList<Object>();

						for(int j = 0 ; j < data.size() ; j++){
							JSONObject subitem = new JSONObject();
							subitem.put("assetInstanceName",data.get(j).getAssetInstName());
							subitem.put("assetName", data.get(j).getAssetName());
							subitem.put("versionable", data.get(j).isVersionable());
							subitem.put("assetInstanceVersionName", data.get(j).getVersionName());
							assetInstanceList.add(subitem);
						}
						item.put("assetInstanceDetails", assetInstanceList);

						list.add(item);
					}
				}
				json.put("Result", list);
				json.put("statusCode", Constants.GET_STATUS_SUCCESS);
				json.put("status", Constants.SUCCESS);
				json.put("message", Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED);
				return Response
						.status(retStat).entity(json.toString()).build();*/
		    	retStat = Status.OK;
		    	retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED;
		    	retScsFlr = Constants.SUCCESS;
		    	retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		    }else{
		    	retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("getFullDependents || End");
				return Response
						.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
		} catch (Exception e) {
			log.error("getFullDependents || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getFullDependents || "+ Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.trace("getFullDependents || end");

		return Response
				.status(retStat)
				.entity(new RelationshipMyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(vosList))).build();
		
	}
	public List<AssetInstanceData> retFwdDependentsForGuest(AssetInstance assetInstance,String userName,Connection conn){

		log.debug("retFwdDependentsForGuest : Begin "+assetInstance);

		AssetInstanceData AssetInstanceData = null;
		List<AssetInstanceData> assetInstances = null;
		
		RelationshipDao relationshipDao = new RelationshipDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean viewFlag = false;
		AssetDao assetDao = new AssetDao();
		AssetInstanceDao assetInstDao = new AssetInstanceDao();
		List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();

		try{
			AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetInstance.getAssetName(), null);
			if(assetDef.isGuestflag() == true){
				assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(aiv.getAssetInstanceId() ,null);
				for(AssetInstance ai : assetInsatnceList){
					if(ai.isPublicAccess() == true){
						viewFlag = true;
						break;
					}
				}
			}
			
			if(viewFlag){
				List<AssetInstance> airs = relationshipDao.getDependants(aiv.getAssetInstVersionId(),conn);
				assetInstances = new ArrayList<AssetInstanceData>();
				for(AssetInstance air : airs){
					AssetInstanceData = new AssetInstanceData();
					AssetInstance assetInst = new AssetInstance();
					assetInst.setAssetInstId(air.getAssetInstId());
					assetInst.setAssetInstVersionId(air.getAssetInstVersionId());
					boolean viewaccess = false;
					AssetDef asset = assetDao.getAssetsByAssetName(air.getAssetName(), null);
					if(asset.isGuestflag() == true){
						assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInst.getAssetInstId() ,null);
						for(AssetInstance ai : assetInsatnceList){
							if(ai.isPublicAccess() == true){
								viewaccess = true;
								break;
							}
						}
					}
					if(viewaccess){
				    	AssetInstanceData.setAssetInstanceVersionName(air.getVersionName());
				    	AssetInstanceData.setAssetName(air.getAssetName());
				    	AssetInstanceData.setVersionableFlag(air.isVersionable());
				    	AssetInstanceData.setAssetInstName(air.getAssetInstName());
				    	//AssetInstanceData.setAssetRelationshipId(air.getAssetRelationshipId());
				    	AssetInstanceData.setAssetRelationshipName(air.getDescription());
				    	AssetInstanceData.setAssetRelationshipType(air.getAssetRelationshipType());
				    	AssetInstanceData.setAssetInstanceVersionId(air.getAssetInstVersionId());
				    	
				    	AssetInstance instance = new AssetInstance();
				    	instance.setAssetInstName(AssetInstanceData.getAssetInstName());
				    	instance.setAssetName(AssetInstanceData.getAssetName());
				    	instance.setVersionName(AssetInstanceData.getAssetInstanceVersionName());

				    	assetInstances.add(AssetInstanceData);
				    	List<AssetInstanceData> li = retFwdDependentsForGuest(instance,userName,conn);
				    	if(li.size() == 0){
				    		li = new ArrayList<AssetInstanceData>();
				    		AssetInstanceData.setAssetInstanceData(li);
				    	}else{
				    		AssetInstanceData.setAssetInstanceData(li);
				    	}
				    }
				}
			}
		} catch (RepoproException e) {
			log.error("retFwdDependentsForGuest || "+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		}
		log.debug("retFwdDependentsForGuest : End ");

		return assetInstances;
	}
	
	public List<AssetInstanceData> retFwdDependentsForRest(AssetInstance assetInstance,String userName,Connection conn){
		
		log.debug("retFwdDependentsForRest : Begin "+assetInstance);
		
		AssetInstanceData AssetInstanceData = null;
		List<AssetInstanceData> assetInstances = null;
		
		RelationshipDao relationshipDao = new RelationshipDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean viewFlag = false;

		try{
			AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
			    	viewFlag = true;
				    break;
			    }
		    }
		    if(viewFlag){
		    	List<AssetInstance> airs = relationshipDao.getDependants(aiv.getAssetInstVersionId(),conn);
		    	assetInstances = new ArrayList<AssetInstanceData>();
		    	for(AssetInstance air : airs){
		    		AssetInstanceData = new AssetInstanceData();
		    		//AssetInstance.setAssetInstId(air.getAssetInstId());
		    		//AssetInstance.setAssetInstVersionId(air.getAssetInstVersionId());
		    		boolean viewaccess = false;
		    		List<GroupAssetInstVersionAccess> groupAssetInstVersionAccess = new ArrayList<GroupAssetInstVersionAccess>();
				    groupAssetInstVersionAccess = assetInstanceVersionDao.retAivAccessRights(air.getAssetInstVersionId(), userName, null);
				    for (int i = 0; i < groupAssetInstVersionAccess.size(); i++) {
					    if (groupAssetInstVersionAccess.get(i).getViewAccess().equals(1L)) {
					    	viewaccess = true;
						    break;
					    }
				    }
				    if(viewaccess){
				    	AssetInstanceData.setAssetInstanceVersionName(air.getVersionName());
				    	AssetInstanceData.setAssetName(air.getAssetName());
				    	AssetInstanceData.setVersionableFlag(air.isVersionable());
				    	AssetInstanceData.setAssetInstName(air.getAssetInstName());
				    	//AssetInstanceData.setAssetRelationshipId(air.getAssetRelationshipId());
				    	AssetInstanceData.setAssetRelationshipName(air.getDescription());
				    	AssetInstanceData.setAssetRelationshipType(air.getAssetRelationshipType());
				    	AssetInstanceData.setAssetInstanceVersionId(air.getAssetInstVersionId());
				    	
				    	AssetInstance instance = new AssetInstance();
				    	instance.setAssetInstName(AssetInstanceData.getAssetInstName());
				    	instance.setAssetName(AssetInstanceData.getAssetName());
				    	instance.setVersionName(AssetInstanceData.getAssetInstanceVersionName());

				    	assetInstances.add(AssetInstanceData);
				    	List<AssetInstanceData> li = retFwdDependentsForRest(instance,userName,conn);
				    	if(li.size() == 0){
				    		li = new ArrayList<AssetInstanceData>();
				    		AssetInstanceData.setAssetInstanceData(li);
				    	}else{
				    		AssetInstanceData.setAssetInstanceData(li);
				    	}
				    }
		    	}
		    }
		} catch (RepoproException e) {
			log.error("retFwdDependentsForRest || "+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		}
		log.debug("retFwdDependentsForRest : End ");

		return assetInstances;
	}
	
	
	/**
	 * @method getAllAssetInstParamDetails
	 * @param userName
	 * @param assetName
	 * @param assetInstanceName
	 * @param versionName
	 * @param versionable
	 * @return success response
	 */
	@GET
	@Path("/getAllAssetInstParamDetails")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	public Response getAllAssetInstParamDetails(
	@QueryParam("assetName") String assetName,
	@QueryParam("assetInstanceName") String assetInstanceName,
	@QueryParam("assetInstanceVersionName") String versionName,
	@HeaderParam("token") String token) {
		
		if(assetName == null || assetInstanceName == null || versionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		
		if(assetName.isEmpty() || assetInstanceName.isEmpty() || versionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.debug("getAllAssetInstParamDetails : Begin");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		boolean versionableFlag = false;
		List<AssetInstanceParameter<Category>> assetInstanceList = new ArrayList<AssetInstanceParameter<Category>>();
		UserDao userDao = new UserDao();
		AssetDao assetDao = new AssetDao();
		AssetInstanceDao assetInstDao = new AssetInstanceDao();
		List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
		RelationshipDao relationshipDao = new RelationshipDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		assetName = assetName.trim();
		assetInstanceName = assetInstanceName.trim();
		versionName = versionName.trim();
		try{
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstParamDetails || "+ Constants.LOG_CONNECTION_OPEN);
			}
			if(!userName.equalsIgnoreCase("guest")){
				User userData = userDao.getUserIdByUserName(userName, null);
				if(userData.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous"; 
			}
			AssetInstance assetInst = new AssetInstance();
			assetInst.setAssetName(assetName);
			assetInst.setAssetInstName(assetInstanceName);
			assetInst.setVersionName(versionName);
			
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetinstDetails(assetName,assetInstanceName,versionName, null);
			if (aiv == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND ;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("getAllAssetInstParamDetails || End");
				return Response
						.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			Boolean versionable = aiv.getVersionable();
			assetInst.setVersionable(aiv.getVersionable());
			boolean viewGuestAivAccess=false;
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			if(userName.equalsIgnoreCase("roleAnonymous")){
				if(assetDef.isGuestflag() == true){
					viewGuestAivAccess = true;
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(aiv.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							if(viewGuestAivAccess){
								List<AssetInstance> vos = relationshipDao.getDependants(aiv.getAssetInstVersionId(),null);

								AssetInstanceParameter<Category> assetInstanceVo = new AssetInstanceParameter<Category>();
								AssetInstanceParameter<Category> assetInstanceVo1 = new AssetInstanceParameter<Category>();
								List<AssetInstanceParameter> result = new LinkedList<AssetInstanceParameter>();

								assetInstanceVo1 = getParametersForAssetInst(assetInst, assetName,
										assetInstanceName, null, null, versionName,userName);
								if(versionable){
									versionableFlag = true;
									assetInstanceVo.setVersionable(versionableFlag);
								}
								assetInstanceVo.setAssetInstName(assetInstanceName);
								assetInstanceVo.setVersionName(versionName);
								assetInstanceVo.setAssetName(assetName);
								assetInstanceVo.setVersionable(versionable);
								assetInstanceVo.setCategoryDetails(assetInstanceVo1.getCategoryDetails());
								assetInstanceVo.setDescription(assetInstanceVo1.getDescription());
								for(AssetInstance list : vos){
									boolean viewFlag = false;
									AssetInstance adr = new AssetInstance();
									adr.setAssetName(list.getAssetName());
									adr.setAssetInstName(list.getAssetInstName());
									adr.setVersionName(list.getVersionName());
									adr.setVersionable(list.isVersionable());
									AssetInstanceVersion assetInstVersion = assetInstanceVersionDao.getAssetInstanceVersion(adr, null);
									if (assetInstVersion == null) {
										retStat = Status.NOT_FOUND;
										retScsFlr = Constants.FAILURE;
										retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND ;
										retStatScsFlr = Constants.GET_STATUS_FAILURE;
										log.trace("getAllAssetInstParamDetails || End");
										return Response
												.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

									}
									AssetDef asset = assetDao.getAssetsByAssetName(list.getAssetName(), null);
									if(asset.isGuestflag() == true){
										assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInstVersion.getAssetInstanceId() ,null);
										for(AssetInstance assetinst : assetInsatnceList){
											if(assetinst.isPublicAccess() == true){
												viewFlag = true;
												break;
											}
										}
									}
									
									if(viewFlag){
										assetInstanceVo1 = getParametersForAssetInst(adr, list.getAssetName(),
												list.getAssetInstName(), null, null, list.getVersionName(),userName);
										result.add(assetInstanceVo1); 
									}
								}
								assetInstanceVo.setAssetInstance(result);

								assetInstanceList.add(assetInstanceVo);
								
								retStat = Status.OK;
								retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED;
								retScsFlr = Constants.SUCCESS;
								retStatScsFlr = Constants.GET_STATUS_SUCCESS;
								
								JSONObject json = new JSONObject();
								List<List<Object>> listdata = new ArrayList<List<Object>>();
								List<Object> list = new ArrayList<Object>();
								for(int i = 0 ; i < assetInstanceList.size() ; i++){
									JSONObject item = new JSONObject();
									List<Object> catList = new ArrayList<Object>();
									item.put("assetInstanceName",assetInstanceList.get(i).getAssetInstName());
									item.put("assetName", assetInstanceList.get(i).getAssetName());
									item.put("versionable", assetInstanceList.get(i).isVersionable());
									if(assetInstanceList.get(i).isVersionable()){
										item.put("assetInstanceVersionName", assetInstanceList.get(i).getVersionName());
									}else{
										item.put("assetInstanceVersionName", "N/A");
									}
									
									
									List<Category> data = new ArrayList<Category>();
									data.addAll(assetInstanceList.get(i).getCategoryDetails());
									for(int j = 0 ; j < data.size() ; j++){
										JSONObject catitem = new JSONObject();
										catitem.put("categoryName",data.get(j).getCategoryName());
										List<Parameter> para = new ArrayList<Parameter>();
										List<Object> cat = new ArrayList<Object>();
										para.addAll(data.get(j).getParametersdata());
										for(Parameter paras:para){
											JSONObject param = new JSONObject();
											param.put("assetParamName", paras.getParamName());
											param.put("fileName", paras.getFileName());
											param.put("paramTypeName", paras.getSelectedTypeName());
											param.put("listTypeName", paras.getListTypeName());
											param.put("paramValue", paras.getValue());
											if(paras.getRTFwithTags()!=null){
												param.put("richTextData", paras.getRTFwithTags());
											}
											if(paras.getTextDataList()!=null){
												param.put("TextData", paras.getTextDataList());
											}
											if(paras.getPossibleValues()!=null){
												param.put("possibleValues", paras.getPossibleValues());
											}
											param.put("updatedBy", paras.getUpdatedBy());
											param.put("updatedTime", paras.getUpdatedTime());
											cat.add(param);
										}
										catitem.put("parameterData", cat);
										catList.add(catitem);

									}
									item.put("categoryDetailsList", catList);

									List<AssetInstanceParameter> assetInstanceData = new ArrayList<AssetInstanceParameter>();
									assetInstanceData.addAll(assetInstanceList.get(i).getAssetInstanceParameters());
									List<Object> finalassetcatList = new ArrayList<Object>();
									for(AssetInstanceParameter aip:assetInstanceData){
										JSONObject assetitem = new JSONObject();
										List<Object> assetcatList = new ArrayList<Object>();
										assetitem.put("assetInstanceName",aip.getAssetInstName());
										assetitem.put("assetName", aip.getAssetName());
										assetitem.put("versionable", aip.isVersionable());
										if(aip.isVersionable()){
											assetitem.put("assetInstanceVersionName", aip.getVersionName());
										}else{
											assetitem.put("assetInstanceVersionName", "N/A");
										}
										
										List<Category> assetdata = new ArrayList<Category>();

										assetdata.addAll(aip.getCategoryDetails());
										for(int j = 0 ; j < assetdata.size() ; j++){
											List<Object> assetcat = new ArrayList<Object>();
											JSONObject catitem = new JSONObject();
											catitem.put("categoryName",assetdata.get(j).getCategoryName());
											List<Parameter> assetpara = new ArrayList<Parameter>();
											assetpara.addAll(assetdata.get(j).getParametersdata());
											for(Parameter paras:assetpara){
												JSONObject param = new JSONObject();
												param.put("assetParamName", paras.getParamName());
												param.put("fileName", paras.getFileName());
												param.put("paramTypeName", paras.getSelectedTypeName());
												param.put("listTypeName", paras.getListTypeName());
												param.put("paramValue", paras.getValue());
												if(paras.getRTFwithTags()!=null){
													param.put("richTextData", paras.getRTFwithTags());
												}
												if(paras.getTextDataList()!=null){
													param.put("TextData", paras.getTextDataList());
												}
												if(paras.getPossibleValues()!=null){
													param.put("possibleValues", paras.getPossibleValues());
												}
												param.put("updatedBy", paras.getUpdatedBy());
												param.put("updatedTime", paras.getUpdatedTime());
												assetcat.add(param);
											}
											catitem.put("parameterData", assetcat);
											assetcatList.add(catitem);
										}
										assetitem.put("categoryDetailsList", assetcatList);
										finalassetcatList.add(assetitem);
										//item.put("assetInstance", assetitem);

									}
									item.put("assetInstance", finalassetcatList);
									list.add(item);
								}
								json.put("Result", list);
								json.put("statusCode", Constants.GET_STATUS_SUCCESS);
								json.put("status", Constants.SUCCESS);
								json.put("message", Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED);
								
							    return Response.status(retStat).entity(json.toString()).build();
							}
						}else{
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getAllAssetInstParamDetails || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getAllAssetInstParamDetails || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
			}
			
			else{

				boolean viewaccessaiv=false;
				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccess = new ArrayList<GroupAssetInstVersionAccess>();
				groupAssetInstVersionAccess = assetInstanceVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);
				for (int i = 0; i < groupAssetInstVersionAccess.size(); i++) {
					if (groupAssetInstVersionAccess.get(i).getViewAccess().equals(1L)) {
						viewaccessaiv = true;
						break;
					}
				}
				if(viewaccessaiv){
					List<AssetInstance> vos = relationshipDao.getDependants(aiv.getAssetInstVersionId(),null);

					AssetInstanceParameter<Category> assetInstanceVo = new AssetInstanceParameter<Category>();
					AssetInstanceParameter<Category> assetInstanceVo1 = new AssetInstanceParameter<Category>();
					List<AssetInstanceParameter> result = new LinkedList<AssetInstanceParameter>();

					assetInstanceVo1 = getParametersForAssetInst(assetInst, assetName,
							assetInstanceName, null, null, versionName,userName);
					if(versionable){
						versionableFlag = true;
						assetInstanceVo.setVersionable(versionableFlag);
					}
					assetInstanceVo.setAssetInstName(assetInstanceName);
					assetInstanceVo.setVersionName(versionName);
					assetInstanceVo.setAssetName(assetName);
					assetInstanceVo.setCategoryDetails(assetInstanceVo1.getCategoryDetails());
					assetInstanceVo.setDescription(assetInstanceVo1.getDescription());
					for(AssetInstance list : vos){
						boolean viewFlag = false;
						AssetInstance adr = new AssetInstance();
						adr.setAssetName(list.getAssetName());
						adr.setAssetInstName(list.getAssetInstName());
						adr.setVersionName(list.getVersionName());
						adr.setVersionable(list.isVersionable());
						AssetInstanceVersion assetInstVersion = assetInstanceVersionDao.getAssetInstanceVersion(adr, null);
						if (assetInstVersion == null) {
							retStat = Status.NOT_FOUND;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND ;
							retStatScsFlr = Constants.GET_STATUS_FAILURE;
							log.trace("getAllAssetInstParamDetails || End");
							return Response
									.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

						}
						List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
						groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(assetInstVersion.getAssetInstVersionId(), userName, null);
						for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
							if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
								viewFlag = true;
								break;
							}
						}
						if(viewFlag){
							assetInstanceVo1 = getParametersForAssetInst(adr, list.getAssetName(),
									list.getAssetInstName(), null, null, list.getVersionName(),userName);
							result.add(assetInstanceVo1);
						}
					}
					assetInstanceVo.setAssetInstance(result);

					assetInstanceList.add(assetInstanceVo);
					
					retStat = Status.OK;
					retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;
					
					JSONObject json = new JSONObject();
					List<List<Object>> listdata = new ArrayList<List<Object>>();
					List<Object> list = new ArrayList<Object>();
					for(int i = 0 ; i < assetInstanceList.size() ; i++){
						JSONObject item = new JSONObject();
						List<Object> catList = new ArrayList<Object>();
						item.put("assetInstanceName",assetInstanceList.get(i).getAssetInstName());
						item.put("assetName", assetInstanceList.get(i).getAssetName());
						item.put("versionable", assetInstanceList.get(i).isVersionable());
						if(assetInstanceList.get(i).isVersionable()){
							item.put("assetInstanceVersionName", assetInstanceList.get(i).getVersionName());
						}else{
							item.put("assetInstanceVersionName", "N/A");
						}
						
						
						List<Category> data = new ArrayList<Category>();
						data.addAll(assetInstanceList.get(i).getCategoryDetails());
						for(int j = 0 ; j < data.size() ; j++){
							JSONObject catitem = new JSONObject();
							catitem.put("categoryName",data.get(j).getCategoryName());
							List<Parameter> para = new ArrayList<Parameter>();
							List<Object> cat = new ArrayList<Object>();
							para.addAll(data.get(j).getParametersdata());
							for(Parameter paras:para){
								JSONObject param = new JSONObject();
								param.put("assetParamName", paras.getParamName());
								param.put("fileName", paras.getFileName());
								param.put("paramTypeName", paras.getSelectedTypeName());
								param.put("listTypeName", paras.getListTypeName());
								param.put("paramValue", paras.getValue());
								if(paras.getRTFwithTags()!=null){
									param.put("richTextData", paras.getRTFwithTags());
								}
								if(paras.getTextDataList()!=null){
									param.put("TextData", paras.getTextDataList());
								}
								if(paras.getPossibleValues()!=null){
									param.put("possibleValues", paras.getPossibleValues());
								}
								param.put("updatedBy", paras.getUpdatedBy());
								param.put("updatedTime", paras.getUpdatedTime());
								cat.add(param);
							}
							catitem.put("parameterData", cat);
							catList.add(catitem);

						}
						item.put("categoryDetailsList", catList);

						List<AssetInstanceParameter> assetInstanceData = new ArrayList<AssetInstanceParameter>();
						assetInstanceData.addAll(assetInstanceList.get(i).getAssetInstanceParameters());
						List<Object> finalassetcatList = new ArrayList<Object>();
						for(AssetInstanceParameter aip:assetInstanceData){
							JSONObject assetitem = new JSONObject();
							List<Object> assetcatList = new ArrayList<Object>();
							assetitem.put("assetInstanceName",aip.getAssetInstName());
							assetitem.put("assetName", aip.getAssetName());
							assetitem.put("versionable", aip.isVersionable());
							if(aip.isVersionable()){
								assetitem.put("assetInstanceVersionName", aip.getVersionName());
							}else{
								assetitem.put("assetInstanceVersionName", "N/A");
							}
							
							List<Category> assetdata = new ArrayList<Category>();

							assetdata.addAll(aip.getCategoryDetails());
							for(int j = 0 ; j < assetdata.size() ; j++){
								List<Object> assetcat = new ArrayList<Object>();
								JSONObject catitem = new JSONObject();
								catitem.put("categoryName",assetdata.get(j).getCategoryName());
								List<Parameter> assetpara = new ArrayList<Parameter>();
								assetpara.addAll(assetdata.get(j).getParametersdata());
								for(Parameter paras:assetpara){
									JSONObject param = new JSONObject();
									param.put("assetParamName", paras.getParamName());
									param.put("fileName", paras.getFileName());
									param.put("paramTypeName", paras.getSelectedTypeName());
									param.put("listTypeName", paras.getListTypeName());
									param.put("paramValue", paras.getValue());
									if(paras.getRTFwithTags()!=null){
										param.put("richTextData", paras.getRTFwithTags());
									}
									if(paras.getTextDataList()!=null){
										param.put("TextData", paras.getTextDataList());
									}
									if(paras.getPossibleValues()!=null){
										param.put("possibleValues", paras.getPossibleValues());
									}
									param.put("updatedBy", paras.getUpdatedBy());
									param.put("updatedTime", paras.getUpdatedTime());
									assetcat.add(param);
								}
								catitem.put("parameterData", assetcat);
								assetcatList.add(catitem);
							}
							assetitem.put("categoryDetailsList", assetcatList);
							finalassetcatList.add(assetitem);
							//item.put("assetInstance", assetitem);

						}
						item.put("assetInstance", finalassetcatList);
						list.add(item);
					}
					json.put("Result", list);
					json.put("statusCode", Constants.GET_STATUS_SUCCESS);
					json.put("status", Constants.SUCCESS);
					json.put("message", Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED);
					
				    return Response.status(retStat).entity(json.toString()).build();
					
				}else{
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("getAllAssetInstParamDetails || End");
					return Response
							.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
		} catch (Exception e) {
			log.error("getAllAssetInstParamDetails || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstParamDetails || "+ Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.debug("getAllAssetInstParamDetails : End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetInstanceList))).build();

	}

	public AssetInstanceParameter<Category> getParametersForAssetInst(
			AssetInstance assetDetReq, String assetName,
			String assetInstanceName, String parentAssetName,
			String parentAssetInstanceName, String versionName,String userName) {
		
		log.debug("getParametersForAssetInst : Begin");

		String retVal = "";
		List<AssetInstRelationship> airs;
		AssetInstanceParameter<Category> assetInstanceVo = new AssetInstanceParameter<Category>();
		AssetDao assetDao = new AssetDao();
		boolean viewFlag = false;
		boolean adminFlag = false;
		boolean paramAccessFlag = true;
		boolean categoryAccessFlag = true;
		try {

			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			AssetInstance assetInstance = assetInstanceDao
					.retAssetInstanceByTypeAndName(assetDetReq.getAssetName(),assetDetReq.getAssetInstName(),null);

			assetInstanceVo.setVersionable(assetInstance.isVersionable());
			// Set name
			assetInstanceVo.setAssetInstName(assetInstance.getAssetInstName());
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(assetDetReq, null);
			//adminFlag = assetInstanceVersionDao.findAdminRightsByUserNameForRest(userName, null);
			/*// Put description
			String desc = tempAiv.getDescription();

			if (desc == null) {
				desc = "";
			}
			assetInstanceVo.setDescription(desc);*/

				// Put rating
				if (null != assetInstance.getRating())
					assetInstanceVo.setRating(assetInstance.getRating());
				else
					assetInstanceVo.setRating(0);

				// Put categories
				List<String> categories = new ArrayList<String>();
				List<Category> categoryList = assetDao.getCategoriesByassetId(assetInstance.getAssetId(),null);
				for(Category categoryData:categoryList){
					categories.add(categoryData.getCategoryName());
				}

				Category categoryVo;
				List<Category> categoryVos = new ArrayList<Category>();
				LinkedList<Parameter> paramvalues;

				// Put metadata
				for (String category : categories) {
					if(!category.equalsIgnoreCase("DUMMY_CATEGORY")){
						if(!userName.equalsIgnoreCase("admin")){
							AssetParamDef categoryaccess = assetDao.getAssetCategoryAccess(userName,category,assetName,null);
							if(categoryaccess == null){
								categoryAccessFlag = false;
							}
						}else{
							categoryAccessFlag = true;
						}
						if(categoryAccessFlag){
							categoryVo = new Category();
							categoryVo.setCategoryName(category);

							categoryVo.setCategoryName(category);
							categoryVo.setDeleted(false);
							categoryVo.setDisp_position(0);

							List<AssetParamDef> paramDef = assetDao
									.getParametersForAssetAndCategory(assetDetReq.getAssetName(), category,null);

							paramvalues = new LinkedList<Parameter>();
							Parameter paramVo = null;
							ParameterValues pv;
							for (AssetParamDef paramDefObj : paramDef) {

								if(!userName.equalsIgnoreCase("admin")){
									AssetParamDef paramaccess = assetDao.getAssetParamAccess(userName,paramDefObj.getAssetParamName(),assetName,null);
									if(paramaccess == null || paramaccess.getAssetParamId() == null){
										paramAccessFlag = false;
									}
								}else{
									paramAccessFlag = true;
								}

								if(paramAccessFlag){
									if (paramDefObj.isHasStaticValue()) {
										paramVo = setAssetInstanceDetailsInMapUsingParamDef(
												paramDefObj, paramDefObj.getStaticValue(),
												paramDefObj.getFileName(),userName,assetDetReq.getAssetName(),null);
									} else {

										pv = assetDao.getParameterForAssetInstParamAndVersionId(paramDefObj.getAssetParamName(),aiv.getAssetInstVersionId(),null);
										if (null != pv) {
											paramVo = setAssetInstanceDetailsInMap(pv,userName,assetDetReq.getAssetName());

										} else {
											paramVo = setAssetInstanceDetailsInMapUsingParamDef(
													paramDefObj, null, null,userName,assetDetReq.getAssetName(),null);
										}
									}
									if (null != paramVo) {
										paramvalues.add(paramVo);
									}
								}
							}

							categoryVo.setParametersdata(paramvalues);
							categoryVos.add(categoryVo);
						}
					}
				}// for loop ends for categories
				assetInstanceVo.setCategoryDetails(categoryVos);
				assetInstanceVo.setAssetName(assetName);
				
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		log.debug("getParametersForAssetInst : End");

		return assetInstanceVo;
	}
	
	public Parameter setAssetInstanceDetailsInMapUsingParamDef(
			AssetParamDef paramDef, String value,String fileName,String userName,String assetName,ParameterValues pv) throws Exception {
		log.debug("setAssetInstanceDetailsInMapUsingParamDef : Begin");
		Parameter paramVo = new Parameter();
		
		String name = paramDef.getAssetParamName();
		
		String typeName = paramDef.getTypeName();
		try{
			String assetType = assetName;
			List<String> values = new ArrayList<String>();
			values.add(value);

			paramVo.setParamName(name);
			paramVo.setSelectedTypeName(typeName);
			paramVo.setValue(value);
			if(pv != null){
				if(pv.getRTFwithTags()!=null)
				paramVo.setRTFwithTags(pv.getRTFwithTags());
			}
			if(pv != null){
				if(pv.getTextDataList()!=null)
				paramVo.setTextDataList(pv.getTextDataList());
			}
			//paramVo.setFileName(fileName);
			AssetDao assetDao = new AssetDao();
			List<AssetParamDef> listValues = new ArrayList<AssetParamDef>();
			List<String> possibleValues = new ArrayList<String>();
			UserDao userDao = new UserDao(); 
			String ListType = null;
			if(null != paramDef.getLastUpdatedTime())
				paramVo.setUpdatedTime(paramDef.getLastUpdatedTime().toString());

			if(null != paramDef.getModifyByUserId()){
				if(!paramDef.getModifyByUserId().equals(0L)){
					User user = userDao.getUserByUserId(paramDef.getModifyByUserId(), null);
					paramVo.setUpdatedBy(user.getUserName());
				}
			}
			if(paramDef.isQuickLink())
				paramVo.isQuickLink();

			if (typeName.equals("list")) {
				if(paramDef.getListTypeParamTypeId().equals(1L)){
					ListType = "customList";
					listValues = assetDao.getFilterList(assetName,name,"customlist",userName,paramDef.getMappedAssetId(), null);
				}
				else if(paramDef.getListTypeParamTypeId().equals(2L)){
					ListType = "assetlist";
					listValues =assetDao.getFilterList(assetName,name,"assetlist",userName,paramDef.getMappedAssetId(), null);
				}
				else if(paramDef.getListTypeParamTypeId().equals(3L)){
					ListType = "nativeuserlist";
					listValues = assetDao.getFilterList(assetName,name,"nativeuserlist",userName,paramDef.getMappedAssetId(), null);
				}else{
					ListType = "LdapUserList";
				}
				for(AssetParamDef listval:listValues){
					possibleValues.add(listval.getParamValue());
				}
				paramVo.setPossibleValues(possibleValues);
				paramVo.setListTypeName(ListType);
			}

			if (typeName.equals("text")) {
				paramVo.setSize(paramDef.getSize());			
			} 
			else if (typeName.equals("file")) {
				if(fileName!=null){
					paramVo.setFileName(fileName);
				}else{
					paramVo.setFileName(paramDef.getFileName());
				}
			}

			paramVo.setHasStaticValue(paramDef.isHasStaticValue());
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		log.debug("setAssetInstanceDetailsInMapUsingParamDef : Exit "+paramVo);
		return paramVo;
	}
	
	public Parameter setAssetInstanceDetailsInMap(ParameterValues pv,String userName,String assetName) {
		log.debug("setAssetInstanceDetailsInMap : Begin");
		Parameter paramVo = new Parameter();
		AssetDao assetDao = new AssetDao();
		UserDao userDao = new UserDao();
		try{
			
			AssetParamDef apd = assetDao.getParamDetailsByParamId(pv.getAssetParamId(),null);
			String value = pv.getValue();	
			paramVo = setAssetInstanceDetailsInMapUsingParamDef(apd, value,pv.getFileName(),userName,assetName,pv);
			paramVo.setUpdatedTime( pv.getLastUpdatedTime().toString());
			if(null != pv.getModifyByUserId()){

				User user = userDao.getUserByUserId(pv.getModifyByUserId(), null);
				paramVo.setUpdatedBy(user.getUserName());
			}
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		log.debug("setAssetInstanceDetailsInMap : Exit "+paramVo);
		return paramVo;
	}
	
	
	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/getAllReverseRelationships")
	public Response getAllReverseRelationshipsMain(
			@QueryParam("assetName")String assetName,
			@QueryParam("assetInstanceName")String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName,
			@HeaderParam("token") String token) {
		
		if(assetName == null || assetInstName == null || assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty() || assetInstName.isEmpty() || assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getAllReverseRelationshipsMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		AssetDao assetDao = new AssetDao();
		AssetInstanceDao assetInstDao = new AssetInstanceDao();
		List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
		boolean viewFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (log.isTraceEnabled()) {
				log.trace("getAllReverseRelationshipsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			AssetInstance assetInstance = new AssetInstance();
			RelationshipManager relManager = new RelationshipManager();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);

			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			
			if(userName.equalsIgnoreCase("roleAnonymous")){
				if(assetDef.isGuestflag() == true){
					AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
					if(assetInstanceVer == null){
						retStat = Status.NOT_FOUND;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;

						log.trace("getAllReverseRelationshipsMain || End");
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr,
										retMsg)).build();
					}
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInstanceVer.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
							response = relManager.getAllReverseRelationships(assetInstanceVersionId);

							MyModel res = (MyModel) response.getEntity();
							List<Object> data = res.getResult();
							JSONObject j1 = null;
							JSONObject json = new JSONObject();
							List<Object> finaldata = new ArrayList<Object>();
							for (int i = 0; i < data.size(); i++) {
								j1 = new JSONObject();
								AssetInstanceVersion aiv = new AssetInstanceVersion();
								aiv = (AssetInstanceVersion) data.get(i);

								j1.put("assetName", aiv.getAssetName());
								j1.put("assetInstanceName", aiv.getAssetInstName());
								j1.put("iconImageName", aiv.getIconImageName());
								j1.put("relationShipName", aiv.getRelName());
								j1.put("relationShipType", aiv.getRelType());
								j1.put("versionable", aiv.getVersionable());
								if(aiv.getVersionable() == true){
									j1.put("versionName", aiv.getVersionName());
								}else{
									j1.put("versionName", "N/A");
								}
								j1.put("sourceAssetInstanceVersionId", aiv.getSrcAssetInstanceVersionId());
																
								finaldata.add(j1);
							}
							json.put("destinationAssetInstanceVersionId", assetInstanceVer.getAssetInstVersionId());
							json.put("totalCount", data.size());
							json.put("result", finaldata);
							json.put("message", res.getMessage());
							json.put("status", res.getStatus());
							json.put("statusCode", res.getStatusCode());
							log.trace("getAllReverseRelationshipsMain || End");

							return Response.status(retStat).entity(json.toString())
									.build();
						}else{

							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;

							log.trace("getAllReverseRelationshipsMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getAllReverseRelationshipsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
			}
			
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAllReverseRelationshipsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVer.getAssetInstVersionId(), userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
				    viewFlag = true;
				    break;
			    }
		    }
		
		    if (viewFlag) {
				long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
				response = relManager.getAllReverseRelationships(assetInstanceVersionId);
				MyModel res = (MyModel) response.getEntity();
				List<Object> data = res.getResult();
				JSONObject j1 = null;
				JSONObject json = new JSONObject();
				List<Object> finaldata = new ArrayList<Object>();
				for (int i = 0; i < data.size(); i++) {
					j1 = new JSONObject();
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv = (AssetInstanceVersion) data.get(i);
					
					j1.put("assetName", aiv.getAssetName());
					j1.put("assetInstanceName", aiv.getAssetInstName());
					j1.put("iconImageName", aiv.getIconImageName());
					j1.put("relationShipName", aiv.getRelName());
					j1.put("relationShipType", aiv.getRelType());
					j1.put("versionable", aiv.getVersionable());
					if(aiv.getVersionable() == true){
						j1.put("versionName", aiv.getVersionName());
					}else{
						j1.put("versionName", "N/A");
					}
					j1.put("sourceAssetInstanceVersionId", aiv.getSrcAssetInstanceVersionId());
										
					finaldata.add(j1);
				}
				json.put("destinationAssetInstanceVersionId", assetInstanceVer.getAssetInstVersionId());
				json.put("totalCount", data.size());
				json.put("result", finaldata);
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("getAllReverseRelationshipsMain || End");
				
				return Response.status(retStat).entity(json.toString())
						.build();
		    } else {
		    	retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			
		} catch (RepoproException e) {
			log.error("getAllReverseRelationshipsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllReverseRelationshipsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllReverseRelationshipsMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllReverseRelationshipsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/***Wrapper function***/
	@POST
	@Encoded
	@Path("/addFavourite")
	public Response addToFavouriteMain(
			@QueryParam("assetInstanceName") String assetInstanceName,
			@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceVersionName") String versionName,
			@HeaderParam("token") String token) {

		if(assetName == null|| assetInstanceName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstanceName = URLDecoder.decode(assetInstanceName, "UTF-8");assetInstanceName = assetInstanceName.trim();
			versionName = URLDecoder.decode(versionName, "UTF-8");versionName = versionName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstanceName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		if(assetName.trim().length()>50|| assetInstanceName.trim().length()>100){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
					.build();
		}
		log.trace("addToFavouriteMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		boolean viewFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (log.isTraceEnabled()) {
				log.trace("addToFavouriteMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			User user = new User();
			if(!userName.equalsIgnoreCase("guest")){
				 user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			} else {
				AssetDao assetDao = new AssetDao();
				AssetInstanceDao assetInstDao = new AssetInstanceDao();
				AssetInstance assetInstance = new AssetInstance();
				assetInstance.setAssetName(assetName);
				assetInstance.setAssetInstName(assetInstanceName);
				assetInstance.setVersionName(versionName);
				AssetDef ad = new AssetDef();
				ad = assetDao.getAssetsByAssetName(assetName, conn);
				if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("addToFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}

				Long assetInstanceId = assetInstDao.getAssetInstIdByName(
						assetInstanceName, ad.getAssetId(), conn);
				if (assetInstanceId == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("addToFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
				FavouritesManager favManager = new FavouritesManager();
				/*User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("addToFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}*/
				
				FavouritesDao favouritesDao = new FavouritesDao();
				AddFavourites myFavourite = favouritesDao.getMyFavourite(assetInstanceId, user.getUserId(), null);
				
				AssetInstanceVersion assetInstanceVer = assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);
				if (assetInstanceVer == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("addToFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
				
				long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();

				List<AssetInstanceVersion> aivs = assetInstanceVersionDao.getAssetInstanceVersions(assetInstanceId,conn);

				for(AssetInstanceVersion aiv : aivs){
					List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
					groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);
					for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
						if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
							viewFlag = true;
							break;
						}
					}

					if (viewFlag) {
						if(myFavourite != null){
							retStat = Status.BAD_REQUEST;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.FAVOURITES_ALREADY_EXISTS;
							retStatScsFlr = Constants.STATUS_FAILURE;

							log.trace("addToFavouriteMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr,
											retMsg)).build();
						}
						response = favManager.addToFavourite(user.getUserId(), assetInstanceId, assetInstanceVersionId);
						MyModel res = (MyModel) response.getEntity();				
						JSONObject json = new JSONObject();
						
						json.put("message", res.getMessage());
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());
						log.trace("addToFavouriteMain || End");
						
						return Response.status(retStat).entity(json.toString())
								.build();
					} else {
						retStat = Status.FORBIDDEN;
						retMsg = Constants.USER_NOT_AUTHORIZED;
						retScsFlr = Constants.FAILURE;
						retStatScsFlr = Constants.FORBIDDEN;
						return Response.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
								.build();
					}
				}

			}
		} catch (RepoproException e) {
			log.error("addToFavouriteMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addToFavouriteMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addToFavouriteMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("addToFavouriteMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@DELETE
	@Encoded
	@Path("/removeFavourite")
	public Response removeFromFavouriteMain(@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetName") String assetName,
			@HeaderParam("token") String token) {
		
		if(assetName == null|| assetInstName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()|| assetInstName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("removeFromFavouriteMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		boolean viewFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();

		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (log.isTraceEnabled()) {
				log.trace("removeFromFavouriteMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			User user = new User();
			if(!userName.equalsIgnoreCase("guest")){
				 user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			} else {
				AssetDao assetDao = new AssetDao();
				AssetInstanceDao assetInstDao = new AssetInstanceDao();
				AssetDef ad = new AssetDef();
				ad = assetDao.getAssetsByAssetName(assetName, conn);
				if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("removeFromFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
				
				Long assetInstId = assetInstDao.getAssetInstIdByName(assetInstName, ad.getAssetId(), conn);
				if (assetInstId == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("removeFromFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
				/*User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("removeFromFavouriteMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}*/
				
				FavouritesDao favouritesDao = new FavouritesDao();
				AddFavourites myFavourite = favouritesDao.getMyFavourite(assetInstId, user.getUserId(), null);
				
				FavouritesManager favManager = new FavouritesManager();
				List<AssetInstanceVersion> aivs = assetInstanceVersionDao.getAssetInstanceVersions(assetInstId,conn);
				
				for(AssetInstanceVersion aiv : aivs){
					List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				    groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);
				    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
					    	viewFlag = true;
						    break;
					    }
				    }

				    if (viewFlag) {
				    	if(myFavourite == null){
							retStat = Status.NOT_FOUND;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.FAVOURITES_DATA_NOT_FOUND;
							retStatScsFlr = Constants.GET_STATUS_FAILURE;

							log.trace("removeFromFavouriteMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr,
											retMsg)).build();
						}
				    	response = favManager.removeFromFavourite(assetInstId, user.getUserId());
				    	MyModel res = (MyModel) response.getEntity();				
						JSONObject json = new JSONObject();
						
						json.put("message", res.getMessage());
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());
						log.trace("removeFromFavouriteMain || End");
						
						return Response.status(retStat).entity(json.toString())
								.build();
				    } else {
				    	retStat = Status.FORBIDDEN;
						retMsg = Constants.USER_NOT_AUTHORIZED;
						retScsFlr = Constants.NOT_AUTHORIZED;
						retStatScsFlr = Constants.FORBIDDEN;
					 	return Response.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
								.build();
				    }
				}
				
			}
		} catch (RepoproException e) {
			log.error("removeFromFavouriteMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("removeFromFavouriteMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("removeFromFavouriteMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("removeFromFavouriteMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/*
	*//**
	 * @method : addInstanceUpdatePropertiesRelationships
	 * @param assetName
	 * @param assetInstName
	 * @param versionName
	 * @param parameterDetails
	 * @param formParams
	 * @param context
	 * @param destinationAsset
	 * @param addRelationshipData
	 * @param removeRelationshipData
	 * @param token
	 * @return
	 *//*
	@PUT
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Path("/addAssetInstanceDetails")
	public Response addInstanceUpdatePropertiesRelationships(@QueryParam("assetName") String assetName,
			//@QueryParam("assetInstanceName") String assetInstName,
			//@QueryParam("assetInstanceVersionName") String versionName,
			@QueryParam("parameterDetails") String parameterDetails,
			FormDataMultiPart formParams, @Context ServletContext context,
			@QueryParam("destinationAsset") String destinationAsset,
			@QueryParam("addRelationshipData") String addRelationshipData,
			@QueryParam("removeRelationshipData") String removeRelationshipData,
			@HeaderParam("token") String token){
		
		if(assetName == null || parameterDetails == null || destinationAsset == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		if(assetName.isEmpty() || parameterDetails.isEmpty() || destinationAsset.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		if((addRelationshipData == null && removeRelationshipData == null)){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
							.build();
		}
		if((addRelationshipData != null && removeRelationshipData != null)){
			if(addRelationshipData.isEmpty() && removeRelationshipData.isEmpty()){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
								.build();
			}
		}
		
		log.trace("addInstanceUpdatePropertiesRelationships || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		assetName = assetName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("addInstanceUpdatePropertiesRelationships : " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("guest")) {
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			AssetInstanceManager aiManager = new AssetInstanceManager();
			
			response = aiManager.addNewAssetInstanceMainHelper(assetName, token, false, conn);
			
			JSONObject json = new JSONObject();
			Response updatePropertiesResponse = null;
			
			Object result =  response.getEntity();
			MyModel model = null;
			MyModelRest modelRest = null;
			if(response.getEntity() instanceof MyModel){
				model = (MyModel) response.getEntity();
			}else if(response.getEntity() instanceof MyModelRest){
				modelRest = (MyModelRest) response.getEntity();
			}
			int statusCode = 0;
			String statusMessage = "";
			if(model !=null ){
				statusCode = response.getStatus();
				statusMessage = model.getMessage();
			}else if(modelRest != null){
				statusCode = response.getStatus();
				statusMessage = modelRest.getMessage();
			}
			
			String assetInstName = "";
			String versionName = "";
			if((statusCode == 200) && (Constants.ASSET_INST_NAME_MATCHED.equalsIgnoreCase(statusMessage))){
				MyModel res = (MyModel) response.getEntity();
				List<Object> data = res.getResult();
		    	
				for (int i = 0; i < data.size(); i++) {
					AssetInstance ai = new AssetInstance();
					ai = (AssetInstance) data.get(i);
					assetInstName = ai.getAssetInstName();
					versionName = ai.getVersionName();
				}
				JSONObject j1 = new JSONObject(res);
				
				updatePropertiesResponse = updateAssetInstancePropertiesRestHelper(assetName, assetInstName, versionName, parameterDetails, formParams, context, token, conn);
			}else {
				return response;
			}
						
			if(updatePropertiesResponse.getEntity() instanceof MyModelRest){
				modelRest = (MyModelRest) updatePropertiesResponse.getEntity();
			}
			if(modelRest != null){
				statusCode = updatePropertiesResponse.getStatus();
				statusMessage = modelRest.getMessage();
				
			}
			Response saveDependencyResponse = null;
			if((statusCode == 200) && Constants.ASSET_INSTANCE_PROPERTIES_UPDATED.equalsIgnoreCase(statusMessage)){
				saveDependencyResponse = saveDependencyHelper(assetName, assetInstName, versionName, destinationAsset, addRelationshipData, removeRelationshipData, token, conn);
			} else {
				return updatePropertiesResponse;
			}
			
			if(saveDependencyResponse.getEntity() instanceof MyModelRest){
				modelRest = (MyModelRest) saveDependencyResponse.getEntity();
			}
			if(modelRest != null){
				statusCode = saveDependencyResponse.getStatus();
				statusMessage = modelRest.getMessage();
			}
			
			if((statusCode == 200) && (Constants.ASSET_INSTANCE_DATA_UPDATED.equalsIgnoreCase(statusMessage))){
				json.put("message", Constants.ASSET_INSTANCE_DETAILS_UPDATED);
				json.put("status", Constants.SUCCESS);
				json.put("statusCode", Constants.GET_STATUS_SUCCESS);
				
				conn.commit();
				return Response.status(retStat).entity(json.toString())
						.build();
			}else{
				return saveDependencyResponse;
			}
					
			
		}catch (RepoproException e) {
			log.error("addInstanceUpdatePropertiesRelationships: SQL Exception addAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}catch (Exception e) {
			log.error("addInstanceUpdatePropertiesRelationships: SQL Exception addAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addInstanceUpdatePropertiesRelationships : " + Constants.LOG_CONNECTION_CLOSE);
			}
			if(conn != null){
				DBConnection.closeDbConnection(conn);
			}
		}

		if (log.isTraceEnabled()) {
			log.trace("addInstanceUpdatePropertiesRelationships || Exit");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}*/
	
	
	
	/*** Wrapper function ***/
	@GET
	@Encoded
	@Path("/getAssetInstance")
	public Response getAssetInstanceForFilterMain(@QueryParam("assetName") String assetName,@QueryParam("start") String from,
			@QueryParam("maxResults") String range,
			@QueryParam("filterCriteria") String filterdatas,@QueryParam("selectParameter") String selectParameter,
			@QueryParam("sortBy") String sortBy,@QueryParam("sortOrder") String sortOrder,
			@HeaderParam("token") String token) {
		if(assetName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try {
			if(from != null) {
				from = URLDecoder.decode(from, "UTF-8");
				from = from.trim();
			}
			if(range != null) {
				range = URLDecoder.decode(range, "UTF-8");
				range = range.trim();
			}
			if(sortBy != null) {
				sortBy = URLDecoder.decode(sortBy, "UTF-8");
				sortBy = sortBy.trim();
			}
			if(sortOrder != null) {
				sortOrder = URLDecoder.decode(sortOrder, "UTF-8");
				sortOrder = sortOrder.trim();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(filterdatas == null){
			if(selectParameter != null || sortBy != null || sortOrder != null || range != null || from != null) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
		}
		
		if(from != null && range != null) {
			if(!from.isEmpty() && !range.isEmpty()) {
				if(from.equals("0") && range.equals("0")) {
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
								.build();
				}
			}
		}
		
		if(from == null) {
			from = "0";
			if(range != null) {
				if(range != "0") {
					return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
							.build();
				}
			}
		}
		if(range == null) {
			range = "0";
			if(from != null) {
				if(from != "0") {
					return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
							.build();
				}
			}
		}
		if(from != null) {
			if(from.trim().isEmpty()) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
		}
		if(range != null) {
			if(range.trim().isEmpty()) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
		}
		if(from != null && !from.trim().isEmpty()) {
			if(!from.matches("[0-9]+")){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						.build();
			}
		}
		
		if(range != null && !range.trim().isEmpty()) {
			if(!range.matches("[0-9]+")){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						.build();
			}
		}
		
		if(sortBy == null) {
			if(sortOrder != null) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					     .build();
			}
		}
		if(sortOrder == null) {
			if(sortBy != null) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					     .build();
			}
		}
		if(sortBy != null) {
			if(sortBy.trim().isEmpty()) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
		}
		if(sortOrder != null) {
			if(sortOrder.trim().isEmpty()) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
		}
		if(sortBy != null) {
			if(!sortBy.trim().isEmpty()) {
				if(!sortBy.equalsIgnoreCase("AssetInstanceName") && !sortBy.equalsIgnoreCase("AssetInstanceVersionId")){
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_SORT_BY_ATTRIBUTE)))
						     .build();
				}
			}
		}
		if(sortOrder != null) {
			if(!sortOrder.trim().isEmpty()) {
				if(!sortOrder.equalsIgnoreCase("ASC") && !sortOrder.equalsIgnoreCase("DESC")){
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_SORTING_ORDER)))
						     .build();
				}
			}
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			if(filterdatas != null){
				filterdatas = URLDecoder.decode(filterdatas, "UTF-8");filterdatas = filterdatas.trim();
			}
			if(selectParameter != null){
				selectParameter = URLDecoder.decode(selectParameter, "UTF-8");selectParameter = selectParameter.trim();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getAssetInstanceForFilterMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response response = null;
		AssetDao assetDao = new AssetDao();
		List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
        CommonUtils commonUtils = new CommonUtils();
		assetName = assetName.trim();
		String userName = "";
		UserDao userDao = new UserDao();
		allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
		List<AssetInstVersionTaxonomy>   assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
		try {
			
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			
			AssetDef asset = assetDao.getAssetsByAssetName(assetName, conn);
			if(asset.getAssetId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous"; 
				if(asset.isGuestflag() == false){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.PUBLIC_ACCESS_BLOCKED_AT_ASSET;
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.UNAUTHORIZED;
					log.trace("getAssetInstanceForFilterMain || End");
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			String taxonomyNames = "";
			String logicalSelect = "";
			String param2Values = "";
			String param1Values = "";
			String assetParamNames = "";
			String operators = "";
			String assetInstanceVersionDescription = "";
			String assetInstanceName = "";
			String assetInstanceVersionId = "";
			
			List<String> parameternames = new ArrayList<String>();
			List<String> operatersList = new ArrayList<String>();
			List<String> parameter1value = new ArrayList<String>();
			List<String> parameter2value = new ArrayList<String>();
			List<String> logicalOperater = new ArrayList<String>();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();

			//Gson gson = new Gson(); // Or use new GsonBuilder().create();
			//FilterData filterData = gson.fromJson(filterdata, FilterData.class); // deserializes json into target2
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, conn);
			if (assetDef.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAssetInstanceForFilterMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			if(filterdatas == null){
					
				response = aivManager.getAssetInstanceBrowseGrid(userName, assetName, assetDef.getAssetId(),0,true);

			}else{
				try{
					ObjectMapper mapper = new ObjectMapper();
					FilterData filterData = new FilterData();

					/*//JSON from String to Object
			//filterData = mapper.readValue(URLDecoder.decode(filterdatas, "UTF-8"), FilterData.class);
			try {
				String pvalues = "";
				JSONObject obj1 = new JSONObject(filterdatas);
				String aivList = obj1.get("parameterData").toString();
				JSONArray aivListArray = new JSONArray(aivList);
				AssetInstanceVersion aiv2 = new AssetInstanceVersion();
				for (int i = 0; i < aivListArray.length(); i++) {
					Iterator itr = aivListArray.getJSONObject(i).keys();
					if(aivListArray.getJSONObject(i).has("parameterValues")){
					 pvalues = aivListArray.getJSONObject(i).get("parameterValues").toString();
						pvalues = pvalues.replace("\"", "\\\"").replace("\\", "\\\\");
					}
				}

				//filterdatas = filterdatas.replace("\"", "\\\"").replace("\\", "\\\\\\");
				System.out.println(filterdatas);
				//mapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_CONTROL_CHARS, true);
				filterData = mapper.readValue(filterdatas, FilterData.class);
			} catch(Exception e) {
				e.printStackTrace();
				throw new Exception(e.getMessage());
			}
					 */

					//URLDecoder.decode(filterdatas, "UTF-8");
					//filterdatas = filterdatas.replace("\"", "\\\"").replace("\\", "\\\\");


					filterData = mapper.readValue(filterdatas, FilterData.class);
					if(filterData.getParameterData()!= null){
						for(ParameterData data:filterData.getParameterData()){
							AssetParamDef paramDetaile = assetDao.getParamIdForAssetAndParamName(assetName, data.getParameterName(), conn);
							if(paramDetaile == null){
								retStat = Status.NOT_FOUND;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_PARAM_NAME;
								retStatScsFlr = Constants.GET_STATUS_FAILURE;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
							if(paramDetaile.getParamTypeId().equals(1L)){
								data.setParameterType("text");
							}else if(paramDetaile.getParamTypeId().equals(2L)){
								data.setParameterType("date");
							}else if(paramDetaile.getParamTypeId().equals(3L)){
								data.setParameterType("file");
							}else if(paramDetaile.getParamTypeId().equals(4L)){
								data.setParameterType("list");
							}else if(paramDetaile.getParamTypeId().equals(7L)){
								data.setParameterType("rich text");
							}else if(paramDetaile.getParamTypeId().equals(9L)){
								data.setParameterType("ldapmapping");
							}
							else{
								retStat = Status.NOT_FOUND;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_PARAM_TYPE;
								retStatScsFlr = Constants.GET_STATUS_FAILURE;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}

							String paramname = data.getParameterName()+"_"+data.getParameterType()+"_";
							parameternames.add(paramname);
							String operaters = data.getOperatorValue();
							operatersList.add(operaters);
							int i=0;

							if(i<filterData.getParameterData().size()-1){
								String logicalope = null;
								logicalope = data.getLogicalOperator();
								if(logicalope!=null){
									logicalOperater.add(logicalope);
								}
							}i++;

							if(data.getParameterType().equalsIgnoreCase("file")){
								String param1val = " ";
								String param2val = " ";
								parameter1value.add(param1val);
								parameter2value.add(param2val);
							}else{
								for(int j=0;j<data.getParameterValues().length;j++){
									String param1val = null;
									String param2val = null;
									if(data.getParameterValues().length==0) {
										
									}
									
									if(data.getParameterValues().length==1){
										param1val = data.getParameterValues()[j];
										param2val = " ";
									}else{
										if(j==0){
											param1val = data.getParameterValues()[0];
										}else{
											param2val = data.getParameterValues()[1];
										}
									}
									if(param1val!=null){
										parameter1value.add(param1val);
									}
									if(param2val!=null){
										parameter2value.add(param2val);
									}
								}
							}
						}
						if(!parameternames.isEmpty()){
							assetParamNames = String.join("~~", parameternames);
						}
						if(!parameter1value.isEmpty()){
							param1Values = String.join("~~", parameter1value);
						}
						if(!parameter2value.isEmpty()){
							param2Values = String.join("~~", parameter2value);
						}
						if(!logicalOperater.isEmpty()){
							logicalSelect = String.join("~~", logicalOperater);
						}
						if(!operatersList.isEmpty()){
							operators = String.join("~~", operatersList);
						}
						if(!parameternames.isEmpty()) {
							if(param1Values.equalsIgnoreCase("")) {
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();
							}
						}
					}//
					if(filterData.getTaxonomyValueList()!= null){
						if(!filterData.getTaxonomyValueList().isEmpty()){
							taxonomyNames = String.join("~~", filterData.getTaxonomyValueList());
						}
					}//
					if(filterData.getAssetInstanceName()!= null){
						assetInstanceName = filterData.getAssetInstanceName();
					}
					if(filterData.getAssetInstanceVersionDescription()!= null){
						assetInstanceVersionDescription = filterData.getAssetInstanceVersionDescription();
					}
					if(filterData.getAssetInstanceVersionId() != null){
						assetInstanceVersionId = filterData.getAssetInstanceVersionId();
					}
				}catch(Exception e){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
								.build();
				
			} 
			List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();
			AssetParamDef paramdetaileddata = new AssetParamDef();
			//AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			String paramvalue = assetParamNames;
			if(!paramvalue.equalsIgnoreCase("")){
				String[] splited = paramvalue.split("~~");
				String[] splitedparametervalues = param1Values.split("~~");
				for (int i = 0; i < splited.length; i++) {
					String paramName = splited[i].split("_")[0];
					paramdetaileddata = assetDao.getAssetParamIdByName(paramName,assetName, conn);
					if(paramdetaileddata!=null){
						AssetParamDef assetParamDef = assetDao.getParamDetailsByParamId(paramdetaileddata.getAssetParamId(),conn);
						if(assetParamDef.isHasStaticValue()){
							retStat = Status.BAD_REQUEST;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.STATIC_VALUES_CANNOT_BE_FILTERED;
							retStatScsFlr = Constants.STATUS_FAILURE;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						assetParamDefList = assetDao.getParamsDetails(userName,asset.getAssetId(),conn);
						boolean paramflag = false;
						List<AssetParamDef> filterList = new ArrayList<AssetParamDef>();
						for(AssetParamDef assetparamdata:assetParamDefList){
							if(paramName.equalsIgnoreCase(assetparamdata.getAssetParamName())){
								paramflag = true;
								if(splited[i].split("_")[1].equalsIgnoreCase("list")){
									if(!assetparamdata.getListTypeParamTypeId().equals(4L)){
										boolean listflag = false;
										if(assetparamdata.getListTypeParamTypeId().equals(1L)){
											filterList = assetDao.getFilterList(assetName,paramName, "CUSTOMLIST",userName,assetparamdata.getMappedAssetId(),conn);
										}else if(assetparamdata.getListTypeParamTypeId().equals(2L)){
											filterList = assetDao.getFilterList(assetName,paramName, "ASSETLIST",userName,assetparamdata.getMappedAssetId(),conn);
										}else if(assetparamdata.getListTypeParamTypeId().equals(3L)){
											filterList = assetDao.getFilterList(assetName,paramName, "NATIVEUSERLIST",userName,assetparamdata.getMappedAssetId(),conn);
										}
										if(paramflag){
											//for(int k=0;k<parameter1value.size();k++){ 
											for(int l = 0; l < filterList.size(); l++){
												if (splitedparametervalues[i].equalsIgnoreCase(filterList.get(l).getParamValue())) {
													listflag = true;
													break;
												}
											}
											if(listflag == false){
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
											//}
										}
									}
								}
								break;
							}
						}
						
						if(paramflag == false){
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						if(!assetParamDef.getTypeName().equalsIgnoreCase(splited[i].split("_")[1])){
							retStat = Status.NOT_FOUND;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.INVALID_PARAM_TYPE;
							retStatScsFlr = Constants.GET_STATUS_FAILURE;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						if(!(splited[i].split("_")[1].equalsIgnoreCase("text")||splited[i].split("_")[1].equalsIgnoreCase("rich text")||splited[i].split("_")[1].equalsIgnoreCase("file")
								||splited[i].split("_")[1].equalsIgnoreCase("list")||splited[i].split("_")[1].equalsIgnoreCase("date")||splited[i].split("_")[1].equalsIgnoreCase("ldapmapping"))){
							retStat = Status.NOT_FOUND;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.INVALID_PARAM_TYPE;
							retStatScsFlr = Constants.GET_STATUS_FAILURE;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
						}
						splited[i] = paramdetaileddata.getAssetParamId() + "_"+splited[i].split("_")[1]+"_";
					}else{
						retStat = Status.NOT_FOUND;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.INVALID_PARAM_NAME;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
					}
				}

				StringBuilder finalparamvalue = new StringBuilder();
				for (int i = 0; i < splited.length; i++) {
					if (i > 0) {
						finalparamvalue.append("~~");
					}
					String param = splited[i];
					finalparamvalue.append(param);
				}
				assetParamNames = finalparamvalue.toString();
			}
			
			

			
			TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
			String taxonomyValue = taxonomyNames;
			if(taxonomyNames.endsWith("/")||taxonomyNames.startsWith("/")){
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
			final List<TaxonomyMaster> tmList = taxonomiesDao.getAllTaxonomiesByParentId(1L,conn);
			if(!taxonomyValue.equalsIgnoreCase("")){
				for(TaxonomyMaster t:tmList){
					recurse(t);
				}
				allTaxs.put((long) 1, tmList);
				allTxs = taxonomiesDao.getAllTaxonomiesByAssetId(asset.getAssetId(), conn);

				for(TaxonomyMaster t:allTxs)
				{
					recurse1(t); 
				}
				Set<Long> hs = new HashSet<Long>();
				hs.addAll(associatedTaxId);
				associatedTaxId.clear();
				associatedTaxId.addAll(hs);
				
				String[] addedTaxIds = new String[]{};
				String[] addedTaxIds1 = new String[]{};
				AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();
				List<Long> idsForTaxon = new ArrayList<Long>();
				if(taxonomyValue.endsWith("~~")||taxonomyValue.startsWith("~~"))
				{
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
				else
				{
					if(taxonomyValue.length() > 0 )
					{
						if(!allTxs.isEmpty())
						{
							addedTaxIds = taxonomyValue.split("~~");
							Boolean flag2 = true;
							for(int t =0; t< addedTaxIds.length && flag2; t++)
							{
								List<TaxonomyMaster> tmpTaxList = tmList;
								addedTaxIds1 = addedTaxIds[t].split("/");

								for(int h =0; h< addedTaxIds1.length; h++)
								{
									Boolean flag = false;
									Long taxNextId = null;
									for(TaxonomyMaster tm:tmpTaxList)
									{
										if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
											flag = true;
											aiatVo.setTaxonomyName(tm.getTaxonomyName());
											taxNextId = tm.getTaxonomyId();
											break;
										}
									}
									if(!flag)
									{
										retStat = Status.NOT_FOUND;
										retScsFlr = Constants.FAILURE;
										retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_SEARCH;
										retStatScsFlr = Constants.GET_STATUS_FAILURE;
										return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
									}
									else
									{
										for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
										{
											if(entry.getKey() ==  taxNextId)
											{ 
												tmpTaxList = entry.getValue();
											}
										}
									}
									if(h == addedTaxIds1.length-1)
									{
										Boolean fl = false;
										Boolean f2 = false;
										if(associatedTaxId.contains(taxNextId)){

										}
										else{
											f2 = true;
										}
										for(Long Id:idsForTaxon)
										{
											if(Id.equals(taxNextId))
											{
												fl = true;
												break;
											}
										}
										if(fl)
										{
											retStat = Status.BAD_REQUEST;
											retScsFlr = Constants.FAILURE;
											retMsg = Constants.DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED;
											retStatScsFlr = Constants.STATUS_FAILURE;
											return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
										}
										if(f2)
										{
											JSONObject json = new JSONObject();

											json.put("message", "No taxonomy is associated with "+assetName+" asset");
											json.put("status", Constants.FAILURE);
											json.put("statusCode", Constants.GET_STATUS_FAILURE);
											retStat = Status.NOT_FOUND;
											return Response.status(retStat).entity(json.toString()).build();
										}
										else
										{
											idsForTaxon.add(taxNextId);
										}
									}
								}
							}
						}
						else{
							JSONObject json = new JSONObject();

							json.put("message", "No taxonomy is associated with "+assetName+" asset");
							json.put("status", Constants.FAILURE);
							json.put("statusCode", Constants.GET_STATUS_FAILURE);
							retStat = Status.NOT_FOUND;
							return Response.status(retStat).entity(json.toString()).build();
						}
					}
					else
					{
						idsForTaxon = Collections.<Long>emptyList();
					}
					aiatVo.setTaxonIds(idsForTaxon);
					assetInstassignList.add(aiatVo);
					List<String> taxonomy = new ArrayList<String>();
					for(int i=0;i<assetInstassignList.size();i++){
						for(int j=0;j<assetInstassignList.get(i).getTaxonIds().size();j++){
							String tax = null;
							tax = assetInstassignList.get(i).getTaxonIds().get(j).toString();
							taxonomy.add(tax);
						}
					}
					StringBuilder finaltaxvalue = new StringBuilder();
					for (int i = 0; i < taxonomy.size(); i++) {
						if (i > 0) {
							finaltaxvalue.append("~~");
						}
						String finaltaxonomy = taxonomy.get(i);
						finaltaxvalue.append(finaltaxonomy);
					}
					taxonomyNames = finaltaxvalue.toString();
				}
			}
			
			
			boolean operatorflag = false;
			String paramdata = assetParamNames;
			if(!paramdata.equalsIgnoreCase("")){
				String[] splitedope = null;
				String[] splited = paramdata.split("~~");
				int j=0;
				for (int i = 0; i < splited.length; i++) {
					String operatorValue = operators;
					if(!operatorValue.equalsIgnoreCase("")){
						splitedope = operatorValue.split("~~");
						String operator = splitedope[j];
						if(splited[i].split("_")[1].equalsIgnoreCase("text") || splited[i].split("_")[1].equalsIgnoreCase("date")){
							if(operator.matches("(?i)=|!=|<|>|<=|>=|Between")){
								splitedope[j] = operator;
								operatorflag = true;
							}else{
								operatorflag = false;
								retStat = Status.BAD_REQUEST;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_OPERATOR;
								retStatScsFlr = Constants.STATUS_FAILURE;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
						}else if(splited[i].split("_")[1].equalsIgnoreCase("file")){
							if(operator.matches("(?i)is empty|is not empty")){
								if(operator.equalsIgnoreCase("is empty")){
									operator = "is null";
								}else{
									operator = "is not null";
								}
								splitedope[j] = operator;
								operatorflag = true;
							}else{
								operatorflag = false;
								retStat = Status.BAD_REQUEST;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_OPERATOR;
								retStatScsFlr = Constants.STATUS_FAILURE;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
						}else if(splited[i].split("_")[1].equalsIgnoreCase("list")){
							if(operator.matches("(?i)=|!=")){
								splitedope[j] = operator;
								operatorflag = true;
							}else{
								operatorflag = false;
								retStat = Status.BAD_REQUEST;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_OPERATOR;
								retStatScsFlr = Constants.STATUS_FAILURE;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
						}else if(splited[i].split("_")[1].equalsIgnoreCase("rich text")){
							if(operator.matches("(?i)=|!=|like|not like")){
								splitedope[j] = operator;
								operatorflag = true;
							}else{
								operatorflag = false;
								retStat = Status.BAD_REQUEST;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_OPERATOR;
								retStatScsFlr = Constants.STATUS_FAILURE;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
						}else if(splited[i].split("_")[1].equalsIgnoreCase("ldapmapping")){
							if(operator.matches("(?i)=|!=|like|not like")){
								splitedope[j] = operator;
								operatorflag = true;
							}else{
								operatorflag = false;
								retStat = Status.BAD_REQUEST;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_OPERATOR;
								retStatScsFlr = Constants.STATUS_FAILURE;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
						}
						j++;
					}
				}
				if(!operatorflag){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_OPERATOR;
					retStatScsFlr = Constants.STATUS_FAILURE;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}

				StringBuilder finaloperatorvalue = new StringBuilder();
				for (int k = 0; k < splitedope.length; k++) {
					if (k > 0) {
						finaloperatorvalue.append("~~");
					}
					String operator = splitedope[k];
					finaloperatorvalue.append(operator);
				}
				operators = finaloperatorvalue.toString();
			}
			
			boolean logicalflag = false;
			String logicalopeValue = logicalSelect;
			if(!logicalopeValue.equalsIgnoreCase("")){
				String[] splitedlogical = logicalopeValue.split("~~");
				for (int j = 0; j < splitedlogical.length; j++) {
					String logicalOperator = splitedlogical[j];
					if(!logicalOperator.matches("(?i)And|or")){
						splitedlogical[j] = logicalOperator;
						logicalflag = true;
					}
				}
				if(logicalflag){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_LOGICAL_OPERATOR;
					retStatScsFlr = Constants.STATUS_FAILURE;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}else{
					StringBuilder finallogicaloperator = new StringBuilder();
					for (int k = 0; k < splitedlogical.length; k++) {
						if (k > 0) {
							finallogicaloperator.append("~~");
						}
						String operator = splitedlogical[k];
						finallogicaloperator.append(operator);
					}
					logicalSelect = finallogicaloperator.toString();
				}
			}
			if(!paramvalue.equalsIgnoreCase("")){
				if(logicalOperater.size() != (parameternames.size()-1)){
					return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
									.build();

				}
			}
			if(!param2Values.isEmpty()){
				String[] splitedparam1 = param1Values.split("~~");
				String[] splitedparam2 = param2Values.split("~~");
				if(splitedparam1.length != splitedparam2.length){
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_PARAM_VALUE;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
				for (int i = 0; i < splitedparam2.length; i++) {
					String param2Value = splitedparam2[i];
					if(param2Value.equalsIgnoreCase("undefined")){
						splitedparam2[i] = " ";
					}else{
						splitedparam2[i] = param2Value;
					}
				}
				StringBuilder finalparam2value = new StringBuilder();
				for (int k = 0; k < splitedparam2.length; k++) {
					if (k > 0) {
						finalparam2value.append("~~");
					}
					String param2value = splitedparam2[k];
					finalparam2value.append(param2value);
				}
				param2Values = finalparam2value.toString();
			}
			
			
			
			if(filterdatas != null){
				if (param2Values.contains("'")||param1Values.contains("'")){
					param1Values = param1Values.replace("'", "\\'");
					param2Values = param2Values.replace("'", "\\'");
				}
				if(assetInstanceVersionId == null){
					assetInstanceVersionId = "";
				}
				if(assetInstanceVersionDescription == null){
					assetInstanceVersionDescription = "";
				}
				if(assetInstanceName == null){
					assetInstanceName = "";
				}

				if(selectParameter == null){//as per show hide
					assetParamNames = URLEncoder.encode(assetParamNames, "UTF-8");
					param1Values = URLEncoder.encode(param1Values, "UTF-8");
					param2Values = URLEncoder.encode(param2Values, "UTF-8");
					operators = URLEncoder.encode(operators, "UTF-8");
					assetName = URLEncoder.encode(assetName, "UTF-8");
					assetInstanceName  = URLEncoder.encode(assetInstanceName, "UTF-8");
					assetInstanceVersionDescription  = URLEncoder.encode(assetInstanceVersionDescription, "UTF-8");

					response = aivManager.getAssetInstanceForFilter(userName, assetName, assetDef.getAssetId(), operators, assetParamNames,
							param1Values, param2Values, logicalSelect, taxonomyNames, Integer.parseInt(from),Integer.parseInt(range),true,sortBy,sortOrder,assetInstanceVersionId,assetInstanceVersionDescription,assetInstanceName,null);
				}else{//as per user specified
					if(selectParameter.isEmpty()) {
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();
					}
					if(selectParameter.endsWith(",") || selectParameter.startsWith(",")){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();
					}
					
					String[] splitSelectParameter = selectParameter.toLowerCase().split(",");
					for(int i=0;i<splitSelectParameter.length;i++) {
						splitSelectParameter[i] = splitSelectParameter[i].trim();
					}
					
					List<String> myList = new ArrayList<String>(Arrays.asList(splitSelectParameter));
					for(String paramName:myList){
						paramName = paramName.trim();
						AssetParamDef paramdetail = assetDao.getAssetParamIdByName(paramName,assetName, conn);
						if(paramdetail == null){
							retStat = Status.NOT_FOUND;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.ASSET_PARAM_NOT_FOUND;
							retStatScsFlr = Constants.GET_STATUS_FAILURE;

							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

						}
					}
					
					selectParameter = String.join(",", myList);
					boolean duplicateFlag = false;
					Set<String> duplicate = new HashSet<String>();
					duplicate.addAll(myList);
					if(duplicate.size()<myList.size()) {
						duplicateFlag = true;
					}
					if(duplicateFlag) {
						retStat = Status.BAD_REQUEST;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.ASSET_PARAM_NAME_ALREADY_EXISTS;
						retStatScsFlr = Constants.STATUS_FAILURE;
						return Response.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}
					
					assetParamNames = URLEncoder.encode(assetParamNames, "UTF-8");
					param1Values = URLEncoder.encode(param1Values, "UTF-8");
					param2Values = URLEncoder.encode(param2Values, "UTF-8");
					operators = URLEncoder.encode(operators, "UTF-8");
					assetName = URLEncoder.encode(assetName, "UTF-8");
					selectParameter = URLEncoder.encode(selectParameter, "UTF-8");
					assetInstanceName  = URLEncoder.encode(assetInstanceName, "UTF-8");
					assetInstanceVersionDescription  = URLEncoder.encode(assetInstanceVersionDescription, "UTF-8");

					response = aivManager.getAssetInstanceForFilter(userName, assetName, assetDef.getAssetId(), operators, assetParamNames,
							param1Values, param2Values, logicalSelect, taxonomyNames, Integer.parseInt(from),Integer.parseInt(range),true,sortBy,sortOrder,assetInstanceVersionId,assetInstanceVersionDescription,assetInstanceName,selectParameter);
				}
			}
			}
			assetName = URLDecoder.decode(assetName, "UTF-8");
			
			MyModel res = (MyModel) response.getEntity();
			if(res.getMessage().equals(Constants.ASSET_INSTANCE_DATA_NOT_FOUND)){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
	        List<Object> data = res.getResult();
	        JSONObject j1 = null;
	        AssetInstanceVersionDao aivDao = new AssetInstanceVersionDao();
	        JSONObject json = new JSONObject();
	        List<Object> finaldata = new ArrayList<Object>();
	        if(filterdatas != null) {
	        	if(range != null) {
	        		if(range != "0") {
	        			Double cuurentPage = (Double.parseDouble(from)+1.0)/Double.parseDouble(range);
	        			if(cuurentPage<1) {
	        				json.put("currentPage", "1");
	        			}else {
	        				json.put("currentPage", Math.ceil(cuurentPage));
	        			}
	        		}
	        	}
	        }
	        for (int i = 0; i < data.size(); i++) {
	        	j1 = new JSONObject();
	        	AssetInstance ai = new AssetInstance();
	        	ai = (AssetInstance) data.get(i);
	        	if(filterdatas != null) {
	        		json.put("TotalResult", ai.getResultTotalCount());
	        		if(range != null) {
	        			if(range != "0") {
	        				Double totalPages = (ai.getResultTotalCount())/Double.parseDouble(range);
	        				json.put("TotalNoOfPages", Math.ceil(totalPages));
	        			}
	        		}
	        	}
	        	
	        	j1.put("assetInstanceName", ai.getAssetInstName());
	        	j1.put("assetName", assetName);
	        	j1.put("description", ai.getDescription());
	        	j1.put("iconImageName", ai.getIconImageName());
	        	j1.put("owner", ai.getOwner());
	        	j1.put("assetInstanceVersionId",ai.getAssetInstVersionId());
	        	
	        	if(ai.isVersionable()){
		        	j1.put("versionName", ai.getVersionName());
	        	}else{
		        	j1.put("versionName", "N/A");

	        	}
	        	
	        	 AssetInstanceVersion aiv5 = aivDao.getAssetinstDetails(assetName, ai.getAssetInstName(), ai.getVersionName(), null);
	        	 
	        	 if(aiv5 == null){
	        		 retStat = Status.NOT_FOUND;
	        		 retScsFlr = Constants.FAILURE;
	        		 retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
	        		 retStatScsFlr = Constants.GET_STATUS_FAILURE;

	        		 return Response
	        				 .status(retStat)
	        				 .entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

	        	 }
	        	 
	        	/* // show more parameters 
	        	Response res11 = aivManager.getParametersDetailsForAssetInstanceVersion(userName, assetName, aiv5.getAssetId(), aiv5.getAssetInstVersionId());
	        	MyModel res1 = (MyModel) res11.getEntity();
		       
		        
		        TreeMap<String, String> showmoreparam = (TreeMap<String, String>) res1.getParamValues();
	        	
		        */
	        	Map<String, String> paramNameWithValues = ai.getParamNameWithValues();
	        	TreeMap <String,String> paramNameWithValuesFinal = new TreeMap<String, String>();
	        	
	        	if(paramNameWithValues != null){
	        		for (Map.Entry<String,String> entry : paramNameWithValues.entrySet()) {

	        			String finalValue = "";
	        			String paramNameArray[] = entry.getKey().split("`@`");
	        			
	        			if(entry.getValue() != null) {
	        				
	        				if(entry.getValue().indexOf("^^DA^^") != -1){

	        					String arr1[] = entry.getValue().split("~");
	        					//String[] paramname = arr1[3].split("`@`");
	        					String derivedAttribute = aivDao.getDerivedAttributeValues(userName, arr1[1], assetName, arr1[3],conn);
	        					String[] data1	 =  derivedAttribute.split("`!!`");
	        					String newValue = "";
	        					if(data1[0].equalsIgnoreCase("0"))
	        						if(data1.length == 2){
	        							finalValue = data1[1].trim();
	        						}else{
	        							finalValue = ""; 
	        						}
	        					else
	        						finalValue = data1[0].trim();

	        					/* if(finalValue.contains("`~`")) {
	        				 String[] val = finalValue.split("`~`");
	        				 for(String str : val) {
	        					 if(str.contains("~~")){
	        						 newValue += str.replaceAll("~~", ",")+",";
	        					 }
	        				 }  newValue = newValue.substring(0, newValue.length()-1); // remove last character ','
	        				 finalValue = newValue;
	        			 }else{
	        				 if(finalValue.contains("~~")){
	        					 newValue += finalValue.replaceAll("~~", ",");
	        					 finalValue = newValue;
        					 }  
	        			 }
	        					 */

	        					if(finalValue.contains("`~`")) {
	        						newValue += finalValue.replaceAll("`~`", ",");
	        						finalValue = newValue;
	        					}
	        					if(finalValue.contains("~~")){
	        						String newValue1 = "";
	        						newValue1 += finalValue.replaceAll("~~", ",");
	        						finalValue = newValue1;
	        					}
	        					if(finalValue.contains("``")){
	        						String newValue1 = "";
	        						newValue1 += finalValue.replaceAll("``", "|");
	        						finalValue = newValue1;
	        					}
	        				}else if(entry.getValue().indexOf("^^DC^^") != -1){

	        					String[] arr2 = entry.getValue().split("~");
	        					//String[] paramname = arr2[3].split("`@`");
	        					finalValue = aivDao.getDerivedComputationValues(userName, arr2[1], assetName, arr2[3], conn);

	        				}else if(entry.getValue().indexOf("^^AC^^") != -1) {
	        					String arr1[] = entry.getValue().split("~");
	        					//String[] paramname = arr1[3].split("`@`");
	        					String derivedAttribute = aivDao.getDerivedAttributeForAssetListValues(userName, arr1[1], assetName, arr1[3],conn);
	        					String[] data1	 =  derivedAttribute.split("`!!`");
	        					String newValue = "";
	        					if(data1[0].equalsIgnoreCase("0")) {
	        						if(data1.length == 2){
	        							finalValue = data1[1].trim();
	        						}else{
	        							finalValue = ""; 
	        						}
	        					}else {
	        						finalValue = data1[0].trim();
	        					}

	        					if(finalValue.contains("`~`")) {
	        						newValue += finalValue.replaceAll("`~`", ",");
	        						finalValue = newValue;
	        					}
	        					if(finalValue.contains("~~")){
	        						String newValue1 = "";
	        						newValue1 += finalValue.replaceAll("~~", ",");
	        						finalValue = newValue1;
	        					}
	        					if(finalValue.contains("``")){
	        						String newValue1 = "";
	        						newValue1 += finalValue.replaceAll("``", "|");
	        						finalValue = newValue1;
	        					}
	        				}
	        				else{
	        					//String[] arr3 = entry.getValue().split("`@`");
	        					String check = entry.getValue();
	        					if(check.contains("~~")){
	        						if(check.contains("``")){
	        							finalValue += check.replaceAll("``", "|").replaceAll("~~", ",");
	        						}else {
	        							finalValue += check.replaceAll("~~", ",");
	        						}
	        					}else {
	        						finalValue = check;
	        					}
	        				}
	        			}else{
	        				finalValue = entry.getValue();
	        			}
	        			paramNameWithValuesFinal.put(paramNameArray[0], finalValue); 

	        		}
	        	}
	        	
	        	if(selectParameter == null || filterdatas == null) {
	        		// show more parameters 
	        		Response res11 = aivManager.getParametersDetailsForAssetInstanceVersion(userName, assetName, aiv5.getAssetId(), aiv5.getAssetInstVersionId(),true);
	        		MyModel res1 = (MyModel) res11.getEntity();


	        		TreeMap<String, String> showmoreparam = (TreeMap<String, String>) res1.getParamValues();


	        		if(showmoreparam != null){
	        			for (Map.Entry<String,String> entry1 : showmoreparam.entrySet()) {

	        				String finalValue = "";

	        				String paramNameArray[] = entry1.getKey().split("`@`");
	        				
	        				if(entry1.getValue() != null) {
	        					if(entry1.getValue().indexOf("^^DA^^") != -1){

	        						String arr1[] = entry1.getValue().split("~");
	        						//String[] paramname = arr1[3].split("`@`");
	        						String derivedAttribute = aivDao.getDerivedAttributeValues(userName, arr1[1], assetName, arr1[3],conn);
	        						String[] data1	 =  derivedAttribute.split("`!!`");
	        						String newValue = "";
	        						if(data1[0].equalsIgnoreCase("0"))
	        							if(data1.length == 2){
	        								finalValue = data1[1].trim();
	        							}else{
	        								finalValue = ""; 
	        							}
	        						else
	        							finalValue = data1[0].trim();

	        						if(finalValue.contains("``")){
	        							String newValue1 = "";
	        							newValue1 += finalValue.replaceAll("``", "|");
	        							finalValue = newValue1;
	        						}

	        						if(finalValue.contains("`~`")) {
	        							newValue += finalValue.replaceAll("`~`", ",");
	        							finalValue = newValue;
	        						}
	        						if(finalValue.contains("~~")){
	        							String newValue1 = "";
	        							newValue1 += finalValue.replaceAll("~~", ",");
	        							finalValue = newValue1;
	        						}
	        					}else if(entry1.getValue().indexOf("^^DC^^") != -1){

	        						String[] arr2 = entry1.getValue().split("~");
	        						//String[] paramname = arr2[3].split("`@`");
	        						finalValue = aivDao.getDerivedComputationValues(userName, arr2[1], assetName, arr2[3], conn);

	        					}else if(entry1.getValue().indexOf("^^AC^^") != -1) {
	        						String arr1[] = entry1.getValue().split("~");
	        						//String[] paramname = arr1[3].split("`@`");
	        						String derivedAttribute = aivDao.getDerivedAttributeForAssetListValues(userName, arr1[1], assetName, arr1[3],conn);
	        						String[] data1	 =  derivedAttribute.split("`!!`");
	        						String newValue = "";
	        						if(data1[0].equalsIgnoreCase("0")) {
	        							if(data1.length == 2){
	        								finalValue = data1[1].trim();
	        							}else{
	        								finalValue = ""; 
	        							}
	        						}else {
	        							finalValue = data1[0].trim();
	        						}

	        						if(finalValue.contains("`~`")) {
	        							newValue += finalValue.replaceAll("`~`", ",");
	        							finalValue = newValue;
	        						}
	        						if(finalValue.contains("~~")){
	        							String newValue1 = "";
	        							newValue1 += finalValue.replaceAll("~~", ",");
	        							finalValue = newValue1;
	        						}
	        						if(finalValue.contains("``")){
	        							String newValue1 = "";
	        							newValue1 += finalValue.replaceAll("``", "|");
	        							finalValue = newValue1;
	        						}
	        					}else{
	        						//String[] test = entry1.getValue().split("`@`");
	        						if(paramNameArray[1].equalsIgnoreCase("5")){

	        							String[] data1	 =  entry1.getValue().split("`!!`");
	        							String newValue = "";
	        							if(data1[0].equalsIgnoreCase("0"))
	        								if(data1.length == 2){
	        									finalValue = data1[1].trim();
	        								}else{
	        									finalValue = ""; 
	        								}

	        							else
	        								finalValue = data1[0].trim();

	        							if(finalValue.contains("``")){
	        								String newValue1 = "";
	        								newValue1 += finalValue.replaceAll("``", "|");
	        								finalValue = newValue1;
	        							}
	        							if(finalValue.contains("`~`")) {
	        								newValue += finalValue.replaceAll("`~`", ",");
	        								finalValue = newValue;
	        							}
	        							if(finalValue.contains("~~")){
	        								String newValue1 = "";
	        								newValue1 += finalValue.replaceAll("~~", ",");
	        								finalValue = newValue1;
	        							}
	        						}else if(paramNameArray[1].equalsIgnoreCase("8")) {
	        							String[] data1 = entry1.getValue().split("`!!`");
	        							String newValue = "";
	        							if(data1[0].equalsIgnoreCase("0")) {
	        								if(data1.length == 2){
	        									finalValue = data1[1].trim();
	        								}else{
	        									finalValue = ""; 
	        								}
	        							}else {
	        								finalValue = data1[0].trim();
	        							}

	        							if(finalValue.contains("``")){
	        								String newValue1 = "";
	        								newValue1 += finalValue.replaceAll("``", "|");
	        								finalValue = newValue1;
	        							}
	        							if(finalValue.contains("`~`")) {
	        								newValue += finalValue.replaceAll("`~`", ",");
	        								finalValue = newValue;
	        							}
	        							if(finalValue.contains("~~")){
	        								String newValue1 = "";
	        								newValue1 += finalValue.replaceAll("~~", ",");
	        								finalValue = newValue1;
	        							}
	        						}else{
	        							//String[] arr3 = entry1.getValue().split("`@`");
	        							String check = entry1.getValue();
	        							if(check.contains("~~")){
	        								if(check.contains("``")){
	        									finalValue += check.replaceAll("``", "|").replaceAll("~~", ",");
	        								}else{
	        									finalValue += check.replaceAll("~~", ",");
	        								}
	        							}else if(check.contains("``")){
	        								finalValue += check.replaceAll("``", "|");
	        							}else {
	        								finalValue = check;
	        							}
	        						}
	        					}
	        				}else {
	        					finalValue = entry1.getValue();
	        				}
	        				paramNameWithValuesFinal.put(paramNameArray[0], finalValue); 
	        			}
	        		}
	        	}
	        	j1.put("parameterData", paramNameWithValuesFinal);
	        	
	        	finaldata.add(j1);
	        }
	        json.put("result", finaldata);
	        json.put("message", res.getMessage());
	        json.put("status", res.getStatus());
	        json.put("statusCode", res.getStatusCode());

	        log.trace("getAssetInstanceForFilterMain || End");
	        return Response.status(retStat).entity(json.toString())
	          .build();
			/*
			log.trace("getAssetInstanceForFilterMain || End");
			return response;*/
			
		} catch (RepoproException e) {
			log.error("getAssetInstanceForFilterMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("getAssetInstanceForFilterMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAssetInstanceForFilterMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/**
	 * @method saveInstanceGroupsAccess
	 * @param instanceGroupAccess
	 * @return success response
	 */
	@PUT
	@Path("/saveInstanceGroupsAccess")
	public Response saveInstanceGroupsAccess(@QueryParam("instanceGroupAccess") String instanceGroupAccess,@HeaderParam("token") String token) {
		if(instanceGroupAccess == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		
		if(instanceGroupAccess.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		if (log.isTraceEnabled()) {
			log.trace("saveInstanceGroupsAccess || Begin " + instanceGroupAccess.toString());
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<GroupAssetAccess> groupAccessList = new ArrayList<GroupAssetAccess>();
		String userName = "";
		UserDao userDao = new UserDao();
		CommonUtils commonUtils = new CommonUtils();
		boolean adminFlag = false;
		try {
			
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (log.isTraceEnabled()) {
				log.trace("saveInstanceGroupsAccess || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			User user = new User();
			if(!userName.equalsIgnoreCase("guest")){
				user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
			
			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
			adminFlag = dao.findAdminRightsByUserName(userName, conn);
			if(adminFlag){

				GroupDao groupdao = new GroupDao();
				AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
				JSONArray groupaccess = new JSONArray(instanceGroupAccess);
				GroupAssetAccess gaa = null;
				AssetInstance assetInstance = null; 

				for (int i = 0; i < groupaccess.length(); i++) {

					gaa = new GroupAssetAccess();
					assetInstance = new AssetInstance(); 

					if(groupaccess.getJSONObject(i).has("assetName")){
						assetInstance.setAssetName(groupaccess.getJSONObject(i).getString("assetName"));
					}else{
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();

					}
					if(groupaccess.getJSONObject(i).has("assetInstanceName")){
						assetInstance.setAssetInstName(groupaccess.getJSONObject(i).getString("assetInstanceName"));
					}else{
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();

					}
					if(groupaccess.getJSONObject(i).has("versionName")){
						assetInstance.setVersionName(groupaccess.getJSONObject(i).getString("versionName"));
					}else{
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();

					}
					AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);
					if(aiv == null){
						retStat = Status.NOT_FOUND;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;
						log.trace("saveInstanceGroupsAccess || End");
						return Response
								.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr,retMsg)).build();
					}

					gaa.setAssetInstversionId(aiv.getAssetInstVersionId());
					if(groupaccess.getJSONObject(i).has("groupName")){
						gaa.setGroupName(groupaccess.getJSONObject(i).getString("groupName"));
					}else{
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();

					}
					int groupId = groupdao.getGroupIdByGroupName(gaa.getGroupName(),conn);
					if(groupId == 0){  
						retStat = Status.NOT_FOUND;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.GROUP_DATA_NOT_FOUND;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;
						return Response
								.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}

					gaa.setGroupId(Long.valueOf(groupId));
					if(groupaccess.getJSONObject(i).has("editAccess")){
						try{
							gaa.setEditAccess(groupaccess.getJSONObject(i).getLong("editAccess"));
							if(gaa.getEditAccess() != 0 && gaa.getEditAccess() != 1){
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
												.build();
							}
						}catch(Exception e){
							return Response
									.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
											.build();
						}
					}
					if(groupaccess.getJSONObject(i).has("deleteAccess")){
						try{
							gaa.setDeleteAccess(groupaccess.getJSONObject(i).getLong("deleteAccess"));
							if(gaa.getDeleteAccess() != 0 && gaa.getDeleteAccess() != 1){
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
												.build();
							}
						}catch(Exception e){
							return Response
									.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
											.build();

						}
					}
					if(groupaccess.getJSONObject(i).has("viewAccess")){
						try{
							gaa.setViewAccess(groupaccess.getJSONObject(i).getLong("viewAccess"));
							if(gaa.getViewAccess() != 0 && gaa.getViewAccess() != 1){
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
												.build();
							}
						}catch(Exception e){
							return Response
									.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
											.build();

						}
					}
					if(gaa.getEditAccess() == 1){
						if(gaa.getViewAccess() == 0){
							return Response
									.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
											.build();

						
						}
					}
					if(gaa.getDeleteAccess() == 1){
						if(gaa.getViewAccess() == 0){
							return Response
									.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
											.build();

						
						}
					}
					groupAccessList.add(gaa);
				}


				if (log.isTraceEnabled()) {
					log.trace("saveInstanceGroupsAccess || dao method called : deleteGroupsAccessAISubmit()");
				}
				dao.deleteGroupsAccessAISubmit(groupAccessList, conn);


				retMsg = Constants.GROUP_ACCESS_SAVED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

				conn.commit();
			}
			
			log.info("saveInstanceGroupsAccess || group access saved");

		} catch (RepoproException e) {
			log.error("saveInstanceGroupsAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("saveInstanceGroupsAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("saveInstanceGroupsAccess || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("saveInstanceGroupsAccess || end");
		}
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/**
	 * @method viewInstanceGroupsAccess
	 * @param assetName
	 * @param assetInstanceName
	 * @param versionName
	 * @param token
	 * @return success response 
	 */
	@GET
	@Path("/viewInstanceGroupsAccess")
	public Response viewInstanceGroupsAccess(
			@QueryParam("assetName") String assetName,@QueryParam("assetInstanceName") String assetInstanceName,
			@QueryParam("versionName") String versionName,@HeaderParam("token") String token) {

		if (log.isTraceEnabled()) {
			log.trace("viewInstanceGroupsAccess || Begin with assetInstanceName :"+assetInstanceName+
					" assetName : "+assetName+" versionName : "+versionName);
		}
		if(assetName == null || versionName == null || assetInstanceName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		
		if(assetName.isEmpty() || versionName.isEmpty() || assetInstanceName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<GroupAssetAccess> aivGroupAccessList = new ArrayList<GroupAssetAccess>();
		AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		String userName = "";
		UserDao userDao = new UserDao();
		CommonUtils commonUtils = new CommonUtils();
		boolean adminFlag = false;
		assetName = assetName.trim();
		versionName = versionName.trim();
		assetInstanceName = assetInstanceName.trim();
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			User user = new User();
			if(!userName.equalsIgnoreCase("guest")){
				user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			if (log.isTraceEnabled()) {
				log.trace("viewInstanceGroupsAccess || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
			adminFlag = dao.findAdminRightsByUserName(userName, conn);
			if(adminFlag){

				AssetInstance assetInstance = new AssetInstance(); 
				assetInstance.setAssetName(assetName);
				assetInstance.setAssetInstName(assetInstanceName);
				assetInstance.setVersionName(versionName);
				AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);
				if(aiv == null){
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("viewInstanceGroupsAccess || End");
					return Response
							.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr,retMsg)).build();
				}
				Response response = assetInstanceVersionManager.viewGroupsWithSingleAIAccess(userName, aiv.getAssetInstVersionId());

				MyModel res = (MyModel) response.getEntity();
				List<Object> data = res.getResult();
				JSONObject json = new JSONObject();
				JSONObject j1 = null;
				List<Object> finaldata = new ArrayList<Object>();
				for (int i = 0; i < data.size(); i++) {
					j1 = new JSONObject();
					GroupAssetAccess aivga = new GroupAssetAccess();
					aivga = (GroupAssetAccess) data.get(i);

					j1.put("groupName", aivga.getGroupName());
					j1.put("editAccess", aivga.getEditAccess());
					j1.put("viewAccess", aivga.getViewAccess());
					j1.put("deleteAccess", aivga.getDeleteAccess());
					finaldata.add(j1);
				}
				json.put("result", finaldata);
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());

				return Response.status(Status.OK).entity(json.toString()).build();
				
			}else{

				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			
			}
		} catch (RepoproException e) {
			log.error("viewInstanceGroupsAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("viewInstanceGroupsAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("viewInstanceGroupsAccess || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(aivGroupAccessList)))
				.build();
	}
	
	
	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/getDerivedAttributeForAssetList")
	public Response getDerivedAttributeForAssetListValuesMain(
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetVersionName, 
			@QueryParam("assetName") String assetName,
			@QueryParam("parameterName") String parameterName,
			@HeaderParam("token") String token) throws RepoproException {
		
		if(assetInstName == null || assetVersionName == null|| assetName == null || parameterName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");assetInstName = assetInstName.trim();
			assetVersionName = URLDecoder.decode(assetVersionName, "UTF-8");assetVersionName = assetVersionName.trim();
			parameterName = URLDecoder.decode(parameterName, "UTF-8");parameterName = parameterName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetInstName.isEmpty() || assetVersionName.isEmpty()|| assetName.isEmpty() || parameterName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getDerivedAttributeForAssetListValuesMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			
			AssetDao ad = new AssetDao();
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			if (log.isTraceEnabled()) {
				log.trace("getDerivedAttributeValuesMain || dao method called : getAssetinstDetails ");
			}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getDerivedAttributeForAssetListValuesMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			AssetDao assetDao = new AssetDao();
			AssetParamDef paramCheck = assetDao.getParamIdForAssetAndParamName(assetName,parameterName,null);
			if(paramCheck != null){
				if(paramCheck.getParamTypeId()!= 8){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_DATA;
					retStatScsFlr = Constants.STATUS_FAILURE;
					log.trace("getDerivedAttributeForAssetListValuesMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}else{
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.INVALID_DATA;
				retStatScsFlr = Constants.STATUS_FAILURE;

				log.trace("getDerivedAttributeForAssetListValuesMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			if(userName.equalsIgnoreCase("roleAnonymous")) {
				AssetInstanceDao assetInstDao = new AssetInstanceDao(); 
				List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
				AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);

				if(assetDef.isGuestflag() == true){
					assetInsatnceList =	assetInstDao.getAssetInstancePublicAccessState(assetInstanceVer.getAssetInstanceId() ,null);
					for(AssetInstance ai : assetInsatnceList){
						if(ai.isPublicAccess() == true){
							AssetParamDef apd  =  ad.getAssetParamAccess(userName,parameterName,assetName,null);

							if(apd!=null && apd.getAssetParamId() != null){
								assetName = URLEncoder.encode(assetName, "UTF-8");
								response = aivManager.getDerivedAttributeForAssetListValues(userName, assetInstanceVer.getAssetInstVersionId().toString(), assetName, parameterName);

								MyModel res = (MyModel) response.getEntity();
								List<Object> data = res.getResult();
								JSONObject j1 = null;
								JSONObject json = new JSONObject();
								List<Object> finaldata = new ArrayList<Object>();
								for (int i = 0; i < data.size(); i++) {
									j1 = new JSONObject();

									//spliting value to remove count
									String datas = data.toString();
									String[] data1	 =  datas.split("`!!`");
									String Value = data1[1].toString();
									if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
										Value = Value.substring(0, Value.length() - 1);
									}
									if(Value.contains("``")){
										Value = Value.replaceAll("``", "|");
									}
									if(Value.contains("~~")){
										Value = Value.replaceAll("~~", ",");
									}

									if(Value.contains("`~`")){

										List<String> strArray = new ArrayList<String>();

										strArray= (Arrays.asList(Value.split("`~`")));

										j1.put("value", strArray);
									}else{
										j1.put("value", Value);
									}
									finaldata.add(j1);
								}
								json.put("result", finaldata);
								json.put("message", res.getMessage());
								json.put("status", res.getStatus());
								json.put("statusCode", res.getStatusCode());

								log.trace("getDerivedAttributeForAssetListValuesMain || End");
								return Response.status(retStat).entity(json.toString())
										.build();
							}else{
								retStat = Status.FORBIDDEN;
								retMsg = Constants.USER_NOT_AUTHORIZED;
								retScsFlr = Constants.NOT_AUTHORIZED;
								retStatScsFlr = Constants.FORBIDDEN;
								log.trace("getDerivedAttributeForAssetListValuesMain || End");
								return Response
										.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}

						}else{
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;
							log.trace("getDerivedAttributeForAssetListValuesMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getDerivedAttributeValuesMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}else {
				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				Boolean viewFlag = false;

				if (log.isTraceEnabled()) {
					log.trace("getDerivedAttributeForAssetListValuesMain || dao method called : retAivAccessRights ");
				}
				groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVer.getAssetInstVersionId(), userName, null);

				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
						viewFlag = true;
						break;
					}
				}

				if (viewFlag) {
					if(!userName.equalsIgnoreCase("admin")){
						AssetParamDef apd  =  ad.getAssetParamAccess(userName,parameterName,assetName,null);

						if(apd!=null && apd.getAssetParamId() != null){
							assetName = URLEncoder.encode(assetName, "UTF-8");
							response = aivManager.getDerivedAttributeForAssetListValues(userName, assetInstanceVer.getAssetInstVersionId().toString(), assetName, parameterName);					
							MyModel res = (MyModel) response.getEntity();
							List<Object> data = res.getResult();
							JSONObject j1 = null;
							JSONObject json = new JSONObject();
							List<Object> finaldata = new ArrayList<Object>();
							for (int i = 0; i < data.size(); i++) {
								j1 = new JSONObject();
								//spliting value to remove count
								String datas = data.toString();
								String[] data1	 =  datas.split("`!!`");
								String Value = data1[1].toString();
								if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
									Value = Value.substring(0, Value.length() - 1);
								}
								if(Value.contains("``")){
									Value = Value.replaceAll("``", "|");
								}
								if(Value.contains("~~")){
									Value = Value.replaceAll("~~", ",");
								}

								if(Value.contains("`~`")){

									List<String> strArray = new ArrayList<String>();

									strArray= (Arrays.asList(Value.split("`~`")));

									j1.put("value", strArray);
								}else{
									j1.put("value", Value);
								}

								finaldata.add(j1);
							}
							json.put("result", finaldata);
							json.put("message", res.getMessage());
							json.put("status", res.getStatus());
							json.put("statusCode", res.getStatusCode());

							log.trace("getDerivedAttributeForAssetListValuesMain || End");
							return Response.status(retStat).entity(json.toString())
									.build();

						} else {
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;
							log.trace("getDerivedAttributeForAssetListValuesMain || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					} else {
						assetName = URLEncoder.encode(assetName, "UTF-8");
						response = aivManager.getDerivedAttributeForAssetListValues(userName, assetInstanceVer.getAssetInstVersionId().toString(),
								assetName, parameterName);

						MyModel res = (MyModel) response.getEntity();
						List<Object> data = res.getResult();
						JSONObject j1 = null;
						JSONObject json = new JSONObject();
						List<Object> finaldata = new ArrayList<Object>();
						for (int i = 0; i < data.size(); i++) {
							j1 = new JSONObject();

							//spliting value to remove count
							String datas = data.toString();
							String[] data1	 =  datas.split("`!!`");
							String Value = data1[1].toString();
							if (Value != null && Value.length() > 0 && Value.charAt(Value.length() - 1) == ']') {
								Value = Value.substring(0, Value.length() - 1);
							}
							if(Value.contains("``")){
								Value = Value.replaceAll("``", "|");
							}
							if(Value.contains("~~")){
								Value = Value.replaceAll("~~", ",");
							}

							if(Value.contains("`~`")){

								List<String> strArray = new ArrayList<String>();

								strArray= (Arrays.asList(Value.split("`~`")));

								j1.put("value", strArray);
							}else{
								j1.put("value", Value);
							}

							finaldata.add(j1);
						}
						json.put("result", finaldata);
						json.put("message", res.getMessage());
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());

						log.trace("getDerivedAttributeForAssetListValuesMain || End");
						return Response.status(retStat).entity(json.toString())
								.build();

					}
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("getDerivedAttributeForAssetListValuesMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
						
			
		} catch (RepoproException e) {
			log.error("getDerivedAttributeForAssetListValuesMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getDerivedAttributeForAssetListValuesMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 
		log.trace("getDerivedAttributeForAssetListValuesMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
}
