package com.thbs.repopro.assetinstanceversion;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import com.thbs.repopro.dto.AssetInstanceVersionRating;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class RatingDao {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	/**
	 * @method : getAllRating
	 * @param assetInstanceVersionId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetInstanceVersionRating> getAllRating(Long assetInstanceVersionId,
			Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllRating || Begin with assetInstanceVersionId : "+ assetInstanceVersionId);
		}
		
		List<AssetInstanceVersionRating> ratingList = new ArrayList<AssetInstanceVersionRating>();
		AssetInstanceVersionRating aivr = null;
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllRating || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_RATINGS));
			
			pstmt.setLong(Constants.ONE, assetInstanceVersionId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllRating || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_RATINGS));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				aivr = new AssetInstanceVersionRating();
				aivr.setRatingId(rs.getLong("rating_id"));
				aivr.setAssetInstanceVersionId(rs.getLong("asset_instance_version_id"));
				aivr.setRating(rs.getInt("rating"));
				aivr.setUsername(rs.getString("user_name"));
				aivr.setDate(rs.getTimestamp("date"));
				aivr.setRatingDescription(rs.getString("ratingDescription"));
				aivr.setUserId(rs.getLong("user_id"));
				aivr.setImageName(rs.getString("image_name"));
				aivr.setEncryptImage(rs.getInt("encrypt_image"));
				ratingList.add(aivr);
				
				if(log.isTraceEnabled()){
					log.debug("getAllRating || "+ aivr.toString());
				}
				
			}
			if(log.isDebugEnabled()){
				log.debug("getAllRating || "+ ratingList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getAllRating || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.RATINGS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllRating || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllRating || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllRating || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getAllRating || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try{
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			}catch(SQLException ex){
				ex.printStackTrace();
			}
		}
		
		if(log.isTraceEnabled()){
			log.trace("getAllRating || End");
		}
		return ratingList;
	}
	
	/**
	 * @method : retCountOfAssetInstancesVersionRating
	 * @param assetInstanceVersionId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public int retCountOfAssetInstancesVersionRating(Long assetInstanceVersionId, String username, 
			Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("retCountOfAssetInstancesVersionRating || Begin with assetInstanceVersionId : " 
						+ assetInstanceVersionId +" \t username : "+username);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int ratingCount = 0;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("retCountOfAssetInstancesVersionRating || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_COUNT_OF_VERSION_RATING));
			
			pstmt.setLong(Constants.ONE, assetInstanceVersionId);
			pstmt.setString(Constants.TWO, username);
			
			if (log.isTraceEnabled()) {
				log.trace("retCountOfAssetInstancesVersionRating || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_COUNT_OF_VERSION_RATING));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				ratingCount = rs.getInt(1);
			}
			
			
		} catch (SQLException e) {
			log.error("retCountOfAssetInstancesVersionRating || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.RATINGS_NOT_FOUND));
		} catch (IOException e) {
			log.error("retCountOfAssetInstancesVersionRating || " + Constants.LOG_IOEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retCountOfAssetInstancesVersionRating || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("retCountOfAssetInstancesVersionRating || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("retCountOfAssetInstancesVersionRating || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try{
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			}catch(SQLException ex){
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("retCountOfAssetInstancesVersionRating || End");
		}
		return ratingCount;
	}
	
	/**
	 * @method : updateRating
	 * @param aivr
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateRating(AssetInstanceVersionRating aivr, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("updateRating || "+ aivr.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateRating || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_RATING));
			
			pstmt.setDouble(Constants.ONE, aivr.getRating());
			pstmt.setString(Constants.TWO, aivr.getRatingDescription());
			pstmt.setLong(Constants.THREE, aivr.getAssetInstanceVersionId());
			pstmt.setString(Constants.FOUR, aivr.getUsername());
			
			if (log.isTraceEnabled()) {
				log.trace("updateRating || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_RATING));
			}

			int result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("updateRating || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.RATING_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateRating || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateRating || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("updateRating || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("updateRating || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException ex){
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("updateRating || End");
		}
	}
	
	/**
	 * @method : addRating
	 * @param aivr
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetInstanceVersionRating addRating(AssetInstanceVersionRating aivr, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("addRating || "+ aivr.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addRating || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_RATING));
			
			pstmt.setLong(Constants.ONE, aivr.getAssetInstanceVersionId());
			pstmt.setDouble(Constants.TWO, aivr.getRating());
			pstmt.setString(Constants.THREE, aivr.getUsername());
			pstmt.setString(Constants.FOUR, aivr.getRatingDescription());
			
			if (log.isTraceEnabled()) {
				log.trace("addRating || "+PropertyFileReader.getInstance().
						getValue(Constants.ADD_RATING));
			}
			
			pstmt.execute();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				aivr.setRatingId(rs.getLong(1));
			}
			
			
		} catch (SQLException e) {
			log.error("addRating || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.RATING_NOT_ADDED));
		} catch (IOException e) {
			log.error("addRating || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addRating || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("addRating || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("addRating || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try{
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			}catch(SQLException ex){
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("addRating || End");
		}
		return aivr;
	}
	
	
	/**
	 * @method : getUsersCount
	 * @param assetInstanceVersionId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetInstanceVersionRating> getUsersCount(Long assetInstanceVersionId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getUsersCount || Begin with asset instance version id : "+ assetInstanceVersionId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetInstanceVersionRating aivr = null;
		List<AssetInstanceVersionRating> aivrList = new ArrayList<AssetInstanceVersionRating>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getUsersCount || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USERS_COUNT));
			
			pstmt.setLong(Constants.ONE, assetInstanceVersionId);
			
			if (log.isTraceEnabled()) {
				log.trace("getUsersCount || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_USERS_COUNT));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				aivr = new AssetInstanceVersionRating();
				aivr.setAssetInstanceVersionId(rs.getLong("asset_instance_version_id"));
				aivr.setRating(rs.getInt("rating"));
				aivr.setCount(rs.getInt("cnt"));
				aivr.setRatingId(rs.getLong("rating_id"));
				aivr.setUsername(rs.getString("user_name"));
				aivr.setDate(rs.getTimestamp("date"));
				aivr.setRatingDescription(rs.getString("ratingDescription"));
				aivr.setUserId(rs.getLong("user_id"));
				aivr.setImageName(rs.getString("image_name"));
				aivrList.add(aivr);
								
				if(log.isTraceEnabled()){
					log.trace("getUsersCount || "+ aivr.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getUsersCount || "+ aivrList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getUsersCount || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_COUNT_NOT_FOUND));
		} catch (IOException e) {
			log.error("getUsersCount || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getUsersCount || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getUsersCount || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getUsersCount || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try{
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			}catch(SQLException ex){
				ex.printStackTrace();
			}
		}
		return aivrList;
	}
	
	
	
}
