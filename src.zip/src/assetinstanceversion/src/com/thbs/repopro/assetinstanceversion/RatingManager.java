package com.thbs.repopro.assetinstanceversion;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AssetInstanceVersionRating;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Path("/ratingmanager")
public class RatingManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : getAllRating
	 * @description : to get all ratings
	 * @return
	 */
	@GET
	@Path("/getAllRating")
	public Response getAllRating(@QueryParam("assetInstanceVersionId") Long assetInstanceVersionId) {

		if(log.isTraceEnabled()){
			log.trace("getAllRating || Begin with assetInstanceVersionId : "+ assetInstanceVersionId);
		}
		
		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		double rating = 0;
		double count = 0;

		List<AssetInstanceVersionRating> ratingList = new ArrayList<AssetInstanceVersionRating>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllRating || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			RatingDao dao = new RatingDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getAllRating || dao method called : getAllRating()");
			}
			ratingList = dao.getAllRating(assetInstanceVersionId, conn);

			for (AssetInstanceVersionRating aivr : ratingList) {
				count++;
				rating = aivr.getRating() + rating;
			}
		
			for (int i = 0; i < ratingList.size(); i++) {
				
				ratingList.get(i).setTotalCount(ratingList.size());
				
				double d = rating / count;
				double decimal = d - (long)d;
				if(decimal==0.5){
					ratingList.get(i).setAvgRating(d);
				}else{
					ratingList.get(i).setAvgRating(Math.round(rating / count));
				}
			}

			retMsg = Constants.ALL_RATINGS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			log.info("getAllRating || fetched all ratings successfully");

		} catch (RepoproException e) {
			log.error("getAllRating || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllRating || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllRating || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (ratingList.isEmpty()) {
			retMsg = Constants.RATINGS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_RATINGS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		if(log.isTraceEnabled()){
			log.trace("getAllRating || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(ratingList))).build();
	}
	
	/**
	 * @method : updateRating
	 * @param aivr
	 * @return
	 */
	@PUT
	@Path("/updaterating")
	public Response updateRating(AssetInstanceVersionRating aivr) {

		if (log.isTraceEnabled()) {
			log.trace("updateRating || " + aivr.toString() + " Begin");
		}

		Connection conn = null;
		int count = 0;
		
		List<AssetInstanceVersionRating> ratingList = new ArrayList<AssetInstanceVersionRating>();
		List<AssetInstanceVersionRating> resultObj = new ArrayList<AssetInstanceVersionRating>();

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateRating || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			RatingDao dao = new RatingDao();
			
			if (log.isTraceEnabled()) {
				log.trace("updateRating || dao method called : getAllRating()");
			}
			ratingList = dao.getAllRating(aivr.getAssetInstanceVersionId(), conn);
			
			if (log.isTraceEnabled()) {
				log.trace("updateRating || dao method called : retCountOfAssetInstancesVersionRating()");
			}
			count = dao.retCountOfAssetInstancesVersionRating(aivr.getAssetInstanceVersionId(),
					aivr.getUsername(), conn);
			
			
			if(ratingList.isEmpty()){
				
				if(count==0){
					if (log.isTraceEnabled()) {
						log.trace("updateRating || dao method called : addRating() "+ aivr.toString());
					}
					dao.addRating(aivr, conn);
					
					retMsg = Constants.RATING_ADDED;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					
					log.info("updateRating || " + aivr.toString() + " rating added successfully");
					
				}else{
					if (log.isTraceEnabled()) {
						log.trace("updateRating || dao method called : updateRating() "+ aivr.toString());
					}
					dao.updateRating(aivr, conn);
					
					retMsg = Constants.RATING_UPDATED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
					
					log.info("updateRating || " + aivr.toString() + " rating updated successfully");
				}
				
			}else{
				
				if(count==0){
					if (log.isTraceEnabled()) {
						log.trace("updateRating || dao method called : addRating() "+ aivr.toString());
					}
					dao.addRating(aivr, conn);
					
					retMsg = Constants.RATING_ADDED;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					
					log.info("updateRating || " + aivr.toString() + " rating added successfully");
					
				}else{
					if (log.isTraceEnabled()) {
						log.trace("updateRating || dao method called : updateRating() "+ aivr.toString());
					}
					dao.updateRating(aivr, conn);
					
					retMsg = Constants.RATING_UPDATED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
					
					log.info("updateRating || " + aivr.toString() + " rating updated successfully");
				}
			
			}
			resultObj.add(aivr);
			conn.commit();

		} catch (RepoproException e) {
			log.error("updateRating || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("updateRating || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateRating || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateRating || End");
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, 
						new ArrayList<Object>(resultObj))).build();

	}
	
	
	/**
	 * @method : getUsersCount
	 * @param assetInstanceVersionId
	 * @return
	 */
	@GET
	@Path("/getuserscount")
	public Response getUsersCount(@QueryParam("assetInstanceVersionId") Long assetInstanceVersionId){
		
		if(log.isTraceEnabled()){
			log.trace("getUsersCount || Begin with asset instance version id : "+ assetInstanceVersionId);
		}
		
		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<AssetInstanceVersionRating> aivrList = new ArrayList<AssetInstanceVersionRating>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getUsersCount || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			RatingDao dao = new RatingDao();
			
			if(log.isTraceEnabled()){
				log.trace("getUsersCount || dao method called : getUsersCount()");
			}
			aivrList = dao.getUsersCount(assetInstanceVersionId, conn);
			
			log.info("getUsersCount || fetched user count successfully");
			
			retMsg = Constants.USER_COUNT_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			double totalcount = 0;
			double count = 0;
			for (AssetInstanceVersionRating aivr : aivrList) {
				count += aivr.getCount();
				totalcount += aivr.getRating()*aivr.getCount();
				
			}
			
			for (int i = 0; i < aivrList.size(); i++) {
				
				double d = totalcount/count;
				double decimal = d - (long)d;
				if(decimal==0.5){
					aivrList.get(i).setAvgRating(d);
				}else{
					aivrList.get(i).setAvgRating(Math.round(totalcount/count));
				}
				
				aivrList.get(i).setTotalCount((int)count);
			}
			
		} catch (RepoproException e) {
			log.error("getUsersCount || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getUsersCount || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getUsersCount || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("getUsersCount || end");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(aivrList))).build();
	}	
}
