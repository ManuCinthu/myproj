package com.thbs.repopro.assetinstanceversion;

import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.activation.MimetypesFileTypeMap;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StreamUtils;

/*import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGEncodeParam;
import com.sun.image.codec.jpeg.JPEGImageEncoder;*/
import com.thbs.repopro.accesscontrol.GroupDao;
import com.thbs.repopro.accesscontrol.RoleDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.assetinstance.AssetInstanceManager;
import com.thbs.repopro.assetinstance.ShowHideDao;
import com.thbs.repopro.assetinstance.ShowHideManager;
import com.thbs.repopro.dto.AivDetails;
import com.thbs.repopro.dto.AivRevisionHistory;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetDetailRequest;
import com.thbs.repopro.dto.AssetInstParams;
import com.thbs.repopro.dto.AssetInstRelationship;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetInstanceVersionTaxonomy;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.AssetRelationshipDef;
import com.thbs.repopro.dto.Category;
import com.thbs.repopro.dto.GamificationDetails;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.GroupAssetAccess;
import com.thbs.repopro.dto.GroupAssetInstVersionAccess;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.LdapMapping;
import com.thbs.repopro.dto.LockTime;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.dto.NameValue;
import com.thbs.repopro.dto.Parameter;
import com.thbs.repopro.dto.ParameterValues;
import com.thbs.repopro.dto.ParentModel;
import com.thbs.repopro.dto.RecentActivity;
import com.thbs.repopro.dto.Role;
import com.thbs.repopro.dto.ShowHideColumn;
import com.thbs.repopro.dto.TaggingMaster;
import com.thbs.repopro.dto.TaxonomyMaster;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.dto.Workflow;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.gamification.GamificationDao;
import com.thbs.repopro.ldap.LDAPUser;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.plugin.AssetRepresentationDao;
import com.thbs.repopro.recentactivity.RecentActivityDao;
import com.thbs.repopro.relationship.RelationshipDao;
import com.thbs.repopro.subscription.SubscriptionDao;
import com.thbs.repopro.tagging.TaggingDao;
import com.thbs.repopro.taxonomies.TaxonomiesDao;
import com.thbs.repopro.taxonomies.TaxonomiesManager;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.workflow.WorkflowDao;

@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.MULTIPART_FORM_DATA })
@Path("/assetInstanceVersionManager")
public class AssetInstanceVersionsManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");
	private	Map<Long, List<TaxonomyMaster>> allTaxs =  null;
	//List<Long> associatedTaxId = new ArrayList<Long>();
	
	void recurseTax(TaxonomyMaster t) throws RepoproException{

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);
			allTaxs.put(t.getTaxonomyId(), chldrn);
			for(TaxonomyMaster i: chldrn)
				recurseTax(i);
		}
		catch (RepoproException e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

	}

	void  recurseTax1(TaxonomyMaster t) throws RepoproException{

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);

			for(TaxonomyMaster a: chldrn){

				TaxonomyMaster t1 = new TaxonomyMaster();
				t1.setTaxonomyId(a.getTaxonomyId());
				t1.setTaxonomyName(a.getTaxonomyName());
				recurseTax1(t1);
				associatedTaxId.add(a.getTaxonomyId());
				associatedTaxId.add(t.getTaxonomyId());

			}
			associatedTaxId.add(t.getTaxonomyId());

		}catch (RepoproException e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
	}
	/**
	 * @method getAssetInstanceDetailsWrapper
	 * @description get Asset Instance Name
	 * @param assetInstVersionId
	 * @param assetType
	 * @return Response List<AssetInstanceVersion>
	 * @throws RepoproException
	 */
	@GET
	@Path("/getAssetInstanceNameByAIVId")
	public Response getAssetInstanceDetailsWrapper(@QueryParam("assetInstVersionId") Long assetInstVersionId,
			@QueryParam("assetType") String assetType){
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<AssetInstanceVersion> aivList = new ArrayList<AssetInstanceVersion>();
		try {
			AssetInstanceVersionDao assetInstanceDao = new AssetInstanceVersionDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceDetailsWrapper || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceDetailsWrapper || dao method called : getAssetInstanceNameByAIVId(assetInstVersionId)");
			}
			AssetInstanceVersion aiv = assetInstanceDao.getAssetInstanceNameByAssetNameAndAivId(assetType, assetInstVersionId, conn);
			if(aiv!=null)
				aivList.add(aiv);
			else
				aivList.add(new AssetInstanceVersion());
			if (aivList.isEmpty()) {
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			
		} catch (RepoproException e) {
			log.error("getAssetInstanceDetailsWrapper || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceDetailsWrapper || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceDetailsWrapper || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(aivList)))
				.build();
	}
	
	/**
	 * @method getAssetInstanceForFilter
	 * @description to get filtered and show and hide asset instance grid
	 * @param userName
	 * @param assetName
	 * @param assetId
	 * @param userId
	 * @param operators
	 * @param assetParamNames
	 * @param param1Values
	 * @param param2Values
	 * @param logicalSelect
	 * @param taxonomyNames
	 * @param groupName
	 * @param from
	 * @return Response List<AssetInstanceVersion>
	 * @throws RepoproException
	 */
	@GET
	@Encoded
	@Path("/getAssetInstanceByFilter")
	public Response getAssetInstanceForFilter(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("assetId") Long assetId,
			@QueryParam("operators") String operators, @QueryParam("assetParamNames") String assetParamNames,
			@QueryParam("param1Values") String param1Values, @QueryParam("param2Values") String param2Values,
			@QueryParam("logicalSelect") String logicalSelect, @QueryParam("taxonomyNames") String taxonomyNames,
			@QueryParam("from") int from,@QueryParam("range") int range,@QueryParam("restApiFlag") boolean restApiFlag,
			@QueryParam("sortBy") String sortBy,@QueryParam("sortOrder") String sortOrder,
			@QueryParam("assetInstanceVersionId") String assetInstanceVersionId,
			@QueryParam("description") String description,@QueryParam("assetInstanceName") String assetInstanceName,
			@QueryParam("selectParameter") String selectParameter) {
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceForFilter || begin with userName : " + userName + " assetName :" + assetName
					+ " assetId:" + assetId + " operators:" + operators + " assetParamNames:" + assetParamNames
					+ " param1Values:" + param1Values + " param2Values:" + param2Values + " logicalSelect:"
					+ logicalSelect + " taxonomyNames:" + taxonomyNames + "from:" + from);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;

		boolean propertiesFlag = true;
		
		List<AssetInstance> listOfAssetInstanceVos = new ArrayList<AssetInstance>();
		try {
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			if(restApiFlag == false){
				assetInstanceVersionId = "";
				assetInstanceName = "";
				description = "";
			}else{
				assetInstanceName = URLDecoder.decode(assetInstanceName, "UTF-8");
				description  = URLDecoder.decode(description, "UTF-8");
				
				if(assetInstanceName.contains("\\")){
					assetInstanceName = assetInstanceName.replace("\\", "\\\\\\\\");
				}
				if(description.contains("\\")){
					description = description.replace("\\", "\\\\\\\\");
				}
			}
			//if(!restApiFlag){
				assetParamNames = URLDecoder.decode(assetParamNames, "UTF-8");
				param1Values = URLDecoder.decode(param1Values, "UTF-8");
				param2Values = URLDecoder.decode(param2Values, "UTF-8");
				operators = URLDecoder.decode(operators, "UTF-8");
				assetName = URLDecoder.decode(assetName, "UTF-8");
			//}
			//assetParamNames = URLDecoder.decode(assetParamNames, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilter || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			ShowHideManager shd = new ShowHideManager();
			ShowHideColumn hideColumn = new ShowHideColumn();
			hideColumn.setAssetId(assetId);
			if (!userName.equalsIgnoreCase("roleAnonymous")) {
				UserDao userDao = new UserDao();
				User user = userDao.retProfileForUserName(userName, conn);
				hideColumn.setUserId(user.getUserId());
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilter || dao method called : getShowHideParams(assetId,UserId)");
			}
			ShowHideColumn shc = shd.getShowHideParamValues(hideColumn, userName, conn);
			java.util.Map<Long, String> hideParameters = shc.getShowParamDetails();
			@SuppressWarnings("unused")
			int showHideParamCount = hideParameters.size();
			String showHideAssetParamName = new String();
			
			if(selectParameter == null){
				@SuppressWarnings("rawtypes")
				Iterator itr = hideParameters.entrySet().iterator();
				while (itr.hasNext()) {
					@SuppressWarnings("rawtypes")
					java.util.Map.Entry pair = (java.util.Map.Entry) itr.next();
					showHideAssetParamName = showHideAssetParamName.concat(pair.getValue().toString() + ",");
				}
			}
			else if(selectParameter != null){
				selectParameter = URLDecoder.decode(selectParameter, "UTF-8");
				showHideAssetParamName = selectParameter;
			}
			
			if (showHideAssetParamName.length() != 0) {
				// non static and static information
				String[] paramNames = showHideAssetParamName.split(",");
				StringBuffer sb = new StringBuffer();
				int sizeOfParameters = 0;
				for (int i = 0; i < paramNames.length; i++) {
					sizeOfParameters = i;
					sb.append(paramNames[i] + ",");
					if(restApiFlag == false){/* added condition to show all the select parameters in rest api response which was restricted to 3 (like in UI)*/
						if (i == 2) {/* restricting to 3 parameters in UI */
							break;
						}
					}
					
				}
				sb = sb.deleteCharAt(sb.length() - 1);
				StringBuffer staticParameters = new StringBuffer();
				StringBuffer nonStaticParameters = new StringBuffer();
				int paramCount = sizeOfParameters;
				paramCount = paramCount + 1;
				int maximumParamCount = 0;
				for (int i = 0; i < paramNames.length; i++) {
					String paramName = paramNames[i];
					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceForFilter || dao method called : getAssetParamDefByAssetNameAndParamName(assetName,paramName)");
					}
					AssetParamDef paramdef = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(assetName,
							paramName, conn);
					if (paramdef.getIs_static() != 1) {// non-static
						nonStaticParameters.append(paramdef.getAssetParamName() + ",");
					} else {
						staticParameters.append(paramdef.getAssetParamName() + ",");
					}
					maximumParamCount++;
					if(restApiFlag == false){/* added condition to show all the select parameters in rest api response which was restricted to 3 (like in UI)*/
						if (maximumParamCount == 3)/* restricting to 3 parameters in UI */
							break;
					}
				}
				List<AssetInstanceVersion> listofFilterInformation = null;
				
				if (nonStaticParameters.length() != 0) {
					nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length() - 1);
				}
				if (staticParameters.length() != 0) {
					staticParameters = staticParameters.deleteCharAt(staticParameters.length() - 1);
				}
				if (log.isTraceEnabled()) {
					log.trace(
							"getAssetInstanceForFilter || dao method called : getAssetInstanceForFilterWithNonStaticParameters to get list of asset instance details for filter applied");
				}
				
				listofFilterInformation = assetInstanceVersionDao.getAssetInstanceForFilterWithNonStaticParametersDao(
						userName, assetName, assetParamNames, param1Values, param2Values, operators, logicalSelect,
						taxonomyNames, sb.toString(), from,range,restApiFlag,sortBy,sortOrder,assetInstanceVersionId,description,assetInstanceName, conn);
				
				int totalResult = 0;
				if(listofFilterInformation != null) {
					if(!listofFilterInformation.isEmpty()) {
						totalResult =  listofFilterInformation.get(0).getResultTotalCount();
					}
				}
				if (nonStaticParameters.length() != 0) {
					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceForFilter || dao method called : getAssetParamDefsByParameters(parameters,assetName)");
					}
					List<AssetParamDef> listOfNonStaticParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(nonStaticParameters.toString(), assetName, conn);
					TreeMap<String, String> paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					TreeMap<String, String> paramValuesRest = new TreeMap<String, String>();
					Long newAssetInstVersionId = 0L;
					
					int jj = 1;
					for (int i = 0; i < listofFilterInformation.size(); i++) {
						
						AssetInstanceVersion aiv = listofFilterInformation.get(i);
						newAssetInstVersionId = aiv.getAssetInstVersionId();
						boolean flag = false;
						AssetInstance vo = new AssetInstance();
						vo.setAssetInstId(aiv.getAssetInstanceId());
						vo.setAssetInstName(aiv.getAssetInstName());
						vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
						vo.setDescription(aiv.getDescription());
						vo.setVersionName(aiv.getVersionName());
						vo.setVersionable(aiv.getVersionable());
						vo.setIconImageName(aiv.getIconImageName());
						vo.setEditAccessFlag(aiv.isEditAccessFlag());
						vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
						vo.setParamTypeId(aiv.getParamTypeId());
						vo.setRTFwithTags(aiv.getRTFwithTags());
						vo.setTextDataList(aiv.getTextDataList());
						vo.setShowHideParamCount(hideParameters.size());
						vo.setLdapMappingValues(aiv.getLdapMappingValue());
						vo.setLdapMappingCount(aiv.getLdapMappingListCount());
						if(totalResult != 0){
							vo.setResultTotalCount(totalResult);
						}
												
						for (int j = 0; j < listOfNonStaticParamDefs.size(); j++) {
							AssetParamDef apd = listOfNonStaticParamDefs.get(j);
							if (aiv.getAssetParamName() != null) {
								if (aiv.getAssetParamName().equalsIgnoreCase(apd.getAssetParamName())) {
									flag = true;
									if (apd.getParamTypeId() == 3) {
										paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getFileName());
									} else {
										if (apd.getParamTypeId() == 5) {
											paramValues.put(apd.getAssetParamName(),
													"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),
													"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()+ "~" + apd.getAssetParamName());
										} else if (apd.getParamTypeId() == 6) {
											paramValues.put(apd.getAssetParamName(),
													"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),
													"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()+ "~" + apd.getAssetParamName());
										} else if (apd.getParamTypeId() == 8) {
											paramValues.put(apd.getAssetParamName(),
													"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),
													"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
													+ "~" + apd.getAssetParamName());
									
										}
										else if(apd.getParamTypeId() == 7){
											if(apd.getHasArray() == 1){
												String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
												paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), rtfTags);
											}else if(apd.getHasArray() == 0){
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
											}
											
										}else if(apd.getParamTypeId() == 1){
											if(apd.getHasArray() == 1){
												String textData = StringUtils.join(aiv.getTextDataList(), "~~");
												paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), textData);
											}else if(apd.getHasArray() == 0){
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
											}
										}else if(apd.getParamTypeId() == 9){
											String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
											paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), ldapData);
										}else {
											paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
										}
									}
									if (flag) {
										if(restApiFlag == true) {
											vo.setParamNameWithValues(paramValuesRest);
										}else {
											vo.setParamNameWithValues(paramValues);
										}
										break;
									}
								}
							} else {
								if (apd.getParamTypeId() == 3) {
									if(aiv.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else {
										paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getFileName());

								} else {
									if (apd.getParamTypeId() == 5) {
										paramValues.put(apd.getAssetParamName(), "^^DA^^~" + aiv.getAssetInstVersionId()
												+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
									} else if (apd.getParamTypeId() == 6) {
										paramValues.put(apd.getAssetParamName(), "^^DC^^~" + aiv.getAssetInstVersionId()
												+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), "^^DC^^~" + aiv.getAssetInstVersionId()
										+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName());
									} else if (apd.getParamTypeId() == 8) {
										paramValues.put(apd.getAssetParamName(), "^^AC^^~" + aiv.getAssetInstVersionId()
										+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), "^^AC^^~" + aiv.getAssetInstVersionId()
										+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName());
									}else if(apd.getParamTypeId() == 7){
										if(apd.getHasArray() == 1){
											String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
											if(rtfTags == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else {
												paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), rtfTags);
										}else if(apd.getHasArray() == 0){
											if(aiv.getParamValue() == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else {
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
										}
									}else if(apd.getParamTypeId() == 1){
										if(apd.getHasArray() == 1){
											String textData = StringUtils.join(aiv.getTextDataList(), "~~");
											if(textData == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else {
												paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), textData);

										}else if(apd.getHasArray() == 0){
											if(aiv.getParamValue() == null) {
												paramValues.put(apd.getAssetParamName(),"`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else {
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
										}
									}else if(apd.getParamTypeId() == 9){
										String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
										if(ldapData == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}else {
											paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), ldapData);
									}else {
										if(aiv.getParamValue() == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}else {
											paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
									}
								}
								if(restApiFlag == true) {
									vo.setParamNameWithValues(paramValuesRest);
								}else {
									vo.setParamNameWithValues(paramValues);
								}
							}
						}
						Map<String, String> finalValues = vo.getParamNameWithValues();
						if(finalValues != null){
							for (AssetParamDef assetParamDef : listOfNonStaticParamDefs) {
								boolean flag1 = false;
								
								for (Map.Entry<String, String> map : finalValues.entrySet()) {
									if(restApiFlag == true) {
										String paramNameArray[] = map.getKey().split("`@`");
										if (assetParamDef.getAssetParamName().equalsIgnoreCase(paramNameArray[0])) {
											flag1 = true;
											break;
										}
									}else {
										if (assetParamDef.getAssetParamName().equalsIgnoreCase(map.getKey())) {
											flag1 = true;
											break;
										}
									}
								}
								
								if (!flag1) {
									if (assetParamDef.getParamTypeId() == 3) {
										if(assetParamDef.getFileName() == null) {
											paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										}else {
											paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getFileName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										}
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getFileName());

									} else {
										if (assetParamDef.getParamTypeId() == 5) {
											paramValues.put(assetParamDef.getAssetParamName(),
													"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
															+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(),
													"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
															+ assetParamDef.getAssetParamName());

										} else if (assetParamDef.getParamTypeId() == 6) {
											paramValues.put(assetParamDef.getAssetParamName(),
													"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
															+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(),
													"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
															+ assetParamDef.getAssetParamName());
										} else if (assetParamDef.getParamTypeId() == 8) {
											paramValues.put(assetParamDef.getAssetParamName(),
													"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
															+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(),
													"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"+ assetParamDef.getAssetParamName());
										}else if(assetParamDef.getParamTypeId() == 7){
											if(assetParamDef.getHasArray() == 1){
												//String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
												if(assetParamDef.getParamValue() == null) {
													paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}else {
													paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}
												paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
											}else if(assetParamDef.getHasArray() == 0){
												if(assetParamDef.getParamValue() == null) {
													paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}else {
													paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}
												paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());

											}
										}else if(assetParamDef.getParamTypeId() == 1){
											if(assetParamDef.getHasArray() == 1){
												//String textData = StringUtils.join(aiv.getTextDataList(), "~~");
												if(assetParamDef.getParamValue() == null) {
													paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}else {
													paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}
												paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());

											}else if(assetParamDef.getHasArray() == 0){
												if(assetParamDef.getParamValue() == null) {
													paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}else {
													paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}
												paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
											}
										}else if(assetParamDef.getParamTypeId() == 9){
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());

										}else {
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());

										}
									}
									if(restApiFlag == true) {
										vo.setParamNameWithValues(paramValuesRest);
									}else {
										vo.setParamNameWithValues(paramValues);
									}
								}
							}
						}
						if (i < listofFilterInformation.size() - 1) {
							if (!newAssetInstVersionId
									.equals(listofFilterInformation.get(jj).getAssetInstVersionId())) {
								listOfAssetInstanceVos.add(vo);
								paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
								paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
							}
						} else {
							listOfAssetInstanceVos.add(vo);
						}
						jj++;
					}
				}
				if (staticParameters.length() != 0) {
					// static information
					TreeMap<String, String> paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					TreeMap<String, String> paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceForFilter || dao method called : getAssetParamDefsByParameters(staticParameters,assetName)");
					}
					List<AssetParamDef> listOfStaticParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(staticParameters.toString(), assetName, conn);
					/*
					 * if (log.isTraceEnabled()) { log.trace(
					 * "getAssetInstanceForFilter || dao method called : getAssetInstanceVersionDetailsWithStaticParameters(assetName,userName,from)"
					 * ); }
					 */
					// listofStaticInformation =
					// assetInstanceVersionDao.getAssetInstanceVersionDetailsWithStaticParameters(assetName,userName,from,
					// conn);
					if (nonStaticParameters.length() != 0) {
						for (int i = 0; i < listOfAssetInstanceVos.size(); i++) {
							AssetInstance aivo = listOfAssetInstanceVos.get(i);
							for (int k = 0; k < listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if (apd.getParamTypeId() == 3) {
									if(apd.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else {
										paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getFileName());

								} else {
									if(apd.getStaticValue() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}else {
										paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getStaticValue());
								}
							}
							java.util.Map<String, String> map = aivo.getParamNameWithValues();
							if (map != null) {
								
								if(restApiFlag == true) {
									map.putAll(paramValuesRest);
								}else {
									map.putAll(paramValues);
								}
								aivo.setParamNameWithValues(map);
								listOfAssetInstanceVos.set(i, aivo);
							} else {
								if(restApiFlag == true) {
									aivo.setParamNameWithValues(paramValuesRest);
								}else {
									aivo.setParamNameWithValues(paramValues);
								}
								listOfAssetInstanceVos.set(i, aivo);
							}
						}
						paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
						paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					} else {
						for (int j = 0; j < listofFilterInformation.size(); j++) {
							AssetInstance vo = new AssetInstance();
							AssetInstanceVersion aiv = listofFilterInformation.get(j);
							for (int k = 0; k < listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if (apd.getParamTypeId() == 3) {
									if(apd.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else {
										paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getFileName());

								} else {
									if(apd.getStaticValue() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}else {
										paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getStaticValue());
								}
							}
							vo.setAssetInstName(aiv.getAssetInstName());
							vo.setAssetInstId(aiv.getAssetInstanceId());
							vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
							vo.setDescription(aiv.getDescription());
							vo.setVersionName(aiv.getVersionName());
							if(restApiFlag == true) {
								vo.setParamNameWithValues(paramValuesRest);
							}else {
								vo.setParamNameWithValues(paramValues);
							}
							vo.setVersionable(aiv.getVersionable());
							vo.setIconImageName(aiv.getIconImageName());
							vo.setShowHideParamCount(hideParameters.size());
							vo.setEditAccessFlag(aiv.isEditAccessFlag());
							vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
							vo.setParamTypeId(aiv.getParamTypeId());
							vo.setRTFwithTags(aiv.getRTFwithTags());
							vo.setTextDataList(aiv.getTextDataList());
							if(totalResult != 0){
								vo.setResultTotalCount(totalResult);
							}
							listOfAssetInstanceVos.add(vo);
							paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
							paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
						}
					}
				}
			} else {
				// getBasic information
				propertiesFlag = false;
				if (log.isTraceEnabled()) {
					log.trace(
							"getAssetInstanceForFilter || dao method called : getAssetInstanceForFilterWithNonStaticParametersDao without showhide parameters");
				}
				List<AssetInstanceVersion> basicInformationOfassetInstance = assetInstanceVersionDao
						.getAssetInstanceForFilterWithNonStaticParametersDao(userName, assetName, assetParamNames,
								param1Values, param2Values, operators, logicalSelect, taxonomyNames, "", from,range,restApiFlag,
								sortBy,sortOrder,assetInstanceVersionId,
								description,assetInstanceName, conn);
				int totalResult = 0;
				if(basicInformationOfassetInstance != null) {
					if(!basicInformationOfassetInstance.isEmpty()) {
						totalResult =  basicInformationOfassetInstance.get(0).getResultTotalCount();
					}
				}
				for (int i = 0; i < basicInformationOfassetInstance.size(); i++) {
					AssetInstanceVersion aiv = basicInformationOfassetInstance.get(i);
					AssetInstance vo = new AssetInstance();
					vo.setAssetInstName(aiv.getAssetInstName());
					vo.setAssetInstId(aiv.getAssetInstanceId());
					vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
					vo.setDescription(aiv.getDescription());
					vo.setVersionName(aiv.getVersionName());
					vo.setVersionable(aiv.getVersionable());
					vo.setIconImageName(aiv.getIconImageName());
					vo.setShowHideParamCount(hideParameters.size());
					vo.setEditAccessFlag(aiv.isEditAccessFlag());
					vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
					vo.setPropertiesFlag(propertiesFlag);
					vo.setParamTypeId(aiv.getParamTypeId());
					vo.setRTFwithTags(aiv.getRTFwithTags());
					vo.setTextDataList(aiv.getTextDataList());
					if(totalResult != 0){
						vo.setResultTotalCount(totalResult);
					}
					listOfAssetInstanceVos.add(vo);
				}
			}
			
			if(restApiFlag == true) {
				if(sortBy != null && sortOrder != null) {
					if(sortBy.equalsIgnoreCase("AssetInstanceName")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(listOfAssetInstanceVos, new Sortbyname());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(listOfAssetInstanceVos, new SortbynameRev());
						}
					}
					else if(sortBy.equalsIgnoreCase("AssetInstanceVersionId")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(listOfAssetInstanceVos, new Sortbyid());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(listOfAssetInstanceVos, new SortbyidRev());
						}
					}
				}
			}else {
				Collections.sort(listOfAssetInstanceVos, new AssetInstance());
			}
			
			if (log.isDebugEnabled()) {
				log.debug("getAssetInstanceForFilter || " + listOfAssetInstanceVos.toString());
			}
			log.debug(" getAssetInstanceForFilter || retrieved " + listOfAssetInstanceVos.size()
					+ " asset instance version details by asset name : " + assetName.toString());
			if (listOfAssetInstanceVos.isEmpty()) {
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAssetInstanceForFilter || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceForFilter || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilter || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceForFilter || end with userName : " + userName + " assetName :" + assetName
					+ " assetId:" + assetId + " operators:" + operators + " assetParamNames:" + assetParamNames
					+ " param1Values:" + param1Values + " param2Values:" + param2Values + " logicalSelect:"
					+ logicalSelect + " taxonomyNames:" + taxonomyNames + " from:" + from);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(listOfAssetInstanceVos)))
				.build();
	}

	/**
	 * @method getAssetInstanceVersionDetails
	 * @description to get asset instance version details
	 * @param assetInstVersionId
	 * @return success response
	 * @throws RepoproException
	 */

	@GET
	@Encoded
	@Path("/getAssetInstanceVersionDetails/{assetInstVersionId}")
	public Response getAssetInstanceVersionDetails(@PathParam("assetInstVersionId") long assetInstVersionId,
			@QueryParam("assetInstName") String assetInstName) {

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceVersionDetails || begin  with assetInstVersionId : " + assetInstVersionId);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		Connection conn = null;
		List<AssetInstanceVersion> assetInstVerDetailsList = new ArrayList<AssetInstanceVersion>();

		try {
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionDetails || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace(
						"getAssetInstanceVersionDetails || dao method called : getAssetInstanceVersionDetails by assetInstVersionId: "
								+ assetInstVersionId);
			}
			AssetInstanceVersion assetInstanceVersion = null;
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			assetInstanceVersion = assetInstanceVersionDao.getAssetInstanceVersionDetailsInAivpage(assetInstVersionId,assetInstName,conn);
			assetInstVerDetailsList.add(assetInstanceVersion);
			conn.commit();

			if (log.isDebugEnabled()) {
				log.debug(" getAssetInstanceVersionDetails  || retrieved " + assetInstVerDetailsList.size()
						+ " asset instance version details by version id : " + assetInstVersionId);
			}

			if (assetInstanceVersion != null) {
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_NOT_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAssetInstanceVersionDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceVersionDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceVersionDetails || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(assetInstVerDetailsList)))
				.build();

	}

	/**
	 * @method getAssetInstanceVersions
	 * @description to get asset instance versions List
	 * @param assetInstId
	 * @return success response
	 * @throws RepoproException
	 */

	@GET
	@Path("/getAssetInstanceVersions/{assetInstId}")
	public Response getAssetInstanceVersions(@PathParam("assetInstId") long assetInstId,
			@QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceVersions : || begin with assetInstId : " + assetInstId);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		Boolean flag = false;
		Connection conn = null;
		List<AssetInstanceVersion> assetInstVersionList = new ArrayList<AssetInstanceVersion>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersions || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			List<AssetInstanceVersion> assetInstVersionList1 = new ArrayList<AssetInstanceVersion>();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();

			if (userName.equalsIgnoreCase("admin")) {

				if (log.isTraceEnabled()) {
					log.trace(
							"getAssetInstanceVersions || dao method called : getAssetInstanceVersions by assetInstId: "
									+ assetInstId);
				}

				assetInstVersionList1 = assetInstanceVersionDao
						.getAssetInstanceVersions(assetInstId, conn);
				for (AssetInstanceVersion aiv : assetInstVersionList1) {
					aiv.setEditAccessFlag(true);
					aiv.setDeleteAccessFlag(true);
					aiv.setViewAccessFlag(true);
					assetInstVersionList.add(aiv);
				}

			}
			else if(userName.equalsIgnoreCase("roleAnonymous")){
				if (log.isTraceEnabled()) {
					log.trace(
							"getAssetInstanceVersions || dao method called : getAssetInstanceVersions by assetInstId: "
									+ assetInstId);
				}

				assetInstVersionList1 = assetInstanceVersionDao
						.getAssetInstanceVersions(assetInstId, conn);
				for (AssetInstanceVersion aiv : assetInstVersionList1) {
					aiv.setEditAccessFlag(false);
					aiv.setDeleteAccessFlag(false);
					aiv.setViewAccessFlag(true);
					assetInstVersionList.add(aiv);
				}
			}else {

				if (log.isTraceEnabled()) {
					log.trace(
							"getAssetInstanceVersions ||  called dao method  : findAdminRightsByUserName() to get admin rights for user");
				}
				flag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);

				if (flag) {

					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceVersions || dao method called : getAssetInstanceVersions by assetInstId: "
										+ assetInstId);
					}

					assetInstVersionList1 = assetInstanceVersionDao
							.getAssetInstanceVersions(assetInstId, conn);
					for (AssetInstanceVersion aiv : assetInstVersionList1) {
						aiv.setEditAccessFlag(true);
						aiv.setDeleteAccessFlag(true);
						aiv.setViewAccessFlag(true);
						assetInstVersionList.add(aiv);
					}

				} else {

					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceVersions || dao method called : getAssetInstanceVersions by assetInstId: "
										+ assetInstId);
					}

					List<AssetInstanceVersion> aivList = assetInstanceVersionDao.getAssetInstanceVersions(assetInstId,
							conn);

					for (AssetInstanceVersion ai : aivList) {

						boolean editflag1 = false;	
						boolean deleteflag1 = false;
						boolean viewflag1 = false;
						List<GroupAssetAccess> groupAssetAccessList = assetInstanceDao.getAssetInstanceAccessForLoginUser(ai.getAssetInstVersionId(), userName,conn);

						for(GroupAssetAccess ga : groupAssetAccessList){
							if (ga.getViewAccess() == 1L) {
								viewflag1 = true;
							}
							if (ga.getEditAccess() == 1L ) {
								editflag1 = true;
							}
							if (ga.getDeleteAccess() == 1L ) {
								deleteflag1 = true;
							}
							
						}
						
						if(editflag1 == true){
							ai.setEditAccessFlag(true);
						}
						else{
							ai.setEditAccessFlag(false);
						}
						
						if(deleteflag1 == true){
							ai.setDeleteAccessFlag(true);
						}
						else{
							ai.setDeleteAccessFlag(false);
						}
						if(viewflag1 == true){
							ai.setViewAccessFlag(true);
						}
						else{
							ai.setViewAccessFlag(false);
						}
						/*for (GroupAssetAccess ga : groupAssetAccessList) {
							if (ga.getViewAccess() == 1L) {
								ai.setViewAccessFlag(true);
							} else {
								ai.setViewAccessFlag(false);
							}
							if (ga.getEditAccess() == 1L ) {
								ai.setEditAccessFlag(true);

							} else {
								ai.setEditAccessFlag(false);
							}
							if (ga.getDeleteAccess() == 1L ) {
								ai.setDeleteAccessFlag(true);

							} else {
								ai.setDeleteAccessFlag(false);
							}
                    if(ai.isViewAccessFlag() == true && ai.isEditAccessFlag() == true && ai.isDeleteAccessFlag() == true )
						break;
						}*/

						assetInstVersionList.add(ai);

					}
				}
			}

			conn.commit();

			log.debug(" getAssetInstanceVersions || retrieved " + assetInstVersionList.size()
					+ " asset instance versions by asset instance id : " + assetInstId + "successfully");

			if (assetInstVersionList.isEmpty()) {
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAssetInstanceVersions || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceVersions || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersions || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceVersions || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(assetInstVersionList)))
				.build();

	}

	/**
	 * @method getAssetInstancePropertiesDetails
	 * @description to get assetInstanceViewDetails
	 * @param user
	 *            name,assetInstanceVersionId,assetName,paramterName
	 * @return Response String
	 * @throws RepoproException
	 */

	@GET
	@Encoded
	@Path("/getAssetInstancePropertiesDetails")
	public Response getAssetInstancePropertiesDetails(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceVersionId") Long assetInstanceVersionId) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstancePropertiesDetails || begin  with userName : " + userName + " assetName "
					+ assetName);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<AssetInstanceVersion> nonStaticList = new ArrayList<AssetInstanceVersion>();
		AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
		AssetInstance vo = new AssetInstance();
		Connection conn = null;
		HashMap<String, List<LinkedHashMap<String, String>>> finalMap = null;
		List<AssetInstanceVersion> finalData = new ArrayList<AssetInstanceVersion>();
		List<AssetInstanceVersion> staticList = new ArrayList<AssetInstanceVersion>();
		List<String> RTFTextWithTags = new ArrayList<String>();
		AssetDao assetdao = new AssetDao();
		try {
			
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancePropertiesDetails || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancePropertiesDetails || Dao method call getParamDefForAssetByGroups()");
			}
			List<AssetParamDef> params = revisionHistoryDao.getParamDefForAssetByGroups(assetName, userName, conn);

			StringBuffer staticParams = new StringBuffer();
			StringBuffer nonStaticParams = new StringBuffer();

			for (int i = 0; i < params.size(); i++) {
				AssetParamDef apd = params.get(i);
				if (apd.getIs_static() == 1) {
					staticParams.append(apd.getAssetParamName() + ",");
				} else {
					long type = apd.getParamTypeId();
					int id = (int) type;
					if (id != 6 && id != 5 && id != 8) {
						nonStaticParams.append(apd.getAssetParamName() + ",");
					}
				}
				if (apd.getParamTypeId() == 5) {
					String derivedData = dao.getDerivedAttributeValues(userName, assetInstanceVersionId.toString(),
							assetName, apd.getAssetParamName(), conn);
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv.setAssetParamName(apd.getAssetParamName());
					aiv.setParamValue(derivedData);
					aiv.setAsset_category_name(apd.getAssetCategoryName());
					aiv.setParam_disp(apd.getParameter_disp_position());
					aiv.setCat_disp(apd.getCategory_disp_position());
					aiv.setAssetParamId(apd.getAssetParamId());
					aiv.setIsStatic(apd.getIs_static());
					aiv.setParamTypeId(apd.getParamTypeId());
					aiv.setDescription(apd.getDescription());
					nonStaticList.add(aiv);
				} else if (apd.getParamTypeId() == 6) {
					AssetInstanceVersion aiv = new AssetInstanceVersion();

					String count = dao.getDerivedComputationValues(userName, assetInstanceVersionId.toString(),
							assetName, apd.getAssetParamName(), conn);
					aiv.setAsset_category_name(apd.getAssetCategoryName());
					aiv.setAssetParamName(apd.getAssetParamName());
					aiv.setParamValue(count);
					aiv.setParam_disp(apd.getParameter_disp_position());
					aiv.setCat_disp(apd.getCategory_disp_position());
					aiv.setAssetParamId(apd.getAssetParamId());
					aiv.setIsStatic(apd.getIs_static());
					aiv.setParamTypeId(apd.getParamTypeId());
					aiv.setDescription(apd.getDescription());
					nonStaticList.add(aiv);
				} else if(apd.getParamTypeId() == 8) {
					String derivedAssetListValue = dao.getDerivedAttributeForAssetListValues(userName, assetInstanceVersionId.toString(),
							assetName, apd.getAssetParamName(), conn);
					
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv.setAssetParamName(apd.getAssetParamName());
					aiv.setParamValue(derivedAssetListValue);
					aiv.setAsset_category_name(apd.getAssetCategoryName());
					aiv.setParam_disp(apd.getParameter_disp_position());
					aiv.setCat_disp(apd.getCategory_disp_position());
					aiv.setAssetParamId(apd.getAssetParamId());
					aiv.setIsStatic(apd.getIs_static());
					aiv.setParamTypeId(apd.getParamTypeId());
					aiv.setDescription(apd.getDescription());
					nonStaticList.add(aiv);
				}
			}

			if (nonStaticParams.length() != 0) {
				nonStaticParams = nonStaticParams.deleteCharAt(nonStaticParams.length() - 1);
			}
			if (staticParams.length() != 0) {
				staticParams = staticParams.deleteCharAt(staticParams.length() - 1);
			}

			

			if (nonStaticParams.length() != 0) {
				if (log.isTraceEnabled()) {
					log.trace(
							"getAssetInstancePropertiesDetails || Dao method call getNonStaticParamDefWithCategoryNames()");
				}
				List<AssetInstanceVersion> list = dao.getNonStaticParamDefWithCategoryNames(assetName,
						assetInstanceVersionId, nonStaticParams.toString(),userName, conn);

				nonStaticList.addAll(list);

			}

			if (staticParams.length() != 0) {
				dao = new AssetInstanceVersionDao();
				if (log.isTraceEnabled()) {
					log.trace(
							"getAssetInstancePropertiesDetails || Dao method call getStaticParamDefWithCategoryNames()");
				}
				staticList = dao.getStaticParamDefWithCategoryNames(assetName, staticParams.toString(),userName,conn);
			}

			staticList.addAll(nonStaticList);
			
			/*AssetInstanceVersion aivv = null;
			for(AssetInstanceVersion a : staticList){
				aivv = new AssetInstanceVersion();
				RTFTextWithTags.add(a.getParamValue());
			}
			aivv.setRTFwithTags(RTFTextWithTags);
			staticList.add(aivv);*/
			
			if (staticList.size() != 0) {
				if (staticList.size() < params.size()) {
					class AssetParameterComparator implements Comparator<AssetInstanceVersion> {

						@Override
						public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
							return o1.getAssetParamName().toLowerCase().compareTo(o2.getAssetParamName().toLowerCase());
						}
					}
					Collections.sort(staticList, new AssetParameterComparator());
					List<AssetInstanceVersion> finalList = new ArrayList<AssetInstanceVersion>();

					for (int i = 0; i < params.size(); i++) {

						AssetParamDef apd = params.get(i);
						boolean flag = false;
						for (int k = 0; k < staticList.size(); k++) {
							AssetInstanceVersion aiv1 = staticList.get(k);
							if (aiv1.getAssetParamName().equalsIgnoreCase(apd.getAssetParamName())) {
								flag = true;
								finalList.add(staticList.get(k));
								break;
							}
							if (flag) {

								break;
							}

							if (staticList.size() == k + 1) {
								if (!flag) {
									AssetInstanceVersion aiv = new AssetInstanceVersion();
									if (apd.getParamTypeId() == 1)
										aiv.setParamTextSize(apd.getSize());

									aiv.setAsset_category_name(apd.getAssetCategoryName());
									aiv.setCat_disp(apd.getCategory_disp_position());
									aiv.setParam_disp(apd.getParameter_disp_position());
									aiv.setAssetParamName(apd.getAssetParamName());
									aiv.setApdFileName(apd.getFileName());
									aiv.setStaticValue(apd.getStaticValue());
									aiv.setIsStatic(apd.getIs_static());
									aiv.setParamTypeId(apd.getParamTypeId());
									aiv.setDerivedAttributeComputation(apd.getDerivedAttributeComputation());
									aiv.setListTypeParamTypeId(apd.getListTypeParamTypeId());
									aiv.setMappedAssetId(apd.getMappedAssetId());
									aiv.setAssetParamId(apd.getAssetParamId());
									aiv.setDescription(apd.getDescription());
									aiv.setMandatory(apd.isHasMandatoryValue());
									aiv.setHasArray(apd.getHasArray());
									//modified by pinak
									if(apd.getParamTypeId()==4L || apd.getParamTypeId()==9L) {
										if(apd.getListType() == 0)
											aiv.setSingleMultipleFlag(true);	//single
										if(apd.getListType() == 1)
											aiv.setSingleMultipleFlag(false);	//multiple
									}
									
									aiv.setCategoryId(apd.getAssetCategoryId());
									// modified by gomathi to add edit access for each category
									if(userName.equalsIgnoreCase("admin")){
										aiv.setEditAccessFlag(true);	
									}else if(userName.equalsIgnoreCase("roleAnonymous")){
										aiv.setEditAccessFlag(false);	
									}else{
									List<GroupDetails> gd = assetdao.getAssetCategoryEditAccessForPropertiesAivPage(userName,aiv.getCategoryId(), conn);
									   for(GroupDetails gd1 : gd){
										   if(gd1.getEditAccess() == 1L){
											   aiv.setEditAccessFlag(true);	
											   break;
										   }
									   }
									}
									finalList.add(aiv);
								}

							}
						}
					}
					staticList = finalList;
				}
			} else {
				for (int i = 0; i < params.size(); i++) {
					AssetParamDef apd = params.get(i);
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					if (apd.getParamTypeId() == 1)
						aiv.setParamTextSize(apd.getSize());

					aiv.setAsset_category_name(apd.getAssetCategoryName());
					aiv.setCat_disp(apd.getCategory_disp_position());
					aiv.setParam_disp(apd.getParameter_disp_position());
					aiv.setAssetParamName(apd.getAssetParamName());
					aiv.setApdFileName(apd.getFileName());
					aiv.setStaticValue(apd.getStaticValue());
					aiv.setIsStatic(apd.getIs_static());
					aiv.setParamTypeId(apd.getParamTypeId());
					aiv.setDerivedAttributeComputation(apd.getDerivedAttributeComputation());
					aiv.setListTypeParamTypeId(apd.getListTypeParamTypeId());
					aiv.setMappedAssetId(apd.getMappedAssetId());
					aiv.setAssetParamId(apd.getAssetParamId());
					aiv.setMandatory(apd.isHasMandatoryValue());
					aiv.setHasArray(apd.getHasArray());
					aiv.setDescription(apd.getDescription());
					aiv.setCategoryId(apd.getAssetCategoryId());
					//Changes done by pinak
					aiv.setListType(apd.getListType());
					if(apd.getParamTypeId()==4L || apd.getParamTypeId()==9L) {
						if(apd.getListType() == 0)
							aiv.setSingleMultipleFlag(true);	//single
						if(apd.getListType() == 1)
							aiv.setSingleMultipleFlag(false);	//multiple
					}
					// modified by gomathi to add edit access for each category
					if(userName.equalsIgnoreCase("admin")){
						aiv.setEditAccessFlag(true);	
					}else if(userName.equalsIgnoreCase("roleAnonymous")){
						aiv.setEditAccessFlag(false);	
					}else{
					List<GroupDetails> gd = assetdao.getAssetCategoryEditAccessForPropertiesAivPage(userName,aiv.getCategoryId(), conn);
					   for(GroupDetails gd1 : gd){
						   if(gd1.getEditAccess() == 1L){
							   aiv.setEditAccessFlag(true);	
							   break;
						   }
					   }
					}
					staticList.add(aiv);
				}
			}
			@SuppressWarnings("unused")
			class AssetInstanceVersinsComparator implements Comparator<AssetInstanceVersion> {

				private List<Comparator<AssetInstanceVersion>> listComparators;

				@SuppressWarnings("unused")
				AssetInstanceVersinsComparator(Comparator<AssetInstanceVersion>... comparators) {
					this.listComparators = Arrays.asList(comparators);
				}

				public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
					for (Comparator<AssetInstanceVersion> comparator : listComparators) {
						int result = comparator.compare(o1, o2);
						if (result != 0) {
							return result;
						}
					}
					return 0;
				}
			}
			@SuppressWarnings("unused")
			class Category_disp_position_Comparator implements Comparator<AssetInstanceVersion> {

				public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
					if (o1.getCat_disp() == o2.getCat_disp())
						return 0;
					return o1.getCat_disp() < o2.getCat_disp() ? -1 : 1;
				}
			}
			class Parameter_disp_position_Comparator implements Comparator<AssetInstanceVersion> {

				public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
					if (o1.getParam_disp() == o2.getParam_disp())
						return 0;
					return o1.getParam_disp() < o2.getParam_disp() ? -1 : 1;
				}
			}
			Collections.sort(staticList, new AssetInstanceVersinsComparator(new Category_disp_position_Comparator(),
					new Parameter_disp_position_Comparator()));
			finalData = staticList;
			
			AssetDao assetDao = new AssetDao();
			for(AssetInstanceVersion ldapmappingdata:finalData) {
				if(ldapmappingdata.getParamTypeId()==9L) {
					List<LDAPUser> ldapList = new ArrayList<LDAPUser>();
					LDAPUser ldapUser = new LDAPUser();
					if(ldapmappingdata.getLdapMappingValue() != null) {
						if(!ldapmappingdata.getLdapMappingValue().isEmpty()) {
							if(ldapmappingdata.getLdapMappingValue().size() != 0) {
								for (Map.Entry<String,Integer> entry : ldapmappingdata.getLdapMappingValue().entrySet()){
									AssetParamDef assetParamDef = assetDao.getParamIdForAssetAndParamName(assetName, ldapmappingdata.getAssetParamName(), conn);
									List<LdapMapping> ldapAttributeList = assetDao.getLdapMappingAttributeList(assetParamDef.getLdapMappingId(), conn);
									for(LdapMapping attribute:ldapAttributeList){
										String attributeName = attribute.getAttributeName().substring(3);
										if(attributeName.equalsIgnoreCase(CommonUtils.LdapFirstName)) {
											if(attribute.getLdapAttributeId() == entry.getValue()) {
												ldapUser.setFirstName(entry.getKey());
												ldapUser.setFirstNameAttributeId(attribute.getLdapAttributeId());
											}
										}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapLastName)) {
											if(attribute.getLdapAttributeId() == entry.getValue()) {
												ldapUser.setLastName(entry.getKey());
												ldapUser.setLastNameAttributeId(attribute.getLdapAttributeId());
											}
										}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapEmail)) {
											if(attribute.getLdapAttributeId() == entry.getValue()) {
												ldapUser.setEmail(entry.getKey());
												ldapUser.setEmailAttributeId(attribute.getLdapAttributeId());
											}
										}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapDept)) {
											if(attribute.getLdapAttributeId() == entry.getValue()) {
												ldapUser.setDept(entry.getKey());
												ldapUser.setDeptAttributeId(attribute.getLdapAttributeId());
											}
										}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapUserId)) {
											if(attribute.getLdapAttributeId() == entry.getValue()) {
												ldapUser.setUserId(entry.getKey());
												ldapUser.setUserIdAttributeId(attribute.getLdapAttributeId());
												
											}
										}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapFullName)) {
											if(attribute.getLdapAttributeId() == entry.getValue()) {
												ldapUser.setFullName(entry.getKey());
												ldapUser.setFullNameAttributeId(attribute.getLdapAttributeId());
											}
										}
									}
								}
								if(ldapUser != null) {
									ldapList.add(ldapUser);
									ldapmappingdata.setLdapmappingdata(ldapList);
								}
							}
						}
					}
				}
			}
			
		} catch (RepoproException e) {
			log.error("getAssetInstancePropertiesDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstancePropertiesDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancePropertiesDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstancePropertiesDetails || " + " || exit");
		}
		
		if(!(staticList.size() == 0) ){
			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_PARAMETERS_SUCCESSFULLY_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_PARAMETERS_NOT_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(finalData))).build();

	}

	/**
	 * @method getDerivedAttributeValues
	 * @description to get derived attribute value
	 * @param user
	 *            name,assetInstanceVersionId,assetName,paramterName
	 * @return Response String
	 * @throws RepoproException
	 */
	@GET
	@Path("/getDerivedAttributeValues")
	public Response getDerivedAttributeValues(@QueryParam("userName") String userName,
			@QueryParam("assetInstanceVersionId") String assetInstanceVersionId,
			@QueryParam("assetName") String assetName, @QueryParam("parameterName") String parameterName) {
		if (log.isTraceEnabled()) {
			log.trace("getDerivedAttributeValues || begin  with userName : " + userName + " assetName " + assetName);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
		Connection conn = null;
		String derivedAttribute = null;
		if (log.isTraceEnabled()) {
			log.trace("getDerivedAttributeValues || " + Constants.LOG_CONNECTION_OPEN);
		}
		try {
			if (log.isTraceEnabled()) {
				log.trace("getDerivedAttributeValues || Dao method call getDerivedAttributeValues()");
			}
			assetName = URLDecoder.decode(assetName, "UTF-8");
			conn = DBConnection.getInstance().getConnection();
			derivedAttribute = dao.getDerivedAttributeValues(userName, assetInstanceVersionId, assetName, parameterName,
					conn);
			retStat = Status.OK;
			retMsg = Constants.DERIVED_ATTRIBUTE_FETCHED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} catch (RepoproException e) {
			log.error("getDerivedAttributeValues || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getDerivedAttributeValues ||	 " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getDerivedAttributeValues || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getDerivedAttributeValues || " + " || exit");
		}
		ArrayList<Object> derivedAttributeList = new ArrayList<Object>();
		derivedAttributeList.add(derivedAttribute);
		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, derivedAttributeList))
				.build();
	}

	/**
	 * @method getDerivedComputationValues
	 * @description to get derived computation value
	 * @param user
	 *            name,assetInstanceVersionId,assetName,paramterName
	 * @return Response String
	 * @throws RepoproException
	 */
	@GET
	@Path("/getDerivedComputationValues")
	public Response getDerivedComputationValues(@QueryParam("userName") String userName,
			@QueryParam("assetInstanceVersionId") String assetInstanceVersionId,
			@QueryParam("assetName") String assetName, @QueryParam("parameterName") String parameterName) {

		if (log.isTraceEnabled()) {
			log.trace("getDerivedComputationValues || begin  with userName : " + userName + " assetName " + assetName);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
		Connection conn = null;
		String derivedAttribute = null;
		if (log.isTraceEnabled()) {
			log.trace("getDerivedComputationValues || " + Constants.LOG_CONNECTION_OPEN);
		}
		try {
			if (log.isTraceEnabled()) {
				log.trace("getDerivedComputationValues || Dao method call getDerivedComputationValues()");
			}
			conn = DBConnection.getInstance().getConnection();
			derivedAttribute = dao.getDerivedComputationValues(userName, assetInstanceVersionId, assetName,
					parameterName, conn);
			retStat = Status.OK;
			retMsg = Constants.DERIVED_COMPUTATION_FETCHED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} catch (RepoproException e) {
			log.error("getDerivedComputationValues || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getDerivedComputationValues || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getDerivedComputationValues || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getDerivedComputationValues || " + " || exit");
		}
		ArrayList<Object> derivedComputationList = new ArrayList<Object>();
		derivedComputationList.add(derivedAttribute);
		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, derivedComputationList))
				.build();
	}
	
	

	/**
	 * @method getAssetInstanceBrowseGrid
	 * @description to get filtered and show and hide asset instance grid
	 * @param user
	 *            name
	 * @return Response List<AssetInstanceVersion>
	 * @throws RepoproException
	 */
	@GET
	@Path("/getAssetInstanceBrowseGrid")
	public Response getAssetInstanceBrowseGrid(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("assetId") Long assetId,
			@QueryParam("from") int from,@QueryParam("restApiFlag") boolean restApiFlag) {
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceBrowseGrid || begin  with userName : " + userName + " assetName " + assetName);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;

		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<AssetInstanceVersion> assetInstVerList = new ArrayList<AssetInstanceVersion>();
		List<AssetInstance> listOfAssetInstanceVos = new ArrayList<AssetInstance>();

		User user = null;
		UserDao userDao = new UserDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceBrowseGrid || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			ShowHideManager shd = new ShowHideManager();
			ShowHideColumn hideColumn = new ShowHideColumn();
			AssetInstanceVersionDao dao = null;
			hideColumn.setAssetId(assetId);
			if (!userName.equalsIgnoreCase("roleAnonymous")) {
				// userDao = new UserDao();
				user = userDao.retProfileForUserName(userName, conn);
				hideColumn.setUserId(user.getUserId());
			}

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceBrowseGrid || dao method called : getShowHideParams(assetId,UserId)");
			}
			ShowHideColumn shc = shd.getShowHideParamValues(hideColumn, userName, conn);

			java.util.Map<Long, String> hideParameters = shc.getShowParamDetails();
			int showHideParamCount = hideParameters.size();
			String assetParamName = new String();
			@SuppressWarnings("rawtypes")
			Iterator itr = hideParameters.entrySet().iterator();
			while (itr.hasNext()) {
				@SuppressWarnings("rawtypes")
				java.util.Map.Entry pair = (java.util.Map.Entry) itr.next();
				assetParamName = assetParamName.concat(pair.getValue().toString() + ",");

			}
			
			if (assetParamName.length() != 0) {
				// non static and static information
				String[] paramNames = assetParamName.split(",");
				StringBuffer sb = new StringBuffer();
				int sizeOfParameters = 0;

				for (int i = 0; i < paramNames.length; i++) {
					sizeOfParameters = i;
					sb.append(paramNames[i] + ",");
					if (i == 2) {
						break;
					}
				}
				StringBuffer staticParameters = new StringBuffer();
				StringBuffer nonStaticParameters = new StringBuffer();
				int paramCount = sizeOfParameters;
				paramCount = paramCount + 1;
				int maximumParamCount = 0;
				for (int i = 0; i < paramNames.length; i++) {
					String paramName = paramNames[i];
					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceBrowseGrid || dao method called : getAssetParamDefByAssetNameAndParamName(assetName,paramName)");
					}
					AssetParamDef paramdef = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(assetName,
							paramName, conn);
					if (paramdef.getIs_static() != 1) {// non-static
						nonStaticParameters.append(paramdef.getAssetParamName() + ",");
					} else {
						staticParameters.append(paramdef.getAssetParamName() + ",");
					}
					maximumParamCount++;
					if (maximumParamCount == 3)
						break;
				}

				List<AssetInstanceVersion> listofStaticInformation = null;
				List<AssetInstanceVersion> listofNonStaticInformation = null;
				

				if (nonStaticParameters.length() != 0) {
					nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length() - 1);
				}
				if (staticParameters.length() != 0) {
					staticParameters = staticParameters.deleteCharAt(staticParameters.length() - 1);
				}

				if (nonStaticParameters.length() != 0) {
					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceBrowseGrid || dao method called : getAssetParamDefsByParameters(parameters,assetName)");
					}
					List<AssetParamDef> listOfNonStaticParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(nonStaticParameters.toString(), assetName, conn);

					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceBrowseGrid || dao method called : getAssetInstanceVersionDetailsWithNonStaticParameters(assetName,parameters)");
					}
					listofNonStaticInformation = assetInstanceVersionDao
							.getAssetInstanceVersionDetailsWithNonStaticParameters(assetName,
									nonStaticParameters.toString(), userName, from,restApiFlag, conn);
					TreeMap<String, String> paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					TreeMap<String, String> paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					
					Long newAssetInstVersionId = 0L;
					int jj = 1;
					for (int i = 0; i < listofNonStaticInformation.size(); i++) {
						AssetInstanceVersion aiv = listofNonStaticInformation.get(i);
						newAssetInstVersionId = aiv.getAssetInstVersionId();
						boolean flag = false;
						AssetInstance vo = new AssetInstance();
						vo.setAssetInstId(aiv.getAssetInstanceId());
						vo.setAssetInstName(aiv.getAssetInstName());
						vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
						vo.setDescription(aiv.getDescription());
						vo.setVersionName(aiv.getVersionName());
						vo.setVersionable(aiv.getVersionable());
						vo.setIconImageName(aiv.getIconImageName());
						vo.setEditAccessFlag(aiv.isEditAccessFlag());
						vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
						vo.setShowHideParamCount(showHideParamCount);
						vo.setParamTypeId(aiv.getParamTypeId());
						vo.setRTFwithTags(aiv.getRTFwithTags());
						vo.setTextDataList(aiv.getTextDataList());
						vo.setLdapMappingValues(aiv.getLdapMappingValue());
						vo.setHasArray(aiv.getHasArray());
						vo.setLdapMappingCount(aiv.getLdapMappingListCount());
												
						// }
						for (int j = 0; j < listOfNonStaticParamDefs.size(); j++) {
							AssetParamDef apd = listOfNonStaticParamDefs.get(j);
							if (aiv.getAssetParamName() != null) {
								if (aiv.getAssetParamName().equalsIgnoreCase(apd.getAssetParamName())) {
									flag = true;

									if (apd.getParamTypeId() == 3) {
										paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getFileName());

									} else {
										if (apd.getParamTypeId() == 5) {
											paramValues.put(apd.getAssetParamName(),
													"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),
													"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()+ "~" + apd.getAssetParamName());

										} else if (apd.getParamTypeId() == 6) {
											paramValues.put(apd.getAssetParamName(),
													"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),
													"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()+ "~" + apd.getAssetParamName());
										} else if (apd.getParamTypeId() == 8) {
											paramValues.put(apd.getAssetParamName(),
													"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),
													"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName());
										
										}else if(apd.getParamTypeId() == 7){
											if(apd.getHasArray() == 1){
												String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
												paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), rtfTags);
											}else if(apd.getHasArray() == 0){
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
											}
											
										}else if(apd.getParamTypeId() == 1){
											if(apd.getHasArray() == 1){
												String textData = StringUtils.join(aiv.getTextDataList(), "~~");
												paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), textData);
											}else if(apd.getHasArray() == 0){
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
											}
											
										}else if(apd.getParamTypeId() == 9){
											String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
											paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), ldapData);
										}
										
										else {
											// user =
											// userDao.retProfiledetailsForUserName(aiv.getParamValue(),
											// conn);
											/*
											 * user = userDao.
											 * retProfiledetailsForUserName(
											 * userName, conn); if(user !=
											 * null){
											 * if(user.getActiveFlag().equals(
											 * "1")){ paramValues.put(apd.
											 * getAssetParamName(),
											 * aiv.getParamValue()); }else{
											 * paramValues.put(apd.
											 * getAssetParamName(), ""); } }
											 */
											paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
										}
									}
									if (flag) {
										if(restApiFlag == true) {
											vo.setParamNameWithValues(paramValuesRest);
										}else {
											vo.setParamNameWithValues(paramValues);
										}
										break;
									}
								}
							} else {
								if (apd.getParamTypeId() == 3) {
									if(aiv.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(),"`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getFileName());
								
								} else {
									if (apd.getParamTypeId() == 5) {
										paramValues.put(apd.getAssetParamName(), "^^DA^^~" + aiv.getAssetInstVersionId()
												+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), "^^DA^^~" + aiv.getAssetInstVersionId()
										+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName());
										
									} else if (apd.getParamTypeId() == 6) {
										paramValues.put(apd.getAssetParamName(), "^^DC^^~" + aiv.getAssetInstVersionId()
												+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), "^^DC^^~" + aiv.getAssetInstVersionId()
										+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName());
										
									}else if (apd.getParamTypeId() == 8) {
										paramValues.put(apd.getAssetParamName(), "^^AC^^~" + aiv.getAssetInstVersionId()
										+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), "^^AC^^~" + aiv.getAssetInstVersionId()
										+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName());
									}
									else if(apd.getParamTypeId() == 7){
										if(apd.getHasArray() == 1){
											String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
											if(rtfTags == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray());
											}else{
												paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), rtfTags);
											
										}else if(apd.getHasArray() == 0){
											if(aiv.getParamValue() == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
										}
									}else if(apd.getParamTypeId() == 1){
										if(apd.getHasArray() == 1){
											String textData = StringUtils.join(aiv.getTextDataList(), "~~");
											if(textData == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), textData);
											
										}else if(apd.getHasArray() == 0){
											if(aiv.getParamValue() == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
										}
									}else if(apd.getParamTypeId() == 9){
										String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
										if(ldapData == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										}else{
											paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										}
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), ldapData);
									}else {
										if(aiv.getParamValue() == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}else{
											paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
									}
								}
								if(restApiFlag == true) {
									vo.setParamNameWithValues(paramValuesRest);
								}else {
									vo.setParamNameWithValues(paramValues);
								}
							}

						}
						Map<String, String> finalValues = vo.getParamNameWithValues();

						for (AssetParamDef assetParamDef : listOfNonStaticParamDefs) {
							boolean flag1 = false;
							for (Map.Entry<String, String> map : finalValues.entrySet()) {

								if(restApiFlag == true) {
									String paramNameArray[] = map.getKey().split("`@`");
									if (assetParamDef.getAssetParamName().equalsIgnoreCase(paramNameArray[0])) {
										flag1 = true;
										break;
									}
								}else {
									if (assetParamDef.getAssetParamName().equalsIgnoreCase(map.getKey())) {
										flag1 = true;
										break;
									}
								}
							}
							if (!flag1) {
								if (assetParamDef.getParamTypeId() == 3) {
									if(assetParamDef.getFileName() == null) {
										paramValues.put(assetParamDef.getAssetParamName(), "`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
									}else{
										paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getFileName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
									}
									paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getFileName());
								} else {
									if (assetParamDef.getParamTypeId() == 5) {
										paramValues.put(assetParamDef.getAssetParamName(),
												"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(),
												"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName());
									} else if (assetParamDef.getParamTypeId() == 6) {
										paramValues.put(assetParamDef.getAssetParamName(),
												"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(),
												"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName());
									} else if (assetParamDef.getParamTypeId() == 8) {
										paramValues.put(assetParamDef.getAssetParamName(),
												"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(),
												"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName());
									}
									else if(assetParamDef.getParamTypeId() == 7){
										if(assetParamDef.getHasArray() == 1){
											if(assetParamDef.getParamValue() == null) {
												//String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												//String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
											
										}else if (assetParamDef.getHasArray() == 0){
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
										}
									}else if(assetParamDef.getParamTypeId() == 1){
										if(assetParamDef.getHasArray() == 1){
											if(assetParamDef.getParamValue() == null) {
											//String textData = StringUtils.join(aiv.getTextDataList(), "~~");
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());

											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
										}else if(assetParamDef.getHasArray() == 0){
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
										}
									}else if(assetParamDef.getParamTypeId() == 9){
										if(assetParamDef.getParamValue() == null) {
											//String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
											paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}else {
											//String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
											paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
									}else {
										if(assetParamDef.getParamValue() == null) {
											paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}else {
											paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
									}
								}
								if(restApiFlag == true) {
									vo.setParamNameWithValues(paramValuesRest);
								}else {
									vo.setParamNameWithValues(paramValues);
								}
							}
						}
						if (i < listofNonStaticInformation.size() - 1) {
							if (!newAssetInstVersionId
									.equals(listofNonStaticInformation.get(jj).getAssetInstVersionId())) {
								listOfAssetInstanceVos.add(vo);
								paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
								paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
							}

						} else {
							listOfAssetInstanceVos.add(vo);
						}
						jj++;
					}

				}
				if (staticParameters.length() != 0) {
					// static information
					TreeMap<String, String> paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					TreeMap<String, String> paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceBrowseGrid || dao method called : getAssetParamDefsByParameters(staticParameters,assetName)");
					}
					List<AssetParamDef> listOfStaticParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(staticParameters.toString(), assetName, conn);
					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceBrowseGrid || dao method called : getAssetInstanceVersionDetailsWithStaticParameters(assetName,userName,from)");
					}
					listofStaticInformation = assetInstanceVersionDao
							.getAssetInstanceVersionDetailsWithStaticParameters(assetName, userName, from, restApiFlag,conn);
					if (nonStaticParameters.length() != 0) {
						AssetInstance vo = new AssetInstance();
						for (int i = 0; i < listOfAssetInstanceVos.size(); i++) {

							AssetInstance aivo = listOfAssetInstanceVos.get(i);
							for (int k = 0; k < listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if (apd.getParamTypeId() == 3) {
									if(apd.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else {
										paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getFileName());
								} else {
									if(apd.getStaticValue() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}else {
										paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getStaticValue());
								}
							}
							java.util.Map<String, String> map = aivo.getParamNameWithValues();
							if (map != null) {
								if(restApiFlag == true) {
									map.putAll(paramValuesRest);
								}else {
									map.putAll(paramValues);
								}
								
								aivo.setParamNameWithValues(map);
								listOfAssetInstanceVos.set(i, aivo);
							} else {
								if(restApiFlag == true) {
									aivo.setParamNameWithValues(paramValuesRest);
								}else {
									aivo.setParamNameWithValues(paramValues);
								}
								
								listOfAssetInstanceVos.set(i, aivo);
							}
						}
						paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
						paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					} else {
						for (int j = 0; j < listofStaticInformation.size(); j++) {
							AssetInstance vo = new AssetInstance();
							AssetInstanceVersion aiv = listofStaticInformation.get(j);
							for (int k = 0; k < listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if (apd.getParamTypeId() == 3) {
									if(apd.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else {
										paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getFileName());
								} else {
									if(apd.getStaticValue() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}else {
										paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}
									paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getStaticValue());
								}
							}
							vo.setAssetInstId(aiv.getAssetInstanceId());
							vo.setAssetInstName(aiv.getAssetInstName());
							vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
							vo.setDescription(aiv.getDescription());
							vo.setVersionName(aiv.getVersionName());
							sizeOfParameters = sizeOfParameters + paramCount;
							if(restApiFlag == true) {
								vo.setParamNameWithValues(paramValuesRest);
							}else {
								vo.setParamNameWithValues(paramValues);
							}
							vo.setVersionable(aiv.getVersionable());
							vo.setIconImageName(aiv.getIconImageName());
							vo.setEditAccessFlag(aiv.isEditAccessFlag());
							vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
							vo.setShowHideParamCount(showHideParamCount);
							vo.setParamTypeId(aiv.getParamTypeId());
							vo.setRTFwithTags(aiv.getRTFwithTags());
							vo.setTextDataList(aiv.getTextDataList());
							vo.setLdapMappingCount(aiv.getLdapMappingListCount());
							listOfAssetInstanceVos.add(vo);
							paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
							paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
						}
					}
				}
			} else {
				// getBasic information
				if (log.isTraceEnabled()) {
					log.trace(
							"getAssetInstanceBrowseGrid || dao method called : getBasicAssetInstanceVersionInformationByAssetName( assetName)");
				}
				List<AssetInstanceVersion> basicInformationOfassetInstance = assetInstanceVersionDao
						.getAassetInstanceDetailsWithOutParameters(assetName, userName, from, conn);

				for (int i = 0; i < basicInformationOfassetInstance.size(); i++) {
					AssetInstanceVersion aiv = basicInformationOfassetInstance.get(i);
					AssetInstance vo = new AssetInstance();
					vo.setAssetInstId(aiv.getAssetInstanceId());
					vo.setAssetInstName(aiv.getAssetInstName());
					vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
					vo.setDescription(aiv.getDescription());
					vo.setVersionName(aiv.getVersionName());
					vo.setVersionable(aiv.getVersionable());
					vo.setIconImageName(aiv.getIconImageName());
					vo.setEditAccessFlag(aiv.isEditAccessFlag());
					vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
					vo.setShowHideParamCount(showHideParamCount);
					vo.setParamTypeId(aiv.getParamTypeId());
					vo.setRTFwithTags(aiv.getRTFwithTags());
					vo.setTextDataList(aiv.getTextDataList());
					vo.setLdapMappingCount(aiv.getLdapMappingListCount());
					listOfAssetInstanceVos.add(vo);
				}
			}

			Collections.sort(listOfAssetInstanceVos, new AssetInstance());

			if (log.isDebugEnabled()) {
				log.debug("getAssetInstanceBrowseGrid || " + assetInstVerList.toString());
			}
			log.debug(" getAssetInstanceBrowseGrid  || retrieved " + assetInstVerList.size()
					+ " asset instance version details by asset name : " + assetName.toString());
			
			if(listOfAssetInstanceVos.size() == 0){
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAssetInstanceBrowseGrid || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceBrowseGrid || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceBrowseGrid || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceBrowseGrid || " + assetInstVerList.toString() + " || exit");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(listOfAssetInstanceVos)))
				.build();

	}

	/**
	 * @method getParametersDetailsForAssetInstanceVersion
	 * @description to get paramValues for assetInstanceVersionId
	 * @param user
	 *            name
	 * @return Response parameterValues
	 * @throws RepoproException
	 */
	@GET
	@Path("/getParametersDetailsForAssetInstanceVersion")
	public Response getParametersDetailsForAssetInstanceVersion(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("assetId") Long assetId,
			@QueryParam("assetInstanceVersionId") Long assetInstanceVersionId,@QueryParam("restApiFlag") boolean restApiFlag) {

		if (log.isTraceEnabled()) {
			log.trace("getParametersDetailsForAssetInstanceVersion || begin  with userName : " + userName
					+ " assetName " + assetName);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		Connection conn = null;
		TreeMap<String, String> paramValues = null;
		TreeMap<String, String> paramValuesRest = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getParametersDetailsForAssetInstanceVersion || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			ShowHideManager shd = new ShowHideManager();

			ShowHideColumn hideColumn = new ShowHideColumn();

			hideColumn.setAssetId(assetId);
			if (!userName.equalsIgnoreCase("roleAnonymous")) {
				UserDao userDao = new UserDao();
				User user = userDao.retProfileForUserName(userName, conn);
				hideColumn.setUserId(user.getUserId());
			}

			if (log.isTraceEnabled()) {
				log.trace(
						"getParametersDetailsForAssetInstanceVersion || dao method called : getShowHideParams(assetId,UserId)");
			}
			ShowHideColumn shc = shd.getShowHideParamValues(hideColumn, userName, conn);

			java.util.Map<Long, String> hideParameters = shc.getShowParamDetails();

			String assetParamName = new String();
			@SuppressWarnings("rawtypes")
			Iterator itr = hideParameters.entrySet().iterator();
			while (itr.hasNext()) {
				@SuppressWarnings("rawtypes")
				java.util.Map.Entry pair = (java.util.Map.Entry) itr.next();
				assetParamName = assetParamName.concat(pair.getValue().toString() + ",");
			}

			StringBuffer nonStaticParameters = new StringBuffer();
			StringBuffer staticParameters = new StringBuffer();
			// System.out.println("ss "+assetParamName.length());
			if (assetParamName.length() != 0) {
				paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
				paramValuesRest = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
				String[] paramNames = assetParamName.split(",");
				StringBuffer sb = new StringBuffer();
				sb.append(assetParamName);
				for (int i = 0; i < paramNames.length; i++) {
					String paramName = paramNames[i];
					if (log.isTraceEnabled()) {
						log.trace(
								"getParametersDetailsForAssetInstanceVersion || dao method called : getAssetParamDefByAssetNameAndParamName(assetName,paramName)");
					}
					AssetParamDef paramdef = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(assetName,
							paramName, conn);
					if (paramdef.getIs_static() != 1) {// non-static
						nonStaticParameters.append(paramdef.getAssetParamName() + ",");
					} else {
						staticParameters.append(paramdef.getAssetParamName() + ",");
					}
				}

				if (staticParameters.length() != 0) {
					staticParameters = staticParameters.deleteCharAt(staticParameters.length() - 1);
				}
				if (nonStaticParameters.length() != 0) {
					nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length() - 1);
				}

				if (nonStaticParameters.length() != 0) {
					List<AssetInstanceVersion> listofNonStaticInformation = null;
					if (log.isTraceEnabled()) {
						log.trace(
								"getParametersDetailsForAssetInstanceVersion || dao method called : getAssetParamDefsByParameters(parameters,assetName)");
					}

					List<AssetParamDef> nonStaticListOfParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(nonStaticParameters.toString(), assetName, conn);
					if (log.isTraceEnabled()) {
						log.trace(
								"getParametersDetailsForAssetInstanceVersion || dao method called : getAssetInstanceVersionDetailsWithNonStaticParameters(assetName,parameters)");
					}
					listofNonStaticInformation = assetInstanceVersionDao.getShowMoreParameterDetailsForNonStatic(
							assetName, sb.toString(), userName, assetInstanceVersionId, conn);
					
					for (int i = 0; i < listofNonStaticInformation.size(); i++) {

						AssetInstanceVersion aiv = listofNonStaticInformation.get(i);
						for (int j = 0; j < nonStaticListOfParamDefs.size(); j++) {
							AssetParamDef apd = nonStaticListOfParamDefs.get(j);
							if (aiv.getAssetParamName() != null) {
								if (aiv.getAssetParamName().equalsIgnoreCase(apd.getAssetParamName())) {
									if (apd.getIs_static() == 1) {
										if (apd.getParamTypeId() == 3) {
											paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getFileName());

										} else {
											paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getStaticValue());

										}
									} else {
										if (apd.getParamTypeId() == 3) {
											paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getFileName());

										} else {
											AssetInstanceVersionDao dao = null;
											if (apd.getParamTypeId() == 5) {
												dao = new AssetInstanceVersionDao();
												String derivedValue = dao.getDerivedAttributeValues(userName,
														assetInstanceVersionId.toString(), assetName,
														apd.getAssetParamName(), conn);
												paramValues.put(apd.getAssetParamName(), derivedValue+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), derivedValue);

											} else if (apd.getParamTypeId() == 6) {
												dao = new AssetInstanceVersionDao();
												String derivedComputationValue = dao.getDerivedComputationValues(
														userName, assetInstanceVersionId.toString(), assetName,
														apd.getAssetParamName(), conn);
												paramValues.put(apd.getAssetParamName(), derivedComputationValue+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), derivedComputationValue);

											} else if (apd.getParamTypeId() == 8) {
												dao = new AssetInstanceVersionDao();
												String derivedAssetListValue = dao.getDerivedAttributeForAssetListValues(userName,
														assetInstanceVersionId.toString(), assetName, apd.getAssetParamName(), conn);
												paramValues.put(apd.getAssetParamName(), derivedAssetListValue+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), derivedAssetListValue);

											}else if(apd.getParamTypeId() == 7){
												if(apd.getHasArray() == 1){
													String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
													paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
													paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), rtfTags);

												}else if(apd.getHasArray() == 0){
													paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
													paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), aiv.getParamValue());
												}
												
											}else if(apd.getParamTypeId() == 1){
												if(apd.getHasArray() == 1){
													String textData = StringUtils.join(aiv.getTextDataList(), "~~");
													paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
													paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),textData);
												}else if(apd.getHasArray() == 0){
													paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
													paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),aiv.getParamValue());
												}
												
											}else if(apd.getParamTypeId() == 9){
												String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
												paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),ldapData);

											}else {
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),aiv.getParamValue());
											}
										}
									}
								}
							} else {
								if (apd.getIs_static() == 1) {
									if (apd.getParamTypeId() == 3) {
										if(apd.getFileName() == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										}else {
											paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										}
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),apd.getFileName());

									} else {
										if(apd.getStaticValue() == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}else {
											paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),apd.getStaticValue());

									}
								} else {
									if (apd.getParamTypeId() == 3) {
										if(apd.getFileName() == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										}else {
											paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										}
										paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),aiv.getFileName());

									} else {
										AssetInstanceVersionDao dao = null;
										if (apd.getParamTypeId() == 5) {
											dao = new AssetInstanceVersionDao();
											String derivedValue = dao.getDerivedAttributeValues(userName,
													assetInstanceVersionId.toString(), assetName,
													apd.getAssetParamName(), conn);
											if(derivedValue == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else {
												paramValues.put(apd.getAssetParamName(), derivedValue+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),derivedValue);
											
										} else if (apd.getParamTypeId() == 6) {
											dao = new AssetInstanceVersionDao();
											String derivedComputationValue = dao.getDerivedComputationValues(userName,
													assetInstanceVersionId.toString(), assetName,
													apd.getAssetParamName(), conn);
											if(derivedComputationValue == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else {
												paramValues.put(apd.getAssetParamName(), derivedComputationValue+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),derivedComputationValue);
											
										} else if (apd.getParamTypeId() == 8) {
											dao = new AssetInstanceVersionDao();
											String derivedAssetListValue = dao.getDerivedAttributeForAssetListValues(userName,
													assetInstanceVersionId.toString(), assetName, apd.getAssetParamName(), conn);
											if(derivedAssetListValue == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else {
												paramValues.put(apd.getAssetParamName(), derivedAssetListValue+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),derivedAssetListValue);
											
										}else if(apd.getParamTypeId() == 7){
											if(apd.getHasArray() == 1){
												String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
												if(rtfTags == null) {
													paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												}else {
													paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												}
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),rtfTags);
												
											}else if(apd.getHasArray() == 0){
												if(aiv.getParamValue() == null) {
													paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												}else {
													paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												}
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),aiv.getParamValue());
											}
											
										}else if(apd.getParamTypeId() == 1){
											if(apd.getHasArray() == 1){
												String textData = StringUtils.join(aiv.getTextDataList(), "~~");
												if(textData == null) {
													paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												}else {
													paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												}
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),textData);
											}else if(apd.getHasArray() == 0){
												if(aiv.getParamValue() == null) {
													paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												}else {
													paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
												}
												paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),aiv.getParamValue());
											}
											
										}else if(apd.getParamTypeId() == 9){
											String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
											if(ldapData == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
											}else {
												paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),ldapData);
										
										}else {
											if(aiv.getParamValue() == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
											}else {
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
											}
											paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(),aiv.getParamValue());
										}
									}
								}
							}
						}
						Map<String, String> finalValues = new TreeMap<String, String>();
						if(restApiFlag ==  true) {
							finalValues = paramValuesRest;
						}else {
							finalValues = paramValues;
						}
						
						for (AssetParamDef assetParamDef : nonStaticListOfParamDefs) {
							boolean flag1 = false;
							for (Map.Entry<String, String> map : finalValues.entrySet()) {
								if(restApiFlag == true) {
									String paramNameArray[] = map.getKey().split("`@`");
									if (assetParamDef.getAssetParamName().equalsIgnoreCase(paramNameArray[0])) {
										flag1 = true;
										break;
									}
								}else {
									if (assetParamDef.getAssetParamName().equalsIgnoreCase(map.getKey())) {
										flag1 = true;
										break;
									}
								}
							}
							if (!flag1) {
								if (assetParamDef.getParamTypeId() == 3) {
									if(assetParamDef.getFileName() == null) {
										paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getFileName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
									}else {
										paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getFileName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
									}
									paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getFileName());
								} else {
									if (assetParamDef.getParamTypeId() == 5) {
										paramValues.put(assetParamDef.getAssetParamName(),
												"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(),
												"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName());
										
									} else if (assetParamDef.getParamTypeId() == 6) {
										paramValues.put(assetParamDef.getAssetParamName(),
												"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(),
												"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName());
										
									} else if (assetParamDef.getParamTypeId() == 8) {
										paramValues.put(assetParamDef.getAssetParamName(),
												"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(),
												"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName());
									}else if(assetParamDef.getParamTypeId() == 7){
										if(assetParamDef.getHasArray() == 1){
											//String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
										}else if(assetParamDef.getHasArray() == 0){
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
										}
									}else if(assetParamDef.getParamTypeId() == 1){
										if(assetParamDef.getHasArray() == 1){
											//String textData = StringUtils.join(aiv.getTextDataList(), "~~");
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());

										}else if(assetParamDef.getHasArray() == 0){
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else {
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
											paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());
										}
									}else if(assetParamDef.getParamTypeId() == 9){
										if(assetParamDef.getParamValue() == null) {
											paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}else {
											paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());

									}else {
										if(assetParamDef.getParamValue() == null) {
											paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}else {
											paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}
										paramValuesRest.put(assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId(), assetParamDef.getParamValue());

									}
								}
							}
						}
					}
				}
				if (staticParameters.length() != 0) {
					// static information
					if (log.isTraceEnabled()) {
						log.trace(
								"getParametersDetailsForAssetInstanceVersion || dao method called : getAssetParamDefsByParameters(parameters,assetName)");
					}
					List<AssetParamDef> staticListOfParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(staticParameters.toString(), assetName, conn);
					for (int k = 0; k < staticListOfParamDefs.size(); k++) {
						AssetParamDef apd = staticListOfParamDefs.get(k);
						if (apd.getIs_static() == 1) {
							if (apd.getParamTypeId() == 3) {
								if(apd.getFileName() == null) {
									paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
								}else {
									paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
								}
								paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getFileName());

							} else {
								if(apd.getStaticValue() == null) {
									paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
								}else {
									paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
								}
								paramValuesRest.put(apd.getAssetParamName()+"`@`"+apd.getParamTypeId(), apd.getStaticValue());

							}
						}
					}
				}
				if (log.isDebugEnabled()) {
					log.debug("getParametersDetailsForAssetInstanceVersion || " + paramValues);
				}

				log.debug(" getParametersDetailsForAssetInstanceVersion  || retrieved " + paramValues.size()
						+ assetName.toString());
			}

			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_PARAMETERS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getParametersDetailsForAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getParametersDetailsForAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getParametersDetailsForAssetInstanceVersion || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getParametersDetailsForAssetInstanceVersion || " + paramValues+ " || exit");
		}
		if(restApiFlag == true) {
			return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, paramValuesRest)).build();

		}else {
			return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, paramValues)).build();

		}

	}

	/**
	 * @method getAssetInstanceVersionDetails
	 * @description get asset instance version details
	 * @param assetInstVersionId
	 * @return success response
	 * @throws RepoproException
	 */

	@GET
	@Path("/retrieveAssetcategorywithParameters")
	public Response getAssetParamDefForAssetByGroups(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName) {

		if (log.isTraceEnabled()) {
			log.trace("getAssetParamDefForAssetByGroups || begin  with userName : " + userName + " assetName "
					+ assetName);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		Connection conn = null;
		List<AssetParamDef> parameters = new ArrayList<AssetParamDef>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDefForAssetByGroups || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace(
						"getAssetParamDefForAssetByGroups || dao method called : retAssetParamDefForAssetByGroups by assetName: "
								+ assetName + " userName " + userName);
			}

			parameters = assetInstanceVersionDao.retAssetParamDefForAssetByGroups(assetName, userName, conn);

			if (log.isDebugEnabled()) {
				log.debug(" getAssetParamDefForAssetByGroups  || retrieved all Parameters" + parameters);
			}
			if (userName.equalsIgnoreCase("roleAnonymous")) {
				// if(parameters.size()!=0){
				retStat = Status.OK;
				retMsg = Constants.ASSET_PARAMETERS_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				// }
			} else {
				if (parameters.size() != 0) {
					retStat = Status.OK;
					retMsg = Constants.ASSET_PARAMETERS_FETCHED;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				} else {
					retStat = Status.OK;
					retMsg = Constants.ASSET_PARAM_DEF_NOT_FETCHED;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				}
			}
		}

		catch (RepoproException e) {
			log.error("getAssetParamDefForAssetByGroups || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}

		catch (Exception e) {
			log.error("getAssetParamDefForAssetByGroups || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDefForAssetByGroups || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetParamDefForAssetByGroups || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(parameters))).build();

	}

	/**
	 * @method : addTaxonomyForAssetInstanceVersion
	 * @param assetInstVersionId
	 * @param taxId
	 * @param versionable
	 * @param versionName
	 * @param assetInstName
	 * @return
	 *//*
	@PUT
	@Encoded
	@Path("/assigntaxonomy")
	public Response addTaxonomyForAssetInstanceVersion(@QueryParam("assetInstVersionId") Long assetInstVersionId,
			@QueryParam("taxId") String taxIdd, @QueryParam("versionable") boolean versionable,
			@QueryParam("versionName") String versionName, @QueryParam("assetInstName") String assetInstName) {

		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyForAssetInstanceVersion || begin with assetInstVersionId : " + assetInstVersionId
					+ "\t taxId : " + taxIdd);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<Long> taxIdss = new ArrayList<Long>();
		List<String> emailIds = new ArrayList<String>();
		List<String> emailIds1 = new ArrayList<String>();
		List<String> emailIdsList = new ArrayList<String>();
		List<String> emailIds1List = new ArrayList<String>();
		List<String> taxNameAdd = new ArrayList<String>();
		List<String> taxNameDelete = new ArrayList<String>();

		try {
			
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			conn = DBConnection.getInstance().getConnection();

			TaxonomiesDao tdao = new TaxonomiesDao();
			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();

			if (log.isTraceEnabled()) {
				log.trace(
						"addTaxonomyForAssetInstanceVersion || dao method called : retTaxonomyIdByAssetInstVersionId()");
			}
			List<AssetInstanceVersionTaxonomy> taxIds = dao.retTaxonomyIdByAssetInstVersionId(assetInstVersionId, conn);

			List<Long> taxId = new ArrayList<Long>();
			if (!taxIdd.equalsIgnoreCase("")) {
				for (String s : taxIdd.split(",")) {
					taxId.add(Long.parseLong(s));
				}
			}
			if (taxIds.isEmpty() && taxId.isEmpty()) {

			}

			if (!taxIds.isEmpty()) {
				for (AssetInstanceVersionTaxonomy a : taxIds) {
					taxIdss.add(a.getAivTaxonomyId());
				}
			}

			List<Long> notPresent = new ArrayList<Long>(taxIdss);
			notPresent.removeAll(taxId);

			for (int j = 0; j < notPresent.size(); j++) {

				if (log.isTraceEnabled()) {
					log.trace("addTaxonomyForAssetInstanceVersion || dao method called : getAllTaxonomySubscribers()");
				}
				emailIds1 = tdao.getAllTaxonomySubscribers(conn, notPresent.get(j));

				if (log.isTraceEnabled()) {
					log.trace("addTaxonomyForAssetInstanceVersion || dao method called : getTaxonomiesByParentId()");
				}
				TaxonomyMaster tm = tdao.getTaxonomiesByParentId(notPresent.get(j), conn);

				if (!emailIds1.isEmpty()) {
					for (String Id : emailIds1) {
						emailIds1List.add(Id);
					}
					taxNameDelete.add(tm.getTaxonomyName());
				}
				if (log.isTraceEnabled()) {
					log.trace("addTaxonomyForAssetInstanceVersion || dao method called : deleteAssignedTaxonomyName()");
				}
				dao.deleteAssignedTaxonomyName(assetInstVersionId, notPresent.get(j), conn);
			}

			if (!taxId.isEmpty()) {
				for (int i = 0; i < taxId.size(); i++) {
					AssetInstanceVersionTaxonomy aivt = new AssetInstanceVersionTaxonomy();

					if (log.isTraceEnabled()) {
						log.trace(
								"addTaxonomyForAssetInstanceVersion || dao method called : getTaxonomiesByParentId()");
					}
					TaxonomyMaster tm = tdao.getTaxonomiesByParentId(taxId.get(i), conn);

					if (taxIdss.contains(taxId.get(i))) {
						int bn = 0;
						for (bn = 0; bn < taxIds.size(); bn++)
							if (taxIds.get(bn).getAivTaxonomyId().equals(taxId.get(i)))
								break;
						aivt.setAssetInstVersionsTaxonomyId(taxIds.get(bn).getAssetInstVersionsTaxonomyId());
						aivt.setAssetInstVersionId(taxIds.get(bn).getAssetInstVersionId());
						aivt.setAivTaxonomyId(tm.getTaxonomyId());

						// dao.updateTaxonomyNameForAssetInstance(aivt, conn);
					} else {
						aivt.setAssetInstVersionId(assetInstVersionId);
						aivt.setAivTaxonomyId(tm.getTaxonomyId());

						if (log.isTraceEnabled()) {
							log.trace(
									"addTaxonomyForAssetInstanceVersion || dao method called : getAllTaxonomySubscribers()");
						}
						emailIds = tdao.getAllTaxonomySubscribers(conn, tm.getTaxonomyId());

						if (!emailIds.isEmpty()) {
							for (String Id1 : emailIds) {
								emailIdsList.add(Id1);
							}
							taxNameAdd.add(tm.getTaxonomyName());
						}

						if (log.isTraceEnabled()) {
							log.trace(
									"addTaxonomyForAssetInstanceVersion || dao method called : addTaxonomyNameForAssetInstance()");
						}
						dao.addTaxonomyNameForAssetInstance(aivt, conn);
					}

				}
			}

			String taxNameAddString = "";
			String taxNameDeleteString = "";

			for (int j = 0; j < taxNameAdd.size(); j++) {
				if (j == taxNameAdd.size() - 1) {
					taxNameAddString += taxNameAdd.get(j) + " ";
				} else {
					taxNameAddString += taxNameAdd.get(j) + ",";
				}
			}

			for (int j = 0; j < taxNameDelete.size(); j++) {
				if (j == taxNameDelete.size() - 1) {
					taxNameDeleteString += taxNameDelete.get(j) + " ";
				} else {
					taxNameDeleteString += taxNameDelete.get(j) + ",";
				}
			}

			MailTemplateDao mailTemplateDao = new MailTemplateDao();
			if (!emailIdsList.isEmpty()) {
				HashSet<String> listToSet = new HashSet<String>(emailIdsList);

				List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
				String mailTemp = "";

				if (versionable) {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"assignTaxNameForAssetInstanceForVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					mailTemp = mailTemp.replaceAll("%assignTaxName%", taxNameAddString)
							.replaceAll("%assetInstName%", assetInstName).replaceAll("%versionName%", versionName);
				} else {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"assignTaxNameForAssetInstanceForNonVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					mailTemp = mailTemp.replaceAll("%assignTaxName%", taxNameAddString).replaceAll("%assetInstName%",
							assetInstName);
				}

				for (String emailId : listWithoutDuplicates) {
					MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					if (taxNameAddString != "") {
						SendEmail.sendTextMail(mailConfig, emailId,
								MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
								MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
										+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
					}
				}

			}

			if (!emailIds1List.isEmpty()) {
				HashSet<String> listToSet = new HashSet<String>(emailIds1List);

				List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
				String mailTemp = "";

				if (versionable) {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"unassignTaxNameForAssetInstanceForVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					mailTemp = mailTemp.replaceAll("%unassignTaxName%", taxNameDeleteString)
							.replaceAll("%assetInstName%", assetInstName).replaceAll("%versionName%", versionName);
				} else {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"unassignTaxNameForAssetInstanceForNonVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					mailTemp = mailTemp.replaceAll("%unassignTaxName%", taxNameDeleteString)
							.replaceAll("%assetInstName%", assetInstName);
				}

				for (String emailId : listWithoutDuplicates) {

					MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					if (taxNameDeleteString != "") {
						SendEmail.sendTextMail(mailConfig, emailId,
								MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
								MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
										+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
					}
				}
			}
			conn.commit();

			log.info("addTaxonomyForAssetInstanceVersion || assigned taxonomy to asset instance version successfully");

			retMsg = Constants.TAXONOMY_ASSIGNED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("addTaxonomyForAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("addTaxonomyForAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyForAssetInstanceVersion || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyForAssetInstanceVersion || end ");
		}
		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

	}
*/
	/**
	 * @method : addTaxonomyForAssetInstanceVersion
	 * @param assetInstVersionId
	 * @param taxId
	 * @param versionable
	 * @param versionName
	 * @param assetInstName
	 * @return
	 */
	@PUT
	@Encoded
	@Path("/assigntaxonomy")
	public Response addTaxonomyForAssetInstanceVersion(@QueryParam("assetInstVersionId") Long assetInstVersionId,
			@QueryParam("taxId") String taxIdd, @QueryParam("versionable") boolean versionable,
			@QueryParam("versionName") String versionName, @QueryParam("assetInstName") String assetInstName) {

		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyForAssetInstanceVersion || begin with assetInstVersionId : " + assetInstVersionId
					+ "\t taxId : " + taxIdd);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyForAssetInstanceVersion : "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");

			Response response = addTaxonomyForAssetInstanceVersionHelper(assetInstVersionId, taxIdd, versionable, versionName, assetInstName, false, conn);
			return response;

		} catch (RepoproException e) {
			log.error("addTaxonomyForAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("addTaxonomyForAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyForAssetInstanceVersion || " + Constants.LOG_CONNECTION_CLOSE);
			}
			if(conn != null){
				DBConnection.closeDbConnection(conn);
			}
		}

		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyForAssetInstanceVersion || end ");
		}
		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

	}
	
	public Response addTaxonomyForAssetInstanceVersionHelper(Long assetInstVersionId,
			String taxIdd,boolean versionable,String versionName,String assetInstName,Boolean importFlag,Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyForAssetInstanceVersionHelper || begin with assetInstVersionId : " + assetInstVersionId
					+ "\t taxId : " + taxIdd);
		}

		Connection conn1 = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<Long> taxIdss = new ArrayList<Long>();
		List<String> emailIds = new ArrayList<String>();
		List<String> emailIds1 = new ArrayList<String>();
		List<String> emailIdsList = new ArrayList<String>();
		List<String> emailIds1List = new ArrayList<String>();
		List<String> taxNameAdd = new ArrayList<String>();
		List<String> taxNameDelete = new ArrayList<String>();
		Map<String,String> finalTaxValues = new LinkedHashMap<String, String>();
				
		try {
			
			//assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			TaxonomiesDao tdao = new TaxonomiesDao();
			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();

			if (log.isTraceEnabled()) {
				log.trace(
						"addTaxonomyForAssetInstanceVersionHelper || dao method called : retTaxonomyIdByAssetInstVersionId()");
			}
			List<AssetInstanceVersionTaxonomy> taxIds = dao.retTaxonomyIdByAssetInstVersionId(assetInstVersionId, conn);

			List<Long> taxId = new ArrayList<Long>();
			if (!taxIdd.equalsIgnoreCase("")) {
				for (String s : taxIdd.split(",")) {
					taxId.add(Long.parseLong(s));
				}
			}
			if (taxIds.isEmpty() && taxId.isEmpty()) {

			}

			if (!taxIds.isEmpty()) {
				for (AssetInstanceVersionTaxonomy a : taxIds) {
					taxIdss.add(a.getAivTaxonomyId());
				}
			}

			List<Long> notPresent = new ArrayList<Long>(taxIdss);
			notPresent.removeAll(taxId);

			for (int j = 0; j < notPresent.size(); j++) {

				if (log.isTraceEnabled()) {
					log.trace("addTaxonomyForAssetInstanceVersionHelper || dao method called : getAllTaxonomySubscribers()");
				}
				emailIds1 = tdao.getAllTaxonomySubscribers(conn, notPresent.get(j));

				if (log.isTraceEnabled()) {
					log.trace("addTaxonomyForAssetInstanceVersionHelper || dao method called : getTaxonomiesByParentId()");
				}
				TaxonomyMaster tm = tdao.getTaxonomiesByParentId(notPresent.get(j), conn);

				if (!emailIds1.isEmpty()) {
					for (String Id : emailIds1) {
						emailIds1List.add(Id);
					}
					taxNameDelete.add(tm.getTaxonomyName());
				}
				if (log.isTraceEnabled()) {
					log.trace("addTaxonomyForAssetInstanceVersionHelper || dao method called : deleteAssignedTaxonomyName()");
				}
				dao.deleteAssignedTaxonomyName(assetInstVersionId, notPresent.get(j), conn);
			}

			if (!taxId.isEmpty()) {
				for (int i = 0; i < taxId.size(); i++) {
					AssetInstanceVersionTaxonomy aivt = new AssetInstanceVersionTaxonomy();

					if (log.isTraceEnabled()) {
						log.trace(
								"addTaxonomyForAssetInstanceVersionHelper || dao method called : getTaxonomiesByParentId()");
					}
					TaxonomyMaster tm = tdao.getTaxonomiesByParentId(taxId.get(i), conn);

					if (taxIdss.contains(taxId.get(i))) {
						int bn = 0;
						for (bn = 0; bn < taxIds.size(); bn++)
							if (taxIds.get(bn).getAivTaxonomyId().equals(taxId.get(i)))
								break;
						aivt.setAssetInstVersionsTaxonomyId(taxIds.get(bn).getAssetInstVersionsTaxonomyId());
						aivt.setAssetInstVersionId(taxIds.get(bn).getAssetInstVersionId());
						aivt.setAivTaxonomyId(tm.getTaxonomyId());

						// dao.updateTaxonomyNameForAssetInstance(aivt, conn);
					} else {
						aivt.setAssetInstVersionId(assetInstVersionId);
						aivt.setAivTaxonomyId(tm.getTaxonomyId());

						if (log.isTraceEnabled()) {
							log.trace(
									"addTaxonomyForAssetInstanceVersionHelper || dao method called : getAllTaxonomySubscribers()");
						}
						emailIds = tdao.getAllTaxonomySubscribers(conn, tm.getTaxonomyId());

						if (!emailIds.isEmpty()) {
							for (String Id1 : emailIds) {
								emailIdsList.add(Id1);
							}
							taxNameAdd.add(tm.getTaxonomyName());
						}

						if (log.isTraceEnabled()) {
							log.trace(
									"addTaxonomyForAssetInstanceVersionHelper || dao method called : addTaxonomyNameForAssetInstance()");
						}
						dao.addTaxonomyNameForAssetInstance(aivt, conn);
					}

				}
			}

			String taxNameAddString = "";
			String taxNameDeleteString = "";
			
			for (int j = 0; j < taxNameAdd.size(); j++) {
				if (j == taxNameAdd.size() - 1) {
					taxNameAddString += taxNameAdd.get(j) + " ";
				} else {
					taxNameAddString += taxNameAdd.get(j) + ",";
				}
			}

			for (int j = 0; j < taxNameDelete.size(); j++) {
				if (j == taxNameDelete.size() - 1) {
					taxNameDeleteString += taxNameDelete.get(j) + " ";
				} else {
					taxNameDeleteString += taxNameDelete.get(j) + ",";
				}
			}
			
			String assginedTaxEmail = "";
			String unassignedTaxEmail = "";
			String assignTax = "";
			String unassignTax = "";
			if(!emailIdsList.isEmpty()){
				assginedTaxEmail = StringUtils.join(emailIdsList,",");
			}
			if(!emailIds1List.isEmpty()){
				unassignedTaxEmail = StringUtils.join(emailIds1List,",");
			}
			if(!taxNameAddString.equalsIgnoreCase("")){
				if(!assginedTaxEmail.equalsIgnoreCase("")){
					assignTax = StringUtils.join(taxNameAddString,"~~",assginedTaxEmail);
				}
			}
			if(!taxNameDeleteString.equalsIgnoreCase("")){
				if(!unassignedTaxEmail.equalsIgnoreCase("")){
					unassignTax = StringUtils.join(taxNameDeleteString,"~~",unassignedTaxEmail);
				}
			}
				
			finalTaxValues.put(assignTax, unassignTax);
			
			if(importFlag == false){
				MailTemplateDao mailTemplateDao = new MailTemplateDao();

				if (!emailIdsList.isEmpty()) {
					HashSet<String> listToSet = new HashSet<String>(emailIdsList);

					List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
					String mailTemp = "";

					if (versionable) {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"assignTaxNameForAssetInstanceForVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assignTaxName%", taxNameAddString)
								.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", versionName);
					} else {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"assignTaxNameForAssetInstanceForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assignTaxName%", taxNameAddString).replaceAll("%assetInstName%",
								instName);
					}

					for (String emailId : listWithoutDuplicates) {
						MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						if (taxNameAddString != "") {
							SendEmail.sendTextMail(mailConfig, emailId,
									MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
											+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
					}
				}

				if (!emailIds1List.isEmpty()) {
					HashSet<String> listToSet = new HashSet<String>(emailIds1List);

					List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
					String mailTemp = "";

					if (versionable) {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"unassignTaxNameForAssetInstanceForVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%unassignTaxName%", taxNameDeleteString)
								.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", versionName);
					} else {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"unassignTaxNameForAssetInstanceForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%unassignTaxName%", taxNameDeleteString)
								.replaceAll("%assetInstName%", instName);
					}

					for (String emailId : listWithoutDuplicates) {

						MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						if (taxNameDeleteString != "") {
							SendEmail.sendTextMail(mailConfig, emailId,
									MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
											+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
					}
				}
			}
			if(importFlag == false){
				conn.commit();
			}
			log.info("addTaxonomyForAssetInstanceVersionHelper || assigned taxonomy to asset instance version successfully");

			retMsg = Constants.TAXONOMY_ASSIGNED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("addTaxonomyForAssetInstanceVersionHelper || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
			try {
				if(importFlag == false){
					conn.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
				throw new RepoproException(e1.getMessage());
			}
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("addTaxonomyForAssetInstanceVersionHelper || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
			try {
				if(importFlag == false){
					conn.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
				throw new RepoproException(e1.getMessage());
			}
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyForAssetInstanceVersionHelper || " + Constants.LOG_CONNECTION_CLOSE);
			}
			if(importFlag == false){
				DBConnection.closeDbConnection(conn);
			}
			if(conn1 != null){
				DBConnection.closeDbConnection(conn1);
			}
		}

		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyForAssetInstanceVersionHelper || end ");
		}
		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,finalTaxValues)).build();

	}
	

	/**
	 * @method : lockAssetInstanceVersion
	 * @param userName
	 * @param aivId
	 * @return
	 */
	@PUT
	@Path("/lockassetinstanceversion")
	public Response lockAssetInstanceVersion(@QueryParam("userName") String userName, @QueryParam("aivId") Long aivId) {

		if (log.isTraceEnabled()) {
			log.trace("lockAssetInstanceVersion || Begin with username : " + userName + " \t aivId : " + aivId);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceVersion assetInstanceVersion = new AssetInstanceVersion();
		List<AssetInstanceVersion> aivList = new ArrayList<AssetInstanceVersion>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("lockAssetInstanceVersion || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();

			if (log.isTraceEnabled()) {
				log.trace("lockAssetInstanceVersion || dao method called : getLockTimeFromDB()");
			}
			LockTime lockTimeFromDB = dao.getLockTimeFromDB(conn);
			int lockTime = Integer.parseInt(lockTimeFromDB.getLockTime());

			LocalDateTime dateTime = LocalDateTime.now();
			dateTime = dateTime.plusMinutes(lockTime);
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

			assetInstanceVersion.setLockedBy(userName);
			assetInstanceVersion.setLockTime(Timestamp.valueOf(dateTime));
			assetInstanceVersion.setAssetInstVersionId(aivId);

			if (log.isTraceEnabled()) {
				log.trace("lockAssetInstanceVersion || dao method called : updateAssetInstanceVersion()");
			}
			dao.updateAssetInstanceVersion(assetInstanceVersion, conn);

			conn.commit();
			aivList.add(assetInstanceVersion);

			log.info("lockAssetInstanceVersion || locked asset instance version successfully");

			retMsg = Constants.ASSET_INSTANCE_VERSION_LOCKED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("lockAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("lockAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("lockAssetInstanceVersion || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("lockAssetInstanceVersion || end ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(aivList))).build();
	}

	/**
	 * @method : unlockAssetInstanceVersion
	 * @param userName
	 * @param aivId
	 * @return
	 */
	@PUT
	@Path("/unlockassetinstanceversion")
	public Response unlockAssetInstanceVersion(@QueryParam("userName") String userName,
			@QueryParam("aivId") Long aivId) {

		if (log.isTraceEnabled()) {
			log.trace("unlockAssetInstanceVersion || Begin with username : " + userName + " \t aivId : " + aivId);
		}

		Connection conn = null;
		AssetInstanceVersion aiv = new AssetInstanceVersion();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<AssetInstanceVersion> aivList = new ArrayList<AssetInstanceVersion>();

		try {
			conn = DBConnection.getInstance().getConnection();

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();

			if (log.isTraceEnabled()) {
				log.trace("unlockAssetInstanceVersion || dao method called : unlockAssetInstanceVersion()");
			}

			aiv.setLockedBy(null);
			aiv.setLockTime(null);
			aiv.setAssetInstVersionId(aivId);

			if (log.isTraceEnabled()) {
				log.trace("unlockAssetInstanceVersion || dao method called : updateAssetInstanceVersion()");
			}
			dao.updateAssetInstanceVersion(aiv, conn);

			aivList.add(aiv);

			conn.commit();

			log.info("unlockAssetInstanceVersion || unlocked asset instance version successfully");

			retMsg = Constants.ASSET_INSTANCE_VERSION_UNLOCKED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("unlockAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("unlockAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("unlockAssetInstanceVersion || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("unlockAssetInstanceVersion || end");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(aivList))).build();
	}

	/**
	 * @method : retAssetInstanceVersion
	 * @param aivId
	 * @param userName
	 * @return
	 */
	@GET
	@Path("/retAssetInstanceVersion")
	public Response retAssetInstanceVersion(@QueryParam("aivId") Long aivId, @QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("retAssetInstanceVersion || begin with aivId : " + aivId + " \t username : " + userName);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<AssetInstanceVersion> aivList = new ArrayList<AssetInstanceVersion>();

		try {
			conn = DBConnection.getInstance().getConnection();

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();

			if (log.isTraceEnabled()) {
				log.trace("retAssetInstanceVersion || dao method called : retAssetInstanceVersion()");
			}
			AssetInstanceVersion aiv = dao.retAssetInstanceVersion(aivId, userName, conn);
			Timestamp lockTime = aiv.getLockTime();// db

			LocalDateTime dateTime = LocalDateTime.now();// current

			if (lockTime != null) {
				LocalDateTime localTime = lockTime.toLocalDateTime();
				if (dateTime.isAfter(localTime)) {
					aiv.setLockedBy(null);
					aiv.setLockTime(null);
					if (log.isTraceEnabled()) {
						log.trace("retAssetInstanceVersion || dao method called : updateAssetInstanceVersion()");
					}
					dao.updateAssetInstanceVersion(aiv, conn);
				}
			}
			aivList.add(aiv);
			conn.commit();

			log.info("retAssetInstanceVersion || asset instance version fetched ");

			retMsg = Constants.ASSET_INSTANCE_VERSIONS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("retAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} catch (Exception e) {
			log.error("retAssetInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retAssetInstanceVersion || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retAssetInstanceVersion || end");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(aivList))).build();
	}

	/**
	 * @method assetInstanceVersionForComparison
	 * @description to comapre two assetInstance version details
	 * @param userName
	 *            ,assetInstanceVersionId,assetName
	 * @return success Response
	 * @throws RepoproException
	 */

	@GET
	@Encoded
	@Path("/assetInstanceVersionForComparison")
	public Response assetInstanceVersionForComparison(@QueryParam("assetName") String assetName,
			@QueryParam("userName") String userName,
			@QueryParam("assetInstanceVersionIds") String assetInstanceVersionIds) {

		if (log.isTraceEnabled()) {
			log.trace("assetInstanceVersionForComparison : || Begin with : assetName" + assetName + "userName"
					+ userName + "assetInstanceVersionIds" + assetInstanceVersionIds);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		Connection conn = null;
		AssetInstanceVersion assetInstVer = null;
		List<AssetInstanceVersion> staticList = new ArrayList<AssetInstanceVersion>();
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetInstanceVersion> assetInstVersionList = new ArrayList<AssetInstanceVersion>();
		List<AssetInstance> RelationShipList = new ArrayList<AssetInstance>();
		String desc_asset_name = null;
		Long desc_version_id = null;
		String composedRelationName = null;
		//String composedRelationName1 = null;
		// String assetRelationshipType = null;
		String[] assetInstVersionIds = assetInstanceVersionIds.split(",");

		try {
			
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("assetInstanceVersionForComparison || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			TreeMap<String, String> paramData = null;
			TreeMap<String, TreeMap<String, String>> parameterData = null;
			// List<String> relationShipData = new ArrayList<String>();
			TreeMap<String, String> paramData1 = null;
			TreeMap<String, TreeMap<String, String>> parameterData1 = null;
			TreeMap<String, TreeMap<String, TreeMap<String, String>>> parameterData2 = null;
			String description = null;

			for (String assetInstVerId : assetInstVersionIds) {

				assetInstVer = new AssetInstanceVersion();

				if (log.isTraceEnabled()) {
					log.trace(
							"assetInstanceVersionForComparison || called Dao method : getAssetInstanceVersionDetails by assetInstVerId: "
									+ assetInstVerId);
				}

				assetInstVer = assetInstanceVersionDao.getAssetInstanceVersionDetails(new Long(assetInstVerId), conn);

				if (assetInstVer.getDescription() == null) {
					description = "No Description Available";

				} else {
					description = assetInstVer.getDescription();
				}
				assetInstVer.setDescription(description);
				assetInstVer.setVersionName(assetInstVer.getVersionName());

				// parameter data

				staticList = new ArrayList<AssetInstanceVersion>();

				if (log.isTraceEnabled()) {
					log.trace(
							"assetInstanceVersionForComparison || called helper method : getParameter() to get parameter data");
				}

				staticList = getParameter(assetName, userName, new Long(assetInstVerId), conn);

				paramData = new TreeMap<String, String>();
				parameterData = new TreeMap<String, TreeMap<String, String>>();
				String prevCName = "";
				String paramName = null;
				String paramValue = null;
				String textdata = null;
				int i = 0;
				// parameter data loop
				for (AssetInstanceVersion aiv : staticList) {
					if (aiv.getParamTypeId() != 5 && aiv.getParamTypeId() != 6 && aiv.getParamTypeId() != 8) {

						String categoryName = aiv.getAsset_category_name();

						if (aiv.getIsStatic() == 1) {
							if (aiv.getParamTypeId() == 3) {
								paramName = aiv.getAssetParamName();
								paramValue = aiv.getApdFileName();
							} else if ((aiv.getParamTypeId() == 2) || (aiv.getParamTypeId() == 4)
									|| (aiv.getParamTypeId() == 1)) {
								paramName = aiv.getAssetParamName();
								paramValue = aiv.getStaticValue();
							}

						} else {
							if (aiv.getParamTypeId() == 3) {
								paramName = aiv.getAssetParamName();
								paramValue = aiv.getFileName();
							} else if (aiv.getParamTypeId() == 1){
								if(aiv.getHasArray() == 1){
								paramName = aiv.getAssetParamName();
								textdata = String.join("~~", aiv.getTextDataList());
								paramValue = textdata;
								}else{
									paramName = aiv.getAssetParamName();
									paramValue = aiv.getParamValue();
								}
								
							}else if (aiv.getParamTypeId() == 7){
								if(aiv.getHasArray() == 1){
								paramName = aiv.getAssetParamName();
								textdata = String.join("~~", aiv.getRTFwithTags());
								paramValue = textdata;
								}else{
									paramName = aiv.getAssetParamName();
									paramValue = aiv.getParamValue();
								}
							}
							else {
								paramName = aiv.getAssetParamName();
								paramValue = aiv.getParamValue();
							}
						}

						if (i == 0) {
							prevCName = categoryName;
							i++;
						}
						if (categoryName.equalsIgnoreCase(prevCName)) {

							paramData.put(paramName, paramValue);
							parameterData.put(categoryName, paramData);
							assetInstVer.setParameterData(parameterData);
						} else {

							assetInstVer.setParameterData(parameterData);
							paramData = new TreeMap<String, String>();
							paramData.put(paramName, paramValue);
							parameterData.put(categoryName, paramData);
							prevCName = categoryName;

						}
					}
				} // parameter data loop end

				assetInstVer.setParameterData(parameterData);

				// relationship data
				if (log.isTraceEnabled()) {
					log.trace(
							"assetInstanceVersionForComparison || called Dao method : getDependants() by assetInstVerId :"
									+ assetInstVerId);
				}

				RelationShipList = relationshipDao.getDependants(new Long(assetInstVerId), conn);

				String relationShipDatas = null;
				List<String> strArray = new ArrayList<String>();

				for (AssetInstance ai1 : RelationShipList) {

					relationShipDatas = ai1.getAssetName() + "->" + ai1.getAssetInstName() + "_" + ai1.getVersionName()
							+ "&<!!`>&";
					strArray.add(relationShipDatas);

				}
				relationShipDatas = StringUtils.join(strArray, '!');
				relationShipDatas = relationShipDatas.replaceAll("&<!!`>&!", "<br>");
				relationShipDatas = relationShipDatas.replaceAll("&<!!`>&", "<br>");
				assetInstVer.setRelationshipData(relationShipDatas);

				// composed relationShip start parameter data
				parameterData2 = new TreeMap<String, TreeMap<String, TreeMap<String, String>>>(/*
																								 * (String
																								 * .
																								 * CASE_INSENSITIVE_ORDER)
																								 */);
				for (AssetInstance ai : RelationShipList) {

					if (ai.getAssetRelationshipType() != null) {
						if (ai.getAssetRelationshipType().equalsIgnoreCase("composition")) {

							composedRelationName = ai.getAssetInstName() + "_" + ai.getVersionName();

							desc_asset_name = ai.getAssetName();
							desc_version_id = ai.getAssetInstVersionId();
							// assetInstVer.setComposedInstName(composedRelationName);
							staticList = new ArrayList<AssetInstanceVersion>();

							if (log.isTraceEnabled()) {
								log.trace(
										"assetInstanceVersionForComparison || called helper method : getParameter() to get parameter data");
							}

							staticList = getParameter(desc_asset_name, userName, desc_version_id, conn);

							paramData1 = new TreeMap<String, String>();
							parameterData1 = new TreeMap<String, TreeMap<String, String>>();
							String prevCName1 = "";
							int j = 0;
							String paramName1 = null;
							String paramValue1 = null;
							String textdata1 = null;

							for (AssetInstanceVersion aiv : staticList) {

								if (aiv.getParamTypeId() != 5 && aiv.getParamTypeId() != 6 && aiv.getParamTypeId() != 8) {
									String categoryName1 = aiv.getAsset_category_name();

									if (aiv.getIsStatic() == 1) {
										if (aiv.getParamTypeId() == 3) {
											paramName1 = aiv.getAssetParamName();
											paramValue1 = aiv.getApdFileName();
										} else if ((aiv.getParamTypeId() == 2) || (aiv.getParamTypeId() == 4)
												|| (aiv.getParamTypeId() == 1)) {
											paramName1 = aiv.getAssetParamName();
											paramValue1 = aiv.getStaticValue();
										}

									} else {
										if (aiv.getParamTypeId() == 3) {
											paramName1 = aiv.getAssetParamName();
											paramValue1 = aiv.getFileName();
										} else if (aiv.getParamTypeId() == 1){
											if(aiv.getHasArray() == 1){
											paramName1 = aiv.getAssetParamName();
											textdata1 = String.join("~~", aiv.getTextDataList());
											paramValue1 = textdata1;
										}else{
											paramName1 = aiv.getAssetParamName();
											paramValue1 = aiv.getParamValue();
										}
										}else if (aiv.getParamTypeId() == 7){
											if(aiv.getHasArray() == 1){
											paramName1 = aiv.getAssetParamName();
											textdata1 = String.join("~~", aiv.getRTFwithTags());
											paramValue1 = textdata1;
											}else{
												paramName1 = aiv.getAssetParamName();
												paramValue1 = aiv.getParamValue();
											}
										}else {
											paramName1 = aiv.getAssetParamName();
											paramValue1 = aiv.getParamValue();
										}
									}
									if (j == 0) {
										prevCName1 = categoryName1;
										j++;
									}
									if (categoryName1.equalsIgnoreCase(prevCName1)) {

										paramData1.put(paramName1, paramValue1);

										parameterData1.put(categoryName1, paramData1);

									} else {
										// assetInstVer.setComposedparameterData(parameterData1);
										parameterData2.put(composedRelationName, parameterData1);
										assetInstVer.setComposedparameterData2(parameterData2);
										paramData1 = new TreeMap<String, String>();
										paramData1.put(paramName1, paramValue1);
										parameterData1.put(categoryName1, paramData1);
										prevCName1 = categoryName1;

									}
								}
							}
							parameterData2.put(composedRelationName, parameterData1);
							assetInstVer.setComposedparameterData2(parameterData2);

						} else {
							// assetInstVer.setComposedInstName("No Proper
							// Dependency");
						}
					}
				} // composed relation end

				assetInstVersionList.add(assetInstVer);

			} // end of version for loop

			conn.commit();

			log.info("assetInstanceVersionForComparison || End ");

			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_VERSIONS_COMPARED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("assetInstanceVersionForComparison || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} catch (Exception e) {
			log.error("assetInstanceVersionForComparison || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("assetInstanceVersionForComparison || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("assetInstanceVersionForComparison || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(assetInstVersionList)))
				.build();

	}

	public List<AssetInstanceVersion> getParameter(String assetName, String userName, Long versionId, Connection conn)throws RepoproException {

		log.trace("getParameter || begin to get parameter data by assetName " + assetName);

		RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		Connection conn1 = null;
		List<AssetInstanceVersion> nonStaticList = new ArrayList<AssetInstanceVersion>();
		List<AssetInstanceVersion> finalData = new ArrayList<AssetInstanceVersion>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getShowHideParamValues : " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getParameter || Dao method call getParamDefForAssetByGroups()");
			}
			List<AssetParamDef> params = revisionHistoryDao.getParamDefForAssetByGroups(assetName, userName, conn);

			StringBuffer staticParams = new StringBuffer();
			StringBuffer nonStaticParams = new StringBuffer();

			for (int i = 0; i < params.size(); i++) {
				AssetParamDef apd = params.get(i);
				if (apd.getIs_static() == 1) {
					staticParams.append(apd.getAssetParamName() + ",");
				} else {
					long type = apd.getParamTypeId();
					int id = (int) type;
					if (id != 6 && id != 5 && id != 8) {
						nonStaticParams.append(apd.getAssetParamName() + ",");
					}
				}

				if (apd.getParamTypeId() == 5) {
					String derivedData = assetInstanceVersionDao.getDerivedAttributeValues(userName,
							versionId.toString(), assetName, apd.getAssetParamName(), conn);
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv.setAssetParamName(apd.getAssetParamName());
					aiv.setParamValue(derivedData);
					aiv.setAsset_category_name(apd.getAssetCategoryName());
					aiv.setParam_disp(apd.getParameter_disp_position());
					aiv.setCat_disp(apd.getCategory_disp_position());
					aiv.setAssetParamId(apd.getAssetParamId());
					aiv.setIsStatic(apd.getIs_static());
					aiv.setParamTypeId(apd.getParamTypeId());
					aiv.setDescription(apd.getDescription());
					nonStaticList.add(aiv);
				} else if (apd.getParamTypeId() == 6) {
					AssetInstanceVersion aiv = new AssetInstanceVersion();

					String count = assetInstanceVersionDao.getDerivedComputationValues(userName, versionId.toString(),
							assetName, apd.getAssetParamName(), conn);
					aiv.setAsset_category_name(apd.getAssetCategoryName());
					aiv.setAssetParamName(apd.getAssetParamName());
					aiv.setParamValue(count);
					aiv.setParam_disp(apd.getParameter_disp_position());
					aiv.setCat_disp(apd.getCategory_disp_position());
					aiv.setAssetParamId(apd.getAssetParamId());
					aiv.setIsStatic(apd.getIs_static());
					aiv.setParamTypeId(apd.getParamTypeId());
					aiv.setDescription(apd.getDescription());
					nonStaticList.add(aiv);
				}

			}

			if (nonStaticParams.length() != 0) {
				nonStaticParams = nonStaticParams.deleteCharAt(nonStaticParams.length() - 1);
			}
			if (staticParams.length() != 0) {
				staticParams = staticParams.deleteCharAt(staticParams.length() - 1);
			}

			List<AssetInstanceVersion> staticList = new ArrayList<AssetInstanceVersion>();

			if (nonStaticParams.length() != 0) {
				if (log.isTraceEnabled()) {
					log.trace("getParameter || Dao method call getNonStaticParamDefWithCategoryNames()");
				}
				List<AssetInstanceVersion> list = assetInstanceVersionDao
						.getNonStaticParamDefWithCategoryNames(assetName, versionId, nonStaticParams.toString(),userName,conn);

				nonStaticList.addAll(list);
			}

			if (staticParams.length() != 0) {
				assetInstanceVersionDao = new AssetInstanceVersionDao();
				if (log.isTraceEnabled()) {
					log.trace("getParameter || Dao method call getStaticParamDefWithCategoryNames()");
				}
				staticList = assetInstanceVersionDao.getStaticParamDefWithCategoryNames(assetName,
						staticParams.toString(),userName,conn);
			}

			staticList.addAll(nonStaticList);
			if (staticList.size() != 0) {
				if (staticList.size() < params.size()) {
					class AssetParameterComparator implements Comparator<AssetInstanceVersion> {

						@Override
						public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
							return o1.getAssetParamName().toLowerCase().compareTo(o2.getAssetParamName().toLowerCase());
						}
					}
					Collections.sort(staticList, new AssetParameterComparator());
					List<AssetInstanceVersion> finalList = new ArrayList<AssetInstanceVersion>();

					for (int i = 0; i < params.size(); i++) {

						AssetParamDef apd = params.get(i);
						boolean flag = false;
						for (int k = 0; k < staticList.size(); k++) {
							AssetInstanceVersion aiv1 = staticList.get(k);
							if (aiv1.getAssetParamName().equalsIgnoreCase(apd.getAssetParamName())) {
								flag = true;
								finalList.add(staticList.get(k));
								break;
							}
							if (flag) {

								break;
							}

							if (staticList.size() == k + 1) {
								if (!flag) {
									AssetInstanceVersion aiv = new AssetInstanceVersion();
									if (apd.getParamTypeId() == 1)
										aiv.setParamTextSize(apd.getSize());
									aiv.setAsset_category_name(apd.getAssetCategoryName());
									aiv.setCat_disp(apd.getCategory_disp_position());
									aiv.setCategoryId(apd.getAssetCategoryId());
									aiv.setParam_disp(apd.getParameter_disp_position());
									aiv.setAssetParamName(apd.getAssetParamName());
									aiv.setApdFileName(apd.getFileName());
									aiv.setStaticValue(apd.getStaticValue());
									aiv.setIsStatic(apd.getIs_static());
									aiv.setParamTypeId(apd.getParamTypeId());
									aiv.setDerivedAttributeComputation(apd.getDerivedAttributeComputation());
									aiv.setListTypeParamTypeId(apd.getListTypeParamTypeId());
									aiv.setMappedAssetId(apd.getMappedAssetId());
									aiv.setAssetParamId(apd.getAssetParamId());
									aiv.setDescription(apd.getDescription());
									aiv.setLdapMappingId(apd.getLdapMappingId());
									finalList.add(aiv);
								}

							}
						}
					}
					staticList = finalList;
				}
			} else {
				for (int i = 0; i < params.size(); i++) {
					AssetParamDef apd = params.get(i);
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					if (apd.getParamTypeId() == 1)
						aiv.setParamTextSize(apd.getSize());
					aiv.setAsset_category_name(apd.getAssetCategoryName());
					aiv.setCat_disp(apd.getCategory_disp_position());
					aiv.setCategoryId(apd.getAssetCategoryId());
					aiv.setParam_disp(apd.getParameter_disp_position());
					aiv.setAssetParamName(apd.getAssetParamName());
					aiv.setApdFileName(apd.getFileName());
					aiv.setStaticValue(apd.getStaticValue());
					aiv.setIsStatic(apd.getIs_static());
					aiv.setParamTypeId(apd.getParamTypeId());
					aiv.setDerivedAttributeComputation(apd.getDerivedAttributeComputation());
					aiv.setListTypeParamTypeId(apd.getListTypeParamTypeId());
					aiv.setMappedAssetId(apd.getMappedAssetId());
					aiv.setAssetParamId(apd.getAssetParamId());
					aiv.setDescription(apd.getDescription());
					staticList.add(aiv);
				}
			}
			@SuppressWarnings("unused")
			class AssetInstanceVersinsComparator implements Comparator<AssetInstanceVersion> {

				private List<Comparator<AssetInstanceVersion>> listComparators;

				@SuppressWarnings("unused")
				AssetInstanceVersinsComparator(Comparator<AssetInstanceVersion>... comparators) {
					this.listComparators = Arrays.asList(comparators);
				}

				public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
					for (Comparator<AssetInstanceVersion> comparator : listComparators) {
						int result = comparator.compare(o1, o2);
						if (result != 0) {
							return result;
						}
					}
					return 0;
				}
			}
			@SuppressWarnings("unused")
			class Category_disp_position_Comparator implements Comparator<AssetInstanceVersion> {

				public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
					if (o1.getCat_disp() == o2.getCat_disp())
						return 0;
					return o1.getCat_disp() < o2.getCat_disp() ? -1 : 1;
				}
			}
			class Parameter_disp_position_Comparator implements Comparator<AssetInstanceVersion> {

				public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
					if (o1.getParam_disp() == o2.getParam_disp())
						return 0;
					return o1.getParam_disp() < o2.getParam_disp() ? -1 : 1;
				}
			}
			Collections.sort(staticList, new AssetInstanceVersinsComparator(new Category_disp_position_Comparator(),
					new Parameter_disp_position_Comparator()));
			finalData = staticList;

		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("getParameter : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("getParameter || Exit");
		}
		return finalData;
	}

	/**
	 * @method updateAssetInstanceVersions
	 * @description to update asset instance version details
	 * @param userName
	 *            ,assetInstanceVersionId,assetName,assetInstanceId,assetId,
	 *            assetName
	 * @return success Response
	 * @throws RepoproException
	 */

	@PUT
	@Encoded
	@Path("/updateAssetInstanceVersions")
	public Response updateAssetInstanceVersions(@QueryParam("assetInstanceId") Long assetInstanceId,
			@QueryParam("assetInstanceName") String assetInstanceName, @QueryParam("assetId") Long assetId,
			@QueryParam("oldVersionName") String oldVersionName, @QueryParam("assetName") String assetName,
			@QueryParam("userName") String userName, @QueryParam("assetInstanceVersionId") Long assetInstanceVersionId,
			AssetInstanceVersion updateAssetInstVersiondata) {

		if (updateAssetInstVersiondata == null) {
			log.warn("updateAssetInstanceVersions || version data  not provided to update");
			return Response.status(Status.BAD_REQUEST).entity(new MyModel(Constants.STATUS_FAILURE, Constants.FAILURE,
					MessageUtil.getMessage(Constants.INVALID_REQUEST))).build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceVersions || " + updateAssetInstVersiondata.toString()
						+ " Begin with assetInstanceId" + assetInstanceId + "and assetInstanceVersionId "
						+ assetInstanceVersionId + "assetInstanceName " + assetInstanceName + " assetId" + assetId
						+ "assetName " + assetName + "oldVersionName" + oldVersionName + "userName" + userName);

			}
			Connection conn = null;
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			boolean flagForDuplicateVersion = false;
			boolean noChange = false;
			SubscriptionDao subscriptionDao = new SubscriptionDao();
			int retStatScsFlr = 0;
			String action = Constants.ACTIVITY_MODIFY;
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			List<AssetInstanceVersion> assetInstVersions = new ArrayList<AssetInstanceVersion>();
			AssetInstanceVersion updatedVersion = null;
			String jsonRslt;
			List<String> jsonList = new ArrayList<String>();
			List<AssetInstanceVersion> versionobj = new ArrayList<AssetInstanceVersion>();
			UserDao userDao = new UserDao();
			User user = null;
			CommonUtils commonUtils = new CommonUtils();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			try {
					
				assetName = URLDecoder.decode(assetName, "UTF-8");
				assetInstanceName = URLDecoder.decode(assetInstanceName, "UTF-8");
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceVersions || " + Constants.LOG_CONNECTION_OPEN);
				}

				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("updateAssetInstanceVersions || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
				
				if (log.isTraceEnabled()) {
					log.trace(
							"updateAssetInstanceVersions || dao method called : getAssetInstanceVersions() by assetInstanceId"
									+ assetInstanceId);
				}

				assetInstVersions = assetInstanceVersionDao.getAssetInstanceVersions(assetInstanceId, conn);

				if (log.isTraceEnabled()) {
					log.trace(
							"updateAssetInstanceVersions : call dao method retProfileForUserName to get user details");
				}

				user = userDao.retProfileForUserName(userName, conn);

				if (assetInstVersions.size() > 0) {
					if (log.isDebugEnabled()) {
						log.debug("updateAssetInstanceVersions || check whether entered version:"
								+ updateAssetInstVersiondata.getVersionName() + " already exist");
					}

					if (oldVersionName != "") {

						for (AssetInstanceVersion list : assetInstVersions) {
							if (updateAssetInstVersiondata.getVersionName()
									.equalsIgnoreCase(list.getVersionName())) {

								if (!(updateAssetInstVersiondata.getVersionName().equalsIgnoreCase(oldVersionName))) {
									flagForDuplicateVersion = true;
								}else if ((updateAssetInstVersiondata.getVersionName().equalsIgnoreCase(list.getVersionName()))
										&& (updateAssetInstVersiondata.getVersionNotes()
												.equalsIgnoreCase(list.getVersionNotes()))) {
									     noChange = true;

								} 
							}
						}

					}
				}

				if (noChange) {

					log.warn("updateAssetInstanceVersions || no changes to update ");

					jsonRslt = Constants.NO_CHANGES_TO_UPDATE;
					jsonList.add(jsonRslt);

					return Response.status(Status.OK)
							.entity(new MyModel(Constants.INSERT_STATUS_SUCCESS, Constants.FAILURE,
									Constants.NO_CHANGES_TO_UPDATE,
									new ArrayList<Object>(jsonList)))
							.build();
				}

				if (flagForDuplicateVersion) {

					log.warn(
							"updateAssetInstanceVersions || Version by this name already exists, please provide different version");

					jsonRslt = Constants.ASSET_INSTANCE_VERSION_NAME_EXIST;
					jsonList.add(jsonRslt);

					return Response.status(Status.OK)
							.entity(new MyModel(Constants.INSERT_STATUS_SUCCESS, Constants.FAILURE,
									Constants.ASSET_INSTANCE_VERSION_NAME_EXIST,
									new ArrayList<Object>(jsonList)))
							.build();

				} else {

					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstanceVersions || dao method called : updateAivUpdatedOn() "
								+ updateAssetInstVersiondata.toString());
					}

					updateAssetInstVersiondata.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					
					if(globalsetting.getGlobalSettingFlag() == 1){
						String description = commonUtils.httpSanitizerForPlainText(updateAssetInstVersiondata.getVersionNotes());
						updateAssetInstVersiondata.setVersionNotes(description);
					}
					
					updatedVersion = assetInstanceVersionDao.updateAssetInstanceVersions(updateAssetInstVersiondata,
							assetInstanceVersionId, conn);

					// add recent activity
					RecentActivityDao recentActivityDao = new RecentActivityDao();
					RecentActivity recentActivity = new RecentActivity();

					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setAssetId(String.valueOf(assetId));
					String versionId = String.valueOf(assetInstanceVersionId);
					recentActivity.setAssetInstVersionId(versionId);
					recentActivity.setDescription(user.getFullName() + ";" + action + ";" + assetName + ";"
							+ assetInstanceName + ";" + "version" + updateAssetInstVersiondata.getVersionName());
					recentActivity.setUser_id(user.getUserId());

					if (log.isTraceEnabled()) {
						log.trace(
								"updateAssetInstanceVersions || dao method called : addRecentActivity() by assetInstanceId"
										+ recentActivity.toString());
					}

					recentActivityDao.addRecentActivity(recentActivity, conn);

					// mailtemplate

					List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstanceId, conn);
					MailTemplateDao mailDao = new MailTemplateDao();
					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					MailConfig mailConfig = mailDao.getMailConfig(conn);
					String mailTemp = null;

					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn, "editAssetInstanceVersion");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstanceName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName)
							.replaceAll("%versionName%", oldVersionName)
							.replaceAll("%newVersionName%", updateAssetInstVersiondata.getVersionName());
					if (emailIds != null) {
						for (String emailId : emailIds) {
							SendEmail.sendTextMail(mailConfig, emailId,
									MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
											+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
					}

					retMsg = Constants.ASSET_INSTANCE_VERSION_UPDATED;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
					versionobj.add(updatedVersion);

				}

				log.info(" updateAssetInstanceVersions || " + updatedVersion.toString()
						+ " Updated asset instance version data successfully");
				conn.commit();

			} catch (RepoproException e) {
				log.error("updateAssetInstanceVersions ||  " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch (Exception e) {
				log.error("updateAssetInstanceVersions ||  " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceVersions || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceVersions || " + updateAssetInstVersiondata.toString() + " End");
			}

			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(versionobj))).build();
		}
	}

	/**
	 * @method addAssetInstanceVersions
	 * @description add asset instance version based on assetInstanceId
	 * @param addAssetInstVersiondata
	 * @param copyFromVersion,assetInstanceId,assetInstName,assetId,userName,
	 *            activeFlag
	 * @return success response
	 * @throws RepoproException
	 */

	@POST
	@Encoded
	@Path("/addAssetInstanceVersions")
	public Response addAssetInstanceVersions(@QueryParam("assetInstanceId") Long assetInstanceId,
			@QueryParam("assetInstName") String assetInstName, @QueryParam("assetId") Long assetId,
			@QueryParam("assetName") String assetName, @QueryParam("userId") Long userId,
			@QueryParam("userName") String userName, @QueryParam("versionableFlag") int versionableFlag,
			@QueryParam("copyFromVersion") String copyFromVersion, @QueryParam("activeFlag") int activeFlag,
			AssetInstanceVersion addAssetInstVersiondata, @Context ServletContext context) {

		if (addAssetInstVersiondata == null) {
			log.warn("addAssetInstanceVersions || version data is not provided to add");
			return Response.status(Status.BAD_REQUEST).entity(new MyModel(Constants.STATUS_FAILURE, Constants.FAILURE,
					MessageUtil.getMessage(Constants.INVALID_REQUEST))).build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceVersions || " + addAssetInstVersiondata.toString()
						+ " Begin with assetInstanceId " + assetInstanceId + "assetInstName " + assetInstName
						+ " assetId" + assetId + "assetName " + assetName + "userId" + userId + "userName" + userName
						+ "versionableFlag" + versionableFlag + "copyFromVersion" + copyFromVersion + "activeFlag"
						+ activeFlag);
			}

			Connection conn = null;
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			boolean flagForDuplicateVersion = false;
			int retStatScsFlr = 0;
			SubscriptionDao subscriptionDao = new SubscriptionDao();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			List<AssetInstanceVersion> aivList = new ArrayList<AssetInstanceVersion>();
			List<AssetInstanceVersion> versionobj = new ArrayList<AssetInstanceVersion>();
			GamificationDetails gamificationDetail = new GamificationDetails();
			RelationshipDao relationshipDao = new RelationshipDao();
			GamificationDao gamificationDao = new GamificationDao();
			RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
			CommonUtils commonUtils = new CommonUtils();
			GroupAssetAccess groupAssetInstVerAccess = null;
			GroupDao groupDao = new GroupDao();
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			WorkflowDao workflowDao = new WorkflowDao();
			RecentActivity recentActivity = null;
			AssetInstanceVersion version = null;
			String jsonRslt;
			List<String> jsonList = new ArrayList<String>();
			UserDao userDao = new UserDao();
			User user = null;
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			AssetRepresentationDao repDao = new AssetRepresentationDao();
			

			try {
				assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
				assetName = URLDecoder.decode(assetName, "UTF-8");
				
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceVersions || " + Constants.LOG_CONNECTION_OPEN);
				}

				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				
				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("addAssetInstanceVersions || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
				
				user = userDao.retProfiledetailsForUserName(userName, conn);

				// latest version 
				AssetInstanceVersion afinal = assetInstanceVersionDao.getLatestAssetInstanceVersion(assetInstanceId, conn);
				
				if (log.isTraceEnabled()) {
					log.trace(
							"addAssetInstanceVersions || dao method called : getAssetInstanceVersions() by assetInstanceId"
									+ assetInstanceId);
				}

				aivList = assetInstanceVersionDao.getAssetInstanceVersions(assetInstanceId, conn);

				if (aivList.size() > 0) {
					if (log.isDebugEnabled()) {
						log.debug("addAssetInstanceVersions || check whether entered version:"
								+ addAssetInstVersiondata.getVersionName() + " already exist");
					}

					for (AssetInstanceVersion list : aivList) {
						if (list.getVersionName().equalsIgnoreCase(addAssetInstVersiondata.getVersionName())) {
							flagForDuplicateVersion = true;
						}
					}
				}
				if (flagForDuplicateVersion) {
					log.warn(
							"addAssetInstanceVersions || Version by this name already exists, please provide different version");

					jsonRslt = Constants.ASSET_INSTANCE_VERSION_NAME_EXIST;
					jsonList.add(jsonRslt);

					return Response.status(Status.OK)
							.entity(new MyModel(Constants.INSERT_STATUS_SUCCESS, Constants.FAILURE,
									Constants.ASSET_INSTANCE_VERSION_NAME_EXIST,
									new ArrayList<Object>(jsonList)))
							.build();

				} else {

					AssetInstanceVersion aiv0 = new AssetInstanceVersion();

					if (copyFromVersion.equalsIgnoreCase("None")) {

						aiv0.setDescription("This is system generated overview");

					} else {

						aiv0.setVersionName(copyFromVersion);
					}

					for (AssetInstanceVersion aiv1 : aivList) {

						if (aiv1.getVersionName().equalsIgnoreCase(copyFromVersion)) {

							aiv0.setDescription(aiv1.getDescription());
							aiv0.setAssetInstVersionId(aiv1.getAssetInstVersionId());

						}
					}

					// adding data to version table

					addAssetInstVersiondata.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));

					if (log.isTraceEnabled()) {
						log.trace(
								"addAssetInstanceVersions || dao method called : addAssetInstanceVersions() by assetInstanceId "
										+ assetInstanceId + "and " + addAssetInstVersiondata.toString());
					}
					
					if(globalsetting.getGlobalSettingFlag() == 1){
						String description = commonUtils.httpSanitizerForPlainText(addAssetInstVersiondata.getVersionNotes());
						addAssetInstVersiondata.setVersionNotes(description);
					}
					version = assetInstanceVersionDao.addAssetInstanceVersions(addAssetInstVersiondata, assetInstanceId,
							aiv0.getDescription(), conn);
					
					Long firstState = null;
					Workflow workflow = workflowDao.retWorkflowByAivId(version.getAssetInstVersionId(), conn);
					if(workflow != null) {
						String jsonStructure = workflow.getJsonStructure();
						JSONObject jsonObject = new JSONObject(jsonStructure);
						
						for(int i=0;i<jsonObject.length();i++) {
							Iterator itr = jsonObject.keys();
							if(itr.hasNext()){
								firstState = Long.parseLong(itr.next().toString());
							}
						}
						assetInstanceDao.updateAssetInstanceState(version.getAssetInstVersionId(),firstState,conn);
					}

					// adding gamification points
					if (!userName.equalsIgnoreCase("admin") && activeFlag == 1) {
						gamificationDetail.setPoints("5");
						gamificationDetail.setActivityTimestamp(
								new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
						gamificationDetail.setField("Asset Instance Version");
						gamificationDetail.setAction("Created");
						gamificationDetail.setUserId(userId);
						gamificationDetail.setAssetId(String.valueOf(assetId));
						gamificationDetail.setAssetInstanceVersionId(version.getAssetInstVersionId().toString());
						if (versionableFlag == 1) {
							gamificationDetail.setInstanceDetails(
									assetName + "~" + assetInstName + "~" + addAssetInstVersiondata.getVersionName());
						} else {
							gamificationDetail.setInstanceDetails(assetName + "~" + assetInstName + "~N/A");
						}

						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceVersions || dao method called : addGamificationPoint() : "
									+ gamificationDetail.toString());
						}
						gamificationDao.addGamificationPoint(gamificationDetail, conn);

					}

					String descForRevision = aiv0.getDescription();
					version.setAssetInstName(assetInstName);
					version.setAssetName(assetName);
					version.setAssetId(assetId);
					Long newAivId = version.getAssetInstVersionId();
					Long oldAivId = aiv0.getAssetInstVersionId();
					String newVersionName = addAssetInstVersiondata.getVersionName();
					String action = Constants.ACTIVITY_CREATE;
					String versionId = String.valueOf(newAivId);

					if (!copyFromVersion.equalsIgnoreCase("None")) {

						// copy properties and dependencies

						if (log.isTraceEnabled()) {
							log.trace(
									"addAssetInstanceVersions || called helper method : CopyPropertiesForChildInstance() : "
											+ gamificationDetail.toString());
						}
						commonUtils.CopyPropertiesForChildInstance(version, userId, copyFromVersion, oldAivId, userName,
								activeFlag, versionableFlag, context, conn);
						
						//Copy Representation Data
						repDao.copyAssetInstanceRepresentation(conn, version.getAssetInstanceId(), oldAivId, newAivId);

						// copyDependencies

						List<AssetInstRelationship> airs = null;
						AssetInstanceVersion aiv1 = new AssetInstanceVersion();
						AssetInstanceVersion aiv = new AssetInstanceVersion();
						Long srcVersionId = oldAivId;
						String destVersionName = addAssetInstVersiondata.getVersionName();
						String dependencyDirection = Constants.FORWARD_DEPENDENCY;

						if (dependencyDirection.equalsIgnoreCase(Constants.FORWARD_DEPENDENCY)) {

							if (log.isTraceEnabled()) {
								log.trace(
										"addAssetInstanceVersions || dao method called : retFwdRelationsForAnAssetInstanceVersionId() : "
												+ srcVersionId);
							}

							airs = relationshipDao.retFwdRelationsForAnAssetInstanceVersionId(srcVersionId, conn);
						} else {
							if (log.isTraceEnabled()) {
								log.trace(
										"addAssetInstanceVersions || dao method called : retRvrRelationsForAnAssetInstanceVersionId() : "
												+ srcVersionId);
							}

							airs = relationshipDao.retRvrRelationsForAnAssetInstanceVersionId(srcVersionId, conn);
						}
						// get asset instance version for new version

						if (log.isTraceEnabled()) {
							log.trace(
									"addAssetInstanceVersions || dao method called : getAssetInstanceVersionDetails() by AivID : "
											+ newAivId);
						}
						aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(newAivId, conn);

						AssetInstRelationship tempAir;

						for (AssetInstRelationship air : airs) {
							if (air.getRelationShipName().equalsIgnoreCase("composition")) {

								AssetDetailRequest adr = new AssetDetailRequest();
								adr.setAssetType(air.getAssetName());
								adr.setAssetInstName(air.getAssetInstanceName());

								List<Float> ds = new ArrayList<Float>();

								for (int i = 0; i < aivList.size(); i++) {

									float as = Float.parseFloat(aivList.get(i).getVersionName());
									ds.add(as);
								}

								float dg = getMax(ds);

								float desstVersionName = Float.parseFloat(newVersionName);
								if (desstVersionName > dg) {
									String stringVersionname = Float.toString(desstVersionName);

									adr.setVersionName(stringVersionname);
								} else {

									String stringVersionname1 = Float.toString(dg);
									String splitVal1 = stringVersionname1
											.substring(stringVersionname1.indexOf(".") + 1);
									int desstVers1 = Integer.parseInt(splitVal1);
									desstVers1 = 0;
									String subStringOfVersion1 = stringVersionname1.substring(0,
											stringVersionname1.indexOf("."));

									int majorver1 = Integer.parseInt(subStringOfVersion1);
									majorver1 = majorver1 + 1;
									adr.setVersionName(majorver1 + "." + desstVers1);
								}

								AssetDetailRequest adr1 = new AssetDetailRequest();
								adr1.setAssetType(air.getAssetName());
								adr1.setAssetInstName(air.getAssetInstanceName());
								adr1.setVersionName(air.getVersionName());
								Long versionid = air.getDestAssetInstVersionId();

								if (log.isTraceEnabled()) {
									log.trace(
											"addAssetInstanceVersions || dao method called : getAssetInstanceVersionDetails() by AivID : "
													+ versionid);
								}

								AssetInstanceVersion aivVo = assetInstanceVersionDao
										.getAssetInstanceVersionDetails(versionid, conn);

								AssetInstanceVersion aiv2 = new AssetInstanceVersion();

								aiv2.setVersionName(addAssetInstVersiondata.getVersionName());
								aiv2.setDescription(aivVo.getDescription());
								aiv2.setVersionNotes(Constants.DEFAULT_VERSION_NOTES);
								aiv2.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));

								if (log.isTraceEnabled()) {
									log.trace(
											"addAssetInstanceVersions || dao method called : addAssetInstanceVersions() : "
													+ aiv2.toString());
								}
								AssetInstanceVersion ai = assetInstanceVersionDao.addAssetInstanceVersions(aiv2,
										air.getAssetInstanceId(), aiv2.getDescription(), conn);

								if (log.isTraceEnabled()) {
									log.trace(
											"addAssetInstanceVersions || dao method called : getAssetInstanceVersionDetails() by AivID : "
													+ ai.getAssetInstVersionId());
								}

								aiv1 = assetInstanceVersionDao
										.getAssetInstanceVersionDetails(ai.getAssetInstVersionId(), conn);

								if (log.isTraceEnabled()) {
									log.trace(
											"addAssetInstanceVersions || dao method called : retassetgroupsAccess() by AssetID : "
													+ air.getAssetId());
								}

								List<GroupAssetAccess> groupAssetAccessList1 = groupDao
										.retassetgroupsAccess(air.getAssetId(), conn);

								for (GroupAssetAccess ga : groupAssetAccessList1) {
									GroupAssetAccess groupAssetInstAccess1 = new GroupAssetAccess();
									groupAssetInstAccess1.setAssetInstversionId(aiv1.getAssetInstVersionId());
									groupAssetInstAccess1.setEditAccess(ga.getEditAccess());
									groupAssetInstAccess1.setViewAccess(ga.getViewAccess());
									groupAssetInstAccess1.setDeleteAccess(ga.getDeleteAccess());
									groupAssetInstAccess1.setGroupId(ga.getGroupId());

									if (log.isTraceEnabled()) {
										log.trace(
												"addAssetInstanceVersions || dao method called : addGroupsAccessAISubmit() : "
														+ groupAssetInstAccess1.toString());
									}

									groupDao.addGroupsAccessAISubmit(groupAssetInstAccess1, conn);
								}

								GamificationDetails gamePoint1 = new GamificationDetails();
								if (!userName.equals("admin") && activeFlag == 1) {

									gamePoint1.setPoints("5");
									gamePoint1.setActivityTimestamp(
											new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
									gamePoint1.setField("Asset Instance version");
									gamePoint1.setAction("Created");
									gamePoint1.setUserId(userId);
									gamePoint1.setAssetId(String.valueOf(aiv1.getAssetId()));
									gamePoint1.setAssetInstanceVersionId(aiv1.getAssetInstVersionId().toString());
									if (aiv1.getVersionable() == true) {
										gamePoint1.setInstanceDetails(aiv1.getAssetName() + "~"
												+ aiv1.getAssetInstName() + "~" + aiv1.getVersionName());
									} else {
										gamePoint1.setInstanceDetails(
												aiv1.getAssetName() + "~" + aiv1.getAssetInstName() + "~N/A");
									}

									if (log.isTraceEnabled()) {
										log.trace(
												"addAssetInstanceVersions || dao method called : addGamificationPoint() : "
														+ gamificationDetail.toString());
									}
									gamificationDao.addGamificationPoint(gamePoint1, conn);

								}

								recentActivity = new RecentActivity();
								recentActivity
										.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								recentActivity.setAssetId(String.valueOf(aiv1.getAssetId()));
								recentActivity.setAssetInstVersionId(String.valueOf(ai.getAssetInstVersionId()));
								recentActivity.setDescription(
										user.getFullName() + ";" + action + ";" + aiv1.getAssetName() + ";"
												+ aiv1.getAssetInstName() + ";" + "version" + aiv1.getVersionName());
								recentActivity.setUser_id(userId);

								if (log.isTraceEnabled()) {
									log.trace("addAssetInstanceVersions || dao method called : addRecentActivity() : "
											+ recentActivity.toString());
								}

								recentActivityDao.addRecentActivity(recentActivity, conn);

								// copy properties for child instance
								if (air.getVersionName().equalsIgnoreCase(copyFromVersion)) {
									int versionFlag;

									if (aiv1.getVersionable() == true) {
										versionFlag = 1;

									} else {
										versionFlag = 0;
									}

									if (log.isTraceEnabled()) {
										log.trace(
												"addAssetInstanceVersions || called helper method : CopyPropertiesForChildInstance()");
									}
									commonUtils.CopyPropertiesForChildInstance(aiv1, userId, copyFromVersion,
											air.getDestAssetInstVersionId(), userName, activeFlag, versionFlag, context,
											conn);
									
									//Copy Representation Data
									repDao.copyAssetInstanceRepresentation(conn, aiv1.getAssetInstanceId(), air.getDestAssetInstVersionId(), aiv1.getAssetInstVersionId());

								}
								tempAir = new AssetInstRelationship();
								tempAir.setAssetRelId(air.getAssetrelationShipId());
								tempAir.setSrcAssetInstVersionId(aiv.getAssetInstVersionId());
								tempAir.setDestAssetInstVersionId(aiv1.getAssetInstVersionId());

								if (log.isTraceEnabled()) {
									log.trace(
											"addAssetInstanceVersions || dao method called : addAssetInstRelationship() : "
													+ tempAir.toString());
								}

								relationshipDao.addAssetInstRelationship(tempAir, conn);

								// Revision Addition for newly added version
								String usedByData = "";

								if (versionableFlag == 0) {
									usedByData = aiv.getAssetInstName() + "(" + air.getRelationShipName() + ")";
								} else {
									usedByData = aiv.getAssetInstName() + "_" + aiv.getVersionName() + "("
											+ air.getRelationShipName() + ")";
								}

								// insertInitialRevisionForAssetInstance

								AivRevisionHistory aivRevHistBo = new AivRevisionHistory();
								aivRevHistBo.setAivId(aiv1.getAssetInstVersionId());
								aivRevHistBo.setRevId(aiv1.getVersionName() + ".0");
								aivRevHistBo.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								aivRevHistBo.setChangedKey("N");
								aivRevHistBo.setOverviewData(aiv1.getDescription());
								aivRevHistBo.setRelationshipData(null);
								aivRevHistBo.setParameterData(null);
								aivRevHistBo.setUserId(userId);
								if (!usedByData.equalsIgnoreCase("")) {
									aivRevHistBo.setUsedBy(usedByData);
								} else {
									aivRevHistBo.setUsedBy(null);
								}

								if (log.isTraceEnabled()) {
									log.trace("addAssetInstanceVersions || dao method called : addRevisionData() : "
											+ aivRevHistBo.toString());
								}
								revisionHistoryDao.addRevisionData(aivRevHistBo, conn);

								// End of Revision Addition for newly added
								// version
							} else {

								tempAir = new AssetInstRelationship();
								tempAir.setAssetRelId(air.getAssetrelationShipId());
								tempAir.setSrcAssetInstVersionId(aiv.getAssetInstVersionId());
								tempAir.setDestAssetInstVersionId(air.getDestAssetInstVersionId());

								if (log.isTraceEnabled()) {
									log.trace(
											"addAssetInstanceVersions || dao method called : addAssetInstRelationship() : "
													+ tempAir.toString());
								}

								relationshipDao.addAssetInstRelationship(tempAir, conn);

								// Revision Addition for newly added version
								String usedByData = " ";

								if (versionableFlag == 0) {
									usedByData = aiv.getAssetInstName() + "(" + air.getRelationShipName() + ")";
								} else {
									usedByData = aiv.getAssetInstName() + "_" + aiv.getVersionName() + "("
											+ air.getRelationShipName() + ")";
								}

								// addUsedByData

								if (log.isTraceEnabled()) {
									log.trace(
											"addAssetInstanceVersions || called helper method : addUsedByData() : to add usedByData");
								}

								addUsedByData(air.getDestAssetInstVersionId(), userId, usedByData, conn);

							}

							if (air.getRelationShipName().equalsIgnoreCase("composition")) {

								if (log.isTraceEnabled()) {
									log.trace("addAssetInstanceVersions || called helper method : recurse()");
								}

								recurse(air, userId, aiv1, destVersionName, copyFromVersion, activeFlag,
										versionableFlag, context, userName, user.getFullName(), conn);

							}
						}

						String desc1 = " ";

						if (log.isTraceEnabled()) {
							log.trace(
									"addAssetInstanceVersions || called helper method : insertRevisionDataFromCopiedAIV() to add aiv revision history ");
						}
						insertRevisionDataFromCopiedAIV(addAssetInstVersiondata, userId, newAivId, oldAivId, true,
								desc1, userName, assetName, assetInstName, versionableFlag, conn);

						recentActivity = new RecentActivity();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setAssetId(String.valueOf(assetId));
						recentActivity.setAssetInstVersionId(versionId);
						recentActivity.setDescription(user.getFullName() + ";" + action + ";" + assetName + ";"
								+ assetInstName + ";" + "version" + version.getVersionName());

						recentActivity.setUser_id(userId);

						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceVersions || dao method called : addRecentActivity() : "
									+ recentActivity.toString());
						}

						recentActivityDao.addRecentActivity(recentActivity, conn);

					} else {
						// mandatory param values should copy if copy from version is none
						
						AssetDao adao = new AssetDao();
						List<AssetParamDef> apd1 = adao.getParamsDetailByAssetName(assetName,conn);
						boolean mandatoryFlag = false;
						for(AssetParamDef st : apd1){
							if(st.getParamTypeId()!= 5 && st.getParamTypeId()!= 6 ){
								if(st.isHasStaticValue() == false){
							 if(st.isHasMandatoryValue()){
								 mandatoryFlag = true;
								 break;
							}
								}
							}
						}
						if(mandatoryFlag){
							
							String newParamDataForRevision= commonUtils.CopyParameterForChildInstanceForCopyVersionNone(version, userId, afinal.getVersionName(), afinal.getAssetInstVersionId(), userName,
									activeFlag, versionableFlag, context, conn);
							
							// revision history generation
							
							AivRevisionHistory aivRevHist = new AivRevisionHistory();

							aivRevHist.setAivId(newAivId);
							aivRevHist.setRevId(addAssetInstVersiondata.getVersionName() + ".0");
							aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							aivRevHist.setChangedKey("V");
							aivRevHist.setUserId(userId);
							aivRevHist.setOverviewData(descForRevision);
							aivRevHist.setRelationshipData("");
							aivRevHist.setParameterData(newParamDataForRevision);
							aivRevHist.setUsedBy("");

							if (log.isTraceEnabled()) {
								log.trace("addAssetInstanceVersions || called dao method : addRevisionData() : "
										+ aivRevHist.toString());
							}

							revisionHistoryDao.addRevisionData(aivRevHist, conn);
							
						}else{
						     insertRevisionDataFromCopiedAIV(addAssetInstVersiondata, userId, newAivId, oldAivId, false,
								descForRevision, userName, assetName, assetInstName, versionableFlag, conn);
						}

						recentActivity = new RecentActivity();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setAssetId(String.valueOf(assetId));
						recentActivity.setAssetInstVersionId(versionId);
						recentActivity.setDescription(user.getFullName() + ";" + action + ";" + assetName + ";"
								+ assetInstName + ";" + "version" + version.getVersionName());
						recentActivity.setUser_id(userId);

						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceVersions || dao method called : addRecentActivity() : "
									+ recentActivity.toString());
						}

						recentActivityDao.addRecentActivity(recentActivity, conn);

					}

					// mailtemplate

					List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstanceId, conn);
					MailTemplateDao mailDao = new MailTemplateDao();
					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					MailConfig mailConfig = mailDao.getMailConfig(conn);
					String mailTemp = null;

					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn, "createAssetInstanceVersion");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%",
							addAssetInstVersiondata.getVersionName());

					if (emailIds != null) {
						for (String emailId : emailIds) {
							SendEmail.sendTextMail(mailConfig, emailId,
									MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
											+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
					}

					// group access

					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceVersions || dao method called : retassetgroupsAccess() by AssetId : "
								+ assetId);
					}

					List<GroupAssetAccess> groupAssetAccessList = groupDao.retassetgroupsAccess(assetId, conn);

					for (GroupAssetAccess ga : groupAssetAccessList) {
						groupAssetInstVerAccess = new GroupAssetAccess();
						groupAssetInstVerAccess.setAssetInstversionId(newAivId);
						groupAssetInstVerAccess.setEditAccess(ga.getEditAccess());
						groupAssetInstVerAccess.setViewAccess(ga.getViewAccess());
						groupAssetInstVerAccess.setDeleteAccess(ga.getDeleteAccess());
						groupAssetInstVerAccess.setGroupId(ga.getGroupId());

						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceVersions || dao method called : addGroupsAccessAISubmit() : "
									+ groupAssetInstVerAccess.toString());
						}
						groupDao.addGroupsAccessAISubmit(groupAssetInstVerAccess, conn);
					}

					retMsg = Constants.ASSET_INSTANCE_VERSION_CREATED;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					versionobj.add(version);
				}

				if (log.isInfoEnabled()) {
					log.info(" addAssetInstanceVersions || asset instance version details "
							+ addAssetInstVersiondata.toString() + " added successfully");
				}
				conn.commit();

			} catch (RepoproException e) {
				log.error("addAssetInstanceVersions ||  " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch (Exception e) {
				log.error("addAssetInstanceVersions ||  " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceVersions || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceVersions || " + addAssetInstVersiondata.toString() + " End");
			}

			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(versionobj))).build();

		}

	}

	public void addRevisionData(String changedKeyword, Long aivId, String VersionName, String overviewData,
			String relationshipData, String parametersData, String usedByData, String userName, Long userId,String instanceRenameing,
			Connection conn) throws RepoproException{

		log.trace("addRevisionData || begin");

		Connection conn1 = null;
		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("addRevisionData : " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();

			if (log.isTraceEnabled()) {
				log.trace("addRevisionData || dao method called : retAivRevHistoryByAivId() by AssetInstanceVersionId :"
						+ aivId);

			}
			List<AivRevisionHistory> aivRevisionHistoryBOs = revisionHistoryDao.retAivRevHistoryByAivId(aivId, conn);

			int[] revIdToFindMaxValue = new int[aivRevisionHistoryBOs.size()];
			String revId;
			String lastOverviewData, lastRelationshipData, lastParameterData, lastUsedByData,lastInstanceRename;

			// To set next revision id(revId)
			int i = 0;
			for (AivRevisionHistory aivRevisionHistoryBO : aivRevisionHistoryBOs) {
				String[] revIdLastIndex = aivRevisionHistoryBO.getRevId().split("\\.");
				revIdToFindMaxValue[i] = Integer.parseInt(revIdLastIndex[2]);
				i++;
			}
			int nextRevIdLastIndex = revIdToFindMaxValue[revIdToFindMaxValue.length - 1] + 1;
			revId = VersionName + "." + nextRevIdLastIndex;

			// To set last revision data's
			lastOverviewData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getOverviewData();
			lastRelationshipData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getRelationshipData();
			lastParameterData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getParameterData();
			lastUsedByData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getUsedBy();
			lastInstanceRename = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getInstanceRename();

			AivRevisionHistory aivRevHistBo = new AivRevisionHistory();
			aivRevHistBo.setAivId(aivId);
			aivRevHistBo.setRevId(revId);
			aivRevHistBo.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			aivRevHistBo.setUserId(userId);
			aivRevHistBo.setChangedKey(changedKeyword);

			if (changedKeyword.equalsIgnoreCase("O")) {
				if (!overviewData.isEmpty()) {
					aivRevHistBo.setOverviewData(overviewData);
				} else {
					aivRevHistBo.setOverviewData(null);
				}
				aivRevHistBo.setRelationshipData(lastRelationshipData);
				aivRevHistBo.setParameterData(lastParameterData);
				aivRevHistBo.setUsedBy(lastUsedByData);
				aivRevHistBo.setInstanceRename(lastInstanceRename);
				revisionHistoryDao.addRevisionData(aivRevHistBo, conn);
			} else if (changedKeyword.equalsIgnoreCase("R")) {
				aivRevHistBo.setOverviewData(lastOverviewData);
				if (!relationshipData.isEmpty()) {
					aivRevHistBo.setRelationshipData(relationshipData);
				} else {
					aivRevHistBo.setRelationshipData(null);
				}
				aivRevHistBo.setParameterData(lastParameterData);
				aivRevHistBo.setUsedBy(lastUsedByData);
				aivRevHistBo.setInstanceRename(lastInstanceRename);
				revisionHistoryDao.addRevisionData(aivRevHistBo, conn);
			} else if (changedKeyword.equalsIgnoreCase("P")) {
				aivRevHistBo.setOverviewData(lastOverviewData);
				aivRevHistBo.setRelationshipData(lastRelationshipData);
				if (!parametersData.isEmpty()) {
					aivRevHistBo.setParameterData(parametersData);
				} else {
					aivRevHistBo.setParameterData(null);
				}
				aivRevHistBo.setUsedBy(lastUsedByData);
				aivRevHistBo.setInstanceRename(lastInstanceRename);
				revisionHistoryDao.addRevisionData(aivRevHistBo, conn);
			} else if (changedKeyword.equalsIgnoreCase("U")) {
				aivRevHistBo.setOverviewData(lastOverviewData);
				aivRevHistBo.setRelationshipData(lastRelationshipData);
				aivRevHistBo.setParameterData(lastParameterData);
				aivRevHistBo.setInstanceRename(lastInstanceRename);
				if (!usedByData.isEmpty()) {
					aivRevHistBo.setUsedBy(usedByData);
				} else {
					aivRevHistBo.setUsedBy(null);
				}

				if (log.isTraceEnabled()) {
					log.trace("addRevisionData || dao method called : addRevisionData() : " + aivRevHistBo.toString());
				}

				revisionHistoryDao.addRevisionData(aivRevHistBo, conn);
			} else if (changedKeyword.equalsIgnoreCase("IR")) {
				if (!instanceRenameing.isEmpty()) {
					aivRevHistBo.setInstanceRename(instanceRenameing);
				} else {
					aivRevHistBo.setInstanceRename(null);
				}
				aivRevHistBo.setOverviewData(lastOverviewData);
				aivRevHistBo.setRelationshipData(lastRelationshipData);
				aivRevHistBo.setParameterData(lastParameterData);
				aivRevHistBo.setUsedBy(lastUsedByData);
				revisionHistoryDao.addRevisionData(aivRevHistBo, conn);
			}else{
				if (!instanceRenameing.isEmpty()) {
					aivRevHistBo.setInstanceRename(instanceRenameing);
				} else {
					aivRevHistBo.setInstanceRename(null);
				}
				if (!parametersData.isEmpty()) {
					aivRevHistBo.setParameterData(parametersData);
				} else {
					aivRevHistBo.setParameterData(lastParameterData);
				}
				if (!relationshipData.isEmpty()) {
					aivRevHistBo.setRelationshipData(relationshipData);
				} else {
					aivRevHistBo.setRelationshipData(lastRelationshipData);
				}
				if (!overviewData.isEmpty()) {
					aivRevHistBo.setOverviewData(overviewData);
				} else {
					aivRevHistBo.setOverviewData(lastOverviewData);
				}
				revisionHistoryDao.addRevisionData(aivRevHistBo, conn);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
			
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("addRevisionData : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("addRevisionData || Exit");
		}

	}

	public void addUsedByData(long destVersionId, Long userId, String usedByData, Connection conn)throws RepoproException {

		Connection conn1 = null;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("addUsedByData : " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace(
						"addUsedByData || dao method called : getAssetInstanceVersionDetails() by AssetInstanceVersionId :"
								+ destVersionId);
			}
			AssetInstanceVersion aiv6 = assetInstanceVersionDao.getAssetInstanceVersionDetails(destVersionId, conn);
			AssetInstanceVersion ai = new AssetInstanceVersion();
			ai.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			ai.setVersionName(aiv6.getVersionName());

			if (log.isTraceEnabled()) {
				log.trace("addUsedByData || dao method called : updateAivUpdatedOn() by AssetInstanceVersionId :"
						+ destVersionId + " and " + ai.toString());
			}

			assetInstanceVersionDao.updateAivUpdatedOn(ai, destVersionId, conn);

			if (log.isTraceEnabled()) {
				log.trace("addUsedByData || dao method called : retAivRevHistoryByAivId() by AssetInstanceVersionId :"
						+ destVersionId);

			}
			List<AivRevisionHistory> aivRevisionHistoryBOs = revisionHistoryDao.retAivRevHistoryByAivId(destVersionId,
					conn);
			int[] revIdToFindMaxValue = new int[aivRevisionHistoryBOs.size()];
			String revId;
			String lastOverviewData, lastRelationshipData, lastParameterData, lastUsedByData;

			// To set next revision id(revId)
			int i = 0;
			for (AivRevisionHistory aivRevisionHistoryBO : aivRevisionHistoryBOs) {
				String[] revIdLastIndex = aivRevisionHistoryBO.getRevId().split("\\.");
				revIdToFindMaxValue[i] = Integer.parseInt(revIdLastIndex[2]);
				i++;
			}
			int nextRevIdLastIndex = revIdToFindMaxValue[revIdToFindMaxValue.length - 1] + 1;
			revId = aiv6.getVersionName() + "." + nextRevIdLastIndex;

			// To set last revision data's
			lastOverviewData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getOverviewData();
			lastRelationshipData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getRelationshipData();
			lastParameterData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getParameterData();
			lastUsedByData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getUsedBy();
			AivRevisionHistory aivRevHist1 = new AivRevisionHistory();
			aivRevHist1.setAivId(destVersionId);
			aivRevHist1.setRevId(revId);
			aivRevHist1.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			aivRevHist1.setUserId(userId);
			aivRevHist1.setChangedKey("U");
			aivRevHist1.setOverviewData(lastOverviewData);
			aivRevHist1.setRelationshipData(lastRelationshipData);
			aivRevHist1.setParameterData(lastParameterData);
			if (lastUsedByData != null) {
				aivRevHist1.setUsedBy(lastUsedByData + Constants.APPEND_STRING + usedByData);
			} else {
				aivRevHist1.setUsedBy(usedByData);
			}

			if (log.isTraceEnabled()) {
				log.trace("addUsedByData || dao method called : addRevisionData() : " + aivRevHist1.toString());
			}

			revisionHistoryDao.addRevisionData(aivRevHist1, conn);

			// End of Revision Addition for newly added
			// version
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("addUsedByData : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("addUsedByData || Exit");
		}

	}

	public void recurse(AssetInstRelationship air, Long userId, AssetInstanceVersion aivos, String destVersionName,
			String copyFromVersion, int activeFlag, int versionableFlag, ServletContext context, String userName,
			String userFullName, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("recurse || begin");
		}

		CommonUtils commonUtils = new CommonUtils();
		RelationshipDao relationshipDao = new RelationshipDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		GamificationDao gamificationDao = new GamificationDao();
		RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		GroupDao groupDao = new GroupDao();
		String action = Constants.ACTIVITY_CREATE;
		AssetInstRelationship tempAir;
		AssetInstanceVersion aiv1 = new AssetInstanceVersion();
		Connection conn1 = null;
		AssetRepresentationDao repDao = new AssetRepresentationDao();

		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("addRevisionData : " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			List<AssetInstRelationship> airs1 = null;

			if (log.isTraceEnabled()) {
				log.trace("recurse || dao method called : retFwdRelationsForAnAssetInstanceVersionId() : "
						+ air.getDestAssetInstVersionId());
			}

			airs1 = relationshipDao.retFwdRelationsForAnAssetInstanceVersionId(air.getDestAssetInstVersionId(), conn);

			if (!airs1.isEmpty()) {

				for (AssetInstRelationship air1 : airs1) {

					if (air1.getRelationShipName().equalsIgnoreCase("composition")) {

						AssetDetailRequest adr = new AssetDetailRequest();
						adr.setAssetType(air1.getAssetName());
						adr.setAssetInstName(air1.getAssetInstanceName());

						if (log.isTraceEnabled()) {
							log.trace("recurse || dao method called : getAssetInstanceVersions() by assetInstanceId : "
									+ air1.getAssetInstanceId());
						}

						List<AssetInstanceVersion> aivVersionList = assetInstanceVersionDao
								.getAssetInstanceVersions(air1.getAssetInstanceId(), conn);

						List<Float> ds = new ArrayList<Float>();

						for (int i = 0; i < aivVersionList.size(); i++) {

							float as = Float.parseFloat(aivVersionList.get(i).getVersionName());
							ds.add(as);
						}

						float dg = getMax(ds);
						float desstVersionName = Float.parseFloat(destVersionName);
						if (/* desstVersionName == dg || */desstVersionName > dg) {
							String stringVersionname = Float.toString(desstVersionName);

							adr.setVersionName(stringVersionname);
						} else {

							String stringVersionname1 = Float.toString(dg);
							String splitVal1 = stringVersionname1.substring(stringVersionname1.indexOf(".") + 1);
							int desstVers1 = Integer.parseInt(splitVal1);
							desstVers1 = 0;
							String subStringOfVersion1 = stringVersionname1.substring(0,
									stringVersionname1.indexOf("."));

							int majorver1 = Integer.parseInt(subStringOfVersion1);
							majorver1 = majorver1 + 1;
							adr.setVersionName(majorver1 + "." + desstVers1);
						}

						AssetDetailRequest adr2 = new AssetDetailRequest();
						adr2.setAssetType(air1.getAssetName());
						adr2.setAssetInstName(air1.getAssetInstanceName());
						adr2.setVersionName(air1.getVersionName());
						Long versionid1 = air1.getDestAssetInstVersionId();

						if (log.isTraceEnabled()) {
							log.trace(
									"recurse || dao method called : getAssetInstanceVersionDetails() by assetInstanceVersionId : "
											+ versionid1);
						}
						AssetInstanceVersion aivVo1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(versionid1,
								conn);

						AssetInstanceVersion aiv2 = new AssetInstanceVersion();

						aiv2.setVersionName(destVersionName);
						aiv2.setDescription(aivVo1.getDescription());
						aiv2.setVersionNotes("This is a default version created by system");
						aiv2.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));

						if (log.isTraceEnabled()) {
							log.trace("recurse || dao method called : addAssetInstanceVersions() by assetInstanceId: "
									+ air1.getAssetInstanceId() + "and" + aiv2.toString());
						}

						AssetInstanceVersion aiv3 = assetInstanceVersionDao.addAssetInstanceVersions(aiv2,
								air1.getAssetInstanceId(), aiv2.getDescription(), conn);

						if (log.isTraceEnabled()) {
							log.trace(
									"recurse || dao method called : getAssetInstanceVersionDetails() by AssetInstanceVersionId : "
											+ air1.getDestAssetInstVersionId());
						}

						aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(aiv3.getAssetInstVersionId(),
								conn);

						if (log.isTraceEnabled()) {
							log.trace("recurse || dao method called : retassetgroupsAccess() by assetId : "
									+ air1.getAssetId());
						}

						List<GroupAssetAccess> groupAssetAccessList = groupDao.retassetgroupsAccess(air1.getAssetId(),
								conn);
						for (GroupAssetAccess ga : groupAssetAccessList) {
							GroupAssetAccess groupAssetInstAccess = new GroupAssetAccess();
							groupAssetInstAccess.setAssetInstversionId(aiv3.getAssetInstVersionId());
							groupAssetInstAccess.setEditAccess(ga.getEditAccess());
							groupAssetInstAccess.setViewAccess(ga.getViewAccess());
							groupAssetInstAccess.setDeleteAccess(ga.getDeleteAccess());
							groupAssetInstAccess.setGroupId(ga.getGroupId());

							if (log.isTraceEnabled()) {
								log.trace("recurse || dao method called : addGroupsAccessAISubmit() : "
										+ groupAssetInstAccess.toString());
							}

							groupDao.addGroupsAccessAISubmit(groupAssetInstAccess, conn);
						}

						if (!userName.equals("admin") && activeFlag == 1) {

							GamificationDetails gamePoint = new GamificationDetails();

							gamePoint.setPoints("5");
							gamePoint.setActivityTimestamp(
									new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
							gamePoint.setField("Asset Instance");
							gamePoint.setAction("Created");
							gamePoint.setUserId(userId);
							gamePoint.setAssetId(String.valueOf(aiv1.getAssetId()));
							gamePoint.setAssetInstanceVersionId(aiv1.getAssetInstVersionId().toString());
							if (versionableFlag == 1) {
								gamePoint.setInstanceDetails(aiv1.getAssetName() + "~" + aiv1.getAssetInstName()
										+ "~" + aiv1.getVersionName());
							} else {
								gamePoint.setInstanceDetails(
										aiv1.getAssetName() + "~" + aiv1.getAssetInstName() + "~N/A");
							}

							if (log.isTraceEnabled()) {
								log.trace("recurse || dao method called : addGamificationPoint()  : "
										+ gamePoint.toString());
							}
							gamificationDao.addGamificationPoint(gamePoint, conn);

						}

						RecentActivity recentActivity = new RecentActivity();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setAssetId(String.valueOf(aiv1.getAssetId()));
						recentActivity.setAssetInstVersionId(aiv1.getAssetInstVersionId().toString());
						recentActivity.setDescription(userFullName + ";" + action + ";" + aiv1.getAssetName() + ";"
								+ aiv1.getAssetInstName() + ";" + "version" + aiv1.getVersionName());
						recentActivity.setUser_id(userId);

						if (log.isTraceEnabled()) {
							log.trace("recurse || dao method called : addRecentActivity() : "
									+ recentActivity.toString());
						}

						recentActivityDao.addRecentActivity(recentActivity, conn);

						if (air1.getVersionName().equalsIgnoreCase(copyFromVersion)) {
							// copy properties for child instance

							if (log.isTraceEnabled()) {
								log.trace("recurse || called helper method  : CopyPropertiesForChildInstance()");
							}
							commonUtils.CopyPropertiesForChildInstance(aiv1, userId, copyFromVersion,
									air1.getDestAssetInstVersionId(), userName, activeFlag, versionableFlag, context,
									conn);

							//Copy Representation Data
							repDao.copyAssetInstanceRepresentation(conn, aiv1.getAssetInstanceId(), air1.getDestAssetInstVersionId(), aiv1.getAssetInstVersionId());
						}

						tempAir = new AssetInstRelationship();
						tempAir.setAssetRelId(air1.getAssetrelationShipId());
						tempAir.setSrcAssetInstVersionId(aivos.getAssetInstVersionId());
						tempAir.setDestAssetInstVersionId(aiv3.getAssetInstVersionId());

						if (log.isTraceEnabled()) {
							log.trace("recurse || dao method called : addAssetInstRelationship() : "
									+ tempAir.toString());
						}

						relationshipDao.addAssetInstRelationship(tempAir, conn);

						// Revision Addition for newly added version
						String usedByData = "";

						if (versionableFlag == 0) {
							usedByData = aivos.getAssetInstName() + "(" + air1.getRelationShipName() + ")";
						} else {
							usedByData = aivos.getAssetInstName() + "_" + aivos.getVersionName() + "("
									+ air1.getRelationShipName() + ")";
						}

						// insert initial revision
						AivRevisionHistory aivRevHistBo = new AivRevisionHistory();
						aivRevHistBo.setAivId(aiv3.getAssetInstVersionId());
						aivRevHistBo.setRevId(aiv3.getVersionName() + ".0");
						aivRevHistBo.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						aivRevHistBo.setChangedKey("N");
						aivRevHistBo.setOverviewData(aiv1.getDescription());
						aivRevHistBo.setRelationshipData(null);
						aivRevHistBo.setParameterData(null);
						aivRevHistBo.setUserId(userId);
						if (!usedByData.equalsIgnoreCase("")) {
							aivRevHistBo.setUsedBy(usedByData);
						} else {
							aivRevHistBo.setUsedBy(null);
						}

						if (log.isTraceEnabled()) {
							log.trace("recurse || dao method called : addRevisionData() : " + aivRevHistBo.toString());
						}

						revisionHistoryDao.addRevisionData(aivRevHistBo, conn);

						// End of Revision Addition for newly added version
					} else {

						tempAir = new AssetInstRelationship();
						tempAir.setAssetRelId(air1.getAssetrelationShipId());
						if (aivos != null) {
							tempAir.setSrcAssetInstVersionId(aivos.getAssetInstVersionId());
						} else {
							tempAir.setSrcAssetInstVersionId(air.getDestAssetInstVersionId());
						}
						tempAir.setDestAssetInstVersionId(air1.getDestAssetInstVersionId());
						if (aivos == null && !air1.getRelationShipName().equalsIgnoreCase("composition")) {

						} else {

							if (log.isTraceEnabled()) {
								log.trace("recurse || dao method called : addAssetInstRelationship() : "
										+ tempAir.toString());
							}
							relationshipDao.addAssetInstRelationship(tempAir, conn);

							// Revision Addition for newly added version

							String usedByData = "";

							if (versionableFlag == 0) {
								usedByData = aivos.getAssetInstName() + "(" + air1.getRelationShipName() + ")";
							} else {
								usedByData = aivos.getAssetInstName() + "_" + aivos.getVersionName() + "("
										+ air1.getRelationShipName() + ")";
							}

							// addUsedByData

							if (log.isTraceEnabled()) {
								log.trace(
										"recurse || dao method called : getAssetInstanceVersionDetails() by assetInstanceVersionId : "
												+ air1.getDestAssetInstVersionId());
							}

							AssetInstanceVersion aiv6 = assetInstanceVersionDao
									.getAssetInstanceVersionDetails(air1.getDestAssetInstVersionId(), conn);
							AssetInstanceVersion ai = new AssetInstanceVersion();
							ai.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));

							ai.setVersionName(aiv6.getVersionName());
							if (log.isTraceEnabled()) {
								log.trace(
										"recurse || dao method called : updateAivUpdatedOn() by assetInstanceVersionId : "
												+ air1.getDestAssetInstVersionId() + "and" + ai.toString());
							}
							assetInstanceVersionDao.updateAivUpdatedOn(ai, air1.getDestAssetInstVersionId(), conn);

							// End of Revision Addition for newly added version

						}

					}
					if (air1.getRelationShipName().equalsIgnoreCase("composition")) {
						recurse(air1, userId, aiv1, destVersionName, copyFromVersion, activeFlag, versionableFlag,
								context, userName, userFullName, conn);

					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("recurse : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("recurse || Exit");
		}
	}

	public float getMax(List<Float> list) {
		Float max = Float.MIN_VALUE;
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i) > max) {
				max = list.get(i);
			}
		}
		return max;
	}

	public void insertRevisionDataFromCopiedAIV(AssetInstanceVersion addAssetInstVersiondata, Long userId,
			Long newAivId, Long oldAivId, boolean isCopied, String desc, String userName, String assetName,
			String assetInstName, int versionableFlag, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("insertRevisionDataFromCopiedAIV || begin");
		}

		Connection conn1 = null;
		try {

			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("insertRevisionDataFromCopiedAIV : " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
			AivRevisionHistory aivRevHist = new AivRevisionHistory();

			aivRevHist.setAivId(newAivId);
			aivRevHist.setRevId(addAssetInstVersiondata.getVersionName() + ".0");
			aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			aivRevHist.setChangedKey("V");
			aivRevHist.setUserId(userId);

			String lastOverviewData, lastRelationshipData, lastParameterData, lastUsedByData;
			List<AssetInstRelationship> airs = new ArrayList<AssetInstRelationship>();
			ArrayList<AssetInstanceVersion> assetInstanceversionList = new ArrayList<AssetInstanceVersion>();
			AssetInstanceVersion assetInstanceversion = null;
			// If copied from old version
			if (isCopied == true) {

				if (log.isTraceEnabled()) {
					log.trace(
							"insertRevisionDataFromCopiedAIV || called dao method : retAivRevHistoryByAivId() by AssetInstanceVersionId: "
									+ oldAivId);
				}

				List<AivRevisionHistory> aivRevisionHistoryList = revisionHistoryDao.retAivRevHistoryByAivId(oldAivId,
						conn);

				int[] revIdToFindMaxValue = new int[aivRevisionHistoryList.size()];
				if (aivRevisionHistoryList.size() > 0) {
					// To set next revision id(revId)
					int i = 0;
					for (AivRevisionHistory aivRevisionHistory : aivRevisionHistoryList) {
						String[] revIdLastIndex = aivRevisionHistory.getRevId().split("\\.");
						revIdToFindMaxValue[i] = Integer.parseInt(revIdLastIndex[2]);
						i++;
					}

					// To set last revision data's
					lastOverviewData = aivRevisionHistoryList.get(revIdToFindMaxValue.length - 1).getOverviewData();

					// Fetching relationship data for revision storage
					AssetDetailRequest adrNew = new AssetDetailRequest();
					RelationshipDao relationshipDao = new RelationshipDao();
					adrNew.setAssetType(assetName);
					adrNew.setAssetInstName(assetInstName);
					adrNew.setVersionName(addAssetInstVersiondata.getVersionName());

					if (log.isTraceEnabled()) {
						log.trace(
								"insertRevisionDataFromCopiedAIV || called dao method : retFwdRelationsForAnAssetInstanceVersionId() by AssetInstanceVersionId: "
										+ newAivId);
					}

					airs = relationshipDao.retFwdRelationsForAnAssetInstanceVersionId(newAivId, conn);

					for (AssetInstRelationship air : airs) {
						assetInstanceversion = new AssetInstanceVersion();

						assetInstanceversion.setAssetName(air.getAssetName());
						assetInstanceversion.setAssetInstName(air.getAssetInstanceName());
						assetInstanceversion.setVersionName(air.getVersionName());

						assetInstanceversionList.add(assetInstanceversion);

					}

					String newRelationshipDataForRevision = " ";
					int j = 1;
					for (AssetInstanceVersion aivo : assetInstanceversionList) {

						if (j == assetInstanceversionList.size()) {
							if (versionableFlag == 0) {
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()
										+ "-->" + aivo.getAssetInstName();
							} else {
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()
										+ "-->" + aivo.getAssetInstName() + "_" + aivo.getVersionName();
							}
						} else {
							if (versionableFlag == 0) {
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()
										+ "-->" + aivo.getAssetInstName() + Constants.APPEND_STRING;
							} else {
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()
										+ "-->" + aivo.getAssetInstName() + "_" + aivo.getVersionName()
										+ Constants.APPEND_STRING;
							}
						}
						j++;
					}
					if (newRelationshipDataForRevision.isEmpty()
							|| newRelationshipDataForRevision.equalsIgnoreCase("")) {
						lastRelationshipData = " ";
					} else {
						lastRelationshipData = newRelationshipDataForRevision;
					}
					lastParameterData = aivRevisionHistoryList.get(revIdToFindMaxValue.length - 1).getParameterData();
					lastUsedByData = " ";

				} else {
					lastOverviewData = " ";
					lastRelationshipData = " ";
					lastParameterData = " ";
					lastUsedByData = " ";
				}
			}

			else {
				lastOverviewData = desc;
				lastRelationshipData = " ";
				lastParameterData = " ";
				lastUsedByData = " ";
			}

			aivRevHist.setOverviewData(lastOverviewData);
			aivRevHist.setRelationshipData(lastRelationshipData);
			aivRevHist.setParameterData(lastParameterData);
			aivRevHist.setUsedBy(lastUsedByData);

			if (log.isTraceEnabled()) {
				log.trace("insertRevisionDataFromCopiedAIV || called dao method : addRevisionData() : "
						+ aivRevHist.toString());
			}

			revisionHistoryDao.addRevisionData(aivRevHist, conn);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("insertRevisionDataFromCopiedAIV : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("insertRevisionDataFromCopiedAIV || Exit");
		}
	}

	/**
	 * @method deleteAssetInstanceVersions
	 * @description to delete asset instance version
	 * @param userName
	 *            ,assetInstanceVersionId,assetName,assetInstanceId,assetId,
	 *            assetName,versionableFlag,versionName
	 * @return success Response
	 * @throws RepoproException
	 *//*

	@DELETE
	@Encoded
	@Path("/deleteAssetInstanceVersions")
	public Response deleteAssetInstanceVersions(@QueryParam("assetInstanceId") Long assetInstanceId,
			@QueryParam("assetInstName") String assetInstName, @QueryParam("assetId") Long assetId,
			@QueryParam("assetName") String assetName, @QueryParam("userName") String userName,
			@QueryParam("userId") Long userId, @QueryParam("versionableFlag") int versionableFlag,
			@QueryParam("assetInstanceVersionId") Long assetInstanceVersionId,
			@QueryParam("versionName") String versionName) {

		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceVersions || Begin with assetInstanceId " + assetInstanceId
					+ "assetInstName+ assetInstName+ " + "assetId" + assetId + "assetName " + assetName + "userId"
					+ userId + "userName" + userName + "versionableFlag" + versionableFlag + "assetInstanceVersionId"
					+ assetInstanceVersionId + "versionName" + versionName);

		}

		Connection conn = null;
		Status retStat = Status.OK;
		SubscriptionDao subscriptionDao = new SubscriptionDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		List<AssetInstanceVersion> versionList = new ArrayList<AssetInstanceVersion>();
		String retMsg = null;
		String retScsFlr = null;
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		RecentActivity recentActivity = new RecentActivity();
		RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
		int retStatScsFlr = 0;
		int val;
		String action = Constants.ACTIVITY_DELETE;
		UserDao userDao = new UserDao();
		User user = null;

		try {
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceVersions || " + Constants.LOG_CONNECTION_OPEN);
			}

			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			user = userDao.retProfileForUserName(userName, conn);
			AssetDetailRequest assetDetReq = new AssetDetailRequest();
			assetDetReq.setAssetInstName(assetInstName);
			assetDetReq.setAssetType(assetName);
			assetDetReq.setVersionName(versionName);

			if (log.isTraceEnabled()) {
				log.trace(
						"deleteAssetInstanceVersions || dao method called : getAssetInstanceVersions() by assetInstanceId"
								+ assetInstanceId);
			}

			versionList = assetInstanceVersionDao.getAssetInstanceVersions(assetInstanceId, conn);

			if (versionList.size() > 1) {

				// remove Relationship Datas

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersions || called helper method : removeRelationshipDatas() to remove relationship data");
				}
				removeRelationshipDatas(assetDetReq, assetInstanceVersionId, userName, userId, versionableFlag, conn);

				// Deleting dependent asset instances deletes the asset instance
				// version entries and other table entries

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersions || called helper method : removeDependents() to remove dependents ");
				}
				removeDependents(assetDetReq, userName, user.getFullName(), userId, assetInstanceVersionId,
						assetInstanceId, versionableFlag, conn);

				// Delete asset instance version

				// To delete revision history record before deleting AIV's

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersions || called  : retAivRevisionHistory() by assetInstanceVersionId :+assetInstanceVersionId ");
				}
				List<AivRevisionHistory> aivRevisionHistoryBOs = revisionHistoryDao
						.retAivRevisionHistory(assetInstanceVersionId, conn);
				for (AivRevisionHistory aivRevisionHistoryBO : aivRevisionHistoryBOs) {

					if (log.isTraceEnabled()) {
						log.trace("deleteAssetInstanceVersions || dao method called : deleteAivRevHistoryByAivId()"
								+ aivRevisionHistoryBO.toString());
					}

					revisionHistoryDao.deleteAivRevHistoryByAivId(aivRevisionHistoryBO, conn);
				}

				// add recent activity

				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setAssetId(String.valueOf(assetId));
				String versionId = String.valueOf(assetInstanceVersionId);
				recentActivity.setAssetInstVersionId(versionId);
				recentActivity.setDescription(user.getFullName() + ";" + action + ";" + assetName + ";" + assetInstName
						+ ";" + "version" + versionName);
				recentActivity.setUser_id(userId);
				recentActivityDao.addRecentActivity(recentActivity, conn);

				if (log.isTraceEnabled()) {
					log.trace("deleteAssetInstanceVersions || dao method called : addRecentActivity()"
							+ recentActivity.toString());
				}

				// mail template
				try {

					List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstanceId, conn);
					MailTemplateDao mailDao = new MailTemplateDao();
					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					MailConfig mailConfig = mailDao.getMailConfig(conn);
					String mailTemp = null;

					if (versionableFlag == 1) {

						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"deleteAssetInstanceVersionForVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%",
								versionName);

					} else {

						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"deleteAssetInstanceVersionForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
					}

					if (emailIds != null) {
						for (String emailId : emailIds) {
							if (versionableFlag == 1) {

								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
							} else {

								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
						}

					}
				} catch (Exception e) {

				}

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersions || dao method called : deleteAssetInstanceVersions by assetInstanceVersionId"
									+ assetInstanceVersionId);
				}
				assetInstanceVersionDao.deleteAssetInstanceVersions(assetInstanceVersionId, conn);

			} else {

				// To get all backward relationships

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersions || called helper method : removeRelationshipDatas() to remove relationship data");
				}

				removeRelationshipDatas(assetDetReq, assetInstanceVersionId, userName, userId, versionableFlag, conn);

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersions || called helper method : removeDependents() to remove dependent data");
				}

				removeDependents(assetDetReq, userName, user.getFullName(), userId, assetInstanceVersionId,
						assetInstanceId, versionableFlag, conn);

				// To delete revision history record before deleting AIV's

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersions || called  : retAivRevisionHistory() by assetInstanceVersionId :+assetInstanceVersionId ");
				}
				List<AivRevisionHistory> aivRevisionHistoryBOs = revisionHistoryDao
						.retAivRevisionHistory(assetInstanceVersionId, conn);
				for (AivRevisionHistory aivRevisionHistoryBO : aivRevisionHistoryBOs) {

					if (log.isTraceEnabled()) {
						log.trace("deleteAssetInstanceVersions || dao method called : deleteAivRevHistoryByAivId()"
								+ aivRevisionHistoryBO.toString());
					}

					revisionHistoryDao.deleteAivRevHistoryByAivId(aivRevisionHistoryBO, conn);

				}

				
				 * AivRevisionHistory aivRevisionHistoryBO = new
				 * AivRevisionHistory();
				 * aivRevisionHistoryBO.setAivId(assetInstanceVersionId); if
				 * (log.isTraceEnabled()) { log.trace(
				 * "deleteAssetInstanceVersions || dao method called : deleteAivRevHistoryByAivId()"
				 * + aivRevisionHistoryBO.toString()); }
				 * 
				 * revisionHistoryDao.deleteAivRevHistoryByAivId(
				 * aivRevisionHistoryBO, conn);
				 

				// add recent activity

				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setAssetId(String.valueOf(assetId));
				String versionId = String.valueOf(assetInstanceVersionId);
				recentActivity.setAssetInstVersionId(versionId);
				recentActivity.setDescription(user.getFullName() + ";" + action + ";" + assetName + ";" + assetInstName
						+ ";" + "version" + versionName);
				recentActivity.setUser_id(userId);
				recentActivityDao.addRecentActivity(recentActivity, conn);
				if (log.isTraceEnabled()) {
					log.trace("deleteAssetInstanceVersions || dao method called : addRecentActivity()"
							+ recentActivity.toString());
				}

				// mail template
				try {

					List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstanceId, conn);
					MailTemplateDao mailDao = new MailTemplateDao();
					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					MailConfig mailConfig = mailDao.getMailConfig(conn);
					String mailTemp = null;

					if (versionableFlag == 1) {

						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"deleteAssetInstanceVersionForVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%",
								versionName);

					} else {

						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"deleteAssetInstanceVersionForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
					}

					if (emailIds != null) {
						for (String emailId : emailIds) {
							if (versionableFlag == 1) {

								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
							} else {

								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
						}

					}
				} catch (Exception e) {

				}
				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersions || dao method called : deleteAssetInstanceVersions by assetInstanceVersionId ()"
									+ assetInstanceVersionId);
				}

				assetInstanceVersionDao.deleteAssetInstanceVersions(assetInstanceVersionId, conn);

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersions || dao method called : deleteAssetInstance() by assetInstanceId"
									+ assetInstanceId);
				}

				assetInstanceDao.deleteAssetInstance(assetInstanceId, conn);
			}

			retMsg = Constants.ASSET_INSTANCE_VERSION_DELETED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			conn.commit();

			if (log.isInfoEnabled()) {
				log.info("deleteAssetInstanceVersions || Asset instance version with AssetInstanceVersionId:"
						+ assetInstanceVersionId + " deleted successfully");
			}
		} catch (RepoproException e) {
			log.error("deleteAssetInstanceVersions || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("deleteAssetInstanceVersions || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceVersions || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceVersions || assetInstanceVersionId:" + assetInstanceVersionId + "||End");
		}

		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
*/
	
	/**
	 * @method deleteAssetInstanceVersions
	 * @description to delete asset instance version
	 * @param userName
	 *            ,assetInstanceVersionId,assetName,assetInstanceId,assetId,
	 *            assetName,versionableFlag,versionName
	 * @return success Response
	 * @throws RepoproException
	 */

	@DELETE
	@Encoded
	@Path("/deleteAssetInstanceVersions")
	public Response deleteAssetInstanceVersions(@QueryParam("assetInstanceId") Long assetInstanceId,
			@QueryParam("assetInstName") String assetInstName, @QueryParam("assetId") Long assetId,
			@QueryParam("assetName") String assetName, @QueryParam("userName") String userName,
			@QueryParam("userId") Long userId, @QueryParam("versionableFlag") int versionableFlag,
			@QueryParam("assetInstanceVersionId") Long assetInstanceVersionId,
			@QueryParam("versionName") String versionName) {

		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceVersions || Begin with assetInstanceId " + assetInstanceId
					+ "assetInstName+ assetInstName+ " + "assetId" + assetId + "assetName " + assetName + "userId"
					+ userId + "userName" + userName + "versionableFlag" + versionableFlag + "assetInstanceVersionId"
					+ assetInstanceVersionId + "versionName" + versionName);

		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		try {
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceVersions || " + Constants.LOG_CONNECTION_OPEN);
			}

			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			assetName = URLDecoder.decode(assetName, "UTF-8");
			
			Response response = deleteAssetInstanceVersionsHelper(assetInstanceId, assetInstName, assetId, assetName, userName, userId,
					versionableFlag, assetInstanceVersionId, versionName, false, conn);
			
			return response;
			
			
		} catch (RepoproException e) {
			log.error("deleteAssetInstanceVersions || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("deleteAssetInstanceVersions || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceVersions || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceVersions || assetInstanceVersionId:" + assetInstanceVersionId + "||End");
		}

		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	public Response deleteAssetInstanceVersionsHelper(Long assetInstanceId,
			String assetInstName, Long assetId,String assetName, String userName,
			Long userId, int versionableFlag,Long assetInstanceVersionId,String versionName,Boolean importFlag,Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceVersions || Begin with assetInstanceId " + assetInstanceId
					+ "assetInstName+ assetInstName+ " + "assetId" + assetId + "assetName " + assetName + "userId"
					+ userId + "userName" + userName + "versionableFlag" + versionableFlag + "assetInstanceVersionId"
					+ assetInstanceVersionId + "versionName" + versionName);

		}

		Connection conn1 = null;
		Status retStat = Status.OK;
		SubscriptionDao subscriptionDao = new SubscriptionDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		List<AssetInstanceVersion> versionList = new ArrayList<AssetInstanceVersion>();
		String retMsg = null;
		String retScsFlr = null;
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		RecentActivity recentActivity = new RecentActivity();
		RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
		int retStatScsFlr = 0;
		int val;
		String action = Constants.ACTIVITY_DELETE;
		UserDao userDao = new UserDao();
		User user = null;

		try {
			
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceVersionsHelper || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			conn.setAutoCommit(false);
			user = userDao.retProfileForUserName(userName, conn);
			AssetDetailRequest assetDetReq = new AssetDetailRequest();
			assetDetReq.setAssetInstName(assetInstName);
			assetDetReq.setAssetType(assetName);
			assetDetReq.setVersionName(versionName);

			if (log.isTraceEnabled()) {
				log.trace(
						"deleteAssetInstanceVersionsHelper || dao method called : getAssetInstanceVersions() by assetInstanceId"
								+ assetInstanceId);
			}

			versionList = assetInstanceVersionDao.getAssetInstanceVersions(assetInstanceId, conn);

			if (versionList.size() > 1) {

				// remove Relationship Datas

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersionsHelper || called helper method : removeRelationshipDatas() to remove relationship data");
				}
				removeRelationshipDatas(assetDetReq, assetInstanceVersionId, userName, userId, versionableFlag, conn);

				// Deleting dependent asset instances deletes the asset instance
				// version entries and other table entries

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersionsHelper || called helper method : removeDependents() to remove dependents ");
				}
				removeDependents(assetDetReq, userName, user.getFullName(), userId, assetInstanceVersionId,
						assetInstanceId, versionableFlag, conn);

				// Delete asset instance version

				// To delete revision history record before deleting AIV's

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersionsHelper || called  : retAivRevisionHistory() by assetInstanceVersionId :+assetInstanceVersionId ");
				}
				List<AivRevisionHistory> aivRevisionHistoryBOs = revisionHistoryDao
						.retAivRevisionHistory(assetInstanceVersionId, conn);
				for (AivRevisionHistory aivRevisionHistoryBO : aivRevisionHistoryBOs) {

					if (log.isTraceEnabled()) {
						log.trace("deleteAssetInstanceVersionsHelper || dao method called : deleteAivRevHistoryByAivId()"
								+ aivRevisionHistoryBO.toString());
					}

					revisionHistoryDao.deleteAivRevHistoryByAivId(aivRevisionHistoryBO, conn);
				}

				// add recent activity

				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setAssetId(String.valueOf(assetId));
				String versionId = String.valueOf(assetInstanceVersionId);
				recentActivity.setAssetInstVersionId(versionId);
				recentActivity.setDescription(user.getFullName() + ";" + action + ";" + assetName + ";" + assetInstName
						+ ";" + "version" + versionName);
				recentActivity.setUser_id(userId);
				recentActivityDao.addRecentActivity(recentActivity, conn);

				if (log.isTraceEnabled()) {
					log.trace("deleteAssetInstanceVersionsHelper || dao method called : addRecentActivity()"
							+ recentActivity.toString());
				}

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersionsHelper || dao method called : deleteAssetInstanceVersions by assetInstanceVersionId"
									+ assetInstanceVersionId);
				}
				assetInstanceVersionDao.deleteAssetInstanceVersions(assetInstanceVersionId, conn);
				
				// mail template
				if(importFlag == false){
					try {

						List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstanceId, conn);
						MailTemplateDao mailDao = new MailTemplateDao();
						MailTemplateDao mailTemplateDao = new MailTemplateDao();
						MailConfig mailConfig = mailDao.getMailConfig(conn);
						String mailTemp = null;

						if (versionableFlag == 1) {

							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"deleteAssetInstanceVersionForVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%",
									versionName);

						} else {

							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"deleteAssetInstanceVersionForNonVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
						}

						if (emailIds != null) {
							for (String emailId : emailIds) {
								if (versionableFlag == 1) {

									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								} else {

									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));

								}
							}

						}
					} catch (Exception e) {

					}
				}
				
				String outputPath = Constants.UPLOADED_JAR_SUPPORT_FILE_PATH + assetInstanceVersionId + "/";
				File instFile = new File(outputPath);
				if(instFile.exists()) {
					FileUtils.forceDelete(new File(outputPath));
				}

			} else {

				// To get all backward relationships

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersionsHelper || called helper method : removeRelationshipDatas() to remove relationship data");
				}

				removeRelationshipDatas(assetDetReq, assetInstanceVersionId, userName, userId, versionableFlag, conn);

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersionsHelper || called helper method : removeDependents() to remove dependent data");
				}

				removeDependents(assetDetReq, userName, user.getFullName(), userId, assetInstanceVersionId,
						assetInstanceId, versionableFlag, conn);

				// To delete revision history record before deleting AIV's

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersionsHelper || called  : retAivRevisionHistory() by assetInstanceVersionId :+assetInstanceVersionId ");
				}
				List<AivRevisionHistory> aivRevisionHistoryBOs = revisionHistoryDao
						.retAivRevisionHistory(assetInstanceVersionId, conn);
				for (AivRevisionHistory aivRevisionHistoryBO : aivRevisionHistoryBOs) {

					if (log.isTraceEnabled()) {
						log.trace("deleteAssetInstanceVersionsHelper || dao method called : deleteAivRevHistoryByAivId()"
								+ aivRevisionHistoryBO.toString());
					}

					revisionHistoryDao.deleteAivRevHistoryByAivId(aivRevisionHistoryBO, conn);

				}

				/*
				 * AivRevisionHistory aivRevisionHistoryBO = new
				 * AivRevisionHistory();
				 * aivRevisionHistoryBO.setAivId(assetInstanceVersionId); if
				 * (log.isTraceEnabled()) { log.trace(
				 * "deleteAssetInstanceVersions || dao method called : deleteAivRevHistoryByAivId()"
				 * + aivRevisionHistoryBO.toString()); }
				 * 
				 * revisionHistoryDao.deleteAivRevHistoryByAivId(
				 * aivRevisionHistoryBO, conn);
				 */

				// add recent activity

				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setAssetId(String.valueOf(assetId));
				String versionId = String.valueOf(assetInstanceVersionId);
				recentActivity.setAssetInstVersionId(versionId);
				recentActivity.setDescription(user.getFullName() + ";" + action + ";" + assetName + ";" + assetInstName
						+ ";" + "version" + versionName);
				recentActivity.setUser_id(userId);
				recentActivityDao.addRecentActivity(recentActivity, conn);
				if (log.isTraceEnabled()) {
					log.trace("deleteAssetInstanceVersionsHelper || dao method called : addRecentActivity()"
							+ recentActivity.toString());
				}

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersionsHelper || dao method called : deleteAssetInstanceVersions by assetInstanceVersionId ()"
									+ assetInstanceVersionId);
				}

				assetInstanceVersionDao.deleteAssetInstanceVersions(assetInstanceVersionId, conn);

				if (log.isTraceEnabled()) {
					log.trace(
							"deleteAssetInstanceVersionsHelper || dao method called : deleteAssetInstance() by assetInstanceId"
									+ assetInstanceId);
				}

				assetInstanceDao.deleteAssetInstance(assetInstanceId, conn);
				
				// mail template
				if(importFlag == false){
					try {

						List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstanceId, conn);
						MailTemplateDao mailDao = new MailTemplateDao();
						MailTemplateDao mailTemplateDao = new MailTemplateDao();
						MailConfig mailConfig = mailDao.getMailConfig(conn);
						String mailTemp = null;

						if (versionableFlag == 1) {

							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"deleteAssetInstanceVersionForVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%",
									versionName);

						} else {

							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"deleteAssetInstanceVersionForNonVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
						}

						if (emailIds != null) {
							for (String emailId : emailIds) {
								if (versionableFlag == 1) {

									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								} else {

									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));

								}
							}

						}

					} catch (Exception e) {

					}
				}
				
				String outputPath = Constants.UPLOADED_JAR_SUPPORT_FILE_PATH + assetInstanceVersionId + "/";
				File instFile = new File(outputPath);
				if(instFile.exists()) {
					FileUtils.forceDelete(new File(outputPath));
				}
			}

			retMsg = Constants.ASSET_INSTANCE_VERSION_DELETED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			if(importFlag == false){
				conn.commit();
			}
			if (log.isInfoEnabled()) {
				log.info("deleteAssetInstanceVersionsHelper || Asset instance version with AssetInstanceVersionId:"
						+ assetInstanceVersionId + " deleted successfully");
			}
		} catch (RepoproException e) {
			log.error("deleteAssetInstanceVersionsHelper || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				if(importFlag == false){
					conn.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
				throw new RepoproException(e1.getMessage());
			}
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("deleteAssetInstanceVersionsHelper || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				if(importFlag == false){
					conn.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
				throw new RepoproException(e1.getMessage());
			}
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceVersionsHelper || " + Constants.LOG_CONNECTION_CLOSE);
			}
			if(importFlag == false){
				DBConnection.closeDbConnection(conn);
			}
			if(conn1 != null){
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceVersionsHelper || assetInstanceVersionId:" + assetInstanceVersionId + "||End");
		}

		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	public void removeRelationshipDatas(AssetDetailRequest assetDetReq, Long assetInstanceVersionId, String userName,
			Long userId, int versionableFlag, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("removeRelationshipDatas || begin");
		}

		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		RelationshipDao relationshipDao = new RelationshipDao();
		AssetInstanceVersion aiv1 = new AssetInstanceVersion();
		Connection conn1 = null;

		try {

			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("removeRelationshipDatas : " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace(
						"removeRelationshipDatas || called dao method : retRvrRelationsForAnAssetInstanceVersionId() by assetInstanceVersionId : "
								+ assetInstanceVersionId);
			}

			List<AssetInstRelationship> airs = relationshipDao
					.retRvrRelationsForAnAssetInstanceVersionId(assetInstanceVersionId, conn);
			for (AssetInstRelationship air : airs) {
				// For updating relationship data Column in revision history

				if (log.isTraceEnabled()) {
					log.trace(
							"removeRelationshipDatas || called dao method : getAssetInstanceVersionDetails() by assetInstanceVersionId : "
									+ air.getSrcAssetInstVersionId());
				}

				AssetInstanceVersion aiv = assetInstanceVersionDao
						.getAssetInstanceVersionDetails(air.getSrcAssetInstVersionId(), conn);

				aiv1.setVersionName(aiv.getVersionName());
				aiv1.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));

				if (log.isTraceEnabled()) {
					log.trace(
							"removeRelationshipDatas || called dao method : updateAivUpdatedOn() by assetInstanceVersionId : "
									+ assetInstanceVersionId);
				}
				assetInstanceVersionDao.updateAivUpdatedOn(aiv1, aiv.getAssetInstVersionId(), conn);
				String removedText = "";
				if (!(versionableFlag == 1)) {
					removedText = assetDetReq.getAssetType() + "-->" + assetDetReq.getAssetInstName();
				} else {
					removedText = assetDetReq.getAssetType() + "-->" + assetDetReq.getAssetInstName() + "_"
							+ assetDetReq.getVersionName();
				}

				if (log.isTraceEnabled()) {
					log.trace(
							"removeRelationshipDatas || called helper method : removeRelationshipDataInRevHistory() to remove relationship data in aiv revision history ");
				}
				removeRelationshipDataInRevHistory(air.getSrcAssetInstVersionId(), assetInstanceVersionId,
						aiv.getVersionName(), removedText, userName, userId, conn);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("removeRelationshipDatas : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("removeRelationshipDatas || Exit");
		}

	}

	public void removeRelationshipDataInRevHistory(Long SrcAssetInstVersionId, Long destAssetInstVersionId,
			String versionName, String removedText, String userName, Long userId, Connection conn)
					throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("removeRelationshipDataInRevHistory || begin");
		}

		RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
		Connection conn1 = null;

		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("removeRelationshipDataInRevHistory || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			AssetDao assetDao = new AssetDao();
			AssetInstanceManager assetInstanceManager = new AssetInstanceManager();
			AssetInstanceVersion assetInstVersion = new AssetInstanceVersion();
			assetInstVersion.setSrcAssetInstanceVersionId(SrcAssetInstVersionId.toString());
			List<AssetInstance> aivos = assetInstanceManager.retFwdDependents(assetInstVersion, conn);
			String newRelationshipDataForRevision = "";
			int l = 1;
			for (AssetInstance aivo : aivos) {
				if (aivo.getAssetInstVersionId() != destAssetInstVersionId) {
					AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
					if (l == aivos.size()) {
						if (!assetDef.isVersionable()) {
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()
									+ "-->" + aivo.getAssetInstName();
						} else {
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()
									+ "-->" + aivo.getAssetInstName() + "_" + aivo.getVersionName();
						}
					} else {
						if (!assetDef.isVersionable()) {
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()
									+ "-->" + aivo.getAssetInstName() + "&<!!>&";
						} else {
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()
									+ "-->" + aivo.getAssetInstName() + "_" + aivo.getVersionName() + "&<!!>&";
						}
					}
					l++;
				}
			}
			if (log.isTraceEnabled()) {
				log.trace(
						"removeRelationshipDataInRevHistory || called dao method : retAivRevisionHistory() by assetInstanceVersionId : "
								+ SrcAssetInstVersionId);
			}
			List<AivRevisionHistory> aivRevisionHistoryBOs = revisionHistoryDao
					.retAivRevisionHistory(SrcAssetInstVersionId, conn);
			int[] revIdToFindMaxValue = new int[aivRevisionHistoryBOs.size()];
			String revId;
			String lastOverviewData, lastRelationshipData, lastParameterData, lastUsedByData;

			// To set next revision id(revId)
			int i = 0;
			for (AivRevisionHistory aivRevisionHistoryBO : aivRevisionHistoryBOs) {
				String[] revIdLastIndex = aivRevisionHistoryBO.getRevId().split("\\.");
				revIdToFindMaxValue[i] = Integer.parseInt(revIdLastIndex[2]);
				i++;
			}
			int nextRevIdLastIndex = revIdToFindMaxValue[revIdToFindMaxValue.length - 1] + 1;
			revId = versionName + "." + nextRevIdLastIndex;

			// To set last revision data's
			lastOverviewData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getOverviewData();
			/*
			 * lastRelationshipData = aivRevisionHistoryBOs.get(
			 * revIdToFindMaxValue.length - 1).getRelationshipData();
			 */
			lastRelationshipData = newRelationshipDataForRevision;
			lastParameterData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getParameterData();
			lastUsedByData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getUsedBy();
			AivRevisionHistory aivRevHistBo = new AivRevisionHistory();
			aivRevHistBo.setAivId(SrcAssetInstVersionId);
			aivRevHistBo.setRevId(revId);
			aivRevHistBo.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			aivRevHistBo.setChangedKey("R");
			aivRevHistBo.setOverviewData(lastOverviewData);
			aivRevHistBo.setParameterData(lastParameterData);
			aivRevHistBo.setUsedBy(lastUsedByData);
			aivRevHistBo.setUserId(userId);
			List<String> relationshipData = new ArrayList<String>();
			String relationshipStr = "";
			if (lastRelationshipData != null) {
				String temp[] = lastRelationshipData.split(Constants.APPEND_STRING);
				int k = 0; // For first time matching, because same aiv's with
				// different relationships available
				for (int j = 0; j < temp.length; j++) {
					if (temp[j].equalsIgnoreCase(removedText)) {
						if (k != 0) {
							relationshipData.add(temp[j]);
						}
						k++;
					} else {
						relationshipData.add(temp[j]);
					}
				}
				for (String str : relationshipData) {
					if (relationshipStr.isEmpty()) {
						relationshipStr = str;
					} else {
						relationshipStr = relationshipStr + Constants.APPEND_STRING + str;
					}
				}
				if (!relationshipStr.isEmpty()) {
					aivRevHistBo.setRelationshipData(relationshipStr);
				} else {
					aivRevHistBo.setRelationshipData(null);
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("removeRelationshipDataInRevHistory || called dao method : addRevisionData(): "
						+ aivRevHistBo.toString());
			}

			revisionHistoryDao.addRevisionData(aivRevHistBo, conn);

		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("removeRelationshipDataInRevHistory : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("removeRelationshipDataInRevHistory || Exit");
		}
	}

	public void removeDependents(AssetDetailRequest adr, String userName, String userFullName, Long userId,
			Long versionId, Long assetInstanceId, int versionableFlag, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("removeDependents || begin");
		}

		RelationshipDao relationshipDao = new RelationshipDao();
		RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		RecentActivity recentActivity = null;
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		String action = Constants.ACTIVITY_DELETE;
		List<AssetInstanceVersion> aivoList = new ArrayList<AssetInstanceVersion>();
		Boolean doForLoop = false;
		Connection conn1 = null;

		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("removeDependents || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("removeDependents || called dao method : retFwdRelationsForAnAssetInstanceVersionId(): "
						+ versionId);
			}

			List<AssetInstRelationship> airs = relationshipDao.retFwdRelationsForAnAssetInstanceVersionId(versionId,
					conn);

			for (AssetInstRelationship air : airs) {
				// For updating usedBy Column in revision history
				AssetInstanceVersion aiVo = new AssetInstanceVersion();
				String removedText = "";

				if (versionableFlag == 0) {
					removedText = adr.getAssetInstName() + "(" + air.getRelationShipName() + ")";
				} else {
					removedText = adr.getAssetInstName() + "_" + adr.getVersionName() + "(" + air.getRelationShipName()
							+ ")";
				}

				if (log.isTraceEnabled()) {
					log.trace("removeDependents  || called helper method : removeUsedByData()");
				}
				removeUsedByData(air.getVersionName(), air.getDestAssetInstVersionId(), userId, removedText, userName,
						conn);
				// End of For updating usedBy Column in revision history

				if (air.getRelationShipName().equalsIgnoreCase("composition")
						|| air.getRelationShipName().equalsIgnoreCase("aggregation")) {
					// below commented code applicable for if parent child exist
					// assetInstDao.deleteAssetInstance(air.getDestAssetInstVersionId().getAssetInstanceId());

					// To delete revision history record before deleting AIV's

					if (log.isTraceEnabled()) {
						log.trace(
								"removeDependents || called dao method : retAivRevisionHistory() by AssetInstanceVersionId() : "
										+ air.getDestAssetInstVersionId());
					}
					List<AivRevisionHistory> aivRevisionHistoryBOs = revisionHistoryDao
							.retAivRevisionHistory(air.getDestAssetInstVersionId(), conn);
					for (AivRevisionHistory aivRevisionHistoryBO : aivRevisionHistoryBOs) {
						if (log.isTraceEnabled()) {
							log.trace("removeDependents || called dao method : deleteAivRevHistoryByAivId(): "
									+ aivRevisionHistoryBO.toString());
						}

						revisionHistoryDao.deleteAivRevHistoryByAivId(aivRevisionHistoryBO, conn);
					}
					aiVo.setAssetInstVersionId(air.getDestAssetInstVersionId());
					aiVo.setVersionName(air.getVersionName());
					aiVo.setAssetId(air.getAssetId());
					aiVo.setAssetName(air.getAssetName());
					aiVo.setAssetInstName(air.getAssetInstanceName());
					aiVo.setAssetInstanceId(air.getAssetInstanceId());

					aivoList.add(aiVo);
				}
				if (air.getRelationShipName().equalsIgnoreCase("composition")
						|| air.getRelationShipName().equalsIgnoreCase("aggregation")) {
					AssetDetailRequest ad = new AssetDetailRequest();
					ad.setAssetType(air.getAssetName());
					ad.setAssetInstName(air.getAssetInstanceName());
					ad.setVersionName(air.getVersionName());
					doForLoop = true;
					removeDependents(ad, userName, userFullName, userId, air.getDestAssetInstVersionId(),
							air.getAssetInstanceId(), versionableFlag, conn);
				}
			}
			if (doForLoop == true) {
				for (int x = 0; x < aivoList.size(); x++) {
					Long aivId = Long.valueOf(aivoList.get(x).getAssetInstVersionId()).longValue();
					Long aiId = Long.valueOf(aivoList.get(x).getAssetInstanceId()).longValue();
					Long assetId = Long.valueOf(aivoList.get(x).getAssetId()).longValue();
					AssetDetailRequest ad1 = new AssetDetailRequest();
					ad1.setAssetType(aivoList.get(x).getAssetName());
					ad1.setAssetInstName(aivoList.get(x).getAssetInstName());
					ad1.setVersionName(aivoList.get(x).getVersionName());

					if (log.isTraceEnabled()) {
						log.trace(
								"removeDependents || called dao method : getAssetInstanceVersions() by assetInstanceId :"
										+ assetInstanceId);
					}
					List<AssetInstanceVersion> versionVos = assetInstanceVersionDao
							.getAssetInstanceVersions(aivoList.get(x).getAssetInstanceId(), conn);

					if (versionVos.size() > 1) {

						if (log.isTraceEnabled()) {
							log.trace(
									"removeDependents || called dao method : deleteAssetInstanceVersions() by AssetInstanceVersionId: "
											+ aivId);
						}
						assetInstanceVersionDao.deleteAssetInstanceVersions(aivId, conn);

						recentActivity = new RecentActivity();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setAssetId(String.valueOf(assetId));
						recentActivity.setAssetInstVersionId(aivId.toString());
						recentActivity.setDescription(userFullName + ";" + action + ";" + ad1.getAssetType() + ";"
								+ ad1.getAssetInstName() + ";" + "version" + ad1.getVersionName());
						recentActivity.setUser_id(userId);
						recentActivityDao.addRecentActivity(recentActivity, conn);

						if (log.isTraceEnabled()) {
							log.trace("removeDependents || dao method called : addRecentActivity()"
									+ recentActivity.toString());
						}

					} else {
						if (log.isTraceEnabled()) {
							log.trace(
									"removeDependents || called dao method : deleteAssetInstanceVersions() by AssetInstanceVersionId: "
											+ aivId);
						}
						assetInstanceVersionDao.deleteAssetInstanceVersions(aivId, conn);

						recentActivity = new RecentActivity();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setAssetId(String.valueOf(assetId));
						recentActivity.setAssetInstVersionId(aivId.toString());
						recentActivity.setDescription(userFullName + ";" + action + ";" + ad1.getAssetType() + ";"
								+ ad1.getAssetInstName() + ";" + "version" + ad1.getVersionName());
						recentActivity.setUser_id(userId);
						recentActivityDao.addRecentActivity(recentActivity, conn);

						if (log.isTraceEnabled()) {
							log.trace("removeDependents || dao method called : addRecentActivity()"
									+ recentActivity.toString());
						}

						if (log.isTraceEnabled()) {
							log.trace(
									"removeDependents || called dao method : deleteAssetInstance() by AssetInstanceId :"
											+ aiId);
						}
						assetInstanceDao.deleteAssetInstance(aiId, conn);
					}

				}
				doForLoop = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("removeDependents : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("removeDependents || Exit");
		}

	}

	public void removeUsedByData(String versionName, Long versionId, Long userId, String removedText, String userName,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("removeUsedByData || begin");
		}
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
		AssetInstanceVersion aiv = new AssetInstanceVersion();
		Connection conn1 = null;

		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("removeUsedByData || " + Constants.LOG_CONNECTION_OPEN);
				}

				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			aiv.setVersionName(versionName);
			aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));

			if (log.isTraceEnabled()) {
				log.trace("removeUsedByData || called dao method : updateAivUpdatedOn() by AssetInstanceVersionId: "
						+ versionId);
			}
			assetInstanceVersionDao.updateAivUpdatedOn(aiv, versionId, conn);

			if (log.isTraceEnabled()) {
				log.trace(
						"removeUsedByData || called dao method : retAivRevHistoryByAivId() by AssetInstanceVersionId: "
								+ versionId);
			}

			List<AivRevisionHistory> aivRevisionHistoryBOs = revisionHistoryDao.retAivRevHistoryByAivId(versionId,
					conn);
			int[] revIdToFindMaxValue = new int[aivRevisionHistoryBOs.size()];
			String revId;
			String lastOverviewData, lastRelationshipData, lastParameterData, lastUsedByData;

			// To set next revision id(revId)
			int i = 0;
			for (AivRevisionHistory aivRevisionHistoryBO : aivRevisionHistoryBOs) {
				String[] revIdLastIndex = aivRevisionHistoryBO.getRevId().split("\\.");
				revIdToFindMaxValue[i] = Integer.parseInt(revIdLastIndex[2]);
				i++;
			}

			int nextRevIdLastIndex = revIdToFindMaxValue[revIdToFindMaxValue.length - 1] + 1;
			revId = versionName + "." + nextRevIdLastIndex;

			// To set last revision data's
			lastOverviewData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getOverviewData();
			lastRelationshipData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getRelationshipData();
			lastParameterData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getParameterData();
			lastUsedByData = aivRevisionHistoryBOs.get(revIdToFindMaxValue.length - 1).getUsedBy();
			AivRevisionHistory aivRevHistBo = new AivRevisionHistory();
			aivRevHistBo.setAivId(versionId);
			aivRevHistBo.setRevId(revId);
			aivRevHistBo.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			aivRevHistBo.setChangedKey("U");
			aivRevHistBo.setUserId(userId);
			aivRevHistBo.setOverviewData(lastOverviewData);
			aivRevHistBo.setRelationshipData(lastRelationshipData);
			aivRevHistBo.setParameterData(lastParameterData);

			List<String> usedByData = new ArrayList<String>();
			String usedByStr = "";
			if (lastUsedByData != null) {
				String temp[] = lastUsedByData.split(Constants.APPEND_STRING);
				for (int j = 0; j < temp.length; j++) {
					if (!temp[j].equalsIgnoreCase(removedText)) {
						usedByData.add(temp[j]);
					}
				}
				for (String str : usedByData) {
					if (usedByStr.isEmpty()) {
						usedByStr = str;
					} else {
						usedByStr = usedByStr + Constants.APPEND_STRING + str;
					}
				}
				if (!usedByStr.isEmpty()) {
					aivRevHistBo.setUsedBy(usedByStr);
				} else {
					aivRevHistBo.setUsedBy(null);
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("removeUsedByData || called dao method : addRevisionData() : " + aivRevHistBo.toString());
			}
			revisionHistoryDao.addRevisionData(aivRevHistBo, conn);

		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("removeUsedByData : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("removeUsedByData || Exit");
		}

	}

	/**
	 * @method getChildNamesForAssetInstance
	 * @description to get child names for asset instance name
	 * @param assetInstVersionId
	 *            , assetId
	 * @return success response
	 * @throws RepoproException
	 */

	@GET
	@Path("/getChildNamesForAssetInstance")
	public Response getChildNamesForAssetInstance(@QueryParam("assetId") long assetId,
			@QueryParam("assetInstVersionId") long assetInstVersionId) {

		if (log.isTraceEnabled()) {
			log.trace("getChildNamesForAssetInstance || begin  with assetId : " + assetId + "and assetInstVersionId :"
					+ assetInstVersionId);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		RelationshipDao relationshipDao = new RelationshipDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		Connection conn = null;
		List<AssetInstanceVersion> childInstNameList = new ArrayList<AssetInstanceVersion>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getChildNamesForAssetInstance || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace(
						"getChildNamesForAssetInstance || dao method called : getAssetInstanceVersionDetails by assetInstVersionId: "
								+ assetInstVersionId);
			}
			
			boolean srcFlag = false;
			List<AssetRelationshipDef> ardForSrcAsset = relationshipDao.retAssetRelationshipDefBySrcAssetId(assetId,conn);
			for(AssetRelationshipDef ard :ardForSrcAsset ){
				if(ard.getFwdRelId() == 1L || ard.getFwdRelId() == 5L){
					srcFlag = true;
					break;
				}
			}
			
			if(srcFlag){//to get child names only when the asset has comp/aggre type relationship
				childInstNameList = assetInstanceVersionDao.getChildNamesForAssetInstance(assetId, assetInstVersionId,
						conn);
			}
			

			conn.commit();
			if (log.isDebugEnabled()) {
				log.debug(" getChildNamesForAssetInstance  || retrieved " + childInstNameList.size()
						+ " child asset instance name  by version id : " + assetInstVersionId + "and asset id"
						+ assetId);
			}
            if(!childInstNameList.isEmpty()){
			retStat = Status.OK;
			retMsg = Constants.CHILD_NAMES_FOR_ASSET_INSTANCE_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
            }else{
            	retStat = Status.OK;
    			retMsg = Constants.NO_CHILD_ASSET_INSTANCE_NAME_AVAILABLE;
    			retScsFlr = Constants.SUCCESS;
    			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
            }

		} catch (RepoproException e) {
			log.error("getChildNamesForAssetInstance || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getChildNamesForAssetInstance || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getChildNamesForAssetInstance || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(childInstNameList)))
				.build();

	}

	/**
	 * @method : viewGroupsWithSingleAIAccess
	 * @param userName
	 * @param aivId
	 * @return
	 */
	@GET
	@Path("/viewGroupsWithSingleAIAccess")
	public Response viewGroupsWithSingleAIAccess(@QueryParam("userName") String userName,
			@QueryParam("aivId") Long aivId) {

		if (log.isTraceEnabled()) {
			log.trace("viewGroupsWithSingleAIAccess || Begin with userName : " + userName + "\t aivId : " + aivId);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<GroupAssetAccess> aivGroupAccessList = new ArrayList<GroupAssetAccess>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("viewGroupsWithSingleAIAccess || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
			GroupDao groupDao = new GroupDao();

			if (log.isTraceEnabled()) {
				log.trace("viewGroupsWithSingleAIAccess || dao method called : retGroupsWithAIVersionAccess()");
			}
			List<GroupAssetAccess> retGroupsWithAIVersionAccess = dao.retGroupsWithAIVersionAccess(userName, aivId,
					conn);

			if (log.isTraceEnabled()) {
				log.trace("viewGroupsWithSingleAIAccess || dao method called : getAllGroups()");
			}
			List<GroupDetails> allGroups = groupDao.getAllGroups(conn);

			for (GroupDetails groupBo : allGroups) {
				if (!groupBo.getGroupName().equalsIgnoreCase("group-admin")
						&& !groupBo.getGroupName().equalsIgnoreCase("Guest")) {

					GroupAssetAccess aivga = new GroupAssetAccess();
					aivga.setGroupId(groupBo.getGroupId());
					aivga.setGroupName(groupBo.getGroupName());
					aivga.setMappedWithAI(false);
					aivga.setEditAccess((long) 0);
					aivga.setViewAccess((long) 0);
					aivga.setDeleteAccess((long) 0);

					if (!retGroupsWithAIVersionAccess.isEmpty()) {
						for (GroupAssetAccess groupAssetInstAccess : retGroupsWithAIVersionAccess) {
							if (groupAssetInstAccess.getGroupId().equals(groupBo.getGroupId())) {
								aivga.setMappedWithAI(true);

								if (groupAssetInstAccess.getEditAccess() == 1) {
									aivga.setEditAccess((long) 1);
								}

								if (groupAssetInstAccess.getViewAccess() == 1) {
									aivga.setViewAccess((long) 1);
								}

								if (groupAssetInstAccess.getDeleteAccess() == 1) {
									aivga.setDeleteAccess((long) 1);
								}
							}
						}
					}

					boolean flagForGroupExistsinList = false;
					for (int i = 0; i < aivGroupAccessList.size(); i++) {
						if (aivGroupAccessList.get(i).getGroupId().equals(aivga.getGroupId())) {
							flagForGroupExistsinList = true;
						}
					}

					if (flagForGroupExistsinList == false) {
						aivGroupAccessList.add(aivga);
					}

				}
			}

			retMsg = Constants.GROUP_ACCESS_ASSET_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("viewGroupsWithSingleAIAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("viewGroupsWithSingleAIAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("viewGroupsWithSingleAIAccess || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(aivGroupAccessList)))
				.build();
	}

	/**
	 * @method : saveGroupsAccessSingleAISubmit
	 * @param gaa
	 * @return
	 */
	@PUT
	@Path("/saveGroupsAccessSingleAISubmit")
	public Response saveGroupsAccessSingleAISubmit(List<GroupAssetAccess> gaa) {

		if (log.isTraceEnabled()) {
			log.trace("saveGroupsAccessSingleAISubmit || Begin " + gaa.toString());
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<GroupAssetAccess> groupAccessList = new ArrayList<GroupAssetAccess>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("saveGroupsAccessSingleAISubmit || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();

			if (log.isTraceEnabled()) {
				log.trace("saveGroupsAccessSingleAISubmit || dao method called : deleteGroupsAccessAISubmit()");
			}
			dao.deleteGroupsAccessAISubmit(gaa, conn);

			if (log.isTraceEnabled()) {
				log.trace("saveGroupsAccessSingleAISubmit || dao method called : addGroupsAccessAISubmit()");
			}

			retMsg = Constants.GROUP_ACCESS_SAVED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

			conn.commit();

			log.info("saveGroupsAccessSingleAISubmit || group access saved");

		} catch (RepoproException e) {
			log.error("saveGroupsAccessSingleAISubmit || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("saveGroupsAccessSingleAISubmit || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("saveGroupsAccessSingleAISubmit || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("saveGroupsAccessSingleAISubmit || end");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(groupAccessList))).build();
	}

	/**
	 * @method : retTaxonomyIdByAssetInstVersionId
	 * @param aivId
	 * @return
	 */
	@GET
	@Path("/retTaxonomyIdByAssetInstVersionId")
	public Response retTaxonomyIdByAssetInstVersionId(@QueryParam("aivId") Long aivId) {

		if (log.isTraceEnabled()) {
			log.trace("retTaxonomyIdByAssetInstVersionId || Begin with aivId : " + aivId);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<AssetInstanceVersionTaxonomy> aivTaxonomyList = new ArrayList<AssetInstanceVersionTaxonomy>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retTaxonomyIdByAssetInstVersionId || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();

			if (log.isTraceEnabled()) {
				log.trace(
						"retTaxonomyIdByAssetInstVersionId || call of dao retTaxonomyIdByAssetInstVersionId method to get TaxonomyId By AssetInstVersionId ");
			}
			aivTaxonomyList = dao.retTaxonomyIdByAssetInstVersionId(aivId, conn);

			retMsg = Constants.TAXONOMIES_BY_AIV_ID_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			log.info("retTaxonomyIdByAssetInstVersionId || taxonomies by asset instance version id fetched");

		} catch (RepoproException e) {
			log.error("retTaxonomyIdByAssetInstVersionId || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("retTaxonomyIdByAssetInstVersionId || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retTaxonomyIdByAssetInstVersionId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retTaxonomyIdByAssetInstVersionId || end");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(aivTaxonomyList))).build();
	}

	/**
	 * @method retAssignedRelationship
	 * @description to get assigned relationships
	 * @param aivId
	 * @return success response
	 */
	@GET
	@Path("/retAssignedRelationship")
	public Response retAssignedRelationship(@QueryParam("aivId") Long aivId) {

		if (log.isTraceEnabled()) {
			log.trace("retAssignedRelationship || Begin with aivId : " + aivId);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetInstRelationship> assetInstRelationshipList = new ArrayList<AssetInstRelationship>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retAssignedRelationship || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace(
						"retAssignedRelationship || call of dao retFwdRelationsForAnAssetInstanceVersionId method to get assigned relations");
			}
			assetInstRelationshipList = relationshipDao.retFwdRelationsForAnAssetInstanceVersionId(aivId, conn);

			if (!assetInstRelationshipList.isEmpty()) {
				retMsg = Constants.RELATIONSHIPS_BY_AIV_ID_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.NO_RELATIONSHIP_DATA_PROVIDED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			log.info("retAssignedRelationship || relationships by asset instance version id fetched");

		} catch (RepoproException e) {
			log.error("retAssignedRelationship || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("retAssignedRelationship || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retAssignedRelationship || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retAssignedRelationship || end");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(assetInstRelationshipList)))
				.build();
	}

	/**
	 * @method retAvailableAssetRelationship
	 * @param srcAssetId
	 * @param destAssetId
	 * @param srcAssetInstId
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/retAvailableAssetRelationship")
	public Response retAvailableAssetRelationship(@QueryParam("srcAssetId") Long srcAssetId,
			@QueryParam("destAssetId") Long destAssetId, @QueryParam("srcAssetInstId") Long srcAssetInstId,
			@QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("retAvailableAssetRelationship || Begin with srcAssetId : " + srcAssetId + " destAssetId :"
					+ destAssetId + "srcAssetInstId:" + srcAssetInstId + " userName:" + userName);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetInstRelationship> assetInstRelationshipList = new ArrayList<AssetInstRelationship>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retAvailableAssetRelationship || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace(
						"retAvailableAssetRelationship || call of dao retFwdRelationsForAnAssetInstanceVersionId method to get available asset relations");
			}
			assetInstRelationshipList = relationshipDao.retAvailableAssetRelationship(srcAssetId, destAssetId,
					srcAssetInstId, userName, conn);

			if (!assetInstRelationshipList.isEmpty()) {
				retMsg = Constants.RELATIONSHIPS_BY_ASSET_ID_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.NO_RELATIONSHIP_DATA_PROVIDED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}

			log.info("retAvailableAssetRelationship || relationships by asset id fetched");

		} catch (RepoproException e) {
			log.error("retAvailableAssetRelationship || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("retAvailableAssetRelationship || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retAvailableAssetRelationship || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retAvailableAssetRelationship || End with srcAssetId : " + srcAssetId + " destAssetId :"
					+ destAssetId + "srcAssetInstId:" + srcAssetInstId + " userName:" + userName);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(assetInstRelationshipList)))
				.build();
	}

	/**
	 * @method retDestAssetsForSrcAsset
	 * @param srcAssetId
	 * @param destAssetId
	 * @param srcAssetInstId
	 * @param userName
	 * @return
	 * @throws RepoproException
	 */
	@GET
	@Encoded
	@Path("/retDestAssetsForSrcAsset")
	public Response retDestAssetsForSrcAsset(@QueryParam("srcAssetName") String srcAssetName) {

		if (log.isTraceEnabled()) {
			log.trace("retDestAssetsForSrcAsset || Begin with srcAssetName : " + srcAssetName);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetRelationshipDef> assetRelationshipDefList = new ArrayList<AssetRelationshipDef>();
		List<AssetDef> assetNamesList = new ArrayList<AssetDef>();
		List<AssetDef> finalAssetNamesList = new ArrayList<AssetDef>();
		try {
			srcAssetName = URLDecoder.decode(srcAssetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("retDestAssetsForSrcAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace(
						"retDestAssetsForSrcAsset || call of dao getAllAssetRelationshipDef method to get available asset relations");
			}
			assetRelationshipDefList = relationshipDao.getAllAssetRelationshipDef(conn);

			for (AssetRelationshipDef assetRelationshipDef : assetRelationshipDefList) {
				// To get only mathched assets with given asset
				if (assetRelationshipDef.getSrcAssetName().equals(srcAssetName)) {
					if (!assetNamesList.contains(assetRelationshipDef.getDestAssetName())) {
						if (assetRelationshipDef.getFwdRelationType().equalsIgnoreCase("composition")
								|| assetRelationshipDef.getFwdRelationType().equalsIgnoreCase("aggregation")) {
							continue;
						} else {
							AssetDef assetNames = new AssetDef();
							assetNames.setAssetName(assetRelationshipDef.getDestAssetName());
							assetNames.setAssetId(assetRelationshipDef.getDestAssetId());
							assetNamesList.add(assetNames);
						}
					}
				}
			}
			AssetInstanceDao assetInstaceDao = new AssetInstanceDao();
			AssetDef asset = null;
			for (AssetDef assetdata : assetNamesList) {
				AssetDef assetData = assetInstaceDao.retAssetDetail(assetdata.getAssetName(), conn);
				asset = new AssetDef();
				asset.setAssetName(assetData.getAssetName());
				asset.setAssetId(assetData.getAssetId());
				asset.setVersionable(assetData.isVersionable());
				finalAssetNamesList.add(asset);
			}
			if (!finalAssetNamesList.isEmpty()) {
				retMsg = Constants.ALL_ASSETS_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			log.info("retDestAssetsForSrcAsset || destination assets for src asset fetched");

		} catch (RepoproException e) {
			log.error("retDestAssetsForSrcAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("retDestAssetsForSrcAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retAvailableAssetRelationship || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retDestAssetsForSrcAsset || End with srcAssetName : " + srcAssetName);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(finalAssetNamesList)))
				.build();
	}

	/**
	 * @method retAivAccessRights
	 * @param AivId
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/retAivAccessRights")
	public Response retAivAccessRights(@QueryParam("AivId") Long AivId, @QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("retAivAccessRights || Begin with AivId : " + AivId + " username:" + userName);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		GroupAssetInstVersionAccess groupAssetInstVersionAccess = new GroupAssetInstVersionAccess();
		List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		List<GroupAssetInstVersionAccess> groupAssetInstVersion = new ArrayList<GroupAssetInstVersionAccess>();
		boolean editFlag = false;
		boolean deleteFlag = false;
		boolean viewFlag = false;
		boolean adminFlag = false;

		try {
			if (log.isTraceEnabled()) {
				log.trace("retAivAccessRights || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("retAivAccessRights || call of dao retAivAccessRights method to get aiv access right");
			}
			
			List<AssetInstanceVersion> versionList = new ArrayList<AssetInstanceVersion>();
			
			AssetInstanceVersion assetInstanceVersionDetails = assetInstanceVersionDao.getAssetInstanceVersionDetails(AivId,conn);
			long assetInstId = assetInstanceVersionDetails.getAssetInstanceId();
			versionList = assetInstanceVersionDao.getAssetInstanceVersions(assetInstId, conn);
			
			boolean delFlag = true;
			for(AssetInstanceVersion versionName:versionList){
				long assetInstVersionId = versionName.getAssetInstVersionId();
				groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if(assetInstVersionId == AivId) {
						if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
							groupAssetInstVersionAccess.setEditFlag(true);
							editFlag = true;
						}
					}
					//if (groupAssetInstVersionAccessList.get(i).getDeleteAccess().equals(1L)) {
						boolean varFlag;
						if(groupAssetInstVersionAccessList.get(i).getDeleteAccess().equals(1L)){
							varFlag = true;
						}else{
							varFlag = false;
						}
						delFlag = delFlag && varFlag;
						groupAssetInstVersionAccess.setDeleteFlag(delFlag);
						/*deleteFlag = true;
						accessCount++;*/
					//}
					if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
						groupAssetInstVersionAccess.setViewFlag(true);
						viewFlag = true;
					}
					if (groupAssetInstVersionAccessList.get(i).getAdminAccess().equals(1L)) {
						groupAssetInstVersionAccess.setAdminFlag(true);
						adminFlag = true;
					}
					if (editFlag == true && deleteFlag == true && viewFlag == true) {
						break;
					}
				}
			}
			
			
			
			/*groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(AivId, userName, conn);
			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
					groupAssetInstVersionAccess.setEditFlag(true);
					editFlag = true;
				}
				if (groupAssetInstVersionAccessList.get(i).getDeleteAccess().equals(1L)) {
					groupAssetInstVersionAccess.setDeleteFlag(true);
					deleteFlag = true;
					accessCount++;
				}
				if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
					groupAssetInstVersionAccess.setViewFlag(true);
					viewFlag = true;
				}
				if (groupAssetInstVersionAccessList.get(i).getAdminAccess().equals(1L)) {
					groupAssetInstVersionAccess.setAdminFlag(true);
					adminFlag = true;
				}
				if (editFlag == true && deleteFlag == true && viewFlag == true) {
					break;
				}
			}*/

			groupAssetInstVersion.add(groupAssetInstVersionAccess);

			if (!groupAssetInstVersionAccessList.isEmpty()) {
				retMsg = Constants.GROUP_ACCESS_ASSETINSTANCE_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.GROUP_ACCESS_ASSETINSTANCE_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}

			log.info("retAivAccessRights || access flags are set successfully");

		} catch (RepoproException e) {
			log.error("retAivAccessRights || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("retAivAccessRights || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retAivAccessRights || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retAivAccessRights || end with AivId : " + AivId + " username:" + userName);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(groupAssetInstVersion)))
				.build();
	}

	/**
	 * @method updateAssetInstancePropertiesDetails
	 * @description to update asset instance properties details
	 * @param userName,assetInstanceVersionId,assetName
	 * @return success Response
	 * @throws RepoproException
	 */
	@POST
	@Encoded
	@Path("/updateAssetInstancePropertiesDetails")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	public Response updateAssetInstancePropertiesDetails(@FormDataParam("hiddenQueryParamValue") String queryParamValue,
			@FormDataParam("hiddenFormDataValue") String formDataValue,FormDataMultiPart bodyParts,
			@Context ServletContext context) {
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceVersion aiv = null;
		List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstancePropertiesDetails : "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			String newFileNameForImageOnly = "";
			String jsonStr1 = formDataValue;
			JSONObject obj1 = new JSONObject(jsonStr1);
			String aivList = obj1.get("aivList").toString();
			JSONArray aivListArray = new JSONArray(aivList);
			for (int i = 0; i < aivListArray.length(); i++) {
				Iterator itr = aivListArray.getJSONObject(i).keys();
				while (itr.hasNext()) {
					aiv = new AssetInstanceVersion();
					Object keyName = itr.next();

					aiv.setAsset_category_name(aivListArray.getJSONObject(i).get("asset_category_name").toString());
					aiv.setAssetParamId(aivListArray.getJSONObject(i).getLong("assetParamId"));
					aiv.setAssetParamName(aivListArray.getJSONObject(i).get("assetParamName").toString());
					aiv.setIsStatic(aivListArray.getJSONObject(i).getInt("isStatic"));
					aiv.setParamTypeId(aivListArray.getJSONObject(i).getLong("paramTypeId"));

					if (aiv.getParamTypeId() == 3) {
						newFileNameForImageOnly = aivListArray.getJSONObject(i).get("newFileName").toString();
						if(!aivListArray.getJSONObject(i).get("fileName").toString().isEmpty() && !newFileNameForImageOnly.isEmpty()){
							aiv.setFileName(newFileNameForImageOnly);
						} else if(!newFileNameForImageOnly.isEmpty()){
							aiv.setFileName(newFileNameForImageOnly);
						} else {
							aiv.setFileName(aivListArray.getJSONObject(i).get("fileName").toString());
						}
					} else if(aiv.getParamTypeId() == 7){
						aiv.setHasArray(aivListArray.getJSONObject(i).getInt("isArray"));
						if(aiv.getHasArray() == 1){
							JSONObject richTextdataJsonObject = aivListArray.getJSONObject(i).getJSONObject("rich_text_data");
							JSONArray withTagArray = null;
							JSONArray withoutTagArray = null;
							if(richTextdataJsonObject.has("without_tag")){
								withoutTagArray = richTextdataJsonObject.getJSONArray("without_tag");
							}
							if(richTextdataJsonObject.has("with_tag")){
								withTagArray = richTextdataJsonObject.getJSONArray("with_tag");
							}
							if(withTagArray != null){
								List<String> withTags = new ArrayList<String>();
								for(int j=0;j<withTagArray.length();j++){
									String textString = withTagArray.getJSONObject(j).get("textField").toString();
									withTags.add(URLDecoder.decode(textString, "UTF-8"));
								}
								aiv.setRTFwithTags(withTags);
								// for adding revision history
								String textdata = String.join("~~", aiv.getRTFwithTags());
								aiv.setParamValue(textdata);
							}
							if(withoutTagArray != null){
								List<String> withoutTags = new ArrayList<String>();
								for(int k=0;k<withoutTagArray.length();k++){
									String textString = withoutTagArray.getJSONObject(k).get("textField").toString();
									withoutTags.add(URLDecoder.decode(textString, "UTF-8"));
								}
								aiv.setRTFwithOutTags(withoutTags);
							}
						}else{
							JSONObject richTextdataJsonObject = aivListArray.getJSONObject(i).getJSONObject("rich_text_data");
							String withTagArray = null;
							String withoutTagArray = null;
							if(richTextdataJsonObject.has("without_tag")){
								withoutTagArray = richTextdataJsonObject.get("without_tag").toString();
							}
							if(richTextdataJsonObject.has("with_tag")){
								withTagArray = richTextdataJsonObject.get("with_tag").toString();
							}
							aiv.setRTFPlainText(URLDecoder.decode(withoutTagArray, "UTF-8"));
							aiv.setParamValue(URLDecoder.decode(withTagArray, "UTF-8"));
						}
					} else if (aiv.getParamTypeId() == 1){
						if(aiv.getIsStatic() == 1){
							String encodeval = URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(), "UTF-8");
							aiv.setParamValue(encodeval);

						}else{
							aiv.setHasArray(aivListArray.getJSONObject(i).getInt("isArray"));
							if(aiv.getHasArray() == 1){
								JSONArray textdataJsonArray = aivListArray.getJSONObject(i).getJSONArray("text_data");
								List<String> textDataList = new ArrayList<String>();
								for(int ii=0;ii<textdataJsonArray.length();ii++){
									String encodeval = URLDecoder.decode(textdataJsonArray.getString(ii), "UTF-8");
									textDataList.add(encodeval);
								}
								aiv.setTextDataList(textDataList);
								// for adding revision history
								String textdata = String.join("~~", aiv.getTextDataList());
								aiv.setParamValue(textdata);
							}else{
								String encodeval = URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(), "UTF-8");
								aiv.setParamValue(encodeval);
							}
						}
					}
					else {
						aiv.setParamValue(URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(), "UTF-8"));
					}
					ListOfAssetInstanceProperties.add(aiv);
					break;
				}
			}

			Response response = updatePropertiesHelper(queryParamValue, ListOfAssetInstanceProperties, bodyParts, context, false, conn);
			return response;

		} catch (RepoproException e) {
			log.error("updateAssetInstancePropertiesDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("updateAssetInstancePropertiesDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstancePropertiesDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			if(conn != null){
				DBConnection.closeDbConnection(conn);
			}
		}

		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstancePropertiesDetails || end ");
		}
		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	public Response updatePropertiesHelper(String queryParamValue ,List<AssetInstanceVersion> ListOfAssetInstanceProperties,FormDataMultiPart bodyParts,ServletContext context,Boolean commitFlag,Connection conn)throws RepoproException{
		AssetInstanceVersion aiv = null;
		//List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();*/
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<String> jsontRevisionString = new ArrayList<String>();
		UserDao userDao = new UserDao();
		User user = null;
		Connection conn1 = null;
		//System.out.println("formDataValue>>>"+formDataValue);
		try {
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			//String newFileNameForImageOnly = "";
			String jsonStr = queryParamValue;
			JSONObject obj = new JSONObject(jsonStr);
			Long aivId = obj.getLong("assetInstanceVersionId");
			Long userId = obj.getLong("userId");
			int activeFlag = obj.getInt("activeFlag");
			String assetName = obj.get("assetName").toString();
			String userName = obj.get("userName").toString();
			/*String jsonStr1 = formDataValue;
			JSONObject obj1 = new JSONObject(jsonStr1);*/
			/*String aivList = obj1.get("aivList").toString();
			JSONArray aivListArray = new JSONArray(aivList);
			for (int i = 0; i < aivListArray.length(); i++) {
				Iterator itr = aivListArray.getJSONObject(i).keys();
				while (itr.hasNext()) {
					aiv = new AssetInstanceVersion();
					Object keyName = itr.next();

					aiv.setAsset_category_name(aivListArray.getJSONObject(i).get("asset_category_name").toString());
					aiv.setAssetParamId(aivListArray.getJSONObject(i).getLong("assetParamId"));
					aiv.setAssetParamName(aivListArray.getJSONObject(i).get("assetParamName").toString());
					aiv.setIsStatic(aivListArray.getJSONObject(i).getInt("isStatic"));
					aiv.setParamTypeId(aivListArray.getJSONObject(i).getLong("paramTypeId"));
					
					if (aiv.getParamTypeId() == 3) {
						newFileNameForImageOnly = aivListArray.getJSONObject(i).get("newFileName").toString();
						//System.out.println("img"+aivListArray.getJSONObject(i).get("fileName").toString());
						//System.out.println("newFileNameForImageOnly::" +newFileNameForImageOnly);
						if(!aivListArray.getJSONObject(i).get("fileName").toString().isEmpty() && !newFileNameForImageOnly.isEmpty()){
							aiv.setFileName(newFileNameForImageOnly);
						} else if(!newFileNameForImageOnly.isEmpty()){
							aiv.setFileName(newFileNameForImageOnly);
						} else {
							aiv.setFileName(aivListArray.getJSONObject(i).get("fileName").toString());
						}
						
						
					} else if(aiv.getParamTypeId() == 7){
						aiv.setHasArray(aivListArray.getJSONObject(i).getInt("isArray"));
						if(aiv.getHasArray() == 1){
						JSONObject richTextdataJsonObject = aivListArray.getJSONObject(i).getJSONObject("rich_text_data");
						JSONArray withTagArray = null;
						JSONArray withoutTagArray = null;
						if(richTextdataJsonObject.has("without_tag")){
							withoutTagArray = richTextdataJsonObject.getJSONArray("without_tag");
						}
						if(richTextdataJsonObject.has("with_tag")){
							withTagArray = richTextdataJsonObject.getJSONArray("with_tag");
						}
						
						if(withTagArray != null){
							List<String> withTags = new ArrayList<String>();
							for(int j=0;j<withTagArray.length();j++){
								String textString = withTagArray.getJSONObject(j).get("textField").toString();
								
								withTags.add(URLDecoder.decode(textString, "UTF-8"));
							}
							aiv.setRTFwithTags(withTags);
							// for adding revision history
							String textdata = String.join("~~", aiv.getRTFwithTags());
							aiv.setParamValue(textdata);
						}
						
						if(withoutTagArray != null){
							List<String> withoutTags = new ArrayList<String>();
							for(int k=0;k<withoutTagArray.length();k++){
								String textString = withoutTagArray.getJSONObject(k).get("textField").toString();
								withoutTags.add(URLDecoder.decode(textString, "UTF-8"));
							}
							aiv.setRTFwithOutTags(withoutTags);
							
						}
						}else{

							JSONObject richTextdataJsonObject = aivListArray.getJSONObject(i).getJSONObject("rich_text_data");
							String withTagArray = null;
							String withoutTagArray = null;
							if(richTextdataJsonObject.has("without_tag")){
								withoutTagArray = richTextdataJsonObject.get("without_tag").toString();
							}
							if(richTextdataJsonObject.has("with_tag")){
								withTagArray = richTextdataJsonObject.get("with_tag").toString();
							}
								aiv.setRTFPlainText(URLDecoder.decode(withoutTagArray, "UTF-8"));
								aiv.setParamValue(URLDecoder.decode(withTagArray, "UTF-8"));
							}
					} else if (aiv.getParamTypeId() == 1){
						
						if(aiv.getIsStatic() == 1){
							String encodeval = URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(), "UTF-8");
							aiv.setParamValue(encodeval);
						
						}else{
							aiv.setHasArray(aivListArray.getJSONObject(i).getInt("isArray"));
							if(aiv.getHasArray() == 1){
								JSONArray textdataJsonArray = aivListArray.getJSONObject(i).getJSONArray("text_data");
								List<String> textDataList = new ArrayList<String>();
								for(int ii=0;ii<textdataJsonArray.length();ii++){
									String encodeval = URLDecoder.decode(textdataJsonArray.getString(ii), "UTF-8");
									textDataList.add(encodeval);
								}
								aiv.setTextDataList(textDataList);
								// for adding revision history
								String textdata = String.join("~~", aiv.getTextDataList());
								aiv.setParamValue(textdata);
							}else{
								String encodeval = URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(), "UTF-8");
								aiv.setParamValue(encodeval);
							}
					}
					}
					
					else {
						aiv.setParamValue(aivListArray.getJSONObject(i).get("paramValue").toString());
					}
					
					ListOfAssetInstanceProperties.add(aiv);
					break;

				}
			}*/

			if (ListOfAssetInstanceProperties.isEmpty()) {
				log.warn("updateAssetInstancePropertiesDetails || version data  not provided to update");
				return Response.status(Status.BAD_REQUEST).entity(new MyModel(Constants.STATUS_FAILURE,
						Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_REQUEST))).build();
			} else {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstancePropertiesDetails || " + ListOfAssetInstanceProperties.toString()
							+ " Begin with assetInstanceVersionId" + aivId + "assetName" + assetName + "userName "
							+ userName);

				}

				AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
				SubscriptionDao subscriptionDao = new SubscriptionDao();
				RecentActivityDao recentActivityDao = new RecentActivityDao();
				GamificationDao gamificationDao = new GamificationDao();
				String action = Constants.ACTIVITY_MODIFY;
				AssetInstanceVersion aiv1 = new AssetInstanceVersion();
				String newParamDataForRevision = "";
				String fileText = "";
				AssetDao assetDao = new AssetDao();
				GamificationDetails gamePoint = new GamificationDetails();
				int countForParam = 1;
				int paramCount = 0;
				paramCount = paramCount + ListOfAssetInstanceProperties.size();
				NameValue paramValue = new NameValue();
				ParameterValues pv = new ParameterValues();

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstancePropertiesDetails || " + Constants.LOG_CONNECTION_OPEN);
				}

				/*conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
*/
				user = userDao.retProfileForUserName(userName, conn);

				if (log.isTraceEnabled()) {
					log.trace(
							"updateAssetInstancePropertiesDetails || called dao method : getAssetInstanceVersionDetails() by : assetInstanceVersionId "
									+ aivId);
				}
				aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(aivId, conn);
				for (AssetInstanceVersion param : ListOfAssetInstanceProperties) {

					//edit category access check
					if(!userName.equalsIgnoreCase("admin")){
						AssetParamDef paramCheck = assetDao.getParamIdForAssetAndParamName(assetName,param.getAssetParamName(),conn);
						List<GroupDetails> gd = assetDao.getAssetCategoryEditAccessForPropertiesAivPage(userName,paramCheck.getAssetCategoryId(), conn);
						   for(GroupDetails gd1 : gd){
							   if(gd1.getEditAccess() == 1L){
								   param.setEditAccessFlag(true);	
								   break;
							   }
						   }
						if(param.isEditAccessFlag() == false){
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.FAILURE;
							retStatScsFlr = Constants.FORBIDDEN;
							log.trace("updateAssetInstancePropertiesDetails || End");
							return Response
									.status(retStat)
									.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					}
					
					param.setAssetName(assetName);
					param.setAssetInstVersionId(aivId);
					Boolean flag = false;
					String NewFileName = null;
					String oldFileName = null;

					/*if(param.getParamTypeId() != 1 &&  param.getParamTypeId() != 7 ){
						if (param.getParamValue() != null) {
							//param.setParamValue(URLDecoder.decode(param.getParamValue(), "UTF-8"));
						}
					}*/
					
					if (param.getParamTypeId() == (Constants.FILE_TYPE)) {
						FormDataBodyPart dataMultiPart = null;

						if (bodyParts != null) {

							dataMultiPart = bodyParts.getField("uploadedFile_" + param.getAssetParamId());
							paramValue.setFileName(param.getFileName());
							
							if(dataMultiPart != null){
							NewFileName = dataMultiPart.getContentDisposition().getFileName();

							paramValue.setImage(dataMultiPart.getEntityAs(InputStream.class));
							//paramValue.setFileName(dataMultiPart.getContentDisposition().getFileName());
							paramValue.setFileName(param.getFileName());
							
							paramValue.setFileMimeType(new MimetypesFileTypeMap().getContentType(dataMultiPart.getContentDisposition().getFileName()));
							
							} 
						}

						if(NewFileName != null){
							if (NewFileName.length() == 0) {
								oldFileName = param.getFileName();
							} else {
								oldFileName = NewFileName;
							}
						}else{
							oldFileName = param.getFileName();
						}
						param.setNewFileName(paramValue.getFileName());

						if (!userName.equals("admin") && activeFlag == 1) {

							if (log.isTraceEnabled()) {
								log.trace(
										"updateAssetInstancePropertiesDetails || called dao method : getParameterForAssetInstParamAndVersionId() by : assetInstanceVersionId "
												+ aivId + "and AssetParamName " + param.getAssetParamName());
							}
							pv = assetDao.getParameterForAssetInstParamAndVersionId(param.getAssetParamName(), aivId,
									conn);

							if (pv != null) {
								if (pv.getFileName() != null && oldFileName.length() != 0) {
									if (!pv.getFileName().equals(oldFileName) && (pv.isImportant() == true)) {

										flag = true;
										gamePoint.setField("Parameter - " + param.getAssetParamName());
										gamePoint.setAction("Updated");

									}
								}
							} else {

								if (log.isTraceEnabled()) {
									log.trace(
											"updateAssetInstancePropertiesDetails || called dao method : getParamIdForAssetAndParamName() by : assetName "
													+ assetName + "and AssetParamName " + param.getAssetParamName());
								}

								AssetParamDef apd = assetDao.getParamIdForAssetAndParamName(assetName,
										param.getAssetParamName(), conn);

								if (oldFileName.length() != 0 && apd.isHasImportantValue() == true) {

									flag = true;
									gamePoint.setField("Parameter - " + param.getAssetParamName());
									gamePoint.setAction("Created");

								}
							}
						}
						
						if(NewFileName != null){
							if (!NewFileName.isEmpty() || NewFileName.length() != 0) {

								fileText = paramValue.getFileName();

							} else if (param.getFileName() != null
									/* || !param.getFileName().isEmpty() */) {
								fileText = param.getFileName();
							} else {
								fileText = " ";
							}

						} else {
							fileText = paramValue.getFileName();
						}
						if (countForParam == paramCount) {
							if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
								newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
										+ fileText;

							}
						} else {
							if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
								newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
										+ fileText + Constants.APPEND_STRING;

							}
						}

						// db

						Boolean UpdateFileinDB = true;
						if(NewFileName != null){
							if (NewFileName.length() == 0 && param.getFileName().length() != 0) {
								UpdateFileinDB = false;
							}
						} else {
							UpdateFileinDB = false;
						}
						if (UpdateFileinDB) {
							if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {

								if (log.isTraceEnabled()) {
									log.trace(
											"updateAssetInstancePropertiesDetails || called helper method : updateParameterForAssetInst() : to update parameter");

								}
									paramValue.setName(param.getAssetParamName());

									updateParameterForAssetInst(param, paramValue, userId, conn);

								
							}
						}

						// folder
						if(NewFileName != null){
							if (!NewFileName.isEmpty() || NewFileName.length() != 0) {

								InputStream image1 = null;
								//String NewFile = null;

								image1 = (dataMultiPart.getEntityAs(InputStream.class));
								//NewFile = dataMultiPart.getContentDisposition().getFileName();

								if (log.isTraceEnabled()) {
									log.trace(
											"updateAssetInstancePropertiesDetails || called helper method : getNameValue()");
								}
								//getNameValue(param, image1, NewFile, context, conn);
							//	getNameValue(param, image1, newFileNameForImageOnly, context, conn);
								getNameValue(param, image1, param.getFileName(), context, conn);
								


							}

						}
					}
// filetype
					else {

						if (!userName.equals("admin") && activeFlag == 1) {

							if (log.isTraceEnabled()) {
								log.trace(
										"updateAssetInstancePropertiesDetails || called dao method : getParameterForAssetInstParamAndVersionId() by : assetInstanceVersionId "
												+ aivId + "and AssetParamName " + param.getAssetParamName());
							}

							pv = assetDao.getParameterForAssetInstParamAndVersionId(param.getAssetParamName(), aivId,
									conn);

							if (pv != null) {
								String oldValueImp = "";
								String newValueImp = "";
								List<String> ldapoldvalue = new ArrayList<String>();
								List<String> ldapnewvalue = new ArrayList<String>();
								if (pv.getParamTypeId() == 1 ){
									if(pv.getHasArray() == 1){
									oldValueImp = pv.getTextDataList().toString();
									newValueImp = param.getTextDataList().toString();
									}else{
										oldValueImp = pv.getValue().toString();
										newValueImp = param.getParamValue().toString();
									}
								}else if(pv.getParamTypeId() == 7){
									if(pv.getHasArray() == 1){
									    oldValueImp = pv.getRTFwithTags().toString();
										newValueImp = param.getRTFwithTags().toString();
									}else{
										oldValueImp = pv.getValue().toString();
										newValueImp = param.getParamValue().toString();
									}
								}else if(pv.getParamTypeId() == 9){
									List<String> dbvalueList = pv.getLdapMappingMap().keySet().stream().collect(Collectors.toList());
									List<String> uivalueList = param.getLdapMappingValue().keySet().stream().collect(Collectors.toList());

									if(pv.getHasArray() == 1) {
										ldapoldvalue = dbvalueList;
										ldapnewvalue = uivalueList;
									}else {
										ldapoldvalue = dbvalueList;
										ldapnewvalue = uivalueList;
									}
								}else{
							    oldValueImp = pv.getValue().trim().toString();
								newValueImp = param.getParamValue().trim().toString();
								}
								int num = oldValueImp.compareTo(newValueImp);
								if ((num < 0 || num > 0) && (pv.isImportant() == true)) {
									// countImp++;
									flag = true;
									gamePoint.setField("Parameter - " + param.getAssetParamName());
									gamePoint.setAction("Updated");
								}
								boolean updateFlag = false;
								if(ldapoldvalue.size() == ldapnewvalue.size()){
									int count = 0;
									
									for(String olddata:ldapoldvalue){
										for(String newdata:ldapnewvalue){
											if(olddata.equalsIgnoreCase(newdata)) {
												count++;
											}
										}
									}
									if(count == ldapoldvalue.size()) {
										updateFlag = true;
									}
								}
								if(updateFlag != true) {
									flag = true;
									gamePoint.setField("Parameter - " + param.getAssetParamName());
									gamePoint.setAction("Updated");
								}
							} else {
								List<String> ldapnewvalue = new ArrayList<String>();
								if (log.isTraceEnabled()) {
									log.trace(
											"updateAssetInstancePropertiesDetails || called dao method : getParamIdForAssetAndParamName() by : assetName "
													+ assetName + "and AssetParamName " + param.getAssetParamName());
								}

								AssetParamDef apd = assetDao.getParamIdForAssetAndParamName(assetName,
										param.getAssetParamName(), conn);

								String newValueImp = null;
								
								if(apd.getParamTypeId() == 1){
									if(apd.getHasArray() == 1)
										newValueImp = param.getTextDataList().toString();
									else
										newValueImp = param.getParamValue().toString();
								}else if(apd.getParamTypeId() == 7){
									if(apd.getHasArray() == 1)
									    newValueImp = param.getRTFwithTags().toString();
									else
										newValueImp = param.getParamValue().toString();	
								}else if(apd.getParamTypeId() == 9) {
									List<String> uivalueList = param.getLdapMappingValue().keySet().stream().collect(Collectors.toList());

									if(apd.getHasArray() == 1) {
										ldapnewvalue = uivalueList;
									}else {
										ldapnewvalue = uivalueList;
									}
									
								}else{
									newValueImp = param.getParamValue();
								}

								if ((newValueImp != null && !newValueImp.isEmpty())
										&& apd.isHasImportantValue() == true) {

									flag = true;
									gamePoint.setField("Parameter - " + param.getAssetParamName());
									gamePoint.setAction("Created");

								}
							}
						}

						if (countForParam == paramCount) {
							if (param.getParamValue() != null) {
								if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
											+ param.getParamValue();
								}
							} else if(param.getParamTypeId() == 9){
								
								if(!param.getLdapMappingValue().isEmpty()) {
									List<String> uivalueList = param.getLdapMappingValue().keySet().stream().collect(Collectors.toList());

									String listString = "";
									for (String s : uivalueList)
									{
										listString += s + "``";
									}
									if (listString.endsWith("``")) {
										listString = listString.substring(0, listString.length() - 2);
									}
									newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
											+listString;
								}else {
									String listString = "";
									newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
											+listString;
								}
							}else {
								if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":";
								}
							}
						} else {
							if (param.getParamValue() != null) {
								if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
											+ param.getParamValue() + Constants.APPEND_STRING;
								}
							} else if(param.getParamTypeId() == 9){
								if(!param.getLdapMappingValue().isEmpty()) {
									List<String> uivalueList = param.getLdapMappingValue().keySet().stream().collect(Collectors.toList());

									String listString = "";
									for (String s : uivalueList)
									{
										listString += s + "``";
									}
									if (listString.endsWith("``")) {
										listString = listString.substring(0, listString.length() - 2);
									}
									newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
											+listString + Constants.APPEND_STRING;
								}else {
									newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
											+ Constants.APPEND_STRING;
								}
							}else {
								if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
											+ Constants.APPEND_STRING;
								}
							}
						}

						if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
							if (log.isTraceEnabled()) {
								log.trace(
										"updateAssetInstancePropertiesDetails || called helper method : updateParameterForAssetInst() : to update parameter");
							}

							updateParameterForAssetInst(param, null, userId, conn);
						}

					}

					// gamification point

					if (flag == true && !userName.equals("admin") && activeFlag == 1) {
						gamePoint.setPoints("1");
						gamePoint.setActivityTimestamp(
								new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());

						gamePoint.setUserId(userId);
						gamePoint.setAssetId(String.valueOf(aiv.getAssetId()));
						gamePoint.setAssetInstanceVersionId(String.valueOf(aivId));
						if (aiv.getVersionable() == true) {
							gamePoint.setInstanceDetails(
									aiv.getAssetName() + "~" + aiv.getAssetInstName() + "~" + aiv.getVersionName());
						} else {
							gamePoint.setInstanceDetails(aiv.getAssetName() + "~" + aiv.getAssetInstName() + "~N/A");
						}

						if (log.isTraceEnabled()) {
							log.trace(
									"updateAssetInstancePropertiesDetails || dao method called : addGamificationPoint() : "
											+ gamePoint.toString());
						}
						gamificationDao.addGamificationPoint(gamePoint, conn);

					}

					countForParam++;

				}

				// updateAivUpdatedOn

				aiv1.setVersionName(aiv.getVersionName());
				aiv1.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));

				if (log.isTraceEnabled()) {
					log.trace(
							"updateAssetInstancePropertiesDetails || called dao method : updateAivUpdatedOn() by AssetInstanceVersionId: "
									+ aivId + "and" + aiv1.toString());
				}
				assetInstanceVersionDao.updateAivUpdatedOn(aiv1, aivId, conn);

				// addRevisionData
				if(commitFlag == false){
					if (log.isTraceEnabled()) {
						log.trace(
								"updateAssetInstancePropertiesDetails || called helper method : addRevisionData() : to add revision data");
					}
					addRevisionData("P", aivId, aiv.getVersionName(), null, null, newParamDataForRevision, null, userName,
							userId,null, conn);
				}
				jsontRevisionString.add(newParamDataForRevision);
				
				// mail template
				if(commitFlag == false){
				try {

					List<String> emailIds = subscriptionDao
							.getAllSubscriptionsByAssetInstanceId(aiv.getAssetInstanceId(), conn);
					MailTemplateDao mailDao = new MailTemplateDao();
					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					MailConfig mailConfig = mailDao.getMailConfig(conn);
					String mailTemp = null;

					if (aiv.getVersionable() == true) {

						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"updatePropertiesForVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%",
								aiv.getVersionName());

					} else {

						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"updatePropertiesForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
					}

					if (emailIds != null) {
						for (String emailId : emailIds) {
							if (aiv.getVersionable() == true) {

								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
							} else {

								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
						}

					}
				} catch (Exception e) {

				}
				}
				if(commitFlag == false){
					// addRecentActivity

					RecentActivity recentActivity = new RecentActivity();
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setAssetId(String.valueOf(aiv.getAssetId()));
					recentActivity.setAssetInstVersionId(String.valueOf(aivId));
					recentActivity.setUser_id(userId);

					if (aiv.getVersionable() == true) {
						recentActivity.setDescription(user.getFullName() + ";" + action + ";" + assetName + ";"
								+ aiv.getAssetInstName() + ";" + "version" + aiv.getVersionName());

						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstancePropertiesDetails || dao method called : addRecentActivity() : "
									+ recentActivity.toString());
						}

						recentActivityDao.addRecentActivity(recentActivity, conn);
					} else {
						recentActivity.setDescription(
								user.getFullName() + ";" + action + ";" + assetName + ";" + aiv.getAssetInstName());

						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstancePropertiesDetails || dao method called : addRecentActivity() : "
									+ recentActivity.toString());
						}

						recentActivityDao.addRecentActivity(recentActivity, conn);
					}

				}
			}
			retMsg = Constants.ASSET_INSTANCE_PROPERTIES_UPDATED;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

			log.info(" updateAssetInstancePropertiesDetails ||" + ListOfAssetInstanceProperties
					+ " Updated asset instance properties details successfully");
			if(commitFlag == false){
				conn.commit();
			}

		} catch (RepoproException e) {
			log.error("updateAssetInstancePropertiesDetails ||  " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {	
				if(commitFlag == false){
					conn.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
				e.printStackTrace();
				throw new RepoproException(e1.getMessage());
			}
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("updateAssetInstancePropertiesDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				if(commitFlag == false){
					conn.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
				throw new RepoproException(e1.getMessage());
			}
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstancePropertiesDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			if(commitFlag == false){
				DBConnection.closeDbConnection(conn);
			}
			if(conn1 != null){
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstancePropertiesDetails || End");
		}

		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,new ArrayList<Object>(jsontRevisionString))).build();

	
	}

	public void getNameValue(AssetInstanceVersion paramVo, InputStream image1, String myFileName,
			@Context ServletContext context, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getNameValue || begin to create thumbnail image for update file properties ");
		}

		AssetDao assetDao = new AssetDao();
		NameValue paramValue = new NameValue();
		Map<String, String> valMap = new LinkedHashMap<String, String>();
		ParameterValues pv = new ParameterValues();
		Connection conn1 = null;
		try {
			if (conn == null) {

				if (log.isTraceEnabled()) {
					log.trace("getNameValue || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (paramVo.getParamTypeId() == (Constants.FILE_TYPE)) {

				if (paramVo.getIsStatic() != 1) {
					if (log.isTraceEnabled()) {
						log.trace("getNameValue || called dao method : getParameterForAssetInstParamAndVersionId() : "
								+ paramVo.getAssetParamName() + "and" + paramVo.getAssetInstVersionId());
					}

					pv = assetDao.getParameterForAssetInstParamAndVersionId(paramVo.getAssetParamName(),
							paramVo.getAssetInstVersionId(), conn);

				}

				if (myFileName.endsWith(".png") || myFileName.endsWith(".jpg") || myFileName.endsWith(".jpeg")
						|| myFileName.endsWith(".PNG") || myFileName.endsWith(".JPG") || myFileName.endsWith(".JPEG")) {

					if (paramVo.getIsStatic() == 1) {

						FileOutputStream fos = new FileOutputStream(
								System.getProperty("java.io.tmpdir") + paramVo.getAssetParamId() + "_" + myFileName);

						byte[] bytes = StreamUtils.copyToByteArray(image1);

						fos.write(bytes);
						fos.close();
					} else {
						if (pv != null) {
							FileOutputStream fos = new FileOutputStream(
									System.getProperty("java.io.tmpdir") + pv.getAssetInstParamId() + "_" + myFileName);

							byte[] bytes = StreamUtils.copyToByteArray(image1);

							fos.write(bytes);
							fos.close();
						} else {
							FileOutputStream fos = new FileOutputStream(
									System.getProperty("java.io.tmpdir") + myFileName);

							byte[] bytes = StreamUtils.copyToByteArray(image1);

							fos.write(bytes);
							fos.close();
						}
					}

					Image image;

					if (paramVo.getIsStatic() == 1) {
						image = Toolkit.getDefaultToolkit().getImage(
								System.getProperty("java.io.tmpdir") + paramVo.getAssetParamId() + "_" + myFileName);
					} else {
						if (pv != null) {
							image = Toolkit.getDefaultToolkit().getImage(
									System.getProperty("java.io.tmpdir") + pv.getAssetInstParamId() + "_" + myFileName);
						} else {
							image = Toolkit.getDefaultToolkit()
									.getImage(System.getProperty("java.io.tmpdir") + myFileName);
						}
					}

					MediaTracker mediaTracker = new MediaTracker(new Container());
					mediaTracker.addImage(image, 0);
					mediaTracker.waitForID(0);
					int thumbWidth = 60;
					int thumbHeight = 60;
					int quality = 100;

					double thumbRatio = (double) thumbWidth / (double) thumbHeight;
					int imageWidth = image.getWidth(null);
					int imageHeight = image.getHeight(null);
					double imageRatio = (double) imageWidth / (double) imageHeight;
					if (thumbRatio < imageRatio) {
						thumbHeight = (int) (thumbWidth / imageRatio);
					} else {
						thumbWidth = (int) (thumbHeight * imageRatio);
					}
					BufferedImage thumbImage = new BufferedImage(thumbWidth, thumbHeight, BufferedImage.TYPE_INT_RGB);
					Graphics2D graphics2D = thumbImage.createGraphics();
					graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
							RenderingHints.VALUE_INTERPOLATION_BILINEAR);
					graphics2D.drawImage(image, 0, 0, thumbWidth, thumbHeight, null);

					// save thumbnail image to outFilename
				/*	JPEGImageEncoder encoder;
					JPEGEncodeParam param;*/
					BufferedOutputStream out;
					String sfile = "";

					File file4 = new File(System.getProperty("user.home") + "/ThumbnailImages");
					if (!file4.exists()) {
						if (file4.mkdir()) {
							System.out.println("Directory thumbnailimages is created!");
						} else {
							System.out.println("Failed to create directory thumbnailimages!");
						}
					}
					if (paramVo.getIsStatic() == 1) {
						out = new BufferedOutputStream(new FileOutputStream(context.getRealPath("")
								+ "/images/thumbnailImages/" + paramVo.getAssetParamId() + "_" + myFileName));
						sfile = context.getRealPath("") + "/images/thumbnailImages/" + paramVo.getAssetParamId() + "_"
								+ myFileName;
						if(myFileName.endsWith("jpg")){
							ImageIO.write(thumbImage, "jpg", new File(sfile));
						}else if(myFileName.endsWith("png")){
							ImageIO.write(thumbImage, "png", new File(sfile));
						}else if(myFileName.endsWith("jpeg")){
							ImageIO.write(thumbImage, "jpeg", new File(sfile));
						}else if(myFileName.endsWith("JPG")){
							ImageIO.write(thumbImage, "JPG", new File(sfile));
						}else if(myFileName.endsWith("PNG")){
							ImageIO.write(thumbImage, "PNG", new File(sfile));
						}else if(myFileName.endsWith("JPEG")){
							ImageIO.write(thumbImage, "JPEG", new File(sfile));
						}
						/*encoder = JPEGCodec.createJPEGEncoder(out);
						param = encoder.getDefaultJPEGEncodeParam(thumbImage);
						quality = Math.max(0, Math.min(quality, 100));
						param.setQuality((float) quality / 100.0f, false);
						encoder.setJPEGEncodeParam(param);
						encoder.encode(thumbImage);*/
						// copy from above to user.home
					} else {
						if (pv != null) {
							out = new BufferedOutputStream(new FileOutputStream(context.getRealPath("")
									+ "/images/thumbnailImages/" + pv.getAssetInstParamId() + "_" + myFileName));
							sfile = context.getRealPath("") + "/images/thumbnailImages/" + pv.getAssetInstParamId()
									+ "_" + myFileName;
							if(myFileName.endsWith("jpg")){
								ImageIO.write(thumbImage, "jpg", new File(sfile));
							}else if(myFileName.endsWith("png")){
								ImageIO.write(thumbImage, "png", new File(sfile));
							}else if(myFileName.endsWith("jpeg")){
								ImageIO.write(thumbImage, "jpeg", new File(sfile));
							}else if(myFileName.endsWith("JPG")){
								ImageIO.write(thumbImage, "JPG", new File(sfile));
							}else if(myFileName.endsWith("PNG")){
								ImageIO.write(thumbImage, "PNG", new File(sfile));
							}else if(myFileName.endsWith("JPEG")){
								ImageIO.write(thumbImage, "JPEG", new File(sfile));
							}
							/*encoder = JPEGCodec.createJPEGEncoder(out);
							param = encoder.getDefaultJPEGEncodeParam(thumbImage);
							quality = Math.max(0, Math.min(quality, 100));
							param.setQuality((float) quality / 100.0f, false);
							encoder.setJPEGEncodeParam(param);
							encoder.encode(thumbImage);*/
							// copy from above to user.home
						} else {
							out = new BufferedOutputStream(new FileOutputStream(
									context.getRealPath("") + "/images/thumbnailImages/" + myFileName));
							sfile = context.getRealPath("") + "/images/thumbnailImages/" + myFileName;
							if(myFileName.endsWith("jpg")){
								ImageIO.write(thumbImage, "jpg", new File(sfile));
							}else if(myFileName.endsWith("png")){
								ImageIO.write(thumbImage, "png", new File(sfile));
							}else if(myFileName.endsWith("jpeg")){
								ImageIO.write(thumbImage, "jpeg", new File(sfile));
							}else if(myFileName.endsWith("JPG")){
								ImageIO.write(thumbImage, "JPG", new File(sfile));
							}else if(myFileName.endsWith("PNG")){
								ImageIO.write(thumbImage, "PNG", new File(sfile));
							}else if(myFileName.endsWith("JPEG")){
								ImageIO.write(thumbImage, "JPEG", new File(sfile));
							}
							/*encoder = JPEGCodec.createJPEGEncoder(out);
							param = encoder.getDefaultJPEGEncodeParam(thumbImage);
							quality = Math.max(0, Math.min(quality, 100));
							param.setQuality((float) quality / 100.0f, false);
							encoder.setJPEGEncodeParam(param);
							encoder.encode(thumbImage);*/
							// copy from above to user.home
							java.util.Date date = new java.util.Date();
							String time = new Timestamp(date.getTime()).toString();
							valMap.put(paramVo.getAssetParamName(), time + "|" + myFileName);
						}
					}

					out.close();
					File sourceFile = new File(sfile);
					String name = sourceFile.getName();
					File checkList = null;
					String[] imgName = null;
					if(name.contains("_")){
						imgName = name.split("_");
					}
					File targetFile = new File(System.getProperty("user.home") + "/ThumbnailImages/" + name);
					if(imgName != null) {
						checkList = new File(System.getProperty("user.home") + "/ThumbnailImages/" +imgName[0]+"_");
					}
					/*BufferedImage image = null;
					BufferedImage invertedImage = null;
					image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));*/
					
					FileUtils.copyFile(sourceFile, targetFile);

					if (paramVo.getFileName() != null) {
						if (!paramVo.getFileName().equalsIgnoreCase(myFileName)) {
							if (paramVo.getIsStatic() == 1) {
								File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
										+ paramVo.getAssetParamId() + "_" + paramVo.getFileName());
								if (file.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");

								File file5 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
										+ paramVo.getAssetParamId() + "_" + paramVo.getFileName());
								if (file5.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");
							} else {
								if (pv != null) {
									File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
											+ pv.getAssetInstParamId() + "_" + paramVo.getFileName());
									if (file.delete()) {
										System.out.println(" File deleted");
									} else
										System.out.println("File doesn't exists");

									File file5 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
											+ pv.getAssetInstParamId() + "_" + paramVo.getFileName());
									if (file5.delete()) {
										System.out.println(" File deleted");
									} else
										System.out.println("File doesn't exists");
								} else {
									File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
											+ paramVo.getFileName());
									if (file.delete()) {
										System.out.println(" File deleted");
									} else
										System.out.println("File doesn't exists");

									File file5 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
											+ paramVo.getFileName());
									if (file5.delete()) {
										System.out.println(" File deleted");
									} else
										System.out.println("File doesn't exists");
								}
							}

						}

					} else if (myFileName.equalsIgnoreCase("") || myFileName == null) {
						if (paramVo.getFileName() != null) {
							if (paramVo.getIsStatic() == 1) {
								File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
										+ paramVo.getAssetParamId() + "_" + paramVo.getFileName());
								if (file.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File  doesn't exists");

								File file7 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
										+ paramVo.getAssetParamId().toString() + "_" + paramVo.getFileName());
								if (file7.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");
							} else {
								if (pv != null) {
									File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
											+ pv.getAssetInstParamId() + "_" + paramVo.getFileName());
									if (file.delete()) {
										System.out.println(" File deleted");
									} else
										System.out.println("File  doesn't exists");

									File file7 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
											+ pv.getAssetInstParamId() + "_" + paramVo.getFileName());
									if (file7.delete()) {
										System.out.println(" File deleted");
									} else
										System.out.println("File doesn't exists");
								}

								else {
									File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
											+ paramVo.getFileName());
									if (file.delete()) {
										System.out.println(" File deleted");
									} else
										System.out.println("File  doesn't exists");

									File file7 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
											+ paramVo.getFileName());
									if (file7.delete()) {
										System.out.println(" File deleted");
									} else
										System.out.println("File doesn't exists");
								}
							}
						}
					}
					if (paramVo.getIsStatic() == 1) {

						File file1 = new File(
								System.getProperty("java.io.tmpdir") + paramVo.getAssetParamId() + "_" + myFileName);
						if (file1.delete()) {
							System.out.println(" File deleted");
						} else
							System.out.println("File doesn't exists");
					} else {
						if (pv != null) {
							File file1 = new File(
									System.getProperty("java.io.tmpdir") + pv.getAssetInstParamId() + "_" + myFileName);
							if (file1.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File doesn't exists");
						}

						else {
							File file1 = new File(System.getProperty("java.io.tmpdir") + myFileName);
							if (file1.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File doesn't exists");
						}
					}
				}

				if (myFileName.equalsIgnoreCase("") && paramVo.getFileName() != null
						&& !paramVo.getNewFileName().equals(paramVo.getFileName())) {

					// if(paramVo.getFileName() != null){
					if (!paramVo.getFileName().equalsIgnoreCase(myFileName)) {
						if (paramVo.getIsStatic() == 1) {
							File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
									+ paramVo.getAssetParamId() + "_" + paramVo.getFileName());
							if (file.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File doesn't exists");

							File file5 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
									+ paramVo.getAssetParamId() + "_" + paramVo.getFileName());
							if (file5.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File doesn't exists");
						} else {
							if (pv != null) {
								File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
										+ pv.getAssetInstParamId() + "_" + paramVo.getFileName());
								if (file.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");

								File file5 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
										+ pv.getAssetInstParamId() + "_" + paramVo.getFileName());
								if (file5.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");
							} else {
								File file = new File(
										context.getRealPath("") + "/images/thumbnailImages/" + paramVo.getFileName());
								if (file.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");

								File file5 = new File(
										System.getProperty("user.home") + "/ThumbnailImages/" + paramVo.getFileName());
								if (file5.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");
							}
						}
					}

					if (paramVo.getIsStatic() == 1) {
						File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
								+ paramVo.getAssetParamId() + "_" + paramVo.getFileName());
						if (file.delete()) {
							System.out.println(" File deleted");
						} else
							System.out.println("File  doesn't exists");

						File file7 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
								+ paramVo.getAssetParamId() + "_" + paramVo.getFileName());
						if (file7.delete()) {
							System.out.println(" File deleted");
						} else
							System.out.println("File doesn't exists");
					}

					else {
						if (pv != null) {
							File file = new File(context.getRealPath("") + "/images/thumbnailImages/"
									+ pv.getAssetInstParamId() + "_" + paramVo.getFileName());
							if (file.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File  doesn't exists");

							File file7 = new File(System.getProperty("user.home") + "/ThumbnailImages/"
									+ pv.getAssetInstParamId() + "_" + paramVo.getFileName());
							if (file7.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File doesn't exists");
						}

						else {
							File file = new File(
									context.getRealPath("") + "/images/thumbnailImages/" + paramVo.getFileName());
							if (file.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File  doesn't exists");

							File file7 = new File(
									System.getProperty("user.home") + "/ThumbnailImages/" + paramVo.getFileName());
							if (file7.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File doesn't exists");
						}
					}

					if (paramVo.getIsStatic() == 1) {

						File file1 = new File(System.getProperty("java.io.tmpdir")
								+ paramVo.getAssetParamId().toString() + "_" + myFileName);
						if (file1.delete()) {
							System.out.println(" File deleted");
						} else
							System.out.println("File doesn't exists");
					} else {
						if (pv != null) {
							File file1 = new File(
									System.getProperty("java.io.tmpdir") + pv.getAssetInstParamId() + "_" + myFileName);
							if (file1.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File doesn't exists");
						}

						else {
							File file1 = new File(System.getProperty("java.io.tmpdir") + myFileName);
							if (file1.delete()) {
								System.out.println(" File deleted");
							} else
								System.out.println("File doesn't exists");
						}
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("getNameValue : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("getNameValue || Exit");
		}
		// valMap.putAll(val);

	}

	public void updateParameterForAssetInst(AssetInstanceVersion param, NameValue paramvalue, Long userId,
			Connection conn) throws RepoproException {

		ParameterValues pv1 = new ParameterValues();
		AssetParamDef param1 = new AssetParamDef();
		AssetDao assetDao = new AssetDao();
		Connection conn1 = null;

		try {
			if (conn == null) {

				if (log.isTraceEnabled()) {
					log.trace("updateParameterForAssetInst || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (param.getIsStatic() == 1) {

				if (param.getParamTypeId() == (Constants.FILE_TYPE)) {

					param1.setFileName(paramvalue.getFileName());
					param1.setAssetParamName(paramvalue.getName());
					param1.setMimetype(paramvalue.getFileMimeType());
					param1.setImage(paramvalue.getImage());

				} else {

					param1.setStaticValue(param.getParamValue());
					param1.setAssetParamName(param.getAssetParamName());

				}

				// update static param
				param1.setModifyByUserId(userId);
				param1.setLastUpdatedTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));

				if (log.isTraceEnabled()) {
					log.trace("updateParameterForAssetInst || called dao method : updateParameterInAssetParamDef() : "
							+ param1.toString());
				}

				assetDao.updateParameterInAssetParamDef(param1, param.getAssetName(), param1.getAssetParamName(), conn);

			} else {

				if (param.getParamTypeId() == (Constants.FILE_TYPE)) {

					pv1.setFileName(paramvalue.getFileName());
					pv1.setAssetParamName(paramvalue.getName());
					pv1.setMimeType(paramvalue.getFileMimeType());
					pv1.setImage(paramvalue.getImage());

				} else if(param.getParamTypeId() == 9){
					pv1.setLdapMappingMap(param.getLdapMappingValue());
				}else {
					pv1.setValue(param.getParamValue());
					pv1.setAssetParamName(param.getAssetParamName());

				}

				if (param.getParamTypeId() == 1) {// text type

					if(param.getHasArray() == 1){
						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : retInstParam() : ");
						}

						AssetInstParams aips = assetDao.retInstParam(
								param.getAssetParamId(),
								param.getAssetInstVersionId(), conn);

						if (aips.getAssetInstParamId() != null) {
							Long assetInstParamId = aips.getAssetInstParamId();
							assetDao.deleteParameterValues(assetInstParamId, conn);
						} else {

							AssetInstParams assetInstParams = new AssetInstParams();

							assetInstParams.setAssetInstVersionId(param
									.getAssetInstVersionId());
							assetInstParams
							.setAssetParamId(param.getAssetParamId());
							assetInstParams.setLastUpdatedTime(new Timestamp(
									Calendar.getInstance().getTimeInMillis()));

							assetInstParams.setModifyByUserId(userId);

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : addAssetInstParam() : "
										+ assetInstParams.toString());
							}

							aips = assetDao.addAssetInstParam(assetInstParams, conn);
						}

						ParameterValues paramValue = new ParameterValues();

						paramValue.setAssetInstParamId(aips.getAssetInstParamId());

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
									+ paramValue.toString());
						}
						if(!param.getTextDataList().isEmpty()){
						for (int i = 0; i < param.getTextDataList().size(); i++) {
							paramValue.setValue(param.getTextDataList().get(i));
							assetDao.addParameterValue(paramValue, conn);
						}
						}else{
							paramValue.setValue("");
							assetDao.addParameterValue(paramValue, conn);
						}
					}else{// text isArray 0 

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : getParameterForAssetInstParamAndVersionId() : "
									+ param.getAssetParamName()
									+ "and"
									+ param.getAssetInstVersionId());
						}

						ParameterValues pv = assetDao
								.getParameterForAssetInstParamAndVersionId(
										param.getAssetParamName(),
										param.getAssetInstVersionId(), conn);

						if (pv != null) {
							// update parametervalues
							pv1.setParameterValuesId(pv.getParameterValuesId());
							pv1.setAssetInstParamId(pv.getAssetInstParamId());

							AssetInstParams assetInstParams = new AssetInstParams();

							assetInstParams.setAssetInstParamId(pv
									.getAssetInstParamId());
							assetInstParams.setAssetInstVersionId(param
									.getAssetInstVersionId());
							assetInstParams
							.setAssetParamId(param.getAssetParamId());
							assetInstParams.setLastUpdatedTime(new Timestamp(
									Calendar.getInstance().getTimeInMillis()));
							assetInstParams.setModifyByUserId(userId);

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : updateAssetInstParam() : "
										+ assetInstParams.toString());
							}

							assetDao.updateAssetInstParam(assetInstParams, conn);

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : updateParameterValues() : "
										+ pv1.toString());
							}

							assetDao.updateParameterValues(pv1, conn);

						} else {

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : retInstParam() : ");
							}

							AssetInstParams aiparam = assetDao.retInstParam(
									param.getAssetParamId(),
									param.getAssetInstVersionId(), conn);

							if (aiparam.getAssetInstParamId() == null) {

								AssetInstParams assetInstParams = new AssetInstParams();

								assetInstParams.setAssetInstVersionId(param
										.getAssetInstVersionId());
								assetInstParams.setAssetParamId(param
										.getAssetParamId());
								assetInstParams.setLastUpdatedTime(new Timestamp(
										Calendar.getInstance().getTimeInMillis()));

								assetInstParams.setModifyByUserId(userId);

								if (log.isTraceEnabled()) {
									log.trace("updateParameterForAssetInst || called dao method : addAssetInstParam() : "
											+ assetInstParams.toString());
								}

								AssetInstParams aip = assetDao.addAssetInstParam(
										assetInstParams, conn);

								ParameterValues paramValue = new ParameterValues();

								paramValue.setAssetInstParamId(aip
										.getAssetInstParamId());

								paramValue.setValue(pv1.getValue());
								
								if (log.isTraceEnabled()) {
									log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
											+ paramValue.toString());
								}

								assetDao.addParameterValue(paramValue, conn);

							} else {

								AssetInstParams assetInstParams = new AssetInstParams();

								assetInstParams.setAssetInstParamId(aiparam
										.getAssetInstParamId());
								assetInstParams.setAssetInstVersionId(aiparam
										.getAssetInstVersionId());
								assetInstParams.setAssetParamId(aiparam
										.getAssetParamId());
								assetInstParams.setLastUpdatedTime(new Timestamp(
										Calendar.getInstance().getTimeInMillis()));
								assetInstParams.setModifyByUserId(userId);

								if (log.isTraceEnabled()) {
									log.trace("updateParameterForAssetInst || called dao method : updateAssetInstParam() : "
											+ assetInstParams.toString());
								}

								assetDao.updateAssetInstParam(assetInstParams, conn);

								ParameterValues paramValue = new ParameterValues();

								paramValue.setAssetInstParamId(aiparam
										.getAssetInstParamId());

								paramValue.setValue(pv1.getValue());
								

								if (log.isTraceEnabled()) {
									log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
											+ paramValue.toString());
								}

								assetDao.addParameterValue(paramValue, conn);

							}
						}
					
					}

				} else if (param.getParamTypeId() == 7) {// rich text type

					if(param.getHasArray() == 1){
						AssetInstParams aips = assetDao.retInstParam(
								param.getAssetParamId(),
								param.getAssetInstVersionId(), conn);

						if (aips.getAssetInstParamId() != null) {
							Long assetInstParamId = aips.getAssetInstParamId();
							assetDao.deleteParameterValues(assetInstParamId, conn);
						} else {

							AssetInstParams assetInstParams = new AssetInstParams();

							assetInstParams.setAssetInstVersionId(param
									.getAssetInstVersionId());
							assetInstParams
							.setAssetParamId(param.getAssetParamId());
							assetInstParams.setLastUpdatedTime(new Timestamp(
									Calendar.getInstance().getTimeInMillis()));

							assetInstParams.setModifyByUserId(userId);

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : addAssetInstParam() : "
										+ assetInstParams.toString());
							}

							aips = assetDao.addAssetInstParam(assetInstParams, conn);
						}

						ParameterValues paramValue = new ParameterValues();

						paramValue.setAssetInstParamId(aips.getAssetInstParamId());

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
									+ paramValue.toString());
						}
						if(!param.getRTFwithTags().isEmpty()){
							for (int i = 0; i < param.getRTFwithTags().size(); i++) {
								paramValue.setRTFText(param.getRTFwithTags().get(i));
								paramValue.setRTFPlainText(param.getRTFwithOutTags().get(i));
								assetDao.addParameterValuesForRichText(paramValue, conn);
							}
						}else{
							paramValue.setRTFText("");
							paramValue.setRTFPlainText("");
							assetDao.addParameterValuesForRichText(paramValue, conn);
						}
					}else{// rich text isArray 0 

						AssetInstParams aips = assetDao.retInstParam(
								param.getAssetParamId(),
								param.getAssetInstVersionId(), conn);

						if (aips.getAssetInstParamId() != null) {
							Long assetInstParamId = aips.getAssetInstParamId();
							assetDao.deleteParameterValues(assetInstParamId, conn);
						} else {

							AssetInstParams assetInstParams = new AssetInstParams();

							assetInstParams.setAssetInstVersionId(param
									.getAssetInstVersionId());
							assetInstParams
							.setAssetParamId(param.getAssetParamId());
							assetInstParams.setLastUpdatedTime(new Timestamp(
									Calendar.getInstance().getTimeInMillis()));

							assetInstParams.setModifyByUserId(userId);

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : addAssetInstParam() : "
										+ assetInstParams.toString());
							}

							aips = assetDao.addAssetInstParam(assetInstParams, conn);
						}

						ParameterValues paramValue = new ParameterValues();

						paramValue.setAssetInstParamId(aips.getAssetInstParamId());

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
									+ paramValue.toString());
						}

						paramValue.setRTFPlainText(param.getRTFPlainText());
						paramValue.setRTFText(param.getParamValue());

						assetDao.addParameterValuesForRichText(paramValue, conn);


					}

				}else if(param.getParamTypeId() == 9){// ldap mapping type

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : retInstParam() : ");
						}

						AssetInstParams aips = assetDao.retInstParam(param.getAssetParamId(),param.getAssetInstVersionId(), conn);

						if (aips.getAssetInstParamId() != null) {
							Long assetInstParamId = aips.getAssetInstParamId();
							assetDao.deleteParameterValues(assetInstParamId, conn);
						} else {

							AssetInstParams assetInstParams = new AssetInstParams();

							assetInstParams.setAssetInstVersionId(param.getAssetInstVersionId());
							assetInstParams.setAssetParamId(param.getAssetParamId());
							assetInstParams.setLastUpdatedTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							assetInstParams.setModifyByUserId(userId);

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : addAssetInstParam() : "
										+ assetInstParams.toString());
							}

							aips = assetDao.addAssetInstParam(assetInstParams, conn);
						}

						ParameterValues paramValue = new ParameterValues();

						paramValue.setAssetInstParamId(aips.getAssetInstParamId());

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
									+ paramValue.toString());
						}
						if(!param.getLdapMappingValue().isEmpty()){
							
							for (Map.Entry<String,Integer> entry : param.getLdapMappingValue().entrySet()) {
								paramValue.setValue(entry.getKey());
								paramValue.setLdapAttributeId(entry.getValue());
								assetDao.addParameterValueForLdapMapping(paramValue, conn);
							}
							
						}else{
							AssetParamDef assetParamDef = assetDao.getParamIdForAssetAndParamName(param.getAssetName(), param.getAssetParamName(), conn);
							List<LdapMapping> ldapAttributeList = assetDao.getLdapMappingAttributeList(assetParamDef.getLdapMappingId(), conn);
							for(LdapMapping attribute:ldapAttributeList){
								paramValue.setValue("");
								paramValue.setLdapAttributeId(attribute.getLdapAttributeId());
								assetDao.addParameterValueForLdapMapping(paramValue, conn);
							}
						}

				}else { // normal update

					if (log.isTraceEnabled()) {
						log.trace("updateParameterForAssetInst || called dao method : getParameterForAssetInstParamAndVersionId() : "
								+ param.getAssetParamName()
								+ "and"
								+ param.getAssetInstVersionId());
					}

					ParameterValues pv = assetDao
							.getParameterForAssetInstParamAndVersionId(
									param.getAssetParamName(),
									param.getAssetInstVersionId(), conn);

					if (pv != null) {
						// update parametervalues
						pv1.setParameterValuesId(pv.getParameterValuesId());
						pv1.setAssetInstParamId(pv.getAssetInstParamId());

						AssetInstParams assetInstParams = new AssetInstParams();

						assetInstParams.setAssetInstParamId(pv
								.getAssetInstParamId());
						assetInstParams.setAssetInstVersionId(param
								.getAssetInstVersionId());
						assetInstParams
						.setAssetParamId(param.getAssetParamId());
						assetInstParams.setLastUpdatedTime(new Timestamp(
								Calendar.getInstance().getTimeInMillis()));
						assetInstParams.setModifyByUserId(userId);

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : updateAssetInstParam() : "
									+ assetInstParams.toString());
						}

						assetDao.updateAssetInstParam(assetInstParams, conn);

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : updateParameterValues() : "
									+ pv1.toString());
						}

						assetDao.updateParameterValues(pv1, conn);

					} else {

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : retInstParam() : ");
						}

						AssetInstParams aiparam = assetDao.retInstParam(
								param.getAssetParamId(),
								param.getAssetInstVersionId(), conn);

						if (aiparam.getAssetInstParamId() == null) {

							AssetInstParams assetInstParams = new AssetInstParams();

							assetInstParams.setAssetInstVersionId(param
									.getAssetInstVersionId());
							assetInstParams.setAssetParamId(param
									.getAssetParamId());
							assetInstParams.setLastUpdatedTime(new Timestamp(
									Calendar.getInstance().getTimeInMillis()));

							assetInstParams.setModifyByUserId(userId);

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : addAssetInstParam() : "
										+ assetInstParams.toString());
							}

							AssetInstParams aip = assetDao.addAssetInstParam(
									assetInstParams, conn);

							ParameterValues paramValue = new ParameterValues();

							paramValue.setAssetInstParamId(aip
									.getAssetInstParamId());

							paramValue.setValue(pv1.getValue());
							paramValue.setFileName(pv1.getFileName());
							paramValue.setImage(pv1.getImage());

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
										+ paramValue.toString());
							}

							assetDao.addParameterValue(paramValue, conn);

						} else {

							AssetInstParams assetInstParams = new AssetInstParams();

							assetInstParams.setAssetInstParamId(aiparam
									.getAssetInstParamId());
							assetInstParams.setAssetInstVersionId(aiparam
									.getAssetInstVersionId());
							assetInstParams.setAssetParamId(aiparam
									.getAssetParamId());
							assetInstParams.setLastUpdatedTime(new Timestamp(
									Calendar.getInstance().getTimeInMillis()));
							assetInstParams.setModifyByUserId(userId);

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : updateAssetInstParam() : "
										+ assetInstParams.toString());
							}

							assetDao.updateAssetInstParam(assetInstParams, conn);

							ParameterValues paramValue = new ParameterValues();

							paramValue.setAssetInstParamId(aiparam
									.getAssetInstParamId());

							paramValue.setValue(pv1.getValue());
							paramValue.setFileName(pv1.getFileName());
							paramValue.setImage(pv1.getImage());

							if (log.isTraceEnabled()) {
								log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
										+ paramValue.toString());
							}

							assetDao.addParameterValue(paramValue, conn);

						}
					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("updateParameterForAssetInst : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("updateParameterForAssetInst || Exit");
		}
	}

	/**
	 * @method : getHierarchyForTaxonomy
	 * @param taxonomyId
	 * @return
	 */
	@GET
	@Path("/getHierarchyForTaxonomy")
	public Response getHierarchyForTaxonomy(@QueryParam("taxonomyId") Long taxonomyId) {

		if (log.isTraceEnabled()) {
			log.trace("getHierarchyForTaxonomy || Begin with taxonomyId : " + taxonomyId);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<String> taxNameWithID = new ArrayList<String>();
		List<ParentModel> parentModels = new ArrayList<ParentModel>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getHierarchyForTaxonomy || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
			TaxonomiesDao tdao = new TaxonomiesDao();
			TaxonomiesManager tmgr = new TaxonomiesManager();

			if (log.isTraceEnabled()) {
				log.trace("getHierarchyForTaxonomy || dao method called : getHierarchyForTaxonomy()");
			}
			List<Long> tt = dao.getHierarchyForTaxonomy(taxonomyId, conn);

			for (Long tm : tt) {
				if (log.isTraceEnabled()) {
					log.trace("getHierarchyForTaxonomy || dao method called : getTaxonomiesByTaxId()");
				}
				TaxonomyMaster master = tdao.getTaxonomiesByTaxId(tm, conn);
				taxNameWithID.add(master.getTaxonomyName() + "|" + master.getTaxonomyId());

				ParentModel parentModel1 = new ParentModel(master.getTaxonomyName() + "|" + master.getTaxonomyId(),
						null);
				parentModels.add(parentModel1);

				if (log.isTraceEnabled()) {
					log.trace("getHierarchyForTaxonomy || helper method called : recurse()");
				}
				tmgr.recurse(parentModels, "", master.getTaxonomyName() + "" + master.getTaxonomyId());
			}

			retMsg = Constants.TAXONOMY_HIERARCHY_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			log.info("getHierarchyForTaxonomy || Hierarchy for Taxonomy fetched");

		} catch (RepoproException e) {
			log.error("getHierarchyForTaxonomy || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getHierarchyForTaxonomy || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getHierarchyForTaxonomy || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getHierarchyForTaxonomy || end");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(parentModels))).build();
	}

	List<Long> associatedTaxId = new ArrayList<Long>();

	/**
	 * @method : queryAIVDetailsForassociatedTaxonomyAction
	 * @param assetName
	 * @param taxId
	 * @return
	 */
	@GET
	@Path("/queryAIVDetailsForassociatedTaxonomyAction")
	public Response queryAIVDetailsForassociatedTaxonomyAction(@QueryParam("assetName") String assetName,
			@QueryParam("taxId") Long taxId) {

		if (log.isTraceEnabled()) {
			log.trace("queryAIVDetailsForassociatedTaxonomyAction || Begin with assetName : " + assetName
					+ " \t taxId : " + taxId);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		boolean flag = false;

		List<Boolean> resFlag = new ArrayList<Boolean>();
		List<Long> listAllTaxonomyNames = new ArrayList<Long>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("queryAIVDetailsForassociatedTaxonomyAction || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
			// List<AssetInstanceVersionTaxonomy> aivtList =
			// dao.getTaxonomydetailsByAssetANDTaxId(assetName, taxId, conn);

			associatedTaxId.clear();
			TaxonomyMaster t1 = new TaxonomyMaster();
			t1.setTaxonomyId(taxId);
			recurse1(t1, conn);
			Set<Long> hs = new HashSet<Long>();
			hs.addAll(associatedTaxId);
			associatedTaxId.clear();
			associatedTaxId.addAll(hs);
			List<AssetInstanceVersionTaxonomy> taxIdList = new ArrayList<AssetInstanceVersionTaxonomy>();
			List<AssetInstanceVersionTaxonomy> taxIdList1 = new ArrayList<AssetInstanceVersionTaxonomy>();

			for (int x = 0; x < associatedTaxId.size(); x++) {
				taxIdList = dao.getTaxonomydetailsByAssetANDTaxId(assetName, associatedTaxId.get(x), conn);
				taxIdList1.addAll(taxIdList);
			}

			for (AssetInstanceVersionTaxonomy tm : taxIdList1) {
				listAllTaxonomyNames.add(tm.getAivTaxonomyId());
			}

			retMsg = Constants.TAXONOMY_DATA_OBTAINED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			log.info("queryAIVDetailsForassociatedTaxonomyAction || taxonomy details fetched");

		} catch (RepoproException e) {
			log.error("queryAIVDetailsForassociatedTaxonomyAction || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("queryAIVDetailsForassociatedTaxonomyAction || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("queryAIVDetailsForassociatedTaxonomyAction || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("queryAIVDetailsForassociatedTaxonomyAction || end");
		}

		if (listAllTaxonomyNames.isEmpty()) {
			flag = false;
			resFlag.add(flag);
		} else {
			flag = true;
			resFlag.add(flag);
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(resFlag))).build();
	}

	void recurse1(TaxonomyMaster t, Connection conn) throws RepoproException {

		TaxonomiesDao tdao = new TaxonomiesDao();
		Connection conn1 = null;

		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("recurse1 || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			List<TaxonomyMaster> chldrn = tdao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);
			for (TaxonomyMaster a : chldrn) {
				TaxonomyMaster t1 = new TaxonomyMaster();
				t1.setTaxonomyId(a.getTaxonomyId());
				t1.setTaxonomyName(a.getTaxonomyName());
				recurse1(t1, conn);
				associatedTaxId.add(a.getTaxonomyId());
				associatedTaxId.add(t.getTaxonomyId());
			}
			associatedTaxId.add(t.getTaxonomyId());
		} catch (RepoproException e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());

		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally {
			if (log.isTraceEnabled()) {
				log.trace("recurse1 || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
	}


		


	/**
	 * @method getAssetInstanceVersionDetails
	 * @description to get asset instance version details
	 * @param assetInstVersionId
	 * @return success response
	 * @throws RepoproException
	 */

	@GET
	@Encoded
	@Path("/downloadfile/")
	public Response downloadFileForProperties(@QueryParam("assetInstverId") long assetInstverId,
			@QueryParam("staticValue") int staticValue, @QueryParam("assetName") String assetName,
			@QueryParam("assetParamName") String assetParamName) {

		if (log.isTraceEnabled()) {
			log.trace("downloadFileForProperties || begin :  ");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		ParameterValues pv = new ParameterValues();
		AssetParamDef apd = new AssetParamDef();
		AssetDao assetDao = new AssetDao();
		// byte b[];
		// byte[] blob;
		List<String> exportedFileLocation = new ArrayList<String>();
		String folder_Name = "DownloadFileFolder";

		try {
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetParamName = URLDecoder.decode(assetParamName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("downloadFileForProperties || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (staticValue == 1) {

				if (log.isTraceEnabled()) {
					log.trace(
							"downloadFileForProperties || dao method called : getParamIdForAssetAndParamName by assetName: "
									+ assetName + "and assetParamName " + assetParamName);
				}

				apd = assetDao.getParamIdForAssetAndParamName(assetName, assetParamName, conn);

			} else {

				if (log.isTraceEnabled()) {
					log.trace(
							"downloadFileForProperties || dao method called : getParameterForAssetInstParamAndVersionId by assetInstverId: "
									+ assetInstverId + "and assetParamName " + assetParamName);
				}

				pv = assetDao.getParameterForAssetInstParamAndVersionId(assetParamName, assetInstverId, conn);

			}

			// create source directory
			String srcFolder = "";
			String fileName = "";
			if (staticValue == 1) {
				srcFolder = System.getProperty("user.home") + "/" + folder_Name;
				fileName = apd.getFileName();
			} else {
				srcFolder = System.getProperty("user.home") + "/" + folder_Name;
				fileName = pv.getFileName();
			}

			File srcBaseFolderPath = new File(srcFolder);
			String filePath = "";
			// Base folder creation for an artifact
			if (!srcBaseFolderPath.exists()) {
				if (srcBaseFolderPath.mkdirs()) {
					filePath = srcBaseFolderPath.getAbsolutePath();
				} else {
					filePath = srcBaseFolderPath.getAbsolutePath();
				}
			} else {
				filePath = srcBaseFolderPath.getAbsolutePath();
			}

			// File file=new File(filePath);
			FileOutputStream outputStream = null;

			if (staticValue == 1) {
				if (apd.getStaticFileContent() != null) {
					outputStream = new FileOutputStream(filePath + "/" + fileName);

					outputStream.write(apd.getStaticFileContent());
				}
			} else {
				if (pv.getFileContent() != null) {
					outputStream = new FileOutputStream(filePath + "/" + fileName);

					outputStream.write(pv.getFileContent());

				}
			}

			outputStream.close();
			outputStream.flush();

			exportedFileLocation.add(fileName);

			conn.commit();
			if (log.isInfoEnabled()) {
				log.info(" downloadFileForProperties  || Downloaded files  ");
			}

			retStat = Status.OK;
			retMsg = Constants.DOWNLOAD_LOCATION_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("downloadFileForProperties || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("downloadFileForProperties || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("downloadFileForProperties || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("downloadFileForProperties || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(exportedFileLocation)))
				.build();

	}


	/*** Wrapper function ***/
	@GET
	@Path("/getAssetInstanceBrowseGridMain")
	public Response getAssetInstanceBrowseGridMain(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("from") int from) {
		log.trace("getAssetInstanceBrowseGridMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
        assetName = assetName.trim();
		userName = userName.trim();
		try {
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			AssetDao assetDao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceBrowseGridMain || dao method called : getAssetsByAssetName ");
			}
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			if (assetDef.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getAssetInstanceBrowseGridMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			response = this.getAssetInstanceBrowseGrid(userName, assetName, assetDef.getAssetId(), from,false);
			log.trace("getAssetInstanceBrowseGridMain || End");
			return response;
		
		} catch (RepoproException e) {
			log.error("getAssetInstanceBrowseGridMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceBrowseGridMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 

		log.trace("getAssetInstanceBrowseGridMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/*** Wrapper function ***//* THIS  API IS  FOR BROWSE GRID (SHOW MORE OPTION)
	@GET
	@Path("/getParametersDetailsForAssetInstanceVersionMain")
	public Response getParametersDetailsForAssetInstanceVersionMain(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("assetInstName") String assetInstName,
			@QueryParam("assetVersionName") String assetVersionName) {
		log.trace("getParametersDetailsForAssetInstanceVersionMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		try {
			
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";

			}
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetDao assetDao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getParametersDetailsForAssetInstanceVersionMain || dao method called : getAssetsByAssetName ");
			}
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			if (assetDef.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retMsg = Constants.NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getParametersDetailsForAssetInstanceVersionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			
			if (log.isTraceEnabled()) {
				log.trace("getParametersDetailsForAssetInstanceVersionMain || dao method called : getAssetsByAssetName ");
			}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, null);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getParametersDetailsForAssetInstanceVersionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
		
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			Boolean viewFlag = false;
			
			if (log.isTraceEnabled()) {
				log.trace("getParametersDetailsForAssetInstanceVersionMain || dao method called : retAivAccessRights ");
			}
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVersionId, userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getViewAccess()
						.equals(1L)) {
					viewFlag = true;
					break;
				}
			}

			if (viewFlag) {

				response = this.getParametersDetailsForAssetInstanceVersion(userName, assetName, assetDef.getAssetId(),
						assetInstanceVersionId);
				
				log.trace("getParametersDetailsForAssetInstanceVersionMain || End");
				return response;

			} else {

				retStat = Status.UNAUTHORIZED;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getParametersDetailsForAssetInstanceVersionMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
		} catch (RepoproException e) {
			log.error("getParametersDetailsForAssetInstanceVersionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getParametersDetailsForAssetInstanceVersionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 
		log.trace("getParametersDetailsForAssetInstanceVersionMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}*/

	

	/*** Wrapper function ***//* THIS API IS USED TO SEE LOCK TIME IN AIV PAGE AFTER GETTING LOCKED.
	@GET
	@Path("/retAssetInstanceVersionMain")
	public Response retAssetInstanceVersionMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstName") String assetInstName, @QueryParam("assetVersionName") String assetVersionName,
			@QueryParam("userName") String userName) {
		log.trace("getAssetInstanceVersionDetailsMain || Begin");
	
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		try {
			
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionDetailsMain || dao method called : getAssetInstanceVersion ");
			}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, null);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getAssetInstanceVersionDetailsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			long aivId = assetInstanceVer.getAssetInstVersionId();
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			Boolean viewFlag = false;
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionDetailsMain || dao method called : retAivAccessRights ");
			}
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aivId, userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getViewAccess()
						.equals(1L)) {
					viewFlag = true;
					break;
				}
			}

			if (viewFlag) {

				response = this.retAssetInstanceVersion(aivId, userName);
				log.trace("getAssetInstanceVersionDetailsMain || End");
				return response;

			} else {

				retStat = Status.UNAUTHORIZED;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getAssetInstanceVersionDetailsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}

		} catch (RepoproException e) {
			log.error("getAssetInstanceVersionDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceVersionDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}

		log.trace("getAssetInstanceVersionDetailsMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
*/
	
	

	
	/*** Wrapper function ***/
	@GET
	@Path("/retAssignedRelationshipMain")
	public Response retAssignedRelationshipMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstName") String assetInstName, @QueryParam("assetVersionName") String assetVersionName,
			@QueryParam("userName") String userName)
					 {
		log.trace("retAssignedRelationshipMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		try {
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersion aiv = new AssetInstanceVersion();
			 
			if (log.isTraceEnabled()) {
				log.trace("retAssignedRelationshipMain || dao method called : getAssetinstDetails ");
			}
		   aiv =  assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);
		 
		   if (aiv == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("retAssignedRelationshipMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
		   List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			
		    Boolean viewFlag = false;
		
			if (log.isTraceEnabled()) {
				log.trace("retAssignedRelationshipMain || dao method called : retAivAccessRights ");
			}
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aiv.getAssetInstVersionId(), userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getViewAccess()
						.equals(1L)) {
					viewFlag = true;
					break;
				}
			}

			if (viewFlag) {
				
				response = this.retAssignedRelationship(aiv.getAssetInstVersionId());
				log.trace("retAssignedRelationshipMain || End");
				return response;

			} else {

				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("retAssignedRelationshipMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}

		} catch (RepoproException e) {
			log.error("retAssignedRelationshipMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("retAssignedRelationshipMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}

		log.trace("retAssignedRelationshipMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/*** Wrapper function ***/
	@GET
	@Path("/retAvailableAssetRelationshipMain")
	public Response retAvailableAssetRelationshipMain(@QueryParam("srcAssetName") String srcAssetName,
			@QueryParam("destAssetName") String destAssetName, @QueryParam("srcAssetInstName") String srcAssetInstName,
			@QueryParam("userName") String userName) {
		log.trace("retAvailableAssetRelationshipMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		try {
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = new AssetDef();
			AssetDef ad1 = new AssetDef();
			AssetInstanceDao assetInstDao = new AssetInstanceDao();
			
			ad = assetDao.getAssetsByAssetName(srcAssetName, null);
			if (ad.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("retAvailableAssetRelationshipMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			ad1 = assetDao.getAssetsByAssetName(destAssetName, null);
			if (ad1.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("retAvailableAssetRelationshipMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			Long srcAssetInstId = assetInstDao.getAssetInstIdByName(srcAssetInstName, ad.getAssetId(), null);
			
			if (srcAssetInstId == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("retAvailableAssetRelationshipMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			  List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			 AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			    Boolean viewFlag = false;
			
				if (log.isTraceEnabled()) {
					log.trace("retAvailableAssetRelationshipMain || dao method called : retAivAccessRights ");
				}
				
				
				List<AssetInstanceVersion> versionList = new ArrayList<AssetInstanceVersion>();
				versionList = assetInstVersionDao.getAssetInstanceVersions(srcAssetInstId, null);

				for(AssetInstanceVersion versionName:versionList){
					long assetInstVersionId = versionName.getAssetInstVersionId();
					groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
					for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
						if (groupAssetInstVersionAccessList.get(i).getDeleteAccess().equals(1L)) {
							viewFlag = true;
							break;
						}
					}
				}
				
				if (viewFlag) {
					
					response = retAvailableAssetRelationship(ad.getAssetId(), ad1.getAssetId(), srcAssetInstId, userName);
					log.trace("retAvailableAssetRelationshipMain || End");
					return response;

				} else {

					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("retAvailableAssetRelationshipMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			
		} catch (RepoproException e) {
			log.error("getAssetInstanceForFilterMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceForFilterMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 

		log.trace("getAssetInstanceForFilterMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/*** Wrapper function ***/
	@GET
	@Path("/queryAIVDetailsForassociatedTaxonomyActionMain")
	public Response queryAIVDetailsForassociatedTaxonomyActionMain(@QueryParam("assetName") String assetName,
			@QueryParam("parentTaxonomyName") String parentTaxonomyName,
			@QueryParam("taxonomyName") String taxonomyName, @QueryParam("userName") String userName) {
		
		log.trace("queryAIVDetailsForassociatedTaxonomyActionMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		
		RoleDao roledao = new RoleDao();
		Role role = new Role();
		List<String> functionNamesList = null;
		List<String> functionIdsList = null;
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		User user = new User();
		UserDao userDao = new UserDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean assetFlag = false;
		boolean adminFlag = false;
		Long taxonomyId = null;
		try {
			if(!userName.equalsIgnoreCase("guest")){
				User userData = userDao.getUserIdByUserName(userName, null);
				if(userData.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
			if (log.isTraceEnabled()) {
				log.trace("queryAIVDetailsForassociatedTaxonomyActionMain || dao method called : getTaxonomyIdByName ");
			}
			Long parentTaxonomyId = taxonomiesDao.getTaxonomyIdByName(parentTaxonomyName,null);
			
			TaxonomyMaster childTaxonomyName = taxonomiesDao.getTaxonomyNameByParentId(taxonomyName, parentTaxonomyId, null);
			if(childTaxonomyName != null){
				taxonomyId = childTaxonomyName.getTaxonomyId();
			}
			//Long taxonomyId = taxonomiesDao.getTaxonomyIdByName(taxonomyName, null);
			if (taxonomyId == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.TAXONOMY_DATA_NOT_FOUND ;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("retAvailableAssetRelationshipMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			
			user = userDao.retProfileForUserName(userName, null);
			if(user.getUserId() == null){
				retStat = Status.UNAUTHORIZED;
				retMsg = Constants.USER_NOT_AUTHENTICATED;
				retScsFlr = Constants.NOT_AUTHENTICATED;
				retStatScsFlr = Constants.UNAUTHORIZED;
				return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, null);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), null);
			}
			
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_ASSETS")){
					assetFlag = true;
			        break;
				}
			}
			
			if(assetFlag || adminFlag){
				response = this.queryAIVDetailsForassociatedTaxonomyAction(assetName, taxonomyId);
				log.trace("queryAIVDetailsForassociatedTaxonomyActionMain || End");
				return response;
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			
		} catch (RepoproException e) {
			log.error("queryAIVDetailsForassociatedTaxonomyActionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("queryAIVDetailsForassociatedTaxonomyActionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 
		log.trace("queryAIVDetailsForassociatedTaxonomyActionMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	

	/**
	 * @method getChildNamesForAssetInstance
	 * @description to get child names for asset instance name
	 * @param assetInstVersionId
	 *            , assetId
	 * @return success response
	 * @throws RepoproException
	 */

	@GET
	@Encoded
	@Path("/getSiblingsOfChildAssetInstance")
	public Response getSiblingsOfChildAssetInstance(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstName") String assetInstName,@QueryParam("assetInstVerName") String assetInstVerName) {

		if (log.isTraceEnabled()) {
			log.trace("getSiblingsOfChildAssetInstance || begin  with assetNamev : " + assetName + " assetInstName :"
					+ assetInstName+"and assetInstVerName "+assetInstVerName);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		RelationshipDao relationshipDao = new RelationshipDao();
		ShowHideDao showHideDao = new ShowHideDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		Connection conn = null;
		List<AssetInstanceVersion> childInstNameList = new ArrayList<AssetInstanceVersion>();

		try {
			
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("getSiblingsOfChildAssetInstance || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace(
						"getSiblingsOfChildAssetInstance || dao method called : getSiblingsOfChildAssetInstance");
			}
			
			Long assetId = showHideDao.getAssetIdByAssetName(assetName, conn);
			
			boolean destFlag = false;
			List<AssetRelationshipDef> ardForDestAsset = relationshipDao.retAssetRelationshipDefByDestAssetId(assetId, conn);
			for(AssetRelationshipDef ard :ardForDestAsset ){
				if(ard.getFwdRelId() == 1L || ard.getFwdRelId() == 5L){
					destFlag = true;
					break;
				}
			}
			
			if(destFlag){
				childInstNameList = assetInstanceVersionDao.getSiblingsOfChildAssetInstance(assetName, assetInstName,assetInstVerName,conn);
			}
			
			if (log.isDebugEnabled()) {
				log.debug(" getSiblingsOfChildAssetInstance  || retrieved " + childInstNameList.toString()
						+ " siblings of child asset instance name  successfully");
			}

			retStat = Status.OK;
			retMsg = Constants.CHILD_NAMES_FOR_ASSET_INSTANCE_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getSiblingsOfChildAssetInstance || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getSiblingsOfChildAssetInstance || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getSiblingsOfChildAssetInstance || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getSiblingsOfChildAssetInstance || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(childInstNameList)))
				.build();

	}
	

	@PUT
	@Path("/updateParameterField/{userName}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public void updateAssetInstanceParameter1(AssetDef assetVo,@PathParam("userName") String userName)
			throws RepoproException {
		
		java.util.Date date= new java.util.Date();
		System.out.println("Upload Start Time : "+new Timestamp(date.getTime()));
		
		importCSV(assetVo,userName);
		
		java.util.Date date1 = new java.util.Date();
		System.out.println("Upload End Time : "+new Timestamp(date1.getTime()));
		
}
	
	
	public void importCSV(AssetDef assetVo , String userName){
		
		if (log.isTraceEnabled()) {
			log.trace("importCSV || Begin with username : " + userName +" and assetVo" +assetVo.toString());
		}
		AssetInstanceDao  assetInstance = new AssetInstanceDao();
		UserDao userDao = new UserDao();
		AssetDao assetDao = new AssetDao();
		User profile = new User();
		Connection conn = null;
		String paramName = "";
		try
		{
			if (log.isTraceEnabled()) {
				log.trace("importCSV || " + Constants.LOG_CONNECTION_OPEN);
			}

			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			if (log.isTraceEnabled()) {
				log.trace("importCSV || dao method called : getAllAssetInstancesWithLatestVersionsNativeQuery()");
			}
		List<AssetInstanceVersion> dbList = assetInstance.getAllAssetInstancesWithLatestVersionsNativeQuery(assetVo.getAssetName(),conn);
		List<AssetInstanceVersion> dbListCopy = dbList;
		
		if (log.isTraceEnabled()) {
			log.trace("importCSV || dao method called : retProfileForUserName()");
		}
	    profile = userDao.retProfileForUserName(userName,conn);
	
	    boolean namesMatched = false;
		for(int i=0;i<assetVo.getAssetInstances().size();i++)
		{ 
			namesMatched = false;
			
			for(int m=0;m<dbList.size();m++)
			{
			if(assetVo.getAssetInstances().get(i).getAssetInstName().equalsIgnoreCase(dbList.get(m).getAssetInstName()) && assetVo.getAssetInstances().get(i).getVersionName().equalsIgnoreCase(dbList.get(m).getVersionName()))
			{
			Parameter pvo = new Parameter();
			LinkedList<Category> categories = new LinkedList<Category>();
			LinkedList<Parameter> parameter = new LinkedList<Parameter>();
			String paramValue = (assetVo.getAssetInstances().get(i).getCategoryDetails().get(0)).getParameters1().get(0).getValue();
			Category cvo = new Category(); 
			AssetInstance assetInstance2 = new AssetInstance();
			
			paramName = (assetVo.getAssetInstances().get(i).getCategoryDetails().get(0)).getParameters1().get(0).getParamName();
			
			if (log.isTraceEnabled()) {
				log.trace("importCSV || dao method called : getParamIdForAssetAndParamName()");
			}
			AssetParamDef apd = assetDao.getParamIdForAssetAndParamName(
					assetVo.getAssetName(), paramName, conn);
			
			pvo.setDisplayOrder(apd.getDisplayPosition());
			pvo.setHasStaticValue(apd.isHasStaticValue());
			pvo.setAssetInstanceParamId(apd.getAssetParamId());
			pvo.setIsAdd(false);
			pvo.setIsSystemParam(apd.isSystemParam());
			pvo.setParamName(paramName);
			pvo.setQuickLink(apd.isQuickLink());
			pvo.setParamTypeId(apd.getParamTypeId());
			pvo.setListTypeParamTypeId(apd.getListTypeParamTypeId());
			pvo.setSize(apd.getSize());
			pvo.setUpdatedBy(userName);
			pvo.setValue(paramValue);
			pvo.setUpdatedTime(new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
			parameter.add(pvo);
			cvo.setParameters1(parameter);
			cvo.setDeleted(false);
		
			categories.add(cvo);
			assetInstance2.setCategoryDetails(categories);
			 this.updateAssetInstanceParameterHelper(userName,
					assetInstance2, assetVo.getAssetName(), dbList.get(m).getAssetInstName(),dbList.get(m).getVersionName(),conn);
			
				 dbListCopy.remove(m);
			     namesMatched = true;
		}
			if(namesMatched == true) {
				break;
			}
		}
		}
		
		if (log.isTraceEnabled()) {
			log.trace("importCSV || dao method called : getParamIdForAssetAndParamName()");
		}
		AssetParamDef apd1 = assetDao.getParamIdForAssetAndParamName(
				assetVo.getAssetName(), paramName, conn);
		
		
		for(int j=0;j<dbListCopy.size();j++)
		{
				Parameter pvo = new Parameter();
				LinkedList<Category> categories = new LinkedList<Category>();
				LinkedList<Parameter> parameter = new LinkedList<Parameter>();
				
				Category cvo = new Category(); 
				AssetInstance assetInstance2 = new AssetInstance();
				
				pvo.setDisplayOrder(apd1.getDisplayPosition());
				pvo.setHasStaticValue(apd1.isHasStaticValue());
				pvo.setAssetInstanceParamId(apd1.getAssetParamId());
				pvo.setIsAdd(false);
				pvo.setIsSystemParam(apd1.isSystemParam());
				pvo.setParamName(paramName);
				pvo.setQuickLink(apd1.isQuickLink());
				pvo.setParamTypeId(apd1.getParamTypeId());
				pvo.setListTypeParamTypeId(apd1.getListTypeParamTypeId());
				pvo.setSize(apd1.getSize());
				pvo.setUpdatedBy(userName);
				pvo.setValue("0");
				pvo.setUpdatedTime(new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
				parameter.add(pvo);
				cvo.setParameters1(parameter);
				cvo.setDeleted(false);
				
				categories.add(cvo);
				assetInstance2.setCategoryDetails(categories);
				this.updateAssetInstanceParameterHelper(userName,
						assetInstance2, assetVo.getAssetName(), dbList.get(j).getAssetInstName(),dbList.get(j).getVersionName(),conn);
			
		}
		
        System.out.println("All done");
    	
        String errStr = "CSV file has been imported successfully for the "+paramName+" parameter in "+assetVo.getAssetName()+" Asset!";
		
		MailTemplateDao mailDao = new MailTemplateDao();
		if (log.isTraceEnabled()) {
			log.trace("importCSV || dao method called : getMailConfig()");
		}
		MailConfig mailConfig = mailDao.getMailConfig(conn);
        SendEmail.sendTextMail(mailConfig, profile.getEmailId(),
				MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
				MessageUtil.getMessage(Constants.EMAIL_HDR) + errStr + "\n"
						+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
        conn.commit();
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			try {
				MailTemplateDao mailDao = new MailTemplateDao();
				MailConfig mailConfig;
				if (log.isTraceEnabled()) {
					log.trace("importCSV || dao method called : getMailConfig()");
				}
				mailConfig = mailDao.getMailConfig(conn);
				String errStr = "Error has been occured while importing CSV file for the "+paramName+" parameter in "+assetVo.getAssetName()+" Asset!";
				try {
					SendEmail.sendTextMail(mailConfig, profile.getEmailId(),
							MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
							MessageUtil.getMessage(Constants.EMAIL_HDR) + errStr + "\n"
									+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		}
	    finally {
				if (log.isTraceEnabled()) {
						log.trace("importCSV || " + Constants.LOG_CONNECTION_CLOSE);
					}
					DBConnection.closeDbConnection(conn);
				}
		if (log.isTraceEnabled()) {
			log.trace("importCSV || End");
		}
		}
	
	// import csv application
public void updateAssetInstanceParameterHelper(String userName,AssetInstance assetInstance ,String assetName, String assetInstName ,String versionName,Connection conn) throws RepoproException
 {

	    if (log.isTraceEnabled()) {
		log.trace("updateAssetInstanceParameterHelper || begin");
	    }
		Connection conn1 = null;

		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceParameterHelper : "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			String newParamDataForRevision = "";
			int countForCategory = 1, countForParam = 1;
			int paramCount = 0;
			String categoryName = null;
			List<Parameter> params;
			User user = new User();
			UserDao userDao = new UserDao();
			AssetInstanceVersion aiv = new AssetInstanceVersion();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			SubscriptionDao subscriptionDao = new SubscriptionDao();
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			GamificationDao gamificationDao = new GamificationDao();
			String action = Constants.ACTIVITY_MODIFY;
			AssetInstanceVersion aiv1 = new AssetInstanceVersion();
			GamificationDetails gamePoint = new GamificationDetails();
			
			
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceParameterHelper || called dao method : retProfileForUserName() by : userName "
						+ userName);
			}
			user = userDao.retProfileForUserName(userName, conn);

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceParameterHelper: call dao getAssetinstDetails() method");
			}

			aiv = assetInstanceVersionDao.getAssetinstDetails(assetName,
					assetInstName, versionName, conn);
			Long aivId = aiv.getAssetInstVersionId();

			for (Object category : assetInstance.getCategoryDetails()) {
				categoryName = ((Category) category).getCategoryName();
				params = ((Category) category).getParameters1();
				paramCount = paramCount + params.size();

				for (Parameter paramobj : params) {
					AssetInstanceVersion param = new AssetInstanceVersion();

					param.setAssetName(assetName);
					param.setAssetInstVersionId(aivId);
					param.setParamTypeId(paramobj.getParamTypeId());
					param.setAssetParamName(paramobj.getParamName());
					param.setParamValue(paramobj.getValue());
					param.setAssetParamId(paramobj.getAssetInstanceParamId());
					if (paramobj.getHasStaticValue() == true) {
						param.setIsStatic(1);
					} else {
						param.setIsStatic(0);
					}

				
					if (param.getParamTypeId() == (Constants.FILE_TYPE)) {/*

                     String NewFileName = null;
					 String oldFileName = null;
					 NameValue nv = null;

						FormDataBodyPart dataMultiPart = null;

						if (bodyParts != null) {

							dataMultiPart = bodyParts.getField("uploadedFile_" + param.getAssetParamId());
							NewFileName = dataMultiPart.getContentDisposition().getFileName();

							paramValue.setImage(dataMultiPart.getEntityAs(InputStream.class));
							paramValue.setFileName(dataMultiPart.getContentDisposition().getFileName());
							
							paramValue.setFileMimeType(new MimetypesFileTypeMap().getContentType(dataMultiPart.getContentDisposition().getFileName()));
							
						}

						if (NewFileName == null || NewFileName.length() == 0) {
							oldFileName = param.getFileName();
						} else {
							oldFileName = NewFileName;
						}

						param.setNewFileName(paramValue.getFileName());

						if (!userName.equals("admin") && activeFlag == 1) {

							if (log.isTraceEnabled()) {
								log.trace(
										"updateAssetInstancePropertiesDetails || called dao method : getParameterForAssetInstParamAndVersionId() by : assetInstanceVersionId "
												+ aivId + "and AssetParamName " + param.getAssetParamName());
							}
							pv = assetDao.getParameterForAssetInstParamAndVersionId(param.getAssetParamName(), aivId,
									conn);

							if (pv != null) {
								if (pv.getFileName() != null && oldFileName.length() != 0) {
									if (!pv.getFileName().equals(oldFileName) && (pv.isImportant() == true)) {

										flag = true;
										gamePoint.setField("Parameter - " + param.getAssetParamName());
										gamePoint.setAction("Updated");

									}
								}
							} else {

								if (log.isTraceEnabled()) {
									log.trace(
											"updateAssetInstancePropertiesDetails || called dao method : getParamIdForAssetAndParamName() by : assetName "
													+ assetName + "and AssetParamName " + param.getAssetParamName());
								}

								AssetParamDef apd = assetDao.getParamIdForAssetAndParamName(assetName,
										param.getAssetParamName(), conn);

								if (oldFileName.length() != 0 && apd.isHasImportantValue() == true) {

									flag = true;
									gamePoint.setField("Parameter - " + param.getAssetParamName());
									gamePoint.setAction("Created");

								}
							}
						}

						if (!NewFileName.isEmpty() || NewFileName.length() != 0) {

							fileText = paramValue.getFileName();

						} else if (param.getFileName() != null
						 || !param.getFileName().isEmpty() ) {
							fileText = param.getFileName();
						} else {
							fileText = " ";
						}

						if (countForParam == paramCount) {
							if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
								newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
										+ fileText;

							}
						} else {
							if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
								newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
										+ fileText + Constants.APPEND_STRING;

							}
						}

						// db

						Boolean UpdateFileinDB = true;
						if (NewFileName.length() == 0 && param.getFileName().length() != 0) {
							UpdateFileinDB = false;
						}
						if (UpdateFileinDB) {
							if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {

								if (log.isTraceEnabled()) {
									log.trace(
											"updateAssetInstancePropertiesDetails || called helper method : updateParameterForAssetInst() : to update parameter");

									paramValue.setName(param.getAssetParamName());

									updateParameterForAssetInst(param, paramValue, userId, conn);

								}
							}
						}

						// folder

						if (!NewFileName.isEmpty() || NewFileName.length() != 0) {

							InputStream image1 = null;
							String NewFile = null;

							image1 = (dataMultiPart.getEntityAs(InputStream.class));
							NewFile = dataMultiPart.getContentDisposition().getFileName();

							if (log.isTraceEnabled()) {
								log.trace(
										"updateAssetInstancePropertiesDetails || called helper method : getNameValue()");
							}

							getNameValue(param, image1, NewFile, context, conn);

						}

					*/}// filetype
					else {

				   if (countForCategory == assetInstance.getCategoryDetails().size() && countForParam == paramCount) {
						 if (param.getParamValue() != null) {
						          newParamDataForRevision = newParamDataForRevision+ param.getAssetParamName()+ ":"+ param.getParamValue();
							}
						else {
							     newParamDataForRevision = newParamDataForRevision+ param.getAssetParamName() + ":";
							}
						} else  {
						    if (param.getParamValue() != null) {
							 newParamDataForRevision = newParamDataForRevision+ param.getAssetParamName()+ ":"+ param.getParamValue()+ Constants.APPEND_STRING;

							} else {
								  newParamDataForRevision = newParamDataForRevision + param.getAssetParamName()	+ ":"+ Constants.APPEND_STRING;
							}
						}
						
						if (log.isTraceEnabled()) {
								log.trace("updateAssetInstanceParameterHelper || called helper method : updateParameterForAssetInst() : to update parameter");
							}

						updateParameterForAssetInstImportCsv(param, null,
									user.getUserId(), conn);

					}
					countForParam++;
				}
				countForCategory++;
			}

			// updateAivUpdatedOn

			aiv1.setVersionName(aiv.getVersionName());
			aiv1.setUpdatedOn(new Timestamp(Calendar.getInstance()
					.getTimeInMillis()));

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceParameterHelper || called dao method : updateAivUpdatedOn() by AssetInstanceVersionId: "
						+ aivId + "and" + aiv1.toString());
			}
			assetInstanceVersionDao.updateAivUpdatedOn(aiv1, aivId, conn);

			// addRevisionData

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceParameterHelper || called helper method : addRevisionData() : to add revision data");
			}

			addRevisionData("P", aivId, aiv.getVersionName(), null, null,
					newParamDataForRevision, null, userName, user.getUserId(),
					null,conn);

			// mail template
			try {

				List<String> emailIds = subscriptionDao
						.getAllSubscriptionsByAssetInstanceId(
								aiv.getAssetInstanceId(), conn);
				MailTemplateDao mailDao = new MailTemplateDao();
				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				MailConfig mailConfig = mailDao.getMailConfig(conn);
				String mailTemp = null;

				if (aiv.getVersionable() == true) {

					MailTemplate mtVo = mailTemplateDao
							.retMailTemplateByTextName(conn,
									"updatePropertiesForVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = aiv.getAssetInstName()
							.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName)
							.replaceAll("%versionName%", aiv.getVersionName());

				} else {

					MailTemplate mtVo = mailTemplateDao
							.retMailTemplateByTextName(conn,
									"updatePropertiesForNonVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = aiv.getAssetInstName()
							.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
				}

				if (emailIds != null) {
					for (String emailId : emailIds) {
						if (aiv.getVersionable() == true) {

							SendEmail
									.sendTextMail(
											mailConfig,
											emailId,
											MessageUtil
													.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
											MessageUtil
													.getMessage(Constants.EMAIL_HDR)
													+ mailTemp
													+ "\n"
													+ MessageUtil
															.getMessage(Constants.EMAIL_NOTE));
						} else {

							SendEmail
									.sendTextMail(
											mailConfig,
											emailId,
											MessageUtil
													.getMessage(Constants.REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE),
											MessageUtil
													.getMessage(Constants.EMAIL_HDR)
													+ mailTemp
													+ "\n"
													+ MessageUtil
															.getMessage(Constants.EMAIL_NOTE));

						}
					}

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			// addRecentActivity

			RecentActivity recentActivity = new RecentActivity();
			recentActivity.setActivityTimestamp(new Timestamp(Calendar
					.getInstance().getTimeInMillis()));
			recentActivity.setAssetId(String.valueOf(aiv.getAssetId()));
			recentActivity.setAssetInstVersionId(String.valueOf(aivId));
			recentActivity.setUser_id(user.getUserId());

			if (aiv.getVersionable() == true) {
				recentActivity.setDescription(user.getFullName() + ";" + action
						+ ";" + assetName + ";" + aiv.getAssetInstName() + ";"
						+ "version" + aiv.getVersionName());

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceParameterHelper || dao method called : addRecentActivity() : "
							+ recentActivity.toString());
				}

				recentActivityDao.addRecentActivity(recentActivity, conn);
			} else {
				recentActivity.setDescription(user.getFullName() + ";" + action
						+ ";" + assetName + ";" + aiv.getAssetInstName());

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceParameterHelper || dao method called : addRecentActivity() : "
							+ recentActivity.toString());
				}

				recentActivityDao.addRecentActivity(recentActivity, conn);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceParameterHelper : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceParameterHelper || End");
		}
	}

	/**
	 * @method filterBrowseGrid
	 * @description to filter browse grid
	 * @param key
	 * @param value
	 * @param assetName
	 * @param userName
	 * @param assetId
	 * @param from
	 * @return
	 */
	@Encoded
	@GET
	@Path("/filterBrowseGrid")
	public Response filterBrowseGrid(@QueryParam("value") String values, 
			@QueryParam("assetName") String assetname,@QueryParam("userName") String userName,
			@QueryParam("assetId") Long assetId, @QueryParam("from") int from) {

		if (log.isTraceEnabled()) {
			log.trace("filterBrowseGrid || Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;

		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<AssetInstanceVersion> assetInstVerList = new ArrayList<AssetInstanceVersion>();
		List<AssetInstance> listOfAssetInstanceVos = new ArrayList<AssetInstance>();

		User user = null;
		UserDao userDao = new UserDao();

		try {
			String actualvalue = URLDecoder.decode(values, "UTF-8");
			String assetName = URLDecoder.decode(assetname, "UTF-8");
			String value = actualvalue;
			if (actualvalue.contains("_")||actualvalue.contains("%")||actualvalue.contains("\\")|| actualvalue.contains("-")){
				value = actualvalue;
				value = value.replace("\\", "\\\\");
				value = value.replace("_", "\\_");
				value = value.replace("%", "\\%");
				
				
			}else{
				value = actualvalue;
			}

			if (log.isTraceEnabled()) {
				log.trace("filterBrowseGrid || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			ShowHideManager shd = new ShowHideManager();
			ShowHideColumn hideColumn = new ShowHideColumn();
			hideColumn.setAssetId(assetId);
			if (!userName.equalsIgnoreCase("roleAnonymous")) {
				user = userDao.retProfileForUserName(userName, conn);
				hideColumn.setUserId(user.getUserId());
			}

			if (log.isTraceEnabled()) {
				log.trace("filterBrowseGrid || dao method called : getShowHideParams(assetId,UserId)");
			}
			ShowHideColumn shc = shd.getShowHideParamValues(hideColumn, userName, conn);

			java.util.Map<Long, String> hideParameters = shc.getShowParamDetails();
			int showHideParamCount = hideParameters.size();
			String assetParamName = new String();
			@SuppressWarnings("rawtypes")
			Iterator itr = hideParameters.entrySet().iterator();
			while (itr.hasNext()) {
				@SuppressWarnings("rawtypes")
				java.util.Map.Entry pair = (java.util.Map.Entry) itr.next();
				assetParamName = assetParamName.concat(pair.getValue().toString() + ",");
			}
			
			if (assetParamName.length() != 0) {
				// non static and static information
				String[] paramNames = assetParamName.split(",");
				StringBuffer sb = new StringBuffer();
				int sizeOfParameters = 0;

				for (int i = 0; i < paramNames.length; i++) {
					sizeOfParameters = i;
					sb.append(paramNames[i] + ",");
					if (i == 2) {
						break;
					}
				}
				StringBuffer staticParameters = new StringBuffer();
				StringBuffer nonStaticParameters = new StringBuffer();
				int paramCount = sizeOfParameters;
				paramCount = paramCount + 1;
				int maximumParamCount = 0;
				for (int i = 0; i < paramNames.length; i++) {
					String paramName = paramNames[i];
					if (log.isTraceEnabled()) {
						log.trace(
								"filterBrowseGrid || dao method called : getAssetParamDefByAssetNameAndParamName(assetName,paramName)");
					}
					AssetParamDef paramdef = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(assetName,
							paramName, conn);
					if (paramdef.getIs_static() != 1) {// non-static
						nonStaticParameters.append(paramdef.getAssetParamName() + ",");
					} else {
						staticParameters.append(paramdef.getAssetParamName() + ",");
					}
					maximumParamCount++;
					if (maximumParamCount == 3)
						break;
				}

				List<AssetInstanceVersion> listofStaticInformation = null;
				List<AssetInstanceVersion> listofNonStaticInformation = null;

				if (nonStaticParameters.length() != 0) {
					nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length() - 1);
				}
				if (staticParameters.length() != 0) {
					staticParameters = staticParameters.deleteCharAt(staticParameters.length() - 1);
				}

				if (nonStaticParameters.length() != 0) {
					if (log.isTraceEnabled()) {
						log.trace(
								"filterBrowseGrid || dao method called : getAssetParamDefsByParameters(parameters,assetName)");
					}
					List<AssetParamDef> listOfNonStaticParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(nonStaticParameters.toString(), assetName, conn);

					if (log.isTraceEnabled()) {
						log.trace(
								"filterBrowseGrid || dao method called : getAssetInstanceVersionDetailsWithNonStaticParametersForFilter(assetName,parameters)");
					}
					listofNonStaticInformation = assetInstanceVersionDao
							.getAssetInstanceVersionDetailsWithNonStaticParametersForFilter(assetName,
									nonStaticParameters.toString(), userName,value , from, conn);
					TreeMap<String, String> paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);

					Long newAssetInstVersionId = 0L;
					int jj = 1;
					for (int i = 0; i < listofNonStaticInformation.size(); i++) {
						AssetInstanceVersion aiv = listofNonStaticInformation.get(i);
						newAssetInstVersionId = aiv.getAssetInstVersionId();
						boolean flag = false;
						AssetInstance vo = new AssetInstance();
						vo.setAssetInstId(aiv.getAssetInstanceId());
						vo.setAssetInstName(aiv.getAssetInstName());
						vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
						vo.setDescription(aiv.getDescription());
						vo.setVersionName(aiv.getVersionName());
						vo.setVersionable(aiv.getVersionable());
						vo.setIconImageName(aiv.getIconImageName());
						vo.setEditAccessFlag(aiv.isEditAccessFlag());
						vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
						vo.setShowHideParamCount(showHideParamCount);
						vo.setParamTypeId(aiv.getParamTypeId());
						vo.setRTFwithTags(aiv.getRTFwithTags());
						vo.setTextDataList(aiv.getTextDataList());
						vo.setHasArray(aiv.getHasArray());
						vo.setLdapMappingValues(aiv.getLdapMappingValue());
						vo.setLdapMappingCount(aiv.getLdapMappingListCount());
						
						// }
						for (int j = 0; j < listOfNonStaticParamDefs.size(); j++) {
							AssetParamDef apd = listOfNonStaticParamDefs.get(j);
							if (aiv.getAssetParamName() != null) {
								if (aiv.getAssetParamName().equalsIgnoreCase(apd.getAssetParamName())) {
									flag = true;

									if (apd.getParamTypeId() == 3) {
										paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									} else {
										if (apd.getParamTypeId() == 5) {
											paramValues.put(apd.getAssetParamName(),
													"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										} else if (apd.getParamTypeId() == 6) {
											paramValues.put(apd.getAssetParamName(),
													"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										} else if (apd.getParamTypeId() == 8) {
											paramValues.put(apd.getAssetParamName(),
													"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										}
										else if(apd.getParamTypeId() == 7){
											if(apd.getHasArray() == 1){
												String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
												paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else if(apd.getHasArray() == 0){
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											
										}else if(apd.getParamTypeId() == 1){
											if(apd.getHasArray() == 1){
												String textData = StringUtils.join(aiv.getTextDataList(), "~~");
												paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else if(apd.getHasArray() == 0){
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											
										}else if(apd.getParamTypeId() == 9){
											String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
											paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
										
										else {
											// user =
											// userDao.retProfiledetailsForUserName(aiv.getParamValue(),
											// conn);
											/*
											 * user = userDao.
											 * retProfiledetailsForUserName(
											 * userName, conn); if(user !=
											 * null){
											 * if(user.getActiveFlag().equals(
											 * "1")){ paramValues.put(apd.
											 * getAssetParamName(),
											 * aiv.getParamValue()); }else{
											 * paramValues.put(apd.
											 * getAssetParamName(), ""); } }
											 */
											paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
									}
									if (flag) {
										vo.setParamNameWithValues(paramValues);
										break;
									}
								}
							} else {
								if (apd.getParamTypeId() == 3) {
									if(aiv.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
								} else {
									if (apd.getParamTypeId() == 5) {
										paramValues.put(apd.getAssetParamName(), "^^DA^^~" + aiv.getAssetInstVersionId()
												+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									} else if (apd.getParamTypeId() == 6) {
										paramValues.put(apd.getAssetParamName(), "^^DC^^~" + aiv.getAssetInstVersionId()
												+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									} else if (apd.getParamTypeId() == 8) {
										paramValues.put(apd.getAssetParamName(), "^^AC^^~" + aiv.getAssetInstVersionId()
										+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
									else if(apd.getParamTypeId() == 7){
										if(apd.getHasArray() == 1){
											String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
											if(rtfTags == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
										}else if(apd.getHasArray() == 0){
											if( aiv.getParamValue() == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
										}
									}else if(apd.getParamTypeId() == 1){
										if(apd.getHasArray() == 1){
											String textData = StringUtils.join(aiv.getTextDataList(), "~~");
											if( textData == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
										}else if(apd.getHasArray() == 0){
											if(aiv.getParamValue() == null) {
												paramValues.put(apd.getAssetParamName(),"`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
										}
									}else if(apd.getParamTypeId() == 9){
										String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
										if(ldapData == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}else{
											paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
									}
									
									else {
										if(aiv.getParamValue() == null) {
											paramValues.put(apd.getAssetParamName(),"`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}else{
											paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
									}
								}
								vo.setParamNameWithValues(paramValues);
							}

						}
						Map<String, String> finalValues = vo.getParamNameWithValues();

						for (AssetParamDef assetParamDef : listOfNonStaticParamDefs) {
							boolean flag1 = false;
							for (Map.Entry<String, String> map : finalValues.entrySet()) {

								if (assetParamDef.getAssetParamName().equalsIgnoreCase(map.getKey())) {
									flag1 = true;
									break;
								}
							}
							if (!flag1) {
								if (assetParamDef.getParamTypeId() == 3) {
									if(assetParamDef.getFileName() == null) {
										paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
									}else{
										paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getFileName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
									}
								} else {
									if (assetParamDef.getParamTypeId() == 5) {
										paramValues.put(assetParamDef.getAssetParamName(),
												"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
									} else if (assetParamDef.getParamTypeId() == 6) {
										paramValues.put(assetParamDef.getAssetParamName(),
												"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
									} else if (assetParamDef.getParamTypeId() == 8) {
										paramValues.put(assetParamDef.getAssetParamName(),
												"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
														+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
									}
									else if(assetParamDef.getParamTypeId() == 7){
										if(assetParamDef.getHasArray() == 1){
											//String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else{
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
										}else if (assetParamDef.getHasArray() == 0){
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else{
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
										}
									}else if(assetParamDef.getParamTypeId() == 1){
										if(assetParamDef.getHasArray() == 1){
											//String textData = StringUtils.join(aiv.getTextDataList(), "~~");
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else{
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
										}else if(assetParamDef.getHasArray() == 0){
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}else{
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
											}
										}
									}else if(assetParamDef.getParamTypeId() == 9){
										//String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
										if(assetParamDef.getParamValue() == null) {
											paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}else{
											paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}
									}else {
										if(assetParamDef.getParamValue() == null) {
											paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}else{
											paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
										}
									}
								}
								vo.setParamNameWithValues(paramValues);
							}
						}
						if (i < listofNonStaticInformation.size() - 1) {
							if (!newAssetInstVersionId
									.equals(listofNonStaticInformation.get(jj).getAssetInstVersionId())) {
								listOfAssetInstanceVos.add(vo);
								paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
							}

						} else {
							listOfAssetInstanceVos.add(vo);
						}
						jj++;
					}

				}
				if (staticParameters.length() != 0) {
					// static information
					TreeMap<String, String> paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceBrowseGrid || dao method called : getAssetParamDefsByParameters(staticParameters,assetName)");
					}
					List<AssetParamDef> listOfStaticParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(staticParameters.toString(), assetName, conn);
					if (log.isTraceEnabled()) {
						log.trace(
								"getAssetInstanceBrowseGrid || dao method called : getAssetInstanceVersionDetailsWithStaticParameters(assetName,userName,from)");
					}
					listofStaticInformation = assetInstanceVersionDao
							.getAssetInstanceVersionDetailsWithStaticParametersForFilter(assetName, userName,value,from, conn);
					if (nonStaticParameters.length() != 0) {
						AssetInstance vo = new AssetInstance();
						for (int i = 0; i < listOfAssetInstanceVos.size(); i++) {

							AssetInstance aivo = listOfAssetInstanceVos.get(i);
							for (int k = 0; k < listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if (apd.getParamTypeId() == 3) {
									if(apd.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
								} else {
									if(apd.getStaticValue() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}
								}
							}
							java.util.Map<String, String> map = aivo.getParamNameWithValues();
							if (map != null) {
								map.putAll(paramValues);
								aivo.setParamNameWithValues(map);
								listOfAssetInstanceVos.set(i, aivo);
							} else {
								aivo.setParamNameWithValues(paramValues);
								listOfAssetInstanceVos.set(i, aivo);
							}
						}
						paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					} else {
						for (int j = 0; j < listofStaticInformation.size(); j++) {
							AssetInstance vo = new AssetInstance();
							AssetInstanceVersion aiv = listofStaticInformation.get(j);
							for (int k = 0; k < listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if (apd.getParamTypeId() == 3) {
									if(apd.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
								} else {
									if(apd.getStaticValue() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}
								}
							}
							vo.setAssetInstId(aiv.getAssetInstanceId());
							vo.setAssetInstName(aiv.getAssetInstName());
							vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
							vo.setDescription(aiv.getDescription());
							vo.setVersionName(aiv.getVersionName());
							sizeOfParameters = sizeOfParameters + paramCount;
							vo.setParamNameWithValues(paramValues);
							vo.setVersionable(aiv.getVersionable());
							vo.setIconImageName(aiv.getIconImageName());
							vo.setEditAccessFlag(aiv.isEditAccessFlag());
							vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
							vo.setShowHideParamCount(showHideParamCount);
							vo.setParamTypeId(aiv.getParamTypeId());
							vo.setRTFwithTags(aiv.getRTFwithTags());
							vo.setTextDataList(aiv.getTextDataList());
							listOfAssetInstanceVos.add(vo);
							paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
						}
					}
				}
			} else {
				// getBasic information
				if (log.isTraceEnabled()) {
					log.trace("filterBrowseGrid || dao method called : getAssetInstanceDetailsWithOutParametersForFilter(assetName, userName, from, conn)");
				}
				List<AssetInstanceVersion> basicInformationOfassetInstance = assetInstanceVersionDao
						.getAssetInstanceDetailsWithOutParametersForFilter(assetName, userName,value, from, conn);

				for (int i = 0; i < basicInformationOfassetInstance.size(); i++) {
					AssetInstanceVersion aiv = basicInformationOfassetInstance.get(i);
					AssetInstance vo = new AssetInstance();
					vo.setAssetInstId(aiv.getAssetInstanceId());
					vo.setAssetInstName(aiv.getAssetInstName());
					vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
					vo.setDescription(aiv.getDescription());
					vo.setVersionName(aiv.getVersionName());
					vo.setVersionable(aiv.getVersionable());
					vo.setIconImageName(aiv.getIconImageName());
					vo.setEditAccessFlag(aiv.isEditAccessFlag());
					vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
					vo.setShowHideParamCount(showHideParamCount);
					listOfAssetInstanceVos.add(vo);
				}
			}

			Collections.sort(listOfAssetInstanceVos, new AssetInstance());

			if (log.isDebugEnabled()) {
				log.debug("filterBrowseGrid || " + assetInstVerList.toString());
			}
			log.debug(" filterBrowseGrid  || retrieved " + assetInstVerList.size()
					+ " asset instance version details by asset name : " + assetName.toString());

			if(listOfAssetInstanceVos.size() == 0){
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("filterBrowseGrid || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("filterBrowseGrid || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterBrowseGrid || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("filterBrowseGrid || " + assetInstVerList.toString() + " || exit");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(listOfAssetInstanceVos)))
				.build();

	}
	/**
	 * @method filterForGetAssetInstanceForFilter
	 * @description to filter the filter data 
	 * @param userName
	 * @param assetName
	 * @param assetId
	 * @param operators
	 * @param assetParamNames
	 * @param param1Values
	 * @param param2Values
	 * @param logicalSelect
	 * @param taxonomyNames
	 * @param key
	 * @param value
	 * @param from
	 * @return success response
	 */
	@GET
	@Encoded
	@Path("/filterSearch")
	public Response filterForGetAssetInstanceForFilter(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("assetId") Long assetId,
			@QueryParam("operators") String operators, @QueryParam("assetParamNames") String assetParamNames,
			@QueryParam("param1Values") String param1Values, @QueryParam("param2Values") String param2Values,
			@QueryParam("logicalSelect") String logicalSelect, @QueryParam("taxonomyNames") String taxonomyNames,
			@QueryParam("value") String values,
			@QueryParam("from") int from){

		if (log.isTraceEnabled()) {
			log.trace("filterForGetAssetInstanceForFilter || begin with userName : " + userName + " assetName :" + assetName
					+ " assetId:" + assetId + " operators:" + operators + " assetParamNames:" + assetParamNames
					+ " param1Values:" + param1Values + " param2Values:" + param2Values + " logicalSelect:"
					+ logicalSelect + " taxonomyNames:" + taxonomyNames +" value:"+values+ "from:" + from);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;

		boolean propertiesFlag = true;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<AssetInstance> listOfAssetInstanceVos = new ArrayList<AssetInstance>();
		try {
			param1Values = URLDecoder.decode(param1Values, "UTF-8");
			param2Values = URLDecoder.decode(param2Values, "UTF-8");
			operators = URLDecoder.decode(operators, "UTF-8");
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetParamNames = URLDecoder.decode(assetParamNames, "UTF-8");
			String actualvalue = URLDecoder.decode(values, "UTF-8");
			String value = actualvalue;
			if (actualvalue.contains("_")||actualvalue.contains("%")||actualvalue.contains("\\")){
				value = actualvalue;
				value = value.replace("\\", "\\\\\\\\");
				//value = value.replace("_", "\\_");
				//value = value.replace("%", "\\%");
			}else{
				value = actualvalue;
			}

			if (log.isTraceEnabled()) {
				log.trace("filterForGetAssetInstanceForFilter || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			ShowHideManager shd = new ShowHideManager();
			ShowHideColumn hideColumn = new ShowHideColumn();
			hideColumn.setAssetId(assetId);
			if (!userName.equalsIgnoreCase("roleAnonymous")) {
				UserDao userDao = new UserDao();
				User user = userDao.retProfileForUserName(userName, conn);
				hideColumn.setUserId(user.getUserId());
			}
			if (log.isTraceEnabled()) {
				log.trace("filterForGetAssetInstanceForFilter || dao method called : getShowHideParams(assetId,UserId)");
			}
			ShowHideColumn shc = shd.getShowHideParamValues(hideColumn, userName, conn);
			java.util.Map<Long, String> hideParameters = shc.getShowParamDetails();
			@SuppressWarnings("unused")
			int showHideParamCount = hideParameters.size();
			String showHideAssetParamName = new String();
			@SuppressWarnings("rawtypes")
			Iterator itr = hideParameters.entrySet().iterator();
			while (itr.hasNext()) {
				@SuppressWarnings("rawtypes")
				java.util.Map.Entry pair = (java.util.Map.Entry) itr.next();
				showHideAssetParamName = showHideAssetParamName.concat(pair.getValue().toString() + ",");
			}
			
			if (showHideAssetParamName.length() != 0) {
				// non static and static information
				String[] paramNames = showHideAssetParamName.split(",");
				StringBuffer sb = new StringBuffer();
				int sizeOfParameters = 0;
				for (int i = 0; i < paramNames.length; i++) {
					sizeOfParameters = i;
					sb.append(paramNames[i] + ",");
					if (i == 2) {
						break;
					}
				}
				sb = sb.deleteCharAt(sb.length() - 1);
				StringBuffer staticParameters = new StringBuffer();
				StringBuffer nonStaticParameters = new StringBuffer();
				int paramCount = sizeOfParameters;
				paramCount = paramCount + 1;
				int maximumParamCount = 0;
				for (int i = 0; i < paramNames.length; i++) {
					String paramName = paramNames[i];
					if (log.isTraceEnabled()) {
						log.trace("filterForGetAssetInstanceForFilter || dao method called : getAssetParamDefByAssetNameAndParamName(assetName,paramName)");
					}
					AssetParamDef paramdef = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(assetName,
							paramName, conn);
					if (paramdef.getIs_static() != 1) {// non-static
						nonStaticParameters.append(paramdef.getAssetParamName() + ",");
					} else {
						staticParameters.append(paramdef.getAssetParamName() + ",");
					}
					maximumParamCount++;
					if (maximumParamCount == 3)
						break;
				}
				List<AssetInstanceVersion> listofFilterInformation = null;
				
				if (nonStaticParameters.length() != 0) {
					nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length() - 1);
				}
				if (staticParameters.length() != 0) {
					staticParameters = staticParameters.deleteCharAt(staticParameters.length() - 1);
				}
				if (log.isTraceEnabled()) {
					log.trace(
							"filterForGetAssetInstanceForFilter || dao method called : getAssetInstanceForFilterWithNonStaticParameters to get list of asset instance details for filter applied");
				}
				listofFilterInformation = assetInstanceVersionDao.filterForGetAssetInstanceForFilterWithNonStaticParametersDao(
						userName, assetName, assetParamNames, param1Values, param2Values, operators, logicalSelect,
						taxonomyNames, sb.toString(),value, from, conn);
				if (nonStaticParameters.length() != 0) {
					if (log.isTraceEnabled()) {
						log.trace(
								"filterForGetAssetInstanceForFilter || dao method called : getAssetParamDefsByParameters(parameters,assetName)");
					}
					List<AssetParamDef> listOfNonStaticParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(nonStaticParameters.toString(), assetName, conn);
					TreeMap<String, String> paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					Long newAssetInstVersionId = 0L;
					int jj = 1;
					for (int i = 0; i < listofFilterInformation.size(); i++) {
						AssetInstanceVersion aiv = listofFilterInformation.get(i);
						newAssetInstVersionId = aiv.getAssetInstVersionId();
						boolean flag = false;
						AssetInstance vo = new AssetInstance();
						vo.setAssetInstId(aiv.getAssetInstanceId());
						vo.setAssetInstName(aiv.getAssetInstName());
						vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
						vo.setDescription(aiv.getDescription());
						vo.setVersionName(aiv.getVersionName());
						vo.setVersionable(aiv.getVersionable());
						vo.setIconImageName(aiv.getIconImageName());
						vo.setEditAccessFlag(aiv.isEditAccessFlag());
						vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
						vo.setParamTypeId(aiv.getParamTypeId());
						vo.setRTFwithTags(aiv.getRTFwithTags());
						vo.setTextDataList(aiv.getTextDataList());
						vo.setShowHideParamCount(hideParameters.size());
						vo.setLdapMappingValues(aiv.getLdapMappingValue());
						vo.setLdapMappingCount(aiv.getLdapMappingListCount());
												
						for (int j = 0; j < listOfNonStaticParamDefs.size(); j++) {
							AssetParamDef apd = listOfNonStaticParamDefs.get(j);
							if (aiv.getAssetParamName() != null) {
								if (aiv.getAssetParamName().equalsIgnoreCase(apd.getAssetParamName())) {
									flag = true;
									if (apd.getParamTypeId() == 3) {
										paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									} else {
										if (apd.getParamTypeId() == 5) {
											paramValues.put(apd.getAssetParamName(),
													"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										} else if (apd.getParamTypeId() == 6) {
											paramValues.put(apd.getAssetParamName(),
													"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										} else if (apd.getParamTypeId() == 8) {
											paramValues.put(apd.getAssetParamName(),
													"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName()
															+ "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
										}
										else if(apd.getParamTypeId() == 7){
											if(apd.getHasArray() == 1){
												String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
												paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else if(apd.getHasArray() == 0){
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
											
										}else if(apd.getParamTypeId() == 1){
											if(apd.getHasArray() == 1){
												String textData = StringUtils.join(aiv.getTextDataList(), "~~");
												paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else if(apd.getHasArray() == 0){
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
										}else if(apd.getParamTypeId() == 9){
											String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
											paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}else {
											paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
									}
									if (flag) {
										vo.setParamNameWithValues(paramValues);
										break;
									}
								}
							} else {
								if (apd.getParamTypeId() == 3) {
									if(aiv.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), aiv.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
								} else {
									if (apd.getParamTypeId() == 5) {
										paramValues.put(apd.getAssetParamName(), "^^DA^^~" + aiv.getAssetInstVersionId()
												+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									} else if (apd.getParamTypeId() == 6) {
										paramValues.put(apd.getAssetParamName(), "^^DC^^~" + aiv.getAssetInstVersionId()
												+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									} else if (apd.getParamTypeId() == 8) {
										paramValues.put(apd.getAssetParamName(), "^^AC^^~" + aiv.getAssetInstVersionId()
										+ "~" + aiv.getAssetName() + "~" + apd.getAssetParamName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
									else if(apd.getParamTypeId() == 7){
										if(apd.getHasArray() == 1){
											String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
											if(rtfTags == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), rtfTags+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
										}else if(apd.getHasArray() == 0){
											if(aiv.getParamValue() == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
										}
									}else if(apd.getParamTypeId() == 1){
										if(apd.getHasArray() == 1){
											String textData = StringUtils.join(aiv.getTextDataList(), "~~");
											if(textData == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), textData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
										}else if(apd.getHasArray() == 0){
											if(aiv.getParamValue() == null) {
												paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}else{
												paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
											}
										}
									}else if(apd.getParamTypeId() == 9){
										String ldapData = StringUtils.join(aiv.getLdapMappingList(), "``");
										if(ldapData == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}else{
											paramValues.put(apd.getAssetParamName(), ldapData+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
									}else {
										if(aiv.getParamValue() == null) {
											paramValues.put(apd.getAssetParamName(), "`null`"+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}else{
											paramValues.put(apd.getAssetParamName(), aiv.getParamValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
										}
									}
								}
								vo.setParamNameWithValues(paramValues);
							}
						}
						Map<String, String> finalValues = vo.getParamNameWithValues();
						if(finalValues != null){
							for (AssetParamDef assetParamDef : listOfNonStaticParamDefs) {
								boolean flag1 = false;
								for (Map.Entry<String, String> map : finalValues.entrySet()) {
									if (assetParamDef.getAssetParamName().equalsIgnoreCase(map.getKey())) {
										flag1 = true;
										break;
									}
								}
								if (!flag1) {
									if (assetParamDef.getParamTypeId() == 3) {
										if(assetParamDef.getFileName() == null) {
											paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										}else{
											paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getFileName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										}
									} else {
										if (assetParamDef.getParamTypeId() == 5) {
											paramValues.put(assetParamDef.getAssetParamName(),
													"^^DA^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
															+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										} else if (assetParamDef.getParamTypeId() == 6) {
											paramValues.put(assetParamDef.getAssetParamName(),
													"^^DC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
															+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										} else if (assetParamDef.getParamTypeId() == 8) {
											paramValues.put(assetParamDef.getAssetParamName(),
													"^^AC^^~" + aiv.getAssetInstVersionId() + "~" + aiv.getAssetName() + "~"
															+ assetParamDef.getAssetParamName()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
										}
										else if(assetParamDef.getParamTypeId() == 7){
											if(assetParamDef.getHasArray() == 1){
												//String rtfTags = StringUtils.join(aiv.getRTFwithTags(), "~~");
												if(assetParamDef.getParamValue() == null) {
													paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}else{
													paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}
											}else if(assetParamDef.getHasArray() == 0){
												if(assetParamDef.getParamValue() == null) {
													paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}else{
													paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}
											}
										}else if(assetParamDef.getParamTypeId() == 1){
											if(assetParamDef.getHasArray() == 1){
												//String textData = StringUtils.join(aiv.getTextDataList(), "~~");
												if(assetParamDef.getParamValue() == null) {
													paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}else{
													paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}
											}else if(assetParamDef.getHasArray() == 0){
												if(assetParamDef.getParamValue() == null) {
													paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}else{
													paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getHasArray()+"`@`"+assetParamDef.getAssetParamId());
												}
											}
										}else if(assetParamDef.getParamTypeId() == 9){
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
											}else{
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
											}
										}else {
											if(assetParamDef.getParamValue() == null) {
												paramValues.put(assetParamDef.getAssetParamName(), "`null`"+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
											}else{
												paramValues.put(assetParamDef.getAssetParamName(), assetParamDef.getParamValue()+"`@`"+assetParamDef.getParamTypeId()+"`@`"+assetParamDef.getListType()+"`@`"+assetParamDef.getAssetParamId());
											}
										}
									}
									vo.setParamNameWithValues(paramValues);
								}
							}
						}
						if (i < listofFilterInformation.size() - 1) {
							if (!newAssetInstVersionId
									.equals(listofFilterInformation.get(jj).getAssetInstVersionId())) {
								listOfAssetInstanceVos.add(vo);
								paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
							}
						} else {
							listOfAssetInstanceVos.add(vo);
						}
						jj++;
					}
				}
				if (staticParameters.length() != 0) {
					// static information
					TreeMap<String, String> paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					if (log.isTraceEnabled()) {
						log.trace(
								"filterForGetAssetInstanceForFilter || dao method called : getAssetParamDefsByParameters(staticParameters,assetName)");
					}
					List<AssetParamDef> listOfStaticParamDefs = assetInstanceVersionDao
							.getAssetParamDefsByParameters(staticParameters.toString(), assetName, conn);
					if (nonStaticParameters.length() != 0) {
						for (int i = 0; i < listOfAssetInstanceVos.size(); i++) {
							AssetInstance aivo = listOfAssetInstanceVos.get(i);
							for (int k = 0; k < listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if (apd.getParamTypeId() == 3) {
									if(apd.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(),"`null`" +"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
								} else {
									if(apd.getStaticValue() == null) {
										paramValues.put(apd.getAssetParamName(),"`null`" +"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
								}
							}
							java.util.Map<String, String> map = aivo.getParamNameWithValues();
							if (map != null) {
								map.putAll(paramValues);
								aivo.setParamNameWithValues(map);
								listOfAssetInstanceVos.set(i, aivo);
							} else {
								aivo.setParamNameWithValues(paramValues);
								listOfAssetInstanceVos.set(i, aivo);
							}
						}
						paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
					} else {
						for (int j = 0; j < listofFilterInformation.size(); j++) {
							AssetInstance vo = new AssetInstance();
							AssetInstanceVersion aiv = listofFilterInformation.get(j);
							for (int k = 0; k < listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if (apd.getParamTypeId() == 3) {
									if(apd.getFileName() == null) {
										paramValues.put(apd.getAssetParamName(),"`null`" +"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), apd.getFileName()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}
								} else {
									if(apd.getStaticValue() == null) {
										paramValues.put(apd.getAssetParamName(),"`null`" +"`@`"+apd.getParamTypeId()+"`@`"+apd.getHasArray()+"`@`"+apd.getAssetParamId());
									}else{
										paramValues.put(apd.getAssetParamName(), apd.getStaticValue()+"`@`"+apd.getParamTypeId()+"`@`"+apd.getListType()+"`@`"+apd.getAssetParamId());
									}
								}
							}
							vo.setAssetInstName(aiv.getAssetInstName());
							vo.setAssetInstId(aiv.getAssetInstanceId());
							vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
							vo.setDescription(aiv.getDescription());
							vo.setVersionName(aiv.getVersionName());
							vo.setParamNameWithValues(paramValues);
							vo.setVersionable(aiv.getVersionable());
							vo.setIconImageName(aiv.getIconImageName());
							vo.setShowHideParamCount(hideParameters.size());
							vo.setEditAccessFlag(aiv.isEditAccessFlag());
							vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
							vo.setParamTypeId(aiv.getParamTypeId());
							vo.setRTFwithTags(aiv.getRTFwithTags());
							vo.setTextDataList(aiv.getTextDataList());
							listOfAssetInstanceVos.add(vo);
							paramValues = new TreeMap<String, String>(String.CASE_INSENSITIVE_ORDER);
						}
					}
				}
			} else {
				// getBasic information
				propertiesFlag = false;
				if (log.isTraceEnabled()) {
					log.trace("filterForGetAssetInstanceForFilter || dao method called : getAssetInstanceForFilterWithNonStaticParametersDao without showhide parameters");
				}
				List<AssetInstanceVersion> basicInformationOfassetInstance = assetInstanceVersionDao
						.filterForGetAssetInstanceForFilterWithNonStaticParametersDao(userName, assetName, assetParamNames,
								param1Values, param2Values, operators, logicalSelect, taxonomyNames, "",value, from, conn);

				for (int i = 0; i < basicInformationOfassetInstance.size(); i++) {
					AssetInstanceVersion aiv = basicInformationOfassetInstance.get(i);
					AssetInstance vo = new AssetInstance();
					vo.setAssetInstName(aiv.getAssetInstName());
					vo.setAssetInstId(aiv.getAssetInstanceId());
					vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
					vo.setDescription(aiv.getDescription());
					vo.setVersionName(aiv.getVersionName());
					vo.setVersionable(aiv.getVersionable());
					vo.setIconImageName(aiv.getIconImageName());
					vo.setShowHideParamCount(hideParameters.size());
					vo.setEditAccessFlag(aiv.isEditAccessFlag());
					vo.setDeleteAccessFlag(aiv.isDeleteAccessFlag());
					vo.setPropertiesFlag(propertiesFlag);
					vo.setParamTypeId(aiv.getParamTypeId());
					vo.setRTFwithTags(aiv.getRTFwithTags());
					vo.setTextDataList(aiv.getTextDataList());
					listOfAssetInstanceVos.add(vo);
				}
			}

			Collections.sort(listOfAssetInstanceVos, new AssetInstance());
			if (log.isDebugEnabled()) {
				log.debug("filterForGetAssetInstanceForFilter || " + listOfAssetInstanceVos.toString());
			}
			log.debug(" filterForGetAssetInstanceForFilter || retrieved " + listOfAssetInstanceVos.size()
					+ " asset instance version details by asset name : " + assetName.toString());
			if (listOfAssetInstanceVos.isEmpty()) {
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("filterForGetAssetInstanceForFilter || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("filterForGetAssetInstanceForFilter || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterForGetAssetInstanceForFilter || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("filterForGetAssetInstanceForFilter || end with userName : " + userName + " assetName :" + assetName
					+ " assetId:" + assetId + " operators:" + operators + " assetParamNames:" + assetParamNames
					+ " param1Values:" + param1Values + " param2Values:" + param2Values + " logicalSelect:"
					+ logicalSelect + " taxonomyNames:" + taxonomyNames + " from:" + from);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(listOfAssetInstanceVos)))
				.build();
	
	}
	
	
	/**
	 * @method : updateCustomizedSectionDataForAIV
	 * @param userName
	 * @param sectionData
	 * @return
	 */
	@PUT
	@Path("/updateCustomizedSectionData")
	public Response updateCustomizedSectionDataForAIV(@QueryParam("userName") String userName,User user) {

		if (log.isTraceEnabled()) {
			log.trace("updateCustomizedSectionDataForAIV || begin");
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		AssetInstanceVersionDao dao = new AssetInstanceVersionDao();

		try {
			
			conn = DBConnection.getInstance().getConnection();
			user.setUserName(userName);
			dao.updateCustomizedSectionData(user,conn);
			if (log.isTraceEnabled()) {
				log.trace("updateCustomizedSectionDataForAIV || dao method called : updateCustomizedSectionData");
			}
			
			conn.commit();

			log.info("updateCustomizedSectionDataForAIV || assigned taxonomy to asset instance version successfully");

			retMsg = Constants.CUSTOMIZED_LAYOUT_DATA_UPDATED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("updateCustomizedSectionDataForAIV || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("updateCustomizedSectionDataForAIV || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateCustomizedSectionDataForAIV || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("updateCustomizedSectionDataForAIV || end ");
		}
		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

	}		
	
	
	/**
	 * @method : getCustomizedSectionDataForAIV
	 * @param userName
	 * @return
	 */
	@GET
	@Path("/getCustomizedSectionData")
	public Response getCustomizedSectionDataForAIV(@QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("getCustomizedSectionDataForAIV || begin");
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		User user = null;
		
		AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
		List<User> userList = new ArrayList<User>();

		try {
			
			conn = DBConnection.getInstance().getConnection();
			
			user = dao.getCustomizedSectionData(userName,conn);
			if (log.isTraceEnabled()) {
				log.trace("getCustomizedSectionDataForAIV || dao method called : updateCustomizedSectionData");
			}
			userList.add(user);

			log.info("getCustomizedSectionDataForAIV || assigned taxonomy to asset instance version successfully");

			retMsg = Constants.CUSTOMIZED_LAYOUT_DATA_FETCHED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getCustomizedSectionDataForAIV || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("getCustomizedSectionDataForAIV || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getCustomizedSectionDataForAIV || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getCustomizedSectionDataForAIV || end ");
		}
		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,new ArrayList<Object>(userList))).build();

	}
	
	@GET
	@Encoded
	@Path("/getAssetInstanceVersionsAndDetails/{assetInstVersionId}")
	public Response getAssetInstanceVersionsAndDeatis(@PathParam("assetInstVersionId") long assetInstVersionId,
			@QueryParam("assetInstName") String assetInstName,@QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceVersionsAndDetails || begin  with assetInstVersionId : " + assetInstVersionId);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		Connection conn = null;
		List<AssetInstanceVersion> assetInstVerDetailsList = new ArrayList<AssetInstanceVersion>();

		try {
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionsAndDetails || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace(
						"getAssetInstanceVersionsAndDetails || dao method called : getAssetInstanceVersionDetails by assetInstVersionId: "
								+ assetInstVersionId);
			}
			AssetInstanceVersion assetInstanceVersion = null;
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			assetInstVerDetailsList = assetInstanceVersionDao.getAssetInstanceVersionsAndDetails(assetInstVersionId,assetInstName,userName,conn);
			//assetInstVerDetailsList.add(assetInstanceVersion);
			conn.commit();

			if (log.isDebugEnabled()) {
				log.debug(" getAssetInstanceVersionsAndDetails  || retrieved " + assetInstVerDetailsList.size()
						+ " asset instance version details by version id : " + assetInstVersionId);
			}

			if (!assetInstVerDetailsList.isEmpty()) {
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_NOT_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAssetInstanceVersionsAndDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceVersionsAndDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionsAndDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceVersionsAndDetails || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(assetInstVerDetailsList)))
				.build();

	}

	// import csv application update properties 
public void updateParameterForAssetInstImportCsv(AssetInstanceVersion param, NameValue paramvalue, Long userId,
			Connection conn)throws RepoproException {

		ParameterValues pv1 = new ParameterValues();
		AssetParamDef param1 = new AssetParamDef();
		AssetDao assetDao = new AssetDao();
		Connection conn1 = null;

		try {
			if (conn == null) {

				if (log.isTraceEnabled()) {
					log.trace("updateParameterForAssetInst || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (param.getIsStatic() == 1) {

				if (param.getParamTypeId() == (Constants.FILE_TYPE)) {

					param1.setFileName(paramvalue.getFileName());
					param1.setAssetParamName(paramvalue.getName());
					param1.setMimetype(paramvalue.getFileMimeType());
					param1.setImage(paramvalue.getImage());

				} else {

					param1.setStaticValue(param.getParamValue());
					param1.setAssetParamName(param.getAssetParamName());

				}

				// update static param
				param1.setModifyByUserId(userId);
				param1.setLastUpdatedTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));

				if (log.isTraceEnabled()) {
					log.trace("updateParameterForAssetInst || called dao method : updateParameterInAssetParamDef() : "
							+ param1.toString());
				}

				assetDao.updateParameterInAssetParamDef(param1, param.getAssetName(), param1.getAssetParamName(), conn);

			} else {

				if (param.getParamTypeId() == (Constants.FILE_TYPE)) {

					pv1.setFileName(paramvalue.getFileName());
					pv1.setAssetParamName(paramvalue.getName());
					pv1.setMimeType(paramvalue.getFileMimeType());
					pv1.setImage(paramvalue.getImage());

				} else {
					pv1.setValue(param.getParamValue());
					pv1.setAssetParamName(param.getAssetParamName());

				}

				if (log.isTraceEnabled()) {
					log.trace(
							"updateParameterForAssetInst || called dao method : getParameterForAssetInstParamAndVersionId() : "
									+ param.getAssetParamName() + "and" + param.getAssetInstVersionId());
				}

				ParameterValues pv = assetDao.getParameterForAssetInstParamAndVersionId(param.getAssetParamName(),
						param.getAssetInstVersionId(), conn);

				if (pv != null) {
					// update parametervalues
					pv1.setParameterValuesId(pv.getParameterValuesId());
					pv1.setAssetInstParamId(pv.getAssetInstParamId());

					AssetInstParams assetInstParams = new AssetInstParams();

					assetInstParams.setAssetInstParamId(pv.getAssetInstParamId());
					assetInstParams.setAssetInstVersionId(param.getAssetInstVersionId());
					assetInstParams.setAssetParamId(param.getAssetParamId());
					assetInstParams.setLastUpdatedTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					assetInstParams.setModifyByUserId(userId);

					if (log.isTraceEnabled()) {
						log.trace("updateParameterForAssetInst || called dao method : updateAssetInstParam() : "
								+ assetInstParams.toString());
					}
					
					assetDao.updateAssetInstParam(assetInstParams, conn);

					if (log.isTraceEnabled()) {
						log.trace("updateParameterForAssetInst || called dao method : updateParameterValues() : "
								+ pv1.toString());
					}

					assetDao.updateParameterValues(pv1, conn);

				} else {

					if (log.isTraceEnabled()) {
						log.trace("updateParameterForAssetInst || called dao method : retInstParam() : ");
					}

					AssetInstParams aiparam = assetDao.retInstParam(param.getAssetParamId(),
							param.getAssetInstVersionId(), conn);

					if (aiparam.getAssetInstParamId() == null) {

						AssetInstParams assetInstParams = new AssetInstParams();

						assetInstParams.setAssetInstVersionId(param.getAssetInstVersionId());
						assetInstParams.setAssetParamId(param.getAssetParamId());
						assetInstParams.setLastUpdatedTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));

						assetInstParams.setModifyByUserId(userId);

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : addAssetInstParam() : "
									+ assetInstParams.toString());
						}

						AssetInstParams aip = assetDao.addAssetInstParam(assetInstParams, conn);

						ParameterValues paramValue = new ParameterValues();

						paramValue.setAssetInstParamId(aip.getAssetInstParamId());

						paramValue.setValue(pv1.getValue());
						paramValue.setFileName(pv1.getFileName());
						paramValue.setImage(pv1.getImage());

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
									+ paramValue.toString());
						}

						assetDao.addParameterValue(paramValue, conn);

					} else {

						AssetInstParams assetInstParams = new AssetInstParams();

						assetInstParams.setAssetInstParamId(aiparam.getAssetInstParamId());
						assetInstParams.setAssetInstVersionId(aiparam.getAssetInstVersionId());
						assetInstParams.setAssetParamId(aiparam.getAssetParamId());
						assetInstParams.setLastUpdatedTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						assetInstParams.setModifyByUserId(userId);

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : updateAssetInstParam() : "
									+ assetInstParams.toString());
						}

						assetDao.updateAssetInstParam(assetInstParams, conn);

						ParameterValues paramValue = new ParameterValues();

						paramValue.setAssetInstParamId(aiparam.getAssetInstParamId());

						paramValue.setValue(pv1.getValue());
						paramValue.setFileName(pv1.getFileName());
						paramValue.setImage(pv1.getImage());

						if (log.isTraceEnabled()) {
							log.trace("updateParameterForAssetInst || called dao method : addParameterValue() : "
									+ paramValue.toString());
						}

						assetDao.addParameterValue(paramValue, conn);

					}

				}

			}
			//conn.commit();

		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
			
		} finally {
			if (conn1 != null) {
				if (log.isTraceEnabled()) {
					log.trace("updateParameterForAssetInst : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("updateParameterForAssetInst || Exit");
		}
	}

/**
 * @mathod getAssetInstancePropertiesStructure
 * @param userName
 * @param assetName
 * @return Response
 * @throws RepoproException
 */
@GET
@Encoded
@Path("/propertiesStructure")
public Response getAssetInstancePropertiesStructure(@QueryParam("userName") String userName,
		@QueryParam("assetName") String assetName) throws RepoproException {

	if (log.isTraceEnabled()) {
		log.trace("getAssetInstancePropertiesStructure || begin  with userName : " + userName + " assetName "
				+ assetName);
	}
	Status retStat = Status.OK;
	String retMsg = null;
	String retScsFlr = null;
	int retStatScsFlr = 0;

	Connection conn = null;
	List<AssetInstanceVersion> finalData = new ArrayList<AssetInstanceVersion>();
	AssetDao assetDao = new AssetDao();

	try {

		assetName = URLDecoder.decode(assetName, "UTF-8");
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstancePropertiesStructure || " + Constants.LOG_CONNECTION_OPEN);
		}
		conn = DBConnection.getInstance().getConnection();

		finalData = assetDao.getParameteresByAssetName(assetName,userName,conn);

		@SuppressWarnings("unused")
		class AssetInstanceVersinsComparator implements Comparator<AssetInstanceVersion> {

			private List<Comparator<AssetInstanceVersion>> listComparators;

			@SuppressWarnings("unused")
			AssetInstanceVersinsComparator(Comparator<AssetInstanceVersion>... comparators) {
				this.listComparators = Arrays.asList(comparators);
			}

			public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
				for (Comparator<AssetInstanceVersion> comparator : listComparators) {
					int result = comparator.compare(o1, o2);
					if (result != 0) {
						return result;
					}
				}
				return 0;
			}
		}
		@SuppressWarnings("unused")
		class Category_disp_position_Comparator implements Comparator<AssetInstanceVersion> {

			public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
				if (o1.getCat_disp() == o2.getCat_disp())
					return 0;
				return o1.getCat_disp() < o2.getCat_disp() ? -1 : 1;
			}
		}
		class Parameter_disp_position_Comparator implements Comparator<AssetInstanceVersion> {

			public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
				if (o1.getParam_disp() == o2.getParam_disp())
					return 0;
				return o1.getParam_disp() < o2.getParam_disp() ? -1 : 1;
			}
		}
		Collections.sort(finalData, new AssetInstanceVersinsComparator(new Category_disp_position_Comparator(),
				new Parameter_disp_position_Comparator()));

	} catch (RepoproException e) {
		log.error("getAssetInstancePropertiesStructure || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		retStat = Status.INTERNAL_SERVER_ERROR;
		retMsg = e.getMessage();
		retScsFlr = Constants.FAILURE;
		retStatScsFlr = Constants.GET_STATUS_FAILURE;
	} catch (Exception e) {
		log.error("getAssetInstancePropertiesStructure || " + Constants.LOG_EXCEPTION + e.getMessage());
		retStat = Status.INTERNAL_SERVER_ERROR;
		retMsg = e.getMessage();
		retScsFlr = Constants.FAILURE;
		retStatScsFlr = Constants.GET_STATUS_FAILURE;
		e.printStackTrace();
	} finally {
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstancePropertiesStructure || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn);
	}
	if (log.isTraceEnabled()) {
		log.trace("getAssetInstancePropertiesStructure || " + " || exit");
	}

	if(!(finalData.size() == 0) ){
		retStat = Status.OK;
		retMsg = Constants.ASSET_INSTANCE_PARAMETERS_SUCCESSFULLY_FETCHED;
		retScsFlr = Constants.SUCCESS;
		retStatScsFlr = Constants.GET_STATUS_SUCCESS;
	}else{
		retStat = Status.OK;
		retMsg = Constants.ASSET_INSTANCE_PARAMETERS_NOT_FETCHED;
		retScsFlr = Constants.SUCCESS;
		retStatScsFlr = Constants.GET_STATUS_SUCCESS;
	}

	return Response.status(retStat)
			.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(finalData))).build();

}


@GET
@Path("/getAivPageDetailsOnLoad")
public Response getAivPageDetailsOnLoad(/*@QueryParam("assetName") String assetName,@QueryParam("assetInstName") String assetInstName,
		@QueryParam("assetVersionName") String assetVersionName*/
		@QueryParam("assetInstVersionId") Long assetInstVersionId,
		@QueryParam("userName") String userName){
	
	/*if (log.isTraceEnabled()) {
		log.trace("getAivPageDetailsOnLoad || Begin with assetName : " + assetName 
				+ "\t assetInstName : "+ assetInstName + "\t assetVersionName : "+ assetVersionName 
				+ "\t userName : "+ userName);
	}*/
	
	if (log.isTraceEnabled()) {
		log.trace("getAivPageDetailsOnLoad || Begin with assetInstVersionId : " + assetInstVersionId 
				+ "\t userName : "+ userName);
	}

	Connection conn = null;
	Status retStat = Status.OK;
	String retMsg = null;
	String retScsFlr = null;
	int retStatScsFlr = 0;
	
	List<AivDetails> aivList = new ArrayList<AivDetails>();
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("getAivPageDetailsOnLoad || " + Constants.LOG_CONNECTION_OPEN);
		}
		conn = DBConnection.getInstance().getConnection();
		AssetInstanceVersion aiv = new AssetInstanceVersion();
		AssetInstanceVersion assetInstanceVersion = new AssetInstanceVersion();
		AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		TaggingMaster tagMaster = new TaggingMaster();
		TaggingDao taggingDao = new TaggingDao();
		AivDetails aivDetails = new AivDetails();
		RelationshipDao relationshipDao = new RelationshipDao();

		
		if (log.isTraceEnabled()) {
			log.trace("getAivPageDetailsOnLoad || dao method called getAssetinstDetails()" );
		}
		/*aiv = assetInstanceVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, null);
		Long assetInstVersionId = aiv.getAssetInstVersionId();*/

		if (log.isTraceEnabled()) {
			log.trace("getAivPageDetailsOnLoad || dao method called getAssetInstanceVersionDetails()" );
		}
		assetInstanceVersion = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstVersionId, conn);//overview
		String assetName = assetInstanceVersion.getAssetName();
		
		if (log.isTraceEnabled()) {
			log.trace("getAivPageDetailsOnLoad || dao method called getParameter()");
		}
		List<AssetInstanceVersion> properties = assetInstanceVersionsManager.getParameter(assetName, userName, assetInstVersionId, conn);//properties

		if (log.isTraceEnabled()) {
			log.trace("getAivPageDetailsOnLoad || dao method called getAllTags()");
		}
		tagMaster.setAssetInstanceVersionId(assetInstVersionId);
		TaggingMaster allTags = taggingDao.getAllTags(tagMaster, conn);//tags

		if (log.isTraceEnabled()) {
			log.trace("getAivPageDetailsOnLoad || dao method called retTaxonomyIdByAssetInstVersionId()");
		}
		List<AssetInstanceVersionTaxonomy> taxonomyIds = assetInstanceVersionDao.retTaxonomyIdByAssetInstVersionId(assetInstVersionId, conn);//taxonomies
		
		List<AssetInstRelationship> relationshipList = relationshipDao.retFwdRelationsForAnAssetInstanceVersionId(assetInstVersionId, conn);
		
		aivDetails.setOverview(assetInstanceVersion);
		aivDetails.setProperties(properties);
		aivDetails.setTags(allTags);
		aivDetails.setTaxonomy(taxonomyIds);
		aivDetails.setRelationships(relationshipList);
		aivList.add(aivDetails);
		

		if (aivList.isEmpty()) {
			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_NOT_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

	} catch (RepoproException e) {
		log.error("getAivPageDetailsOnLoad || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		retStat = Status.INTERNAL_SERVER_ERROR;
		retMsg = e.getMessage();
		retScsFlr = Constants.FAILURE;
		retStatScsFlr = Constants.GET_STATUS_FAILURE;
	} catch (Exception e) {
		log.error("getAivPageDetailsOnLoad || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		retStat = Status.INTERNAL_SERVER_ERROR;
		retMsg = e.getMessage();
		retScsFlr = Constants.FAILURE;
		retStatScsFlr = Constants.GET_STATUS_FAILURE;
	} finally {
		if (log.isTraceEnabled()) {
			log.trace("getAivPageDetailsOnLoad || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn);
	}
	if (log.isTraceEnabled()) {
		log.trace("getAivPageDetailsOnLoad || end");
	}
	return Response.status(retStat)
			.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(aivList))).build();
}


	/**
	 * @method getDerivedAttributeForAssetListValues
	 * @description to get derived attribute value
	 * @param user name,assetInstanceVersionId,assetName,paramterName
	 * @return Response String
	 * @throws RepoproException
	 */
	@GET
	@Path("/getDerivedAttributeForAssetListValues")
	public Response getDerivedAttributeForAssetListValues(@QueryParam("userName") String userName,
			@QueryParam("assetInstanceVersionId") String assetInstanceVersionId,
			@QueryParam("assetName") String assetName, @QueryParam("parameterName") String parameterName) {
		
		if (log.isTraceEnabled()) {
			log.trace("getDerivedAttributeForAssetListValues || begin  with userName : " + userName + " assetName " + assetName);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
		Connection conn = null;
		String derivedAttribute = null;
		ArrayList<Object> derivedAttributeForAssetList = new ArrayList<Object>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getDerivedAttributeForAssetListValues || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			if (log.isTraceEnabled()) {
				log.trace("getDerivedAttributeForAssetListValues || Dao method call getDerivedAttributeForAssetListValues()");
			}
			assetName = URLDecoder.decode(assetName, "UTF-8");
			
			derivedAttribute = dao.getDerivedAttributeForAssetListValues(userName, assetInstanceVersionId, assetName, parameterName,conn);
			derivedAttributeForAssetList.add(derivedAttribute);
			
			retStat = Status.OK;
			retMsg = Constants.DERIVED_ATTRIBUTE_FOR_ASSET_LIST_FETCHED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} catch (RepoproException e) {
			log.error("getDerivedAttributeForAssetListValues || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getDerivedAttributeForAssetListValues ||	 " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getDerivedAttributeForAssetListValues || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getDerivedAttributeForAssetListValues || " + " || exit");
		}
		
		return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, derivedAttributeForAssetList))
				.build();
	}
	
	
	class Sortbyname implements Comparator<AssetInstance> {
		
		public int compare(AssetInstance o1, AssetInstance o2) {
			return o1.getAssetInstName().toLowerCase().compareTo(o2.getAssetInstName().toLowerCase());
		} 
	}
	
	class SortbynameRev implements Comparator<AssetInstance> {
		
		public int compare(AssetInstance o1, AssetInstance o2) {
			return o2.getAssetInstName().toLowerCase().compareTo(o1.getAssetInstName().toLowerCase());
		} 
	}
	
	class Sortbyid implements Comparator<AssetInstance> {

		public int compare(AssetInstance o1, AssetInstance o2) {
			return o1.getAssetInstVersionId().compareTo(o2.getAssetInstVersionId());
		} 
	}
	
	class SortbyidRev implements Comparator<AssetInstance> {

		public int compare(AssetInstance o1, AssetInstance o2) {
			return o2.getAssetInstVersionId().compareTo(o1.getAssetInstVersionId());
		} 
	}
	
	
	/**
	 * @method : checkForDeletionOfMappedInstance
	 * @param assetInstId
	 * @return
	 */
	@GET
	@Path("/checkForDeletionOfMappedInstance")
	public Response checkForDeletionOfMappedInstance(@QueryParam("assetInstId") Long assetInstId) {
		
		if (log.isTraceEnabled()) {
			log.trace("checkForDeletionOfMappedInstance || begin with assetInstId : " + assetInstId);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;

		boolean deleteInstanceFlag = false;
		List<Boolean> resFlag = new ArrayList<Boolean>();
		
		List<AssetInstRelationship> assetInstRelationshipList = new ArrayList<AssetInstRelationship>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("checkForDeletionOfMappedInstance || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			List<AssetInstanceVersion> assetInstanceVersionsList = assetInstanceVersionDao.getAssetInstanceVersions(assetInstId, conn);
			
			for(AssetInstanceVersion aiv : assetInstanceVersionsList){
				assetInstRelationshipList = assetInstanceVersionDao.getRelationshipsBasedOnDestAivId(aiv.getAssetInstVersionId(), conn);
				if(assetInstRelationshipList.size() != 0) {
					deleteInstanceFlag = true;
					break;
				}
			}
			
			resFlag.add(deleteInstanceFlag);
			
		} catch (RepoproException e) {
			log.error("checkForDeletionOfMappedInstance || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("checkForDeletionOfMappedInstance || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("checkForDeletionOfMappedInstance || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("checkForDeletionOfMappedInstance || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(resFlag))).build();
	}
	
	
	/**
	 * @method : checkForDeletionOfMappedInstance
	 * @param assetInstId
	 * @return
	 */
	@GET
	@Path("/checkForDeletionOfMappedInstanceVersion")
	public Response checkForDeletionOfMappedInstanceVersion(@QueryParam("aivId") Long aivId) {
		
		if (log.isTraceEnabled()) {
			log.trace("checkForDeletionOfMappedInstanceVersion || begin with aivId : " + aivId);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;

		boolean deleteInstanceFlag = false;
		List<Boolean> resFlag = new ArrayList<Boolean>();
		
		List<AssetInstRelationship> assetInstRelationshipList = new ArrayList<AssetInstRelationship>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("checkForDeletionOfMappedInstanceVersion || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();

			assetInstRelationshipList = assetInstanceVersionDao.getRelationshipsBasedOnDestAivId(aivId, conn);
			if(assetInstRelationshipList.size() != 0) {
				deleteInstanceFlag = true;
			}

			resFlag.add(deleteInstanceFlag);

		} catch (RepoproException e) {
			log.error("checkForDeletionOfMappedInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("checkForDeletionOfMappedInstanceVersion || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("checkForDeletionOfMappedInstanceVersion || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("checkForDeletionOfMappedInstanceVersion || End ");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(resFlag))).build();
	}
	
	@PUT
	@Path("/saveGroupsAccessMultipleAISubmit")
	public Response saveGroupsAccessMultipleAISubmit(List<GroupAssetAccess> gaa) {
		if (log.isTraceEnabled()) {
			log.trace("saveGroupsAccessMultipleAISubmit || Begin " + gaa.toString());
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		try {
			if (log.isTraceEnabled()) {
				log.trace("saveGroupsAccessMultipleAISubmit || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
			
			if (log.isTraceEnabled()) {
				log.trace("saveGroupsAccessMultipleAISubmit || dao method called : deleteInsertGroupsAccessMultipleAISubmit()");
			}
			dao.deleteInsertGroupsAccessMultipleAISubmit(gaa, conn);

			retMsg = Constants.GROUP_ACCESS_SAVED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

			conn.commit();

			log.info("saveGroupsAccessMultipleAISubmit || group access saved");

		} catch (RepoproException e) {
			log.error("saveGroupsAccessMultipleAISubmit || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("saveGroupsAccessMultipleAISubmit || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("saveGroupsAccessMultipleAISubmit || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("saveGroupsAccessMultipleAISubmit || end");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	@GET
	@Encoded
	@Path("/totalCountOfInstancesByFilter")
	public Response getAssetInstanceForFilterForTotalCountOfInstances(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("assetId") Long assetId,
			@QueryParam("operators") String operators, @QueryParam("assetParamNames") String assetParamNames,
			@QueryParam("param1Values") String param1Values, @QueryParam("param2Values") String param2Values,
			@QueryParam("logicalSelect") String logicalSelect, @QueryParam("taxonomyNames") String taxonomyNames) {
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceForFilterForTotalCountOfInstances || begin with userName : " + userName + " assetName :" + assetName
					+ " assetId:" + assetId + " operators:" + operators + " assetParamNames:" + assetParamNames
					+ " param1Values:" + param1Values + " param2Values:" + param2Values + " logicalSelect:"
					+ logicalSelect + " taxonomyNames:" + taxonomyNames);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<String> countOfAivids = new ArrayList<String>();
		Map<String,String> countOfAividsJson = new TreeMap<String,String>();
		try {
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			
			assetParamNames = URLDecoder.decode(assetParamNames, "UTF-8");
			param1Values = URLDecoder.decode(param1Values, "UTF-8");
			param2Values = URLDecoder.decode(param2Values, "UTF-8");
			operators = URLDecoder.decode(operators, "UTF-8");
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterForTotalCountOfInstances || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterForTotalCountOfInstances || dao method called : getCountforAssetInstanceForFilter to get list of asset instance details for filter applied");
			}
			countOfAivids = assetInstanceVersionDao.getCountforAssetInstanceForFilter(userName, assetName, assetParamNames,
							param1Values, param2Values, operators, logicalSelect, taxonomyNames, "", conn);
			
			countOfAividsJson.put("count", countOfAivids.get(0));
			countOfAividsJson.put("AivIds", countOfAivids.get(1));

			if (log.isDebugEnabled()) {
				log.debug("getAssetInstanceForFilterForTotalCountOfInstances || " + countOfAividsJson.toString());
			}
			if (log.isInfoEnabled()) {
				log.info(" getAssetInstanceForFilterForTotalCountOfInstances || retrieved " + countOfAividsJson.size()
				+ " asset instance version details by asset name : " + assetName.toString());
			}
			if (countOfAividsJson.isEmpty()) {
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAssetInstanceForFilterForTotalCountOfInstances || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceForFilterForTotalCountOfInstances || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterForTotalCountOfInstances || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceForFilterForTotalCountOfInstances || end with userName : " + userName + " assetName :" + assetName
					+ " assetId:" + assetId + " operators:" + operators + " assetParamNames:" + assetParamNames
					+ " param1Values:" + param1Values + " param2Values:" + param2Values + " logicalSelect:"
					+ logicalSelect + " taxonomyNames:" + taxonomyNames );
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, countOfAividsJson))
				.build();
	}
	
	@GET
	@Encoded
	@Path("/filterSearchCount")
	public Response filterGetAssetInstanceForFilterForTotalCountOfInstances(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("assetId") Long assetId,
			@QueryParam("operators") String operators, @QueryParam("assetParamNames") String assetParamNames,
			@QueryParam("param1Values") String param1Values, @QueryParam("param2Values") String param2Values,
			@QueryParam("logicalSelect") String logicalSelect, @QueryParam("taxonomyNames") String taxonomyNames,
			@QueryParam("value") String values){

		if (log.isTraceEnabled()) {
			log.trace("filterGetAssetInstanceForFilterForTotalCountOfInstances || begin with userName : " + userName + " assetName :" + assetName
					+ " assetId:" + assetId + " operators:" + operators + " assetParamNames:" + assetParamNames
					+ " param1Values:" + param1Values + " param2Values:" + param2Values + " logicalSelect:"
					+ logicalSelect + " taxonomyNames:" + taxonomyNames +" value:"+values);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<String> countOfAivids = new ArrayList<String>();
		Map<String,String> countOfAividsJson = new TreeMap<String,String>();
		try {
			param1Values = URLDecoder.decode(param1Values, "UTF-8");
			param2Values = URLDecoder.decode(param2Values, "UTF-8");
			operators = URLDecoder.decode(operators, "UTF-8");
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetParamNames = URLDecoder.decode(assetParamNames, "UTF-8");
			String actualvalue = URLDecoder.decode(values, "UTF-8");
			String value = actualvalue;
			if (actualvalue.contains("_")||actualvalue.contains("%")||actualvalue.contains("\\")){
				value = actualvalue;
				value = value.replace("\\", "\\\\\\\\");
			}else{
				value = actualvalue;
			}

			if (log.isTraceEnabled()) {
				log.trace("filterGetAssetInstanceForFilterForTotalCountOfInstances || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			
			if (log.isTraceEnabled()) {
				log.trace("filterGetAssetInstanceForFilterForTotalCountOfInstances || dao method called : getAssetInstanceForFilterWithNonStaticParameters to get list of asset instance details for filter applied");
			}
			countOfAivids = assetInstanceVersionDao
					.getCountOffilterForGetAssetInstanceForFilterWithNonStaticParametersDao(userName, assetName, assetParamNames,
							param1Values, param2Values, operators, logicalSelect, taxonomyNames,"",value, conn);

			countOfAividsJson.put("count", countOfAivids.get(0));
			countOfAividsJson.put("AivIds", countOfAivids.get(1));
			
			if (log.isDebugEnabled()) {
				log.debug("filterGetAssetInstanceForFilterForTotalCountOfInstances || " + countOfAividsJson.toString());
			}
			
			log.debug(" filterGetAssetInstanceForFilterForTotalCountOfInstances || retrieved " + countOfAividsJson.size()
			+ " asset instance version details by asset name : " + assetName.toString());
			
			if (countOfAividsJson.isEmpty()) {
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("filterGetAssetInstanceForFilterForTotalCountOfInstances || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("filterGetAssetInstanceForFilterForTotalCountOfInstances || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterGetAssetInstanceForFilterForTotalCountOfInstances || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("filterGetAssetInstanceForFilterForTotalCountOfInstances || end with userName : " + userName + " assetName :" + assetName
					+ " assetId:" + assetId + " operators:" + operators + " assetParamNames:" + assetParamNames
					+ " param1Values:" + param1Values + " param2Values:" + param2Values + " logicalSelect:"
					+ logicalSelect + " taxonomyNames:" + taxonomyNames);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, countOfAividsJson)).build();
	
	}
	
	/**
	 * @method filterBrowseGridCount
	 * @param values
	 * @param assetname
	 * @param userName
	 * @param assetId
	 * @param from
	 * @return HttpResponse
	 */
	@Encoded
	@GET
	@Path("/filterBrowseGridCount")
	public Response filterBrowseGridCount(@QueryParam("value") String values, 
			@QueryParam("assetName") String assetname,@QueryParam("userName") String userName,
			@QueryParam("assetId") Long assetId) {

		if (log.isTraceEnabled()) {
			log.trace("filterBrowseGridCount || Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;

		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<String> listofCountInformation = new ArrayList<String>();
		Map<String,String> countOfAividsJson = new TreeMap<String,String>();

		try {
			String actualvalue = URLDecoder.decode(values, "UTF-8");
			String assetName = URLDecoder.decode(assetname, "UTF-8");
			String value = actualvalue;
			if (actualvalue.contains("_")||actualvalue.contains("%")||actualvalue.contains("\\")|| actualvalue.contains("-")){
				value = actualvalue;
				value = value.replace("\\", "\\\\");
				value = value.replace("_", "\\_");
				value = value.replace("%", "\\%");				
			}else{
				value = actualvalue;
			}

			if (log.isTraceEnabled()) {
				log.trace("filterBrowseGridCount || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			listofCountInformation = assetInstanceVersionDao
						.getCountOfAssetInstanceVersionDetailsForFilter(assetName,userName,value, conn);	
			
			countOfAividsJson.put("count", listofCountInformation.get(0));
			countOfAividsJson.put("AivIds", listofCountInformation.get(1));

			if (log.isDebugEnabled()) {
				log.debug("filterBrowseGridCount || " + listofCountInformation.toString());
			}
			log.debug(" filterBrowseGridCount  || retrieved " + listofCountInformation.size()
					+ " asset instance version details by asset name : " + assetName.toString());

			if(listofCountInformation.size() == 0){
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("filterBrowseGridCount || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("filterBrowseGridCount || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterBrowseGridCount || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("filterBrowseGridCount || " + listofCountInformation.toString() + " || exit");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,countOfAividsJson))
				.build();

	}
	
	
	/**
	 * @method getAssetInstanceBrowseGridForTotalCount
	 * @description to get filtered and show and hide asset instance grid
	 * @param user name
	 * @return Response List<AssetInstanceVersion>
	 * @throws RepoproException
	 */
	@GET
	@Path("/getAssetInstanceBrowseGridForTotalCount")
	public Response getAssetInstanceBrowseGridForTotalCount(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("assetId") Long assetId,
			@QueryParam("from") int from,@QueryParam("restApiFlag") boolean restApiFlag) {
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceBrowseGridForTotalCount || begin  with userName : " + userName + " assetName " + assetName);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		
		List<String> aivIdsList = new ArrayList<String>();
		Map<String,String> countOfAividsJson = new TreeMap<String,String>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceBrowseGridForTotalCount || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceBrowseGridForTotalCount || dao method called : getShowHideParams(assetId,UserId)");
			}
			
			if (log.isTraceEnabled()) {
				log.trace(
						"getAssetInstanceBrowseGridForTotalCount || dao method called : getAssetParamDefsByParameters(parameters,assetName)");
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceBrowseGridForTotalCount || dao method called : getAssetInstanceVersionDetailsWithNonStaticParameters(assetName,parameters)");
			}
			aivIdsList = assetInstanceVersionDao
					.getAssetInstanceVersionDetailsWithNonStaticParametersForTotalCount(assetName, "", userName, from,restApiFlag, conn);
			
			countOfAividsJson.put("count", aivIdsList.get(0));
			countOfAividsJson.put("AivIds", aivIdsList.get(1));
			
			if (log.isDebugEnabled()) {
				log.debug("getAssetInstanceBrowseGridForTotalCount || " + aivIdsList.toString());
			}
			log.debug(" getAssetInstanceBrowseGridForTotalCount  || retrieved " + aivIdsList.size()+ " instances for " + assetName.toString());

			if(aivIdsList.size() == 0){
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAssetInstanceBrowseGridForTotalCount || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceBrowseGridForTotalCount || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceBrowseGridForTotalCount || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceBrowseGridForTotalCount || " + aivIdsList.toString() + " || exit");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, countOfAividsJson))
				.build();

	}
	
	
	/**
	 * @method : viewGroupsWithMultipleAIAccess
	 * @param userName
	 * @param aivId
	 * @return
	 */
	@GET
	@Path("/viewGroupsWithMultipleAIAccess")
	public Response viewGroupsWithMultipleAIAccess(@QueryParam("aivId") String aivIds) {

		if (log.isTraceEnabled()) {
			log.trace("viewGroupsWithMultipleAIAccess || Begin with aivIds : " + aivIds);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<GroupAssetAccess> aivGroupAccessList = new ArrayList<GroupAssetAccess>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("viewGroupsWithMultipleAIAccess || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetInstanceVersionDao dao = new AssetInstanceVersionDao();
			GroupDao groupDao = new GroupDao();

			if (log.isTraceEnabled()) {
				log.trace("viewGroupsWithMultipleAIAccess || dao method called : retGroupsWithAIVersionAccess()");
			}
			List<GroupAssetAccess> retGroupsWithAIVersionAccess = dao.retGroupsWithAIVersionAccessForMultipleAivIds(aivIds, conn);

			if (log.isTraceEnabled()) {
				log.trace("viewGroupsWithMultipleAIAccess || dao method called : getAllGroups()");
			}
			List<GroupDetails> allGroups = groupDao.getAllGroups(conn);
			
			for(GroupDetails gd : allGroups) {
				if(!gd.getGroupName().equalsIgnoreCase("group-admin") && !gd.getGroupName().equalsIgnoreCase("Guest")) {
					GroupAssetAccess aivga = new GroupAssetAccess();
					aivga.setGroupId(gd.getGroupId());
					aivga.setGroupName(gd.getGroupName());
					aivga.setEditAccess((long) 0);
					aivga.setViewAccess((long) 0);
					aivga.setDeleteAccess((long) 0);
					
					aivGroupAccessList.add(aivga);
				}
			}
			
			for(GroupAssetAccess gaa : retGroupsWithAIVersionAccess) {
				boolean checkAccessFlag = false;
				int index = aivGroupAccessList.indexOf(gaa);
				if(index != -1) {
					GroupAssetAccess aivga = aivGroupAccessList.get(index);
					long aivLength = gaa.getAivIdsList().split(",").length;
					long aivIdsLength = aivIds.split(",").length;
					aivga.setGroupId(gaa.getGroupId());
					if(aivLength != aivIdsLength) {
						checkAccessFlag = true;
					}
					else if(gaa.getGroupIdcount() == 0) {
						aivga.setEditAccess((long) 0);
						aivga.setViewAccess((long) 0);
						aivga.setDeleteAccess((long) 0);
					}
					else if(gaa.getGroupIdcount() != 0){
						checkAccessFlag = true;
					}
					if(checkAccessFlag) {
						if(gaa.getEditAccess() == 0) {
							aivga.setEditAccess((long) 0);
						}else if(gaa.getGroupIdcount() == gaa.getEditAccess()) {
							aivga.setEditAccess((long) 1);
						}else if(gaa.getEditAccess() < gaa.getGroupIdcount()) {
							aivga.setEditAccess((long) 2);
						}

						if(gaa.getViewAccess() == 0) {
							aivga.setViewAccess((long) 0);
						}else if(gaa.getGroupIdcount() == gaa.getViewAccess()) {
							aivga.setViewAccess((long) 1);
						}else if(gaa.getViewAccess() < gaa.getGroupIdcount()) {
							aivga.setViewAccess((long) 2);
						}

						if(gaa.getDeleteAccess() == 0) {
							aivga.setDeleteAccess((long) 0);
						}else if(gaa.getGroupIdcount() == gaa.getDeleteAccess()) {
							aivga.setDeleteAccess((long) 1);
						}else if(gaa.getDeleteAccess() < gaa.getGroupIdcount()) {
							aivga.setDeleteAccess((long) 2);
						}
					}
					aivGroupAccessList.set(index, aivga);
				}
			}

			retMsg = Constants.GROUP_ACCESS_ASSET_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("viewGroupsWithMultipleAIAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("viewGroupsWithMultipleAIAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("viewGroupsWithMultipleAIAccess || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(aivGroupAccessList)))
				.build();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
