package com.thbs.repopro.assetinstanceversion;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AddFavourites;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class FavouritesDao {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method AddFavourites 
	 * @Description to insert or delete the favourites
	 * @param addFavourites
	 * @param conn
	 * @return
	 * @throws CreateContentException
	 * @throws DataNotFoundException
	 * @throws RepoproException 
	 */
	public AddFavourites addFavourites(AddFavourites addFavourites,
			Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("addFavourites ||" + addFavourites.toString() + "|| Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addFavourites || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (log.isTraceEnabled()) {
				log.trace("addFavourites ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.INSERT_TO_ADD_FAVOURITES));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.INSERT_TO_ADD_FAVOURITES));

			preparedStmt.setString(Constants.ONE, addFavourites.getFavName());
			preparedStmt.setString(Constants.TWO, addFavourites.getUrl());
			preparedStmt.setLong(Constants.THREE, addFavourites.getUserId());
			preparedStmt.setLong(Constants.FOUR, addFavourites.getAssetInstanceId());
			preparedStmt.executeUpdate();

		} catch (SQLException e) {
			log.error("addFavourites || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INSERT_ADD_FAVOURITES_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addFavourites || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addFavourites||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addFavourites ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addFavourites ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("addFavourites ||" + addFavourites.toString() + "|| End");
		}
		return addFavourites;
	}

	
	/**
	 * 
	 * @param conn
	 * @param userId
	 * @return
	 * @throws DataNotFoundException
	 * @throws RepoproException
	 */
	public List<AddFavourites> getAllFavourites(Connection conn, Long userId)
			throws RepoproException {

		log.trace("getAllFavourites || Begin with userId : "+ userId);

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		
		AddFavourites addFavourites = null;
		List<AddFavourites> favouritedata = new ArrayList<AddFavourites>();
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllFavourites || " + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_FAVOURITES_DATA));
			
			preparedStmt.setLong(Constants.ONE, userId);
			
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllFavourites || " + PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_FAVOURITES_DATA));
			}

			while (rs.next()) {
				addFavourites = new AddFavourites();
				addFavourites.setAssetInstanceId(rs.getLong("asset_inst_id"));
				addFavourites.setFavName(rs.getString("fav_name"));
				String favName = addFavourites.getFavName().split("~")[1];
				String aivId = addFavourites.getFavName().split("~")[0];
				addFavourites.setFavName(favName);
				addFavourites.setAssetInstanceVersionId(Long.parseLong(aivId));
				addFavourites.setAssetInstName(rs.getString("asset_inst_name"));
				addFavourites.setAssetName(rs.getString("asset_name"));
				
				favouritedata.add(addFavourites);
				if (log.isTraceEnabled()) {
					log.trace("getAllFavourites ||" + addFavourites.toString());
				}
			}
			
			if (log.isDebugEnabled()) {
				log.debug("getAllFavourites ||" + favouritedata.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getAllFavourites || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.FAVOURITES_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllFavourites|| " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllFavourites || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllFavourites || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getAllFavourites ||"
						+ Constants.LOG_CONNECTION_CLOSE);

			}
			
		}
		log.trace("getAllFavourites || End");

		return favouritedata;
	}
	
	
	/**
	 * @method : removeFromFavorite
	 * @param userId
	 * @param assetInstId
	 * @param conn
	 * @throws RepoproException
	 */
	public void removeFromFavourite(Long userId, Long assetInstId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("removeFromFavourite || Begin with userId : "+ userId +"\t assetInstId : "+ assetInstId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("removeFromFavourite || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_FROM_ADD_FAVOURITES));
			
			pstmt.setLong(Constants.ONE, userId);
			pstmt.setLong(Constants.TWO, assetInstId);
			
			if (log.isTraceEnabled()) {
				log.trace("removeFromFavourite || "+PropertyFileReader.getInstance().
						getValue(Constants.DELETE_FROM_ADD_FAVOURITES));
			}
			
			pstmt.executeUpdate();
						
			
		} catch (SQLException e) {
			log.error("removeFromFavourite || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.FAVOURITES_DATA_NOT_DELETED));
		} catch (IOException e) {
			log.error("removeFromFavourite || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("removeFromFavourite || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("removeFromFavourite || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("removeFromFavourite || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("removeFromFavourite || end");
		}
	}
	
	
	/**
	 * @method : getMyFavourite
	 * @param assetInstId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AddFavourites getMyFavourite(Long assetInstId, Long userId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getMyFavourite || Begin with assetInstId : "+ assetInstId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AddFavourites addFavourites = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getMyFavourite || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_MY_FAVOURITE));
			
			pstmt.setLong(Constants.ONE, assetInstId);
			pstmt.setLong(Constants.TWO, userId);
			
			if (log.isTraceEnabled()) {
				log.trace("getMyFavourite || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_MY_FAVOURITE));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				addFavourites = new AddFavourites();
				addFavourites.setFavName(rs.getString("fav_name"));
				addFavourites.setUrl(rs.getString("url"));
				
				if(log.isTraceEnabled()){
					log.trace("getMyFavourite || "+ addFavourites.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getMyFavourite || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.FAVOURITES_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getMyFavourite || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getMyFavourite || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getMyFavourite || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getMyFavourite || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getMyFavourite || end");
		}
		return addFavourites;
	}
	
	
	/**
	 * @method : getFavouritesByAssetInstId
	 * @param assetInstId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AddFavourites getFavouritesByAssetInstId(Long aivId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getFavouritesByAssetInstId || Begin with assetInstId : "+ aivId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AddFavourites addFavourites = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getFavouritesByAssetInstId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_FAVOURITE_BY_ASSET_INST_ID));
			
			pstmt.setLong(Constants.ONE, aivId);
			
			if (log.isTraceEnabled()) {
				log.trace("getFavouritesByAssetInstId || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_FAVOURITE_BY_ASSET_INST_ID));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				addFavourites = new AddFavourites();
				
				String assetName = rs.getString("asset_name");
				String assetInstName = rs.getString("asset_inst_name");
				
				addFavourites.setFavName(aivId+"~"+assetInstName+"("+assetName+")");
				addFavourites.setUrl(assetName+"/"+assetInstName);
				
				if(log.isTraceEnabled()){
					log.trace("getFavouritesByAssetInstId || "+ addFavourites.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getFavouritesByAssetInstId || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.FAVOURITES_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getFavouritesByAssetInstId || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getFavouritesByAssetInstId || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getFavouritesByAssetInstId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getFavouritesByAssetInstId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getFavouritesByAssetInstId || end");
		}
		return addFavourites;
	}
	
	
	/**
	 * @method : OnRenameAssetInstanceRenameFavourites
	 * @param assetName
	 * @param assetInstName
	 * @param assetInstId
	 * @param assetInstVersionId
	 * @param userId
	 * @param conn
	 * @throws RepoproException
	 */
	public void OnRenameAssetInstanceRenameFavourites(String assetName, String assetInstName, Long assetInstId, Long assetInstVersionId, Long userId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("OnRenameAssetInstanceRenameFavourites || Begin with assetName : "+ assetName 
					+" \t assetInstName : "+ assetInstName +" \t assetInstId : "+ assetInstId 
					+" \t assetInstVersionId : "+ assetInstVersionId +" \t userId : "+ userId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("OnRenameAssetInstanceRenameFavourites || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			String favName = assetInstVersionId+"~"+assetInstName+"("+assetName+")";
			
			AddFavourites myFavourite = getMyFavourite(assetInstId,userId,conn);
			
			if(myFavourite != null){
				myFavourite.setFavName(favName);
				myFavourite.setUrl(assetName+"/"+assetInstName);
				
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.UPDATE_FAVOURITES));
				
				pstmt.setString(Constants.ONE, myFavourite.getFavName());
				pstmt.setString(Constants.TWO, myFavourite.getUrl());
				pstmt.setLong(Constants.THREE, assetInstId);
				
				if (log.isTraceEnabled()) {
					log.trace("OnRenameAssetInstanceRenameFavourites || "+PropertyFileReader.getInstance().
							getValue(Constants.UPDATE_FAVOURITES));
				}
				pstmt.executeUpdate();
			}
			
			
		} catch (SQLException e) {
			log.error("OnRenameAssetInstanceRenameFavourites || " + Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.FAVOURITES_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("OnRenameAssetInstanceRenameFavourites || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("OnRenameAssetInstanceRenameFavourites || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("OnRenameAssetInstanceRenameFavourites || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("OnRenameAssetInstanceRenameFavourites || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("OnRenameAssetInstanceRenameFavourites || end");
		}	
	}
	
	
	/**
	 * @method : OnRenameAssetRenameFavourites
	 * @param oldAssetName
	 * @param newAssetName
	 * @param conn
	 * @throws RepoproException
	 */
	public void OnRenameAssetRenameFavourites(String oldAssetName, String newAssetName, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("OnRenameAssetRenameFavourites || Begin with oldAssetName : "+ oldAssetName 
					+"\t newAssetName : "+ newAssetName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("OnRenameAssetRenameFavourites || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if(!oldAssetName.equalsIgnoreCase(newAssetName)){
			List<AddFavourites> retFavouriteBasedOnAssetName = retFavouriteBasedOnAssetName(oldAssetName, conn);
			
			if(!retFavouriteBasedOnAssetName.isEmpty()){
				for(AddFavourites addFavourites : retFavouriteBasedOnAssetName){
					String fevAssetName = addFavourites.getUrl().substring(0, oldAssetName.length()+1);
					 
					if(fevAssetName.equals(oldAssetName+"/")){
						addFavourites.setUrl(addFavourites.getUrl().replace(fevAssetName,newAssetName+"/"));
					}
					if(addFavourites.getFavName().indexOf("("+oldAssetName+")")>0){
						addFavourites.setFavName(addFavourites.getFavName().replace("("+oldAssetName+")", "("+newAssetName+")"));
					}
					
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.UPDATE_FAVOURITES_ASSET_NAME));
					
					pstmt.setString(Constants.ONE, addFavourites.getFavName());
					pstmt.setString(Constants.TWO, addFavourites.getUrl());
					pstmt.setLong(Constants.THREE, addFavourites.getAssetInstanceId());
					
					if (log.isTraceEnabled()) {
						log.trace("OnRenameAssetInstanceRenameFavourites || "+PropertyFileReader.getInstance().
								getValue(Constants.UPDATE_FAVOURITES_ASSET_NAME));
					}
					pstmt.addBatch();
				}
				pstmt.executeBatch();
			}
			}
			
		} catch (SQLException e) {
			log.error("OnRenameAssetRenameFavourites || " + Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.FAVOURITES_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("OnRenameAssetRenameFavourites || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("OnRenameAssetRenameFavourites || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("OnRenameAssetRenameFavourites || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("OnRenameAssetRenameFavourites || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("OnRenameAssetRenameFavourites || end");
		}		
	}
	
	
	/**
	 * @method : retFavouriteBasedOnAssetName
	 * @param assetName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AddFavourites> retFavouriteBasedOnAssetName(String assetName, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("retFavouriteBasedOnAssetName || Begin with assetName : "+ assetName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AddFavourites addFavourites = null;
		List<AddFavourites> favList = new ArrayList<AddFavourites>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("retFavouriteBasedOnAssetName || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_FAV_BASED_ON_ASSET_NAME));
			
			pstmt.setString(Constants.ONE, "%"+assetName+"/%");
			
			rs = pstmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retFavouriteBasedOnAssetName || " + PropertyFileReader.getInstance().getValue(
								Constants.RET_FAV_BASED_ON_ASSET_NAME));
			}

			while (rs.next()) {
				addFavourites = new AddFavourites();
				addFavourites.setFavName(rs.getString("fav_name"));
				addFavourites.setUrl(rs.getString("url"));
				addFavourites.setUserId(rs.getLong("user_id"));
				addFavourites.setAssetInstanceId(rs.getLong("asset_inst_id"));
				favList.add(addFavourites);
				if (log.isTraceEnabled()) {
					log.trace("retFavouriteBasedOnAssetName ||" + addFavourites.toString());
				}
			}
			
			if (log.isDebugEnabled()) {
				log.debug("retFavouriteBasedOnAssetName ||" + favList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("retFavouriteBasedOnAssetName || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.FAVOURITES_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retFavouriteBasedOnAssetName || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retFavouriteBasedOnAssetName || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retFavouriteBasedOnAssetName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retFavouriteBasedOnAssetName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("retFavouriteBasedOnAssetName || end");
		}
		return favList;
	}
}
