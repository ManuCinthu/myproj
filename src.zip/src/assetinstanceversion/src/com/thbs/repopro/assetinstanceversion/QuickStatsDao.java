package com.thbs.repopro.assetinstanceversion;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AdminAccessName;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.QuickStats;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class QuickStatsDao {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method getQuickStats
	 * @description get list of assets with count of asset instances
	 * @param userName
	 * @param conn
	 * @return List<QuickStats>
	 * @throws RepoproException
	 */
	public List<QuickStats> getQuickStats(String userName, Connection conn)
			throws RepoproException {
		if(log.isTraceEnabled()){
			log.trace("getQuickStats || begin  userName"+userName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		PreparedStatement preparedStm = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		ResultSet resultSet = null;
		ResultSet relset = null;
		AssetDef assetDef = null;
		List<AssetDef> assetDefList = new ArrayList<AssetDef>();
		QuickStats quickStats = null;
		List<QuickStats> quickStatsList = new ArrayList<QuickStats>();
		AdminAccessName adminAccessName = null;
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		boolean flag = false;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getQuickStats || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ASSETS));
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("getQuickStats || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_ASSETS));
			}
			while (rs.next()) {
				assetDef = new AssetDef();
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDefList.add(assetDef);
				if (log.isTraceEnabled()) {
					log.trace("getQuickStats || returning resultset  : "
							+ assetDef.getAssetId().toString());
				}

			}
			if (log.isDebugEnabled()) {
				log.debug("getQuickStats || returning resultset  : "
						+ assetDefList.toString());
			}

			if (userName.equalsIgnoreCase("roleAnonymous")) {

				preparedStm = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ASSET_AND_COUNT_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getQuickStats || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ASSET_AND_COUNT_FOR_GUEST));
				}

				for (int i = 0; i < assetDefList.size(); i++) {
					preparedStm.setLong(Constants.ONE, assetDefList.get(i)
							.getAssetId());
					resultSet = preparedStm.executeQuery();
					while (resultSet.next()) {
						quickStats = new QuickStats();
						quickStats.setAssetName(resultSet.getString("asset_name"));
						quickStats.setAssetId(resultSet.getLong("asset_id"));
						quickStats.setAssetIconImageName(resultSet.getString("icon_image_name"));
						quickStats.setAssetInstanceVersionCount(resultSet.getLong("count"));
						if (quickStats.getAssetName() != null) {
							quickStatsList.add(quickStats);
						}
						if (log.isTraceEnabled()) {
							log.trace("getQuickStats || returning resultset  : "
									+ quickStats.toString());
						}
					}
				}
			} else {

				preparedStm = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ADMIN_RIGHT));
				if (log.isTraceEnabled()) {
					log.trace("getQuickStats || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ADMIN_RIGHT));
				}
				preparedStm.setString(Constants.ONE, userName);
				resultSet = preparedStm.executeQuery();

				while (resultSet.next()) {
					adminAccessName = new AdminAccessName();
					adminAccessName.setUserName(resultSet
							.getString("user_name"));
					adminAccessName.setGroupName(resultSet
							.getString("group_name"));
					adminAccessName.setRoleName(resultSet
							.getString("role_name"));
					adminAccessNameList.add(adminAccessName);
					if (log.isTraceEnabled()) {
						log.trace("getQuickStats || returning resultset for admin check : "
								+ adminAccessName.toString());
					}
				}

				for (AdminAccessName adminAccess : adminAccessNameList) {
					if (adminAccess.getUserName().equalsIgnoreCase("admin")
							|| adminAccess.getGroupName().equalsIgnoreCase(
									"group-admin")
									|| adminAccess.getRoleName().equalsIgnoreCase(
											"role-admin")) {
						flag = true;
					}
				}

				if (flag) {
					preparedSt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(
									Constants.GET_ASSET_AND_COUNT_FOR_ADMIN));
					if (log.isTraceEnabled()) {
						log.trace("getQuickStats || "
								+ PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_AND_COUNT_FOR_ADMIN));
					}
					for (int i = 0; i < assetDefList.size(); i++) {
						preparedSt.setLong(Constants.ONE, assetDefList.get(i)
								.getAssetId());
						relset = preparedSt.executeQuery();
						while (relset.next()) {
							quickStats = new QuickStats();
							quickStats.setAssetName(relset.getString("asset_name"));
							quickStats.setAssetId(relset.getLong("asset_id"));
							quickStats.setAssetIconImageName(relset.getString("icon_image_name"));
							quickStats.setAssetInstanceVersionCount(relset.getLong("count"));
							if (quickStats.getAssetName() != null) {
								quickStatsList.add(quickStats);
							}
							if (log.isTraceEnabled()) {
								log.trace("getQuickStats || returning resultset  : "
										+ quickStats.toString());
							}
						}
					}

				} else {
					preparedSt = conn
							.prepareStatement(PropertyFileReader
									.getInstance()
									.getValue(
											Constants.GET_ASSET_AND_COUNT_FOR_NON_ADMIN_USER));
					if (log.isTraceEnabled()) {
						log.trace("getQuickStats || "
								+ PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_AND_COUNT_FOR_NON_ADMIN_USER));
					}
					for (int i = 0; i < assetDefList.size(); i++) {
						preparedSt.setString(Constants.ONE, userName);
						preparedSt.setLong(Constants.TWO, assetDefList.get(i).getAssetId());
						relset = preparedSt.executeQuery();
						while (relset.next()) {
							quickStats = new QuickStats();
							quickStats.setAssetName(relset.getString("asset_name"));
							quickStats.setAssetId(relset.getLong("asset_id"));
							quickStats.setAssetIconImageName(relset.getString("icon_image_name"));
							quickStats.setAssetInstanceVersionCount(relset.getLong("count"));
							if (quickStats.getAssetName() != null) {
								quickStatsList.add(quickStats);
							}
							if (log.isTraceEnabled()) {
								log.trace("getQuickStats || returning resultset  : "
										+ quickStats.toString());
							}
						}
					}
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getQuickStats || returning resultset  : "
						+ quickStatsList.toString());
			}
		} catch (SQLException e) {
			log.error("getQuickStats ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.GET_QUICKSTATS_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getQuickStats ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getQuickStats ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getQuickStats ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(relset);
			DBConnection.closeResultSet(rs);
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closePreparedStatement(preparedStm);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getQuickStats ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		log.trace("getQuickStats || exit");

		return quickStatsList;
	}
}
