package com.thbs.repopro.assetinstanceversion;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.DiscussionComment;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.GroupAssetInstVersionAccess;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Path("/discussionmanager")
public class DiscussionCommentManager {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	/**
	 * @method : listAllComments
	 * @param aivId
	 * @return
	 */
	@GET
	@Path("/listallcomments")
	public Response listAllComments(@QueryParam("aivId") Long aivId, @QueryParam("userName") String userName){
		
		if(log.isTraceEnabled()){
			log.trace("listAllComments || Begin with aivId : "+ aivId);
		}
		
		Connection conn = null;
		
		List<DiscussionComment> commentsList = new ArrayList<DiscussionComment>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("listAllComments || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			conn = DBConnection.getInstance().getConnection();
			
			DiscussionCommentDao dao = new DiscussionCommentDao();
			
			if (log.isTraceEnabled()) {
				log.trace("listAllComments || dao method called : listAllComments()");
			}
			commentsList = dao.listAllComments(aivId, userName, conn);
			
			log.info("listAllComments || retrieved "+ commentsList.size()+ " comments successfully");
			
			retMsg = Constants.ALL_COMMENTS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("listAllComments || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}catch(Exception e){
			log.error("listAllComments || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("listAllComments || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("listAllComments || end ");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(commentsList))).build();
		
	}
	
	/**
	 * @method : addComment
	 * @param dc
	 * @return
	 */
	@POST
	@Path("/addcomment")
	public Response addComment(DiscussionComment dc){
		
		if(log.isTraceEnabled()){
			log.trace("addComment || "+ dc.toString() +" Begin");
		}
		
		Connection conn = null;
		
		List<DiscussionComment> commentsList = new ArrayList<DiscussionComment>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();
		try {
			if (log.isTraceEnabled()){
				log.trace("addComment || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			//get global setting setting details
			if (log.isTraceEnabled()){
				log.trace("addComment || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
			
			DiscussionCommentDao dao = new DiscussionCommentDao();
			
			if(globalsetting.getGlobalSettingFlag() == 1){
				String description = commonUtils.httpSanitizerForPlainText(dc.getDescription());
				dc.setDescription(description);
			}
			if (log.isTraceEnabled()) {
				log.trace("addComment || dao method called : addComment()");
			}
			DiscussionComment addComment = dao.addComment(dc, conn);
			
			Long commentId = addComment.getCommentId();
			Long parentCommentId = addComment.getParentCommentId();
			
			retMsg = Constants.COMMENT_ADDED;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			
			dc.setCommentId(commentId);
			dc.setParentCommentId(parentCommentId);
			commentsList.add(dc);
			
			log.info("addComment || "+ dc.toString() +" added comment successfully");
			conn.commit();
			
			
		} catch (RepoproException e) {
			log.error("addComment || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("addComment || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addComment || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("addComment || end ");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(commentsList)))
				.build();
	}
	
	/**
	 * @method : addReply
	 * @param dc
	 * @return
	 */
	@POST
	@Path("/addreply")
	public Response addReply(DiscussionComment dc){
		
		if(log.isTraceEnabled()){
			log.trace("addReply || "+ dc.toString() +" Begin");
		}
		
		Connection conn = null;
		
		List<DiscussionComment> commentsList = new ArrayList<DiscussionComment>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();
	
		try {
			if (log.isTraceEnabled()){
				log.trace("addReply || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			//get global setting setting details
			if (log.isTraceEnabled()){
				log.trace("addReply || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
			
			DiscussionCommentDao dao = new DiscussionCommentDao();
			
			if(globalsetting.getGlobalSettingFlag() == 1){
				String description = commonUtils.httpSanitizerForPlainText(dc.getDescription());
				dc.setDescription(description);
			}
			if (log.isTraceEnabled()) {
				log.trace("addReply || dao method called : addReply()");
			}
			DiscussionComment addReply = dao.addReply(dc, conn);
			
			Long commentId = addReply.getCommentId();
			Long parentCommentId = addReply.getParentCommentId();
			
			retMsg = Constants.REPLY_ADDED;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			
			dc.setCommentId(commentId);
			dc.setParentCommentId(parentCommentId);
			commentsList.add(dc);
			
			log.info("addReply || "+ dc.toString() +" added reply successfully");
			conn.commit();
			
			
		} catch(RepoproException e){
			log.error("addReply || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch(Exception e){
			log.error("addReply || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addReply || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("addReply || end ");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(commentsList)))
				.build();
		
	}
	
/***Wrapper function***/
	@GET
	@Path("/listallcommentsMain")
	public Response listAllCommentsMain(
			@QueryParam("assetName")String assetName,
			@QueryParam("assetInstName")String assetInstName,
			@QueryParam("assetVersionName")String assetVersionName,
			@QueryParam("userName")String userName){
		log.trace("listAllCommentsMain || Begin");
		Connection conn = null;
		Response response = null;
		
		boolean viewFlag = false;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("listAllCommentsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User userdata = userDao.getUserIdByUserName(userName, null);
				if(userdata.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			
			if(assetInstanceVer == null){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("listAllCommentsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			long aivId = assetInstanceVer.getAssetInstVersionId();
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aivId, userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
			    	viewFlag = true;
				    break;
			    }
		    }

		    if (viewFlag) {
		    	response = this.listAllComments(aivId, userName);
				return response;
		    } else {
		    	retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			
		} catch (RepoproException e) {
			log.error("listAllCommentsMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("listAllCommentsMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("listAllCommentsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("listAllCommentsMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
	}

/***Wrapper function***/
	@POST
	@Path("/addcommentMain")
	public Response addCommentMain(DiscussionComment dc,@QueryParam("userName") String userName) {
		log.trace("addCommentMain || Begin");
		Connection conn = null;
		Response response = null;
		DiscussionComment comment = new DiscussionComment();
		//String userName = null;
		Long userId = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		boolean editFlag = false;

		try {
			if (log.isTraceEnabled()) {
				log.trace("addCommentMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			User user = new User();
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User userdata = userDao.getUserIdByUserName(userName, null);
				if(userdata.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (dc.getUserName().equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			} else {
				userName = dc.getUserName();
				user = userDao.getUserIdByUserName(userName, conn);
				if (userId == null) {
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("addCommentMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();

			assetInstance.setAssetName(dc.getAssetName());
			assetInstance.setAssetInstName(dc.getAssetInstName());
			assetInstance.setVersionName(dc.getAssetVersionName());
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao
					.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INST_VERSION_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("addCommentMain || End");
				return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}

			long aivId = assetInstanceVer.getAssetInstVersionId();
			comment.setAssetInstanceVersionId(aivId);
			comment.setUserId(userId);
			comment.setDescription(dc.getDescription());
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aivId, userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
			    	editFlag = true;
				    break;
			    }
		    }

		    if (editFlag) {
		    	response = this.addComment(comment);
				return response;
		    } else {
		    	retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
		    

		} catch (RepoproException e) {
			log.error("addCommentMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addCommentMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addCommentMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("addCommentMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

/***Wrapper function***/
	@POST
	@Path("/addreplyMain")
	public Response addReplyMain(DiscussionComment dc,@QueryParam("userName") String userName) {
		log.trace("addReplyMain || Begin");
		Connection conn = null;
		Response response = null;
		DiscussionComment comment = new DiscussionComment();
		//String userName = null;
		Long userId = null;
		long parentCommentId = 0;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		boolean editFlag = false;

		try {
			if (log.isTraceEnabled()) {
				log.trace("addReplyMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			DiscussionCommentDao discussionCommentDao = new DiscussionCommentDao();
			User user = new User();
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User userdata = userDao.getUserIdByUserName(userName, null);
				if(userdata.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (dc.getUserName().equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			} else {
				userName = dc.getUserName();
				
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("addReplyMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}

			assetInstance.setAssetName(dc.getAssetName());
			assetInstance.setAssetInstName(dc.getAssetInstName());
			assetInstance.setVersionName(dc.getAssetVersionName());
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("addReplyMain || End");
				return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}

			long aivId = assetInstanceVer.getAssetInstVersionId();
			if (user.getUserId() != null) {
				parentCommentId = discussionCommentDao.getParentCommentId(
						user.getUserId(), aivId, dc.getDescription(), conn);
			}
			comment.setAssetInstanceVersionId(aivId);
			comment.setUserId(user.getUserId());
			comment.setDescription(dc.getDescription());
			comment.setParentCommentId(parentCommentId);
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(aivId, userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
			    	editFlag = true;
				    break;
			    }
		    }

		    if (editFlag) {
		    	response = addReply(comment);
				return response;
		    } else {
		    	retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			
			

		} catch (RepoproException e) {
			log.error("addReplyMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			log.error("addReplyMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addReplyMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("addReplyMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
}
