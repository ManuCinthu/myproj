package com.thbs.repopro.assetinstanceversion;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.dto.AddFavourites;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.GroupAssetInstVersionAccess;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;

@Path("/favourite")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class FavouritesManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");
	
	/**
	 * @method AddFavourites
	 * @Description to insert or delete the favourites
	 * @param userId
	 * @param assetInstanceId
	 * @return
	 * @
	 */
	@POST
	@Path("/addtofavourites")
	public Response addToFavourite(@QueryParam("userId") Long userId,
			@QueryParam("assetInstanceId") Long assetInstanceId,
			@QueryParam("assetInstVersionId") Long aivId)
			{

		if(log.isTraceEnabled()){
			log.trace("addToFavourite || Begin with userId : "+ userId +"\t assetInstanceId : "+ assetInstanceId);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
			
		AddFavourites addFavourites = new AddFavourites();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addToFavourite ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			FavouritesDao dao = new FavouritesDao();
			
			if(log.isTraceEnabled()){
				log.trace("addToFavourite || dao method called : getFavouritesByAssetInstId()");
			}
			AddFavourites favouritesByAssetInstId = dao.getFavouritesByAssetInstId(aivId, conn);
			
			addFavourites.setUserId(userId);
			addFavourites.setAssetInstanceId(assetInstanceId);
			addFavourites.setFavName(favouritesByAssetInstId.getFavName());
			addFavourites.setUrl(favouritesByAssetInstId.getUrl());
			
			if(log.isTraceEnabled()){
				log.trace("addToFavourite || dao method called : addFavourites()");
			}
			dao.addFavourites(addFavourites, conn);
			
			conn.commit();

			log.info("addToFavourite || added to my favourites successfully");
			
			retMsg = Constants.FAVOURITES_ADDED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addToFavourite ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("addToFavourite || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

	}

	/**
	 * @Method getAllFavourites
	 * @Description shows all the details of the userid
	 * @param userId
	 * @return
	 * @
	 */
	@GET
	@Path("/id")
	public Response getAllFavourites(@QueryParam("userId") Long userId){
		if(log.isTraceEnabled()){
			log.trace("getAllFavourites || Begin :userId:"+userId);
		}
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<AddFavourites> favouriteList = new ArrayList<AddFavourites>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllFavourites || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			FavouritesDao dao = new FavouritesDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getAllFavourites ||dao method called : getAllFavourites()");
			}
			favouriteList = dao.getAllFavourites(conn, userId);

			log.info("getAllFavourites || retrieved all favourites ");
			

		} catch (RepoproException e) {
			log.error("getAllFavourites || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllFavourites || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllFavourites || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (favouriteList.isEmpty()) {
			retMsg = Constants.FAVOURITES_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} else {
			retMsg = Constants.ALL_FAVOURITES_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		}

		log.trace("getAllFavourites|| End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(favouriteList))).build();
	}
	
	
	/**
	 * @method : removeFromFavorite
	 * @param assetInstId
	 * @param userId
	 * @return
	 */
	@DELETE
	@Path("/removeFromFavourite")
	public Response removeFromFavourite(@QueryParam("assetInstId") Long assetInstId, @QueryParam("userId") Long userId){
		
		if(log.isTraceEnabled()){
			log.trace("removeFromFavorite || Begin with assetInstId : "+ assetInstId +"\t userId : "+ userId);
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("removeFromFavorite || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			FavouritesDao dao = new FavouritesDao();
			
			if (log.isTraceEnabled()) {
				log.trace("removeFromFavorite ||dao method called : removeFromFavourite()");
			}
			dao.removeFromFavourite(userId, assetInstId, conn);
			
			conn.commit();
			
			retMsg = Constants.FAVOURITES_DATA_DELETED;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			
			log.info("removeFromFavourite || removed from my favouritess successfully");
			
			
		} catch(RepoproException e){
			log.error("removeFromFavourite || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch(Exception e){
			log.error("removeFromFavourite || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("removeFromFavourite || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
				.build();
	}
	
	
	/**
	 * @method : getMyFavourite
	 * @param assetInstId
	 * @return
	 */
	@GET
	@Path("/getMyFavourite")
	public Response getMyFavourite(@QueryParam("assetInstId") Long assetInstId, 
			@QueryParam("userId") Long userId){
		
		if(log.isTraceEnabled()){
			log.trace("getMyFavourite || Begin with assetInstId : "+ assetInstId);
		}
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AddFavourites addFavourites = new AddFavourites();
		List<AddFavourites> favList = new ArrayList<AddFavourites>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getMyFavourite || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			FavouritesDao dao = new FavouritesDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getMyFavourite ||dao method called : getMyFavourite()");
			}
			addFavourites = dao.getMyFavourite(assetInstId, userId, conn);
			favList.add(addFavourites);
			
			log.info("getMyFavourite || fetched my favourite");
			
			
		} catch(RepoproException e){
			log.error("getMyFavourite || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getMyFavourite || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getMyFavourite || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (addFavourites == null) {
			
			return Response
					.status(Status.OK)
					.entity(new MyModel(Constants.GET_STATUS_SUCCESS,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.FAVOURITES_DATA_NOT_FOUND)))
					.build();
		} else {
			addFavourites.setFavouriteflag(1L);
			return Response
					.status(Status.OK)
					.entity(new MyModel(Constants.GET_STATUS_SUCCESS,
							Constants.SUCCESS, MessageUtil
							.getMessage(Constants.FAVOURITES_DATA_FETCHED),new ArrayList<Object>(favList)))
					.build();
		}
		
	}



/***Wrapper function***/
	@GET
	@Path("/get")
	public Response getAllFavouritesMain(@QueryParam("userName") String userName) {
		log.trace("getAllFavouritesMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllFavouritesMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			} else {
				User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("getAllFavouritesMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
				response = this.getAllFavourites(user.getUserId());
				return response;
			}
		} catch (RepoproException e) {
			log.error("getAllFavouritesMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllFavouritesMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllFavouritesMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllFavouritesMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

}
