package com.thbs.repopro.accesscontrol;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.GroupAssetAccess;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.GroupRoles;
import com.thbs.repopro.dto.Role;
import com.thbs.repopro.dto.UserGroups;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class GroupDao {

	//Logger log = Logger.getLogger(GroupDao.class.getName());
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );

	/**
	 * @method : addGroup
	 * @param group details
	 * @description : to create a new group
	 * @throws RepoproException 
	 * @throws RepoproException 
	 */
	
	public GroupDetails addGroup(GroupDetails groupDetails, Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("addGroup || "+ groupDetails.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			if (log.isTraceEnabled()){
				log.trace("addGroup || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.CREATE_GROUP));
			
			pstmt.setString(Constants.ONE, groupDetails.getGroupName());
			pstmt.setString(Constants.TWO, groupDetails.getDescription());

			if (log.isTraceEnabled()) {
				log.trace("addGroup || "+ PropertyFileReader.getInstance().
						getValue(Constants.CREATE_GROUP));
			}
			
			pstmt.execute();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				groupDetails.setGroupId(rs.getLong(1));
			}
			
		} catch (SQLException e) {
			log.error("addGroup || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.GROUP_NOT_CREATED));
		} catch (IOException e) {
			log.error("addGroup || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addGroup || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addGroup || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addGroup || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("addGroup || generated userId : "+ groupDetails.getGroupId() +" End");
		}
		return groupDetails;
	}
	
	
	/**
	 * @method : getAllGroups
	 * @description : to get all groups
	 * @return List<GroupDetails>
	 * @throws RepoproException
	 * @throws RepoproException 
	 */
	public List<GroupDetails> getAllGroups(Connection conn) throws RepoproException{

		log.trace("getAllGroups || Begin");
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<GroupDetails> groupList = new ArrayList<GroupDetails>();
		GroupDetails groupDetails = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroups || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_GROUPS));
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroups || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_GROUPS));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				groupDetails = new GroupDetails();
				groupDetails.setGroupId(rs.getLong("group_id"));
				groupDetails.setGroupName(rs.getString("group_name"));
				groupDetails.setDescription(rs.getString("description"));
				groupList.add(groupDetails);
				if(log.isTraceEnabled()){
					log.trace("getAllGroups || "+ groupDetails.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllGroups || "+ groupList.toString());
			}

		} catch (SQLException e) {
			log.error("getAllGroups || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.GROUPS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllGroups || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllGroups || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllGroups || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeResultSet(rs);
			if (log.isTraceEnabled()) {
				log.trace("getAllGroups || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		
		log.trace("getAllGroups || End");
		
		return groupList;
	}
	
	/**
	 * @method : getGroupIdByGroupName
	 * @description : to get GroupId
	 * @param group name
	 * @return groupId
	 * @throws RepoproException 
	 */
	public int getGroupIdByGroupName(String groupName, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getGroupIdByGroupName || Begin with group name : "+ groupName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int group_id = 0;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getGroupIdByGroupName || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_GROUP_ID_BY_GROUP_NAME));
			
			pstmt.setString(Constants.ONE, groupName);
			
			if (log.isTraceEnabled()) {
				log.trace("getGroupIdByGroupName || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_GROUP_ID_BY_GROUP_NAME));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				group_id = rs.getInt("group_id");
				if(log.isTraceEnabled()){
					log.trace("getGroupIdByGroupName || "+ group_id);
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getGroupIdByGroupName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.GROUPS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getGroupIdByGroupName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getGroupIdByGroupName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getGroupIdByGroupName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getGroupIdByGroupName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getGroupIdByGroupName || End");
		}
		
		return group_id;
		
	}
	
	
	/**
	 * @method updateGroup
	 * @description to update a Group
	 * @param updateGroup
	 * @throws RepoproException 
	 */
	public void updateGroup(GroupDetails updateGroup, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("updateGroup || "+ updateGroup.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateGroup || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_GROUP));
			
			pstmt.setString(Constants.ONE, updateGroup.getGroupName());
			pstmt.setString(Constants.TWO, updateGroup.getDescription());
			pstmt.setLong(Constants.THREE, updateGroup.getGroupId());
			
			if (log.isTraceEnabled()) {
				log.trace("updateGroup || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_GROUP));
			}

			int result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("updateGroup || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateGroup || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateGroup || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("updateGroup || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateGroup || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("updateGroup || End");
		}
		
	}
	
	/**
	 * @method deleteGroup
	 * @description to delete a Group
	 * @param groupId
	 * @return Response Success message
	 * @throws RepoproException 
	 */
	public String deleteGroup(Long groupId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("deleteGroup || Begin with groupId : "+ groupId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		String msg = "";
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteGroup || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_GROUP));
			
			pstmt.setLong(Constants.ONE, groupId);
			
			if (log.isTraceEnabled()) {
				log.trace("deleteGroup || "+PropertyFileReader.getInstance().
						getValue(Constants.DELETE_GROUP));
			}
			
			int result = pstmt.executeUpdate();
						
		} catch (SQLException e) {
			log.error("deleteGroup || " + Constants.LOG_DELETE_SQLEXCEPTION+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteGroup || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteGroup || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("deleteGroup || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteGroup || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("deleteGroup || End");
		}
		return msg;
		
	}
	
	/**
	 * @method : getUserGroupsByGroupId
	 * @description : to get user groups
	 * @param group Id
	 * @return List<UserGroups>
	 * @throws RepoproException
	 */
	public List<UserGroups> getUserGroupsByGroupId(Long groupId, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getUserGroupsByGroupId || Begin with groupId : "+ groupId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<UserGroups> userGroupsList = new ArrayList<UserGroups>();
		UserGroups userGroups = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getUserGroupsByGroupId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USER_GROUPS_BY_GROUP_ID));
						
			pstmt.setLong(Constants.ONE, groupId);
			
			if (log.isTraceEnabled()) {
				log.trace("getUserGroupsByGroupId || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_USER_GROUPS_BY_GROUP_ID));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				userGroups = new UserGroups();
				userGroups.setUserGroupsId(rs.getLong("user_groups_id"));
				userGroups.setUserId(rs.getLong("user_id"));
				userGroups.setGroupId(rs.getLong("group_id"));
				userGroupsList.add(userGroups);
				if(log.isTraceEnabled()){
					log.trace("getUserGroupsByGroupId || "+ userGroups.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getUserGroupsByGroupId || "+ userGroupsList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getUserGroupsByGroupId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_GROUPS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getUserGroupsByGroupId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getUserGroupsByGroupId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getUserGroupsByGroupId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getUserGroupsByGroupId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getUserGroupsByGroupId || End");
		}
		return userGroupsList;
	}
	
	/**
	 * @method : deleteGroupRoleByGroupId
	 * @param groupId
	 * @throws RepoproException 
	 */
	public void deleteGroupRoleByGroupId(Long groupId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("deleteGroupRoleByGroupId || Begin with groupId : "+ groupId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteGroupRoleByGroupId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			List<GroupRoles> groupRolesList = retGroupRolesByGroupId(groupId, conn);
			for(GroupRoles roles : groupRolesList){
				deleteGroupRole(roles, conn);
			}
			
			
		} catch (SQLException e) {
			log.error("deleteGroupRoleByGroupId || " + Constants.LOG_DELETE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ROLE_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteGroupRoleByGroupId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteGroupRoleByGroupId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("deleteGroupRoleByGroupId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteGroupRoleByGroupId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("deleteGroupRoleByGroupId || End");
		}
		
	}
	
	/**
	 * @method : retGroupRolesByGroupId
	 * @param groupId
	 * @param conn
	 * @return List<GroupRoles>
	 * @throws RepoproException
	 */
	public List<GroupRoles> retGroupRolesByGroupId(Long groupId, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("retGroupRolesByGroupId || Begin with groupId : "+ groupId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<GroupRoles> groupRolesList = new ArrayList<GroupRoles>();
		GroupRoles groupRoles = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("retGroupRolesByGroupId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_GROUP_ROLES_BY_GROUP_ID));
			
			pstmt.setLong(Constants.ONE, groupId);
			
			if (log.isTraceEnabled()) {
				log.trace("retGroupRolesByGroupId || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_GROUP_ROLES_BY_GROUP_ID));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				groupRoles = new GroupRoles();
				groupRoles.setGroupRolesId(rs.getLong("group_roles_id"));
				groupRoles.setGroupId(rs.getLong("group_id"));
				groupRoles.setRoleId(rs.getLong("role_id"));
				groupRolesList.add(groupRoles);
				if(log.isTraceEnabled()){
					log.trace("retGroupRolesByGroupId || "+groupRoles.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("retGroupRolesByGroupId || "+groupRolesList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("retGroupRolesByGroupId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ROLES_NOT_FOUND));
		} catch (IOException e) {
			log.error("retGroupRolesByGroupId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retGroupRolesByGroupId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("retGroupRolesByGroupId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retGroupRolesByGroupId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("retGroupRolesByGroupId || End");
		}
		return groupRolesList;
	}
	
	/**
	 * @method : deleteGroupRole
	 * @param groupRoles obj
	 * @throws RepoproException 
	 */
	public void deleteGroupRole(GroupRoles groupRoles, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("deleteGroupRole || "+ groupRoles.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		List<String> msg = new ArrayList<String>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteGroupRole || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_GROUP_ROLES));
			
			pstmt.setLong(Constants.ONE, groupRoles.getGroupId());
			
			if (log.isTraceEnabled()) {
				log.trace("deleteGroupRole || "+PropertyFileReader.getInstance().
							getValue(Constants.DELETE_GROUP_ROLES));
			}
			
			int result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("deleteGroupRole || " + Constants.LOG_DELETE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ROLE_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteGroupRole || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteGroupRole || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("deleteGroupRole || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteGroupRole || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("deleteGroupRole || End");
		}
	}
	
	/**
	 * @method : delGroup
	 * @param groupId
	 * @return List<String>
	 * @throws RepoproException 
	 */
	public String delGroup(Long groupId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("deleteGroup || Begin with groupId : "+ groupId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		String msg = "";
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteGroup || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			GroupDetails groupDetailsList = getGroupById(groupId, conn);
			
			if(log.isTraceEnabled()){
				log.trace("deleteGroup || "+ groupDetailsList.toString() + 
								"retrieved groups by id successfully");
			}
			
			if(groupDetailsList != null){
				msg = deleteGroup(groupId, conn);
			}
			
			
		} catch (SQLException e) {
			log.error("deleteGroupRole || " + Constants.LOG_DELETE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteGroupRole || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteGroupRole || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("deleteGroupRole || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteGroupRole || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("deleteGroupRole || End");
		}
		return msg;
		
	}
	
	/**
	 * @method : getGroupById
	 * @param groupId
	 * @return List<GroupDetails>
	 * @throws RepoproException
	 */
	public GroupDetails getGroupById(Long groupId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getGroupById || Begin with groupId : "+ groupId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		GroupDetails groupDetails = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getGroupById || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_GROUP_BY_ID));
			
			pstmt.setLong(Constants.ONE, groupId);
			
			if (log.isTraceEnabled()) {
				log.trace("getGroupById || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_GROUP_BY_ID));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				groupDetails = new GroupDetails();
				groupDetails.setGroupId(rs.getLong("group_id"));
				groupDetails.setGroupName(rs.getString("group_name"));
				groupDetails.setDescription(rs.getString("description"));
				
				if(log.isTraceEnabled()){
					log.trace("getGroupById || "+groupDetails.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getGroupById || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUPS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getGroupById || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getGroupById || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getGroupById || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getGroupById || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getGroupById || End");
		}
		return groupDetails;
		
	}
	
	
	/**
	 * @method : getAllGroupRoles
	 * @description : to get all group roles
	 * @return List<RoleDetails>
	 * @throws RepoproException
	 */
	public List<Role> getAllGroupRoles(Connection conn) throws RepoproException{
		
		log.trace("getAllGroupRoles || Begin");
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<Role> rolesList = new ArrayList<Role>();
		Role roleDetails = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRoles || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_GROUP_ROLES));
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRoles || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_GROUP_ROLES));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				roleDetails = new Role();
				roleDetails.setRoleId(rs.getLong("role_id"));
				roleDetails.setRoleName(rs.getString("role_name"));
				roleDetails.setAuthority(rs.getString("authority"));
				roleDetails.setDescription(rs.getString("description"));
				rolesList.add(roleDetails);
				if(log.isTraceEnabled()){
					log.trace("getAllGroupRoles || "+roleDetails.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllGroupRoles || "+rolesList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getAllGroupRoles || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ROLES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllGroupRoles || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllGroupRoles || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllGroupRoles || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRoles || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		
		log.trace("getAllGroupRoles || End");
		return rolesList;		
	}
	
	/**
	 * @method getAllGroupRolesByGroupId
	 * @param groupId
	 * @param conn
	 * @return List<Role>
	 * @throws RepoproException
	 */
	public List<Role> getAllGroupRolesByGroupId(Long groupId, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllGroupRolesByGroupId || Begin with groupId : "+ groupId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<Role> rolesList = new ArrayList<Role>();
		Role roleDetails = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRolesByGroupId || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_GROUP_ROLES_BY_GROUP_ID));
			
			pstmt.setLong(Constants.ONE, groupId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRolesByGroupId || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_GROUP_ROLES_BY_GROUP_ID));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				roleDetails = new Role();
				roleDetails.setRoleId(rs.getLong("role_id"));
				roleDetails.setRoleName(rs.getString("role_name"));
				roleDetails.setAuthority(rs.getString("authority"));
				roleDetails.setDescription(rs.getString("description"));
				rolesList.add(roleDetails);
				if(log.isTraceEnabled()){
					log.trace("getAllGroupRolesByGroupId || "+roleDetails.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllGroupRolesByGroupId || "+rolesList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getAllGroupRolesByGroupId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ROLES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllGroupRolesByGroupId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllGroupRolesByGroupId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllGroupRolesByGroupId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRolesByGroupId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAllGroupRolesByGroupId || End");
		}
		return rolesList;
	}
	
	/**
	 * @method : getAllGroupsHavingEditAiPermission
	 * @param function description
	 * @return List<Groupdetails>
	 * @throws RepoproException
	 */
	public List<GroupDetails> getAllGroupsHavingEditAiPermission(String funcDesc, Connection conn) 
			throws RepoproException{
		
		log.trace("getAllGroupsHavingEditAiPermission || Begin with function description : "+ funcDesc);
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<GroupDetails> groupDetailsList = new ArrayList<GroupDetails>();
		GroupDetails groupDetails = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsHavingEditAiPermission || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_GROUPS_HAVING_EDIT_AI_PERMISSION));
			
			pstmt.setString(Constants.ONE, funcDesc);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsHavingEditAiPermission || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_GROUPS_HAVING_EDIT_AI_PERMISSION));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				groupDetails = new GroupDetails();
				groupDetails.setGroupId(rs.getLong("group_id"));
				groupDetails.setGroupName(rs.getString("group_name"));
				groupDetails.setDescription(rs.getString("description"));
				groupDetailsList.add(groupDetails);
				if(log.isTraceEnabled()){
					log.trace("getAllGroupsHavingEditAiPermission || "+groupDetails.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllGroupsHavingEditAiPermission || "+groupDetailsList.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAllGroupsHavingEditAiPermission || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUPS_HAVING_EDIT_AI_PERMISSION_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllGroupsHavingEditAiPermission || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllGroupsHavingEditAiPermission || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllGroupsHavingEditAiPermission || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsHavingEditAiPermission || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		
		log.trace("getAllGroupsHavingEditAiPermission || End");
		return groupDetailsList;
	}
	
	/**
	 * @method : getGroupsByAssetCategory
	 * @param assetName
	 * @param assetCategoryName
	 * @return List<GroupDetails>
	 * @throws RepoproException
	 */
	public List<GroupDetails> getGroupsByAssetCategory(String assetName, 
			String assetCategoryName, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getGroupsByAssetCategory || Begin with asset name : " + assetName +
					" \t asset category name : " + assetCategoryName);
		}
				
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<GroupDetails> groupDetailsList = new ArrayList<GroupDetails>();
		GroupDetails groupDetails = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getGroupsByAssetCategory || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_GROUPS_BY_ASSET_CATEGORY));
			
			pstmt.setString(Constants.ONE, assetName);
			pstmt.setString(Constants.TWO, assetCategoryName);
			
			if (log.isTraceEnabled()) {
				log.trace("getGroupsByAssetCategory || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_GROUPS_BY_ASSET_CATEGORY));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				groupDetails = new GroupDetails();
				groupDetails.setGroupId(rs.getLong("group_id"));
				groupDetails.setGroupName(rs.getString("group_name"));
				groupDetails.setDescription(rs.getString("description"));
				groupDetailsList.add(groupDetails);
				if(log.isTraceEnabled()){
					log.trace("getGroupsByAssetCategory || "+groupDetails.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getGroupsByAssetCategory || "+groupDetailsList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getGroupsByAssetCategory || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUPS_BY_ASSET_CATEGORY_NOT_FOUND));
		} catch (IOException e) {
			log.error("getGroupsByAssetCategory || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getGroupsByAssetCategory || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getGroupsByAssetCategory || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getGroupsByAssetCategory || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		
		if(log.isTraceEnabled()){
			log.trace("getGroupsByAssetCategory || Begin");
		}
		return groupDetailsList;
	}
	
	/**
	 * @method : addGroupRole
	 * @param groupId
	 * @param addRoleId
	 * @param conn
	 * @throws RepoproException
	 */
	public List<GroupDetails> addGroupRole(GroupDetails updateGroup, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("addGroupRole || "+ updateGroup.getRoleId() + updateGroup.getAssociatedRoleIds().toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		
		List<GroupDetails> list = new ArrayList<GroupDetails>();
		
		int result = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("addGroupRole || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_GROUP_ROLES));

			pstmt.setLong(Constants.ONE, updateGroup.getGroupId());

			if (log.isTraceEnabled()) {
				log.trace("addGroupRole || " + Constants.DELETE_GROUP_ROLES);
			}

			result = pstmt.executeUpdate();
			
			pstmt1 = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.CREATE_GROUP_ROLE));
		
			if(!updateGroup.getAssociatedRoleIds().isEmpty()){
				for (int i = 0; i < updateGroup.getAssociatedRoleIds().size(); i++) {

					Long addRoleId = Long.parseLong(updateGroup
							.getAssociatedRoleIds().get(i));
					pstmt1.setLong(Constants.ONE, updateGroup.getGroupId());
					pstmt1.setLong(Constants.TWO, addRoleId);
					pstmt1.execute();
					GroupDetails groupRole = new GroupDetails();
					groupRole.setRoleId(addRoleId);
					groupRole.setGroupId(updateGroup.getGroupId());

					rs = pstmt1.getGeneratedKeys();
					if (rs != null && rs.next()) {
						groupRole.setGroupRolesId(rs.getLong(1));
					}
					list.add(groupRole);
					if (log.isTraceEnabled()) {
						log.trace("addGroupRole ||" + updateGroup.toString());
					}
					if (log.isTraceEnabled()) {
						log.trace("addGroupRole ||"+ PropertyFileReader.getInstance().getValue(Constants.CREATE_GROUP_ROLE));
					}

				}
			}
			if (log.isDebugEnabled()) {
				log.debug("addGroupRole ||" +list.toString());
			}
			
		} catch (SQLException e) {
			log.error("addGroupRole || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ROLE_NOT_CREATED));
		} catch (IOException e) {
			log.error("addGroupRole || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addGroupRole || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addGroupRole || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt1);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addGroupRole || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);	
		}

		if(log.isTraceEnabled()){
			log.trace("addGroupRole || End");
		}
		return list;
	}
	
	/**
	 * @method : delGroupRole
	 * @param groupId
	 * @param removeRoleId
	 * @param conn
	 * @throws RepoproException
	 */
	public int delGroupRole(Long groupId, Long removeRoleId, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("delGroupRole || Begin with groupId : "+ groupId + 
					" \t removed role id : " + removeRoleId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		int result = 0;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("delGroupRole || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DEL_GROUP_ROLES_BY_GROUP_ID_AND_ROLE_ID));

			pstmt.setLong(Constants.ONE, groupId);
			pstmt.setLong(Constants.TWO, removeRoleId);

			if (log.isTraceEnabled()) {
				log.trace("delGroupRole || "+Constants.DEL_GROUP_ROLES_BY_GROUP_ID_AND_ROLE_ID);
			}

			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("SQL Exception delGroupRole || " + Constants.LOG_DELETE_SQLEXCEPTION+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ROLE_NOT_DELETED));
		} catch (IOException e) {
			log.error("delGroupRole || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("delGroupRole || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("delGroupRole || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("delGroupRole || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("delGroupRole || End");
		}
		return result;
		
	}
	
	/**
	 * @method : retGroupRoleByGroupIdAndRoleId
	 * @param groupId
	 * @param roleId
	 * @param conn
	 * @return GroupRole obj
	 * @throws RepoproException 
	 */
	public GroupRoles retGroupRoleByGroupIdAndRoleId(Long groupId, Long roleId, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("retGroupRoleByGroupIdAndRoleId || Begin with groupId : "+ groupId +
						" \t roleId : " + roleId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		GroupRoles groupRoles = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("retGroupRoleByGroupIdAndRoleId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_GROUP_ROLES_BY_GROUP_ID_AND_ROLE_ID));
			
			pstmt.setLong(Constants.ONE, groupId);
			pstmt.setLong(Constants.TWO, roleId);
			
			if (log.isTraceEnabled()) {
				log.trace("retGroupRoleByGroupIdAndRoleId || "
							+Constants.GET_GROUP_ROLES_BY_GROUP_ID_AND_ROLE_ID);
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				groupRoles = new GroupRoles();
				groupRoles.setGroupRolesId(rs.getLong("group_roles_id"));
				groupRoles.setGroupId(rs.getLong("group_id"));
				groupRoles.setRoleId(rs.getLong("role_id"));
				if(log.isTraceEnabled()){
					log.trace("retGroupRoleByGroupIdAndRoleId || "+groupRoles.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("retGroupRoleByGroupIdAndRoleId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ROLES_NOT_FOUND));
		} catch (IOException e) {
			log.error("retGroupRoleByGroupIdAndRoleId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retGroupRoleByGroupIdAndRoleId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("retGroupRoleByGroupIdAndRoleId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retGroupRoleByGroupIdAndRoleId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("retGroupRoleByGroupIdAndRoleId || End");
		}
		return groupRoles;
	}
	

	
	/**
	 * @method retassetgroupsAccess
	 * @param assetId
	 * @param conn
	 * @return List GroupAssetAccess
	 * @throws RepoproException
	 */
	public List<GroupAssetAccess> retassetgroupsAccess(Long assetId, Connection conn) throws RepoproException{
		
		if (log.isDebugEnabled()) {
			log.debug("retassetgroupsAccess" + assetId + " Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
				
		List<GroupAssetAccess> groupAssetAccessList = new ArrayList<GroupAssetAccess>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retassetgroupsAccess: "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_GROUP_ASSETS_ACCESS_BY_ASSET_ID));
			preparedStmt.setLong(Constants.ONE, assetId);

			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retassetgroupsAccess:"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_GROUP_ASSETS_ACCESS_BY_ASSET_ID));
			}
			while (rs.next()) {
				GroupAssetAccess assetGroupAccess = new GroupAssetAccess();
				assetGroupAccess.setAssetGroupId(rs.getLong("asset_group_id"));
				assetGroupAccess.setAssetId(rs.getLong("asset_id"));
				assetGroupAccess.setGroupId(rs.getLong("group_id"));
				assetGroupAccess.setAddAccess(rs.getLong("add_access"));
				assetGroupAccess.setEditAccess(rs.getLong("edit_access"));
				assetGroupAccess.setViewAccess(rs.getLong("view_access"));
				assetGroupAccess.setDeleteAccess(rs.getLong("delete_access"));
				groupAssetAccessList.add(assetGroupAccess);

				if (log.isTraceEnabled()) {
					log.trace("retassetgroupsAccess:"+ groupAssetAccessList.toString());
				}
			}

		}catch (SQLException e) {
			log.error("retassetgroupsAccess || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.RET_GROUP_ASSETS_ACCESS_BY_ASSET_ID_DETAILS_FAILED));
		} catch (IOException e) {
			log.error("retassetgroupsAccess || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retassetgroupsAccess || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("retassetgroupsAccess || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("retassetgroupsAccess: "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isDebugEnabled()) {
			log.debug("retassetgroupsAccess" + assetId + " End");
		}

		return groupAssetAccessList;
	}

	
	/**
	 * @method :addGroupsAccessAISubmit
	 * @param groupAssetInstAccess
	 * @param conn
	 * @return GroupAssetAccess
	 * @throws CreateContentException
	 * @throws DataNotFoundException
	 */

	public GroupAssetAccess addGroupsAccessAISubmit(
			GroupAssetAccess groupAssetInstAccess, Connection conn)
			throws RepoproException{
		if (log.isDebugEnabled()) {
			log.debug("addGroupsAccessAISubmit"
					+ groupAssetInstAccess.toString() + " Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		int val = 0;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addGroupsAccessAISubmit: "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.ADD_GROUP_ACCESS_AI_SUBMIT_DETAILS));

			preparedStmt.setLong(Constants.ONE,
					groupAssetInstAccess.getAssetInstversionId());
			preparedStmt.setLong(Constants.TWO,
					groupAssetInstAccess.getGroupId());
			preparedStmt.setLong(Constants.THREE,
					groupAssetInstAccess.getEditAccess());
			preparedStmt.setLong(Constants.FOUR,
					groupAssetInstAccess.getViewAccess());
			preparedStmt.setLong(Constants.FIVE,
					groupAssetInstAccess.getDeleteAccess());

			val = preparedStmt.executeUpdate();
			
			rs = preparedStmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				groupAssetInstAccess.setAssetInstversionGroupId(rs.getLong(1));
			}

			if (log.isTraceEnabled()) {
				log.trace("addGroupsAccessAISubmit:"
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_GROUP_ACCESS_AI_SUBMIT_DETAILS));
			}

		}catch (SQLException e) {
			log.error("addGroupsAccessAISubmit || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ADD_GROUP_ACCESS_AI_SUBMIT_DETAILS_FAILED));
		} catch (IOException e) {
			log.error("addGroupsAccessAISubmit || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addGroupsAccessAISubmit || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("addGroupsAccessAISubmit || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addGroupsAccessAISubmit: "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isDebugEnabled()) {

			log.debug("addGroupsAccessAISubmit:"
					+ groupAssetInstAccess.toString() + " End");
		}
		return groupAssetInstAccess;
	}
	
	
	/**
	 * @method : getGroupAccessByAssetId
	 * @param GroupAssetAccess
	 * @param conn
	 * @throws RepoproException 
	 */
	public List<Map<String,Long>> getGroupAccessByAssetId(Long assetId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getGroupAccessByAssetId || Begin with assetId : "+ assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<GroupAssetAccess> gaaList = new ArrayList<GroupAssetAccess>();
		List<Map<String,Long>> list = new ArrayList<Map<String,Long>>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getGroupAccessByAssetId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ASSET_ACCESS_GROUPS_BY_ASSET_ID));
			pstmt.setLong(Constants.ONE, assetId);
			
			rs = pstmt.executeQuery();
			
			Map<String, Long> map = new LinkedHashMap<String, Long>(); 
			while(rs.next()){
				
				GroupAssetAccess gaa = new GroupAssetAccess();
				gaa.setAddAccess(rs.getLong("add_access"));
				gaa.setAssetGroupId(rs.getLong("asset_group_id"));
				gaa.setAssetId(rs.getLong("asset_id"));
				gaa.setDeleteAccess(rs.getLong("delete_access"));
				gaa.setViewAccess(rs.getLong("view_access"));
				gaa.setEditAccess(rs.getLong("edit_access"));
				gaa.setGroupId(rs.getLong("group_id"));
				gaaList.add(gaa);
			}
			
			for (int i = 0; i < gaaList.size(); i++) {
				
				GroupAssetAccess ga = gaaList.get(i);
				if(ga.getAddAccess()!=0){
					map.put("add_access", ga.getAddAccess());	
				}
				
				if(ga.getDeleteAccess()!=0){
					map.put("delete_access", ga.getDeleteAccess());	
				}
				
				if(ga.getEditAccess()!=0){
					map.put("edit_access", ga.getEditAccess());	
				}
				
				if(ga.getViewAccess()!=0){
					map.put("view_access", ga.getViewAccess());	
				}
				
				map.put("asset_group_id", ga.getAssetGroupId());
				map.put("asset_id", ga.getAssetId());
				map.put("group_id", ga.getGroupId());
				list.add(map);
				map= new LinkedHashMap<String, Long>(); 
			
				if (log.isTraceEnabled()) {
					log.trace("getGroupAccessByAssetId || "
								+Constants.GET_ASSET_ACCESS_GROUPS_BY_ASSET_ID);
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getGroupAccessByAssetId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ACCESS_ASSET_NOT_FOUND));
		} catch (IOException e) {
			log.error("getGroupAccessByAssetId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getGroupAccessByAssetId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getGroupAccessByAssetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getGroupAccessByAssetId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getGroupAccessByAssetId || End");
		}
		return list;
	}
	
	
	/**
	 * @method : addGroupsAssetAccessSubmit
	 * @param GroupAssetAccess
	 * @param conn
	 * @throws RepoproException 
	 */
	@SuppressWarnings("resource")
	public void addGroupsAssetAccessSubmit(Long assetId,List<Map<String, Long>> listOfAccessForAsset, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("addGroupsAssetAccessSubmit || Begin with assetId : "+ assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("addGroupsAssetAccessSubmit || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if (log.isTraceEnabled()) {
				log.trace("addGroupsAssetAccessSubmit || "+ PropertyFileReader.getInstance().getValue(Constants.DELETE_ASSET_GROUP_ACCESS_BY_ASSET_ID));
			}
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_ASSET_GROUP_ACCESS_BY_ASSET_ID));
			
			
			pstmt.setLong(Constants.ONE, assetId);
			int result = pstmt.executeUpdate();
		
				if (log.isTraceEnabled()) {
					log.trace("addGroupsAssetAccessSubmit || "+ PropertyFileReader.getInstance().getValue(Constants.ADD_GROUPS_ASSET_ACCESS_SUBMIT));
				}
				pstmt1 = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.ADD_GROUPS_ASSET_ACCESS_SUBMIT));
			
			Iterator<Map<String, Long>> itr = listOfAccessForAsset.iterator();
			while (itr.hasNext()) {
				Map<String,Long> mapOfValues = (Map<String, Long>) itr.next();
				
				pstmt1.setLong(Constants.ONE, assetId);
				pstmt1.setLong(Constants.TWO, mapOfValues.get("group_id"));
				
				if(mapOfValues.containsKey("add_access")){
					pstmt1.setLong(Constants.THREE, mapOfValues.get("add_access"));
				}else{
					pstmt1.setLong(Constants.THREE, 0);
				}
				if(mapOfValues.containsKey("edit_access")){
					pstmt1.setLong(Constants.FOUR, mapOfValues.get("edit_access"));
				}else{
					pstmt1.setLong(Constants.FOUR, 0);
				}
				
				if(mapOfValues.containsKey("view_access")){
					pstmt1.setLong(Constants.FIVE, mapOfValues.get("view_access"));
				}else{
					pstmt1.setLong(Constants.FIVE, 0);
				}
				
				if(mapOfValues.containsKey("delete_access")){
					pstmt1.setLong(Constants.SIX, mapOfValues.get("delete_access"));
				}else{
					pstmt1.setLong(Constants.SIX, 0);
				}
				
				pstmt1.executeUpdate();
				
			}
			if (log.isTraceEnabled()) {
				log.trace("addGroupsAssetAccessSubmit || "
							+Constants.ADD_GROUPS_ASSET_ACCESS_SUBMIT);
			}
			
		} catch (SQLException e) {
			log.error("addGroupsAssetAccessSubmit || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_ROLES_NOT_FOUND));
		} catch (IOException e) {
			log.error("addGroupsAssetAccessSubmit || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addGroupsAssetAccessSubmit || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("addGroupsAssetAccessSubmit || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closePreparedStatement(pstmt1);
			if (log.isTraceEnabled()) {
				log.trace("addGroupsAssetAccessSubmit || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("addGroupsAssetAccessSubmit || End");
		}
	}
	/**
	 * @method : getAllGroupsWithAllAccess
	 * @description : to get all groups
	 * @return List<GroupDetails>
	 * @throws RepoproException
	 * @throws RepoproException 
	 */
	public List<GroupAssetAccess> getAllGroupsWithAllAccess(Connection conn) throws RepoproException{

		log.trace("getAllGroupsWithAllAccess || Begin");
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<GroupAssetAccess> groupAssetAccessList = new ArrayList<GroupAssetAccess>();
		GroupAssetAccess groupAssetAccess= null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccess || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_GROUPS));
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccess || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_GROUPS));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				groupAssetAccess = new GroupAssetAccess();
				groupAssetAccess.setGroupId(rs.getLong("group_id"));
				groupAssetAccess.setGroupName(rs.getString("group_name"));
				groupAssetAccess.setViewAccess((long)0);
				groupAssetAccess.setDeleteAccess((long)0);
				groupAssetAccess.setAddAccess((long)0);
				groupAssetAccess.setEditAccess((long)0);
				groupAssetAccessList.add(groupAssetAccess);
				if(log.isTraceEnabled()){
					log.debug("getAllGroupsWithAllAccess || "+ groupAssetAccess.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllGroupsWithAllAccess || "+ groupAssetAccessList.toString());
			}

		} catch (SQLException e) {
			log.error("getAllGroupsWithAllAccess || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.GROUPS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllGroupsWithAllAccess || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllGroupsWithAllAccess || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllGroupsWithAllAccess || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccess || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		
		log.trace("getAllGroupsWithAllAccess || End");
		
		return groupAssetAccessList;
	}
	
	
	/**
	 * @method : getAllGroupsWithAllAccess
	 * @description : to get all groups
	 * @return List<GroupDetails>
	 * @throws RepoproException
	 * @throws RepoproException 
	 */
	public List<GroupAssetAccess> getAllGroupsWithAllAccessForEditAsset(Long assetId,Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllGroupsWithAllAccessForEditAsset || Begin with assetId : "+ assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<GroupAssetAccess> aivGroupAccessList = new ArrayList<GroupAssetAccess>();
		List<GroupAssetAccess> groupAssetAccessList = new ArrayList<GroupAssetAccess>();
		GroupAssetAccess groupAssetAccess= null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			/*pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ASSET_GROUP_ACCESS_FOR_ASSET));
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccessForEditAsset || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ASSET_GROUP_ACCESS_FOR_ASSET));
			}

			pstmt.setLong(Constants.ONE, assetId);
			rs = pstmt.executeQuery();

			while(rs.next()){
				groupAssetAccess = new GroupAssetAccess();
				groupAssetAccess.setGroupId(rs.getLong("group_id"));
				groupAssetAccess.setGroupName(rs.getString("group_name"));
				groupAssetAccess.setViewAccess(rs.getLong("view_access"));
				groupAssetAccess.setDeleteAccess(rs.getLong("delete_access"));
				groupAssetAccess.setAddAccess(rs.getLong("add_access"));
				groupAssetAccess.setEditAccess(rs.getLong("edit_access"));
				groupAssetAccessList.add(groupAssetAccess);
				if(log.isTraceEnabled()){
					log.debug("getAllGroupsWithAllAccessForEditAsset || "+ groupAssetAccess.toString());
				}
			}
			
			if(log.isDebugEnabled()){
				log.debug("getAllGroupsWithAllAccessForEditAsset || "+ groupAssetAccessList.toString());
			}
			if(groupAssetAccessList.size()==0){
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_GROUPS));
				rs = pstmt.executeQuery();

				while(rs.next()){
					if(rs.getString("group_name").equalsIgnoreCase("Guest")||rs.getString("group_name").equalsIgnoreCase("Group-admin")){
						
					}else{
					groupAssetAccess = new GroupAssetAccess();
					groupAssetAccess.setGroupId(rs.getLong("group_id"));
					
					groupAssetAccess.setGroupName(rs.getString("group_name"));
					groupAssetAccess.setViewAccess((long)0);
					groupAssetAccess.setDeleteAccess((long)0);
					groupAssetAccess.setAddAccess((long)0);
					groupAssetAccess.setEditAccess((long)0);
					groupAssetAccessList.add(groupAssetAccess);
					if(log.isTraceEnabled()){
						log.debug("getAllGroupsWithAllAccessForEditAsset || "+ groupAssetAccess.toString());
					}
					}
				
			}
			}*/
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ASSET_GROUP_ACCESS_FOR_ASSET));
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccessForEditAsset || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ASSET_GROUP_ACCESS_FOR_ASSET));
			}

			pstmt.setLong(Constants.ONE, assetId);
			rs = pstmt.executeQuery();

			while(rs.next()){
				groupAssetAccess = new GroupAssetAccess();
				groupAssetAccess.setGroupId(rs.getLong("group_id"));
				groupAssetAccess.setGroupName(rs.getString("group_name"));
				groupAssetAccess.setViewAccess(rs.getLong("view_access"));
				groupAssetAccess.setDeleteAccess(rs.getLong("delete_access"));
				groupAssetAccess.setAddAccess(rs.getLong("add_access"));
				groupAssetAccess.setEditAccess(rs.getLong("edit_access"));
				groupAssetAccessList.add(groupAssetAccess);
				if(log.isTraceEnabled()){
					log.debug("getAllGroupsWithAllAccessForEditAsset || "+ groupAssetAccess.toString());
				}
			}
			
			if(log.isDebugEnabled()){
				log.debug("getAllGroupsWithAllAccessForEditAsset || "+ groupAssetAccessList.toString());
			}
			
			List<GroupDetails> allGroups = getAllGroups(conn1);
			
			for(GroupDetails groupBo : allGroups){
				if(!groupBo.getGroupName().equalsIgnoreCase("group-admin") && !groupBo.getGroupName().equalsIgnoreCase("Guest")){
					
					groupAssetAccess = new GroupAssetAccess();
					groupAssetAccess.setGroupId(groupBo.getGroupId());
					groupAssetAccess.setGroupName(groupBo.getGroupName());
					groupAssetAccess.setMappedWithAI(false);
					groupAssetAccess.setViewAccess((long)0);
					groupAssetAccess.setDeleteAccess((long)0);
					groupAssetAccess.setAddAccess((long)0);
					groupAssetAccess.setEditAccess((long)0);
					//groupAssetAccessList.add(groupAssetAccess);
					
					for(GroupAssetAccess gaa : groupAssetAccessList){
						if(gaa.getGroupId().equals(groupBo.getGroupId())){
							groupAssetAccess.setMappedWithAI(true);
							
							if(gaa.getAddAccess() == 1){
								groupAssetAccess.setAddAccess((long)1);
							}
							if(gaa.getEditAccess() == 1){
								groupAssetAccess.setEditAccess((long)1);
							}
							if(gaa.getViewAccess() == 1){
								groupAssetAccess.setViewAccess((long)1);
							}
							if(gaa.getDeleteAccess() == 1){
								groupAssetAccess.setDeleteAccess((long)1);
							}
						}
						
						boolean flagForGroupExistsinList = false;
						for(int i=0;i<aivGroupAccessList.size();i++){
							if(aivGroupAccessList.get(i).getGroupId().equals(groupAssetAccess.getGroupId())){
								flagForGroupExistsinList = true;
							}
						}

						if(flagForGroupExistsinList == false){
							aivGroupAccessList.add(groupAssetAccess);	
						}
						
					}
				}
			}
						
			
		} catch (SQLException e) {
			log.error("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.GROUPS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		
		if(log.isTraceEnabled()){
			log.trace("getAllGroupsWithAllAccessForEditAsset || End");
		}
		
		
		return aivGroupAccessList;
	}
	
	
	/**
	 * @method getCategoryAccessByAssetId
	 * @param categoryId
	 * @param categoryGroupValues
	 * @param conn
	 * @return Map<Long,Map<Long,String>>
	 * @throws RepoproException
	 */
	public Map<Long,Map<Long,String>> getCategoryAccessByAssetId(Long categoryId,Map<Long, Map<Long, String>> categoryGroupValues,Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getCategoryAccessByAssetId || Begin with categoryId : "+ categoryId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getCategoryAccessByAssetId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ASSET_CATEGORY_ACCESS_ASSET_CATEGORY_ID));
			pstmt.setLong(Constants.ONE, categoryId);
			rs = pstmt.executeQuery();
			Map<Long, String> map = new LinkedHashMap<Long, String>(); 
			while(rs.next()){
				
				map.put(rs.getLong("group_id"), rs.getString("group_name"));
				
			}if(categoryGroupValues==null){
				categoryGroupValues = new LinkedHashMap<Long, Map<Long,String>>();
				categoryGroupValues.put(categoryId, map);
			}else{
				categoryGroupValues.put(categoryId, map);
			}
			//finalMap.put(categoryId, map);
			if (log.isTraceEnabled()) {
				log.trace("getCategoryAccessByAssetId || "
							+Constants.GET_ASSET_CATEGORY_ACCESS_ASSET_CATEGORY_ID);
			}
			
		} catch (SQLException e) {
			log.error("getCategoryAccessByAssetId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_ASSET_CATEGORY_ACCESS_ASSET_CATEGORY_ID_NOT_FOUND));
		} catch (IOException e) {
			log.error("getCategoryAccessByAssetId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getCategoryAccessByAssetId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getCategoryAccessByAssetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getCategoryAccessByAssetId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getCategoryAccessByAssetId || End");
		}
		return categoryGroupValues;
	}


	public Long getAssetIdByAssetname(String assetName, Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("getAssetIdByAssetname || Begin with assetName : "+ assetName);
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Long assetId = null;
		
		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetIdByAssetname ||" + Constants.LOG_CONNECTION_OPEN);
			}
			
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ASSET_ID_BY_ASSET_NAME));
			
			preparedStmt.setString(Constants.ONE, assetName);
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetIdByAssetname ||" + PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_ID_BY_ASSET_NAME));
			}
			
			rs = preparedStmt.executeQuery();
			
			while (rs.next()) {
				
				assetId = rs.getLong("asset_id");
				
			}
			
		}catch(SQLException e){
			
			e.printStackTrace();
			log.error("getAssetIdByAssetname ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_ASSET_ID_BY_ASSET_NAME_DATA_NOT_FOUND));
			
		}catch(IOException e){
			
			log.error("getAssetIdByAssetname ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		}catch(PropertyVetoException e){
			
			log.error("getAssetIdByAssetname ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			
		}catch(Exception e){
			
			log.error("getAssetIdByAssetname ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
			
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getAssetIdByAssetname || "+ Constants.LOG_CONNECTION_CLOSE);
			}
		}
		return assetId;
		
	}


	public List<String> getRoleIdsByRoleNames(List<String> roleNamesList, Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getRoleIdsByRoleNames || Begin : "+ roleNamesList.toString());
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<String> roleIdsList = null;
		Role role = new Role();
		
		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getFunNamesByFunIds ||" + Constants.LOG_CONNECTION_OPEN);
			}
			
			String[] roleNames = null;
			List<String> roleList = new ArrayList<String>();
			for(String s: roleNamesList){
				roleNames = s.split(",");
				roleList.add(roleNames[0]);
			}
			
			roleIdsList = new ArrayList<String>();
			if(roleNames != null){
			for(String str : roleNamesList){
				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ROLE_IDS_BY_ROLE_NAMES));
				
				preparedStmt.setString(Constants.ONE, str);
				rs = preparedStmt.executeQuery();
				
				while(rs.next()){
					roleIdsList.add(rs.getString("role_id"));
				}
				 
			 }
			}
			
		}catch(SQLException e){
			
			e.printStackTrace();
			log.error("getFunNamesByFunIds ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_ROLE_IDS_BY_ROLE_NAMES_DATA_NOT_FOUND));
			
		}catch(IOException e){
			
			log.error("getFunNamesByFunIds ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		}catch(PropertyVetoException e){
			
			log.error("getFunNamesByFunIds ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			
		}catch(Exception e){
			
			log.error("getFunNamesByFunIds ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
			
		}finally{
			
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getFunNamesByFunIds || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		
		return roleIdsList;
	}
	
	
}