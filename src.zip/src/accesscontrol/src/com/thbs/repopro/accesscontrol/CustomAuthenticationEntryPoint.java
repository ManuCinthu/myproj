package com.thbs.repopro.accesscontrol;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;

public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {
	static Logger log = Logger.getLogger(CustomAuthenticationEntryPoint.class
			.getName());

	public void commence(HttpServletRequest request,
			HttpServletResponse response, AuthenticationException authException)
			throws IOException, ServletException {
		if (log.isDebugEnabled()) {
			log.debug("commence : begin ");
		}
		Map<String, String[]> parameterMap = request.getParameterMap();

		String[] userName = parameterMap.get("userName");

		String token = "";
		
		boolean is_oAuth = false;
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();
		List<GlobalSetting> globalSetting = new ArrayList<GlobalSetting>();
		int guestAccess = 0;
		try {
			globalSetting = globalSettingDao.getGlobalSetting(null);
		} catch (RepoproException e) {
			e.printStackTrace();
		}
		
		for(GlobalSetting gs : globalSetting) {
			guestAccess = gs.getGuestAccess();
			if(gs.getMechanism().equalsIgnoreCase("oAuth")){
				is_oAuth = true;
				break;
			}
		}
		
		if(is_oAuth) {
			if (((HttpServletRequest) request).getHeader("Authorization") != null) {
				token = ((HttpServletRequest) request).getHeader("Authorization");
			}
		}else {
			if (((HttpServletRequest) request).getParameter("tokenName") != null) {
				token = ((HttpServletRequest) request).getParameter("tokenName");
			} else if (((HttpServletRequest) request).getHeader("token") != null) {
				token = ((HttpServletRequest) request).getHeader("token");
			}
		}
		/*if (((HttpServletRequest) request).getParameter("tokenName") != null) {
			token = ((HttpServletRequest) request).getParameter("tokenName");
		} else if (((HttpServletRequest) request).getHeader("token") != null) {

			token = ((HttpServletRequest) request).getHeader("token");

		}else if (((HttpServletRequest) request).getHeader("Authorization") != null) {

			token = ((HttpServletRequest) request).getHeader("Authorization");

		}*/
		
		
		
		/*if(guestAccess == 0) {*/
			if(userName == null && token == ""){
				response.setContentType("application/json; charset=UTF-8");
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				PrintWriter printout = response.getWriter();

				JSONObject JObject = new JSONObject(); 
				JObject.put("message", "USER_NOT_AUTHORIZED");
				JObject.put("status", "NOT_AUTHORIZED");
				JObject.put("statusCode", "401");
				printout.print(JObject);
				printout.flush();
				
			}else if (userName == null && token != "") {
				response.setContentType("application/json; charset=UTF-8");
			    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		        PrintWriter printout = response.getWriter();

		        JSONObject JObject = new JSONObject(); 
		        JObject.put("message", "Unauthorized: Authentication token was either missing or invalid.");
		        JObject.put("status", "NOT_AUTHORIZED");
		        JObject.put("statusCode", "401");
                printout.print(JObject);
		        printout.flush();
			}
		//}
		/*else if (userName == null && token != "") {
			
			    response.setContentType("application/json; charset=UTF-8");
			    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		        PrintWriter printout = response.getWriter();

		        JSONObject JObject = new JSONObject(); 
		        JObject.put("message", "Unauthorized: Authentication token was either missing or invalid."); 
		        JObject.put("status", "NOT_AUTHORIZED"); 
		        JObject.put("statusCode", "401"); 
                printout.print(JObject);
		        printout.flush();
		}*/ else if (guestAccess == 1) {
			
			if(userName[0].toString().equalsIgnoreCase("guest")
					&& !token.equalsIgnoreCase("")) {
			//response.sendError(HttpServletResponse.SC_BAD_REQUEST,
			//		"Bad Request!");
			response.setContentType("application/json; charset=UTF-8");
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	        PrintWriter printout = response.getWriter();

	        JSONObject JObject = new JSONObject(); 
	        JObject.put("message", "Bad Request!"); 
	        JObject.put("status", "INVALID_REQUEST"); 
	        JObject.put("statusCode", "400"); 
            printout.print(JObject);
	        printout.flush();
	        }
		} else {
		
			    response.setContentType("application/json; charset=UTF-8");
			    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		        PrintWriter printout = response.getWriter();

		        JSONObject JObject = new JSONObject(); 
		        JObject.put("message", "Unauthorized: Authentication token was either missing or invalid."); 
		        JObject.put("status", "NOT_AUTHORIZED"); 
		        JObject.put("statusCode", "401"); 
                printout.print(JObject);
		        printout.flush();
		}

		if (log.isDebugEnabled()) {
			log.debug("commence : end ");
		}
	}
}