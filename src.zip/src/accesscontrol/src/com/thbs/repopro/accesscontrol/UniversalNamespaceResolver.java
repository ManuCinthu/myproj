package com.thbs.repopro.accesscontrol;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;

import javax.xml.namespace.NamespaceContext;

public class UniversalNamespaceResolver extends Properties implements NamespaceContext {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */

	public UniversalNamespaceResolver() {
		super();
	}
	
	public String getNamespaceURI(String prefix) {
		return (String) super.get(prefix);
	        
	}

	public String getPrefix(String uri) {
		// Slow, but ok
		Enumeration enm = (Enumeration) super.keys();
		while (enm.hasMoreElements()) {
			String key = (String) enm.nextElement();
			String value = (String) super.get(key);
			if (value.equals(uri)) {
				return key;
			}
		}
		return "";
	}

	public Iterator getPrefixes(String arg0) {
		// TODO: Unimplemented
		return new Vector().iterator();
	}
}
