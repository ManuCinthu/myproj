package com.thbs.repopro.accesscontrol;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.Key;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StreamUtils;

import java.util.Base64;
import java.util.HashSet;

import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.ldap.LDAPAuthentication;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.DeleteSrcFolderContent;
import com.thbs.repopro.util.EncryptPassword;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;
import com.thbs.repopro.util.PasswordGenerator;

@Produces(MediaType.APPLICATION_JSON)
@Consumes({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
@Path("/user")
public class UserManager {

	// static Logger log = Logger.getLogger("timeBased");
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	@POST
	@Path("/validateloggedinuser")
	public Response validatepublisherLoggedinUser(User userDto) throws UnsupportedEncodingException{
		if (log.isDebugEnabled()) {
			log.debug("validatepublisherLoggedinUser : begin with userName : "+userDto.getUserName() +" and password : "+CommonUtils.encrypt(userDto.getPassword()));
		}

		Status retStat = Status.OK;
		UserDao userDao = new UserDao();
		GlobalSetting globalSetting = new GlobalSetting();
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();
		String flag  = null;
		Connection conn = null;
		//String userName = userDto.getUserName();
		String userName = null;
		String password = null;

		try{
			String decodedUserName = java.net.URLDecoder.decode(userDto.getUserName(), "UTF-8");
			//Decrypt password using MD 5
			
			String decodedPassword = java.net.URLDecoder.decode(userDto.getPassword(), "UTF-8");
			

			userName = decodedUserName;
			password = decodedPassword;
		}catch(UnsupportedEncodingException e){
			throw new UnsupportedEncodingException(e.getMessage());
		}
		String encryptedPassword = password;
		try{
			final String ALGO = "AES";
			final byte[] keyValue = 
					new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };
			Key key = new SecretKeySpec(keyValue, ALGO);;
			Cipher c = Cipher.getInstance(ALGO);
			c.init(Cipher.ENCRYPT_MODE, key);
			byte[] encVal = c.doFinal(password.getBytes());
			encryptedPassword =  Base64.getEncoder().encodeToString(encVal);

		}catch(Exception e){
			e.printStackTrace();
		}

		List<String> msgList = new ArrayList<String>();
		String adminUserFlag = "adminUser";
		String invalid = "invalid";
		try {
			if (log.isInfoEnabled()) {
				log.info("validatepublisherLoggedinUser : " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			boolean authenticateFalg = false;
			LDAPAuthentication  Authentication = new LDAPAuthentication();
			//User user = loginDao.getUserByUserCredentials(userDto.getLinkedPublisherName(), "", userDto.getUserName(), userDto.getPassword(),conn);
			User user = userDao.retProfileForUserNameAndPwd(userName, encryptedPassword, conn);

			if(user == null){
				user = userDao.retProfiledetailsForUserName(userName,conn);
				if(!((user.getUserName().equals("admin")) ||(user.getPassword().equals("")))){
					if(!user.getActiveFlag().equals("0")){

						if(user.getLoginAttempt() < 3){
							userDao.updateFailAttempts(userName,conn);
							flag = "false";
						}

						if (user.getLoginAttempt() >= 3) {
							//	userDao.updateFailAttempts(userName,conn);
							flag = "account_locked";
						} 

						msgList.add(flag);
						
					}else{
						flag = "User is inactive";
						msgList.add(flag);
					}
				}else if(!user.getUserName().equals("admin")){
					if(user.getPassword().equals("")){
						if(!user.getActiveFlag().equals("0")){
						globalSetting = globalSettingDao.retGlobalSettingByName("Ldap" , conn);
						if(globalSetting.getGlobalLdapSettingFlag() == 1){
							authenticateFalg = Authentication.authenticateUser(userName, password);
							if(authenticateFalg == true){
								flag = "true";
							}else{
								flag = "false";
							}
							msgList.add(flag);	
						}else{
							flag = "false";
							msgList.add(flag);	
						}
						}
						else
						{
							flag = "User is inactive";
							msgList.add(flag);
						}
					}
					else{
						authenticateFalg = Authentication.authenticateUser(userName, password);
						if(authenticateFalg == true){
							flag = "true";
						}else{
							flag = "false";
						}
						msgList.add(flag);
					}
				}else{
					if(user.getLoginAttempt() < 3){
						userDao.updateFailAttempts(userName,conn);
						flag = "false";
					}

					if (user.getLoginAttempt() >= 3) {
						//	userDao.updateFailAttempts(userName,conn);
						flag = "admin_account_locked";
					} 

					msgList.add(flag);
				}
			}else{
				if(user.getActiveFlag().equals("0")){
					flag = "User is inactive";
					msgList.add(flag);
				}else if(user.getLoginAttempt() >= 3){
					if(user.getUserName().equals("admin")){
						flag = "admin_account_locked";
					}else{
						flag = "account_locked";
					}
					msgList.add(flag);
				}else {
					userDao.resetFailAttempts(userName,conn);
					flag = "true";
					msgList.add(flag);
				}
			}
			conn.commit();
			retStat = Status.OK;
		} 
		catch (Exception e) {
			log.error("validatepublisherLoggedinUser :" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			try {
				conn.rollback();
			}
			catch(Exception e1){
				log.error("validatepublisherLoggedinUser :" + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
			}
		}
		finally {
			if (log.isInfoEnabled()) {
				log.info("validatepublisherLoggedinUser : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);			
		}
		if (log.isDebugEnabled()) {
			log.debug("validatepublisherLoggedinUser :" + msgList.toString() + "Exit");
		}
		return Response
				.status(retStat)
				.entity(new ArrayList<Object>(msgList)).build();
	}

	@GET
	@Path("/retProfiledetailsForUserName")
	public Response retProfiledetailsForUserName(@QueryParam("userName") String userName) {
		Authentication userDet = SecurityContextHolder.getContext().getAuthentication();
		if (log.isDebugEnabled()) {
			log.debug("retProfiledetailsForUserName : begin with userName : "+userName );
		}
		//String userName = userDet.getPrincipal().toString();

		Status retStat = Status.OK;
		UserDao userDao = new UserDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		RoleDao roleDao = new RoleDao();

		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;		

		Connection conn = null;
		List<User> userList = new ArrayList<User>();
		boolean flag = false;

		try {
			if (log.isInfoEnabled()) {
				log.info("retProfiledetailsForUserName : " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			User user = userDao.retProfiledetailsForUserName(userName, conn);
			List<UserFunction> userFunctions = roleDao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			for(UserFunction userFunc : userFunctions){
				if(userFunc.getFunctionId() == 2){
					flag = true;
					break;
				}
			}
			if(assetInstanceVersionDao.findAdminRightsByUserName(userName, conn) || flag){
				user.setAccessFlag(true);
			}else{
				user.setAccessFlag(false);
			}
			
            if(user.getPassword().equalsIgnoreCase("")|| user.getPassword() == null){
            	user.setLdapFlag(1);
			}else{
				user.setLdapFlag(0);
			}
            user.setPassword(null);
                        
			userList.add(user);
			

			retStat = Status.OK;
		} 
		catch (Exception e) {
			log.error("retProfiledetailsForUserName :" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			try {
				conn.rollback();
			}
			catch(Exception e1){
				log.error("retProfiledetailsForUserName :" + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
			}
		}
		finally {
			if (log.isInfoEnabled()) {
				log.info("retProfiledetailsForUserName : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);			
		}
		if (log.isDebugEnabled()) {
			log.debug("retProfiledetailsForUserName :" + userList.toString() + "Exit");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(userList))).build();
	}

	/**
	 * @method getUsers
	 * @description to get all users
	 * @param
	 * @return Response List<ApiUser>
	 */
	@GET
	@Path("/allUsers")
	public Response getUsers() {

		log.trace("getUsers || begin");
		UserDao userDao = new UserDao();
		List<User> usersList = null;
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getUsers || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (log.isTraceEnabled()) {
				log.trace("getUsers || dao method called : getUsers()");
			}
			usersList = userDao.getUsers(false, conn);

			retStat = Status.OK;
			retMsg = Constants.USERS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			if(log.isDebugEnabled()){
				log.debug(" getUsers  || retrieved " + usersList.size() + " users successfully");
			}

			if (usersList.isEmpty()) {
				retStat = Status.OK;
				retMsg = Constants.USER_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		}

		catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getUsers || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getUsers ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(usersList))).build();

	}

	
	/***Wrapper function***/
	/*for UI purpose aiv page properties tab userlist dropdown*/
	/**
	 * @method : getUsersMain
	 * @param groupName
	 * @return Response with List<Group> List of all Groups by type
	 */
	@GET
	@Path("/getUsersMain")
	public Response getUsersMain(@HeaderParam("token") String token) {
		
		if (log.isTraceEnabled()) {
			log.trace("getUsersMain || Begin");
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		
		User user1 = new User();
		UserDao userDao = new UserDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean userFlag = false;
		RoleDao roledao = new RoleDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId(userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("getUsersMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (!userName.equalsIgnoreCase("guest")) {
				user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user1 != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user1.getUserId(), conn);
			}
				        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
			        break;
				}
			}
			
			if(userFlag || adminFlag){
				response = this.getUsers();
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	User user = new User();
		        	user = (User) data.get(i);
		        	
		        	j1.put("userName", user.getUserName());
		        	j1.put("fullName", user.getFullName());
		        	j1.put("emailId", user.getEmailId());
		        	j1.put("department", user.getDepartment());
		        	j1.put("imageName", user.getImageName());
		        	j1.put("activeFlag", user.getActiveFlag());
		        	
		        	finaldata.add(j1);
		        }
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getUsersMain || End");
		        return Response.status(retStat).entity(json.toString()).build();   
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
		} catch (RepoproException e) {
			log.error("getUsersMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getUsersMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getUsersMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getUsersMain || End");
		}
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/**
	 * @method getUserByUserId
	 * @description to get user by id
	 * @param userId
	 *            the requested user id
	 * @return Response List<ApiUser>
	 */
	@GET
	@Path("/retrieveUser/{userId}")
	public Response getUserByUserId(@PathParam("userId") Long userId) {

		if (log.isTraceEnabled()) {
			log.trace("getUserByUserId || begin with userId :" + userId);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		Connection conn = null;
		User userById = null;
		List<User> userList = new ArrayList<User>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || dao method called : getUserByUserId(userId)");
			}

			userById = userDao.getUserByUserId(userId, conn);
			User user = new User();
			user.setUserId(userById.getUserId());
			user.setUserName(userById.getUserName());
			user.setFullName(userById.getFullName());
			user.setEmailId(userById.getEmailId());
			user.setImageName(userById.getImageName());
			user.setImage(userById.getImage());
			user.setRoleId(userById.getRoleId());
			user.setSubscribe(userById.isSubscribe());
			user.setActiveFlag(userById.getActiveFlag());
			user.setDepartment(userById.getDepartment());
			user.setAdminMessageFlag(userById.getAdminMessageFlag());
			user.setLeaderBoardFlag(userById.getLeaderBoardFlag());
			user.setRecentActivityFlag(userById.getRecentActivityFlag());
			user.setUserDetailFlag(userById.getUserDetailFlag());
			user.setQuickStatFlag(userById.getQuickStatFlag());
			//user.setPassword(userById.getString("password"));
			user.setSectionPosition(userById.getSectionPosition());
			user.setSectionVisibility(userById.getSectionVisibility());
			userList.add(user);

			if (log.isDebugEnabled()) {
				log.debug("getUserByUserId || user : " + userList.toString());
			}

			log.debug(" getUserByUserId  || retrieved " + userList.size()
					+ " user by userId : " + userId + "successfully ");

			retStat = Status.OK;
			retMsg = Constants.USER_BY_ID_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		catch (Exception e) {
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getUserByUserId  || exit");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(userList))).build();
	}




	//=========================================================================================================================================
	/***Wrapper function***/
	/**
	 * @method getUserByUserId
	 * @description to get user by id
	 * @param userName
	 * @return Response 
	 */
	@GET
	@Path("/retrieveUser/userName")
	public Response getUserByUserIdMain(@QueryParam("userName") String userName) {

		if(userName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(userName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		if (log.isTraceEnabled()) {
			log.trace("getUserByUserIdMain || begin with userName :" + userName);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		Connection conn = null;
		Response response = null;
		userName = userName.trim();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getUserByUserIdMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			User user = new User();
			if (!userName.equalsIgnoreCase("guest")) {
				User user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}

			user = userDao.getUserIdByUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
			}

			response = this.getUserByUserId(user.getUserId());
			return response;

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getUserByUserIdMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getUserByUserIdMain  || exit");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	//=========================================================================================================================================	




	/**
	 * 
	 * @param userId
	 * @return
	 */
	public User getUserByUserIdForImport(Long userId) {

		if (log.isTraceEnabled()) {
			log.trace("getUserByUserId || begin with userId :" + userId);
		}

		UserDao userDao = new UserDao();
		Connection conn = null;
		User userById = null;
		List<User> userList = new ArrayList<User>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || dao method called : getUserByUserId(userId)");
			}

			userById = userDao.getUserByUserId(userId, conn);

			if (log.isDebugEnabled()) {
				log.debug("getUserByUserId || user : " + userList.toString());
			}

			log.debug(" getUserByUserId  || retrieved " + userList.size()
					+ " user by userId : " + userId + "successfully ");

		}catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getUserByUserId  || exit");
		}
		return userById;
	}

	/**
	 * @method getUsers
	 * @description to get all users for grid
	 * @param
	 * @return Response List<ApiUser>
	 */
	@GET
	@Path("/userForGrid")
	public Response getAllUserNamesForGrid(@QueryParam("userName") String userName ,
			@QueryParam("from") Long from) {

		if (log.isTraceEnabled()) {
			log.trace("getAllUserNamesForGrid || begin with user id from :"+ from);
		}

		UserDao userDao = new UserDao();
		List<User> usersListForGrid = null;
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<User> userListGrid = new ArrayList<User>();
		try {
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getAllUserNamesForGrid || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllUserNamesForGrid || dao method called : getUsersForGrid(from)");
			}
			usersListForGrid = userDao.getUsersForGrid(userName ,from, conn);

			for (User profile : usersListForGrid) {
				if(!profile.getUserName().equalsIgnoreCase("admin")){
					User user = new User();
					user.setUserId(profile.getUserId());
					user.setUserName(profile.getUserName());
					user.setFullName(profile.getFullName());
					user.setEmailId(profile.getEmailId());
					user.setImageName(profile.getImageName());
					if (profile.getActiveFlag().equalsIgnoreCase("0")) {
						user.setActiveFlag("Inactive");
					} else {
						user.setActiveFlag("Active");
					}
					if (profile.getPassword().equalsIgnoreCase("")) {
						user.setNative(false);
					} else {
						user.setNative(true);
					}
					user.setDepartment(profile.getDepartment());
					user.setLockStatus(profile.getLockStatus());

					user.setEncryptFullName(profile.getEncryptFullName());
					user.setEncryptEmailId(profile.getEncryptEmailId());
					user.setEncryptDepartment(profile.getEncryptDepartment());
					user.setEncryptImage(profile.getEncryptImage());
					userListGrid.add(user);

					if (log.isTraceEnabled()) {
						log.trace("getAllUserNamesForGrid || " + user.toString());
					}
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllUserNamesForGrid || "
						+ userListGrid.toString());
			}

			log.info(" getAllUserNamesForGrid  :retrieved "
					+ usersListForGrid.size() + " users successfully|| "
					+ " from : " + from.toString());

			retStat = Status.OK;
			retMsg = Constants.USERS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			if (usersListForGrid.isEmpty()) {
				retStat = Status.OK;
				retMsg = Constants.USER_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllUserNamesForGrid || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getAllUserNamesForGrid ||  exit");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(userListGrid))).build();

	}

	

	/**
	 * @method getAllUserNamesForGridMain
	 * @description to get all users for grid
	 * @param
	 * @return Response List<ApiUser>
	 */
	@GET
	@Path("/getAllUserNamesForGridMain")
	public Response getAllUserNamesForGridMain(@QueryParam("from") String from,
			@HeaderParam("token") String token) {
		
		if(from == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(from.trim().isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		if (log.isTraceEnabled()) {
			log.trace("getAllUserNamesForGridMain || Begin");
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		
		User user1 = new User();
		UserDao userDao = new UserDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean userFlag = false;
		RoleDao roledao = new RoleDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId(userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllUserNamesForGridMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (!userName.equalsIgnoreCase("guest")) {
				user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user1 != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user1.getUserId(), conn);
			}
				        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
			        break;
				}
			}
			
			if(userFlag || adminFlag){
				response = this.getAllUserNamesForGrid(userName,Long.valueOf(from));
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	User user = new User();
		        	user = (User) data.get(i);
		        	
		        	j1.put("userName", user.getUserName());
		        	j1.put("fullName", user.getFullName());
		        	j1.put("emailId", user.getEmailId());
		        	j1.put("department", user.getDepartment());
		        	j1.put("imageName", user.getImageName());
		        	j1.put("activeFlag", user.getActiveFlag());
		        	
		        	finaldata.add(j1);
		        }
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getAllUserNamesForGridMain || End");
		        return Response.status(retStat).entity(json.toString()).build();   
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }			
			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllUserNamesForGridMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getAllUserNamesForGridMain ||  exit");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/**
	 * @method addUser
	 * @description to add a new user
	 * @param user
	 * @return Response SuccessMessage
	 */
	@POST
	@Path("/addUser")
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response addUser(@FormDataParam("hiddenVariableForManageUser")String hiddenVariableForManageUser, 
			FormDataMultiPart formParams, 
			@Context ServletContext context){
		
		

/*		if (log.isTraceEnabled()) {
			log.trace("addUser || begin with : uName " + uName
					+ "  fullName : "
					+ fullName + " || emailId : " + emailId
					+ " || department : " + department);
		}
		if (uName == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {*/
		String uName = "";
		String fullName = "";
		String emailId = "";
		String department = "";
		String encryptFullName = "";
		String encryptEmailId = "";
		String encryptDepartment = "";
		String encryptImage = "";
		
		String jsonStr = hiddenVariableForManageUser;
		JSONObject obj = null;
		try {
			
			 obj = new JSONObject(jsonStr);
			 uName = obj.get("uName").toString();
			 fullName = obj.get("fullName").toString();
			 emailId = obj.get("emailId").toString();
			 department = obj.get("department").toString();
			 encryptFullName = obj.get("encryptFullName").toString();
			 encryptEmailId = obj.get("encryptEmailId").toString();
			 encryptDepartment = obj.get("encryptDepartment").toString();
			 encryptImage = obj.get("encryptImage").toString();
			 
			
		} catch (JSONException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			List<String> jsonList = new ArrayList<String>();
			Connection conn = null;
			UserDao userDao = new UserDao();
			User userList = new User();
			String jsonRslt;
			boolean flag = true;
			boolean emailFlag = true;

			try {
				if (log.isTraceEnabled()) {
					log.trace("addUser || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("addUser || dao method called : getUsers()");
				}
				List<User> usersList = userDao.getUsers(false, conn);

				 department = URLDecoder.decode(department,"UTF-8");

				FormDataBodyPart dataMultiPart = null;

				if(formParams!=null){

					dataMultiPart = formParams.getField("userImage");
                 if(dataMultiPart != null){
					if (dataMultiPart.getContentDisposition().getFileName() != null) {
						userList.setImage(dataMultiPart
								.getEntityAs(InputStream.class));
						userList.setImageName(dataMultiPart.getContentDisposition()
								.getFileName());

					}
				}else {
						userList.setImageName(null);
					}
				}
				String userPassword = "Pa55w0rd!";
				EncryptPassword encryptPwd = new EncryptPassword();
				userPassword = encryptPwd.encryptPassword(userPassword);
				userList.setUserName(uName);
				userList.setPassword(userPassword);
				
				userList.setFullName(fullName);
				userList.setEmailId(emailId);
				userList.setDepartment(department);
				
				userList.setEncryptFullName(Integer.parseInt(encryptFullName));
				userList.setEncryptEmailId(Integer.parseInt(encryptEmailId));
				userList.setEncryptDepartment(Integer.parseInt(encryptDepartment));
				userList.setEncryptImage(Integer.parseInt(encryptImage));
				
				//User user = userDao.getUserByUserId(1L, conn);
				userList.setSectionPosition("Tags~~0,Taxonomies~~1,Overview~~2,Properties~~3,Relationships & Reverse Relationships~~4,Revision History~~5,Discussion~~6,Versions~~7,Asset Visualization~~8");
				userList.setSectionVisibility("Tags~~checked,Taxonomies~~checked,Overview~~checked,Properties~~checked,Relationships & Reverse Relationships~~checked,Revision History~~checked,Discussion~~checked,Versions~~checked,Asset Visualization~~checked");

				if (log.isDebugEnabled()) {
					log.debug("addUser || " + userList.toString());
				}

				if (usersList.size() > 0) {
					if (log.isDebugEnabled()) {
						log.debug("addUser || check whether entered name already exist || "
								+ "uName : " + uName);
					}
					for (int i = 0; i < usersList.size(); i++) {

						if (uName.equalsIgnoreCase(usersList.get(i)
								.getUserName())) {
							flag = false;
							break;
						}

					}
				}

				/*if (usersList.size() > 0) {
					if (log.isDebugEnabled()) {
						log.debug("addUser || check whether entered email id already exist ||  "
								+ "email id : " + emailId);
					}
					for (int i = 0; i < usersList.size(); i++) {

						if (emailId.equalsIgnoreCase(usersList.get(i)
								.getEmailId())) {
							emailFlag = false;
							break;
						}
					}
				}

				if (emailFlag == false) {
					log.warn("addUser || entered email id already exist || "
							+ "emailId : " + emailId);
					jsonRslt = Constants.EMAIL_EXIST;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE, MessageUtil
									.getMessage(Constants.EMAIL_EXIST),
									new ArrayList<Object>(jsonList))).build();
				}*/

				if (flag == false) {
					log.warn("addUser || entered user name already exist || "
							+ "uName : " + uName);

					jsonRslt = Constants.USER_NAME_EXIST;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.USER_NAME_EXIST),
									new ArrayList<Object>(jsonList))).build();
				} else {
					jsonRslt = Constants.SUCCESS;

					if (log.isTraceEnabled()) {
						log.trace("addUser || dao method called : addUser(userList)");
					}

					Long userIdAdd = userDao.addUser(userList, conn);
					jsonList.add(userIdAdd.toString());
					conn.commit();
					log.info(" addUser  || added a user by user id : "
							+ userIdAdd.toString() + " successfully || "
							+ "uName " + uName + " || fullName : " + fullName
							+ " || emailId : " + emailId + " || department : "
							+ department);

				}
				if(dataMultiPart != null){
				if (jsonList != null && formParams != null) {
					for (int i = 0; i < jsonList.size(); i++) {
						BufferedImage image = null;

						image = ImageIO.read(dataMultiPart
								.getEntityAs(InputStream.class));
						String name = dataMultiPart.getContentDisposition()
								.getFileName();
						String userId =  jsonList.get(i);
						if (name.toLowerCase().indexOf("jpg".toLowerCase()) != -1
								|| name.toUpperCase().indexOf(
										"jpg".toUpperCase()) != -1) {
							String uploadedFileLocation = context.getRealPath("")
									+ Constants.USERIMAGE_FILE_NAME +userId+Constants.USERIMAGE_JPG_NAME ;
							ImageIO.write(image, "jpg", new File(
									uploadedFileLocation));
						} else if (name.toLowerCase().indexOf(
								"png".toLowerCase()) != -1
								|| name.toUpperCase().indexOf(
										"png".toUpperCase()) != -1) {
							String uploadedFileLocation = context.getRealPath("")
									+ Constants.USERIMAGE_FILE_NAME +userId+Constants.USERIMAGE_PNG_NAME;
							ImageIO.write(image, "png", new File(
									uploadedFileLocation));
						}
					}
				}}
				retStat = Status.OK;
				retMsg = Constants.USER_CREATED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;

				MailTemplateDao mailTemplateDao = new MailTemplateDao();

				String msg = "Your profile has been created as : \n User Name : "+ userList.getUserName() +  "\nPassword : Pa55w0rd! "+ "\nFull Name : "+ fullName + "\n NOTE: Please change the Password using 'Reset Password' link under Profile section in Home Page";

				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(
						Constants.REPOPRO_PROFILE_CREATED), MessageUtil.getMessage(Constants.EMAIL_HDR) 
						+ msg+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));


				retStat = Status.OK;
				retMsg = Constants.USER_CREATED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}

			catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			}catch (Exception e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}

			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addUser || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("addUser  || " + jsonList.toString() + " || end");
			}
			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(jsonList))).build();
		//}

	}
	
	
	@POST
	@Path("/addUserMain")
	public Response addUserMain(
			@FormDataParam("userDetails") String userDetails,
			FormDataMultiPart formParams, @Context ServletContext context,
			@HeaderParam("token") String token){
		
		String uName = null;
		String fullName = null;
		String emailId = null;
		String department = null;
		UserDao userDao = new UserDao();
		User userDto = new User();
		
		try {
			String jsonStr1 = userDetails;
			JSONObject jsonObject = new JSONObject(jsonStr1);
			if(jsonObject.has("uName")){
				uName = jsonObject.get("uName").toString();
			}
			if(jsonObject.has("fullName")){
				fullName = jsonObject.get("fullName").toString();
			}
			if(jsonObject.has("emailId")){
				emailId = jsonObject.get("emailId").toString();
			}
			if(jsonObject.has("department")){
				department = jsonObject.get("department").toString();
			}
			
			if(uName == null || fullName == null || emailId == null || department == null){
				   return Response.status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
			}
			if(uName.trim().isEmpty() || fullName.trim().isEmpty() || emailId.trim().isEmpty() || department.trim().isEmpty()){
				   return Response.status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
			if(fullName.trim().length()>50 || emailId.trim().length()>150 || department.trim().length()>50){
				   return Response .status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
				
		Response response = null;
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		User user = new User();
		RoleDao roledao = new RoleDao();
		boolean userFlag = false;
		boolean adminFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		uName = uName.trim();
		fullName = fullName.trim();
		emailId = emailId.trim();
		department = department.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			conn = DBConnection.getInstance().getConnection();
			
			if(!userName.equalsIgnoreCase("guest")){
				user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
			        break;
				}
			}
			
			if(userFlag || adminFlag){
				
				boolean flag = true;
				List<User> usersList = userDao.getUsers(false, conn);
				if (usersList.size() > 0) {
					if (log.isDebugEnabled()) {
						log.debug("addUserMain || check whether entered name already exist || " + "uName : " + uName);
					}
					for (int i = 0; i < usersList.size(); i++) {
						if (uName.equalsIgnoreCase(usersList.get(i).getUserName())) {
							flag = false;
							break;
						}
					}
				}
				if (flag == false) {
					log.warn("addUserMain || entered user name already exist || " + "uName : " + uName);
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.USER_NAME_EXIST))).build();
				}
				
				User user1 = userDao.getUserByUserId(1L, conn);
				
				String userPassword = "Pa55w0rd!";
				
				EncryptPassword encryptPwd = new EncryptPassword();
				userPassword = encryptPwd.encryptPassword(userPassword);
				userDto.setUserName(uName);
				userDto.setPassword(userPassword);
				userDto.setFullName(fullName);
				userDto.setEmailId(emailId);
				userDto.setDepartment(department);
				userDto.setActiveFlag("1");
				userDto.setSectionPosition(user1.getSectionPosition());
				userDto.setSectionVisibility(user1.getSectionVisibility());
				
				FormDataBodyPart dataMultiPart = null;
				if(formParams!=null){
					dataMultiPart = formParams.getField("userImage");
					
					if(dataMultiPart != null){
						String uploadedFileName = dataMultiPart.getContentDisposition().getFileName();
						
						if(uploadedFileName != null){
							
							if(uploadedFileName.endsWith(".png") || uploadedFileName.endsWith(".jpg") || uploadedFileName.endsWith(".jpeg")
									|| uploadedFileName.endsWith(".PNG") || uploadedFileName.endsWith(".JPG") || uploadedFileName.endsWith(".JPEG")){

								if (dataMultiPart.getContentDisposition().getFileName() != null) {
									userDto.setImage(dataMultiPart.getEntityAs(InputStream.class));
									userDto.setImageName(dataMultiPart.getContentDisposition().getFileName());
								}
							}else{
								return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Only 'png/jpg/jpeg' format images are supported")).build();
							}

							String folder_Name = "userImageFolder";
							String srcFolder = "";
							String fileName = "";

							srcFolder = System.getProperty("user.home") + "/" + folder_Name;
							fileName = userDto.getImageName();

							File srcBaseFolderPath = new File(srcFolder);
							String filePath = "";
							// Base folder creation for an artifact
							if (!srcBaseFolderPath.exists()) {
								if (srcBaseFolderPath.mkdirs()) {
									filePath = srcBaseFolderPath.getAbsolutePath();
								} else {
									filePath = srcBaseFolderPath.getAbsolutePath();
								}
							} else {
								filePath = srcBaseFolderPath.getAbsolutePath();
							}

							// File file=new File(filePath);
							FileOutputStream outputStream = null;
							outputStream = new FileOutputStream(filePath + "/" + fileName);

							byte[] bytes = StreamUtils.copyToByteArray(userDto.getImage());
							outputStream.write(bytes);

							outputStream.close();
							outputStream.flush();
							/*String fileName = context.getRealPath("")+Constants.USERIMAGE_FILE_NAME+
								userId+ Constants.USERIMAGE_JPG_NAME;*/
							String fileName1 = filePath + "/" + fileName;
							File newFile = new File(fileName1);
							
							double size = (double)newFile.length()/(1024);
														
							File directory = new File(filePath);
							//make sure directory exists 
							if(directory.exists()){
								//To delete artifact inside src folder from user home
								DeleteSrcFolderContent deletesrcFolder = new DeleteSrcFolderContent();
								deletesrcFolder.delete(directory);
							}							
							
							if(size>1024){
								return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "File size should be less than 1MB")).build();
							}
						}
					}
				}
				
				String newRegex = "^[A-Za-z0-9]+$";
				Pattern pattern = Pattern.compile(newRegex);
				Matcher matcher = pattern.matcher(uName);
				
				if(!matcher.find()){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, "Please use alphanumeric characters in user name field"))
							.build();
				}
				
				String newRegex1 = "^[A-Za-z-. ]+$";
				Pattern pattern1 = Pattern.compile(newRegex1);
				Matcher matcher1 = pattern1.matcher(fullName);
				
				if(!matcher1.find()){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, "Please use only alphabets, dot and hyphen in full name field"))
							.build();
				}
				
				//String emailId = "deekshathbs@m.abc";
				String newRegex2 = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
						+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z0-9]{2,})$";
				Pattern pattern2 = Pattern.compile(newRegex2);
				Matcher matcher2 = pattern2.matcher(emailId);
				
				if(!matcher2.find()){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_EMAIL_ID)))
							.build();
				}
				
				String iChars = "`!%^*=[];{}|<>?~";

				for (int i = 0; i < department.length(); i++){
					if (iChars.indexOf(department.charAt(i)) != -1){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, "Special characters except :'\"+#$/&(),-_.@ are not allowed in department field"))
								.build();
					}
				}
				if(formParams != null){
					if(dataMultiPart != null){
						userDto.setImage(dataMultiPart.getEntityAs(InputStream.class));
					}
				}
				
				Long userId = userDao.addUser(userDto, conn);
				
				if(formParams != null){
					BufferedImage image = null;
					
					if(dataMultiPart != null){
						image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
						String name = dataMultiPart.getContentDisposition().getFileName();
						
						if(name != null){
							if (name.toLowerCase().indexOf("jpg".toLowerCase()) != -1
									|| name.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {

								String uploadedFileLocation = context.getRealPath("")
										+ Constants.USERIMAGE_FILE_NAME + userId+ Constants.USERIMAGE_JPG_NAME;

								ImageIO.write(image, "jpg", new File(uploadedFileLocation));

							} else if (name.toLowerCase().indexOf("png".toLowerCase()) != -1
									|| name.toUpperCase().indexOf("png".toUpperCase()) != -1) {

								String uploadedFileLocation = context.getRealPath("")
										+ Constants.USERIMAGE_FILE_NAME + userId+ Constants.USERIMAGE_PNG_NAME;
								ImageIO.write(image, "png", new File(uploadedFileLocation));
							}
						}
					}
				}
								
				conn.commit();
				
				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				String msg = "Your profile has been created as : \n User Name : "+ uName +  "\nPassword : Pa55w0rd! "+ "\nFull Name : "+ fullName + "\n NOTE: Please change the Password using 'Reset Password' link under Profile section in Home Page";
				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(
						Constants.REPOPRO_PROFILE_CREATED), MessageUtil.getMessage(Constants.EMAIL_HDR) 
						+ msg+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
				
				JSONObject json = new JSONObject();
				
				json.put("message", Constants.USER_CREATED);
				json.put("status", Constants.SUCCESS);
				json.put("statusCode", Constants.INSERT_STATUS_SUCCESS);
				log.trace("addUserMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
						
		} catch (RepoproException e) {
			log.error("addUserMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addUserMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addUserMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.trace("addUserMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
		

	/**
	 * @method updateUser
	 * @description to update a user
	 * @param userId user id to update
	 * @param ApiUser user to be updated
	 * @return Response SuccessMessage
	 */
	@PUT
	@Path("/updateUser")
	public Response updateUser(@FormDataParam("hiddenVariableForManageEditedUser")String hiddenVariableForManageEditedUser,
			FormDataMultiPart formParams, @Context ServletContext context){

		/*if (log.isTraceEnabled()) {
			log.trace("updateUser || begin with userId:" + userId
					+ " uName " + uName + " || fullName : " + fullName
					+ " || emailId : " + emailId + " || department : "
					+ department + "|| oldPassword : " + oldPassword
					+ "|| newPassword : " + newPassword + "|| formParams : "
					+ formParams);
		}
*/
		
		String usrId="";
		String uName = "";
		String fullName = "";
		String emailId = "";
		String department = "";
		String oldPassword = "";
		String newPassword = "";
		String encryptFullName = "";
		String encryptEmailId = "";
		String encryptDepartment = "";
		String encryptImage = "";
		
		String jsonStr = hiddenVariableForManageEditedUser;
		String associatedGroupIds="";
		JSONObject obj = null;
		try {
			
			
			 obj = new JSONObject(jsonStr);
			 usrId = obj.get("editedUserId").toString();
			 uName = obj.get("uName").toString();
			 fullName = obj.get("fullName").toString();
			 emailId = obj.get("emailId").toString();
			 department = obj.get("department").toString();
			 oldPassword = obj.get("oldPassword").toString();
			 newPassword = obj.get("newPassword").toString();
			 associatedGroupIds=obj.get("addedUserFunctionIds1").toString();
			 encryptFullName = obj.get("encryptFullName").toString();
			 encryptEmailId = obj.get("encryptEmailId").toString();
			 encryptDepartment = obj.get("encryptDepartment").toString();
			 encryptImage = obj.get("encryptImage").toString();
			
		} catch (JSONException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<String> jsonList = new ArrayList<String>();
		UserDao userDao = new UserDao();
		boolean flag = true;
		boolean emailFlag = true;
		Long userId=Long.parseLong(usrId);
		List<User> UserList1 = new ArrayList<User>();
		String NewFileName = "";
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateUser || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("addUser || dao method called : getUsers()");
			}
			List<User> usersList = userDao.getUsers(false, conn);
			department = URLDecoder.decode(department,"UTF-8");
			newPassword = URLDecoder.decode(newPassword,"UTF-8");
			oldPassword = URLDecoder.decode(oldPassword,"UTF-8");

			User userData = userDao.getUserByUserId(userId, conn);
			String jsonRslt;
			User updatedUser = new User();
			
			updatedUser.setUserId(userId);
			updatedUser.setUserName(uName);
			updatedUser.setImageName(userData.getImageName());
			updatedUser.setImage(userData.getImage());
			updatedUser.setFullName(fullName);
			updatedUser.setEmailId(emailId);
			updatedUser.setDepartment(department);
			updatedUser.setEncryptFullName(Integer.parseInt(encryptFullName));
			updatedUser.setEncryptEmailId(Integer.parseInt(encryptEmailId));
			updatedUser.setEncryptDepartment(Integer.parseInt(encryptDepartment));
			updatedUser.setEncryptImage(Integer.parseInt(encryptImage));

			FormDataBodyPart dataMultiPart = null;

			if(formParams!=null){

				dataMultiPart = formParams.getField("uploadUserImageBtnInUserPage");
				
				if(dataMultiPart != null){/*
					if (dataMultiPart.getContentDisposition().getFileName() != null) {
						updatedUser.setImage(dataMultiPart
							.getEntityAs(InputStream.class));
					updatedUser.setImageName(dataMultiPart
							.getContentDisposition().getFileName());
				}
				*/

					if (dataMultiPart.getContentDisposition().getFileName() != null) {
						 NewFileName = dataMultiPart.getContentDisposition().getFileName();
						if(NewFileName.equals("")||NewFileName.length() == 0){
							updatedUser.setImageName(userData.getImageName());
							updatedUser.setImage(userData.getImage());
						}else{
							updatedUser.setImage(dataMultiPart
									.getEntityAs(InputStream.class));
							updatedUser.setImageName(dataMultiPart.getContentDisposition()
									.getFileName());
						}

					}
				}
			}

			if (!oldPassword.equalsIgnoreCase("")) {

				String oldPassworddata = oldPassword;
				String newPassworddata = newPassword;

				EncryptPassword encryptPwd = new EncryptPassword();
				String oldUserPassword = userData.getPassword();
				newPassworddata = encryptPwd.encryptPassword(newPassworddata);
				oldPassworddata = encryptPwd.encryptPassword(oldPassworddata);

				if (userData.getUserName().equalsIgnoreCase(uName)
						&& oldPassworddata.equalsIgnoreCase(oldUserPassword)) {

					updatedUser.setPassword(oldPassworddata);
					updatedUser.setNewPassword(newPassworddata);

					if (log.isTraceEnabled()) {
						log.trace("updateUser ||dao call of  changePassword method to reset password");
					}
					userDao.changePassword(updatedUser, conn);

				} else {
					jsonRslt = Constants.USER_PASSWORD_NOT_UPDATED;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.UPDATE_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.USER_PASSWORD_NOT_UPDATED),
									new ArrayList<Object>(jsonList))).build();
				}

			}			

			if (log.isDebugEnabled()) {
				log.debug("updateUser || " + updatedUser.toString());
			}

			/*if (usersList.size() > 0) {
				if (log.isDebugEnabled()) {
					log.debug("updateUser || check whether entered email id already exist ||  "
							+ "email id : " + emailId);
				}
				if(!userData.getEmailId().equalsIgnoreCase(emailId)){
					for (int i = 0; i < usersList.size(); i++) {

						if (emailId.equalsIgnoreCase(usersList.get(i).getEmailId())) {
							emailFlag = false;
							break;
						}
					}
				}
			}*/

			/*if (emailFlag == false) {
				log.warn("updateUser || entered email id already exist || "
						+ "emailId : " + emailId);
				jsonRslt = Constants.EMAIL_EXIST;
				jsonList.add(jsonRslt);
				return Response
						.status(Status.OK)
						.entity(new MyModel(
								Constants.INSERT_STATUS_SUCCESS,
								Constants.FAILURE, MessageUtil
								.getMessage(Constants.EMAIL_EXIST),
								new ArrayList<Object>(jsonList))).build();
			}else {*/

				jsonRslt = Constants.SUCCESS;
				if (log.isTraceEnabled()) {
					log.trace("updateUser ||dao call of  updateUser method to update user data");
				}
				userDao.updateUser(updatedUser, conn);

			//}


			if (formParams != null) {
				if(!NewFileName.equals("")||NewFileName.length() != 0){

				File file = new File(context.getRealPath("")+ Constants.USERIMAGE_FILE_NAME);
				String[] myFiles;

				if (file.isDirectory()) {
					myFiles = file.list();
					for (int i = 0; i < myFiles.length; i++) {
						File myFile = new File(file, myFiles[i]);
						if(myFile.getName().equalsIgnoreCase(userId+".jpg")||myFile.getName().equalsIgnoreCase(userId+".png"))
						{
							myFile.delete();
						}
					}
				}
				BufferedImage image = null;
				
				if(dataMultiPart != null){
				image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
				
				String name = dataMultiPart.getContentDisposition().getFileName();
				
				if (name.toLowerCase().indexOf("jpg".toLowerCase()) != -1
						|| name.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {

					String uploadedFileLocation = context.getRealPath("")
							+ Constants.USERIMAGE_FILE_NAME + userId+ Constants.USERIMAGE_JPG_NAME;

					ImageIO.write(image, "jpg", new File(uploadedFileLocation));

				} else if (name.toLowerCase().indexOf("png".toLowerCase()) != -1
						|| name.toUpperCase().indexOf("png".toUpperCase()) != -1) {

					String uploadedFileLocation = context.getRealPath("")
							+ Constants.USERIMAGE_FILE_NAME + userId+ Constants.USERIMAGE_PNG_NAME;
					ImageIO.write(image, "png", new File(uploadedFileLocation));
				}
			}
			}
		}

			List<User> userGroupList = new ArrayList<User>();
			String[] addedGroups = new String[]{};
			List<String> groupId = new ArrayList<String>();
			
			if(!associatedGroupIds.equalsIgnoreCase("")){
				addedGroups = associatedGroupIds.split(",");
			}
			
			if (log.isTraceEnabled()) {
				log.trace("updateUser ||dao call of  addUserGroup method to add user associated groups");
			}
			userGroupList = userDao.addUserGroup(userId,addedGroups,conn);
			updatedUser.setPassword(null);
			updatedUser.setNewPassword(null);
			updatedUser.setConfirmNewPassword(null);
			UserList1.add(updatedUser);

			MailTemplateDao mailTemplateDao = new MailTemplateDao(); 
			MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateUserProfile");
			String mailTemp = mtVo.getMailTemplate();
			mailTemp = mailTemp.replaceAll("%fullName%", fullName).replaceAll("%emailId%", emailId).replaceAll("%userName%", updatedUser.getUserName());
			MailTemplateDao mailDao = new MailTemplateDao();
			MailConfig mailConfig = mailDao.getMailConfig(conn);
			SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_PROFILE_UPDATE), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

			log.info(" updateUser  || user by user id :" + userId.toString()
					+ " is updated successfully || " + updatedUser.toString());

			conn.commit();
			retMsg = Constants.USER_UPDATED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			}

		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateUser || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("updateUser || end");

	
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,new ArrayList<Object>(UserList1))).build();
	}


	/***Wrapper function***/
	/**
	 * @method updateUser
	 * @description to update a user
	 * @param userId user id to update
	 * @param ApiUser user to be updated
	 * @return Response SuccessMessage
	 */
	@PUT
	@Path("/updateUserMain")
	public Response updateUserMain(
			@FormDataParam("userDetails") String userDetails,
			FormDataMultiPart formParams, @Context ServletContext context,
			@HeaderParam("token") String token){

		if(userDetails == null){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(userDetails.isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		if(userDetails != null){
			try {
				String jsonStr = userDetails;
				JSONObject jsonObject = new JSONObject(jsonStr);
				if(jsonObject.has("uName") && !jsonObject.has("fullName") && !jsonObject.has("emailId") 
						&& !jsonObject.has("department") && !jsonObject.has("associatedGroupNames")){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
				}
			} catch (JSONException e) {
				e.printStackTrace();
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
		}
				
		if (log.isTraceEnabled()) {
			log.trace("updateUserMain || begin with userDetails : " 
					+ userDetails.toString()+ "|| formParams : " + formParams);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		Response response = null;
		UserDao userDao = new UserDao();
		GroupDao groupDao = new GroupDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		List<String> grpNames = new ArrayList<String>();
		List<String> grpNamesList = new ArrayList<String>();
		boolean userFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		List<String> groupIdsList = new ArrayList<String>();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("updateUserMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			User user = new User();
			if (!userName.equalsIgnoreCase("guest")) {
				User user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			User user1 = userDao.getUserIdByUserName(userName, conn);//check if logged in user has access
			if (user1.getUserId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("updateUserMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			boolean imageFlag = false;
			StringBuffer procedure = new StringBuffer("");
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			
			userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user1.getUserId(), conn);

			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
			        break;
				}
			}
			
			if(userFlag || adminFlag){
				
				String jsonStr1 = userDetails;
				JSONObject jsonObject = new JSONObject(jsonStr1);
				String uName = "";
				if(formParams != null || jsonObject.has("fullName") || jsonObject.has("emailId")
						|| jsonObject.has("department")){
					
					if(jsonObject.has("uName")){
						uName = jsonObject.get("uName").toString();
						uName = uName.trim();
						if(uName.isEmpty()){
							return Response.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
						}
						user = userDao.retProfileForUserName(uName, conn);//check if username is present
						if (user == null) {
							retStat = Status.NOT_FOUND;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.USER_NOT_FOUND;
							retStatScsFlr = Constants.GET_STATUS_FAILURE;
							log.trace("updateUserMain || End");
							return Response.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						
						if(user.getActiveFlag().equalsIgnoreCase("0")){
							retStat = Status.BAD_REQUEST;
							retScsFlr = Constants.FAILURE;
							retMsg = "USER_INACTIVE";
							retStatScsFlr = Constants.STATUS_FAILURE;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					}else{
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
					}
					
					
					procedure = new StringBuffer("update profile set ");
					
					if(jsonObject.has("fullName")){
						String fullName = jsonObject.get("fullName").toString();
						fullName = fullName.trim();
						if(fullName.isEmpty()){
							   return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
						}
						if(fullName.length()>50){
							return Response.status(Status.BAD_REQUEST)
								     .entity(new MyModelRest(Constants.STATUS_FAILURE,
								       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
						}
						String newRegex1 = "^[A-Za-z-. ]+$";
						Pattern pattern1 = Pattern.compile(newRegex1);
						Matcher matcher1 = pattern1.matcher(fullName);
						
						if(!matcher1.find()){
							return Response.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, "Please use only alphabets, dot and hyphen in full name field"))
									.build();
						}
						procedure.append("full_name='"+fullName+"',");
					}
					if(jsonObject.has("emailId")){
						String emailId = jsonObject.get("emailId").toString();
						emailId = emailId.trim();
						if(emailId.isEmpty()){
							   return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
						}
						if(emailId.trim().length()>150){
							return Response.status(Status.BAD_REQUEST)
								     .entity(new MyModelRest(Constants.STATUS_FAILURE,
								       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
						}
						String newRegex2 = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
								+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z0-9]{2,})$";
						Pattern pattern2 = Pattern.compile(newRegex2);
						Matcher matcher2 = pattern2.matcher(emailId);
						
						if(!matcher2.find()){
							return Response
									.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_EMAIL_ID)))
									.build();
						}
						procedure.append("email_id='"+emailId+"',");
					}
					if(jsonObject.has("department")){
						String department = jsonObject.get("department").toString();
						department = department.trim();
						if(department.isEmpty()){
							   return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
						}
						if(department.length()>50){
							return Response.status(Status.BAD_REQUEST)
								     .entity(new MyModelRest(Constants.STATUS_FAILURE,
								       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
						}
						String iChars = "`!%^*=[];{}|<>?~";

						for (int i = 0; i < department.length(); i++){
							if (iChars.indexOf(department.charAt(i)) != -1){
								return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Special characters except :'\"+#$/&(),-_.@ are not allowed in department field"))
										.build();
							}
						}
						procedure.append("department='"+department+"',");
					}
					
					User userData = userDao.getUserByUserId(user.getUserId(), conn);
					user.setImageName(userData.getImageName());
					user.setImage(userData.getImage());
					
					FormDataBodyPart dataMultiPart = null;
					if(formParams!=null){
						dataMultiPart = formParams.getField("userImage");
						if(dataMultiPart != null){
							String uploadedFileName = dataMultiPart.getContentDisposition().getFileName();
							
							if(uploadedFileName != null){
								if(uploadedFileName.endsWith(".png") || uploadedFileName.endsWith(".jpg") || uploadedFileName.endsWith(".jpeg")
										|| uploadedFileName.endsWith(".PNG") || uploadedFileName.endsWith(".JPG") || uploadedFileName.endsWith(".JPEG")){

									if (dataMultiPart.getContentDisposition().getFileName() != null) {
										user.setImage(dataMultiPart.getEntityAs(InputStream.class));
										user.setImageName(dataMultiPart.getContentDisposition().getFileName());
										
										imageFlag = true;
										procedure.append("image_name=?,");
										procedure.append("image=? ");
									}
								}else{
									return Response.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, "Only 'png/jpg/jpeg' format images are supported")).build();
								}
								String folder_Name = "userImageFolder";
								String srcFolder = "";
								String fileName = "";

								srcFolder = System.getProperty("user.home") + "/" + folder_Name;
								fileName = user.getImageName();

								File srcBaseFolderPath = new File(srcFolder);
								String filePath = "";
								// Base folder creation for an artifact
								if (!srcBaseFolderPath.exists()) {
									if (srcBaseFolderPath.mkdirs()) {
										filePath = srcBaseFolderPath.getAbsolutePath();
									} else {
										filePath = srcBaseFolderPath.getAbsolutePath();
									}
								} else {
									filePath = srcBaseFolderPath.getAbsolutePath();
								}

								// File file=new File(filePath);
								FileOutputStream outputStream = null;
								outputStream = new FileOutputStream(filePath + "/" + fileName);

								byte[] bytes = StreamUtils.copyToByteArray(user.getImage());
								outputStream.write(bytes);

								outputStream.close();
								outputStream.flush();
								/*String fileName = context.getRealPath("")+Constants.USERIMAGE_FILE_NAME+
									userId+ Constants.USERIMAGE_JPG_NAME;*/
								String fileName1 = filePath + "/" + fileName;
								File newFile = new File(fileName1);
								
								double size = (double)newFile.length()/(1024);
															
								File directory = new File(filePath);
								//make sure directory exists 
								if(directory.exists()){
									//To delete artifact inside src folder from user home
									DeleteSrcFolderContent deletesrcFolder = new DeleteSrcFolderContent();
									deletesrcFolder.delete(directory);
								}							
								
								if(size>1024){
									return Response.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, "File size should be less than 1MB")).build();
								}
							}
						}						
						
						File file = new File(context.getRealPath("")+ Constants.USERIMAGE_FILE_NAME);
						String[] myFiles;

						if (file.isDirectory()) {
							myFiles = file.list();
							for (int i = 0; i < myFiles.length; i++) {
								File myFile = new File(file, myFiles[i]);

								if (myFile.getName().matches(Long.toString(user.getUserId())+"(.*)")) {
									myFile.delete();
								}
							}
						}
						BufferedImage image = null;
						
						if(dataMultiPart != null){
							image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
							String name = dataMultiPart.getContentDisposition().getFileName();
							
							if(name != null){
								if (name.toLowerCase().indexOf("jpg".toLowerCase()) != -1
										|| name.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {

									String uploadedFileLocation = context.getRealPath("")
											+ Constants.USERIMAGE_FILE_NAME + user.getUserId()+ Constants.USERIMAGE_JPG_NAME;

									ImageIO.write(image, "jpg", new File(uploadedFileLocation));

								} else if (name.toLowerCase().indexOf("png".toLowerCase()) != -1
										|| name.toUpperCase().indexOf("png".toUpperCase()) != -1) {

									String uploadedFileLocation = context.getRealPath("")
											+ Constants.USERIMAGE_FILE_NAME + user.getUserId()+ Constants.USERIMAGE_PNG_NAME;
									ImageIO.write(image, "png", new File(uploadedFileLocation));
								}
							}
						}
					}
					
					
					
					/*
					FormDataBodyPart dataMultiPart = null;
					if(formParams!=null){
						dataMultiPart = formParams.getField("userImage");
						if (dataMultiPart.getContentDisposition().getFileName() != null) {
							//updatedUser.setImage(dataMultiPart.getEntityAs(InputStream.class));
							//updatedUser.setImageName(dataMultiPart.getContentDisposition().getFileName());
							
							user.setImage(dataMultiPart.getEntityAs(InputStream.class));
							user.setImageName(dataMultiPart.getContentDisposition().getFileName());
							
							InputStream image = dataMultiPart.getEntityAs(InputStream.class);
							String imageName = dataMultiPart.getContentDisposition().getFileName();
							procedure.append(",image_name='"+user.getImageName()+"'");
							procedure.append(",image='"+user.getImage()+"'");
						}
						
						File file = new File(context.getRealPath("")+ Constants.USERIMAGE_FILE_NAME);
						String[] myFiles;

						if (file.isDirectory()) {
							myFiles = file.list();
							for (int i = 0; i < myFiles.length; i++) {
								File myFile = new File(file, myFiles[i]);

								if (myFile.getName().matches(Long.toString(user.getUserId())+"(.*)")) {
									myFile.delete();
								}
							}
						}
						BufferedImage image = null;

						image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
						String name = dataMultiPart.getContentDisposition().getFileName();

						if (name.toLowerCase().indexOf("jpg".toLowerCase()) != -1
								|| name.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {

							String uploadedFileLocation = context.getRealPath("")
									+ "/profileImages/"
									+ user.getUserId()+".jpg";

							ImageIO.write(image, "jpg", new File(uploadedFileLocation));

						} else if (name.toLowerCase().indexOf("png".toLowerCase()) != -1
								|| name.toUpperCase().indexOf("png".toUpperCase()) != -1) {

							String uploadedFileLocation = context.getRealPath("")
									+ "/profileImages/"
									+ user.getUserId()+".png";
							ImageIO.write(image, "png", new File(uploadedFileLocation));
						}
						
						
					}*/
					
					procedure.deleteCharAt(procedure.length() - 1);
					
					procedure.append(" where user_id="+user.getUserId()+";");
					
					preparedStmt = conn.prepareStatement(procedure.toString());
					
					if(imageFlag == true){
						preparedStmt.setString(Constants.ONE, user.getImageName());
						preparedStmt.setBinaryStream(Constants.TWO, user.getImage());
					}
										
					if(uName.equalsIgnoreCase("admin")){
						if(userName.equalsIgnoreCase("admin")){
							if(jsonObject.has("associatedGroupNames")){
								return Response.status(Status.BAD_REQUEST)
									     .entity(new MyModelRest(Constants.STATUS_FAILURE,
									       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
							}
							preparedStmt.executeUpdate();
							conn.commit();
							JSONObject json = new JSONObject();
							
							json.put("message", Constants.USER_UPDATED);
							json.put("status", Constants.SUCCESS);
							json.put("statusCode", Constants.UPDATE_STATUS_SUCCESS);
							log.trace("updateUserMain || End");
							
							return Response.status(retStat).entity(json.toString()).build();
						}else{
							return Response.status(Status.UNAUTHORIZED)
									.entity(new MyModelRest(Constants.UNAUTHORIZED,
											Constants.FAILURE, Constants.USER_NOT_AUTHORIZED)).build();
						}
					}
					preparedStmt.executeUpdate();
				}
				
				
				if(jsonObject.has("associatedGroupNames")){
					String associatedGroupNames = jsonObject.get("associatedGroupNames").toString();
					associatedGroupNames = associatedGroupNames.trim();
					if(associatedGroupNames.isEmpty()){
						   return Response.status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					
					String[] splitNames = associatedGroupNames.split(",");

					for(int i=0;i<splitNames.length;i++){
						splitNames[i] = splitNames[i].trim();
						if(!splitNames[i].isEmpty()){
							grpNames.add(splitNames[i]);
						}
					}
					grpNamesList = grpNames;
					
					/* to check if each group name passed is valid */
					List<String> groupNamesFromDB = new ArrayList<String>();
					if(!grpNamesList.isEmpty()){
						List<GroupDetails> allGroups = groupDao.getAllGroups(conn);
						for(GroupDetails gd : allGroups){
							groupNamesFromDB.add(gd.getGroupName());
						}
						
						for(int i=0;i<splitNames.length;i++){
							splitNames[i] = splitNames[i].trim();
							if(!groupNamesFromDB.contains(splitNames[i])){
								retStat = Status.NOT_FOUND;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.GROUP_DATA_NOT_FOUND;
								retStatScsFlr = Constants.GET_STATUS_FAILURE;

								log.trace("updateUserMain || End");
								return Response.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}
						}
						
						for(int i=0;i<splitNames.length;i++){
							int groupId = groupDao.getGroupIdByGroupName(splitNames[i],conn);
							if(groupId != 0){
								groupIdsList.add(String.valueOf(groupId));
							}else{
								retStat = Status.NOT_FOUND;
								retMsg = Constants.GROUP_DATA_NOT_FOUND;
								retScsFlr = Constants.FAILURE;
								retStatScsFlr = Constants.GET_STATUS_FAILURE;
							 	return Response.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}
						}
						
						String[] groupIds = new String[groupIdsList.size()];
						groupIds = groupIdsList.toArray(groupIds);
						userDao.addUserGroup(user.getUserId(),groupIds,conn);
					}	
				}
				
				conn.commit();
				String userEmailId = null;
				if(jsonObject.has("emailId")){
					userEmailId = jsonObject.get("emailId").toString();
					userEmailId = userEmailId.trim();
				}
				
				MailTemplateDao mailTemplateDao = new MailTemplateDao(); 
				MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateUserProfile");
				String mailTemp = mtVo.getMailTemplate();
				if(userEmailId != null && !userEmailId.isEmpty()){
					mailTemp = mailTemp.replaceAll("%fullName%", user.getFullName()).replaceAll("%emailId%", userEmailId).replaceAll("%userName%", uName);
				}else{
					mailTemp = mailTemp.replaceAll("%fullName%", user.getFullName()).replaceAll("%emailId%", user.getEmailId()).replaceAll("%userName%", uName);
				}
				
				MailTemplateDao mailDao = new MailTemplateDao();
				MailConfig mailConfig = mailDao.getMailConfig(conn);
				SendEmail.sendTextMail(mailConfig,user.getEmailId(), MessageUtil.getMessage(Constants.REPOPRO_PROFILE_UPDATE), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
				
				JSONObject json = new JSONObject();
				
				json.put("message", Constants.USER_UPDATED);
				json.put("status", Constants.SUCCESS);
				json.put("statusCode", Constants.UPDATE_STATUS_SUCCESS);
				log.trace("updateUserMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateUserMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("updateUserMain || end");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}



	/**
	 * @method changePassword
	 * @description to change password
	 * @param userName user name to change password
	 * @return Response SuccessMessage
	 */
	@PUT
	@Path("changePassword/{userId}")
	public Response changePassword(@PathParam("userId") Long userId, User user) {

		if (log.isTraceEnabled()) {
			log.trace("changePassword || begin with userId : " + userId
					+ " || user : " + user.toString());
		}

		if (userId == null) {
			log.warn("changePassword || entered user id is null || user id : "
					+ userId);
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			List<String> jsonList = new ArrayList<String>();
			UserDao userDao = new UserDao();
			User userList = new User();

			String oldPassword = user.getPassword();
			String newPassword = user.getNewPassword();
			String confirmNewPassword = user.getConfirmNewPassword();

			userList.setUserId(userId);
			userList.setPassword(user.getPassword());
			userList.setNewPassword(user.getNewPassword());
			userList.setConfirmNewPassword(user.getConfirmNewPassword());

			try {
				if (log.isTraceEnabled()) {
					log.trace("changePassword || "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				String jsonRslt;

				if (log.isTraceEnabled()) {
					log.trace("changePassword || dao method called : getUserByUserId(userId)");
				}

				User userByUserId = userDao.getUserByUserId(userId, conn);

				EncryptPassword encryptPwd = new EncryptPassword();
				String oldUserPassword = userByUserId.getPassword();
				//oldUserPassword = encryptPwd.encryptPassword(oldUserPassword);
				newPassword = encryptPwd.encryptPassword(newPassword);
				confirmNewPassword = encryptPwd
						.encryptPassword(confirmNewPassword);
				oldPassword = encryptPwd.encryptPassword(oldPassword);

				if (oldPassword.equalsIgnoreCase(oldUserPassword)) {
					if (newPassword.equalsIgnoreCase(confirmNewPassword)) {

						userList.setNewPassword(newPassword);

						if (log.isDebugEnabled()) {
							log.debug("changePassword || "
									+ userList.toString());
						}

						if (log.isTraceEnabled()) {
							log.trace("changePassword || dao method called : changePassword(userList)");
						}

						userDao.changePassword(userList, conn);

						log.info(" changePassword  || password of user id "
								+ userId.toString()
								+ " is updated successfully || Updated password : "
								+ userList.getNewPassword());

						retMsg = Constants.USER_PASSWORD_UPDATED;
						retScsFlr = Constants.SUCCESS;
						retStat = Status.OK;
						retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
					}

				} else {
					jsonRslt = Constants.USER_PASSWORD_NOT_UPDATED;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.UPDATE_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.USER_PASSWORD_NOT_UPDATED),
									new ArrayList<Object>(jsonList))).build();
				}

				MailTemplateDao mailTemplateDao = new MailTemplateDao(); 
				MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateUserProfile");
				String mailTemp = mtVo.getMailTemplate();
				mailTemp = mailTemp.replaceAll("%fullName%", userByUserId.getFullName()).replaceAll("%emailId%", userByUserId.getEmailId()).replaceAll("%userName%", userByUserId.getUserName());
				MailTemplateDao mailDao = new MailTemplateDao();
				MailConfig mailConfig = mailDao.getMailConfig(conn);
				SendEmail.sendTextMail(mailConfig,userByUserId.getEmailId(), MessageUtil.getMessage(Constants.REPOPRO_PROFILE_UPDATE), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

				conn.commit();
				retMsg = Constants.USER_PASSWORD_UPDATED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				return Response
						.status(Status.OK)
						.entity(new MyModel(
								Constants.UPDATE_STATUS_SUCCESS,
								Constants.SUCCESS,
								MessageUtil
								.getMessage(Constants.USER_PASSWORD_UPDATED)))
								.build();

			} catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retMsg = e.getMessage();
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				}

			} catch (Exception e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retMsg = e.getMessage();
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				}

			} finally {
				if (log.isTraceEnabled()) {
					log.trace("changePassword || Constants.LOG_CONNECTION_CLOSE");
				}
				DBConnection.closeDbConnection(conn);
			}
			log.trace("changePassword || exit");
			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
					.build();
		}

	}


	/***Wrapper function***/
	@PUT
	@Path("/changePasswordMain")
	public Response changePasswordMain(
			@FormDataParam("changePasswordDetails") String changePasswordDetails,
			@HeaderParam("token") String token){
		
		String password = null;
		String newPassword = null;
		String confirmNewPassword = null;
		
		if(changePasswordDetails == null){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(changePasswordDetails.isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		try {
			String jsonStr1 = changePasswordDetails;
			JSONObject jsonObject = new JSONObject(jsonStr1);
			if(jsonObject.has("password")){
				password = jsonObject.get("password").toString();
			}
			if(jsonObject.has("newPassword")){
				newPassword = jsonObject.get("newPassword").toString();
			}
			if(jsonObject.has("confirmNewPassword")){
				confirmNewPassword = jsonObject.get("confirmNewPassword").toString();
			}
			
			if(password == null || newPassword == null || confirmNewPassword == null){
				   return Response.status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
			}
			if(password.trim().isEmpty() || newPassword.trim().isEmpty() || confirmNewPassword.trim().isEmpty()){
				   return Response.status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
			if(password.trim().length()>50 || newPassword.trim().length()>50 || confirmNewPassword.trim().length()>50){
				   return Response .status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		if (log.isTraceEnabled()) {
			log.trace("changePasswordMain || password : " + CommonUtils.encrypt(password) +" newPassword : "+ CommonUtils.encrypt(newPassword) 
					+" confirmNewPassword : "+ CommonUtils.encrypt(confirmNewPassword) );
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response response = null;
		UserDao userDao = new UserDao();
		password = password.trim();
		newPassword = newPassword.trim();
		confirmNewPassword = confirmNewPassword.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("changePasswordMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
			User user = new User();
			user.setUserName(userName);
			user.setPassword(password);
			user.setNewPassword(newPassword);
			user.setConfirmNewPassword(confirmNewPassword);

			User user1 = new User();
			user1 = userDao.retProfileForUserName(userName, conn);
			if(user1 == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			String newRegex1 = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{6,20})";
			Pattern pattern2 = Pattern.compile(newRegex1);
			Matcher matcher2 = pattern2.matcher(newPassword);
			
			if(!matcher2.find()){
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
						 Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_PASSWORD))).build();
			}
			
			if(!newPassword.equalsIgnoreCase(confirmNewPassword)){
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
						 Constants.FAILURE, "Passwords do not match")).build();
			}
			
			response = this.changePassword(user1.getUserId(), user);
			MyModel res = (MyModel) response.getEntity();
			JSONObject json = new JSONObject();
			
			if(res.getStatus().equalsIgnoreCase(Constants.FAILURE)){
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", Constants.STATUS_FAILURE);
				return Response.status(Status.BAD_REQUEST).entity(json.toString()).build();
			}
			
			json.put("message", res.getMessage());
			json.put("status", res.getStatus());
			json.put("statusCode", res.getStatusCode());
			log.trace("changePasswordMain || End");
			
			return Response.status(retStat).entity(json.toString()).build();		
			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

		} finally {
			if (log.isTraceEnabled()) {
				log.trace("changePasswordMain || Constants.LOG_CONNECTION_CLOSE");
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("changePasswordMain || exit");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}


	/**
	 * @method deleteUser
	 * @description to delete a user
	 * @param userId user id to update
	 * @param ApiUser user to be updated
	 * @return Response SuccessMessage

	 */
	@SuppressWarnings("null")
	@DELETE
	@Path("/deleteUser/{userId}")
	public Response deleteUser(@PathParam("userId") Long userId) {

		if (log.isDebugEnabled()) {
			log.debug("deleteUser || begin with userId : " + userId);
		}
		if (userId == null) {
			log.warn("deleteUser || entered user id is null "
					+ userId.toString());

			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			UserDao userDao = new UserDao();

			try {
				if (log.isTraceEnabled()) {
					log.trace("deleteUser || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("deleteUser || dao method called : getUserByUserId(userId)");
				}

				User updatedUser = userDao.getUserByUserId(userId, conn);

				if (log.isDebugEnabled()) {
					log.debug("deleteUser || " + updatedUser.toString());
				}

				updatedUser.setActiveFlag("0");

				if (log.isTraceEnabled()) {
					log.trace("deleteUser || dao method called : updateUser(updatedUser)");
				}

				userDao.deleteUser(updatedUser, conn);
				conn.commit();

				log.info("deleteUser || deleted user with user id "
						+ userId.toString() + " successfully");

				retMsg = Constants.USER_DELETED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;

			} catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			} catch (Exception e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retMsg = e.getMessage();
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				}

			} finally {
				if (log.isTraceEnabled()) {
					log.trace("deleteUser || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			log.trace("deleteUser || end");
			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
					.build();
		}
	}





	//================================================================================================================================================	
	/***Wrapper function***/
	/**
	 * @method deleteUser
	 * @description to delete a user
	 * @param userId user id to update
	 * @param ApiUser user to be updated
	 * @return Response SuccessMessage
	 */
	
	@DELETE
	@Path("/deleteUser/userName")
	public Response deleteUserMain(@FormDataParam("userDetails") String userDetails, 
			@HeaderParam("token") String token) {

		if(userDetails == null) {
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE, Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(userDetails.trim().isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}

		if (log.isDebugEnabled()) {
			log.debug("deleteUserMain || begin with userDetails : " + userDetails);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response response = null;
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean userFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		userDetails = userDetails.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		User user1 = new User();

		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteUserMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}

			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			User user = userDao.retProfileForUserName(userName, conn);
			if(user == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}

			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
					break;
				}
			}

			if(userFlag || adminFlag){
				
				String jsonStr = userDetails;
				JSONObject jsonObject = new JSONObject(jsonStr);
				
				if(jsonObject.has("userNameToBeDeleted")){
					String userNameToBeDeleted = jsonObject.get("userNameToBeDeleted").toString();
					userNameToBeDeleted = userNameToBeDeleted.trim();
					if(userNameToBeDeleted.isEmpty()){
						return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					
					user1 = userDao.retProfileForUserName(userNameToBeDeleted, conn);
					if(user1 == null){
						retStat = Status.NOT_FOUND;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.USER_NOT_FOUND;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
					}					
					
				}else{
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE, Constants.FAILURE, MessageUtil
									.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
				}
				
				response = this.deleteUser(user1.getUserId());
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("deleteUserMain || End");
				return Response.status(retStat).entity(json.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;

		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteUserMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("deleteUserMain || end");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	//================================================================================================================================================	



	/**
	 * @method : getAllUserGroups
	 * @param userId
	 * @return success response
	 */
	@GET
	@Path("/getAllUserGroups")
	public Response getAllUserGroups(@QueryParam("userId") Long userId) {

		log.trace("getAllUserGroups || begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		GroupDao groupDao = new GroupDao();
		UserDao userDao = new UserDao();
		List<GroupDetails> groupDetails = new ArrayList<GroupDetails>();
		List<GroupDetails> groupDetailsMappedWithUser = new ArrayList<GroupDetails>();
		List<GroupDetails> groupDetailsMappedWithUsersList = new ArrayList<GroupDetails>();
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getAllUserGroups || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllUserGroups || dao method called : getAllGroups() to get list of all groups");
			}
			groupDetails = groupDao.getAllGroups(conn);
			if (log.isTraceEnabled()) {
				log.trace("getAllUserGroups || dao method called : retAllUserGroupsMappedWithUserId() to get list of  groups");
			}
			groupDetailsMappedWithUser = userDao.retAllUserGroupsMappedWithUserId(userId,conn);
			for(GroupDetails groupDetail : groupDetails){
				GroupDetails group = new GroupDetails();
				group.setGroupId(groupDetail.getGroupId());
				group.setGroupName(groupDetail.getGroupName());
				group.setDescription(groupDetail.getDescription());
				group.setMappedWithUser(false);
				for(GroupDetails groupDetailsMapped : groupDetailsMappedWithUser){
					if(groupDetailsMapped.getGroupId() == groupDetail.getGroupId()){
						group.setMappedWithUser(true);
					}
				}
				groupDetailsMappedWithUsersList.add(group);
			}
			retStat = Status.OK;
			retMsg = Constants.ASSOCIATED_GROUP_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			log.debug(" getAllUserGroups  || retrieved " + groupDetailsMappedWithUsersList.size()
					+ " users successfully");

			if (groupDetailsMappedWithUsersList.isEmpty()) {
				retStat = Status.OK;
				retMsg = Constants.ASSOCIATED_GROUP_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			}
		}

		catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllUserGroups || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getAllUserGroups ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(groupDetailsMappedWithUsersList))).build();
	}



	//=========================================================================================================================================================
	/***Wrapper function***/
	/**
	 * @method : getAllUserGroupsMain
	 * @param userName
	 * @return success response
	 */
	@GET
	@Path("/getAllUserGroups/userName")
	public Response getAllUserGroupsMain(@QueryParam("uName") String uName,
			@HeaderParam("token") String token) {

		if(uName == null){
			   return Response .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(uName.trim().isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}		
		log.trace("getAllUserGroupsMain || begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		UserDao userDao = new UserDao();
		boolean adminFlag = false;
		RoleDao roledao = new RoleDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean userFlag = false;
		uName = uName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId(userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllUserGroupsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			User user1 = userDao.getUserIdByUserName(uName, conn);
			if(user1.getUserId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			User user = new User();
			user = userDao.getUserIdByUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}

			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
			        break;
				}
			}
			
			if(userFlag || adminFlag){
				
				if(user1.getActiveFlag().equalsIgnoreCase("0")){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = "USER_INACTIVE";
					retStatScsFlr = Constants.STATUS_FAILURE;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				
				response = this.getAllUserGroups(user1.getUserId());
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	GroupDetails gd = new GroupDetails();
		        	gd = (GroupDetails) data.get(i);
		        	
		        	j1.put("groupName", gd.getGroupName());
		        	j1.put("description", gd.getDescription());
		        	j1.put("mappedWithUser", gd.isMappedWithUser());
		        	
		        	finaldata.add(j1);
		        }
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getAllUserGroupsMain || End");
		        return Response.status(retStat).entity(json.toString()).build();   
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllUserGroupsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getAllUserGroupsMain ||  exit ");

		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

	}
	//=========================================================================================================================================================


	/**
	 * @method : updateUserActiveFalg
	 * @param assetDef
	 * @return success response
	 */
	@PUT
	@Path("/updateUserActiveFlag")
	public Response updateUserActiveFlag(User user){
		if (log.isTraceEnabled()) {
			log.trace("updateUserActiveFlag || Begin: user:"+user.toString());
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		UserDao userDao = new UserDao(); 
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateUserActiveFlag ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (!user.equals(null)) {

				if (log.isTraceEnabled()) {
					log.trace("updateUserActiveFlag || dao call of updateActiveFlag() method to set active flag for user");
				}
				userDao.updateActiveFlag(user, conn);
			}
			if (log.isDebugEnabled()) {
				log.debug("updateUserActiveFlag || active flag:"+user.getActiveFlag()+" was set for user with user id:"+user.getUserId()+" successfully");
			}
			conn.commit();

			retMsg = Constants.USER_ACCESS_SAVED_SUCCESSFULLY;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			}
		}catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateUserActiveFlag||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("updateUserActiveFlag || Enduser:"+user.toString());
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

	}


	/***Wrapper function***/
	@PUT
	@Path("/updateUserActiveFlagMain")
	public Response updateUserActiveFlagMain(@FormDataParam("uNameDetails") String uNameDetails, 
			@HeaderParam("token") String token){
		
		if(uNameDetails == null){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(uNameDetails.trim().isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		String uName = null;
		String activeFlag = null;
		
		try{
			String jsonStr = uNameDetails;
			JSONObject jsonObject = new JSONObject(jsonStr);
			
			if(jsonObject.has("uName")){
				uName = jsonObject.getString("uName").toString();
				uName = uName.trim();
			}
			if(jsonObject.has("activeFlag")){
				activeFlag = jsonObject.get("activeFlag").toString();
				activeFlag = activeFlag.trim();
			}
			
			if(uName == null || activeFlag == null){
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
			}
			if(uName.isEmpty() || activeFlag.isEmpty()){
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
			return Response.status(Status.BAD_REQUEST).entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
				
		if (log.isTraceEnabled()) {
			log.trace("updateUserActiveFlagMain || Begin with uNameDetails :"+uNameDetails);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean userFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		Response response = null;
		uNameDetails = uNameDetails.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId(userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("updateUserActiveFlagMain ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			User user = new User();
			
			User user2 = new User();
			user2 = userDao.retProfileForUserName(uName, conn);
			if(user2 == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			User user1 = userDao.retProfileForUserName(userName, conn);
			if(user1 == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			String activeFlagVal = "";
			if(activeFlag.equalsIgnoreCase("true")){
				activeFlagVal = "1";
			}
			if(activeFlag.equalsIgnoreCase("false")){
				activeFlagVal = "0";
			}
			
			user.setUserId(user2.getUserId());
			user.setActiveFlag(activeFlagVal);
			
			if(!activeFlag.equalsIgnoreCase("true") && !activeFlag.equalsIgnoreCase("false")){
				 return Response.status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user1.getUserId(), conn);
			
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
			        break;
				}
			}

			if(userFlag || adminFlag){
				response = this.updateUserActiveFlag(user);
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("updateUserActiveFlagMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

		}catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateUserActiveFlagMain||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateUserActiveFlagMain || End");
		}
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

	}



	/**
	 * @method updateDynamicWidgets
	 * @description to update flag values for dynamic widgets
	 * @param user
	 * @return success response message
	 * @throws RepoproException
	 */
	@PUT
	@Path("/updateDynamicWidgets")
	public Response updateDynamicWidgets(User user) {

		if (user == null) {
			log.warn("updateDynamicWidgets || user data  not provided to update");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("updateDynamicWidgets || Begin" + user.toString());
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			UserDao userDao = new UserDao();
			try {
				if (log.isTraceEnabled()) {
					log.trace("updateDynamicWidgets ||"
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("updateDynamicWidgets || dao call of updateFlagsForDynamicWidgets() method to set  flags for user");
				}
				userDao.updateDynamicWidgets(user, conn);

				if (log.isDebugEnabled()) {
					log.debug("updateDynamicWidgets || " + user.toString()
							+ " was set for user with user id:"
							+ user.getUserId() + " successfully");
				}
				conn.commit();

				retMsg = Constants.DYNAMIC_WIDGETS_UPDATED_SUCCESSFULLY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			} catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retMsg = e.getMessage();
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				}
			} catch (Exception e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retMsg = e.getMessage();
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateDynamicWidgets||"
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("updateDynamicWidgets || End");
			}

			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
					.build();

		}
	}


	/***Wrapper function***/
	@PUT
	@Path("/updateDynamicWidgetsMain")
	public Response updateDynamicWidgetsMain(User user) {

		if (user == null) {
			log.warn("updateDynamicWidgetsMain || user data  not provided to update");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("updateDynamicWidgetsMain || Begin" + user.toString());
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			UserDao userDao = new UserDao();
			RoleDao roledao = new RoleDao();
			List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
			boolean userFlag = false;
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			boolean adminFlag = false;
			Response response = null;
			try {
				if (log.isTraceEnabled()) {
					log.trace("updateDynamicWidgetsMain ||" + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if(user.getUserName().equalsIgnoreCase("guest")){
					String userName = "roleAnonymous";
					userName = user.getUserName();
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					return Response.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
							.build();
				}

				User user1 = new User();
				user1 = userDao.getUserIdByUserName(user.getUserName(), conn);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}

				user = userDao.retProfileForUserName(user.getUserName(), conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
				if(user != null){
					adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(user.getUserName(), conn);
					userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
				}

				for(UserFunction uf : userfunctionMappedWithRoleId){
					if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
						userFlag = true;
				        break;
					}
				}

				if(userFlag || adminFlag){
					response = this.updateDynamicWidgets(user1);
					return response;
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					return Response.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
							.build();
				}

			} catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

			} catch (Exception e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateDynamicWidgetsMain||"
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("updateDynamicWidgetsMain || End");
			}

			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
					.build();

		}
	}


	/**
	 * @method getAllUsers
	 * @description to get all active users
	 * @return success response message with list of all active usres
	 * @throws RepoproException
	 */
	@GET
	@Path("/getAllActiveUsers")
	public Response getAllUsers() {

		List<User> activeUsersList = new ArrayList<User>();

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		UserDao userDao = new UserDao();

		if (log.isTraceEnabled()) {
			log.trace("getAllUsers || Begin");
		}

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllUsers ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getAllUsers || dao call of getAllActiveUser()");
			}
			activeUsersList = userDao.getAllActiveUser(conn);

			if (log.isInfoEnabled()) {
				log.info("getAllUsers || " + activeUsersList.toString() + "retrieved successfully");
			}

			retMsg = Constants.SUCCESS;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		catch (Exception e) {
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllUsers||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllUsers || End");
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,new ArrayList<Object>(activeUsersList)))
				.build();

	}


	/**
	 * @method : updateSubscriptionFlag
	 * @param userId
	 * @param flag
	 * @return
	 */
	@PUT
	@Path("/updateSubscriptionFlag")
	public Response updateSubscriptionFlag(@QueryParam("userId") Long userId, @QueryParam("flag") int flag){

		if(log.isTraceEnabled()){
			log.trace("updateSubscriptionFlag || Begin with userName : "+ userId +" \t flag : "+ flag);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		int subFlag = 0;

		List<Long> result = new ArrayList<Long>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateSubscriptionFlag ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			UserDao dao = new UserDao();

			if(flag == 1){
				subFlag = 1;
				dao.updateSubscriptionFlag(userId, subFlag, conn);
				result.add((long)subFlag);
			}else{
				subFlag = 0;
				dao.updateSubscriptionFlag(userId, subFlag, conn);
				result.add((long)subFlag);
			}

			conn.commit();

			retMsg = Constants.USER_ACCESS_SAVED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;


		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			}
		}
		catch (Exception e) {
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateSubscriptionFlag||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("updateSubscriptionFlag || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(result))).build();
	}


	/***Wrapper function***/
	@PUT
	@Path("/updateSubscriptionFlagMain")
	public Response updateSubscriptionFlagMain(@FormDataParam("flagDetails") String flagDetails,
			@HeaderParam("token") String token){

		if(flagDetails == null){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(flagDetails.trim().isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		String flag = null;
		try{
			String jsonStr = flagDetails;
			JSONObject jsonObject = new JSONObject(jsonStr);
			
			if(jsonObject.has("flag")){
				flag = jsonObject.get("flag").toString();
				flag = flag.trim();
			}
			if(flag == null){
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
			}
			if(flag.isEmpty()){
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
			return Response.status(Status.BAD_REQUEST).entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		if(log.isTraceEnabled()){
			log.trace("updateSubscriptionFlagMain || Begin with flagDetails : "+ flagDetails);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		UserDao userDao = new UserDao();
		flagDetails = flagDetails.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId(userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("updateSubscriptionFlagMain ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

			User user = new User();
			user = userDao.retProfileForUserName(userName, conn);
			if(user == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			String flagVal = "";
			if(flag.equalsIgnoreCase("true")){
				flagVal = "1";
			}
			if(flag.equalsIgnoreCase("false")){
				flagVal = "0";
			}
			
			if(!flag.equalsIgnoreCase("true") && !flag.equalsIgnoreCase("false")){
				 return Response.status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
			
			if(flag.equalsIgnoreCase("true") && user.isSubscribe() == true){
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ALREADY_SUBSCRIBED;
				retStatScsFlr = Constants.STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			if(flag.equalsIgnoreCase("false") && user.isSubscribe() == false){
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ALREADY_UNSUBSCRIBED;
				retStatScsFlr = Constants.STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			response = this.updateSubscriptionFlag(user.getUserId(),Integer.parseInt(flagVal));
			MyModel res = (MyModel) response.getEntity();				
			JSONObject json = new JSONObject();
			
			json.put("message", res.getMessage());
			json.put("status", res.getStatus());
			json.put("statusCode", res.getStatusCode());
			log.trace("updateSubscriptionFlagMain || End");
			
			return Response.status(retStat).entity(json.toString()).build();

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		}
		catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateSubscriptionFlagMain||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateSubscriptionFlagMain || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}



	/**
	 * @method forgotPassword
	 * @description to retrieve forgot password
	 * @param userName
	 * @return Response SuccessMessage

	 */
	@POST
	@Path("/forgotPassword/{userName}/")
	public Response retForgotPassword(@PathParam("userName") String userName) {
		
		if (log.isDebugEnabled()) {
			log.debug("retForgotPassword || begin with userName : " + userName);
		}
		if (userName == null || userName.equals("")) {
			log.warn("retForgotPassword || entered user name is null "
					+ userName.toString());

			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			UserDao userDao = new UserDao();
			char[] randomPwdNumbers = new char[6];
			String newPassword = "";
			User retvedProfile = null;;
			String password = "";
			//char ch = 0 ;
			GlobalSettingDao globalDao = new GlobalSettingDao();
			//List<GlobalSetting> globalsettinglist = new ArrayList<GlobalSetting>();
			String message ="";
			//List<String> jsonList = new ArrayList<String>();

			try {
				if (log.isTraceEnabled()) {
					log.trace("retForgotPassword || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("retForgotPassword || dao method called : retProfileForUserName(userName, conn)");
				}
				//if(!userName.equals(""))
					retvedProfile = userDao.retProfileForUserName(userName, conn);
				GlobalSetting globalsettinglist = globalDao.retGlobalSettingByName("Ldap",conn);
				
				if(retvedProfile == null){
					message = "Invalid UserName";
				}
				else{
					password = retvedProfile.getPassword();
					if(globalsettinglist.getGlobalLdapSettingFlag() == 1){
						
						//String userNameFromDB = retvedProfile.getUserName();
						
							
							if(password.equals("")){
								if(userName != null && retvedProfile.getActiveFlag().equals("0"))
									message = "Invalid UserName";
								else if(userName != null && retvedProfile.getActiveFlag().equals("1"))
									message = "Please contact your LDAP admin for your password details!";
								else
									message = "Invalid UserName";
							}else{
								if(userName != null && retvedProfile.getActiveFlag().equals("0")){
									message = "Invalid UserName";
								}else if((userName != null && retvedProfile.getActiveFlag().equals("1")) || (userName.equalsIgnoreCase("admin"))){
									randomPwdNumbers = PasswordGenerator.randomPwdGenerator();
									String str = "";
									for(int i=0;i<randomPwdNumbers.length;i++){
										str = str+randomPwdNumbers[i];
									}
									char[] profileChar = retvedProfile.getUserName().toCharArray();
									newPassword = str+retvedProfile.getUserName()+Character.toString(profileChar[0]).toUpperCase()+"!";
									
									EncryptPassword encryptPwd = new EncryptPassword();
									retvedProfile.setPassword(encryptPwd.encryptPassword(newPassword));
									if (log.isDebugEnabled()) {
										log.debug("retForgotPassword || dao method called : updateUserPassword(retvedProfile, conn)");
									}
									userDao.updateUserPassword(retvedProfile, conn);

									if (log.isTraceEnabled()) {
										log.trace("retForgotPassword || dao method called :  updateUserPassword(retvedProfile, conn)");
									}

									conn.commit();

									/*retMsg = Constants.USER_UPDATED;
									retScsFlr = Constants.SUCCESS;
									retStat = Status.OK;
									retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;*/

									MailTemplateDao mailTemplateDao = new MailTemplateDao();

									String msg = "Your new password is "+newPassword + "\n";

									MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
									SendEmail.sendTextMail(mailConfig, retvedProfile.getEmailId(), MessageUtil.getMessage(
											Constants.REPOPRO_PASSWORD_RESET), MessageUtil.getMessage(Constants.EMAIL_HDR) 
											+ msg+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

									
									message = "Reset password mail has been sent";
								}else{
									message = "Invalid UserName";
								}
							}
						//}
					}else{
						if(password.equals("")){
							if(userName != null && retvedProfile.getActiveFlag().equals("0")){
								message = "Invalid UserName";
							}else if(userName != null && retvedProfile.getActiveFlag().equals("1")){
								message = "This application is running in Native mode";
							}else{
								message = "Invalid UserName";	
							}
						}else{
							if(userName != null && retvedProfile.getActiveFlag().equals("0")){
								message = "Invalid UserName";
							}else if(userName != null && (retvedProfile.getActiveFlag().equals("1"))){
								randomPwdNumbers = PasswordGenerator.randomPwdGenerator();
								String str = "";
								for(int i=0;i<randomPwdNumbers.length;i++){
									str = str+randomPwdNumbers[i];
								}
								char[] profileChar = retvedProfile.getUserName().toCharArray();
								newPassword = str+retvedProfile.getUserName()+Character.toString(profileChar[0]).toUpperCase()+"!";
								
								EncryptPassword encryptPwd = new EncryptPassword();
								retvedProfile.setPassword(encryptPwd.encryptPassword(newPassword));
								if (log.isDebugEnabled()) {
									log.debug("retForgotPassword || dao method called : updateUserPassword(retvedProfile, conn)");
								}
								userDao.updateUserPassword(retvedProfile, conn);

								if (log.isTraceEnabled()) {
									log.trace("retForgotPassword || dao method called :  updateUserPassword(retvedProfile, conn)");
								}

								conn.commit();

								/*retMsg = Constants.USER_UPDATED;
								retScsFlr = Constants.SUCCESS;
								retStat = Status.OK;
								retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;*/

								MailTemplateDao mailTemplateDao = new MailTemplateDao();

								String msg = "Your new password is "+newPassword + "\n";

								MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
								SendEmail.sendTextMail(mailConfig, retvedProfile.getEmailId(), MessageUtil.getMessage(
										Constants.REPOPRO_PASSWORD_RESET), MessageUtil.getMessage(Constants.EMAIL_HDR) 
										+ msg+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

								
								message = "Reset password mail has been sent";
							}else{
								message = "Invalid UserName";
							}
						}
					}
				}


					//jsonList.add(message);
					if(!message.equalsIgnoreCase("Reset password mail has been sent")){
						retStat = Status.OK;
						retMsg = message;
						retScsFlr = Constants.FAILURE;
						retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
					}
					else{
						retMsg = message;
						retScsFlr = Constants.SUCCESS;
						retStat = Status.OK;
						retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
					}

			} catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retMsg = e.getMessage();
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				}
			} catch (Exception e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retMsg = e.getMessage();
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				}

			} finally {
				if (log.isTraceEnabled()) {
					log.trace("retForgotPassword || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			log.trace("retForgotPassword || end");
			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
					.build();
		}
	}


	/**
	 * @method updateDynamicWidgets
	 * @description to update flag values for dynamic widgets
	 * @param user
	 * @return success response message
	 * @throws RepoproException
	 */
	@PUT
	@Path("/updateLockStatus")
	public Response updateLockStatus(@QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("updateLockStatus || Begin with userName" + userName);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		UserDao userDao = new UserDao();
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateLockStatus ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("updateLockStatus || dao call of resetFailAttempts() method to reset lock status");
			}
			userDao.resetFailAttempts(userName, conn);

			conn.commit();

			retMsg = Constants.LOCK_STATUS_UPDATED_SUCCESSFULLY;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateLockStatus||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("updateLockStatus || End");
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
				.build();


	}
	
	
	/**
	 * @method updateLockStatusMain
	 * @description to update user when account is locked
	 * @param user
	 * @return success response message
	 * @throws RepoproException
	 */
	@PUT
	@Path("/updateLockStatusMain")
	public Response updateLockStatusMain(@FormDataParam("uNameDetails") String uNameDetails,
			@HeaderParam("token") String token) {
		
		if(uNameDetails == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(uNameDetails.trim().isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		String uName = null;
		try{
			String jsonStr = uNameDetails;
			JSONObject jsonObject = new JSONObject(jsonStr);
			
			if(jsonObject.has("uName")){
				uName = jsonObject.getString("uName").toString();
				uName = uName.trim();
			}
			if(uName == null){
				   return Response.status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
			}
			if(uName.trim().isEmpty()){
				   return Response.status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
			return Response.status(Status.BAD_REQUEST).entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		if (log.isTraceEnabled()) {
			log.trace("updateLockStatusMain || Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		UserDao userDao = new UserDao();
				
		if (log.isTraceEnabled()) {
			log.trace("updateLockStatusMain || Begin with uNameDetails :"+uNameDetails);
		}
		
		Response response = null;
		uNameDetails = uNameDetails.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId(userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("updateLockStatusMain ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			User user2 = new User();
			user2 = userDao.retProfiledetailsForUserName(uName, conn);
			if(user2 == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			if(userName.equalsIgnoreCase("admin")){
				if(user2.getActiveFlag().equalsIgnoreCase("0")){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = "USER_INACTIVE";
					retStatScsFlr = Constants.STATUS_FAILURE;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				if(user2.getLoginAttempt() < 3){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = "USER_ACCOUNT_NOT_LOCKED";
					retStatScsFlr = Constants.STATUS_FAILURE;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				response = this.updateLockStatus(uName);
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("updateLockStatusMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateLockStatusMain||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateLockStatusMain || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
		
	/**
	 * @method getFilteredUsersForGrid
	 * @description to get all filtered users for grid
	 * @param
	 * @return Response List<ApiUser>
	 */
	@GET
	@Encoded
	@Path("/filteredUsersForGrid")
	public Response getFilteredUsersForGrid(@QueryParam("userName") String userName, @QueryParam("serachString") String searchString ,@QueryParam("from") Long from) {

		if (log.isTraceEnabled()) {
			log.trace("getFilteredUsersForGrid || begin");
		}

		UserDao userDao = new UserDao();
		List<User> usersListForGrid = null;
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<User> userListGrid = new ArrayList<User>();
		try {
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getFilteredUsersForGrid || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (log.isTraceEnabled()) {
				log.trace("getFilteredUsersForGrid || dao method called : getUsersForGrid(from)");
			}
			
			String actualValue = URLDecoder.decode(searchString, "UTF-8");
			String value = "";
			if (actualValue.contains("_") || actualValue.contains("%") || actualValue.contains("'") || actualValue.contains("\\") || actualValue.contains("+")){
				value = actualValue;
				value = value.replace("\\", "\\\\");
				value = value.replace("_", "\\_");
				value = value.replace("%", "\\%");
				value = value.replace("'", "\\'");
				value = value.replace("+", "\\+");
			}else{
				value = actualValue;
			}
			usersListForGrid = userDao.getFlilteredUsersForGrid(userName, value ,from, conn);

			for (User profile : usersListForGrid) {
				if(!profile.getUserName().equalsIgnoreCase("")){
					User user = new User();
					user.setUserId(profile.getUserId());
					user.setUserName(profile.getUserName());
					user.setFullName(profile.getFullName());
					user.setEmailId(profile.getEmailId());
					user.setDepartment(profile.getDepartment());
					user.setImageName(profile.getImageName());
					if (profile.getActiveFlag().equalsIgnoreCase("0")) {
						user.setActiveFlag("Inactive");
					} else {
						user.setActiveFlag("Active");
					}
					if (profile.getPassword().equalsIgnoreCase("")) {
						user.setNative(false);
					} else {
						user.setNative(true);
					}

					user.setLockStatus(profile.getLockStatus());
					user.setEncryptFullName(profile.getEncryptFullName());
					user.setEncryptEmailId(profile.getEncryptEmailId());
					user.setEncryptDepartment(profile.getEncryptDepartment());
					user.setEncryptImage(profile.getEncryptImage());
					userListGrid.add(user);

					if (log.isTraceEnabled()) {
						log.trace("getFilteredUsersForGrid || " + user.toString());
					}
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getFilteredUsersForGrid || "
						+ userListGrid.toString());
			}

			log.info(" getFilteredUsersForGrid  :retrieved "
					+ usersListForGrid.size() + " users successfully|| ");

			retStat = Status.OK;
			retMsg = Constants.USERS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			if (usersListForGrid.isEmpty()) {
				retStat = Status.OK;
				retMsg = Constants.USER_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllUserNamesForGrid || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getFilteredUsersForGrid ||  exit");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(userListGrid))).build();

	}
	
	@GET
	@Path("/userName")
	public Response getUserNamefromSecurityContext(@Context HttpServletRequest request)
	{
		            if(log.isDebugEnabled()){
						log.debug("getUserNamefromSecurityContext : begin");
					}
            		HttpSession httpSession = request.getSession();
            		SecurityContext ctx = (SecurityContext) httpSession.getAttribute("SPRING_SECURITY_CONTEXT");
            		 
            		Authentication auth=ctx.getAuthentication();
					String userName = auth.getPrincipal().toString();
					
					
					
					if(log.isDebugEnabled()){
						log.debug("getUserNamefromSecurityContext  :  end");
					}
					return Response.ok(userName).build();
			
	}
	
	
	/**
	 * @method : getRoleGroupDetailsByUserName
	 * @param userName
	 * @param token
	 * @return
	 */
	@GET
	@Path("/groupRoleDetailsForUser")
	public Response getRoleGroupDetailsByUserName(@QueryParam("userName") String userName,
			@HeaderParam("token") String token){
		
		if(userName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		if(userName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		if(log.isTraceEnabled()){
			log.trace("getRoleGroupDetailsByUserName || Begin with username : "+ userName);
		}
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		userName = userName.trim();
		UserDao userDao = new UserDao();
		List<User> userListByUserName = new ArrayList<User>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getRoleGroupDetailsByUserName || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
			
			userListByUserName = userDao.getRoleGroupDetailsByUserName(userName, conn);
			
			JSONObject j1 = null;
			JSONObject json = new JSONObject();
			List<Object> finaldata = new ArrayList<Object>();
			for (int i = 0; i < userListByUserName.size(); i++) {
				j1 = new JSONObject();
				User user = new User();
				user = (User) userListByUserName.get(i);
				
				j1.put("roleName", user.getRoleName());
				j1.put("groupName", user.getGroupName());
				j1.put("roleDescription", user.getRoleDescription());
				j1.put("groupDescription", user.getGroupDescription());
				
				finaldata.add(j1);
			}
			json.put("result", finaldata);
			json.put("message", Constants.GROUP_ROLE_DETAILS_FETCHED);
			json.put("status", Constants.SUCCESS);
			json.put("statusCode", Constants.GET_STATUS_SUCCESS);
			log.trace("getRoleGroupDetailsByUserName || End");
			
			return Response.status(retStat).entity(json.toString())
					.build();
			
		} catch (RepoproException e) {
			log.error("getRoleGroupDetailsByUserName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getRoleGroupDetailsByUserName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getRoleGroupDetailsByUserName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getRoleGroupDetailsByUserName || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
		
	}
	
	@GET
	@Encoded
	@Path("/filterUsersAttributesForGrid")
	public Response getFilterUsersAttributesForGrid(@QueryParam("userName") String userName,
			@QueryParam("attributeList") String attributeList,
			@QueryParam("searchString") String searchString,@QueryParam("groupIds") String groupIds,
			@QueryParam("from") Long from) {

		if (log.isTraceEnabled()) {
			log.trace("getFilterUsersAttributesForGrid || begin");
		}

		UserDao userDao = new UserDao();
		List<User> usersListForGrid = null;
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<User> userListGrid = new ArrayList<User>();
		try {
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getFilterUsersAttributesForGrid || "+ Constants.LOG_CONNECTION_OPEN);
			}
			if (log.isTraceEnabled()) {
				log.trace("getFilterUsersAttributesForGrid || dao method called : getUsersForGrid(from)");
			}
			
			String actualValue = URLDecoder.decode(searchString, "UTF-8");
			String value = "";
			if (actualValue.contains("_") || actualValue.contains("%") || actualValue.contains("'") || actualValue.contains("\\") || actualValue.contains("+")){
				value = actualValue;
				value = value.replace("\\", "\\\\");
				value = value.replace("_", "\\_");
				value = value.replace("%", "\\%");
				value = value.replace("'", "\\'");
				value = value.replace("+", "\\+");
			}else{
				value = actualValue;
			}
			
			if(attributeList != null && !attributeList.isEmpty() && !attributeList.equalsIgnoreCase("")) {
				List<String> attributes = new ArrayList<String>(Arrays.asList(attributeList.split(",")));
				usersListForGrid = userDao.getFlilteredUsersAttributeForGrid(userName,attributes,value,from,groupIds,false,conn);
			}else {
				usersListForGrid = userDao.getFlilteredUsersForGrid(userName, value ,from, conn);
			}
			
			Set<User> usersListForGridSet = new HashSet<User>();
			
			usersListForGridSet.addAll(usersListForGrid);
			usersListForGrid = new ArrayList<User>();
			usersListForGrid.addAll(usersListForGridSet);
			
			for (User profile : usersListForGrid) {
				if(!profile.getUserName().equalsIgnoreCase("admin")){
					User user = new User();
					user.setUserId(profile.getUserId());
					user.setUserName(profile.getUserName());
					user.setFullName(profile.getFullName());
					user.setEmailId(profile.getEmailId());
					user.setImageName(profile.getImageName());
					if (profile.getActiveFlag().equalsIgnoreCase("0")) {
						user.setActiveFlag("Inactive");
					} else {
						user.setActiveFlag("Active");
					}
					if (profile.getPassword().equalsIgnoreCase("")) {
						user.setNative(false);
					} else {
						user.setNative(true);
					}
					user.setDepartment(profile.getDepartment());
					user.setLockStatus(profile.getLockStatus());
					userListGrid.add(user);

					if (log.isTraceEnabled()) {
						log.trace("getFilterUsersAttributesForGrid || " + user.toString());
					}
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getFilterUsersAttributesForGrid || "+ userListGrid.toString());
			}

			log.info(" getFilterUsersAttributesForGrid  :retrieved "+ usersListForGrid.size() + " users successfully|| ");

			retStat = Status.OK;
			retMsg = Constants.USERS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			if (usersListForGrid.isEmpty()) {
				retStat = Status.OK;
				retMsg = Constants.USER_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getFilterUsersAttributesForGrid || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getFilterUsersAttributesForGrid ||  exit");

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,new ArrayList<Object>(userListGrid))).build();

	}
}
