package com.thbs.repopro.accesscontrol;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;

public class LogoutSuccessHandler extends SimpleUrlLogoutSuccessHandler {
	
	static Logger log = Logger.getLogger(LogoutSuccessHandler.class.getName());

	   // Just for setting the default target URL
	   public LogoutSuccessHandler(String defaultTargetURL) {
	        this.setDefaultTargetUrl(defaultTargetURL);
	   }

	   @Override
	   public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
		   RedirectStrategy redirectStrategy =  super.getRedirectStrategy();
		   if(authentication != null)
		   {
		   if (log.isDebugEnabled()) {
				log.debug("onLogoutSuccess : begin with AuthenticationName : "+authentication.getName() + "begin");
				}
		  
	       // super.onLogoutSuccess(request, response, authentication);
	       
			
		   
	    	String token = request.getRequestedSessionId();
	    	UserDao userDao = new UserDao();
	    	userDao.deleteTokenDetails(token, null);
	    	redirectStrategy.sendRedirect(request, response,"/prelogout.html");
	    	
	        super.onLogoutSuccess(request, response, authentication);
	        if (log.isDebugEnabled()) {
				log.debug("onLogoutSuccess : Exit");
			}
	   }
		   else
		   {
			    String token = request.getRequestedSessionId();
		    	UserDao userDao = new UserDao();
		    	userDao.deleteTokenDetails(token, null);
			    redirectStrategy.sendRedirect(request, response,"/prelogout.html");
		   }
	}
}