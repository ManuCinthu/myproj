package com.thbs.repopro.accesscontrol;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

@Path("/guestAccess")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class GuestManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");
	GuestDao guestDao = new GuestDao();

	/**
	 * @method : retrieveGuestAssetTypes
	 * @description :get Guest AssetType
	 * @return Response Success message
	 * @throws RepoproException
	 */
	@GET
	public Response retrieveGuestAssetTypes(){
		
		if (log.isTraceEnabled()) {
			log.trace("retrieveGuestAssetTypes || Begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<AssetDef> assetDefListForGuest = new ArrayList<AssetDef>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retrieveGuestAssetTypes || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("retrieveGuestAssetTypes || dao call of getAssetTypeListForGuest() method ");
			}
			assetDefListForGuest = guestDao.getAssetTypeListForGuest(conn);

			if (log.isInfoEnabled()) {
				log.info("retrieveGuestAssetTypes || retrieve "
						+ assetDefListForGuest.size()+ " rows of Assetdata for guestaccess");
			}
			
			if(assetDefListForGuest.isEmpty()){
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retMsg = Constants.ALL_ASSET_DATA_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("SQL Exception retrieveGuestAssetTypes|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}catch (Exception e) {
			log.error("SQL Exception retrieveGuestAssetTypes|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retrieveGuestAssetTypes|| "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retrieveGuestAssetTypes || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetDefListForGuest))).build();
	}

	/**
	 * @method : saveGuestAssetType
	 * @description :save Guest Access for AssetType
	 * @param assetDef
	 * @return Response Success message
	 */
	@PUT
	@Path("/saveGuestAccess")
	public Response saveGuestAssetType(AssetDef assetDef) {
		if (log.isTraceEnabled()) {
			log.trace("saveGuestAssetType || Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("saveGuestAssetType ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (!assetDef.equals(null)) {

				assetDef.setQuicksearchflag(assetDef.isGuestflag());
				if (log.isTraceEnabled()) {
					log.trace("saveGuestAssetType || dao call of updateGuestAssetType() method to set Asset access rights for guest user");
				}
				guestDao.updateGuestAssetType(assetDef, conn);
			}
			if (log.isInfoEnabled()) {
				log.info("saveGuestAssetType || save Asset access rights for guest user ");
			}
			conn.commit();

			retMsg = Constants.GUEST_ACCESS_SAVED_SUCCESSFULLY;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
		} catch (RepoproException e) {
			log.error("SQL Exception saveGuestAssetType ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}catch (Exception e) {
			log.error("SQL Exception saveGuestAssetType ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("saveGuestAssetType||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("saveGuestAssetType || End");
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

	}

}
