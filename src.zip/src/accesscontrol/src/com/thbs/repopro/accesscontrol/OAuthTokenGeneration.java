package com.thbs.repopro.accesscontrol;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import java.security.cert.CertificateException;
import java.sql.Connection;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Properties;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

import javax.annotation.Generated;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import javax.security.cert.X509Certificate;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Node;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.json.JSONObject;
import org.opensaml.Configuration;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.io.Unmarshaller;
import org.opensaml.xml.io.UnmarshallerFactory;
import org.opensaml.xml.io.UnmarshallingException;

import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.thbs.repopro.dto.User;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.InitApp;
import com.thbs.repopro.util.MyModelRest;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/auth")
public class OAuthTokenGeneration {
	private final static Logger log = LoggerFactory.getLogger("timeBased");
	@GET
	@Path("/exchangeSamlAssertionForToken")
	public Response retrieveOAuthAccessToken(@QueryParam("samlAssertion") String encodedsamlAssertion) 
	
	{
		//System.out.println("STARTED ");
		if(log.isTraceEnabled()){
			log.trace("Started the method to exchange token for SAML Assertion");
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		byte[] output2 = null;
		String outputString = null;
	    Base64.Decoder decoder = Base64.getUrlDecoder();
		byte[] decoded = decoder.decode(encodedsamlAssertion);
		if(log.isDebugEnabled()){
			log.info("SAML Assertion Decoded ");//System.out.println("Decoded: " + new String(decoded));
		}
	    String samlXML = new String(decoded);
			
	    	String xpath = CommonUtils.xpath;
	    	String nameID = getUserID(samlXML,xpath);
	    		  		
	  		//System.out.println(nameID);
	  		UserDao userDao = new UserDao();
	  		User user = null;
	  		try{
	  		conn = DBConnection.getInstance().getConnection();
	  		if(log.isTraceEnabled()){
	  			log.trace("Connected to DB");
	  		}
			conn.setAutoCommit(false);
	  		user = userDao.retProfiledetailsForUserName(nameID,conn);
	  		 if(user == null)
	  		 {
	  			retStat = Status.NOT_FOUND;
				retMsg = Constants.USER_NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS; 
				if(log.isDebugEnabled()){
					log.debug("User not found for "+nameID);
				}
	  		 }
	  		 else
	  		 {
	  			if(log.isDebugEnabled()){
	  			log.debug("User found for Namr ID : "+nameID);	
	  			}
	  			System.setProperty("javax.net.ssl.trustStore",CommonUtils.trustStorePath);
	  			System.setProperty("javax.net.ssl.trustStorePassword", CommonUtils.trustStorePassword);
	  			Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());

	  			// TrustStore..
	  			//System.out.println("ADDING KEYSTORE ");
	  			char[] passphrase = CommonUtils.trustStorePassword.toCharArray(); // password
	  			KeyStore keystore = null;
	  			try {
	  				keystore = KeyStore.getInstance("JKS");
	  			} catch (KeyStoreException e4) {
	  				// TODO Auto-generated catch block
	  				e4.printStackTrace();
	  			}
	  			// KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
	  			try {
	  				keystore.load(new FileInputStream(CommonUtils.trustStorePath),passphrase);
	  				if(log.isDebugEnabled()){
	  					log.debug("Successfully Fetched the trustStore path and password");
	  				}
	  			} catch (NoSuchAlgorithmException e3) {
	  				// TODO Auto-generated catch block
	  				e3.printStackTrace();
	  			} catch (CertificateException e3) {
	  				// TODO Auto-generated catch block
	  				e3.printStackTrace();
	  			} catch (FileNotFoundException e3) {
	  				// TODO Auto-generated catch block
	  				e3.printStackTrace();
	  			} catch (IOException e3) {
	  				// TODO Auto-generated catch block
	  				e3.printStackTrace();
	  			} // path

	  			// TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
	  			// //instance
	  			TrustManagerFactory tmf = null;
	  			try {
	  				tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
	  			} catch (NoSuchAlgorithmException e2) 
	  			{
	  				// TODO Auto-generated catch block
	  				e2.printStackTrace();
	  			}
	  			try {
	  				tmf.init(keystore);
	  			} catch (KeyStoreException e2) {
	  				// TODO Auto-generated catch block
	  				e2.printStackTrace();
	  			}
	  			// HostnameVerifier hostnameVerifier =
	  			// HttpsURLConnection.getDefaultHostnameVerifier();

	  			HostnameVerifier hostnameVerifier = new HostnameVerifier() {
	  				@Override
	  				public boolean verify(String urlHostName, SSLSession session) {
	  					return true;
	  				}
	  			};
	  			// Install the all-trusting host verifier
	  			HttpsURLConnection.setDefaultHostnameVerifier(hostnameVerifier);

	  			
	  			SSLContext ctx = null;
	  			try {
	  				ctx = SSLContext.getInstance("SSL");
	  			} catch (NoSuchAlgorithmException e1) {
	  				// TODO Auto-generated catch block
	  				e1.printStackTrace();
	  			}
	  			// TrustManager[] trustManagers = tmf.getTrustManagers();
	  			// TrustManager[] myTrustManager = { new InsecureTrustManager() };
	  			
	  			//System.out.println("TRUSTING CERTIFICATES");
	  			TrustManager[] trustManagers = new TrustManager[] { new X509TrustManager() {
	  				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	  					return null;
	  				}

	  				public void checkServerTrusted(X509Certificate[] certs,
	  						String authType) {
	  				}

	  				@Override
	  				public void checkClientTrusted(
	  						java.security.cert.X509Certificate[] arg0, String arg1)
	  						throws CertificateException {
	  					// TODO Auto-generated method stub

	  				}

	  				@Override
	  				public void checkServerTrusted(
	  						java.security.cert.X509Certificate[] arg0, String arg1)
	  						throws CertificateException {
	  					// TODO Auto-generated method stub

	  				}
	  			} };

	  			try {
	  				ctx.init(null, trustManagers, null);
	  			} catch (KeyManagementException e1) {
	  				// TODO Auto-generated catch block
	  				e1.printStackTrace();
	  			}
	  			
	  			
	  			Client client = ClientBuilder.newBuilder()
	  			        .sslContext(ctx)
	  			        .hostnameVerifier(hostnameVerifier)
	  			        .build();
	  			//System.out.println("CALLING IDP WITH PARAMS : "+CommonUtils.grantType+" "+encodedsamlAssertion+" "+CommonUtils.clientId+" "+CommonUtils.clientSecret);
	  			if(log.isTraceEnabled()){
	  				log.trace("Connecting to IdP with the credentials and assertion");
	  			}
	  			WebTarget target = client.target(CommonUtils.oAuthEndPoint);
	  			Response response2 = target.queryParam("grant_type", CommonUtils.grantType).queryParam("assertion",encodedsamlAssertion).request().header("client_id",CommonUtils.clientId).header("client_secret", CommonUtils.clientSecret).post(Entity.json(""));
	  			//System.out.println("RESPONSE : "+response2.getStatus());
	  			//System.out.println(response2.getStatus());
	  			String output = response2.readEntity(String.class).toString();
	  			//System.out.println(output);
	  			JSONObject jsonObject = new JSONObject(output);
	  			String access_token = jsonObject.getString("access_token");
	  			String expires_in = jsonObject.getString("expires_in");
	  			LocalDateTime dateTime = LocalDateTime.now().plusSeconds(Long.valueOf(expires_in).longValue());
	  			if(log.isDebugEnabled()){
	  				log.debug("Token successfully obtained, expires in "+expires_in);
	  			}
	  			//System.out.println("JSON OBJECT : "+access_token+" "+expires_in);
	            userDao.insertOAuthTokenDetails(access_token, user.getUserId(),Timestamp.valueOf(dateTime),Long.valueOf(expires_in).longValue(), null);
	            retStat = Status.FOUND;
				retMsg = output;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS; 

	  		 }
	  		}
	  		
			catch (Exception e) {
				log.error("retrieveAccessTokenForSamlExchange :" + Constants.LOG_EXCEPTION
						+ e.getMessage());
				retStat = Status.BAD_REQUEST;
				retMsg = Constants.INVALID_REQUEST;
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.STATUS_FAILURE; 
				try {
					conn.rollback();
				    }
				catch(Exception e1){
					log.error("retrieveAccessTokenForSamlExchange :" + Constants.LOG_EXCEPTION
							+ e1.getMessage());
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retMsg = e1.getMessage();
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
				}
				    if(log.isInfoEnabled()){
				    	log.info("Unable to fetch the access token for the user id : "+nameID);
				    }
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			finally {//both trace
				if (log.isTraceEnabled()) {
					log.trace("retrieveAccessTokenForSamlExchange : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);			
			}
			if (log.isTraceEnabled()) {
				log.trace("retrieveAccessTokenForSamlExchange :" + user.toString() + "Exit");
			}

			if(log.isInfoEnabled()){
	    	log.info("Successfully fetched the access token for the user id : "+nameID);
			}
		return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
	}
	
	public static String getUserID(String xmlBody, String xpathString) {
		if(log.isTraceEnabled()){
			log.trace("Fteching the Name id from SAML assertion using xpath");
		}
		
		Document doc = null;			
		String finalPayload = "";
		String[] xpathStringArray = null;
		String xPathSplitVal = "";
		String xmlStr = "";
		StringBuffer result = new StringBuffer();		
		BufferedReader reader = new BufferedReader(new StringReader(xmlBody));
		String line;
		try {
			while ( (line = reader.readLine() ) != null){
				result.append(line.trim());
				xmlStr = result.toString();
			}
		} catch (IOException e1) {}

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		XPathFactory xpathfactory = XPathFactory.newInstance();
		XPath xpath = xpathfactory.newXPath();
		NodeList nodes = null;
		DocumentBuilder db = null;
		String nodeVal = "";
		/*String nodeName = "";*/
		
		try {
			db = dbf.newDocumentBuilder();
			doc = db.parse(new InputSource(new StringReader(xmlStr)));
		}catch (Exception w) {
		}
		if(xpathString.length()>0){
			xpathStringArray = xpathString.split(",");
		}
		UniversalNamespaceResolver ctx = new UniversalNamespaceResolver();
		String home = System.getProperty("user.home");
		FileInputStream fin = null;
		try {
			
			fin = new FileInputStream(home + "/RepoPro.properties");
		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		for (int xp = 0; xp < xpathStringArray.length; xp++) {
			xPathSplitVal = xpathStringArray[xp];
					try {
						ctx.load(fin);
					} catch (IOException e1) {
					}finally{
						if(null != fin)
							try {
								fin.close();
							} catch (IOException e) {
							}
					}
					
					xpath.setNamespaceContext(ctx);
					XPathExpression expr = null;
					try{
						try{
							expr = xpath.compile(xPathSplitVal);
						}catch(Exception wq){
						}
						if(null != expr){
							nodes = (NodeList) expr.evaluate(doc, XPathConstants.NODESET);
						}
					}catch(Exception e){
						//e.printStackTrace();
					}
				if(nodes.getLength() > 0){
					for (int i = 0; i < nodes.getLength(); i++) {
						try {
							if(nodes.item(i).getNodeType() == Node.COMMENT_NODE) {
								continue;
							}else{ 
								/*if ((nodes.item(i).getNodeType()) == Node.ELEMENT_NODE) {
									visitRecursively(nodes.item(i)); 
								}else{*/
									for (int ijk = 0; ijk < nodes.getLength(); ijk++) {
											nodeVal = nodes.item(ijk).getTextContent();
									}
								//}
							}
						} catch (Exception e) {
						}
					}
				}
		}
		if(log.isInfoEnabled()){
			log.info("Successfully fetched the Name ID from the SAML assertion");
		}
		return nodeVal;
	}
}
