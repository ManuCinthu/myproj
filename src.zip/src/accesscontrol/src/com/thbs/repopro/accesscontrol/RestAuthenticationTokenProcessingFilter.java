package com.thbs.repopro.accesscontrol;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.GenericFilterBean;

import com.jayway.jsonpath.JsonPath;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.PluginUtlities;

public class RestAuthenticationTokenProcessingFilter extends GenericFilterBean {
	
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	AuthenticationManager authManager;

	public RestAuthenticationTokenProcessingFilter(AuthenticationManager authManager) {
		this.authManager = authManager;

	}

	private static final String REDIS_KEY_PREFIX = "spring:session:sessions:";

	@Autowired
	private RedisOperations<String, Object> redisOps;

	// @Autowired
	// private SessionRepository sessionRepo;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
       
		String bearer = "Bearer ";

		Connection conn = null;
		
		boolean is_oAuth = false;
		GlobalSettingDao globalsettingDao = new GlobalSettingDao();
		List<GlobalSetting> globalSetting = null;
		try {
			globalSetting = globalsettingDao.getGlobalSetting(conn);
		} catch (RepoproException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		for(GlobalSetting g : globalSetting){
			if(g.getMechanism().equalsIgnoreCase("oAuth")){
				is_oAuth = true;
				break;
			}
		}
		// oAuth Mode
		if(is_oAuth)
		{
			String authHeader = "";
			
			if (((HttpServletRequest) request).getHeader("Authorization") != null) 
			{
				authHeader = ((HttpServletRequest) request).getHeader("Authorization").trim();
				
				if ((authHeader.toLowerCase().startsWith(bearer.toLowerCase()))) 
				{
				String authHeaderValue = authHeader.substring(bearer.length()).trim();
				int commaIndex = authHeaderValue.indexOf(' ');
				if (commaIndex > 0) {
					authHeaderValue = authHeaderValue.substring(0, commaIndex);
				}
				//plug-in call
				
				Class validateOauth = PluginUtlities.getplugin();

				Method method = null;
				try {
					method = validateOauth.getMethod("validateAccessToken", String.class);
				} catch (NoSuchMethodException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SecurityException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Object instanance = null;
				try {
					instanance = validateOauth.newInstance();
				} catch (InstantiationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					UserDao userDao = new UserDao();
					//CommonUtils commonutils = new CommonUtils();
					Object outputString = method.invoke(instanance , authHeaderValue);
					JsonPath response_statusPath = null;
					JsonPath tokenuser_Path = null;
					JsonPath failureResponse_Path = null;
					String response_statusValue = null;
					String tokenuser_PathValue = null;
					String failureResponse_PathValue = null;
					System.out.println("outputString : "+outputString.toString());
					JSONObject jsonObject = null;
					try {
						jsonObject = new JSONObject(outputString.toString());
					} catch (JSONException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					System.out.println("jsonObject : "+jsonObject.toString());
					boolean flag = false;
					try{
						response_statusPath = JsonPath.compile("$.response_status"); 
		  				String response_status = response_statusPath.read(jsonObject.toString()).toString();
		  				System.out.println("response_status : : > > "+response_status);
		  				/*response_statusValue = response_status.replaceAll("[^A-Za-z0-9]","");
		  				System.out.println("response_statusValue : + "+response_statusValue);*/
		  				if(response_status.equalsIgnoreCase("success"))
		  				{
		  					System.out.println("SUCCESS");
		  					tokenuser_Path = JsonPath.compile("$.token_user"); 
			  				String token_userVal = tokenuser_Path.read(jsonObject.toString()).toString();
			  				tokenuser_PathValue = token_userVal.replaceAll("[^A-Za-z0-9]","");
			  				if(tokenuser_PathValue.equalsIgnoreCase(""))
			  				{
			  				flag = false;
			  				}
			  				else
			  				{
			  					flag = true;
			  				}
		  				}
		  				else if(response_status.equalsIgnoreCase("failure"))
		  				{
		  					flag = false;
		  					failureResponse_Path = JsonPath.compile("$.failure_response");
		  					String failureResponse_Val = failureResponse_Path.read(jsonObject.toString()).toString();
		  					failureResponse_PathValue = failureResponse_Val.replaceAll("[^A-Za-z0-9]","");
		  					if(log.isWarnEnabled())
		  					{
		  						log.warn("failure_response  : "+failureResponse_PathValue);
		  					}
		  				}
		  				}
					catch (Exception e)
					{
		  				e.printStackTrace();
		  					
		  			}
					if(flag)
					{
					//System.out.println(userName);
					User userDetails = null;
					//User user = null;
					
					try {
						//userDetails = commonutils.userDetails(authHeaderValue);
						userDetails = userDao.getUserIdByUserName(tokenuser_PathValue.toString(), conn);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {
						userDetails = userDao.getUserByUserId(userDetails.getUserId(), null);
					} catch (RepoproException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
							userDetails.getUserName().toString().trim(),
							CommonUtils.decrypt(userDetails.getPassword()));
					authentication
					.setDetails(new WebAuthenticationDetailsSource()
					.buildDetails((HttpServletRequest) request));

					// set the authentication into the SecurityContext

					SecurityContextHolder.getContext().setAuthentication(
							authManager.authenticate(authentication));
				}
				}catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					chain.doFilter(request, response);
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					chain.doFilter(request, response);
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					chain.doFilter(request, response);
				}
				}
				
				
				}
			else
			{
				GlobalSettingDao globalSettingDao = new GlobalSettingDao();
				List<GlobalSetting> globalSetting1 = new ArrayList<GlobalSetting>();
				int guestAccess = 0;
				try {
					globalSetting1 = globalSettingDao.getGlobalSetting(null);
				} catch (RepoproException e) {
					e.printStackTrace();
				}
				
				for(GlobalSetting gs : globalSetting1) {
					guestAccess = gs.getGuestAccess();
				}
				
				if(guestAccess == 1) {

					UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
							"ROLE_ANONYMOUS", "");
					authentication
					.setDetails(new WebAuthenticationDetailsSource()
							.buildDetails((HttpServletRequest) request));

					// set the authentication into the SecurityContext

					SecurityContextHolder.getContext().setAuthentication(
							authManager.authenticate(authentication));
				}
			}
				
			} 
		
		else
		{
			// Native Mode
			
			try {

				String token = null;
				if (((HttpServletRequest) request).getParameter("tokenName") != null) {
					token = ((HttpServletRequest) request)
							.getParameter("tokenName").trim();
				} else if (((HttpServletRequest) request).getHeader("token") != null) {

					token = ((HttpServletRequest) request).getHeader("token").trim();

				}
				// validate the token
				Set<String> keys = redisOps.keys("spring:session:sessions"
						+ "*");
				
				 User user = null;
				UserDao userDao = new UserDao();
				CommonUtils commonutils = new CommonUtils();
				if(token != null)
				{
					user = commonutils.userDetails(token);
    			    
				}
    			
				for (String key : keys) {
					String id = key.substring(REDIS_KEY_PREFIX.length());

					
					if(token != null){
						if (token.equals(id)) {
							User userDetails = null;
							

							try {
					
								userDetails = userDao.getUserByUserId(user.getUserId(), null);


							} catch (RepoproException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
									userDetails.getUserName().toString().trim(),
									CommonUtils.decrypt(userDetails.getPassword()));
							authentication
							.setDetails(new WebAuthenticationDetailsSource()
							.buildDetails((HttpServletRequest) request));

							// set the authentication into the SecurityContext

							SecurityContextHolder.getContext().setAuthentication(
									authManager.authenticate(authentication));
							break;

						}
					}
				}

				if (token == null) {

					GlobalSettingDao globalSettingDao = new GlobalSettingDao();
					List<GlobalSetting> globalSetting1 = new ArrayList<GlobalSetting>();
					int guestAccess = 0;
					try {
						globalSetting1 = globalSettingDao.getGlobalSetting(null);
					} catch (RepoproException e) {
						e.printStackTrace();
					}
					
					for(GlobalSetting gs : globalSetting1) {
						guestAccess = gs.getGuestAccess();
					}
					
					if(guestAccess == 1) {
						UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
								"ROLE_ANONYMOUS", "");
						authentication
						.setDetails(new WebAuthenticationDetailsSource()
						.buildDetails((HttpServletRequest) request));

						// set the authentication into the SecurityContext

						SecurityContextHolder.getContext().setAuthentication(
								authManager.authenticate(authentication));
					}
				}
				//chain.doFilter(request, response);
			} catch (Exception e) {
				// e.printStackTrace();
				chain.doFilter(request, response);
			}
			
		}
		chain.doFilter(request, response);
	}
	

	}

