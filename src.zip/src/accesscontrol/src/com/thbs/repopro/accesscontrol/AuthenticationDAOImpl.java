package com.thbs.repopro.accesscontrol;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.security.Key;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;
import org.opensaml.common.SAMLException;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.ws.message.encoder.MessageEncodingException;
import org.opensaml.xml.XMLObject;
import org.opensaml.xml.encryption.DecryptionException;
import org.opensaml.xml.security.SecurityException;
import org.opensaml.xml.util.XMLHelper;
import org.opensaml.xml.validation.ValidationException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.security.saml.context.SAMLMessageContext;
import org.springframework.security.saml.util.SAMLUtil;
import org.springframework.security.saml.websso.WebSSOProfileConsumerImpl;
import org.springframework.stereotype.Component;

import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.ldap.LDAPAuthentication;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;



@Component
public class AuthenticationDAOImpl implements AuthenticationProvider {
	static Logger log = Logger.getLogger(AuthenticationDAOImpl.class.getName());
    int count = 0; 
	@SuppressWarnings("deprecation")
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		Connection conn = null;
		Authentication resultAuthentication = null;
		List<SimpleGrantedAuthority> authorities = new ArrayList<SimpleGrantedAuthority>();
		GlobalSettingDao globalsettingDao = new GlobalSettingDao();
		GlobalSetting globalsetting = null;
		String firstName = "";
		String lastName = "";
		String email = "";
		try {
			 globalsetting = globalsettingDao.retGlobalSettingByName("SAML", null);
		} catch (RepoproException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		//boolean ssoMode = false;
		
		Long sso = globalsetting.getGlobalSettingFlag();
		if((authentication.getCredentials() instanceof SAMLMessageContext || authentication.getCredentials().toString().equals("")) && sso == 1L){
        	String username = "";
			if(!authentication.getCredentials().toString().equals("") )
			{
			WebSSOProfileConsumerImpl web = new WebSSOProfileConsumerImpl();
			if(!CommonUtils.responseSkew.equalsIgnoreCase("") && CommonUtils.responseSkew != null) {
				web.setResponseSkew(Integer.parseInt(CommonUtils.responseSkew)); //Response Skew add for public IDP
			}
			SAMLMessageContext saml = null;
			SAMLCredential credential = null;
			saml = (SAMLMessageContext)authentication.getCredentials();
			
			try {
				credential = web.processAuthenticationResponse(saml);
			} catch (SAMLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			} catch (SecurityException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			} catch (ValidationException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			} catch (DecryptionException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			String samlAssertionresponse= "";
	        try {
				 samlAssertionresponse = XMLHelper.nodeToString(SAMLUtil.marshallMessage(credential.getAuthenticationAssertion()));
			} catch (MessageEncodingException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
	        
	        
	        
	        /*Changes for SAML webversion to get user details from SAML assertion begin*/
	        if(log.isDebugEnabled()){
	        	log.debug("Fetching the user details from SAML Assertion.");
	        }
	        
	        if(CommonUtils.samlAssertionFirstName.isEmpty() || (CommonUtils.samlAssertionFirstName == "")){
	        	if(log.isDebugEnabled()){
    	        	log.debug("Setting default First Name: "+firstName);
    	        }
	        	firstName = CommonUtils.defaultFirstNameForSAML;
	        }else{
	        Attribute firstNameAttribute =  credential.getAttribute(CommonUtils.samlAssertionFirstName);
	        if(firstNameAttribute != null){
            List<XMLObject> firstNamexmlObj = firstNameAttribute.getAttributeValues();
            firstName = firstNamexmlObj.get(0).getDOM().getTextContent();
	        }
	        else{
	        	firstName = CommonUtils.defaultFirstNameForSAML;
	        	if(log.isDebugEnabled()){
    	        	log.debug("Setting default First Name: "+firstName);
    	        }
	        }
	        }
	        if(log.isDebugEnabled()){
	        	log.debug("Captured the first name of the user : "+firstName);
	        }
	        if(CommonUtils.samlAssertionLastName.isEmpty() || (CommonUtils.samlAssertionLastName.equals(""))){
	        	if(log.isDebugEnabled()){
    	        	log.debug("Setting default Last Name: "+lastName);
    	        }
	        	lastName = CommonUtils.defaultLastNameForSAML;
	        }else{
	        Attribute lastNameAttribute =  credential.getAttribute(CommonUtils.samlAssertionLastName);
            if(lastNameAttribute != null){
	        List<XMLObject> lastNamexmlObj = lastNameAttribute.getAttributeValues();
            lastName = lastNamexmlObj.get(0).getDOM().getTextContent();
            } else{
            	if(log.isDebugEnabled()){
    	        	log.debug("Setting default Last Name: "+lastName);
    	        }
            	lastName = CommonUtils.defaultLastNameForSAML;
	            }
	        }
	        
	        if(log.isDebugEnabled()){
	        	log.debug("Captured the last name of the user : "+lastName);
	        }
		        
	        if(CommonUtils.samlAssertionMailID.isEmpty() || (CommonUtils.samlAssertionMailID == "")){
	        	if(log.isDebugEnabled()){
    	        	log.debug("Setting default mail id: "+email);
    	        }
	        	email = CommonUtils.defaultMailForSAML;
	        	}else{
            Attribute mailIdAttribute =  credential.getAttribute(CommonUtils.samlAssertionMailID);
            if(mailIdAttribute != null){
            List<XMLObject> mailIdxmlObj = mailIdAttribute.getAttributeValues();
            email = mailIdxmlObj.get(0).getDOM().getTextContent();
            }else{
            	if(log.isDebugEnabled()){
    	        	log.debug("Setting default mail id: "+email);
    	        }
            	email = CommonUtils.defaultMailForSAML;
            }
	        }
	        
	                
	        if(log.isDebugEnabled()){
	        	log.debug("Captured the email of the user : "+email);
	        }
	        
		        /*Changes for SAML webversion to get user details from SAML assertion end*/
	        			    username = (String)credential.getNameID().getValue().trim();
			   // ssoCount++;
			}
			else
			{ 
				username = (String)authentication.getPrincipal().toString().trim();
			}
		
			if(username.equalsIgnoreCase("ROLE_ANONYMOUS")){
				
				authorities.add(new SimpleGrantedAuthority("ROLE_ANONYMOUS"));
			
			int i = 1;
			List<String> functionList = null;
			UserDao userDao = new UserDao();
			try {
				functionList = userDao.retFunctionsForUserName(username,conn);
			} catch (RepoproException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			for(String function : functionList ){
				//authorities[i] = new SimpleGrantedAuthority(function);
				authorities.add(new SimpleGrantedAuthority(function));
				i++;
			}
			
		}
			else{
				
				try {


					
					if (log.isTraceEnabled()) {
						log.trace("authenticate || " + Constants.LOG_CONNECTION_OPEN);
					}
					try {
						conn = DBConnection.getInstance().getConnection();
					} catch (RepoproException | IOException | SQLException
							| PropertyVetoException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				
					UserDao userDao = new UserDao();
					
					//User user = userDao.retProfileForUserName(username,conn);
					   
			
						//Repo Pro Authentication		
						try
						{
							boolean flag = false;
							List<String> userNameFromDB =  userDao.retAllUsers(conn);
							for(int i=0;i<userNameFromDB.size();i++)
							{
								if(username.equalsIgnoreCase(userNameFromDB.get(i)))
								{
									flag = true;
									break;
								}
							}
							if(flag == true)
							{
								List<String> functionList = null;
								try {
									functionList = userDao.retFunctionsForUserName(username,conn);
								} catch (RepoproException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								//GrantedAuthority[] authorities = new GrantedAuthority[functionList.size()+1];
								if(username.equalsIgnoreCase("admin")){
									authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
								}else{
									authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
								}
								int i = 1;
								for(String function : functionList ){
									//authorities[i] = new SimpleGrantedAuthority(function);
									authorities.add(new SimpleGrantedAuthority(function));
									i++;
								}
							}
							else
							{ 
								// 	
								User userList = new User();
								userList.setUserName(username);
								userList.setPassword("");
								userList.setFullName(firstName+" "+lastName);
								userList.setEmailId(email);
								userList.setDepartment(CommonUtils.defaultDeptForSAML);
								userList.setImageName(null);
								userList.setSectionPosition("Tags~~0,Taxonomies~~1,Overview~~2,Properties~~3,Relationships & Reverse Relationships~~4,Revision History~~5,Discussion~~6,Versions~~7,Asset Visualization~~8");
								userList.setSectionVisibility("Tags~~checked,Taxonomies~~checked,Overview~~checked,Properties~~checked,Relationships & Reverse Relationships~~checked,Revision History~~checked,Discussion~~checked,Versions~~checked,Asset Visualization~~checked");
								Long userId = userDao.addUser(userList, conn);
								userDao.addUsertoDefaultgroup(userId,conn);
								
								List<String> functionList = null;
								try {
									functionList = userDao.retFunctionsForUserName(username,null);
								} catch (RepoproException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								//GrantedAuthority[] authorities = new GrantedAuthority[functionList.size()+1];
								if(username.equalsIgnoreCase("admin")){
									authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
								}else{
									authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
								}
								int i = 1;
								for(String function : functionList ){
									//authorities[i] = new SimpleGrantedAuthority(function);
									authorities.add(new SimpleGrantedAuthority(function));
									i++;
								}
							}			
						}
						catch(RepoproException re)
						{
							re.printStackTrace();
							throw new AuthenticationServiceException("");
						}
						
			}
				

			 catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				if (log.isDebugEnabled()) {
					log.debug("AuthenticationDAOImpl ||"
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			
			 resultAuthentication = new UsernamePasswordAuthenticationToken(username,authentication.getCredentials(),authorities);	
			
		}
			 resultAuthentication = new UsernamePasswordAuthenticationToken(username,authentication.getCredentials(),authorities);
		}
		else
		{

	        
			User userProfile = null;
			
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			User userProfileByUserName = null;
			String username = authentication.getPrincipal().toString().trim();
			String password = (String)authentication.getCredentials();	
			
			try {
			if(username.equalsIgnoreCase("ROLE_ANONYMOUS")){
				
					authorities.add(new SimpleGrantedAuthority("ROLE_ANONYMOUS"));
				
				int i = 1;
				List<String> functionList = null;
				UserDao userDao = new UserDao();
				try {
					functionList = userDao.retFunctionsForUserName(username,conn);
				} catch (RepoproException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				for(String function : functionList ){
					//authorities[i] = new SimpleGrantedAuthority(function);
					authorities.add(new SimpleGrantedAuthority(function));
					i++;
				}
				
			}
			else{
				String encryptedPassword = password;
				/*
				 * Encrypting the password
				 */
				try{
					final String ALGO = "AES";
					final byte[] keyValue = 
							new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };
					Key key = new SecretKeySpec(keyValue, ALGO);;
				    Cipher c = Cipher.getInstance(ALGO);
				    c.init(Cipher.ENCRYPT_MODE, key);
				    byte[] encVal = c.doFinal(password.getBytes());
				    encryptedPassword =  Base64.getEncoder().encodeToString(encVal);

				}catch(Exception e){
					e.printStackTrace();
				}
				
				
				if (log.isTraceEnabled()) {
					log.trace("authenticate || " + Constants.LOG_CONNECTION_OPEN);
				}
				try {
					conn = DBConnection.getInstance().getConnection();
				} catch (RepoproException | IOException | SQLException
						| PropertyVetoException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				String decryptedPassword = null;
				UserDao userDao = new UserDao();
				
				 
				
				try{
					final String ALGO = "AES";
					final byte[] keyValue = 
							new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };
					Key key = new SecretKeySpec(keyValue, ALGO);;
				    Cipher c = Cipher.getInstance(ALGO);
				    c.init(Cipher.DECRYPT_MODE, key);
				    User user = userDao.retProfileForUserName(username,conn);
				    if(!user.getPassword().equals(""))
				    {
				    byte[] decodedValue = DatatypeConverter.parseBase64Binary(user.getPassword());
				    byte[] decVal = c.doFinal(decodedValue);
				    decryptedPassword = new String(decVal);
				    }
				    else
				    {
				    	decryptedPassword = "";
				    }
				    
				}catch(Exception e){
					e.printStackTrace();
				}
				
				
				
				GlobalSetting globalSetting = null;
				try {
					globalSetting = globalSettingDao.retGlobalSettingByName("Ldap" , conn);
				} catch (RepoproException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(globalSetting.getGlobalLdapSettingFlag() == 0 && !password.equalsIgnoreCase("")){
					//Repo Pro Authentication		
					try
					{
						boolean flag = false;
						List<String> userNameFromDB =  userDao.retAllUsers(conn);
						for(int i=0;i<userNameFromDB.size();i++)
						{
							if(username.equalsIgnoreCase(userNameFromDB.get(i)))
							{
								flag = true;
								break;
							}
						}
						if(flag == true){
					       userProfile = userDao.retProfileForUserNameAndPwd(username, encryptedPassword ,conn);
						}else{
							throw new BadCredentialsException("Invalid username/password");		
						}			
					}
					catch(RepoproException re)
					{
						re.printStackTrace();
						throw new AuthenticationServiceException("");
					}
					
					if(userProfile==null)
					{		
						throw new BadCredentialsException("Invalid username/password");	
					}
				}else{
					//Ldap Authentication
					
					try
					{
						boolean flagByUserName = false;
						List<String> userNameFromDB =  userDao.retAllUsers(conn);
						for(int i=0;i<userNameFromDB.size();i++)
						{
							if(username.equalsIgnoreCase(userNameFromDB.get(i)))
							{
								flagByUserName = true;
								break;
							}
						}
						if(flagByUserName == true){
							userProfileByUserName = userDao.retProfileForUserName(username,conn);
						}else{
							throw new BadCredentialsException("Invalid username/password");		
						}
					}
					catch(RepoproException re)
					{
						re.printStackTrace();
						throw new AuthenticationServiceException("");
					}
					
					if(userProfileByUserName==null)
					{		
						throw new BadCredentialsException("Invalid username/password");	
					}else{
						boolean isAuthenticationSuccessful = false;
						boolean flag = false;
						List<String> userNameFromDB = null;
						try {
							userNameFromDB = userDao.retAllUsers(conn);
						} catch (RepoproException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						for(int i=0;i<userNameFromDB.size();i++)
						{
							if(username.equalsIgnoreCase(userNameFromDB.get(i)))
							{
								flag = true;
								break;
							}
						}
						if(flag == true){
					       try {
							userProfile = userDao.retProfileForUserNameAndPwd(username, encryptedPassword ,conn);
						} catch (RepoproException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						}else{
							throw new BadCredentialsException("Invalid username/password");		
						}	
						
						if(userProfile == null){
							isAuthenticationSuccessful = false;
							if(!decryptedPassword.equals(""))
							{
							 throw new BadCredentialsException("Invalid username/password");
							}
						}else{
							isAuthenticationSuccessful = true;
						}

						if(!isAuthenticationSuccessful && !userProfileByUserName.getActiveFlag().equals("0") && !password.equalsIgnoreCase("")){
							LDAPAuthentication ldapAuthentication = new LDAPAuthentication();
							if ((count == 0) || (count >0 && !password.equalsIgnoreCase(""))){ 
							if (!ldapAuthentication.authenticateUser(username,password)) {
								throw new BadCredentialsException("Invalid username/password");	
							}
							}count++;
						}else if(!isAuthenticationSuccessful && userProfileByUserName.getActiveFlag().equals("0") ){
							throw new BadCredentialsException("Invalid username/password");
						}
				}	
				}

				List<String> functionList = null;
				try {
					functionList = userDao.retFunctionsForUserName(username,conn);
				} catch (RepoproException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//GrantedAuthority[] authorities = new GrantedAuthority[functionList.size()+1];
				if(username.equalsIgnoreCase("admin")){
					authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
				}else{
					authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
				}
				int i = 1;
				for(String function : functionList ){
					//authorities[i] = new SimpleGrantedAuthority(function);
					authorities.add(new SimpleGrantedAuthority(function));
					i++;
				}
				
				
				
				try {
					userProfile = userDao.retProfileForUserName(username, conn);
				} catch (RepoproException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				if (log.isDebugEnabled()) {
					log.debug("AuthenticationDAOImpl ||"
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			 resultAuthentication = new UsernamePasswordAuthenticationToken(authentication.getPrincipal(),authentication.getCredentials(),authorities);	
			if (log.isDebugEnabled()) {
				if(resultAuthentication == null){
					log.debug("authenticate : Resultset is null");
					}else{
				log.debug("authenticate :"+resultAuthentication.toString()+" Exit ");
			}}
			return resultAuthentication;
		}
		return resultAuthentication;
		
	}

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return true;
	}
	
}
