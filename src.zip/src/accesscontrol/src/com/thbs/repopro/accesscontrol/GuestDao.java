package com.thbs.repopro.accesscontrol;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class GuestDao {
	private static final Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method getAssetTypeListForGuest
	 * @description get Guest Access Asset Type
	 * @param conn
	 * @return List<AssetDef>
	 * @throws RepoproException
	 */
	public List<AssetDef> getAssetTypeListForGuest(Connection conn)
			throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getAssetTypeListForGuest || Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<AssetDef> assetDefList = new ArrayList<AssetDef>();
		AssetDef assetdef = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAssetTypeListForGuest ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_ALL_ASSET_TYPES_FOR_GUEST));
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("getAssetTypeListForGuest ||"
						+ PropertyFileReader.getInstance().getValue(Constants.RET_ALL_ASSET_TYPES_FOR_GUEST));
			}
			while (rs.next()) {
				assetdef = new AssetDef();
				assetdef.setAssetId(rs.getLong("asset_id"));
				assetdef.setAssetName(rs.getString("asset_name"));
				assetdef.setDescription(rs.getString("description"));
				assetdef.setGuestflag(rs.getBoolean("guest_flag"));
				assetdef.setQuicksearchflag(rs.getBoolean("quick_search_flag"));
				assetDefList.add(assetdef);
				if (log.isTraceEnabled()) {
					log.trace("getAssetTypeListForGuest ||"+ assetdef.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAssetTypeListForGuest ||"+ assetDefList.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAssetTypeListForGuest ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetTypeListForGuest ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetTypeListForGuest ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetTypeListForGuest ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getAssetTypeListForGuest ||"+ Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isTraceEnabled()) {
			log.trace("getAssetTypeListForGuest || End");
		}
		return assetDefList;
	}

	
	/**
	 * @method updateGuestAssetType
	 * @description update Guest Asset type
	 * @param assetDef
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateGuestAssetType(AssetDef assetDef, Connection conn)
			throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("updateGuestAssetType || where Guestflag:"
					+ assetDef.isGuestflag() + ",Quicksearchflag:"
					+ assetDef.isQuicksearchflag() + ",AssetName:"
					+ assetDef.getAssetName() + " || Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("updateGuestAssetType ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_GUEST_ACCESS));
			preparedStmt.setBoolean(Constants.ONE, assetDef.isGuestflag());
			preparedStmt.setBoolean(Constants.TWO, assetDef.isQuicksearchflag());
			preparedStmt.setString(Constants.THREE, assetDef.getAssetName());
			preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateGuestAssetType ||"
						+ PropertyFileReader.getInstance().getValue(Constants.UPDATE_GUEST_ACCESS));
			}

		} catch (SQLException e) {
			log.error("updateGuestAssetType ||"
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.UPDATE_GUEST_ACCESS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("updateGuestAssetType ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("updateGuestAssetType ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("updateGuestAssetType ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("updateGuestAssetType ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {
			log.trace("updateGuestAssetType || End");
		}
	}

}
