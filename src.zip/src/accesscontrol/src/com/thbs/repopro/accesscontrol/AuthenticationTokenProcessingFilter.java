package com.thbs.repopro.accesscontrol;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Set;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.GenericFilterBean;

import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.util.CommonUtils;

public class AuthenticationTokenProcessingFilter extends GenericFilterBean {

	AuthenticationManager authManager;

	public AuthenticationTokenProcessingFilter(AuthenticationManager authManager) {
		this.authManager = authManager;

	}

	private static final String REDIS_KEY_PREFIX = "spring:session:sessions:";

	@Autowired
	private RedisOperations<String, Object> redisOps;

	// @Autowired
	// private SessionRepository sessionRepo;

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
        String bearer = "Bearer";
		if(1<0){//When Repopro is released as a trial version, the given if condition should be changed as if(1!=2)
													
			if(System.currentTimeMillis()>1525347780000l){//Less than value in this given condition is the hard coded value of the expiration date of system time
				
				UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
						"ROLE_NONE", "");
				authentication
				.setDetails(new WebAuthenticationDetailsSource()
				.buildDetails((HttpServletRequest) request));

				chain.doFilter(request, response);
				return;
			}
		}
		GlobalSettingDao globalsettingDao = new GlobalSettingDao();
		GlobalSetting globalsetting = null;
		try {
			globalsetting = globalsettingDao
					.retGlobalSettingByName("SAML", null);
		} catch (RepoproException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		Long sso = globalsetting.getGlobalSettingFlag();
		if (sso == 0L) {
			try {

				String token = null;
				if (((HttpServletRequest) request).getParameter("tokenName") != null) {
					token = ((HttpServletRequest) request)
							.getParameter("tokenName").trim();
				} else if (((HttpServletRequest) request).getHeader("token") != null) {

					token = ((HttpServletRequest) request).getHeader("token").trim();

				}
				// validate the token
				Set<String> keys = redisOps.keys("spring:session:sessions"
						+ "*");
				//String[] userName = null;
				//HttpServletRequest httpServletRequest = (HttpServletRequest) request;
				//Map<String, String[]> pmap = httpServletRequest
				//		.getParameterMap();

				//userName = pmap.get("userName");
				//userName = StringUtils.stripAll(userName);
				 User user = null;
				UserDao userDao = new UserDao();
				CommonUtils commonutils = new CommonUtils();
				if(token != null)
				{
					user = commonutils.userDetails(token);
    			    
				}
    			
				for (String key : keys) {
					String id = key.substring(REDIS_KEY_PREFIX.length());

					// Session session = sessionRepo.getSession(id);
					if(token != null){
						if (token.equals(id)) {
							User userDetails = null;
							//User user = null;
							//UserDao userDao = new UserDao();

							try {
								/*	if (userName == null) {
								HttpSession httpSession = httpServletRequest
										.getSession();
								SecurityContext ctx = (SecurityContext) httpSession
										.getAttribute("SPRING_SECURITY_CONTEXT");

								Authentication auth = ctx.getAuthentication();

								String userName1 = auth.getPrincipal()
										.toString();
								user = userDao.retProfileForUserName(
										userName1.trim(), null);
							} else {
								user = userDao.retProfileForUserName(
										userName[0].trim(), null);
							}*/

								userDetails = userDao.getUserByUserId(user.getUserId(), null);


							} catch (RepoproException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
									userDetails.getUserName().toString().trim(),
									CommonUtils.decrypt(userDetails.getPassword()));
							authentication
							.setDetails(new WebAuthenticationDetailsSource()
							.buildDetails((HttpServletRequest) request));

							// set the authentication into the SecurityContext

							SecurityContextHolder.getContext().setAuthentication(
									authManager.authenticate(authentication));
							break;

						}
					}
				}

				if (token == null) {
					//if (userName == null) {
						UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
								"ROLE_ANONYMOUS", "");
						authentication
						.setDetails(new WebAuthenticationDetailsSource()
						.buildDetails((HttpServletRequest) request));

						// set the authentication into the SecurityContext

						SecurityContextHolder.getContext().setAuthentication(
								authManager.authenticate(authentication));

						// continue thru the filter chain
			/*		} else if (userName[0].equalsIgnoreCase("guest")
							|| userName[0].equalsIgnoreCase("roleAnonymous")) {
						UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
								"ROLE_ANONYMOUS", "");
						authentication
						.setDetails(new WebAuthenticationDetailsSource()
						.buildDetails((HttpServletRequest) request));

						// set the authentication into the SecurityContext

						SecurityContextHolder.getContext().setAuthentication(
								authManager.authenticate(authentication));

						// continue thru the filter chain
					}*/

				}
				chain.doFilter(request, response);
			} catch (Exception e) {
				// e.printStackTrace();
				chain.doFilter(request, response);
			}
		} else {
			
			UserDao userDao = new UserDao();
			CommonUtils commonutils = new CommonUtils();
			HttpSession httpSession = ((HttpServletRequest) request).getSession();
    		SecurityContext ctx = (SecurityContext) httpSession.getAttribute("SPRING_SECURITY_CONTEXT");
    		if(ctx == null)
    		{
    			try {

    				String token = null;
    				if (((HttpServletRequest) request).getParameter("tokenName") != null) {
    					token = ((HttpServletRequest) request)
    							.getParameter("tokenName").trim();
    				} else if (((HttpServletRequest) request).getHeader("token") != null) {

    					token = ((HttpServletRequest) request).getHeader("token").trim();

    				}
    				// validate the token
    				Set<String> keys = redisOps.keys("spring:session:sessions"
    						+ "*");
    				//String[] userName = null;
    				//HttpServletRequest httpServletRequest = (HttpServletRequest) request;
    				//Map<String, String[]> pmap = httpServletRequest
    				//		.getParameterMap();

    				//userName = pmap.get("userName");
    				//userName = StringUtils.stripAll(userName);
    				//UserDao userDao = new UserDao();
    				
    				if(token != null)
    				{
    				if ((token.toLowerCase().startsWith(bearer.toLowerCase()))) 
    				{
    					User userDetails = null;
    					User user = null;
    					
    					String authHeaderValue = token.substring(bearer.length()).trim();
    					int commaIndex = authHeaderValue.indexOf(' ');
    					if (commaIndex > 0) {
    						authHeaderValue = authHeaderValue.substring(0, commaIndex);
    					}
    					user = commonutils.getUserDetailsFromOauth(authHeaderValue);
    					userDetails = userDao.getUserByUserId(user.getUserId(), null);
    					LocalDateTime currentTime = LocalDateTime.now();
    					if (Timestamp.valueOf(currentTime).after(user.getTimestamp()))
    					{
    					UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
								userDetails.getUserName().toString().trim(),
								CommonUtils.decrypt(userDetails.getPassword()));
						authentication
						.setDetails(new WebAuthenticationDetailsSource()
						.buildDetails((HttpServletRequest) request));

						// set the authentication into the SecurityContext

						SecurityContextHolder.getContext().setAuthentication(
								authManager.authenticate(authentication));
    					}
						
    				}
    				else
    				{
    					User user = null;
    					if(token != null)
        				{
        					user = commonutils.userDetails(token);
            			    
        				}
    				for (String key : keys) {
    					String id = key.substring(REDIS_KEY_PREFIX.length());

    					// Session session = sessionRepo.getSession(id);
    					if(token != null){
    						if (token.equals(id)) {
    							User userDetails = null;
    							//User user1 = null;
    							//UserDao userDao1 = new UserDao();

    							try {
    								/*		if (userName == null) {
    								HttpSession httpSession1 = httpServletRequest
    										.getSession();
    								SecurityContext ctx1 = (SecurityContext) httpSession1
    										.getAttribute("SPRING_SECURITY_CONTEXT");

    								Authentication auth = ctx1.getAuthentication();

    								String userName1 = auth.getPrincipal()
    										.toString();
    								user1 = userDao1.retProfileForUserName(
    										userName1.trim(), null);
    							} else {
    								user1 = userDao1.retProfileForUserName(
    										userName[0].trim(), null);
    							}*/



    								userDetails = userDao.getUserByUserId(user.getUserId(), null);


    							} catch (RepoproException e) {
    								// TODO Auto-generated catch block
    								e.printStackTrace();
    							}

    							UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
    									userDetails.getUserName().toString().trim(),
    									CommonUtils.decrypt(userDetails.getPassword()));
    							authentication
    							.setDetails(new WebAuthenticationDetailsSource()
    							.buildDetails((HttpServletRequest) request));

    							// set the authentication into the SecurityContext

    							SecurityContextHolder.getContext().setAuthentication(
    									authManager.authenticate(authentication));
    							break;

    						}
    					}

    				}
    				}
    				}
    				if (token == null) {
    					//if (userName == null) {
    						UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
    								"ROLE_ANONYMOUS", "");
    						authentication
    						.setDetails(new WebAuthenticationDetailsSource()
    						.buildDetails((HttpServletRequest) request));

    						// set the authentication into the SecurityContext

    						SecurityContextHolder.getContext().setAuthentication(
    								authManager.authenticate(authentication));

    						// continue thru the filter chain
    					 /*else if (userName[0].equalsIgnoreCase("guest")
    							|| userName[0].equalsIgnoreCase("roleAnonymous")) {
    						UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
    								"ROLE_ANONYMOUS", "");
    						authentication
    						.setDetails(new WebAuthenticationDetailsSource()
    						.buildDetails((HttpServletRequest) request));

    						// set the authentication into the SecurityContext

    						SecurityContextHolder.getContext().setAuthentication(
    								authManager.authenticate(authentication));

    						// continue thru the filter chain
    					}
*/
    				}
    				chain.doFilter(request, response);
    			} catch (Exception e) {
    				// e.printStackTrace();
    				chain.doFilter(request, response);
    			}
    		}
    		else{
    			String userName = ctx.getAuthentication().getPrincipal().toString();
    			User userDetails = null;
    			try {
    				 userDetails = userDao.retProfileForUserName(userName, null);
    			} catch (RepoproException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    			UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
    					userDetails.getUserName().toString().trim(),
    					CommonUtils.decrypt(userDetails.getPassword()));
    			authentication.setDetails(new WebAuthenticationDetailsSource()
    			.buildDetails((HttpServletRequest) request));

    			// set the authentication into the SecurityContext

    			SecurityContextHolder.getContext().setAuthentication(
    					authManager.authenticate(authentication));
    			chain.doFilter(request, response);
    		}
    		
    	
		}

	}
}
