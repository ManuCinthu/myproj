package com.thbs.repopro.accesscontrol;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.GroupRoles;
import com.thbs.repopro.dto.Role;
import com.thbs.repopro.dto.RoleFunction;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class RoleDao {

	private static final Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : addRole
	 * @description : to insert roledetails
	 * @param addrole
	 * @param conn
	 * @return role
	 * @throws RepoproException
	 */
	public Role addRole(Role addrole, Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("addRole ||" + addrole.toString() + "|| Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addRole ||" + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.INSERT_ROLE_DATA));
			preparedStmt.setString(Constants.ONE, addrole.getRoleName());
			preparedStmt.setString(Constants.TWO, "");
			preparedStmt.setString(Constants.THREE, addrole.getDescription());
			preparedStmt.execute();
			rs = preparedStmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				addrole.setRoleId(rs.getLong(1));
			}
			if (log.isTraceEnabled()) {
				log.trace("addRole ||"
						+ PropertyFileReader.getInstance().getValue(Constants.INSERT_ROLE_DATA));

			}

		} catch (SQLException e) {
			log.error("addRole ||" + Constants.LOG_CREATE_SQLEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INSERT_ROLE_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addRole ||" + Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addRole ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addRole ||" + Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addRole ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {
			log.trace("addRole ||" + addrole.toString() + "||End");
		}
		return addrole;
	}

	/**
	 * @method : getAllRoleData
	 * @description :get all roledetails
	 * @param conn
	 * @return List<Role>
	 * @throws RepoproException
	 */
	public List<Role> getAllRoleData(Connection conn) throws RepoproException {

		log.trace("getAllRoleData || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<Role> roledata = new ArrayList<Role>();
		Role role = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllRoleData ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ROLE_DATA));
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllRoleData ||"
						+ PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ROLE_DATA));
			}

			while (rs.next()) {
				role = new Role();
				role.setRoleId(rs.getLong("role_id"));
				role.setRoleName(rs.getString("role_name"));
				role.setAuthority(rs.getString("authority"));
				role.setDescription(rs.getString("description"));
				roledata.add(role);
				if (log.isTraceEnabled()) {
					log.trace("getAllRoleData ||" + role.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllRoleData ||" + roledata.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAllRoleData ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ROLE_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllRoleData ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllRoleData ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllRoleData ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleData ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		log.trace("getAllRoleData || End");

		return roledata;
	}

	/**
	 * @method : updateRole
	 * @description :update roledetails
	 * @param role_id
	 * @param roledata
	 * @param conn
	 * @return Role
	 * @throws RepoproException
	 */
	public Role updateRole(Long role_id, Role roledata, Connection conn)
			throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("updateRole ||" + role_id + " " + roledata.getRoleName()
					+ " " + roledata.getDescription() + " || Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("updateRole ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_ROLE));
			preparedStmt.setString(Constants.ONE, roledata.getRoleName());
			preparedStmt.setString(Constants.TWO, roledata.getDescription());
			preparedStmt.setLong(Constants.THREE, role_id);
			preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateRole ||"
						+ PropertyFileReader.getInstance().getValue(Constants.UPDATE_ROLE));
			}

		} catch (SQLException e) {
			log.error("updateRole ||" + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.UPDATE_ROLE_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("updateRole ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("updateRole ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("updateRole ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			
			if (log.isTraceEnabled()) {
				log.trace("updateRole ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		
		}
		if (log.isTraceEnabled()) {

			log.trace("updateRole ||" + role_id + " ," + roledata.getRoleName()
					+ ", " + roledata.getDescription() + " ||End");
		}

		return roledata;

	}

	/**
	 * @method : deleteRole
	 * @description :delete roledetails by role_id
	 * @param role_id
	 * @param conn
	 * @throws RepoproException
	 */
	public int deleteRole(Long role_id, Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("deleteRole by role_id ||" + role_id + " ||Begin");
		}

		PreparedStatement preparedStmt = null;
		Connection conn1 = null;
		int result = 0;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteRole ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_ROLE));
			preparedStmt.setLong(Constants.ONE, role_id);
			result = preparedStmt.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("deleteRole ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_ROLE));
			}

		} catch (SQLException e) {
			log.error("SQL Exception deleteRole||"
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ROLE_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteRole ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteRole ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteRole ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			
			if (log.isTraceEnabled()) {
				log.trace("deleteRole ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteRole by role_Id ||" + role_id + "||End");
		}
		return result;
	}

	/**
	 * @method :getGroupRolesByRoleId
	 * @description :get grouproles by role_id
	 * @param role_id
	 * @param conn
	 * @return List<GroupRoles>
	 * @throws RepoproException
	 */
	public List<GroupRoles> getGroupRolesByRoleId(Long role_id, Connection conn)
			throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getGroupRolesByRoleId ||" + role_id + "||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<GroupRoles> groupdata = new ArrayList<GroupRoles>();
		GroupRoles group = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getGroupRolesByRoleId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_GROUP_ROLES_BY_ROLE_ID));
			preparedStmt.setLong(Constants.ONE, role_id);
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("getGroupRolesByRoleId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_GROUP_ROLES_BY_ROLE_ID));
			}
			while (rs.next()) {
				group = new GroupRoles();
				group.setGroupId(rs.getLong("group_id"));
				group.setGroupRolesId(rs.getLong("group_roles_id"));
				group.setRoleId(rs.getLong("role_id"));
				groupdata.add(group);
				if (log.isTraceEnabled()) {
					log.trace("getGroupRolesByRoleId ||" + group.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getGroupRolesByRoleId ||" + groupdata.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getGroupRolesByRoleId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getGroupRolesByRoleId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getGroupRolesByRoleId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getGroupRolesByRoleId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("getGroupRolesByRoleId ||" + role_id + "|| End");
		}
		return groupdata;
	}

	/**
	 * @method :retRoleFunctionsByRoleId
	 * @description :get rolefunction by role_id
	 * @param role_id
	 * @param conn
	 * @return List<RoleFunction>
	 * @throws RepoproException
	 */
	public List<RoleFunction> retRoleFunctionsByRoleId(Long role_id,
			Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("retRoleFunctionsByRoleId ||" + role_id + "|| Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<RoleFunction> functiondata = new ArrayList<RoleFunction>();
		RoleFunction function = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retRoleFunctionsByRoleId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_ROLE_FUNCTIONS_BY_ROLE_ID));
			preparedStmt.setLong(Constants.ONE, role_id);
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("retRoleFunctionsByRoleId ||"
						+ PropertyFileReader.getInstance().getValue(Constants.RET_ROLE_FUNCTIONS_BY_ROLE_ID));
			}
			while (rs.next()) {
				function = new RoleFunction();
				function.setRoleId(rs.getLong("role_id"));
				function.setFunctionId(rs.getLong("function_id"));
				function.setRoleFunctionId(rs.getLong("role_function_id"));
				functiondata.add(function);
				if (log.isTraceEnabled()) {
					log.trace("retRoleFunctionsByRoleId ||"
							+ function.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retRoleFunctionsByRoleId ||"
						+ functiondata.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retRoleFunctionsByRoleId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.ROLE_FUNCTION_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retRoleFunctionsByRoleId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retRoleFunctionsByRoleId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retRoleFunctionsByRoleId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}
		
		}
		if (log.isTraceEnabled()) {
			log.trace("retRoleFunctionsByRoleId ||" + role_id + "|| End");
		}
		return functiondata;
	}

	/**
	 * @method :deleteRoleFunctionByRoleId
	 * @description :delete rolefunction by role_id
	 * @param role_id
	 * @param conn
	 * @throws RepoproException
	 */
	public int deleteRoleFunctionByRoleId(Long role_id, Connection conn)
			throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("deleteRoleFunctionByRoleId ||" + role_id + "|| Begin");
		}
		java.sql.PreparedStatement preparedStmt = null;
		Connection conn1 = null;
		int result = 0;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteRoleFunctionByRoleId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.DELETE_FUNCTION_ROLE_BY_ID));
			preparedStmt.setLong(Constants.ONE, role_id);
			result = preparedStmt.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("deleteRoleFunctionByRoleId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_FUNCTION_ROLE_BY_ID));
			}
			
		} catch (SQLException e) {
			log.error("SQL Exception deleteRoleFunctionByRoleId ||"
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.FUNCTION_ROLE_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteRoleFunctionByRoleId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteRoleFunctionByRoleId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteRoleFunctionByRoleId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			
			DBConnection.closePreparedStatement(preparedStmt);
			
			if (log.isTraceEnabled()) {
				log.trace("deleteRoleFunctionByRoleId ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteRoleFunctionByRoleId ||" + role_id + "|| End");
		}
		return result;
	}

	/**
	 * @method :getRoleById
	 * @description :get roledetails by role_id
	 * @param role_id
	 * @param conn
	 * @return Role
	 * @throws RepoproException
	 */
	public Role getRoleById(Long role_id, Connection conn)
			throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getRoleById ||" + role_id + "|| Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Role role = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getRoleById ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.GET_ROLE_DATA_BY_ROLE_ID));
			preparedStmt.setLong(Constants.ONE, role_id);
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("getRoleById ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ROLE_DATA_BY_ROLE_ID));
			}
			while (rs.next()) {
				role = new Role();
				role.setRoleId(rs.getLong("role_id"));
				role.setRoleName(rs.getString("role_name"));
				role.setAuthority(rs.getString("authority"));
				role.setDescription(rs.getString("description"));
				if (log.isTraceEnabled()) {
					log.trace("getRoleById :" + role.toString());
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getRoleById ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ROLE_DATA_BY_ID_NOT_FOUND));
		} catch (IOException e) {
			log.error("getRoleById ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getRoleById ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getRoleById ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("getRoleById ||" + role_id + "||End");
		}
		return role;
	}

	/**
	 * @method :addRoleFunction
	 * @description :insert rolefunction by role_id
	 * @param role_id
	 * @param addFunctionId
	 * @param conn
	 * @return List<RoleFunction>
	 * @throws RepoproException
	 */
	public List<RoleFunction> addRoleFunction(Role roleData,
			Connection conn) throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("addRoleFunction ||where role_id:"
					+ roleData.getRoleId() + ",AssociatedFunctionIds:"
					+ roleData.getAssociateFunctionIds().toString()
					+ "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		PreparedStatement preparedStmt1 = null;
		ResultSet rs = null;

		List<RoleFunction> list = new ArrayList<RoleFunction>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addRoleFunction ||" + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt1 = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_ROLE_FUNCTION_DATA));
			preparedStmt1.setLong(Constants.ONE, roleData.getRoleId());
			preparedStmt1.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("addRoleFunction ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_ROLE_FUNCTION_DATA));
			}
			if(!roleData.getAssociateFunctionIds().isEmpty()){
				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.ADD_ROLE_FUNCTION_DATA));
				for (int i = 0; i < roleData.getAssociateFunctionIds().size(); i++) {

					Long addFunctionId = Long.parseLong(roleData
							.getAssociateFunctionIds().get(i));
					preparedStmt.setLong(Constants.ONE, roleData.getRoleId());
					preparedStmt.setLong(Constants.TWO, addFunctionId);
					preparedStmt.execute();
					if (log.isTraceEnabled()) {
						log.trace("addRoleFunction ||"
								+ PropertyFileReader.getInstance().getValue(
										Constants.ADD_ROLE_FUNCTION_DATA));
					}
					RoleFunction roleFunc = new RoleFunction();
					roleFunc.setRoleId(roleData.getRoleId());
					roleFunc.setFunctionId(addFunctionId);
					rs = preparedStmt.getGeneratedKeys();
					if (rs != null && rs.next()) {
						roleFunc.setRoleFunctionId(rs.getLong(1));
					}
					list.add(roleFunc);

					if (log.isTraceEnabled()) {
						log.trace("addRoleFunction ||" + roleData.toString());
					}

				}
			}
			if (log.isDebugEnabled()) {
				log.debug("addRoleFunction ||" + list.toString());
			}
		} catch (SQLException e) {
			log.error("addRoleFunction ||" + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INSERT_ROLE_FUNCTION_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addRoleFunction ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addRoleFunction ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addRoleFunction ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt1);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addRoleFunction ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {

			log.trace("addRoleFunction ||where role_id:"
					+ roleData.getRoleId() + ",AssociatedFunctionIds:"
					+ roleData.getAssociateFunctionIds().toString()
					+ "|| End");
		}
		return list;
	}

	/**
	 * @method :getAllRoleFunctions
	 * @description :get rolefunction details
	 * @param conn
	 * @return <UserFunction>
	 * @throws RepoproException
	 */
	public List<UserFunction> getAllRoleFunctions(Connection conn)
			throws RepoproException {

		log.trace("getAllRoleFunctions || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<UserFunction> userfunction = new ArrayList<UserFunction>();
		UserFunction function = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctions ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_ALL_ROLE_FUNCTIONS));
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctions ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_ROLE_FUNCTIONS));
			}
			rs = preparedStmt.executeQuery();
			while (rs.next()) {
				function = new UserFunction();
				function.setFunctionId(rs.getLong("function_id"));
				function.setFunctionName(rs.getString("function_name"));
				function.setFunctionDescription(rs
						.getString("function_description"));
				userfunction.add(function);

				if (log.isTraceEnabled()) {
					log.trace("getAllRoleFunctions ||" + function.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllRoleFunctions ||" + userfunction.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAllRoleFunctions ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.ROLE_FUNCTION_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllRoleFunctions ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllRoleFunctions ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllRoleFunctions ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
			
		}
		log.trace("getAllRoleFunctions || Begin");
		return userfunction;
	}

	/**
	 * @method :retAllRoleFunctionsMappedWithRoleId
	 * @description :get rolefunction details by role_id
	 * @param role_id
	 * @param conn
	 * @return List<UserFunction>
	 * @throws DataNotFoundException
	 */
	public List<UserFunction> retAllRoleFunctionsMappedWithRoleId(Long role_id,
			Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("retAllRoleFunctionsMappedWithRoleId ||" + role_id
					+ "|| Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<UserFunction> userfunction = new ArrayList<UserFunction>();
		UserFunction function = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retAllRoleFunctionsMappedWithRoleId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_ALL_ROLE_FUNCTIONS_BY_ROLE_ID));
			preparedStmt.setLong(Constants.ONE, role_id);
			if (log.isTraceEnabled()) {
				log.trace("retAllRoleFunctionsMappedWithRoleId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_ROLE_FUNCTIONS_BY_ROLE_ID));
			}
			rs = preparedStmt.executeQuery();
			while (rs.next()) {
				function = new UserFunction();
				function.setFunctionId(rs.getLong("function_id"));
				function.setFunctionName(rs.getString("function_name"));
				function.setFunctionDescription(rs
						.getString("function_description"));
				userfunction.add(function);
				if (log.isTraceEnabled()) {
					log.trace("retAllRoleFunctionsMappedWithRoleId ||"
							+ function.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retAllRoleFunctionsMappedWithRoleId ||"
						+ userfunction.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retAllRoleFunctionsMappedWithRoleId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.ROLE_FUNCTION_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retAllRoleFunctionsMappedWithRoleId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retAllRoleFunctionsMappedWithRoleId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			log.error("retAllRoleFunctionsMappedWithRoleId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("retAllRoleFunctionsMappedWithRoleId ||" + role_id
					+ "|| End");
		}
		return userfunction;
	}
	
	
	/**
	 * @method : retAllRoleFunctionsMappedWithUserId
	 * @param userId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<UserFunction> retAllRoleFunctionsMappedWithUserId(Long userId, Connection conn) throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("retAllRoleFunctionsMappedWithUserId || Begin with userId : "+ userId);
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		
		UserFunction function = null;
		
		List<UserFunction> userfunction = new ArrayList<UserFunction>();
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retAllRoleFunctionsMappedWithUserId ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_ALL_ROLE_FUNCTIONS_BY_USER_ID));
			
			preparedStmt.setLong(Constants.ONE, userId);
			
			if (log.isTraceEnabled()) {
				log.trace("retAllRoleFunctionsMappedWithUserId ||" + PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_ROLE_FUNCTIONS_BY_USER_ID));
			}
			
			rs = preparedStmt.executeQuery();
			
			while (rs.next()) {
				function = new UserFunction();
				function.setFunctionId(rs.getLong("function_id"));
				function.setFunctionName(rs.getString("function_name"));
				function.setFunctionDescription(rs
						.getString("function_description"));
				userfunction.add(function);
				if (log.isTraceEnabled()) {
					log.trace("retAllRoleFunctionsMappedWithUserId ||" + function.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retAllRoleFunctionsMappedWithUserId ||" + userfunction.toString());
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retAllRoleFunctionsMappedWithUserId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ROLE_FUNCTION_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retAllRoleFunctionsMappedWithUserId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retAllRoleFunctionsMappedWithUserId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			log.error("retAllRoleFunctionsMappedWithUserId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("retAllRoleFunctionsMappedWithUserId || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("retAllRoleFunctionsMappedWithRoleId || End");
		}
		return userfunction;
	}
	
	
	
	/**
	 * @method : getRoleIdByRoleName
	 * @param roleName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	
	public Long getRoleIdByRoleName(String roleName, Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("getRoleIdByRoleName || Begin with roleName : "+ roleName);
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Long roleId = null;
		
		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getRoleIdByRoleName ||" + Constants.LOG_CONNECTION_OPEN);
			}
			
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ROLE_ID_BY_ROLE_NAME));
			
			preparedStmt.setString(Constants.ONE, roleName);
			
			if (log.isTraceEnabled()) {
				log.trace("getRoleIdByRoleName ||" + PropertyFileReader.getInstance().getValue(
								Constants.GET_ROLE_ID_BY_ROLE_NAME));
			}
			
			rs = preparedStmt.executeQuery();
			
			while (rs.next()) {
				
				 roleId = rs.getLong("role_id");
				
			}
			
		}catch(SQLException e){
			
			e.printStackTrace();
			log.error("getRoleIdByRoleName ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_ROLE_ID_BY_ROLE_NAME_DATA_NOT_FOUND));
			
		}catch(IOException e){
			
			log.error("getRoleIdByRoleName ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		}catch(PropertyVetoException e){
			
			log.error("getRoleIdByRoleName ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			
		}catch(Exception e){
			
			log.error("getRoleIdByRoleName ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
			
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getRoleIdByRoleName || "+ Constants.LOG_CONNECTION_CLOSE);
			}
		}
		return roleId;
	}

	
	
	
	public List<String> getFunIdsByFunNames(List<String> functionNamesList, Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("getFunNamesByFunIds || Begin : "+ functionNamesList.toString());
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<String> functionIdsList = null;
		Role role = new Role();
		
		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getFunNamesByFunIds ||" + Constants.LOG_CONNECTION_OPEN);
			}
			
			String[] functionNames = null;
			List<String> funNamesList = new ArrayList<String>();
			for(String s: functionNamesList){
				  functionNames = s.split(",");
				  funNamesList.add(functionNames[0]);
			}
			
			functionIdsList = new ArrayList<String>();
			if(functionNames != null){
			for(String str : funNamesList){
				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_FUNCTION_IDS_BY_FUNCTION_NAMES));
				
				preparedStmt.setString(Constants.ONE, str);
				rs = preparedStmt.executeQuery();
				
				while(rs.next()){
					functionIdsList.add(rs.getString("function_id"));
				}
				 
			 }
			}
			
		}catch(SQLException e){
			
			e.printStackTrace();
			log.error("getFunNamesByFunIds ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_FUN_IDS_BY_FUN_NAMES_DATA_NOT_FOUND));
			
		}catch(IOException e){
			
			log.error("getFunNamesByFunIds ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		}catch(PropertyVetoException e){
			
			log.error("getFunNamesByFunIds ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			
		}catch(Exception e){
			
			log.error("getFunNamesByFunIds ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
			
		}finally{
			
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getFunNamesByFunIds || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		
		return functionIdsList;
	}
	
	
	
	
	
	
	
	
	
}
