package com.thbs.repopro.accesscontrol;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.GroupAssetAccess;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.Role;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.dto.UserGroups;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;

@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Path("/groupmanager")
public class GroupManager {
	
	//Logger log = Logger.getLogger(GroupManager.class.getName());
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	/**
	 * @method : addGroup
	 * @description : to create a new group
	 * @param addgroup
	 *            New Group Object
	 * @return Response Success message
	 */
	@POST
	@Path("/addgroup")
	public Response addGroup(GroupDetails addGroup){
		
		if(addGroup == null) {
			log.warn("addGroup || Group data to be inserted is not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_REQUEST)))
					.build();
		}
		else {
			if(log.isTraceEnabled()){
				log.trace("addGroup || "+ addGroup.toString() +" Begin");
			}
			CommonUtils commonUtils = new CommonUtils();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			Connection conn = null;
			
			List<String> result = new ArrayList<String>();
			List<GroupDetails> groupListObj = new ArrayList<GroupDetails>();
			
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			
			try{
				if (log.isTraceEnabled()){
					log.trace("addGroup || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("addGroup || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
				
				boolean flagForDuplicateGroup = false;
				
				GroupDao dao = new GroupDao();
				
				String jsonRslt;
				List<String> jsonList = new ArrayList<String>();
				
				List<GroupDetails> groupList = new ArrayList<GroupDetails>();
				
				if (log.isTraceEnabled()) {
					log.trace("addGroup || dao method called : getAllGroups()");
				}
				groupList = dao.getAllGroups(conn);
				
				for(GroupDetails list : groupList){
					if(list.getGroupName().equalsIgnoreCase(addGroup.getGroupName())){
						flagForDuplicateGroup = true;
					}
				}
				
				if(flagForDuplicateGroup == true){
					log.warn("addGroup || Group by this name already exists, please provide different name");
					result.add("Group by this name already exists, please provide different name");
					
					jsonRslt = Constants.GROUP_NAME_EXIST;	
					jsonList.add(jsonRslt);
					
					return Response
							.status(Status.OK)
							.entity(new MyModel(Constants.INSERT_STATUS_FAILURE,
									Constants.FAILURE, MessageUtil
									.getMessage(Constants.GROUP_NOT_CREATED), new ArrayList<Object>(jsonList)))
							.build();
					
				}else{
					
					if(globalsetting.getGlobalSettingFlag() == 1){
						String description = commonUtils.httpSanitizerForPlainText(addGroup.getDescription());
						addGroup.setDescription(description);
					}
					if (log.isTraceEnabled()) {
						log.trace("addGroup || dao method called : addGroup() " + addGroup.toString());
					}
					GroupDetails groupDet = dao.addGroup(addGroup, conn);
										
					Long groupId = groupDet.getGroupId();
					
					retMsg = Constants.GROUP_CREATED;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					
					addGroup.setGroupId(groupId);
					groupListObj.add(addGroup);
				}
				
				log.debug("addGroup || "+ addGroup.toString() +" added group successfully");
				conn.commit();
			} catch (RepoproException e) {
				log.error("addGroup || " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}

			} catch (Exception e) {
				log.error("addGroup || " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}

			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addGroup || "+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if(log.isTraceEnabled()){
				log.trace("addGroup || "+ addGroup.toString() +" End");
			}
			
			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(groupListObj)))
					.build();
		}
		
	}
	
	
	@POST
	@Path("/addGroupMain")
	public Response addGroupMain(@QueryParam("groupName") String groupName, 
			@QueryParam("groupDescription") String groupDescription,
			@HeaderParam("token") String token){
		
		if(groupName == null || groupDescription == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(groupName.isEmpty() || groupDescription.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		if(groupName.trim().length()>30 || groupDescription.trim().length()>100){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
		}
		
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		User user = new User();
		RoleDao roledao = new RoleDao();
		GroupDetails group = new GroupDetails();
		UserDao userDao = new UserDao();
		boolean groupFlag = false;
		boolean adminFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		groupName = groupName.trim();
		groupDescription = groupDescription.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, null);
			if(user != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), null);
			}
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_GRPS")){
					groupFlag = true;
			        break;
				}
			}
			
			group.setGroupName(groupName);
			group.setDescription(groupDescription);
			
			if(groupFlag || adminFlag){
				String newRegex = "^[A-Za-z0-9-_ ]+$";
				Pattern pattern = Pattern.compile(newRegex);
				Matcher matcher = pattern.matcher(groupName);
				
				if(!matcher.find()){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, "Please use only alphanumeric characters, space, - and _ in group name."))
							.build();
				}
				
				response = this.addGroup(group);
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				if(res.getStatus().equalsIgnoreCase(Constants.FAILURE)){
					json.put("message", res.getResult());
					json.put("status", res.getStatus());
					json.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("addGroupMain || End");
					
					return Response.status(Status.BAD_REQUEST).entity(json.toString()).build();
				}
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("addGroupMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
				
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }	
			
		} catch (RepoproException e) {
			log.error("addGroupMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addGroupMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addGroupMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.trace("addGroupMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	
	/**
	 * @method : getAllGroups
	 * @description : to get all groups
	 * @return Response with List<Group> List of all Groups
	 */
	@GET
	@Path("/getallgroups")
	public Response getAllGroups(){
		
		log.trace("getAllGroups || Begin");
		
		Connection conn = null;
		
		List<GroupDetails> groupList = new ArrayList<GroupDetails>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllGroups || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			GroupDao dao = new GroupDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroups || dao method called : getAllGroups()");
			}
			groupList = dao.getAllGroups(conn);
		
			for(GroupDetails group:groupList){
				if (log.isTraceEnabled()) {
					log.trace("deleteGroup || dao method called : getUserGroupsByGroupId()");
				}
				List<UserGroups> userGroupsList = dao.getUserGroupsByGroupId(group.getGroupId(), conn);

				if(userGroupsList.size() != 0){
					group.setGroupUserFlag(true);
				}
			}
			
			/*Iterator<GroupDetails> iterator = groupList.iterator();
			while(iterator.hasNext()){
				GroupDetails gd = iterator.next();
				if(gd.getGroupName().equals("group-admin")|| gd.getGroupName().equals("Guest")){
					iterator.remove();
				}
			}*/
			
			log.debug("getAllGroups || retrieved "+ groupList.size()+ " groups successfully");
			
			retMsg = Constants.ALL_GROUPS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("getAllGroups || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}catch(Exception e){
			log.error("getAllGroups || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroups || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if (groupList.isEmpty()) {
			retMsg = Constants.GROUPS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_GROUPS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		
		log.trace("getAllGroups || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(groupList))).build();
		
	}
	
	
	/***Wrapper function***/
	/**
	 * @method : getAllGroupsMain
	 * @param groupName
	 * @return Response with List<Group> List of all Groups by type
	 */
	@GET
	@Path("/getAllGroupsMain")
	public Response getAllGroupsMain(@HeaderParam("token") String token) {
		
		if (log.isTraceEnabled()) {
			log.trace("getAllGroupsMain || Begin");
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		
		User user1 = new User();
		UserDao userDao = new UserDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean groupFlag = false;
		RoleDao roledao = new RoleDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId(userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (!userName.equalsIgnoreCase("guest")) {
				user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user1 != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user1.getUserId(), conn);
			}
				        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_GRPS")){
					groupFlag = true;
			        break;
				}
			}
			
			if(groupFlag || adminFlag){
				response = this.getAllGroups();
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	GroupDetails gd = new GroupDetails();
		        	gd = (GroupDetails) data.get(i);
		        			        	
		        	j1.put("groupName", gd.getGroupName());
		        	j1.put("description", gd.getDescription());
		        	
		        	finaldata.add(j1);
		        }
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getAllGroupsMain || End");
		        return Response.status(retStat).entity(json.toString()).build();   
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
		} catch (RepoproException e) {
			log.error("getAllGroupsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllGroupsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllGroupsMain || End");
		}

		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	
	/**
	 * @method getAllGroupsWithAccess
	 * @return success response
	 */
	@GET
	@Path("/getallgroupsAccess")
	public Response getAllGroupsWithAccess(){
		
		log.trace("getAllGroupsWithAccess || Begin");
		
		Connection conn = null;
		
		List<GroupAssetAccess> groupList = new ArrayList<GroupAssetAccess>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllGroupsWithAccess || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			GroupDao dao = new GroupDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAccess || dao method called : getAllGroupsWithAllAccess()");
			}
			groupList = dao.getAllGroupsWithAllAccess(conn);
			
			Iterator<GroupAssetAccess> iterator = groupList.iterator();
			while(iterator.hasNext()){
				GroupAssetAccess gd = iterator.next();
				if(gd.getGroupName().equals("group-admin")|| gd.getGroupName().equals("Guest")){
					iterator.remove();
				}
			}
			
			log.debug("getAllGroupsWithAccess || retrieved "+ groupList.size()+ " groups successfully");
			
			retMsg = Constants.ALL_GROUPS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("getAllGroupsWithAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}catch(Exception e){
			log.error("getAllGroupsWithAccess || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAccess || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if (groupList.isEmpty()) {
			retMsg = Constants.GROUPS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_GROUPS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		
		log.trace("getAllGroupsWithAccess || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(groupList))).build();
		
	}
	
	
	/**
	 * @method getAllGroupsWithAllAccessForEditAsset
	 * @param assetId
	 * @return success response
	 */
	@GET
	@Path("/getallgroupsAccessForEditAsset")
	public Response getAllGroupsWithAllAccessForEditAsset(@QueryParam("assetId")Long assetId){
		
		log.trace("getAllGroupsWithAllAccessForEditAsset || Begin");
		
		Connection conn = null;
		
		List<GroupAssetAccess> groupList = new ArrayList<GroupAssetAccess>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		Boolean flagForGroupExistsinList = false;
		GroupDao groupDao = new GroupDao();
		int retStatScsFlr = 0;
		List<GroupAssetAccess> groupIsMappedWithList = new ArrayList<GroupAssetAccess>();
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			GroupDao dao = new GroupDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccessForEditAsset || dao method called : getAllGroupsWithAllAccessForEditAsset()");
			}
			groupList = dao.getAllGroupsWithAllAccessForEditAsset(assetId,conn);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccessForEditAsset || dao method called : getAllGroups()");
			}
			
			List<GroupDetails>  groupBos = groupDao.getAllGroups(conn);
			
			for(GroupDetails groupBo : groupBos)
			{
			if(!groupBo.getGroupName().equalsIgnoreCase("group-admin") && !groupBo.getGroupName().equalsIgnoreCase("Guest"))
			{
				GroupAssetAccess groupMappedwithAssetVo = new GroupAssetAccess();
				groupMappedwithAssetVo.setGroupId(groupBo.getGroupId());
				groupMappedwithAssetVo.setGroupName(groupBo.getGroupName());
				groupMappedwithAssetVo.setMappedWithAI(false);
				groupMappedwithAssetVo.setAddAccess(0L);
				groupMappedwithAssetVo.setEditAccess(0L);
				groupMappedwithAssetVo.setViewAccess(0L);
				groupMappedwithAssetVo.setDeleteAccess(0L);
										
			for(GroupAssetAccess groupAssetAccess:groupList)
			{
				
				if(groupAssetAccess.getGroupId().equals(groupBo.getGroupId()))
				{
					groupMappedwithAssetVo.setMappedWithAI(true);
					
					if(groupAssetAccess.getAddAccess() == 1)
					{
						groupMappedwithAssetVo.setAddAccess(1L);
					}
					
					if(groupAssetAccess.getEditAccess() == 1)
					{
						groupMappedwithAssetVo.setEditAccess(1L);
					}
					
					if(groupAssetAccess.getViewAccess() == 1)
					{
						groupMappedwithAssetVo.setViewAccess(1L);
					}
					
					if(groupAssetAccess.getDeleteAccess() == 1)
					{
						groupMappedwithAssetVo.setDeleteAccess(1L);
					}
				}
			}
			
			
			//Checking duplicate entries in  list
			
			
			
			
			for(int i=0;i<groupIsMappedWithList.size();i++){
				if(groupIsMappedWithList.get(i).getGroupId().equals(groupMappedwithAssetVo.getGroupId())){
					flagForGroupExistsinList = true;
				}
			}
			//If user not exists in list, then adding into list
			if(flagForGroupExistsinList == false){
				groupIsMappedWithList.add(groupMappedwithAssetVo);	
			}
			
			}
			}
			
					
			log.debug("getAllGroupsWithAllAccessForEditAsset || retrieved "+ groupIsMappedWithList.size()+ " groups successfully");
			
			retMsg = Constants.ALL_GROUPS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}catch(Exception e){
			log.error("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccessForEditAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if (groupList.isEmpty()) {
			retMsg = Constants.GROUPS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_GROUPS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		
		log.trace("getAllGroupsWithAllAccessForEditAsset || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(groupIsMappedWithList))).build();
		
	}

//===========================================================================================================================================	
	/***Wrapper function***/
	/* used for UI purpose in edit asset page */
	@GET
	@Path("/getAllGroupsWithAllAccessForEditAssetMain")
	public Response getAllGroupsWithAllAccessForEditAssetMain(
			@QueryParam("assetName") String assetName, @QueryParam("userName") String userName) {

		if(userName == null|| assetName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(userName.isEmpty()|| assetName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getAllGroupsWithAllAccessForEditAsset || Begin");

		Connection conn = null;
		Response response = null;
		boolean groupFlag = false;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		RoleDao roledao = new RoleDao();
		User user = new User();
		UserDao userDao = new UserDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		userName = userName.trim();
		assetName = assetName.trim();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccessForEditAssetMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (!userName.equalsIgnoreCase("guest")) {
				User user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			GroupDao dao = new GroupDao();
			
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

			Long assetId = dao.getAssetIdByAssetname(assetName, conn);
			if (assetId == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAllGroupsWithAllAccessForEditAssetMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
						
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user != null)
			userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_GRPS")){
					groupFlag = true;
			        break;
				}
			}
			
			if(groupFlag || adminFlag){
				response = this.getAllGroupsWithAllAccessForEditAsset(assetId);
				return response;
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
		} catch (RepoproException e) {
			log.error("getAllGroupsWithAllAccessForEditAssetMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllGroupsWithAllAccessForEditAssetMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsWithAllAccessForEditAssetMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllGroupsWithAllAccessForEditAssetMain || End");

		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

	}
//===================================================================================================================================	
	
	
	
	
	/**
	 * @method updateGroup
	 * @description to update a Group
	 * @param updateGroup
	 * @return Response Success message 
	 */
	@PUT
	@Path("/updategroup")
	public Response updateGroup(GroupDetails updateGroup){
		
		if(updateGroup == null) {
			log.warn("updateGroup || Group data to be updated not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_REQUEST)))
					.build();
		}
		else{
			if(log.isTraceEnabled()){
				log.trace("updateGroup || "+ updateGroup.toString() +" Begin");
			}
			
			Connection conn = null;
			
			List<String> result = new ArrayList<String>();
			List<GroupDetails> groupList = new ArrayList<GroupDetails>();
			
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			CommonUtils commonUtils = new CommonUtils();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			
			try {
				if (log.isTraceEnabled()){
					log.trace("updateGroup || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("updateGroup || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
				
				boolean flagForDuplicateGroup = false;
				
				GroupDao dao = new GroupDao();
				
				String jsonRslt;
				List<String> jsonList = new ArrayList<String>();
				
				if (log.isTraceEnabled()) {
					log.trace("updateGroup || dao method called : getGroupById()");
				}
				GroupDetails groupId = dao.getGroupById(updateGroup.getGroupId(), conn);
				
				if (log.isTraceEnabled()) {
					log.trace("updateGroup || dao method called : getAllGroups()");
				}
				groupList = dao.getAllGroups(conn);
				
				if(groupList.size()>0){
					for(int i=0;i<groupList.size();i++){
						if(!(groupId.getGroupName().equalsIgnoreCase(groupList.get(i).getGroupName()))){
							if(updateGroup.getGroupName().equalsIgnoreCase(groupList.get(i).getGroupName())){
								flagForDuplicateGroup = true;
							}
						}
					}
				}
				if(globalsetting.getGlobalSettingFlag() == 1){
					String description = commonUtils.httpSanitizerForPlainText(updateGroup.getDescription());
					updateGroup.setDescription(description);
				}
				if(flagForDuplicateGroup == true){
					log.warn("updateGroup || check whether entered name already exist");
					result.add("Please check whether entered name already exist" 
								+ "Group Name : "+updateGroup.getGroupName());
					
					jsonRslt = Constants.GROUP_NAME_EXIST;	
					jsonList.add(jsonRslt);	
					
					return Response
							.status(Status.OK)
							.entity(new MyModel(Constants.UPDATE_STATUS_SUCCESS,
									Constants.FAILURE, MessageUtil
									.getMessage(Constants.GROUP_NOT_UPDATED),new ArrayList<Object>(jsonList)))
							.build();
					
				}else{
					if (log.isTraceEnabled()) {
						log.trace("updateGroup || dao method called : updateGroup() "+ updateGroup.toString());
					}
					dao.updateGroup(updateGroup, conn);
					
					retMsg = Constants.GROUP_UPDATED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				}
				
				if (log.isTraceEnabled()) {
					log.trace("updateGroup || dao method called : addGroupRole() to update group roles details");
				}
				groupList = dao.addGroupRole(updateGroup, conn);
				
				log.info("updateGroup || "+ updateGroup.toString() +" group data updated successfully");
				conn.commit();
				
				
			} catch (RepoproException e) {
				log.error("updateGroup || " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch (Exception e) {
				log.error("updateGroup || " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateGroup || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if(log.isTraceEnabled()){
				log.trace("updateGroup || "+ updateGroup.toString() +" End");
			}
			
			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(result)))
					.build();
		}
		
		
	}
	
	
	
	
//========================================================================================================================================
	/***Wrapper function***/
	/**
	 * @method updateGroupMain
	 * @description to update a Group
	 * @param groupNameBeforeUpdate
	 * @param updateGroup
	 * @return Response Success message 
	 */
	@PUT
	@Path("/updategroupMain")
	public Response updateGroupMain(@QueryParam("groupName") String groupName, 
			@QueryParam("groupDetails") String groupDetails,
			@HeaderParam("token") String token){
		
		if (groupName == null) {
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
							.build();
		}
		if(groupName.trim().isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		if(groupDetails == null || groupDetails.isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		if(groupDetails != null){
			try {
				String jsonStr = groupDetails;
				JSONObject jsonObject = new JSONObject(jsonStr);
				if(!jsonObject.has("description") && !jsonObject.has("associatedRoleNames")){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
				}
			} catch (JSONException e) {
				e.printStackTrace();
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}	
		}
		
		if (log.isTraceEnabled()) {
			log.trace("updateGroupMain || " + groupName.toString() + " Begin");
		}

		Connection conn = null;

		List<String> roleNamesList = new ArrayList<String>();
		List<String> roleIdsList = new ArrayList<String>();
		RoleDao roledao = new RoleDao();
		User user = new User();
		UserDao userDao = new UserDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean groupFlag = false;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		List<String> roleNames = new ArrayList<String>();
		GroupDetails updateGroup = new GroupDetails();
		groupName = groupName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("updateGroupMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			GroupDao groupDao = new GroupDao();
			if (!userName.equalsIgnoreCase("guest")) {
				User user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

			Long groupId = (long) groupDao.getGroupIdByGroupName(groupName, conn);
			if (groupId == 0) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.GROUP_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("updateGroupMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			updateGroup.setGroupId(groupId);
			updateGroup.setGroupName(groupName);
					
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user != null)
			userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_GRPS")){
					groupFlag = true;
			        break;
				}
			}
			
			if(groupFlag || adminFlag){
				
				String jsonStr1 = groupDetails;
				JSONObject jsonObject = new JSONObject(jsonStr1);
				if(jsonObject.has("description")){
					String groupDescription = jsonObject.get("description").toString();
					groupDescription = groupDescription.trim();
					if(groupDescription.equalsIgnoreCase("")){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					updateGroup.setDescription(groupDescription);
					groupDao.updateGroup(updateGroup, conn);
				}
				
				if(jsonObject.has("associatedRoleNames")){
					String associatedRoleNames = jsonObject.get("associatedRoleNames").toString();
					associatedRoleNames = associatedRoleNames.trim();
					
					String[] splitNames = associatedRoleNames.split(",");
					for(int i=0;i<splitNames.length;i++){
						splitNames[i] = splitNames[i].trim();
						if(!splitNames[i].isEmpty()){
							roleNames.add(splitNames[i]);
						}
					}
					roleNamesList = roleNames;
					/*to check if each role is valid*/
					List<String> roleNamesFromDB = new ArrayList<String>();
					if(!roleNamesList.isEmpty()){
						List<Role> allRoleData = roledao.getAllRoleData(conn);
						for(Role role : allRoleData){
							roleNamesFromDB.add(role.getRoleName());
						}
						
						for(int i=0;i<splitNames.length;i++){
							splitNames[i] = splitNames[i].trim();
							if(!roleNamesFromDB.contains(splitNames[i])){
								retStat = Status.NOT_FOUND;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.ROLE_DATA_NOT_FOUND;
								retStatScsFlr = Constants.GET_STATUS_FAILURE;

								log.trace("updateGroupMain || End");
								return Response.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}
						}
						roleIdsList = groupDao.getRoleIdsByRoleNames(roleNamesList, conn);
						if (roleIdsList.isEmpty()) {
							retStat = Status.NOT_FOUND;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.ROLE_DATA_NOT_FOUND;
							retStatScsFlr = Constants.GET_STATUS_FAILURE;

							log.trace("updateGroupMain || End");
							return Response.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						updateGroup.setAssociatedRoleIds(roleIdsList);
						groupDao.addGroupRole(updateGroup, conn);
					}
				}
				conn.commit();
				JSONObject json = new JSONObject();
				
				json.put("message", Constants.GROUP_UPDATED);
				json.put("status", Constants.SUCCESS);
				json.put("statusCode", Constants.UPDATE_STATUS_SUCCESS);
				log.trace("updateGroupMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }

		} catch (RepoproException e) {
			log.error("updateGroupMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("updateGroupMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateGroupMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateGroupMain ||  End");
		}

		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
//========================================================================================================================================
	
	
	
	/**
	 * @method : deleteGroup
	 * @description : to delete a group
	 * @param groupId
	 * @return Response message
	 */
	@DELETE
	@Path("/deletegroup/{groupId}")
	public Response deleteGroup(@PathParam("groupId") Long groupId){
		
		if(log.isTraceEnabled()){
			log.trace("deleteGroup || Begin with groupId : "+ groupId);
		}
		
		Connection conn = null;
		
		List<String> msg = new ArrayList<String>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("deleteGroup || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			GroupDao dao = new GroupDao();
			
			if (log.isTraceEnabled()) {
				log.trace("deleteGroup || dao method called : getUserGroupsByGroupId()");
			}
			List<UserGroups> userGroupsList = dao.getUserGroupsByGroupId(groupId, conn);
						
			if(userGroupsList.size() != 0){
				log.warn("This Group is mapped with "+userGroupsList.size()+" users. Cannot delete this Group!");
				msg.add("This Group is mapped with "+userGroupsList.size()+" users. Cannot delete this Group!");
			}else{
				if (log.isTraceEnabled()) {
					log.trace("deleteGroup || dao method called : deleteGroupRoleByGroupId()");
				}
				dao.deleteGroupRoleByGroupId(groupId, conn);
						
				if (log.isTraceEnabled()) {
					log.trace("deleteGroup || dao method called : delGroup()");
				}
				String newMsg = dao.delGroup(groupId, conn);
				msg.add(newMsg);			
			}
			
			conn.commit();
			retMsg = Constants.GROUP_DELETED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			
			log.info("deleteGroup || Group with id "+ groupId +" deleted successfully");
			
		} catch (RepoproException e) {
			log.error("deleteGroup || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("deleteGroup || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteGroup || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("deleteGroup || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg,new ArrayList<Object>(msg)))
				.build();
		
	}
	
	
	
	
//=================================================================================================================================================	
	/***Wrapper function***/
	/**
	 * @method : deleteGroupMain
	 * @description : to delete a group
	 * @param groupName
	 * @return Response message
	 */
	@DELETE
	@Path("/deletegroup/groupName")
	public Response deleteGroupMain(@QueryParam("groupName") String groupName, 
			@HeaderParam("token") String token) {

		if(groupName == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(groupName.isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		if (log.isTraceEnabled()) {
			log.trace("deleteGroupMain || Begin with groupName : " + groupName);
		}

		Connection conn = null;

		RoleDao roledao = new RoleDao();
		User user = new User();
		UserDao userDao = new UserDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean groupFlag = false;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		groupName = groupName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteGroupMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			GroupDao dao = new GroupDao();
			if (!userName.equalsIgnoreCase("guest")) {
				User user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

			long groupId = (long) dao.getGroupIdByGroupName(groupName, conn);
			if (groupId == 0) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.GROUP_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("deleteGroupMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user != null)
			userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_GRPS")){
					groupFlag = true;
			        break;
				}
			}
			
			if(groupFlag || adminFlag){
				response = this.deleteGroup(groupId);
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				if(!res.getResult().get(0).equals("")){
					json.put("message", res.getResult());
					json.put("status", res.getStatus());
					json.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("deleteGroupMain || End");
					
					return Response.status(Status.BAD_REQUEST).entity(json.toString()).build();
				}
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("deleteGroupMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			

		} catch (RepoproException e) {
			log.error("deleteGroupMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("deleteGroupMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteGroupMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteGroupMain || End");
		}

		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
//==============================================================================================================================================	
	
	
	
	
	
	/**
	 * @method : getAllGroupRoles
	 * @description : to get all group roles
	 * @return Response with List<Group> List of all Groups by type
	 */
	@GET
	@Path("/getallgrouproles/{groupId}")
	public Response getAllGroupRoles(@PathParam("groupId") Long groupId){
		
		if(log.isTraceEnabled()){
			log.trace("getAllGroupRoles || Begin with groupId : "+ groupId);
		}
				
		Connection conn = null;
		
		List<Role> groupRoleList = new ArrayList<Role>();
		List<Role> groupRoleByIdList = new ArrayList<Role>();
		List<Role> roleIsMappedWithGroups = new ArrayList<Role>();
		
		Role roleDetails = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllGroupRoles || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			GroupDao dao = new GroupDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRoles || dao method called : getAllGroupRoles()");
			}
			groupRoleList = dao.getAllGroupRoles(conn);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRoles || dao method called : getAllGroupRolesByGroupId()");
			}
			groupRoleByIdList = dao.getAllGroupRolesByGroupId(groupId, conn);
				
			for(Role role : groupRoleList){
				roleDetails = new Role();
				roleDetails.setRoleId(role.getRoleId());
				roleDetails.setRoleName(role.getRoleName());
				roleDetails.setDescription(role.getDescription());
				roleDetails.setMappedWithGroup(false);
				for(Role role2 : groupRoleByIdList){
					if(role2.getRoleId() == role.getRoleId()){
						roleDetails.setMappedWithGroup(true);
					}
				}
				roleIsMappedWithGroups.add(roleDetails);
			}
			
			if(log.isTraceEnabled()){
				log.trace("getAllGroupRoles || "+ roleIsMappedWithGroups.toString());
			}
			
			retMsg = Constants.ALL_GROUP_ROLES_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			log.debug("getAllGroupRoles || retrieved " + roleIsMappedWithGroups.size() + " groups successfully");
			
			
		} catch(RepoproException e){
			log.error("getAllGroupRoles || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getAllGroupRoles || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRoles || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if (roleIsMappedWithGroups.isEmpty()) {
			retMsg = Constants.GROUP_ROLES_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_GROUP_ROLES_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		
		if(log.isTraceEnabled()){
			log.trace("getAllGroupRoles || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(roleIsMappedWithGroups))).build();
		
	}
	
	
	
	
//========================================================================================================================================	
	/***Wrapper function***/
	/**
	 * @method : getAllGroupRolesMain
	 * @param groupName
	 * @return Response with List<Group> List of all Groups by type
	 */
	@GET
	@Path("/getallgrouproles/groupName")
	public Response getAllGroupRolesMain(@QueryParam("groupName") String groupName, 
			@HeaderParam("token") String token) {

		if(groupName == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(groupName.isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		if (log.isTraceEnabled()) {
			log.trace("getAllGroupRolesMain || Begin with groupName : " + groupName);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		
		User user1 = new User();
		UserDao userDao = new UserDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean groupFlag = false;
		RoleDao roledao = new RoleDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		groupName = groupName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId(userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRolesMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (!userName.equalsIgnoreCase("guest")) {
				user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			GroupDao dao = new GroupDao();

			Long groupId = (long) dao.getGroupIdByGroupName(groupName, conn);
			if (groupId == 0) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.GROUP_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAllGroupRolesMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user1 != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user1.getUserId(), conn);
			}
				        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_GRPS")){
					groupFlag = true;
			        break;
				}
			}
			
			if(groupFlag || adminFlag){
				response = this.getAllGroupRoles(groupId);
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	Role role = new Role();
		        	role = (Role) data.get(i);
		        	
		        	j1.put("roleName", role.getRoleName());
		        	j1.put("description", role.getDescription());
		        	j1.put("mappedWithRole", role.isMappedWithGroup());
		        	
		        	finaldata.add(j1);
		        }
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getAllGroupRolesMain || End");
		        return Response.status(retStat).entity(json.toString()).build();   
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
		} catch (RepoproException e) {
			log.error("getAllGroupRolesMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllGroupRolesMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupRolesMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllGroupRolesMain || End");
		}

		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

	}
//===========================================================================================================================================	
	
	
	
	
	
	/**
	 * @method : getAllGroupsHavingEditAiPermission
	 * @description : to get all groups having edit AI permission
	 * @param function description
	 * @return Response message
	 */
	@GET
	@Path("/groupswitheditaipermission/{function_description}")
	public Response getAllGroupsHavingEditAiPermission(@PathParam("function_description") String funcDesc){
		
		if(log.isTraceEnabled()){
			log.trace("getAllGroupsHavingEditAiPermission || Begin with function description : "+ funcDesc);
		}
		
		Connection conn = null;
		
		List<GroupDetails> groupDetailsList = new ArrayList<GroupDetails>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllGroupsHavingEditAiPermission || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			GroupDao dao = new GroupDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsHavingEditAiPermission || dao method called : "
							+ "getAllGroupsHavingEditAiPermission()");
			}
			groupDetailsList = dao.getAllGroupsHavingEditAiPermission(funcDesc, conn);
			
			retMsg = Constants.ALL_GROUPS_HAVING_EDIT_AI_PERMISSION_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			log.info(" getAllGroupsHavingEditAiPermission || retrieved "
						+groupDetailsList.size() + " groups successfully");
			
		} catch(RepoproException e){
			log.error("getAllGroupsHavingEditAiPermission || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getAllGroupsHavingEditAiPermission || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllGroupsHavingEditAiPermission || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if (groupDetailsList.isEmpty()) {
			retMsg = Constants.GROUPS_HAVING_EDIT_AI_PERMISSION_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_GROUPS_HAVING_EDIT_AI_PERMISSION_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		
		if(log.isTraceEnabled()){
			log.trace("getAllGroupsHavingEditAiPermission || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(groupDetailsList))).build();
	}
	
	/**
	 * @method : getGroupsByAssetCategory
	 * @description : to get all group by asset category
	 * @param assetName
	 * @param assetCategoryName
	 * @return Response message
	 */
	@GET
	@Path("/getgroupsbyassetcategory/{assetName}/{assetCategoryName}")
	public Response getGroupsByAssetCategory(@PathParam("assetName") String assetName,
										@PathParam("assetCategoryName") String assetCategoryName){
		
		if(log.isTraceEnabled()){
			log.trace("getGroupsByAssetCategory || Begin with asset name : "+ assetName +
					" \t asset category name" + assetCategoryName);
		}
		
		Connection conn = null;
		
		List<GroupDetails> groupDetailsList = new ArrayList<GroupDetails>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getGroupsByAssetCategory || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			GroupDao dao = new GroupDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getGroupsByAssetCategory || dao method called : "
							+ "getGroupsByAssetCategory()");
			}
			groupDetailsList = dao.getGroupsByAssetCategory(assetName, assetCategoryName, conn);
			
			retMsg = Constants.ALL_GROUPS_BY_ASSET_CATEGORY_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			log.info(" getGroupsByAssetCategory || retrieved " +groupDetailsList.size() + " groups successfully");
			
		} catch(RepoproException e){
			log.error("getGroupsByAssetCategory || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getGroupsByAssetCategory || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getGroupsByAssetCategory || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if (groupDetailsList.isEmpty()) {
			retMsg = Constants.GROUPS_BY_ASSET_CATEGORY_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_GROUPS_BY_ASSET_CATEGORY_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		
		if(log.isTraceEnabled()){
			log.trace("getGroupsByAssetCategory || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(groupDetailsList))).build();
		
	}
	
}
