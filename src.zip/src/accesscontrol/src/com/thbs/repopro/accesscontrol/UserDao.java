package com.thbs.repopro.accesscontrol;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class UserDao {

	// static Logger log = Logger.getLogger(UserDao.class.getName());
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : getUsers
	 * @description : to get all users
	 * @param
	 * @return List<User>
	 * @throws RepoproException
	 */
	public List<User> getUsers(boolean imageFlag,Connection conn) throws RepoproException {

		log.trace("getUsers || begin");

		List<User> usersList = new ArrayList<User>();
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getUsers || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ALL_USERS));
			
			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			
			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getUsers || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_USERS));
			}

			while (resultSet.next()) {
				User user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setImageName(resultSet.getString("image_name"));
				if (imageFlag) {
					user.setImage(resultSet.getBinaryStream("decrypted_image"));
				}
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
				user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
				user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
				user.setEncryptImage(resultSet.getInt("encrypt_image"));

				usersList.add(user);

				if (log.isTraceEnabled()) {
					log.trace("getUsers || returning resultset  : "
							+ user.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getUsers || returning resultset  : "
						+ usersList.toString());
			}

		} catch (MySQLSyntaxErrorException e) {
			log.error("getUsers || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_FOUND));
		} catch (IOException e) {
			log.error("getUsers || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getUsers || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getUsers || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getUsers || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("getUsers || exit");
		return usersList;
	}


	/**
	 * @param userName 
	 * @method : getUsersForGrid
	 * @description : to get all users for grid
	 * @param
	 * @return List<User>
	 * @throws RepoproException
	 */
	public List<User> getUsersForGrid(String userName, Long from,Connection conn)
			throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("getUsersForGrid || begin  from : " + from);
		}
		List<User> usersListForGrid = new ArrayList<User>();
		Connection conn1 = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStmt = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getUsersForGrid || " + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_USERS_FOR_GRID));

			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			preparedStmt.setLong(Constants.FIVE, from);
			
			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getUsersForGrid || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_USERS_FOR_GRID));
			}
			if(userName.equalsIgnoreCase("admin")){
				while (resultSet.next()) {
				User user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setImageName(resultSet.getString("image_name"));
				user.setImage(resultSet.getBinaryStream("decrypted_image"));
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setPassword(resultSet.getString("password"));
				user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
				user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
				user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
				user.setEncryptImage(resultSet.getInt("encrypt_image"));
				
				  int lock = resultSet.getInt("lockAccount_flag");
				     if (lock == 1){
				    	 user.setLockStatus("unlock");
				     }else if(lock ==0){
				    	 user.setLockStatus("lock"); 
				     }
				usersListForGrid.add(user);

				if (log.isTraceEnabled()) {
					log.trace("getUsersForGrid || " + user.toString());
				}
			}
			}else{
				
				while (resultSet.next()) {
				User user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setImageName(resultSet.getString("image_name"));
				user.setImage(resultSet.getBinaryStream("decrypted_image"));
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setPassword(resultSet.getString("password"));
				user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
				user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
				user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
				user.setEncryptImage(resultSet.getInt("encrypt_image"));
				usersListForGrid.add(user);

				if (log.isTraceEnabled()) {
					log.trace("getUsersForGrid || " + user.toString());
				}
			}
			}

		} catch (SQLException e) {
			log.error("getUsersForGrid || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_FOUND));
		} catch (IOException e) {
			log.error("getUsersForGrid || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getUsersForGrid || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getUsersForGrid || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getUsersForGrid || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("getUsersForGrid || exit");
		return usersListForGrid;
	}

	/**
	 * @method : addUser
	 * @description : to create a new user
	 * @param user
	 * @return
	 * @throws RepoproException
	 */
	public Long addUser(User user, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addUser || begin || " + user.toString());
		}
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		Long userId = null;
		Connection conn1 = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("addUser : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.INSERT_USER));
			user.setActiveFlag("1");
			preparedStmt.setString(Constants.ONE, user.getUserName());
			preparedStmt.setString(Constants.TWO, user.getPassword());
			preparedStmt.setString(Constants.THREE, user.getFullName());
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FIVE, user.getEmailId());
			preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.SEVEN, user.getImageName());
			preparedStmt.setBinaryStream(Constants.EIGHT, user.getImage());
			preparedStmt.setString(Constants.NINE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TEN, user.getDepartment());
			preparedStmt.setString(Constants.ELEVEN, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWELVE, user.getActiveFlag());
			preparedStmt.setString(Constants.THIRTEEN, user.getSectionPosition());
			preparedStmt.setString(Constants.FOURTEEN, user.getSectionVisibility());
			preparedStmt.setInt(Constants.FIFTEEN, user.getEncryptFullName());
			preparedStmt.setInt(Constants.SIXTEEN, user.getEncryptEmailId());
			preparedStmt.setInt(Constants.SEVENTEEN, user.getEncryptDepartment());
			preparedStmt.setInt(Constants.EIGHTEEN, user.getEncryptImage());
			
			preparedStmt.executeUpdate();

			resultSet = preparedStmt.getGeneratedKeys();

			if (log.isTraceEnabled()) {
				log.trace("getUsers || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.INSERT_USER));
			}

			if (resultSet != null && resultSet.next()) {
				userId = resultSet.getLong(1);
			}

		} catch (SQLException e) {
			log.error("addUser || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_CREATED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addUser ||  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addUser ||  " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addUser ||  " + Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("addUser || " + Constants.LOG_CONNECTION_CLOSE);
			}

		}
		if (log.isTraceEnabled()) {
			log.trace("addUser ||  generated user id : " + userId.toString()
					+ " || exit ");
		}
		return userId;
	}

	/**
	 * @method : updateUser
	 * @description : to update a profile
	 * @param user
	 * @return
	 * @throws RepoproException
	 */
	public void updateUser(User user, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateUser ||" + user.toString() + " || begin");
		}

		PreparedStatement preparedStmt = null;
		Connection conn1 = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("updateUser || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_USER_BY_ID));

			preparedStmt.setString(Constants.ONE, user.getFullName());
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, user.getEmailId());
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FIVE, user.getDepartment());
			preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.SEVEN, user.getImageName());
			preparedStmt.setBinaryStream(Constants.EIGHT, user.getImage());
			preparedStmt.setString(Constants.NINE, CommonUtils.encryptionKey);
			preparedStmt.setInt(Constants.TEN, user.getEncryptFullName());
			preparedStmt.setInt(Constants.ELEVEN, user.getEncryptEmailId());
			preparedStmt.setInt(Constants.TWELVE, user.getEncryptDepartment());
			preparedStmt.setInt(Constants.THIRTEEN, user.getEncryptImage());
			preparedStmt.setLong(Constants.FOURTEEN, user.getUserId());

			int result = preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateUser || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_USER_BY_ID));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("updateUser || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_UPDATED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("updateUser ||  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("updateUser ||  " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("updateUser ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("updateUser || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.trace("updateUser ||  exit");
	}


	/**
	 * @method : changePassword
	 * @description : to update user's password
	 * @param user
	 * @return
	 * @throws RepoproException
	 */
	public void changePassword(User userList, Connection conn)
			throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("changePassword || begin with user : "
					+ userList.toString());
		}

		PreparedStatement preparedStmt = null;
		Connection conn1 = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("changePassword || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.UPDATE_USER_PASSWORD_BY_ID));

			preparedStmt.setString(Constants.ONE, userList.getNewPassword());
			preparedStmt.setLong(Constants.TWO, userList.getUserId());

			int result = preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("changePassword || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_USER_PASSWORD_BY_ID));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("changePassword || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_PASSWORD_NOT_UPDATED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("changePassword ||  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("changePassword ||  "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("changePassword ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("changePassword || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.trace("changePassword || exit");
	}

	/**
	 * @method : deleteUser
	 * @description : to delete a profile
	 * @param user
	 * @return
	 * @throws RepoproException
	 */
	public void deleteUser(User user, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteUser || begin with user : " + user.toString());
		}

		PreparedStatement preparedStmt = null;
		Connection conn1 = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteUser || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_USER_BY_NAME));

			preparedStmt.setString(Constants.ONE, user.getActiveFlag());
			preparedStmt.setString(Constants.TWO, user.getUserName());

			int result = preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("deleteUser || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_USER_BY_NAME));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("deleteUser || " + Constants.LOG_DELETE_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_DELETED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("deleteUser ||  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (RepoproException e) {
			e.printStackTrace();
			log.error("deleteUser ||  " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("deleteUser ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("deleteUser || " + Constants.LOG_CONNECTION_CLOSE);
			}

		}
		log.trace("deleteUser || exit");
	}

	/**
	 * @method : getUserByUserId
	 * @description : to get a user by id
	 * @param userId requested user
	 * @return ApiUser
	 * @throws RepoproException
	 */
	public User getUserByUserId(Long userId, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getUserByUserId || begin with userId : "
					+ userId.toString());
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		User user = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USER_BY_ID));

			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			preparedStmt.setLong(Constants.FIVE, userId);

			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_USER_BY_ID));
			}
			while (resultSet.next()) {
				user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setImageName(resultSet.getString("image_name"));
				user.setImage(resultSet.getBinaryStream("decrypted_image"));
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setAdminMessageFlag(resultSet.getInt("admin_message_flag"));
				user.setLeaderBoardFlag(resultSet.getInt("leader_board_flag"));
				user.setRecentActivityFlag(resultSet.getInt("recent_activity_flag"));
				user.setUserDetailFlag(resultSet.getInt("user_detail_flag"));
				user.setQuickStatFlag(resultSet.getInt("quick_stat_flag"));
				user.setPassword(resultSet.getString("password"));
				user.setSectionPosition(resultSet.getString("section_name_position"));
				user.setSectionVisibility(resultSet.getString("section_name_visibility"));
				user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
				user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
				user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
				user.setEncryptImage(resultSet.getInt("encrypt_image"));
				if (log.isTraceEnabled()) {
					log.trace("getUserByUserId || user : " + user.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getUserByUserId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_FOUND));

		} catch (IOException e) {
			log.error("getUserByUserId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("getUserByUserId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("deleteUser ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		log.trace("getUserByUserId || exit");
		
		return user;
	}
	/**
	 * 
	 * @param userId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<GroupDetails> retAllUserGroupsMappedWithUserId(Long userId, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getUserByUserId || begin with userId : " + userId.toString());
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		List<GroupDetails> groupDetailsList = new ArrayList<GroupDetails>();
		GroupDetails groupDetails = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retAllUserGroupsMappedWithUserId || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_ALL_USER_GROUPS_BY_USER_ID));

			preparedStmt.setLong(Constants.ONE, userId);

			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retAllUserGroupsMappedWithUserId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_USER_GROUPS_BY_USER_ID));
			}

			while (resultSet.next()) {
				groupDetails = new GroupDetails();
				groupDetails.setGroupId(resultSet.getLong("group_id"));
				groupDetails.setGroupName(resultSet.getString("group_name"));
				groupDetails.setDescription(resultSet.getString("description"));

				groupDetailsList.add(groupDetails);
				if (log.isTraceEnabled()) {
					log.trace("retAllUserGroupsMappedWithUserId || groupDetails : " + groupDetails.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retAllUserGroupsMappedWithUserId || groupDetailsList : " + groupDetailsList.toString());
			}

		} catch (SQLException e) {
			log.error("retAllUserGroupsMappedWithUserId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_DATA_NOT_FOUND));

		} catch (IOException e) {
			log.error("retAllUserGroupsMappedWithUserId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("retAllUserGroupsMappedWithUserId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("retAllUserGroupsMappedWithUserId ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("retAllUserGroupsMappedWithUserId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("retAllUserGroupsMappedWithUserId || exit");

		return groupDetailsList;
	}

	
	/**
	 * @method : addUserGroup
	 * @param userId
	 * @param addedGroups
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<User> addUserGroup(Long userId,String[] addedGroups,
			Connection conn) throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("addUserGroup ||where userId:"
					+ userId + ",associatedGroupIds:"
					+ addedGroups.toString()
					+ "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		PreparedStatement preparedStmt1 = null;
		ResultSet rs = null;

		List<User> userList = new ArrayList<User>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addUserGroup ||" + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt1 = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_USER_GROUPS_DATA));
			preparedStmt1.setLong(Constants.ONE,userId);
			preparedStmt1.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("addUserGroup ||"+ PropertyFileReader.getInstance().getValue(Constants.DELETE_USER_GROUPS_DATA));
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_USER_GROUPS_DATA));
			if(addedGroups.length!=0){
				for (int i = 0; i < addedGroups.length; i++) {

					Long addGroupId = Long.parseLong(addedGroups[i]);
					preparedStmt.setLong(Constants.ONE, userId);
					preparedStmt.setLong(Constants.TWO, addGroupId);
					preparedStmt.execute();
					if (log.isTraceEnabled()) {
						log.trace("addUserGroup ||"+ PropertyFileReader.getInstance().getValue(Constants.ADD_USER_GROUPS_DATA));
					}
					User user = new User();
					user.setUserId(userId);
					user.setGroupId(addGroupId);
					rs = preparedStmt.getGeneratedKeys();
					if (rs != null && rs.next()) {
						user.setUserGroupId(rs.getLong(1));
					}
					userList.add(user);

					if (log.isTraceEnabled()) {
						log.trace("addUserGroup ||" + user.toString());
					}
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("addUserGroup ||" + userList.toString());
			}
		} catch (SQLException e) {
			log.error("addUserGroup ||" + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INSERT_USER_GROUP_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addUserGroup ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addUserGroup ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addUserGroup ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt1);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addUserGroup ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("addUserGroup || End");
		}
		return userList;
	}


	/**
	 * @method updateActiveFlag
	 * @description to update active flag of user
	 * @param user
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateActiveFlag(User user, Connection conn)
			throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("updateActiveFlag || where userId:"+user.getUserId()+" ActiveFlag:"
					+ user.getActiveFlag() + " || Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("updateActiveFlag ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_USER_ACTIVE_FLAG));
			preparedStmt.setString(Constants.ONE,user.getActiveFlag());
			preparedStmt.setLong(Constants.TWO, user.getUserId());
			preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateActiveFlag ||"+ PropertyFileReader.getInstance().getValue(Constants.UPDATE_USER_ACTIVE_FLAG));
			}


		} catch (SQLException e) {
			log.error("updateActiveFlag ||" + Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.UPDATE_USER_ACTIVE_FLAG_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("updateActiveFlag ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("updateActiveFlag ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("updateActiveFlag ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("updateActiveFlag ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateActiveFlag || End");
		}
	}


	/**
	 * @method retProfileForUserName
	 * @description to get profile for username
	 * @param username
	 * @return user
	 * @throws RepoproException
	 */
	public User retProfileForUserName(String username ,Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("retProfileForUserName || begin with username : "
					+ username.toString());
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		User user = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retProfileForUserName || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USER_BY_USERNAME));

			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FIVE, username);

			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retProfileForUserName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_USER_BY_USERNAME));
			}

			while (resultSet.next()) {
				user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setPassword(resultSet.getString("password"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setImageName(resultSet.getString("image_name"));
				user.setImage(resultSet.getBinaryStream("decrypted_image"));
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
				user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
				user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
				user.setEncryptImage(resultSet.getInt("encrypt_image"));
				
				if (log.isTraceEnabled()) {
					log.trace("retProfileForUserName || user : " + user.toString());
				}
			}

		} catch (SQLException e) {
			log.error("retProfileForUserName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_BY_NAME_NOT_FOUND));

		} catch (IOException e) {
			log.error("retProfileForUserName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("retProfileForUserName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("retProfileForUserName ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("retProfileForUserName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("retProfileForUserName || exit");

		return user;
	}
	
	public User retProfiledetailsForUserName(String username ,Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("retProfiledetailsForUserName || begin with username : "
					+ username.toString());
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		User user = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retProfiledetailsForUserName || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USER_BY_USERNAME));

			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FIVE, username);

			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retProfiledetailsForUserName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_USER_BY_USERNAME));
			}

			while (resultSet.next()) {
				user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setPassword(resultSet.getString("password"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setImageName(resultSet.getString("image_name"));
				user.setImage(resultSet.getBinaryStream("decrypted_image"));
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setLoginAttempt(resultSet.getInt("loginAttempt"));
				user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
				user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
				user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
				user.setEncryptImage(resultSet.getInt("encrypt_image"));
				if (log.isTraceEnabled()) {
					log.trace("retProfiledetailsForUserName || user : " + user.toString());
				}
			}

		} catch (SQLException e) {
			log.error("retProfiledetailsForUserName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_BY_NAME_NOT_FOUND));

		} catch (IOException e) {
			log.error("retProfiledetailsForUserName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("retProfiledetailsForUserName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("retProfiledetailsForUserName ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("retProfiledetailsForUserName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("retProfiledetailsForUserName || exit");

		return user;
	}

	/**
	 * @method retAllUsers
	 * @description to get retAll user names
	 * @param 
	 * @return List<userName>
	 * @throws RepoproException
	 */
	public List<String> retAllUsers(Connection conn) throws RepoproException {

		log.trace("retAllUsers || begin");

		List<String> userName = new ArrayList<String>();
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		User user = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retAllUsers || " + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_USERNAMES));
			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retAllUsers || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_USERNAMES));
			}

			while (resultSet.next()) {
				user = new User();

				user.setUserName(resultSet.getString("user_name"));

				/*	user.setUserId(resultSet.getLong("user_id"));
				user.setFullName(resultSet.getString("full_name"));
				user.setEmailId(resultSet.getString("email_id"));
				user.setImageName(resultSet.getString("image_name"));
				if (imageFlag) {
					user.setImage(resultSet.getBinaryStream("image"));
				}
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("department"));*/

				userName.add(user.getUserName());

				if (log.isTraceEnabled()) {
					log.trace("retAllUsers || returning resultset  : "
							+ user.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retAllUsers || returning resultset  : "
						+ userName.toString());
			}


		} catch (SQLException e) {
			log.error("retAllUsers || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_FOUND));

		} catch (IOException e) {
			log.error("retAllUsers || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("retAllUsers || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("retAllUsers ||  " + Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("retAllUsers || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("retAllUsers || exit");
		return userName;
	}


	/**
	 * @method retProfileForUserNameAndPwd
	 * @description to get profile details 
	 * @param username ,Password
	 * @return user
	 * @throws RepoproException
	 */
	public User retProfileForUserNameAndPwd(String username,
			String Password, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("retProfileForUserNameAndPwd || begin with username : "
					+ username.toString());
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		User user = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retProfileForUserNameAndPwd || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USER_BY_USERNAME_AND_PASSWORD));

			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FIVE, username);
			preparedStmt.setString(Constants.SIX, Password);

			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retProfileForUserName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_USER_BY_USERNAME_AND_PASSWORD));
			}

			while (resultSet.next()) {
				user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setPassword(resultSet.getString("password"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setImageName(resultSet.getString("image_name"));
				user.setImage(resultSet.getBinaryStream("decrypted_image"));
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setLoginAttempt(resultSet.getInt("loginAttempt"));

				if (log.isTraceEnabled()) {
					log.trace("retProfileForUserNameAndPwd || user : " + user.toString());
				}
			}

		} catch (SQLException e) {
			log.error("retProfileForUserNameAndPwd || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_BY_NAME_AND_PASSWORD_NOT_FOUND));

		} catch (IOException e) {
			log.error("retProfileForUserNameAndPwd || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("retProfileForUserNameAndPwd || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("retProfileForUserNameAndPwd ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("retProfileForUserNameAndPwd || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("retProfileForUserNameAndPwd || exit");

		return user;
	}



	/**
	 * @method retFunctionsForUserName
	 * @description to retrieve function description for username
	 * @param username
	 * @return Function description ForUserName
	 * @throws RepoproException
	 */
	public List<String> retFunctionsForUserName(String username,Connection conn)throws RepoproException {

		log.trace("retFunctionsForUserName || begin with username "+username);

		List<String> fun_desc = new ArrayList<String>();
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		User user = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retFunctionsForUserName || " + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_FUNCTIONS_FOR_USER_NAME));
			preparedStmt.setString(Constants.ONE, username);
			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retFunctionsForUserName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_FUNCTIONS_FOR_USER_NAME));
			}

			while (resultSet.next()) {
				user = new User();

				user.setFunctionDescription(resultSet.getString("function_description"));
				fun_desc.add(user.getFunctionDescription());

				if (log.isTraceEnabled()) {
					log.trace("retFunctionsForUserName || returning resultset  : "
							+ user.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retFunctionsForUserName || returning resultset  : "
						+ fun_desc.toString());
			}


		} catch (SQLException e) {
			log.error("retFunctionsForUserName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_FUNCTIONS_FOR_USER_NAME_NOT_FOUND));

		} catch (IOException e) {
			log.error("retFunctionsForUserName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("retFunctionsForUserName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("retFunctionsForUserName ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("retFunctionsForUserName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("retFunctionsForUserName || exit");
		return fun_desc;
	}


	/**
	 * @method updateFlagsForDynamicWidgets
	 * @description to update flag values for dynamic widgets
	 * @param user
	 * @return 
	 * @throws RepoproException
	 */
	public void updateDynamicWidgets(User user , Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateDynamicWidgets || where userId:" + user.getUserId()
					+ " || Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("updateDynamicWidgets ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.UPDATE_DYNAMIC_WIDGETS));

			preparedStmt.setInt(Constants.ONE, user.getRecentActivityFlag());
			preparedStmt.setInt(Constants.TWO, user.getAdminMessageFlag());
			preparedStmt.setInt(Constants.THREE, user.getLeaderBoardFlag());
			preparedStmt.setInt(Constants.FOUR, user.getUserDetailFlag());
			preparedStmt.setInt(Constants.FIVE, user.getQuickStatFlag());
			preparedStmt.setLong(Constants.SIX, user.getUserId());

			preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateDynamicWidgets ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_DYNAMIC_WIDGETS));
			}

		} catch (SQLException e) {
			log.error("updateDynamicWidgets ||" + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.UPDATE_DYNAMIC_WIDGETS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("updateDynamicWidgets ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("updateDynamicWidgets ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("updateDynamicWidgets ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("updateDynamicWidgets ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("updateDynamicWidgets || End");
		}
	}

	/**
	 * @method getAllActiveUser
	 * @description to get all active users
	 * @param connection
	 * @return list of all active users
	 * @throws RepoproException
	 */
	public List<User> getAllActiveUser(Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllActiveUser || Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		User user = null;
		List<User> userList = new ArrayList<User>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllActiveUser ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ALL_USERNAMES));

			rs = preparedStmt.executeQuery();

			while(rs.next()){
				user = new User();
				user.setUserId(rs.getLong("user_id"));
				user.setUserName(rs.getString("user_name"));
				user.setFullName(rs.getString("full_name"));
				user.setEmailId(rs.getString("email_id"));
				user.setImageName(rs.getString("image_name"));
				user.setEncryptFullName(rs.getInt("encrypt_full_name"));
				userList.add(user);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllActiveUser ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_USERNAMES));
			}

		} catch (SQLException e) {
			log.error("getAllActiveUser ||" + Constants.GET_ALL_USERNAMES + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.USER_DATA_NOT_FOUND));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getAllActiveUser ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllActiveUser ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAllActiveUser || End");
		}
		return userList;
	}
	
	
	/**
	 * @method : updateSubscriptionFlag
	 * @param userId
	 * @param flag
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateSubscriptionFlag(Long userId, int flag, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("updateSubscriptionFlag || Begin with userId : "+ userId +" \t flag : "+ flag);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("updateSubscriptionFlag || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_USER_SUBSCRIPTION_FLAG));
			
			pstmt.setInt(Constants.ONE, flag);
			pstmt.setLong(Constants.TWO, userId);
			
			
			if (log.isTraceEnabled()) {
				log.trace("updateSubscriptionFlag || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_USER_SUBSCRIPTION_FLAG));
			}

			pstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			log.error("updateSubscriptionFlag || " + Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.UPDATE_USER_SUBSCRIPTION_FLAG_FAILED));
		} catch (IOException e) {
			log.error("updateSubscriptionFlag || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateSubscriptionFlag || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateSubscriptionFlag || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateSubscriptionFlag || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("updateSubscriptionFlag || End");
		}
		
		
	}
	
	
	/**
	 * @method : updateUserPassword
	 * @description : to update password for a profile
	 * @param user
	 * @return
	 * @throws RepoproException
	 */
	public void updateUserPassword(User user, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateUserPassword ||" + user.toString() + " || begin");
		}

		PreparedStatement preparedStmt = null;
		Connection conn1 = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("updateUserPassword || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_USER_PASSWORD_BY_USER_ID));

			preparedStmt.setString(Constants.ONE, user.getPassword());
			preparedStmt.setLong(Constants.TWO, user.getUserId());

			int result = preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateUserPassword || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_USER_PASSWORD_BY_USER_ID));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("updateUserPassword || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_UPDATED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("updateUserPassword ||  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("updateUserPassword ||  " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("updateUserPassword ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("updateUserPassword || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.trace("updateUserPassword ||  exit");
	}


	public void  updateFailAttempts(String userName, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateFailAttempts || for userName :" + userName + " || begin");
		}
		ResultSet rs = null;
		PreparedStatement preparedStmt = null;
		PreparedStatement preparedStmt1 = null;
		Connection conn1 = null;
		int attemptCount = 0;
		//String message = null ;
		int accountLockFlag = 0;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("updateFailAttempts || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ATTEMPTS_COUNT));

			preparedStmt.setString(Constants.ONE,userName );
			
			rs = preparedStmt.executeQuery();
			while (rs.next()) {
				attemptCount = rs.getInt("loginAttempt");
				accountLockFlag = rs.getInt("lockAccount_flag");
				
			}
			
			preparedStmt1 = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_USER_ATTEMPT));
			if(attemptCount < 2){
				preparedStmt1.setInt(Constants.ONE, attemptCount+1);
				preparedStmt1.setInt(Constants.TWO, accountLockFlag);
				preparedStmt1.setString(Constants.THREE, userName);
				preparedStmt1.executeUpdate();
			}else if(attemptCount == 2){
				preparedStmt1.setInt(Constants.ONE, attemptCount+1);
				preparedStmt1.setInt(Constants.TWO, 0);
				preparedStmt1.setString(Constants.THREE, userName);
				preparedStmt1.executeUpdate();
				//message = "account_locked";
			}/*else if(attemptCount == 3){
				message = "account_locked";
			}*/
				

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("updateFailAttempts || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_ATTEMPT_NOT_UPDATED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("updateFailAttempts ||  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("updateFailAttempts ||  " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("updateFailAttempts ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closePreparedStatement(preparedStmt1);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("updateFailAttempts || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.trace("updateFailAttempts : exit");
		
	}


	public void resetFailAttempts(String userName, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("resetFailAttempts || for userName :" + userName
					+ " || begin");
		}

		PreparedStatement preparedStmt = null;
		Connection conn1 = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("resetFailAttempts || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_USER_ATTEMPT));
			preparedStmt.setInt(Constants.ONE, 0);
			preparedStmt.setInt(Constants.TWO, 1);
			preparedStmt.setString(Constants.THREE, userName);

			preparedStmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("resetFailAttempts || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_ATTEMPT_NOT_UPDATED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("resetFailAttempts ||  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("resetFailAttempts ||  "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("resetFailAttempts ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("resetFailAttempts || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.trace("resetFailAttempts :  exit");
	}
	/**
	 * @method : getUserByUserId
	 * @description : to get a user by id
	 * @param userName of requested user
	 * @return userId
	 * @throws RepoproException
	 */
	public User getUserIdByUserName(String userName, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getUserIdByUserName || begin with userName : "
					+ userName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		User user = new User();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getUserIdByUserName || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USER_BY_NAME));

			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, userName);

			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getUserByUserName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_USER_BY_NAME));
			}

			/*if (!resultSet.isBeforeFirst()) {
				log.error("getUserIdByUserName || No data is fetched from DB and DataNotFoundException is"
						+ " thrown");
				throw new RepoproException(
						MessageUtil.getMessage(Constants.USER_NOT_FOUND));
			}*/
			while (resultSet.next()) {
				user.setUserId(resultSet.getLong("user_id"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
								
				if(resultSet.getString("password").equalsIgnoreCase("")){
					user.setPassword(resultSet.getString("password"));
				}
				if (log.isTraceEnabled()) {
					log.trace("getUserByUserName || user Id: " + user.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getUserByUserId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_FOUND));

		} catch (IOException e) {
			log.error("getUserByUserId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("getUserByUserId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("getUserByUserId ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getUserByUserId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		log.trace("getUserByUserId || exit");
		
		return user;
	}
	
	/**
	 * @param userName 
	 * @method : getFlilteredUsersForGrid
	 * @description : to get all filtered users for grid
	 * @param
	 * @return List<User>
	 * @throws RepoproException
	 */
	public List<User> getFlilteredUsersForGrid(String userName, String searchString, Long from, Connection conn)
			throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("getFlilteredUsersForGrid || begin :");
		}
		List<User> usersListForGrid = new ArrayList<User>();
		Connection conn1 = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStmt = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getFlilteredUsersForGrid || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_FILTERED_USERS_FOR_GRID));
			
			if (log.isTraceEnabled()) {
				log.trace("getFlilteredUsersForGrid || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_FILTERED_USERS_FOR_GRID));
			}
			
			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FIVE,searchString);
			preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.SEVEN,searchString);
			preparedStmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.NINE,searchString);
			preparedStmt.setString(Constants.TEN, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.ELEVEN,searchString);
			preparedStmt.setLong(Constants.TWELVE, from);
			
			resultSet = preparedStmt.executeQuery();

			if(userName.equalsIgnoreCase("admin")){
				while (resultSet.next()) {
				User user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setImageName(resultSet.getString("image_name"));
				user.setImage(resultSet.getBinaryStream("decrypted_image"));
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setPassword(resultSet.getString("password"));
				user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
				user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
				user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
				user.setEncryptImage(resultSet.getInt("encrypt_image"));
				
				  int lock = resultSet.getInt("lockAccount_flag");
				     if (lock == 1){
				    	 user.setLockStatus("unlock");
				     }else if(lock ==0){
				    	 user.setLockStatus("lock"); 
				     }
				usersListForGrid.add(user);

				if (log.isTraceEnabled()) {
					log.trace("getFlilteredUsersForGrid || " + user.toString());
				}
			}
			}else{
				
				while (resultSet.next()) {
				User user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setImageName(resultSet.getString("image_name"));
				user.setImage(resultSet.getBinaryStream("decrypted_image"));
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setPassword(resultSet.getString("password"));
				user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
				user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
				user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
				user.setEncryptImage(resultSet.getInt("encrypt_image"));
				
				usersListForGrid.add(user);

				if (log.isTraceEnabled()) {
					log.trace("getFlilteredUsersForGrid || " + user.toString());
				}
			}
			}

		} catch (SQLException e) {
			log.error("getFlilteredUsersForGrid || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_FOUND));
		} catch (IOException e) {
			log.error("getFlilteredUsersForGrid || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getFlilteredUsersForGrid || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getFlilteredUsersForGrid || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getFlilteredUsersForGrid || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("getFlilteredUsersForGrid || exit");
		return usersListForGrid;
	}
	
	public void addUsertoDefaultgroup(Long userId,
			Connection conn) throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("addUsertoDefaultgroup ||where userId : "
					+ userId + "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		PreparedStatement preparedStmt1 = null;
		ResultSet rs = null;

	
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addUsertoDefaultgroup ||" + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt1 = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_USER_FROM_DEFAULT_GROUP));
			preparedStmt1.setString(Constants.ONE,"EveryOne");
			rs = preparedStmt1.executeQuery();
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_USER_GROUPS_DATA));
			while (rs.next()) {
			
				Long addGroupId = rs.getLong("group_id");
				preparedStmt.setLong(Constants.ONE, userId);
				preparedStmt.setLong(Constants.TWO, addGroupId);
				preparedStmt.execute();
				if (log.isTraceEnabled()) {
					log.trace("addUserGroup ||"+ PropertyFileReader.getInstance().getValue(Constants.ADD_USER_GROUPS_DATA));
				}
				//User user = new User();
				//user.setUserId(userId);
				//user.setGroupId(addGroupId);
				

				/*if (log.isTraceEnabled()) {
					log.trace("addUsertoDefaultgroup ||" + user.toString());
				}*/
				
			}
			conn.commit();
			if (log.isTraceEnabled()) {
				log.trace("addUsertoDefaultgroup ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_USER_FROM_DEFAULT_GROUP));
			}

		
		} catch (SQLException e) {
			log.error("addUsertoDefaultgroup ||" + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INSERT_USER_GROUP_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addUsertoDefaultgroup ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addUsertoDefaultgroup ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addUsertoDefaultgroup ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt1);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addUsertoDefaultgroup ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("addUsertoDefaultgroup || End");
		}
		
	}
	
	/**
	 * @method insertTokenDetails
	 * @description to insert token for logged in user
	 * @param token
	 * @throws DataNotFoundException
	 */
	public void insertTokenDetails(String token,Long userId,Timestamp timestamp,Connection conn) {
		if (log.isDebugEnabled()) {
			log.debug("insertTokenDetails : "+userId+" Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		try {
			if(conn == null){				
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isInfoEnabled()) {
				log.info("insertTokenDetails : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.INSERT_TOKEN_DETAILS));
			preparedStmt.setString(Constants.ONE, token);
			preparedStmt.setLong(Constants.TWO, userId);
			
			int result = preparedStmt.executeUpdate();
			conn.commit();
	/*		if (result == 0) {
				log.error("updateUserAccountDetails : apiName is not updated and throws"
						+ " UpdateContentException");
				throw new UpdateContentException(
						MessageUtil
						.getMessage(Constants.USER_ACCOUNT_DETAILS_NOT_UPDATED));
			}*/
			
		}catch (SQLException e) {
			log.error("insertTokenDetails : " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(
					MessageUtil.getMessage(Constants.USER_ACCOUNT_DETAILS_NOT_UPDATED));*/
		}catch (IOException e) {
			log.error("insertTokenDetails :" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} catch (PropertyVetoException e) {
			log.error("insertTokenDetails :" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} catch (Exception e) {
			log.error("insertTokenDetails :" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} finally {
			if (log.isInfoEnabled()) {
				log.info("insertTokenDetails : " + Constants.LOG_CONNECTION_CLOSE);
			}			
			DBConnection.closeDbConnection(conn);
			try {
				if(preparedStmt != null){
					preparedStmt.close();
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		if (log.isDebugEnabled()) {
			log.debug("insertTokenDetails by userId : Exit");
		}
	}
	
	public void insertOAuthTokenDetails(String token,Long userId,Timestamp timestamp,Long expiry_in,Connection conn) {
		if (log.isDebugEnabled()) {
			log.debug("insertOAuthTokenDetails : "+userId+" Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		try {
			if(conn == null){				
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isInfoEnabled()) {
				log.info("insertOAuthTokenDetails : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.INSERT_OAUTH_TOKEN_DETAILS));
			preparedStmt.setString(Constants.ONE, token);
			preparedStmt.setLong(Constants.TWO, userId);
			preparedStmt.setTimestamp(Constants.THREE, timestamp);
			preparedStmt.setLong(Constants.FOUR,expiry_in);
			
			int result = preparedStmt.executeUpdate();
			conn.commit();
	/*		if (result == 0) {
				log.error("updateUserAccountDetails : apiName is not updated and throws"
						+ " UpdateContentException");
				throw new UpdateContentException(
						MessageUtil
						.getMessage(Constants.USER_ACCOUNT_DETAILS_NOT_UPDATED));
			}*/
			
		}catch (SQLException e) {
			log.error("insertOAuthTokenDetails : " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(
					MessageUtil.getMessage(Constants.USER_ACCOUNT_DETAILS_NOT_UPDATED));*/
		}catch (IOException e) {
			log.error("insertOAuthTokenDetails :" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} catch (PropertyVetoException e) {
			log.error("insertOAuthTokenDetails :" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} catch (Exception e) {
			log.error("insertOAuthTokenDetails :" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} finally {
			if (log.isInfoEnabled()) {
				log.info("insertOAuthTokenDetails : " + Constants.LOG_CONNECTION_CLOSE);
			}			
			DBConnection.closeDbConnection(conn);
			try {
				if(preparedStmt != null){
					preparedStmt.close();
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		if (log.isDebugEnabled()) {
			log.debug("insertOAuthTokenDetails by userId : Exit");
		}
	}
	
	/**
	 * @method deleteTokenDetails
	 * @description to delete logged out users token from db
	 * @param token
	 * @throws DataNotFoundException
	 */
	public void deleteTokenDetails(String token,Connection conn) {
		if (log.isDebugEnabled()) {
			log.debug("deleteTokenDetails : "+token+" Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		try {
			if(conn == null){				
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isInfoEnabled()) {
				log.info("deleteTokenDetails : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_TOKEN_DETAILS));
			preparedStmt.setString(Constants.ONE, token);
			
			int result = preparedStmt.executeUpdate();
			conn.commit();
	/*		if (result == 0) {
				log.error("updateUserAccountDetails : apiName is not updated and throws"
						+ " UpdateContentException");
				throw new UpdateContentException(
						MessageUtil
						.getMessage(Constants.USER_ACCOUNT_DETAILS_NOT_UPDATED));
			}*/
			
		}catch (SQLException e) {
			log.error("deleteTokenDetails : " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(
					MessageUtil.getMessage(Constants.USER_ACCOUNT_DETAILS_NOT_UPDATED));*/
		}catch (IOException e) {
			log.error("deleteTokenDetails :" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} catch (PropertyVetoException e) {
			log.error("deleteTokenDetails :" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} catch (Exception e) {
			log.error("deleteTokenDetails :" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} finally {
			if (log.isInfoEnabled()) {
				log.info("deleteTokenDetails : " + Constants.LOG_CONNECTION_CLOSE);
			}			
			DBConnection.closeDbConnection(conn);
			try {
				if(preparedStmt != null){
					preparedStmt.close();
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		if (log.isDebugEnabled()) {
			log.debug("deleteTokenDetails: Exit");
		}
	}
	
	
	public void deleteOAuthTokenDetails(String token,Connection conn) {
		if (log.isDebugEnabled()) {
			log.debug("deleteOAuthTokenDetails : "+token+" Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		try {
			if(conn == null){				
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isInfoEnabled()) {
				log.info("deleteOAuthTokenDetails : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_OAUTH_TOKEN_DETAILS));
			preparedStmt.setString(Constants.ONE, token);
			
			int result = preparedStmt.executeUpdate();
			conn.commit();
	/*		if (result == 0) {
				log.error("updateUserAccountDetails : apiName is not updated and throws"
						+ " UpdateContentException");
				throw new UpdateContentException(
						MessageUtil
						.getMessage(Constants.USER_ACCOUNT_DETAILS_NOT_UPDATED));
			}*/
			
		}catch (SQLException e) {
			log.error("deleteOAuthTokenDetails : " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(
					MessageUtil.getMessage(Constants.USER_ACCOUNT_DETAILS_NOT_UPDATED));*/
		}catch (IOException e) {
			log.error("deleteOAuthTokenDetails :" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} catch (PropertyVetoException e) {
			log.error("deleteOAuthTokenDetails :" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} catch (Exception e) {
			log.error("deleteOAuthTokenDetails :" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			/*throw new UpdateContentException(e.getMessage());*/
		} finally {
			if (log.isInfoEnabled()) {
				log.info("deleteOAuthTokenDetails : " + Constants.LOG_CONNECTION_CLOSE);
			}			
			DBConnection.closeDbConnection(conn);
			try {
				if(preparedStmt != null){
					preparedStmt.close();
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		if (log.isDebugEnabled()) {
			log.debug("deleteOAuthTokenDetails: Exit");
		}
	}
	
	/**
	 * @method : getUserDetailsByToken
	 * @description : to get a user by token
	 * @param token
	 *            requested user's details
	 * @return User
	 * @throws RepoproException
	 */
	public User getUserDetailsByToken(String token,Connection conn) throws RepoproException{
		if (log.isDebugEnabled()) {
			log.debug("getUserDetailsByToken : begin with userId : "+token);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		User user = null;
		try {
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isInfoEnabled()) {
				log.info("getUserDetailsByToken : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USER_DETAILS_BY_TOKEN));
			preparedStmt.setString(Constants.ONE, token);
			resultSet = preparedStmt.executeQuery();

			/*if (!resultSet.isBeforeFirst()) {
				log.error("getUserDetailsByToken : No data is fetched from DB and DataNotFoundException is"
						+ " thrown");
				throw new  RepoproException(
						MessageUtil.getMessage(Constants.USER_NOT_FOUND));
			}*/
			while (resultSet.next()) {
				user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				
			}
			
		} catch (SQLException e) {
			log.error("getUserDetailsByToken : " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_FOUND));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getUserDetailsByToken :  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getUserDetailsByToken :  " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getUserDetailsByToken :  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isInfoEnabled()) {
				log.info("getUserDetailsByToken : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(preparedStmt != null){
					preparedStmt.close();
				}
				if(resultSet != null){
					resultSet.close();  
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (log.isDebugEnabled()) {
			if(user == null){
				log.debug("getUserDetailsByToken : Resultset is null");
				}else{
			log.debug("getUserDetailsByToken :"+user.toString()+" exit");
		}}
		return user;
	}
	
	
	public User getUserDetailsByOauthToken(String token,Connection conn) throws RepoproException{
		if (log.isDebugEnabled()) {
			log.debug("getUserDetailsByOauthToken : begin with userId : "+token);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		User user = null;
		try {
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isInfoEnabled()) {
				log.info("getUserDetailsByOauthToken : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USER_DETAILS_BY_OAUTH_TOKEN));
			preparedStmt.setString(Constants.ONE, token);
			resultSet = preparedStmt.executeQuery();

			/*if (!resultSet.isBeforeFirst()) {
				log.error("getUserDetailsByToken : No data is fetched from DB and DataNotFoundException is"
						+ " thrown");
				throw new  RepoproException(
						MessageUtil.getMessage(Constants.USER_NOT_FOUND));
			}*/
			while (resultSet.next()) {
				user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setTimestamp(resultSet.getTimestamp("timestamp"));
			}
			
		} catch (SQLException e) {
			log.error("getUserDetailsByOauthToken : " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_FOUND));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getUserDetailsByOauthToken :  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getUserDetailsByOauthToken :  " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getUserDetailsByOauthToken :  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isInfoEnabled()) {
				log.info("getUserDetailsByOauthToken : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(preparedStmt != null){
					preparedStmt.close();
				}
				if(resultSet != null){
					resultSet.close();  
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (log.isDebugEnabled()) {
			if(user == null){
				log.debug("getUserDetailsByOauthToken : Resultset is null");
				}else{
			log.debug("getUserDetailsByOauthToken :"+user.toString()+" exit");
		}}
		return user;
	}
	
	/**
	 * @method : getUsersBySearch
	 * @description : to get all users
	 * @param
	 * @return List<User>
	 * @throws RepoproException
	 */
	public List<User> getUsersBySearch(boolean imageFlag,String searchStr,Connection conn) throws RepoproException {

		log.trace("getUsersBySearch || begin");

		List<User> usersList = new ArrayList<User>();
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getUsersBySearch || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ALL_FILTERED_USERS_FOR_GRID_EXPORT));
			
			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FIVE,searchStr);
			preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.SEVEN,searchStr);
			preparedStmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.NINE,searchStr);
			preparedStmt.setString(Constants.TEN, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.ELEVEN,searchStr);
			
			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getUsersBySearch || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_FILTERED_USERS_FOR_GRID_EXPORT));
			}

			while (resultSet.next()) {
				User user = new User();
				user.setUserId(resultSet.getLong("user_id"));
				user.setUserName(resultSet.getString("user_name"));
				user.setFullName(resultSet.getString("decrypted_full_name"));
				user.setEmailId(resultSet.getString("decrypted_email_id"));
				user.setImageName(resultSet.getString("image_name"));
				if (imageFlag) {
					user.setImage(resultSet.getBinaryStream("decrypted_image"));
				}
				user.setRoleId(resultSet.getLong("role_id"));
				user.setSubscribe(resultSet.getBoolean("subscription"));
				user.setActiveFlag(resultSet.getString("active_flag"));
				user.setDepartment(resultSet.getString("decrypted_dept"));
				user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
				user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
				user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
				user.setEncryptImage(resultSet.getInt("encrypt_image"));

				usersList.add(user);

				if (log.isTraceEnabled()) {
					log.trace("getUsersBySearch || returning resultset  : "
							+ user.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getUsersBySearch || returning resultset  : "
						+ usersList.toString());
			}

		} catch (MySQLSyntaxErrorException e) {
			log.error("getUsersBySearch || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_NOT_FOUND));
		} catch (IOException e) {
			log.error("getUsersBySearch || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getUsersBySearch || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getUsersBySearch || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getUsersBySearch || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("getUsersBySearch || exit");
		return usersList;
	}
	
	
	/**
	 * @method : findAdminRightsByUserName
	 * @param userName
	 * @param conn
	 * @return boolean
	 * @throws RepoproException
	 */
	public List<User> getRoleGroupDetailsByUserName(String userName, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getRoleGroupDetailsByUserName || Begin with userName:"+ userName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		User user = null;
		List<User> userList = new ArrayList<User>();

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getRoleGroupDetailsByUserName ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ADMIN_RIGHT));
			preparedStmt.setString(Constants.ONE, userName);
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("getRoleGroupDetailsByUserName ||"
						+ PropertyFileReader.getInstance().getValue(Constants.GET_ADMIN_RIGHT));
			}
			while (rs.next()) {
				
				user = new User();
				
				user.setUserName(rs.getString("user_name"));
				user.setRoleName(rs.getString("role_name"));
				user.setGroupName(rs.getString("group_name"));
				user.setRoleDescription(rs.getString("roleDescription"));
				user.setGroupDescription(rs.getString("groupDescription"));

				userList.add(user);				
				
				if (log.isTraceEnabled()) {
					log.trace("getRoleGroupDetailsByUserName ||" + userName+ " data is retrieved successfully");
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getRoleGroupDetailsByUserName || "+ userList.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getRoleGroupDetailsByUserName ||" + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.ADMIN_RIGHTS_NOT_FOUND_BY_USER_NAME));
		} catch (IOException e) {
			log.error("getRoleGroupDetailsByUserName ||" + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getRoleGroupDetailsByUserName ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getRoleGroupDetailsByUserName ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}

		}
		if (log.isTraceEnabled()) {
			log.trace("getRoleGroupDetailsByUserName || End ");
		}
		return userList;
	}
	
	
	/**
	 * @method getAllActiveUsers
	 * @description to get all active users
	 * @param connection
	 * @return list of all active users
	 * @throws RepoproException
	 */
	public List<User> getAllActiveUsers(String userName, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllActiveUsers || Begin with userName : "+userName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		User user = null;
		List<User> userList = new ArrayList<User>();
		
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllActiveUsers ||" + Constants.LOG_CONNECTION_OPEN);
			}
			
			boolean userFlag = false;
			User user2 = userDao.retProfileForUserName(userName, conn);
			userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user2.getUserId(), conn);
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
					break;
				}
			}
			
			if(userName.equalsIgnoreCase("admin")) {
				userFlag = true;
			}
			
			if(userFlag) {
				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_ACTIVE_USERS_FOR_LOGGED_IN_USER));
				
				preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
				
			}else {
				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ALL_ACTIVE_USERS));

				preparedStmt.setString(Constants.ONE, userName);
				preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);				
			}
			rs = preparedStmt.executeQuery();

			while(rs.next()){
				user = new User();
				user.setUserId(rs.getLong("user_id"));
				user.setUserName(rs.getString("user_name"));
				user.setFullName(rs.getString("masked_full_name"));
				user.setEmailId(rs.getString("email_id"));
				user.setImageName(rs.getString("image_name"));
				user.setEncryptImage(rs.getInt("encrypt_image"));
				userList.add(user);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllActiveUsers ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_ACTIVE_USERS));
			}

		} catch (SQLException e) {
			log.error("getAllActiveUsers ||" + Constants.GET_ALL_ACTIVE_USERS + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.USER_DATA_NOT_FOUND));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getAllActiveUsers ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllActiveUsers ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAllActiveUsers || End");
		}
		return userList;
	}
	
	
	/**
	 * @method getAllActiveUsersForExport
	 * @description to get all active users
	 * @param connection
	 * @return list of all active users
	 * @throws RepoproException
	 */
	public List<User> getAllActiveUsersForExport(String userName, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllActiveUsersForExport || Begin with userName : "+userName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		User user = null;
		List<User> userList = new ArrayList<User>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllActiveUsersForExport ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ALL_ACTIVE_USERS_FOR_EXPORT));

			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			
			rs = preparedStmt.executeQuery();

			while(rs.next()){
				user = new User();
				user.setUserId(rs.getLong("user_id"));
				user.setUserName(rs.getString("user_name"));
				user.setFullName(rs.getString("decrypted_full_name"));
				user.setEmailId(rs.getString("email_id"));
				user.setImageName(rs.getString("image_name"));
				userList.add(user);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllActiveUsersForExport ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_ACTIVE_USERS_FOR_EXPORT));
			}

		} catch (SQLException e) {
			log.error("getAllActiveUsersForExport ||" + Constants.GET_ALL_ACTIVE_USERS_FOR_EXPORT + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.USER_DATA_NOT_FOUND));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getAllActiveUsersForExport ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllActiveUsersForExport ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAllActiveUsersForExport || End");
		}
		return userList;
	}
	
	
	public Map<Long, String> getUserStatusByUserId(String userIds, Connection conn) throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("getUserStatusByUserId || Begin with userIds : "+userIds);
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		User user = null;
		Map<Long, String> userMap = new HashMap<Long, String>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getUserStatusByUserId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			String sql = PropertyFileReader.getInstance().getValue(Constants.GET_USER_STATUS_BY_USERID);
			
			String sqlIN = Arrays.asList(userIds.split(",")).stream()
					.map(x -> String.valueOf(x))
					.collect(Collectors.joining(",", "(", ")"));
					
		    sql = sql.replace("(?)", sqlIN);
		    
		    pstmt = conn.prepareStatement(sql);
			
			if (log.isTraceEnabled()) {
				log.trace("getUserStatusByUserId || " + PropertyFileReader.getInstance()
							.getValue(Constants.GET_USER_STATUS_BY_USERID));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				userMap.put(rs.getLong("user_id"), rs.getString("user_name")+"~~"+rs.getString("active_flag"));
			}
			if(log.isDebugEnabled()){
				log.debug("getUserStatusByUserId || "+userMap.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getUserStatusByUserId || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.USER_NOT_FOUND));
		} catch (IOException e) {
			log.error("getUserStatusByUserId || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getUserStatusByUserId || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getUserStatusByUserId || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getUserStatusByUserId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return userMap;
	}
	
	public List<User> getFlilteredUsersAttributeForGrid(String userName,List<String> attributesList, String searchString, Long from,String groupIds,boolean exportFlag, Connection conn)
			throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("getFlilteredUsersAttributeForGrid || begin :");
		}
		List<User> usersListForGrid = new ArrayList<User>();
		Connection conn1 = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStmt = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getFlilteredUsersAttributeForGrid || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(attributesList != null && !attributesList.isEmpty() && !attributesList.get(0).equalsIgnoreCase("")) {
				
				StringBuffer procedure = new StringBuffer("");
				procedure = new StringBuffer("SELECT distinct *,\n" + 
						"convert(aes_decrypt(p.full_name,'"+CommonUtils.encryptionKey+"') using utf8mb4) as decrypted_full_name,\n" + 
						"convert(aes_decrypt(p.email_id,'"+CommonUtils.encryptionKey+"') using utf8mb4) as decrypted_email_id,\n" + 
						"convert(aes_decrypt(p.department,'"+CommonUtils.encryptionKey+"') using utf8mb4) as decrypted_dept,\n" + 
						"aes_decrypt(image,'"+CommonUtils.encryptionKey+"') as decrypted_image"); 
						
				if(groupIds != null && !groupIds.isEmpty()&& !groupIds.equalsIgnoreCase("")) {	
					procedure.append(",ug.group_id,ug.user_id as userGroupId" ); 
				}
				
				procedure.append(" FROM profile p ");
				if(groupIds != null && !groupIds.isEmpty()&& !groupIds.equalsIgnoreCase("")) {	
					procedure.append(" JOIN user_groups ug ON p.user_id = ug.user_id\n " ); 
				}
				
				procedure.append(" where p.user_id in (select p1.user_id from profile p1 where ");
				       
				       
				for(int i=0;i<attributesList.size();i++){

					if(!attributesList.get(i).equalsIgnoreCase("IncludeInActiveUser") && !attributesList.get(i).equalsIgnoreCase("ActiveUser")) {
						if (i>0){
							procedure.append(" or ");
						}
					}
					if(attributesList.get(i).equalsIgnoreCase("UserName")){
						procedure.append(" p1.user_name like CONCAT('%','"+searchString+"','%') ");
					}
					else if(attributesList.get(i).equalsIgnoreCase("EmailId")) {
						procedure.append(" (lower(convert(aes_decrypt(p1.email_id,'"+CommonUtils.encryptionKey+"') using utf8mb4)) "
								+ "like CONCAT('%',lower('"+searchString+"'),'%')) ");
					}
					else if(attributesList.get(i).equalsIgnoreCase("FullName")) {
						procedure.append(" (lower(convert(aes_decrypt(p1.full_name,'"+CommonUtils.encryptionKey+"') using utf8mb4)) "
								+ "like CONCAT('%',lower('"+searchString+"'),'%')) ");
					}
					else if(attributesList.get(i).equalsIgnoreCase("Department")){
						procedure.append(" (lower(convert(aes_decrypt(p1.department,'"+CommonUtils.encryptionKey+"') using utf8mb4)) "
								+ "like CONCAT('%',lower('"+searchString+"'),'%'))");
					}
				}
				if(groupIds != null && !groupIds.isEmpty()&& !groupIds.equalsIgnoreCase("")) {
					boolean activeFlag = true;
					for(int i=0;i<attributesList.size();i++){
						if(attributesList.get(i).equalsIgnoreCase("IncludeInActiveUser")) {
							procedure.append(") and ug.group_id in("+groupIds+") order by user_name asc ");
							activeFlag = false;break;
						}
					}
					if(activeFlag) {
						procedure.append(") and active_flag = 1 and ug.group_id in("+groupIds+") order by user_name asc ");
					}
				}else {
					boolean activeFlag = true;
					for(int i=0;i<attributesList.size();i++){
						if(attributesList.get(i).equalsIgnoreCase("IncludeInActiveUser")) {
							procedure.append(")  order by user_name asc ");
							activeFlag = false;break;
						}
					}
					if(activeFlag) {
						procedure.append(") and active_flag = 1 order by user_name asc ");
					}
				}
				if(!exportFlag) {
					procedure.append("limit "+from+",20;");
				}else {
					procedure.append(";");
				}

				preparedStmt = conn.prepareStatement(procedure.toString());
				resultSet = preparedStmt.executeQuery();

			}
			
			if(userName.equalsIgnoreCase("admin")){
				while (resultSet.next()) {
					User user = new User();
					user.setUserId(resultSet.getLong("user_id"));
					user.setUserName(resultSet.getString("user_name"));
					user.setFullName(resultSet.getString("decrypted_full_name"));
					user.setEmailId(resultSet.getString("decrypted_email_id"));
					user.setImageName(resultSet.getString("image_name"));
					user.setImage(resultSet.getBinaryStream("decrypted_image"));
					user.setSubscribe(resultSet.getBoolean("subscription"));
					user.setActiveFlag(resultSet.getString("active_flag"));
					user.setDepartment(resultSet.getString("decrypted_dept"));
					user.setPassword(resultSet.getString("password"));
					user.setEncryptFullName(resultSet.getInt("encrypt_full_name"));
					user.setEncryptEmailId(resultSet.getInt("encrypt_email_id"));
					user.setEncryptDepartment(resultSet.getInt("encrypt_department"));
					user.setEncryptImage(resultSet.getInt("encrypt_image"));
					
					user.setRoleId(resultSet.getLong("role_id"));
					user.setSubscribe(resultSet.getBoolean("subscription"));
					user.setActiveFlag(resultSet.getString("active_flag"));
					user.setPassword(resultSet.getString("password"));
					int lock = resultSet.getInt("lockAccount_flag");
					if (lock == 1){
						user.setLockStatus("unlock");
					}else if(lock ==0){
						user.setLockStatus("lock"); 
					}
					usersListForGrid.add(user);

					if (log.isTraceEnabled()) {
						log.trace("getFlilteredUsersAttributeForGrid || " + user.toString());
					}
				}
			}else{

				while (resultSet.next()) {
					User user = new User();
					user.setUserId(resultSet.getLong("user_id"));
					user.setUserName(resultSet.getString("user_name"));
					user.setFullName(resultSet.getString("decrypted_full_name"));
					user.setEmailId(resultSet.getString("decrypted_email_id"));
					user.setImageName(resultSet.getString("image_name"));
					user.setImage(resultSet.getBinaryStream("image"));
					user.setRoleId(resultSet.getLong("role_id"));
					user.setSubscribe(resultSet.getBoolean("subscription"));
					user.setActiveFlag(resultSet.getString("active_flag"));
					user.setDepartment(resultSet.getString("decrypted_dept"));
					user.setPassword(resultSet.getString("password"));
					usersListForGrid.add(user);

					if (log.isTraceEnabled()) {
						log.trace("getFlilteredUsersAttributeForGrid || " + user.toString());
					}
				}
			}

		} catch (SQLException e) {
			log.error("getFlilteredUsersAttributeForGrid || " + Constants.LOG_GET_SQLEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.USER_NOT_FOUND));
		} catch (IOException e) {
			log.error("getFlilteredUsersAttributeForGrid || " + Constants.LOG_IOEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getFlilteredUsersAttributeForGrid || "+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getFlilteredUsersAttributeForGrid || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getFlilteredUsersAttributeForGrid || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("getFlilteredUsersAttributeForGrid || exit");
		return usersListForGrid;
	}
	
	
}
