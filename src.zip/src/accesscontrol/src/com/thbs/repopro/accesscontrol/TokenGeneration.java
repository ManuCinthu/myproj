package com.thbs.repopro.accesscontrol;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.security.Key;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import java.util.Base64;
import java.util.List;

import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.ldap.LDAPAuthentication;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModelRest;
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/rest")
public class TokenGeneration {
	
	static Logger log = Logger.getLogger(TokenGeneration.class.getName());
	
	
	/**
	
	 * @param request
	 * @return
	
	 */
	@GET
	@Path("/webLogin")
	public Response getTokenForwebLoginForRepopro(@Context HttpServletRequest request,@QueryParam("userName") String userName)
	{
		            if(log.isDebugEnabled()){
						log.debug("getTokenForwebLoginForRepopro : begin");
					}
            		//HttpSession httpSession = request.getSession();
            		//SecurityContext ctx = (SecurityContext) httpSession.getAttribute("SPRING_SECURITY_CONTEXT");
            		 
            		//Authentication auth=ctx.getAuthentication();
					String token = getToken(request,false);
					if(log.isDebugEnabled()){
						log.debug("getTokenForwebLoginForRepopro  :  end");
					}
					UserDao userDao = new UserDao();
					User user = null;
					try 
					{
						user = userDao.retProfileForUserName(userName, null);
					} 
					catch (RepoproException e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 LocalDateTime dateTime = LocalDateTime.now();
                     userDao.insertTokenDetails(token, user.getUserId(),Timestamp.valueOf(dateTime), null);
					return Response.ok(token).build();
			
	}
		
	

	
	
	@GET
	@Path("/login")
	public Response getTokenForExposeRestAPILoginForRepopro(@HeaderParam("authorization") String authString,@Context HttpServletRequest request){
		if (log.isDebugEnabled()) {
			log.debug("getTokenForExposeRestAPILoginForRepopro : begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
	    Connection conn=null;
	   /* GlobalSetting globalSetting = null;
	    GlobalSettingDao globalSettingDao = new GlobalSettingDao();
	    LDAPAuthentication ldapAuthentication = new LDAPAuthentication();*/
		try {
			/*try {
				 globalSetting = globalSettingDao.retGlobalSettingByName("Ldap" , conn);
			} catch (RepoproException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}*/
			/*if(globalSetting.getGlobalLdapSettingFlag() == 0){*/
				// Native Users
				
				try {
					conn = DBConnection.getInstance().getConnection();
				} catch (RepoproException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (PropertyVetoException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				conn.setAutoCommit(false);
				boolean flag = false;
		        String decodedAuth = "";
		        // Header is in the format "Basic 5tyc0uiDat4"
		        // We need to extract data before decoding it back to original string
		        if(authString != null){
		            String[] authParts = authString.split("\\s+");
			        String authInfo = authParts[1];
			        // Decode the data back to original string
			        byte[] bytes = null;
			        bytes =  Base64.getDecoder().decode(authInfo);
			        decodedAuth = new String(bytes);
			       
			        
			        String[] decodedAuthArray = decodedAuth.split(":");
			        
			        if( decodedAuthArray.length != 2){
			        	retStat = Status.UNAUTHORIZED;
			        	retMsg = Constants.USER_NOT_AUTHENTICATED;
			        	retScsFlr = Constants.NOT_AUTHENTICATED;
			        	retStatScsFlr = Constants.UNAUTHORIZED;
			        	return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			       }
			        String userName = decodedAuthArray[0];
			       
			        String password = decodedAuthArray[1];
					String encryptedPassword = password;
					/*
					 * Encrypting the password
					 */
					try{
						final String ALGO = "AES";
						final byte[] keyValue = 
								new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };
						Key key = new SecretKeySpec(keyValue, ALGO);;
					    Cipher c = Cipher.getInstance(ALGO);
					    c.init(Cipher.ENCRYPT_MODE, key);
					    byte[] encVal = c.doFinal(password.getBytes());
					    encryptedPassword = Base64.getEncoder().encodeToString(encVal);

					}catch(Exception e){
						e.printStackTrace();
					}
					
				
			        UserDao userDao = new UserDao();
			       
			        User user = userDao.getUserIdByUserName(userName, conn);;
			        
			        if(user.getUserId() != null)
					{
			        	if(user.getActiveFlag().equalsIgnoreCase("1")) {
			        		// LDAP User check
			        		if(user.getPassword() != null && user.getPassword().equalsIgnoreCase("")){
			        			LDAPAuthentication ldapAuthentication = new LDAPAuthentication();
			        			flag = ldapAuthentication.authenticateUser(userName, password);			        		
			        		} 

			        		// Native User
			        		else {				        	
			        			user = userDao.retProfileForUserNameAndPwd(userName, encryptedPassword, conn);

			        			if (user != null) {
			        				if(user.getActiveFlag().equalsIgnoreCase("1"))// active user
			        					flag = true;
			        			}				        	
			        		}
			        	}
					}
			        
			        
			        
					/*try {
						user = userDao.retProfileForUserNameAndPwd(userName, encryptedPassword, conn);
					} catch (RepoproException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			        if(user != null)
					{ 
			        	if(user.getActiveFlag().equalsIgnoreCase("1"))// active user
						flag = true;
					}
			        try {
						user = userDao.getUserIdByUserName(userName, conn);
					} catch (RepoproException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}*/
			        
			        /*if(user.getPassword() != null){
			        	if(user.getPassword().equalsIgnoreCase("")){

			        		retStat = Status.UNAUTHORIZED;
			        		retMsg = Constants.USER_NOT_AUTHENTICATED;
			        		retScsFlr = Constants.NOT_AUTHENTICATED;
			        		retStatScsFlr = Constants.UNAUTHORIZED;
			        		return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	

			        	}
			        }*/
			        
					GlobalSettingDao globalsettingDao = new GlobalSettingDao();
					boolean is_oAuth = false;
					List<GlobalSetting> globalSetting = null;
					try {
						globalSetting = globalsettingDao.getGlobalSetting(conn);

						for(GlobalSetting g : globalSetting){
							if(g.getMechanism().equalsIgnoreCase("oAuth")){
								is_oAuth = true;
								break;
							}
						}
					}catch(Exception e){
                		e.printStackTrace();
                	}
			        if(is_oAuth){
		        		retStat = Status.UNAUTHORIZED;
		        		retMsg = Constants.USER_NOT_AUTHENTICATED;
		        		retScsFlr = Constants.NOT_AUTHENTICATED;
		        		retStatScsFlr = Constants.UNAUTHORIZED;
		        		return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			        }
			        
					if(flag == true)
					{
						String token = getToken(request,true);
                        LocalDateTime dateTime = LocalDateTime.now();
                        userDao.insertTokenDetails(token, user.getUserId(),Timestamp.valueOf(dateTime), null);
                        JSONObject json = new JSONObject();
                        try{
                        String message = "Access token generated successfully";
                        json.put("token", token);
    					json.put("message", message);
    					json.put("status", Constants.SUCCESS);
    					json.put("statusCode", Constants.GET_STATUS_SUCCESS);
    					
                    	}catch(Exception e){
                    		e.printStackTrace();
                    	}
    					return Response.status(retStat).entity(json.toString())
    							.build();
                        //return Response.ok(token).build();
					}
					else
					{
						retStat = Status.UNAUTHORIZED;
						retMsg = Constants.USER_NOT_AUTHENTICATED;
						retScsFlr = Constants.NOT_AUTHENTICATED;
						retStatScsFlr = Constants.UNAUTHORIZED;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
					}
			         
		        }
				
			//}
			/*else{
				// LDAP and Native Users
				
				try {
					conn = DBConnection.getInstance().getConnection();
				} catch (RepoproException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (PropertyVetoException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				conn.setAutoCommit(false);
				boolean flag = false;
		        String decodedAuth = "";
		        // Header is in the format "Basic 5tyc0uiDat4"
		        // We need to extract data before decoding it back to original string
		        if(authString != null){
		            String[] authParts = authString.split("\\s+");
			        String authInfo = authParts[1];
			        // Decode the data back to original string
			        byte[] bytes = null;
			        bytes =  Base64.getDecoder().decode(authInfo);
			        decodedAuth = new String(bytes);
			       
			        
			        String[] decodedAuthArray = decodedAuth.split(":");
			        if( decodedAuthArray.length != 2){
			        	retStat = Status.UNAUTHORIZED;
			        	retMsg = Constants.USER_NOT_AUTHENTICATED;
			        	retScsFlr = Constants.NOT_AUTHENTICATED;
			        	retStatScsFlr = Constants.UNAUTHORIZED;
			        	return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			       }
			        
			        String userName = decodedAuthArray[0];
			       
			        String password = decodedAuthArray[1];
					String encryptedPassword = password;
					
					 * Encrypting the password
					 
					try{
						final String ALGO = "AES";
						final byte[] keyValue = 
								new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };
						Key key = new SecretKeySpec(keyValue, ALGO);;
					    Cipher c = Cipher.getInstance(ALGO);
					    c.init(Cipher.ENCRYPT_MODE, key);
					    byte[] encVal = c.doFinal(password.getBytes());
					    encryptedPassword =  Base64.getEncoder().encodeToString(encVal);

					}catch(Exception e){
						e.printStackTrace();
					}
					
				
			        UserDao userDao = new UserDao();
			       
			        User user = null;
					try {
						user = userDao.retProfileForUserName(userName, conn);
					} catch (RepoproException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			        if(user != null)
					{
			        	String password1 = user.getPassword();
			        	if(password1.equalsIgnoreCase("")){
			        		boolean flag1 = ldapAuthentication.authenticateUser(userName,password);
			        		if(flag1 == true)
			        		{
			        			if(user.getActiveFlag().equalsIgnoreCase("1"))// active user 
			        			flag = true;
			        		}
			        		else{
			        			flag = false;
			        		}
			        	}
			        	else{
			        		try {
								User user1 = userDao.retProfileForUserNameAndPwd(userName, encryptedPassword, conn);
								if(user1 != null)
								{
									if(user1.getActiveFlag().equalsIgnoreCase("1"))// active user
									flag = true;
								}
								else
								{
									flag = false;
								}
							} catch (RepoproException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
			        	}
						
						
					}
			        try {
						user = userDao.getUserIdByUserName(userName, conn);
					} catch (RepoproException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			        if(user.getPassword() != null){
			        	if(user.getPassword().equalsIgnoreCase("")){

			        		retStat = Status.UNAUTHORIZED;
			        		retMsg = Constants.USER_NOT_AUTHENTICATED;
			        		retScsFlr = Constants.NOT_AUTHENTICATED;
			        		retStatScsFlr = Constants.UNAUTHORIZED;
			        		return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	

			        	}
			        }
					if(flag == true)
					{
						String token = getToken(request,true);
						LocalDateTime dateTime = LocalDateTime.now();
	                    userDao.insertTokenDetails(token, user.getUserId(),Timestamp.valueOf(dateTime), null);
	                    JSONObject json = new JSONObject();
                        try{
                        String message = "Access token generated successfully";
                        json.put("token", token);
    					json.put("message", message);
    					json.put("status", Constants.SUCCESS);
    					json.put("statusCode", Constants.GET_STATUS_SUCCESS);
    					
                    	}catch(Exception e){
                    		e.printStackTrace();
                    	}
    					return Response.status(retStat).entity(json.toString())
    							.build();
	                    //  return Response.ok(token).build();
					}
					else
					{
						retStat = Status.UNAUTHORIZED;
						retMsg = Constants.USER_NOT_AUTHENTICATED;
						retScsFlr = Constants.NOT_AUTHENTICATED;
						retStatScsFlr = Constants.UNAUTHORIZED;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
					}
			         
		        }
				
				
			}*/

		} catch (SQLException e1) {
			//log.error("getTokenForExposeRestAPILoginForRepopro :  " + Constants.LOG_GET_SQLEXCEPTION + e1.getMessage());
			e1.printStackTrace();
		} catch (IOException e1) {
			//log.error("getTokenForExposeRestAPILoginForRepopro :  " + Constants.LOG_IOEXCEPTION + e1.getMessage());
			e1.printStackTrace();
		} catch (RepoproException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}  finally {
			if (log.isInfoEnabled()) {
				//log.info("getTokenForExposeRestAPILoginForRepopro : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isDebugEnabled()) {
			if(Response.status(Response.Status.UNAUTHORIZED).build() == null){
				log.debug("getTokenForExposeRestAPILoginForRepopro : Resultset is null");
				}else{
			log.debug("getTokenForExposeRestAPILoginForRepopro :"+Response.status(Response.Status.UNAUTHORIZED).build()+" end");
		}}
		retStat = Status.UNAUTHORIZED;
		retMsg = Constants.USER_NOT_AUTHENTICATED;
		retScsFlr = Constants.NOT_AUTHENTICATED;
		retStatScsFlr = Constants.UNAUTHORIZED;
		return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
		
		//}
		
	}
	

public static synchronized String getToken(HttpServletRequest request,boolean flag)  {
		
		try {
			
			 HttpSession session = request.getSession();
			 if(flag == true){
				 request.changeSessionId();
			 }
			 String token = session.getId();
			
			
			return token;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	}
	

