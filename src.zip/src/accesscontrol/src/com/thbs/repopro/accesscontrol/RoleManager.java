package com.thbs.repopro.accesscontrol;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.GroupRoles;
import com.thbs.repopro.dto.Role;
import com.thbs.repopro.dto.RoleFunction;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;

@Path("/roledetails")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class RoleManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method addRole
	 * @description to add a role details
	 * @param roledata
	 * @return Response Success message
	 */

	@POST
	public Response addRole(Role roledata) {
		if (roledata == null) {
			log.warn("addRole || role details to be inserted not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
									.getMessage(Constants.INVALID_REQUEST)))
					.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("addRole || Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			List<String> jsonRsltList = new ArrayList<String>();
			List<Role> jsonList = new ArrayList<Role>();
			String jsonRslt;
			RoleDao roledao = new RoleDao();
			List<Role> rolelist = new ArrayList<Role>();
			CommonUtils commonUtils = new CommonUtils();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			try {
				if (log.isTraceEnabled()) {
					log.trace("addRole ||" + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("addRole || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
				
				
				if (log.isTraceEnabled()) {
					log.trace("addRole || call of dao method getAllRoleData()");
				}
				rolelist = roledao.getAllRoleData(conn);
				boolean flagForDuplicateRole = false;

				if (rolelist.size() > 0) {
					if (log.isDebugEnabled()) {
						log.debug("addRole || check whether entered Role name:"
								+ roledata.getRoleName() + " already exist");
					}
					for (Role roledat : rolelist) {

						if (roledat.getRoleName().equalsIgnoreCase(
								roledata.getRoleName())) {
							flagForDuplicateRole = true;
							log.warn("addRole || rolename "
									+ roledata.getRoleName()
									+ " already exists:");
						}
					}
				}

				if (flagForDuplicateRole == true) {

					jsonRslt = Constants.ROLE_NAME_ALREADY_EXISTS;
					jsonRsltList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
											.getMessage(Constants.ROLE_NAME_ALREADY_EXISTS),
									new ArrayList<Object>(jsonRsltList)))
							.build();

				} else {
					if(globalsetting.getGlobalSettingFlag() == 1){
						String description = commonUtils.httpSanitizerForPlainText(roledata.getDescription());
						roledata.setDescription(description);
					}
					if (log.isTraceEnabled()) {
						log.trace("addRole || call of dao addRole() method to add role details");
					}
					roledata = roledao.addRole(roledata, conn);

					retStat = Status.OK;
					retMsg = Constants.ROLE_DATA_CREATED;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					jsonList.add(roledata);
				}
				if (log.isDebugEnabled()) {
					log.debug("addRole || role details " + roledata.toString()
							+ " inserted successfully ");
				}
				conn.commit();

			} catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}

			} catch (Exception e) {
				log.error("addRole || SQL Exception addRole:"
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addRole : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("addRole || End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(jsonList))).build();

		}
	}
	
	
	@POST
	@Path("/addRole")
	public Response addRoleMain(@QueryParam("roleName") String roleName, 
			@QueryParam("roleDescription") String roleDescription,
			@HeaderParam("token") String token){
		
		if(roleName == null || roleDescription == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(roleName.trim().isEmpty() || roleDescription.trim().isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		if(roleName.trim().length()>30 || roleDescription.trim().length()>100){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
			     .build();
		}
		
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		User user = new User();
		RoleDao roledao = new RoleDao();
		Role role = new Role();
		UserDao userDao = new UserDao();
		boolean roleFlag = false;
		boolean adminFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		roleName = roleName.trim();
		roleDescription = roleDescription.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, null);
			if(user != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), null);
			}
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_ROLES")){
			        roleFlag = true;
			        break;
				}
			}
			
			role.setRoleName(roleName);
			role.setDescription(roleDescription);
			
			if(roleFlag || adminFlag){
				String newRegex = "^[A-Za-z0-9-_ ]+$";
				Pattern pattern = Pattern.compile(newRegex);
				Matcher matcher = pattern.matcher(roleName);
				
				if(!matcher.find()){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, "Please use only alphanumeric characters, space, - and _ in role name."))
							.build();
				}
				
				response = this.addRole(role);
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				if(res.getStatus().equalsIgnoreCase(Constants.FAILURE)){
					json.put("message", res.getMessage());
					json.put("status", res.getStatus());
					json.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("addRoleMain || End");
					
					return Response.status(Status.BAD_REQUEST).entity(json.toString()).build();
				}
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("addRoleMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
				
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
		} catch (RepoproException e) {
			log.error("addRoleMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addRoleMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addRoleMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		log.trace("addRoleMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		
	}
	

	/**
	 * @method updateRole
	 * @description to update a roledetails
	 * @param role_id
	 * @param roledata
	 * @return Response Success message
	 */
	@PUT
	@Path("/{role_Id}")
	public Response updateRole(@PathParam("role_Id") Long role_id, Role roledata)
			{
		if (roledata == null) {
			log.warn("updateRole || roledata to be updated is not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
									.getMessage(Constants.INVALID_REQUEST)))
					.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("updateRole || Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			List<String> jsonList = new ArrayList<String>();
			String jsonRslt;
			List<RoleFunction> rolefunctionlist = new ArrayList<RoleFunction>();
			RoleDao roledao = new RoleDao();
			List<Role> rolelist = new ArrayList<Role>();
			CommonUtils commonUtils = new CommonUtils();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			try {
				if (log.isTraceEnabled()) {
					log.trace("updateRole ||" + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("updateRole || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
				
				Role role = new Role();
				if (log.isTraceEnabled()) {
					log.trace("updateRole ||call of dao getRoleById() method");
				}
				role = roledao.getRoleById(role_id, conn);

				if (log.isTraceEnabled()) {
					log.trace("updateRole || call of dao getAllRoleData() method");
				}
				rolelist = roledao.getAllRoleData(conn);

				boolean flagForDuplicateRole = false;

				if (rolelist.size() > 0) {
					if (log.isDebugEnabled()) {
						log.debug("updateRole || check whether entered name already exist "
								+ "role name : " + roledata.getRoleName());
					}
					for (int i = 0; i < rolelist.size(); i++) {

						if (!role.getRoleName().equalsIgnoreCase(
								rolelist.get(i).getRoleName())) {
							if (roledata.getRoleName().equalsIgnoreCase(
									rolelist.get(i).getRoleName())) {
								flagForDuplicateRole = true;
								log.warn("updateRole || rolename "
										+ roledata.getRoleName()
										+ " already exists");
								break;
							}
						}
					}
				}

				if (flagForDuplicateRole == true) {

					jsonRslt = Constants.ROLE_NAME_ALREADY_EXISTS;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.UPDATE_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
											.getMessage(Constants.ROLE_NAME_ALREADY_EXISTS),
									new ArrayList<Object>(jsonList))).build();
				} else {
					jsonRslt = Constants.SUCCESS;
					jsonList.add(jsonRslt);
					
					if(globalsetting.getGlobalSettingFlag() == 1){
						String description = commonUtils.httpSanitizerForPlainText(roledata.getDescription());
						roledata.setDescription(description);
					}
					if (log.isTraceEnabled()) {
						log.trace("updateRole || call of dao updateRole() method to update ");
					}
					roledata = roledao.updateRole(role_id, roledata, conn);

				}
				
				if (log.isTraceEnabled()) {
					log.trace("updateRole || call dao addRoleFunction() method for saving function id's");
				}
				roledata.setRoleId(role_id);
				
				rolefunctionlist = roledao.addRoleFunction(roledata, conn);
				
				if (log.isInfoEnabled()) {
					log.info("updateRole || updation of role data "+ roledata.toString() + " is successfull");
				}
				conn.commit();
				retMsg = Constants.ROLE_DATA_UPDATED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			} catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch (Exception e) {
				log.error("updateRole || SQL Exception updateRole: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateRole ||" + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("updateRole || End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(jsonList))).build();

		}
	}
	
	
	
	//===========================================================================================================================
	/**
	 * @method updateRoleMain
	 * @description to update a roledetails
	 * @param roleNameBeforeUpdate
	 * @param roledata
	 * @return Response Success message
	 */
	@PUT
	@Path("/roleNameBeforeUpdate")
	public Response updateRoleMain(@QueryParam("roleName") String roleName,
			@QueryParam("roleDetails") String roleDetails, 
			@HeaderParam("token") String token) {

		if (roleName == null) {
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(roleName.trim().isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		if(roleDetails == null || roleDetails.isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		if(roleDetails != null){
			try {
				String jsonStr = roleDetails;
				JSONObject jsonObject = new JSONObject(jsonStr);
				if(!jsonObject.has("description") && !jsonObject.has("associateFunctionNames")){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
				}
			} catch (JSONException e) {
				e.printStackTrace();
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
		}
				
		if (log.isTraceEnabled()) {
			log.trace("updateRoleMain || Begin");
		}

		Connection conn = null;
		Response response = null;
		RoleDao roledao = new RoleDao();
		Role role = new Role();
		List<String> functionNamesList = new ArrayList<String>();
		List<String> functionNames = new ArrayList<String>();
		List<String> functionIdsList = new ArrayList<String>();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		User user = new User();
		UserDao userDao = new UserDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean roleFlag = false;
		boolean adminFlag = false;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		roleName = roleName.trim();
		
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("updateRoleMain ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (!userName.equalsIgnoreCase("guest")) {
				User user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}

			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).
						entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			Long roleId = roledao.getRoleIdByRoleName(roleName,conn);
			if(roleId == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ROLE_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("updateRoleMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			role.setRoleId(roleId);
			role.setRoleName(roleName);
			
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}

			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}

			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_ROLES")){
					roleFlag = true;
					break;
				}
			}

			if(roleFlag || adminFlag){
				
				String jsonStr1 = roleDetails;
				JSONObject jsonObject = new JSONObject(jsonStr1);
				if(jsonObject.has("description")){
					String roleDescription = jsonObject.get("description").toString();
					roleDescription = roleDescription.trim();
					if(roleDescription.equals("")){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					role.setDescription(roleDescription);
					roledao.updateRole(roleId, role, conn);
				}
				
				if(jsonObject.has("associateFunctionNames")){
					String associateFunctionNames = jsonObject.getString("associateFunctionNames").toString();
					associateFunctionNames = associateFunctionNames.trim();
					
					String[] splitNames = associateFunctionNames.split(",");
					for(int i=0;i<splitNames.length;i++){
						splitNames[i] = splitNames[i].trim();
						if(!splitNames[i].isEmpty()){
							functionNames.add(splitNames[i]);
						}
					}
					functionNamesList = functionNames;
					/*to check if each function name is valid*/
					List<String> functionNamesFromDB = new ArrayList<String>();
					if(!functionNamesList.isEmpty()){
						List<UserFunction> allRoleFunctions = roledao.getAllRoleFunctions(conn);
						for(UserFunction userFunction : allRoleFunctions){
							functionNamesFromDB.add(userFunction.getFunctionName());
						}
						
						for(int i=0;i<splitNames.length;i++){
							splitNames[i] = splitNames[i].trim();
							if(!functionNamesFromDB.contains(splitNames[i])){
								retStat = Status.NOT_FOUND;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.FUNCTION_DATA_NOT_FOUND;
								retStatScsFlr = Constants.GET_STATUS_FAILURE;

								log.trace("updateRoleMain || End");
								return Response.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}
						}
						functionIdsList = roledao.getFunIdsByFunNames(functionNamesList,conn);
						if (functionIdsList.isEmpty()) {
							retStat = Status.NOT_FOUND;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.FUNCTION_DATA_NOT_FOUND;
							retStatScsFlr = Constants.GET_STATUS_FAILURE;

							log.trace("updateRoleMain || End");
							return Response.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						role.setAssociateFunctionIds(functionIdsList);
						roledao.addRoleFunction(role, conn);
					}
				}
				conn.commit();
				JSONObject json = new JSONObject();
				
				json.put("message", Constants.ROLE_DATA_UPDATED);
				json.put("status", Constants.SUCCESS);
				json.put("statusCode", Constants.UPDATE_STATUS_SUCCESS);
				log.trace("updateRoleMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
				
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;

		} catch (Exception e) {
			log.error("updateRoleMain || SQL Exception updateRole: " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateRoleMain ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("updateRoleMain || End");
		}

		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();


	}
	//===========================================================================================================================
	
	
	
	

	/**
	 * @method deleteRole
	 * @description to delete a roledetails
	 * @param role_id
	 * @return Response Success message
	 */
	@DELETE
	@Path("/{role_Id}")
	public Response deleteRole(@PathParam("role_Id") Long role_id)
			{

		if (log.isTraceEnabled()) {
			log.trace("deleteRole by role_id: ||"+role_id+"||Begin");
		}

		List<GroupRoles> grouplist = new ArrayList<GroupRoles>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<String> jsonList = new ArrayList<String>();
		String jsonRslt;
		boolean result = false;
		int delval = 0;
		int val = 0;
		RoleDao roledao = new RoleDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteRole ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("deleteRole || call dao getGroupRolesByRoleId() method");
			}
			grouplist = roledao.getGroupRolesByRoleId(role_id, conn);

			if (grouplist.size() != 0) {
				result = true;
			}
			if (result == true) {
				jsonRslt = Constants.ROLE_MAPPPED_WITH_GROUP;
				jsonList.add(jsonRslt);
				return Response
						.status(Status.OK)
						.entity(new MyModel(
								Constants.DELETE_STATUS_SUCCESS,
								Constants.FAILURE,
								MessageUtil
										.getMessage(Constants.ROLE_MAPPPED_WITH_GROUP),
								new ArrayList<Object>(jsonList))).build();
			} else {

				List<RoleFunction> function = new ArrayList<RoleFunction>();

				if (log.isTraceEnabled()) {
					log.trace("deleteRole || call dao retRoleFunctionsByRoleId() method to retrieve list of role function ");
				}
				function = roledao.retRoleFunctionsByRoleId(role_id, conn);

				if (!(function.isEmpty())) {
					if (log.isTraceEnabled()) {
						log.trace("deleteRole || call dao deleteRoleFunctionByRoleId() method");
					}
					val = roledao.deleteRoleFunctionByRoleId(role_id, conn);

				}

				Role role = new Role();
				if (log.isTraceEnabled()) {
					log.trace("deleteRole || call dao getRoleById() method retrieve data to be deleted");
				}
				role = roledao.getRoleById(role_id, conn);

				if (role != null) {
					if (log.isTraceEnabled()) {
						log.trace("deleteRole || call dao deleteRole() method: ");
					}
					delval = roledao.deleteRole(role_id, conn);
				}
			}
			if (log.isInfoEnabled()) {
				log.info("deleteRole ||" + val
						+ ":rows were deleted from rolefunction and " + delval
						+ ":rows deleted from role");
			}
			conn.commit();
			retMsg = Constants.ROLE_DELETED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}

		} catch (Exception e) {
			log.error("SQL Exception deleteGroup ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteRole ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("deleteRole by role_id || End");
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	
	
	
//===============================================================================================================================
	/**
	 * @method deleteRoleMain
	 * @description to delete a roledetails
	 * @param roleName
	 * @return Response Success message
	 */
	@DELETE
	@Path("/deleteRoleName")
	public Response deleteRoleMain(@QueryParam("roleName") String roleName, 
			@HeaderParam("token") String token) {
		
		if(roleName == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(roleName.trim().isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteRoleMain : ||"+roleName+"||Begin");
		}
		
		Connection conn = null;
		Response response = null;
		
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		User user = new User();
		UserDao userDao = new UserDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean roleFlag = false;
		boolean adminFlag = false;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		roleName = roleName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteRoleMain ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (!userName.equalsIgnoreCase("guest")) {
				User user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			Long roleId = roledao.getRoleIdByRoleName(roleName,conn);
			if(roleId == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ROLE_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("deleteRoleMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_ROLES")){
					roleFlag = true;
			        break;
				}
			}
			
			if(roleFlag || adminFlag){
				response = this.deleteRole(roleId);
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				if(res.getStatus().equalsIgnoreCase(Constants.FAILURE)){
					json.put("message", res.getMessage());
					json.put("status", res.getStatus());
					json.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("deleteRoleMain || End");
					
					return Response.status(Status.BAD_REQUEST).entity(json.toString()).build();
				}
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("deleteRoleMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
				
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception deleteRoleMain ||" + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteRoleMain ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("deleteRoleMain || End");
		}

		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
//================================================================================================================================	
	
	
	
	
	/**
	 * @method getAllRoleFunctions
	 * @description to get role function details
	 * @param role_id
	 * @return Response Success message
	 */
	@GET
	@Path("/{role_Id}")
	public Response getAllRoleFunctions(@PathParam("role_Id") Long role_id)
			{
		if (log.isTraceEnabled()) {
			log.trace("getAllRoleFunctions with  role_id:||"+role_id+"||Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		RoleDao roledao = new RoleDao();

		List<UserFunction> userfunctionlist = new ArrayList<UserFunction>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctions || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			List<UserFunction> userfunction = new ArrayList<UserFunction>();
			List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();

			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctions || dao call of getAllRoleFunctions() method retrieves rolefunctionlist");
			}
			userfunction = roledao.getAllRoleFunctions(conn);

			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctions || dao call of retAllRoleFunctionsMappedWithRoleId() method retrieves rolefunctionlistbyroleid");
			}
			userfunctionMappedWithRoleId = roledao
					.retAllRoleFunctionsMappedWithRoleId(role_id, conn);

			for (UserFunction userfunc : userfunction) {
				UserFunction userFunction = new UserFunction();
				userFunction.setFunctionId(userfunc.getFunctionId());
				userFunction.setFunctionName(userfunc.getFunctionName());
				userFunction.setFunctionDescription(userfunc
						.getFunctionDescription());
				userFunction.setMappedWithRole(false);
				for (UserFunction userfunctionMappedWithRoleIds : userfunctionMappedWithRoleId) {
					if (userfunctionMappedWithRoleIds.getFunctionId() == userfunc
							.getFunctionId()) {

						userFunction.setMappedWithRole(true);

					}
				}
				userfunctionlist.add(userFunction);

			}
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctions || retrieve userfunction list:"
						+ userfunctionlist.toString());
			}
			if (log.isInfoEnabled()) {
				log.info("getAllRoleFunctions || retrieve userfunction list "
						+ userfunctionlist.size());
			}
			
			retStat = Status.OK;
			retMsg = Constants.LIST_BY_ROLE_ID;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} catch (Exception e) {
			log.error("SQL Exception getAllRoleFunctions|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctions||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllRoleFunctions || End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(userfunctionlist))).build();

	}

	
	
	
//===========================================================================================
	/**
	 * @method getAllRoleFunctionsMain
	 * @description to get role function details
	 * @param roleName
	 * @return Response Success message
	 */
	@GET
	@Path("/roleName")
	public Response getAllRoleFunctionsMain(@QueryParam("roleName") String roleName,
			@HeaderParam("token") String token) {
		
		if(roleName == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(roleName.isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		if (log.isTraceEnabled()) {
			log.trace("getAllRoleFunctionsMain with  role_id:||"+roleName+"||Begin");
		}
		
		Connection conn = null;
		Response response = null;
		RoleDao roledao = new RoleDao();
		UserDao userDao = new UserDao();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		User user = new User();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean roleFlag = false;
		boolean adminFlag = false;
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		roleName = roleName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctionsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (!userName.equalsIgnoreCase("guest")) {
				user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctionsMain || dao call of  method getRoleIdByRoleName to get roleId");
			}
			
			Long roleId = roledao.getRoleIdByRoleName(roleName,conn);
			if(roleId == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ROLE_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAllRoleFunctionsMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_ROLES")){
			        roleFlag = true;
			        break;
				}
			}
			
			if(roleFlag || adminFlag){
				response = this.getAllRoleFunctions(roleId);
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	UserFunction uf = new UserFunction();
		        	uf = (UserFunction) data.get(i);
		        	
		        	j1.put("functionName", uf.getFunctionName());
		        	j1.put("mappedWithRole", uf.isMappedWithRole());
		        	
		        	finaldata.add(j1);
		        }
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getAllRoleFunctionsMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
		        
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("SQL Exception getAllRoleFunctions|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctionsMain||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllRoleFunctionsMain || End");
		}

		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
 //==================================================================================================================	

	
	
	
	/**
	 * @method getAllRoleData
	 * @description to get role details
	 * @return Response Success message
	 */
	@GET
	@Path("/rolelist")
	public Response getAllRoleData() {

		log.trace("getAllRoleData || Begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<Role> rolelist = new ArrayList<Role>();
		RoleDao roledao = new RoleDao();
		List<GroupRoles> grouplist = new ArrayList<GroupRoles>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleData || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getAllRoleData || dao call of getAllRoleData() method ");
			}
			rolelist = roledao.getAllRoleData(conn);

			for(Role role:rolelist){
				if (log.isTraceEnabled()) {
					log.trace("deleteRole || call dao getGroupRolesByRoleId() method");
				}
				grouplist = roledao.getGroupRolesByRoleId(role.getRoleId(), conn);

				if (grouplist.size() != 0) {
					role.setGroupRoleFlag(true);
				}
			}
			
			/*Iterator<Role> iterator = rolelist.iterator();
			while(iterator.hasNext()){
				Role r = iterator.next();
				if(r.getRoleName().equals("role-admin")|| r.getRoleName().equals("Guest")){
					iterator.remove();
				}
			}*/
			
			if (log.isDebugEnabled()) {
				log.debug("getAllRoleData || retrieve " + rolelist.size()
						+ " rows of roledata");
			}
			

		} catch (RepoproException e) {
			log.error("SQL Exception getAllRoleData ||" + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} catch (Exception e) {
			log.error("SQL Exception getAllRoleData ||" + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("getAllRoleData ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (rolelist.isEmpty()) {
			retMsg = Constants.ROLES_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_ROLES_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		log.trace("getAllRoleData || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(rolelist))).build();
	}
	
	
	/**
	 * @method getAllRoleDataMain
	 * @description to get role function details
	 * @param roleName
	 * @return Response Success message
	 */
	@GET
	@Path("/getAllRoleDataMain")
	public Response getAllRoleDataMain(@HeaderParam("token") String token) {
		
		if (log.isTraceEnabled()) {
			log.trace("getAllRoleDataMain || Begin");
		}
		
		Connection conn = null;
		Response response = null;
		RoleDao roledao = new RoleDao();
		UserDao userDao = new UserDao();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		User user = new User();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean roleFlag = false;
		boolean adminFlag = false;
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleDataMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (!userName.equalsIgnoreCase("guest")) {
				user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleDataMain || dao call of  method getRoleIdByRoleName to get roleId");
			}
								
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			if(user != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_ROLES")){
			        roleFlag = true;
			        break;
				}
			}
			
			if(roleFlag || adminFlag){
				response = this.getAllRoleData();
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	Role role = new Role();
		        	role = (Role) data.get(i);
		        	
		        	j1.put("roleName", role.getRoleName());
		        	j1.put("description", role.getDescription());
		        	
		        	finaldata.add(j1);
		        }
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getAllRoleDataMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
		        
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("SQL Exception getAllRoleDataMain|| " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleDataMain||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllRoleDataMain || End");
		}

		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/**
	 * @method : getAllRoleFunctionsForUserId
	 * @param userId
	 * @return
	 */
	@GET
	@Path("/getAllRoleFunctionsByUserName")
	public Response getAllRoleFunctionsByUserName(@QueryParam("userName") String userName){
		
		if(log.isTraceEnabled()){
			log.trace("getAllRoleFunctionsByUserName || Begin with userName : "+ userName);
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		RoleDao roledao = new RoleDao();

		List<UserFunction> userfunctionlist = new ArrayList<UserFunction>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean Flag=false;
		User user = new User();
		UserDao userDao = new UserDao();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctionsByUserName || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			List<UserFunction> userfunction = new ArrayList<UserFunction>();
			List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();

			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctionsByUserName || dao call of getAllRoleFunctions() method retrieves rolefunctionlist");
			}
			userfunction = roledao.getAllRoleFunctions(conn);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctionsByUserName || dao call of retProfileForUserName() method retrieves user details");
			}
			user = userDao.retProfileForUserName(userName, conn);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctionsByUserName || dao call of findAdminRightsByUserName() method");
			}
			Flag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			
			AssetDao dao = new AssetDao();
			AssetInstanceDao assetInstDao = new AssetInstanceDao();
			AssetInstanceVersionDao aiv = new AssetInstanceVersionDao();
			
			
			if(userName.equalsIgnoreCase("Admin")){
				for(UserFunction userfunc : userfunction){
					UserFunction userFunction = new UserFunction();
					userFunction.setFunctionId(userfunc.getFunctionId());
					userFunction.setFunctionName(userfunc.getFunctionName());
					userFunction.setFunctionDescription(userfunc.getFunctionDescription());
					userFunction.setMappedWithRole(true);
					userFunction.setInstanceCreation(true);
					userFunction.setAdminFlag(Flag);
					userfunctionlist.add(userFunction);
				}
			}else if(Flag){
				
				for(UserFunction userfunc : userfunction){
					UserFunction userFunction = new UserFunction();
					userFunction.setFunctionId(userfunc.getFunctionId());
					userFunction.setFunctionName(userfunc.getFunctionName());
					userFunction.setFunctionDescription(userfunc.getFunctionDescription());
					userFunction.setMappedWithRole(true);
					userFunction.setInstanceCreation(true);
					userFunction.setAdminFlag(Flag);
					userfunctionlist.add(userFunction);
				}
			}else{
				if (log.isTraceEnabled()) {
					log.trace("getAllRoleFunctionsByUserName || dao call of retAllRoleFunctionsMappedWithUserId() method retrieves rolefunctionlistbyuserid");
				}
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
				
				List<AssetDef> assetList = new ArrayList<AssetDef>();
				assetList = dao.fetchAllAssetsDetails(conn);
				boolean instanceCreation = false;
				for(int i =0;i<assetList.size();i++){
					AssetInstance ai = assetInstDao.getAssetLevelAddAccessForLoginUser(assetList.get(i).getAssetName(), userName, conn);
					if(ai.getAddAccessFlag() == true){
						instanceCreation = true;
						break;
					}
				}
				for (UserFunction userfunc : userfunction) {
					UserFunction userFunction = new UserFunction();
					userFunction.setFunctionId(userfunc.getFunctionId());
					userFunction.setFunctionName(userfunc.getFunctionName());
					userFunction.setFunctionDescription(userfunc.getFunctionDescription());
					userFunction.setMappedWithRole(false);
					userFunction.setInstanceCreation(instanceCreation);
					userFunction.setAdminFlag(Flag);
					for (UserFunction userfunctionMappedWithRoleIds : userfunctionMappedWithRoleId) {
						if (userfunctionMappedWithRoleIds.getFunctionId() == userfunc
								.getFunctionId()) {
							userFunction.setMappedWithRole(true);
						}
					}
					userfunctionlist.add(userFunction);
				}
			}
			
			if (log.isInfoEnabled()) {
				log.info("getAllRoleFunctionsByUserName || retrieve userfunction list "
						+ userfunctionlist.size());
			}
			
			retStat = Status.OK;
			retMsg = Constants.LIST_BY_ROLE_ID;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} catch (Exception e) {
			log.error("SQL Exception getAllRoleFunctionsByUserName|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllRoleFunctionsByUserName||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("getAllRoleFunctionsByUserName || end");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(userfunctionlist))).build();
	}

}
