package com.thbs.repopro.relationship;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetInstRelationship;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.AssetRelationshipDef;
import com.thbs.repopro.dto.RelationshipDef;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class RelationshipDao {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : getAllRelationships
	 * @description : to get AllRelationships
	 * @param conn
	 * @return List<RelationshipDef>
	 * @throws DataNotFoundException
	 */
	public List<RelationshipDef> getAllRelationships(Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllRelationships || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<RelationshipDef> relationshiplist = new ArrayList<RelationshipDef>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllRelationships||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance()
					.getValue(Constants.RET_ALL_RELATIONSHIP_DEFS));

			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationships ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_RELATIONSHIP_DEFS));
			}
			while (rs.next()) {
				RelationshipDef relationship = new RelationshipDef();
				relationship.setRelationshipId(rs.getLong("relationship_id"));
				relationship.setRelationName(rs.getString("relationship_name"));
				relationship.setMaxValue(rs.getString("maxValue"));
				relationshiplist.add(relationship);
				if (log.isTraceEnabled()) {
					log.trace("getAllRelationships ||"
							+ relationship.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllRelationships ||"
						+ relationshiplist.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAllRelationships ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("getAllRelationships ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllRelationships ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllRelationships ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isTraceEnabled()) {
			log.trace("getAllRelationships || exit");
		}
		return relationshiplist;
	}
	/**
	 * @method getRelationshipsByRelId
	 * @param relId
	 * @param conn
	 * @return RelationshipDef
	 * @throws RepoproException
	 */
	public RelationshipDef getRelationshipsByRelId(Long relId,Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getRelationshipsByRelId || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		RelationshipDef relationship = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getRelationshipsByRelId||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_RELATIONSHIP_DEFS_BY_REL_ID));
			preparedStmt.setLong(Constants.ONE,relId);
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("getRelationshipsByRelId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_RELATIONSHIP_DEFS_BY_REL_ID));
			}
			while (rs.next()) {
				relationship = new RelationshipDef();
				relationship.setRelationshipId(rs.getLong("relationship_id"));
				relationship.setRelationName(rs.getString("relationship_name"));
				relationship.setMaxValue(rs.getString("maxValue"));
				if (log.isTraceEnabled()) {
					log.trace("getRelationshipsByRelId ||"
							+ relationship.toString());
				}
			}
		

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getRelationshipsByRelId ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("getRelationshipsByRelId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getRelationshipsByRelId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getRelationshipsByRelId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isTraceEnabled()) {
			log.trace("getRelationshipsByRelId || exit");
		}
		return relationship;
	}



	/**
	 * @method : getAllAssetRelationshipDef
	 * @description : to get AllAssetRelationship
	 * @param conn
	 * @return List<AssetRelationship>
	 * @throws DataNotFoundException
	 */
	public List<AssetRelationshipDef> getAllAssetRelationshipDef(Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllAssetRelationshipDef || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<AssetRelationshipDef> relationshiplist = new ArrayList<AssetRelationshipDef>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDef||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_ALL_ASSET_RELATIONSHIP_DEFS));

			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDef ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_ASSET_RELATIONSHIP_DEFS));
			}
			while (rs.next()) {
				AssetRelationshipDef relationship = new AssetRelationshipDef();
				relationship.setAssetRelId(rs.getLong("asset_rel_id"));
				relationship.setSrcAssetName(rs.getString("src_asset_name"));
				relationship.setDestAssetName(rs.getString("dest_asset_name"));
				relationship.setFwdRelationType(rs.getString("fwd_rel_name"));
				relationship.setBwdRelationType(rs.getString("bwd_rel_name"));
				relationship.setDescription(rs.getString("description"));
				relationship.setSrcAssetId(rs.getLong("src_asset_id"));
				relationship.setDestAssetId(rs.getLong("dest_asset_id"));
				relationship.setFwdRelId(rs.getLong("fwd_rel_id"));
				relationship.setBwdRelId(rs.getLong("bwd_rel_id"));
				relationshiplist.add(relationship);
				if (log.isTraceEnabled()) {
					log.trace("getAllAssetRelationshipDef ||"
							+ relationship.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetRelationshipDef ||"
						+ relationshiplist.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAllAssetRelationshipDef ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetRelationshipDef ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetRelationshipDef ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetRelationshipDef ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isDebugEnabled()) {
			log.debug("getAllAssetRelationshipDef || exit");
		}
		return relationshiplist;
	}

	/**
	 * @method : getAllAssetRelationshipDef
	 * @description : to get AllAssetRelationship
	 * @param conn
	 * @return List<AssetRelationship>
	 * @throws DataNotFoundException
	 */
	public List<AssetRelationshipDef> getAllAssetRelationshipforGrid(Connection conn,int from) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllAssetRelationshipDef || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<AssetRelationshipDef> relationshiplist = new ArrayList<AssetRelationshipDef>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDef||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_ALL_ASSET_RELATIONSHIP_DEFS_FOR_GRID));
			preparedStmt.setInt(Constants.ONE,from);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDef ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_ASSET_RELATIONSHIP_DEFS_FOR_GRID));
			}
			while (rs.next()) {
				AssetRelationshipDef relationship = new AssetRelationshipDef();
				relationship.setAssetRelId(rs.getLong("asset_rel_id"));
				relationship.setSrcAssetName(rs.getString("src_asset_name"));
				relationship.setDestAssetName(rs.getString("dest_asset_name"));
				relationship.setFwdRelationType(rs.getString("fwd_rel_name"));
				relationship.setBwdRelationType(rs.getString("bwd_rel_name"));
				relationship.setDescription(rs.getString("description"));
				relationship.setSrcAssetId(rs.getLong("src_asset_id"));
				relationship.setDestAssetId(rs.getLong("dest_asset_id"));
				relationship.setFwdRelId(rs.getLong("fwd_rel_id"));
				relationship.setBwdRelId(rs.getLong("bwd_rel_id"));
				relationship.setSrcImageName(rs.getString("src_image_name"));
				relationship.setDestImageName(rs.getString("dest_image_name"));
				relationshiplist.add(relationship);
				if (log.isTraceEnabled()) {
					log.trace("getAllAssetRelationshipDef ||"
							+ relationship.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetRelationshipDef ||"
						+ relationshiplist.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAllAssetRelationshipDef ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetRelationshipDef ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetRelationshipDef ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetRelationshipDef ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isDebugEnabled()) {
			log.debug("getAllAssetRelationshipDef || exit");
		}
		return relationshiplist;
	}
	/**
	 * @method : retAssetRelationshipDefByDestAssetId
	 * @param destAssetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetRelationshipDef> retAssetRelationshipDefByDestAssetId(Long destAssetId,Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("retAssetRelationshipDefByDestAssetId || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<AssetRelationshipDef> relationshiplist = new ArrayList<AssetRelationshipDef>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retAssetRelationshipDefByDestAssetId||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_ASSET_RELATIONSHIPDEF_BY_DEST_ASSETID));
			preparedStmt.setLong(Constants.ONE, destAssetId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retAssetRelationshipDefByDestAssetId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_ASSET_RELATIONSHIPDEF_BY_DEST_ASSETID));
			}
			while (rs.next()) {
				AssetRelationshipDef relationship = new AssetRelationshipDef();
				relationship.setAssetRelId(rs.getLong("asset_rel_id"));
				relationship.setSrcAssetId(rs.getLong("src_asset_id"));
				relationship.setDestAssetId(rs.getLong("dest_asset_id"));
				relationship.setFwdRelId(rs.getLong("fwd_rel_id"));
				relationship.setBwdRelId(rs
						.getLong("bwd_rel_id"));
				relationship.setDescription(rs.getString("description"));

				relationshiplist.add(relationship);
				if (log.isTraceEnabled()) {
					log.trace("retAssetRelationshipDefByDestAssetId ||"
							+ relationship.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retAssetRelationshipDefByDestAssetId ||"
						+ relationshiplist.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retAssetRelationshipDefByDestAssetId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("retAssetRelationshipDefByDestAssetId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retAssetRelationshipDefByDestAssetId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retAssetRelationshipDefByDestAssetId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isDebugEnabled()) {
			log.debug("retAssetRelationshipDefByDestAssetId || exit");
		}
		return relationshiplist;
	}

	/**
	 * @method : getAllAssetInstRelationshipsForAssetRelId
	 * @description : to get AllAssetInstRelationships
	 * @param assetRelId
	 * @param conn
	 * @return List<AssetInstRelationship>
	 * @throws DataNotFoundException
	 */
	public List<AssetInstRelationship> getAllAssetInstRelationshipsForAssetRelId(
			Long assetRelId, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllAssetInstRelationshipsForAssetRelId ||where assetRalId:"
					+ assetRelId + "|| begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<AssetInstRelationship> relationshiplist = new ArrayList<AssetInstRelationship>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstRelationshipsForAssetRelId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_ASSET_INST_RELATION_SHIP_FOR_ASSET));
			preparedStmt.setLong(1, assetRelId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstRelationshipsForAssetRelId ||"
						+ PropertyFileReader
						.getInstance()
						.getValue(
								Constants.RET_ASSET_INST_RELATION_SHIP_FOR_ASSET));
			}
			while (rs.next()) {
				AssetInstRelationship relationship = new AssetInstRelationship();

				relationship.setAssetInstRelId(rs.getLong("asset_inst_rel_id"));
				relationship.setSrcAssetInstVersionId(rs
						.getLong("src_asset_inst_version_id"));
				relationship.setDestAssetInstVersionId(rs
						.getLong("dest_asset_inst_version_id"));
				relationship.setAssetRelId(rs.getLong("asset_rel_id"));
				relationshiplist.add(relationship);
				if (log.isTraceEnabled()) {
					log.trace("getAllAssetInstRelationshipsForAssetRelId ||"
							+ relationship.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetInstRelationshipsForAssetRelId ||"
						+ relationshiplist.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAllAssetInstRelationshipsForAssetRelId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetInstRelationshipsForAssetRelId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetInstRelationshipsForAssetRelId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetInstRelationshipsForAssetRelId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isDebugEnabled()) {
			log.debug("getAllAssetInstRelationshipsForAssetRelId ||where assetRalId:"
					+ assetRelId + "|| exit");
		}
		return relationshiplist;
	}

	/**
	 * @method : deleteAssetRelationshipDefByAssetRelId
	 * @description : to delete AssetRelationship
	 * @param assetRelId
	 * @param conn
	 * @return integer value number of rows deleted
	 * @throws DeleteContentException
	 */
	public int deleteAssetInstRelationship(String SrcAssetInstanceVersionId,Long RemovedDestAssetInstVersionIds,Long RemovedAssetRelationshipIds, Connection conn) 
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRelationshipDefByAssetRelId || Begin with  descassetinstanceversionid: " + RemovedDestAssetInstVersionIds
					+"srcassetinstanceversionid:"+SrcAssetInstanceVersionId+"assetrelationshipId:"+RemovedAssetRelationshipIds);
		}

		PreparedStatement preparedStmt = null;
		Connection conn1 = null;
		int result = 0;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationshipDefByAssetRelId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance()
					.getValue(Constants.DELETE_ASSET_INST_RELATIONSHIP));
			
			preparedStmt.setString(Constants.ONE, SrcAssetInstanceVersionId);
			preparedStmt.setLong(Constants.TWO, RemovedDestAssetInstVersionIds);
			preparedStmt.setLong(Constants.THREE, RemovedAssetRelationshipIds);
			result = preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationshipDefByAssetRelId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_ASSET_INST_RELATIONSHIP));
			}
			

		} catch (SQLException e) {
			log.error("SQL Exception deleteAssetRelationshipDefByAssetRelId||"
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSET_RELATION_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteAssetRelationshipDefByAssetRelId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteAssetRelationshipDefByAssetRelId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteAssetRelationshipDefByAssetRelId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {

			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationshipDefByAssetRelId ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRelationshipDefByAssetRelId || End");
		}
		return result;
	}

	/**
	 * @method : addRelationBetAssetsWithName
	 * @description : to add AssetRelationship
	 * @param assetRelationshipDef
	 * @param conn
	 * @return AssetRelationshipDef
	 * @throws DataNotFoundException
	 */
	public AssetRelationshipDef addRelationBetAssetsWithName(AssetRelationshipDef assetRelationshipDef, 
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addRelationBetAssetsWithName ||"
					+ assetRelationshipDef.toString() + "|| begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addRelationBetAssetsWithName ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			assetRelationshipDef
			.setBwdRelId(assetRelationshipDef.getFwdRelId() + 1);

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_RELATION_DATA));
			preparedStmt.setLong(Constants.ONE,
					assetRelationshipDef.getSrcAssetId());
			preparedStmt.setLong(Constants.TWO,
					assetRelationshipDef.getDestAssetId());
			preparedStmt.setLong(Constants.THREE,
					assetRelationshipDef.getFwdRelId());
			preparedStmt.setLong(Constants.FOUR,
					assetRelationshipDef.getBwdRelId());
			preparedStmt.setString(Constants.FIVE,
					assetRelationshipDef.getDescription());

			preparedStmt.execute();
			rs = preparedStmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				assetRelationshipDef.setAssetRelId(rs.getLong(1));
			}
			if (log.isTraceEnabled()) {
				log.trace("addRelationBetAssetsWithName ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_RELATION_DATA));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("addRelationBetAssetsWithName ||"
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED));
		} catch (IOException e) {
			log.error("addRelationBetAssetsWithName ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addRelationBetAssetsWithName ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addRelationBetAssetsWithName ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isDebugEnabled()) {
			log.debug("addRelationBetAssetsWithName || "
					+ assetRelationshipDef.toString() + "||exit");
		}
		return assetRelationshipDef;
	}

	/**
	 * @method : updateRelationBetAssetsWithName
	 * @description : to update AssetRelationship
	 * @param assetRelationshipDef
	 * @param assetRelationshipDef
	 * @param conn
	 * @return AssetRelationshipDef
	 * @throws DataNotFoundException
	 */
	public AssetRelationshipDef updateRelationBetAssetsWithName(AssetRelationshipDef assetRelationshipDef, 
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateRelationBetAssetsWithName || "
					+ assetRelationshipDef.toString() + "||begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("updateRelationBetAssetsWithName ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			assetRelationshipDef
			.setBwdRelId(assetRelationshipDef.getFwdRelId() + 1);

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_RELATION_DATA));
			preparedStmt.setLong(Constants.ONE,
					assetRelationshipDef.getSrcAssetId());
			preparedStmt.setLong(Constants.TWO,
					assetRelationshipDef.getDestAssetId());
			preparedStmt.setLong(Constants.THREE,
					assetRelationshipDef.getFwdRelId());
			preparedStmt.setLong(Constants.FOUR,
					assetRelationshipDef.getBwdRelId());
			preparedStmt.setString(Constants.FIVE,
					assetRelationshipDef.getDescription());
			preparedStmt.setLong(Constants.SIX,
					assetRelationshipDef.getAssetRelId());

			preparedStmt.execute();

			if (log.isTraceEnabled()) {
				log.trace("updateRelationBetAssetsWithName ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_RELATION_DATA));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("updateRelationBetAssetsWithName ||"
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED_TO_UPDATE));
		} catch (IOException e) {
			log.error("updateRelationBetAssetsWithName ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateRelationBetAssetsWithName ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateRelationBetAssetsWithName ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isDebugEnabled()) {
			log.debug("updateRelationBetAssetsWithName || "
					+ assetRelationshipDef.toString() + "||exit");
		}
		return assetRelationshipDef;
	}

	/**
	 * @method : getAllReverseRelationships
	 * @param assetInstanceVersionId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetInstanceVersion> getAllReverseRelationships(Long assetInstanceVersionId, Connection conn) 
			throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getAllReverseRelationships || begin with assetInstanceVersionId : "+ assetInstanceVersionId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetInstanceVersion aiv = null;
		List<AssetInstanceVersion> aivList = new ArrayList<AssetInstanceVersion>();

		try {
			if (log.isTraceEnabled()){
				log.trace("getAllReverseRelationships || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_REVERSE_RELATIONSHIPS));

			pstmt.setLong(Constants.ONE, assetInstanceVersionId);

			if (log.isTraceEnabled()) {
				log.trace("getAllReverseRelationships || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_REVERSE_RELATIONSHIPS));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				aiv = new AssetInstanceVersion();
				aiv.setIconImageName(rs.getString("icon_image_name"));
				aiv.setAssetId(rs.getLong("asset_id"));
				aiv.setAssetName(rs.getString("asset_name"));
				aiv.setRelName(rs.getString("description"));
				aiv.setAssetInstName(rs.getString("asset_inst_name"));
				aiv.setRelType(rs.getString("relationship_name"));
				aiv.setRelId(rs.getLong("relationship_id"));
				aiv.setFwdRelId(rs.getLong("fwd_rel_id"));
				aiv.setDestAssetInstVersionId(rs.getString("dest_asset_inst_version_id"));
				aiv.setSrcAssetInstanceVersionId(rs.getString("src_asset_inst_version_id"));
				aiv.setVersionName(rs.getString("version_name"));
				aiv.setAssetRelId(rs.getLong("asset_rel_id"));
				aiv.setVersionable(rs.getBoolean("versionable"));
				aivList.add(aiv);

				if(log.isTraceEnabled()){
					log.trace("getAllReverseRelationships || "+ aiv.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllReverseRelationships || "+ aivList.toString());
			}


		} catch (SQLException e) {
			log.error("getAllReverseRelationships || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.REVERSE_RELATIONSHIPS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllReverseRelationships || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllReverseRelationships || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllReverseRelationships || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllReverseRelationships || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if(log.isTraceEnabled()){
			log.trace("getAllReverseRelationships || End");
		}
		return aivList;
	}


	/**
	 * @method : retAssetRelDefForAssetsByRelationName
	 * @param srcAssetName
	 * @param destAssetName
	 * @param relationName
	 * @param conn
	 * @return
	 * @throws RepoproException 
	 */
	public AssetRelationshipDef retAssetRelDefForAssetsByRelationName(String srcAssetName,String destAssetName,String relationName,Connection conn) throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("retAssetRelDefForAssetsByRelationName ||   begin with "+srcAssetName +" "+destAssetName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		AssetRelationshipDef assetRelationshipDef = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("retAssetRelDefForAssetsByRelationName ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}


			if (log.isTraceEnabled()) {
				log.trace("retAssetRelDefForAssetsByRelationName ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_RELATIONSHIP_DEF_BY_RELATION_NAME));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_RELATIONSHIP_DEF_BY_RELATION_NAME));

			preparedStmt.setString(1, srcAssetName);
			preparedStmt.setString(2, relationName);
			preparedStmt.setString(3, destAssetName);

			rs = preparedStmt.executeQuery();

			while (rs.next()) {
				assetRelationshipDef = new AssetRelationshipDef();
				assetRelationshipDef.setAssetRelId(rs.getLong("asset_rel_id"));
			}


		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retAssetRelDefForAssetsByRelationName ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED));
		} catch (IOException e) {
			log.error("retAssetRelDefForAssetsByRelationName ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retAssetRelDefForAssetsByRelationName ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retAssetRelDefForAssetsByRelationName ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isDebugEnabled()) {
			log.trace("retAssetRelDefForAssetsByRelationName ||exit");
		}
		return assetRelationshipDef;
	}


	/**
	 * @method : getAssetInstanceAndVersionDetailsByVersionId
	 * @param assetInstanceVersionId
	 * @param conn
	 * @return
	 * @throws RepoproException 
	 */
	public String[] getAssetInstanceAndVersionDetailsByVersionId(Long assetInstanceVersionId,Connection conn) throws RepoproException{

		if (log.isDebugEnabled()) {
			log.trace("getAssetInstanceAndVersionDetailsByVersionId Begins with || assetInstanceVersionId "+assetInstanceVersionId);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		String[] assetInstanceNameandVersionName =  new String[2];
		try{
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAndVersionDetailsByVersionId ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAndVersionDetailsByVersionId ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_INSTANCE_NAME_AND_VERSION_NAME_BY_ASSET_INSTANCE_VERSION_ID));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_INSTANCE_NAME_AND_VERSION_NAME_BY_ASSET_INSTANCE_VERSION_ID));
			preparedStmt.setLong(1, assetInstanceVersionId);
			rs = preparedStmt.executeQuery();
			
			while(rs.next()){
				assetInstanceNameandVersionName[0] = rs.getString("asset_inst_name");
				assetInstanceNameandVersionName[1] = rs.getString("version_name");
				if (log.isDebugEnabled()) {
					log.trace("getAssetInstanceAndVersionDetailsByVersionId ||"+assetInstanceNameandVersionName[0]+" "+assetInstanceNameandVersionName[1] );
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAssetInstanceAndVersionDetailsByVersionId ||"+assetInstanceNameandVersionName[0]+" "+assetInstanceNameandVersionName[1] );
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAssetInstanceAndVersionDetailsByVersionId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED));
		} catch (IOException e) {
			log.error("getAssetInstanceAndVersionDetailsByVersionId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetInstanceAndVersionDetailsByVersionId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetInstanceAndVersionDetailsByVersionId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isDebugEnabled()) {
			log.trace("getAssetInstanceAndVersionDetailsByVersionId || end");
		}
		return assetInstanceNameandVersionName;	
	}


	/**
	 * @method : retAssetInstanceByTypeAndName
	 * @param assetName
	 * @param assetInstanceName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetInstance retAssetInstanceByTypeAndName(String assetName,String assetInstanceName,Connection conn)throws RepoproException{

		if (log.isDebugEnabled()) {
			log.trace("retAssetInstanceByTypeAndName Begins with || assetName "+assetName+" assetInstanceName "+assetInstanceName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetInstance ai = new AssetInstance();

		try{
			if (log.isTraceEnabled()) {
				log.trace("retAssetInstanceByTypeAndName ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retAssetInstanceByTypeAndName ||"+ PropertyFileReader.getInstance().getValue(Constants.RET_ASSET_INST_BY_ASSET_NAME_AND_INST_NAME_MY));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.RET_ASSET_INST_BY_ASSET_NAME_AND_INST_NAME_MY));
			preparedStmt.setString(1, assetName);
			preparedStmt.setString(2, assetInstanceName);
			rs = preparedStmt.executeQuery();
			while(rs.next()){
				assetInstanceName = rs.getString("asset_inst_name");
				if (log.isDebugEnabled()) {
					log.trace("retAssetInstanceByTypeAndName ||"+assetInstanceName );
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retAssetInstanceByTypeAndName ||"+assetInstanceName );
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retAssetInstanceByTypeAndName ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED));
		} catch (IOException e) {
			log.error("retAssetInstanceByTypeAndName ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retAssetInstanceByTypeAndName ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retAssetInstanceByTypeAndName ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isDebugEnabled()) {
			log.trace("retAssetInstanceByTypeAndName || end");
		}
		return ai;	
	}


	/**
	 * @method : getDependants
	 * @param assetInstanceVersionId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetInstance> getDependants(Long assetInstanceVersionId,Connection conn)throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getDependants || begins with assetInstanceVersionId || "+assetInstanceVersionId);
		}

		RelationshipDao relationShipDao = new RelationshipDao();
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<AssetInstance> assetInstances;
		assetInstances = new ArrayList<AssetInstance>();
		try{
			if (log.isTraceEnabled()) {
				log.trace("getDependants ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			AssetInstance assetInstance = null;
			List<AssetInstRelationship> airs = null;
			if(log.isTraceEnabled()){
				log.trace("getDependants || dao method calling || retFwdRelationsForAnAssetInstanceVersionId || "+assetInstanceVersionId);
			}

			airs = relationShipDao.retFwdRelationsForAnAssetInstanceVersionId(assetInstanceVersionId, conn);
			for(AssetInstRelationship air : airs){
				assetInstance = new AssetInstance();
				assetInstance.setAssetInstVersionId(air.getDestAssetInstVersionId());
				assetInstance.setAssetRelationshipName(air.getDescrption());
				assetInstance.setAssetRelationshipType(air.getRelationShipName());
				assetInstance.setAssetName(air.getAssetName());
				assetInstance.setDescription(air.getDescrption());
				assetInstance.setVersionName(air.getVersionName());
				assetInstance.setAssetInstId(air.getAssetInstanceId());
				assetInstance.setAssetInstName(air.getAssetInstanceName());
				assetInstance.setAssetRelationshipId(air.getAssetrelationShipId().toString());
				if(air.getVersionable().equals("1")){
					assetInstance.setVersionable(true);
				}else{
					assetInstance.setVersionable(false);
				}
				assetInstances.add(assetInstance);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getDependants ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED));
		} catch (IOException e) {
			log.error("getDependants ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getDependants ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getDependants ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isDebugEnabled()) {
			log.trace("getDependants || end");
		}
		return assetInstances;
	}

	/**
	 * @method : retFwdRelationsForAnAssetInstanceVersionId
	 * @param assetInstanceVersionId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetInstRelationship> retFwdRelationsForAnAssetInstanceVersionId(Long assetInstanceVersionId,Connection conn)throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("retFwdRelationsForAnAssetInstanceVersionId Begins with assetInstanceVersionId  || "+assetInstanceVersionId);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetInstRelationship air =null;
		List<AssetInstRelationship> listOfAirs = new ArrayList<AssetInstRelationship>();

		try{
			if (log.isTraceEnabled()) {
				log.trace("retFwdRelationsForAnAssetInstanceVersionId ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retFwdRelationsForAnAssetInstanceVersionId ||"+ PropertyFileReader.getInstance().getValue(Constants.RET_FWD_ASSET_RELATIONSHIP_INSTANCE_FOR_ASSET_INSTANCE_VERSION_ID_ALL_RELATIONTYPES));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.RET_FWD_ASSET_RELATIONSHIP_INSTANCE_FOR_ASSET_INSTANCE_VERSION_ID_ALL_RELATIONTYPES));

			preparedStmt.setLong(1, assetInstanceVersionId);
			rs = preparedStmt.executeQuery();

			while(rs.next()){

				air= new AssetInstRelationship();
				air.setDestAssetInstVersionId(rs.getLong("dest_asset_inst_version_id"));
				air.setAssetrelationShipId(rs.getLong("asset_rel_id"));
				air.setRelationShipName(rs.getString("relationship_name"));
				air.setAssetName(rs.getString("asset_name"));
				air.setDescrption(rs.getString("description"));
				air.setVersionName(rs.getString("version_name"));
				air.setAssetInstanceName(rs.getString("asset_inst_name"));
				air.setAssetInstanceId(rs.getLong("asset_instance_id"));
				air.setAssetId(rs.getLong("asset_id"));
				air.setFwdRelationId(rs.getLong("fwd_rel_id"));
				air.setVersionable(rs.getString("versionable"));
				listOfAirs.add(air);
				if(log.isTraceEnabled()){
					log.trace("retFwdRelationsForAnAssetInstanceVersionId || "+ air.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("retFwdRelationsForAnAssetInstanceVersionId || "+ listOfAirs.toString());
			}


		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retFwdRelationsForAnAssetInstanceVersionId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED));
		} catch (IOException e) {
			log.error("retFwdRelationsForAnAssetInstanceVersionId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retFwdRelationsForAnAssetInstanceVersionId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retFwdRelationsForAnAssetInstanceVersionId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if(log.isTraceEnabled()){
			log.trace("retFwdRelationsForAnAssetInstanceVersionId || End ");
		}

		return listOfAirs;
	}


	/**
	 * @method : retAssetRelDefById
	 * @param assetRelationShipId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */

	public AssetRelationshipDef retAssetRelDefById(Long assetRelationShipId,Connection conn)throws RepoproException{
		if(log.isTraceEnabled()){
			log.trace("retAssetRelDefById Begins with assetRelationShipId  || "+assetRelationShipId);
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetRelationshipDef assetRelationshipDef = new AssetRelationshipDef();
		try{
			if (log.isTraceEnabled()) {
				log.trace("retAssetRelDefById ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retAssetRelDefById ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_RELATION_SHIP_DEF_BY_ASSET_RELATION_SHIP_ID));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_RELATION_SHIP_DEF_BY_ASSET_RELATION_SHIP_ID));

			preparedStmt.setLong(1, assetRelationShipId);
			rs = preparedStmt.executeQuery();

			while(rs.next()){
				assetRelationshipDef.setFwdRelId(rs.getLong("fwd_rel_id"));
				assetRelationshipDef.setDescription(rs.getString("description"));
				if(log.isTraceEnabled()){
					log.trace("retAssetRelDefById || "+ assetRelationshipDef.toString());
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retAssetRelDefById ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED));
		} catch (IOException e) {
			log.error("retAssetRelDefById ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retAssetRelDefById ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retAssetRelDefById ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}

		if(log.isTraceEnabled()){
			log.trace("retAssetRelDefById || End ");
		}
		return assetRelationshipDef;
	}

	/**
	 * @method : getAssetParamDefByDerivedAttributeIsNotNull
	 * @description : to get getAssetParamDefByDerivedAttributeIsNotNull
	 * @return Response Success message
	 */
	public List<AssetParamDef> getAssetParamDefByDerivedAttributeIsNotNull(Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAssetParamDefByDerivedAttributeIsNotNull ||  Begin");
		}

		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Connection conn1 = null;
		List<AssetParamDef> listOfParams = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDefByDerivedAttributeIsNotNull || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if(conn==null){
				conn1 = DBConnection.getInstance().getConnection();
				conn1 = conn;
			}


			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDefByDerivedAttributeIsNotNull ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAM_DEF_BY_DERIVED_ATTRIBUTE_IS_NOT_NULL));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAM_DEF_BY_DERIVED_ATTRIBUTE_IS_NOT_NULL));

			rs = preparedStmt.executeQuery();
			listOfParams = new ArrayList<AssetParamDef>();

			while(rs.next()){
				AssetParamDef apd = new AssetParamDef();
				apd.setAssetParamName(rs.getString("asset_param_name"));
				apd.setAssetParamId(rs.getLong("asset_param_id"));
				apd.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				apd.setParamTypeId(rs.getLong("param_type_id"));
				listOfParams.add(apd);

			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAssetParamDefByDerivedAttributeIsNotNull ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.ASSET_PARAM_DEF_NOT_FETCHED));
		} catch (IOException e) {
			log.error("getAssetParamDefByDerivedAttributeIsNotNull ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetParamDefByDerivedAttributeIsNotNull ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetParamDefByDerivedAttributeIsNotNull ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDefByDerivedAttributeIsNotNull||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllRelationships|| End");
		}

		return listOfParams;

	}

	/**
	 * @method : updateDerivedRuleWithRelationName
	 * @description : to get updateDerivedRuleWithRelationName
	 * @return Response Success message
	 */
	public void updateDerivedRuleWithRelationName(AssetParamDef apd,Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateDerivedRuleWithRelationName ||  Begin with "+apd.getAssetParamId());
		}

		PreparedStatement preparedStmt = null;
		Connection conn1 = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateDerivedRuleWithRelationName || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if(conn==null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}


			if (log.isTraceEnabled()) {
				log.trace("updateDerivedRuleWithRelationName ||"+ PropertyFileReader.getInstance().getValue(Constants.UPDATE_DERIVED_ATTRIBUTE_COMPUTATION_RULE_RELATION_NAME));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_DERIVED_ATTRIBUTE_COMPUTATION_RULE_RELATION_NAME));

			preparedStmt.setString(Constants.ONE, apd.getDerivedAttributeComputation());
			preparedStmt.setLong(Constants.TWO, apd.getAssetParamId());

			preparedStmt.executeUpdate();


		} catch (SQLException e) {
			e.printStackTrace();
			log.error("updateDerivedRuleWithRelationName ||"
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.UPDATE_DERIVED_RULE_FAILED));
		} catch (IOException e) {
			log.error("updateDerivedRuleWithRelationName ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateDerivedRuleWithRelationName ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateDerivedRuleWithRelationName ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {

			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("updateDerivedRuleWithRelationName||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("updateDerivedRuleWithRelationName|| End");
		}

	}


	/**
	 * @method : retRvrRelationsForAnAssetInstanceVersionId
	 * @param srcVersionId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetInstRelationship> retRvrRelationsForAnAssetInstanceVersionId(
			Long srcVersionId, Connection conn)throws RepoproException  {

		if (log.isTraceEnabled()) {
			log.trace("retRvrRelationsForAnAssetInstanceVersionId Begins with assetInstanceVersionId || "
					+ srcVersionId);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetInstRelationship air = null;
		List<AssetInstRelationship> listOfAirs = new ArrayList<AssetInstRelationship>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retRvrRelationsForAnAssetInstanceVersionId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retRvrRelationsForAnAssetInstanceVersionId ||"
						+ PropertyFileReader.getInstance().getValue(Constants.RET_RVR_ASSET_RELATIONSHIP_INSTANCE_FOR_ASSET_INSTANCE_VERSION_ID));
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.RET_RVR_ASSET_RELATIONSHIP_INSTANCE_FOR_ASSET_INSTANCE_VERSION_ID));

			preparedStmt.setLong(1, srcVersionId);
			rs = preparedStmt.executeQuery();

			while (rs.next()) {

				air = new AssetInstRelationship();
				air.setSrcAssetInstVersionId(rs.getLong("src_asset_inst_version_id"));
				air.setAssetrelationShipId(rs.getLong("asset_rel_id"));
				air.setRelationShipName(rs.getString("relationship_name"));
				air.setAssetName(rs.getString("asset_name"));
				air.setDescrption(rs.getString("description"));
				air.setVersionName(rs.getString("version_name"));
				air.setAssetInstanceName(rs.getString("asset_inst_name"));
				air.setAssetInstanceId(rs.getLong("asset_instance_id"));

				listOfAirs.add(air);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retRvrRelationsForAnAssetInstanceVersionId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.REVERSE_RELATIONSHIPS_NOT_FOUND));
		} catch (IOException e) {
			log.error("retRvrRelationsForAnAssetInstanceVersionId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retRvrRelationsForAnAssetInstanceVersionId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retRvrRelationsForAnAssetInstanceVersionId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}

		}

		if (log.isTraceEnabled()) {
			log.trace("retRvrRelationsForAnAssetInstanceVersionId || End ");
		}

		return listOfAirs;

	}


	/**
	 * @method : addAssetInstRelationship
	 * @param tempAir
	 * @param conn
	 * @throws RepoproException
	 */
	public void addAssetInstRelationship(AssetInstRelationship tempAir,
			Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addAssetInstRelationship || " + tempAir.toString() + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}


			if (log.isTraceEnabled()) {
				log.trace("addAssetInstRelationship || " + Constants.LOG_CONNECTION_OPEN);
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_ASSET_INST_RELATIONSHIP));

			pstmt.setLong(Constants.ONE, tempAir.getSrcAssetInstVersionId());
			pstmt.setLong(Constants.TWO, tempAir.getDestAssetInstVersionId());
			pstmt.setLong(Constants.THREE,tempAir.getAssetRelId());


			if (log.isTraceEnabled()) {
				log.trace("addAssetInstRelationship || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_ASSET_INST_RELATIONSHIP));
			}

			pstmt.executeUpdate();

			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				tempAir.setAssetInstRelId(rs.getLong(1));
			}


		} catch (SQLException e) {
			log.error("addAssetInstRelationship || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ADD_ASSET_INST_RELATIONSHIP_NOT_CREATED));
		} catch (IOException e) {
			log.error("addAssetInstRelationship || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addAssetInstRelationship || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addAssetInstRelationship || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstRelationship || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("addAssetInstRelationship || " + tempAir.toString() + " End");
		}		
	}
	/**
	 * @method deleteAssetRelationshipDefByAssetRelId
	 * @param assetRelId
	 * @param conn
	 * @return int
	 * @throws RepoproException
	 */
	public int deleteAssetRelationshipDefByAssetRelId(Long assetRelId, Connection conn) 
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRelationshipDefByAssetRelId || Begin with assetRelId : " + assetRelId);
		}

		PreparedStatement preparedStmt = null;
		Connection conn1 = null;
		int result = 0;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationshipDefByAssetRelId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance()
					.getValue(Constants.DELETE_ASSET_RELATIONSHIP));
			preparedStmt.setLong(Constants.ONE, assetRelId);
			result = preparedStmt.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationshipDefByAssetRelId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_ASSET_RELATIONSHIP));
			}
			

		} catch (SQLException e) {
			log.error("SQL Exception deleteAssetRelationshipDefByAssetRelId||"
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.ASSET_RELATION_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteAssetRelationshipDefByAssetRelId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteAssetRelationshipDefByAssetRelId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteAssetRelationshipDefByAssetRelId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {

			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationshipDefByAssetRelId ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRelationshipDefByAssetRelId || End");
		}
		return result;
	}
	
	/**
	 * @method : retRelationshipsByassetId
	 * @param assetInstanceVersionId
	 * @param conn
	 * @return List<AssetInstRelationship>
	 * @throws RepoproException
	 */
	public List<AssetInstRelationship> retAvailableAssetRelationship(Long srcAssetId,Long destAssetId,Long assetInstId,String userName,Connection conn)throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("retAvailableAssetRelationship Begins with || srcAssetId:"+srcAssetId+"destAssetId:"+destAssetId+"assetInstId:"+assetInstId+"userName:"+userName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetInstRelationship air =null;
		List<AssetInstRelationship> listOfAirs = new ArrayList<AssetInstRelationship>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		Boolean flag = true;
		try{
			if (log.isTraceEnabled()) {
				log.trace("retAvailableAssetRelationship ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			
			flag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);	
			
			if(flag){
				if(srcAssetId == destAssetId){
					if (log.isTraceEnabled()) {
						log.trace("retAvailableAssetRelationship ||"+ PropertyFileReader.getInstance().getValue(Constants.RET_RELATIONSHIPS_BY_SAME_ASSETIDS_FOR_ADMIN));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.RET_RELATIONSHIPS_BY_SAME_ASSETIDS_FOR_ADMIN));

					preparedStmt.setLong(Constants.ONE, destAssetId);
					preparedStmt.setLong(Constants.TWO, srcAssetId);
					preparedStmt.setLong(Constants.THREE, destAssetId);
					preparedStmt.setLong(Constants.FOUR, assetInstId);

				}else{
					if (log.isTraceEnabled()) {
						log.trace("retAvailableAssetRelationship ||"+ PropertyFileReader.getInstance().getValue(Constants.RET_RELATIONSHIPS_BY_ASSETID_FOR_ADMIN));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.RET_RELATIONSHIPS_BY_ASSETID_FOR_ADMIN));

					preparedStmt.setLong(Constants.ONE, destAssetId);
					preparedStmt.setLong(Constants.TWO, srcAssetId);
					preparedStmt.setLong(Constants.THREE, destAssetId);

				}
			}
			else{
				if(srcAssetId == destAssetId){
					if (log.isTraceEnabled()) {
						log.trace("retAvailableAssetRelationship ||"+ PropertyFileReader.getInstance().getValue(Constants.RET_RELATIONSHIPS_BY_SAME_ASSETIDS_FOR_NON_ADMIN));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.RET_RELATIONSHIPS_BY_SAME_ASSETIDS_FOR_NON_ADMIN));

					preparedStmt.setLong(Constants.ONE, destAssetId);
					preparedStmt.setLong(Constants.TWO, srcAssetId);
					preparedStmt.setLong(Constants.THREE, destAssetId);
					preparedStmt.setString(Constants.FOUR, userName);
					preparedStmt.setLong(Constants.FIVE, assetInstId);
				

				}else{
					if (log.isTraceEnabled()) {
						log.trace("retAvailableAssetRelationship ||"+ PropertyFileReader.getInstance().getValue(Constants.RET_RELATIONSHIPS_BY_ASSETID_FOR_NON_ADMIN));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.RET_RELATIONSHIPS_BY_ASSETID_FOR_NON_ADMIN));

					preparedStmt.setLong(Constants.ONE, destAssetId);
					preparedStmt.setLong(Constants.TWO, srcAssetId);
					preparedStmt.setLong(Constants.THREE, destAssetId);
					preparedStmt.setString(Constants.FOUR, userName);

				}
			}
			
			
			rs = preparedStmt.executeQuery();

			while(rs.next()){

				air= new AssetInstRelationship();
				air.setDestAssetInstVersionId(rs.getLong("asset_instance_version_id"));
				air.setAssetrelationShipId(rs.getLong("asset_rel_id"));
				air.setVersionable(rs.getString("versionable"));
				air.setDescrption(rs.getString("description"));
				air.setVersionName(rs.getString("version_name"));
				air.setAssetInstanceName(rs.getString("asset_inst_name"));
				air.setAssetInstanceId(rs.getLong("asset_inst_id"));
				air.setAssetId(rs.getLong("asset_id"));
				air.setAssetName(rs.getString("asset_name"));
				air.setFwdRelationId(rs.getLong("fwd_rel_id"));

				listOfAirs.add(air);
				if(log.isTraceEnabled()){
					log.trace("retRelationshipsByassetId || "+ air.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("retRelationshipsByassetId || "+ listOfAirs.toString());
			}


		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retRelationshipsByassetId ||"
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED));
		} catch (IOException e) {
			log.error("retRelationshipsByassetId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retRelationshipsByassetId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retRelationshipsByassetId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if(log.isTraceEnabled()){
			log.trace("retRelationshipsByassetId || End ");
		}

		return listOfAirs;
	}
	
	/**
	 * @method getAllRelationshipsByAssetInstVersionId 
	 * @param assetInstVersionId
	 * @param conn
	 * @return List<AssetRelationshipDef>
	 * @throws RepoproException
	 */
	public List<AssetRelationshipDef> getAllRelationshipsByAssetInstVersionId(Long assetInstVersionId,Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllRelationshipsByAssetInstVersionId || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<AssetRelationshipDef> relationshiplist = new ArrayList<AssetRelationshipDef>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllRelationshipsByAssetInstVersionId||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance()
					.getValue(Constants.GET_ALL_RELATIONSHIPS_BY_ASSET_INSTANCE_VERSION_ID));

			preparedStmt.setLong(Constants.ONE, assetInstVersionId);
			
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationshipsByAssetInstVersionId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_RELATIONSHIPS_BY_ASSET_INSTANCE_VERSION_ID));
			}
			while (rs.next()) {
				
				AssetRelationshipDef ard = new AssetRelationshipDef();
				
				ard.setDescription(rs.getString("description"));
				ard.setFwdRelId(rs.getLong("fwd_rel_id"));
				relationshiplist.add(ard);
				
				if (log.isTraceEnabled()) {
					log.trace("getAllRelationshipsByAssetInstVersionId ||"
							+ ard.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllRelationshipsByAssetInstVersionId ||"
						+ relationshiplist.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAllRelationshipsByAssetInstVersionId ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("getAllRelationshipsByAssetInstVersionId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllRelationshipsByAssetInstVersionId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllRelationshipsByAssetInstVersionId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isTraceEnabled()) {
			log.trace("getAllRelationshipsByAssetInstVersionId || exit");
		}
		return relationshiplist;
	}
	
	/**
	 * @method getAvailbleAssetRelationships
	 * @param srcAssetId
	 * @param destassetid
	 * @param conn
	 * @return AssetRelationshipDef
	 * @throws RepoproException
	 */
	public List<AssetRelationshipDef> getAvailbleAssetRelationships(Long srcAssetId,Long destassetid,Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAvailbleAssetRelationships || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetRelationshipDef relationship = null;
		List<AssetRelationshipDef> relationshiplist = new ArrayList<AssetRelationshipDef>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAvailbleAssetRelationships||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ASSET_RELATIONSHIP_ID));
			preparedStmt.setLong(Constants.ONE, srcAssetId);
			preparedStmt.setLong(Constants.TWO, destassetid);
			rs = preparedStmt.executeQuery();
			
			if (log.isTraceEnabled()) {
				log.trace("getAvailbleAssetRelationships ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_RELATIONSHIP_ID));
			}
			while (rs.next()) {
				relationship = new AssetRelationshipDef();
				relationship.setAssetRelId(rs.getLong("asset_rel_id"));
				relationship.setSrcAssetId(rs.getLong("src_asset_id"));
				relationship.setDestAssetId(rs.getLong("dest_asset_id"));
				relationship.setFwdRelId(rs.getLong("fwd_rel_id"));
				relationship.setBwdRelId(rs.getLong("bwd_rel_id"));
				relationship.setDescription(rs.getString("description"));
				relationshiplist.add(relationship);
				if (log.isTraceEnabled()) {
					log.trace("getAvailbleAssetRelationships ||"+ relationship.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.trace("getAvailbleAssetRelationships ||"+ relationshiplist.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAvailbleAssetRelationships ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("getAvailbleAssetRelationships ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAvailbleAssetRelationships ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAvailbleAssetRelationships ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}

		}
		if (log.isTraceEnabled()) {
			log.trace("getAvailbleAssetRelationships || exit");
		}
		return relationshiplist;
	}
	
	
	/**
	 * @method : retAllAssetRelationshipDefsForAggregationAndCompositionType
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetRelationshipDef> retAllAssetRelationshipDefsForAggregationAndCompositionType(Connection conn) 
			throws RepoproException{
		
		log.trace("retAllAssetRelationshipDefsForAggregationAndCompositionType || Begin");
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetRelationshipDef ard = null;
		List<AssetRelationshipDef> ardList = new ArrayList<AssetRelationshipDef>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("retAllAssetRelationshipDefsForAggregationAndCompositionType || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_ALL_ARD_FOR_COMP_AGGR_RELATION));
			
			if (log.isTraceEnabled()) {
				log.trace("retAllAssetRelationshipDefsForAggregationAndCompositionType || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_ALL_ARD_FOR_COMP_AGGR_RELATION));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				ard = new AssetRelationshipDef();
				ard.setSrcAssetId(rs.getLong("src_asset_id"));
				ard.setSrcAssetName(rs.getString("src_asset_name"));
				ard.setDestAssetId(rs.getLong("dest_asset_id"));
				ard.setDestAssetName(rs.getString("dest_asset_name"));
				ardList.add(ard);
				if(log.isTraceEnabled()){
					log.trace("retAllAssetRelationshipDefsForAggregationAndCompositionType || "+ ard.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("retAllAssetRelationshipDefsForAggregationAndCompositionType || "+ ardList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("retAllAssetRelationshipDefsForAggregationAndCompositionType || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("retAllAssetRelationshipDefsForAggregationAndCompositionType || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retAllAssetRelationshipDefsForAggregationAndCompositionType || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retAllAssetRelationshipDefsForAggregationAndCompositionType || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retAllAssetRelationshipDefsForAggregationAndCompositionType || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("retAllAssetRelationshipDefsForAggregationAndCompositionType || end");
		return ardList;
	}
	
	/**
	 * @method : checkingRelationInDB
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetRelationshipDef checkingRelationInDB(String relationName ,Connection conn)throws RepoproException {
		
		log.trace("checkingRelationInDB || Begin");
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AssetRelationshipDef ard = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("checkingRelationInDB || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.CHEKING_RELATION_IN_DATABASE));
			
			if (log.isTraceEnabled()) {
				log.trace("checkingRelationInDB || "+PropertyFileReader.getInstance().
						getValue(Constants.CHEKING_RELATION_IN_DATABASE));
			}
			pstmt.setString(Constants.ONE, relationName);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				ard = new AssetRelationshipDef();
				ard.setSrcAssetId(rs.getLong("src_asset_id"));
				ard.setDestAssetId(rs.getLong("dest_asset_id"));
				ard.setAssetRelId(rs.getLong("asset_rel_id"));
				ard.setFwdRelId(rs.getLong("fwd_rel_id"));
				ard.setBwdRelId(rs.getLong("bwd_rel_id"));
				
				if(log.isTraceEnabled()){
					log.trace("checkingRelationInDB || "+ ard.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("checkingRelationInDB || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("checkingRelationInDB || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("checkingRelationInDB || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("checkingRelationInDB || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("checkingRelationInDB || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("checkingRelationInDB || end");
		return ard;
	}
	
	public Long getRelIdByReltype(String fwdRelationType, Connection conn)throws RepoproException  {
		log.trace("getRelIdByReltype() || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Long relIdId=null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getRelIdByReltype() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_RELATIONSHIP_ID_BY_TYPE));
			preparedStmt.setString(Constants.ONE,fwdRelationType);
			rs = preparedStmt.executeQuery();


			while (rs.next()) {
				relIdId=rs.getLong("relationship_id");
			}
			if (log.isTraceEnabled()) {
				log.trace("getRelIdByReltype() ||" + relIdId);
			}

		} catch (SQLException e) {
			log.error("getRelIdByReltype || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage()
					);
		} catch (IOException e) {
			log.error("getTaxonomyIdByName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getTaxonomyIdByName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getTaxonomyIdByName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomyIdByName || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getTaxonomyIdByName || End");

		return relIdId;
	}
	public Long getAssetRelId(Long sourceAssetId, Long destAssetId, String description, Connection conn)throws RepoproException {
		log.trace("getAssetRelId() || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Long assetRelId=null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getRelIdByReltype() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ASSET_RELATIONSHIP_ID_BY_DESC));
			preparedStmt.setLong(Constants.ONE,sourceAssetId);
			preparedStmt.setLong(Constants.TWO,destAssetId);
			preparedStmt.setString(Constants.THREE, description);
			rs = preparedStmt.executeQuery();


			while (rs.next()) {
				assetRelId=rs.getLong("asset_rel_id");
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetRelId() ||" + assetRelId);
			}

		} catch (SQLException e) {
			log.error("getAssetRelId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage()
					);
		} catch (IOException e) {
			log.error("getAssetRelId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAssetRelId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAssetRelId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetRelId || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAssetRelId || End");
		return assetRelId;
	}
	/**
	 * @method retAssetRelDefByrelDescription
	 * @param Description
	 * @param conn
	 * @return AssetRelationshipDef
	 * @throws RepoproException
	 */
	public AssetRelationshipDef retAssetRelDefByrelDescription(String Description,Connection conn)throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("retAssetRelDefByrelDescription Begins with Description|| "+Description);
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetRelationshipDef assetRelationshipDef = new AssetRelationshipDef();
		try{
			if (log.isTraceEnabled()) {
				log.trace("retAssetRelDefByrelDescription ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retAssetRelDefByrelDescription ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_RELATION_SHIP_DEF_BY_ASSET_RELATION_SHIP_NAME));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_RELATION_SHIP_DEF_BY_ASSET_RELATION_SHIP_NAME));

			preparedStmt.setString(Constants.ONE, Description);
			rs = preparedStmt.executeQuery();

			while(rs.next()){
				assetRelationshipDef.setAssetRelId(rs.getLong("asset_rel_id"));
				assetRelationshipDef.setFwdRelId(rs.getLong("fwd_rel_id"));
				
				if(log.isTraceEnabled()){
					log.trace("retAssetRelDefByrelDescription || "+ assetRelationshipDef.toString());
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retAssetRelDefByrelDescription ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.NO_RELATIONSHIP_DATA_PROVIDED));
		} catch (IOException e) {
			log.error("retAssetRelDefByrelDescription ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retAssetRelDefByrelDescription ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retAssetRelDefByrelDescription ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}
		}
		if(log.isTraceEnabled()){
			log.trace("retAssetRelDefByrelDescription || End ");
		}
		return assetRelationshipDef;
	}
	
	/**
	 * @method : getAllAssetRelationshipDef
	 * @description : to get AllAssetRelationship
	 * @param conn
	 * @return List<AssetRelationship>
	 * @throws DataNotFoundException
	 */
	public List<AssetRelationshipDef> getAllFilteredAssetRelationshipforGrid(Connection conn,int from , String searchStr) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllAssetRelationshipDef || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<AssetRelationshipDef> relationshiplist = new ArrayList<AssetRelationshipDef>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDef||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_ALL_ASSET_RELATIONSHIP_DEFS_FOR_GRID_FILTER));
			preparedStmt.setString(Constants.ONE,searchStr);
			preparedStmt.setString(Constants.TWO,searchStr);
			preparedStmt.setString(Constants.THREE,searchStr);
			preparedStmt.setString(Constants.FOUR,searchStr);
			preparedStmt.setInt(Constants.FIVE,from);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDef ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_ASSET_RELATIONSHIP_DEFS_FOR_GRID_FILTER));
			}
			while (rs.next()) {
				AssetRelationshipDef relationship = new AssetRelationshipDef();
				relationship.setAssetRelId(rs.getLong("asset_rel_id"));
				relationship.setSrcAssetName(rs.getString("src_asset_name"));
				relationship.setDestAssetName(rs.getString("dest_asset_name"));
				relationship.setFwdRelationType(rs.getString("fwd_rel_name"));
				relationship.setBwdRelationType(rs.getString("bwd_rel_name"));
				relationship.setDescription(rs.getString("description"));
				relationship.setSrcAssetId(rs.getLong("src_asset_id"));
				relationship.setDestAssetId(rs.getLong("dest_asset_id"));
				relationship.setFwdRelId(rs.getLong("fwd_rel_id"));
				relationship.setBwdRelId(rs.getLong("bwd_rel_id"));
				relationship.setSrcImageName(rs.getString("src_image_name"));
				relationship.setDestImageName(rs.getString("dest_image_name"));
				relationshiplist.add(relationship);
				if (log.isTraceEnabled()) {
					log.trace("getAllAssetRelationshipDef ||"
							+ relationship.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetRelationshipDef ||"
						+ relationshiplist.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAllAssetRelationshipDef ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetRelationshipDef ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetRelationshipDef ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetRelationshipDef ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}

		}
		if (log.isDebugEnabled()) {
			log.debug("getAllAssetRelationshipDef || exit");
		}
		return relationshiplist;
	}

	
	/**
	 * @method : retAssetRelationshipDefBySrcAssetId
	 * @param destAssetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetRelationshipDef> retAssetRelationshipDefBySrcAssetId(Long srcAssetId,Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("retAssetRelationshipDefBySrcAssetId || begin with srcAssetId : "+srcAssetId);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		
		AssetRelationshipDef relationship = null;
		List<AssetRelationshipDef> relationshiplist = new ArrayList<AssetRelationshipDef>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retAssetRelationshipDefBySrcAssetId||" + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_ASSET_RELATIONSHIPDEF_BY_SRC_ASSETID));
			preparedStmt.setLong(Constants.ONE, srcAssetId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retAssetRelationshipDefByDestAssetId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_ASSET_RELATIONSHIPDEF_BY_SRC_ASSETID));
			}
			while (rs.next()) {
				relationship = new AssetRelationshipDef();
				relationship.setAssetRelId(rs.getLong("asset_rel_id"));
				relationship.setSrcAssetId(rs.getLong("src_asset_id"));
				relationship.setDestAssetId(rs.getLong("dest_asset_id"));
				relationship.setFwdRelId(rs.getLong("fwd_rel_id"));
				relationship.setBwdRelId(rs.getLong("bwd_rel_id"));
				relationship.setDescription(rs.getString("description"));

				relationshiplist.add(relationship);
				if (log.isTraceEnabled()) {
					log.trace("retAssetRelationshipDefBySrcAssetId ||"
							+ relationship.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retAssetRelationshipDefBySrcAssetId ||"
						+ relationshiplist.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retAssetRelationshipDefBySrcAssetId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("retAssetRelationshipDefBySrcAssetId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retAssetRelationshipDefBySrcAssetId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retAssetRelationshipDefBySrcAssetId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}
		}
		if (log.isDebugEnabled()) {
			log.debug("retAssetRelationshipDefBySrcAssetId || exit");
		}
		return relationshiplist;
	}
	
}
