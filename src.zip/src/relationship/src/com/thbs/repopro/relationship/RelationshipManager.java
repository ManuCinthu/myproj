
package com.thbs.repopro.relationship;

import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.RoleDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstRelationship;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.AssetRelationshipDef;
import com.thbs.repopro.dto.GroupAssetInstVersionAccess;
import com.thbs.repopro.dto.RelationshipDef;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;

@Path("/relationship")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class RelationshipManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : getAllRelationships
	 * @description : to get AllRelationships
	 * @return Response Success message
	 */
	@GET
	@Path("/relationshipName")
	public Response getAllRelationships() {
		if (log.isTraceEnabled()) {
			log.trace("getAllRelationships ||  Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<RelationshipDef> relationshipList = new ArrayList<RelationshipDef>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationships || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationships || dao call of getAllRelationships() method to get list of relationship name");
			}
			relationshipList = relationshipDao.getAllRelationships(conn);

			if (log.isDebugEnabled()) {
				log.debug("getAllRelationships || retrieve "
						+ relationshipList.size() + "Relationships");
			}

			conn.commit();
			retStat = Status.OK;
			retMsg = Constants.RELATIONSHIP_NAMES_RETRIEVED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("SQL Exception getAllRelationships|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception getAllRelationships|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationships||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllRelationships|| End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(relationshipList))).build();

	}

	/**
	 * @method : addRelationBetAssetsWithName
	 * @description : to add RelationBetAssets
	 * @param assetRelationshipDef
	 * @return Response Success message
	 */
	@POST
	@Path("/addRelationship")
	public Response addRelationBetAssetsWithName(
			AssetRelationshipDef assetRelationshipDef) {
		if (assetRelationshipDef == null) {
			log.warn("addRelationBetAssetsWithName || AssetRelationship details to be inserted not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("addRelationBetAssetsWithName || Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			RelationshipDao relationshipDao = new RelationshipDao();
			List<AssetRelationshipDef> assetRelationshipList = new ArrayList<AssetRelationshipDef>();
			List<AssetRelationshipDef> ardForDestAsset = new ArrayList<AssetRelationshipDef>();
			List<AssetRelationshipDef> assetRelationship = new ArrayList<AssetRelationshipDef>();
			AssetDao assetDao = null;
			AssetDef srcAssetDef = null;
			AssetDef dstAssetDef = null;
			boolean flagForReverseExists = false;
			boolean flagForCompAggrExists = false;
			boolean flagForClasExists = false;
			boolean flagForAssoExists = false;
			boolean flagForAssoClasExists = false;
			try {
				if (log.isTraceEnabled()) {
					log.trace("addRelationBetAssetsWithName ||"
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				if (log.isTraceEnabled()) {
					log.trace("addRelationBetAssetsWithName || dao call of getAllAssetRelationshipDef() "
							+ "method to get list of asset relationship");
				}
				assetRelationshipList = relationshipDao.getAllAssetRelationshipDef(conn);
				boolean flagForDuplicateRelationshipName = false;
				for (AssetRelationshipDef relationshipDefList : assetRelationshipList) {
					if (relationshipDefList.getAssetRelId() != assetRelationshipDef
							.getAssetRelId()) {
						if (relationshipDefList.getDescription()
								.equalsIgnoreCase(
										assetRelationshipDef.getDescription())) {
							flagForDuplicateRelationshipName = true;
						}
					}
				}
				if (flagForDuplicateRelationshipName == true) {
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.RELATIONSHIP_BY_THIS_NAME_ALREADY_EXISTS)))
									.build();
				} else {

					for (AssetRelationshipDef relationship : assetRelationshipList) {
						if (assetRelationshipDef.getSrcAssetId() == relationship
								.getDestAssetId()
								&& assetRelationshipDef.getDestAssetId() == relationship
								.getSrcAssetId()
								&& assetRelationshipDef.getSrcAssetId() != assetRelationshipDef
								.getDestAssetId()) {

							flagForReverseExists = true;
						}
					}
					if (log.isTraceEnabled()) {
						log.trace("addRelationBetAssetsWithName || dao call of retAssetRelationshipDefByDestAssetId() "
								+ "method to get list of asset relationship by destination asset id");
					}
					ardForDestAsset = relationshipDao.retAssetRelationshipDefByDestAssetId(assetRelationshipDef.getDestAssetId(), conn);
					if (flagForReverseExists == true) {

						return Response
								.status(Status.OK)
								.entity(new MyModel(
										Constants.INSERT_STATUS_SUCCESS,
										Constants.FAILURE,
										MessageUtil
										.getMessage(Constants.REVERSE_RELATIONSHIP_NOT_ALLOWED)))
										.build();
					} else {
						if (assetRelationshipDef.getFwdRelId() == 3
								|| assetRelationshipDef.getFwdRelId() == 7) {

							for (AssetRelationshipDef ard : ardForDestAsset) {
								if (ard.getFwdRelId() == 5|| ard.getFwdRelId() == 1) {
									flagForCompAggrExists = true;
								}
							}
							if (flagForCompAggrExists == true) {
								return Response
										.status(Status.OK)
										.entity(new MyModel(
												Constants.INSERT_STATUS_SUCCESS,
												Constants.FAILURE,
												MessageUtil
												.getMessage(Constants.ASSOCIATION_OR_CLASSIFICATION_RELATIONSHIP_NOT_ALLOWED)))
												.build();
							}
							if (assetRelationshipDef.getFwdRelId() == 3) {

								for (AssetRelationshipDef ard : ardForDestAsset) {
									if (ard.getFwdRelId() == 7 && assetRelationshipDef.getSrcAssetId() == ard.getSrcAssetId()) {
										flagForClasExists = true;
									}
								}
								if (flagForClasExists == true) {
									return Response
											.status(Status.OK)
											.entity(new MyModel(
													Constants.INSERT_STATUS_SUCCESS,
													Constants.FAILURE,
													MessageUtil
													.getMessage(Constants.ASSOCIATION_RELATIONSHIP_NOT_ALLOWED)))
													.build();

								}
							} else if (assetRelationshipDef.getFwdRelId() == 7) {

								for (AssetRelationshipDef ard : ardForDestAsset) {
									if (ard.getFwdRelId() == 3
											&& assetRelationshipDef.getSrcAssetId() == ard.getSrcAssetId()) {
										flagForAssoExists = true;
									}
								}
								if (flagForAssoExists == true) {
									return Response
											.status(Status.OK)
											.entity(new MyModel(
													Constants.INSERT_STATUS_SUCCESS,
													Constants.FAILURE,
													MessageUtil
													.getMessage(Constants.CLASSIFICATION_RELATIONSHIP_NOT_ALLOWED)))
													.build();
								}
							}

						} else if (assetRelationshipDef.getFwdRelId() == 5
								|| assetRelationshipDef.getFwdRelId() == 1) {

							if (assetRelationshipDef.getSrcAssetId() == assetRelationshipDef
									.getDestAssetId()) {
								return Response
										.status(Status.OK)
										.entity(new MyModel(
												Constants.INSERT_STATUS_SUCCESS,
												Constants.FAILURE,
												MessageUtil
												.getMessage(Constants.COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED)))
												.build();

							} else {
								if (log.isTraceEnabled()) {
									log.trace("addRelationBetAssetsWithName || dao call of getAllAssetInstances() "
											+ "method to get list of asset instances by destination asset id");
								}
								AssetInstanceDao assetInstDao = new AssetInstanceDao();
								List<AssetInstance> assetInstances = new ArrayList<AssetInstance>();
								assetInstances = assetInstDao.getAllAssetInstances(assetRelationshipDef.getDestAssetId(), conn);

								if (assetInstances.size() > 0) {
									return Response
											.status(Status.OK)
											.entity(new MyModel(
													Constants.INSERT_STATUS_SUCCESS,
													Constants.FAILURE,
													MessageUtil
													.getMessage(Constants.COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET)))
													.build();
								} else {

									for (AssetRelationshipDef ard : ardForDestAsset) {
										if (ard.getFwdRelId() == 5|| ard.getFwdRelId() == 1) {
											flagForCompAggrExists = true;
										} else if (ard.getFwdRelId() == 3|| ard.getFwdRelId() == 7) {
											flagForAssoClasExists = true;
										}
									}
									if (flagForCompAggrExists == true) {
										return Response
												.status(Status.OK)
												.entity(new MyModel(
														Constants.INSERT_STATUS_SUCCESS,
														Constants.FAILURE,
														MessageUtil
														.getMessage(Constants.COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET_AS_CHIlD)))
														.build();
									} else if (flagForAssoClasExists == true) {
										return Response
												.status(Status.OK)
												.entity(new MyModel(
														Constants.INSERT_STATUS_SUCCESS,
														Constants.FAILURE,
														MessageUtil
														.getMessage(Constants.COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET_AS_PARENT)))
														.build();
									}

									if (assetRelationshipDef.getFwdRelId() == 1) {
										if (log.isTraceEnabled()) {
											log.trace("addRelationBetAssetsWithName || dao call of getAssetsByAssetId() "
													+ "method to check versionability of source asset id");
										}
										assetDao = new AssetDao();
										srcAssetDef = new AssetDef();
										dstAssetDef = new AssetDef();
										srcAssetDef = assetDao.getAssetsByAssetId(assetRelationshipDef.getSrcAssetId(),conn);
										if (log.isTraceEnabled()) {
											log.trace("addRelationBetAssetsWithName || dao call of getAssetsByAssetId() "
													+ "method to check versionability of  destination asset id");
										}
										dstAssetDef = assetDao.getAssetsByAssetId(assetRelationshipDef.getDestAssetId(),conn);

										if (srcAssetDef.isVersionable() == false
												|| dstAssetDef.isVersionable() == false) {

											return Response
													.status(Status.OK)
													.entity(new MyModel(
															Constants.INSERT_STATUS_SUCCESS,
															Constants.FAILURE,
															MessageUtil
															.getMessage(Constants.PLEASE_SELECT_A_VERSIONABLE_ASSET_FOR_THIS_RELATIONSHIP_TYPE)))
															.build();
										}
									}
								}
							}
						}
					}
				}
				if (log.isTraceEnabled()) {
					log.trace("addRelationBetAssetsWithName || dao call of addRelationBetAssetsWithName() "
							+ "to add asset relationship");
				}
				assetRelationshipDef = relationshipDao
						.addRelationBetAssetsWithName(assetRelationshipDef,conn);

				if (log.isDebugEnabled()) {
					log.debug("addRelationBetAssetsWithName || Relationships data:"
							+ assetRelationshipDef.toString()
							+ " added successfully");
				}
				conn.commit();
				assetRelationship.add(assetRelationshipDef);
				retMsg = Constants.RELATIONSHIP_DATA_SAVED_SUCCESSFULLY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;

			} catch (RepoproException e) {
				log.error("addRelationBetAssetsWithName || SQL Exception addRelationBetAssetsWithName:"
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch (Exception e) {
				log.error("addRelationBetAssetsWithName || SQL Exception addRelationBetAssetsWithName:"
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addRelationBetAssetsWithName : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("addRelationBetAssetsWithName || End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(assetRelationship))).build();
		}

	}

	/**
	 * @method : updateRelationBetAssetsWithName
	 * @description : to update RelationBetAssets
	 * @param assetRelationshipDef
	 * @return Response Success message
	 */
	@PUT
	@Path("/updateRelationship/{oldRelationName}")
	public Response updateRelationBetAssetsWithName(
			AssetRelationshipDef assetRelationshipDef,@PathParam("oldRelationName") String oldRelationName) {
		if (assetRelationshipDef == null) {
			log.warn("updateRelationBetAssetsWithName || AssetRelationship details to be updated not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("updateRelationBetAssetsWithName || Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;

			RelationshipDao relationshipDao = new RelationshipDao();
			List<AssetInstRelationship> assetInstRelationships = new ArrayList<AssetInstRelationship>();
			List<AssetRelationshipDef> assetRelationshipList = new ArrayList<AssetRelationshipDef>();
			List<AssetRelationshipDef> ardForDestAsset = new ArrayList<AssetRelationshipDef>();
			List<AssetRelationshipDef> assetRelationship = new ArrayList<AssetRelationshipDef>();
			List<AssetInstance> assetInstances = null;
			AssetInstanceDao assetInstDao = null;
			AssetDao assetDao = null;
			AssetDef srcAssetDef = null;
			AssetDef dstAssetDef = null;
			boolean flagForReverseExists = false;
			boolean flagForCompAggrExists = false;
			boolean flagForClasExists = false;
			boolean flagForAssoExists = false;
			boolean flagForAssoClasExists = false;
			boolean flagForDuplicateRelationshipName = false;
			try {
				if (log.isTraceEnabled()) {
					log.trace("updateRelationBetAssetsWithName ||"
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				if (log.isTraceEnabled()) {
					log.trace("updateRelationBetAssetsWithName || dao call of getAllAssetInstRelationshipsForAssetRelId() "
							+ "method to check mapping of asset with asset instances");
				}

				assetInstRelationships = relationshipDao
						.getAllAssetInstRelationshipsForAssetRelId(
								assetRelationshipDef.getAssetRelId(), conn);
				
				if (assetInstRelationships.size() != 0) {
					AssetRelationshipDef ard = relationshipDao.checkingRelationInDB(oldRelationName,conn);
					if (ard.getSrcAssetId().equals(assetRelationshipDef.getSrcAssetId())&& ard.getDestAssetId().equals(assetRelationshipDef.getDestAssetId()) && ard.getFwdRelId().equals(assetRelationshipDef.getFwdRelId())){
						/*if(oldRelationName.equalsIgnoreCase(assetRelationshipDef.getDescription())){
							
						}
						else{
							 return Response
										.status(Status.CREATED)
										.entity(new MyModel(
												Constants.STATUS_FAILURE,
												Constants.FAILURE,
												MessageUtil
												.getMessage(Constants.THIS_RELATIONSHIP_MAPPED_WITH_ASSET_INSTANCE)))
												.build();
						}*/
					}
					else
					{
                      return Response
							.status(Status.CREATED)
							.entity(new MyModel(
									Constants.STATUS_FAILURE,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.THIS_RELATIONSHIP_MAPPED_WITH_ASSET_INSTANCE)))
									.build();
					}
				} else {
					if (log.isTraceEnabled()) {
						log.trace("updateRelationBetAssetsWithName || dao call of getAllAssetRelationshipDef() "
								+ "method to get list of asset relationships");
					}
					assetRelationshipList = relationshipDao
							.getAllAssetRelationshipDef(conn);
					if(!oldRelationName.equalsIgnoreCase(assetRelationshipDef.getDescription())){
						for (AssetRelationshipDef relationshipDefList : assetRelationshipList) {

							if (relationshipDefList.getAssetRelId() != assetRelationshipDef.getAssetRelId()) {

								if (relationshipDefList.getDescription()
										.equalsIgnoreCase(assetRelationshipDef.getDescription())) {
									flagForDuplicateRelationshipName = true;
								}
							}
						}
					}
					

			
					if (flagForDuplicateRelationshipName == true) {

						return Response
								.status(Status.OK)
								.entity(new MyModel(
										Constants.UPDATE_STATUS_SUCCESS,
										Constants.FAILURE,
										MessageUtil
										.getMessage(Constants.RELATIONSHIP_BY_THIS_NAME_ALREADY_EXISTS)))
										.build();
					} else {
						if (log.isTraceEnabled()) {
							log.trace("updateRelationBetAssetsWithName || dao call of retAssetRelationshipDefByDestAssetId() "
									+ "method to get list of asset relationships by destination asset id");
						}
						ardForDestAsset = relationshipDao
								.retAssetRelationshipDefByDestAssetId(
										assetRelationshipDef.getDestAssetId(),
										conn);
						for (AssetRelationshipDef relationship : assetRelationshipList) {
							if(!relationship.getAssetRelId().equals(assetRelationshipDef.getAssetRelId())){
								if (assetRelationshipDef.getSrcAssetId() == relationship.getDestAssetId()
										&& assetRelationshipDef.getDestAssetId() == relationship.getSrcAssetId()
										&& assetRelationshipDef.getSrcAssetId() != assetRelationshipDef.getDestAssetId()) {

									flagForReverseExists = true;
								}
							}
							
						}

						if (flagForReverseExists == true) {

							return Response
									.status(Status.OK)
									.entity(new MyModel(
											Constants.UPDATE_STATUS_SUCCESS,
											Constants.FAILURE,
											MessageUtil
											.getMessage(Constants.REVERSE_RELATIONSHIP_NOT_ALLOWED)))
											.build();
						} else {
							if (assetRelationshipDef.getFwdRelId() == 3
									|| assetRelationshipDef.getFwdRelId() == 7) {

								for (AssetRelationshipDef ard : ardForDestAsset) {
									if(!ard.getAssetRelId().equals(assetRelationshipDef.getAssetRelId())){
										if (ard.getFwdRelId() == 5 || ard.getFwdRelId() == 1) {
											flagForCompAggrExists = true;
										}
									}
								}
								if (flagForCompAggrExists == true) {
									return Response
											.status(Status.OK)
											.entity(new MyModel(
													Constants.UPDATE_STATUS_SUCCESS,
													Constants.FAILURE,
													MessageUtil
													.getMessage(Constants.ASSOCIATION_OR_CLASSIFICATION_RELATIONSHIP_NOT_ALLOWED)))
													.build();
								}
								if (assetRelationshipDef.getFwdRelId() == 3) {

									for (AssetRelationshipDef ard : ardForDestAsset) {
										if (ard.getFwdRelId() == 7
												&& assetRelationshipDef
												.getSrcAssetId() == ard
												.getSrcAssetId()) {
											flagForClasExists = true;
										}
									}
									if (flagForClasExists == true) {
										return Response
												.status(Status.OK)
												.entity(new MyModel(
														Constants.UPDATE_STATUS_SUCCESS,
														Constants.FAILURE,
														MessageUtil
														.getMessage(Constants.ASSOCIATION_RELATIONSHIP_NOT_ALLOWED)))
														.build();

									}
								} else if (assetRelationshipDef.getFwdRelId() == 7) {

									for (AssetRelationshipDef ard : ardForDestAsset) {
										if (ard.getFwdRelId() == 3
												&& assetRelationshipDef
												.getSrcAssetId() == ard
												.getSrcAssetId()) {
											flagForAssoExists = true;
										}
									}
									if (flagForAssoExists == true) {
										return Response
												.status(Status.OK)
												.entity(new MyModel(
														Constants.UPDATE_STATUS_SUCCESS,
														Constants.FAILURE,
														MessageUtil
														.getMessage(Constants.CLASSIFICATION_RELATIONSHIP_NOT_ALLOWED)))
														.build();
									}
								}
							} else if (assetRelationshipDef.getFwdRelId() == 5
									|| assetRelationshipDef.getFwdRelId() == 1) {

								if (assetRelationshipDef.getSrcAssetId() == assetRelationshipDef
										.getDestAssetId()) {
									return Response
											.status(Status.OK)
											.entity(new MyModel(
													Constants.UPDATE_STATUS_SUCCESS,
													Constants.FAILURE,
													MessageUtil
													.getMessage(Constants.COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED)))
													.build();

								} else {
									if (log.isTraceEnabled()) {
										log.trace("updateRelationBetAssetsWithName || dao call of getAllAssetInstances() "
												+ "method to get list of asset instances by destination asset id");
									}
									assetInstances = new ArrayList<AssetInstance>();
									assetInstDao = new AssetInstanceDao();
									assetInstances = assetInstDao.getAllAssetInstances(assetRelationshipDef.getDestAssetId(),conn);

									if (assetInstances.size() > 0) {
										return Response
												.status(Status.OK)
												.entity(new MyModel(
														Constants.UPDATE_STATUS_SUCCESS,
														Constants.FAILURE,
														MessageUtil
														.getMessage(Constants.COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET)))
														.build();
									} else {

										for (AssetRelationshipDef ard : ardForDestAsset) {
											if(!ard.getAssetRelId().equals(assetRelationshipDef.getAssetRelId())){
												if (ard.getFwdRelId() == 5|| ard.getFwdRelId() == 1) {
													flagForCompAggrExists = true;
												} else if (ard.getFwdRelId() == 3|| ard.getFwdRelId() == 7) {
													flagForAssoClasExists = true;
												}
											}
										}
										if (flagForCompAggrExists == true) {
											return Response
													.status(Status.OK)
													.entity(new MyModel(
															Constants.UPDATE_STATUS_SUCCESS,
															Constants.FAILURE,
															MessageUtil
															.getMessage(Constants.COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET_AS_CHIlD)))
															.build();
										} else if (flagForAssoClasExists == true) {
											return Response
													.status(Status.OK)
													.entity(new MyModel(
															Constants.UPDATE_STATUS_SUCCESS,
															Constants.FAILURE,
															MessageUtil
															.getMessage(Constants.COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET_AS_PARENT)))
															.build();
										}

										if (assetRelationshipDef.getFwdRelId() == 1) {
											if (log.isTraceEnabled()) {
												log.trace("updateRelationBetAssetsWithName || dao call of getAssetsByAssetId() "
														+ "method to check versionability of source asset");
											}
											assetDao = new AssetDao();
											srcAssetDef = new AssetDef();
											dstAssetDef = new AssetDef();
											srcAssetDef = assetDao
													.getAssetsByAssetId(
															assetRelationshipDef
															.getSrcAssetId(),
															conn);
											if (log.isTraceEnabled()) {
												log.trace("updateRelationBetAssetsWithName || dao call of getAssetsByAssetId() "
														+ "method to check versionability of destination asset");
											}
											dstAssetDef = assetDao
													.getAssetsByAssetId(
															assetRelationshipDef
															.getDestAssetId(),
															conn);

											if (srcAssetDef.isVersionable() == false
													|| dstAssetDef
													.isVersionable() == false) {

												return Response
														.status(Status.OK)
														.entity(new MyModel(
																Constants.UPDATE_STATUS_SUCCESS,
																Constants.FAILURE,
																MessageUtil
																.getMessage(Constants.PLEASE_SELECT_A_VERSIONABLE_ASSET_FOR_THIS_RELATIONSHIP_TYPE)))
																.build();
											}
										}
									}
								}
							}
						}
					}
				}
				
				if (log.isTraceEnabled()) {
					log.trace("updateRelationBetAssetsWithName || dao call of updateRelationBetAssetsWithName() "
							+ "method to update asset relationship");
				}
				
				

			/*	String relationName = assetRelationshipDef.getDescription();

				java.util.regex.Pattern p = java.util.regex.Pattern.compile("[\\[]"+oldRelationName+"[\\]]");
				List<AssetParamDef> listOfParams = relationshipDao.getAssetParamDefByDerivedAttributeIsNotNull(conn);

				for(int i =0;i<listOfParams.size();i++){

					AssetParamDef  apd =listOfParams.get(i);
					String rule = apd.getDerivedAttributeComputation();
					Matcher m = p.matcher(rule);
					if(m.find()){
						rule = rule.replaceAll("[\\[]"+oldRelationName+"[\\]]", "["+relationName+"]");
						apd.setDerivedAttributeComputation(rule);
						relationshipDao.updateDerivedRuleWithRelationName(apd, conn);
					}

				}*/

				assetRelationshipDef = relationshipDao
						.updateRelationBetAssetsWithName(assetRelationshipDef,
								conn);
				
				String newRelationName = assetRelationshipDef.getDescription();
				List<AssetParamDef> listOfParams = relationshipDao.getAssetParamDefByDerivedAttributeIsNotNull(conn);

				for(int i =0;i<listOfParams.size();i++){
					AssetParamDef apd = listOfParams.get(i);
					String rule =apd.getDerivedAttributeComputation();
					
					if(listOfParams.get(i).getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){
						
						Pattern p = Pattern.compile("[\\[][a-zA-Z0-9_ ]+[\\]]");
						Matcher m =p.matcher(rule);
						while(m.find()){
							String relationName = m.group();
							relationName = relationName.substring(1, relationName.length()-1);
							AssetRelationshipDef ard = relationshipDao.checkingRelationInDB(relationName , conn);
							if(ard==null){
								if(relationName.contains("^")){
									rule = rule.replaceAll("[\\[][\\^]?(?i)"+relationName+"[\\]]","[^"+newRelationName+"]");
								}else{
									rule = rule.replaceAll("[\\[](?i)"+relationName+"[\\]]","["+newRelationName+"]");
								}
								apd.setDerivedAttributeComputation(rule);
								relationshipDao.updateDerivedRuleWithRelationName(apd, conn);
								break;
							}
						}
					}else if(listOfParams.get(i).getParamTypeId().equals(Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID)){
						Pattern p = Pattern.compile("[\\[][a-zA-Z0-9_ ]+[\\]]");
						Matcher m =p.matcher(rule);
						while(m.find()){
							String relationName = m.group();
							relationName = relationName.substring(1, relationName.length()-1);
							AssetRelationshipDef ard = relationshipDao.checkingRelationInDB(relationName , conn);
							if(ard==null){
								
								if(relationName.contains("^")){
									rule = rule.replaceAll("[\\[][\\^]?(?i)"+relationName+"[\\]]","[^"+newRelationName+"]");
								}else{
									rule = rule.replaceAll("[\\[](?i)"+relationName+"[\\]]","["+newRelationName+"]");
								}
								apd.setDerivedAttributeComputation(rule);
								relationshipDao.updateDerivedRuleWithRelationName(apd, conn);
								break;
							}
						}
					
						
					}
				}
				
				if (log.isDebugEnabled()) {
					log.debug("updateRelationBetAssetsWithName || Relationships data:"
							+ assetRelationshipDef.toString()
							+ " updated successfully with assetrelationshipid:"
							+ assetRelationshipDef.getAssetRelId());
				}
				conn.commit();
				assetRelationship.add(assetRelationshipDef);
				retMsg = Constants.RELATIONSHIP_DATA_UPDATED_SUCCESSFULLY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				
			} catch (RepoproException e) {
				log.error("updateRelationBetAssetsWithName || SQL Exception updateRelationBetAssetsWithName:"
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch (Exception e) {
				log.error("updateRelationBetAssetsWithName || SQL Exception updateRelationBetAssetsWithName:"
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateRelationBetAssetsWithName : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("updateRelationBetAssetsWithName || End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(assetRelationship))).build();
		}
	}

	/**
	 * @method : getAllAssetRelationshipDefForGrid
	 * @description : to update RelationBetAssets
	 * @return Response Success message
	 */
	@GET
	@Path("/relationshipView")
	public Response getAllAssetRelationshipDefForGrid(@QueryParam("from") int from) {
		if (log.isTraceEnabled()) {
			log.trace("getAllAssetRelationshipDefForGrid ||  Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetRelationshipDef> relationshipList = new ArrayList<AssetRelationshipDef>();
		List<AssetInstRelationship> assetInstRelationshiplist = new ArrayList<AssetInstRelationship>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDefForGrid || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDefForGrid || dao call of getAllAssetRelationshipforGrid() method to get list of relationships added");
			}
			relationshipList = relationshipDao.getAllAssetRelationshipforGrid(conn, from);

			for(int i=0;i<relationshipList.size();i++){
				assetInstRelationshiplist = relationshipDao.getAllAssetInstRelationshipsForAssetRelId(relationshipList.get(i).getAssetRelId(), conn);
				if(assetInstRelationshiplist.size()!=0){
					relationshipList.get(i).setRelationMappedFlag(true);
				}
				else{
					relationshipList.get(i).setRelationMappedFlag(false);	
				}
			}

			List<AssetParamDef> listOfParams = relationshipDao.getAssetParamDefByDerivedAttributeIsNotNull(conn);

			for(int i=0;i<listOfParams.size();i++){
				AssetParamDef apd = listOfParams.get(i);
				String derivedattributeComputation = apd.getDerivedAttributeComputation();
				boolean flag = false;
				for(int j=0;j<relationshipList.size();j++){
					String relationName =relationshipList.get(j).getDescription();
					java.util.regex.Pattern p =java.util.regex.Pattern.compile("[\\[]"+relationName+"[\\]]");
					Matcher m = p.matcher(derivedattributeComputation);
					if(m.find()){
						relationshipList.get(j).setDerivedAttributeMappedFlag(true);
						flag = true;
						break;

					}
				}
				if(flag)break;
			}
				
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetRelationshipDefForGrid || Relationships names:"
						+ relationshipList.size() + " retrieved successfully");
			}
			retStat = Status.OK;
			retMsg = Constants.RELATIONSHIP_DATA_RETRIEVED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("SQL Exception getAllAssetRelationshipDef|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception getAllAssetRelationshipDef|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDef||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllAssetRelationshipDefForGrid|| End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(relationshipList))).build();

	}

	/**
	 * @method : deleteAssetRelationship
	 * @description : to delete AssetRelationship
	 * @param assetRelId
	 * @return Response Success message
	 */
	@DELETE
	@Path("/deleteRelationship/{assetRelId}/{relationName}")
	public Response deleteAssetRelationship(
			@PathParam("assetRelId") Long assetRelId,
			@PathParam("relationName") String relationName) {

		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRelationship by assetRelId || Begin");
		}

		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetInstRelationship> assetInstRelationshiplist = new ArrayList<AssetInstRelationship>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<String> jsonList = new ArrayList<String>();
		String jsonRslt;
		boolean result = false;
		String result1 = "";
		int val = 0;
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationship ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationship || dao call of getAllAssetInstRelationshipsForAssetRelId() method to get list of AssetInatance relationships available");
			}
			assetInstRelationshiplist = relationshipDao.getAllAssetInstRelationshipsForAssetRelId(assetRelId, conn);

			if (assetInstRelationshiplist.size() != 0) {
				result = true;
			}

			if (result == true) {
				jsonRslt = Constants.RELATIONSHIP_MAPPPED_WITH_ASSET_INSTANCE;
				jsonList.add(jsonRslt);
				return Response
						.status(Status.OK)
						.entity(new MyModel(
								Constants.DELETE_STATUS_SUCCESS,
								Constants.FAILURE,
								MessageUtil
										.getMessage(Constants.RELATIONSHIP_NOT_DELETED),
								new ArrayList<Object>(jsonList))).build();
			} else {
				if (log.isTraceEnabled()) {
					log.trace("deleteAssetRelationship || dao call of deleteAssetRelationshipDefByAssetRelId() method to delete asset relationship");
				}
				
				// By Karthikeyan 24/10/2017
				
				AssetRelationshipDef ard = relationshipDao.retAssetRelDefById(assetRelId, conn);
				List<AssetParamDef> listOfParams = relationshipDao.getAssetParamDefByDerivedAttributeIsNotNull(conn);
				
				for(int i=0;i<listOfParams.size();i++){
					String relationName1 = ard.getDescription().toLowerCase();
					
				if(listOfParams.get(i).getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){
						/*if(apd.get(i).getDerivedComputedDescription().contains(relationName)){
							String paramName = apd.get(i).getAssetParamName();
							result = ard.getDescription()+" : Using Under This :"+paramName+" Directly U can Not Remove Relation ";
						}*/
						String paramName = listOfParams.get(i).getAssetParamName();
						Pattern p = Pattern.compile("[\\[][a-zA-Z0-9 ]+[\\]]");
				        Matcher m = p.matcher(listOfParams.get(i).getDerivedAttributeComputation());
				        while (m.find()) {
				        	String rep = m.group(0);
				        	 rep = rep.substring(rep.indexOf("[")+1,rep.indexOf("]"));
				        	 if(rep.equalsIgnoreCase(relationName1)){
				        		 result1 = ard.getDescription()+" : relation name is mapped under : "+paramName+" parameter name can't be removed ! ";
				        	 }
				        }
						
						
						
					}else if(listOfParams.get(i).getParamTypeId().equals(Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID)){
						/*if(apd.get(i).getDerivedComputedDescription().contains(relationName)){
							String paramName = apd.get(i).getAssetParamName();
							result = ard.getDescription()+" : Using Under This :"+paramName+" Directly U can Not Remove Relation ";
						}*/
						
						String paramName = listOfParams.get(i).getAssetParamName();
						Pattern p = Pattern.compile("[\\[][a-zA-Z0-9 ]+[\\]]");
				        Matcher m = p.matcher(listOfParams.get(i).getDerivedAttributeComputation());
				        while (m.find()) {
				        		String rep = m.group(0);
				        		rep = rep.substring(rep.indexOf("[")+1,rep.indexOf("]"));
				        		if(rep.equalsIgnoreCase(relationName1)){
					        		 result1 = ard.getDescription()+" : relation name is mapped under : "+paramName+" parameter name can't be removed ! ";
				        		}
				        }
					}
				}

				if(result1.equalsIgnoreCase(""))
				{
				   val = relationshipDao.deleteAssetRelationshipDefByAssetRelId(assetRelId, conn);
				    retMsg = Constants.RELATIONSHIP_DELETED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
				} else {
					jsonRslt = result1;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.DELETE_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
											.getMessage(Constants.RELATIONSHIP_NOT_DELETED),
									new ArrayList<Object>(jsonList))).build();
				}
				if (log.isInfoEnabled()) {
					log.info("deleteAssetRelationship ||" + val
							+ " relationships deleted successfully");
				}
			}
			conn.commit();
			
		}catch (RepoproException e) {
			log.error("SQL Exception deleteAssetRelationship ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("SQL Exception deleteAssetRelationship ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationship ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRelationship by assetRelId || End");
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/**
	 * @method : getAllReverseRelationships
	 * @param assetInstanceVersionId
	 * @return
	 */
	@GET
	@Path("/getallreverserelationships")
	public Response getAllReverseRelationships(@QueryParam("assetInstanceVersionId") Long assetInstanceVersionId){

		if(log.isTraceEnabled()){
			log.trace("getAllReverseRelationships || begin with assetInstanceVersionId : "+ assetInstanceVersionId);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<AssetInstanceVersion> aivList = new ArrayList<AssetInstanceVersion>();

		try {
			if (log.isTraceEnabled()){
				log.trace("getAllReverseRelationships || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			RelationshipDao dao = new RelationshipDao();

			if(log.isTraceEnabled()){
				log.trace("getAllReverseRelationships || dao method called : getAllReverseRelationships()");
			}
			aivList = dao.getAllReverseRelationships(assetInstanceVersionId, conn);

			log.debug("getAllReverseRelationships || retrieved "+ aivList.size() +" reverse relationships successfully");

			retMsg = Constants.ALL_REVERSE_RELATIONSHIPS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;


		} catch(RepoproException e){
			log.error("getAllReverseRelationships || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getAllReverseRelationships || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllReverseRelationships || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (aivList.isEmpty()) {
			retMsg = Constants.REVERSE_RELATIONSHIPS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_REVERSE_RELATIONSHIPS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		if(log.isTraceEnabled()){
			log.trace("getAllReverseRelationships || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(aivList))).build();

	}

	/**
	 * @method filterDependencyTreeActionOnLoad
	 * @param assetName
	 * @param assetInstanceVersionId
	 * @param relationId
	 * @return success response
	 */
	@GET
	@Path("/relation/loaddependencies")
	public Response filterDependencyTreeActionOnLoad(
			@QueryParam("assetName")String assetName,
			@QueryParam("assetInstanceVersionId")Long assetInstanceVersionId,@QueryParam("relationId")String relationId){
		if(log.isTraceEnabled()){
			log.trace("filterDependencyTreeActionOnLoad by assetName :"+assetName+" assetInstanceVersionId"+assetInstanceVersionId);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response res   = null;
		//RelationshipDao relationshipDao = new RelationshipDao();
		//List<AssetRelationshipDef> relationshipList = new ArrayList<AssetRelationshipDef>();
		try {
			/*List<String> relationId = new ArrayList<String>();;
			if(log.isTraceEnabled()){
				log.trace("filterDependencyTreeActionForOnClick || dao calling method getAllRelationshipsByAssetInstVersionId(assetInstanceVersionId,conn)");
			}
			relationshipList = relationshipDao.getAllRelationshipsByAssetInstVersionId(assetInstanceVersionId, conn);
			for(AssetRelationshipDef relData:relationshipList){
				String rel= null;
				rel = relData.getDescription()+"-"+relData.getFwdRelId().toString();
				relationId.add(rel);
			}
			HashSet<String> set = new HashSet<>(relationId);
			ArrayList<String> result = new ArrayList<>(set);
			String finalrelationId = String.join("!", result);*/
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if(log.isTraceEnabled()){
				log.trace("filterDependencyTreeActionForOnClick || dao calling method filterDependencyTreeAction(assetName,assetInstanceVersionId,relationId)");
			}
			res = CommonUtils.filterDependencyTreeAction(assetName, assetInstanceVersionId, relationId);

		} catch (Exception e) {
			log.error("SQL Exception filterDependencyTreeActionOnLoad ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterDependencyTreeActionOnLoad ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("filterDependencyTreeActionOnLoad || End");
		}
		return res;
	}

	/**
	 * @method filterDependencyTreeActionForOnClick
	 * @param assetName
	 * @param assetInstanceVersionId
	 * @param relationId
	 * @return success response
	 */
	@GET
	@Path("/relations/onclick")
	public Response filterDependencyTreeActionForOnClick(
			@QueryParam("assetName")String assetName,
			@QueryParam("assetInstanceVersionId")Long assetInstanceVersionId,
			@QueryParam("relationId")String relationId){
		if(log.isTraceEnabled()){
			log.trace("filterDependencyTreeActionForOnClick by assetName :"+assetName+" assetInstanceVersionId"+assetInstanceVersionId);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response res =null;
		try {
			if(log.isTraceEnabled()){
				log.trace("filterDependencyTreeActionForOnClick || dao calling method filterDependencyTreeAction(assetName,assetInstanceVersionId,relationId)");
			}
			res = CommonUtils.filterDependencyTreeAction(assetName, assetInstanceVersionId, relationId);

		} catch (Exception e) {
			log.error("SQL Exception on filterDependencyTreeActionForOnClick ||"+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterDependencyTreeActionForOnClick ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("filterDependencyTreeActionForOnClick || End");
		}
		return res ;
	}

	/**
	 * @method getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId
	 * @param assetInstVersionId
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/getrelationNameId")
	public Response getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId(@QueryParam("assetInstVersionId") Long assetInstVersionId) {
		if (log.isTraceEnabled()) {
			log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId ||  Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetRelationshipDef> relationshipList = new ArrayList<AssetRelationshipDef>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId || dao call of getAllRelationships() method to get list of relationship name");
			}
			relationshipList = relationshipDao.getAllRelationshipsByAssetInstVersionId(assetInstVersionId, conn);

			if (log.isDebugEnabled()) {
				log.debug("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId || retrieve "
						+ relationshipList.size() + "Relationships");
			}

			conn.commit();
			retStat = Status.OK;
			retMsg = Constants.RELATIONSHIP_NAMES_RETRIEVED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
             
		} catch (RepoproException e) {
			log.error("SQL Exception getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId|| End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(relationshipList))).build();

	}

	/***Wrapper function***/
	@POST
	@Path("/addRelationshipMain")
	public Response addRelationBetAssetsWithNameMain(@QueryParam("srcAssetName") String srcAssetName, 
			@QueryParam("destAssetName") String destAssetName,
			@QueryParam("fwdRelationType") String fwdRelationType, 
			@QueryParam("description") String description,
			@HeaderParam("token") String token) {
		
		if(srcAssetName == null || destAssetName == null || fwdRelationType == null || description == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			      Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(srcAssetName.trim().isEmpty() || destAssetName.trim().isEmpty() || fwdRelationType.trim().isEmpty() || description.trim().isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			      Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		if(description.trim().length()>100){
			return Response.status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
		}
		
		log.trace("addRelationBetAssetsWithNameMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetRelationshipDef relationshipDef = new AssetRelationshipDef();
		User user = new User();
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean relFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		userName = userName.trim();
		srcAssetName = srcAssetName.trim();
		destAssetName = destAssetName.trim();
		fwdRelationType = fwdRelationType.trim();
		description = description.trim();
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("addRelationBetAssetsWithNameMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			AssetDao assetDao = new AssetDao();
			RelationshipDao relationshipDao = new RelationshipDao();
			AssetDef ad = new AssetDef();
			ad = assetDao.getAssetsByAssetName(srcAssetName, conn);
			if (ad.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("addRelationBetAssetsWithNameMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			AssetDef ad1 = new AssetDef();
			ad1 = assetDao.getAssetsByAssetName(destAssetName, conn);
			if (ad1.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("addRelationBetAssetsWithNameMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			Long fwdRelId = relationshipDao.getRelIdByReltype(fwdRelationType, conn);
			if (fwdRelId == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.RELATIONSHIP_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("addRelationBetAssetsWithNameMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			relationshipDef.setSrcAssetId(ad.getAssetId());
			relationshipDef.setDestAssetId(ad1.getAssetId());
			relationshipDef.setFwdRelId(fwdRelId);
			relationshipDef.setDescription(description);
			
			user = userDao.retProfileForUserName(userName, conn);
			if(user == null){
				retStat = Status.UNAUTHORIZED;
				retMsg = Constants.USER_NOT_AUTHENTICATED;
				retScsFlr = Constants.NOT_AUTHENTICATED;
				retStatScsFlr = Constants.UNAUTHORIZED;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(user.getUserName(), conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
			
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_RELS")){
					relFlag = true;
			        break;
				}
			}
			
			if(relFlag || adminFlag){
				String newRegex = "^[A-Za-z0-9 ]+$";
				Pattern pattern = Pattern.compile(newRegex);
				Matcher matcher = pattern.matcher(description);

				if(!matcher.find()){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, "Please use only alphanumeric characters in relationship name.")).build();
				}
				response = this.addRelationBetAssetsWithName(relationshipDef);
				MyModel res = (MyModel) response.getEntity();
				JSONObject json = new JSONObject();
				
				if(res.getStatus() == Constants.FAILURE){
					json.put("message", res.getMessage());
					json.put("status", res.getStatus());
					json.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("addRelationBetAssetsWithNameMain || End");
					
					return Response.status(Status.BAD_REQUEST).entity(json.toString()).build();
				}
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("addRelationBetAssetsWithNameMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
						
		} catch (RepoproException e) {
			log.error("addRelationBetAssetsWithNameMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addRelationBetAssetsWithNameMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addRelationBetAssetsWithNameMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("addRelationBetAssetsWithNameMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/***Wrapper function***/
	@PUT
	@Path("/updateRelationshipMain")
	public Response updateRelationBetAssetsWithNameMain(
			@QueryParam("relationshipName") String relationshipName,
			@QueryParam("relationshipDetails") String relationshipDetails,
			@HeaderParam("token") String token) {
		
		if(relationshipName == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(relationshipName.trim().isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		if(relationshipDetails == null || relationshipDetails.isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		if(relationshipDetails != null && !relationshipDetails.isEmpty()){
			try{
				String jsonStr = relationshipDetails;
				JSONObject jsonObject = new JSONObject(jsonStr);
				if(!jsonObject.has("relationshipName") && !jsonObject.has("relationshipType") && 
						!jsonObject.has("sourceAssetName") && !jsonObject.has("destinationAssetName")){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
				}
			}catch(JSONException e){
				e.printStackTrace();
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
		}
		
		log.trace("updateRelationBetAssetsWithNameMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetRelationshipDef updateRelationship = new AssetRelationshipDef();
		User user = new User();
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean relFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		relationshipName = relationshipName.trim();
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("updateRelationBetAssetsWithNameMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
			AssetDao assetDao = new AssetDao();
			RelationshipDao relationshipDao = new RelationshipDao();

			AssetRelationshipDef ard = relationshipDao.checkingRelationInDB(relationshipName, conn);
			if(ard == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.RELATIONSHIP_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("updateRelationBetAssetsWithNameMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			updateRelationship.setAssetRelId(ard.getAssetRelId());

			String jsonStr = relationshipDetails;
			JSONObject json = new JSONObject(jsonStr);

			if(json.has("relationshipName")){
				String jsonRelationshipName = json.get("relationshipName").toString();
				jsonRelationshipName = jsonRelationshipName.trim();
				if(jsonRelationshipName.trim().length()>100){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE, Constants.FAILURE, 
									MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
				}
				String newRegex = "^[A-Za-z0-9 ]+$";
				Pattern pattern = Pattern.compile(newRegex);
				Matcher matcher = pattern.matcher(jsonRelationshipName);

				if(!matcher.find()){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, "Please use only alphanumeric characters in relationship name.")).build();
				}
				updateRelationship.setDescription(jsonRelationshipName);
			}else{
				updateRelationship.setDescription(ard.getDescription());
			}

			if(json.has("relationshipType")){
				String relationshipType = json.getString("relationshipType").toString();
				relationshipType = relationshipType.trim();
				Long fwdRelId = relationshipDao.getRelIdByReltype(relationshipType, conn);/*to check for rel type*/
				if (fwdRelId == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.RELATIONSHIP_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateRelationBetAssetsWithNameMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				updateRelationship.setFwdRelId(fwdRelId);
			}else{
				updateRelationship.setFwdRelId(ard.getFwdRelId());
			}

			if(json.has("sourceAssetName") && json.has("destinationAssetName")){

				String sourceAssetName = json.get("sourceAssetName").toString();
				sourceAssetName = sourceAssetName.trim();
				AssetDef srcAsset = assetDao.getAssetsByAssetName(sourceAssetName, conn);
				if(srcAsset.getAssetId() == null){
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateRelationBetAssetsWithNameMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				updateRelationship.setSrcAssetId(srcAsset.getAssetId());

				String destinationAssetName = json.get("destinationAssetName").toString();
				destinationAssetName = destinationAssetName.trim();
				AssetDef destAsset = assetDao.getAssetsByAssetName(destinationAssetName, conn);
				if(destAsset.getAssetId() == null){
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateRelationBetAssetsWithNameMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				updateRelationship.setDestAssetId(destAsset.getAssetId());

			}else if(json.has("sourceAssetName") || json.has("destinationAssetName")){
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}else{
				updateRelationship.setSrcAssetId(ard.getSrcAssetId());
				updateRelationship.setDestAssetId(ard.getDestAssetId());
			}

			user = userDao.retProfileForUserName(userName, conn);
			if(user == null){
				retStat = Status.UNAUTHORIZED;
				retMsg = Constants.USER_NOT_AUTHENTICATED;
				retScsFlr = Constants.NOT_AUTHENTICATED;
				retStatScsFlr = Constants.UNAUTHORIZED;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}

			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(user.getUserName(), conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}

			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_RELS")){
					relFlag = true;
					break;
				}
			}

			if(relFlag || adminFlag){

				response = this.updateRelationBetAssetsWithName(updateRelationship, relationshipName);
				MyModel res = (MyModel) response.getEntity();
				JSONObject json1 = new JSONObject();

				if(res.getStatus() == Constants.FAILURE){
					json1.put("message", res.getMessage());
					json1.put("status", res.getStatus());
					json1.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("updateRelationBetAssetsWithNameMain || End");
					return Response.status(Status.BAD_REQUEST).entity(json1.toString()).build();
				}

				json1.put("message", res.getMessage());
				json1.put("status", res.getStatus());
				json1.put("statusCode", res.getStatusCode());
				log.trace("updateRelationBetAssetsWithNameMain || End");

				return Response.status(retStat).entity(json1.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

		} catch (RepoproException e) {
			log.error("updateRelationBetAssetsWithNameMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("updateRelationBetAssetsWithNameMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateRelationBetAssetsWithNameMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("updateRelationBetAssetsWithNameMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

/***Wrapper function***/
	@DELETE
	@Path("/deleteRelationshipMain")
	public Response deleteAssetRelationshipMain(
			@QueryParam("srcAssetName") String srcAssetName,
			@QueryParam("destAssetName") String destAssetName,
			@QueryParam("description") String description,
			@HeaderParam("token") String token) {
		
		if(srcAssetName == null || destAssetName == null || description == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		if(srcAssetName.trim().isEmpty() || destAssetName.trim().isEmpty() || description.trim().isEmpty()){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		log.trace("deleteAssetRelationshipMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean relFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		User user = new User();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		srcAssetName = srcAssetName.trim();
		destAssetName = destAssetName.trim();
		description = description.trim();
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationshipMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			AssetDao assetDao = new AssetDao();
			RelationshipDao relationshipDao = new RelationshipDao();
			AssetDef ad = new AssetDef();
			ad = assetDao.getAssetsByAssetName(srcAssetName,conn);
			if (ad.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("deleteAssetRelationshipMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			AssetDef ad1 = new AssetDef();
			ad1 = assetDao.getAssetsByAssetName(destAssetName,conn);
			if (ad1.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("deleteAssetRelationshipMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			Long assetRelId = relationshipDao.getAssetRelId(ad.getAssetId(),ad1.getAssetId(), description, conn);
			if (assetRelId == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.RELATIONSHIP_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("deleteAssetRelationshipMain || End");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.UNAUTHORIZED;
				retMsg = Constants.USER_NOT_AUTHENTICATED;
				retScsFlr = Constants.NOT_AUTHENTICATED;
				retStatScsFlr = Constants.UNAUTHORIZED;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(user.getUserName(), conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
			
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_RELS")){
					relFlag = true;
			        break;
				}
			}
			
			if(relFlag || adminFlag){
				response = this.deleteAssetRelationship(assetRelId, description);
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				if(res.getStatus() == Constants.FAILURE){
					//json.put("message", res.getMessage());
					json.put("message", res.getResult());
					json.put("status", res.getStatus());
					json.put("statusCode", Constants.STATUS_FAILURE);
					log.trace("deleteAssetRelationshipMain || End");
					
					return Response.status(Status.BAD_REQUEST).entity(json.toString()).build();
				}
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("deleteAssetRelationshipMain || End");
				
				return Response.status(retStat).entity(json.toString()).build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			
		} catch (RepoproException e) {
			log.error("deleteAssetRelationshipMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("deleteAssetRelationshipMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetRelationshipMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("deleteAssetRelationshipMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}



/***Wrapper function***/
	@GET
	@Path("/relation/loaddependenciesMain")
	public Response filterDependencyTreeActionOnLoadMain(@QueryParam("userName") String userName,
			@QueryParam("assetName")String assetName,
			@QueryParam("assetInstName")String assetInstName,
			@QueryParam("assetVersionName")String assetVersionName,@QueryParam("relationType")String relationType) {
		
		if(userName == null || assetName == null || assetInstName == null || assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(userName.isEmpty() || assetName.isEmpty() || assetInstName.isEmpty() || assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("filterDependencyTreeActionOnLoadMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		userName = userName.trim();
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		assetVersionName = assetVersionName.trim();
		try {
			if (log.isTraceEnabled()) {
				log.trace("filterDependencyTreeActionOnLoadMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			AssetInstanceVersion assetInstanceVer=assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetVersionName, conn);
			if (assetInstanceVer == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("filterDependencyTreeActionOnLoadMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			
			long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
			RelationshipDao relationshipDao = new RelationshipDao();
			Long relId = relationshipDao.getRelIdByReltype(relationType, conn);
			response = this.filterDependencyTreeActionOnLoad(assetName, assetInstanceVersionId,relId.toString());
            return response;
		} catch (RepoproException e) {
			log.error("filterDependencyTreeActionOnLoadMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("filterDependencyTreeActionOnLoadMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterDependencyTreeActionOnLoadMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("filterDependencyTreeActionOnLoadMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

/***Wrapper function***/
	@GET
	@Path("/relations/onclickMain")
	public Response filterDependencyTreeActionForOnClickMain(@QueryParam("userName") String userName,
			@QueryParam("assetName")String assetName,
			@QueryParam("assetInstName")String assetInstName,
			@QueryParam("assetVersionName")String assetVersionName,
			@QueryParam("relationName") String relationName) {
		
		if(userName == null || assetName == null || assetInstName == null || assetVersionName == null || relationName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(userName.isEmpty() || assetName.isEmpty() || assetInstName.isEmpty() || assetVersionName.isEmpty() || relationName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("filterDependencyTreeActionForOnClickMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		userName = userName.trim();
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		assetVersionName = assetVersionName.trim();
		relationName = relationName.trim();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("filterDependencyTreeActionForOnClickMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("filterDependencyTreeActionForOnClickMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			
			long assetInstanceVersionId = assetInstanceVer.getAssetInstVersionId();
			/*RelationshipDao relationshipDao = new RelationshipDao();
			Long relId = relationshipDao.getRelIdByReltype(relationType, conn);*/
			
			response = this.filterDependencyTreeActionForOnClick(assetName, assetInstanceVersionId, relationName);
            return response;
		} catch (RepoproException e) {
			log.error("filterDependencyTreeActionForOnClickMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("filterDependencyTreeActionForOnClickMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterDependencyTreeActionForOnClickMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("filterDependencyTreeActionForOnClickMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

/***Wrapper function***/
	@GET
	@Path("/getrelationNameIdMain")
	public Response getAllRelationshipNamesAndRelationShipIdByAssetInstVersionIdMain(
			@QueryParam("assetName")String assetName,
			@QueryParam("assetInstName")String assetInstName,
			@QueryParam("assetVersionName") String assetVersionName,
			@QueryParam("userName") String userName) {
		
		if(userName == null || assetName == null || assetInstName == null || assetVersionName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(userName.isEmpty() || assetName.isEmpty() || assetInstName.isEmpty() || assetVersionName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionIdMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		boolean viewFlag = false;
		UserDao userDao = new UserDao();
		userName = userName.trim();
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		assetVersionName = assetVersionName.trim();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionIdMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(assetVersionName);
			
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionIdMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			
			long assetInstVersionId = assetInstanceVer.getAssetInstVersionId();
			
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		    groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
		    for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
			    if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
			    	viewFlag = true;
				    break;
			    }
		    }

		    if (viewFlag) {
		    	response = this.getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId(assetInstVersionId);
	            return response;
		    } else {
			    retStat = Status.FORBIDDEN;
			    retMsg = Constants.USER_NOT_AUTHORIZED;
			    retScsFlr = Constants.FAILURE;
			    retStatScsFlr = Constants.GET_STATUS_FAILURE;
			 	return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			
			
		} catch (RepoproException e) {
			log.error("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionIdMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionIdMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionIdMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllRelationshipNamesAndRelationShipIdByAssetInstVersionIdMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/**
	 * @method : getAllFilteredAssetRelationshipDefForGrid
	 * @description : to update RelationBetAssets Filter search
	 * @return Response Success message
	 */
	@GET
	@Encoded
	@Path("/relationshipViewFilter")
	public Response getAllFilteredAssetRelationshipDefForGrid(@QueryParam("userName")String userName,@QueryParam("searchString")String searchStr,@QueryParam("from") int from) {
		if (log.isTraceEnabled()) {
			log.trace("getAllFilteredAssetRelationshipDefForGrid ||  Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetRelationshipDef> relationshipList = new ArrayList<AssetRelationshipDef>();
		List<AssetInstRelationship> assetInstRelationshiplist = new ArrayList<AssetInstRelationship>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetRelationshipDefForGrid || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			String actualValue = URLDecoder.decode(searchStr, "UTF-8");
			String value = "";
			if (searchStr.contains("_") || searchStr.contains("%")){
				value = actualValue;
				value = value.replace("_", "\\_");
				value = value.replace("%", "\\%");
			}else{
				value = actualValue;
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetRelationshipDefForGrid || dao call of getAllFilteredAssetRelationshipforGrid() method to get list of relationships added");
			}
			relationshipList = relationshipDao.getAllFilteredAssetRelationshipforGrid(conn, from,value);

			for(int i=0;i<relationshipList.size();i++){
				assetInstRelationshiplist = relationshipDao.getAllAssetInstRelationshipsForAssetRelId(relationshipList.get(i).getAssetRelId(), conn);
				if(assetInstRelationshiplist.size()!=0){
					relationshipList.get(i).setRelationMappedFlag(true);
				}
				else{
					relationshipList.get(i).setRelationMappedFlag(false);	
				}
			}

			List<AssetParamDef> listOfParams = relationshipDao.getAssetParamDefByDerivedAttributeIsNotNull(conn);

			for(int i=0;i<listOfParams.size();i++){
				AssetParamDef apd = listOfParams.get(i);
				String derivedattributeComputation = apd.getDerivedAttributeComputation();
				boolean flag = false;
				for(int j=0;j<relationshipList.size();j++){
					String relationName =relationshipList.get(j).getDescription();
					java.util.regex.Pattern p =java.util.regex.Pattern.compile("[\\[]"+relationName+"[\\]]");
					Matcher m = p.matcher(derivedattributeComputation);
					if(m.find()){
						relationshipList.get(j).setDerivedAttributeMappedFlag(true);
						flag = true;
						break;

					}
				}
				if(flag)break;
			}
				
			if (log.isDebugEnabled()) {
				log.debug("getAllFilteredAssetRelationshipDefForGrid || Relationships names:"
						+ relationshipList.size() + " retrieved successfully");
			}
			retStat = Status.OK;
			retMsg = Constants.RELATIONSHIP_DATA_RETRIEVED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("SQL Exception getAllFilteredAssetRelationshipDefForGrid|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception getAllFilteredAssetRelationshipDefForGrid|| "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetRelationshipDefForGrid||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllFilteredAssetRelationshipDefForGrid|| End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(relationshipList))).build();

	}
	
	
	/***Wrapper function***/
	@GET
	@Path("/getAllAssetRelationshipDefForGridMain")
	public Response getAllAssetRelationshipDefForGridMain(@QueryParam("from") int from,
			@HeaderParam("token") String token) {
				
		log.trace("getAllAssetRelationshipDefForGridMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean relFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		User user = new User();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
				
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDefForGridMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
									
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.UNAUTHORIZED;
				retMsg = Constants.USER_NOT_AUTHENTICATED;
				retScsFlr = Constants.NOT_AUTHENTICATED;
				retStatScsFlr = Constants.UNAUTHORIZED;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(user.getUserName(), conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
			
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_RELS")){
					relFlag = true;
			        break;
				}
			}
			
			if(relFlag || adminFlag){
				response = this.getAllAssetRelationshipDefForGrid(from);
				MyModel res = (MyModel) response.getEntity();
				List<Object> data = res.getResult();
				List<Object> finaldata = new ArrayList<Object>();
				JSONObject json = new JSONObject();
				JSONObject j1 = null;
				
				for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	AssetRelationshipDef ard = new AssetRelationshipDef();
		        	ard = (AssetRelationshipDef) data.get(i);
		        	
		        	j1.put("sourceAssetName", ard.getSrcAssetName());
		        	j1.put("destinationAssetName", ard.getDestAssetName());
		        	j1.put("relationName", ard.getDescription());
		        	j1.put("relationType", ard.getFwdRelationType());
		        	j1.put("sourceImageName", ard.getSrcImageName());
		        	j1.put("destinationImageName", ard.getDestImageName());
		        	
		        	finaldata.add(j1);
		        }
				json.put("result", finaldata);
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("getAllAssetRelationshipDefForGridMain || End");
				
				return Response.status(retStat).entity(json.toString())
						.build();
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
						
		} catch (RepoproException e) {
			log.error("getAllAssetRelationshipDefForGridMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllAssetRelationshipDefForGridMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRelationshipDefForGridMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllAssetRelationshipDefForGridMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

}
