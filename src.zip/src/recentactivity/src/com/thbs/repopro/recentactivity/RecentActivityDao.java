package com.thbs.repopro.recentactivity;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.RoleDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.RecentActivity;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class RecentActivityDao {

	private final static Logger log = LoggerFactory.getLogger("timeBased");
	
	/**
	 * @method addRecentActivity
	 * @description to add recent activity data
	 * @param recentActivity
	 * @param conn
	 * @return RecentActivity
	 * @throws RepoproException
	 */
	public RecentActivity addRecentActivity(RecentActivity recentActivity,
			Connection conn) throws RepoproException{
		
		if (log.isDebugEnabled()) {
			log.debug("addRecentActivity" + recentActivity.toString()
					+ " Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addRecentActivity: " + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_RECENT_ACTIVITY));

			preparedStmt.setTimestamp(Constants.ONE, recentActivity.getActivityTimestamp());
			preparedStmt.setString(Constants.TWO,recentActivity.getDescription());
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, recentActivity.getAssetId());
			preparedStmt.setString(Constants.FIVE,recentActivity.getAssetInstVersionId());
			preparedStmt.setLong(Constants.SIX,recentActivity.getUser_id());
			
			preparedStmt.executeUpdate();
			
			rs = preparedStmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				recentActivity.setActivityId(rs.getLong(1));
			}

			if (log.isTraceEnabled()) {
				log.trace("addRecentActivity:"
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_RECENT_ACTIVITY));
			}
		} catch (SQLException e) {
			log.error("addRecentActivity: " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.ADD_RECENT_ACTIVITY_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addRecentActivity:  " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addRecentActivity:  "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addRecentActivity:  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addRecentActivity: "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isDebugEnabled()) {

			log.debug("addRecentActivity:" + recentActivity.toString() + " End");
		}
		return recentActivity;
	}
	
	
	/**
	 * @method getRecentActivityDetails
	 * @description to get recent activity details
	 * @param userName
	 * @param from
	 * @param conn
	 * @return List<RecentActivity>
	 * @throws RepoproException
	 */
	public List<RecentActivity> getRecentActivityDetails(String userName,int from,
			Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("getRecentActivityDetails||userName:" + userName + "from:"+from+" ||Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
		RecentActivity recentActivity = null;
		AssetInstanceVersionDao assetInstanceVersionDao =  new AssetInstanceVersionDao();
		
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getRecentActivity ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			
			boolean userFlag = false;
			if(!userName.equalsIgnoreCase("roleAnonymous")) {
				User user2 = userDao.retProfileForUserName(userName, conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user2.getUserId(), conn);
				for(UserFunction uf : userfunctionMappedWithRoleId){
					if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
						userFlag = true;
						break;
					}
				}
			}
			
			if(userName.equalsIgnoreCase("roleAnonymous")){
				if (log.isTraceEnabled()) {
					log.trace("getRecentActivityDetails ||"+ PropertyFileReader.getInstance().getValue(
							Constants.RET_RECENTACTIVITY_DETAILS_FOR_GUEST));
				}
				preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.RET_RECENTACTIVITY_DETAILS_FOR_GUEST));

				preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.THREE, userName);
				preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.SEVEN, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
				preparedStmt.setInt(Constants.NINE,from);

				rs = preparedStmt.executeQuery();
			}
			else{
				boolean flagForUser = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn1);
				if(flagForUser){
					if (log.isTraceEnabled()) {
						log.trace("getRecentActivityDetails ||"+ PropertyFileReader.getInstance().getValue(
								Constants.RET_RECENTACTIVITY_DETAILS_FOR_ADMIN));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.RET_RECENTACTIVITY_DETAILS_FOR_ADMIN));
					
					preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
					preparedStmt.setInt(Constants.TWO,from);
					
					rs = preparedStmt.executeQuery();
				}
				else{
					if (log.isTraceEnabled()) {
						log.trace("getRecentActivityDetails ||"+ PropertyFileReader.getInstance().getValue(
								Constants.RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN));
					}
					
					if(userFlag) {
						preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
								.getValue(Constants.RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN_FOR_LOGGED_IN_USER));
						
						preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.TWO, userName);
						preparedStmt.setInt(Constants.THREE,from);
					}else {
						preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
								.getValue(Constants.RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN));
						
						preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.THREE, userName);
						preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.SEVEN, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.NINE,userName);
						preparedStmt.setInt(Constants.TEN,from);
					}
					rs = preparedStmt.executeQuery();
				}
			}

			while (rs.next()) {
				recentActivity = new RecentActivity();
				recentActivity.setActivityId(rs.getLong("activity_id"));
				recentActivity.setActivityTimestamp(rs.getTimestamp("activity_timestamp"));
				recentActivity.setDescription(rs.getString("masked_description"));
				recentActivity.setAssetId(rs.getString("asset_id"));
				recentActivity.setAssetInstVersionId(rs.getString("asset_inst_version_id"));
				recentActivity.setUser_id(rs.getLong("user_id"));
				recentActivity.setUser_image(rs.getString("image_name"));
				recentActivity.setUserName(rs.getString("user_name"));
				recentActivity.setEncryptImage(rs.getInt("encrypt_image"));
				
				recentActivityList.add(recentActivity);
				if (log.isTraceEnabled()) {
					log.trace("getRecentActivityDetails ||"+ recentActivity.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getRecentActivityDetails ||"+ recentActivityList.toString());
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getRecentActivityDetails ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.RECENT_ACTIVITY_DETAILS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getRecentActivityDetails ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getRecentActivityDetails ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getRecentActivityDetails ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getRecentActivityDetails ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("getRecentActivityDetails||userName:" + userName +"from:"+from+"|| End");
		}

		return recentActivityList;
	}
	
	
	/**
	 * @method getRecentActivity
	 * @description to get recent activity data with fixed range
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<RecentActivity> getRecentActivity(String userName,
			Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("getRecentActivity || userName:" + userName + " ||Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
		RecentActivity recentActivity = null;
		AssetInstanceVersionDao assetInstanceVersionDao =  new AssetInstanceVersionDao();
		
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getRecentActivity ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			
			boolean userFlag = false;
			if(!userName.equalsIgnoreCase("roleAnonymous")) {
				User user2 = userDao.retProfileForUserName(userName, conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user2.getUserId(), conn);
				for(UserFunction uf : userfunctionMappedWithRoleId){
					if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
						userFlag = true;
						break;
					}
				}
			}
			
			if(userName.equalsIgnoreCase("roleAnonymous")){
				if (log.isTraceEnabled()) {
					log.trace("getRecentActivity ||"+ PropertyFileReader.getInstance().getValue(
							Constants.RET_RECENTACTIVITY_FOR_GUEST));
				}
				preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.RET_RECENTACTIVITY_FOR_GUEST));
				
				preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.THREE, userName);
				preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.SEVEN, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);

				rs = preparedStmt.executeQuery();
			}
			else{
				boolean flagForUser = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn1);
				if(flagForUser){
					if (log.isTraceEnabled()) {
						log.trace("getRecentActivity ||"+ PropertyFileReader.getInstance().getValue(
								Constants.RET_RECENTACTIVITY_FOR_ADMIN));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.RET_RECENTACTIVITY_FOR_ADMIN));
					
					preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
					
					rs = preparedStmt.executeQuery();
				}
				else{
					if (log.isTraceEnabled()) {
						log.trace("getRecentActivity ||"+ PropertyFileReader.getInstance().getValue(
								Constants.RET_RECENTACTIVITY_FOR_NON_ADMIN));
					}
					
					if(userFlag) {
						preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
								.getValue(Constants.RET_RECENTACTIVITY_FOR_NON_ADMIN_FOR_LOGGED_IN_USER));
						
						preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.TWO, userName);
					}else {
						preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
								.getValue(Constants.RET_RECENTACTIVITY_FOR_NON_ADMIN));
						
						preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.THREE, userName);
						preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.SEVEN, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
						preparedStmt.setString(Constants.NINE,userName);
					}
					
					rs = preparedStmt.executeQuery();
				}
			}

			while (rs.next()) {
				recentActivity = new RecentActivity();
				recentActivity.setActivityId(rs.getLong("activity_id"));
				recentActivity.setActivityTimestamp(rs.getTimestamp("activity_timestamp"));
				recentActivity.setDescription(rs.getString("masked_description"));
				recentActivity.setAssetId(rs.getString("asset_id"));
				recentActivity.setAssetInstVersionId(rs.getString("asset_inst_version_id"));
				recentActivity.setUser_id(rs.getLong("user_id"));
				recentActivity.setUserName(rs.getString("user_name"));
				recentActivity.setUser_image(rs.getString("image_name"));
				recentActivity.setEncryptImage(rs.getInt("encrypt_image"));
				
				recentActivityList.add(recentActivity);
				if (log.isTraceEnabled()) {
					log.trace("getRecentActivity ||"+ recentActivity.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getRecentActivity ||"+ recentActivityList.toString());
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getRecentActivity ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.RECENT_ACTIVITY_DETAILS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getRecentActivity ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getRecentActivity ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getRecentActivity ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getRecentActivity ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("getRecentActivity || userName:" + userName + "|| End");
		}

		return recentActivityList;
	}
	
	
	public List<RecentActivity> filterRecentActivityDetails(String value, int from,
			String userName, Connection conn) throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("filterRecentActivityDetails || value : "+ value +
					"from:"+from+" userName : " +userName+" ||Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
		RecentActivity recentActivity = null;
		AssetInstanceVersionDao assetInstanceVersionDao =  new AssetInstanceVersionDao();
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("filterRecentActivityDetails ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			if(userName.equalsIgnoreCase("roleAnonymous")){
				if (log.isTraceEnabled()) {
					log.trace("filterRecentActivityDetails ||"+ PropertyFileReader.getInstance().getValue(
							Constants.FILTER_RECENTACTIVITY_DETAILS_FOR_GUEST));
				}
				preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.FILTER_RECENTACTIVITY_DETAILS_FOR_GUEST));
				
				preparedStmt.setString(Constants.ONE,value);
				preparedStmt.setString(Constants.TWO,value);
				preparedStmt.setInt(Constants.THREE,from);

				rs = preparedStmt.executeQuery();
			}
			else{
				boolean flagForUser = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn1);
				if(flagForUser){
					if (log.isTraceEnabled()) {
						log.trace("filterRecentActivityDetails ||"+ PropertyFileReader.getInstance().getValue(
								Constants.FILTER_RECENTACTIVITY_DETAILS_FOR_ADMIN));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.FILTER_RECENTACTIVITY_DETAILS_FOR_ADMIN));
					
					preparedStmt.setString(Constants.ONE,value);
					preparedStmt.setString(Constants.TWO,value);
					preparedStmt.setInt(Constants.THREE,from);
					
					rs = preparedStmt.executeQuery();
				}
				else{
					if (log.isTraceEnabled()) {
						log.trace("filterRecentActivityDetails ||"+ PropertyFileReader.getInstance().getValue(
								Constants.FILTER_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.FILTER_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN));
					
					preparedStmt.setString(Constants.ONE,userName);
					preparedStmt.setString(Constants.TWO,value);
					preparedStmt.setString(Constants.THREE,value);
					preparedStmt.setInt(Constants.FOUR,from);
					
					rs = preparedStmt.executeQuery();
				}
			}

			while (rs.next()) {
				recentActivity = new RecentActivity();
				recentActivity.setActivityId(rs.getLong("activity_id"));
				recentActivity.setActivityTimestamp(rs.getTimestamp("activity_timestamp"));
				recentActivity.setDescription(rs.getString("description"));
				recentActivity.setAssetId(rs.getString("asset_id"));
				recentActivity.setAssetInstVersionId(rs.getString("asset_inst_version_id"));
				recentActivity.setUser_id(rs.getLong("user_id"));
				recentActivity.setUser_image(rs.getString("image_name"));
				recentActivityList.add(recentActivity);
				if (log.isTraceEnabled()) {
					log.trace("filterRecentActivityDetails ||"+ recentActivity.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("filterRecentActivityDetails ||"+ recentActivityList.toString());
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("filterRecentActivityDetails ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.RECENT_ACTIVITY_DETAILS_NOT_FOUND));
		} catch (IOException e) {
			log.error("filterRecentActivityDetails ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("filterRecentActivityDetails ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("filterRecentActivityDetails ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("filterRecentActivityDetails ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("filterRecentActivityDetails|| End");
		}
		return recentActivityList;
	}
}
