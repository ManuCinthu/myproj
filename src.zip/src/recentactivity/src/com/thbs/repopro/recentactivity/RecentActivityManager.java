package com.thbs.repopro.recentactivity;

import java.sql.Connection;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.RecentActivity;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

@Path("/recentActivity")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class RecentActivityManager {
	
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method retrieveRecentActivityDetails
	 * @description to get recent activity details
	 * @param userName
	 * @param from
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/recentActivityDetails")
	public Response retrieveRecentActivityDetails(@QueryParam("userName") String userName,
			@QueryParam("from") int from){
		if (log.isTraceEnabled()) {
			log.trace("retrieveGuestAssetTypes || Begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		List<RecentActivity> recentActivityGridList = new ArrayList<RecentActivity>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("retrieveRecentActivityDetails || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("retrieveRecentActivityDetails || dao call of getRecentActivityDetails() method ");
			}
			recentActivityList = recentActivityDao.getRecentActivityDetails(userName, from, conn);
			for(RecentActivity activity:recentActivityList){
				String recentActData = activity.getDescription();
				String[] splitedArray = recentActData.split(";");
				Timestamp recentActivityTimestamp = activity.getActivityTimestamp();
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
				String dateStr = formatter.format(recentActivityTimestamp);
				
				if(splitedArray.length == 3){
					activity.setDescription("");
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);					
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName("N/A");
					activity.setAssetInstanceVersionName("N/A");
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
					activity.setUser_image(activity.getUser_image());
					activity.setEncryptImage(activity.getEncryptImage());

				}
				else if(splitedArray.length == 4){
					activity.setDescription("");
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName(splitedArray[3].toString());
					activity.setAssetInstanceVersionName("N/A");
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
					activity.setUser_image(activity.getUser_image());
					activity.setEncryptImage(activity.getEncryptImage());

				}
				else{
					activity.setDescription("");
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName(splitedArray[3].toString());
					String val = splitedArray[4].substring(splitedArray[4].indexOf("Version")+8);
					activity.setAssetInstanceVersionName(val);
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
					activity.setUser_image(activity.getUser_image());
					activity.setEncryptImage(activity.getEncryptImage());

				}
				
				recentActivityGridList.add(activity);
				
			}
			if (log.isDebugEnabled()) {
				log.debug("retrieveRecentActivityDetails || retrieve "
						+ recentActivityGridList.size()+ " rows of recentactivity data");
			}
			conn.commit();
			if(recentActivityGridList.isEmpty()){
				retMsg = Constants.RECENT_ACTIVITY_DETAILS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retMsg = Constants.RECENT_ACTIVITY_DATA_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("retrieveRecentActivityDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}catch (Exception e) {
			log.error("retrieveRecentActivityDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retrieveRecentActivityDetails|| "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retrieveRecentActivityDetails || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(recentActivityGridList))).build();
	}
	/**
	 * @method retrieveRecentActivity
	 * @description to get fixed range recent activity 
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/getRecentActivity")
	public Response retrieveRecentActivity(@QueryParam("userName") String userName){
		if (log.isTraceEnabled()) {
			log.trace("retrieveRecentActivity || Begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		List<RecentActivity> recentActivityGridList = new ArrayList<RecentActivity>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("retrieveRecentActivity || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("retrieveRecentActivity || dao call of getRecentActivity() method ");
			}
			recentActivityList = recentActivityDao.getRecentActivity(userName,conn);
		
			for(RecentActivity activity:recentActivityList){
		
				String recentActData = activity.getDescription();
				String[] splitedArray = recentActData.split(";");
				Timestamp recentActivityTimestamp = activity.getActivityTimestamp();
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
				String dateStr = formatter.format(recentActivityTimestamp);
				
				if(splitedArray.length == 3){
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName("");
					activity.setAssetInstanceVersionName("");
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
					activity.setDescription(activity.getDescription());
					activity.setUser_image(activity.getUser_image());
					activity.setEncryptImage(activity.getEncryptImage());
				}
				else if(splitedArray.length == 4){
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName(splitedArray[3].toString());
					activity.setAssetInstanceVersionName("N/A");
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
					activity.setDescription(activity.getDescription());
					activity.setUser_image(activity.getUser_image());
					activity.setEncryptImage(activity.getEncryptImage());
				}
				else{
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName(splitedArray[3].toString());
					String val = splitedArray[4].substring(splitedArray[4].indexOf("Version")+8);
					activity.setAssetInstanceVersionName(val);
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
					activity.setDescription(activity.getDescription());
					activity.setUser_image(activity.getUser_image());
					activity.setEncryptImage(activity.getEncryptImage());
				}
				
				recentActivityGridList.add(activity);
				
			}
			if (log.isDebugEnabled()) {
				log.debug("retrieveRecentActivity || retrieve "
						+ recentActivityGridList.size()+ " rows of recentactivity data");
			}
			conn.commit();
			if(recentActivityGridList.isEmpty()){
				retMsg = Constants.RECENT_ACTIVITY_DETAILS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retMsg = Constants.RECENT_ACTIVITY_DATA_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("retrieveRecentActivity || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}catch (Exception e) {
			log.error("retrieveRecentActivity || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retrieveRecentActivity|| "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("retrieveRecentActivity || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(recentActivityGridList))).build();
	}
	
	
	/**
	 * @method : filterRecentActivityDetails
	 * @param key
	 * @param value
	 * @param from
	 * @param userName
	 * @return
	 */
	@GET
	@Path("/filterRecentActivityDetails")
	public Response filterRecentActivityDetails(@QueryParam("value") String value, 
			@QueryParam("from") int from, @QueryParam("userName") String userName){
		
		if (log.isTraceEnabled()) {
			log.trace("filterRecentActivityDetails|| value : "+ value 
					+"from:"+from+" +userName :"+userName+" ||Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		List<RecentActivity> recentActivityGridList = new ArrayList<RecentActivity>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("filterRecentActivityDetails || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
			}
			
			recentActivityList = recentActivityDao.filterRecentActivityDetails(value, from, userName, conn);
			
			for(RecentActivity activity:recentActivityList){
				String recentActData = activity.getDescription();
				String[] splitedArray = recentActData.split(";");
				Timestamp recentActivityTimestamp = activity.getActivityTimestamp();
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
				String dateStr = formatter.format(recentActivityTimestamp);
				
				if(splitedArray.length == 3){
					activity.setDescription("");
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName("N/A");
					activity.setAssetInstanceVersionName("N/A");
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
					activity.setUser_image(activity.getUser_image());

				}
				else if(splitedArray.length == 4){
					activity.setDescription("");
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName(splitedArray[3].toString());
					activity.setAssetInstanceVersionName("N/A");
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
					activity.setUser_image(activity.getUser_image());

				}
				else{
					activity.setDescription("");
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName(splitedArray[3].toString());
					String val = splitedArray[4].substring(splitedArray[4].indexOf("Version")+8);
					activity.setAssetInstanceVersionName(val);
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
					activity.setUser_image(activity.getUser_image());

				}
				recentActivityGridList.add(activity);
			}
			
			if(recentActivityGridList.isEmpty()){
				retMsg = Constants.RECENT_ACTIVITY_DETAILS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retMsg = Constants.RECENT_ACTIVITY_DATA_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			
		} catch (RepoproException e) {
			log.error("filterRecentActivityDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}catch (Exception e) {
			log.error("filterRecentActivityDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterRecentActivityDetails|| " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("filterRecentActivityDetails || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(recentActivityList))).build();
	}
	
}
