package com.thbs.repopro.dto;

import java.util.Arrays;
import java.util.List;

public class ParameterData {
private String LogicalOperator;
private String parameterName;
private String operatorValue;
private String parameterType;
private String parameterValues[];

public String getLogicalOperator() {
	return LogicalOperator;
}

public void setLogicalOperator(String logicalOperator) {
	LogicalOperator = logicalOperator;
}

public String getParameterName() {
	return parameterName;
}

public void setParameterName(String parameterName) {
	this.parameterName = parameterName;
}

public String getOperatorValue() {
	return operatorValue;
}

public void setOperatorValue(String operatorValue) {
	this.operatorValue = operatorValue;
}

public String getParameterType() {
	return parameterType;
}

public void setParameterType(String parameterType) {
	this.parameterType = parameterType;
}

public String[] getParameterValues() {
	return parameterValues;
}

public void setParameterValues(String[] parameterValues) {
	this.parameterValues = parameterValues;
}

@Override
public String toString() {
	return "ParameterData [LogicalOperator=" + LogicalOperator + ", parameterName="
			+ parameterName + ", operatorValue=" + operatorValue
			+ ", parameterType=" + parameterType + ", parameterValues="
			+ Arrays.toString(parameterValues) + "]";
}

}
