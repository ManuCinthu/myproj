package com.thbs.repopro.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class AivRevisionHistory {

	private Long aivRevisionHistoryId;
	private Long aivId;
	private String revId;
	private Timestamp revisedOn;
	private String changedKey;
	private String overviewData;
	private String relationshipData;
	private String parameterData;
	private String usedBy;
	private Long userId;
	private String userName;
	private String imageName;
	private String instanceRename;
	private String newInstanceKey;
	private String overviewKey;
	private String instanceRenameKey;
	private String parameterKey;
	private String relationshipKey;
	private String versionName;
	private int encryptImage;
	
	HashMap<String, String> parameterDataMap = new HashMap<String, String>();

	public Long getAivRevisionHistoryId() {
		return aivRevisionHistoryId;
	}

	public void setAivRevisionHistoryId(Long aivRevisionHistoryId) {
		this.aivRevisionHistoryId = aivRevisionHistoryId;
	}

	public Long getAivId() {
		return aivId;
	}

	public void setAivId(Long aivId) {
		this.aivId = aivId;
	}

	public String getRevId() {
		return revId;
	}

	public void setRevId(String revId) {
		this.revId = revId;
	}

	public Timestamp getRevisedOn() {
		return revisedOn;
	}

	public void setRevisedOn(Timestamp revisedOn) {
		this.revisedOn = revisedOn;
	}

	public String getChangedKey() {
		return changedKey;
	}

	public void setChangedKey(String changedKey) {
		this.changedKey = changedKey;
	}

	public String getOverviewData() {
		return overviewData;
	}

	public void setOverviewData(String overviewData) {
		this.overviewData = overviewData;
	}

	public String getRelationshipData() {
		return relationshipData;
	}

	public void setRelationshipData(String relationshipData) {
		this.relationshipData = relationshipData;
	}

	public String getParameterData() {
		return parameterData;
	}

	public void setParameterData(String parameterData) {
		this.parameterData = parameterData;
	}

	public String getUsedBy() {
		return usedBy;
	}

	public void setUsedBy(String usedBy) {
		this.usedBy = usedBy;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public HashMap<String, String> getParameterDataMap() {
		return parameterDataMap;
	}

	public void setParameterDataMap(HashMap<String, String> parameterDataMap) {
		this.parameterDataMap = parameterDataMap;
	}

	public String getInstanceRename() {
		return instanceRename;
	}

	public void setInstanceRename(String instanceRename) {
		this.instanceRename = instanceRename;
	}

	public String getNewInstanceKey() {
		return newInstanceKey;
	}

	public void setNewInstanceKey(String newInstanceKey) {
		this.newInstanceKey = newInstanceKey;
	}

	public String getOverviewKey() {
		return overviewKey;
	}

	public void setOverviewKey(String overviewKey) {
		this.overviewKey = overviewKey;
	}

	public String getInstanceRenameKey() {
		return instanceRenameKey;
	}

	public void setInstanceRenameKey(String instanceRenameKey) {
		this.instanceRenameKey = instanceRenameKey;
	}

	public String getParameterKey() {
		return parameterKey;
	}

	public void setParameterKey(String parameterKey) {
		this.parameterKey = parameterKey;
	}

	public String getRelationshipKey() {
		return relationshipKey;
	}

	public void setRelationshipKey(String relationshipKey) {
		this.relationshipKey = relationshipKey;
	}

	public String getVersionName() {
		return versionName;
	}

	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}

	public int getEncryptImage() {
		return encryptImage;
	}

	public void setEncryptImage(int encryptImage) {
		this.encryptImage = encryptImage;
	}

	@Override
	public String toString() {
		return "AivRevisionHistory [aivRevisionHistoryId=" + aivRevisionHistoryId + ", aivId=" + aivId + ", revId="
				+ revId + ", revisedOn=" + revisedOn + ", changedKey=" + changedKey + ", overviewData=" + overviewData
				+ ", relationshipData=" + relationshipData + ", parameterData=" + parameterData + ", usedBy=" + usedBy
				+ ", userId=" + userId + ", userName=" + userName + ", imageName=" + imageName + ", instanceRename="
				+ instanceRename + ", newInstanceKey=" + newInstanceKey + ", overviewKey=" + overviewKey
				+ ", instanceRenameKey=" + instanceRenameKey + ", parameterKey=" + parameterKey + ", relationshipKey="
				+ relationshipKey + ", versionName=" + versionName + ", encryptImage=" + encryptImage
				+ ", parameterDataMap=" + parameterDataMap + "]";
	}

}
