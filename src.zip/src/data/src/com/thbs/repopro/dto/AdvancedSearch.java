package com.thbs.repopro.dto;

public class AdvancedSearch {

	private String usecase;
	private String query;
	private String parameters;
	private int useCaseTotalCount;
	
	public String getUsecase() {
		return usecase;
	}
	public void setUsecase(String usecase) {
		this.usecase = usecase;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getParameters() {
		return parameters;
	}
	public void setParameters(String parameters) {
		this.parameters = parameters;
	}
	public int getUseCaseTotalCount() {
		return useCaseTotalCount;
	}
	public void setUseCaseTotalCount(int useCaseTotalCount) {
		this.useCaseTotalCount = useCaseTotalCount;
	}
	@Override
	public String toString() {
		return "AdvancedSearch [usecase=" + usecase + ", query=" + query
				+ ", parameters=" + parameters + ", useCaseTotalCount="
				+ useCaseTotalCount + "]";
	}
	
	
	
}
