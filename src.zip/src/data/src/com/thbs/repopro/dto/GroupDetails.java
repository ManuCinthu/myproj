package com.thbs.repopro.dto;

import java.util.List;

public class GroupDetails {

	private Long groupId;
	private String groupName;
	private String categoryName;
	private String description;
	private Long groupRolesId;
	private Long roleId;
	private List<String> associatedRoleIds;
	private List<String> associatedRoleNames;
	private boolean isMappedWithUser;
	private boolean groupUserFlag; 
    private Long editAccess;
	
	
	public GroupDetails() {
		super();
	}

	public GroupDetails(GroupDetails gt){
		this.groupId = gt.getGroupId();
		this.groupName = gt.getGroupName();
		this.categoryName = gt.getCategoryName();
		this.description = gt.getDescription();
		this.groupRolesId = gt.getGroupRolesId();
		this.roleId = gt.getRoleId();
		this.associatedRoleIds = gt.getAssociatedRoleIds();
		this.isMappedWithUser = gt.isMappedWithUser();
		this.groupUserFlag = gt.isGroupUserFlag();
	}
	
	
	public Long getEditAccess() {
		return editAccess;
	}

	public void setEditAccess(Long editAccess) {
		this.editAccess = editAccess;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getGroupRolesId() {
		return groupRolesId;
	}

	public void setGroupRolesId(Long groupRolesId) {
		this.groupRolesId = groupRolesId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public List<String> getAssociatedRoleIds() {
		return associatedRoleIds;
	}

	public void setAssociatedRoleIds(List<String> associatedRoleIds) {
		this.associatedRoleIds = associatedRoleIds;
	}

	public boolean isMappedWithUser() {
		return isMappedWithUser;
	}

	public void setMappedWithUser(boolean isMappedWithUser) {
		this.isMappedWithUser = isMappedWithUser;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public boolean isGroupUserFlag() {
		return groupUserFlag;
	}

	public void setGroupUserFlag(boolean groupUserFlag) {
		this.groupUserFlag = groupUserFlag;
	}
	
	public List<String> getAssociatedRoleNames() {
		return associatedRoleNames;
	}

	public void setAssociatedRoleNames(List<String> associatedRoleNames) {
		this.associatedRoleNames = associatedRoleNames;
	}

	@Override
	public String toString() {
		return "GroupDetails [groupId=" + groupId + ", groupName=" + groupName
				+ ", categoryName=" + categoryName + ", description="
				+ description + ", groupRolesId=" + groupRolesId + ", roleId="
				+ roleId + ", associatedRoleIds=" + associatedRoleIds
				+ ", associatedRoleNames=" + associatedRoleNames
				+ ", isMappedWithUser=" + isMappedWithUser + ", groupUserFlag="
				+ groupUserFlag + ", editAccess=" + editAccess + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((associatedRoleIds == null) ? 0 : associatedRoleIds.hashCode());
		result = prime * result + ((associatedRoleNames == null) ? 0 : associatedRoleNames.hashCode());
		result = prime * result + ((categoryName == null) ? 0 : categoryName.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((groupId == null) ? 0 : groupId.hashCode());
		result = prime * result + ((groupName == null) ? 0 : groupName.hashCode());
		result = prime * result + ((groupRolesId == null) ? 0 : groupRolesId.hashCode());
		result = prime * result + (groupUserFlag ? 1231 : 1237);
		result = prime * result + (isMappedWithUser ? 1231 : 1237);
		result = prime * result + ((roleId == null) ? 0 : roleId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GroupDetails other = (GroupDetails) obj;
		if (associatedRoleIds == null) {
			if (other.associatedRoleIds != null)
				return false;
		} else if (!associatedRoleIds.equals(other.associatedRoleIds))
			return false;
		if (associatedRoleNames == null) {
			if (other.associatedRoleNames != null)
				return false;
		} else if (!associatedRoleNames.equals(other.associatedRoleNames))
			return false;
		if (categoryName == null) {
			if (other.categoryName != null)
				return false;
		} else if (!categoryName.equals(other.categoryName))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (groupId == null) {
			if (other.groupId != null)
				return false;
		} else if (!groupId.equals(other.groupId))
			return false;
		if (groupName == null) {
			if (other.groupName != null)
				return false;
		} else if (!groupName.equals(other.groupName))
			return false;
		if (groupRolesId == null) {
			if (other.groupRolesId != null)
				return false;
		} else if (!groupRolesId.equals(other.groupRolesId))
			return false;
		if (groupUserFlag != other.groupUserFlag)
			return false;
		if (isMappedWithUser != other.isMappedWithUser)
			return false;
		if (roleId == null) {
			if (other.roleId != null)
				return false;
		} else if (!roleId.equals(other.roleId))
			return false;
		return true;
	}
	
	

	
}
