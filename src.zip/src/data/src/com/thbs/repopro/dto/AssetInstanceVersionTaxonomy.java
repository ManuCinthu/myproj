package com.thbs.repopro.dto;

public class AssetInstanceVersionTaxonomy {

	private Long assetInstVersionsTaxonomyId;
	private Long assetInstVersionId;
	private Long aivTaxonomyId;

	private Long taxonomyId;
	private String taxonomyName;
	private Long parenttaxonomyId;

	public Long getAssetInstVersionsTaxonomyId() {
		return assetInstVersionsTaxonomyId;
	}

	public void setAssetInstVersionsTaxonomyId(Long assetInstVersionsTaxonomyId) {
		this.assetInstVersionsTaxonomyId = assetInstVersionsTaxonomyId;
	}

	public Long getAssetInstVersionId() {
		return assetInstVersionId;
	}

	public void setAssetInstVersionId(Long assetInstVersionId) {
		this.assetInstVersionId = assetInstVersionId;
	}

	public Long getAivTaxonomyId() {
		return aivTaxonomyId;
	}

	public void setAivTaxonomyId(Long aivTaxonomyId) {
		this.aivTaxonomyId = aivTaxonomyId;
	}

	public Long getTaxonomyId() {
		return taxonomyId;
	}

	public void setTaxonomyId(Long taxonomyId) {
		this.taxonomyId = taxonomyId;
	}

	public String getTaxonomyName() {
		return taxonomyName;
	}

	public void setTaxonomyName(String taxonomyName) {
		this.taxonomyName = taxonomyName;
	}

	public Long getParenttaxonomyId() {
		return parenttaxonomyId;
	}

	public void setParenttaxonomyId(Long parenttaxonomyId) {
		this.parenttaxonomyId = parenttaxonomyId;
	}

	@Override
	public String toString() {
		return "AssetInstanceVersionTaxonomy [assetInstVersionsTaxonomyId="
				+ assetInstVersionsTaxonomyId + ", assetInstVersionId="
				+ assetInstVersionId + ", aivTaxonomyId=" + aivTaxonomyId
				+ ", taxonomyId=" + taxonomyId + ", taxonomyName="
				+ taxonomyName + ", parenttaxonomyId=" + parenttaxonomyId + "]";
	}

}
