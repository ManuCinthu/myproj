package com.thbs.repopro.dto;

import java.sql.Timestamp;

public class RecentActivity {
	private Long activityId;
	private Timestamp activityTimestamp;
	private String description;
	private String assetId;
	private String assetInstVersionId;
	private String date;
	private String userName;
	private String action;
	private String assetName;
	private String assetInstName;
	private String assetInstanceVersionName;
	private String user_image;
	private Long user_id;
	private int encryptImage;

	public Long getActivityId() {
		return activityId;
	}

	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

	public Timestamp getActivityTimestamp() {
		return activityTimestamp;
	}

	public void setActivityTimestamp(Timestamp activityTimestamp) {
		this.activityTimestamp = activityTimestamp;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getAssetInstVersionId() {
		return assetInstVersionId;
	}

	public void setAssetInstVersionId(String assetInstVersionId) {
		this.assetInstVersionId = assetInstVersionId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetInstName() {
		return assetInstName;
	}

	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}

	public String getAssetInstanceVersionName() {
		return assetInstanceVersionName;
	}

	public void setAssetInstanceVersionName(String assetInstanceVersionName) {
		this.assetInstanceVersionName = assetInstanceVersionName;
	}

	public String getUser_image() {
		return user_image;
	}

	public void setUser_image(String user_image) {
		this.user_image = user_image;
	}

	public Long getUser_id() {
		return user_id;
	}

	public void setUser_id(Long user_id) {
		this.user_id = user_id;
	}

	public int getEncryptImage() {
		return encryptImage;
	}

	public void setEncryptImage(int encryptImage) {
		this.encryptImage = encryptImage;
	}

	@Override
	public String toString() {
		return "RecentActivity [activityId=" + activityId + ", activityTimestamp=" + activityTimestamp
				+ ", description=" + description + ", assetId=" + assetId + ", assetInstVersionId=" + assetInstVersionId
				+ ", date=" + date + ", userName=" + userName + ", action=" + action + ", assetName=" + assetName
				+ ", assetInstName=" + assetInstName + ", assetInstanceVersionName=" + assetInstanceVersionName
				+ ", user_image=" + user_image + ", user_id=" + user_id + ", encryptImage=" + encryptImage + "]";
	}

}
