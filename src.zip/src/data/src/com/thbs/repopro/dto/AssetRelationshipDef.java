package com.thbs.repopro.dto;

public class AssetRelationshipDef {
private Long assetRelId;
private Long srcAssetId;
private Long destAssetId;
private Long fwdRelId;
private Long bwdRelId;
private String description;
private String srcAssetName;
private String destAssetName;
private String fwdRelationType;
private String bwdRelationType;
private boolean relationMappedFlag;
private boolean derivedAttributeMappedFlag;
private String srcImageName;
private String destImageName;

public boolean isDerivedAttributeMappedFlag() {
	return derivedAttributeMappedFlag;
}
public void setDerivedAttributeMappedFlag(boolean derivedAttributeMappedFlag) {
	this.derivedAttributeMappedFlag = derivedAttributeMappedFlag;
}
public boolean isRelationMappedFlag() {
	return relationMappedFlag;
}
public void setRelationMappedFlag(boolean relationMappedFlag) {
	this.relationMappedFlag = relationMappedFlag;
}
public Long getAssetRelId() {
	return assetRelId;
}
public void setAssetRelId(Long assetRelId) {
	this.assetRelId = assetRelId;
}
public Long getSrcAssetId() {
	return srcAssetId;
}
public void setSrcAssetId(Long srcAssetId) {
	this.srcAssetId = srcAssetId;
}
public Long getDestAssetId() {
	return destAssetId;
}
public void setDestAssetId(Long destAssetId) {
	this.destAssetId = destAssetId;
}
public Long getFwdRelId() {
	return fwdRelId;
}
public void setFwdRelId(Long fwdRelId) {
	this.fwdRelId = fwdRelId;
}
public Long getBwdRelId() {
	return bwdRelId;
}
public void setBwdRelId(Long bwdRelId) {
	this.bwdRelId = bwdRelId;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getSrcAssetName() {
	return srcAssetName;
}
public void setSrcAssetName(String srcAssetName) {
	this.srcAssetName = srcAssetName;
}
public String getDestAssetName() {
	return destAssetName;
}
public void setDestAssetName(String destAssetName) {
	this.destAssetName = destAssetName;
}
public String getFwdRelationType() {
	return fwdRelationType;
}
public void setFwdRelationType(String fwdRelationType) {
	this.fwdRelationType = fwdRelationType;
}
public String getBwdRelationType() {
	return bwdRelationType;
}
public void setBwdRelationType(String bwdRelationType) {
	this.bwdRelationType = bwdRelationType;
}
public String getSrcImageName() {
	return srcImageName;
}
public void setSrcImageName(String srcImageName) {
	this.srcImageName = srcImageName;
}
public String getDestImageName() {
	return destImageName;
}
public void setDestImageName(String destImageName) {
	this.destImageName = destImageName;
}
@Override
public String toString() {
	return "AssetRelationshipDef [assetRelId=" + assetRelId + ", srcAssetId="
			+ srcAssetId + ", destAssetId=" + destAssetId + ", fwdRelId="
			+ fwdRelId + ", bwdRelId=" + bwdRelId + ", description="
			+ description + ", srcAssetName=" + srcAssetName
			+ ", destAssetName=" + destAssetName + ", fwdRelationType="
			+ fwdRelationType + ", bwdRelationType=" + bwdRelationType
			+ ", relationMappedFlag=" + relationMappedFlag
			+ ", derivedAttributeMappedFlag=" + derivedAttributeMappedFlag
			+ ", srcImageName=" + srcImageName + ", destImageName="
			+ destImageName + "]";
}




}
