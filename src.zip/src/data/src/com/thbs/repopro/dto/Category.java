package com.thbs.repopro.dto;

import java.util.LinkedList;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
public class Category {
	
	
	private Long categoryId;
	private Long assetId;
	private String categoryName;
	private List<AssetParamDef> parameters;
	private boolean deleted;
	private LinkedList<Parameter> parameters1;
	private String catDisp;
	private boolean flagForCategoryUsageInAssetListRule;
	
	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	private List<AssetParamDef> listOfAssetParamDefs;
	//@XmlElement(name="parameterDetailsList")
	private LinkedList<Parameter> parametersdata;
	
	
	private String description;
	private int disp_position;
	
	
	private String categoryAction;
	
	private String actionForCategory;
	
	public List<AssetParamDef> getParameters() {
		return parameters;
	}

	public void setParameters(List<AssetParamDef> parameters) {
		this.parameters = parameters;
	}

	public boolean isFlagForCategoryRuleUsage() {
		return flagForCategoryRuleUsage;
	}

	public void setFlagForCategoryRuleUsage(boolean flagForCategoryRuleUsage) {
		this.flagForCategoryRuleUsage = flagForCategoryRuleUsage;
	}

	private boolean flagForCategoryRuleUsage;

	
	

	public String getActionForCategory() {
		return actionForCategory;
	}

	public void setActionForCategory(String actionForCategory) {
		this.actionForCategory = actionForCategory;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getDisp_position() {
		return disp_position;
	}

	public void setDisp_position(int disp_position) {
		this.disp_position = disp_position;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public List<AssetParamDef> getListOfAssetParamDefs() {
		return listOfAssetParamDefs;
	}

	public void setListOfAssetParamDefs(
			List<AssetParamDef> listOfAssetParamDefs) {
		this.listOfAssetParamDefs = listOfAssetParamDefs;
	}

	public String getCategoryAction() {
		return categoryAction;
	}

	public void setCategoryAction(String categoryAction) {
		this.categoryAction = categoryAction;
	}

	public LinkedList<Parameter> getParametersdata() {
		return parametersdata;
	}

	public void setParametersdata(LinkedList<Parameter> parametersdata) {
		this.parametersdata = parametersdata;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public String getCatDisp() {
		return catDisp;
	}

	public void setCatDisp(String catDisp) {
		this.catDisp = catDisp;
	}

	public LinkedList<Parameter> getParameters1() {
		return parameters1;
	}

	public void setParameters1(LinkedList<Parameter> parameters1) {
		this.parameters1 = parameters1;
	}

	public boolean isFlagForCategoryUsageInAssetListRule() {
		return flagForCategoryUsageInAssetListRule;
	}

	public void setFlagForCategoryUsageInAssetListRule(boolean flagForCategoryUsageInAssetListRule) {
		this.flagForCategoryUsageInAssetListRule = flagForCategoryUsageInAssetListRule;
	}

	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", assetId=" + assetId + ", categoryName=" + categoryName
				+ ", parameters=" + parameters + ", deleted=" + deleted + ", parameters1=" + parameters1 + ", catDisp="
				+ catDisp + ", flagForCategoryUsageInAssetListRule=" + flagForCategoryUsageInAssetListRule
				+ ", listOfAssetParamDefs=" + listOfAssetParamDefs + ", parametersdata=" + parametersdata
				+ ", description=" + description + ", disp_position=" + disp_position + ", categoryAction="
				+ categoryAction + ", actionForCategory=" + actionForCategory + ", flagForCategoryRuleUsage="
				+ flagForCategoryRuleUsage + "]";
	}
}
