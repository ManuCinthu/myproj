package com.thbs.repopro.dto;

public class QuickStats {
	private String assetName;
	private Long assetInstanceVersionCount;
    private String assetIconImageName;
    private Long assetId;
	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public Long getAssetInstanceVersionCount() {
		return assetInstanceVersionCount;
	}

	public void setAssetInstanceVersionCount(Long assetInstanceVersionCount) {
		this.assetInstanceVersionCount = assetInstanceVersionCount;
	}

	public String getAssetIconImageName() {
		return assetIconImageName;
	}

	public void setAssetIconImageName(String assetIconImageName) {
		this.assetIconImageName = assetIconImageName;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	@Override
	public String toString() {
		return "QuickStats [assetName=" + assetName
				+ ", assetInstanceVersionCount=" + assetInstanceVersionCount
				+ ", assetIconImageName=" + assetIconImageName + ", assetId="
				+ assetId + "]";
	}

	

}
