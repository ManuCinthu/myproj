package com.thbs.repopro.dto;

import java.util.List;

public class AssetInstVersionTaxonomy {

	private Long assetInstVersionTaxonomyId;
	private Long taxonomyId;
	private String assetName;
	private String assetInstanceName;
	private Long assetInstVersionId;
	private String versionName;
	private String overview;
	public boolean versionable;
	private List<Long> taxonIds;
	private Long assetId;
	private boolean taxonomiesFlagChecker=true;
	private String taxonomyName;
	private List<Long> unassigntaxonIds;

	public Long getAssetInstVersionTaxonomyId() {
		return assetInstVersionTaxonomyId;
	}
	public void setAssetInstVersionTaxonomyId(Long assetInstVersionTaxonomyId) {
		this.assetInstVersionTaxonomyId = assetInstVersionTaxonomyId;
	}
	public Long getTaxonomyId() {
		return taxonomyId;
	}
	public void setTaxonomyId(Long taxonomyId) {
		this.taxonomyId = taxonomyId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetInstanceName() {
		return assetInstanceName;
	}
	public void setAssetInstanceName(String assetInstanceName) {
		this.assetInstanceName = assetInstanceName;
	}
	public Long getAssetInstVersionId() {
		return assetInstVersionId;
	}
	public void setAssetInstVersionId(Long assetInstVersionId) {
		this.assetInstVersionId = assetInstVersionId;
	}
	public String getVersionName() {
		return versionName;
	}
	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}
	public String getOverview() {
		return overview;
	}
	public void setOverview(String overview) {
		this.overview = overview;
	}
	public boolean isVersionable() {
		return versionable;
	}
	public void setVersionable(boolean versionable) {
		this.versionable = versionable;
	}
	public List<Long> getTaxonIds() {
		return taxonIds;
	}
	public void setTaxonIds(List<Long> taxonIds) {
		this.taxonIds = taxonIds;
	}
	public boolean isTaxonomiesFlagChecker() {
		return taxonomiesFlagChecker;
	}
	public void setTaxonomiesFlagChecker(boolean taxonomiesFlagChecker) {
		this.taxonomiesFlagChecker = taxonomiesFlagChecker;
	}
	public Long getAssetId() {
		return assetId;
	}
	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}
	public String getTaxonomyName() {
		return taxonomyName;
	}
	public void setTaxonomyName(String taxonomyName) {
		this.taxonomyName = taxonomyName;
	}
	public List<Long> getUnassigntaxonIds() {
		return unassigntaxonIds;
	}
	public void setUnassigntaxonIds(List<Long> unassigntaxonIds) {
		this.unassigntaxonIds = unassigntaxonIds;
	}
	@Override
	public String toString() {
		return "AssetInstVersionTaxonomy [assetInstVersionTaxonomyId="
				+ assetInstVersionTaxonomyId + ", taxonomyId=" + taxonomyId
				+ ", assetName=" + assetName + ", assetInstanceName="
				+ assetInstanceName + ", assetInstVersionId=" + assetInstVersionId
				+ ", versionName=" + versionName + ", overview=" + overview
				+ ", versionable=" + versionable + ", taxonIds=" + taxonIds
				+ ", assetId=" + assetId + ", taxonomiesFlagChecker="
				+ taxonomiesFlagChecker + ", taxonomyName=" + taxonomyName
				+ ", unassigntaxonIds=" + unassigntaxonIds + "]";
	}

}
