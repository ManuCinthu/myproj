package com.thbs.repopro.dto;

public class RelationshipDef {
	private Long relationshipId;
	private String relationName;
	private String minValue;
	private String maxValue;
	private String desc;

	public Long getRelationshipId() {
		return relationshipId;
	}

	public void setRelationshipId(Long relationshipId) {
		this.relationshipId = relationshipId;
	}

	public String getRelationName() {
		return relationName;
	}

	public void setRelationName(String relationName) {
		this.relationName = relationName;
	}

	public String getMinValue() {
		return minValue;
	}

	public void setMinValue(String minValue) {
		this.minValue = minValue;
	}

	public String getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(String maxValue) {
		this.maxValue = maxValue;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	@Override
	public String toString() {
		return "RelationshipDef [relationshipId=" + relationshipId
				+ ", relationName=" + relationName + ", minValue=" + minValue
				+ ", maxValue=" + maxValue + ", desc=" + desc + "]";
	}

}
