package com.thbs.repopro.dto;

import java.util.Arrays;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

public class Workflow {

	private Long workflowId;
	private String workflowName;
	private String jsonStructure;
	private Map<String, InstanceStatus> status;
	private Long[] selectedAssets; // save
	private Long currentStatus;
	private Map<Long, String> nextStates;
	private Map<Long, String> assignedAssets; //get all
	private Map<Long, String> allAssets;
	private boolean flagIfStateUpdated;

	public Long getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Long workflowId) {
		this.workflowId = workflowId;
	}

	public String getWorkflowName() {
		return workflowName;
	}

	public void setWorkflowName(String workflowName) {
		this.workflowName = workflowName;
	}

	public String getJsonStructure() {
		return jsonStructure;
	}

	public void setJsonStructure(String jsonStructure) {
		this.jsonStructure = jsonStructure;
	}
	
	public Map<String, InstanceStatus> getStatus() {
		return status;
	}

	public void setStatus(Map<String, InstanceStatus> status) {
		this.status = status;
	}

	public Long[] getSelectedAssets() {
		return selectedAssets;
	}

	public void setSelectedAssets(Long[] selectedAssets) {
		this.selectedAssets = selectedAssets;
	}

	public Long getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(Long currentStatus) {
		this.currentStatus = currentStatus;
	}

	public Map<Long, String> getNextStates() {
		return nextStates;
	}

	public void setNextStates(Map<Long, String> nextStates) {
		this.nextStates = nextStates;
	}

	public Map<Long, String> getAssignedAssets() {
		return assignedAssets;
	}

	public void setAssignedAssets(Map<Long, String> assignedAssets) {
		this.assignedAssets = assignedAssets;
	}

	public Map<Long, String> getAllAssets() {
		return allAssets;
	}

	public void setAllAssets(Map<Long, String> allAssets) {
		this.allAssets = allAssets;
	}

	public boolean isFlagIfStateUpdated() {
		return flagIfStateUpdated;
	}

	public void setFlagIfStateUpdated(boolean flagIfStateUpdated) {
		this.flagIfStateUpdated = flagIfStateUpdated;
	}

	@Override
	public String toString() {
		return "Workflow [workflowId=" + workflowId + ", workflowName=" + workflowName + ", jsonStructure="
				+ jsonStructure + ", status=" + status + ", selectedAssets=" + Arrays.toString(selectedAssets)
				+ ", currentStatus=" + currentStatus + ", nextStates=" + nextStates + ", assignedAssets="
				+ assignedAssets + ", allAssets=" + allAssets + ", flagIfStateUpdated=" + flagIfStateUpdated + "]";
	}
	
	public JSONObject statusToJsonObject() {
		JSONObject jsonObject = new JSONObject();
		this.status.forEach((key, value) ->{
			JSONObject instanceState = new JSONObject();
			try {
				instanceState.put("instanceState", value.getInstanceState());
				instanceState.put("next", value.getNext());
				instanceState.put("blockId", value.getBlockId());
				instanceState.put("nodetype", value.getNodetype());
				instanceState.put("positionX", value.getPositionX());
				instanceState.put("positionY", value.getPositionY());
				instanceState.put("connectingSourceId", value.getConnectingSourceId());
				instanceState.put("connectingTargetId", value.getConnectingTargetId());
				
				jsonObject.put(key, instanceState);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		return jsonObject;
	}
	
	/*public Map<String, InstanceStatus> statusToMap(JSONObject jsonObject) throws JSONException{
		Map<String, InstanceStatus> status = new HashMap<>();
		Iterator<String> iterator = jsonObject.keys();
		while(iterator.hasNext()) {
			String key = iterator.next();
			InstanceStatus instanceStatus = new InstanceStatus();
			instanceStatus.setInstanceState(jsonObject.getJSONObject(key).getString("instanceState"));
			Long[] nextLong =
			instanceStatus.setNext(jsonObject.getJSONObject(key).getJSONArray("next"));
		}
	}*/
}
