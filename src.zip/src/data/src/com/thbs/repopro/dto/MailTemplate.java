package com.thbs.repopro.dto;

public class MailTemplate {
	
private Long mailTemplateId;
private String functionalityName;
private String mailTemplate;

public Long getMailTemplateId() {
	return mailTemplateId;
}
public void setMailTemplateId(Long mailTemplateId) {
	this.mailTemplateId = mailTemplateId;
}
public String getFunctionalityName() {
	return functionalityName;
}
public void setFunctionalityName(String functionalityName) {
	this.functionalityName = functionalityName;
}
public String getMailTemplate() {
	return mailTemplate;
}
public void setMailTemplate(String mailTemplate) {
	this.mailTemplate = mailTemplate;
}

@Override
public String toString() {
	return "MailTemplate [mailTemplateId=" + mailTemplateId
			+ ", functionalityName=" + functionalityName + ", mailTemplate="
			+ mailTemplate + "]";
}


}
