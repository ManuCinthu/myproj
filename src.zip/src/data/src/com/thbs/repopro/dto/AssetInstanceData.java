package com.thbs.repopro.dto;

import java.util.List;

public class AssetInstanceData {
private List<AssetInstanceData> AssetInstanceData;
private String assetInstName;
private String assetName;
private String assetInstanceVersionName;
private boolean versionableFlag;
private String assetRelationshipName;
private String assetRelationshipType;
private Long assetInstanceVersionId;

public Long getAssetInstanceVersionId() {
	return assetInstanceVersionId;
}
public void setAssetInstanceVersionId(Long assetInstanceVersionId) {
	this.assetInstanceVersionId = assetInstanceVersionId;
}
public List<AssetInstanceData> getAssetInstanceData() {
	return AssetInstanceData;
}
public void setAssetInstanceData(List<AssetInstanceData> assetInstanceData) {
	AssetInstanceData = assetInstanceData;
}
public String getAssetInstName() {
	return assetInstName;
}
public void setAssetInstName(String assetInstName) {
	this.assetInstName = assetInstName;
}
public String getAssetName() {
	return assetName;
}
public void setAssetName(String assetName) {
	this.assetName = assetName;
}
public String getAssetInstanceVersionName() {
	return assetInstanceVersionName;
}
public void setAssetInstanceVersionName(String assetInstanceVersionName) {
	this.assetInstanceVersionName = assetInstanceVersionName;
}
public boolean isVersionableFlag() {
	return versionableFlag;
}
public void setVersionableFlag(boolean versionableFlag) {
	this.versionableFlag = versionableFlag;
}
public String getAssetRelationshipName() {
	return assetRelationshipName;
}
public void setAssetRelationshipName(String assetRelationshipName) {
	this.assetRelationshipName = assetRelationshipName;
}
public String getAssetRelationshipType() {
	return assetRelationshipType;
}
public void setAssetRelationshipType(String assetRelationshipType) {
	this.assetRelationshipType = assetRelationshipType;
}
@Override
public String toString() {
	return "AssetInstanceData [AssetInstanceData=" + AssetInstanceData
			+ ", assetInstName=" + assetInstName + ", assetName=" + assetName
			+ ", assetInstanceVersionName=" + assetInstanceVersionName
			+ ", versionableFlag=" + versionableFlag
			+ ", assetRelationshipName=" + assetRelationshipName
			+ ", assetRelationshipType=" + assetRelationshipType + "]";
}



}
