package com.thbs.repopro.dto;

import java.util.List;
import java.util.Map;

public class AssetParamSuccess {
	
	    private String parentAssetName;
		
		private String parentAssetInstanceName;
		
		private String assetType;
		
		private String assetInstName;
		
		private String versionName;
		
		private String assetInstanceDescription;
		
		private String catName;
		
		private String paramName;
		
		private String paramValue;
		
		private String paramTypeName;
		
        private String fileExist;
		
		private boolean isVersionable;
		
		private boolean hasStaticValue;
		private int hasArray;
		private Long paramTypeId;
		
		private Long listTypeParamTypeId;
		
		private Long assetParamId;
		
		private String RTFText;
		private String RTFPlainText;
		private List<String> RTFwithTags;
		private List<String> RTFwithOutTags;
		private List<String> textDataList;
		private Map<String,Integer> ldapMappingValue;
		
		private String errorMessage;
		/**
		 * @return the hasStaticValue
		 */
		public boolean isHasStaticValue() {
			return hasStaticValue;
		}

		public Map<String, Integer> getLdapMappingValue() {
			return ldapMappingValue;
		}

		public void setLdapMappingValue(Map<String, Integer> ldapMappingValue) {
			this.ldapMappingValue = ldapMappingValue;
		}

		/**
		 * @param hasStaticValue the hasStaticValue to set
		 */
		public void setHasStaticValue(boolean hasStaticValue) {
			this.hasStaticValue = hasStaticValue;
		}

		/**
		 * @return the fileExist
		 */
		public String getFileExist() {
			return fileExist;
		}

		/**
		 * @param fileExist the fileExist to set
		 */
		public void setFileExist(String fileExist) {
			this.fileExist = fileExist;
		}

		/**
		 * @return the isVersionable
		 */
		public boolean isVersionable() {
			return isVersionable;
		}

		/**
		 * @param isVersionable the isVersionable to set
		 */
		public void setVersionable(boolean isVersionable) {
			this.isVersionable = isVersionable;
		}

		/**
		 * @return the parentAssetName
		 */
		public String getParentAssetName() {
			return parentAssetName;
		}

		/**
		 * @param parentAssetName the parentAssetName to set
		 */
		public void setParentAssetName(String parentAssetName) {
			this.parentAssetName = parentAssetName;
		}

		/**
		 * @return the parentAssetInstanceName
		 */
		public String getParentAssetInstanceName() {
			return parentAssetInstanceName;
		}

		/**
		 * @param parentAssetInstanceName the parentAssetInstanceName to set
		 */
		public void setParentAssetInstanceName(String parentAssetInstanceName) {
			this.parentAssetInstanceName = parentAssetInstanceName;
		}

		/**
		 * @return the assetType
		 */
		public String getAssetType() {
			return assetType;
		}

		/**
		 * @param assetType the assetType to set
		 */
		public void setAssetType(String assetType) {
			this.assetType = assetType;
		}

		/**
		 * @return the assetInstName
		 */
		public String getAssetInstName() {
			return assetInstName;
		}

		/**
		 * @param assetInstName the assetInstName to set
		 */
		public void setAssetInstName(String assetInstName) {
			this.assetInstName = assetInstName;
		}

		/**
		 * @return the versionName
		 */
		public String getVersionName() {
			return versionName;
		}

		/**
		 * @param versionName the versionName to set
		 */
		public void setVersionName(String versionName) {
			this.versionName = versionName;
		}

		/**
		 * @return the assetInstanceDescription
		 */
		public String getAssetInstanceDescription() {
			return assetInstanceDescription;
		}

		/**
		 * @param assetInstanceDescription the assetInstanceDescription to set
		 */
		public void setAssetInstanceDescription(String assetInstanceDescription) {
			this.assetInstanceDescription = assetInstanceDescription;
		}

		/**
		 * @return the catName
		 */
		public String getCatName() {
			return catName;
		}

		/**
		 * @param catName the catName to set
		 */
		public void setCatName(String catName) {
			this.catName = catName;
		}

		/**
		 * @return the paramName
		 */
		public String getParamName() {
			return paramName;
		}

		/**
		 * @param paramName the paramName to set
		 */
		public void setParamName(String paramName) {
			this.paramName = paramName;
		}

		/**
		 * @return the paramValue
		 */
		public String getParamValue() {
			return paramValue;
		}

		/**
		 * @param paramValue the paramValue to set
		 */
		public void setParamValue(String paramValue) {
			this.paramValue = paramValue;
		}

		/**
		 * @return the paramTypeName
		 */
		public String getParamTypeName() {
			return paramTypeName;
		}

		/**
		 * @param paramTypeName the paramTypeName to set
		 */
		public void setParamTypeName(String paramTypeName) {
			this.paramTypeName = paramTypeName;
		}


		public Long getParamTypeId() {
			return paramTypeId;
		}

		public void setParamTypeId(Long paramTypeId) {
			this.paramTypeId = paramTypeId;
		}

		public Long getListTypeParamTypeId() {
			return listTypeParamTypeId;
		}

		public void setListTypeParamTypeId(Long listTypeParamTypeId) {
			this.listTypeParamTypeId = listTypeParamTypeId;
		}

		public Long getAssetParamId() {
			return assetParamId;
		}

		public void setAssetParamId(Long assetParamId) {
			this.assetParamId = assetParamId;
		}

		public String getRTFText() {
			return RTFText;
		}

		public void setRTFText(String rTFText) {
			RTFText = rTFText;
		}

		public String getRTFPlainText() {
			return RTFPlainText;
		}

		public void setRTFPlainText(String rTFPlainText) {
			RTFPlainText = rTFPlainText;
		}

		public List<String> getRTFwithTags() {
			return RTFwithTags;
		}

		public void setRTFwithTags(List<String> rTFwithTags) {
			RTFwithTags = rTFwithTags;
		}

		public List<String> getRTFwithOutTags() {
			return RTFwithOutTags;
		}

		public void setRTFwithOutTags(List<String> rTFwithOutTags) {
			RTFwithOutTags = rTFwithOutTags;
		}

		public List<String> getTextDataList() {
			return textDataList;
		}

		public void setTextDataList(List<String> textDataList) {
			this.textDataList = textDataList;
		}

		public String getErrorMessage() {
			return errorMessage;
		}

		public void setErrorMessage(String errorMessage) {
			this.errorMessage = errorMessage;
		}

		public int getHasArray() {
			return hasArray;
		}

		public void setHasArray(int hasArray) {
			this.hasArray = hasArray;
		}

		@Override
		public String toString() {
			return "AssetParamSuccess [parentAssetName=" + parentAssetName + ", parentAssetInstanceName="
					+ parentAssetInstanceName + ", assetType=" + assetType + ", assetInstName=" + assetInstName
					+ ", versionName=" + versionName + ", assetInstanceDescription=" + assetInstanceDescription
					+ ", catName=" + catName + ", paramName=" + paramName + ", paramValue=" + paramValue
					+ ", paramTypeName=" + paramTypeName + ", fileExist=" + fileExist + ", isVersionable="
					+ isVersionable + ", hasStaticValue=" + hasStaticValue + ", hasArray=" + hasArray + ", paramTypeId="
					+ paramTypeId + ", listTypeParamTypeId=" + listTypeParamTypeId + ", assetParamId=" + assetParamId
					+ ", RTFText=" + RTFText + ", RTFPlainText=" + RTFPlainText + ", RTFwithTags=" + RTFwithTags
					+ ", RTFwithOutTags=" + RTFwithOutTags + ", textDataList=" + textDataList + ", ldapMappingValue="
					+ ldapMappingValue + ", errorMessage=" + errorMessage + "]";
		}
		
		

}
