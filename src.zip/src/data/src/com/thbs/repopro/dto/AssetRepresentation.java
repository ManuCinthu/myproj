package com.thbs.repopro.dto;

public class AssetRepresentation {
	
	private Long assetRepresentationId;
	private String representationName;	
	private Long assetId;
	private String jarName;
	private String jarPath;
	private String implementedClassName;	
	private String allowedExtensions;
	private boolean isLinkedToAsset;
	
	
	
	public boolean isLinkedToAsset() {
		return isLinkedToAsset;
	}
	public void setLinkedToAsset(boolean isLinkedToAsset) {
		this.isLinkedToAsset = isLinkedToAsset;
	}
	public Long getAssetRepresentationId() {
		return assetRepresentationId;
	}
	public void setAssetRepresentationId(Long assetRepresentationId) {
		this.assetRepresentationId = assetRepresentationId;
	}
	public Long getAssetId() {
		return assetId;
	}
	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}
	public String getJarName() {
		return jarName;
	}
	public void setJarName(String jarName) {
		this.jarName = jarName;
	}
	public String getJarPath() {
		return jarPath;
	}
	public void setJarPath(String jarPath) {
		this.jarPath = jarPath;
	}
	public String getImplementedClassName() {
		return implementedClassName;
	}
	public void setImplementedClassName(String implementedClassName) {
		this.implementedClassName = implementedClassName;
	}
	public String getAllowedExtensions() {
		return allowedExtensions;
	}
	public void setAllowedExtensions(String allowedExtensions) {
		this.allowedExtensions = allowedExtensions;
	}
	public String getRepresentationName() {
		return representationName;
	}
	public void setRepresentationName(String representationName) {
		this.representationName = representationName;
	}
	
}
