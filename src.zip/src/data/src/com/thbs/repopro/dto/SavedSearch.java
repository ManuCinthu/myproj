package com.thbs.repopro.dto;

public class SavedSearch {
private long searchId;
private String searchName;
private String paramsValue;
private String operatorsValue;
private String param1Value;
private String logicalSelectValue;
private String assetName;
private String param2Value;
private String taxValue;
private int publicValue;
private String userName;
private Long assetId;
private int defaultUserFilterView;

public long getSearchId() {
	return searchId;
}
public void setSearchId(long searchId) {
	this.searchId = searchId;
}
public String getSearchName() {
	return searchName;
}
public void setSearchName(String searchName) {
	this.searchName = searchName;
}
public String getParamsValue() {
	return paramsValue;
}
public void setParamsValue(String paramsValue) {
	this.paramsValue = paramsValue;
}
public String getOperatorsValue() {
	return operatorsValue;
}
public void setOperatorsValue(String operatorsValue) {
	this.operatorsValue = operatorsValue;
}
public String getParam1Value() {
	return param1Value;
}
public void setParam1Value(String param1Value) {
	this.param1Value = param1Value;
}
public String getLogicalSelectValue() {
	return logicalSelectValue;
}
public void setLogicalSelectValue(String logicalSelectValue) {
	this.logicalSelectValue = logicalSelectValue;
}
public String getAssetName() {
	return assetName;
}
public void setAssetName(String assetName) {
	this.assetName = assetName;
}
public String getParam2Value() {
	return param2Value;
}
public void setParam2Value(String param2Value) {
	this.param2Value = param2Value;
}
public String getTaxValue() {
	return taxValue;
}
public void setTaxValue(String taxValue) {
	this.taxValue = taxValue;
}
public int getPublicValue() {
	return publicValue;
}
public void setPublicValue(int publicValue) {
	this.publicValue = publicValue;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public Long getAssetId() {
	return assetId;
}
public void setAssetId(Long assetId) {
	this.assetId = assetId;
}
public int getDefaultUserFilterView() {
	return defaultUserFilterView;
}
public void setDefaultUserFilterView(int defaultUserFilterView) {
	this.defaultUserFilterView = defaultUserFilterView;
}
@Override
public String toString() {
	return "SavedSearch [searchId=" + searchId + ", searchName=" + searchName + ", paramsValue=" + paramsValue
			+ ", operatorsValue=" + operatorsValue + ", param1Value=" + param1Value + ", logicalSelectValue="
			+ logicalSelectValue + ", assetName=" + assetName + ", param2Value=" + param2Value + ", taxValue="
			+ taxValue + ", publicValue=" + publicValue + ", userName=" + userName + ", assetId=" + assetId
			+ ", defaultUserFilterView=" + defaultUserFilterView + "]";
}

}