package com.thbs.repopro.dto;

import java.util.Map;

public class TaggingMaster {

	private Long tagId;
	private Map<Long,String> tagNames;
	private Long userId;
	private String userName;
	private Long assetInstanceVersionId;
	private String assetName;
	private String assetInstName;
	private String assetVersionName;
	
	public Long getTagId() {
		return tagId;
	}
	public void setTagId(Long tagId) {
		this.tagId = tagId;
	}
	public Map<Long, String> getTagNames() {
		return tagNames;
	}
	public void setTagNames(Map<Long, String> tagNames) {
		this.tagNames = tagNames;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getAssetInstanceVersionId() {
		return assetInstanceVersionId;
	}
	public void setAssetInstanceVersionId(Long assetInstanceVersionId) {
		this.assetInstanceVersionId = assetInstanceVersionId;
	}
	
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetInstName() {
		return assetInstName;
	}
	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}
	public String getAssetVersionName() {
		return assetVersionName;
	}
	public void setAssetVersionName(String assetVersionName) {
		this.assetVersionName = assetVersionName;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Override
	public String toString() {
		return "TaggingMaster [tagId=" + tagId + ", tagNames=" + tagNames + ", userId=" + userId + ", userName="
				+ userName + ", assetInstanceVersionId=" + assetInstanceVersionId + ", assetName=" + assetName
				+ ", assetInstName=" + assetInstName + ", assetVersionName=" + assetVersionName + "]";
	}

	
	

}
