package com.thbs.repopro.dto;

public class GroupAssetInstVersionAccess {
	private Long assetInstversionGroupId;
	private Long assetInstversionId;
	private Long groupId;
	private Long editAccess;
	private Long viewAccess;
	private Long deleteAccess;
	private boolean editFlag;
	private boolean deleteFlag;
	private boolean viewFlag;
	private boolean adminFlag;
	private Long adminAccess;
	
	public Long getAssetInstversionGroupId() {
		return assetInstversionGroupId;
	}
	public void setAssetInstversionGroupId(Long assetInstversionGroupId) {
		this.assetInstversionGroupId = assetInstversionGroupId;
	}
	public Long getAssetInstversionId() {
		return assetInstversionId;
	}
	public void setAssetInstversionId(Long assetInstversionId) {
		this.assetInstversionId = assetInstversionId;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public Long getEditAccess() {
		return editAccess;
	}
	public void setEditAccess(Long editAccess) {
		this.editAccess = editAccess;
	}
	public Long getViewAccess() {
		return viewAccess;
	}
	public void setViewAccess(Long viewAccess) {
		this.viewAccess = viewAccess;
	}
	public Long getDeleteAccess() {
		return deleteAccess;
	}
	public void setDeleteAccess(Long deleteAccess) {
		this.deleteAccess = deleteAccess;
	}
	public boolean isEditFlag() {
		return editFlag;
	}
	public void setEditFlag(boolean editFlag) {
		this.editFlag = editFlag;
	}
	public boolean isDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public boolean isViewFlag() {
		return viewFlag;
	}
	public void setViewFlag(boolean viewFlag) {
		this.viewFlag = viewFlag;
	}
	
	public boolean isAdminFlag() {
		return adminFlag;
	}
	public void setAdminFlag(boolean adminFlag) {
		this.adminFlag = adminFlag;
	}
	
	public Long getAdminAccess() {
		return adminAccess;
	}
	public void setAdminAccess(Long adminAccess) {
		this.adminAccess = adminAccess;
	}
	@Override
	public String toString() {
		return "GroupAssetInstVersionAccess [assetInstversionGroupId="
				+ assetInstversionGroupId + ", assetInstversionId="
				+ assetInstversionId + ", groupId=" + groupId + ", editAccess="
				+ editAccess + ", viewAccess=" + viewAccess + ", deleteAccess="
				+ deleteAccess + ", editFlag=" + editFlag + ", deleteFlag="
				+ deleteFlag + ", viewFlag=" + viewFlag + ", adminFlag="
				+ adminFlag + ", adminAccess=" + adminAccess + "]";
	}
	
}
