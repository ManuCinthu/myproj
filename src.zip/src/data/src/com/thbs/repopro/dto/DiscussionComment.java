package com.thbs.repopro.dto;

import java.sql.Timestamp;

public class DiscussionComment {

	private Long commentId;
	private Timestamp commentTimestamp;
	private Long userId;
	private String userName;
	private Long assetInstanceVersionId;
	private String assetName;
	private String assetInstName;
	private String assetVersionName;
	private String description;
	private Long parentCommentId;
	private int encryptImage;

	private String fullName;
	private String imageName;

	public Long getCommentId() {
		return commentId;
	}

	public void setCommentId(Long commentId) {
		this.commentId = commentId;
	}

	public Timestamp getCommentTimestamp() {
		return commentTimestamp;
	}

	public void setCommentTimestamp(Timestamp commentTimestamp) {
		this.commentTimestamp = commentTimestamp;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getAssetInstanceVersionId() {
		return assetInstanceVersionId;
	}

	public void setAssetInstanceVersionId(Long assetInstanceVersionId) {
		this.assetInstanceVersionId = assetInstanceVersionId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getParentCommentId() {
		return parentCommentId;
	}

	public void setParentCommentId(Long parentCommentId) {
		this.parentCommentId = parentCommentId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetInstName() {
		return assetInstName;
	}

	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}

	public String getAssetVersionName() {
		return assetVersionName;
	}

	public void setAssetVersionName(String assetVersionName) {
		this.assetVersionName = assetVersionName;
	}

	public int getEncryptImage() {
		return encryptImage;
	}

	public void setEncryptImage(int encryptImage) {
		this.encryptImage = encryptImage;
	}

	@Override
	public String toString() {
		return "DiscussionComment [commentId=" + commentId + ", commentTimestamp=" + commentTimestamp + ", userId="
				+ userId + ", userName=" + userName + ", assetInstanceVersionId=" + assetInstanceVersionId
				+ ", assetName=" + assetName + ", assetInstName=" + assetInstName + ", assetVersionName="
				+ assetVersionName + ", description=" + description + ", parentCommentId=" + parentCommentId
				+ ", encryptImage=" + encryptImage + ", fullName=" + fullName + ", imageName=" + imageName + "]";
	}

}
