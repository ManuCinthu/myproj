package com.thbs.repopro.dto;

public class AddFavourites {
	
private Long addFavId;
private String favName;
private String url;
private Long userId;
private Long assetInstanceId;
private Long assetInstanceVersionId;
private Long favouriteFlag;
private String assetInstName;
private String assetName;

public Long getAddFavId() {
	return addFavId;
}
public void setAddFavId(Long addFavId) {
	this.addFavId = addFavId;
}
public String getFavName() {
	return favName;
}
public void setFavName(String favName) {
	this.favName = favName;
}
public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public Long getUserId() {
	return userId;
}
public void setUserId(Long userId) {
	this.userId = userId;
}
public Long getAssetInstanceId() {
	return assetInstanceId;
}
public void setAssetInstanceId(Long assetInstanceId) {
	this.assetInstanceId = assetInstanceId;
}
public Long getFavouriteflag() {
	return favouriteFlag;
}
public void setFavouriteflag(Long favouriteflag) {
	favouriteFlag = favouriteflag;
}
public String getAssetInstName() {
	return assetInstName;
}
public void setAssetInstName(String assetInstName) {
	this.assetInstName = assetInstName;
}
public String getAssetName() {
	return assetName;
}
public void setAssetName(String assetName) {
	this.assetName = assetName;
}
public Long getAssetInstanceVersionId() {
	return assetInstanceVersionId;
}
public void setAssetInstanceVersionId(Long assetInstanceVersionId) {
	this.assetInstanceVersionId = assetInstanceVersionId;
}
@Override
public String toString() {
	return "AddFavourites [addFavId=" + addFavId + ", favName=" + favName
			+ ", url=" + url + ", userId=" + userId + ", assetInstanceId="
			+ assetInstanceId + ", assetInstanceVersionId="
			+ assetInstanceVersionId + ", favouriteFlag=" + favouriteFlag
			+ ", assetInstName=" + assetInstName + ", assetName=" + assetName
			+ "]";
}



}
