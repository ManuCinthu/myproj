package com.thbs.repopro.dto;

import java.util.List;

public class AivDetailsComposite {
	private List<AssetInstanceVersion> overview;
	private List<AssetInstanceVersion> properties;
	private List<TaggingMaster> tags;
	private List<AssetInstanceVersionTaxonomy> taxonomy;
	private List<AssetRelationshipDef> relationships;
	private List<String> onloadrelationships;
	private List<AssetInstanceVersion> reverseRelationship;
	private List<AssetInstanceVersion> versionDetails;
	
	
	public List<AssetInstanceVersion> getOverview() {
		return overview;
	}
	public void setOverview(List<AssetInstanceVersion> overview) {
		this.overview = overview;
	}
	public List<AssetInstanceVersion> getProperties() {
		return properties;
	}
	public void setProperties(List<AssetInstanceVersion> properties) {
		this.properties = properties;
	}
	public List<TaggingMaster> getTags() {
		return tags;
	}
	public void setTags(List<TaggingMaster> tags) {
		this.tags = tags;
	}
	public List<AssetInstanceVersionTaxonomy> getTaxonomy() {
		return taxonomy;
	}
	public void setTaxonomy(List<AssetInstanceVersionTaxonomy> taxonomy) {
		this.taxonomy = taxonomy;
	}
	
	public List<AssetRelationshipDef> getRelationships() {
		return relationships;
	}
	public void setRelationships(List<AssetRelationshipDef> relationships) {
		this.relationships = relationships;
	}
	public List<String> getOnloadrelationships() {
		return onloadrelationships;
	}
	public void setOnloadrelationships(List<String> onloadrelationships) {
		this.onloadrelationships = onloadrelationships;
	}
	public List<AssetInstanceVersion> getReverseRelationship() {
		return reverseRelationship;
	}
	public void setReverseRelationship(
			List<AssetInstanceVersion> reverseRelationship) {
		this.reverseRelationship = reverseRelationship;
	}
	public List<AssetInstanceVersion> getVersionDetails() {
		return versionDetails;
	}
	public void setVersionDetails(List<AssetInstanceVersion> versionDetails) {
		this.versionDetails = versionDetails;
	}
	@Override
	public String toString() {
		return "AivDetailsComposite [overview=" + overview + ", properties="
				+ properties + ", tags=" + tags + ", taxonomy=" + taxonomy
				+ ", relationships=" + relationships + ", onloadrelationships="
				+ onloadrelationships + ", reverseRelationship="
				+ reverseRelationship + ", versionDetails=" + versionDetails
				+ "]";
	}

}
