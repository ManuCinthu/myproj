package com.thbs.repopro.dto;

import java.util.Comparator;

public class TaxonomyMaster implements Comparator<TaxonomyMaster>{
	private Long taxonomyId;
	private String taxonomyName;
	private Long parenttaxonomyId;
	private String subscription; 

	public Long getTaxonomyId() {
		return taxonomyId;
	}

	public void setTaxonomyId(Long taxonomyId) {
		this.taxonomyId = taxonomyId;
	}

	public String getTaxonomyName() {
		return taxonomyName;
	}

	public void setTaxonomyName(String taxonomyName) {
		this.taxonomyName = taxonomyName;
	}

	public Long getParenttaxonomyId() {
		return parenttaxonomyId;
	}

	public void setParenttaxonomyId(Long parenttaxonomyId) {
		this.parenttaxonomyId = parenttaxonomyId;
	}


	public String getSubscription() {
		return subscription;
	}

	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	@Override
	public String toString() {
		return "TaxonomyMaster [taxonomyId=" + taxonomyId + ", taxonomyName="
				+ taxonomyName + ", parenttaxonomyId=" + parenttaxonomyId
				+ ", subscription=" + subscription + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime
				* result
				+ ((parenttaxonomyId == null) ? 0 : parenttaxonomyId.hashCode());
		result = prime * result
				+ ((subscription == null) ? 0 : subscription.hashCode());
		result = prime * result
				+ ((taxonomyId == null) ? 0 : taxonomyId.hashCode());
		result = prime * result
				+ ((taxonomyName == null) ? 0 : taxonomyName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TaxonomyMaster other = (TaxonomyMaster) obj;
		if (parenttaxonomyId == null) {
			if (other.parenttaxonomyId != null)
				return false;
		} else if (!parenttaxonomyId.equals(other.parenttaxonomyId))
			return false;
		if (subscription == null) {
			if (other.subscription != null)
				return false;
		} else if (!subscription.equals(other.subscription))
			return false;
		if (taxonomyId == null) {
			if (other.taxonomyId != null)
				return false;
		} else if (!taxonomyId.equals(other.taxonomyId))
			return false;
		if (taxonomyName == null) {
			if (other.taxonomyName != null)
				return false;
		} else if (!taxonomyName.equals(other.taxonomyName))
			return false;
		return true;
	}

	@Override
	public int compare(TaxonomyMaster o1, TaxonomyMaster o2) {
		return o1.getTaxonomyId().compareTo(o2.getTaxonomyId());
	}
	

	

}
