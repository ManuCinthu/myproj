package com.thbs.repopro.dto;

import java.sql.Timestamp;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="assetInstance")

@XmlAccessorType(XmlAccessType.FIELD)
public class AssetInstance implements Comparator<AssetInstance> {
	private Long assetInstId;
	private Long assetId;
	private String assetInstName;
	private Integer rating;
	private int displayPosition;
	private boolean publicAccess;
	private String owner;
	private String assetName;
	private String assetInstanceDescription;
	private Long assetInstVersionId;
	private String versionName;
	private boolean versionable;
	private String assetRelationshipId;
	private String assetRelationshipName;
	private String assetRelationshipType;
	private String description;
	private String name;
	private String tagName;
	private String value;
	private String taxonomyName;
	private HashMap<String, String> assetInstanceMap;
	private Map<String, String> paramNameWithValues;
	private int showHideParamCount;
	private String newDescription;
	private String parentAssetInstName;
	private String parentAssetName;
	private String parentVersionName;
	private Long parentAssetInstVersionId;
	private Long parentAssetId;
	private String paramRevData;
	private String iconImageName;
	private Boolean editAccessFlag;
	private Boolean deleteAccessFlag;
	private Boolean addAccessFlag;
	private Boolean propertiesFlag;
	private Long assetParamId;
	private List<Category> categoryDetails;	
	private List<String> RTFwithTags;
	private List<String> RTFwithOutTags;
	private List<String> textDataList;
	private int rtfCount;
	private int textCount;
	private Long paramTypeId;
	private int hasArray;
	private int ldapMappingCount;
	private int resultTotalCount;
	private Map<String, Integer> ldapMappingValues;
	private Timestamp createdOn;
	private boolean deleteInstanceFlag;
	
	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public int getResultTotalCount() {
		return resultTotalCount;
	}

	public void setResultTotalCount(int resultTotalCount) {
		this.resultTotalCount = resultTotalCount;
	}

	public Map<String, Integer> getLdapMappingValues() {
		return ldapMappingValues;
	}

	public void setLdapMappingValues(Map<String, Integer> ldapMappingValues) {
		this.ldapMappingValues = ldapMappingValues;
	}

	public int getLdapMappingCount() {
		return ldapMappingCount;
	}

	public void setLdapMappingCount(int ldapMappingCount) {
		this.ldapMappingCount = ldapMappingCount;
	}

	public int getHasArray() {
		return hasArray;
	}

	public void setHasArray(int hasArray) {
		this.hasArray = hasArray;
	}

	public Long getParamTypeId() {
		return paramTypeId;
	}

	public void setParamTypeId(Long paramTypeId) {
		this.paramTypeId = paramTypeId;
	}

	public List<String> getRTFwithTags() {
		return RTFwithTags;
	}

	public void setRTFwithTags(List<String> rTFwithTags) {
		RTFwithTags = rTFwithTags;
	}

	public List<String> getRTFwithOutTags() {
		return RTFwithOutTags;
	}

	public void setRTFwithOutTags(List<String> rTFwithOutTags) {
		RTFwithOutTags = rTFwithOutTags;
	}

	public List<String> getTextDataList() {
		return textDataList;
	}

	public void setTextDataList(List<String> textDataList) {
		this.textDataList = textDataList;
	}

	public int getRtfCount() {
		return rtfCount;
	}

	public void setRtfCount(int rtfCount) {
		this.rtfCount = rtfCount;
	}

	public int getTextCount() {
		return textCount;
	}

	public void setTextCount(int textCount) {
		this.textCount = textCount;
	}

	@XmlElementWrapper(name="assetInstances")
	@XmlElement(name="assetInstance",nillable=true,required=false)
	private List<AssetInstance> assetInstance;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public Map<String, String> getParamNameWithValues() {
		return paramNameWithValues;
	}

	public void setParamNameWithValues(Map<String, String> paramNameWithValues) {
		this.paramNameWithValues = paramNameWithValues;
	}

	public Long getAssetInstId() {
		return assetInstId;
	}

	public void setAssetInstId(Long assetInstId) {
		this.assetInstId = assetInstId;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getAssetInstName() {
		return assetInstName;
	}

	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public int getDisplayPosition() {
		return displayPosition;
	}

	public void setDisplayPosition(int displayPosition) {
		this.displayPosition = displayPosition;
	}

	public boolean isPublicAccess() {
		return publicAccess;
	}

	public void setPublicAccess(boolean publicAccess) {
		this.publicAccess = publicAccess;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetInstanceDescription() {
		return assetInstanceDescription;
	}

	public void setAssetInstanceDescription(String assetInstanceDescription) {
		this.assetInstanceDescription = assetInstanceDescription;
	}

	public Long getAssetInstVersionId() {
		return assetInstVersionId;
	}

	public void setAssetInstVersionId(Long assetInstVersionId) {
		this.assetInstVersionId = assetInstVersionId;
	}

	public String getVersionName() {
		return versionName;
	}

	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}

	public HashMap<String, String> getAssetInstanceMap() {
		return assetInstanceMap;
	}

	public void setAssetInstanceMap(HashMap<String, String> assetInstanceMap) {
		this.assetInstanceMap = assetInstanceMap;
	}

	public String getAssetRelationshipId() {
		return assetRelationshipId;
	}

	public void setAssetRelationshipId(String assetRelationshipId) {
		this.assetRelationshipId = assetRelationshipId;
	}

	public String getAssetRelationshipName() {
		return assetRelationshipName;
	}

	public void setAssetRelationshipName(String assetRelationshipName) {
		this.assetRelationshipName = assetRelationshipName;
	}

	public String getAssetRelationshipType() {
		return assetRelationshipType;
	}

	public void setAssetRelationshipType(String assetRelationshipType) {
		this.assetRelationshipType = assetRelationshipType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isVersionable() {
		return versionable;
	}

	public void setVersionable(boolean versionable) {
		this.versionable = versionable;
	}

	public String getTaxonomyName() {
		return taxonomyName;
	}

	public void setTaxonomyName(String taxonomyName) {
		this.taxonomyName = taxonomyName;
	}

	public int getShowHideParamCount() {
		return showHideParamCount;
	}

	public void setShowHideParamCount(int showHideParamCount) {
		this.showHideParamCount = showHideParamCount;
	}

	public String getNewDescription() {
		return newDescription;
	}

	public void setNewDescription(String newDescription) {
		this.newDescription = newDescription;
	}

	public String getParentAssetInstName() {
		return parentAssetInstName;
	}

	public void setParentAssetInstName(String parentAssetInstName) {
		this.parentAssetInstName = parentAssetInstName;
	}

	public String getParentAssetName() {
		return parentAssetName;
	}

	public void setParentAssetName(String parentAssetName) {
		this.parentAssetName = parentAssetName;
	}

	public String getParentVersionName() {
		return parentVersionName;
	}

	public void setParentVersionName(String parentVersionName) {
		this.parentVersionName = parentVersionName;
	}

	public Long getParentAssetInstVersionId() {
		return parentAssetInstVersionId;
	}

	public void setParentAssetInstVersionId(Long parentAssetInstVersionId) {
		this.parentAssetInstVersionId = parentAssetInstVersionId;
	}

	public Long getParentAssetId() {
		return parentAssetId;
	}

	public void setParentAssetId(Long parentAssetId) {
		this.parentAssetId = parentAssetId;
	}

	public String getIconImageName() {
		return iconImageName;
	}

	public void setIconImageName(String iconImageName) {
		this.iconImageName = iconImageName;
	}

	public Boolean getEditAccessFlag() {
		return editAccessFlag;
	}

	public void setEditAccessFlag(Boolean editAccessFlag) {
		this.editAccessFlag = editAccessFlag;
	}

	public Boolean getDeleteAccessFlag() {
		return deleteAccessFlag;
	}

	public void setDeleteAccessFlag(Boolean deleteAccessFlag) {
		this.deleteAccessFlag = deleteAccessFlag;
	}

	public Boolean getAddAccessFlag() {
		return addAccessFlag;
	}

	public void setAddAccessFlag(Boolean addAccessFlag) {
		this.addAccessFlag = addAccessFlag;
	}

	public String getParamRevData() {
		return paramRevData;
	}

	public void setParamRevData(String paramRevData) {
		this.paramRevData = paramRevData;
	}

	public Boolean getPropertiesFlag() {
		return propertiesFlag;
	}

	public void setPropertiesFlag(Boolean propertiesFlag) {
		this.propertiesFlag = propertiesFlag;
	}

	public List<AssetInstance> getAssetInstance() {
		return assetInstance;
	}

	public void setAssetInstance(List<AssetInstance> assetInstance) {
		this.assetInstance = assetInstance;
	}

	public Long getAssetParamId() {
		return assetParamId;
	}

	public void setAssetParamId(Long assetParamId) {
		this.assetParamId = assetParamId;
	}

	public List<Category> getCategoryDetails() {
		return categoryDetails;
	}

	public void setCategoryDetails(List<Category> categoryDetails) {
		this.categoryDetails = categoryDetails;
	}

	public boolean isDeleteInstanceFlag() {
		return deleteInstanceFlag;
	}

	public void setDeleteInstanceFlag(boolean deleteInstanceFlag) {
		this.deleteInstanceFlag = deleteInstanceFlag;
	}

	@Override
	public String toString() {
		return "AssetInstance [assetInstId=" + assetInstId + ", assetId=" + assetId + ", assetInstName=" + assetInstName
				+ ", rating=" + rating + ", displayPosition=" + displayPosition + ", publicAccess=" + publicAccess
				+ ", owner=" + owner + ", assetName=" + assetName + ", assetInstanceDescription="
				+ assetInstanceDescription + ", assetInstVersionId=" + assetInstVersionId + ", versionName="
				+ versionName + ", versionable=" + versionable + ", assetRelationshipId=" + assetRelationshipId
				+ ", assetRelationshipName=" + assetRelationshipName + ", assetRelationshipType="
				+ assetRelationshipType + ", description=" + description + ", name=" + name + ", tagName=" + tagName
				+ ", value=" + value + ", taxonomyName=" + taxonomyName + ", assetInstanceMap=" + assetInstanceMap
				+ ", paramNameWithValues=" + paramNameWithValues + ", showHideParamCount=" + showHideParamCount
				+ ", newDescription=" + newDescription + ", parentAssetInstName=" + parentAssetInstName
				+ ", parentAssetName=" + parentAssetName + ", parentVersionName=" + parentVersionName
				+ ", parentAssetInstVersionId=" + parentAssetInstVersionId + ", parentAssetId=" + parentAssetId
				+ ", paramRevData=" + paramRevData + ", iconImageName=" + iconImageName + ", editAccessFlag="
				+ editAccessFlag + ", deleteAccessFlag=" + deleteAccessFlag + ", addAccessFlag=" + addAccessFlag
				+ ", propertiesFlag=" + propertiesFlag + ", assetParamId=" + assetParamId + ", categoryDetails="
				+ categoryDetails + ", RTFwithTags=" + RTFwithTags + ", RTFwithOutTags=" + RTFwithOutTags
				+ ", textDataList=" + textDataList + ", rtfCount=" + rtfCount + ", textCount=" + textCount
				+ ", paramTypeId=" + paramTypeId + ", hasArray=" + hasArray + ", ldapMappingCount=" + ldapMappingCount
				+ ", resultTotalCount=" + resultTotalCount + ", ldapMappingValues=" + ldapMappingValues + ", createdOn="
				+ createdOn + ", deleteInstanceFlag=" + deleteInstanceFlag + ", assetInstance=" + assetInstance + "]";
	}

	@Override
	/*public int compare(AssetInstance o1, AssetInstance o2) {
		if(o1.getAssetInstName().equals(o2.getAssetInstName())){
			Long o1Version = Long.parseLong(o1.getVersionName().split("v")[1]);
			Long o2Version = Long.parseLong(o2.getVersionName().split("v")[1]);
			Double v1 = Double.parseDouble(o1.getVersionName());
			Double v2 = Double.parseDouble(o2.getVersionName());
			return v1.compareTo(v2);
		}else{
			return o1.getAssetInstName().compareTo(o2.getAssetInstName());
		}
		return ((Integer)(o1.getAssetInstName().toLowerCase().compareTo(o2.getAssetInstName().toLowerCase()))).compareTo((Integer)(o1.getVersionName().compareTo(o2.getVersionName())));
	}*/
	public int compare(AssetInstance o1, AssetInstance o2) {
		return o1.getAssetInstName().toLowerCase()
				.compareTo(o2.getAssetInstName().toLowerCase());
	}
}
