package com.thbs.repopro.dto;

public class AdminAccessName {
	private String userName;

	private String groupName;

	private String roleName;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	@Override
	public String toString() {
		return "AdminAccessName [userName=" + userName + ", groupName="
				+ groupName + ", roleName=" + roleName + "]";
	}
	
}
