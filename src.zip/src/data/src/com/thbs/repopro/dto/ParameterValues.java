package com.thbs.repopro.dto;

import java.io.InputStream;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ParameterValues {
	
	private Long parameterValuesId;
	
	private String value;
	private String RTFText;
	private String RTFPlainText;
	private Long assetInstParamId;
	private long src_asset_instance_version_id;
	private long dest_asset_instance_version_id;
	private String assetParamName;
	private InputStream image;
	private Long assetParamId;
	private Long modifyByUserId;
	private Timestamp lastUpdatedTime;
	private List<String> RTFwithTags;
	private List<String> RTFwithOutTags;
	private List<String> textDataList;
	private long paramTypeId; 
    private int hasArray;
    private List<String> ldapMappingList;
    private int ldapAttributeId;
    private Map<String,Integer> ldapMappingMap;
    
	public Map<String, Integer> getLdapMappingMap() {
		return ldapMappingMap;
	}

	public void setLdapMappingMap(Map<String, Integer> ldapMappingMap) {
		this.ldapMappingMap = ldapMappingMap;
	}

	public int getLdapAttributeId() {
		return ldapAttributeId;
	}

	public void setLdapAttributeId(int ldapAttributeId) {
		this.ldapAttributeId = ldapAttributeId;
	}

	public List<String> getLdapMappingList() {
		return ldapMappingList;
	}

	public void setLdapMappingList(List<String> ldapMappingList) {
		this.ldapMappingList = ldapMappingList;
	}

	public int getHasArray() {
		return hasArray;
	}

	public void setHasArray(int hasArray) {
		this.hasArray = hasArray;
	}

	public List<String> getTextDataList() {
		return textDataList;
	}

	public void setTextDataList(List<String> textDataList) {
		this.textDataList = textDataList;
	}

	public long getParamTypeId() {
		return paramTypeId;
	}

	public void setParamTypeId(long paramTypeId) {
		this.paramTypeId = paramTypeId;
	}

	public List<String> getRTFwithTags() {
		return RTFwithTags;
	}

	public void setRTFwithTags(List<String> rTFwithTags) {
		RTFwithTags = rTFwithTags;
	}

	public List<String> getRTFwithOutTags() {
		return RTFwithOutTags;
	}

	public void setRTFwithOutTags(List<String> rTFwithOutTags) {
		RTFwithOutTags = rTFwithOutTags;
	}

	public String getRTFText() {
		return RTFText;
	}

	public void setRTFText(String rTFText) {
		RTFText = rTFText;
	}

	public String getRTFPlainText() {
		return RTFPlainText;
	}

	public void setRTFPlainText(String rTFPlainText) {
		RTFPlainText = rTFPlainText;
	}
	private  boolean isImportant;
	private boolean isMandatory;
	public String getAssetParamName() {
		return assetParamName;
	}

	public void setAssetParamName(String assetParamName) {
		this.assetParamName = assetParamName;
	}

	public void setAssetInstParamId(Long assetInstParamId) {
		this.assetInstParamId = assetInstParamId;
	}
	private byte[] fileContent;
	
	private String fileName;
	
	public long getSrc_asset_instance_version_id() {
		return src_asset_instance_version_id;
	}

	public boolean isImportant() {
		return isImportant;
	}

	public void setImportant(boolean isImportant) {
		this.isImportant = isImportant;
	}

	public Long getAssetInstParamId() {
		return assetInstParamId;
	}

	public void setSrc_asset_instance_version_id(long src_asset_instance_version_id) {
		this.src_asset_instance_version_id = src_asset_instance_version_id;
	}

	public long getDest_asset_instance_version_id() {
		return dest_asset_instance_version_id;
	}

	public void setDest_asset_instance_version_id(
			long dest_asset_instance_version_id) {
		this.dest_asset_instance_version_id = dest_asset_instance_version_id;
	}
	private String mimeType;

	public String getFileName() {
		return fileName==null?fileName:fileName.trim();
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getFileContent() {
		return fileContent;
	}

	public void setFileContent(byte[] fileContent) {
		this.fileContent = fileContent;
	}

	public Long getParameterValuesId() {
		return parameterValuesId;
	}

	public void setParameterValuesId(Long parameterValuesId) {
		this.parameterValuesId = parameterValuesId;
	}
	
	

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	
	

	public InputStream getImage() {
		return image;
	}

	public void setImage(InputStream image) {
		this.image = image;
	}

	public Long getAssetParamId() {
		return assetParamId;
	}

	public void setAssetParamId(Long assetParamId) {
		this.assetParamId = assetParamId;
	}

	public Long getModifyByUserId() {
		return modifyByUserId;
	}

	public void setModifyByUserId(Long modifyByUserId) {
		this.modifyByUserId = modifyByUserId;
	}

	public Timestamp getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(Timestamp lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public boolean isMandatory() {
		return isMandatory;
	}

	public void setMandatory(boolean isMandatory) {
		this.isMandatory = isMandatory;
	}

	@Override
	public String toString() {
		return "ParameterValues [parameterValuesId=" + parameterValuesId + ", value=" + value + ", RTFText=" + RTFText
				+ ", RTFPlainText=" + RTFPlainText + ", assetInstParamId=" + assetInstParamId
				+ ", src_asset_instance_version_id=" + src_asset_instance_version_id
				+ ", dest_asset_instance_version_id=" + dest_asset_instance_version_id + ", assetParamName="
				+ assetParamName + ", image=" + image + ", assetParamId=" + assetParamId + ", modifyByUserId="
				+ modifyByUserId + ", lastUpdatedTime=" + lastUpdatedTime + ", RTFwithTags=" + RTFwithTags
				+ ", RTFwithOutTags=" + RTFwithOutTags + ", textDataList=" + textDataList + ", paramTypeId="
				+ paramTypeId + ", hasArray=" + hasArray + ", ldapMappingList=" + ldapMappingList + ", ldapAttributeId="
				+ ldapAttributeId + ", ldapMappingMap=" + ldapMappingMap + ", isImportant=" + isImportant
				+ ", isMandatory=" + isMandatory + ", fileContent=" + Arrays.toString(fileContent) + ", fileName="
				+ fileName + ", mimeType=" + mimeType + "]";
	}
	
	
}
