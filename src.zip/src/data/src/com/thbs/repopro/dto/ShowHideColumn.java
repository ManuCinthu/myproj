package com.thbs.repopro.dto;


import java.util.Comparator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedMap;

public class ShowHideColumn {

	private Long userId;
	private Long assetId;
	Boolean adminFalg;
	private Map<Long, String> showParamDetails;
	private Map<Long, String> showGroupDetails;
	private Map<Long, String> showAivDetails;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public Map<Long, String> getShowParamDetails() {
		return showParamDetails;
	}

	public void setShowParamDetails(Map<Long, String> showParamDetails) {
		this.showParamDetails = showParamDetails;
	}

	public Map<Long, String> getShowGroupDetails() {
		return showGroupDetails;
	}

	public void setShowGroupDetails(Map<Long, String> showGroupDetails) {
		this.showGroupDetails = showGroupDetails;
	}

	public Map<Long, String> getShowAivDetails() {
		return showAivDetails;
	}

	public void setShowAivDetails(Map<Long, String> showAivDetails) {
		this.showAivDetails = showAivDetails;
	}

	public Boolean getAdminFalg() {
		return adminFalg;
	}

	public void setAdminFalg(Boolean adminFalg) {
		this.adminFalg = adminFalg;
	}

	@Override
	public String toString() {
		return "ShowHideColumn [userId=" + userId + ", assetId=" + assetId
				+ ", adminFalg=" + adminFalg + ", showParamDetails="
				+ showParamDetails + ", showGroupDetails=" + showGroupDetails
				+ ", showAivDetails=" + showAivDetails + "]";
	}

	public static Map<java.lang.Long, java.lang.String> entriesSortedByValues(
			SortedMap<java.lang.Long, java.lang.String> paramValues) {
		// TODO Auto-generated method stub
		return null;
	}

}