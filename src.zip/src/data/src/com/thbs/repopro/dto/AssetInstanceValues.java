package com.thbs.repopro.dto;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="assetInstanceVoes")
@XmlAccessorType(XmlAccessType.FIELD)
public class AssetInstanceValues {

	@XmlElementWrapper(name="assetInstanceData")
	@XmlElement(name="assetInstanceData")
	/*private List<AssetInstance> assetInstance;

	public List<AssetInstance> getAssetInstance() {
		return assetInstance;
	}

	public void setAssetInstance(List<AssetInstance> assetInstance) {
		this.assetInstance = assetInstance;
	}*/
	private List<AssetInstanceData> assetInstanceData;

	public List<AssetInstanceData> getAssetInstanceData() {
		return assetInstanceData;
	}

	public void setAssetInstanceData(List<AssetInstanceData> assetInstanceData) {
		this.assetInstanceData = assetInstanceData;
	}
	
}