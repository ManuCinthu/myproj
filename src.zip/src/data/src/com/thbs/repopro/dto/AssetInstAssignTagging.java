package com.thbs.repopro.dto;

import java.util.List;

public class AssetInstAssignTagging {
	
	private String assetName;
	private String assetInstanceName;
	private String assetInstanceVersionId;
	private String versionName;
	private List<String> tagsFromXls;
	
	
	
	
	/**
	 * @return the assetInstanceVersionId
	 */
	public String getAssetInstanceVersionId() {
		return assetInstanceVersionId;
	}
	/**
	 * @param assetInstanceVersionId the assetInstanceVersionId to set
	 */
	public void setAssetInstanceVersionId(String assetInstanceVersionId) {
		this.assetInstanceVersionId = assetInstanceVersionId;
	}
	/**
	 * @return the assetName
	 */
	public String getAssetName() {
		return assetName;
	}
	/**
	 * @param assetName the assetName to set
	 */
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	/**
	 * @return the assetInstanceName
	 */
	public String getAssetInstanceName() {
		return assetInstanceName;
	}
	/**
	 * @param assetInstanceName the assetInstanceName to set
	 */
	public void setAssetInstanceName(String assetInstanceName) {
		this.assetInstanceName = assetInstanceName;
	}
	/**
	 * @return the versionName
	 */
	public String getVersionName() {
		return versionName;
	}
	/**
	 * @param versionName the versionName to set
	 */
	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}
	/**
	 * @return the tagsFromXls
	 */
	public List<String> getTagsFromXls() {
		return tagsFromXls;
	}
	/**
	 * @param tagsFromXls the tagsFromXls to set
	 */
	public void setTagsFromXls(List<String> tagsFromXls) {
		this.tagsFromXls = tagsFromXls;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AssetInstAssignTagging [assetName=" + assetName + ", assetInstanceName=" + assetInstanceName
				+ ", assetInstanceVersionId=" + assetInstanceVersionId + ", versionName=" + versionName
				+ ", tagsFromXls=" + tagsFromXls + "]";
	}
	
	

}
