package com.thbs.repopro.dto;

public class LockTime {

	private Long lockTimeId;
	private String lockTime;

	public Long getLockTimeId() {
		return lockTimeId;
	}

	public void setLockTimeId(Long lockTimeId) {
		this.lockTimeId = lockTimeId;
	}

	public String getLockTime() {
		return lockTime;
	}

	public void setLockTime(String lockTime) {
		this.lockTime = lockTime;
	}

	@Override
	public String toString() {
		return "LockTime [lockTimeId=" + lockTimeId + ", lockTime=" + lockTime
				+ "]";
	}

}
