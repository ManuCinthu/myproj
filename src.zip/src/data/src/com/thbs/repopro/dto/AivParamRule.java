package com.thbs.repopro.dto;

public class AivParamRule {
	private int paramRuleId;
	private String paramRuleValue;
	private String paramRuleName;
	private String paramRuleOperatorValue;
	private String paramRuleParam1Value;
	private String paramRulelogicalOperators;
	private String assetName;
	private String userName;
	private int aivId;
	private int assetId;
	private String scheduler;
	private String paramName;
	private String actionForRuleSet;
	
	public int getParamRuleId() {
		return paramRuleId;
	}
	public void setParamRuleId(int paramRuleId) {
		this.paramRuleId = paramRuleId;
	}
	
	public String getParamRuleName() {
		return paramRuleName;
	}
	public void setParamRuleName(String paramRuleName) {
		this.paramRuleName = paramRuleName;
	}
	public String getParamRuleValue() {
		return paramRuleValue;
	}
	public void setParamRuleValue(String paramRuleValue) {
		this.paramRuleValue = paramRuleValue;
	}
	public String getParamRuleOperatorValue() {
		return paramRuleOperatorValue;
	}
	public void setParamRuleOperatorValue(String paramRuleOperatorValue) {
		this.paramRuleOperatorValue = paramRuleOperatorValue;
	}
	public String getParamRuleParam1Value() {
		return paramRuleParam1Value;
	}
	public void setParamRuleParam1Value(String paramRuleParam1Value) {
		this.paramRuleParam1Value = paramRuleParam1Value;
	}
	public String getParamRulelogicalOperators() {
		return paramRulelogicalOperators;
	}
	public void setParamRulelogicalOperators(String paramRulelogicalOperators) {
		this.paramRulelogicalOperators = paramRulelogicalOperators;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getAivId() {
		return aivId;
	}
	public void setAivId(int aivId) {
		this.aivId = aivId;
	}
	public String getScheduler() {
		return scheduler;
	}
	public void setScheduler(String scheduler) {
		this.scheduler = scheduler;
	}
	
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	
	public String getActionForRuleSet() {
		return actionForRuleSet;
	}
	public void setActionForRuleSet(String actionForRuleSet) {
		this.actionForRuleSet = actionForRuleSet;
	}
	
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	@Override
	public String toString() {
		return "AivParamRule [paramRuleId=" + paramRuleId + ", paramRuleValue=" + paramRuleValue + ", paramRuleName="
				+ paramRuleName + ", paramRuleOperatorValue=" + paramRuleOperatorValue + ", paramRuleParam1Value="
				+ paramRuleParam1Value + ", paramRulelogicalOperators=" + paramRulelogicalOperators + ", assetName="
				+ assetName + ", userName=" + userName + ", aivId=" + aivId + ", assetId=" + assetId + ", scheduler="
				+ scheduler + ", paramName=" + paramName + ", actionForRuleSet=" + actionForRuleSet + "]";
	}
	
}
