package com.thbs.repopro.dto;


import java.sql.Timestamp;

public class HelpContents {
	
	private int id ;
	private Timestamp created_On;
	private String created_By;
	private String help_Content;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Timestamp getCreated_On() {
		return created_On;
	}
	public void setCreated_On(Timestamp created_On) {
		this.created_On = created_On;
	}
	public String getCreated_By() {
		return created_By;
	}
	public void setCreated_By(String created_By) {
		this.created_By = created_By;
	}
	public String getHelp_Content() {
		return help_Content;
	}
	public void setHelp_Content(String help_Content) {
		this.help_Content = help_Content;
	}
	@Override
	public String toString() {
		return "HelpContents [id=" + id + ", created_On=" + created_On
				+ ", created_By=" + created_By + ", help_Content="
				+ help_Content + "]";
	}
	
	
	
	
	
	
	
	

}
