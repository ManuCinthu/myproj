package com.thbs.repopro.dto;

public class UserGroups {

	private Long userGroupsId;
	private Long userId;
	private Long groupId;

	public Long getUserGroupsId() {
		return userGroupsId;
	}

	public void setUserGroupsId(Long userGroupsId) {
		this.userGroupsId = userGroupsId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	@Override
	public String toString() {
		return "UserGroups [userGroupsId=" + userGroupsId + ", userId="
				+ userId + ", groupId=" + groupId + "]";
	}

}
