package com.thbs.repopro.dto;

import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class NameValue {

	private String name;
	
	private String value;
	
	private byte[] byteValue;
	private String RTFPlainText;
	private List<String> RTFwithTags;
	private List<String> RTFwithOutTags;
	private List<String> textDataList;
	private List<String> ldapMappingList;
	private Map<String,Integer> ldapMappingMap;
	private String fileName;
	private InputStream image;
	
	private String fileMimeType;

	
	public String getRTFPlainText() {
		return RTFPlainText;
	}

	public void setRTFPlainText(String rTFPlainText) {
		RTFPlainText = rTFPlainText;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public byte[] getByteValue() {
		return byteValue;
	}

	public void setByteValue(byte[] byteValue) {
		this.byteValue = byteValue;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileMimeType() {
		return fileMimeType;
	}

	public void setFileMimeType(String fileMimeType) {
		this.fileMimeType = fileMimeType;
	}

	
	
	public List<String> getTextDataList() {
		return textDataList;
	}

	public void setTextDataList(List<String> textDataList) {
		this.textDataList = textDataList;
	}

	public List<String> getRTFwithTags() {
		return RTFwithTags;
	}

	public void setRTFwithTags(List<String> rTFwithTags) {
		RTFwithTags = rTFwithTags;
	}

	public List<String> getRTFwithOutTags() {
		return RTFwithOutTags;
	}

	public void setRTFwithOutTags(List<String> rTFwithOutTags) {
		RTFwithOutTags = rTFwithOutTags;
	}

	public InputStream getImage() {
		return image;
	}

	public void setImage(InputStream image) {
		this.image = image;
	}

	public List<String> getLdapMappingList() {
		return ldapMappingList;
	}

	public void setLdapMappingList(List<String> ldapMappingList) {
		this.ldapMappingList = ldapMappingList;
	}

	public Map<String, Integer> getLdapMappingMap() {
		return ldapMappingMap;
	}

	public void setLdapMappingMap(Map<String, Integer> ldapMappingMap) {
		this.ldapMappingMap = ldapMappingMap;
	}

	@Override
	public String toString() {
		return "NameValue [name=" + name + ", value=" + value + ", byteValue=" + Arrays.toString(byteValue)
				+ ", RTFPlainText=" + RTFPlainText + ", RTFwithTags=" + RTFwithTags + ", RTFwithOutTags="
				+ RTFwithOutTags + ", textDataList=" + textDataList + ", ldapMappingList=" + ldapMappingList
				+ ", ldapMappingMap=" + ldapMappingMap + ", fileName=" + fileName + ", image=" + image
				+ ", fileMimeType=" + fileMimeType + "]";
	}	
	
	
	
	
	
}
