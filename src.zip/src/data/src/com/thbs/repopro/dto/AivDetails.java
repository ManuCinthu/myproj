package com.thbs.repopro.dto;

import java.util.List;

public class AivDetails {

	private AssetInstanceVersion overview;
	private List<AssetInstanceVersion> properties;
	private TaggingMaster tags;
	private List<AssetInstanceVersionTaxonomy> taxonomy;
	private List<AssetInstRelationship> relationships;

	public AssetInstanceVersion getOverview() {
		return overview;
	}

	public void setOverview(AssetInstanceVersion overview) {
		this.overview = overview;
	}

	public List<AssetInstanceVersion> getProperties() {
		return properties;
	}

	public void setProperties(List<AssetInstanceVersion> properties) {
		this.properties = properties;
	}

	public TaggingMaster getTags() {
		return tags;
	}

	public void setTags(TaggingMaster tags) {
		this.tags = tags;
	}

	public List<AssetInstanceVersionTaxonomy> getTaxonomy() {
		return taxonomy;
	}

	public void setTaxonomy(List<AssetInstanceVersionTaxonomy> taxonomy) {
		this.taxonomy = taxonomy;
	}

	public List<AssetInstRelationship> getRelationships() {
		return relationships;
	}

	public void setRelationships(List<AssetInstRelationship> relationships) {
		this.relationships = relationships;
	}

	@Override
	public String toString() {
		return "AivDetails [overview=" + overview + ", properties="
				+ properties + ", tags=" + tags + ", taxonomy=" + taxonomy
				+ ", relationships=" + relationships + "]";
	}

}
