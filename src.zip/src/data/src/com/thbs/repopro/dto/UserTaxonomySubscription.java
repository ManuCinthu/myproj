package com.thbs.repopro.dto;

public class UserTaxonomySubscription {

	private Long userTaxonomySubscriptionId;
	private Long userId;
	private Long taxonomyId;

	public Long getUserTaxonomySubscriptionId() {
		return userTaxonomySubscriptionId;
	}

	public void setUserTaxonomySubscriptionId(Long userTaxonomySubscriptionId) {
		this.userTaxonomySubscriptionId = userTaxonomySubscriptionId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getTaxonomyId() {
		return taxonomyId;
	}

	public void setTaxonomyId(Long taxonomyId) {
		this.taxonomyId = taxonomyId;
	}

	@Override
	public String toString() {
		return "UserTaxonomySubscription [userTaxonomySubscriptionId="
				+ userTaxonomySubscriptionId + ", userId=" + userId
				+ ", taxonomyId=" + taxonomyId + "]";
	}
}
