package com.thbs.repopro.dto;

import java.util.HashMap;
import java.util.Set;

public class SearchResponse {

	private HashMap<String, Object> response;
	private Set<Object> searchResponse;

	private int totalCount;

	private int profileCount;
	private int assetCount;
	private int assetInstanceCount;
	private int parameterCount;
	private int taxonomyCount;
	private int taggingCount;

	public HashMap<String, Object> getResponse() {
		return response;
	}

	public void setResponse(HashMap<String, Object> response) {
		this.response = response;
	}

	public Set<Object> getSearchResponse() {
		return searchResponse;
	}

	public void setSearchResponse(Set<Object> searchResponse) {
		this.searchResponse = searchResponse;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getProfileCount() {
		return profileCount;
	}

	public void setProfileCount(int profileCount) {
		this.profileCount = profileCount;
	}

	public int getAssetCount() {
		return assetCount;
	}

	public void setAssetCount(int assetCount) {
		this.assetCount = assetCount;
	}

	public int getAssetInstanceCount() {
		return assetInstanceCount;
	}

	public void setAssetInstanceCount(int assetInstanceCount) {
		this.assetInstanceCount = assetInstanceCount;
	}

	public int getParameterCount() {
		return parameterCount;
	}

	public void setParameterCount(int parameterCount) {
		this.parameterCount = parameterCount;
	}

	public int getTaxonomyCount() {
		return taxonomyCount;
	}

	public void setTaxonomyCount(int taxonomyCount) {
		this.taxonomyCount = taxonomyCount;
	}

	public int getTaggingCount() {
		return taggingCount;
	}

	public void setTaggingCount(int taggingCount) {
		this.taggingCount = taggingCount;
	}

	@Override
	public String toString() {
		return "SearchResponse [response=" + response + ", searchResponse="
				+ searchResponse + ", totalCount=" + totalCount
				+ ", profileCount=" + profileCount + ", assetCount="
				+ assetCount + ", assetInstanceCount=" + assetInstanceCount
				+ ", parameterCount=" + parameterCount + ", taxonomyCount="
				+ taxonomyCount + ", taggingCount=" + taggingCount + "]";
	}

}
