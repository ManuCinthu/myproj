package com.thbs.repopro.dto;

import java.util.List;

public class FilterData {
	private List<String> taxonomyValueList;
	private List<ParameterData> parameterData;
	private String assetInstanceVersionDescription;
	private String assetInstanceName;
	private String assetInstanceVersionId;
	
	public List<String> getTaxonomyValueList() {
		return taxonomyValueList;
	}
	public void setTaxonomyValueList(List<String> taxonomyValueList) {
		this.taxonomyValueList = taxonomyValueList;
	}
	public List<ParameterData> getParameterData() {
		return parameterData;
	}
	public void setParameterData(List<ParameterData> parameterData) {
		this.parameterData = parameterData;
	}
	public String getAssetInstanceVersionDescription() {
		return assetInstanceVersionDescription;
	}
	public void setAssetInstanceVersionDescription(
			String assetInstanceVersionDescription) {
		this.assetInstanceVersionDescription = assetInstanceVersionDescription;
	}
	public String getAssetInstanceName() {
		return assetInstanceName;
	}
	public void setAssetInstanceName(String assetInstanceName) {
		this.assetInstanceName = assetInstanceName;
	}
	public String getAssetInstanceVersionId() {
		return assetInstanceVersionId;
	}
	public void setAssetInstanceVersionId(String assetInstanceVersionId) {
		this.assetInstanceVersionId = assetInstanceVersionId;
	}
	@Override
	public String toString() {
		return "FilterData [taxonomyValueList=" + taxonomyValueList
				+ ", parameterData=" + parameterData
				+ ", assetInstanceVersionDescription="
				+ assetInstanceVersionDescription + ", assetInstanceName="
				+ assetInstanceName + ", assetInstanceVersionId="
				+ assetInstanceVersionId + "]";
	}

}
