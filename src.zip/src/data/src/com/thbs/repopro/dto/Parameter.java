package com.thbs.repopro.dto;

import java.math.BigInteger;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

// This class is used to store parameter details of an asset instance
@XmlRootElement(name="Parameter")
public class Parameter {

	private String paramId;
	
	private String paramName;
	
	private String paramDescription;
	
	private String value;
	
	private List<String> typeNames;
	
	private String selectedTypeName;
	
	private String listTypeName;
	
	private String mappedAssetName;
	
	private String updatedTime;
	
	private String updatedBy;
	
	private boolean isQuickLink;
	
	private List<String> possibleValues;
	
	private Long paramTypeId;
	private Long listTypeParamTypeId;
	private List<String> RTFwithTags;
	private List<String> RTFwithOutTags;
	private List<String> textDataList;
	
	public List<String> getRTFwithTags() {
		return RTFwithTags;
	}

	public void setRTFwithTags(List<String> rTFwithTags) {
		RTFwithTags = rTFwithTags;
	}

	public List<String> getRTFwithOutTags() {
		return RTFwithOutTags;
	}

	public void setRTFwithOutTags(List<String> rTFwithOutTags) {
		RTFwithOutTags = rTFwithOutTags;
	}

	public List<String> getTextDataList() {
		return textDataList;
	}

	public void setTextDataList(List<String> textDataList) {
		this.textDataList = textDataList;
	}

	public boolean isHasImportantValue() {
		return hasImportantValue;
	}

	public String getOldfileName() {
		return oldfileName;
	}

	public void setOldfileName(String oldfileName) {
		this.oldfileName = oldfileName;
	}
	public void setHasImportantValue(boolean hasImportantValue) {
		this.hasImportantValue = hasImportantValue;
	}
	private int size;
	
	private String fileName;
	
	private int displayOrder;
	
	private boolean isSystemParam;
	
	private boolean hasStaticValue;
	
	private boolean hasImportantValue;
	
	private boolean hasMandatoryValue;
	
	private boolean hasdefViewValue;
	
	private boolean isAdd;
	
	private String listParamTypeId;
	
	private CommonsMultipartFile uploadFile;
	
	private List<String> selectIcon;
	
	private boolean hasComputedValue;
	private String textidObj;
	private boolean hasDerivedValue;
	
	private String dynamicQuery;
	
	
	public String getDynamicQuery() {
		return dynamicQuery;
	}

	public void setDynamicQuery(String dynamicQuery) {
		this.dynamicQuery = dynamicQuery;
	}
	

	public boolean isHasComputedValue() {
		return hasComputedValue;
	}

	public void setHasComputedValue(boolean hasComputedValue) {
		this.hasComputedValue = hasComputedValue;
	}

	public String getTextidObj() {
		return textidObj;
	}

	public void setTextidObj(String textidObj) {
		this.textidObj = textidObj;
	}

	public boolean isHasDerivedValue() {
		return hasDerivedValue;
	}

	public void setHasDerivedValue(boolean hasDerivedValue) {
		this.hasDerivedValue = hasDerivedValue;
	}




	private String oldfileName;
	
	private String assetInstParamId;
	
	private Long assetInstanceParamId;
	
	public Long getAssetInstanceParamId() {
		return assetInstanceParamId;
	}

	public void setAssetInstanceParamId(Long assetInstanceParamId) {
		this.assetInstanceParamId = assetInstanceParamId;
	}

	public String getAssetInstParamId() {
		return assetInstParamId;
	}

	public void setAssetInstParamId(String assetInstParamId) {
		this.assetInstParamId = assetInstParamId;
	}

	/**
	 * @return the paramId
	 */
	public String getParamId() {
		return paramId;
	}

	/**
	 * @param paramId the paramId to set
	 */
	public void setParamId(String paramId) {
		this.paramId = paramId;
	}
	
	/**
	 * @return the mappedAssetName
	 */
	public String getMappedAssetName() {
		return mappedAssetName;
	}

	/**
	 * @param mappedAssetName the mappedAssetName to set
	 */
	public void setMappedAssetName(String mappedAssetName) {
		this.mappedAssetName = mappedAssetName;
	}

	/**
	 * @return the paramName
	 */
	public String getParamName() {
		return paramName;
	}

	/**
	 * @param paramName the paramName to set
	 */
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	/**
	 * @return the paramDescription
	 */
	public String getParamDescription() {
		return paramDescription;
	}

	/**
	 * @param paramDescription the paramDescription to set
	 */
	public void setParamDescription(String paramDescription) {
		this.paramDescription = paramDescription;
	}
	
	/**
	 * @return the values
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param values the values to set
	 */
	public void setValue(String values) {
		this.value = values;
	}
	
	/**
	 * @return the displayOrder
	 */
	public int getDisplayOrder() {
		return displayOrder;
	}

	/**
	 * @param displayOrder the displayOrder to set
	 */
	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}

	/**
	 * @return the isSystemParam
	 */
	public boolean getIsSystemParam() {
		return isSystemParam;
	}

	/**
	 * @param isSystemParam the isSystemParam to set
	 */
	public void setIsSystemParam(boolean isSystemParam) {
		this.isSystemParam = isSystemParam;
	}

	/**
	 * @return the hasStaticValue
	 */
	public boolean getHasStaticValue() {
		return hasStaticValue;
	}

	/**
	 * @param hasStaticValue the hasStaticValue to set
	 */
	public void setHasStaticValue(boolean hasStaticValue) {
		this.hasStaticValue = hasStaticValue;
	}

	
	

	/**
	 * @return the typeName
	 */
	public List<String> getTypeNames() {
		return typeNames;
	}

	/**
	 * @param typeName the typeName to set
	 */
	public void setTypeNames(List<String> typeNames) {
		this.typeNames = typeNames;
	}

	/**
	 * @return the selectedTypeName
	 */
	public String getSelectedTypeName() {
		return selectedTypeName;
	}

	/**
	 * @param selectedTypeName the selectedTypeName to set
	 */
	public void setSelectedTypeName(String selectedTypeName) {
		this.selectedTypeName = selectedTypeName;
	}
	
	/**
	 * @return the listTypeName
	 */
	public String getListTypeName() {
		return listTypeName;
	}

	/**
	 * @param listTypeName the listTypeName to set
	 */
	public void setListTypeName(String listTypeName) {
		this.listTypeName = listTypeName;
	}

	/**
	 * @return the updatedTime
	 */
	public String getUpdatedTime() {
		return updatedTime;
	}

	/**
	 * @param updatedTime the updatedTime to set
	 */
	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the isQuickLink
	 */
	public boolean isQuickLink() {
		return isQuickLink;
	}

	/**
	 * @param isQuickLink the isQuickLink to set
	 */
	public void setQuickLink(boolean isQuickLink) {
		this.isQuickLink = isQuickLink;
	}

	/**
	 * @return the possibleValues
	 */
	public List<String> getPossibleValues() {
		return possibleValues;
	}

	/**
	 * @param possibleValues the possibleValues to set
	 */
	public void setPossibleValues(List<String> possibleValues) {
		this.possibleValues = possibleValues;
	}

	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	/**
	 * @return isAdd
	 */
	public boolean getIsAdd() {
		return isAdd;
	}

	/**
	 * @param isAdd , if the parameter is being added newly
	 */
	public void setIsAdd(boolean isAdd) {
		this.isAdd = isAdd;
	}
		
	/**
	 * @return the uploadFile
	 */
	@XmlTransient
	public CommonsMultipartFile getUploadFile() {
		return uploadFile;
	}

	/**
	 * @param uploadFile the uploadFile to set
	 */
	public void setUploadFile(CommonsMultipartFile uploadFile) {
		this.uploadFile = uploadFile;
	}

	
	public Long getParamTypeId() {
		return paramTypeId;
	}

	public void setParamTypeId(Long paramTypeId) {
		this.paramTypeId = paramTypeId;
	}

	public Long getListTypeParamTypeId() {
		return listTypeParamTypeId;
	}

	public void setListTypeParamTypeId(Long listTypeParamTypeId) {
		this.listTypeParamTypeId = listTypeParamTypeId;
	}

	public void setSystemParam(boolean isSystemParam) {
		this.isSystemParam = isSystemParam;
	}

	public void setAdd(boolean isAdd) {
		this.isAdd = isAdd;
	}

	public String getListParamTypeId() {
		return listParamTypeId;
	}

	public void setListParamTypeId(String listParamTypeId) {
		this.listParamTypeId = listParamTypeId;
	}

	public void setSelectIcon(List<String> selectIcon) {
		this.selectIcon = selectIcon;
	}

	public List<String> getSelectIcon() {
		return selectIcon;
	}

	public boolean isHasdefViewValue() {
		return hasdefViewValue;
	}

	public void setHasdefViewValue(boolean hasdefViewValue) {
		this.hasdefViewValue = hasdefViewValue;
	}

	public boolean isHasMandatoryValue() {
		return hasMandatoryValue;
	}

	public void setHasMandatoryValue(boolean hasMandatoryValue) {
		this.hasMandatoryValue = hasMandatoryValue;
	}

	@Override
	public String toString() {
		return "Parameter [paramId=" + paramId + ", paramName=" + paramName
				+ ", paramDescription=" + paramDescription + ", value=" + value
				+ ", typeNames=" + typeNames + ", selectedTypeName="
				+ selectedTypeName + ", listTypeName=" + listTypeName
				+ ", mappedAssetName=" + mappedAssetName + ", updatedTime="
				+ updatedTime + ", updatedBy=" + updatedBy + ", isQuickLink="
				+ isQuickLink + ", possibleValues=" + possibleValues
				+ ", paramTypeId=" + paramTypeId + ", listTypeParamTypeId="
				+ listTypeParamTypeId + ", RTFwithTags=" + RTFwithTags
				+ ", RTFwithOutTags=" + RTFwithOutTags + ", textDataList="
				+ textDataList + ", size=" + size + ", fileName=" + fileName
				+ ", displayOrder=" + displayOrder + ", isSystemParam="
				+ isSystemParam + ", hasStaticValue=" + hasStaticValue
				+ ", hasImportantValue=" + hasImportantValue
				+ ", hasMandatoryValue=" + hasMandatoryValue
				+ ", hasdefViewValue=" + hasdefViewValue + ", isAdd=" + isAdd
				+ ", listParamTypeId=" + listParamTypeId + ", uploadFile="
				+ uploadFile + ", selectIcon=" + selectIcon
				+ ", hasComputedValue=" + hasComputedValue + ", textidObj="
				+ textidObj + ", hasDerivedValue=" + hasDerivedValue
				+ ", dynamicQuery=" + dynamicQuery + ", oldfileName="
				+ oldfileName + ", assetInstParamId=" + assetInstParamId
				+ ", assetInstanceParamId=" + assetInstanceParamId + "]";
	}

}
