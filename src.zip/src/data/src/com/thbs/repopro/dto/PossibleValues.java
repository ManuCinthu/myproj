package com.thbs.repopro.dto;

public class PossibleValues {
	private long valueId;
	private long assetParamId;
	private String value;
	private String iconImageName;
	private int listType;
	private boolean multiSelectFlag;
	
	public boolean isMultiSelectFlag() {
		return multiSelectFlag;
	}
	public void setMultiSelectFlag(boolean multiSelectFlag) {
		this.multiSelectFlag = multiSelectFlag;
	}
	public int getListType() {
		return listType;
	}
	public void setListType(int listType) {
		this.listType = listType;
	}
	public long getValueId() {
		return valueId;
	}
	public void setValueId(long valueId) {
		this.valueId = valueId;
	}
	public long getAssetParamId() {
		return assetParamId;
	}
	public void setAssetParamId(long assetParamId) {
		this.assetParamId = assetParamId;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getIconImageName() {
		return iconImageName;
	}
	public void setIconImageName(String iconImageName) {
		this.iconImageName = iconImageName;
	}
	@Override
	public String toString() {
		return "PossibleValues [valueId=" + valueId + ", assetParamId="
				+ assetParamId + ", value=" + value + ", iconImageName="
				+ iconImageName + "]";
	}

}
