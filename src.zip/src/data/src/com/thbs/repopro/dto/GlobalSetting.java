package com.thbs.repopro.dto;

public class GlobalSetting {

	
	private int globalLdapSettingFlag;
	private int globalLockSettingFlag;
	private Long globalSettingId;
	private String globalSettingName;
	private Long globalSettingFlag;
	private String lockTime;
	private int ssoFlag;
	private int circularImage;
	private int invertedImage;
	private int crossSiteScriptProtection;
	private String mechanism;
	private int guestAccess;
	
	public int getGlobalLdapSettingFlag() {
		return globalLdapSettingFlag;
	}

	public void setGlobalLdapSettingFlag(int globalLdapSettingFlag) {
		this.globalLdapSettingFlag = globalLdapSettingFlag;
	}

	public int getGlobalLockSettingFlag() {
		return globalLockSettingFlag;
	}

	public void setGlobalLockSettingFlag(int globalLockSettingFlag) {
		this.globalLockSettingFlag = globalLockSettingFlag;
	}

	public String getLockTime() {
		return lockTime;
	}

	public void setLockTime(String lockTime) {
		this.lockTime = lockTime;
	}

	public Long getGlobalSettingId() {
		return globalSettingId;
	}

	public void setGlobalSettingId(Long globalSettingId) {
		this.globalSettingId = globalSettingId;
	}

	public String getGlobalSettingName() {
		return globalSettingName;
	}

	public void setGlobalSettingName(String globalSettingName) {
		this.globalSettingName = globalSettingName;
	}

	public Long getGlobalSettingFlag() {
		return globalSettingFlag;
	}

	public void setGlobalSettingFlag(Long globalSettingFlag) {
		this.globalSettingFlag = globalSettingFlag;
	}

	public int getSsoFlag() {
		return ssoFlag;
	}

	public void setSsoFlag(int ssoFlag) {
		this.ssoFlag = ssoFlag;
	}

	public int getCircularImage() {
		return circularImage;
	}

	public void setCircularImage(int circularImage) {
		this.circularImage = circularImage;
	}

	public int getInvertedImage() {
		return invertedImage;
	}

	public void setInvertedImage(int invertedImage) {
		this.invertedImage = invertedImage;
	}

	
	public int getCrossSiteScriptProtection() {
		return crossSiteScriptProtection;
	}

	public void setCrossSiteScriptProtection(int crossSiteScriptProtection) {
		this.crossSiteScriptProtection = crossSiteScriptProtection;
	}
	public String getMechanism() {
		return mechanism;
	}
	public void setMechanism(String mechanism) {
		this.mechanism = mechanism;
	}
	public int getGuestAccess() {
		return guestAccess;
	}

	public void setGuestAccess(int guestAccess) {
		this.guestAccess = guestAccess;
	}

	@Override
	public String toString() {
		return "GlobalSetting [globalLdapSettingFlag=" + globalLdapSettingFlag + ", globalLockSettingFlag="
				+ globalLockSettingFlag + ", globalSettingId=" + globalSettingId + ", globalSettingName="
				+ globalSettingName + ", globalSettingFlag=" + globalSettingFlag + ", lockTime=" + lockTime
				+ ", ssoFlag=" + ssoFlag + ", circularImage=" + circularImage + ", invertedImage=" + invertedImage
				+ ", crossSiteScriptProtection=" + crossSiteScriptProtection + ", mechanism=" + mechanism
				+ ", guestAccess=" + guestAccess + "]";
	}

}
