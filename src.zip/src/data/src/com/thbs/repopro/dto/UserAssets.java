package com.thbs.repopro.dto;

public class UserAssets {
private Long userAssetId;
private Long userId;
private Long assetId;
public Long getUserAssetId() {
	return userAssetId;
}
public void setUserAssetId(Long userAssetId) {
	this.userAssetId = userAssetId;
}
public Long getUserId() {
	return userId;
}
public void setUserId(Long userId) {
	this.userId = userId;
}
public Long getAssetId() {
	return assetId;
}
public void setAssetId(Long assetId) {
	this.assetId = assetId;
}
@Override
public String toString() {
	return "UserAssets [userAssetId=" + userAssetId + ", userId=" + userId
			+ ", assetId=" + assetId + "]";
}

}
