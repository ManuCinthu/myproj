package com.thbs.repopro.dto;

import java.util.List;

public class AssetDetailRequest {
	private String parentAssetName;
	private String parentAssetInstanceName;
	private String assetType;
	private String assetInstName;
	private String versionName;
	private String assetInstanceDescription;
	private boolean isVersionable;
	private String dependentName;
	private boolean myFavFlag;
	private boolean subInstFlag;
	private String owner;
    private List<String> addAssetInstVersionIds;
    private List<String> removeAssetInstVersionIds;
    private List<String> selectedAssetRelationship;
    private List<String> removedAssetRelationship;
    
	public String getParentAssetName() {
		return parentAssetName;
	}

	public void setParentAssetName(String parentAssetName) {
		this.parentAssetName = parentAssetName;
	}

	public String getParentAssetInstanceName() {
		return parentAssetInstanceName;
	}

	public void setParentAssetInstanceName(String parentAssetInstanceName) {
		this.parentAssetInstanceName = parentAssetInstanceName;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getAssetInstName() {
		return assetInstName;
	}

	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}

	public String getVersionName() {
		return versionName;
	}

	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}

	public String getAssetInstanceDescription() {
		return assetInstanceDescription;
	}

	public void setAssetInstanceDescription(String assetInstanceDescription) {
		this.assetInstanceDescription = assetInstanceDescription;
	}

	public boolean isVersionable() {
		return isVersionable;
	}

	public void setVersionable(boolean isVersionable) {
		this.isVersionable = isVersionable;
	}

	public String getDependentName() {
		return dependentName;
	}

	public void setDependentName(String dependentName) {
		this.dependentName = dependentName;
	}

	public boolean isMyFavFlag() {
		return myFavFlag;
	}

	public void setMyFavFlag(boolean myFavFlag) {
		this.myFavFlag = myFavFlag;
//		System.out.println(myFavFlag);
	}

	public boolean isSubInstFlag() {
		return subInstFlag;
	}

	public void setSubInstFlag(boolean subInstFlag) {
		this.subInstFlag = subInstFlag;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public List<String> getAddAssetInstVersionIds() {
		return addAssetInstVersionIds;
	}

	public void setAddAssetInstVersionIds(List<String> addAssetInstVersionIds) {
		this.addAssetInstVersionIds = addAssetInstVersionIds;
	}

	public List<String> getRemoveAssetInstVersionIds() {
		return removeAssetInstVersionIds;
	}

	public void setRemoveAssetInstVersionIds(List<String> removeAssetInstVersionIds) {
		this.removeAssetInstVersionIds = removeAssetInstVersionIds;
	}

	public List<String> getSelectedAssetRelationship() {
		return selectedAssetRelationship;
	}

	public void setSelectedAssetRelationship(List<String> selectedAssetRelationship) {
		this.selectedAssetRelationship = selectedAssetRelationship;
	}

	public List<String> getRemovedAssetRelationship() {
		return removedAssetRelationship;
	}

	public void setRemovedAssetRelationship(List<String> removedAssetRelationship) {
		this.removedAssetRelationship = removedAssetRelationship;
	}

	@Override
	public String toString() {
		return "AssetDetailRequest [parentAssetName=" + parentAssetName
				+ ", parentAssetInstanceName=" + parentAssetInstanceName
				+ ", assetType=" + assetType + ", assetInstName="
				+ assetInstName + ", versionName=" + versionName
				+ ", assetInstanceDescription=" + assetInstanceDescription
				+ ", isVersionable=" + isVersionable + ", dependentName="
				+ dependentName + ", myFavFlag=" + myFavFlag + ", subInstFlag="
				+ subInstFlag + ", owner=" + owner
				+ ", addAssetInstVersionIds=" + addAssetInstVersionIds
				+ ", removeAssetInstVersionIds=" + removeAssetInstVersionIds
				+ ", selectedAssetRelationship=" + selectedAssetRelationship
				+ ", removedAssetRelationship=" + removedAssetRelationship
				+ "]";
	}

}
