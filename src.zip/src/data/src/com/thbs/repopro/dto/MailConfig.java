package com.thbs.repopro.dto;


public class MailConfig {
	private String userName;
	private String password;
	private String authentication;
	private String startTLSEnable;
	private String host;
	private int port;
	private String bcc;
	private String senderMailId;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAuthentication() {
		return authentication;
	}
	public void setAuthentication(String authentication) {
		this.authentication = authentication;
	}
	public String getStartTLSEnable() {
		return startTLSEnable;
	}
	public void setStartTLSEnable(String startTLSEnable) {
		this.startTLSEnable = startTLSEnable;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getBcc() {
		return bcc;
	}
	public void setBcc(String bcc) {
		this.bcc = bcc;
	}
	public String getSenderMailId() {
		return senderMailId;
	}
	public void setSenderMailId(String senderMailId) {
		this.senderMailId = senderMailId;
	}
	
	@Override
	public String toString() {
		return "MailConfig [userName=" + userName + ", password=" + password
				+ ", authentication=" + authentication + ", startTLSEnable="
				+ startTLSEnable + ", host=" + host + ", port=" + port
				+ ", bcc=" + bcc + ", senderMailId=" + senderMailId + "]";
	}
	
	
}
