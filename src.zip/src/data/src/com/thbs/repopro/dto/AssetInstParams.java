package com.thbs.repopro.dto;

import java.sql.Timestamp;



public class AssetInstParams {

	private Long assetInstParamId;
	private Long assetInstVersionId;
	private Long assetParamId;
	private Timestamp lastUpdatedTime;
	private Long modifyByUserId;

	public Long getAssetInstParamId() {
		return assetInstParamId;
	}

	public void setAssetInstParamId(Long assetInstParamId) {
		this.assetInstParamId = assetInstParamId;
	}

	public Long getAssetInstVersionId() {
		return assetInstVersionId;
	}

	

	public Long getAssetParamId() {
		return assetParamId;
	}

	public void setAssetParamId(Long assetParamId) {
		this.assetParamId = assetParamId;
	}

	public void setAssetInstVersionId(Long assetInstVersionId) {
		this.assetInstVersionId = assetInstVersionId;
	}

	public Timestamp getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(Timestamp lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public Long getModifyByUserId() {
		return modifyByUserId;
	}

	public void setModifyByUserId(Long modifyByUserId) {
		this.modifyByUserId = modifyByUserId;
	}

	@Override
	public String toString() {
		return "AssetInstParams [assetInstParamId=" + assetInstParamId
				+ ", assetInstVersionId=" + assetInstVersionId
				+ ", assetParamId=" + assetParamId + ", lastUpdatedTime="
				+ lastUpdatedTime + ", modifyByUserId=" + modifyByUserId + "]";
	}

}
