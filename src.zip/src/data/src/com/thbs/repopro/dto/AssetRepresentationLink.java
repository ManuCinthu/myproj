package com.thbs.repopro.dto;

public class AssetRepresentationLink {
	
	private Long assetRepresentationLinkId;
	private Long assetId;
	private Long assetRepresentationId;
	
	
	
	public Long getAssetRepresentationLinkId() {
		return assetRepresentationLinkId;
	}
	public void setAssetRepresentationLinkId(Long assetRepresentationLinkId) {
		this.assetRepresentationLinkId = assetRepresentationLinkId;
	}
	public Long getAssetId() {
		return assetId;
	}
	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}
	public Long getAssetRepresentationId() {
		return assetRepresentationId;
	}
	public void setAssetRepresentationId(Long assetRepresentationId) {
		this.assetRepresentationId = assetRepresentationId;
	}
	
	
	

}
