package com.thbs.repopro.dto;

import java.util.List;

public class ParentModel {
	private String label;
	private List<ParentModel> children;
	public ParentModel(){
		
	}
	public ParentModel(String label, List<ParentModel> children) {
		this.label = label;
		this.children = children;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public List<ParentModel> getChildren() {
		return children;
	}
	public void setChildren(List<ParentModel> children) {
		this.children = children;
	}
	@Override
	public String toString() {
		return "ParentModel [label=" + label + ", children=" + children + "]";
	}
	
}
