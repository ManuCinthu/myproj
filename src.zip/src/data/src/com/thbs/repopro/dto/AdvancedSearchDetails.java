package com.thbs.repopro.dto;

public class AdvancedSearchDetails {
	
	private Long    service_Id;
	private String  service_Name;
	private String  service_Version_Name;
	private String  service_Description;
	private Long    operation_Id;
    private String  operation_Name;
	private String  operation_Version_Name;
	private String  operation_Description;
	
	public Long getService_Id() {
		return service_Id;
	}
	public void setService_Id(Long service_Id) {
		this.service_Id = service_Id;
	}
	public String getService_Name() {
		return service_Name;
	}
	public void setService_Name(String service_Name) {
		this.service_Name = service_Name;
	}
	public String getService_Version_Name() {
		return service_Version_Name;
	}
	public void setService_Version_Name(String service_Version_Name) {
		this.service_Version_Name = service_Version_Name;
	}
	public String getService_Description() {
		return service_Description;
	}
	public void setService_Description(String service_Description) {
		this.service_Description = service_Description;
	}
	public Long getOperation_Id() {
		return operation_Id;
	}
	public void setOperation_Id(Long operation_Id) {
		this.operation_Id = operation_Id;
	}
	public String getOperation_Name() {
		return operation_Name;
	}
	public void setOperation_Name(String operation_Name) {
		this.operation_Name = operation_Name;
	}
	public String getOperation_Version_Name() {
		return operation_Version_Name;
	}
	public void setOperation_Version_Name(String operation_Version_Name) {
		this.operation_Version_Name = operation_Version_Name;
	}
	public String getOperation_Description() {
		return operation_Description;
	}
	public void setOperation_Description(String operation_Description) {
		this.operation_Description = operation_Description;
	}
	
	@Override
	public String toString() {
		return "AdvancedSearchDetails [service_Id=" + service_Id + ", service_Name=" + service_Name
				+ ", service_Version_Name=" + service_Version_Name + ", service_Description=" + service_Description
				+ ", operation_Id=" + operation_Id + ", operation_Name=" + operation_Name + ", operation_Version_Name="
				+ operation_Version_Name + ", operation_Description=" + operation_Description + "]";
	}
	
}
