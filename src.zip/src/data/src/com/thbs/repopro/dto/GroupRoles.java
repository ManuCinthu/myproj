package com.thbs.repopro.dto;

import java.util.List;

public class GroupRoles {

	private Long groupRolesId;
	private Long groupId;
	private Long roleId;
	private List<String> associatedRoleIds;

	public Long getGroupRolesId() {
		return groupRolesId;
	}

	public void setGroupRolesId(Long groupRolesId) {
		this.groupRolesId = groupRolesId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public List<String> getAssociatedRoleIds() {
		return associatedRoleIds;
	}

	public void setAssociatedRoleIds(List<String> associatedRoleIds) {
		this.associatedRoleIds = associatedRoleIds;
	}

	@Override
	public String toString() {
		return "GroupRoles [groupRolesId=" + groupRolesId + ", groupId="
				+ groupId + ", roleId=" + roleId + ", associatedRoleIds="
				+ associatedRoleIds + "]";
	}

}
