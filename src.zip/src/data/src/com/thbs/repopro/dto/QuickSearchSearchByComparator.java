package com.thbs.repopro.dto;

import java.util.Comparator;

public class QuickSearchSearchByComparator implements Comparator<QuickSearch>{

	@Override
	public int compare(QuickSearch o1, QuickSearch o2) {
		return o1.getSearchBy().compareTo(o2.getSearchBy());
	}

}
