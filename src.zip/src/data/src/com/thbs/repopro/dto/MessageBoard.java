package com.thbs.repopro.dto;

import java.sql.Timestamp;

public class MessageBoard {

	private String createdBy;
	private String adminMessage;
	private Timestamp createdOn;
	private String maintenance;
	private int ison;
	private int id;

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getAdminMessage() {
		return adminMessage;
	}

	public void setAdminMessage(String adminMessage) {
		this.adminMessage = adminMessage;
	}

	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public String getMaintenance() {
		return maintenance;
	}

	public void setMaintenance(String maintenance) {
		this.maintenance = maintenance;
	}

	public int getIson() {
		return ison;
	}

	public void setIson(int ison) {
		this.ison = ison;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "MessageBoard [createdBy=" + createdBy + ", adminMessage="
				+ adminMessage + ", createdOn=" + createdOn + ", maintenance="
				+ maintenance + ", ison=" + ison + ", id=" + id + "]";
	}

}
