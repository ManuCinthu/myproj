package com.thbs.repopro.dto;

import java.util.List;

public class Role {

	private Long roleId;
	private String roleName;
	private String authority;
	private String description;
	private boolean isMappedWithGroup;
	private Long functionId;
	private Long roleFunctionId;
	private List<String> associateFunctionIds;
	private List<String> associateFunctionNames;
	private boolean groupRoleFlag;

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isMappedWithGroup() {
		return isMappedWithGroup;
	}

	public void setMappedWithGroup(boolean isMappedWithGroup) {
		this.isMappedWithGroup = isMappedWithGroup;
	}

	public Long getFunctionId() {
		return functionId;
	}

	public void setFunctionId(Long functionId) {
		this.functionId = functionId;
	}

	public Long getRoleFunctionId() {
		return roleFunctionId;
	}

	public void setRoleFunctionId(Long roleFunctionId) {
		this.roleFunctionId = roleFunctionId;
	}

	public List<String> getAssociateFunctionIds() {
		return associateFunctionIds;
	}

	public void setAssociateFunctionIds(List<String> associateFunctionIds) {
		this.associateFunctionIds = associateFunctionIds;
	}

	public boolean isGroupRoleFlag() {
		return groupRoleFlag;
	}

	public void setGroupRoleFlag(boolean groupRoleFlag) {
		this.groupRoleFlag = groupRoleFlag;
	}
	
	public List<String> getAssociateFunctionNames() {
		return associateFunctionNames;
	}

	public void setAssociateFunctionNames(List<String> associateFunctionNames) {
		this.associateFunctionNames = associateFunctionNames;
	}

	@Override
	public String toString() {
		return "Role [roleId=" + roleId + ", roleName=" + roleName + ", authority=" + authority + ", description="
				+ description + ", isMappedWithGroup=" + isMappedWithGroup + ", functionId=" + functionId
				+ ", roleFunctionId=" + roleFunctionId + ", associateFunctionIds=" + associateFunctionIds
				+ ", associateFunctionNames=" + associateFunctionNames + ", groupRoleFlag=" + groupRoleFlag + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((associateFunctionIds == null) ? 0 : associateFunctionIds.hashCode());
		result = prime * result + ((associateFunctionNames == null) ? 0 : associateFunctionNames.hashCode());
		result = prime * result + ((authority == null) ? 0 : authority.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((functionId == null) ? 0 : functionId.hashCode());
		result = prime * result + (groupRoleFlag ? 1231 : 1237);
		result = prime * result + (isMappedWithGroup ? 1231 : 1237);
		result = prime * result + ((roleFunctionId == null) ? 0 : roleFunctionId.hashCode());
		result = prime * result + ((roleId == null) ? 0 : roleId.hashCode());
		result = prime * result + ((roleName == null) ? 0 : roleName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Role other = (Role) obj;
		if (associateFunctionIds == null) {
			if (other.associateFunctionIds != null)
				return false;
		} else if (!associateFunctionIds.equals(other.associateFunctionIds))
			return false;
		if (associateFunctionNames == null) {
			if (other.associateFunctionNames != null)
				return false;
		} else if (!associateFunctionNames.equals(other.associateFunctionNames))
			return false;
		if (authority == null) {
			if (other.authority != null)
				return false;
		} else if (!authority.equals(other.authority))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (functionId == null) {
			if (other.functionId != null)
				return false;
		} else if (!functionId.equals(other.functionId))
			return false;
		if (groupRoleFlag != other.groupRoleFlag)
			return false;
		if (isMappedWithGroup != other.isMappedWithGroup)
			return false;
		if (roleFunctionId == null) {
			if (other.roleFunctionId != null)
				return false;
		} else if (!roleFunctionId.equals(other.roleFunctionId))
			return false;
		if (roleId == null) {
			if (other.roleId != null)
				return false;
		} else if (!roleId.equals(other.roleId))
			return false;
		if (roleName == null) {
			if (other.roleName != null)
				return false;
		} else if (!roleName.equals(other.roleName))
			return false;
		return true;
	}

}
