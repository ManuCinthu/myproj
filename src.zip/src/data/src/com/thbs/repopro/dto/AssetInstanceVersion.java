package com.thbs.repopro.dto;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;



import javax.xml.bind.annotation.XmlRootElement;

import org.slf4j.Logger;

import com.thbs.repopro.ldap.LDAPUser;

@XmlRootElement(name = "AssetInstanceVersion")
public class AssetInstanceVersion implements Comparator<AssetInstanceVersion> {

	private Long assetId;
	private Boolean versionable;
	private Long assetInstVersionId;
	private int paramTextSize;
	private Long assetInstanceId;
	private String versionName;
	private String versionNotes;
	private String description;
	private String lockedBy;
	private String owner;
	private String assetName;
	private String relName;
	private String assetInstName;
	private String relType;
	private Long relId;
	private Long fwdRelId;
	private String destAssetInstVersionId;
	private String srcAssetInstanceVersionId;
	private Long assetRelId;
	private String iconImageName;
	private String groupName;
	private String userName;
	private String assetParamName;
	private String notes;
	private String taxonomyName;
	private int cat_disp;
	private int param_disp;
	private Timestamp updatedOn;
	private Timestamp createdOn;
	private Timestamp lockTime;
	private String paramValue;
	private String from;
	private String to;
	private String asset_category_name;
	private int isStatic;
	private String staticValue;
	private String fileName;
	private String newFileName;
	private String apdFileName;
	private String derivedAttributeComputation;
	private Long paramTypeId;
	private String composedInstName;
	private Long listTypeParamTypeId;
	private Long mappedAssetId;
	private Long assetParamId;
	private Long assetInstParamId;
	private boolean isImportant;
	private boolean isMandatory;
	private String tagName;
	private TreeMap<String, String> paramNamewithvalue;
	private boolean editAccessFlag;
	private boolean deleteAccessFlag;
	private boolean viewAccessFlag;
	private String action;	
	private byte[] byteValue;
	private String assetInstVersionIdForimport;
	private String RTFText;
	private String RTFPlainText;
	private List<String> RTFwithTags;
	private List<String> RTFwithOutTags;
	private List<String> textDataList;
	private int rtfCount;
	private int textCount;
	private List<String> versionList;
	private boolean singleMultipleFlag;
	private int listType;
	private InputStream filecontent;
	private int ldapUserListCount;
	private Connection conn;
	private Logger log;
	private Long userId;
	private List<String> ldapMappingList;
	private List<Integer> ldapAttributeId;
	private int ldapMappingListCount;
	private Map<String, Integer> ldapMappingValue;
	private int ldapMappingId;
	private List<LDAPUser> ldapmappingdata;
	private int resultTotalCount;
	private boolean deleteInstanceFlag;
	private boolean notifyFlag;
	
	public Timestamp getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}

	public int getResultTotalCount() {
		return resultTotalCount;
	}

	public void setResultTotalCount(int resultTotalCount) {
		this.resultTotalCount = resultTotalCount;
	}

	public List<LDAPUser> getLdapmappingdata() {
		return ldapmappingdata;
	}

	public void setLdapmappingdata(List<LDAPUser> ldapmappingdata) {
		this.ldapmappingdata = ldapmappingdata;
	}

	public List<Integer> getLdapAttributeId() {
		return ldapAttributeId;
	}

	public void setLdapAttributeId(List<Integer> ldapAttributeId) {
		this.ldapAttributeId = ldapAttributeId;
	}

	public List<String> getLdapMappingList() {
		return ldapMappingList;
	}

	public void setLdapMappingList(List<String> ldapMappingList) {
		this.ldapMappingList = ldapMappingList;
	}

	public int getLdapMappingListCount() {
		return ldapMappingListCount;
	}

	public void setLdapMappingListCount(int ldapMappingListCount) {
		this.ldapMappingListCount = ldapMappingListCount;
	}

	public Map<String, Integer> getLdapMappingValue() {
		return ldapMappingValue;
	}

	public void setLdapMappingValue(Map<String, Integer> ldapMappingValue) {
		this.ldapMappingValue = ldapMappingValue;
	}

	public int getLdapMappingId() {
		return ldapMappingId;
	}

	public void setLdapMappingId(int ldapMappingId) {
		this.ldapMappingId = ldapMappingId;
	}

	public int getListType() {
		return listType;
	}

	public void setListType(int listType) {
		this.listType = listType;
	}

	public Connection getConn() {
		return conn;
	}

	public void setConn(Connection conn) {
		this.conn = conn;
	}

	public Logger getLog() {
		return log;
	}

	public void setLog(Logger log) {
		this.log = log;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public boolean isSingleMultipleFlag() {
		return singleMultipleFlag;
	}

	public void setSingleMultipleFlag(boolean singleMultipleFlag) {
		this.singleMultipleFlag = singleMultipleFlag;
	}

	public List<String> getVersionList() {
		return versionList;
	}

	public void setVersionList(List<String> versionList) {
		this.versionList = versionList;
	}

	public int getRtfCount() {
		return rtfCount;
	}

	public void setRtfCount(int rtfCount) {
		this.rtfCount = rtfCount;
	}

	public int getTextCount() {
		return textCount;
	}

	public void setTextCount(int textCount) {
		this.textCount = textCount;
	}

	public List<String> getTextDataList() {
		return textDataList;
	}

	public void setTextDataList(List<String> textDataList) {
		this.textDataList = textDataList;
	}

	public String getRTFText() {
		return RTFText;
	}

	public void setRTFText(String rTFText) {
		RTFText = rTFText;
	}

	public List<String> getRTFwithTags() {
		return RTFwithTags;
	}

	public void setRTFwithTags(List<String> rTFwithTags) {
		RTFwithTags = rTFwithTags;
	}

	public List<String> getRTFwithOutTags() {
		return RTFwithOutTags;
	}

	public void setRTFwithOutTags(List<String> rTFwithOutTags) {
		RTFwithOutTags = rTFwithOutTags;
	}

	public String getRTFPlainText() {
		return RTFPlainText;
	}

	public void setRTFPlainText(String rTFPlainText) {
		RTFPlainText = rTFPlainText;
	}

	// HashMap<String, String> param = new HashMap<String, String>();
	private String relationshipData ;
	TreeMap<String, TreeMap<String, String>> parameterData = new TreeMap<String, TreeMap<String, String>>();
	//HashMap<String, HashMap<String, String>> composedparameterData = new HashMap<String, HashMap<String, String>>();
	TreeMap<String, TreeMap<String, TreeMap<String, String>>> composedparameterData2 = new TreeMap<String, TreeMap<String, TreeMap<String, String>>>();
	

	public TreeMap<String, TreeMap<String, TreeMap<String, String>>> getComposedparameterData2() {
		return composedparameterData2;
	}

	public void setComposedparameterData2(
			TreeMap<String, TreeMap<String, TreeMap<String, String>>> composedparameterData2) {
		this.composedparameterData2 = composedparameterData2;
	}

	public boolean isNotifyFlag() {
		return notifyFlag;
	}

	public void setNotifyFlag(boolean notifyFlag) {
		this.notifyFlag = notifyFlag;
	}

	HashMap<Long, Long> destVersionIdRelid = new HashMap<Long, Long>();
	private List<Long> removedDestAssetInstVersionIds;
	private List<Long> addDestAssetInstVersionIds;
	private List<Long> removedRelationshipIds;
	private List<Long> addRelationshipIds;
	private List<String> removedAssetInstNames;
	private List<String> removedVersionNames;
	private List<String> addAssetInstNames;
	private List<String> addVersionNames;
	private List<String> addRelationshipNames;
	private List<String> removeRelationshipNames;
	private List<String> addAssetNames;
	private List<String> removeAssetNames;
	private Long categoryId;
	private int hasArray;
	


	public int getHasArray() {
		return hasArray;
	}

	public void setHasArray(int hasArray) {
		this.hasArray = hasArray;
	}

	public int getParamTextSize() {
		return paramTextSize;
	}

	public void setParamTextSize(int paramTextSize) {
		this.paramTextSize = paramTextSize;
	}
	public String getNewFileName() {
		return newFileName;
	}

	public void setNewFileName(String newFileName) {
		this.newFileName = newFileName;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public TreeMap<String, String> getParamNamewithvalue() {
		return paramNamewithvalue;
	}

	public void setParamNamewithvalue(TreeMap<String, String> paramNamewithvalue) {
		this.paramNamewithvalue = paramNamewithvalue;
	}

	public Long getListTypeParamTypeId() {
		return listTypeParamTypeId;
	}

	public void setListTypeParamTypeId(Long listTypeParamTypeId) {
		this.listTypeParamTypeId = listTypeParamTypeId;
	}

	public Long getMappedAssetId() {
		return mappedAssetId;
	}

	public void setMappedAssetId(Long mappedAssetId) {
		this.mappedAssetId = mappedAssetId;
	}

	public Long getAssetParamId() {
		return assetParamId;
	}

	public void setAssetParamId(Long assetParamId) {
		this.assetParamId = assetParamId;
	}

	public boolean isImportant() {
		return isImportant;
	}

	public void setImportant(boolean isImportant) {
		this.isImportant = isImportant;
	}

	public Boolean getVersionable() {
		return versionable;
	}

	public void setVersionable(Boolean versionable) {
		this.versionable = versionable;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getComposedInstName() {
		return composedInstName;
	}

	public void setComposedInstName(String composedInstName) {
		this.composedInstName = composedInstName;
	}

	
	public TreeMap<String, TreeMap<String, String>> getParameterData() {
		return parameterData;
	}

	public void setParameterData(
			TreeMap<String, TreeMap<String, String>> parameterData) {
		this.parameterData = parameterData;
	}

	public String getRelationshipData() {
		return relationshipData;
	}

	public void setRelationshipData(String relationshipData) {
		this.relationshipData = relationshipData;
	}

	public Long getAssetInstVersionId() {
		return assetInstVersionId;
	}

	public void setAssetInstVersionId(Long assetInstVersionId) {
		this.assetInstVersionId = assetInstVersionId;
	}

	public Long getAssetInstanceId() {
		return assetInstanceId;
	}

	public void setAssetInstanceId(Long assetInstanceId) {
		this.assetInstanceId = assetInstanceId;
	}

	public String getVersionName() {
		return versionName;
	}

	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}

	public String getVersionNotes() {
		return versionNotes;
	}

	public void setVersionNotes(String versionNotes) {
		this.versionNotes = versionNotes;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLockedBy() {
		return lockedBy;
	}

	public void setLockedBy(String lockedBy) {
		this.lockedBy = lockedBy;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getRelName() {
		return relName;
	}

	public void setRelName(String relName) {
		this.relName = relName;
	}

	public String getAssetInstName() {
		return assetInstName;
	}

	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}

	public String getRelType() {
		return relType;
	}

	public void setRelType(String relType) {
		this.relType = relType;
	}

	public Long getRelId() {
		return relId;
	}

	public void setRelId(Long relId) {
		this.relId = relId;
	}

	public Long getFwdRelId() {
		return fwdRelId;
	}

	public void setFwdRelId(Long fwdRelId) {
		this.fwdRelId = fwdRelId;
	}

	public String getDestAssetInstVersionId() {
		return destAssetInstVersionId;
	}

	public void setDestAssetInstVersionId(String destAssetInstVersionId) {
		this.destAssetInstVersionId = destAssetInstVersionId;
	}

	public String getSrcAssetInstanceVersionId() {
		return srcAssetInstanceVersionId;
	}

	public void setSrcAssetInstanceVersionId(String srcAssetInstanceVersionId) {
		this.srcAssetInstanceVersionId = srcAssetInstanceVersionId;
	}

	public Long getAssetRelId() {
		return assetRelId;
	}

	public void setAssetRelId(Long assetRelId) {
		this.assetRelId = assetRelId;
	}

	public String getIconImageName() {
		return iconImageName;
	}

	public void setIconImageName(String iconImageName) {
		this.iconImageName = iconImageName;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAssetParamName() {
		return assetParamName;
	}

	public void setAssetParamName(String assetParamName) {
		this.assetParamName = assetParamName;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getTaxonomyName() {
		return taxonomyName;
	}

	public void setTaxonomyName(String taxonomyName) {
		this.taxonomyName = taxonomyName;
	}

	public int getCat_disp() {
		return cat_disp;
	}

	public void setCat_disp(int cat_disp) {
		this.cat_disp = cat_disp;
	}

	public int getParam_disp() {
		return param_disp;
	}

	public void setParam_disp(int param_disp) {
		this.param_disp = param_disp;
	}

	public Timestamp getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}

	public Timestamp getLockTime() {
		return lockTime;
	}

	public void setLockTime(Timestamp lockTime) {
		this.lockTime = lockTime;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getAsset_category_name() {
		return asset_category_name;
	}

	public void setAsset_category_name(String asset_category_name) {
		this.asset_category_name = asset_category_name;
	}

	public int getIsStatic() {
		return isStatic;
	}

	public void setIsStatic(int isStatic) {
		this.isStatic = isStatic;
	}

	public String getStaticValue() {
		return staticValue;
	}

	public void setStaticValue(String staticValue) {
		this.staticValue = staticValue;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getApdFileName() {
		return apdFileName;
	}

	public void setApdFileName(String apdFileName) {
		this.apdFileName = apdFileName;
	}

	public String getDerivedAttributeComputation() {
		return derivedAttributeComputation;
	}

	public void setDerivedAttributeComputation(
			String derivedAttributeComputation) {
		this.derivedAttributeComputation = derivedAttributeComputation;
	}

	public Long getParamTypeId() {
		return paramTypeId;
	}

	public void setParamTypeId(Long paramTypeId) {
		this.paramTypeId = paramTypeId;
	}

	public HashMap<Long, Long> getDestVersionIdRelid() {
		return destVersionIdRelid;
	}

	public void setDestVersionIdRelid(HashMap<Long, Long> destVersionIdRelid) {
		this.destVersionIdRelid = destVersionIdRelid;
	}

	public List<Long> getRemovedDestAssetInstVersionIds() {
		return removedDestAssetInstVersionIds;
	}

	public void setRemovedDestAssetInstVersionIds(
			List<Long> removedDestAssetInstVersionIds) {
		this.removedDestAssetInstVersionIds = removedDestAssetInstVersionIds;
	}

	public List<Long> getAddDestAssetInstVersionIds() {
		return addDestAssetInstVersionIds;
	}

	public void setAddDestAssetInstVersionIds(
			List<Long> addDestAssetInstVersionIds) {
		this.addDestAssetInstVersionIds = addDestAssetInstVersionIds;
	}

	public List<Long> getRemovedRelationshipIds() {
		return removedRelationshipIds;
	}

	public void setRemovedRelationshipIds(List<Long> removedRelationshipIds) {
		this.removedRelationshipIds = removedRelationshipIds;
	}

	public List<Long> getAddRelationshipIds() {
		return addRelationshipIds;
	}

	public void setAddRelationshipIds(List<Long> addRelationshipIds) {
		this.addRelationshipIds = addRelationshipIds;
	}

	public Long getAssetInstParamId() {
		return assetInstParamId;
	}

	public void setAssetInstParamId(Long assetInstParamId) {
		this.assetInstParamId = assetInstParamId;
	}

	public boolean isEditAccessFlag() {
		return editAccessFlag;
	}

	public void setEditAccessFlag(boolean editAccessFlag) {
		this.editAccessFlag = editAccessFlag;
	}

	public boolean isDeleteAccessFlag() {
		return deleteAccessFlag;
	}

	public void setDeleteAccessFlag(boolean deleteAccessFlag) {
		this.deleteAccessFlag = deleteAccessFlag;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public byte[] getByteValue() {
		return byteValue;
	}

	public void setByteValue(byte[] byteValue) {
		this.byteValue = byteValue;
	}

	public String getAssetInstVersionIdForimport() {
		return assetInstVersionIdForimport;
	}

	public void setAssetInstVersionIdForimport(String assetInstVersionIdForimport) {
		this.assetInstVersionIdForimport = assetInstVersionIdForimport;
	}

	public List<String> getRemovedAssetInstNames() {
		return removedAssetInstNames;
	}

	public void setRemovedAssetInstNames(List<String> removedAssetInstNames) {
		this.removedAssetInstNames = removedAssetInstNames;
	}

	public List<String> getRemovedVersionNames() {
		return removedVersionNames;
	}

	public void setRemovedVersionNames(List<String> removedVersionNames) {
		this.removedVersionNames = removedVersionNames;
	}

	public List<String> getAddAssetInstNames() {
		return addAssetInstNames;
	}

	public void setAddAssetInstNames(List<String> addAssetInstNames) {
		this.addAssetInstNames = addAssetInstNames;
	}

	public List<String> getAddVersionNames() {
		return addVersionNames;
	}

	public void setAddVersionNames(List<String> addVersionNames) {
		this.addVersionNames = addVersionNames;
	}

	public List<String> getAddRelationshipNames() {
		return addRelationshipNames;
	}

	public void setAddRelationshipNames(List<String> addRelationshipNames) {
		this.addRelationshipNames = addRelationshipNames;
	}

	public List<String> getRemoveRelationshipNames() {
		return removeRelationshipNames;
	}

	public void setRemoveRelationshipNames(List<String> removeRelationshipNames) {
		this.removeRelationshipNames = removeRelationshipNames;
	}

	public List<String> getAddAssetNames() {
		return addAssetNames;
	}

	public void setAddAssetNames(List<String> addAssetNames) {
		this.addAssetNames = addAssetNames;
	}

	public List<String> getRemoveAssetNames() {
		return removeAssetNames;
	}

	public void setRemoveAssetNames(List<String> removeAssetNames) {
		this.removeAssetNames = removeAssetNames;
	}

	
	public boolean isViewAccessFlag() {
		return viewAccessFlag;
	}

	public void setViewAccessFlag(boolean viewAccessFlag) {
		this.viewAccessFlag = viewAccessFlag;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public InputStream getFilecontent() {
		return filecontent;
	}

	public void setFilecontent(InputStream filecontent) {
		this.filecontent = filecontent;
	}

	public int getLdapUserListCount() {
		return ldapUserListCount;
	}

	public void setLdapUserListCount(int ldapUserListCount) {
		this.ldapUserListCount = ldapUserListCount;
	}

	public boolean isDeleteInstanceFlag() {
		return deleteInstanceFlag;
	}

	public void setDeleteInstanceFlag(boolean deleteInstanceFlag) {
		this.deleteInstanceFlag = deleteInstanceFlag;
	}

	@Override
	public String toString() {
		return "AssetInstanceVersion [assetId=" + assetId + ", versionable=" + versionable + ", assetInstVersionId="
				+ assetInstVersionId + ", paramTextSize=" + paramTextSize + ", assetInstanceId=" + assetInstanceId
				+ ", versionName=" + versionName + ", versionNotes=" + versionNotes + ", description=" + description
				+ ", lockedBy=" + lockedBy + ", owner=" + owner + ", assetName=" + assetName + ", relName=" + relName
				+ ", assetInstName=" + assetInstName + ", relType=" + relType + ", relId=" + relId + ", fwdRelId="
				+ fwdRelId + ", destAssetInstVersionId=" + destAssetInstVersionId + ", srcAssetInstanceVersionId="
				+ srcAssetInstanceVersionId + ", assetRelId=" + assetRelId + ", iconImageName=" + iconImageName
				+ ", groupName=" + groupName + ", userName=" + userName + ", assetParamName=" + assetParamName
				+ ", notes=" + notes + ", taxonomyName=" + taxonomyName + ", cat_disp=" + cat_disp + ", param_disp="
				+ param_disp + ", updatedOn=" + updatedOn + ", createdOn=" + createdOn + ", lockTime=" + lockTime
				+ ", paramValue=" + paramValue + ", from=" + from + ", to=" + to + ", asset_category_name="
				+ asset_category_name + ", isStatic=" + isStatic + ", staticValue=" + staticValue + ", fileName="
				+ fileName + ", newFileName=" + newFileName + ", apdFileName=" + apdFileName
				+ ", derivedAttributeComputation=" + derivedAttributeComputation + ", paramTypeId=" + paramTypeId
				+ ", composedInstName=" + composedInstName + ", listTypeParamTypeId=" + listTypeParamTypeId
				+ ", mappedAssetId=" + mappedAssetId + ", assetParamId=" + assetParamId + ", assetInstParamId="
				+ assetInstParamId + ", isImportant=" + isImportant + ", isMandatory=" + isMandatory + ", tagName="
				+ tagName + ", paramNamewithvalue=" + paramNamewithvalue + ", editAccessFlag=" + editAccessFlag
				+ ", deleteAccessFlag=" + deleteAccessFlag + ", viewAccessFlag=" + viewAccessFlag + ", action=" + action
				+ ", byteValue=" + Arrays.toString(byteValue) + ", assetInstVersionIdForimport="
				+ assetInstVersionIdForimport + ", RTFText=" + RTFText + ", RTFPlainText=" + RTFPlainText
				+ ", RTFwithTags=" + RTFwithTags + ", RTFwithOutTags=" + RTFwithOutTags + ", textDataList="
				+ textDataList + ", rtfCount=" + rtfCount + ", textCount=" + textCount + ", versionList=" + versionList
				+ ", singleMultipleFlag=" + singleMultipleFlag + ", listType=" + listType + ", filecontent="
				+ filecontent + ", ldapUserListCount=" + ldapUserListCount + ", conn=" + conn + ", log=" + log
				+ ", userId=" + userId + ", ldapMappingList=" + ldapMappingList + ", ldapAttributeId=" + ldapAttributeId
				+ ", ldapMappingListCount=" + ldapMappingListCount + ", ldapMappingValue=" + ldapMappingValue
				+ ", ldapMappingId=" + ldapMappingId + ", ldapmappingdata=" + ldapmappingdata + ", resultTotalCount="
				+ resultTotalCount + ", deleteInstanceFlag=" + deleteInstanceFlag + ", notifyFlag=" + notifyFlag
				+ ", relationshipData=" + relationshipData + ", parameterData=" + parameterData
				+ ", composedparameterData2=" + composedparameterData2 + ", destVersionIdRelid=" + destVersionIdRelid
				+ ", removedDestAssetInstVersionIds=" + removedDestAssetInstVersionIds + ", addDestAssetInstVersionIds="
				+ addDestAssetInstVersionIds + ", removedRelationshipIds=" + removedRelationshipIds
				+ ", addRelationshipIds=" + addRelationshipIds + ", removedAssetInstNames=" + removedAssetInstNames
				+ ", removedVersionNames=" + removedVersionNames + ", addAssetInstNames=" + addAssetInstNames
				+ ", addVersionNames=" + addVersionNames + ", addRelationshipNames=" + addRelationshipNames
				+ ", removeRelationshipNames=" + removeRelationshipNames + ", addAssetNames=" + addAssetNames
				+ ", removeAssetNames=" + removeAssetNames + ", categoryId=" + categoryId + ", hasArray=" + hasArray
				+ "]";
	}

	@Override
	public int compare(AssetInstanceVersion o1, AssetInstanceVersion o2) {
		// TODO Auto-generated method stub
		
		/*if(o1.getAssetInstName().equals(o2.getAssetInstName())){
			return o1.getAssetParamId().compareTo(o2.getAssetParamId());
		}else{
			return o1.getAssetInstName().toLowerCase()
					.compareTo(o2.getAssetInstName().toLowerCase());
		}*/
		
		return o1.getAssetInstName().toLowerCase()
				.compareTo(o2.getAssetInstName().toLowerCase());
		
	}

	public boolean isMandatory() {
		return isMandatory;
	}

	public void setMandatory(boolean isMandatory) {
		this.isMandatory = isMandatory;
	}

}
