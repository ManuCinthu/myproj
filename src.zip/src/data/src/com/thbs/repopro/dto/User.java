package com.thbs.repopro.dto;

import java.io.InputStream;
import java.sql.Timestamp;
import java.util.HashMap;

public class User {

	private Long userId;

	private String userName;

	private String fullName;

	private String emailId;

	private Long roleId;

	private String password;

	private boolean subscribe;

	private String activeFlag;

	private String department;

	private InputStream image;

	private String imageName;

	private int count;

	private String newPassword;

	private String confirmNewPassword;

	private HashMap<String, String> userMap;
	
	private Long userGroupId;
	
	private Long groupId;

	private int recentActivityFlag;
	
	private int adminMessageFlag;
	
	private int leaderBoardFlag;
	
	private int userDetailFlag;
	
	private int quickStatFlag;
	
	private String functionDescription;
	
	private boolean accessFlag; 

	private int loginAttempt;
	
	private boolean lockAccountFlag;
	
	private String lockStatus;
	
	private boolean isNative;
	
	private int ldapFlag;
	
	private String sectionName;
	
	private String sectionPosition;
	
	private String sectionVisibility;
	
	private String roleName;
	private String roleDescription;
	private String groupName;
	private String groupDescription;
	
	private Timestamp timestamp;
	
	private int encryptFullName;
	private int encryptEmailId;
	private int encryptDepartment;
	private int encryptImage;
	
	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public String getSectionVisibility() {
		return sectionVisibility;
	}

	public void setSectionVisibility(String sectionVisibility) {
		this.sectionVisibility = sectionVisibility;
	}
	
	public String getSectionPosition() {
		return sectionPosition;
	}

	public void setSectionPosition(String sectionPosition) {
		this.sectionPosition = sectionPosition;
	}

	public int getLdapFlag() {
		return ldapFlag;
	}

	public void setLdapFlag(int ldapFlag) {
		this.ldapFlag = ldapFlag;
	}

	public boolean isNative() {
		return isNative;
	}

	public void setNative(boolean isNative) {
		this.isNative = isNative;
	}

	public boolean getAccessFlag() {
		return accessFlag;
	}

	public void setAccessFlag(boolean accessFlag) {
		this.accessFlag = accessFlag;
	}

	/**
	 * @return the newPassword
	 */
	public String getNewPassword() {
		return newPassword;
	}

	/**
	 * @param newPassword
	 *            the newPassword to set
	 */
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	/**
	 * @return the confirmNewPassword
	 */
	public String getConfirmNewPassword() {
		return confirmNewPassword;
	}

	/**
	 * @param confirmNewPassword
	 *            the confirmNewPassword to set
	 */
	public void setConfirmNewPassword(String confirmNewPassword) {
		this.confirmNewPassword = confirmNewPassword;
	}

	/**
	 * @return the imageName
	 */
	public String getImageName() {
		return imageName;
	}

	/**
	 * @param imageName
	 *            the imageName to set
	 */
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @param fullName
	 *            the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	/**
	 * @return the emailId
	 */
	public String getEmailId() {
		return emailId;
	}

	/**
	 * @param emailId
	 *            the emailId to set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	/**
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	/**
	 * @param roleId
	 *            the roleId to set
	 */
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the subscribe
	 */
	public boolean isSubscribe() {
		return subscribe;
	}

	/**
	 * @param subscribe
	 *            the subscribe to set
	 */
	public void setSubscribe(boolean subscribe) {
		this.subscribe = subscribe;
	}

	/**
	 * @return the activeFlag
	 */
	public String getActiveFlag() {
		return activeFlag;
	}

	/**
	 * @param activeFlag
	 *            the activeFlag to set
	 */
	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department
	 *            the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return the image
	 */
	public InputStream getImage() {
		return image;
	}

	/**
	 * @param image
	 *            the image to set
	 */
	public void setImage(InputStream image) {
		this.image = image;
	}

	/**
	 * @return the count
	 */
	public int getCount() {
		return count;
	}

	/**
	 * @param count
	 *            the count to set
	 */
	public void setCount(int count) {
		this.count = count;
	}

	public HashMap<String, String> getUserMap() {
		return userMap;
	}

	public void setUserMap(HashMap<String, String> userMap) {
		this.userMap = userMap;
	}

	public Long getUserGroupId() {
		return userGroupId;
	}

	public void setUserGroupId(Long userGroupId) {
		this.userGroupId = userGroupId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	
	
	
	public String getLockStatus() {
		return lockStatus;
	}

	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

	public int getRecentActivityFlag() {
		return recentActivityFlag;
	}

	public void setRecentActivityFlag(int recentActivityFlag) {
		this.recentActivityFlag = recentActivityFlag;
	}

	public int getAdminMessageFlag() {
		return adminMessageFlag;
	}

	public void setAdminMessageFlag(int adminMessageFlag) {
		this.adminMessageFlag = adminMessageFlag;
	}

	public int getLeaderBoardFlag() {
		return leaderBoardFlag;
	}

	public void setLeaderBoardFlag(int leaderBoardFlag) {
		this.leaderBoardFlag = leaderBoardFlag;
	}

	public int getUserDetailFlag() {
		return userDetailFlag;
	}

	public void setUserDetailFlag(int userDetailFlag) {
		this.userDetailFlag = userDetailFlag;
	}

	public int getQuickStatFlag() {
		return quickStatFlag;
	}

	public void setQuickStatFlag(int quickStatFlag) {
		this.quickStatFlag = quickStatFlag;
	}

	
	
	public String getFunctionDescription() {
		return functionDescription;
	}

	public void setFunctionDescription(String functionDescription) {
		this.functionDescription = functionDescription;
	}
	

	public int getLoginAttempt() {
		return loginAttempt;
	}

	public void setLoginAttempt(int loginAttempt) {
		this.loginAttempt = loginAttempt;
	}
	

	public boolean isLockAccountFlag() {
		return lockAccountFlag;
	}

	public void setLockAccountFlag(boolean lockAccountFlag) {
		this.lockAccountFlag = lockAccountFlag;
	}
	
	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}


	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getGroupDescription() {
		return groupDescription;
	}

	public void setGroupDescription(String groupDescription) {
		this.groupDescription = groupDescription;
	}

	public int getEncryptFullName() {
		return encryptFullName;
	}

	public void setEncryptFullName(int encryptFullName) {
		this.encryptFullName = encryptFullName;
	}

	public int getEncryptEmailId() {
		return encryptEmailId;
	}

	public void setEncryptEmailId(int encryptEmailId) {
		this.encryptEmailId = encryptEmailId;
	}

	public int getEncryptDepartment() {
		return encryptDepartment;
	}

	public void setEncryptDepartment(int encryptDepartment) {
		this.encryptDepartment = encryptDepartment;
	}

	public int getEncryptImage() {
		return encryptImage;
	}

	public void setEncryptImage(int encryptImage) {
		this.encryptImage = encryptImage;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", fullName=" + fullName + ", emailId=" + emailId
				+ ", roleId=" + roleId + ", password=" + password + ", subscribe=" + subscribe + ", activeFlag="
				+ activeFlag + ", department=" + department + ", image=" + image + ", imageName=" + imageName
				+ ", count=" + count + ", newPassword=" + newPassword + ", confirmNewPassword=" + confirmNewPassword
				+ ", userMap=" + userMap + ", userGroupId=" + userGroupId + ", groupId=" + groupId
				+ ", recentActivityFlag=" + recentActivityFlag + ", adminMessageFlag=" + adminMessageFlag
				+ ", leaderBoardFlag=" + leaderBoardFlag + ", userDetailFlag=" + userDetailFlag + ", quickStatFlag="
				+ quickStatFlag + ", functionDescription=" + functionDescription + ", accessFlag=" + accessFlag
				+ ", loginAttempt=" + loginAttempt + ", lockAccountFlag=" + lockAccountFlag + ", lockStatus="
				+ lockStatus + ", isNative=" + isNative + ", ldapFlag=" + ldapFlag + ", sectionName=" + sectionName
				+ ", sectionPosition=" + sectionPosition + ", sectionVisibility=" + sectionVisibility + ", roleName="
				+ roleName + ", roleDescription=" + roleDescription + ", groupName=" + groupName + ", groupDescription="
				+ groupDescription + ", timestamp=" + timestamp + ", encryptFullName=" + encryptFullName
				+ ", encryptEmailId=" + encryptEmailId + ", encryptDepartment=" + encryptDepartment + ", encryptImage="
				+ encryptImage + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */

}
