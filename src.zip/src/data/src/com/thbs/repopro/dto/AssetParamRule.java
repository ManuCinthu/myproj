package com.thbs.repopro.dto;

import java.util.Arrays;
import java.util.Map;

import org.json.JSONArray;

public class AssetParamRule {
	
	private int paramRuleId;
	private String paramRuleName;
	private String assetParamName;//save
	private String operatorValue;
	private String param1Value;
	private String logicalOperator;
	private String param2Value;
	private Long assetId;
	private String scheduler;
	private Long[] userIds; //save
	private Map<Long, String> userList; //get
	private String parameterName;
	private JSONArray selectedUserIds;//get
	private String actionForRule;
	
	public int getParamRuleId() {
		return paramRuleId;
	}

	public void setParamRuleId(int paramRuleId) {
		this.paramRuleId = paramRuleId;
	}

	public String getParamRuleName() {
		return paramRuleName;
	}

	public void setParamRuleName(String paramRuleName) {
		this.paramRuleName = paramRuleName;
	}

	public String getAssetParamName() {
		return assetParamName;
	}

	public void setAssetParamName(String assetParamName) {
		this.assetParamName = assetParamName;
	}

	public String getOperatorValue() {
		return operatorValue;
	}

	public void setOperatorValue(String operatorValue) {
		this.operatorValue = operatorValue;
	}

	public String getParam1Value() {
		return param1Value;
	}

	public void setParam1Value(String param1Value) {
		this.param1Value = param1Value;
	}

	public String getLogicalOperator() {
		return logicalOperator;
	}

	public void setLogicalOperator(String logicalOperator) {
		this.logicalOperator = logicalOperator;
	}

	public String getParam2Value() {
		return param2Value;
	}

	public void setParam2Value(String param2Value) {
		this.param2Value = param2Value;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getScheduler() {
		return scheduler;
	}

	public void setScheduler(String scheduler) {
		this.scheduler = scheduler;
	}

	public Long[] getUserIds() {
		return userIds;
	}

	public void setUserIds(Long[] userIds) {
		this.userIds = userIds;
	}

	public Map<Long, String> getUserList() {
		return userList;
	}

	public void setUserList(Map<Long, String> userList) {
		this.userList = userList;
	}

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public JSONArray getSelectedUserIds() {
		return selectedUserIds;
	}

	public void setSelectedUserIds(JSONArray selectedUserIds) {
		this.selectedUserIds = selectedUserIds;
	}

	public String getActionForRule() {
		return actionForRule;
	}

	public void setActionForRule(String actionForRule) {
		this.actionForRule = actionForRule;
	}

	@Override
	public String toString() {
		return "AssetParamRule [paramRuleId=" + paramRuleId + ", paramRuleName=" + paramRuleName + ", assetParamName="
				+ assetParamName + ", operatorValue=" + operatorValue + ", param1Value=" + param1Value
				+ ", logicalOperator=" + logicalOperator + ", param2Value=" + param2Value + ", assetId=" + assetId
				+ ", scheduler=" + scheduler + ", userIds=" + Arrays.toString(userIds) + ", userList=" + userList
				+ ", parameterName=" + parameterName + ", selectedUserIds=" + selectedUserIds + ", actionForRule="
				+ actionForRule + "]";
	}
}
