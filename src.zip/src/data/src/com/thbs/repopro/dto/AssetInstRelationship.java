package com.thbs.repopro.dto;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="AssetInstRelationship")
public class AssetInstRelationship {
	private Long assetInstRelId;
	private Long srcAssetInstVersionId;
	private Long destAssetInstVersionId;
	private Long assetRelId;
	private Long assetInstanceVersionId;
	private String assetName;
	private String assetInstanceName;
	private Long assetInstanceId;
	private String versionable;
	private Long fwdRelationId;
	private Long bwdRelationId;
	private String descrption;
	private String versionName;
	private Long assetrelationShipId;
	private String srcAssetName;
	private Long srcAssetId;
	private String sourceInstanceName;
	private String sourceVersionName;
	private String sourceDescription;
	private String type;
	private String relationShipName;
	private String destAssetName;
	private Long destAssetId;
	private String destInstanceName;
	private String destInstanceVersionName;
	private String destdescription;
	private Long assetId;
	private String action;
	
	public Long getAssetInstRelId() {
		return assetInstRelId;
	}

	public void setAssetInstRelId(Long assetInstRelId) {
		this.assetInstRelId = assetInstRelId;
	}

	public Long getSrcAssetInstVersionId() {
		return srcAssetInstVersionId;
	}

	public void setSrcAssetInstVersionId(Long srcAssetInstVersionId) {
		this.srcAssetInstVersionId = srcAssetInstVersionId;
	}

	public Long getDestAssetInstVersionId() {
		return destAssetInstVersionId;
	}

	public void setDestAssetInstVersionId(Long destAssetInstVersionId) {
		this.destAssetInstVersionId = destAssetInstVersionId;
	}

	public Long getAssetRelId() {
		return assetRelId;
	}

	public void setAssetRelId(Long assetRelId) {
		this.assetRelId = assetRelId;
	}

	public Long getAssetInstanceVersionId() {
		return assetInstanceVersionId;
	}

	public void setAssetInstanceVersionId(Long assetInstanceVersionId) {
		this.assetInstanceVersionId = assetInstanceVersionId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetInstanceName() {
		return assetInstanceName;
	}

	public void setAssetInstanceName(String assetInstanceName) {
		this.assetInstanceName = assetInstanceName;
	}

	public Long getAssetInstanceId() {
		return assetInstanceId;
	}

	public void setAssetInstanceId(Long assetInstanceId) {
		this.assetInstanceId = assetInstanceId;
	}

	public String getVersionable() {
		return versionable;
	}

	public void setVersionable(String versionable) {
		this.versionable = versionable;
	}

	public Long getFwdRelationId() {
		return fwdRelationId;
	}

	public void setFwdRelationId(Long fwdRelationId) {
		this.fwdRelationId = fwdRelationId;
	}

	public Long getBwdRelationId() {
		return bwdRelationId;
	}

	public void setBwdRelationId(Long bwdRelationId) {
		this.bwdRelationId = bwdRelationId;
	}

	public String getDescrption() {
		return descrption;
	}

	public void setDescrption(String descrption) {
		this.descrption = descrption;
	}

	public String getVersionName() {
		return versionName;
	}

	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}

	public Long getAssetrelationShipId() {
		return assetrelationShipId;
	}

	public void setAssetrelationShipId(Long assetrelationShipId) {
		this.assetrelationShipId = assetrelationShipId;
	}

	public String getSrcAssetName() {
		return srcAssetName;
	}

	public void setSrcAssetName(String srcAssetName) {
		this.srcAssetName = srcAssetName;
	}

	public Long getSrcAssetId() {
		return srcAssetId;
	}

	public void setSrcAssetId(Long srcAssetId) {
		this.srcAssetId = srcAssetId;
	}

	public String getSourceInstanceName() {
		return sourceInstanceName;
	}

	public void setSourceInstanceName(String sourceInstanceName) {
		this.sourceInstanceName = sourceInstanceName;
	}

	public String getSourceVersionName() {
		return sourceVersionName;
	}

	public void setSourceVersionName(String sourceVersionName) {
		this.sourceVersionName = sourceVersionName;
	}

	public String getSourceDescription() {
		return sourceDescription;
	}

	public void setSourceDescription(String sourceDescription) {
		this.sourceDescription = sourceDescription;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRelationShipName() {
		return relationShipName;
	}

	public void setRelationShipName(String relationShipName) {
		this.relationShipName = relationShipName;
	}

	public String getDestAssetName() {
		return destAssetName;
	}

	public void setDestAssetName(String destAssetName) {
		this.destAssetName = destAssetName;
	}

	public Long getDestAssetId() {
		return destAssetId;
	}

	public void setDestAssetId(Long destAssetId) {
		this.destAssetId = destAssetId;
	}

	public String getDestInstanceName() {
		return destInstanceName;
	}

	public void setDestInstanceName(String destInstanceName) {
		this.destInstanceName = destInstanceName;
	}

	public String getDestInstanceVersionName() {
		return destInstanceVersionName;
	}

	public void setDestInstanceVersionName(String destInstanceVersionName) {
		this.destInstanceVersionName = destInstanceVersionName;
	}

	public String getDestdescription() {
		return destdescription;
	}

	public void setDestdescription(String destdescription) {
		this.destdescription = destdescription;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	@Override
	public String toString() {
		return "AssetInstRelationship [assetInstRelId=" + assetInstRelId
				+ ", srcAssetInstVersionId=" + srcAssetInstVersionId
				+ ", destAssetInstVersionId=" + destAssetInstVersionId
				+ ", assetRelId=" + assetRelId + ", assetInstanceVersionId="
				+ assetInstanceVersionId + ", assetName=" + assetName
				+ ", assetInstanceName=" + assetInstanceName
				+ ", assetInstanceId=" + assetInstanceId + ", versionable="
				+ versionable + ", fwdRelationId=" + fwdRelationId
				+ ", bwdRelationId=" + bwdRelationId + ", descrption="
				+ descrption + ", versionName=" + versionName
				+ ", assetrelationShipId=" + assetrelationShipId
				+ ", srcAssetName=" + srcAssetName + ", srcAssetId="
				+ srcAssetId + ", sourceInstanceName=" + sourceInstanceName
				+ ", sourceVersionName=" + sourceVersionName
				+ ", sourceDescription=" + sourceDescription + ", type=" + type
				+ ", relationShipName=" + relationShipName + ", destAssetName="
				+ destAssetName + ", destAssetId=" + destAssetId
				+ ", destInstanceName=" + destInstanceName
				+ ", destInstanceVersionName=" + destInstanceVersionName
				+ ", destdescription=" + destdescription + ", assetId="
				+ assetId + ", action=" + action + "]";
	}

}
