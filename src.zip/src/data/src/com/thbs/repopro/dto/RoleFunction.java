package com.thbs.repopro.dto;

import java.util.List;

public class RoleFunction {
private Long roleId;
private Long functionId;
private Long roleFunctionId;
private List<String> associateFunctionIds;

public Long getRoleId() {
	return roleId;
}
public void setRoleId(Long roleId) {
	this.roleId = roleId;
}
public Long getFunctionId() {
	return functionId;
}
public void setFunctionId(Long functionId) {
	this.functionId = functionId;
}
public Long getRoleFunctionId() {
	return roleFunctionId;
}
public void setRoleFunctionId(Long roleFunctionId) {
	this.roleFunctionId = roleFunctionId;
}

public List<String> getAssociateFunctionIds() {
	return associateFunctionIds;
}
public void setAssociateFunctionIds(List<String> associateFunctionIds) {
	this.associateFunctionIds = associateFunctionIds;
}
@Override
public String toString() {
	return "RoleFunction [roleId=" + roleId + ", functionId=" + functionId
			+ ", roleFunctionId=" + roleFunctionId + ", associateFunctionIds="
			+ associateFunctionIds + "]";
}


}
