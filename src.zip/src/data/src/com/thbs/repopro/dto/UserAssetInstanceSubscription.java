package com.thbs.repopro.dto;

public class UserAssetInstanceSubscription {

	private Long subscriptionId;// id
	private Long userId;// user_id
	private Long assetInstanceId;// asset_instance_id
	private String assetInstanceName;
	private String subscriptionFlag;
	private String iconImageName;
	
	public String getIconImageName() {
		return iconImageName;
	}

	public void setIconImageName(String iconImageName) {
		this.iconImageName = iconImageName;
	}

	public Long getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(Long subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getAssetInstanceId() {
		return assetInstanceId;
	}

	public void setAssetInstanceId(Long assetInstanceId) {
		this.assetInstanceId = assetInstanceId;
	}

	public String getAssetInstanceName() {
		return assetInstanceName;
	}

	public void setAssetInstanceName(String assetInstanceName) {
		this.assetInstanceName = assetInstanceName;
	}

	public String getSubscriptionFlag() {
		return subscriptionFlag;
	}

	public void setSubscriptionFlag(String subscriptionFlag) {
		this.subscriptionFlag = subscriptionFlag;
	}

	@Override
	public String toString() {
		return "UserAssetInstanceSubscription [subscriptionId="
				+ subscriptionId + ", userId=" + userId + ", assetInstanceId="
				+ assetInstanceId + ", assetInstanceName=" + assetInstanceName
				+ ", subscriptionFlag=" + subscriptionFlag + ", iconImageName="
				+ iconImageName + "]";
	}

}
