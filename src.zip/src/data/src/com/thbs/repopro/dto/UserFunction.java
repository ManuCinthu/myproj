package com.thbs.repopro.dto;

public class UserFunction {
private Long functionId;
private String functionName;
private String functionDescription;
private boolean isMappedWithRole;
private boolean instanceCreation;
private boolean adminFlag;


public boolean isInstanceCreation() {
	return instanceCreation;
}
public void setInstanceCreation(boolean instanceCreation) {
	this.instanceCreation = instanceCreation;
}
public Long getFunctionId() {
	return functionId;
}
public void setFunctionId(Long functionId) {
	this.functionId = functionId;
}
public String getFunctionName() {
	return functionName;
}
public void setFunctionName(String functionName) {
	this.functionName = functionName;
}
public String getFunctionDescription() {
	return functionDescription;
}
public void setFunctionDescription(String functionDescription) {
	this.functionDescription = functionDescription;
}
public boolean isMappedWithRole() {
	return isMappedWithRole;
}
public void setMappedWithRole(boolean isMappedWithRole) {
	this.isMappedWithRole = isMappedWithRole;
}
public boolean isAdminFlag() {
	return adminFlag;
}
public void setAdminFlag(boolean adminFlag) {
	this.adminFlag = adminFlag;
}
@Override
public String toString() {
	return "UserFunction [functionId=" + functionId + ", functionName=" + functionName + ", functionDescription="
			+ functionDescription + ", isMappedWithRole=" + isMappedWithRole + ", instanceCreation=" + instanceCreation
			+ ", adminFlag=" + adminFlag + "]";
}



}
