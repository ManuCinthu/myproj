package com.thbs.repopro.dto;

public class AssetInstDescSuccess {
	
	private String parentAssetName;
	
	private String parentAssetInstanceName;
	
	private String assetType;
	
	private String assetInstName;
	
	private String versionName;
	
	private Long assetInstanceVersionId;
	
	private String assetInstanceDescription;
	
	private boolean descriptionChecker;
	
	
	/**
	 * @return the assetInstanceDescription
	 */
	public String getAssetInstanceDescription() {
		return assetInstanceDescription;
	}
	/**
	 * @param assetInstanceDescription the assetInstanceDescription to set
	 */
	public void setAssetInstanceDescription(String assetInstanceDescription) {
		this.assetInstanceDescription = assetInstanceDescription;
	}
	/**
	 * @return the descriptionChecker
	 */
	public boolean isDescriptionChecker() {
		return descriptionChecker;
	}
	/**
	 * @param descriptionChecker the descriptionChecker to set
	 */
	public void setDescriptionChecker(boolean descriptionChecker) {
		this.descriptionChecker = descriptionChecker;
	}
	/**
	 * @return the parentAssetName
	 */
	public String getParentAssetName() {
		return parentAssetName;
	}
	/**
	 * @param parentAssetName the parentAssetName to set
	 */
	public void setParentAssetName(String parentAssetName) {
		this.parentAssetName = parentAssetName;
	}
	/**
	 * @return the parentAssetInstanceName
	 */
	public String getParentAssetInstanceName() {
		return parentAssetInstanceName;
	}
	/**
	 * @param parentAssetInstanceName the parentAssetInstanceName to set
	 */
	public void setParentAssetInstanceName(String parentAssetInstanceName) {
		this.parentAssetInstanceName = parentAssetInstanceName;
	}
	/**
	 * @return the assetType
	 */
	public String getAssetType() {
		return assetType;
	}
	/**
	 * @param assetType the assetType to set
	 */
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	/**
	 * @return the assetInstName
	 */
	public String getAssetInstName() {
		return assetInstName;
	}
	/**
	 * @param assetInstName the assetInstName to set
	 */
	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}
	/**
	 * @return the versionName
	 */
	public String getVersionName() {
		return versionName;
	}
	/**
	 * @param versionName the versionName to set
	 */
	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}
	/**
	 * @return the assetInstanceVersionId
	 */
	public Long getAssetInstanceVersionId() {
		return assetInstanceVersionId;
	}
	/**
	 * @param assetInstanceVersionId the assetInstanceVersionId to set
	 */
	public void setAssetInstanceVersionId(Long assetInstanceVersionId) {
		this.assetInstanceVersionId = assetInstanceVersionId;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AssetInstDescSuccess [parentAssetName=" + parentAssetName + ", parentAssetInstanceName="
				+ parentAssetInstanceName + ", assetType=" + assetType + ", assetInstName=" + assetInstName
				+ ", versionName=" + versionName + ", assetInstanceVersionId=" + assetInstanceVersionId
				+ ", assetInstanceDescription=" + assetInstanceDescription + ", descriptionChecker="
				+ descriptionChecker + "]";
	}
	
	

}
