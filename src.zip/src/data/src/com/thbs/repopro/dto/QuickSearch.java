package com.thbs.repopro.dto;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class QuickSearch implements Comparator<QuickSearch> {

	private static AtomicInteger atomicInteger = new AtomicInteger();
	private String searchBy;

	private Long assetId;
	private String assetName;
	private String assetDescription;

	private Long assetInstId;
	private String assetInstName;
	private String assetInstDescription;
	private Long assetInstVersionId;
	private String versionName;
	private boolean versionable;

	private Long taxonomyId;
	private String taxonomyName;

	private Long tagId;
	private String tagName;

	private Long assetParamId;
	private String assetParamName;
	private Long paramTypeId;
	private String paramValue;
	private String fileName;

	private Long userId;
	private String userName;
	private String fullName;
	private String emailId;
	private String department;
	private String imageName;

	private HashMap<String, String> userMap;
	private HashMap<String, String> assetMap;
	private HashMap<String, String> assetInstanceMap;
	private HashMap<String, String> parameterMap;
	private HashMap<String, Object> paramMap;
	private HashMap<Long, Object> taxonomyMap;
	private HashMap<Long, Object> taggingMap;
	
	private List<String> textValues;
	private List<String> paramValues;
	private List<String> taxValues;
	private List<String> tagValues;
	private List<String> dateValues;
	private List<String> fileValues;
	private List<String> ldapMappingValues;
	
	private int encryptFullName;
	private int encryptEmailId;
	private int encryptDepartment;
	private int encryptImage;
	
	private String decryptedFullName;
	private String decryptedEmailId;
	private String decryptedDept;
	
	public QuickSearch updateMissingAttributes(QuickSearch quickSearch) {

		if (this.assetId == null) {
			this.assetId = quickSearch.getAssetId();
		}
		if (this.assetName == null) {
			this.assetName = quickSearch.getAssetName();
		}
		if (this.assetDescription == null) {
			this.assetDescription = quickSearch.getAssetDescription();
		}

		if (this.assetInstId == null) {
			this.assetInstId = quickSearch.getAssetInstId();
		}
		if (this.assetInstName == null) {
			this.assetInstName = quickSearch.getAssetInstName();
		}
		if (this.assetInstDescription == null) {
			this.assetInstDescription = quickSearch.getAssetInstDescription();
		}
		if (this.assetInstVersionId == null) {
			this.assetInstVersionId = quickSearch.getAssetInstVersionId();
		}
		if (this.versionName == null) {
			this.versionName = quickSearch.getVersionName();
		}
		if (this.taxonomyName == null) {
			this.taxonomyName = quickSearch.getTaxonomyName();
		}

		if (this.assetParamId == null) {
			this.assetParamId = quickSearch.getAssetParamId();
		}
		if (this.assetParamName == null) {
			this.assetParamName = quickSearch.getAssetParamName();
		}
		if (this.paramTypeId == null) {
			this.paramTypeId = quickSearch.getParamTypeId();
		}
		if (this.paramValue == null) {
			this.paramValue = quickSearch.getParamValue();
		}
		if (this.fileName == null) {
			this.fileName = quickSearch.getFileName();
		}

		if (this.userId == null) {
			this.userId = quickSearch.getUserId();
		}
		if (this.userName == null) {
			this.userName = quickSearch.getUserName();
		}
		if (this.fullName == null) {
			this.fullName = quickSearch.getFullName();
		}
		if (this.emailId == null) {
			this.emailId = quickSearch.getEmailId();
		}
		if (this.department == null) {
			this.department = quickSearch.getDepartment();
		}

		if (this.userMap == null) {
			this.userMap = quickSearch.getUserMap();
		}
		if (this.assetMap == null) {
			this.assetMap = quickSearch.getAssetMap();
		}
		if (this.assetInstanceMap == null) {
			this.assetInstanceMap = quickSearch.getAssetInstanceMap();
		}
		if (this.parameterMap == null) {
			this.parameterMap = quickSearch.getParameterMap();
		}
		if (this.paramMap == null && quickSearch.getParamMap()!=null) {
			this.paramMap = new HashMap<String, Object>();
			this.paramMap.putAll(quickSearch.getParamMap());
		}
		
		if (this.taxonomyMap == null && quickSearch.getTaxonomyMap() != null) {
			this.taxonomyMap = new HashMap<Long, Object>();
			this.taxonomyMap.putAll(quickSearch.getTaxonomyMap());
		}
		if (this.taggingMap == null && quickSearch.getTaggingMap() != null) {
			this.taggingMap = new HashMap<Long, Object>() ;
			this.taggingMap.putAll(quickSearch.getTaggingMap());
		}
		
		if (this.textValues == null && quickSearch.getTextValues() != null) {
			this.textValues = new ArrayList<String>();
			this.textValues.addAll(quickSearch.getTextValues());
		}
		if(this.paramValues == null && quickSearch.getParamValues()!=null){
			this.paramValues = new ArrayList<String>();
			this.paramValues.addAll(quickSearch.getParamValues());
		}
		if(this.taxValues == null && quickSearch.getTaxValues()!=null){
			this.taxValues = new ArrayList<String>();
			this.taxValues.addAll(quickSearch.getTaxValues());
		}
		if(this.tagValues == null && quickSearch.getTagValues()!=null){
			this.tagValues = new ArrayList<String>();
			this.tagValues.addAll(quickSearch.getTagValues());
		}
		if(this.dateValues == null && quickSearch.getDateValues()!=null){
			this.dateValues = new ArrayList<String>();
			this.dateValues.addAll(quickSearch.getDateValues());
		}
		if(this.fileValues == null && quickSearch.getFileValues()!=null){
			this.fileValues = new ArrayList<String>();
			this.fileValues.addAll(quickSearch.getFileValues());
		}
		if (this.ldapMappingValues == null && quickSearch.getLdapMappingValues() != null) {
			this.ldapMappingValues = new ArrayList<String>();
			this.ldapMappingValues.addAll(quickSearch.getLdapMappingValues());
		}
		return this;
	}

	public String getSearchBy() {
		return searchBy;
	}

	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetDescription() {
		return assetDescription;
	}

	public void setAssetDescription(String assetDescription) {
		this.assetDescription = assetDescription;
	}

	public Long getAssetInstId() {
		return assetInstId;
	}

	public void setAssetInstId(Long assetInstId) {
		this.assetInstId = assetInstId;
	}

	public String getAssetInstName() {
		return assetInstName;
	}

	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}

	public String getAssetInstDescription() {
		return assetInstDescription;
	}

	public void setAssetInstDescription(String assetInstDescription) {
		this.assetInstDescription = assetInstDescription;
	}

	public Long getAssetInstVersionId() {
		return assetInstVersionId;
	}

	public void setAssetInstVersionId(Long assetInstVersionId) {
		this.assetInstVersionId = assetInstVersionId;
	}

	public String getVersionName() {
		return versionName;
	}

	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}

	public boolean isVersionable() {
		return versionable;
	}

	public void setVersionable(boolean versionable) {
		this.versionable = versionable;
	}

	public Long getTaxonomyId() {
		return taxonomyId;
	}

	public void setTaxonomyId(Long taxonomyId) {
		this.taxonomyId = taxonomyId;
	}

	public String getTaxonomyName() {
		return taxonomyName;
	}

	public void setTaxonomyName(String taxonomyName) {
		this.taxonomyName = taxonomyName;
	}

	public Long getTagId() {
		return tagId;
	}

	public void setTagId(Long tagId) {
		this.tagId = tagId;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public Long getAssetParamId() {
		return assetParamId;
	}

	public void setAssetParamId(Long assetParamId) {
		this.assetParamId = assetParamId;
	}

	public String getAssetParamName() {
		return assetParamName;
	}

	public void setAssetParamName(String assetParamName) {
		this.assetParamName = assetParamName;
	}

	public Long getParamTypeId() {
		return paramTypeId;
	}

	public void setParamTypeId(Long paramTypeId) {
		this.paramTypeId = paramTypeId;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public HashMap<String, String> getUserMap() {
		return userMap;
	}

	public void setUserMap(HashMap<String, String> userMap) {
		this.userMap = userMap;
	}

	public HashMap<String, String> getAssetMap() {
		return assetMap;
	}

	public void setAssetMap(HashMap<String, String> assetMap) {
		this.assetMap = assetMap;
	}

	public HashMap<String, String> getAssetInstanceMap() {
		return assetInstanceMap;
	}

	public void setAssetInstanceMap(HashMap<String, String> assetInstanceMap) {
		this.assetInstanceMap = assetInstanceMap;
	}

	public HashMap<String, String> getParameterMap() {
		return parameterMap;
	}

	public void setParameterMap(HashMap<String, String> parameterMap) {
		this.parameterMap = parameterMap;
	}

	public HashMap<String, Object> getParamMap() {
		return paramMap;
	}

	public void setParamMap(HashMap<String, Object> paramMap) {
		this.paramMap = paramMap;
	}

	public HashMap<Long, Object> getTaxonomyMap() {
		return taxonomyMap;
	}

	public void setTaxonomyMap(Map<Long, Object> taxonomyValues) {
		this.taxonomyMap = (HashMap<Long, Object>) taxonomyValues;
	}

	public HashMap<Long, Object> getTaggingMap() {
		return taggingMap;
	}

	public void setTaggingMap(Map<Long, Object> taggingValues) {
		this.taggingMap = (HashMap<Long, Object>) taggingValues;
	}

	public List<String> getTextValues() {
		return textValues;
	}

	public void setTextValues(List<String> textValues) {
		this.textValues = textValues;
	}

	public List<String> getParamValues() {
		return paramValues;
	}

	public void setParamValues(List<String> paramValues) {
		this.paramValues = paramValues;
	}

	public List<String> getTaxValues() {
		return taxValues;
	}

	public void setTaxValues(List<String> taxValues) {
		this.taxValues = taxValues;
	}

	public List<String> getTagValues() {
		return tagValues;
	}

	public void setTagValues(List<String> tagValues) {
		this.tagValues = tagValues;
	}

	public List<String> getDateValues() {
		return dateValues;
	}

	public void setDateValues(List<String> dateValues) {
		this.dateValues = dateValues;
	}

	public List<String> getFileValues() {
		return fileValues;
	}

	public void setFileValues(List<String> fileValues) {
		this.fileValues = fileValues;
	}

	public List<String> getLdapMappingValues() {
		return ldapMappingValues;
	}

	public void setLdapMappingValues(List<String> ldapMappingValues) {
		this.ldapMappingValues = ldapMappingValues;
	}

	public int getEncryptFullName() {
		return encryptFullName;
	}

	public void setEncryptFullName(int encryptFullName) {
		this.encryptFullName = encryptFullName;
	}

	public int getEncryptEmailId() {
		return encryptEmailId;
	}

	public void setEncryptEmailId(int encryptEmailId) {
		this.encryptEmailId = encryptEmailId;
	}

	public int getEncryptDepartment() {
		return encryptDepartment;
	}

	public void setEncryptDepartment(int encryptDepartment) {
		this.encryptDepartment = encryptDepartment;
	}

	public int getEncryptImage() {
		return encryptImage;
	}

	public void setEncryptImage(int encryptImage) {
		this.encryptImage = encryptImage;
	}
	
	public String getDecryptedFullName() {
		return decryptedFullName;
	}

	public void setDecryptedFullName(String decryptedFullName) {
		this.decryptedFullName = decryptedFullName;
	}

	public String getDecryptedEmailId() {
		return decryptedEmailId;
	}

	public void setDecryptedEmailId(String decryptedEmailId) {
		this.decryptedEmailId = decryptedEmailId;
	}

	public String getDecryptedDept() {
		return decryptedDept;
	}

	public void setDecryptedDept(String decryptedDept) {
		this.decryptedDept = decryptedDept;
	}

	@Override
	public String toString() {
		return "QuickSearch [searchBy=" + searchBy + ", assetId=" + assetId + ", assetName=" + assetName
				+ ", assetDescription=" + assetDescription + ", assetInstId=" + assetInstId + ", assetInstName="
				+ assetInstName + ", assetInstDescription=" + assetInstDescription + ", assetInstVersionId="
				+ assetInstVersionId + ", versionName=" + versionName + ", versionable=" + versionable + ", taxonomyId="
				+ taxonomyId + ", taxonomyName=" + taxonomyName + ", tagId=" + tagId + ", tagName=" + tagName
				+ ", assetParamId=" + assetParamId + ", assetParamName=" + assetParamName + ", paramTypeId="
				+ paramTypeId + ", paramValue=" + paramValue + ", fileName=" + fileName + ", userId=" + userId
				+ ", userName=" + userName + ", fullName=" + fullName + ", emailId=" + emailId + ", department="
				+ department + ", imageName=" + imageName + ", userMap=" + userMap + ", assetMap=" + assetMap
				+ ", assetInstanceMap=" + assetInstanceMap + ", parameterMap=" + parameterMap + ", paramMap=" + paramMap
				+ ", taxonomyMap=" + taxonomyMap + ", taggingMap=" + taggingMap + ", textValues=" + textValues
				+ ", paramValues=" + paramValues + ", taxValues=" + taxValues + ", tagValues=" + tagValues
				+ ", dateValues=" + dateValues + ", fileValues=" + fileValues + ", ldapMappingValues="
				+ ldapMappingValues + ", encryptFullName=" + encryptFullName + ", encryptEmailId=" + encryptEmailId
				+ ", encryptDepartment=" + encryptDepartment + ", encryptImage=" + encryptImage + ", decryptedFullName="
				+ decryptedFullName + ", decryptedEmailId=" + decryptedEmailId + ", decryptedDept=" + decryptedDept
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((assetInstVersionId == null) ? getAtomicNumber() : assetInstVersionId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuickSearch other = (QuickSearch) obj;
		boolean equalsFlag = true;
		
		if(assetInstVersionId !=null && other.assetInstVersionId !=null){
			
			if(assetInstVersionId.equals(other.assetInstVersionId)){
				return true;
			}else{
				return false;
			}
		}else{

			if (assetInstVersionId == null) {
				if (other.assetInstVersionId != null)
					return false;
			} else{
				if (other.assetInstVersionId == null)
					return false;
			}
			
			if (taxonomyId == null) {
				if (other.taxonomyId != null){
					equalsFlag = equalsFlag && false;
					return equalsFlag;
				}
					
			} else if (!taxonomyId.equals(other.taxonomyId)){
				equalsFlag = equalsFlag && false;
				return equalsFlag;
			}
				
			if (userId == null) {
				if (other.userId != null){
					equalsFlag = equalsFlag && false;
					return equalsFlag;
				}
					
			} else if (!userId.equals(other.userId)){
				equalsFlag = equalsFlag && false;
				return equalsFlag;
			}
				

			if (assetId == null) {
				if (other.assetId != null){
					equalsFlag = equalsFlag && false;
					return equalsFlag;
				}
					
			} else if (!assetId.equals(other.assetId)){
				equalsFlag = equalsFlag && false;
				return equalsFlag;
			}
				
			return equalsFlag;
		}
		
	}


	@Override
	public int compare(QuickSearch o1, QuickSearch o2) {
		return o1.getAssetInstName().toLowerCase().compareTo(o2.getAssetInstName().toLowerCase());
	}

	public int getAtomicNumber() {
		int i = atomicInteger.incrementAndGet();
		return i;
	}

}
