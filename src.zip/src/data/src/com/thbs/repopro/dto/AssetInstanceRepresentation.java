package com.thbs.repopro.dto;

public class AssetInstanceRepresentation {

	private Long assetInstanceRepresentationId;
	private Long assetInstanceId;
	private Long assetInstanceVersionId;
	private String uploadedFileName;
	private String ipAddress;
	
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public Long getAssetInstanceRepresentationId() {
		return assetInstanceRepresentationId;
	}
	public void setAssetInstanceRepresentationId(Long assetInstanceRepresentationId) {
		this.assetInstanceRepresentationId = assetInstanceRepresentationId;
	}
	public Long getAssetInstanceId() {
		return assetInstanceId;
	}
	public void setAssetInstanceId(Long assetInstanceId) {
		this.assetInstanceId = assetInstanceId;
	}
	public Long getAssetInstanceVersionId() {
		return assetInstanceVersionId;
	}
	public void setAssetInstanceVersionId(Long assetInstanceVersionId) {
		this.assetInstanceVersionId = assetInstanceVersionId;
	}
	public String getUploadedFileName() {
		return uploadedFileName;
	}
	public void setUploadedFileName(String uploadedFileName) {
		this.uploadedFileName = uploadedFileName;
	}
	public String getUploadedFilePath() {
		return uploadedFilePath;
	}
	public void setUploadedFilePath(String uploadedFilePath) {
		this.uploadedFilePath = uploadedFilePath;
	}
	private String uploadedFilePath;
	
}
