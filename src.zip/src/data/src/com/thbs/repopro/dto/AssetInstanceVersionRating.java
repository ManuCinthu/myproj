package com.thbs.repopro.dto;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class AssetInstanceVersionRating {

	private Long ratingId;
	private Long assetInstanceVersionId;
	private int rating;
	private String username;
	private Timestamp date;
	private String ratingDescription;
	private double avgRating;
	/**added to get assetInstanceVersionId by names*/
	private String assetName;
	private String assetInstName;
	private String assetVersionName;
	private Long userId;
	private String imageName;
	private int count;
	private int totalCount;
	private int encryptImage;

	private boolean destAccessFlag;
	private List<AssetInstanceVersion> aivDetailsList;
	private List<AssetInstanceVersion> lockUnlockStatus;
	private List<AssetInstanceVersionRating> aivRatingList;
	private List<AssetRelationshipDef> AssetRelDefList;
	private List<User>customizedSectionData;
	private List<AssetInstanceVersion>childInstanceNameList;
	private List<AssetInstanceVersion>SiblingsOfChildAssetInstance;
	private List<GroupAssetInstVersionAccess>userAccessRights;
	private List<GlobalSetting>globalSetting;
	
	
	
	public List<GlobalSetting> getGlobalSetting() {
		return globalSetting;
	}

	public void setGlobalSetting(List<GlobalSetting> globalSetting) {
		this.globalSetting = globalSetting;
	}

	public List<GroupAssetInstVersionAccess> getUserAccessRights() {
		return userAccessRights;
	}

	public void setUserAccessRights(
			List<GroupAssetInstVersionAccess> userAccessRights) {
		this.userAccessRights = userAccessRights;
	}

	public List<AssetInstanceVersion> getChildInstanceNameList() {
		return childInstanceNameList;
	}

	public void setChildInstanceNameList(
			List<AssetInstanceVersion> childInstanceNameList) {
		this.childInstanceNameList = childInstanceNameList;
	}

	public List<AssetInstanceVersion> getSiblingsOfChildAssetInstance() {
		return SiblingsOfChildAssetInstance;
	}

	public void setSiblingsOfChildAssetInstance(
			List<AssetInstanceVersion> siblingsOfChildAssetInstance) {
		SiblingsOfChildAssetInstance = siblingsOfChildAssetInstance;
	}

	public List<User> getCustomizedSectionData() {
		return customizedSectionData;
	}

	public void setCustomizedSectionData(List<User> customizedSectionData) {
		this.customizedSectionData = customizedSectionData;
	}

	public List<AssetInstanceVersion> getLockUnlockStatus() {
		return lockUnlockStatus;
	}

	public void setLockUnlockStatus(List<AssetInstanceVersion> lockUnlockStatus) {
		this.lockUnlockStatus = lockUnlockStatus;
	}

	public boolean isDestAccessFlag() {
		return destAccessFlag;
	}

	public void setDestAccessFlag(boolean destAccessFlag) {
		this.destAccessFlag = destAccessFlag;
	}

	

	public List<AssetInstanceVersion> getAivDetailsList() {
		return aivDetailsList;
	}

	public void setAivDetailsList(List<AssetInstanceVersion> aivDetailsList) {
		this.aivDetailsList = aivDetailsList;
	}

	public List<AssetInstanceVersionRating> getAivRatingList() {
		return aivRatingList;
	}

	public void setAivRatingList(List<AssetInstanceVersionRating> aivRatingList) {
		this.aivRatingList = aivRatingList;
	}

	public List<AssetRelationshipDef> getAssetRelDefList() {
		return AssetRelDefList;
	}

	public void setAssetRelDefList(List<AssetRelationshipDef> assetRelDefList) {
		AssetRelDefList = assetRelDefList;
	}

	public Long getRatingId() {
		return ratingId;
	}

	public void setRatingId(Long ratingId) {
		this.ratingId = ratingId;
	}

	public Long getAssetInstanceVersionId() {
		return assetInstanceVersionId;
	}

	public void setAssetInstanceVersionId(Long assetInstanceVersionId) {
		this.assetInstanceVersionId = assetInstanceVersionId;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public String getRatingDescription() {
		return ratingDescription;
	}

	public void setRatingDescription(String ratingDescription) {
		this.ratingDescription = ratingDescription;
	}

	public double getAvgRating() {
		return avgRating;
	}

	public void setAvgRating(double avgRating) {
		this.avgRating = avgRating;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getEncryptImage() {
		return encryptImage;
	}

	public void setEncryptImage(int encryptImage) {
		this.encryptImage = encryptImage;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetInstName() {
		return assetInstName;
	}

	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}

	public String getAssetVersionName() {
		return assetVersionName;
	}

	public void setAssetVersionName(String assetVersionName) {
		this.assetVersionName = assetVersionName;
	}

	@Override
	public String toString() {
		return "AssetInstanceVersionRating [ratingId=" + ratingId + ", assetInstanceVersionId=" + assetInstanceVersionId
				+ ", rating=" + rating + ", username=" + username + ", date=" + date + ", ratingDescription="
				+ ratingDescription + ", avgRating=" + avgRating + ", assetName=" + assetName + ", assetInstName="
				+ assetInstName + ", assetVersionName=" + assetVersionName + ", userId=" + userId + ", imageName="
				+ imageName + ", count=" + count + ", totalCount=" + totalCount + ", encryptImage=" + encryptImage
				+ ", destAccessFlag=" + destAccessFlag + ", aivDetailsList=" + aivDetailsList + ", lockUnlockStatus="
				+ lockUnlockStatus + ", aivRatingList=" + aivRatingList + ", AssetRelDefList=" + AssetRelDefList
				+ ", customizedSectionData=" + customizedSectionData + ", childInstanceNameList="
				+ childInstanceNameList + ", SiblingsOfChildAssetInstance=" + SiblingsOfChildAssetInstance
				+ ", userAccessRights=" + userAccessRights + ", globalSetting=" + globalSetting + "]";
	}

}
