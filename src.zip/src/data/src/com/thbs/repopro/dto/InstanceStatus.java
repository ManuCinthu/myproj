package com.thbs.repopro.dto;

import java.util.Arrays;

public class InstanceStatus {
	
	private String instanceState;
	private Long[] next;
	private String blockId;
	private String nodetype;
	private int positionX;
	private int positionY;
	private String[] connectingSourceId;
	private String[] connectingTargetId;
	
	public String getInstanceState() {
		return instanceState;
	}
	
	public void setInstanceState(String instanceState) {
		this.instanceState = instanceState;
	}
	
	public Long[] getNext() {
		return next;
	}
	
	public void setNext(Long[] next) {
		this.next = next;
	}

	public String getBlockId() {
		return blockId;
	}

	public void setBlockId(String blockId) {
		this.blockId = blockId;
	}

	public String getNodetype() {
		return nodetype;
	}

	public void setNodetype(String nodetype) {
		this.nodetype = nodetype;
	}

	public int getPositionX() {
		return positionX;
	}

	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}

	public int getPositionY() {
		return positionY;
	}

	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}

	public String[] getConnectingSourceId() {
		return connectingSourceId;
	}

	public void setConnectingSourceId(String[] connectingSourceId) {
		this.connectingSourceId = connectingSourceId;
	}

	public String[] getConnectingTargetId() {
		return connectingTargetId;
	}

	public void setConnectingTargetId(String[] connectingTargetId) {
		this.connectingTargetId = connectingTargetId;
	}

	@Override
	public String toString() {
		return "InstanceStatus [instanceState=" + instanceState + ", next=" + Arrays.toString(next) + ", blockId="
				+ blockId + ", nodetype=" + nodetype + ", positionX=" + positionX + ", positionY=" + positionY
				+ ", connectingSourceId=" + Arrays.toString(connectingSourceId) + ", connectingTargetId="
				+ Arrays.toString(connectingTargetId) + "]";
	}
	
}
