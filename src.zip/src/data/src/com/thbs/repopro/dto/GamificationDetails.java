package com.thbs.repopro.dto;

import java.sql.Timestamp;
import java.util.Map;

public class GamificationDetails {
	private Long gamificationId;
	private String activityTimestamp;
	private Long userId;
	private String action;
	private String field;
	private String assetId;
	private String assetInstanceVersionId;
	private String points;
	private String instanceDetails;
	private String assetName;
	private String assetInstanceName;
	private String assetInstanceVersionName;
	private String fullName;
	private String imageName;
	private int encryptImage;
	
	private Map<String, Integer> mapPointList;
	
	public Long getGamificationId() {
		return gamificationId;
	}
	public void setGamificationId(Long gamificationId) {
		this.gamificationId = gamificationId;
	}
	public String getActivityTimestamp() {
		return activityTimestamp;
	}
	public void setActivityTimestamp(String activityTimestamp) {
		this.activityTimestamp = activityTimestamp;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getAssetId() {
		return assetId;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	public String getAssetInstanceVersionId() {
		return assetInstanceVersionId;
	}
	public void setAssetInstanceVersionId(String assetInstanceVersionId) {
		this.assetInstanceVersionId = assetInstanceVersionId;
	}
	public String getPoints() {
		return points;
	}
	public void setPoints(String points) {
		this.points = points;
	}
	public String getInstanceDetails() {
		return instanceDetails;
	}
	public void setInstanceDetails(String instanceDetails) {
		this.instanceDetails = instanceDetails;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetInstanceName() {
		return assetInstanceName;
	}
	public void setAssetInstanceName(String assetInstanceName) {
		this.assetInstanceName = assetInstanceName;
	}
	public String getAssetInstanceVersionName() {
		return assetInstanceVersionName;
	}
	public void setAssetInstanceVersionName(String assetInstanceVersionName) {
		this.assetInstanceVersionName = assetInstanceVersionName;
	}
	public Map<String, Integer> getMapPointList() {
		return mapPointList;
	}
	public void setMapPointList(Map<String, Integer> mapPointList) {
		this.mapPointList = mapPointList;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public int getEncryptImage() {
		return encryptImage;
	}
	public void setEncryptImage(int encryptImage) {
		this.encryptImage = encryptImage;
	}
	@Override
	public String toString() {
		return "GamificationDetails [gamificationId=" + gamificationId + ", activityTimestamp=" + activityTimestamp
				+ ", userId=" + userId + ", action=" + action + ", field=" + field + ", assetId=" + assetId
				+ ", assetInstanceVersionId=" + assetInstanceVersionId + ", points=" + points + ", instanceDetails="
				+ instanceDetails + ", assetName=" + assetName + ", assetInstanceName=" + assetInstanceName
				+ ", assetInstanceVersionName=" + assetInstanceVersionName + ", fullName=" + fullName + ", imageName="
				+ imageName + ", encryptImage=" + encryptImage + ", mapPointList=" + mapPointList + "]";
	}
	
	
}
