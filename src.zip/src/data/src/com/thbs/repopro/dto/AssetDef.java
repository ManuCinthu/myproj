package com.thbs.repopro.dto;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AssetDef {
	private Long assetId;
	private String assetName;
	private String description;
	private InputStream iconImage;
	private InputStream invertedIconImage;
	private boolean isSystemAsset;
	private boolean versionable;
	private String iconImageName;
	private Long parentAssetId;
	private String ratingDescription;
	private boolean guestflag;
	private boolean quicksearchflag;
	private HashMap<String, String> assetMap;
	List<Category> categoryParameters;
	List<Category> categories;
	private boolean flagForAssetUsageInRule;
	private List<Map<String, Long>> groupAccessForAsset;
	private Map<Long, Set<GroupDetails>> categoriesWithAccess;
	private Map<Long, String> assetAssignedTaxonomies;
	private Long userId;
	private String userName;
	private boolean relFlag;
	private boolean isArrayFlag;
	private List<AssetParamDef> draggedPramms;
	
	private  List<AssetInstance> assetInstances;

	private boolean flagForAssetUsageInAssetListRule;
	
	private AssetRepresentation assetRepresentation;
	
	private Long workflowId;
	private boolean enableWorkflow;
	private boolean flagIfWorkflowAssigned;
	
	public AssetRepresentation getAssetRepresentation() {
		return assetRepresentation;
	}

	public void setAssetRepresentation(AssetRepresentation assetRepresentation) {
		this.assetRepresentation = assetRepresentation;
	}

	public List<AssetInstance> getAssetInstances() {
		return assetInstances;
	}

	public void setAssetInstances(List<AssetInstance> assetInstances) {
		this.assetInstances = assetInstances;
	}

	public List<AssetParamDef> getDraggedPramms() {
		return draggedPramms;
	}

	public void setDraggedPramms(List<AssetParamDef> draggedPramms) {
		this.draggedPramms = draggedPramms;
	}

	public boolean isFlagForAssetUsageInRule() {
		return flagForAssetUsageInRule;
	}

	public void setFlagForAssetUsageInRule(boolean flagForAssetUsageInRule) {
		this.flagForAssetUsageInRule = flagForAssetUsageInRule;
	}

	public List<Map<String, Long>> getGroupAccessForAsset() {
		return groupAccessForAsset;
	}

	public void setGroupAccessForAsset(
			List<Map<String, Long>> groupAccessForAsset) {
		this.groupAccessForAsset = groupAccessForAsset;
	}

	public Map<Long, Set<GroupDetails>> getCategoriesWithAccess() {
		return categoriesWithAccess;
	}

	public void setCategoriesWithAccess(Map<Long, Set<GroupDetails>> details) {
		this.categoriesWithAccess = details;
	}

	public Map<Long, String> getAssetAssignedTaxonomies() {
		return assetAssignedTaxonomies;
	}

	public void setAssetAssignedTaxonomies(
			Map<Long, String> assetAssignedTaxonomies) {
		this.assetAssignedTaxonomies = assetAssignedTaxonomies;
	}

	public String getAssetName() {
		return assetName;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public InputStream getIconImage() {
		return iconImage;
	}

	public void setIconImage(InputStream iconImage) {
		this.iconImage = iconImage;
	}

	public boolean isSystemAsset() {
		return isSystemAsset;
	}

	public void setSystemAsset(boolean isSystemAsset) {
		this.isSystemAsset = isSystemAsset;
	}

	public boolean isVersionable() {
		return versionable;
	}

	public void setVersionable(boolean versionable) {
		this.versionable = versionable;
	}

	public String getIconImageName() {
		return iconImageName;
	}

	public void setIconImageName(String iconImageName) {
		this.iconImageName = iconImageName;
	}

	public Long getParentAssetId() {
		return parentAssetId;
	}

	public void setParentAssetId(Long parentAssetId) {
		this.parentAssetId = parentAssetId;
	}

	public String getRatingDescription() {
		return ratingDescription;
	}

	public void setRatingDescription(String ratingDescription) {
		this.ratingDescription = ratingDescription;
	}

	public boolean isGuestflag() {
		return guestflag;
	}

	public void setGuestflag(boolean guestflag) {
		this.guestflag = guestflag;
	}

	public boolean isQuicksearchflag() {
		return quicksearchflag;
	}

	public void setQuicksearchflag(boolean quicksearchflag) {
		this.quicksearchflag = quicksearchflag;
	}

	public HashMap<String, String> getAssetMap() {
		return assetMap;
	}

	public void setAssetMap(HashMap<String, String> assetMap) {
		this.assetMap = assetMap;
	}

	public List<Category> getCategoryParameters() {
		return categoryParameters;
	}

	public void setCategoryParameters(List<Category> categoryParameters) {
		this.categoryParameters = categoryParameters;
	}

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public boolean isRelFlag() {
		return relFlag;
	}

	public void setRelFlag(boolean relFlag) {
		this.relFlag = relFlag;
	}

	public boolean getIsArrayFlag() {
		return isArrayFlag;
	}

	public void setIsArrayFlag(boolean isArrayFlag) {
		this.isArrayFlag = isArrayFlag;
	}

	public InputStream getInvertedIconImage() {
		return invertedIconImage;
	}

	public void setInvertedIconImage(InputStream invertedIconImage) {
		this.invertedIconImage = invertedIconImage;
	}

	public boolean isFlagForAssetUsageInAssetListRule() {
		return flagForAssetUsageInAssetListRule;
	}

	public void setFlagForAssetUsageInAssetListRule(boolean flagForAssetUsageInAssetListRule) {
		this.flagForAssetUsageInAssetListRule = flagForAssetUsageInAssetListRule;
	}

	public Long getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Long workflowId) {
		this.workflowId = workflowId;
	}

	public boolean getEnableWorkflow() {
		return enableWorkflow;
	}

	public void setEnableWorkflow(boolean enableWorkflow) {
		this.enableWorkflow = enableWorkflow;
	}

	public boolean isFlagIfWorkflowAssigned() {
		return flagIfWorkflowAssigned;
	}

	public void setFlagIfWorkflowAssigned(boolean flagIfWorkflowAssigned) {
		this.flagIfWorkflowAssigned = flagIfWorkflowAssigned;
	}

	@Override
	public String toString() {
		return "AssetDef [assetId=" + assetId + ", assetName=" + assetName + ", description=" + description
				+ ", iconImage=" + iconImage + ", invertedIconImage=" + invertedIconImage + ", isSystemAsset="
				+ isSystemAsset + ", versionable=" + versionable + ", iconImageName=" + iconImageName
				+ ", parentAssetId=" + parentAssetId + ", ratingDescription=" + ratingDescription + ", guestflag="
				+ guestflag + ", quicksearchflag=" + quicksearchflag + ", assetMap=" + assetMap
				+ ", categoryParameters=" + categoryParameters + ", categories=" + categories
				+ ", flagForAssetUsageInRule=" + flagForAssetUsageInRule + ", groupAccessForAsset="
				+ groupAccessForAsset + ", categoriesWithAccess=" + categoriesWithAccess + ", assetAssignedTaxonomies="
				+ assetAssignedTaxonomies + ", userId=" + userId + ", userName=" + userName + ", relFlag=" + relFlag
				+ ", isArrayFlag=" + isArrayFlag + ", draggedPramms=" + draggedPramms + ", assetInstances="
				+ assetInstances + ", flagForAssetUsageInAssetListRule=" + flagForAssetUsageInAssetListRule
				+ ", assetRepresentation=" + assetRepresentation + ", workflowId=" + workflowId + ", enableWorkflow="
				+ enableWorkflow + ", flagIfWorkflowAssigned=" + flagIfWorkflowAssigned + "]";
	}

}
