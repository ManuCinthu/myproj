package com.thbs.repopro.dto;

import java.io.InputStream;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class AssetParamDef implements Comparator<AssetParamDef>{

	private Long assetParamId;
	private Long assetCategoryId;
	private String assetParamName;
	private String assetCategoryName;
	private InputStream image;
	private String description;
	private Long paramTypeId;
	private Long listTypeParamTypeId;
	private Long mappedAssetId;
    private int size;
    private boolean quickLink;
	private int displayPosition;
	private boolean hasStaticValue;
	private boolean hasImportantValue;
	private boolean hasMandatoryValue;
	private boolean hasdefViewValue;
    private String staticValue;
	private boolean isSystemParam;
	private String fileName;
	private String mimetype;
	private Timestamp lastUpdatedTime;
	private Long modifyByUserId;
	private byte[] staticFileContent;
	private String paramValue;
	private String typeName;
	private String listTypeName;
	private int is_static;
	private String derivedAttributeComputation;
	private List<PossibleValues> customListValues;
	private String assetName;
	private String assetInstName;
	private String versionName;
	private String paramDisp;
	private int hasArray;
	private boolean hasArrayFlag;
	private Long assetInstVersionId;
	private int listType;
	private boolean multiSelectFlag;
	private int ldapMappingId;
	private Map<String,Integer> ldapMappingValue;
	private String derivedAssetListRule;
	private boolean flagForParameterUsageInAssetListRule;
	private boolean mappingFlag;
	private boolean notifyOnRuleValidate;
	
	public Map<String, Integer> getLdapMappingValue() {
		return ldapMappingValue;
	}
	public void setLdapMappingValue(Map<String, Integer> ldapMappingValue) {
		this.ldapMappingValue = ldapMappingValue;
	}
	public int getLdapMappingId() {
		return ldapMappingId;
	}
	public void setLdapMappingId(int ldapMappingId) {
		this.ldapMappingId = ldapMappingId;
	}
	public Long getAssetInstVersionId() {
		return assetInstVersionId;
	}
	public void setAssetInstVersionId(Long assetInstVersionId) {
		this.assetInstVersionId = assetInstVersionId;
	}
	public int getHasArray() {
		return hasArray;
	}
	public void setHasArray(int hasArray) {
		this.hasArray = hasArray;
	}
	public List<PossibleValues> getCustomListValues() {
		return customListValues;
	}
	public void setCustomListValues(List<PossibleValues> customListValues) {
		this.customListValues = customListValues;
	}
	public String getActionForParameter() {
		return actionForParameter;
	}
	public void setActionForParameter(String actionForParameter) {
		this.actionForParameter = actionForParameter;
	}
	public String getParameterAction() {
		return parameterAction;
	}
	public void setParameterAction(String parameterAction) {
		this.parameterAction = parameterAction;
	}
	private int category_disp_position;
	private int parameter_disp_position;
	
	public int getDefaultView() {
		return defaultView;
	}
	public void setDefaultView(int defaultView) {
		this.defaultView = defaultView;
	}
	private int defaultView;

	
	
	private String actionForParameter;
	private String parameterAction;
	
	
	private boolean flagForParameterUsageInRule;
	
			
	public boolean isFlagForParameterUsageInRule() {
		return flagForParameterUsageInRule;
	}
	public void setFlagForParameterUsageInRule(boolean flagForParameterUsageInRule) {
		this.flagForParameterUsageInRule = flagForParameterUsageInRule;
	}
	public String getDerivedAttributeComputation() {
		return derivedAttributeComputation;
	}
	public void setDerivedAttributeComputation(String derivedAttributeComputation) {
		this.derivedAttributeComputation = derivedAttributeComputation;
	}
	public int getIs_static() {
		return is_static;
	}
	public String getAssetCategoryName() {
		return assetCategoryName;
	}
	public void setAssetCategoryName(String assetCategoryName) {
		this.assetCategoryName = assetCategoryName;
	}
	public void setIs_static(int is_static) {
		this.is_static = is_static;
	}
	public Long getAssetParamId() {
		return assetParamId;
	}
	public void setAssetParamId(Long assetParamId) {
		this.assetParamId = assetParamId;
	}
	public Long getAssetCategoryId() {
		return assetCategoryId;
	}
	public void setAssetCategoryId(Long assetCategoryId) {
		this.assetCategoryId = assetCategoryId;
	}
	public String getAssetParamName() {
		return assetParamName;
	}
	public void setAssetParamName(String assetParamName) {
		this.assetParamName = assetParamName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getParamTypeId() {
		return paramTypeId;
	}
	public void setParamTypeId(Long paramTypeId) {
		this.paramTypeId = paramTypeId;
	}
	public Long getListTypeParamTypeId() {
		return listTypeParamTypeId;
	}
	public void setListTypeParamTypeId(Long listTypeParamTypeId) {
		this.listTypeParamTypeId = listTypeParamTypeId;
	}
	public Long getMappedAssetId() {
		return mappedAssetId;
	}
	public void setMappedAssetId(Long mappedAssetId) {
		this.mappedAssetId = mappedAssetId;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public boolean isQuickLink() {
		return quickLink;
	}
	public void setQuickLink(boolean quickLink) {
		this.quickLink = quickLink;
	}
	public int getDisplayPosition() {
		return displayPosition;
	}
	public void setDisplayPosition(int displayPosition) {
		this.displayPosition = displayPosition;
	}
	public boolean isHasStaticValue() {
		return hasStaticValue;
	}
	public void setHasStaticValue(boolean hasStaticValue) {
		this.hasStaticValue = hasStaticValue;
	}
	public boolean isHasImportantValue() {
		return hasImportantValue;
	}
	public void setHasImportantValue(boolean hasImportantValue) {
		this.hasImportantValue = hasImportantValue;
	}
	public boolean isHasdefViewValue() {
		return hasdefViewValue;
	}
	public void setHasdefViewValue(boolean hasdefViewValue) {
		this.hasdefViewValue = hasdefViewValue;
	}
	public String getStaticValue() {
		return staticValue;
	}
	public void setStaticValue(String staticValue) {
		this.staticValue = staticValue;
	}
	public boolean isSystemParam() {
		return isSystemParam;
	}
	public void setSystemParam(boolean isSystemParam) {
		this.isSystemParam = isSystemParam;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getMimetype() {
		return mimetype;
	}
	public void setMimetype(String mimetype) {
		this.mimetype = mimetype;
	}
	public Timestamp getLastUpdatedTime() {
		return lastUpdatedTime;
	}
	public void setLastUpdatedTime(Timestamp lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}
	public Long getModifyByUserId() {
		return modifyByUserId;
	}
	public void setModifyByUserId(Long modifyByUserId) {
		this.modifyByUserId = modifyByUserId;
	}
	public byte[] getStaticFileContent() {
		return staticFileContent;
	}
	public void setStaticFileContent(byte[] staticFileContent) {
		this.staticFileContent = staticFileContent;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getListTypeName() {
		return listTypeName;
	}
	public void setListTypeName(String listTypeName) {
		this.listTypeName = listTypeName;
	}
	
	
	

	public String getParamDisp() {
		return paramDisp;
	}
	public void setParamDisp(String paramDisp) {
		this.paramDisp = paramDisp;
	}
	public InputStream getImage() {
		return image;
	}
	public void setImage(InputStream image) {
		this.image = image;
	}
	
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetInstName() {
		return assetInstName;
	}
	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}
	public String getVersionName() {
		return versionName;
	}
	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}
	public int getCategory_disp_position() {
		return category_disp_position;
	}
	public void setCategory_disp_position(int category_disp_position) {
		this.category_disp_position = category_disp_position;
	}
	public int getParameter_disp_position() {
		return parameter_disp_position;
	}
	public void setParameter_disp_position(int parameter_disp_position) {
		this.parameter_disp_position = parameter_disp_position;
	}
	public boolean isHasMandatoryValue() {
		return hasMandatoryValue;
	}
	public void setHasMandatoryValue(boolean hasMandatoryValue) {
		this.hasMandatoryValue = hasMandatoryValue;
	}
	public boolean isHasArrayFlag() {
		return hasArrayFlag;
	}
	public void setHasArrayFlag(boolean hasArrayFlag) {
		this.hasArrayFlag = hasArrayFlag;
	}
	public int getListType() {
		return listType;
	}
	public void setListType(int listType) {
		this.listType = listType;
	}
	public boolean isMultiSelectFlag() {
		return multiSelectFlag;
	}
	public void setMultiSelectFlag(boolean multiSelectFlag) {
		this.multiSelectFlag = multiSelectFlag;
	}
	public String getDerivedAssetListRule() {
		return derivedAssetListRule;
	}
	public void setDerivedAssetListRule(String derivedAssetListRule) {
		this.derivedAssetListRule = derivedAssetListRule;
	}
	public boolean isFlagForParameterUsageInAssetListRule() {
		return flagForParameterUsageInAssetListRule;
	}
	public void setFlagForParameterUsageInAssetListRule(boolean flagForParameterUsageInAssetListRule) {
		this.flagForParameterUsageInAssetListRule = flagForParameterUsageInAssetListRule;
	}
	
	public boolean isMappingFlag() {
		return mappingFlag;
	}
	public void setMappingFlag(boolean mappingFlag) {
		this.mappingFlag = mappingFlag;
	}
	
	public boolean isNotifyOnRuleValidate() {
		return notifyOnRuleValidate;
	}
	public void setNotifyOnRuleValidate(boolean notifyOnRuleValidate) {
		this.notifyOnRuleValidate = notifyOnRuleValidate;
	}
	@Override
	public String toString() {
		return "AssetParamDef [assetParamId=" + assetParamId + ", assetCategoryId=" + assetCategoryId
				+ ", assetParamName=" + assetParamName + ", assetCategoryName=" + assetCategoryName + ", image=" + image
				+ ", description=" + description + ", paramTypeId=" + paramTypeId + ", listTypeParamTypeId="
				+ listTypeParamTypeId + ", mappedAssetId=" + mappedAssetId + ", size=" + size + ", quickLink="
				+ quickLink + ", displayPosition=" + displayPosition + ", hasStaticValue=" + hasStaticValue
				+ ", hasImportantValue=" + hasImportantValue + ", hasMandatoryValue=" + hasMandatoryValue
				+ ", hasdefViewValue=" + hasdefViewValue + ", staticValue=" + staticValue + ", isSystemParam="
				+ isSystemParam + ", fileName=" + fileName + ", mimetype=" + mimetype + ", lastUpdatedTime="
				+ lastUpdatedTime + ", modifyByUserId=" + modifyByUserId + ", staticFileContent="
				+ Arrays.toString(staticFileContent) + ", paramValue=" + paramValue + ", typeName=" + typeName
				+ ", listTypeName=" + listTypeName + ", is_static=" + is_static + ", derivedAttributeComputation="
				+ derivedAttributeComputation + ", customListValues=" + customListValues + ", assetName=" + assetName
				+ ", assetInstName=" + assetInstName + ", versionName=" + versionName + ", paramDisp=" + paramDisp
				+ ", hasArray=" + hasArray + ", hasArrayFlag=" + hasArrayFlag + ", assetInstVersionId="
				+ assetInstVersionId + ", listType=" + listType + ", multiSelectFlag=" + multiSelectFlag
				+ ", ldapMappingId=" + ldapMappingId + ", ldapMappingValue=" + ldapMappingValue
				+ ", derivedAssetListRule=" + derivedAssetListRule + ", flagForParameterUsageInAssetListRule="
				+ flagForParameterUsageInAssetListRule + ", mappingFlag=" + mappingFlag + ", notifyOnRuleValidate="
				+ notifyOnRuleValidate + ", category_disp_position=" + category_disp_position
				+ ", parameter_disp_position=" + parameter_disp_position + ", defaultView=" + defaultView
				+ ", actionForParameter=" + actionForParameter + ", parameterAction=" + parameterAction
				+ ", flagForParameterUsageInRule=" + flagForParameterUsageInRule + "]";
	}
	
	//@Override
	/*public int compare(AssetParamDef o1, AssetParamDef o2) {
		return o1.getAssetParamName().toLowerCase().compareTo(o2.getAssetParamName().toLowerCase());
	}*/
	@Override
	public int compare(AssetParamDef o1, AssetParamDef o2) {
		if(o1.getAssetParamName().contains("_")) {
			return o1.getAssetParamName().split("_")[0].toLowerCase().compareTo(o2.getAssetParamName().split("_")[0].toLowerCase());
		}else {
			return o1.getAssetParamName().toLowerCase().compareTo(o2.getAssetParamName().toLowerCase());
		}
	}
}
