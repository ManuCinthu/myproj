package com.thbs.repopro.dto;

import java.io.InputStream;

public class LoginColorConfiguration {

	private Long loginColorConfigurationId;
	private String loginFontColorCode;
	private String loginFrameColorCode;
	private String Primary_Buttoncolor;
	private String Primary_Button_text_color;
	private String Secondary_Buttoncolor;
	private String Secondary_Button_text_color;
	private String headingcolor;
	private String themecolor;
	private InputStream logoimage;
	private String logo_filename;
	private InputStream faviconimage;
	private String favicon_filename;
	private InputStream background_image;
	private String backgroundimg_filename;
	private InputStream loginPageLogo;
	private String loginPageLogo_filename;
	
	public Long getLoginColorConfigurationId() {
		return loginColorConfigurationId;
	}
	public void setLoginColorConfigurationId(Long loginColorConfigurationId) {
		this.loginColorConfigurationId = loginColorConfigurationId;
	}
	public String getLoginFontColorCode() {
		return loginFontColorCode;
	}
	public void setLoginFontColorCode(String loginFontColorCode) {
		this.loginFontColorCode = loginFontColorCode;
	}
	public String getLoginFrameColorCode() {
		return loginFrameColorCode;
	}
	public void setLoginFrameColorCode(String loginFrameColorCode) {
		this.loginFrameColorCode = loginFrameColorCode;
	}
	public String getPrimary_Buttoncolor() {
		return Primary_Buttoncolor;
	}
	public void setPrimary_Buttoncolor(String primary_Buttoncolor) {
		Primary_Buttoncolor = primary_Buttoncolor;
	}
	public String getPrimary_Button_text_color() {
		return Primary_Button_text_color;
	}
	public void setPrimary_Button_text_color(String primary_Button_text_color) {
		Primary_Button_text_color = primary_Button_text_color;
	}
	public String getSecondary_Buttoncolor() {
		return Secondary_Buttoncolor;
	}
	public void setSecondary_Buttoncolor(String secondary_Buttoncolor) {
		Secondary_Buttoncolor = secondary_Buttoncolor;
	}
	public String getSecondary_Button_text_color() {
		return Secondary_Button_text_color;
	}
	public void setSecondary_Button_text_color(String secondary_Button_text_color) {
		Secondary_Button_text_color = secondary_Button_text_color;
	}
	public String getHeadingcolor() {
		return headingcolor;
	}
	public void setHeadingcolor(String headingcolor) {
		this.headingcolor = headingcolor;
	}
	public String getThemecolor() {
		return themecolor;
	}
	public void setThemecolor(String themecolor) {
		this.themecolor = themecolor;
	}
	public InputStream getLogoimage() {
		return logoimage;
	}
	public void setLogoimage(InputStream logoimage) {
		this.logoimage = logoimage;
	}
	public String getLogo_filename() {
		return logo_filename;
	}
	public void setLogo_filename(String logo_filename) {
		this.logo_filename = logo_filename;
	}
	public InputStream getFaviconimage() {
		return faviconimage;
	}
	public void setFaviconimage(InputStream faviconimage) {
		this.faviconimage = faviconimage;
	}
	public String getFavicon_filename() {
		return favicon_filename;
	}
	public void setFavicon_filename(String favicon_filename) {
		this.favicon_filename = favicon_filename;
	}
	public InputStream getBackground_image() {
		return background_image;
	}
	public void setBackground_image(InputStream background_image) {
		this.background_image = background_image;
	}
	public String getBackgroundimg_filename() {
		return backgroundimg_filename;
	}
	public void setBackgroundimg_filename(String backgroundimg_filename) {
		this.backgroundimg_filename = backgroundimg_filename;
	}
	public InputStream getLoginPageLogo() {
		return loginPageLogo;
	}
	public void setLoginPageLogo(InputStream loginPageLogo) {
		this.loginPageLogo = loginPageLogo;
	}
	public String getLoginPageLogo_filename() {
		return loginPageLogo_filename;
	}
	public void setLoginPageLogo_filename(String loginPageLogo_filename) {
		this.loginPageLogo_filename = loginPageLogo_filename;
	}
	@Override
	public String toString() {
		return "LoginColorConfiguration [loginColorConfigurationId=" + loginColorConfigurationId
				+ ", loginFontColorCode=" + loginFontColorCode + ", loginFrameColorCode=" + loginFrameColorCode
				+ ", Primary_Buttoncolor=" + Primary_Buttoncolor + ", Primary_Button_text_color="
				+ Primary_Button_text_color + ", Secondary_Buttoncolor=" + Secondary_Buttoncolor
				+ ", Secondary_Button_text_color=" + Secondary_Button_text_color + ", headingcolor=" + headingcolor
				+ ", themecolor=" + themecolor + ", logoimage=" + logoimage + ", logo_filename=" + logo_filename
				+ ", faviconimage=" + faviconimage + ", favicon_filename=" + favicon_filename + ", background_image="
				+ background_image + ", backgroundimg_filename=" + backgroundimg_filename + ", loginPageLogo="
				+ loginPageLogo + ", loginPageLogo_filename=" + loginPageLogo_filename + "]";
	}
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}
}
		