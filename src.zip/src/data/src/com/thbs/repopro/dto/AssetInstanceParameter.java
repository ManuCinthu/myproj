package com.thbs.repopro.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="assetInstance")

@XmlAccessorType(XmlAccessType.FIELD)
public class AssetInstanceParameter<T>{
	private Long assetInstId;
	private Long assetId;
	private String assetInstName;
	private Integer rating;
	private int displayPosition;
	private boolean publicAccess;
	private String owner;
	private String assetName;
	private String assetInstanceDescription;
	private Long assetInstVersionId;
	private String versionName;
	private boolean versionable;
	private String assetRelationshipId;
	private String assetRelationshipName;
	private String assetRelationshipType;
	private String description;
	private String name;
	private String tagName;
	private String value;
	private String taxonomyName;
	private HashMap<String, String> assetInstanceMap;
	private Map<String, String> paramNameWithValues;
	private int showHideParamCount;
	private String newDescription;
	private String parentAssetInstName;
	private String parentAssetName;
	private String parentVersionName;
	private Long parentAssetInstVersionId;
	private Long parentAssetId;
	private String paramRevData;
	private String iconImageName;
	private Boolean editAccessFlag;
	private Boolean deleteAccessFlag;
	private Boolean addAccessFlag;
	private Boolean propertiesFlag;
	@XmlElementWrapper(name="assetInstances")
	@XmlElement(name="assetInstance",nillable=true,required=false)
	private List<AssetInstanceParameter> assetInstanceParameter;
	@XmlElement(name="categoryDetailsList")
	private List<Category> categoryDetails;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public Map<String, String> getParamNameWithValues() {
		return paramNameWithValues;
	}

	public void setParamNameWithValues(Map<String, String> paramNameWithValues) {
		this.paramNameWithValues = paramNameWithValues;
	}

	public Long getAssetInstId() {
		return assetInstId;
	}

	public void setAssetInstId(Long assetInstId) {
		this.assetInstId = assetInstId;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getAssetInstName() {
		return assetInstName;
	}

	public void setAssetInstName(String assetInstName) {
		this.assetInstName = assetInstName;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public int getDisplayPosition() {
		return displayPosition;
	}

	public void setDisplayPosition(int displayPosition) {
		this.displayPosition = displayPosition;
	}

	public boolean isPublicAccess() {
		return publicAccess;
	}

	public void setPublicAccess(boolean publicAccess) {
		this.publicAccess = publicAccess;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetInstanceDescription() {
		return assetInstanceDescription;
	}

	public void setAssetInstanceDescription(String assetInstanceDescription) {
		this.assetInstanceDescription = assetInstanceDescription;
	}

	public Long getAssetInstVersionId() {
		return assetInstVersionId;
	}

	public void setAssetInstVersionId(Long assetInstVersionId) {
		this.assetInstVersionId = assetInstVersionId;
	}

	public String getVersionName() {
		return versionName;
	}

	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}

	public HashMap<String, String> getAssetInstanceMap() {
		return assetInstanceMap;
	}

	public void setAssetInstanceMap(HashMap<String, String> assetInstanceMap) {
		this.assetInstanceMap = assetInstanceMap;
	}

	public String getAssetRelationshipId() {
		return assetRelationshipId;
	}

	public void setAssetRelationshipId(String assetRelationshipId) {
		this.assetRelationshipId = assetRelationshipId;
	}

	public String getAssetRelationshipName() {
		return assetRelationshipName;
	}

	public void setAssetRelationshipName(String assetRelationshipName) {
		this.assetRelationshipName = assetRelationshipName;
	}

	public String getAssetRelationshipType() {
		return assetRelationshipType;
	}

	public void setAssetRelationshipType(String assetRelationshipType) {
		this.assetRelationshipType = assetRelationshipType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isVersionable() {
		return versionable;
	}

	public void setVersionable(boolean versionable) {
		this.versionable = versionable;
	}

	public String getTaxonomyName() {
		return taxonomyName;
	}

	public void setTaxonomyName(String taxonomyName) {
		this.taxonomyName = taxonomyName;
	}

	public int getShowHideParamCount() {
		return showHideParamCount;
	}

	public void setShowHideParamCount(int showHideParamCount) {
		this.showHideParamCount = showHideParamCount;
	}

	public String getNewDescription() {
		return newDescription;
	}

	public void setNewDescription(String newDescription) {
		this.newDescription = newDescription;
	}

	public String getParentAssetInstName() {
		return parentAssetInstName;
	}

	public void setParentAssetInstName(String parentAssetInstName) {
		this.parentAssetInstName = parentAssetInstName;
	}

	public String getParentAssetName() {
		return parentAssetName;
	}

	public void setParentAssetName(String parentAssetName) {
		this.parentAssetName = parentAssetName;
	}

	public String getParentVersionName() {
		return parentVersionName;
	}

	public void setParentVersionName(String parentVersionName) {
		this.parentVersionName = parentVersionName;
	}

	public Long getParentAssetInstVersionId() {
		return parentAssetInstVersionId;
	}

	public void setParentAssetInstVersionId(Long parentAssetInstVersionId) {
		this.parentAssetInstVersionId = parentAssetInstVersionId;
	}

	public Long getParentAssetId() {
		return parentAssetId;
	}

	public void setParentAssetId(Long parentAssetId) {
		this.parentAssetId = parentAssetId;
	}

	public String getIconImageName() {
		return iconImageName;
	}

	public void setIconImageName(String iconImageName) {
		this.iconImageName = iconImageName;
	}

	public Boolean getEditAccessFlag() {
		return editAccessFlag;
	}

	public void setEditAccessFlag(Boolean editAccessFlag) {
		this.editAccessFlag = editAccessFlag;
	}

	public Boolean getDeleteAccessFlag() {
		return deleteAccessFlag;
	}

	public void setDeleteAccessFlag(Boolean deleteAccessFlag) {
		this.deleteAccessFlag = deleteAccessFlag;
	}

	public Boolean getAddAccessFlag() {
		return addAccessFlag;
	}

	public void setAddAccessFlag(Boolean addAccessFlag) {
		this.addAccessFlag = addAccessFlag;
	}

	public String getParamRevData() {
		return paramRevData;
	}

	public void setParamRevData(String paramRevData) {
		this.paramRevData = paramRevData;
	}

	public Boolean getPropertiesFlag() {
		return propertiesFlag;
	}

	public void setPropertiesFlag(Boolean propertiesFlag) {
		this.propertiesFlag = propertiesFlag;
	}

	public List<AssetInstanceParameter> getAssetInstanceParameters() {
		return assetInstanceParameter;
	}

	public void setAssetInstance(List<AssetInstanceParameter> result) {
		this.assetInstanceParameter = result;
	}

	public List<Category> getCategoryDetails() {
		return categoryDetails;
	}

	public void setCategoryDetails(List<Category> categoryDetails) {
		this.categoryDetails = categoryDetails;
	}

	@Override
	public String toString() {
		return "AssetInstance [assetInstId=" + assetInstId + ", assetId="
				+ assetId + ", assetInstName=" + assetInstName + ", rating="
				+ rating + ", displayPosition=" + displayPosition
				+ ", publicAccess=" + publicAccess + ", owner=" + owner
				+ ", assetName=" + assetName + ", assetInstanceDescription="
				+ assetInstanceDescription + ", assetInstVersionId="
				+ assetInstVersionId + ", versionName=" + versionName
				+ ", versionable=" + versionable + ", assetRelationshipId="
				+ assetRelationshipId + ", assetRelationshipName="
				+ assetRelationshipName + ", assetRelationshipType="
				+ assetRelationshipType + ", description=" + description
				+ ", name=" + name + ", tagName=" + tagName + ", value="
				+ value + ", taxonomyName=" + taxonomyName
				+ ", assetInstanceMap=" + assetInstanceMap
				+ ", paramNameWithValues=" + paramNameWithValues
				+ ", showHideParamCount=" + showHideParamCount
				+ ", newDescription=" + newDescription
				+ ", parentAssetInstName=" + parentAssetInstName
				+ ", parentAssetName=" + parentAssetName
				+ ", parentVersionName=" + parentVersionName
				+ ", parentAssetInstVersionId=" + parentAssetInstVersionId
				+ ", parentAssetId=" + parentAssetId + ", paramRevData="
				+ paramRevData + ", iconImageName=" + iconImageName
				+ ", editAccessFlag=" + editAccessFlag + ", deleteAccessFlag="
				+ deleteAccessFlag + ", addAccessFlag=" + addAccessFlag
				+ ", propertiesFlag=" + propertiesFlag + ", assetInstance="
				+ assetInstanceParameter + ", categoryDetails=" + categoryDetails + "]";
	}

}
