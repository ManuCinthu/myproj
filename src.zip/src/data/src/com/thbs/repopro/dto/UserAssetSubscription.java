package com.thbs.repopro.dto;

public class UserAssetSubscription {

	private Long subscriptionId;// id
	private Long userId;// user_id
	private Long assetId;// asset_id
	private String assetName;
	private String subscriptionFlag;
	private String iconImageName;

	public String getIconImageName() {
		return iconImageName;
	}

	public void setIconImageName(String iconImageName) {
		this.iconImageName = iconImageName;
	}

	private boolean notifyFlag;

	public Long getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(Long subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getSubscriptionFlag() {
		return subscriptionFlag;
	}

	public void setSubscriptionFlag(String subscriptionFlag) {
		this.subscriptionFlag = subscriptionFlag;
	}

	public boolean getNotifyFlag() {
		return notifyFlag;
	}

	public void setNotifyFlag(boolean notifyFlag) {
		this.notifyFlag = notifyFlag;
	}

	@Override
	public String toString() {
		return "UserAssetSubscription [subscriptionId=" + subscriptionId
				+ ", userId=" + userId + ", assetId=" + assetId
				+ ", assetName=" + assetName + ", subscriptionFlag="
				+ subscriptionFlag + ", iconImageName=" + iconImageName
				+ ", notifyFlag=" + notifyFlag + "]";
	}

}
