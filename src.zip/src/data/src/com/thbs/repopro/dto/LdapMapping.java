package com.thbs.repopro.dto;

public class LdapMapping {

	private int ldapMappingId;
	private String mappingName;
	private String attributeName;
	private int ldapAttributeId;
	private String attributeDisplayName;
	
	public String getAttributeDisplayName() {
		return attributeDisplayName;
	}
	public void setAttributeDisplayName(String attributeDisplayName) {
		this.attributeDisplayName = attributeDisplayName;
	}
	public int getLdapAttributeId() {
		return ldapAttributeId;
	}
	public void setLdapAttributeId(int ldapAttributeId) {
		this.ldapAttributeId = ldapAttributeId;
	}
	public int getLdapMappingId() {
		return ldapMappingId;
	}
	public void setLdapMappingId(int ldapMappingId) {
		this.ldapMappingId = ldapMappingId;
	}
	public String getMappingName() {
		return mappingName;
	}
	public void setMappingName(String mappingName) {
		this.mappingName = mappingName;
	}
	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	@Override
	public String toString() {
		return "LdapMapping [ldapMappingId=" + ldapMappingId + ", mappingName=" + mappingName + ", attributeName="
				+ attributeName + ", ldapAttributeId=" + ldapAttributeId + ", attributeDisplayName="
				+ attributeDisplayName + "]";
	}
	
	
}
