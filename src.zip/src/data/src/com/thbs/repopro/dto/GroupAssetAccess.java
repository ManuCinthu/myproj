package com.thbs.repopro.dto;

import java.util.List;

public class GroupAssetAccess {
	private Long assetGroupId;
	private Long assetId;
	private Long groupId;
	private Long assetInstversionGroupId;
	private Long assetInstversionId;
	private Long addAccess;
	private Long editAccess;
	private Long viewAccess;
	private Long deleteAccess;
	private String groupName;
	private String assetName;
	private String assetInstanceName;
	private String VersionName;
	private boolean isMappedWithAI;
	private List<Long> aivIds;
	private List<Long> groupIds;
	private int groupIdcount;
	private String aivIdsList;
	
	public List<Long> getAivIds() {
		return aivIds;
	}

	public void setAivIds(List<Long> aivIds) {
		this.aivIds = aivIds;
	}

	public Long getAssetGroupId() {
		return assetGroupId;
	}

	public void setAssetGroupId(Long assetGroupId) {
		this.assetGroupId = assetGroupId;
	}

	public Long getAssetId() {
		return assetId;
	}

	public void setAssetId(Long assetId) {
		this.assetId = assetId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Long getAddAccess() {
		return addAccess;
	}

	public void setAddAccess(Long addAccess) {
		this.addAccess = addAccess;
	}

	public Long getEditAccess() {
		return editAccess;
	}

	public void setEditAccess(Long editAccess) {
		this.editAccess = editAccess;
	}

	public Long getViewAccess() {
		return viewAccess;
	}

	public void setViewAccess(Long viewAccess) {
		this.viewAccess = viewAccess;
	}

	public Long getDeleteAccess() {
		return deleteAccess;
	}

	public void setDeleteAccess(Long deleteAccess) {
		this.deleteAccess = deleteAccess;
	}

	public Long getAssetInstversionGroupId() {
		return assetInstversionGroupId;
	}

	public void setAssetInstversionGroupId(Long assetInstversionGroupId) {
		this.assetInstversionGroupId = assetInstversionGroupId;
	}

	public Long getAssetInstversionId() {
		return assetInstversionId;
	}

	public void setAssetInstversionId(Long assetInstversionId) {
		this.assetInstversionId = assetInstversionId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public boolean isMappedWithAI() {
		return isMappedWithAI;
	}

	public void setMappedWithAI(boolean isMappedWithAI) {
		this.isMappedWithAI = isMappedWithAI;
	}

	public List<Long> getGroupIds() {
		return groupIds;
	}

	public void setGroupIds(List<Long> groupIds) {
		this.groupIds = groupIds;
	}
	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getAssetInstanceName() {
		return assetInstanceName;
	}

	public void setAssetInstanceName(String assetInstanceName) {
		this.assetInstanceName = assetInstanceName;
	}

	public String getVersionName() {
		return VersionName;
	}

	public void setVersionName(String versionName) {
		VersionName = versionName;
	}

	public int getGroupIdcount() {
		return groupIdcount;
	}

	public void setGroupIdcount(int groupIdcount) {
		this.groupIdcount = groupIdcount;
	}

	public String getAivIdsList() {
		return aivIdsList;
	}

	public void setAivIdsList(String aivIdsList) {
		this.aivIdsList = aivIdsList;
	}

	@Override
	public String toString() {
		return "GroupAssetAccess [assetGroupId=" + assetGroupId + ", assetId=" + assetId + ", groupId=" + groupId
				+ ", assetInstversionGroupId=" + assetInstversionGroupId + ", assetInstversionId=" + assetInstversionId
				+ ", addAccess=" + addAccess + ", editAccess=" + editAccess + ", viewAccess=" + viewAccess
				+ ", deleteAccess=" + deleteAccess + ", groupName=" + groupName + ", assetName=" + assetName
				+ ", assetInstanceName=" + assetInstanceName + ", VersionName=" + VersionName + ", isMappedWithAI="
				+ isMappedWithAI + ", aivIds=" + aivIds + ", groupIds=" + groupIds + ", groupIdcount=" + groupIdcount
				+ ", aivIdsList=" + aivIdsList + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((groupId == null) ? 0 : groupId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GroupAssetAccess other = (GroupAssetAccess) obj;
		if (groupId == null) {
			if (other.groupId != null)
				return false;
		} else if (!groupId.equals(other.groupId))
			return false;
		return true;
	}

}
