package com.thbs.repopro.mail;
import java.beans.PropertyVetoException;
import java.io.IOException;
import org.codehaus.jackson.map.ObjectMapper;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.thbs.repopro.util.EncryptPassword;
import com.thbs.repopro.util.MessageUtil;
import com.google.gson.Gson;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;


@Path("/mailconfig")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class MailconfigManager {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getallmailconfig")
	public Response getallmailconfig() {
		log.trace("getallmailconfig || Begin ");
		Connection conn = null;
		List<MailConfig> mailList = new ArrayList<MailConfig>();

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()){
				log.trace("getallmailconfig || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			MailconfigurationDao dao = new MailconfigurationDao();

			if (log.isTraceEnabled()) {
				log.trace("getallmailconfig || dao method called : getallmailconfig()");
			}
			
			mailList = dao.getallmailconfig(conn);

			log.debug(" getallmailconfig || retrieved "+ mailList.size() +" details successfully");

			retStat = Status.OK;
			retMsg = Constants.GET_ALL_MAILCONFIG;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch(RepoproException e){
			log.error("getallmailconfig || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getallmailconfig || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getallmailconfig || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (mailList.isEmpty()) {
			retMsg = Constants.DETAILS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_DETAILS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		log.trace("getallmailconfig || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(mailList))).build();
	}
	
	
	@POST
	@Path("/addMailconfig")
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response newmailconfig(@FormDataParam("mailDetails") String mailDetails, 
			FormDataMultiPart formParams) throws org.json.JSONException, SQLException, IOException, PropertyVetoException {
		
		String userName = "";
		String password = "";
		String authentication = "";
		String startTLSEnable = "";
		String host="";
		int port=0;
		String bcc=null;
		String senderMailId=null;
		String jsonStr = mailDetails;
		
		JSONObject obj = null;
		try {
			obj = new JSONObject(jsonStr);
			
		
		 userName = obj.get("userName").toString();
		 password = obj.get("password").toString();
		 authentication = obj.get("authentication").toString();
		 startTLSEnable = obj.get("startTLSEnable").toString();
		 host = obj.get("host").toString();
		 port = obj.get("port").hashCode();
		 if(obj.isNull("bcc")) {
			 bcc = null;
			} else {
			    bcc = obj.getString("bcc");
			}
	
		 if(obj.isNull("senderMailId") || obj.getString("senderMailId").equalsIgnoreCase("") || obj.getString("senderMailId").trim().isEmpty()) {
			 senderMailId = null;
			} 
		 else {
			 senderMailId=CommonUtils.encrypt(obj.getString("senderMailId").trim());
			}
		
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
        Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<String> jsonList = new ArrayList<String>();
		Connection conn = null;
		MailconfigurationDao mailconfigdao = new MailconfigurationDao();
		MailConfig mailConfig = new MailConfig();
		try {
			if (log.isTraceEnabled()) {
				log.trace("newmailconfig || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			EncryptPassword encryptPwd = new EncryptPassword();
			password = encryptPwd.encryptPassword(password);
			//Tpassword=CommonUtils.encrypt(password);
			mailConfig.setUserName(userName);
			mailConfig.setPassword(password);
			mailConfig.setAuthentication(authentication);
			mailConfig.setStartTLSEnable(startTLSEnable);
			mailConfig.setHost(host);
			mailConfig.setPort(port);
			mailConfig.setBcc(bcc);
			mailConfig.setSenderMailId(senderMailId);
		
		
			if (log.isDebugEnabled()) {
				log.debug("newmailconfig || " + mailConfig.toString());
			}
			mailconfigdao.newmailconfig(mailConfig,conn);
		    conn.commit();
	        jsonList.add(mailConfig.toString());
			if (log.isTraceEnabled()) {
				log.trace("newmailconfig || dao method called : newmailconfig(mailList)");
			}
			
			retMsg = Constants.SUCCESS;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}
		 finally {
			if (log.isTraceEnabled()) {
				log.trace("newmailconfig || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("newmailconfig  || " + jsonList.toString() + " || end");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(jsonList))).build();
}
		

	
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getmailconfigflag")
	public Response getmailconflag() {
		log.trace("getmailconflag || Begin ");
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<MailConfig> configList = null;
		boolean flag = false;
		HashMap<String, Boolean> flagstatus= new HashMap<String, Boolean>();
		List<Boolean> resultFlag = new ArrayList<Boolean>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getmailconflag || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			MailconfigurationDao dao = new MailconfigurationDao();

			if (log.isTraceEnabled()) {
				log.trace("getmailconflag || dao method called : getallmailconfig()");
			}
			configList = dao.getallmailconfig(conn);
			
			if (configList.size() != 0) {
				flag = true;
			}
			flagstatus.put("mailConfigurationAccessflag", flag);
		    resultFlag.add(flag);
			log.debug(" getmailconflag || retrieved "+ configList.size() +" details successfully");

				retStat = Status.OK;
				retMsg = Constants.GET_ALL_MAILCONFIG;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			

			} catch(RepoproException e){
				log.error("getmailconflag || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
			} catch(Exception e){
				log.error("getmailconflag || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("getmailconfflag || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			
		log.trace("getmailconfigflag || End");
		return Response.status(retStat)
                .entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(resultFlag))).build();
}
	
	
	
	@SuppressWarnings("finally")
	@POST
	@Path("/testMailconfig")
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	public Response testmail(@FormDataParam("mailDetails") String mailDetails, FormDataMultiPart formParams)
			throws Exception {
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		//System.out.println(dateFormat.format(cal.getTime()));
		long startTime = System.currentTimeMillis();
		MailconfigurationDao mailconfigdao = new MailconfigurationDao();
		String userName = "";
		String password = "";
		String authentication = "";
		String startTLSEnable = "";
		String host = "";
		int port = 0;
		String bcc = null;
		String senderMailId = null;
		String jsonStr = mailDetails;
		User user = new User();
		UserDao userDao = new UserDao();
		JSONObject obj = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		
		try {
			obj = new JSONObject(jsonStr);
			obj.put("password", CommonUtils.encrypt(obj.get("password").toString()));
			System.out.println(password);

			userName = obj.get("userName").toString();
			authentication = obj.get("authentication").toString();
			startTLSEnable = obj.get("startTLSEnable").toString();
			host = obj.get("host").toString();
			port = obj.get("port").hashCode();

			if (obj.isNull("bcc")) {
				bcc = null;
			} else {
				bcc = obj.getString("bcc");
			}

			if (obj.isNull("senderMailId") || obj.getString("senderMailId").equalsIgnoreCase("")
					|| obj.getString("senderMailId").trim().isEmpty()) {
				senderMailId = null;
			} else {
				senderMailId = CommonUtils.encrypt(obj.getString("senderMailId").trim());
			}

			// TODO: logic
			
			User toUser = userDao.retProfileForUserName("admin", conn);
			if (toUser != null) {
				toUser.getEmailId();

			}
			

			// to call formdetails to object
			ObjectMapper mapper = new ObjectMapper();
			MailConfig mailConfig = new MailConfig();
			mailConfig = mapper.readValue(obj.toString(), MailConfig.class);
		    SendEmail.sendTextMailNonThread(mailConfig, toUser.getEmailId(), "Test Mail", "Test mail tested successfully");
			//log.trace(" testmail" + "test mail sent successfully");
            
			retStat = Status.OK;
			retMsg = Constants.TEST_MAIL_SENT_SUCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
		   } catch (RepoproException e) {
			//e.printStackTrace();
			log.trace("testmail || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = Constants.TEST_MAIL_NOT_SENT;
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			} catch(Exception e){
				log.trace("testmail || " + Constants.LOG_EXCEPTION + e.getMessage());
				//e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
			} /*finally {
			if (log.isTraceEnabled()) {
				log.trace("testmail || " + Constants.LOG_CONNECTION_CLOSE);
			}
			}*/
		
		if (log.isTraceEnabled()) {
			log.trace("testmail||End"+(System.currentTimeMillis() - startTime)/1000+" Secs");
		}
		
    DateFormat dateFormat2 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
    Calendar cal2 = Calendar.getInstance();
   System.out.println(dateFormat2.format(cal2.getTime()));
	return Response.status(retStat)
			.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}


}
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


