package com.thbs.repopro.mail;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class MailconfigurationDao {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
   public List<MailConfig> getallmailconfig(Connection conn) throws RepoproException{

	log.trace("getallmailconfig || Begin  ");
	Connection conn1 = null;
	PreparedStatement mailConfigStatement = null;
	ResultSet rs = null;
	List<MailConfig> mailList = new ArrayList<MailConfig>();
	MailConfig mailConfig = null;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("getallmailconfig || "+ Constants.LOG_CONNECTION_OPEN);
		}
		if(conn == null){
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		
		mailConfigStatement = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_MAILCONFIG));
		if (log.isTraceEnabled()) {
			log.trace("getallmailconfig || "+PropertyFileReader.getInstance().
					getValue(Constants.GET_ALL_MAILCONFIG));
		}
		rs = mailConfigStatement.executeQuery();
		while(rs.next()){
			mailConfig = new MailConfig();
			
			String senderMailId=null;
			mailConfig.setUserName(rs.getString("user_name"));
			String password = CommonUtils.decrypt(rs.getString("password"));
			mailConfig.setPassword(password);
			
			
			mailConfig.setAuthentication(rs.getString("auth"));
			mailConfig.setStartTLSEnable(rs.getString("start_TLS_enable"));
			mailConfig.setHost(rs.getString("host"));
			mailConfig.setPort(rs.getInt("port"));
			mailConfig.setBcc(rs.getString("bcc"));
			
			if((rs.getString("sender_mail_id"))!=null) {
		    senderMailId= CommonUtils.decrypt(rs.getString("sender_mail_id"));
		    mailConfig.setSenderMailId(senderMailId);
		 }
			else {	
				senderMailId=null;
			    mailConfig.setSenderMailId(senderMailId);
			
			}
			
			mailList.add(mailConfig);
			if (log.isTraceEnabled()) {
				log.trace("getallmailconfig || "+ mailConfig.toString());
			}
		
		
		}	}	
			
		catch (SQLException e) {
			log.error("getallmailconfig || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.MAILCONFIG_NOT_FOUND));
		} catch (IOException e) {
			log.error("getallmailconfig || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getallmailconfig || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getallmailconfig || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(mailConfigStatement);
			if (log.isTraceEnabled()) {
				log.trace("getallmailconfig || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			}
		
		return mailList; 
		}	





			
public MailConfig newmailconfig(MailConfig mailConfig, Connection conn) throws RepoproException {

	if (log.isTraceEnabled()) {
		log.trace("newmailconfig || begin || " + mailConfig.toString());
	}
	PreparedStatement mailConfigInsertStatement = null;
	ResultSet resultSet = null;
	Connection conn1 = null;
	try {
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}
		if (log.isTraceEnabled()) {
			log.trace("newmailconfig : " + Constants.LOG_CONNECTION_OPEN);
		}
		
		//Deleting previous records
		deleteMailDetails(conn);
		
		mailConfigInsertStatement = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.ADD_MAILCONFIG),Statement.RETURN_GENERATED_KEYS);
		 mailConfigInsertStatement.setString(Constants.ONE,mailConfig.getUserName());
	   	 mailConfigInsertStatement.setString(Constants.TWO,mailConfig.getPassword());
	   	 mailConfigInsertStatement.setString(Constants.THREE,mailConfig.getAuthentication());
	   	 mailConfigInsertStatement.setString(Constants.FOUR,mailConfig.getStartTLSEnable());
	   	 mailConfigInsertStatement.setString(Constants.FIVE,mailConfig.getHost());
	   	 mailConfigInsertStatement.setInt(Constants.SIX,mailConfig.getPort());
	   	 mailConfigInsertStatement.setString(Constants.SEVEN,mailConfig.getBcc());
	   	 mailConfigInsertStatement.setString(Constants.EIGHT,mailConfig.getSenderMailId());
	   	 mailConfigInsertStatement.executeUpdate();

		resultSet = mailConfigInsertStatement.getGeneratedKeys();
		if (log.isTraceEnabled()) {
			log.trace("newmailconfig || "
					+ PropertyFileReader.getInstance().getValue(
							Constants.ADD_MAIL));
		}

		if (resultSet != null && resultSet.next()) {
			}

	} catch (SQLException e) {
		log.error("newmailconfig || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.MAIL_NOT_CREATED));
	} catch (IOException e) {
		e.printStackTrace();
		log.error("newmailconfig ||  " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		e.printStackTrace();
		log.error("newmailconfig ||  " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		e.printStackTrace();
		log.error("newmailconfig ||  " + Constants.LOG_EXCEPTION + e.getMessage());
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closeResultSet(resultSet);
		DBConnection.closePreparedStatement(mailConfigInsertStatement);
		DBConnection.closeDbConnection(conn1);
		if (log.isTraceEnabled()) {
			log.trace("newmailconfig || " + Constants.LOG_CONNECTION_CLOSE);
		}

	}
	
	return mailConfig;
}

			
public boolean deleteMailDetails( Connection conn) throws RepoproException{
	
	if(log.isTraceEnabled()) {
		log.trace("deleteMailDetails || Begin with mailConfig");
	}
	
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	
	boolean status = false;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("deleteMailDetails || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}
		
		pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_MAIL_DETAILS));
		
		if (log.isTraceEnabled()) {
			log.trace("deleteMailDetails || " + PropertyFileReader.getInstance().getValue(Constants.DELETE_MAIL_DETAILS));
		}
		
		pstmt.executeUpdate();
		status = true;
		
	} catch (SQLException e) {
		log.error("deleteMailDetails || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(MessageUtil.getMessage(Constants.MAIL_NOT_DELETED));
	} catch (IOException e) {
		log.error("deleteMailDetails || " + Constants.LOG_IOEXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("deleteMailDetails || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("deleteMailDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closePreparedStatement(pstmt);
		if (log.isTraceEnabled()) {
			log.trace("deleteMailDetails || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);
	}
	return status;
}
}









			
			
















    
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	

				
				
				

				
						
						
							
							
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
