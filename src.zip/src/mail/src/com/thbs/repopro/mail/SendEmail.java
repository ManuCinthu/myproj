package com.thbs.repopro.mail;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.mail.internet.MimeMultipart;

import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;

public class SendEmail {
	private  static Properties properties = null;
//	private final static String from = "repopro3@gmail.com";
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	
	/**
	 * @method : sendTextMail
	 * @param mailConfig
	 * @param to
	 * @param subject
	 * @param body
	 * @throws Exception
	 */
	public static void sendTextMail(MailConfig mailConfig, String to,  String subject,  String body) throws  Exception {
		Thread th = new Thread(){
			@SuppressWarnings("null")
			public void run(){
				try{
					Properties props = new Properties();
					if(mailConfig.getAuthentication().equals("1")){
						props.put("mail.smtp.auth", "true");
					}
					if(mailConfig.getStartTLSEnable().equals("1")){
						props.put("mail.smtp.starttls.enable", "true");
					}
					props.put("mail.smtp.host", mailConfig.getHost());
					//props.put("mail.smtp.port", mailConfig.getPort());
					props.put("mail.smtp.port",String.valueOf(mailConfig.getPort()));
					
					if(mailConfig.getBcc()!=null) {
						props.put("mail.smtp.bcc", mailConfig.getBcc());
					}
					
					if ( mailConfig.getSenderMailId() != null) {
						props.put("mail.smtp.senderMailId", mailConfig.getSenderMailId());
					}					
					String password = CommonUtils.decrypt(mailConfig.getPassword());
					System.out.println(password);
                    props.put("mail.smtp.password", password);
                    Authenticator authenticator = new Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(mailConfig.getUserName(), password);
						}
					};
					System.out.println(password);
                    if (props.isEmpty()) {
						throw new Exception("Cannot  send mail. Host  data not available.");
					}

					//Session sessionObj = Session.getDefaultInstance(props, authenticator);
					Session sessionObj = Session.getInstance(props,authenticator);
					//sessionObj.setDebug(true);
					Message  msg  = new MimeMessage(sessionObj);
					
					String from = mailConfig.getUserName(); //mailConfig.getSenderMailId();
					InternetAddress  fromAddress  = new InternetAddress(from);
					InternetAddress  toAddress =  new InternetAddress(to);
					if(mailConfig.getBcc() != null) {
						InternetAddress  bccAddress =  new InternetAddress(mailConfig.getBcc());
						msg.setRecipient(Message.RecipientType.BCC, bccAddress);
					}
					
					
					msg.setFrom(fromAddress);
					msg.setSubject(subject);
					msg.setRecipient(RecipientType.TO, toAddress);
					
					msg.setContent(body, "text/plain; charset=UTF-8");
					Transport.send(msg);
					System.out.println(password);
				}catch(Exception e){
					//e.printStackTrace();
					log.trace("Exceptions", e);
					//throw new RepoproException(e.getMessage());
				}
			}
		};
		th.start();
	}

	
	/**
	 * @method : sendAttachedMail
	 * @param to
	 * @param subject
	 * @param text
	 * @param fileName
	 * @throws Exception
	 */
	public static void sendAttachedMail(MailConfig mailConfig,String to, String subject, String text, String fileName, String filePathWithName) throws Exception {
		Thread th = new Thread(){
			public void run(){
				try{
					Properties props = new Properties();
					if(mailConfig.getAuthentication().equals("1")){
						props.put("mail.smtp.auth", "true");
					}
					if(mailConfig.getStartTLSEnable().equals("1")){
						props.put("mail.smtp.starttls.enable", "true");
					}
					props.put("mail.smtp.host", mailConfig.getHost());
					//props.put("mail.smtp.port", mailConfig.getPort());
					props.put("mail.smtp.port",String.valueOf(mailConfig.getPort()));
					if(mailConfig.getBcc()!=null) {
						props.put("mail.smtp.bcc", mailConfig.getBcc());
					}
					
					if ( mailConfig.getSenderMailId()!= null) {
						props.put("mail.smtp.senderMailId", mailConfig.getSenderMailId());
					}	
					
					String password = CommonUtils.decrypt(mailConfig.getPassword());
                    props.put("mail.smtp.password", password);
                   
                    
					Authenticator authenticator = new Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication() {
							return new PasswordAuthentication(mailConfig.getUserName(), password);
						}
					};
					
                   /* props.put("mail.smtp.username",mailConfig.getUserName());*/
					if (props.isEmpty()) {
						throw new Exception("Cannot send mail. Host data not available.");
					}

					//Session session = Session.getDefaultInstance(props, authenticator);
					Session session = Session.getInstance(props, authenticator);
					//session.setDebug(true);
					String from = mailConfig.getSenderMailId();
					InternetAddress fromAddress = new InternetAddress(from);

					Message message = new MimeMessage(session);

					message.setFrom(fromAddress);

					message.setRecipients(Message.RecipientType.TO,InternetAddress.parse(to));

					message.setSubject(subject);

					BodyPart messageBodyPart = new MimeBodyPart();

					messageBodyPart.setText(text);

					Multipart multipart = new MimeMultipart();

					multipart.addBodyPart(messageBodyPart);

					messageBodyPart = new MimeBodyPart();
					DataSource source = new FileDataSource(filePathWithName);
					messageBodyPart.setDataHandler(new DataHandler(source));
					messageBodyPart.setFileName(fileName);
					multipart.addBodyPart(messageBodyPart);

					message.setContent(multipart);


					Transport.send(message);
				}catch(Exception e){
					//e.printStackTrace();
					log.trace("Exceptions", e);
				}finally{
					CommonUtils.deleteDir(filePathWithName);
				}
			}
			
			/*@Override
		    protected void finalize() throws Throwable {
				CommonUtils.deleteDir(filePathWithName);
		    }*/
		};
		th.start();

	}
	
public static void sendTextMailNonThread(MailConfig mailConfig, String to,  String subject,  String body) throws  Exception {
		try
	    {
			
			Properties props = new Properties();
			if(mailConfig.getAuthentication().equals("1")){
				props.put("mail.smtp.auth", "true");
			}
			if(mailConfig.getStartTLSEnable().equals("1")){
				props.put("mail.smtp.starttls.enable", "true");
			}
			props.put("mail.smtp.host", mailConfig.getHost());
		 //props.put("mail.smtp.port", mailConfig.getPort());
		   props.put("mail.smtp.port",String.valueOf(mailConfig.getPort()));
		    
			if(mailConfig.getBcc()!=null) {
				props.put("mail.smtp.bcc", mailConfig.getBcc());
			}
			
			if ( mailConfig.getSenderMailId() != null) {
				props.put("mail.smtp.senderMailId", mailConfig.getSenderMailId());
			}
			String password = CommonUtils.decrypt(mailConfig.getPassword());
            props.put("mail.smtp.password", password);
            Authenticator authenticator = new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(mailConfig.getUserName(), password);
				}
			};
			
            if (props.isEmpty()) {
				throw new Exception("Cannot  send mail. Host  data not available.");
			}
			
            Session session= Session.getInstance(props, authenticator);
			session.setDebug(true);
			Message  msg  = new MimeMessage(session);
			
			String from = mailConfig.getUserName(); //mailConfig.getSenderMailId();
			InternetAddress  fromAddress  = new InternetAddress(from);
			InternetAddress  toAddress =  new InternetAddress(to);
			if(mailConfig.getBcc() != null) {
				InternetAddress  bccAddress =  new InternetAddress(mailConfig.getBcc());
				msg.setRecipient(Message.RecipientType.BCC, bccAddress);
			}
			
			msg.setFrom(fromAddress);
			msg.setSubject(subject);
			msg.setRecipient(RecipientType.TO, toAddress);
			
			msg.setContent(body, "text/plain; charset=UTF-8");
			Transport.send(msg);
	    }
		catch (Exception e) {
		    // e.printStackTrace();
			log.trace("Exceptions", e);
			throw new RepoproException(e.getMessage());
		    }
	}
}
			
			
		
	
	
	
	
	
	
	
	
	
	
	
	
