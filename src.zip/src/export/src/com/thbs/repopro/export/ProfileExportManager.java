package com.thbs.repopro.export;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;

@Path("/profileExport")
public class ProfileExportManager {
	private final static Logger log = LoggerFactory.getLogger("timeBased");
	
	private static final String FILE_PATH = System.getProperty("user.home")+"/";
	
	/**
	 * @method profileExport
	 * @description to export profile details
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/exportProfile")
//	@Produces("application/vnd.ms-excel")
	@Produces("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	public Response profileExport()throws RepoproException{

		log.trace("profileExport || Begin");

		long startTime = System.currentTimeMillis();
		String downloadName = "Profile_Export_" + System.currentTimeMillis()+ "".concat(".xlsx");
		String filePath = FILE_PATH+downloadName;
		File file = new File(filePath);
		ResponseBuilder response = null;
		UserDao userDao = new UserDao();
		List<User> userListData = new ArrayList<User>();
		Connection conn = null;
		XSSFSheet mySheet1 = null;
		FileOutputStream fileOutputStream = null;
		Runtime runTime = Runtime.getRuntime();

		try{
			fileOutputStream = new FileOutputStream(filePath);
			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);
			if (log.isTraceEnabled()) {
				log.trace("profileExport || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			userListData = userDao.getUsers(false,conn);
			List<User> userList = new ArrayList<User>();
			for(User profile:userListData)
			{
				if(!profile.getUserName().equalsIgnoreCase("admin")){
					User user=new User();
					user.setUserId(profile.getUserId());
					user.setUserName(profile.getUserName());
					user.setPassword(profile.getPassword());
					user.setActiveFlag(profile.getActiveFlag());
					user.setFullName(profile.getFullName());
					user.setEmailId(profile.getEmailId());
					user.setDepartment(profile.getDepartment());
					user.setEncryptFullName(profile.getEncryptFullName());
					user.setEncryptEmailId(profile.getEncryptEmailId());
					user.setEncryptDepartment(profile.getEncryptDepartment());

					userList.add(user);	
				}
			}
			mySheet1 = myWorkBook.createSheet("Profile");

			setProfileExcelData(conn,mySheet1,cellHeaderStyle,userList);

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			try {
				fileOutputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (log.isDebugEnabled()) {
				log.debug("profileExport ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}


		log.trace("profileExport || End");
		runTime.gc();
		return response.build();
	}
	
	/**
	 * @method setProfileExcelData
	 * @description to set profile excel data
	 * @param conn
	 * @param mySheet
	 * @param cellHeaderStyle
	 * @param export
	 */
	public void setProfileExcelData(Connection conn,XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle, 
			List<User> export){

		log.trace("setProfileExcelData || Begin");

		int rowNum = 0;
		XSSFRow myRow = null;
		UserDao userDao = new UserDao();
		try {

			myRow = mySheet.createRow(rowNum++);
			myRow.createCell(0).setCellValue("User Name");
			myRow.createCell(1).setCellValue("Full Name");
			myRow.createCell(2).setCellValue("Email-Id");
			myRow.createCell(3).setCellValue("Department");
			myRow.createCell(4).setCellValue("Associated Groups");
			myRow.createCell(5).setCellValue("Status");
			myRow.createCell(6).setCellValue("Encrypt FullName");
			myRow.createCell(7).setCellValue("Encrypt EmailId");
			myRow.createCell(8).setCellValue("Encrypt Department");
			
			for (User export1 : export) {
				myRow = mySheet.createRow(rowNum++);
				myRow.createCell(0).setCellValue(export1.getUserName());
				myRow.createCell(1).setCellValue(export1.getFullName());
				myRow.createCell(2).setCellValue(export1.getEmailId());
				myRow.createCell(3).setCellValue(export1.getDepartment());
				
				myRow.createCell(6).setCellValue(export1.getEncryptFullName());
				myRow.createCell(7).setCellValue(export1.getEncryptEmailId());
				myRow.createCell(8).setCellValue(export1.getEncryptDepartment());
				
				if (log.isTraceEnabled()) {
					log.trace("setProfileExcelData || dao method called : retAllUserGroupsMappedWithUserId() to get asscociated user group details");
				}
				List<GroupDetails> groupDetails = userDao.retAllUserGroupsMappedWithUserId(export1.getUserId(),conn);
				String group = new String();

				for(GroupDetails groupDetail:groupDetails){
					if(!groupDetail.getGroupName().equalsIgnoreCase("Guest")){
						group = group.concat(groupDetail.getGroupName().toString()+",");
					}
				}
				group = group.replaceAll(",$", "");			
				myRow.createCell(4).setCellValue(group);
				if(export1.getActiveFlag().equalsIgnoreCase("1"))
					myRow.createCell(5).setCellValue("Active");
				else if(export1.getActiveFlag().equalsIgnoreCase("2"))
					myRow.createCell(5).setCellValue("Active");
				else if(export1.getActiveFlag().equalsIgnoreCase("0"))
					myRow.createCell(5).setCellValue("Inactive");
				
				
			}

		}catch (Exception e) {
			e.printStackTrace();
		}
		log.trace("setProfileExcelData || End");
	}
	
	/**
	 * @method profileExport
	 * @description to export profile details
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Encoded
	@Path("/exportProfileSearch")
//	@Produces("application/vnd.ms-excel")
	@Produces("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	public Response profileSearchExport(@QueryParam("serachString") String searchString )throws RepoproException{

		log.trace("profileSearchExport || Begin");

		long startTime = System.currentTimeMillis();
		String downloadName = "Profile_Export_Search_" + System.currentTimeMillis()+ "".concat(".xlsx");
		String filePath = FILE_PATH+downloadName;
		File file = new File(filePath);
		ResponseBuilder response = null;
		UserDao userDao = new UserDao();
		List<User> userListData = new ArrayList<User>();
		Connection conn = null;
		XSSFSheet mySheet1 = null;
		FileOutputStream fileOutputStream = null;
		Runtime runTime = Runtime.getRuntime();

		try{
			fileOutputStream = new FileOutputStream(filePath);
			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);
			if (log.isTraceEnabled()) {
				log.trace("profileSearchExport || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			String actualValue = URLDecoder.decode(searchString, "UTF-8");
			String value = "";
			if (actualValue.contains("_") || actualValue.contains("%") || actualValue.contains("'") || actualValue.contains("\\") || actualValue.contains("+")){
				value = actualValue;
				value = value.replace("\\", "\\\\");
				value = value.replace("_", "\\_");
				value = value.replace("%", "\\%");
				value = value.replace("'", "\\'");
				value = value.replace("+", "\\+");
			}else{
				value = actualValue;
			}
			userListData = userDao.getUsersBySearch(false, value , conn);
			List<User> userList = new ArrayList<User>();
			for(User profile:userListData)
			{
				if(!profile.getUserName().equalsIgnoreCase("admin")){
					User user=new User();
					user.setUserId(profile.getUserId());
					user.setUserName(profile.getUserName());
					user.setPassword(profile.getPassword());
					user.setActiveFlag(profile.getActiveFlag());
					user.setFullName(profile.getFullName());
					user.setEmailId(profile.getEmailId());
					user.setDepartment(profile.getDepartment());
					user.setEncryptFullName(profile.getEncryptFullName());
					user.setEncryptEmailId(profile.getEncryptEmailId());
					user.setEncryptDepartment(profile.getEncryptDepartment());
					
					userList.add(user);	
				}
			}
			mySheet1 = myWorkBook.createSheet("Profile");

			setProfileExcelData(conn,mySheet1,cellHeaderStyle,userList);

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			try {
				fileOutputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (log.isDebugEnabled()) {
				log.debug("profileSearchExport ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}


		log.trace("profileSearchExport || End");
		runTime.gc();
		return response.build();
	}
	@GET
	@Encoded
	@Path("/exportfilterUsersAttributes")
//	@Produces("application/vnd.ms-excel")
	@Produces("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	public Response exportfilterUsersAttributes(@QueryParam("userName") String userName,
			@QueryParam("attributeList") String attributeList,
			@QueryParam("searchString") String searchString,
			@QueryParam("groupIds") String groupIds)throws RepoproException{

		log.trace("profileSearchExport || Begin");

		long startTime = System.currentTimeMillis();
		String downloadName = "Profile_Export_Search_" + System.currentTimeMillis()+ "".concat(".xlsx");
		String filePath = FILE_PATH+downloadName;
		File file = new File(filePath);
		ResponseBuilder response = null;
		UserDao userDao = new UserDao();
		List<User> userListData = new ArrayList<User>();
		Connection conn = null;
		XSSFSheet mySheet1 = null;
		FileOutputStream fileOutputStream = null;
		Runtime runTime = Runtime.getRuntime();

		try{
			fileOutputStream = new FileOutputStream(filePath);
			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);
			if (log.isTraceEnabled()) {
				log.trace("profileSearchExport || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			String actualValue = URLDecoder.decode(searchString, "UTF-8");
			String value = "";
			if (actualValue.contains("_") || actualValue.contains("%") || actualValue.contains("'") || actualValue.contains("\\") || actualValue.contains("+")){
				value = actualValue;
				value = value.replace("\\", "\\\\");
				value = value.replace("_", "\\_");
				value = value.replace("%", "\\%");
				value = value.replace("'", "\\'");
				value = value.replace("+", "\\+");
			}else{
				value = actualValue;
			}
			
			if(attributeList != null && !attributeList.isEmpty() && !attributeList.equalsIgnoreCase("")) {
				
				List<String> attributes = new ArrayList<String>(Arrays.asList(attributeList.split(",")));
				userListData = userDao.getFlilteredUsersAttributeForGrid(userName, attributes, value,0L,groupIds,true, conn);

			}else {
				userListData = userDao.getUsersBySearch(false, value , conn);
			}
			Set<User> usersListForGridSet = new HashSet<User>();
			
			usersListForGridSet.addAll(userListData);
			userListData = new ArrayList<User>();
			userListData.addAll(usersListForGridSet);
			
			List<User> userList = new ArrayList<User>();
			for(User profile:userListData)
			{
				if(!profile.getUserName().equalsIgnoreCase("admin")){
					User user=new User();
					user.setUserId(profile.getUserId());
					user.setUserName(profile.getUserName());
					user.setPassword(profile.getPassword());
					user.setActiveFlag(profile.getActiveFlag());
					user.setFullName(profile.getFullName());
					user.setEmailId(profile.getEmailId());
					user.setDepartment(profile.getDepartment());
					user.setEncryptFullName(profile.getEncryptFullName());
					user.setEncryptEmailId(profile.getEncryptEmailId());
					user.setEncryptDepartment(profile.getEncryptDepartment());
					
					userList.add(user);	
				}
			}
			mySheet1 = myWorkBook.createSheet("Profile");

			setProfileExcelData(conn,mySheet1,cellHeaderStyle,userList);

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			try {
				fileOutputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (log.isDebugEnabled()) {
				log.debug("profileSearchExport ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}


		log.trace("profileSearchExport || End");
		runTime.gc();
		return response.build();
	}
}
