package com.thbs.repopro.export;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.advancedsearch.AdvancedSearchDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstance.ShowHideDao;
import com.thbs.repopro.assetinstance.ShowHideManager;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstRelationship;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.GamificationDetails;
import com.thbs.repopro.dto.LdapMapping;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.QuickSearch;
import com.thbs.repopro.dto.QuickSearchSearchByComparator;
import com.thbs.repopro.dto.RecentActivity;
import com.thbs.repopro.dto.SearchResponse;
import com.thbs.repopro.dto.ShowHideColumn;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.gamification.GamificationDao;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.quicksearch.SearchDao;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.LeaderBoardUtil;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;

@Path("/export")
public class ExcelExportManager {
	
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	private static final String FILE_PATH = System.getProperty("user.home")+"/";

	private static String exportInProcess = "0";

	public static String isExportInProcess() {
		return exportInProcess;
	}

	public static void setExportInProcess(String exportInProcess) {
		ExcelExportManager.exportInProcess = exportInProcess;
	}

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	private Timer timer;

	private String downloadName;

	private InputStream fileInputStream;

	public InputStream getFileInputStream() {
		return fileInputStream;
	}

	public void setFileInputStream(InputStream fileInputStream) {
		this.fileInputStream = fileInputStream;
	}

	/**
	 * @method excelExport
	 * @description Full export
	 * @return Excel(.xlxs file)
	 * @throws RepoproException
	 */
	@GET
	@Path("/exportTab/{userName}")
	//	@Produces("application/vnd.ms-excel")
	public Response excelExport(@PathParam("userName")String userName)throws RepoproException{

		log.trace("excelExport || Begin");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		ArrayList<String> al = new ArrayList<String>();

		try{
			al.add(exportInProcess);

			retStat = Status.OK;
			retMsg = this.message;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		catch(Exception e){
			log.error("Exception excelExport ||"
					+ e.getMessage());
		} finally{
			if (log.isDebugEnabled()) {
				log.debug("excelExport ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
		}

		log.trace("excelExport || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(al))).build();

	}

	@GET
	@Path("/exportInExcel/{userName}")
	public Response exporterXls(@PathParam("userName")String userName){

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try{

			timer = new Timer();
			timer.schedule(new TimerTask() {
				public void run() {
					processFullExportExcel(userName);
					this.cancel();//avoid memory leak
				}
			}, 0);

			retStat = Status.OK;
			retMsg = this.message;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;


		}catch(Exception e){
			e.printStackTrace();
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}


	public void processFullExportExcel(String userName){

		Connection conn = null;
		List<AssetDef> assetList = null;
		ExcelExportDao exportDao = new ExcelExportDao();
		XSSFSheet mySheet1 = null;
		XSSFSheet mySheet2 = null;
		AssetDao assetDao = new AssetDao();
		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		
		exportInProcess = "1";

		User user = new User();
		UserDao userDao = new UserDao();
		MailConfig mailConfig = null;
		
		Runtime r = Runtime.getRuntime();
		
		if (log.isInfoEnabled()) {
			log.info("excelExport || started at " + System.currentTimeMillis());
		}
		try{

			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);

			if (log.isTraceEnabled()) {
				log.trace("excelExport || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("excelExport || dao call of getAllAssets() method to retrieve Asset Details list");
			}
			//assetList = assetDao.getAllAssets(conn);
			assetList = assetDao.getAllAssetNames(userName, conn);
			boolean authorityFlag = assetInstVerDao.findAdminRightsByUserName(userName, conn);

			user = userDao.retProfileForUserName(userName, conn);
			MailTemplateDao mailDao = new MailTemplateDao();
			mailConfig = mailDao.getMailConfig(conn);

			//Iteration for each asset number of times
			StringBuffer nonStaticParameters = null;
			StringBuffer staticParameters = null;
			String attributeSheetName = null;
			String relationshipSheetName = null;

			List<AssetInstanceVersion> assetAttributeList = null ;
			List<AssetInstRelationship> aseetInstRelList = null;

			List<AssetParamDef> assetParamList = null;

			for(AssetDef asset : assetList){
				
				if (log.isDebugEnabled()) {
					log.debug("excelExport || Processing for " + asset.getAssetName() + " : " + System.currentTimeMillis());
				}
				
				boolean flag = false;
				nonStaticParameters = new StringBuffer();
				staticParameters = new StringBuffer();

				attributeSheetName = asset.getAssetName();
				if(attributeSheetName.length() > 19)
					attributeSheetName = asset.getAssetName().substring(0,18);
				mySheet1 = myWorkBook.createSheet(attributeSheetName+" Attributes");

				relationshipSheetName = asset.getAssetName();
				if(attributeSheetName.length() > 16)
					relationshipSheetName =  asset.getAssetName().substring(0,15); 
				mySheet2 = myWorkBook.createSheet(relationshipSheetName+" Relationships");

				// Asset instance attributes
				List<AssetParamDef> assetParamDefList = exportDao.getAssetParamDetails(conn, asset.getAssetName());
				for(AssetParamDef assetParamDef : assetParamDefList){
					if(assetParamDef.getIs_static() == 0){							// for Static Asset Attributes
						flag = true;
						break;
					}
				}

				for(AssetParamDef assetParamDef : assetParamDefList){
					if(assetParamDef.getIs_static() == 0){							// for Static Asset Attributes
						nonStaticParameters.append(assetParamDef.getAssetParamName()+",");
					}else{
						staticParameters.append(assetParamDef.getAssetParamName()+",");
					}
				}
				if(nonStaticParameters.length()!=0){
					nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length()-1);	
				}
				if(staticParameters.length()!=0){
					staticParameters = staticParameters.deleteCharAt(staticParameters.length()-1);
				}
				
				assetAttributeList = exportDao.getFinalResultForAttributeSheeet(conn , asset.getAssetId(),asset.getAssetName(),flag,staticParameters,nonStaticParameters, assetParamDefList,userName,authorityFlag);
				Collections.sort(assetAttributeList,new AssetInstanceVersion());
				
				assetParamList = exportDao.getAssetInstanceParameters(conn, asset.getAssetName());
				if (log.isDebugEnabled()) {
					log.debug("excelExport || obtained attribute values: " + System.currentTimeMillis());
				}

				//Asset Instance relationship
				aseetInstRelList = exportDao.getAssetInstanceRelationships(conn,asset.getAssetName());
				
				if (log.isDebugEnabled()) {
					log.debug("excelExport || obtained relationship details: " + System.currentTimeMillis());
				}

				setExcelDataAssetAttributes(mySheet1,cellHeaderStyle,assetParamList,assetAttributeList,asset.getAssetName(),conn,userName);
				if (log.isDebugEnabled()) {
					log.debug("excelExport || processed all attribute values " + System.currentTimeMillis());
				}
				setExcelDataAIRelationships(mySheet2,cellHeaderStyle,aseetInstRelList,asset.getAssetName());
				if (log.isDebugEnabled()) {
					log.debug("excelExport || processed all relationships details " + System.currentTimeMillis());
				}
				
			}


			try{
				//Write the workbook in file system
				FileOutputStream out = new FileOutputStream(new File(FILE_PATH+"RepoProExport.xlsx"));
				myWorkBook.write(out);
				out.close();

				SendEmail.sendTextMail(mailConfig,user.getEmailId(), "RepoPro Export XLSX: Successful", MessageUtil.getMessage(Constants.EMAIL_HDR) + "Export of repository as XLSX was successful. Please download the file from the download link available in Import/Export page.\n\nRepoPro "  + MessageUtil.getMessage(Constants.EMAIL_NOTE));
			}catch (Exception e){
				SendEmail.sendTextMail(mailConfig,user.getEmailId(), "RepoPro Export XLS: Failed",MessageUtil.getMessage(Constants.EMAIL_HDR) + "An error was encountered while processing your export repository request.\n\nRepoPro" + MessageUtil.getMessage(Constants.EMAIL_NOTE));
			}
		}catch(Exception e){
			try {
				SendEmail.sendTextMail(mailConfig,user.getEmailId(), "RepoPro Export XLS: Failed",MessageUtil.getMessage(Constants.EMAIL_HDR) + "An error was encountered while processing your export repository request.\n\nRepoPro" + MessageUtil.getMessage(Constants.EMAIL_NOTE));
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}finally{
			if (log.isDebugEnabled()) {
				log.debug("exporterXls ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isInfoEnabled()) {
			log.info("excelExport || finished at " + System.currentTimeMillis());
		}
		exportInProcess = "2";
		r.gc();     
	}


	@GET
	@Path("/downloadFile")
	@Produces("application/vnd.ms-excel")
	public Response downloadFile() throws Exception {
		String url = FILE_PATH+"RepoProExport.xlsx";
		File file = new File(url);  

		ResponseBuilder response = Response.ok((Object) file);
		response.header("Content-Disposition",
				"attachment; filename=RepoProExport.xlsx");
		return response.build();
	}



	public void setExcelDataAssetAttributes(XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle, List<AssetParamDef> assetParamList , List<AssetInstanceVersion> assetAttributeList,String assetName,Connection con,String userName){
		int rowNum = 0;
		int colCount;
		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		AssetDao assetDao = new AssetDao();
		try {
			XSSFRow rowa = mySheet.createRow(rowNum++);
			XSSFCell cell0b=  rowa.createCell(0);
			cell0b.setCellValue(assetName);
			cell0b.setCellStyle(cellHeaderStyle);

			XSSFRow rowa11 = mySheet.createRow(rowNum++);

			XSSFCell cell0b1=  rowa11.createCell(0);
			cell0b1.setCellValue("Asset instance version id");
			cell0b1.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b2=  rowa11.createCell(1);
			cell0b2.setCellValue("Asset Instance name");
			cell0b2.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b3=  rowa11.createCell(2);
			cell0b3.setCellValue("Version Name");
			cell0b3.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b4=  rowa11.createCell(3);
			cell0b4.setCellValue("Overview");
			cell0b4.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b5=  rowa11.createCell(4);
			cell0b5.setCellValue("Created On");
			cell0b5.setCellStyle(cellHeaderStyle);

			
			colCount = 4+1;
			int paramcount = 0;
			Map<String, String> ldapColMapping = new LinkedHashMap<String, String>();
			for(AssetParamDef assetParam : assetParamList){
				if(assetParam.getParamTypeId() == 9L){
					List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(assetParam.getLdapMappingId(), con);
					for(LdapMapping attribute:ldapMappingList) {
						XSSFCell cell0b14=  rowa11.createCell(colCount);
						String colName = assetParam.getAssetParamName()+"_"+attribute.getAttributeDisplayName();
						ldapColMapping.put(assetParam.getAssetParamName(), colName);
						cell0b14.setCellValue(colName);
						cell0b14.setCellStyle(cellHeaderStyle);
						colCount++;	
						paramcount++;
					} 
				} else {
					XSSFCell cell0b14=  rowa11.createCell(colCount);
					cell0b14.setCellValue(assetParam.getAssetParamName());
					cell0b14.setCellStyle(cellHeaderStyle);
					colCount++;
					paramcount++;
				}			
			}

			XSSFCell cell0b6=  rowa11.createCell(colCount++);
			cell0b6.setCellValue("%%Taxonomies%%");
			cell0b6.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b7=  rowa11.createCell(colCount++);
			cell0b7.setCellValue("%%Tags%%");
			cell0b7.setCellStyle(cellHeaderStyle);

			int tempColCount = 0;
			long latestAssetInstanceVersionId = 0;
			Row row = mySheet.createRow(rowNum);
			Cell cell = null;
			Cell cell2 = null;
			Cell cell3 = null;
			Cell cell4 = null;
			Cell cell5 = null;
			Cell cell6 = null;
			Cell cell7 = null;
			Cell cell8 = null;
			TreeMap<String , String> hm = null;
			String derivedAttrVals = null;
			String derivedCompVal = null;
			StringBuilder sb = null;
			String cellVal = "";

			if(assetAttributeList != null){
				for (AssetInstanceVersion attributeExportVo : assetAttributeList) {

					if(attributeExportVo.getAssetInstVersionId() != latestAssetInstanceVersionId){

						row = mySheet.createRow(rowNum++);

						cell = row.createCell(0);
						cell.setCellValue(attributeExportVo.getAssetInstVersionId());
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print 1st cell data " + System.currentTimeMillis());
						}

						cell2 = row.createCell(1);
						cell2.setCellValue(attributeExportVo.getAssetInstName());
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print 2nd cell data " + System.currentTimeMillis());
						}

						cell3 = row.createCell(2);
						if(attributeExportVo.getVersionName() == null || attributeExportVo.getVersionable() == null || attributeExportVo.getVersionable() == false){
							cell3.setCellValue("NA");
						}else{
							cell3.setCellValue(attributeExportVo.getVersionName());
						}
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print 3rd cell data " + System.currentTimeMillis());
						}

						cell4 = row.createCell(3);
						if(attributeExportVo.getDescription() != null && attributeExportVo.getDescription().length() >= 32768){
							cell4.setCellValue(" *** Limit exceeded for cell. ***");
						}else{
							cell4.setCellValue(attributeExportVo.getDescription());
						}
						
						cell5 = row.createCell(4);
						if(attributeExportVo.getCreatedOn() != null){
							SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
							String dateStr = formatter.format(attributeExportVo.getCreatedOn());
							cell5.setCellValue(dateStr);
						}else{
							cell5.setCellValue("");
						}
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print 4th cell data " + System.currentTimeMillis());
						}

						tempColCount = 4+1;
						hm = attributeExportVo.getParamNamewithvalue();
						for(Map.Entry<String, String> paramMapEntry : hm.entrySet()){
							Map<String,Integer> ldapmappingdata = new LinkedHashMap<String,Integer>();
							int x = 0;
							int ldapMaapingId = 0;
							String ldapmapping = null;
							List<String> paramValList = new ArrayList<String>();
							for(AssetParamDef astParName : assetParamList){
								if(astParName.getParamTypeId() == 5){
									derivedAttrVals = assetInstVerDao.getDerivedAttributeValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
									String[] derval = derivedAttrVals.split("`!!`");
									if(derval[0].equals("0")){
										derivedAttrVals = derval[1];
									}else{
										derivedAttrVals = derval[0];
									}
									if(derivedAttrVals.contains("``")) {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}
										if(derivedAttrVals.contains("``")){
											derivedAttrVals = derivedAttrVals.replaceAll("``", "|");
										}
										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals = derivedAttrVals.replace("`~`", "~~");
										}
									}else {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}

										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals=derivedAttrVals.replace("`~`", ",");
										}
									}
									cell6 = row.createCell(tempColCount+x);
									cell6.setCellValue(derivedAttrVals.trim());
								}else if(astParName.getParamTypeId() == 6){
									derivedCompVal = assetInstVerDao.getDerivedComputationValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName,  astParName.getAssetParamName(), con);
									cell6 = row.createCell(tempColCount+x);
									cell6.setCellValue(derivedCompVal);
								} else if(astParName.getParamTypeId() == 8) {//full export
									cellVal = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
									String derivedAssetListValue = cellVal;
									String finalValue = "";
									String[] data = derivedAssetListValue.split("`!!`");
									if(data[0].equalsIgnoreCase("0")) {
										if(data.length == 2){
			        						finalValue = data[1];
			        					}else{
			        						finalValue = ""; 
			        					}
									}else {
										if(data.length == 2){
			        						finalValue = data[1];
			        					}else{
			        						finalValue = ""; 
			        					}
									}
									if(finalValue.contains("``")) {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}
										if(finalValue.contains("``")){
											finalValue = finalValue.replaceAll("``", "|");
										}
										if(finalValue.contains("`~`")){
											finalValue = finalValue.replace("`~`", "~~");
										}
									}else {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}

										if(finalValue.contains("`~`")){
											finalValue = finalValue.replace("`~`", ",");
										}
									}
									cellVal = finalValue;
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal);
								}
								if(astParName.getAssetParamName().equalsIgnoreCase(paramMapEntry.getKey())){
									// ************new changes for rich text****************
									if(paramMapEntry.getValue() != null && paramMapEntry.getValue().endsWith("~~") && (astParName.getParamTypeId() == 7 || astParName.getParamTypeId() == 1)){
										sb = new StringBuilder(paramMapEntry.getValue());
										sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
										sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
										if(sb.length() >= 32768){
											cellVal = " *** Limit exceeded for cell. ***";
										}else{
											cellVal = sb.toString();
										}
										
										cell6 = row.createCell(tempColCount+x);
										cell6.setCellValue(cellVal);
										// ******************* end********************
									}else if(paramMapEntry.getValue() != null && paramMapEntry.getValue().endsWith("``") && astParName.getParamTypeId() == 9 ){	
										ldapMaapingId = astParName.getLdapMappingId();										
										//List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMaapingId, con);
										sb = new StringBuilder(paramMapEntry.getValue());
										sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");
										sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");
										

										ldapmapping = sb.toString();
										
										paramValList = new ArrayList<String>(Arrays.asList(ldapmapping.split("``")));
										for(String data:paramValList) {
											String[] ldapmappingval = data.split("~~~~");
											ldapmappingdata.put(ldapmappingval[0], Integer.parseInt(ldapmappingval[1]));
										}

										if(!ldapmappingdata.isEmpty()) {
											List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMaapingId, con);
											for(LdapMapping attribute:ldapMappingList){
												for (Map.Entry<String,Integer> entry : ldapmappingdata.entrySet()) {
													//List<String> attributeData = new ArrayList<String>(Arrays.asList(atributes.split("~~~~")));
													if(attribute.getLdapAttributeId() == entry.getValue()) {
														Cell cell0b14 = row.createCell(tempColCount +x);
														cell0b14.setCellValue(entry.getKey());
														x++;
													}
												}
											}
										}																																																
									}else{
										cell6 = row.createCell(tempColCount+x);
										cell6.setCellValue(paramMapEntry.getValue());
									}
									
									if(astParName.getParamTypeId() == 9 ){
										if(!ldapmappingdata.isEmpty()){
											colCount = colCount+ldapmappingdata.size();
										}
										break;
									}else{
										colCount++;
										break;
									}
									
								}else{									
									if(astParName.getParamTypeId() == 9) {
										List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(astParName.getLdapMappingId(), con);
										x = x+ldapMappingList.size();
									}else{
										x++;
									}
								}
								
								if (log.isDebugEnabled()) {
									log.debug("setExcelDataAssetAttributes || Print "+(tempColCount+x)+"th cell data " + System.currentTimeMillis());
								}
							}
						}
						
						cell7 = row.createCell(5+paramcount);
						cell7.setCellValue(attributeExportVo.getTaxonomyName());
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print "+(5+assetParamList.size())+"th cell data " + System.currentTimeMillis());
						}

						cell8 = row.createCell(6+paramcount);
						cell8.setCellValue(attributeExportVo.getTagName());
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print "+(6+assetParamList.size())+"th cell data " + System.currentTimeMillis());
						}
						
					}else{ 

						cell = row.createCell(0);
						cell.setCellValue(attributeExportVo.getAssetInstVersionId());
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print 1st cell data " + System.currentTimeMillis());
						}

						cell2 = row.createCell(1);
						cell2.setCellValue(attributeExportVo.getAssetInstName());
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print 2nd cell data " + System.currentTimeMillis());
						}

						cell3 = row.createCell(2);
						if(attributeExportVo.getVersionName() == null || attributeExportVo.getVersionable() == null || attributeExportVo.getVersionable() == false){
							cell3.setCellValue("NA");
						}else{
							cell3.setCellValue(attributeExportVo.getVersionName());
						}
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print 3rd cell data " + System.currentTimeMillis());
						}
						
						cell4 = row.createCell(3);
						if(attributeExportVo.getDescription() != null && attributeExportVo.getDescription().length() >= 32768){
							cell4.setCellValue(" *** Limit exceeded for cell. ***");
						}else{
							cell4.setCellValue(attributeExportVo.getDescription());
						}
						
						if(attributeExportVo.getCreatedOn() != null){
							SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
							String dateStr = formatter.format(attributeExportVo.getCreatedOn());
							cell5.setCellValue(dateStr);
						}else{
							cell5.setCellValue("");
						}
						
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print 4th cell data " + System.currentTimeMillis());
						}

						hm = attributeExportVo.getParamNamewithvalue();
						for(Map.Entry<String, String> paramMapEntry : hm.entrySet()){
							Map<String,Integer> ldapmappingdata = new LinkedHashMap<String,Integer>();
							int x = 0;
							int ldapMaapingId = 0;
							String ldapmapping = null;
							List<String> paramValList = new ArrayList<String>();
							for(AssetParamDef astParName : assetParamList){
								if(astParName.getParamTypeId() == 5){
									derivedAttrVals = assetInstVerDao.getDerivedAttributeValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
									String[] derval = derivedAttrVals.split("`!!`");
									if(derval.length > 1){
										if(derval[0].equals("0")){
											derivedAttrVals = derval[1];
										}else{
											derivedAttrVals = derval[0];
										}
									}
									if(derivedAttrVals.contains("``")) {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}
										if(derivedAttrVals.contains("``")){
											derivedAttrVals = derivedAttrVals.replaceAll("``", "|");
										}
										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals = derivedAttrVals.replace("`~`", "~~");
										}
									}else {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}

										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals=derivedAttrVals.replace("`~`", ",");
										}
									}
									cell6 = row.createCell(tempColCount+x);
									cell6.setCellValue(derivedAttrVals.trim());
								}else if(astParName.getParamTypeId() == 6){
									derivedCompVal = assetInstVerDao.getDerivedComputationValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName,  astParName.getAssetParamName(), con);
									cell6 = row.createCell(tempColCount+x);
									cell6.setCellValue(derivedCompVal);
								} else if(astParName.getParamTypeId() == 8) {//full export
									cellVal = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
									String derivedAssetListValue = cellVal;
									String finalValue = "";
									String[] data = derivedAssetListValue.split("`!!`");
									if(data[0].equalsIgnoreCase("0")) {
										if(data.length == 2){
			        						finalValue = data[1];
			        					}else{
			        						finalValue = ""; 
			        					}
									}else {
										if(data.length == 2){
			        						finalValue = data[1];
			        					}else{
			        						finalValue = ""; 
			        					}
									}
									if(finalValue.contains("``")) {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}
										if(finalValue.contains("``")){
											finalValue = finalValue.replaceAll("``", "|");
										}
										if(finalValue.contains("`~`")){
											finalValue = finalValue.replace("`~`", "~~");
										}
									}else {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}

										if(finalValue.contains("`~`")){
											finalValue = finalValue.replace("`~`", ",");
										}
									}
									cellVal = finalValue;
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal);
								}
								if(astParName.getAssetParamName().equalsIgnoreCase(paramMapEntry.getKey())){
									// ************new changes for rich text****************
									if(paramMapEntry.getValue() != null && paramMapEntry.getValue().endsWith("~~") && (astParName.getParamTypeId() == 7 || astParName.getParamTypeId() == 1)){
										sb = new StringBuilder(paramMapEntry.getValue());
										sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
										sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
										if(sb.length() >= 32768){
											cellVal = " *** Limit exceeded for cell. ***";
										}else{
											cellVal = sb.toString();
										}
										
										cell6 = row.createCell(tempColCount+x);
										cell6.setCellValue(cellVal);
										// ************new changes for rich text****************
									}else if( paramMapEntry.getValue() != null && paramMapEntry.getValue().endsWith("``") && astParName.getParamTypeId() == 9 ){	
										ldapMaapingId = astParName.getLdapMappingId();										
										//List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMaapingId, con);
										sb = new StringBuilder(paramMapEntry.getValue());
										sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");
										sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");
										
										ldapmapping = sb.toString();
										
										paramValList = new ArrayList<String>(Arrays.asList(ldapmapping.split("``")));
										for(String data:paramValList) {
											String[] ldapmappingval = data.split("~~~~");
											ldapmappingdata.put(ldapmappingval[0], Integer.parseInt(ldapmappingval[1]));
										}

										if(!ldapmappingdata.isEmpty()) {
											List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMaapingId, con);
											for(LdapMapping attribute:ldapMappingList){
												for (Map.Entry<String,Integer> entry : ldapmappingdata.entrySet()) {
													//List<String> attributeData = new ArrayList<String>(Arrays.asList(atributes.split("~~~~")));
													if(attribute.getLdapAttributeId() == entry.getValue()) {
														Cell cell0b14 = row.createCell(tempColCount +x);
														cell0b14.setCellValue(entry.getKey());
														x++;
													}
												}
											}
										}
									}else{
										cell6 = row.createCell(tempColCount+x);
										cell6.setCellValue(paramMapEntry.getValue());
									}
									if(astParName.getParamTypeId() == 9 ){
										if(!ldapmappingdata.isEmpty()){
											colCount = colCount+ldapmappingdata.size();
										}
										break;
									}else{
										colCount++;
										break;
									}
									
								}else{
									if(astParName.getParamTypeId() == 9) {
										List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(astParName.getLdapMappingId(), con);
										x = x+ldapMappingList.size();
									}else{
										x++;
									}
								}
								
								if (log.isDebugEnabled()) {
									log.debug("setExcelDataAssetAttributes || Print "+(tempColCount+x)+"th cell data " + System.currentTimeMillis());
								}
							}
						}

						cell7 = row.createCell(5+paramcount);
						cell7.setCellValue(attributeExportVo.getTaxonomyName());
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print "+(5+assetParamList.size())+"th cell data " + System.currentTimeMillis());
						}

						cell8 = row.createCell(6+paramcount);
						cell8.setCellValue(attributeExportVo.getTagName());
						
						if (log.isDebugEnabled()) {
							log.debug("setExcelDataAssetAttributes || Print "+(6+assetParamList.size())+"th cell data " + System.currentTimeMillis());
						}

					}

					latestAssetInstanceVersionId = attributeExportVo.getAssetInstVersionId();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void setExcelDataAIRelationships(XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle ,List<AssetInstRelationship> assetInsRelList,String assetName){
		int rowNum = 0;
		try {
			XSSFRow rowa11 = mySheet.createRow(rowNum++);

			XSSFCell cell0b11=  rowa11.createCell(0);
			cell0b11.setCellValue(assetName);
			cell0b11.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b12=  rowa11.createCell(2);
			cell0b12.setCellValue("Source");
			cell0b12.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b13=  rowa11.createCell(7);
			cell0b13.setCellValue("Target");
			cell0b13.setCellStyle(cellHeaderStyle);

			XSSFRow rowa = mySheet.createRow(rowNum++);

			XSSFCell cell0a=  rowa.createCell(0);
			cell0a.setCellValue("Source Asset Type");
			cell0a.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b=  rowa.createCell(1);
			cell0b.setCellValue("Source Asset Instance Version Id");
			cell0b.setCellStyle(cellHeaderStyle);

			XSSFCell cell0c=  rowa.createCell(2);
			cell0c.setCellValue("Source Asset Instance");
			cell0c.setCellStyle(cellHeaderStyle);

			XSSFCell cell0d=  rowa.createCell(3);
			cell0d.setCellValue("Source Version Name");
			cell0d.setCellStyle(cellHeaderStyle);

			XSSFCell cell0e=  rowa.createCell(4);
			cell0e.setCellValue("Overview");
			cell0e.setCellStyle(cellHeaderStyle);

			XSSFCell cell0f=  rowa.createCell(5);
			cell0f.setCellValue("Relation Type");
			cell0f.setCellStyle(cellHeaderStyle);

			XSSFCell cell0g=  rowa.createCell(6);
			cell0g.setCellValue("Relation Name");
			cell0g.setCellStyle(cellHeaderStyle);

			XSSFCell cell0h=  rowa.createCell(7);
			cell0h.setCellValue("Target Asset Type");
			cell0h.setCellStyle(cellHeaderStyle);

			XSSFCell cell0i=  rowa.createCell(8);
			cell0i.setCellValue("Target Asset Instance Version Id");
			cell0i.setCellStyle(cellHeaderStyle);

			XSSFCell cell0j=  rowa.createCell(9);
			cell0j.setCellValue("Target Asset Instance");
			cell0j.setCellStyle(cellHeaderStyle);

			XSSFCell cell0k=  rowa.createCell(10);
			cell0k.setCellValue("Target Version Name");
			cell0k.setCellStyle(cellHeaderStyle);

			XSSFCell cell0l=  rowa.createCell(11);
			cell0l.setCellValue("Overview");
			cell0l.setCellStyle(cellHeaderStyle);

			Row row = null;
			Cell cell = null;
			Cell cell2 = null;
			Cell cell3 = null;
			Cell cell4 = null;
			Cell cell5 = null;
			Cell cell6 = null;
			Cell cell7 = null;
			Cell cell8 = null;
			Cell cell9 = null;
			Cell cell10 = null;
			Cell cell11 = null;
			Cell cell12 = null;

			if(assetInsRelList != null){
				for (AssetInstRelationship assetInsrelVo : assetInsRelList) {
					row = mySheet.createRow(rowNum++);
					cell = row.createCell(0);
					cell.setCellValue(assetInsrelVo.getSrcAssetName());
					cell2 = row.createCell(1);
					cell2.setCellValue(assetInsrelVo.getSrcAssetId());
					cell3 = row.createCell(2);
					cell3.setCellValue(assetInsrelVo.getSourceInstanceName());
					cell4 = row.createCell(3);
					cell4.setCellValue(assetInsrelVo.getSourceVersionName());
					cell5 = row.createCell(4);
					cell5.setCellValue(assetInsrelVo.getSourceDescription());
					cell6 = row.createCell(5);
					cell6.setCellValue(assetInsrelVo.getRelationShipName());
					cell7 = row.createCell(6);
					cell7.setCellValue(assetInsrelVo.getType());
					cell8 = row.createCell(7);
					cell8.setCellValue(assetInsrelVo.getDestAssetName());
					cell9 = row.createCell(8);
					cell9.setCellValue(assetInsrelVo.getDestAssetId());
					cell10 = row.createCell(9);
					cell10.setCellValue(assetInsrelVo.getDestInstanceName());
					cell11 = row.createCell(10);
					cell11.setCellValue(assetInsrelVo.getDestInstanceVersionName());
					cell12 = row.createCell(11);
					cell12.setCellValue(assetInsrelVo.getDestdescription());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<AssetInstanceVersion> getAssetInstanceVersionsNonStaticExport(Connection con,String assetName){
		ExcelExportDao exportDao = new ExcelExportDao();
		List<AssetInstanceVersion> assetInstanceVersionList = null;
		try{
			assetInstanceVersionList = exportDao.getAssetInstanceVersionsNonStaticExport(con, assetName);
		}catch(Exception e){
			e.printStackTrace();
		}
		return assetInstanceVersionList;
	}

	public List<AssetInstanceVersion> getAssetParamDtlsStaticExport(Connection con,String assetName, String assetParamName){
		ExcelExportDao exportDao = new ExcelExportDao();
		List<AssetInstanceVersion> assetParams = null;
		try{
			assetParams = exportDao.getAssetParamDtlsStaticExport(con, assetName,assetParamName);
		}catch(Exception e){
			e.printStackTrace();
		}
		return assetParams;
	}

	/**
	 * @method excelExportQuickSearch
	 * @description Export excel for quick search
	 * @param searchString
	 * @param options
	 * @param userName
	 * @return Excel(.xlxs file)
	 * @throws RepoproException
	 */
	@GET
	@Path("/exportQuickSearch")
//	@Produces("application/vnd.ms-excel")
	@Encoded
	@Produces("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	public Response excelExportQuickSearch(@QueryParam("searchString") String searchString,
			@QueryParam("options") String options,
			@QueryParam("userName") String userName)throws RepoproException{

		log.trace("excelExportQuickSearch || Begin");

		long startTime = System.currentTimeMillis();
//		String downloadName = options+"_"+searchString +"_"+System.currentTimeMillis()+"".concat(".xlsx");
		String downloadName = "Quick_search_result_"+System.currentTimeMillis()+"".concat(".xlsx");
//		System.setProperty("java.io.tmpdir", "C:\\temp\\");
//		File file = new File(FILE_PATH+downloadName);
		ResponseBuilder response = null;
		SearchDao searchDao = new SearchDao();
		Connection conn = null;
		FileOutputStream fileOutputStream = null;
		XSSFSheet mySheet = null;
		Runtime r = Runtime.getRuntime();
		try{
			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			mySheet = myWorkBook.createSheet("Quick Search Details");

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);
			File file = File.createTempFile(downloadName, "");

			file.deleteOnExit();
			fileOutputStream = new FileOutputStream(file);
			if (log.isTraceEnabled()) {
				log.trace("excelExportQuickSearch || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			
			searchString = searchString.trim();
			options = options.trim();
			userName = userName.trim();
			
			searchString = URLDecoder.decode(searchString, "UTF-8");
			options = URLDecoder.decode(options, "UTF-8");
			
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("excelExportQuickSearch || dao call of search() method to retrieve Search Details list");
			}

			SearchResponse schResp = searchDao.search(searchString, options, userName, conn, false, 0,0, null, null, false);

			printExcelQuickSearch(mySheet,cellHeaderStyle,schResp,options);

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

			log.info("Total time taken for Quick Search Export :"+(System.currentTimeMillis() - startTime)/1000 +" secs");
		}catch(RepoproException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			log.error("Null pointer exception excelExportQuickSearch ||"
					+ e.getMessage());
		}catch(IOException e){
			log.error("IO Exception excelExportQuickSearch ||"
					+ e.getMessage());
		}catch(Exception e){
			log.error("Exception excelExportQuickSearch ||"
					+ e.getMessage());
		}finally{
			try {
				fileOutputStream.close();
			} catch (IOException e) {
				log.error("IO Exception excelExportQuickSearch ||"
						+ e.getMessage());
			}
			if (log.isDebugEnabled()) {
				log.debug("excelExportQuickSearch ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("excelExportQuickSearch || End");
		r.gc();
		return response.build();
	}
	
	/**
	 * @method excelExportGamificationPoints
	 * @description Export excel for Leader board
	 * @return Excel(.xlxs file)
	 * @throws RepoproException
	 */
	@GET
	@Path("/exportInExcelGamificationPoints")
	//	@Produces("application/vnd.ms-excel")
	public void excelExportGamificationPoints(@QueryParam("userName") String userName)throws RepoproException{

		log.trace("excelExportGamificationPoints || Begin");
		long startTime = System.currentTimeMillis();
		downloadName = "Leader_Board_Rank_Details_"+System.currentTimeMillis()+"".concat(".xlsx");
		File file = new File(FILE_PATH+downloadName);
		ResponseBuilder response = null;
		Connection conn = null;
		XSSFSheet mySheet = null;
		FileOutputStream fileOutputStream = null;

		Map<String, Integer> mapList = new LinkedHashMap<String, Integer>();
		UserDao userDao = new UserDao();
		User user = null;

		List<GamificationDetails> gamelist = new ArrayList<GamificationDetails>();
		GamificationDetails gamepoint = new GamificationDetails();
		Runtime r = Runtime.getRuntime();
		try{

			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			mySheet = myWorkBook.createSheet("Leader Board Rank Details");

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);

			fileOutputStream = new FileOutputStream(file);
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("excelExportGamificationPoints || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("excelExportGamificationPoints || dao call of getAllUserProfiles() method to retrieve user list");
			}

			mapList = LeaderBoardUtil.getLeaderBoardRankForExport(userName);
			gamepoint.setMapPointList(mapList);
			gamelist.add(gamepoint);

			String tempStr = "";
			String[] splitArray ;
			String pointVal = "";
			String rankVal = "";
			String nameVal = ""; 
			List<HashMap<String,String>> pointMapList = new ArrayList<HashMap<String,String>>();
			for(GamificationDetails gameDetail : gamelist){
				Map<String, Integer> pointDtlsMap = gameDetail.getMapPointList();
				for(Map.Entry<String, Integer> pointEntry : pointDtlsMap.entrySet()){
					tempStr = pointEntry.getKey();
					splitArray = tempStr.split("~");
					rankVal = pointEntry.getValue().toString();
					pointVal = splitArray[0];
					nameVal = splitArray[1]; 
					HashMap<String, String> pointMap = new HashMap<String, String>();
					pointMap.put("rank",rankVal);
					pointMap.put("name",nameVal);
					pointMap.put("point",pointVal);
					pointMapList.add(pointMap);
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("excelExportGamificationPoints ||Export of ranks along with points :"
						+ gamepoint.getMapPointList().toString());
			}

			exportGamificationPoints(mySheet,cellHeaderStyle, pointMapList);
			conn.commit();

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

			user = userDao.retProfileForUserName("admin", conn);
			MailTemplateDao mailDao = new MailTemplateDao();
			MailConfig mailConfig = mailDao.getMailConfig(conn);
			SendEmail.sendAttachedMail(mailConfig,user.getEmailId(), "RepoPro Export XLSX: Successful", MessageUtil.getMessage(Constants.EMAIL_HDR) + "Export of Leader Board Details as XLSX was successful. Please find the file in attachment.\n\nRepoPro "  + MessageUtil.getMessage(Constants.EMAIL_NOTE),downloadName,FILE_PATH+downloadName);

			log.info("Time taken for Leader board Export :"+(System.currentTimeMillis() - startTime)/1000+" Secs");
		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			try {
				fileOutputStream.close();
			} catch (IOException e1) {
				log.debug("excelExportGamificationPoints ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			if (log.isDebugEnabled()) {
				log.debug("excelExportGamificationPoints ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("excelExportGamificationPoints || End");
		r.gc();
		//		return response.build();
	}

	/**
	 * @method excelExportGamificationPointViewDetails
	 * @description Export excel for Leader board view all
	 * @return Excel(.xlxs file)
	 * @throws RepoproException
	 */
	@GET
	@Path("/exportInExcelGamificationPointViewDetails")
//	@Produces("application/vnd.ms-excel")
	public void excelExportGamificationPointViewDetails(@QueryParam("userName") String userName)throws RepoproException{

		log.trace("excelExportGamificationPointViewDetails || Begin");
		long startTime = System.currentTimeMillis();
		Calendar calendar = Calendar.getInstance();
		downloadName = "Leader_Board_Details_"+System.currentTimeMillis()+"".concat(".xlsx");
		File file = new File(FILE_PATH+downloadName);
		ResponseBuilder response = null;
		Connection conn = null;
		XSSFSheet mySheet = null;
		FileOutputStream fileOutputStream = null;

		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDao gamificationDao = new GamificationDao();
		UserDao userDao = new UserDao();
		User user = null;
		Runtime r = Runtime.getRuntime();
		try{

			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			mySheet = myWorkBook.createSheet("Leader Board Details");

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);

			fileOutputStream = new FileOutputStream(file);
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("excelExportGamificationPointViewDetails || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("excelExportGamificationPointViewDetails || dao call of retGamificationDetails() method to retrieve Game Details list");
			}

			gameDetailsList = gamificationDao.retGamificationDetailsExport(userName, conn);

			for (int i = 0; i < gameDetailsList.size(); i++) {
				String instanceData = gameDetailsList.get(i)
						.getInstanceDetails();
				String[] splitedArray = instanceData.split("~");
				gameDetailsList.get(i).setAssetName(splitedArray[0]);
				gameDetailsList.get(i).setAssetInstanceName(splitedArray[1]);
				gameDetailsList.get(i).setAssetInstanceVersionName(
						splitedArray[2]);

			}

			if (log.isDebugEnabled()) {
				log.debug("excelExportGamificationPointViewDetails ||list of game details:"
						+ gameDetailsList.size() + "retrieved successfully");
			}

			exportGamificationPointDtls(mySheet,cellHeaderStyle, gameDetailsList);
			conn.commit();
			
			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

			user = userDao.retProfileForUserName("admin", conn);
			MailTemplateDao mailDao = new MailTemplateDao();
			MailConfig mailConfig = mailDao.getMailConfig(conn);
			SendEmail.sendAttachedMail(mailConfig,user.getEmailId(), "RepoPro Export XLSX: Successful", MessageUtil.getMessage(Constants.EMAIL_HDR) + "Export of Leader Board Ranks Details as XLSX was successful. Please find the file in attachment.\n\nRepoPro "  + MessageUtil.getMessage(Constants.EMAIL_NOTE),downloadName,FILE_PATH+downloadName);

			log.info("Time taken for Leader board point details Export :"+(System.currentTimeMillis() - startTime)/1000+" Secs");
		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			try {
				fileOutputStream.close();
			} catch (IOException e) {
				log.error("IO Exception excelExportGamificationPointViewDetails ||"
						+ e.getMessage());
			}
			if (log.isDebugEnabled()) {
				log.debug("exportGamificationPointDtls ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("excelExportGamificationPointViewDetails || End");
		r.gc();
//		return response.build();
	}
	
	public void printExcelQuickSearch(XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle , SearchResponse searchResult , String options){
		int rowNum = 0;
		try {
			HashSet<Object> respObjHashSet = new HashSet<Object>(); 
			String finalDescriptionWithMetadata = "";
			HashMap<String, Object> paramMap = new HashMap<String, Object>();
			respObjHashSet =  (HashSet<Object>) searchResult.getSearchResponse();
			int tempTaxonomyMasterCount = 0;
			int tempTaxonomyMasterCount2 = 0;
			int tempAssetInstanceCnt1 = 0;
			int tempAssetInstanceCnt2 = 0;
			int tempParamCnt = 0;
			int tempAssetCnt = 0;
			int tempTaggingCount = 0;
			int tempProfileCount = 0;
			HashMap<Long , String> tempTaxonomyMap = new HashMap<Long, String>();
			String[] splitArray = new String[10];
			String splitedText = "";

			/*QuickSearch respObjSetdemo = new QuickSearch();
			int tempCount = 0;
			for(Object objt : respObjHashSet){
				respObjSetdemo = (QuickSearch) objt;
				if(respObjSetdemo.getSearchBy().equalsIgnoreCase("Profile")){
					tempCount++;
				}
			}*/

			Row row = null;

			XSSFRow rowa = null;
			XSSFCell cell0a = null;
			XSSFCell cell0b =  null;
			XSSFCell cell0c =  null;
			XSSFCell cell0d =  null;
			XSSFCell cell0e =  null;
			XSSFCell cell0f =  null;

			Cell cell0 = null;
			Cell cell1 = null;
			Cell cell2 = null;
			Cell cell3 = null;
			Cell cell4 = null;
			Cell cell5 = null;
			Cell cell10 = null;
			Cell cell11 = null;
			Cell cell12 = null;

			XSSFRow rowb = null;
			XSSFCell cell1a = null;
			XSSFCell cell1b = null;
			XSSFCell cell1c = null;
			XSSFCell cell1d = null;
			XSSFCell cell1e = null;

			Cell cell0p = null;
			Cell cell1p = null;
			Cell cell2p = null;
			Cell cell3p = null;
			Cell cell4p = null;

			if(options.equalsIgnoreCase("keyword")){

				QuickSearch respObjSet = new QuickSearch();
				ArrayList<QuickSearch> finalList = new ArrayList<QuickSearch>();
				for(Object objt : respObjHashSet){
					respObjSet = (QuickSearch) objt;
					finalList.add(respObjSet);
				}
				Collections.sort(finalList , new QuickSearchSearchByComparator());


				int tempFirstCount = 0;
				int tempFirstCount2 = 0;

				for(QuickSearch qs : finalList){

					if(qs.getSearchBy().equalsIgnoreCase("Asset Instance")){

						if(tempAssetInstanceCnt1 == 0){
							rowa = mySheet.createRow(rowNum++);

							cell0a =  rowa.createCell(0);
							cell0a.setCellValue("Category");
							cell0a.setCellStyle(cellHeaderStyle);

							cell0b =  rowa.createCell(1);
							cell0b.setCellValue("Asset Name");
							cell0b.setCellStyle(cellHeaderStyle);

							cell0c =  rowa.createCell(2);
							cell0c.setCellValue("Asset Instance Version Id");
							cell0c.setCellStyle(cellHeaderStyle);

							cell0d =  rowa.createCell(3);
							cell0d.setCellValue("Asset Instance Name");
							cell0d.setCellStyle(cellHeaderStyle);

							cell0e =  rowa.createCell(4);
							cell0e.setCellValue("Version Name");
							cell0e.setCellStyle(cellHeaderStyle);

							cell0f =  rowa.createCell(5);
							cell0f.setCellValue("Description");
							cell0f.setCellStyle(cellHeaderStyle);

							tempAssetInstanceCnt1++;
						}

						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Assets Instance");

						cell1 = row.createCell(1);
						if(qs.getAssetName() != null){
							cell1.setCellValue(qs.getAssetName());
						}else{
							cell1.setCellValue("");
						}

						cell2 = row.createCell(2);
						if(qs.getAssetInstVersionId() != null){
							cell2.setCellValue(qs.getAssetInstVersionId()); 
						}else{
							cell2.setCellValue(""); 
						}

						cell3 = row.createCell(3);
						if(qs.getAssetInstName() != null){
							cell3.setCellValue(qs.getAssetInstName()); 
						}else{
							cell3.setCellValue(""); 
						}

						cell4 = row.createCell(4);
						if(qs.getVersionName() != null){
							cell4.setCellValue(qs.getVersionName()); 
						}else{
							cell4.setCellValue(""); 
						}

						if(qs.getParamMap() != null){
							paramMap = qs.getParamMap();
							finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
							for(Map.Entry<String,Object> entry:paramMap.entrySet()){
								splitArray = entry.getKey().split("`~`",2);
								splitedText = splitArray[0];
								finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
							}
						}else{
							finalDescriptionWithMetadata = qs.getAssetInstDescription();
						}
						
						cell5 = row.createCell(5);
						if(qs.getAssetInstDescription() != null){
							if(finalDescriptionWithMetadata.length() >= 32768){
								cell5.setCellValue(" *** Limit exceeded for cell. ***");
							}else{
								cell5.setCellValue(finalDescriptionWithMetadata);
							}
						}else{
							cell5.setCellValue("");
						}
					}
					if(qs.getSearchBy().equalsIgnoreCase("Asset")){

						if(tempAssetCnt == 0){
							rowa = mySheet.createRow(rowNum++);

							cell0a=  rowa.createCell(0);
							cell0a.setCellValue("Category");
							cell0a.setCellStyle(cellHeaderStyle);

							cell0b=  rowa.createCell(1);
							cell0b.setCellValue("Asset Name");
							cell0b.setCellStyle(cellHeaderStyle);

							cell0f=  rowa.createCell(2);
							cell0f.setCellValue("Description");
							cell0f.setCellStyle(cellHeaderStyle);

							tempAssetCnt++;
						}

						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Asset");

						cell1 = row.createCell(1);
						if(qs.getAssetName() != null){
							cell1.setCellValue(qs.getAssetName());
						}else{
							cell1.setCellValue("");
						}

						if(qs.getParamMap() != null){
							paramMap = qs.getParamMap();
							finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
							for(Map.Entry<String,Object> entry:paramMap.entrySet()){
								splitArray = entry.getKey().split("`~`",2);
								splitedText = splitArray[0];
								finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
							}
						}else{
							finalDescriptionWithMetadata = qs.getAssetDescription();
						}

						cell2 = row.createCell(2);
						if(qs.getAssetDescription() != null){
							if(finalDescriptionWithMetadata.length() >= 32768){
								cell2.setCellValue(" *** Limit exceeded for cell. ***");
							}else{
								cell2.setCellValue(finalDescriptionWithMetadata);
							}
						}else{
							cell2.setCellValue("");
						}
					}
					if(qs.getSearchBy().equalsIgnoreCase("Parameters")){

						if(tempParamCnt == 0){
							rowa = mySheet.createRow(rowNum++);

							cell0a=  rowa.createCell(0);
							cell0a.setCellValue("Category");
							cell0a.setCellStyle(cellHeaderStyle);

							cell0b=  rowa.createCell(1);
							cell0b.setCellValue("Asset Name");
							cell0b.setCellStyle(cellHeaderStyle);

							cell0c=  rowa.createCell(2);
							cell0c.setCellValue("Asset Instance Version Id");
							cell0c.setCellStyle(cellHeaderStyle);

							cell0d=  rowa.createCell(3);
							cell0d.setCellValue("Asset Instance Name");
							cell0d.setCellStyle(cellHeaderStyle);

							cell0e=  rowa.createCell(4);
							cell0e.setCellValue("Version Name");
							cell0e.setCellStyle(cellHeaderStyle);

							cell0f=  rowa.createCell(5);
							cell0f.setCellValue("Description");
							cell0f.setCellStyle(cellHeaderStyle);

							tempParamCnt++;
						}

						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Parameters");

						cell1 = row.createCell(1);
						if(qs.getAssetName() != null){
							cell1.setCellValue(qs.getAssetName());
						}else{
							cell1.setCellValue("");
						}

						cell2 = row.createCell(2);
						if(qs.getAssetInstVersionId() != null){
							cell2.setCellValue(qs.getAssetInstVersionId()); 
						}else{
							cell2.setCellValue(""); 
						}

						cell3 = row.createCell(3);
						if(qs.getAssetInstName() != null){
							cell3.setCellValue(qs.getAssetInstName()); 
						}else{
							cell3.setCellValue(""); 
						}

						cell4 = row.createCell(4);
						if(qs.getVersionName() != null){
							cell4.setCellValue(qs.getVersionName()); 
						}else{
							cell4.setCellValue(""); 
						}

						if(qs.getParamMap() != null){
							paramMap = qs.getParamMap();
							finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
							for(Map.Entry<String,Object> entry:paramMap.entrySet()){
								splitArray = entry.getKey().split("`~`",2);
								splitedText = splitArray[0];
								finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
							}
						}else{
							finalDescriptionWithMetadata = qs.getAssetInstDescription();
						}

						cell5 = row.createCell(5);
						if(qs.getAssetInstDescription() != null){
							if(finalDescriptionWithMetadata.length() >= 32768){
								cell5.setCellValue(" *** Limit exceeded for cell. ***");
							}else{
								cell5.setCellValue(finalDescriptionWithMetadata);
							}
						}else{
							cell5.setCellValue("");
						}
					}
					if(qs.getSearchBy().equalsIgnoreCase("Profile")){

						if(tempProfileCount == 0){
							rowNum++;
							rowb = mySheet.createRow(rowNum++);

							cell1a =  rowb.createCell(0);
							cell1a.setCellValue("Category");
							cell1a.setCellStyle(cellHeaderStyle);

							cell1b=  rowb.createCell(1);
							cell1b.setCellValue("UserName");
							cell1b.setCellStyle(cellHeaderStyle);

							cell1c=  rowb.createCell(2);
							cell1c.setCellValue("Full Name");
							cell1c.setCellStyle(cellHeaderStyle);

							cell1d=  rowb.createCell(3);
							cell1d.setCellValue("Department");
							cell1d.setCellStyle(cellHeaderStyle);

							cell1e=  rowb.createCell(4);
							cell1e.setCellValue("Email Id");
							cell1e.setCellStyle(cellHeaderStyle);
							
							tempProfileCount++;

						}

						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Profile");

						cell1 = row.createCell(1);
						cell1.setCellValue(qs.getUserName());

						cell2 = row.createCell(2);
						cell2.setCellValue(qs.getDecryptedFullName()); 

						cell3 = row.createCell(3);
						cell3.setCellValue(qs.getDecryptedDept()); 

						cell4 = row.createCell(4);
						cell4.setCellValue(qs.getDecryptedEmailId());
						

//						tempFirstCount++;
					}
					if(qs.getSearchBy().equalsIgnoreCase("Asset Instance^Taxonomy") || qs.getSearchBy().equalsIgnoreCase("Taxonomy")){
						
						if(qs.getAssetInstVersionId() != null){
							if(tempFirstCount == 0){

								rowa = mySheet.createRow(rowNum++);

								cell0a=  rowa.createCell(0);
								cell0a.setCellValue("Category");
								cell0a.setCellStyle(cellHeaderStyle);

								cell0b=  rowa.createCell(1);
								cell0b.setCellValue("Asset Name");
								cell0b.setCellStyle(cellHeaderStyle);

								cell0c=  rowa.createCell(2);
								cell0c.setCellValue("Asset Instance Version Id");
								cell0c.setCellStyle(cellHeaderStyle);

								cell0d=  rowa.createCell(3);
								cell0d.setCellValue("Asset Instance Name");
								cell0d.setCellStyle(cellHeaderStyle);

								cell0e=  rowa.createCell(4);
								cell0e.setCellValue("Version Name");
								cell0e.setCellStyle(cellHeaderStyle);

								cell0f=  rowa.createCell(5);
								cell0f.setCellValue("Description");
								cell0f.setCellStyle(cellHeaderStyle);

								tempFirstCount++;
							}
							row = mySheet.createRow(rowNum++);

							cell0 = row.createCell(0);
							cell0.setCellValue("By Taxonomy");

							cell1 = row.createCell(1);
							if(qs.getAssetName() != null){
								cell1.setCellValue(qs.getAssetName());
							}else{
								cell1.setCellValue("");
							}

							cell2 = row.createCell(2);
							if(qs.getAssetInstVersionId() != null){
								cell2.setCellValue(qs.getAssetInstVersionId()); 
							}else{
								cell2.setCellValue(""); 
							}

							cell3 = row.createCell(3);
							if(qs.getAssetInstName() != null){
								cell3.setCellValue(qs.getAssetInstName()); 
							}else{
								cell3.setCellValue(""); 
							}

							cell4 = row.createCell(4);
							if(qs.getVersionName() != null){
								cell4.setCellValue(qs.getVersionName()); 
							}else{
								cell4.setCellValue(""); 
							}

							if(qs.getParamMap() != null){
								paramMap = qs.getParamMap();
								finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
								for(Map.Entry<String,Object> entry:paramMap.entrySet()){
									splitArray = entry.getKey().split("`~`",2);
									splitedText = splitArray[0];
									finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
								}
							}else{
								finalDescriptionWithMetadata = qs.getAssetInstDescription();
							}

							cell5 = row.createCell(5);
							if(qs.getAssetInstDescription() != null){
								if(finalDescriptionWithMetadata.length() >= 32768){
									cell5.setCellValue(" *** Limit exceeded for cell. ***");
								}else{
									cell5.setCellValue(finalDescriptionWithMetadata);
								}
							}else{
								cell5.setCellValue("");
							}

						}else{
							// ********************* new changes *******************
							if(qs.getSearchBy().equalsIgnoreCase("Asset Instance^Taxonomy")){
								if(tempFirstCount == 0){

									rowa = mySheet.createRow(rowNum++);

									cell0a=  rowa.createCell(0);
									cell0a.setCellValue("Category");
									cell0a.setCellStyle(cellHeaderStyle);

									cell0b=  rowa.createCell(1);
									cell0b.setCellValue("Asset Name");
									cell0b.setCellStyle(cellHeaderStyle);

									cell0c=  rowa.createCell(2);
									cell0c.setCellValue("Asset Instance Version Id");
									cell0c.setCellStyle(cellHeaderStyle);

									cell0d=  rowa.createCell(3);
									cell0d.setCellValue("Asset Instance Name");
									cell0d.setCellStyle(cellHeaderStyle);

									cell0e=  rowa.createCell(4);
									cell0e.setCellValue("Version Name");
									cell0e.setCellStyle(cellHeaderStyle);

									cell0f=  rowa.createCell(5);
									cell0f.setCellValue("Description");
									cell0f.setCellStyle(cellHeaderStyle);

									tempFirstCount++;
								}
								row = mySheet.createRow(rowNum++);

								cell0 = row.createCell(0);
								cell0.setCellValue("By Taxonomy");

								cell1 = row.createCell(1);
								if(qs.getAssetName() != null){
									cell1.setCellValue(qs.getAssetName());
								}else{
									cell1.setCellValue("");
								}

								cell2 = row.createCell(2);
								if(qs.getAssetInstVersionId() != null){
									cell2.setCellValue(qs.getAssetInstVersionId()); 
								}else{
									cell2.setCellValue(""); 
								}

								cell3 = row.createCell(3);
								if(qs.getAssetInstName() != null){
									cell3.setCellValue(qs.getAssetInstName()); 
								}else{
									cell3.setCellValue(""); 
								}

								cell4 = row.createCell(4);
								if(qs.getVersionName() != null){
									cell4.setCellValue(qs.getVersionName()); 
								}else{
									cell4.setCellValue(""); 
								}

								if(qs.getParamMap() != null){
									paramMap = qs.getParamMap();
									finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
									for(Map.Entry<String,Object> entry:paramMap.entrySet()){
										splitArray = entry.getKey().split("`~`",2);
										splitedText = splitArray[0];
										finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
									}
								}else{
									finalDescriptionWithMetadata = qs.getAssetInstDescription();
								}

								cell5 = row.createCell(5);
								if(qs.getAssetInstDescription() != null){
									if(finalDescriptionWithMetadata.length() >= 32768){
										cell5.setCellValue(" *** Limit exceeded for cell. ***");
									}else{
										cell5.setCellValue(finalDescriptionWithMetadata);
									}
								}else{
									cell5.setCellValue("");
								}
								// ************************* end ******************************
							}else{
								HashMap<Long , Object> taxonomyMap = qs.getTaxonomyMap();
								if(taxonomyMap != null){
									for(Map.Entry<Long, Object> mapEntry : taxonomyMap.entrySet()){
										tempTaxonomyMap.put(mapEntry.getKey(), mapEntry.getValue().toString());
									}
								}
							}
							
						}
					}


					if(qs.getSearchBy().equalsIgnoreCase("Asset Instance^Tagging") || qs.getSearchBy().equalsIgnoreCase("Tagging")){

						if(tempTaggingCount == 0){

							rowa = mySheet.createRow(rowNum++);

							cell0a=  rowa.createCell(0);
							cell0a.setCellValue("Category");
							cell0a.setCellStyle(cellHeaderStyle);

							cell0b=  rowa.createCell(1);
							cell0b.setCellValue("Asset Name");
							cell0b.setCellStyle(cellHeaderStyle);

							cell0c=  rowa.createCell(2);
							cell0c.setCellValue("Asset Instance Version Id");
							cell0c.setCellStyle(cellHeaderStyle);

							cell0d=  rowa.createCell(3);
							cell0d.setCellValue("Asset Instance Name");
							cell0d.setCellStyle(cellHeaderStyle);

							cell0e=  rowa.createCell(4);
							cell0e.setCellValue("Version Name");
							cell0e.setCellStyle(cellHeaderStyle);

							cell0f=  rowa.createCell(5);
							cell0f.setCellValue("Description");
							cell0f.setCellStyle(cellHeaderStyle);

							tempTaggingCount++;
						}

						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Tagging");

						cell1 = row.createCell(1);
						if(qs.getAssetName() != null){
							cell1.setCellValue(qs.getAssetName());
						}else{
							cell1.setCellValue("");
						}

						cell2 = row.createCell(2);
						if(qs.getAssetInstVersionId() != null){
							cell2.setCellValue(qs.getAssetInstVersionId()); 
						}else{
							cell2.setCellValue(""); 
						}

						cell3 = row.createCell(3);
						if(qs.getAssetInstName() != null){
							cell3.setCellValue(qs.getAssetInstName()); 
						}else{
							cell3.setCellValue(""); 
						}

						cell4 = row.createCell(4);
						if(qs.getVersionName() != null){
							cell4.setCellValue(qs.getVersionName()); 
						}else{
							cell4.setCellValue(""); 
						}

						if(qs.getParamMap() != null){
							paramMap = qs.getParamMap();
							finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
							for(Map.Entry<String,Object> entry:paramMap.entrySet()){
								splitArray = entry.getKey().split("`~`",2);
								splitedText = splitArray[0];
								finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
							}
						}else{
							finalDescriptionWithMetadata = qs.getAssetInstDescription();
						}

						cell5 = row.createCell(5);
						if(qs.getAssetInstDescription() != null){
							if(finalDescriptionWithMetadata.length() >= 32768){
								cell5.setCellValue(" *** Limit exceeded for cell. ***");
							}else{
								cell5.setCellValue(finalDescriptionWithMetadata);
							}
						}else{
							cell5.setCellValue("");
						}
					}

				}

				if(tempTaxonomyMap.entrySet().size() != 0){

					if(tempTaxonomyMasterCount2 == 0){

						rowNum++;
						rowb = mySheet.createRow(rowNum++);

						cell1a=  rowb.createCell(0);
						cell1a.setCellValue("Category");
						cell1a.setCellStyle(cellHeaderStyle);

						cell1b=  rowb.createCell(1);
						cell1b.setCellValue("Taxonomy Id");
						cell1b.setCellStyle(cellHeaderStyle);

						cell1c=  rowb.createCell(2);
						cell1c.setCellValue("Taxonomy Name");
						cell1c.setCellStyle(cellHeaderStyle);

						tempTaxonomyMasterCount2++;

					}

					for(Map.Entry<Long, String> mapEntry : tempTaxonomyMap.entrySet()){
						row = mySheet.createRow(rowNum++);

						cell10 = row.createCell(0);
						cell10.setCellValue("By Taxonomy Master keyword");

						cell11 = row.createCell(1);
						cell11.setCellValue(mapEntry.getKey());

						cell12 = row.createCell(2);
						cell12.setCellValue(mapEntry.getValue()); 

					}
				}

			}else if(options.equalsIgnoreCase("taxonomy")){

				QuickSearch respObjSet = new QuickSearch();
				ArrayList<QuickSearch> finalList = new ArrayList<QuickSearch>();
				for(Object objt : respObjHashSet){
					respObjSet = (QuickSearch) objt;
					finalList.add(respObjSet);
				}
				Collections.sort(finalList , new QuickSearchSearchByComparator());
				int tempFirstCount = 0;
				for(QuickSearch qs : finalList){

					if(qs.getAssetInstVersionId() != null){

						if(tempFirstCount == 0){

							rowa = mySheet.createRow(rowNum++);

							cell0a=  rowa.createCell(0);
							cell0a.setCellValue("Category");
							cell0a.setCellStyle(cellHeaderStyle);

							cell0b=  rowa.createCell(1);
							cell0b.setCellValue("Asset Name");
							cell0b.setCellStyle(cellHeaderStyle);

							cell0c=  rowa.createCell(2);
							cell0c.setCellValue("Asset Instance Version Id");
							cell0c.setCellStyle(cellHeaderStyle);

							cell0d=  rowa.createCell(3);
							cell0d.setCellValue("Asset Instance Name");
							cell0d.setCellStyle(cellHeaderStyle);

							cell0e=  rowa.createCell(4);
							cell0e.setCellValue("Version Name");
							cell0e.setCellStyle(cellHeaderStyle);

							cell0f=  rowa.createCell(5);
							cell0f.setCellValue("Description");
							cell0f.setCellStyle(cellHeaderStyle);

							tempFirstCount++;
						}
						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Taxonomy");

						cell1 = row.createCell(1);
						if(qs.getAssetName() != null){
							cell1.setCellValue(qs.getAssetName());
						}else{
							cell1.setCellValue("");
						}

						cell2 = row.createCell(2);
						if(qs.getAssetInstVersionId() != null){
							cell2.setCellValue(qs.getAssetInstVersionId()); 
						}else{
							cell2.setCellValue(""); 
						}

						cell3 = row.createCell(3);
						if(qs.getAssetInstName() != null){
							cell3.setCellValue(qs.getAssetInstName()); 
						}else{
							cell3.setCellValue(""); 
						}

						cell4 = row.createCell(4);
						if(qs.getVersionName() != null){
							cell4.setCellValue(qs.getVersionName()); 
						}else{
							cell4.setCellValue(""); 
						}

						if(qs.getParamMap() != null){
							paramMap = qs.getParamMap();
							finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
							for(Map.Entry<String,Object> entry:paramMap.entrySet()){
								splitArray = entry.getKey().split("`~`",2);
								splitedText = splitArray[0];
								finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
							}
						}else{
							finalDescriptionWithMetadata = qs.getAssetInstDescription();
						}

						cell5 = row.createCell(5);
						if(qs.getAssetInstDescription() != null){
							if(finalDescriptionWithMetadata.length() >= 32768){
								cell5.setCellValue(" *** Limit exceeded for cell. ***");
							}else{
								cell5.setCellValue(finalDescriptionWithMetadata);
							}
						}else{
							cell5.setCellValue("");
						}

					}if(qs.getSearchBy().equalsIgnoreCase("Asset")){

						if(tempAssetCnt == 0){
							rowa = mySheet.createRow(rowNum++);

							cell0a=  rowa.createCell(0);
							cell0a.setCellValue("Category");
							cell0a.setCellStyle(cellHeaderStyle);

							cell0b=  rowa.createCell(1);
							cell0b.setCellValue("Asset Name");
							cell0b.setCellStyle(cellHeaderStyle);

							cell0f=  rowa.createCell(2);
							cell0f.setCellValue("Description");
							cell0f.setCellStyle(cellHeaderStyle);

							tempAssetCnt++;
						}

						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Taxonomy");

						cell1 = row.createCell(1);
						if(qs.getAssetName() != null){
							cell1.setCellValue(qs.getAssetName());
						}else{
							cell1.setCellValue("");
						}

						if(qs.getParamMap() != null){
							paramMap = qs.getParamMap();
							finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
							for(Map.Entry<String,Object> entry:paramMap.entrySet()){
								splitArray = entry.getKey().split("`~`",2);
								splitedText = splitArray[0];
								finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
							}
						}else{
							finalDescriptionWithMetadata = qs.getAssetDescription();
						}

						cell2 = row.createCell(2);
						if(qs.getAssetDescription() != null){
							if(finalDescriptionWithMetadata.length() >= 32768){
								cell2.setCellValue(" *** Limit exceeded for cell. ***");
							}else{
								cell2.setCellValue(finalDescriptionWithMetadata);
							}
						}else{
							cell2.setCellValue("");
						}
					}else{
						HashMap<Long , Object> taxonomyMap = qs.getTaxonomyMap();
						if(taxonomyMap != null){
							for(Map.Entry<Long, Object> mapEntry : taxonomyMap.entrySet()){
								tempTaxonomyMap.put(mapEntry.getKey(), mapEntry.getValue().toString());
							}
						}
					}
				}
				if(tempTaxonomyMap != null){

					if(tempTaxonomyMasterCount == 0){

						rowNum++;
						rowb = mySheet.createRow(rowNum++);

						cell1a=  rowb.createCell(0);
						cell1a.setCellValue("Category");
						cell1a.setCellStyle(cellHeaderStyle);

						cell1b=  rowb.createCell(1);
						cell1b.setCellValue("Taxonomy Id");
						cell1b.setCellStyle(cellHeaderStyle);

						cell1c=  rowb.createCell(2);
						cell1c.setCellValue("Taxonomy Name");
						cell1c.setCellStyle(cellHeaderStyle);

						tempTaxonomyMasterCount++;

					}

					for(Map.Entry<Long, String> mapEntry : tempTaxonomyMap.entrySet()){
						row = mySheet.createRow(rowNum++);

						cell10 = row.createCell(0);
						cell10.setCellValue("By Taxonomy Master");

						cell11 = row.createCell(1);
						cell11.setCellValue(mapEntry.getKey());

						cell12 = row.createCell(2);
						cell12.setCellValue(mapEntry.getValue()); 

					}
				}
			}else if(options.equalsIgnoreCase("tags")){
				QuickSearch respObjSet = new QuickSearch();
				ArrayList<QuickSearch> finalList = new ArrayList<QuickSearch>();
				for(Object objt : respObjHashSet){
					respObjSet = (QuickSearch) objt;
					finalList.add(respObjSet);
				}
				Collections.sort(finalList , new QuickSearchSearchByComparator());
				for(QuickSearch qs : finalList){

					if(tempTaggingCount == 0){

						rowa = mySheet.createRow(rowNum++);

						cell0a=  rowa.createCell(0);
						cell0a.setCellValue("Category");
						cell0a.setCellStyle(cellHeaderStyle);

						cell0b=  rowa.createCell(1);
						cell0b.setCellValue("Asset Name");
						cell0b.setCellStyle(cellHeaderStyle);

						cell0c=  rowa.createCell(2);
						cell0c.setCellValue("Asset Instance Version Id");
						cell0c.setCellStyle(cellHeaderStyle);

						cell0d=  rowa.createCell(3);
						cell0d.setCellValue("Asset Instance Name");
						cell0d.setCellStyle(cellHeaderStyle);

						cell0e=  rowa.createCell(4);
						cell0e.setCellValue("Version Name");
						cell0e.setCellStyle(cellHeaderStyle);

						cell0f=  rowa.createCell(5);
						cell0f.setCellValue("Description");
						cell0f.setCellStyle(cellHeaderStyle);

						tempTaggingCount++;
					}

					row = mySheet.createRow(rowNum++);

					cell0 = row.createCell(0);
					cell0.setCellValue("By Tagging");

					cell1 = row.createCell(1);
					if(qs.getAssetName() != null){
						cell1.setCellValue(qs.getAssetName());
					}else{
						cell1.setCellValue("");
					}

					cell2 = row.createCell(2);
					if(qs.getAssetInstVersionId() != null){
						cell2.setCellValue(qs.getAssetInstVersionId()); 
					}else{
						cell2.setCellValue(""); 
					}

					cell3 = row.createCell(3);
					if(qs.getAssetInstName() != null){
						cell3.setCellValue(qs.getAssetInstName()); 
					}else{
						cell3.setCellValue(""); 
					}

					cell4 = row.createCell(4);
					if(qs.getVersionName() != null){
						cell4.setCellValue(qs.getVersionName()); 
					}else{
						cell4.setCellValue(""); 
					}

					if(qs.getParamMap() != null){
						paramMap = qs.getParamMap();
						finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
						for(Map.Entry<String,Object> entry:paramMap.entrySet()){
							splitArray = entry.getKey().split("`~`",2);
							splitedText = splitArray[0];
							finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
						}
					}else{
						finalDescriptionWithMetadata = qs.getAssetInstDescription();
					}

					cell5 = row.createCell(5);
					if(qs.getAssetInstDescription() != null){
						if(finalDescriptionWithMetadata.length() >= 32768){
							cell5.setCellValue(" *** Limit exceeded for cell. ***");
						}else{
							cell5.setCellValue(finalDescriptionWithMetadata);
						}
					}else{
						cell5.setCellValue("");
					}
				}
			}else{
				QuickSearch respObjSet = new QuickSearch();
				ArrayList<QuickSearch> finalList = new ArrayList<QuickSearch>();
				for(Object objt : respObjHashSet){
					respObjSet = (QuickSearch) objt;
					finalList.add(respObjSet);
				}
				Collections.sort(finalList , new QuickSearchSearchByComparator());
				int tempFirstCount = 0;
				for(QuickSearch qs : finalList){
					if(qs.getSearchBy().equals("Asset Instance")){

						if(tempAssetInstanceCnt2 == 0){
							rowa = mySheet.createRow(rowNum++);

							cell0a=  rowa.createCell(0);
							cell0a.setCellValue("Category");
							cell0a.setCellStyle(cellHeaderStyle);

							cell0b=  rowa.createCell(1);
							cell0b.setCellValue("Asset Name");
							cell0b.setCellStyle(cellHeaderStyle);

							cell0c=  rowa.createCell(2);
							cell0c.setCellValue("Asset Instance Version Id");
							cell0c.setCellStyle(cellHeaderStyle);

							cell0d=  rowa.createCell(3);
							cell0d.setCellValue("Asset Instance Name");
							cell0d.setCellStyle(cellHeaderStyle);

							cell0e=  rowa.createCell(4);
							cell0e.setCellValue("Version Name");
							cell0e.setCellStyle(cellHeaderStyle);

							cell0f=  rowa.createCell(5);
							cell0f.setCellValue("Description");
							cell0f.setCellStyle(cellHeaderStyle);

							tempAssetInstanceCnt2++;
						}

						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Asset Instances");

						cell1 = row.createCell(1);
						if(qs.getAssetName() != null){
							cell1.setCellValue(qs.getAssetName());
						}else{
							cell1.setCellValue("");
						}

						cell2 = row.createCell(2);
						if(qs.getAssetInstVersionId() != null){
							cell2.setCellValue(qs.getAssetInstVersionId()); 
						}else{
							cell2.setCellValue(""); 
						}

						cell3 = row.createCell(3);
						if(qs.getAssetInstName() != null){
							cell3.setCellValue(qs.getAssetInstName()); 
						}else{
							cell3.setCellValue(""); 
						}

						cell4 = row.createCell(4);
						if(qs.getVersionName() != null){
							cell4.setCellValue(qs.getVersionName()); 
						}else{
							cell4.setCellValue(""); 
						}

						if(qs.getParamMap() != null){
							paramMap = qs.getParamMap();
							finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
							for(Map.Entry<String,Object> entry:paramMap.entrySet()){
								splitArray = entry.getKey().split("`~`",2);
								splitedText = splitArray[0];
								finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
							}
						}else{
							finalDescriptionWithMetadata = qs.getAssetInstDescription();
						}

						cell5 = row.createCell(5);
						if(qs.getAssetInstDescription() != null){
							if(finalDescriptionWithMetadata.length() >= 32768){
								cell5.setCellValue(" *** Limit exceeded for cell. ***");
							}else{
								cell5.setCellValue(finalDescriptionWithMetadata);
							}
						}else{
							cell5.setCellValue("");
						}
					}

					if(qs.getSearchBy().equalsIgnoreCase("Asset")){

						if(tempAssetCnt == 0){
							rowa = mySheet.createRow(rowNum++);

							cell0a=  rowa.createCell(0);
							cell0a.setCellValue("Category");
							cell0a.setCellStyle(cellHeaderStyle);

							cell0b=  rowa.createCell(1);
							cell0b.setCellValue("Asset Name");
							cell0b.setCellStyle(cellHeaderStyle);

							cell0f=  rowa.createCell(2);
							cell0f.setCellValue("Description");
							cell0f.setCellStyle(cellHeaderStyle);

							tempAssetCnt++;
						}
						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Asset");

						cell1 = row.createCell(1);
						if(qs.getAssetName() != null){
							cell1.setCellValue(qs.getAssetName());
						}else{
							cell1.setCellValue("");
						}

						if(qs.getParamMap() != null){
							paramMap = qs.getParamMap();
							finalDescriptionWithMetadata = qs.getAssetInstDescription() + " Metadata ";
							for(Map.Entry<String,Object> entry:paramMap.entrySet()){
								splitArray = entry.getKey().split("`~`",2);
								splitedText = splitArray[0];
								finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
							}
						}else{
							finalDescriptionWithMetadata = qs.getAssetDescription();
						}

						cell2 = row.createCell(2);
						if(qs.getAssetDescription() != null){
							if(finalDescriptionWithMetadata.length() >= 32768){
								cell2.setCellValue(" *** Limit exceeded for cell. ***");
							}else{
								cell2.setCellValue(finalDescriptionWithMetadata);
							}
						}else{
							cell2.setCellValue("");
						}
					}
					if(qs.getSearchBy().equalsIgnoreCase("Parameters")){
						if(tempParamCnt == 0){
							rowa = mySheet.createRow(rowNum++);

							cell0a=  rowa.createCell(0);
							cell0a.setCellValue("Category");
							cell0a.setCellStyle(cellHeaderStyle);

							cell0b=  rowa.createCell(1);
							cell0b.setCellValue("Asset Name");
							cell0b.setCellStyle(cellHeaderStyle);

							cell0c=  rowa.createCell(2);
							cell0c.setCellValue("Asset Instance Version Id");
							cell0c.setCellStyle(cellHeaderStyle);

							cell0d=  rowa.createCell(3);
							cell0d.setCellValue("Asset Instance Name");
							cell0d.setCellStyle(cellHeaderStyle);

							cell0e=  rowa.createCell(4);
							cell0e.setCellValue("Version Name");
							cell0e.setCellStyle(cellHeaderStyle);

							cell0f=  rowa.createCell(5);
							cell0f.setCellValue("Description");
							cell0f.setCellStyle(cellHeaderStyle);

							tempParamCnt++;
						}
						row = mySheet.createRow(rowNum++);

						cell0 = row.createCell(0);
						cell0.setCellValue("By Parameters");

						cell1 = row.createCell(1);
						if(qs.getAssetName() != null){
							cell1.setCellValue(qs.getAssetName());
						}else{
							cell1.setCellValue("");
						}

						cell2 = row.createCell(2);
						if(qs.getAssetInstVersionId() != null){
							cell2.setCellValue(qs.getAssetInstVersionId()); 
						}else{
							cell2.setCellValue(""); 
						}

						cell3 = row.createCell(3);
						if(qs.getAssetInstName() != null){
							cell3.setCellValue(qs.getAssetInstName()); 
						}else{
							cell3.setCellValue(""); 
						}

						cell4 = row.createCell(4);
						if(qs.getVersionName() != null){
							cell4.setCellValue(qs.getVersionName()); 
						}else{
							cell4.setCellValue(""); 
						}

						if(qs.getParamMap() != null){
							paramMap = qs.getParamMap();
							finalDescriptionWithMetadata = qs.getAssetInstDescription() + " . Metadata ";
							for(Map.Entry<String,Object> entry:paramMap.entrySet()){
								splitArray = entry.getKey().split("`~`",2);
								splitedText = splitArray[0];
								finalDescriptionWithMetadata = finalDescriptionWithMetadata+" : "+splitedText+" : "+entry.getValue();
							}
						}else{
							finalDescriptionWithMetadata = qs.getAssetInstDescription();
						}

						cell5 = row.createCell(5);
						if(qs.getAssetInstDescription() != null){
							if(finalDescriptionWithMetadata.length() >= 32768){
								cell5.setCellValue(" *** Limit exceeded for cell. ***");
							}else{
								cell5.setCellValue(finalDescriptionWithMetadata);
							}
						}else{
							cell5.setCellValue("");
						}
					}

					if(qs.getSearchBy().equalsIgnoreCase("Profile")){

						if(tempProfileCount == 0){
							rowNum++;
							rowb = mySheet.createRow(rowNum++);

							cell1a=  rowb.createCell(0);
							cell1a.setCellValue("Category");
							cell1a.setCellStyle(cellHeaderStyle);

							cell1b=  rowb.createCell(1);
							cell1b.setCellValue("UserName");
							cell1b.setCellStyle(cellHeaderStyle);

							cell1c=  rowb.createCell(2);
							cell1c.setCellValue("Full Name");
							cell1c.setCellStyle(cellHeaderStyle);

							cell1d=  rowb.createCell(3);
							cell1d.setCellValue("Department");
							cell1d.setCellStyle(cellHeaderStyle);

							cell1e=  rowb.createCell(4);
							cell1e.setCellValue("Email Id");
							cell1e.setCellStyle(cellHeaderStyle);
							
							tempProfileCount++;
						}

						row = mySheet.createRow(rowNum++);

						cell0p = row.createCell(0);
						cell0p.setCellValue("By Profile");

						cell1p = row.createCell(1);
						cell1p.setCellValue(qs.getUserName());

						cell2p = row.createCell(2);
						cell2p.setCellValue(qs.getFullName()); 

						cell3p = row.createCell(3);
						cell3p.setCellValue(qs.getDepartment()); 

						cell4p = row.createCell(4);
						cell4p.setCellValue(qs.getEmailId());

//						tempFirstCount++;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void exportGamificationPoints(XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle ,List<HashMap<String, String>> pointMapList){
		int rowNum = 0;
		try {

			XSSFRow rowa = mySheet.createRow(rowNum++);

			XSSFCell cell0a=  rowa.createCell(0);
			cell0a.setCellValue("Rank");
			cell0a.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b=  rowa.createCell(1);
			cell0b.setCellValue("Full Name");
			cell0b.setCellStyle(cellHeaderStyle);

			XSSFCell cell0c=  rowa.createCell(2);
			cell0c.setCellValue("Points");
			cell0c.setCellStyle(cellHeaderStyle);

			Cell cell0 = null;
			Cell cell1 = null;
			Cell cell2 = null;

			for(HashMap<String, String> gameMap : pointMapList){
				Row row = mySheet.createRow(rowNum++);
				for(Map.Entry<String, String> entry : gameMap.entrySet()){
					if("rank".equals(entry.getKey())){
						cell0 = row.createCell(0);
						if(entry.getValue().equals("") || entry.getValue() == null){
							cell0.setCellValue("N/A");
						}else{
							cell0.setCellValue(entry.getValue());
						}
					}
					if("name".equals(entry.getKey())){
						cell1 = row.createCell(1);
						if(entry.getValue().equals("") || entry.getValue() == null){
							cell1.setCellValue("N/A");
						}else{
							cell1.setCellValue(entry.getValue());
						}
					}
					if("point".equals(entry.getKey())){
						cell2 = row.createCell(2);
						if(entry.getValue().equals("") || entry.getValue() == null){
							cell2.setCellValue("N/A");
						}else{
							cell2.setCellValue(entry.getValue());
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void exportGamificationPointDtls(XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle ,List<GamificationDetails> gamePointDtlsList){
		int rowNum = 0;
		try {

			XSSFRow rowa = mySheet.createRow(rowNum++);

			XSSFCell cell0a=  rowa.createCell(0);
			cell0a.setCellValue("Date");
			cell0a.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b=  rowa.createCell(1);
			cell0b.setCellValue("Full Name");
			cell0b.setCellStyle(cellHeaderStyle);

			XSSFCell cell0c=  rowa.createCell(2);
			cell0c.setCellValue("Action");
			cell0c.setCellStyle(cellHeaderStyle);

			XSSFCell cell0d=  rowa.createCell(3);
			cell0d.setCellValue("Field");
			cell0d.setCellStyle(cellHeaderStyle);

			XSSFCell cell0e=  rowa.createCell(4);
			cell0e.setCellValue("Asset Name");
			cell0e.setCellStyle(cellHeaderStyle);

			XSSFCell cell0f=  rowa.createCell(5);
			cell0f.setCellValue("Asset Instance Name");
			cell0f.setCellStyle(cellHeaderStyle);

			XSSFCell cell0g=  rowa.createCell(6);
			cell0g.setCellValue("Version Name");
			cell0g.setCellStyle(cellHeaderStyle);

			XSSFCell cell0h=  rowa.createCell(7);
			cell0h.setCellValue("Points");
			cell0h.setCellStyle(cellHeaderStyle);

			Row row = null;
			Cell cell0 = null;
			Cell cell1 = null;
			Cell cell2 = null;
			Cell cell3 = null;
			Cell cell4 = null;
			Cell cell5 = null;
			Cell cell6 = null;
			Cell cell7 = null;
			String activityTimestamp = null;
			DateTimeFormatter dateTimeFormatter = null;
			LocalDateTime abc = null;
			String dateStr = null;

			for(GamificationDetails game : gamePointDtlsList){
				row = mySheet.createRow(rowNum++);

				cell0 = row.createCell(0);
				activityTimestamp = game.getActivityTimestamp();

				dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
				abc = LocalDateTime.parse(activityTimestamp, dateTimeFormatter);
				dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
				dateStr = abc.format(dateTimeFormatter);
				if(dateStr.equals("") || dateStr == null){
					cell0.setCellValue("N/A");
				}else{
					cell0.setCellValue(dateStr);
				}

				cell1 = row.createCell(1);
				if(game.getFullName().equals("") || game.getFullName() == null){
					cell1.setCellValue("N/A");
				}else{
					cell1.setCellValue(game.getFullName());
				}

				cell2 = row.createCell(2);
				if(game.getAction().equals("") || game.getAction() == null){
					cell2.setCellValue("N/A");
				}else{
					cell2.setCellValue(game.getAction());
				}

				cell3 = row.createCell(3);
				if(game.getField().equals("") || game.getField() == null){
					cell3.setCellValue("N/A");
				}else{
					cell3.setCellValue(game.getField());
				}

				cell4 = row.createCell(4);
				if(game.getAssetName().equals("") || game.getAssetName() == null){
					cell4.setCellValue("N/A");
				}else{
					cell4.setCellValue(game.getAssetName());
				}

				cell5 = row.createCell(5);
				if(game.getAssetInstanceName().equals("") || game.getAssetInstanceName() == null){
					cell5.setCellValue("N/A");
				}else{
					cell5.setCellValue(game.getAssetInstanceName());
				}

				cell6 = row.createCell(6);
				if(game.getAssetInstanceVersionName().equals("") || game.getAssetInstanceVersionName() == null){
					cell6.setCellValue("N/A");
				}else{
					cell6.setCellValue(game.getAssetInstanceVersionName());
				}

				cell7 = row.createCell(7);
				if(game.getPoints().equals("") || game.getPoints() == null){
					cell7.setCellValue("N/A");
				}else{
					cell7.setCellValue(game.getPoints());
				}

			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @method excelExportBrowseGrid
	 * @description Export excel for Browse grid
	 * @param from
	 * @param to
	 * @param userName
	 * @param assetName
	 * @param assetId
	 * @param userId
	 * @return Excel(.xlxs file)
	 * @throws RepoproException
	 */
	@GET
	//	@Produces("application/vnd.ms-excel")
	@Path("/exportBrowseGrid/{userName}")
	public void excelExportBrowseGrid(@PathParam("userName") String userName,
			@QueryParam("assetName") String assetName,
			@QueryParam("assetId") Long assetId,
			@QueryParam("userId") Long userId) {
		
		try{
			timer = new Timer();
			timer.schedule(new TimerTask() {
				public void run() {
					processBrowseGridExport(userName , assetName , assetId , userId);
					this.cancel();//avoid memory leak
				}
			}, 0);

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void processBrowseGridExport(String userName , String assetName , Long assetId , Long userId ){
		log.trace("excelExportBrowseGrid || Begin");
		long startTime = System.currentTimeMillis();
		downloadName = assetName+"_export_"+System.currentTimeMillis()+"".concat(".xlsx");;
		File file = new File(FILE_PATH+downloadName);
		ResponseBuilder response = null;
		Connection conn = null;
		XSSFSheet mySheet1 = null;
		XSSFSheet mySheet2 = null;
		FileOutputStream fileOutputStream = null;
		boolean flag = false;
		boolean showFlag = false;

		ExcelExportDao exportDao = new ExcelExportDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<AssetInstanceVersion> assetInstVerList = new ArrayList<AssetInstanceVersion>();
		List<AssetDef> assetlList = new ArrayList<AssetDef>();
		List<String> showColList = new ArrayList<String>();
		ShowHideDao showHideDao = new ShowHideDao();
		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		UserDao userDao = new UserDao();
		User user = null;

		StringBuffer staticParameters = new StringBuffer("");
		StringBuffer nonStaticParameters = new StringBuffer("");
		Runtime r = Runtime.getRuntime();
		try {
			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			String shortAssetName = "";
			if(assetName.length() > 19){
				shortAssetName = assetName.substring(0,18);
				mySheet1 = myWorkBook.createSheet(shortAssetName+" Attributes");
			}else{
				mySheet1 = myWorkBook.createSheet(assetName+" Attributes");
			}


			if(assetName.length() > 16){
				shortAssetName = assetName.substring(0,15);
				mySheet2 = myWorkBook.createSheet(shortAssetName+" Relationships");
			}else{
				mySheet2 = myWorkBook.createSheet(assetName+" Relationships");
			}


			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);

			fileOutputStream = new FileOutputStream(file);
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("excelExportBrowseGrid || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			ShowHideManager shd = new ShowHideManager();
			ShowHideColumn hideColumn = new ShowHideColumn();
			hideColumn.setAssetId(assetId);
			hideColumn.setUserId(userId);

			if (log.isTraceEnabled()) {
				log.trace("excelExportBrowseGrid || method called : getShowHideParamValues");
			}
			ShowHideColumn shc = shd.getShowHideParamValues(hideColumn, userName, conn);

			java.util.Map<Long, String> hideParameters = shc.getShowParamDetails();

			String assetParamName = new String();
			@SuppressWarnings("rawtypes")
			Iterator itr = hideParameters.entrySet().iterator();
			while (itr.hasNext()) {
				@SuppressWarnings("rawtypes")
				java.util.Map.Entry pair = (java.util.Map.Entry)itr.next();
				assetParamName = assetParamName.concat(pair.getValue().toString()+",");
			}

			String[] paramNames  = {};
			StringBuffer sb =new StringBuffer();
			if(!assetParamName.equals("")){
				paramNames  = assetParamName.split(",");
			}

			for (int i = 0; i < paramNames.length; i++) {
				sb.append(paramNames[i]+",");
				showColList.add(paramNames[i]);
			}

			String paramName = null;
			AssetParamDef paramdef = null;

			for(int i=0;i<paramNames.length;i++){
				paramName = paramNames[i];
				if (log.isTraceEnabled()) {
					log.trace("excelExportBrowseGrid || dao method called : getAssetParamDefByAssetNameAndParamName(assetName,paramName)");
				}
				paramdef = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(assetName,paramName, conn);
				if(paramdef.getIs_static()!=1){   //non-static
					nonStaticParameters.append(paramdef.getAssetParamName()+",");
				}else{
					staticParameters.append(paramdef.getAssetParamName()+",");
				}

			}

			// Asset instance attributes
			List<AssetParamDef> assetParamDefList = exportDao.getAssetParamDetails(conn, assetName);
			for(AssetParamDef assetParamDef : assetParamDefList){
				for(int i=0;i<paramNames.length;i++){
					if(assetParamDef.getIs_static() == 0 && paramNames[i].equalsIgnoreCase(assetParamDef.getAssetParamName())){							// for Static Asset Attributes
						flag = true;
						break;
					}
				}
			}

			boolean authorityFlag = assetInstVerDao.findAdminRightsByUserName(userName, conn);

			if(nonStaticParameters.length()!=0){
				nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length()-1);	
			}
			if(staticParameters.length()!=0){
				staticParameters = staticParameters.deleteCharAt(staticParameters.length()-1);
			}

			//boolean flagForUser = assetInstVerDao.findAdminRightsByUserName(userName, conn);

			List<AssetInstanceVersion> assetInstanceVersionList = exportDao.getFinalResultForBrowseGridAttributeSheeet(conn, assetId ,assetName, flag,authorityFlag, staticParameters, nonStaticParameters, userName,authorityFlag);
			Collections.sort(assetInstanceVersionList,new AssetInstanceVersion());

			ShowHideColumn showHideCol = showHideDao.getShowHideForAivIdColumn(shc, conn);
			Map<Long, String> showAivMap = showHideCol.getShowAivDetails();
			for(Map.Entry<Long, String> map : showAivMap.entrySet()){
				if(map.getValue()!= null){
					showFlag = true;
				}
			}

			List<AssetParamDef> assetParamList = exportDao.getAssetInstanceParameters(conn, assetName);
			printExcelBrowseGridAttributeSheet(conn ,mySheet1,cellHeaderStyle,assetInstanceVersionList,assetName,showColList,showFlag,assetParamList,userName);
			

			if (log.isDebugEnabled()) {
				log.debug("excelExportBrowseGrid ||list of asset details:"
						+ assetlList.size() + "retrieved successfully");
			}

			//boolean accessFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			List<AssetInstRelationship> assetInstRel = exportDao.getFinalResultForBrowseGridRelationshipSheeet(conn, assetName, userName, authorityFlag);
			setExcelDataAIRelationships(mySheet2, cellHeaderStyle, assetInstRel, assetName);

			if (log.isDebugEnabled()) {
				log.debug("excelExportBrowseGrid || "
						+ assetInstVerList.toString());
			}
			log.debug(" excelExportBrowseGrid  || retrieved "
					+ assetInstVerList.size()
					+ " asset instance version details by asset name : "
					+ assetName.toString());

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

			user = userDao.retProfileForUserName(userName, conn);
			MailTemplateDao mailDao = new MailTemplateDao();
			MailConfig mailConfig = mailDao.getMailConfig(conn);
			SendEmail.sendAttachedMail(mailConfig,user.getEmailId(), "RepoPro Export XLSX: Successful", MessageUtil.getMessage(Constants.EMAIL_HDR) + "Export of "+assetName+" List as XLSX was successful. Please find the file in attachment.\n\nRepoPro "  + MessageUtil.getMessage(Constants.EMAIL_NOTE),downloadName,FILE_PATH+downloadName);

			log.info("excelExportBrowseGrid || Time taken for Browse Grid Export :"+(System.currentTimeMillis() - startTime)/1000+" Secs");
		}
		catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			//			CommonUtils.deleteDir(FILE_PATH+downloadName);
			if (log.isTraceEnabled()) {
				log.trace("excelExportBrowseGrid || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("excelExportBrowseGrid || "
					+ assetInstVerList.toString() + " || exit");
		}
		//		return response.build();
		r.gc();
	}

	/**
	 * @method printExcelBrowseGridAttributeSheet
	 * @description print Excel for Browse grid Attribute sheet
	 * @return Excel(.xlxs file)
	 */
	public void printExcelBrowseGridAttributeSheet(Connection con , XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle ,List<AssetInstanceVersion> assetInstanceVersionList,String assetName,List<String> showColList,boolean showColFlag,List<AssetParamDef> assetParamList,String userName){
		int rowNum = 0;
		int colCount = 0;
		int finalCnt = 0;
		int basicColCount = 0;
		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		AssetDao assetDao = new AssetDao();
		try {
			XSSFRow rowa = mySheet.createRow(rowNum++);

			XSSFCell cell0b=  rowa.createCell(0);
			cell0b.setCellValue(assetName);
			cell0b.setCellStyle(cellHeaderStyle);

			XSSFRow rowa11 = mySheet.createRow(rowNum++);

			if(showColFlag == true){
				XSSFCell cell0b1=  rowa11.createCell(colCount++);
				cell0b1.setCellValue("Asset instance version id");
				cell0b1.setCellStyle(cellHeaderStyle);
			}

			XSSFCell cell0b2=  rowa11.createCell(colCount++);
			cell0b2.setCellValue("Asset Instance name");
			cell0b2.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b3=  rowa11.createCell(colCount++);
			cell0b3.setCellValue("Version Name");
			cell0b3.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b4=  rowa11.createCell(colCount++);
			cell0b4.setCellValue("Overview");
			cell0b4.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b5=  rowa11.createCell(colCount++);
			cell0b5.setCellValue("Created On");
			cell0b5.setCellStyle(cellHeaderStyle);
			
			//New ShowColumn List
			List<String> showColWithParamTypeIdList = new ArrayList<String>();
			
			//			colCount = 4;
			if(showColList.size() != 0){
				for(String col : showColList){
					AssetParamDef assetParamDef = assetDao.retParamIdForAssetAndParamName(assetName,col,con);
					
					//Concatenate Param Type Id with showCol
					String showColWithParamTypeId = col + "~~" + assetParamDef.getParamTypeId();					
					
					if(assetParamDef.getParamTypeId() == 9L){
						showColWithParamTypeId = showColWithParamTypeId + "~~" + assetParamDef.getLdapMappingId();
						List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(assetParamDef.getLdapMappingId(), con);
						for(LdapMapping attribute:ldapMappingList) {

							XSSFCell cell0b14=  rowa11.createCell(colCount);
							cell0b14.setCellValue(col+"_"+attribute.getAttributeDisplayName());
							cell0b14.setCellStyle(cellHeaderStyle);
							colCount++;
							basicColCount++;
						} 
					}else {

						XSSFCell cell0b14=  rowa11.createCell(colCount);
						cell0b14.setCellValue(col);
						cell0b14.setCellStyle(cellHeaderStyle);
						colCount++;
						basicColCount++;
						
					}
					
					showColWithParamTypeIdList.add(showColWithParamTypeId);
				}
			}

			XSSFCell cell0b6=  rowa11.createCell(colCount++);
			cell0b6.setCellValue("%%Taxonomies%%");
			cell0b6.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b7=  rowa11.createCell(colCount++);
			cell0b7.setCellValue("%%Tags%%");
			cell0b7.setCellStyle(cellHeaderStyle);

			int tempColCount = 5;
			long latestAssetInstanceVersionId = 0;
			Row row = mySheet.createRow(rowNum);
			Cell cell = null;
			Cell cell2 = null;
			Cell cell3 = null;
			Cell cell4 = null;
			Cell cell5 = null;
			Cell cell6 = null;
			Cell cell7 = null;
			Cell cell8 = null;
			StringBuilder sb = null;

			for (AssetInstanceVersion attributeExportVo : assetInstanceVersionList) {
				int colCountForFlag = 0;
				if(attributeExportVo.getAssetInstVersionId() == latestAssetInstanceVersionId){
					if(showColFlag == true){
						cell = row.createCell(colCountForFlag);
						if(attributeExportVo.getAssetInstVersionId() == null){
							cell.setCellValue("");
						}else{
							cell.setCellValue(attributeExportVo.getAssetInstVersionId());
						}
						colCountForFlag++;
					}

					cell2 = row.createCell(colCountForFlag++);
					if(attributeExportVo.getAssetInstName() == null){
						cell2.setCellValue("");
					}else{
						cell2.setCellValue(attributeExportVo.getAssetInstName());
					}

					cell3 = row.createCell(colCountForFlag++);
					if(attributeExportVo.getVersionName() == null || attributeExportVo.getVersionable() == null || attributeExportVo.getVersionable() == false){
						cell3.setCellValue("NA");
					}else{
						cell3.setCellValue(attributeExportVo.getVersionName());
					}

					cell4 = row.createCell(colCountForFlag++);
					if(attributeExportVo.getDescription() == null){
						cell4.setCellValue("");
					}else{
						if(attributeExportVo.getDescription().length() >= 32768){
							cell4.setCellValue(" *** Limit exceeded for cell. ***");
						}else{
							cell4.setCellValue(attributeExportVo.getDescription());
						}
					}

					cell5 = row.createCell(colCountForFlag++);
					if(attributeExportVo.getCreatedOn() == null){
						cell5.setCellValue("");
					}else{
						SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
						String dateStr = formatter.format(attributeExportVo.getCreatedOn());
						cell5.setCellValue(dateStr);
					}
					
					TreeMap<String , String> hm = attributeExportVo.getParamNamewithvalue();
					/*for(Map.Entry<String, String> paramMapEntry : hm.entrySet()){
						Cell cell5 = row.createCell(tempColCount++);
						cell5.setCellValue(paramMapEntry.getValue());
					}*/


					String curParamName = null;
					
					for(Map.Entry<String, String> paramMapEntry : hm.entrySet()){
						String ldapmapping = null;
						List<String> paramValList = new ArrayList<String>();
						Map<String,Integer> ldapmappingdata = new LinkedHashMap<String,Integer>();
						int x = 0;
						curParamName = paramMapEntry.getKey();
						Long curParamType = 0L;
						int ldapMaapingId = 0;
						for(AssetParamDef astParName : assetParamList){
							if(astParName.getAssetParamName().equalsIgnoreCase(curParamName)){
								curParamType = astParName.getParamTypeId();
								if(curParamType == 9) {
									ldapMaapingId = astParName.getLdapMappingId();
								}
								break;
							}
						}
						String cellVal = null;
						if(curParamType == 5){
							cellVal = assetInstVerDao.getDerivedAttributeValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, curParamName, con);
							/*Cell cell5 = row.createCell(tempColCount+x);
							cell5.setCellValue(derivedAttrVals);*/
						}else if(curParamType == 6){
							cellVal = assetInstVerDao.getDerivedComputationValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName,  curParamName, con);
							/*Cell cell5 = row.createCell(tempColCount+x);
							cell5.setCellValue(derivedCompVal);*/
						}else if(curParamType == 8) {//browse/browse search export
							cellVal = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, curParamName, con);
						}
						else 
							//routingName1.substring(protocol.length()+1, routingName1.lastIndexOf(","));
							if(paramMapEntry.getValue() != null){
								sb = new StringBuilder(paramMapEntry.getValue());
								// ************new changes for rich text****************
								if(paramMapEntry.getValue() != null && paramMapEntry.getValue().endsWith("~~") && (curParamType == 7 || curParamType == 1)){
									sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
									sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
									if(sb.length() >= 32768){
										cellVal = " *** Limit exceeded for cell. ***";
									}else{
										cellVal = sb.toString();
									}
//									System.out.println(sb);
								}else if(paramMapEntry.getValue() != null && paramMapEntry.getValue().endsWith("``") && curParamType == 9 ){
									sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");
									sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");

									ldapmapping = sb.toString();
									
									paramValList = new ArrayList<String>(Arrays.asList(ldapmapping.split("``")));
									for(String data:paramValList) {
										String[] ldapmappingval = data.split("~~~~");
										
										ldapmappingdata.put(ldapmappingval[0], Integer.parseInt(ldapmappingval[1]));

									}
									if(sb.length() >= 32768){
										cellVal = " *** Limit exceeded for cell. ***";
									}else{
										cellVal = sb.toString();
									}
//									System.out.println(sb);
								}else{
									cellVal = paramMapEntry.getValue();
								}
								//**************** end ******************************
							}

						for(String col : showColWithParamTypeIdList){
							String[] colArr = col.split("~~"); 
							String column = colArr[0];
							Long paramTypeId = Long.parseLong(colArr[1]);
							
							if(column.equalsIgnoreCase(curParamName)){
								if(curParamType == 9){
									if(!ldapmappingdata.isEmpty()) {
										List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMaapingId, con);
										for(LdapMapping attribute:ldapMappingList){
											for (Map.Entry<String,Integer> entry : ldapmappingdata.entrySet()) {
												//List<String> attributeData = new ArrayList<String>(Arrays.asList(atributes.split("~~~~")));
												if(attribute.getLdapAttributeId() == entry.getValue()) {
													Cell cell0b14 = row.createCell(tempColCount +x);
													cell0b14.setCellValue(entry.getKey());
													x++;
												}
											}
										}
									}
								}else{
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal);
								}
								break;
							}else{
								if(paramTypeId == 9) {
									int ldapMappingId = Integer.parseInt(colArr[2]);
									List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMappingId, con);
									x = x+ldapMappingList.size();
								}else{
									x++;
								}
							}
						}
						/*if(astParName.getAssetParamName().equalsIgnoreCase(paramMapEntry.getKey())){
							Cell cell5 = row.createCell(tempColCount +x);
							cell5.setCellValue(paramMapEntry.getValue());
							colCount++;
							break;
						}else{
							x++;
						}
						}*/
					}
					int x = 0;
					String cellVal = null;
					for(String col : showColWithParamTypeIdList){
						String[] colArr = col.split("~~"); 
						String column = colArr[0];
						Long paramTypeId = Long.parseLong(colArr[1]);
						
						for(AssetParamDef astParName : assetParamList){							
							if(column.equalsIgnoreCase(astParName.getAssetParamName())){
								cellVal = null;
								if(astParName.getParamTypeId() == 5){
									cellVal = assetInstVerDao.getDerivedAttributeValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
									String derivedAttrVals = cellVal;
									String[] derval = derivedAttrVals.split("`!!`");
									if(derval[0].equals("0")){
										derivedAttrVals = derval[1];
									}else{
										derivedAttrVals = derval[0];
									}
									if(derivedAttrVals.contains("``")) {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}
										if(derivedAttrVals.contains("``")){
											derivedAttrVals = derivedAttrVals.replaceAll("``", "|");
										}
										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals=derivedAttrVals.replace("`~`", "~~");
										}
									}else {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}

										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals=derivedAttrVals.replace("`~`", ",");
										}
									}
									cellVal = derivedAttrVals;
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal.trim());
								}else if(astParName.getParamTypeId() == 6){
									cellVal = assetInstVerDao.getDerivedComputationValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName,  astParName.getAssetParamName(), con);
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal);								
								}else if(astParName.getParamTypeId() == 8) {//browse/browse search export
									cellVal = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
									String derivedAssetListValue = cellVal;
									String finalValue = "";
									String[] data = derivedAssetListValue.split("`!!`");
									if(data[0].equalsIgnoreCase("0")) {
										if(data.length == 2){
			        						finalValue = data[1];
			        					}else{
			        						finalValue = ""; 
			        					}
									}else {
										if(data.length == 2){
			        						finalValue = data[1];
			        					}else{
			        						finalValue = ""; 
			        					}
									}
									if(finalValue.contains("``")) {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}
										if(finalValue.contains("``")){
											finalValue = finalValue.replaceAll("``", "|");
										}
										if(finalValue.contains("`~`")){
											finalValue = finalValue.replace("`~`", "~~");
										}
									}else {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}

										if(finalValue.contains("`~`")){
											finalValue = finalValue.replace("`~`", ",");
										}
									}
									cellVal = finalValue;
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal);
									
								}
							}
						}
						
						if(paramTypeId == 9) {
							int ldapMappingId = Integer.parseInt(colArr[2]);
							List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMappingId, con);
							x = x+ldapMappingList.size();
						}else{
							x++;
						}
					}
					
					
					finalCnt = colCountForFlag+basicColCount;

					cell7 = row.createCell(finalCnt);
					if(attributeExportVo.getTaxonomyName() == null){
						cell7.setCellValue("");
					}else{
						cell7.setCellValue(attributeExportVo.getTaxonomyName());
					}


					cell8 = row.createCell(finalCnt+1);
					cell8.setCellValue(attributeExportVo.getTagName());


				}else{
					row = mySheet.createRow(rowNum++);

					if(showColFlag == true){
						cell = row.createCell(colCountForFlag);
						if(attributeExportVo.getAssetInstVersionId() == null){
							cell.setCellValue("");
						}else{
							cell.setCellValue(attributeExportVo.getAssetInstVersionId());
						}
						colCountForFlag++;
					}

					cell2 = row.createCell(colCountForFlag++);
					if(attributeExportVo.getAssetInstName() == null){
						cell2.setCellValue("");
					}else{
						cell2.setCellValue(attributeExportVo.getAssetInstName());
					}

					cell3 = row.createCell(colCountForFlag++);
					if(attributeExportVo.getVersionName() == null || attributeExportVo.getVersionable() == null || attributeExportVo.getVersionable() == false){
						cell3.setCellValue("NA");
					}else{
						cell3.setCellValue(attributeExportVo.getVersionName());
					}

					cell4 = row.createCell(colCountForFlag++);
					if(attributeExportVo.getDescription() == null){
						cell4.setCellValue("");
					}else{
						if(attributeExportVo.getDescription().length() >= 32768){
							cell4.setCellValue(" *** Limit exceeded for cell. ***");
						}else{
							cell4.setCellValue(attributeExportVo.getDescription());
						}
					}

					cell5 = row.createCell(colCountForFlag++);
					if(attributeExportVo.getCreatedOn() == null){
						cell5.setCellValue("");
					}else{
						SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
						String dateStr = formatter.format(attributeExportVo.getCreatedOn());
						cell5.setCellValue(dateStr);
					}
					
					tempColCount = colCountForFlag;
					/*TreeMap<String , String> hm = attributeExportVo.getParamNamewithvalue();
					if(hm != null){
						for(Map.Entry<String, String> paramMapEntry : hm.entrySet()){
							Cell cell5 = row.createCell(tempColCount++);
							cell5.setCellValue(paramMapEntry.getValue());
							colCount++;
						}
					}*/

					TreeMap<String , String> hm = attributeExportVo.getParamNamewithvalue();
					String curParamName = null;
					for(Map.Entry<String, String> paramMapEntry : hm.entrySet()){
						String ldapmapping = null;
						List<String> paramValList = new ArrayList<String>();
						Map<String,Integer> ldapmappingdata = new LinkedHashMap<String,Integer>();
						int x = 0;
						curParamName = paramMapEntry.getKey();
						Long curParamType = 0L;
						int ldapMaapingId = 0;
						for(AssetParamDef astParName : assetParamList){
							if(astParName.getAssetParamName().equalsIgnoreCase(curParamName)){
								curParamType = astParName.getParamTypeId();
								if(curParamType == 9) {
									ldapMaapingId = astParName.getLdapMappingId();
								}
								break;
							}
						}
						String cellVal = null;
						
						if(curParamType == 5){
							cellVal = assetInstVerDao.getDerivedAttributeValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, curParamName, con);
							/*Cell cell5 = row.createCell(tempColCount+x);
							cell5.setCellValue(derivedAttrVals);*/
						}else if(curParamType == 6){
							cellVal = assetInstVerDao.getDerivedComputationValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName,  curParamName, con);
							/*Cell cell5 = row.createCell(tempColCount+x);
							cell5.setCellValue(derivedCompVal);*/
						}else if(curParamType == 8) {//browse/browse search export
							cellVal = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, curParamName, con);
						}
						else if(paramMapEntry.getValue() != null){
								sb = new StringBuilder(paramMapEntry.getValue());
								// ************new changes for rich text****************
								if(paramMapEntry.getValue() != null && paramMapEntry.getValue().endsWith("~~") && (curParamType == 7 || curParamType == 1)){
									sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
									sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
									if(sb.length() >= 32768){
										cellVal = " *** Limit exceeded for cell. ***";
									}else{
										cellVal = sb.toString();
									}
								}else if(paramMapEntry.getValue() != null && paramMapEntry.getValue().endsWith("``") && curParamType == 9 ){
									sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");
									sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");
									ldapmapping = sb.toString();
									paramValList = new ArrayList<String>(Arrays.asList(ldapmapping.split("``")));
									for(String data:paramValList) {
										String[] ldapmappingval = data.split("~~~~");
										ldapmappingdata.put(ldapmappingval[0], Integer.parseInt(ldapmappingval[1]));

									}
									if(sb.length() >= 32768){
										cellVal = " *** Limit exceeded for cell. ***";
									}else{
										cellVal = sb.toString();
									}
								}else{
									cellVal = paramMapEntry.getValue();
								}
								//**************** end ******************************
						}

						for(String col : showColWithParamTypeIdList){
							String[] colArr = col.split("~~"); 
							String column = colArr[0];
							Long paramTypeId = Long.parseLong(colArr[1]);
							
							if(column.equalsIgnoreCase(curParamName)){
								if(curParamType == 9){
									if(!ldapmappingdata.isEmpty()) {
										List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMaapingId, con);
										for(LdapMapping attribute:ldapMappingList){
											for (Map.Entry<String,Integer> entry : ldapmappingdata.entrySet()) {
												//List<String> attributeData = new ArrayList<String>(Arrays.asList(atributes.split("~~~~")));
												if(attribute.getLdapAttributeId() == entry.getValue()) {
													Cell cell0b14 = row.createCell(tempColCount +x);
													cell0b14.setCellValue(entry.getKey());
													x++;
												}
											}
										}
									}
								}else{
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal);
								}
								break;
							}else{								
								if(paramTypeId == 9) {	
									int ldapMappingId = Integer.parseInt(colArr[2]);
									List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMappingId, con);
									x = x+ldapMappingList.size();
								}else{
									x++;
								}
							}
						}
						/*if(astParName.getAssetParamName().equalsIgnoreCase(paramMapEntry.getKey())){
							Cell cell5 = row.createCell(tempColCount +x);
							cell5.setCellValue(paramMapEntry.getValue());
							colCount++;
							break;
						}else{
							x++;
						}
						}*/
					}

					int x = 0;
					String cellVal = null;
					for(String col : showColWithParamTypeIdList){
						String[] colArr = col.split("~~"); 
						String column = colArr[0];
						Long paramTypeId = Long.parseLong(colArr[1]);
						
						for(AssetParamDef astParName : assetParamList){							
							if(column.equalsIgnoreCase(astParName.getAssetParamName())){
								cellVal = null;
								if(astParName.getParamTypeId() == 5){
									cellVal = assetInstVerDao.getDerivedAttributeValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
									String derivedAttrVals = cellVal;
									String[] derval = derivedAttrVals.split("`!!`");
									if(derval[0].equals("0")){
										derivedAttrVals = derval[1];
									}else{
										derivedAttrVals = derval[0];
									}
									if(derivedAttrVals.contains("``")) {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}
										if(derivedAttrVals.contains("``")){
											derivedAttrVals = derivedAttrVals.replaceAll("``", "|");
										}
										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals=derivedAttrVals.replace("`~`", "~~");
										}
									}else {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}

										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals=derivedAttrVals.replace("`~`", ",");
										}
									}
									cellVal = derivedAttrVals;
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal.trim());
								}else if(astParName.getParamTypeId() == 6){
									cellVal = assetInstVerDao.getDerivedComputationValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName,  astParName.getAssetParamName(), con);
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal);								
								}else if(astParName.getParamTypeId() == 8) {//browse/browse search export
									cellVal = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
									String derivedAssetListValue = cellVal;
									String finalValue = "";
									String[] data = derivedAssetListValue.split("`!!`");
									if(data[0].equalsIgnoreCase("0")) {
										if(data.length == 2){
			        						finalValue = data[1];
			        					}else{
			        						finalValue = ""; 
			        					}
									}else {
										if(data.length == 2){
			        						finalValue = data[1];
			        					}else{
			        						finalValue = ""; 
			        					}
									}
									if(finalValue.contains("``")) {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}
										if(finalValue.contains("``")){
											finalValue = finalValue.replaceAll("``", "|");
										}
										if(finalValue.contains("`~`")){
											finalValue=finalValue.replace("`~`", "~~");
										}
									}else {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}

										if(finalValue.contains("`~`")){
											finalValue = finalValue.replace("`~`", ",");
										}
									}
									cellVal = finalValue;
									cell6 = row.createCell(tempColCount +x);
									cell6.setCellValue(cellVal);
								}
							}
						}
						
						if(paramTypeId == 9) {
							int ldapMappingId = Integer.parseInt(colArr[2]);
							List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMappingId, con);
							x = x+ldapMappingList.size();
						}else{
							x++;
						}
					}

					finalCnt = colCountForFlag+basicColCount;

					cell7 = row.createCell(finalCnt);
					if(attributeExportVo.getTaxonomyName() == null){
						cell7.setCellValue("");
					}else{
						cell7.setCellValue(attributeExportVo.getTaxonomyName());
					}

					cell8 = row.createCell(finalCnt+1);
					cell8.setCellValue(attributeExportVo.getTagName());

				}

				latestAssetInstanceVersionId = attributeExportVo.getAssetInstVersionId();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @method exportCreateFilter
	 * @description Export excel for create filter
	 * @param userName
	 * @param assetName
	 * @param assetId
	 * @param userId
	 * @param operators
	 * @param assetParamNames
	 * @param param1Values
	 * @param param2Values
	 * @param logicalSelect
	 * @param taxonomyNames
	 * @return Excel(.xlxs file)
	 * @throws RepoproException
	 */
	@GET
	@Encoded
	@Path("/exportCreateFilter")
	public void exportCreateFilter(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName,
			@QueryParam("assetId") Long assetId,
			@QueryParam("userId") Long userId,
			@QueryParam("operators") String operators,
			@QueryParam("assetParamNames") String assetParamNames,
			@QueryParam("param1Values") String param1Values,
			@QueryParam("param2Values") String param2Values,
			@QueryParam("logicalSelect") String logicalSelect,
			@QueryParam("taxonomyNames") String taxonomyNames) {
		
		try{
			timer = new Timer();
			timer.schedule(new TimerTask() {
				public void run() {
					processExportCreateFilter(userName,assetName,assetId,userId,operators,assetParamNames,param1Values,param2Values,logicalSelect,taxonomyNames);
					this.cancel();//avoid memory leak
				}
			}, 0);

		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void processExportCreateFilter(String userName,String assetName,Long assetId,Long userId,String operators,String assetParamNames,String param1Values,String param2Values,String logicalSelect,String taxonomyNames) {

		if (log.isTraceEnabled()) {
			log.trace("exportCreateFilter || begin  with userName : "
					+ userName+" assetName :"+assetName+" assetId:"+assetId+
					" userId:"+userId+" operators:"+operators+" assetParamNames:"+assetParamNames+
					" param1Values:"+param1Values+" param2Values:"+param2Values+" logicalSelect:"+logicalSelect+
					" taxonomyNames:"+taxonomyNames);
		}
		try {
			assetName = URLDecoder.decode(assetName, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		downloadName = "Filtered_export_"+assetName+"_"+System.currentTimeMillis()+"".concat(".xlsx");
		long startTime = System.currentTimeMillis();
		File file = new File(FILE_PATH+downloadName);
		ResponseBuilder response = null;
		Connection conn = null;
		XSSFSheet mySheet1 = null;
		XSSFSheet mySheet2 = null;
		FileOutputStream fileOutputStream = null;
		boolean flag = false;
		boolean showFlag = false;

		ExcelExportDao exportDao = new ExcelExportDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<AssetInstanceVersion> assetInstVerList = new ArrayList<AssetInstanceVersion>();
		List<AssetDef> assetlList = new ArrayList<AssetDef>();
		List<String> showColList = new ArrayList<String>();
		List<AssetInstanceVersion> listofFilterInformation = null ;
		ShowHideDao showHideDao = new ShowHideDao();
		List<AssetInstance> listOfAssetInstanceVos = new ArrayList<AssetInstance>();
		UserDao userDao = new UserDao();
		User user = null;

		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		StringBuffer staticParameters = new StringBuffer("");
		StringBuffer nonStaticParameters = new StringBuffer("");
		StringBuilder richtextFinalRes = new StringBuilder("");
//		StringBuilder richtextFinalRes2 = new StringBuilder("");
		List<AssetParamDef> listOfNonStaticParamDefs = null;
		Runtime r = Runtime.getRuntime();
		try {
			XSSFWorkbook myWorkBook = new XSSFWorkbook();
			//assetName = URLDecoder.decode(assetName, "UTF-8");
			param1Values = URLDecoder.decode(param1Values, "UTF-8");
			param2Values = URLDecoder.decode(param2Values, "UTF-8");
			operators = URLDecoder.decode(operators, "UTF-8");
			assetParamNames = URLDecoder.decode(assetParamNames, "UTF-8");
			
			if(param1Values.contains("'")){
				param1Values = param1Values.replace("'", "\\'");
			}
			if(param2Values.contains("'")){
				param2Values = param2Values.replace("'", "\\'");
			}
			
			String shortAssetName = "";
			if(assetName.length() > 19){
				shortAssetName = assetName.substring(0,18);
				mySheet1 = myWorkBook.createSheet(shortAssetName+" Attributes");
			}else{
				mySheet1 = myWorkBook.createSheet(assetName+" Attributes");
			}


			if(assetName.length() > 16){
				shortAssetName = assetName.substring(0,15);
				mySheet2 = myWorkBook.createSheet(shortAssetName+" Relationships");
			}else{
				mySheet2 = myWorkBook.createSheet(assetName+" Relationships");
			}

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);

			fileOutputStream = new FileOutputStream(file);
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("exportCreateFilter || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			ShowHideManager shd = new ShowHideManager();
			ShowHideColumn hideColumn = new ShowHideColumn();
			hideColumn.setAssetId(assetId);
			hideColumn.setUserId(userId);

			if (log.isTraceEnabled()) {
				log.trace("exportCreateFilter || method called : getShowHideParamValues");
			}
			ShowHideColumn shc = shd.getShowHideParamValues(hideColumn, userName, conn);

			java.util.Map<Long, String> hideParameters = shc.getShowParamDetails();

			String showHideAssetParamName = new String();
			@SuppressWarnings("rawtypes")
			Iterator itr = hideParameters.entrySet().iterator();
			while (itr.hasNext()) {
				@SuppressWarnings("rawtypes")
				java.util.Map.Entry pair = (java.util.Map.Entry)itr.next();
				showHideAssetParamName = showHideAssetParamName.concat(pair.getValue().toString()+",");
			}

			boolean flagForUser = assetInstVerDao.findAdminRightsByUserName(userName, conn);


			if(showHideAssetParamName.length()!=0){
				//non static and static information
				String[] paramNames  = showHideAssetParamName.split(",");
				StringBuffer sb = new StringBuffer();

				for (int i = 0; i < paramNames.length; i++) {
					sb.append(paramNames[i]+",");
					showColList.add(paramNames[i]);
				}
				sb = sb.deleteCharAt(sb.length()-1);
				for(int i=0;i<paramNames.length;i++){
					String paramName = paramNames[i];
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceForFilter || dao method called : getAssetParamDefByAssetNameAndParamName(assetName,paramName)");
					}
					AssetParamDef paramdef = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(assetName,paramName, conn);
					if(paramdef.getIs_static()!= 1){//non-static
						nonStaticParameters.append(paramdef.getAssetParamName()+",");
					}else{
						staticParameters.append(paramdef.getAssetParamName()+",");
					}
				}

				// Asset instance attributes
				List<AssetParamDef> assetParamDefList = exportDao.getAssetParamDetails(conn, assetName);
				for(AssetParamDef assetParamDef : assetParamDefList){
					for(int i=0;i<paramNames.length;i++){
						if(assetParamDef.getIs_static() == 0 && paramNames[i].equalsIgnoreCase(assetParamDef.getAssetParamName())){							// for Static Asset Attributes
							flag = true;
							break;
						}
					}
				}

				if(nonStaticParameters.length()!=0){
					nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length()-1);	
				}
				if(staticParameters.length()!=0){
					staticParameters = staticParameters.deleteCharAt(staticParameters.length()-1);
				}
				if (log.isTraceEnabled()) {
					log.trace("getAssetInstanceForFilter || dao method called : getAssetInstanceForFilterWithNonStaticParameters to get list of asset instance details for filter applied");
				}

				listofFilterInformation = exportDao.getFinalResultForCreateFilterAttributeSheet(userName, assetId , assetName,
						assetParamNames, param1Values, param2Values,operators, logicalSelect, taxonomyNames,sb.toString(),flag,flagForUser,staticParameters,nonStaticParameters, conn);
				
				if(nonStaticParameters.length()!=0){
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceForFilter || dao method called : getAssetParamDefsByParameters(parameters,assetName)");
					}
					listOfNonStaticParamDefs = assetInstanceVersionDao.getAssetParamDefsByParameters(nonStaticParameters.toString(),assetName,conn);

					TreeMap<String, String> paramValues =  new TreeMap<String,String>();
					Long newAssetInstVersionId = 0L;
					String latestAssetInstParamName = "";
					int jj=1;
					for (int i = 0; i < listofFilterInformation.size(); i++) {
						AssetInstanceVersion aiv = listofFilterInformation.get(i);
						newAssetInstVersionId = aiv.getAssetInstVersionId();
						AssetInstance vo =new AssetInstance();
						vo.setAssetInstName(aiv.getAssetInstName());
						vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
						vo.setDescription(aiv.getDescription());
						vo.setCreatedOn(aiv.getCreatedOn());
						vo.setVersionName(aiv.getVersionName());
						vo.setVersionable(aiv.getVersionable());
						vo.setTagName(aiv.getTagName());
						vo.setTaxonomyName(aiv.getTaxonomyName());
						
//						richtextFinalRes = new StringBuilder("");
						for (int j = 0; j < listOfNonStaticParamDefs.size(); j++) {
							AssetParamDef apd = listOfNonStaticParamDefs.get(j);
							/*if(apd.getHasArray() == 0){
								richtextFinalRes = new StringBuilder();
							}*/
							if(aiv.getAssetParamName()!=null)
								if(aiv.getAssetParamName().equalsIgnoreCase(apd.getAssetParamName())){
									flag = true;

									if(apd.getParamTypeId()==3){
										paramValues.put(apd.getAssetParamName().toLowerCase(), aiv.getFileName());
									}else{
										if(apd.getParamTypeId()==5){


											paramValues.put(apd.getAssetParamName().toLowerCase(), assetInstanceVersionDao.getDerivedAttributeValues(userName, aiv.getAssetInstVersionId().toString(), assetName, apd.getAssetParamName().toLowerCase(), conn));
										}else if(apd.getParamTypeId()==6){
											paramValues.put(apd.getAssetParamName().toLowerCase(), assetInstanceVersionDao.getDerivedComputationValues(userName, aiv.getAssetInstVersionId().toString(), assetName, apd.getAssetParamName().toLowerCase(), conn));
										}else if(apd.getParamTypeId()==8) {
											paramValues.put(apd.getAssetParamName().toLowerCase(), assetInstanceVersionDao.getDerivedAttributeForAssetListValues(userName, aiv.getAssetInstVersionId().toString(), assetName, apd.getAssetParamName().toLowerCase(), conn));
										}
										else if(apd.getParamTypeId() == 7 || apd.getParamTypeId() == 1){
											if(!latestAssetInstParamName.equalsIgnoreCase("")){
												if(latestAssetInstParamName.equals(aiv.getAssetParamName())){
													richtextFinalRes.append(aiv.getParamValue() + "~~") ;
												}else{
													richtextFinalRes = new StringBuilder(aiv.getParamValue() + "~~");
												}
											}else{
												richtextFinalRes = new StringBuilder(aiv.getParamValue() + "~~");
											}
//											richtextFinalRes.replace(yourString.lastIndexOf(","), yourString.lastIndexOf(",") + 1, ")" );
											paramValues.put(apd.getAssetParamName().toLowerCase(), richtextFinalRes.toString());
											latestAssetInstParamName = apd.getAssetParamName();
										}else{
											paramValues.put(apd.getAssetParamName().toLowerCase(), aiv.getParamValue());
										}
									}
									/*if(flag){
										vo.setParamNameWithValues(paramValues);
										break;
									}*/
								}
							vo.setParamNameWithValues(paramValues);
						}
						
						
						
						if(i<listofFilterInformation.size()-1){
							if(!newAssetInstVersionId.equals(listofFilterInformation.get(jj).getAssetInstVersionId())){
								listOfAssetInstanceVos.add(vo);
								paramValues = new TreeMap<String, String>();
							}
						}else{
							listOfAssetInstanceVos.add(vo);
						}
						jj++;
					}
				} if(staticParameters.length()!= 0){
					//static information
					TreeMap<String, String> paramValues =  new TreeMap<String,String>();
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceForFilter || dao method called : getAssetParamDefsByParameters(staticParameters,assetName)");
					}
					List<AssetParamDef> listOfStaticParamDefs = assetInstanceVersionDao.getAssetParamDefsByParameters(staticParameters.toString(),assetName,conn);

					if(nonStaticParameters.length()!=0){
						for(int i=0;i<listOfAssetInstanceVos.size();i++){

							AssetInstance aivo = listOfAssetInstanceVos.get(i);
							for (int k = 0; k< listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if(apd.getParamTypeId()==3){
									paramValues.put(apd.getAssetParamName().toLowerCase(),apd.getFileName());
								}else{
									paramValues.put(apd.getAssetParamName().toLowerCase(), apd.getStaticValue());
								}
							}
							java.util.Map<String, String> map = aivo.getParamNameWithValues();
							if(map!=null){
								map.putAll(paramValues);	
								aivo.setParamNameWithValues(map);
								listOfAssetInstanceVos.set(i, aivo);
							}else{
								aivo.setParamNameWithValues(paramValues);
								listOfAssetInstanceVos.set(i, aivo);
							}
						}
						paramValues= new TreeMap<String, String>();

					}else{

						for (int j = 0; j < listofFilterInformation.size(); j++) {
							AssetInstance vo = new AssetInstance();
							AssetInstanceVersion aiv = listofFilterInformation.get(j);
							for (int k = 0; k< listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if(apd.getParamTypeId()==3){
									paramValues.put(apd.getAssetParamName().toLowerCase(),apd.getFileName());
								}else{
									paramValues.put(apd.getAssetParamName().toLowerCase(), apd.getStaticValue());
								}
							}
							vo.setAssetInstName(aiv.getAssetInstName());
							vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
							vo.setDescription(aiv.getDescription());
							vo.setCreatedOn(aiv.getCreatedOn());
							vo.setVersionName(aiv.getVersionName());
							vo.setVersionable(aiv.getVersionable());
							vo.setParamNameWithValues(paramValues);
							vo.setTagName(aiv.getTagName());
							vo.setTaxonomyName(aiv.getTaxonomyName());
							listOfAssetInstanceVos.add(vo);
							paramValues= new TreeMap<String, String>();
						}
					}
				}
			}else {

				// getBasic information
				TreeMap<String, String> paramValues =  new TreeMap<String,String>();
				listOfNonStaticParamDefs = assetInstanceVersionDao.getAssetParamDefsByParameters(nonStaticParameters.toString(),assetName,conn);
				if (log.isTraceEnabled()) {
					log.trace("getAssetInstanceForFilter || dao method called : getAassetInstanceDetailsWithOutParametersExcelExport( assetName)");
				}
				/*List<AssetInstanceVersion> basicInformationOfassetInstance  = exportDao.getAssetInstanceForFilterWithNonStaticParametersDaoExcelExport(userName, assetName,
						assetParamNames, param1Values, param2Values,operators, logicalSelect, taxonomyNames,"", conn);*/

				listofFilterInformation = exportDao.getFinalResultForCreateFilterAttributeSheet(userName, assetId , assetName,
						assetParamNames, param1Values, param2Values,operators, logicalSelect, taxonomyNames,"",flag,flagForUser,staticParameters,nonStaticParameters, conn);
				
				for (int i = 0; i < listofFilterInformation.size(); i++) {
					AssetInstanceVersion aiv = listofFilterInformation.get(i);
					AssetInstance vo = new AssetInstance();
					vo.setAssetInstName(aiv.getAssetInstName());
					vo.setAssetInstVersionId(aiv
							.getAssetInstVersionId());
					vo.setDescription(aiv.getDescription());
					vo.setCreatedOn(aiv.getCreatedOn());
					vo.setVersionName(aiv.getVersionName());
					vo.setVersionable(aiv.getVersionable());
					vo.setTagName(aiv.getTagName());
					vo.setTaxonomyName(aiv.getTaxonomyName());
					for(AssetParamDef apd : listOfNonStaticParamDefs){
						if(apd.getParamTypeId() == 3){
							paramValues.put(apd.getAssetParamName(), apd.getFileName());
						}else{
							paramValues.put(apd.getAssetParamName(), apd.getStaticValue());
						}
					}
					vo.setParamNameWithValues(paramValues);
					listOfAssetInstanceVos.add(vo);
				}
			}

			ShowHideColumn showHideCol = showHideDao.getShowHideForAivIdColumn(shc, conn);
			Map<Long, String> showAivMap = showHideCol.getShowAivDetails();
			for(Map.Entry<Long, String> map : showAivMap.entrySet()){
				if(map.getValue()!= null){
					showFlag = true;
				}
			}
			
			Collections.sort(listOfAssetInstanceVos, new AssetInstance());

			List<AssetParamDef> assetParamList = exportDao.getAssetInstanceParameters(conn, assetName);

			printExcelCreateFilterAttributeSheet(conn ,mySheet1,cellHeaderStyle,listOfAssetInstanceVos,assetName,showColList,showFlag,assetParamList,userName);

			if (log.isDebugEnabled()) {
				log.debug("exportCreateFilter ||list of asset details:"
						+ assetlList.size() + "retrieved successfully");
			}
			List<AssetInstRelationship> assetInstRel = exportDao.getFinalResultForCreateFilterRelationshipSheeet(conn, assetName, listOfAssetInstanceVos, userName);
			setExcelDataAIRelationships(mySheet2, cellHeaderStyle, assetInstRel, assetName);

			if (log.isDebugEnabled()) {
				log.debug("exportCreateFilter || "
						+ assetInstVerList.toString());
			}
			log.debug(" exportCreateFilter  || retrieved "
					+ assetInstVerList.size()
					+ " asset instance version details by asset name : "
					+ assetName.toString());

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

			user = userDao.retProfileForUserName(userName, conn);
			MailTemplateDao mailDao = new MailTemplateDao();
			MailConfig mailConfig = mailDao.getMailConfig(conn);
			SendEmail.sendAttachedMail(mailConfig,user.getEmailId(), "RepoPro Export XLSX: Successful", MessageUtil.getMessage(Constants.EMAIL_HDR) + "Export of "+assetName+" List as XLSX was successful. Please find the file in attachment.\n\nRepoPro "  + MessageUtil.getMessage(Constants.EMAIL_NOTE),downloadName,FILE_PATH+downloadName);

			log.info("Time taken for Create Filter Export :"+(System.currentTimeMillis() - startTime)/1000+" Secs");


		}
		catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("exportCreateFilter || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("exportCreateFilter || "
					+ assetInstVerList.toString() + " || exit");
		}
		//		return response.build();
		r.gc();
	}

	/**
	 * @method exportRecentActivity
	 * @description Export all recent activities
	 * @param userName
	 * @return Excel(.xlxs file)
	 * @throws RepoproException
	 */
	@GET
	@Path("/exportRecentActivity")
	//	@Produces("application/vnd.ms-excel")
	public void exportRecentActivity(@QueryParam("userName")String userName)throws RepoproException{

		try{

			timer = new Timer();
			timer.schedule(new TimerTask() {
				public void run() {
					processRecentActivityThread(userName);
					this.cancel();//avoid memory leak
				}
			}, 0);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void processRecentActivityThread(String userName){
		long startTime = System.currentTimeMillis();
		downloadName = "Recent_Activity_Details_"+System.currentTimeMillis()+"_"+userName+ "".concat(".xlsx");
		File file = new File(FILE_PATH+downloadName);
		ResponseBuilder response = null;
		Connection conn = null;
		XSSFSheet mySheet = null;
		FileOutputStream fileOutputStream = null;

		List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
		ExcelExportDao exportDao = new ExcelExportDao();
		List<RecentActivity> recentActivityExportList = new ArrayList<RecentActivity>();
		UserDao userDao = new UserDao();
		User user = null; 
		Runtime r = Runtime.getRuntime();
		try{

			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			mySheet = myWorkBook.createSheet("Recent Activity Details");

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);

			fileOutputStream = new FileOutputStream(file);
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("exportRecentActivity || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("exportRecentActivity || dao call of getRecentActivityExportDetails() method ");
			}
			recentActivityList = exportDao.getRecentActivityExportDetails(userName, conn);

			String recentActData = null;
			String[] splitedArray = null;
			Timestamp recentActivityTimestamp = null;
			SimpleDateFormat formatter = null;
			String dateStr = null;

			for(RecentActivity activity:recentActivityList){
				recentActData = activity.getDescription();
				splitedArray = recentActData.split(";");
				recentActivityTimestamp = activity.getActivityTimestamp();
				formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
				dateStr = formatter.format(recentActivityTimestamp);

				if(splitedArray.length == 3){
					activity.setDescription("");
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName("N/A");
					activity.setAssetInstanceVersionName("N/A");
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
				}
				else if(splitedArray.length == 4){
					activity.setDescription("");
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName(splitedArray[3].toString());
					activity.setAssetInstanceVersionName("N/A");
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
				}
				else{
					activity.setDescription("");
					activity.setActivityTimestamp(null);
					activity.setDate(dateStr);
					activity.setUserName(splitedArray[0]);
					activity.setAction(splitedArray[1]);
					activity.setAssetName(splitedArray[2]);
					activity.setAssetInstName(splitedArray[3].toString());
					String val = "";
					if(splitedArray[4].length() > splitedArray[4].indexOf("Version")+8){
						val = splitedArray[4].substring(splitedArray[4].indexOf("Version")+8);
					}
					activity.setAssetInstanceVersionName(val);
					activity.setAssetInstVersionId(activity.getAssetInstVersionId());
				}

				recentActivityExportList.add(activity);
			}
			exportRecentActivityDetails(mySheet,cellHeaderStyle, recentActivityExportList);
			conn.commit();

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

			user = userDao.retProfileForUserName(userName, conn);
			MailTemplateDao mailDao = new MailTemplateDao();
			MailConfig mailConfig = mailDao.getMailConfig(conn);
			SendEmail.sendAttachedMail(mailConfig,user.getEmailId(), "RepoPro Export XLSX: Successful", MessageUtil.getMessage(Constants.EMAIL_HDR) + "Export of Recent Activity Details  as XLSX was successful. Please find the file in attachment.\n\nRepoPro"  + MessageUtil.getMessage(Constants.EMAIL_NOTE),downloadName,FILE_PATH+downloadName);

			log.info("Time taken for Recent Activity Export :"+(System.currentTimeMillis() - startTime)/1000+" Secs");
		}catch(IOException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			try {
				fileOutputStream.close();
			} catch (IOException e) {
				log.error("IO Exception exportRecentActivity ||"
						+ e.getMessage());
			}
			if (log.isDebugEnabled()) {
				log.debug("exportRecentActivity ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("exportRecentActivity || End");
		//		return response.build();
		r.gc();
	}


	public void exportRecentActivityDetails(XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle ,List<RecentActivity> recentActivityExportList){
		int rowNum = 0;
		try {

			XSSFRow rowa = mySheet.createRow(rowNum++);

			XSSFCell cell0a=  rowa.createCell(0);
			cell0a.setCellValue("Date");
			cell0a.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b=  rowa.createCell(1);
			cell0b.setCellValue("Full Name");
			cell0b.setCellStyle(cellHeaderStyle);

			XSSFCell cell0c=  rowa.createCell(2);
			cell0c.setCellValue("Action");
			cell0c.setCellStyle(cellHeaderStyle);

			XSSFCell cell0d=  rowa.createCell(3);
			cell0d.setCellValue("Asset Name");
			cell0d.setCellStyle(cellHeaderStyle);

			XSSFCell cell0e=  rowa.createCell(4);
			cell0e.setCellValue("Asset Instance Name");
			cell0e.setCellStyle(cellHeaderStyle);

			XSSFCell cell0f=  rowa.createCell(5);
			cell0f.setCellValue("Version Name");
			cell0f.setCellStyle(cellHeaderStyle);

			for(RecentActivity activity : recentActivityExportList){
				Row row = mySheet.createRow(rowNum++);

				Cell cell0 = row.createCell(0);
				if(activity.getDate() == null || activity.getDate().equals("")){
					cell0.setCellValue("N/A");
				}else{
					cell0.setCellValue(activity.getDate());
				}

				Cell cell1 = row.createCell(1);
				if(activity.getUserName() == null || activity.getUserName().equals("")){
					cell1.setCellValue("N/A");
				}else{
					cell1.setCellValue(activity.getUserName());
				}


				Cell cell2 = row.createCell(2);
				if(activity.getAction() == null || activity.getAction().equals("")){
					cell2.setCellValue("N/A");
				}else{
					cell2.setCellValue(activity.getAction());
				}

				Cell cell3 = row.createCell(3);
				if(activity.getAssetName() == null || activity.getAssetName().equals("")){
					cell3.setCellValue("N/A");
				}else{
					cell3.setCellValue(activity.getAssetName());
				}

				Cell cell4 = row.createCell(4);
				if(activity.getAssetInstName() == null || activity.getAssetInstName().equals("")){
					cell4.setCellValue("N/A");
				}else{
					cell4.setCellValue(activity.getAssetInstName());
				}

				Cell cell5 = row.createCell(5);
				if(activity.getAssetInstanceVersionName() == null || activity.getAssetInstanceVersionName().equals("")){
					cell5.setCellValue("N/A");
				}else{
					cell5.setCellValue(activity.getAssetInstanceVersionName());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @method printExcelCreateFilterAttributeSheet
	 * @description print Excel for Create Filter
	 * @return Excel(.xlxs file)
	 */
	public void printExcelCreateFilterAttributeSheet(Connection con , XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle ,List<AssetInstance> assetInstanceList,String assetName,List<String> showColList,boolean showColFlag,List<AssetParamDef> assetParamList,String userName){
		int rowNum = 0;
		int colCount = 0;
		int finalCnt = 0;
		int basicColCount = 0;
		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		AssetDao assetDao = new AssetDao();
		StringBuilder sb = null;
		try {
			XSSFRow rowa = mySheet.createRow(rowNum++);

			XSSFCell cell0b=  rowa.createCell(0);
			cell0b.setCellValue(assetName);
			cell0b.setCellStyle(cellHeaderStyle);

			XSSFRow rowa11 = mySheet.createRow(rowNum++);

			if(showColFlag == true){
				XSSFCell cell0b1=  rowa11.createCell(colCount++);
				cell0b1.setCellValue("Asset instance version id");
				cell0b1.setCellStyle(cellHeaderStyle);
			}

			XSSFCell cell0b2=  rowa11.createCell(colCount++);
			cell0b2.setCellValue("Asset Instance name");
			cell0b2.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b3=  rowa11.createCell(colCount++);
			cell0b3.setCellValue("Version Name");
			cell0b3.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b4=  rowa11.createCell(colCount++);
			cell0b4.setCellValue("Overview");
			cell0b4.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b5=  rowa11.createCell(colCount++);
			cell0b5.setCellValue("Created On");
			cell0b5.setCellStyle(cellHeaderStyle);

			//New ShowColumn List
			List<String> showColWithParamTypeIdList = new ArrayList<String>();
			
			//			colCount = 4;
			if(showColList.size() != 0){
				for(String col : showColList){					
					AssetParamDef assetParamDef = assetDao.retParamIdForAssetAndParamName(assetName,col,con);
					//Concatenate Param Type Id with showCol
					String showColWithParamTypeId = col + "~~" + assetParamDef.getParamTypeId();
					if(assetParamDef.getParamTypeId() == 9L){
						showColWithParamTypeId = showColWithParamTypeId + "~~" + assetParamDef.getLdapMappingId();
						List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(assetParamDef.getLdapMappingId(), con);
						for(LdapMapping attribute:ldapMappingList) {

							XSSFCell cell0b14=  rowa11.createCell(colCount);
							cell0b14.setCellValue(col+"_"+attribute.getAttributeDisplayName());
							cell0b14.setCellStyle(cellHeaderStyle);
							colCount++;
							basicColCount++;
						} 
					}else {

						XSSFCell cell0b14=  rowa11.createCell(colCount);
						cell0b14.setCellValue(col);
						cell0b14.setCellStyle(cellHeaderStyle);
						colCount++;
						basicColCount++;
						
					}
					showColWithParamTypeIdList.add(showColWithParamTypeId);
				}			
				
			}

			XSSFCell cell0b6=  rowa11.createCell(colCount++);
			cell0b6.setCellValue("%%Taxonomies%%");
			cell0b6.setCellStyle(cellHeaderStyle);

			XSSFCell cell0b7=  rowa11.createCell(colCount++);
			cell0b7.setCellValue("%%Tags%%");
			cell0b7.setCellStyle(cellHeaderStyle);

			int tempColCount = 0;
			Row row = mySheet.createRow(rowNum);
			Cell cell = null;
			Cell cell2 = null;
			Cell cell3 = null;
			Cell cell4 = null;
			Cell cell5 = null;
			Cell cell6 = null;
			Cell cell7 = null;
			Cell cell8 = null;

			for (AssetInstance attributeExportVo : assetInstanceList) {
				int colCountForFlag = 0;
				row = mySheet.createRow(rowNum++);

				if(showColFlag == true){
					cell = row.createCell(colCountForFlag);
					if(attributeExportVo.getAssetInstVersionId() == null){
						cell.setCellValue("");
					}else{
						cell.setCellValue(attributeExportVo.getAssetInstVersionId());
					}
					colCountForFlag++;
				}

				cell2 = row.createCell(colCountForFlag++);
				if(attributeExportVo.getAssetInstName() == null){
					cell2.setCellValue("");
				}else{
					cell2.setCellValue(attributeExportVo.getAssetInstName());
				}

				cell3 = row.createCell(colCountForFlag++);
				if(attributeExportVo.getVersionName() == null || attributeExportVo.isVersionable() == false){
					cell3.setCellValue("NA");
				}else{
					cell3.setCellValue(attributeExportVo.getVersionName());
				}

				cell4 = row.createCell(colCountForFlag++);
				if(attributeExportVo.getDescription() == null){
					cell4.setCellValue("");
				}else{
					if(attributeExportVo.getDescription().length() >= 32768){
						cell4.setCellValue(" *** Limit exceeded for cell. ***");
					}else{
						cell4.setCellValue(attributeExportVo.getDescription());
					}
				}

				cell5 = row.createCell(colCountForFlag++);
				if(attributeExportVo.getCreatedOn() == null){
					cell5.setCellValue("");
				}else{
					SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
					String dateStr = formatter.format(attributeExportVo.getCreatedOn());
					cell5.setCellValue(dateStr);
				}
				
				tempColCount = colCountForFlag;
				Map<String , String> hm = attributeExportVo.getParamNameWithValues();
				String curParamName = null;
				for(Map.Entry<String, String> paramMapEntry : hm.entrySet()){
					int x = 0;
					curParamName = paramMapEntry.getKey();
					Long curParamType = 0L;
					String cellVal = null;
					String ldapmapping = null;
					List<String> paramValList = new ArrayList<String>();
					int ldapMaapingId = 0;
					Map<String,Integer> ldapmappingdata = new LinkedHashMap<String,Integer>();
					for(AssetParamDef astParName : assetParamList){
						if(astParName.getAssetParamName().equalsIgnoreCase(curParamName)){
							curParamType = astParName.getParamTypeId();
							if(curParamType == 9) {
								ldapMaapingId = astParName.getLdapMappingId();
							}
							break;
						}
					}
					if(curParamType == 5){
						cellVal = assetInstVerDao.getDerivedAttributeValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, curParamName, con);
						/*Cell cell5 = row.createCell(tempColCount+x);
						cell5.setCellValue(derivedAttrVals);*/
					}else if(curParamType == 6){
						cellVal = assetInstVerDao.getDerivedComputationValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName,  curParamName, con);
						/*Cell cell5 = row.createCell(tempColCount+x);
						cell5.setCellValue(derivedCompVal);*/
					}else if(curParamType == 8) {
						cellVal = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, curParamName, con);
					}
					else {
						if(paramMapEntry.getValue() != null){
							sb = new StringBuilder(paramMapEntry.getValue());
							if(paramMapEntry.getValue().endsWith("~~") && (curParamType == 7 || curParamType == 1)){
								sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
								sb = sb.replace(paramMapEntry.getValue().lastIndexOf("~~"), paramMapEntry.getValue().lastIndexOf('~'), "");
								if(sb.length() >= 32768){
									cellVal = " *** Limit exceeded for cell. ***";
								}else{
									cellVal = sb.toString();
								}
							}else if(paramMapEntry.getValue() != null && paramMapEntry.getValue().endsWith("``") && curParamType == 9 ){
								sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");
								sb = sb.replace(paramMapEntry.getValue().lastIndexOf("``"), paramMapEntry.getValue().lastIndexOf('`'), "");

								ldapmapping = sb.toString();
								
								paramValList = new ArrayList<String>(Arrays.asList(ldapmapping.split("``")));
								for(String data:paramValList) {
									String[] ldapmappingval = data.split("~~~~");
									
									ldapmappingdata.put(ldapmappingval[0], Integer.parseInt(ldapmappingval[1]));

								}
								if(sb.length() >= 32768){
									cellVal = " *** Limit exceeded for cell. ***";
								}else{
									cellVal = sb.toString();
								}
//								System.out.println(sb);
							}else{
								cellVal = paramMapEntry.getValue();
							}
						}
						
//						cellVal = paramMapEntry.getValue();

					for(String col : showColWithParamTypeIdList){
						String[] colArr = col.split("~~"); 
						String column = colArr[0];
						Long paramTypeId = Long.parseLong(colArr[1]);
						
						if(column.equalsIgnoreCase(curParamName)){
							if(curParamType == 9){
								if(!ldapmappingdata.isEmpty()) {
									List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMaapingId, con);
									for(LdapMapping attribute:ldapMappingList){
										for (Map.Entry<String,Integer> entry : ldapmappingdata.entrySet()) {
											//List<String> attributeData = new ArrayList<String>(Arrays.asList(atributes.split("~~~~")));
											if(attribute.getLdapAttributeId() == entry.getValue()) {
												Cell cell0b14 = row.createCell(tempColCount +x);
												cell0b14.setCellValue(entry.getKey());
												x++;
											}
										}
									}
								}
							} else{
								cell6 = row.createCell(tempColCount +x);
								cell6.setCellValue(cellVal);
							}
							break;
						}else {
							if(paramTypeId == 9) {
								int ldapMappingId = Integer.parseInt(colArr[2]);
								List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMappingId, con);
								x = x+ldapMappingList.size();
							}else{
								x++;
							}
						}
					/*if(astParName.getAssetParamName().equalsIgnoreCase(paramMapEntry.getKey())){
						Cell cell5 = row.createCell(tempColCount +x);
						cell5.setCellValue(paramMapEntry.getValue());
						colCount++;
						break;
					}else{
						x++;
					}
					}*/
					}
				  }
				}
				int x = 0;
				String cellVal = null;
				for(String col : showColWithParamTypeIdList){
					String[] colArr = col.split("~~"); 
					String column = colArr[0];
					Long paramTypeId = Long.parseLong(colArr[1]);
					
					
					Long curParamType = 0L;
					int ldapMaapingId = 0;
					
					for(AssetParamDef astParName : assetParamList){
						curParamType = astParName.getParamTypeId();	
						if(curParamType == 9) {
							ldapMaapingId = astParName.getLdapMappingId();
						}
						if(column.equalsIgnoreCase(astParName.getAssetParamName())){
							cellVal = null;
							if(astParName.getParamTypeId() == 5){
								cellVal = assetInstVerDao.getDerivedAttributeValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
								String derivedAttrVals = cellVal;
								String[] derval = derivedAttrVals.split("`!!`");
								if(derval[0].equals("0")){
									derivedAttrVals = derval[1];
								}else{
									derivedAttrVals = derval[0];
								}
								if(derivedAttrVals.contains("``")) {
									if(derivedAttrVals.contains("~~")){
										derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
									}
									if(derivedAttrVals.contains("``")){
										derivedAttrVals = derivedAttrVals.replaceAll("``", "|");
									}
									if(derivedAttrVals.contains("`~`")){
										derivedAttrVals=derivedAttrVals.replace("`~`", "~~");
									}
								}else {
									if(derivedAttrVals.contains("~~")){
										derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
									}

									if(derivedAttrVals.contains("`~`")){
										derivedAttrVals=derivedAttrVals.replace("`~`", ",");
									}
								}
								cellVal = derivedAttrVals;
								cell6 = row.createCell(tempColCount +x);
								cell6.setCellValue(cellVal.trim());
							}else if(astParName.getParamTypeId() == 6){
								cellVal = assetInstVerDao.getDerivedComputationValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName,  astParName.getAssetParamName(), con);
								cell6 = row.createCell(tempColCount +x);
								cell6.setCellValue(cellVal);								
							}else if(astParName.getParamTypeId() == 8) {//filter/filter search export
								cellVal = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, astParName.getAssetParamName(), con);
								String derivedAssetListValue = cellVal;
								String finalValue = "";
								String[] data = derivedAssetListValue.split("`!!`");
								if(data[0].equalsIgnoreCase("0")) {
									if(data.length == 2){
		        						finalValue = data[1];
		        					}else{
		        						finalValue = ""; 
		        					}
								}else {
									if(data.length == 2){
		        						finalValue = data[1];
		        					}else{
		        						finalValue = ""; 
		        					}
								}
								if(finalValue.contains("``")) {
									if(finalValue.contains("~~")){
										finalValue = finalValue.replaceAll("~~", ",");
									}
									if(finalValue.contains("``")){
										finalValue = finalValue.replaceAll("``", "|");
									}
									if(finalValue.contains("`~`")){
										finalValue = finalValue.replace("`~`", "~~");
									}
								}else {
									if(finalValue.contains("~~")){
										finalValue = finalValue.replaceAll("~~", ",");
									}

									if(finalValue.contains("`~`")){
										finalValue = finalValue.replace("`~`", ",");
									}
								}
								cellVal = finalValue;
								cell5 = row.createCell(tempColCount +x);
								cell5.setCellValue(cellVal);
							}
						}
					}
					
					if(paramTypeId == 9) {
						int ldapMappingId = Integer.parseInt(colArr[2]);
						List<LdapMapping> ldapMappingList = assetDao.getLdapMappingAttributeList(ldapMappingId, con);
						x = x+ldapMappingList.size();
					}else{
						x++;
					}					
				}

				finalCnt = colCountForFlag+basicColCount;

				cell7 = row.createCell(finalCnt);
				if(attributeExportVo.getTaxonomyName() == null){
					cell7.setCellValue("");
				}else{
					cell7.setCellValue(attributeExportVo.getTaxonomyName());
				}

				cell8 = row.createCell(finalCnt+1);
				cell8.setCellValue(attributeExportVo.getTagName());


			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/***Wrapper function***/
	@GET
	@Path("/exportCreateFilterMain")
	public void exportCreateFilterMain(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("operators") String operators,
			@QueryParam("assetParamNames") String assetParamNames, @QueryParam("param1Values") String param1Values,
			@QueryParam("param2Values") String param2Values, @QueryParam("logicalSelect") String logicalSelect,
			@QueryParam("taxonomyNames") String taxonomyNames) {
		log.trace("exportCreateFilterMain || Begin");
		Connection conn = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("exportCreateFilterMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AssetDao assetDao = new AssetDao();
			UserDao userDao = new UserDao();
			User user = new User();
			if(userName.equalsIgnoreCase("guest")){

			}else
			{
				user = userDao.getUserIdByUserName(userName, conn);
			}
			AssetDef ad = assetDao.getAssetsByAssetName(assetName, conn);

			processExportCreateFilter(userName, assetName, ad.getAssetId(), user.getUserId(), operators, assetParamNames, param1Values,
					param2Values, logicalSelect, taxonomyNames);
		} catch (RepoproException e) {
			log.error("exportCreateFilterMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			log.error("exportCreateFilterMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("exportCreateFilterMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("exportCreateFilterMain || End");
		System.gc();
	}



	/**
	 * @method advancedSearchExport
	 * @description Export excel for Advanced Search
	 * @return Excel(.xlxs file)
	 * @throws RepoproException
	 */
	@GET
	@Path("/advancedSearchExport")
//	@Produces("application/vnd.ms-excel")
	@Produces("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	public Response advancedSearchExport(@QueryParam("usecase") String usecase,@QueryParam("parameters") String parameters,@QueryParam("userName") String userName)throws RepoproException{

		log.trace("advancedSearchExport || Begin");
		downloadName = "Custom_search_details_"+userName+"_"+System.currentTimeMillis()+"".concat(".xlsx");
//		File file = new File(System.getProperty("java.io.tmpdir")+downloadName);
		ResponseBuilder response = null;
		Connection conn = null;
		XSSFSheet mySheet = null;
		FileOutputStream fileOutputStream = null;

		Runtime r = Runtime.getRuntime();
		try{

			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			mySheet = myWorkBook.createSheet("Custom Search Details");

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);
			File file = File.createTempFile(downloadName, "");

			file.deleteOnExit();

			fileOutputStream = new FileOutputStream(file);
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("advancedSearchExport || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("advancedSearchExport || dao call of advancedSearchByUsecaseDetails() method to retrieve user list");
			}

			AdvancedSearchDao advancedSearchDao = new AdvancedSearchDao();
			
			boolean flag = advancedSearchDao.advancedSearchExport(mySheet, cellHeaderStyle, usecase, parameters, userName, conn);

			conn.commit();

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

		}catch(IOException e){
			log.error("advancedSearchExport || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		}catch(Exception e){
			log.error("advancedSearchExport || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} finally{
			try {
				fileOutputStream.close();
			} catch (IOException e1) {
				log.debug("advancedSearchExport ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			if (log.isDebugEnabled()) {
				log.debug("advancedSearchExport ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
			//			CommonUtils.deleteDir(FILE_PATH+downloadName);
		}

		log.trace("advancedSearchExport || End");
		r.gc();
		return response.build();
	}
	
	
	/**
	 * @method filterForGetAssetInstanceForFilterExport
	 * @description to filter the filter data 
	 * @param userName
	 * @param assetName
	 * @param assetId
	 * @param operators
	 * @param assetParamNames
	 * @param param1Values
	 * @param param2Values
	 * @param logicalSelect
	 * @param taxonomyNames
	 * @param key
	 * @param value
	 * @param from
	 * @return success response
	 */
	@GET
	@Encoded
	@Path("/filterSearchExport")
	public void filterForGetAssetInstanceForFilterExport(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName, @QueryParam("assetId") Long assetId,
			@QueryParam("operators") String operators, @QueryParam("assetParamNames") String assetParamNames,
			@QueryParam("param1Values") String param1Values, @QueryParam("param2Values") String param2Values,
			@QueryParam("logicalSelect") String logicalSelect, @QueryParam("taxonomyNames") String taxonomyNames,
			@QueryParam("value") String value){

		if (log.isTraceEnabled()) {
			log.trace("filterForGetAssetInstanceForFilterExport || begin with userName : " + userName + " assetName :" + assetName
					+ " assetId:" + assetId + " operators:" + operators + " assetParamNames:" + assetParamNames
					+ " param1Values:" + param1Values + " param2Values:" + param2Values + " logicalSelect:"
					+ logicalSelect + " taxonomyNames:" + taxonomyNames +" value:"+value);
		}
		try {
			assetName = URLDecoder.decode(assetName, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		downloadName = "Filtered_export_"+assetName+"_"+System.currentTimeMillis()+"".concat(".xlsx");
		long startTime = System.currentTimeMillis();
		File file = new File(FILE_PATH+downloadName);
		ResponseBuilder response = null;
		Connection conn = null;
		XSSFSheet mySheet1 = null;
		XSSFSheet mySheet2 = null;
		FileOutputStream fileOutputStream = null;
		boolean flag = false;
		boolean showFlag = false;
		boolean propertiesFlag = false;
		User user = null;
		UserDao userDao = null;

		ExcelExportDao exportDao = new ExcelExportDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<AssetInstanceVersion> assetInstVerList = new ArrayList<AssetInstanceVersion>();
		List<AssetDef> assetlList = new ArrayList<AssetDef>();
		List<String> showColList = new ArrayList<String>();
		List<AssetInstanceVersion> listofFilterInformation = null ;
		ShowHideDao showHideDao = new ShowHideDao();
		List<AssetInstance> listOfAssetInstanceVos = new ArrayList<AssetInstance>();

		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		StringBuffer staticParameters = new StringBuffer("");
		StringBuffer nonStaticParameters = new StringBuffer("");
		StringBuilder richtextFinalRes = new StringBuilder("");
		StringBuffer sb = new StringBuffer("");

		List<AssetParamDef> listOfNonStaticParamDefs = null;
		Runtime r = Runtime.getRuntime();
		try {
			
			String actualValue = URLDecoder.decode(value, "UTF-8");
			String finalVal = "";
			if (actualValue.contains("_") || actualValue.contains("%") || actualValue.contains("\\")){
				finalVal = actualValue;
				finalVal = actualValue.replace("\\", "\\\\\\\\");
			}else{
				finalVal = actualValue;
			}
			
			
			XSSFWorkbook myWorkBook = new XSSFWorkbook();
			assetName = URLDecoder.decode(assetName, "UTF-8");
			param1Values = URLDecoder.decode(param1Values, "UTF-8");
			param2Values = URLDecoder.decode(param2Values, "UTF-8");
			operators = URLDecoder.decode(operators, "UTF-8");
			
			if(param1Values.contains("'")){
				param1Values = param1Values.replace("'", "\\'");
			}
			if(param2Values.contains("'")){
				param2Values = param2Values.replace("'", "\\'");
			}
			String shortAssetName = "";
			if(assetName.length() > 19){
				shortAssetName = assetName.substring(0,18);
				mySheet1 = myWorkBook.createSheet(shortAssetName+" Attributes");
			}else{
				mySheet1 = myWorkBook.createSheet(assetName+" Attributes");
			}


			if(assetName.length() > 16){
				shortAssetName = assetName.substring(0,15);
				mySheet2 = myWorkBook.createSheet(shortAssetName+" Relationships");
			}else{
				mySheet2 = myWorkBook.createSheet(assetName+" Relationships");
			}

			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);

			fileOutputStream = new FileOutputStream(file);
			conn = DBConnection.getInstance().getConnection();
			
			boolean flagForUser = assetInstVerDao.findAdminRightsByUserName(userName, conn);
			
			ShowHideManager shd = new ShowHideManager();
			ShowHideColumn hideColumn = new ShowHideColumn();
			
			userDao = new UserDao();
			user = userDao.getUserIdByUserName(userName, conn);
			hideColumn.setAssetId(assetId);
			hideColumn.setUserId(user.getUserId());
			
			ShowHideColumn shc = shd.getShowHideParamValues(hideColumn, userName, conn);
			java.util.Map<Long, String> hideParameters = shc.getShowParamDetails();
			@SuppressWarnings("unused")
			int showHideParamCount = hideParameters.size();
			String showHideAssetParamName = new String();
			@SuppressWarnings("rawtypes")
			Iterator itr = hideParameters.entrySet().iterator();
			while (itr.hasNext()) {
				@SuppressWarnings("rawtypes")
				java.util.Map.Entry pair = (java.util.Map.Entry) itr.next();
				showHideAssetParamName = showHideAssetParamName.concat(pair.getValue().toString() + ",");
			}
			if (showHideAssetParamName.length() != 0) {
				//non static and static information
				String[] paramNames  = showHideAssetParamName.split(",");
//				StringBuffer sb = new StringBuffer();

				for (int i = 0; i < paramNames.length; i++) {
					sb.append(paramNames[i]+",");
					showColList.add(paramNames[i]);
				}
				sb = sb.deleteCharAt(sb.length()-1);
				for(int i=0;i<paramNames.length;i++){
					String paramName = paramNames[i];
					if (log.isTraceEnabled()) {
						log.trace("filterForGetAssetInstanceForFilterExport || dao method called : getAssetParamDefByAssetNameAndParamName(assetName,paramName)");
					}
					AssetParamDef paramdef = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(assetName,paramName, conn);
					if(paramdef.getIs_static()!= 1){//non-static
						nonStaticParameters.append(paramdef.getAssetParamName()+",");
					}else{
						staticParameters.append(paramdef.getAssetParamName()+",");
					}
				}

				// Asset instance attributes
				List<AssetParamDef> assetParamDefList = exportDao.getAssetParamDetails(conn, assetName);
				for(AssetParamDef assetParamDef : assetParamDefList){
					for(int i=0;i<paramNames.length;i++){
						if(assetParamDef.getIs_static() == 0 && paramNames[i].equalsIgnoreCase(assetParamDef.getAssetParamName())){							// for Static Asset Attributes
							flag = true;
							break;
						}
					}
				}
				
				if(nonStaticParameters.length()!=0){
					nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length()-1);	
				}
				if(staticParameters.length()!=0){
					staticParameters = staticParameters.deleteCharAt(staticParameters.length()-1);
				}
				if (log.isTraceEnabled()) {
					log.trace("filterForGetAssetInstanceForFilterExport || dao method called : getFinalResultForCreateFilterAttributeSheetWithFilter to get list of asset instance details for filter applied");
				}


				listofFilterInformation = exportDao.getFinalResultForCreateFilterAttributeSheetWithFilter(userName, assetId , assetName,
						assetParamNames, param1Values, param2Values,operators, logicalSelect, taxonomyNames,sb.toString(),flag,flagForUser,staticParameters,nonStaticParameters,finalVal, conn);
				if(nonStaticParameters.length()!=0){
					if (log.isTraceEnabled()) {
						log.trace("filterForGetAssetInstanceForFilterExport || dao method called : getAssetParamDefsByParameters(parameters,assetName)");
					}
					listOfNonStaticParamDefs = assetInstanceVersionDao.getAssetParamDefsByParameters(nonStaticParameters.toString(),assetName,conn);

					TreeMap<String, String> paramValues =  new TreeMap<String,String>();
					Long newAssetInstVersionId = 0L;
					String latestAssetInstParamName = "";
					int jj=1;
					for (int i = 0; i < listofFilterInformation.size(); i++) {
						AssetInstanceVersion aiv = listofFilterInformation.get(i);
						newAssetInstVersionId = aiv.getAssetInstVersionId();
						AssetInstance vo =new AssetInstance();
						vo.setAssetInstName(aiv.getAssetInstName());
						vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
						vo.setDescription(aiv.getDescription());
						vo.setCreatedOn(aiv.getCreatedOn());
						vo.setVersionName(aiv.getVersionName());
						vo.setVersionable(aiv.getVersionable());
						vo.setTagName(aiv.getTagName());
						vo.setTaxonomyName(aiv.getTaxonomyName());
						for (int j = 0; j < listOfNonStaticParamDefs.size(); j++) {
							AssetParamDef apd = listOfNonStaticParamDefs.get(j);
							if(aiv.getAssetParamName()!=null)
								//---------------------start Pinak 25-07-2018------------
								if(aiv.getAssetParamName().equalsIgnoreCase(apd.getAssetParamName())){
									flag = true;
	
									if(apd.getParamTypeId()==3){
										paramValues.put(apd.getAssetParamName().toLowerCase(), aiv.getFileName());
									}else{
										if(apd.getParamTypeId()==5){
	
	
											paramValues.put(apd.getAssetParamName().toLowerCase(), assetInstanceVersionDao.getDerivedAttributeValues(userName, aiv.getAssetInstVersionId().toString(), assetName, apd.getAssetParamName().toLowerCase(), conn));
										}else if(apd.getParamTypeId()==6){
											paramValues.put(apd.getAssetParamName().toLowerCase(), assetInstanceVersionDao.getDerivedComputationValues(userName, aiv.getAssetInstVersionId().toString(), assetName, apd.getAssetParamName().toLowerCase(), conn));
										}else if(apd.getParamTypeId()==8) {
											paramValues.put(apd.getAssetParamName().toLowerCase(), assetInstanceVersionDao.getDerivedAttributeForAssetListValues(userName, aiv.getAssetInstVersionId().toString(), assetName, apd.getAssetParamName().toLowerCase(), conn));
										}
										else if(apd.getParamTypeId() == 7 || apd.getParamTypeId() == 1){
											if(!latestAssetInstParamName.equalsIgnoreCase("")){
												if(latestAssetInstParamName.equals(aiv.getAssetParamName())){
													richtextFinalRes.append(aiv.getParamValue() + "~~") ;
												}else{
													richtextFinalRes = new StringBuilder(aiv.getParamValue() + "~~");
												}
											}else{
												richtextFinalRes = new StringBuilder(aiv.getParamValue() + "~~");
											}
	//										richtextFinalRes.replace(yourString.lastIndexOf(","), yourString.lastIndexOf(",") + 1, ")" );
											paramValues.put(apd.getAssetParamName().toLowerCase(), richtextFinalRes.toString());
											latestAssetInstParamName = apd.getAssetParamName();
										}else{
											paramValues.put(apd.getAssetParamName().toLowerCase(), aiv.getParamValue());
										}
									}
									/*if(flag){
										vo.setParamNameWithValues(paramValues);
										break;
									}*/
								}
								//-------------------- end Pinak 25-08-2018 --------------
							vo.setParamNameWithValues(paramValues);
						}
						if(i<listofFilterInformation.size()-1){
							if(!newAssetInstVersionId.equals(listofFilterInformation.get(jj).getAssetInstVersionId())){
								listOfAssetInstanceVos.add(vo);
								paramValues = new TreeMap<String, String>();
							}
						}else{
							listOfAssetInstanceVos.add(vo);
						}
						jj++;
					}
				} if(staticParameters.length()!= 0){
					//static information
					TreeMap<String, String> paramValues =  new TreeMap<String,String>();
					if (log.isTraceEnabled()) {
						log.trace("filterForGetAssetInstanceForFilterExport || dao method called : getAssetParamDefsByParameters(staticParameters,assetName)");
					}
					List<AssetParamDef> listOfStaticParamDefs = assetInstanceVersionDao.getAssetParamDefsByParameters(staticParameters.toString(),assetName,conn);

					if(nonStaticParameters.length()!=0){
						for(int i=0;i<listOfAssetInstanceVos.size();i++){

							AssetInstance aivo = listOfAssetInstanceVos.get(i);
							for (int k = 0; k< listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if(apd.getParamTypeId()==3){
									paramValues.put(apd.getAssetParamName().toLowerCase(),apd.getFileName());
								}else{
									paramValues.put(apd.getAssetParamName().toLowerCase(), apd.getStaticValue());
								}
							}
							java.util.Map<String, String> map = aivo.getParamNameWithValues();
							if(map!=null){
								map.putAll(paramValues);	
								aivo.setParamNameWithValues(map);
								listOfAssetInstanceVos.set(i, aivo);
							}else{
								aivo.setParamNameWithValues(paramValues);
								listOfAssetInstanceVos.set(i, aivo);
							}
						}
						paramValues= new TreeMap<String, String>();

					}else{

						for (int j = 0; j < listofFilterInformation.size(); j++) {
							AssetInstance vo = new AssetInstance();
							AssetInstanceVersion aiv = listofFilterInformation.get(j);
							for (int k = 0; k< listOfStaticParamDefs.size(); k++) {
								AssetParamDef apd = listOfStaticParamDefs.get(k);
								if(apd.getParamTypeId()==3){
									paramValues.put(apd.getAssetParamName().toLowerCase(),apd.getFileName());
								}else{
									paramValues.put(apd.getAssetParamName().toLowerCase(), apd.getStaticValue());
								}
							}
							vo.setAssetInstName(aiv.getAssetInstName());
							vo.setAssetInstVersionId(aiv.getAssetInstVersionId());
							vo.setDescription(aiv.getDescription());
							vo.setCreatedOn(aiv.getCreatedOn());
							vo.setVersionName(aiv.getVersionName());
							vo.setVersionable(aiv.getVersionable());
							vo.setParamNameWithValues(paramValues);
							vo.setTagName(aiv.getTagName());
							vo.setTaxonomyName(aiv.getTaxonomyName());
							listOfAssetInstanceVos.add(vo);
							paramValues= new TreeMap<String, String>();
						}
					}
				}
			}else {

				// getBasic information
				TreeMap<String, String> paramValues =  new TreeMap<String,String>();
				listOfNonStaticParamDefs = assetInstanceVersionDao.getAssetParamDefsByParameters(nonStaticParameters.toString(),assetName,conn);
				if (log.isTraceEnabled()) {
					log.trace("filterForGetAssetInstanceForFilterExport || dao method called : getAassetInstanceDetailsWithOutParametersExcelExport( assetName)");
				}
				/*List<AssetInstanceVersion> basicInformationOfassetInstance  = exportDao.getAssetInstanceForFilterWithNonStaticParametersDaoExcelExport(userName, assetName,
						assetParamNames, param1Values, param2Values,operators, logicalSelect, taxonomyNames,"", conn);*/

				listofFilterInformation = exportDao.getFinalResultForCreateFilterAttributeSheet(userName, assetId , assetName,
						assetParamNames, param1Values, param2Values,operators, logicalSelect, taxonomyNames,"",flag,flagForUser,staticParameters,nonStaticParameters, conn);

				for (int i = 0; i < listofFilterInformation.size(); i++) {
					AssetInstanceVersion aiv = listofFilterInformation.get(i);
					AssetInstance vo = new AssetInstance();
					vo.setAssetInstName(aiv.getAssetInstName());
					vo.setAssetInstVersionId(aiv
							.getAssetInstVersionId());
					vo.setDescription(aiv.getDescription());
					vo.setCreatedOn(aiv.getCreatedOn());
					vo.setVersionName(aiv.getVersionName());
					vo.setVersionable(aiv.getVersionable());
					vo.setTagName(aiv.getTagName());
					vo.setTaxonomyName(aiv.getTaxonomyName());
					for(AssetParamDef apd : listOfNonStaticParamDefs){
						if(apd.getParamTypeId() == 3){
							paramValues.put(apd.getAssetParamName(), apd.getFileName());
						}else{
							paramValues.put(apd.getAssetParamName(), apd.getStaticValue());
						}
					}
					vo.setParamNameWithValues(paramValues);
					listOfAssetInstanceVos.add(vo);
				}
			}

			Collections.sort(listOfAssetInstanceVos, new AssetInstance());
			List<AssetParamDef> assetParamList = exportDao.getAssetInstanceParameters(conn, assetName);
			
			ShowHideColumn showHideCol = showHideDao.getShowHideForAivIdColumn(shc, conn);
			Map<Long, String> showAivMap = showHideCol.getShowAivDetails();
			for(Map.Entry<Long, String> map : showAivMap.entrySet()){
				if(map.getValue()!= null){
					showFlag = true;
				}
			}

			printExcelCreateFilterAttributeSheet(conn ,mySheet1,cellHeaderStyle,listOfAssetInstanceVos,assetName,showColList,showFlag,assetParamList,userName);

			if (log.isDebugEnabled()) {
				log.debug("filterForGetAssetInstanceForFilterExport ||list of asset details:"
						+ assetlList.size() + "retrieved successfully");
			}
			List<AssetInstRelationship> assetInstRel = exportDao.getFinalResultForCreateFilterSearchRelationshipSheeet(conn, assetName, listOfAssetInstanceVos, userName , finalVal);
			setExcelDataAIRelationships(mySheet2, cellHeaderStyle, assetInstRel, assetName);

			if (log.isDebugEnabled()) {
				log.debug("filterForGetAssetInstanceForFilterExport || "
						+ assetInstVerList.toString());
			}
			log.debug(" filterForGetAssetInstanceForFilterExport  || retrieved "
					+ assetInstVerList.size()
					+ " asset instance version details by asset name : "
					+ assetName.toString());

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

			user = userDao.retProfileForUserName(userName, conn);
			MailTemplateDao mailDao = new MailTemplateDao();
			MailConfig mailConfig = mailDao.getMailConfig(conn);
			SendEmail.sendAttachedMail(mailConfig,user.getEmailId(), "RepoPro Export XLSX: Successful", MessageUtil.getMessage(Constants.EMAIL_HDR) + "Export of "+assetName+" filtered List as XLSX was successful. Please find the file in attachment.\n\nRepoPro "  + MessageUtil.getMessage(Constants.EMAIL_NOTE),downloadName,FILE_PATH+downloadName);

			log.info("Time taken for Create Filter Export :"+(System.currentTimeMillis() - startTime)/1000+" Secs");
		}catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterForGetAssetInstanceForFilterExport || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("filterForGetAssetInstanceForFilterExport || "
					+ assetInstVerList.toString() + " || exit");
		}
		//		return response.build();
		r.gc();
	
	}
	
	
	/**
	 * @method excelExportBrowseGrid
	 * @description Export excel for Browse grid
	 * @param from
	 * @param to
	 * @param userName
	 * @param assetName
	 * @param assetId
	 * @param userId
	 * @return Excel(.xlxs file)
	 * @throws RepoproException
	 */
	@GET
	@Encoded
	@Path("/exportBrowseGridSearchData/{userName}")
	public void exportBrowseGridSearchData(@PathParam("userName") String userName,
			@QueryParam("assetName") String assetName,
			@QueryParam("assetId") Long assetId,
			@QueryParam("userId") Long userId,
			@QueryParam("value")String searchValue) {
		log.trace("exportBrowseGridSearchData || Begin");
		long startTime = System.currentTimeMillis();
		
		ResponseBuilder response = null;
		Connection conn = null;
		XSSFSheet mySheet1 = null;
		XSSFSheet mySheet2 = null;
		FileOutputStream fileOutputStream = null;
		boolean flag = false;
		boolean showFlag = false;

		ExcelExportDao exportDao = new ExcelExportDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<AssetInstanceVersion> assetInstVerList = new ArrayList<AssetInstanceVersion>();
		List<AssetDef> assetlList = new ArrayList<AssetDef>();
		List<String> showColList = new ArrayList<String>();
		ShowHideDao showHideDao = new ShowHideDao();
		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		UserDao userDao = new UserDao();
		User user = null;

		StringBuffer staticParameters = new StringBuffer("");
		StringBuffer nonStaticParameters = new StringBuffer("");
		Runtime r = Runtime.getRuntime();
		try {
			
			String actualValue = URLDecoder.decode(searchValue, "UTF-8");
			String actualAssetName = URLDecoder.decode(assetName, "UTF-8");
			
			downloadName = actualAssetName+"_export_"+System.currentTimeMillis()+"".concat(".xlsx");;
			File file = new File(FILE_PATH+downloadName);
			
			String finalVal = actualValue;
			if (actualValue.contains("_")||actualValue.contains("%")||actualValue.contains("\\") || actualValue.contains("'")){
				finalVal = actualValue;
				finalVal = actualValue.replace("\\", "\\\\\\\\");
				/*finalVal = finalVal.replace("_", "\\_");
				finalVal = finalVal.replace("%", "\\%");*/
			}else{
				finalVal = actualValue;
			}
			
			XSSFWorkbook myWorkBook = new XSSFWorkbook();

			String shortAssetName = "";
			if(actualAssetName.length() > 19){
				shortAssetName = actualAssetName.substring(0,18);
				mySheet1 = myWorkBook.createSheet(shortAssetName+" Attributes");
			}else{
				mySheet1 = myWorkBook.createSheet(actualAssetName+" Attributes");
			}


			if(actualAssetName.length() > 16){
				shortAssetName = actualAssetName.substring(0,15);
				mySheet2 = myWorkBook.createSheet(shortAssetName+" Relationships");
			}else{
				mySheet2 = myWorkBook.createSheet(actualAssetName+" Relationships");
			}


			XSSFFont headerFont = myWorkBook.createFont();
			headerFont.setBoldweight(XSSFFont.BOLDWEIGHT_BOLD);

			XSSFCellStyle cellHeaderStyle = myWorkBook.createCellStyle();
			cellHeaderStyle.setFont(headerFont);

			fileOutputStream = new FileOutputStream(file);
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("exportBrowseGridSearchData || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			ShowHideManager shd = new ShowHideManager();
			ShowHideColumn hideColumn = new ShowHideColumn();
			hideColumn.setAssetId(assetId);
			hideColumn.setUserId(userId);

			if (log.isTraceEnabled()) {
				log.trace("exportBrowseGridSearchData || method called : getShowHideParamValues");
			}
			ShowHideColumn shc = shd.getShowHideParamValues(hideColumn, userName, conn);

			java.util.Map<Long, String> hideParameters = shc.getShowParamDetails();

			String assetParamName = new String();
			@SuppressWarnings("rawtypes")
			Iterator itr = hideParameters.entrySet().iterator();
			while (itr.hasNext()) {
				@SuppressWarnings("rawtypes")
				java.util.Map.Entry pair = (java.util.Map.Entry)itr.next();
				assetParamName = assetParamName.concat(pair.getValue().toString()+",");
			}

			String[] paramNames  = {};
			StringBuffer sb =new StringBuffer();
			if(!assetParamName.equals("")){
				paramNames  = assetParamName.split(",");
			}

			for (int i = 0; i < paramNames.length; i++) {
				sb.append(paramNames[i]+",");
				showColList.add(paramNames[i]);
			}

			String paramName = null;
			AssetParamDef paramdef = null;

			for(int i=0;i<paramNames.length;i++){
				paramName = paramNames[i];
				if (log.isTraceEnabled()) {
					log.trace("exportBrowseGridSearchData || dao method called : getAssetParamDefByAssetNameAndParamName(assetName,paramName)");
				}
				paramdef = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(actualAssetName,paramName, conn);
				if(paramdef.getIs_static()!=1){   //non-static
					nonStaticParameters.append(paramdef.getAssetParamName()+",");
				}else{
					staticParameters.append(paramdef.getAssetParamName()+",");
				}

			}

			// Asset instance attributes
			List<AssetParamDef> assetParamDefList = exportDao.getAssetParamDetails(conn, actualAssetName);
			for(AssetParamDef assetParamDef : assetParamDefList){
				for(int i=0;i<paramNames.length;i++){
					if(assetParamDef.getIs_static() == 0 && paramNames[i].equalsIgnoreCase(assetParamDef.getAssetParamName())){							// for Static Asset Attributes
						flag = true;
						break;
					}
				}
			}

			boolean authorityFlag = assetInstVerDao.findAdminRightsByUserName(userName, conn);

			if(nonStaticParameters.length()!=0){
				nonStaticParameters = nonStaticParameters.deleteCharAt(nonStaticParameters.length()-1);	
			}
			if(staticParameters.length()!=0){
				staticParameters = staticParameters.deleteCharAt(staticParameters.length()-1);
			}

			boolean flagForUser = assetInstVerDao.findAdminRightsByUserName(userName, conn);

			List<AssetInstanceVersion> assetInstanceVersionList = exportDao.getFinalResultForBrowseGridAttributeSheeetWithFilter(conn, assetId , actualAssetName, flag,flagForUser, staticParameters, nonStaticParameters, userName,authorityFlag,finalVal);
			Collections.sort(assetInstanceVersionList,new AssetInstanceVersion());

			ShowHideColumn showHideCol = showHideDao.getShowHideForAivIdColumn(shc, conn);
			Map<Long, String> showAivMap = showHideCol.getShowAivDetails();
			for(Map.Entry<Long, String> map : showAivMap.entrySet()){
				if(map.getValue()!= null){
					showFlag = true;
				}
			}

			List<AssetParamDef> assetParamList = exportDao.getAssetInstanceParameters(conn, actualAssetName);
			printExcelBrowseGridAttributeSheet(conn ,mySheet1,cellHeaderStyle,assetInstanceVersionList,actualAssetName,showColList,showFlag,assetParamList,userName);


			if (log.isDebugEnabled()) {
				log.debug("exportBrowseGridSearchData ||list of asset details:"
						+ assetlList.size() + "retrieved successfully");
			}

			boolean accessFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			List<AssetInstRelationship> assetInstRel = exportDao.getFinalResultForBrowseGridSearchRelationshipSheeet(conn, actualAssetName, userName, accessFlag , finalVal);
			setExcelDataAIRelationships(mySheet2, cellHeaderStyle, assetInstRel, actualAssetName);

			if (log.isDebugEnabled()) {
				log.debug("exportBrowseGridSearchData || "
						+ assetInstVerList.toString());
			}
			log.debug(" exportBrowseGridSearchData  || retrieved "
					+ assetInstVerList.size()
					+ " asset instance version details by asset name : "
					+ actualAssetName.toString());

			response = Response.ok((Object) file);
			response.header("Content-Disposition","attachment; filename="+downloadName);
			myWorkBook.write(fileOutputStream);

			user = userDao.retProfileForUserName(userName, conn);
			MailTemplateDao mailDao = new MailTemplateDao();
			MailConfig mailConfig = mailDao.getMailConfig(conn);
			SendEmail.sendAttachedMail(mailConfig,user.getEmailId(), "RepoPro Export XLSX: Successful", MessageUtil.getMessage(Constants.EMAIL_HDR) + "Export of "+actualAssetName+" List as XLSX was successful. Please find the file in attachment.\n\nRepoPro "  + MessageUtil.getMessage(Constants.EMAIL_NOTE),downloadName,FILE_PATH+downloadName);

			log.info("exportBrowseGridSearchData || Time taken for Browse Grid Export :"+(System.currentTimeMillis() - startTime)/1000+" Secs");
		}
		catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			//			CommonUtils.deleteDir(FILE_PATH+downloadName);
			if (log.isTraceEnabled()) {
				log.trace("exportBrowseGridSearchData || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("exportBrowseGridSearchData || "
					+ assetInstVerList.toString() + " || exit");
		}
		//		return response.build();
		r.gc();
	}
	
}
