package com.thbs.repopro.export;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AdminAccessName;
import com.thbs.repopro.dto.AssetInstRelationship;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.RecentActivity;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;


public class ExcelExportDao {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	public List<AssetInstRelationship> getAssetInstanceRelationships(Connection con,String assetName)throws RepoproException, SQLException{
		log.trace("getAssetInstanceRelationships : begin");
		ArrayList<AssetInstRelationship> al = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		try{
			al = new ArrayList<AssetInstRelationship>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceRelationships : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS));
			preparedStmt.setString(Constants.ONE, assetName);
			rs = preparedStmt.executeQuery();
			AssetInstRelationship assetInsRel = null;
			while(rs.next()){
				assetInsRel = new AssetInstRelationship();
				assetInsRel.setSrcAssetName(rs.getString("src_asset"));
				assetInsRel.setSrcAssetId(rs.getLong("src_id"));
				assetInsRel.setSourceInstanceName(rs.getString("src_instname"));
				assetInsRel.setSourceVersionName(rs.getString("src_versioname"));
				assetInsRel.setSourceDescription(rs.getString("src_description"));
				assetInsRel.setType(rs.getString("type"));
				assetInsRel.setRelationShipName(rs.getString("relatiname"));
				assetInsRel.setDestAssetName(rs.getString("destassetname"));
				assetInsRel.setDestAssetId(rs.getLong("dest_id"));
				assetInsRel.setDestInstanceName(rs.getString("destinstname"));
				assetInsRel.setDestInstanceVersionName(rs.getString("destversioname"));
				assetInsRel.setDestdescription(rs.getString("destdescription"));
				al.add(assetInsRel);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceRelationships : "+PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}	
		return al;
	}

	public List<AssetInstance> getAssetInstanceAttributes(Connection con,String assetName)throws RepoproException, SQLException{
		log.trace("getAssetInstanceAttributes : begin");
		ArrayList<AssetInstance> al = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		try{
			al = new ArrayList<AssetInstance>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAttributes : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_ATTRIBUTES));
			preparedStmt.setString(Constants.ONE, assetName);
			rs = preparedStmt.executeQuery();
			AssetInstance assetInsAttr = null;
			while(rs.next()){
				assetInsAttr = new AssetInstance();
				assetInsAttr.setAssetInstVersionId(rs.getLong("vid"));
				assetInsAttr.setAssetInstName(rs.getString("instname"));
				assetInsAttr.setVersionName(rs.getString("versionname"));
				assetInsAttr.setDescription(rs.getString("description"));
				assetInsAttr.setValue(rs.getString("value"));
				al.add(assetInsAttr);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAttributes : "+PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_ATTRIBUTES));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}	
		return al;
	}

	public List<AssetParamDef> getAssetInstanceParameters(Connection con,String assetName)throws RepoproException, SQLException{
		log.trace("getAssetInstanceParameters : begin");
		ArrayList<AssetParamDef> apdList = new ArrayList<AssetParamDef>();
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		try{
			apdList = new ArrayList<AssetParamDef>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceParameters : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAMS_FOR_ASSET));
			preparedStmt.setString(Constants.ONE, assetName);
			rs = preparedStmt.executeQuery();
			AssetParamDef apd = null;
			while(rs.next()){
				apd = new AssetParamDef();
				apd.setAssetParamName(rs.getString("asset_param_name"));
				apd.setParamTypeId(rs.getLong("param_type_id"));
				apd.setLdapMappingId(rs.getInt("ldap_mapping_id"));
				apdList.add(apd);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceParameters : "+PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAMS_FOR_ASSET));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}	
		return apdList;
	}

	public List<AssetInstanceVersion> getAssetInstanceVersionsNonStaticExport(Connection con,String assetName)throws RepoproException,SQLException{
		log.trace("getAssetInstanceVersionsNonStaticExport : begin");
		ArrayList<AssetInstanceVersion> assetInstVersions = null;
		Connection con1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null; 
		try{
			assetInstVersions = new ArrayList<AssetInstanceVersion>();
			if(con == null){
				con1 = DBConnection.getInstance().getConnection();
			}
			if(log.isTraceEnabled()){
				log.trace("getAssetInstanceVersionsNonStaticExport : " + Constants.LOG_CONNECTION_OPEN);
			}
			pstmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_INSTANCE_VERSIONS_EXPORT));
			pstmt.setString(Constants.ONE, assetName);
			rs = pstmt.executeQuery();
			AssetInstanceVersion assetInstanceExportvo = null;
			while(rs.next()){
				assetInstanceExportvo = new AssetInstanceVersion();
				assetInstanceExportvo.setAssetInstVersionId(rs.getLong("vid"));
				assetInstanceExportvo.setAssetInstName(rs.getString("instname"));
				assetInstanceExportvo.setVersionName(rs.getString("versionname"));
				assetInstanceExportvo.setDescription(rs.getString("description"));
				assetInstanceExportvo.setAssetParamName(rs.getString("apname"));
				assetInstanceExportvo.setParamTypeId(rs.getLong("paramTypeId"));
				assetInstanceExportvo.setFileName(rs.getString("fileName"));
				assetInstanceExportvo.setParamValue(rs.getString("pvalue"));
				assetInstanceExportvo.setIsStatic(rs.getInt("isStatic"));
				assetInstVersions.add(assetInstanceExportvo);
			}
			if(log.isTraceEnabled()){
				log.trace("getAssetInstanceVersionsNonStaticExport : "+PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_INSTANCE_VERSIONS_EXPORT));
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(con1);
		}
		return assetInstVersions;
	}

	public List<AssetInstanceVersion> getAssetParamDtlsStaticExport(Connection con,String assetName,String assetParamName)throws RepoproException,SQLException{
		log.trace("getAssetParamDtlsStaticExport : begin");
		ArrayList<AssetInstanceVersion> assetParams = null;
		Connection con1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null; 
		try{
			assetParams = new ArrayList<AssetInstanceVersion>();
			if(con == null){
				con1 = DBConnection.getInstance().getConnection();
			}
			if(log.isTraceEnabled()){
				log.trace("getAssetParamDtlsStaticExport : " + Constants.LOG_CONNECTION_OPEN);
			}
			pstmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAMS_EXPORT));
			pstmt.setString(Constants.ONE, assetName);
			pstmt.setString(Constants.TWO, assetParamName);
			rs = pstmt.executeQuery();
			AssetInstanceVersion assetInstance = null;
			while(rs.next()){
				assetInstance = new AssetInstanceVersion();
				assetInstance.setAssetParamName(rs.getString("assetParamName"));
				assetInstance.setFileName(rs.getString("fileName"));
				assetInstance.setParamTypeId(rs.getLong("paramTypeId"));
				assetParams.add(assetInstance);
			}
			if(log.isTraceEnabled()){
				log.trace("getAssetParamDtlsStaticExport : "+PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAMS_EXPORT));
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(con1);
		}
		return assetParams;
	}

	public List<String> getAssetParamValuesByAssetName(Connection con,String assetName)throws RepoproException, SQLException{
		log.trace("getAssetParamValuesByAssetName : begin");
		ArrayList<String> al = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		try{
			al = new ArrayList<String>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamValuesByAssetName : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAM_VALUES));
			preparedStmt.setString(Constants.ONE, assetName);
			rs = preparedStmt.executeQuery();
			while(rs.next()){
				al.add(rs.getString("pvalue"));
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamValuesByAssetName : "+PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAM_VALUES));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}	
		return al;
	}

	public List<AssetParamDef> getAssetParamDetails(Connection con,String assetName)throws RepoproException, SQLException{

		log.trace("getAssetParamDetails : begin");

		ArrayList<AssetParamDef> assetParamDefList = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		try{
			assetParamDefList = new ArrayList<AssetParamDef>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDetails : " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAM_DETAILS));
			preparedStmt.setString(Constants.ONE, assetName);
			rs = preparedStmt.executeQuery();
			while(rs.next()){
				AssetParamDef assetParamDef = new AssetParamDef();
				assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
				assetParamDef.setAssetParamName(rs.getString("asset_param_name"));
				assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
				assetParamDef.setIs_static(rs.getInt("is_static"));
				assetParamDef.setStaticValue(rs.getString("static_val"));
				assetParamDefList.add(assetParamDef);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDetails : "+PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAM_DETAILS));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets : " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}	
		log.trace("getAssetParamDetails : End");
		return assetParamDefList;
	}

	@SuppressWarnings("resource")
	public List<AssetInstanceVersion> getFinalResultForAttributeSheeet(Connection con,Long assetId ,String assetName,boolean flag,StringBuffer staticParam,StringBuffer nonStaticParam,List<AssetParamDef> assetParamDefList,String userName,boolean authorityFlag){
		
		log.trace("getFinalResultForAttributeSheeet : begin");

		List<AssetInstanceVersion> assetAttributeList = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		PreparedStatement preparedStmt1 = null;
		StringBuilder queryStr = null;
		StringBuffer queryStrBuffer = null;
		LinkedHashMap<String,String> paramValues = null;
		List<AssetParamDef> apdList = new ArrayList<AssetParamDef>();
		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		String assetInstanceVersionId = "";
		String tempTableName1 = "";
		String tempTableName2 = "";
		String tempTableName3 = "";
		StringBuilder richtextFinalRes = null;
		StringBuilder ldapMappingFinalResult = null;

		try{
			assetAttributeList = new ArrayList<AssetInstanceVersion>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForAttributeSheeet : " + Constants.LOG_CONNECTION_OPEN);
			}

			if(flag){
				//create
				tempTableName1 = "table"+userName+System.currentTimeMillis();
				queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");

				if(nonStaticParam.length() !=0){
					queryStrBuffer.append("SELECT a.avid as vid,a.created_on, a.instname,a.versionname, a.description, b.apname, b.pvalue as value,b.ldap_attribute_id,pvfileName,staticVal,"
							+ "staticFilename,isStatic,paramtypeId,derivedattibuteandComputation,derivedassetlist,a.versionable,b.assetInstParamId from( SELECT aiv.asset_instance_version_id as avid,aiv.created_on,"
							+ " ai.asset_inst_name as instname,aiv.version_name as versionname, aiv.description,ad.versionable from asset_def ad JOIN asset_instance ai On "
							+ "ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id WHERE "
							+ "asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on, "
							+ "ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description, apd.asset_param_name as apname,"
							+ " pv.value as pvalue, pv.ldap_attribute_id, pv.fileName as pvfileName, apd.fileName as staticFilename, apd.static_val as staticVal, apd.is_static as isStatic,"
							+ " apd.param_type_id as paramtypeId, apd.derived_computed_description as derivedattibuteandComputation,apd.derived_asset_list as derivedassetlist,ad.versionable,aip.asset_inst_param_id as assetInstParamId from asset_def ad JOIN "
							+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN "
							+ "asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON "
							+ "aip.asset_param_id=apd.asset_param_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE "
							+ "ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"'))b ON a.avid=b.vid");
					
					/*queryStrBuffer.append("SELECT a.vid, a.instname,a.versionname, a.description, b.apname, b.value,pvfileName,staticVal,"
							+ "staticFilename,isStatic,paramtypeId,derivedattibuteandComputation,a.versionable FROM( SELECT aiv.asset_instance_version_id AS vid,"
							+ " ai.asset_inst_name AS instname,aiv.version_name AS versionname, aiv.description,ad.versionable AS versionable FROM "
							+ "asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id "
							+ "WHERE asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN (SELECT DISTINCT apd.asset_param_id,aiv.asset_instance_version_id AS vid, "
							+ "ai.asset_inst_name AS instname, aiv.version_name AS versionname, aiv.description, apd.asset_param_name AS apname, pv.value AS VALUE,"
							+ " pv.fileName AS pvfileName, apd.fileName AS staticFilename, apd.static_val AS staticVal, apd.is_static AS isStatic,"
							+ " apd.param_type_id AS paramtypeId, apd.derived_computed_description AS derivedattibuteandComputation FROM asset_def ad JOIN asset_instance "
							+ "ai ON ad.asset_id=ai.asset_id LEFT JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id  INNER JOIN asset_inst_params aip ON"
							+ " aip.asset_inst_param_id IN (SELECT DISTINCT asset_inst_param_id FROM asset_inst_params) LEFT JOIN asset_param_def apd ON "
							+ "aip.asset_param_id=apd.asset_param_id LEFT JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id "
							+ "WHERE ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"') GROUP BY vid,instname,versionname,description,apname  )b ON a.vid=b.vid");*/

				}
				if(staticParam.length() !=0)
				{
					String[] strArray = staticParam.toString().split(",");

					AssetParamDef apd = null;
					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'"); 
						preparedStmt = con.prepareStatement(queryStBuff.toString());
						rs = preparedStmt.executeQuery();
						while(rs.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(rs.getLong("asset_param_id"));
							apd.setAssetParamName(rs.getString("asset_param_name"));
							apd.setIs_static(rs.getInt("is_static"));
							apd.setStaticValue(rs.getString("static_val"));
							apd.setParamTypeId(rs.getLong("param_type_id"));
							apd.setFileName(rs.getString("fileName"));
							apdList.add(apd);
						}
					}
				}
			}
			else{
				if(staticParam.length() !=0){
					if(nonStaticParam.length() ==0){
						//create
						tempTableName1 = "table"+userName+System.currentTimeMillis();
						queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as "); 
						
						queryStrBuffer.append("SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description,ad.versionable from"
								+ " asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON"
								+ " ai.asset_inst_id=aiv.asset_instance_id WHERE ad.asset_name='"+assetName+"' ORDER BY  aiv.asset_instance_version_id");

					}
					String[] strArray = staticParam.toString().split(",");

					AssetParamDef apd = null;
					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'"); 
						preparedStmt = con.prepareStatement(queryStBuff.toString());
						rs = preparedStmt.executeQuery();
						while(rs.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(rs.getLong("asset_param_id"));
							apd.setAssetParamName(rs.getString("asset_param_name"));
							apd.setIs_static(rs.getInt("is_static"));
							apd.setStaticValue(rs.getString("static_val"));
							apd.setParamTypeId(rs.getLong("param_type_id"));
							apd.setFileName(rs.getString("fileName"));
							apdList.add(apd);
						}
					}

				}
			}

			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp1data = "CREATE INDEX vid ON "+tempTableName1+" (vid)" ;
			
			preparedStmt1 = con.prepareStatement(temp1data.toString());
			preparedStmt1.executeUpdate();
			
			tempTableName2 = "table"+userName+System.currentTimeMillis();
			queryStrBuffer = new StringBuffer("Create table "+tempTableName2+"(avd INT,grouppath TEXT)");

			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp2data = "CREATE INDEX avd ON "+tempTableName2+" (avd)" ;
			
			preparedStmt1 = con.prepareStatement(temp2data.toString());
			preparedStmt1.executeUpdate();
			
			String storedProcedure = "{call getAssetAttributes(?,?,?,?,?)}";
			CallableStatement callableStatement = con.prepareCall(storedProcedure);
			callableStatement.setString(1, assetName);
			callableStatement.setString(2, userName);
			callableStatement.setBoolean(3, authorityFlag);
			callableStatement.setString(4, tempTableName2);
			callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);
			callableStatement.execute();

			tempTableName3 = "table"+userName+System.currentTimeMillis();
			queryStr = new StringBuilder("create table "+tempTableName3+" as ");

			queryStr.append("select aiv.asset_instance_version_id as vid,aiv.created_on,"
					+ "ai.asset_inst_name as instname,group_concat(tg.tag_name) as tagname from asset_def ad JOIN "
					+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
					+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id LEFT OUTER JOIN "
					+ "tagging_master tg ON aiv.asset_instance_version_id=tg.asset_instance_version_id WHERE "
					+ "ad.asset_name='"+assetName+"' GROUP BY vid;");
			preparedStmt = con.prepareStatement(queryStr.toString());
			preparedStmt.executeUpdate();

			String temp3data = "CREATE INDEX vid ON "+tempTableName3+" (vid)" ;
			
			preparedStmt1 = con.prepareStatement(temp3data.toString());
			preparedStmt1.executeUpdate();
			
			
			if(flag){
				queryStr = new StringBuilder("select p.vid,p.created_on,p.instname,p.description,p.apname,p.versionname,p.pvfileName,p.staticVal,p.isStatic,p.paramtypeId,p.staticFilename,"
						+ "p.value,p.ldap_attribute_id,p.versionable as versionable,t.grouppath as taxname,tg.tagname as tagname,p.assetInstParamId from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.vid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.vid=tg.vid ; ");
			}else{
				queryStr = new StringBuilder("select p.vid,p.created_on,p.instname,p.description,p.versionname,"
						+ "t.grouppath as taxname,p.versionable as versionable,tg.tagname as tagname from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.vid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.vid=tg.vid ; ");
			}

			preparedStmt = con.prepareStatement(queryStr.toString());
			rs = preparedStmt.executeQuery();
			long latestAssetInstVerId = 0L;
			
//			preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_NONSTATIC_PARAM_DETAILS_EXPORT));
//			preparedStmt.setString(Constants.ONE, nonStaticParam.toString());
//			rs = preparedStmt.executeQuery();
//			if (log.isTraceEnabled()) {
//				log.trace("getFinalResultForAttributeSheeet ||"
//						+ PropertyFileReader
//						.getInstance()
//						.getValue(
//								Constants.GET_ALL_NONSTATIC_PARAM_DETAILS_EXPORT));
//			}
//			while(rs.next()){
//				
//			}
			long latestAssetInstparamId = 0L;
			AssetInstanceVersion attributeExportVo = null;
			while(rs.next()){
				attributeExportVo = new AssetInstanceVersion();
				attributeExportVo.setAssetInstVersionId(rs.getLong("vid"));
				attributeExportVo.setAssetInstName(rs.getString("instname"));
				attributeExportVo.setDescription(rs.getString("description"));
				//					
				attributeExportVo.setTaxonomyName(rs.getString("taxname"));
				attributeExportVo.setTagName(rs.getString("tagname"));
				attributeExportVo.setVersionable(rs.getBoolean("versionable"));
				attributeExportVo.setVersionName(rs.getString("versionname"));
				attributeExportVo.setCreatedOn(rs.getTimestamp("created_on"));
				paramValues = new LinkedHashMap<String, String>();
				assetInstanceVersionId = rs.getString("vid");
				if(flag){
					attributeExportVo.setAssetParamName(rs.getString("apname"));
					if(rs.getInt("isStatic") == 1){
						if(rs.getInt("paramtypeId") == 3)
						{
							paramValues.put(rs.getString("apname"), rs.getString("staticFilename"));
						}
						else{
							
							paramValues.put(rs.getString("apname"), rs.getString("staticVal"));
						}
					}else{
						if(rs.getInt("paramtypeId") == 3)
						{
							paramValues.put(rs.getString("apname"), rs.getString("pvfileName"));
						}
						else if(rs.getInt("paramtypeId") == 5){
							String derivedAttrVals = assetInstVerDao.getDerivedAttributeValues(userName, assetInstanceVersionId, assetName, rs.getString("apname"), con);
							String[] derval = derivedAttrVals.split("`!!`");
							if(derval[0].equals("0")){
								derivedAttrVals = derval[1];
							}else{
								derivedAttrVals = derval[0];
							}
							if(derivedAttrVals.contains("~~")){
								derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
							}
							
							if(derivedAttrVals.contains("`~`")){
								derivedAttrVals=derivedAttrVals.replace("`~`", ",");
							}
							paramValues.put(rs.getString("apname"), derivedAttrVals);
						}else if(rs.getInt("paramtypeId") == 6){
							String derivedCompVal = assetInstVerDao.getDerivedComputationValues(userName, assetInstanceVersionId, assetName, rs.getString("apname"), con);
							paramValues.put(rs.getString("apname"), derivedCompVal);
						}else if(rs.getInt("paramtypeId") == 8) {
							String derivedAssetListValue = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, attributeExportVo.getAssetInstVersionId().toString(), assetName, rs.getString("apname"), con);
							String finalValue = "";
							String[] data = derivedAssetListValue.split("`!!`");
							if(data[0].equalsIgnoreCase("0")) {
								if(data.length == 2){
	        						finalValue = data[1];
	        					}else{
	        						finalValue = ""; 
	        					}
							}else {
								finalValue = data[0];
							}
							
							if(finalValue.contains("~~")){
								finalValue = finalValue.replaceAll("~~", ",");
							}
							
							if(finalValue.contains("`~`")){
								finalValue = finalValue.replace("`~`", ",");
							}
							paramValues.put(rs.getString("apname"), finalValue);
						}
						else if(rs.getInt("paramtypeId") == 7 || rs.getInt("paramtypeId") == 1){
//							System.out.println(latestAssetInstparamId+"------------"+rs.getLong("assetInstParamId"));
							if(latestAssetInstparamId != 0){
								if(latestAssetInstparamId == rs.getLong("assetInstParamId")){
									richtextFinalRes.append(rs.getString("value") + "~~") ;
								}else{
									richtextFinalRes = new StringBuilder(rs.getString("value") + "~~");
								}
							}else{
								richtextFinalRes = new StringBuilder(rs.getString("value") + "~~");
							}
//							richtextFinalRes.replace(yourString.lastIndexOf(","), yourString.lastIndexOf(",") + 1, ")" );
							paramValues.put(rs.getString("apname"), richtextFinalRes.toString());
							latestAssetInstparamId = rs.getLong("assetInstParamId");
						} else if( rs.getInt("paramtypeId") == 9 ){
							
							if(latestAssetInstparamId != 0){
								if(latestAssetInstparamId == rs.getLong("assetInstParamId")){
									ldapMappingFinalResult.append(rs.getString("value")+"~~~~"+rs.getString("ldap_attribute_id") + "``") ;
								}else{
									ldapMappingFinalResult = new StringBuilder(rs.getString("value") +"~~~~"+rs.getString("ldap_attribute_id") + "``");
								}
							}else{
								ldapMappingFinalResult = new StringBuilder(rs.getString("value") +"~~~~"+rs.getString("ldap_attribute_id") + "``");
							}
							paramValues.put(rs.getString("apname"), ldapMappingFinalResult.toString());
							latestAssetInstparamId = rs.getLong("assetInstParamId");
							
						} else{
							if(rs.getString("apname") != null){
								
								paramValues.put(rs.getString("apname"), rs.getString("value"));
							}
						}
					}
					if(latestAssetInstVerId != rs.getLong("vid")){
						for(AssetParamDef apd : apdList){
							if(apd.getIs_static() == 1){
								if(apd.getParamTypeId() == 3){

									paramValues.put(apd.getAssetParamName(), apd.getFileName());
								}else{
									paramValues.put(apd.getAssetParamName(), apd.getStaticValue());
								}
							}
						}
					}
				}else{
					for(AssetParamDef apd : apdList){
						if(apd.getParamTypeId() == 3){
							paramValues.put(apd.getAssetParamName(), apd.getFileName());
						}else{
							paramValues.put(apd.getAssetParamName(), apd.getStaticValue());
						}
					}
				}

				attributeExportVo.setParamNamewithvalue(new TreeMap<String, String>(paramValues));
				assetAttributeList.add(attributeExportVo);
//				Collections.sort(assetAttributeList,new AssetInstanceVersion());

				latestAssetInstVerId = rs.getLong("vid");
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForAttributeSheeet : "+queryStr.toString());
			}

			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForAttributeSheeet : "+"Drop table table1;");
			}

		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(null != tempTableName1){
					preparedStmt = con.prepareStatement("Drop table IF EXISTS "+tempTableName1);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName2){
					
					preparedStmt = con.prepareStatement("Drop table IF EXISTS "+tempTableName2);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName3){
					preparedStmt = con.prepareStatement("Drop table IF EXISTS "+tempTableName3);
					preparedStmt.executeUpdate();
				}

				DBConnection.closeResultSet(rs);
				DBConnection.closePreparedStatement(preparedStmt);
				DBConnection.closePreparedStatement(preparedStmt1);
				if (log.isTraceEnabled()) {
					log.trace("getFinalResultForAttributeSheeet : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}catch(Exception e){
				e.printStackTrace();
			}
		}	
		log.trace("getFinalResultForAttributeSheeet : End");
		return assetAttributeList;
	}

	@SuppressWarnings("resource")
	public List<AssetInstanceVersion> getFinalResultForBrowseGridAttributeSheeet(Connection con, Long assetId,String assetName,boolean flag,boolean flagForUser,StringBuffer staticParam,StringBuffer nonStaticParam,String userName,boolean authorityFlag){

		log.trace("getFinalResultForBrowseGridAttributeSheeet : begin");

		List<AssetInstanceVersion> assetAttributeList = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		PreparedStatement preparedStmt1 = null;
		StringBuffer queryStrBuffer = new StringBuffer("");
		LinkedHashMap<String,String> paramValues = null;
		List<AssetParamDef> apdList = new ArrayList<AssetParamDef>();
		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		String assetInstanceVersionId = "";
		String tempTableName1 = null;
		String tempTableName2 = null;
		String tempTableName3 = null;
		StringBuilder richtextFinalRes = null;
		StringBuilder ldapMappingFinalRes = null;


		try{
			assetAttributeList = new ArrayList<AssetInstanceVersion>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridAttributeSheeet : " + Constants.LOG_CONNECTION_OPEN);
			}

			if(flag){
				//create
				tempTableName1 = "table"+userName+System.currentTimeMillis();
				queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");

				if(nonStaticParam.length() !=0){

					if(userName.equalsIgnoreCase("roleAnonymous")){
						queryStrBuffer.append("SELECT a.vid,a.created_on, a.instname, a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,isstatic,staticval,"
								+ "paramtypeid,apdfilename,derivedattributecomputation,derivedassetlist,a.versionable,b.assetInstParamId from  ( SELECT aiv.asset_instance_version_id as vid,aiv.created_on,  ai.asset_inst_name as instname,"
								+ "  aiv.version_name as versionname,  aiv.description , ad.versionable as versionable from asset_def ad JOIN asset_instance ai On ad.asset_id=ai.asset_id  JOIN "
								+ "asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id WHERE asset_name='"+assetName+"' AND ad.guest_flag=1 AND ai.public_access=1 ORDER BY "
								+ "ai.asset_inst_name)a  LEFT OUTER JOIN  ( SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname, "
								+ "aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname, pv.value as value,pv.ldap_attribute_id,pv.filename as pvfileName, "
								+ "apd.is_static as isstatic, apd.static_val as staticval, apd.param_type_id as paramtypeid, apd.derived_computed_description "
								+ "as derivedattributecomputation, apd.derived_asset_list as derivedassetlist,apd.filename as apdfilename,aip.asset_inst_param_id as assetInstParamId from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
								+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON "
								+ "aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN "
								+ "asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id  JOIN "
								+ "user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='Guest' AND "
								+ "ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"')GROUP BY vid,apname)b ON a.vid=b.vid GROUP BY b.apname");
					}else{
						if(flagForUser){ // admin users
							queryStrBuffer.append("SELECT a.vid,a.created_on, a.instname,a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,staticVal,"
									+ "staticFilename,isStatic,paramtypeId,derivedattibuteandComputation,derivedassetlist,a.versionable,b.assetInstParamId from( SELECT aiv.asset_instance_version_id as"
									+ " vid,aiv.created_on, ai.asset_inst_name as instname,aiv.version_name as versionname, aiv.description,ad.versionable as versionable from asset_def ad JOIN "
									+ "asset_instance ai On ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id WHERE "
									+ "asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on, "
									+ "ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description, apd.asset_param_name as apname,"
									+ " pv.value as value,pv.ldap_attribute_id, pv.fileName as pvfileName, apd.fileName as staticFilename, apd.static_val as staticVal, "
									+ "apd.is_static as isStatic, apd.param_type_id as paramtypeId, apd.derived_computed_description as derivedattibuteandComputation,apd.derived_asset_list as derivedassetlist,aip.asset_inst_param_id as assetInstParamId from "
									+ "asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON "
									+ "ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN "
									+ "asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN parameter_values pv ON "
									+ "aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"+assetName+"' AND "
									+ "FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"'))b ON a.vid=b.vid");
						}else{
							queryStrBuffer.append("SELECT a.vid,a.created_on, a.instname, a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,isStatic,staticVal,paramtypeId,"
									+ "staticfileName,derivedattributecomputation,derivedassetlist,a.versionable,b.assetInstParamId from (SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname, "
									+ "aiv.version_name as versionname, aiv.description , ad.versionable as versionable from asset_def ad JOIN asset_instance ai On ad.asset_id=ai.asset_id JOIN "
									+ "asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id JOIN asset_instance_version_group_access aivga ON "
									+ "aiv.asset_instance_version_id=aivga.asset_instance_version_id JOIN user_groups ug ON aivga.group_id=ug.group_id  JOIN profile p ON "
									+ "p.user_id=ug.user_id WHERE p.user_name='"+userName+"' AND aivga.view_access=1 AND asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN"
									+ "  (SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description, "
									+ "apd.asset_param_name as apname, pv.value as value,pv.ldap_attribute_id,pv.fileName as pvfilename,apd.fileName as staticfileName,apd.is_static as isstatic,"
									+ "apd.static_val as staticval,apd.param_type_id as paramtypeid,apd.derived_computed_description as derivedattributecomputation,apd.derived_asset_list as derivedassetlist,aip.asset_inst_param_id as assetInstParamId from "
									+ "asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON "
									+ "ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN "
									+ "parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON "
									+ "aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN "
									+ "user_groups ug ON acg.group_id=ug.group_id JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN "
									+ "profile p ON ug.user_id=p.user_id WHERE p.user_name='"+userName+"' AND ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"') GROUP BY "
									+ "vid,apname,value)b ON a.vid=b.vid");
						}
					}
				}if(staticParam.length() != 0){
					String[] strArray = staticParam.toString().split(",");
					
					AssetParamDef apd = null;
					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'");  
						preparedStmt = con.prepareStatement(queryStBuff.toString());
						rs = preparedStmt.executeQuery();
						while(rs.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(rs.getLong("asset_param_id"));
							apd.setAssetParamName(rs.getString("asset_param_name"));
							apd.setIs_static(rs.getInt("is_static"));
							apd.setStaticValue(rs.getString("static_val"));
							apd.setParamTypeId(rs.getLong("param_type_id"));
							apd.setFileName(rs.getString("fileName"));
							apdList.add(apd);
						}
					}
				}
			}else{
				if(staticParam.length() !=0){
					if(nonStaticParam.length() ==0){
						//create
						tempTableName1 = "table"+userName+System.currentTimeMillis();
						queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
						if(userName.equalsIgnoreCase("roleAnonymous")){
							queryStrBuffer.append("SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
									+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
									+ "ad.asset_name='"+assetName+"' and ai.public_access=1 ORDER BY  aiv.asset_instance_version_id");
						}else{
							if(flagForUser){//admin users
								queryStrBuffer.append("SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
										+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
										+ "ad.asset_name='"+assetName+"' ORDER BY  aiv.asset_instance_version_id");
							}else{ // non admin users
								queryStrBuffer.append("SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from group_details gd ,"
										+ "asset_instance_version_group_access aivga,user_groups ug,profile p,asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
										+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE ad.asset_name='"+assetName+"' and p.user_name='"+userName+"' and "
										+ "p.user_id=ug.user_id and aivga.asset_instance_version_id=aiv.asset_instance_version_id and aivga.group_id=gd.group_id and "
										+ "ug.group_id=gd.group_id and aivga.view_access=1 ORDER BY  aiv.asset_instance_version_id");
							}
						}
					}

					String[] strArray = staticParam.toString().split(",");

					AssetParamDef apd = null;
					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'"); 
						preparedStmt = con.prepareStatement(queryStBuff.toString());
						rs = preparedStmt.executeQuery();
						while(rs.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(rs.getLong("asset_param_id"));
							apd.setAssetParamName(rs.getString("asset_param_name"));
							apd.setIs_static(rs.getInt("is_static"));
							apd.setStaticValue(rs.getString("static_val"));
							apd.setParamTypeId(rs.getLong("param_type_id"));
							apd.setFileName(rs.getString("fileName"));
							apdList.add(apd);
						}
					}
				}
			}
			
			if(staticParam.length() == 0){
				
				//create
				tempTableName1 = "table"+userName+System.currentTimeMillis();
				queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
				
				if(nonStaticParam.length() ==0){
					if(userName.equalsIgnoreCase("roleAnonymous")){
						queryStrBuffer.append("SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
								+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
								+ "ad.asset_name='"+assetName+"' and ai.public_access=1 ORDER BY  aiv.asset_instance_version_id");
					}else{
						if(flagForUser){//admin users
							queryStrBuffer.append("SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
									+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
									+ "ad.asset_name='"+assetName+"' ORDER BY  aiv.asset_instance_version_id");
						}else{ // non admin users
							queryStrBuffer.append("SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from group_details gd ,"
									+ "asset_instance_version_group_access aivga,user_groups ug,profile p,asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
									+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE ad.asset_name='"+assetName+"' and p.user_name='"+userName+"' and "
									+ "p.user_id=ug.user_id and aivga.asset_instance_version_id=aiv.asset_instance_version_id and aivga.group_id=gd.group_id and "
									+ "ug.group_id=gd.group_id and aivga.view_access=1 ORDER BY  aiv.asset_instance_version_id");
						}
					}
				}else{
					if(userName.equalsIgnoreCase("roleAnonymous")){
						queryStrBuffer.append("SELECT a.vid,a.created_on, a.instname, a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,isstatic,staticval,"
								+ "paramtypeid,apdfilename,derivedattributecomputation,derivedassetlist,a.versionable,b.assetInstParamId from  ( SELECT aiv.asset_instance_version_id as vid,aiv.created_on,  ai.asset_inst_name as instname,"
								+ "  aiv.version_name as versionname,  aiv.description , ad.versionable as versionable from asset_def ad JOIN asset_instance ai On ad.asset_id=ai.asset_id  JOIN "
								+ "asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id WHERE asset_name='"+assetName+"' AND ad.guest_flag=1 AND ai.public_access=1 ORDER BY "
								+ "ai.asset_inst_name)a  LEFT OUTER JOIN  ( SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname, "
								+ "aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname, pv.value as value,pv.ldap_attribute_id,  pv.filename as pvfileName, "
								+ "apd.is_static as isstatic, apd.static_val as staticval, apd.param_type_id as paramtypeid, apd.derived_computed_description "
								+ "as derivedattributecomputation, apd.derived_asset_list as derivedassetlist,apd.filename as apdfilename,aip.asset_inst_param_id as assetInstParamId  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
								+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON "
								+ "aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN "
								+ "asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id  JOIN "
								+ "user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='Guest' AND "
								+ "ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"')GROUP BY vid,apname)b ON a.vid=b.vid GROUP BY b.apname");
					}else{
						if(flagForUser){ // admin users
							queryStrBuffer.append("SELECT a.vid,a.created_on, a.instname,a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,staticVal,"
									+ "staticFilename,isStatic,paramtypeId,derivedattibuteandComputation,derivedassetlist,a.versionable,b.assetInstParamId from( SELECT aiv.asset_instance_version_id as"
									+ " vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname, aiv.description,ad.versionable as versionable from asset_def ad JOIN "
									+ "asset_instance ai On ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id WHERE "
									+ "asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on, "
									+ "ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description, apd.asset_param_name as apname,"
									+ " pv.value as value,pv.ldap_attribute_id, pv.fileName as pvfileName, apd.fileName as staticFilename, apd.static_val as staticVal, "
									+ "apd.is_static as isStatic, apd.param_type_id as paramtypeId, apd.derived_computed_description as derivedattibuteandComputation,apd.derived_asset_list as derivedassetlist,aip.asset_inst_param_id as assetInstParamId from "
									+ "asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON "
									+ "ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN "
									+ "asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN parameter_values pv ON "
									+ "aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"+assetName+"' AND "
									+ "FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"'))b ON a.vid=b.vid");
						}else{
							queryStrBuffer.append("SELECT a.vid,a.created_on, a.instname, a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,isStatic,staticVal,paramtypeId,"
									+ "staticfileName,derivedattributecomputation,derivedassetlist,a.versionable,b.assetInstParamId from (SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname, "
									+ "aiv.version_name as versionname, aiv.description , ad.versionable as versionable from asset_def ad JOIN asset_instance ai On ad.asset_id=ai.asset_id JOIN "
									+ "asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id JOIN asset_instance_version_group_access aivga ON "
									+ "aiv.asset_instance_version_id=aivga.asset_instance_version_id JOIN user_groups ug ON aivga.group_id=ug.group_id  JOIN profile p ON "
									+ "p.user_id=ug.user_id WHERE p.user_name='"+userName+"' AND aivga.view_access=1 AND asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN"
									+ "  (SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description, "
									+ "apd.asset_param_name as apname, pv.value as value,pv.ldap_attribute_id,pv.fileName as pvfilename,apd.fileName as staticfileName,apd.is_static as isstatic,"
									+ "apd.static_val as staticval,apd.param_type_id as paramtypeid,apd.derived_computed_description as derivedattributecomputation,apd.derived_asset_list as derivedassetlist,aip.asset_inst_param_id as assetInstParamId from "
									+ "asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON "
									+ "ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN "
									+ "parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON "
									+ "aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN "
									+ "user_groups ug ON acg.group_id=ug.group_id JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN "
									+ "profile p ON ug.user_id=p.user_id WHERE p.user_name='"+userName+"' AND ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"') GROUP BY "
									+ "vid,apname,value)b ON a.vid=b.vid");
						}
					}
				}
				
			}
			
						
			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp1data = "CREATE INDEX vid ON "+tempTableName1+" (vid)" ;
			
			preparedStmt1 = con.prepareStatement(temp1data.toString());
			preparedStmt1.executeUpdate();

		
			
			tempTableName2 = "table"+userName+System.currentTimeMillis();
			queryStrBuffer = new StringBuffer("Create table "+tempTableName2+"(avd INT,grouppath TEXT)");

			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp2data = "CREATE INDEX avd ON "+tempTableName2+" (avd)" ;
			
			preparedStmt1 = con.prepareStatement(temp2data.toString());
			preparedStmt1.executeUpdate();
			
			String storedProcedure = "{call getAssetAttributes(?,?,?,?,?)}";
			CallableStatement callableStatement = con.prepareCall(storedProcedure);
			callableStatement.setString(1, assetName);
			callableStatement.setString(2, userName);
			callableStatement.setBoolean(3, authorityFlag);
			callableStatement.setString(4, tempTableName2);
			callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);
			callableStatement.execute();

			tempTableName3 = "table"+userName+System.currentTimeMillis();
			queryStrBuffer = new StringBuffer("Create table "+tempTableName3+" as ");

			queryStrBuffer.append("select aiv.asset_instance_version_id as vid,aiv.created_on,"
					+ "ai.asset_inst_name as instname,group_concat(tg.tag_name) as tagname from asset_def ad JOIN "
					+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
					+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id LEFT OUTER JOIN "
					+ "tagging_master tg ON aiv.asset_instance_version_id=tg.asset_instance_version_id WHERE "
					+ "ad.asset_name='"+assetName+"' GROUP BY vid;");
			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();
			
			String temp3data = "CREATE INDEX vid ON "+tempTableName3+" (vid)" ;
			
			preparedStmt1 = con.prepareStatement(temp3data.toString());
			preparedStmt1.executeUpdate();
			
			
			if(flag){
				queryStrBuffer = new StringBuffer("select p.vid,p.created_on,p.instname,p.description,p.apname,p.versionname,p.pvfileName,p.staticVal,p.isStatic,p.paramtypeId,p.staticFilename,"
						+ "p.value,p.assetInstParamId,t.grouppath as taxname,tg.tagname as tagname,p.versionable,p.ldap_attribute_id from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.vid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.vid=tg.vid ; ");
			}else{
				queryStrBuffer = new StringBuffer("select p.vid,p.created_on,p.instname,p.description,p.versionname,"
						+ "t.grouppath as taxname,tg.tagname as tagname,p.versionable from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.vid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.vid=tg.vid ; ");
			}

			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			rs = preparedStmt.executeQuery();
			long latestAssetInstVerId = 0L;
			AssetInstanceVersion attributeExportVo = null;
			long latestAssetInstparamId = 0L;
			long latestAssetInstLdapparamId = 0L;
			while(rs.next()){
				attributeExportVo = new AssetInstanceVersion();
				attributeExportVo.setAssetInstVersionId(rs.getLong("vid"));
				attributeExportVo.setAssetInstName(rs.getString("instname"));
				attributeExportVo.setDescription(rs.getString("description"));
				attributeExportVo.setCreatedOn(rs.getTimestamp("created_on"));
				//					
				attributeExportVo.setTaxonomyName(rs.getString("taxname"));
				attributeExportVo.setTagName(rs.getString("tagname"));
				attributeExportVo.setVersionName(rs.getString("versionname"));
				attributeExportVo.setVersionable(rs.getBoolean("versionable"));
				paramValues = new LinkedHashMap<String, String>();
				assetInstanceVersionId = rs.getString("vid");
				if(flag){
					attributeExportVo.setAssetParamName(rs.getString("apname"));
					if(rs.getInt("isStatic") == 1){
						if(rs.getInt("paramtypeId") == 3)
						{
							paramValues.put(rs.getString("apname"), rs.getString("staticFilename"));
						}else{
							
							paramValues.put(rs.getString("apname"), rs.getString("staticVal"));
						}
					}else{
						if(rs.getInt("paramtypeId") == 3)
						{
							paramValues.put(rs.getString("apname"), rs.getString("pvfileName"));
						}
						else if(rs.getInt("paramtypeId") == 5){
							
							String derivedAttrVals = assetInstVerDao.getDerivedAttributeValues(userName, assetInstanceVersionId, assetName, rs.getString("apname"), con);
							paramValues.put(rs.getString("apname"), derivedAttrVals);
						}else if(rs.getInt("paramtypeId") == 6){
							String derivedCompVal = assetInstVerDao.getDerivedComputationValues(userName, assetInstanceVersionId, assetName, rs.getString("apname"), con);
							paramValues.put(rs.getString("apname"), derivedCompVal);
						} else if(rs.getInt("paramtypeId") == 8) {
							String derivedAssetListValue = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, assetInstanceVersionId, assetName, rs.getString("apname"), con);
							paramValues.put(rs.getString("apname"),derivedAssetListValue);
						}
						else if(rs.getInt("paramtypeId") == 7 || rs.getInt("paramtypeId") == 1){
							if(latestAssetInstparamId != 0){
								if(latestAssetInstparamId == rs.getLong("assetInstParamId")){
									richtextFinalRes.append(rs.getString("value") + "~~") ;
								}else{
									richtextFinalRes = new StringBuilder(rs.getString("value") + "~~");
								}
							}else{
								richtextFinalRes = new StringBuilder(rs.getString("value") + "~~");
							}
							paramValues.put(rs.getString("apname"), richtextFinalRes.toString());
							latestAssetInstparamId = rs.getLong("assetInstParamId");
						}else if(rs.getInt("paramtypeId") == 9){
							if(latestAssetInstLdapparamId != 0){
								if(latestAssetInstLdapparamId == rs.getLong("assetInstParamId")){
									ldapMappingFinalRes.append(rs.getString("value")+"~~~~"+rs.getString("ldap_attribute_id") + "``") ;
								}else{
									ldapMappingFinalRes = new StringBuilder(rs.getString("value") +"~~~~"+rs.getString("ldap_attribute_id") + "``");
								}
							}else{
								ldapMappingFinalRes = new StringBuilder(rs.getString("value") +"~~~~"+rs.getString("ldap_attribute_id") + "``");
							}
							paramValues.put(rs.getString("apname"), ldapMappingFinalRes.toString());
							latestAssetInstLdapparamId = rs.getLong("assetInstParamId");
						}else{
							if(rs.getString("apname") != null){
							
								paramValues.put(rs.getString("apname"), rs.getString("value"));
							}
						}
					}
					if(latestAssetInstVerId != rs.getLong("vid")){
						for(AssetParamDef apd : apdList){
							if(apd.getIs_static() == 1){
								if(apd.getParamTypeId() == 3){

									paramValues.put(apd.getAssetParamName(), apd.getFileName());
								}else{
									paramValues.put(apd.getAssetParamName(), apd.getStaticValue());
								}
							}
						}
					}
				}else{
					for(AssetParamDef apd : apdList){
						if(apd.getParamTypeId() == 3){
							paramValues.put(apd.getAssetParamName(), apd.getFileName());
						}else{
							paramValues.put(apd.getAssetParamName(), apd.getStaticValue());
						}
					}
				}

				attributeExportVo.setParamNamewithvalue(new TreeMap<String,String>(paramValues));
				assetAttributeList.add(attributeExportVo);

				latestAssetInstVerId = rs.getLong("vid");
				
			}
			
			
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridAttributeSheeet : "+queryStrBuffer.toString());
			}

			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridAttributeSheeet : "+"Drop table table1;");
			}

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeDbConnection(conn1);
			try{
				
				if(null != tempTableName1){
					preparedStmt = con.prepareStatement("Drop table IF EXISTS "+tempTableName1);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName2){
					
					preparedStmt = con.prepareStatement("Drop table IF EXISTS "+tempTableName2);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName3){
					preparedStmt = con.prepareStatement("Drop table IF EXISTS "+tempTableName3);
					preparedStmt.executeUpdate();
				}

				DBConnection.closeResultSet(rs);
				DBConnection.closePreparedStatement(preparedStmt);
				DBConnection.closePreparedStatement(preparedStmt1);
				if (log.isTraceEnabled()) {
					log.trace("getFinalResultForBrowseGridAttributeSheeet : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}catch(SQLException e){
				if (log.isErrorEnabled()) {
					log.error("getFinalResultForBrowseGridAttributeSheeet : " + e.getMessage());
				}
				e.printStackTrace();
			}
		}	
		log.trace("getFinalResultForBrowseGridAttributeSheeet : End");
		return assetAttributeList;
	}


	public List<AssetInstRelationship> getFinalResultForBrowseGridRelationshipSheeet(Connection con,String assetName,String userName, boolean accessFlag){

		log.trace("getFinalResultForBrowseGridRelationshipSheeet : begin");
		ArrayList<AssetInstRelationship> al = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		try{
			al = new ArrayList<AssetInstRelationship>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridRelationshipSheeet : " + Constants.LOG_CONNECTION_OPEN);
			}

			if(accessFlag){
				preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS));
				preparedStmt.setString(Constants.ONE, assetName);
			}else{
				preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_BROWSE_GRID_NON_ADMIN));
				preparedStmt.setString(Constants.ONE, assetName);
				preparedStmt.setString(Constants.TWO, userName);
			}
			rs = preparedStmt.executeQuery();
			AssetInstRelationship assetInsRel = null;
			while(rs.next()){
				assetInsRel = new AssetInstRelationship();
				assetInsRel.setSrcAssetName(rs.getString("src_asset"));
				assetInsRel.setSrcAssetId(rs.getLong("src_id"));
				assetInsRel.setSourceInstanceName(rs.getString("src_instname"));
				assetInsRel.setSourceVersionName(rs.getString("src_versioname"));
				assetInsRel.setSourceDescription(rs.getString("src_description"));
				assetInsRel.setType(rs.getString("type"));
				assetInsRel.setRelationShipName(rs.getString("relatiname"));
				assetInsRel.setDestAssetName(rs.getString("destassetname"));
				assetInsRel.setDestAssetId(rs.getLong("dest_id"));
				assetInsRel.setDestInstanceName(rs.getString("destinstname"));
				assetInsRel.setDestInstanceVersionName(rs.getString("destversioname"));
				assetInsRel.setDestdescription(rs.getString("destdescription"));
				al.add(assetInsRel);
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridRelationshipSheeet : "+PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridRelationshipSheeet : " + Constants.LOG_CONNECTION_CLOSE);
			}
		}	
		return al;
	}


	/**
	 * @method getRecentActivityExportDetails
	 * @description to get recent activity details
	 * @param userName
	 * @param conn
	 * @return List<RecentActivity>
	 * @throws RepoproException
	 */
	public List<RecentActivity> getRecentActivityExportDetails(String userName,
			Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getRecentActivityExportDetails||userName:" + userName +" ||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
		RecentActivity recentActivity = null;
		AssetInstanceVersionDao assetInstanceVersionDao =  new AssetInstanceVersionDao();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getRecentActivityExportDetails ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			if(userName.equalsIgnoreCase("roleAnonymous")){
				if (log.isTraceEnabled()) {
					log.trace("getRecentActivityDetails ||"+ PropertyFileReader.getInstance().getValue(
							Constants.RET_RECENTACTIVITY_DETAILS_FOR_GUEST_EXPORT));
				}
				preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.RET_RECENTACTIVITY_DETAILS_FOR_GUEST_EXPORT));

				rs = preparedStmt.executeQuery();
			}
			else{
				boolean flagForUser = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn1);
				if(flagForUser){
					if (log.isTraceEnabled()) {
						log.trace("getRecentActivityExportDetails ||"+ PropertyFileReader.getInstance().getValue(
								Constants.RET_RECENTACTIVITY_DETAILS_FOR_ADMIN_EXPORT));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.RET_RECENTACTIVITY_DETAILS_FOR_ADMIN_EXPORT));
					
					preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
					rs = preparedStmt.executeQuery();
				}
				else{
					if (log.isTraceEnabled()) {
						log.trace("getRecentActivityExportDetails ||"+ PropertyFileReader.getInstance().getValue(
								Constants.RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN_EXPORT));
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN_EXPORT));
					
					preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
					preparedStmt.setString(Constants.TWO,userName);
					rs = preparedStmt.executeQuery();
				}
			}



			while (rs.next()) {
				recentActivity = new RecentActivity();
				recentActivity.setActivityId(rs.getLong("activity_id"));
				recentActivity.setActivityTimestamp(rs.getTimestamp("activity_timestamp"));
				recentActivity.setDescription(rs.getString("masked_description"));
				recentActivity.setAssetId(rs.getString("asset_id"));
				recentActivity.setAssetInstVersionId(rs.getString("asset_inst_version_id"));
				recentActivity.setUser_id(rs.getLong("user_id"));
				
				recentActivityList.add(recentActivity);
				if (log.isTraceEnabled()) {
					log.trace("getRecentActivityExportDetails ||"+ recentActivity.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getRecentActivityExportDetails ||"+ recentActivityList.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getRecentActivityExportDetails ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.RECENT_ACTIVITY_DETAILS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getRecentActivityExportDetails ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getRecentActivityExportDetails ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getRecentActivityExportDetails ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getRecentActivityExportDetails ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("getRecentActivityExportDetails||userName:" + userName +"|| End");
		}

		return recentActivityList;
	}


	/**
	 * @method : getBasicInformationByAssetName
	 * @description : to get Basic Information 
	 * @param assetName
	 * @return AssetInstanceVersionList
	 * @throws RepoproException
	 */

	public List<AssetInstanceVersion> getAassetInstanceDetailsWithOutParametersExcelExport(
			String assetName,String userName, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAassetInstanceDetailsWithOutParametersExcelExport || Begin with assetName:"
					+ assetName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetInstanceVersion versions = null;
		List<AssetInstanceVersion> AssetInstanceVersionList = new ArrayList<AssetInstanceVersion>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAassetInstanceDetailsWithOutParametersExcelExport ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if(userName.equalsIgnoreCase("admin")){
				preparedStmt = conn
						.prepareStatement(PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN_EXPORT));
				preparedStmt.setString(Constants.ONE, assetName);
				rs = preparedStmt.executeQuery();
				if (log.isTraceEnabled()) {
					log.trace("getAassetInstanceDetailsWithOutParametersExcelExport ||"
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN_EXPORT));
				}
				while (rs.next()) {
					versions = new AssetInstanceVersion();
					versions.setAssetInstVersionId(rs.getLong("asset_instance_version_id"));
					versions.setAssetInstName(rs.getString("asset_inst_name"));
					versions.setDescription(rs.getString("description"));
					versions.setVersionName(rs.getString("version_name"));
					AssetInstanceVersionList.add(versions);
					if (log.isTraceEnabled()) {
						log.trace("getAassetInstanceDetailsWithOutParametersExcelExport ||"
								+ versions.toString()
								+ "data is retrieved successfully");
					}
				}if (log.isDebugEnabled()) {
					log.debug("getAassetInstanceDetailsWithOutParametersExcelExport || "
							+ AssetInstanceVersionList.toString());
				}

			}else if(userName.equalsIgnoreCase("roleAnonymous")){
				preparedStmt = conn
						.prepareStatement(PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST_EXPORT));
				preparedStmt.setString(Constants.ONE, assetName);
				rs = preparedStmt.executeQuery();
				if (log.isTraceEnabled()) {
					log.trace("getAassetInstanceDetailsWithOutParametersExcelExport ||"
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST_EXPORT));
				}
				while (rs.next()) {
					versions = new AssetInstanceVersion();
					versions.setAssetInstVersionId(rs.getLong("asset_instance_version_id"));
					versions.setAssetInstName(rs.getString("asset_inst_name"));
					versions.setDescription(rs.getString("description"));
					versions.setVersionName(rs.getString("version_name"));
					AssetInstanceVersionList.add(versions);
					if (log.isTraceEnabled()) {
						log.trace("getAassetInstanceDetailsWithOutParametersExcelExport ||"
								+ versions.toString()
								+ "data is retrieved successfully");
					}
				}if (log.isDebugEnabled()) {
					log.debug("getAassetInstanceDetailsWithOutParametersExcelExport || "
							+ AssetInstanceVersionList.toString());
				}

			}else{
				boolean flagForUser = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn1);
				if(flagForUser){//admin users
					preparedStmt = conn
							.prepareStatement(PropertyFileReader
									.getInstance()
									.getValue(
											Constants.GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN_EXPORT));
					preparedStmt.setString(Constants.ONE, assetName);
					rs = preparedStmt.executeQuery();
					if (log.isTraceEnabled()) {
						log.trace("getAassetInstanceDetailsWithOutParametersExcelExport ||"
								+ PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN_EXPORT));
					}
					while (rs.next()) {
						versions = new AssetInstanceVersion();
						versions.setAssetInstVersionId(rs.getLong("asset_instance_version_id"));
						versions.setAssetInstName(rs.getString("asset_inst_name"));
						versions.setDescription(rs.getString("description"));
						versions.setVersionName(rs.getString("version_name"));
						AssetInstanceVersionList.add(versions);
						if (log.isTraceEnabled()) {
							log.trace("getAassetInstanceDetailsWithOutParametersExcelExport ||"
									+ versions.toString()
									+ "data is retrieved successfully");
						}
					}if (log.isDebugEnabled()) {
						log.debug("getAassetInstanceDetailsWithOutParametersExcelExport || "
								+ AssetInstanceVersionList.toString());
					}

				}else{//non admins
					preparedStmt = conn
							.prepareStatement(PropertyFileReader
									.getInstance()
									.getValue(
											Constants.GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN_EXPORT));
					preparedStmt.setString(Constants.ONE, assetName);
					preparedStmt.setString(Constants.TWO, userName);

					rs = preparedStmt.executeQuery();
					if (log.isTraceEnabled()) {
						log.trace("getAassetInstanceDetailsWithOutParametersExcelExport ||"
								+ PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN));
					}
					while (rs.next()) {
						versions = new AssetInstanceVersion();
						versions.setAssetInstVersionId(rs.getLong("asset_instance_version_id"));
						versions.setAssetInstName(rs.getString("asset_inst_name"));
						versions.setDescription(rs.getString("description"));
						versions.setVersionName(rs.getString("version_name"));
						AssetInstanceVersionList.add(versions);
						if (log.isTraceEnabled()) {
							log.trace("getAassetInstanceDetailsWithOutParametersExcelExport ||"
									+ versions.toString()
									+ "data is retrieved successfully");
						}
					}if (log.isDebugEnabled()) {
						log.debug("getAassetInstanceDetailsWithOutParametersExcelExport || "
								+ AssetInstanceVersionList.toString());
					}
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAassetInstanceDetailsWithOutParametersExcelExport ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.ASSET_INSTANCE_VERSIONS_BASIC_INFORMATION_NOT_FETCHED));
		} catch (IOException e) {
			log.error("getAassetInstanceDetailsWithOutParametersExcelExport ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAassetInstanceDetailsWithOutParametersExcelExport ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAassetInstanceDetailsWithOutParametersExcelExport ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAassetInstanceDetailsWithOutParametersExcelExport || End ");
		}
		return AssetInstanceVersionList;
	}
	
	public List<AssetInstRelationship> getFinalResultForCreateFilterRelationshipSheeet(Connection con,String assetName,List<AssetInstance> assetInstanceList,String userName){

		log.trace("getFinalResultForBrowseGridRelationshipSheeet : begin");
		ArrayList<AssetInstRelationship> al = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetInstanceVersionDao aivDao = new AssetInstanceVersionDao();
		try{
			boolean flagForAdminRights = aivDao.findAdminRightsByUserName(userName, con);
			AssetInstRelationship assetInsRel = null;
			al = new ArrayList<AssetInstRelationship>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridRelationshipSheeet : " + Constants.LOG_CONNECTION_OPEN);
			}
			
			for(AssetInstance ai : assetInstanceList){
				if(flagForAdminRights){
					preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER));
					preparedStmt.setString(Constants.ONE, assetName);
					preparedStmt.setLong(Constants.TWO, ai.getAssetInstVersionId());
				}else{
					preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER_NON_ADMIN));
					preparedStmt.setString(Constants.ONE, assetName);
					preparedStmt.setString(Constants.TWO, userName);
					preparedStmt.setLong(Constants.THREE, ai.getAssetInstVersionId());
				}
				rs = preparedStmt.executeQuery();
				while(rs.next()){
					assetInsRel = new AssetInstRelationship();
					assetInsRel.setSrcAssetName(rs.getString("src_asset"));
					assetInsRel.setSrcAssetId(rs.getLong("src_id"));
					assetInsRel.setSourceInstanceName(rs.getString("src_instname"));
					assetInsRel.setSourceVersionName(rs.getString("src_versioname"));
					assetInsRel.setSourceDescription(rs.getString("src_description"));
					assetInsRel.setType(rs.getString("type"));
					assetInsRel.setRelationShipName(rs.getString("relatiname"));
					assetInsRel.setDestAssetName(rs.getString("destassetname"));
					assetInsRel.setDestAssetId(rs.getLong("dest_id"));
					assetInsRel.setDestInstanceName(rs.getString("destinstname"));
					assetInsRel.setDestInstanceVersionName(rs.getString("destversioname"));
					assetInsRel.setDestdescription(rs.getString("destdescription"));
					al.add(assetInsRel);
				}
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridRelationshipSheeet : "+PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridRelationshipSheeet : " + Constants.LOG_CONNECTION_CLOSE);
			}
		}	
		return al;
	}
	
	
	/**
	 * @method getAssetInstanceForFilterWithNonStaticParametersDao
	 * @description get asset instance details for filter applied
	 * @param userName
	 * @param assetName
	 * @param assetParamName
	 * @param param1Values
	 * @param param2Values
	 * @param operators
	 * @param logicalSelect
	 * @param taxonomyNames
	 * @param showHideAssetParamName
	 * @param from
	 * @param conn
	 * @return AssetInstanceVersion
	 * @throws RepoproException
	 */
	@SuppressWarnings("resource")
	public List<AssetInstanceVersion> getFinalResultForCreateFilterAttributeSheet(
			String userName, Long assetId , String assetName, String assetParamNames,
			String param1Values, String param2Values, String operators,
			String logicalSelect, String taxonomyNames,
			String showHideAssetParamName,
			boolean flag,
			boolean flagForUser,
			StringBuffer staticParam,
			StringBuffer nonStaticParam,
			Connection conn)
					throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceForFilterWithNonStaticParametersDao ||begin  with userName : "
					+ userName+" assetName :"+assetName+" operators:"+operators+" assetParamNames:"+assetParamNames+
					" param1Values:"+param1Values+" param2Values:"+param2Values+" logicalSelect:"+logicalSelect+
					" taxonomyNames:"+taxonomyNames);
		}

		Connection conn1 = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStmt = null;
		ResultSet rsltSet = null;
		PreparedStatement preparedSt = null;
		AssetInstanceVersion assetInstanceVersionsDetails = null;
		List<AssetInstanceVersion> assetInstanceVersionsListForGrid = new ArrayList<AssetInstanceVersion>();
		AdminAccessName adminAccessName = null;
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		boolean adminflag = false;
		int andCount=1;
		List<AssetParamDef> apdList = new ArrayList<AssetParamDef>();
		
		StringBuffer queryStrBuffer = new StringBuffer("");
		
		String tempTableName1 = null;
		String tempTableName2 = null;
		String tempTableName3 = null;

		PreparedStatement preparedStmt1 = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			String[] assetParamNameList = null;
			if (!assetParamNames.equalsIgnoreCase("")) {
				assetParamNameList = assetParamNames.split("~~");
			}
			String[] param1ValuesList = null;
			if (!param1Values.equalsIgnoreCase("")) {
				param1ValuesList = param1Values.split("~~");
			}
			String[] param2ValuesList = null;
			if (!param2Values.equalsIgnoreCase("")) {
				param2ValuesList = param2Values.split("~~");
			}
			String[] operatorsList = null;
			if (!operators.equalsIgnoreCase("")) {
				operatorsList = operators.split("~~");
			}
			String[] logicalSelectList = null;
			if (!logicalSelect.equalsIgnoreCase("")) {
				logicalSelectList = logicalSelect.split("~~");
			}
			String[] taxonomyNamesList = null;
			if (!taxonomyNames.equalsIgnoreCase("")) {
				taxonomyNamesList = taxonomyNames.split("~~");
			}
			
			
			if(flag){
				//create
				tempTableName1 = "table"+userName+System.currentTimeMillis();
				queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
				
				if(nonStaticParam.length() !=0){
					if (userName.equalsIgnoreCase("roleAnonymous")) {

						if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

							queryStrBuffer.append("select * from (select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,ad.versionable,ad.icon_image_name,apd.is_static,apd.static_val from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and ai3.public_access=1 and aiv3.asset_instance_version_id in (select * from  (");

							if(assetParamNameList.length > 1)
								queryStrBuffer.append("select distinct * from (");

							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i>0){
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equals("And"))
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

								String[] params=assetParamNameList[i].split("_");

								queryStrBuffer.append("((a.asset_param_id="+ params[0]);
								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										//procedure.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//										queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
											
											/*else {
											queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										}*/
										//else
											//queryStrBuffer.append();									
									}
								}else {
									if (operatorsList[i].equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else 
											queryStrBuffer.append(" and '" + param2ValuesList[i]+ "'");
									}
								}
								queryStrBuffer.append(" ))");

							}
							if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
							queryStrBuffer.append(" union all ");
							queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and ai2.public_access=1 and asset_name=\"").append(assetName).append("\" and (");

							if (taxonomyNamesList.length > 0) {
								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id =  " + s + " or ";
								}
								queryStrBuffer.append(taxStr.substring(0,taxStr.length() - 4) + ")");

							}
							queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");

							/*queryStrBuffer
							.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr, apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
									+ Constants.GUEST
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid order by avid");*/
							
							// updated by Pinak 26-09-18
							
							queryStrBuffer
							.append(" order by asset_inst_name) AS a LEFT OUTER JOIN (SELECT  pv.parameter_values_id,aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN  group_details gd on gd.group_name='"
									+ Constants.GUEST
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "'))b ON a.avid=b.vid order by asset_inst_name,cast(version_name as decimal(16,8))");

						} else if (!taxonomyNames.equalsIgnoreCase("")) {

							queryStrBuffer.append("select * from (select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and ai3.public_access=1 and aiv3.asset_instance_version_id in (select * from (");
							queryStrBuffer.append("select distinct 	aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and ai2.public_access=1 and asset_name=\"").append(assetName).append("\" and  ( ");

							String taxStr = "";
							for (String s : taxonomyNamesList) {
								taxStr += "aivt.aiv_taxonomy_id = " + s + " or ";
							}
							queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4)+ ")");

							queryStrBuffer.append(") as tbl2)");

							/*queryStrBuffer
							.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr, apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
									+ Constants.GUEST
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid order by avid");*/
							
							// updated by Pinak 26-09-18
							
							queryStrBuffer
							.append(" order by asset_inst_name) AS a LEFT OUTER JOIN (SELECT pv.parameter_values_id,aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.ldap_attribute_id, pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id  JOIN group_details gd on gd.group_name='"
									+ Constants.GUEST
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "'))b ON a.avid=b.vid order by asset_inst_name,cast(version_name as decimal(16,8))");

						} else {
							andCount=1;

							queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id and ai.public_access=1 and aiv.asset_instance_version_id in ( select * from (");


							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i>0){
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equals("And"))
										andCount++;
								}

								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
								String[] params=assetParamNameList[i].split("_");
								queryStrBuffer.append("((a.asset_param_id="+ params[0]);
								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//										queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
											
											/*else {
											queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										}*/
										//else
											//queryStrBuffer.append();									
									}
								}else {
									if (operatorsList[i].equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else
											queryStrBuffer.append(" and '" + param2ValuesList[i]+ "'");
									}
								}
								queryStrBuffer.append(" ))");

							}
							queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
							queryStrBuffer.append(")"); 
							queryStrBuffer
							.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr, apd.asset_param_name as apname,pv.value as pvalue, pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
									+ Constants.GUEST
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid order by avid");
						}
					}else {
						preparedSt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ADMIN_RIGHT));
						if (log.isTraceEnabled()) {
							log.trace("getQuickStats || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.GET_ADMIN_RIGHT));
						}
						preparedSt.setString(Constants.ONE, userName);
						rsltSet = preparedSt.executeQuery();

						while (rsltSet.next()) {
							adminAccessName = new AdminAccessName();
							adminAccessName.setUserName(rsltSet.getString("user_name"));
							adminAccessName.setGroupName(rsltSet.getString("group_name"));
							adminAccessName.setRoleName(rsltSet.getString("role_name"));
							adminAccessNameList.add(adminAccessName);
							if (log.isTraceEnabled()) {
								log.trace("getQuickStats || returning resultset for admin check : "
										+ adminAccessName.toString());
							}
						}

						for (AdminAccessName adminAccess : adminAccessNameList) {
							if (adminAccess.getUserName().equalsIgnoreCase("admin")
									|| adminAccess.getGroupName().equalsIgnoreCase(
											"group-admin")
											|| adminAccess.getRoleName().equalsIgnoreCase(
													"role-admin")) {
								adminflag = true;
							}
						}

						if (adminflag) {


							if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

								queryStrBuffer.append("SELECT * FROM (SELECT aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id" 
										+" AND aiv.asset_instance_version_id IN ( SELECT * FROM (");
								if(assetParamNameList.length > 1)
									queryStrBuffer.append("select distinct * from (");

								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i > 0) {
										queryStrBuffer.append(" union all ");
										if (logicalSelectList[i - 1].equalsIgnoreCase("And"))
											andCount++;
									}

									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

									String[] params=assetParamNameList[i].split("_");

									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}else{
											if(operatorsList[i].equals("=")){
													//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
											} else {
												//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
											}
												
												/*else {
												queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											}*/
											//else
												//queryStrBuffer.append();									
										}
									}else {
										if (operatorsList[i].equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else 
												queryStrBuffer.append(" and '"+ param2ValuesList[i] + "'");
										}
									}
									queryStrBuffer.append(" ))");

								}
								if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
								if(andCount>1)
									queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 

								queryStrBuffer.append(" union all ");
								queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

								if (taxonomyNamesList.length > 0) {
									String taxStr = "";
									for (String s : taxonomyNamesList) {
										taxStr += "aivt.aiv_taxonomy_id =" + s + " or ";
									}
									queryStrBuffer.append(taxStr.substring(0,taxStr.length() - 4)+ ")");
								}
								queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");

								queryStrBuffer
								.append(" )As a LEFT OUTER JOIN  (SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "'))b ON a.avid=b.vid order by avid");

							} else if (!taxonomyNames.equalsIgnoreCase("")) {

								queryStrBuffer.append("select * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and aiv3.asset_instance_version_id in (select * from (");
								queryStrBuffer.append("select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and  ( ");

								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id =" + s + " or ";
								}

								queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4));
								queryStrBuffer.append(")");
								queryStrBuffer.append(") as tbl2)");
								queryStrBuffer
								.append(" )As a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr,apd.asset_param_name as apname, pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "'))b ON a.avid=b.vid order by avid");

							} else {
								andCount=1;

								queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id and aiv.asset_instance_version_id in ( select * from (");
								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i>0){
										queryStrBuffer.append(" union all ");
										if (logicalSelectList[i - 1].equalsIgnoreCase("And"))								
											andCount++;
									}
									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

									String[] params=assetParamNameList[i].split("_");

									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}else{
											if(operatorsList[i].equals("=")){
													//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
												//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
											} else {
												//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
											}
												
												/*else {
												queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											}*/
											//else
												//queryStrBuffer.append();									
										}
									}else {
										if (operatorsList[i].equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else
												queryStrBuffer.append(" and '"+ param2ValuesList[i] + "'");
										}
									}
									queryStrBuffer.append(" ))");

								}
								queryStrBuffer.append(") as tbl ");
								if(andCount>1)
									queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
								queryStrBuffer.append(")"); 

								queryStrBuffer
								.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "'))b ON a.avid=b.vid order by avid");
							}


						} else {

							if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

								/*queryStrBuffer.append(
										"select * from(select aiv3.asset_instance_version_id avid,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,aivga3.edit_access,aivga3.delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1  and aiv3.asset_instance_version_id in (select * from  ( ");
								if(assetParamNameList.length > 1)
									queryStrBuffer.append("select distinct * from (");
								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i > 0) {
										queryStrBuffer.append(" union all ");
										if(logicalSelectList[i-1].equals("And"))
											andCount++;
									}
									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
									String[] params = assetParamNameList[i].split("_");
									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}else{
											if(operatorsList[i].equals("=")){
													//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
											} else {
												//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
											}
												
												else {
												queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											}
											//else
												//queryStrBuffer.append();									
										}
									}else {
										if (operatorsList[i]
												.equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer
											.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else 
												queryStrBuffer.append(" and '"+ param2ValuesList[i] + "'");
										}
									}
									queryStrBuffer.append(" ))");

								}
								if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
								if(andCount>1)
									queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
								queryStrBuffer.append(" union all ");
								queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

								if (taxonomyNamesList.length > 0) {
									String taxStr = "";
									for (String s : taxonomyNamesList) {
										taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
									}
									queryStrBuffer.append(taxStr.substring(0,
											taxStr.length() - 4)+")");

								}
								queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");
								queryStrBuffer.append(" group by aiv3.asset_instance_version_id");
								queryStrBuffer
								.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr,apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id  WHERE p.user_name='"
										+ userName
										+ "' AND ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid order by a.avid,b.pvalue");*/
								
								queryStrBuffer.append(
										"select distinct * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,max(aivga3.edit_access) as edit_access,max(aivga3.delete_access) as delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where ");
								queryStrBuffer.append("aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1  and aiv3.asset_instance_version_id in (select * from  ( ");
								
								if(assetParamNameList.length > 1)
									queryStrBuffer.append("select distinct * from (");
								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i > 0) {
										queryStrBuffer.append(" union all ");
										if(logicalSelectList[i-1].equalsIgnoreCase("And"))
											andCount++;
									}
									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
									String[] params = assetParamNameList[i].split("_");
									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											//procedure.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}else{
											if(operatorsList[i].equals("=")){
												//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
												
											}  else {
												//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) =0");
												
											} 
																			
										}

									}else {
										if (operatorsList[i]
												.equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer
											.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else 
												queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
										}
									}
									queryStrBuffer.append(" ))");

								}
								if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
								if(andCount>1)
									queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
								queryStrBuffer.append(" union all ");
								queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

								if (taxonomyNamesList.length > 0) {
									String taxStr = "";
									for (String s : taxonomyNamesList) {
										taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
									}
									queryStrBuffer.append(taxStr.substring(0,
											taxStr.length() - 4)+")");

								}
								queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");
								queryStrBuffer.append(" group by aiv3.asset_instance_version_id,ai3.asset_inst_name,ai3.asset_inst_id");
								
								queryStrBuffer
									.append(" order by asset_inst_name)AS a LEFT OUTER JOIN (SELECT pv.parameter_values_id,aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id  WHERE p.user_name='"
											+ userName
											+ "' AND ad.asset_name='"
											+ assetName
											+ "' AND FIND_IN_SET (apd.asset_param_name,'"
											+ showHideAssetParamName
											+ "'))b ON a.avid=b.vid order by asset_inst_name,cast(version_name as decimal(16,8))");

							} else if (!taxonomyNames.equalsIgnoreCase("")) {

								queryStrBuffer.append("select distinct * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,max(aivga3.edit_access) as edit_access,max(aivga3.delete_access) as delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where ");
									
								queryStrBuffer.append("aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1 and aiv3.asset_instance_version_id in (select * from (");
								
								queryStrBuffer.append("select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and  ( ");

								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
								}
								queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4));
								queryStrBuffer.append(")");

								queryStrBuffer.append(" ) as tbl2) group by aiv3.asset_instance_version_id,ai3.asset_inst_name,ai3.asset_inst_id ");
								queryStrBuffer
									.append(" order by asset_inst_name)AS a LEFT OUTER JOIN (SELECT pv.parameter_values_id,aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
											+ userName
											+ "' AND ad.asset_name='"
											+ assetName
											+ "' AND FIND_IN_SET (apd.asset_param_name,'"
											+ showHideAssetParamName
											+ "'))b ON a.avid=b.vid order by asset_inst_name,cast(version_name as decimal(16,8))");
							} else {
								/*andCount=1;

								queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access,aivga.edit_access,aivga.delete_access,ad.versionable,ad.icon_image_name  from asset_instance_versions  aiv,asset_instance ai,asset_def ad,asset_instance_version_group_access aivga,user_groups ug,profile p where aiv.asset_instance_id=ai.asset_inst_id and ai.asset_id=ad.asset_id and ad.asset_id=ai.asset_id and p.user_id=ug.user_id and aiv.asset_instance_version_id=aivga.asset_instance_version_id and aivga.group_id=ug.group_id and p.user_name='"+userName+"'  and aivga.view_access=1 and aiv.asset_instance_version_id in ( select * from (");

								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i > 0) {
										queryStrBuffer.append(" union all ");
										if(logicalSelectList[i-1].equals("And"))
											andCount++;
									}
									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
									String[] params = assetParamNameList[i].split("_");
									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}else{
											if(operatorsList[i].equals("=")){
													//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
											} else {
												//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
											}
												
												else {
												queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											}
											//else
												//queryStrBuffer.append();									
										}
									}else {
										if (operatorsList[i]
												.equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer
											.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else
												queryStrBuffer.append(" and '"+ param2ValuesList[i] + "'");
										}
									}
									queryStrBuffer.append(" ))");

								}
								queryStrBuffer.append(") as tbl ");
								if(andCount>1)
								{
									queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
								}
								queryStrBuffer.append(") group by aiv.asset_instance_version_id");

								queryStrBuffer
								.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr,apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
										+ userName
										+ "' AND ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid order by a.avid,b.pvalue");*/
								
								
								andCount=1;

								queryStrBuffer.append("select distinct * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access,max(aivga.edit_access) as edit_access,max(aivga.delete_access) as delete_access,ad.versionable,ad.icon_image_name  from asset_instance_versions  aiv,asset_instance ai,asset_def ad,asset_instance_version_group_access aivga,user_groups ug,profile p where ");
								
								queryStrBuffer.append("aiv.asset_instance_id=ai.asset_inst_id and ai.asset_id=ad.asset_id and ad.asset_id=ai.asset_id and p.user_id=ug.user_id and aiv.asset_instance_version_id=aivga.asset_instance_version_id and aivga.group_id=ug.group_id and p.user_name='"+userName+"'  and aivga.view_access=1 and aiv.asset_instance_version_id in ( select * from (");

								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i > 0) {
										queryStrBuffer.append(" union all ");
										if(logicalSelectList[i-1].equalsIgnoreCase("And"))
											andCount++;
									}
									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
									String[] params = assetParamNameList[i].split("_");
									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											//procedure.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}
										else{
											/*if(operatorsList[i].equals("=")){
													//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
												procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											}  else {
												procedure.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
											}*/

											if(operatorsList[i].equals("=")){
												//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");

											}  else {
												//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) =0");

											} 

											/*else {
												procedure.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											}*/
											//else
											//procedure.append();									
										}


									}else {
										if (operatorsList[i]
												.equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer
											.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else
												queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
										}
									}
									queryStrBuffer.append(" ))");

								}
								queryStrBuffer.append(") as tbl ");
								if(andCount>1)
								{
									queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
								}
								queryStrBuffer.append(") group by aiv.asset_instance_version_id,ai.asset_inst_name,ai.asset_inst_id");
								queryStrBuffer
									.append(" order by asset_inst_name)AS a LEFT OUTER JOIN (SELECT pv.parameter_values_id,aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.list_param_type_id as listparamtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
											+ userName
											+ "' AND ad.asset_name='"
											+ assetName
											+ "' AND FIND_IN_SET (apd.asset_param_name,'"
											+ showHideAssetParamName
											+ "'))b ON a.avid=b.vid order by asset_inst_name,cast(version_name as decimal(16,8))");
							}

						}
					}
				}
				if(staticParam.length() !=0){
					String[] strArray = staticParam.toString().split(",");
					
					AssetParamDef apd = null;
					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'"); 
						preparedStmt = conn.prepareStatement(queryStBuff.toString());
						resultSet = preparedStmt.executeQuery();
						while(resultSet.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(resultSet.getLong("asset_param_id"));
							apd.setAssetParamName(resultSet.getString("asset_param_name"));
							apd.setIs_static(resultSet.getInt("is_static"));
							apd.setStaticValue(resultSet.getString("static_val"));
							apd.setParamTypeId(resultSet.getLong("param_type_id"));
							apd.setFileName(resultSet.getString("fileName"));
							apdList.add(apd);
						}
					}
				}
			}else{
				if(staticParam.length() !=0){
					if(nonStaticParam.length() ==0){
						//create
						tempTableName1 = "table"+userName+System.currentTimeMillis();
						queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
						if(userName.equalsIgnoreCase("roleAnonymous")){
							queryStrBuffer.append("SELECT aiv.asset_instance_version_id as avid,aiv.created_on,ai.asset_inst_name as asset_inst_name,aiv.version_name as version_name,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
									+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
									+ "ad.asset_name='"+assetName+"' and ai.public_access=1 ORDER BY  aiv.asset_instance_version_id");
							
							
						}else{
							if(flagForUser){//admin users
								queryStrBuffer.append("SELECT aiv.asset_instance_version_id as avid,aiv.created_on,ai.asset_inst_name as asset_inst_name,aiv.version_name as version_name,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
										+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
										+ "ad.asset_name='"+assetName+"' ORDER BY  aiv.asset_instance_version_id");
							}else{ // non admin users
								queryStrBuffer.append("SELECT aiv.asset_instance_version_id as avid,aiv.created_on,ai.asset_inst_name as asset_inst_name,aiv.version_name as version_name,aiv.description as description,ad.versionable as versionable from group_details gd ,"
										+ "asset_instance_version_group_access aivga,user_groups ug,profile p,asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
										+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE ad.asset_name='"+assetName+"' and p.user_name='"+userName+"' and "
										+ "p.user_id=ug.user_id and aivga.asset_instance_version_id=aiv.asset_instance_version_id and aivga.group_id=gd.group_id and "
										+ "ug.group_id=gd.group_id and aivga.view_access=1 ORDER BY  aiv.asset_instance_version_id");
							}
						}
					}

					String[] strArray = staticParam.toString().split(",");


					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'"); 
						preparedStmt = conn.prepareStatement(queryStBuff.toString());
						resultSet = preparedStmt.executeQuery();
						AssetParamDef apd = null;
						while(resultSet.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(resultSet.getLong("asset_param_id"));
							apd.setAssetParamName(resultSet.getString("asset_param_name"));
							apd.setIs_static(resultSet.getInt("is_static"));
							apd.setStaticValue(resultSet.getString("static_val"));
							apd.setParamTypeId(resultSet.getLong("param_type_id"));
							apd.setFileName(resultSet.getString("fileName"));
							apdList.add(apd);
						}
					}
				}
			}
			
			if(staticParam.length() == 0 && nonStaticParam.length() ==0){
				//create
				tempTableName1 = "table"+userName+System.currentTimeMillis();
				queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
				
				if(userName.equalsIgnoreCase("roleAnonymous")){
					/*queryStrBuffer.append("SELECT aiv.asset_instance_version_id as avid,ai.asset_inst_name as asset_inst_name,aiv.version_name as version_name,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
							+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
							+ "ad.asset_name='"+assetName+"' and ai.public_access=1 ORDER BY  aiv.asset_instance_version_id");*/
					
					if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

						queryStrBuffer.append("select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,ad.versionable,ad.icon_image_name,apd.is_static,apd.static_val from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and ai3.public_access=1 and aiv3.asset_instance_version_id in (select * from  (");

						if(assetParamNameList.length > 1)
							queryStrBuffer.append("select distinct * from (");

						for (int i = 0; i < assetParamNameList.length; i++) {

							if (i>0){
								queryStrBuffer.append(" union all ");
								if(logicalSelectList[i-1].equals("And"))
									andCount++;
							}
							queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

							String[] params=assetParamNameList[i].split("_");

							queryStrBuffer.append("((a.asset_param_id="+ params[0]);
							if (param1ValuesList[i].trim().length() > 0) {
								if(params[1].trim().equals("date")){
									queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
								}else if(params[1].trim().equals("text")){
									//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//									queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
									queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
								}
								else if(params[1].trim().equals("rich text")){
									if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
										queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
									}else{
										queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
									}
								}else{
									if(operatorsList[i].equals("=")){
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
										//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
									} else {
										//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
										//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
										queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
									}
										
										/*else {
										queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
									}*/
									//else
										//queryStrBuffer.append();									
								}
							}else {
								if (operatorsList[i].equalsIgnoreCase("is null")) {
									queryStrBuffer.append(" and b.fileContent = ''");
								} else {
									queryStrBuffer.append(" and b.fileContent != ''");
								}
							}
							if (param2ValuesList != null) {
								if (param2ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date"))
										queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
									else 
										queryStrBuffer.append(" and '" + param2ValuesList[i]+ "'");
								}
							}
							queryStrBuffer.append(" ))");

						}
						if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
						if(andCount>1)
							queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
						queryStrBuffer.append(" union all ");
						queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and ai2.public_access=1 and asset_name=\"").append(assetName).append("\" and (");

						if (taxonomyNamesList.length > 0) {
							String taxStr = "";
							for (String s : taxonomyNamesList) {
								taxStr += "aivt.aiv_taxonomy_id =  " + s + " or ";
							}
							queryStrBuffer.append(taxStr.substring(0,taxStr.length() - 4) + ")");

						}
						queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");

						/*queryStrBuffer
						.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr, apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
								+ Constants.GUEST
								+ "' AND ad.asset_name='"
								+ assetName
								+ "' AND FIND_IN_SET (apd.asset_param_name,'"
								+ showHideAssetParamName
								+ "') GROUP BY vid,apname)b ON a.avid=b.vid order by avid");
*/
					} else if (!taxonomyNames.equalsIgnoreCase("")) {

						queryStrBuffer.append("select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and ai3.public_access=1 and aiv3.asset_instance_version_id in (select * from (");
						queryStrBuffer.append("select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and ai2.public_access=1 and asset_name=\"").append(assetName).append("\" and  ( ");

						String taxStr = "";
						for (String s : taxonomyNamesList) {
							taxStr += "aivt.aiv_taxonomy_id = " + s + " or ";
						}
						queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4)+ ")");

						queryStrBuffer.append(") as tbl2)");

						/*queryStrBuffer
						.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr, apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
								+ Constants.GUEST
								+ "' AND ad.asset_name='"
								+ assetName
								+ "' AND FIND_IN_SET (apd.asset_param_name,'"
								+ showHideAssetParamName
								+ "') GROUP BY vid,apname)b ON a.avid=b.vid order by avid");*/

					} else {
						andCount=1;

						queryStrBuffer.append("select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id and ai.public_access=1 and aiv.asset_instance_version_id in ( select * from (");


						for (int i = 0; i < assetParamNameList.length; i++) {

							if (i>0){
								queryStrBuffer.append(" union all ");
								if(logicalSelectList[i-1].equals("And"))
									andCount++;
							}

							queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
							String[] params=assetParamNameList[i].split("_");
							queryStrBuffer.append("((a.asset_param_id="+ params[0]);
							if (param1ValuesList[i].trim().length() > 0) {

								/*queryStrBuffer.append(" and b.value "
										+ operatorsList[i] + " '"
										+ param1ValuesList[i] + "'");*/
								
								if(params[1].trim().equals("date"))
									queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
								/*else
								queryStrBuffer.append(" and b.value "
										+ operatorsList[i] + " '"
										+ param1ValuesList[i] + "'");*/
								else{
									if(operatorsList[i].equals("=")){
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
										//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
									}	 else {
										//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
										//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
										queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
									} 
																		
								}

							}else {
								if (operatorsList[i].equalsIgnoreCase("is null")) {
									queryStrBuffer.append(" and b.fileContent = ''");
								} else {
									queryStrBuffer.append(" and b.fileContent != ''");
								}
							}
							if (param2ValuesList != null) {
								if (param2ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date"))
										queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
									else
										queryStrBuffer.append(" and '" + param2ValuesList[i]+ "'");
								}
							}
							queryStrBuffer.append(" ))");

						}
						queryStrBuffer.append(") as tbl ");
						if(andCount>1)
							queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
						queryStrBuffer.append(")"); //System.out.println(queryStrBuffer);
						/*queryStrBuffer
						.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr, apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
								+ Constants.GUEST
								+ "' AND ad.asset_name='"
								+ assetName
								+ "' AND FIND_IN_SET (apd.asset_param_name,'"
								+ showHideAssetParamName
								+ "') GROUP BY vid,apname)b ON a.avid=b.vid order by avid");*/
						
						//updated by Pinak 26-09-2018
						
						queryStrBuffer
						.append(" order by asset_inst_name)AS a LEFT OUTER JOIN (SELECT pv.parameter_values_id,aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
								+ userName
								+ "' AND ad.asset_name='"
								+ assetName
								+ "' AND FIND_IN_SET (apd.asset_param_name,'"
								+ showHideAssetParamName
								+ "'))b ON a.avid=b.vid order by asset_inst_name,cast(version_name as decimal(16,8))");
					}
				}else{
					if(flagForUser){//admin users
						/*queryStrBuffer.append("SELECT aiv.asset_instance_version_id as avid,ai.asset_inst_name as asset_inst_name,aiv.version_name as version_name,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
								+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
								+ "ad.asset_name='"+assetName+"' ORDER BY  aiv.asset_instance_version_id");*/
						
						



						if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

							queryStrBuffer.append("SELECT aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id" 
									+" AND aiv.asset_instance_version_id IN ( SELECT * FROM (");
							if(assetParamNameList.length > 1)
								queryStrBuffer.append("select distinct * from (");

							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i > 0) {
									queryStrBuffer.append(" union all ");
									if (logicalSelectList[i - 1].equalsIgnoreCase("And"))
										andCount++;
								}

								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

								String[] params=assetParamNameList[i].split("_");

								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//										queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
											
											/*else {
											queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										}*/
										//else
											//queryStrBuffer.append();									
									}
								}else {
									if (operatorsList[i].equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else 
											queryStrBuffer.append(" and '"+ param2ValuesList[i] + "'");
									}
								}
								queryStrBuffer.append(" ))");

							}
							if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 

							queryStrBuffer.append(" union all ");
							queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

							if (taxonomyNamesList.length > 0) {
								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id =" + s + " or ";
								}
								queryStrBuffer.append(taxStr.substring(0,taxStr.length() - 4)+ ")");
							}
							queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");

							/*queryStrBuffer
							.append(" )As a LEFT OUTER JOIN  (SELECT aiv.asset_instance_version_id as vid,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr,apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "'))b ON a.avid=b.vid order by avid");*/

						} else if (!taxonomyNames.equalsIgnoreCase("")) {

							queryStrBuffer.append("select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and aiv3.asset_instance_version_id in (select * from (");
							queryStrBuffer.append("select distinct aiv2.asset_instance_version_id,aiv3.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and  ( ");

							String taxStr = "";
							for (String s : taxonomyNamesList) {
								taxStr += "aivt.aiv_taxonomy_id =" + s + " or ";
							}

							queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4));
							queryStrBuffer.append(")");
							queryStrBuffer.append(") as tbl2)");
							/*queryStrBuffer
							.append(" )As a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr,apd.asset_param_name as apname, pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "'))b ON a.avid=b.vid order by avid");
*/
						} else {
							andCount=1;

							queryStrBuffer.append("select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id and aiv.asset_instance_version_id in ( select * from (");
							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i>0){
									queryStrBuffer.append(" union all ");
									if (logicalSelectList[i - 1].equalsIgnoreCase("And"))								
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

								String[] params=assetParamNameList[i].split("_");

								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//										queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
											
											/*else {
											queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										}*/
										//else
											//queryStrBuffer.append();									
									}
								}else {
									if (operatorsList[i].equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else
											queryStrBuffer.append(" and '"+ param2ValuesList[i] + "'");
									}
								}
								queryStrBuffer.append(" ))");

							}
							queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
							queryStrBuffer.append(")"); 

							/*queryStrBuffer
							.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "'))b ON a.avid=b.vid order by avid");*/
						}


					
					}else{

						if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

							/*queryStrBuffer.append(
									"select * from(select aiv3.asset_instance_version_id avid,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,aivga3.edit_access,aivga3.delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1  and aiv3.asset_instance_version_id in (select * from  ( ");
							if(assetParamNameList.length > 1)
								queryStrBuffer.append("select distinct * from (");
							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i > 0) {
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equals("And"))
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
								String[] params = assetParamNameList[i].split("_");
								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//										queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
											
											else {
											queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										}
										//else
											//queryStrBuffer.append();									
									}
								}else {
									if (operatorsList[i]
											.equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer
										.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else 
											queryStrBuffer.append(" and '"+ param2ValuesList[i] + "'");
									}
								}
								queryStrBuffer.append(" ))");

							}
							if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
							queryStrBuffer.append(" union all ");
							queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

							if (taxonomyNamesList.length > 0) {
								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
								}
								queryStrBuffer.append(taxStr.substring(0,
										taxStr.length() - 4)+")");

							}
							queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");
							queryStrBuffer.append(" group by aiv3.asset_instance_version_id");
							queryStrBuffer
							.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr,apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id  WHERE p.user_name='"
									+ userName
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid order by a.avid,b.pvalue");*/
							
							queryStrBuffer.append(
									"select distinct * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,max(aivga3.edit_access) as edit_access,max(aivga3.delete_access) as delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where ");
							queryStrBuffer.append("aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1  and aiv3.asset_instance_version_id in (select * from  ( ");
							
							if(assetParamNameList.length > 1)
								queryStrBuffer.append("select distinct * from (");
							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i > 0) {
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equalsIgnoreCase("And"))
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
								String[] params = assetParamNameList[i].split("_");
								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										//procedure.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
											//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
											
										}  else {
											//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) =0");
											
										} 
																		
									}

								}else {
									if (operatorsList[i]
											.equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer
										.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else 
											queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
									}
								}
								queryStrBuffer.append(" ))");

							}
							if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
							queryStrBuffer.append(" union all ");
							queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

							if (taxonomyNamesList.length > 0) {
								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
								}
								queryStrBuffer.append(taxStr.substring(0,
										taxStr.length() - 4)+")");

							}
							queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");
							queryStrBuffer.append(" group by aiv3.asset_instance_version_id,ai3.asset_inst_name,ai3.asset_inst_id");
							
							queryStrBuffer
								.append(" order by asset_inst_name)AS a LEFT OUTER JOIN (SELECT pv.parameter_values_id,aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id  WHERE p.user_name='"
										+ userName
										+ "' AND ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "'))b ON a.avid=b.vid order by asset_inst_name,cast(version_name as decimal(16,8))");

						} else if (!taxonomyNames.equalsIgnoreCase("")) {

							queryStrBuffer.append("select distinct * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,max(aivga3.edit_access) as edit_access,max(aivga3.delete_access) as delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where ");
								
							queryStrBuffer.append("aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1 and aiv3.asset_instance_version_id in (select * from (");
							
							queryStrBuffer.append("select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and  ( ");

							String taxStr = "";
							for (String s : taxonomyNamesList) {
								taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
							}
							queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4));
							queryStrBuffer.append(")");

							queryStrBuffer.append(" ) as tbl2) group by aiv3.asset_instance_version_id,ai3.asset_inst_name,ai3.asset_inst_id ");
							queryStrBuffer
								.append(" order by asset_inst_name)AS a LEFT OUTER JOIN (SELECT pv.parameter_values_id,aiv.asset_instance_version_id as vid,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
										+ userName
										+ "' AND ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "'))b ON a.avid=b.vid order by asset_inst_name,cast(version_name as decimal(16,8))");
						} else {
							/*andCount=1;

							queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access,aivga.edit_access,aivga.delete_access,ad.versionable,ad.icon_image_name  from asset_instance_versions  aiv,asset_instance ai,asset_def ad,asset_instance_version_group_access aivga,user_groups ug,profile p where aiv.asset_instance_id=ai.asset_inst_id and ai.asset_id=ad.asset_id and ad.asset_id=ai.asset_id and p.user_id=ug.user_id and aiv.asset_instance_version_id=aivga.asset_instance_version_id and aivga.group_id=ug.group_id and p.user_name='"+userName+"'  and aivga.view_access=1 and aiv.asset_instance_version_id in ( select * from (");

							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i > 0) {
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equals("And"))
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
								String[] params = assetParamNameList[i].split("_");
								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
										queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.value,'\\\\',''))");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
												//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											//queryStrBuffer.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
											//queryStrBuffer.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
											
											else {
											queryStrBuffer.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										}
										//else
											//queryStrBuffer.append();									
									}
								}else {
									if (operatorsList[i]
											.equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer
										.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else
											queryStrBuffer.append(" and '"+ param2ValuesList[i] + "'");
									}
								}
								queryStrBuffer.append(" ))");

							}
							queryStrBuffer.append(") as tbl ");
							if(andCount>1)
							{
								queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
							}
							queryStrBuffer.append(") group by aiv.asset_instance_version_id");

							queryStrBuffer
							.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as decr,apd.asset_param_name as apname,pv.value as pvalue,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.is_static,apd.static_val from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
									+ userName
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid order by a.avid,b.pvalue");*/
							
							
							andCount=1;

							queryStrBuffer.append("select distinct * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,aiv.description,ai.asset_inst_id,aiv.version_name,ai.public_access,max(aivga.edit_access) as edit_access,max(aivga.delete_access) as delete_access,ad.versionable,ad.icon_image_name  from asset_instance_versions  aiv,asset_instance ai,asset_def ad,asset_instance_version_group_access aivga,user_groups ug,profile p where ");
							
							queryStrBuffer.append("aiv.asset_instance_id=ai.asset_inst_id and ai.asset_id=ad.asset_id and ad.asset_id=ai.asset_id and p.user_id=ug.user_id and aiv.asset_instance_version_id=aivga.asset_instance_version_id and aivga.group_id=ug.group_id and p.user_name='"+userName+"'  and aivga.view_access=1 and aiv.asset_instance_version_id in ( select * from (");

							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i > 0) {
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equalsIgnoreCase("And"))
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
								String[] params = assetParamNameList[i].split("_");
								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										//procedure.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
//										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}
									else{
										/*if(operatorsList[i].equals("=")){
												//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', (REPLACE(b.value,'~~',','))) ))");
											procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										}  else {
											procedure.append(" and b.value "+ operatorsList[i] + " '"+ param1ValuesList[i] + "'");
										}*/

										if(operatorsList[i].equals("=")){
											//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");

										}  else {
											//procedure.append(" and FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))=0");
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) =0");

										} 

										/*else {
											procedure.append(" and !FIND_IN_SET('" + param1ValuesList[i] + "', REPLACE(b.value,'~~',','))");
										}*/
										//else
										//procedure.append();									
									}


								}else {
									if (operatorsList[i]
											.equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer
										.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else
											queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
									}
								}
								queryStrBuffer.append(" ))");

							}
							queryStrBuffer.append(") as tbl ");
							if(andCount>1)
							{
								queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
							}
							queryStrBuffer.append(") group by aiv.asset_instance_version_id,ai.asset_inst_name,ai.asset_inst_id");
							queryStrBuffer
								.append(" order by asset_inst_name)AS a LEFT OUTER JOIN (SELECT pv.parameter_values_id,aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.list_param_type_id as listparamtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
										+ userName
										+ "' AND ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "'))b ON a.avid=b.vid order by asset_inst_name,cast(version_name as decimal(16,8))");
						}

					}
				}
			}
			
			preparedStmt = conn.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp1data = "CREATE INDEX avid ON "+tempTableName1+" (avid)" ;
			
			preparedStmt1 = conn.prepareStatement(temp1data.toString());
			preparedStmt1.executeUpdate();
			
			tempTableName2 = "table"+userName+System.currentTimeMillis();
			queryStrBuffer = new StringBuffer("Create table "+tempTableName2+"(avd INT,grouppath TEXT)");

			preparedStmt = conn.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp2data = "CREATE INDEX avd ON "+tempTableName2+" (avd)" ;
			
			preparedStmt1 = conn.prepareStatement(temp2data.toString());
			preparedStmt1.executeUpdate();
			
			String storedProcedure = "{call getAssetAttributes(?,?,?,?,?)}";
			CallableStatement callableStatement = conn.prepareCall(storedProcedure);
			callableStatement.setString(1, assetName);
			callableStatement.setString(2, userName);
			callableStatement.setBoolean(3, flagForUser);
			callableStatement.setString(4, tempTableName2);
			callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);
			callableStatement.execute();

			tempTableName3 = "table"+userName+System.currentTimeMillis();
			queryStrBuffer = new StringBuffer("Create table "+tempTableName3+" as ");

			queryStrBuffer.append("select aiv.asset_instance_version_id as avid,aiv.created_on,"
					+ "ai.asset_inst_name as asset_inst_name,group_concat(tg.tag_name) as tagname from asset_def ad JOIN "
					+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
					+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id LEFT OUTER JOIN "
					+ "tagging_master tg ON aiv.asset_instance_version_id=tg.asset_instance_version_id WHERE "
					+ "ad.asset_name='"+assetName+"' GROUP BY avid;");
			preparedStmt = conn.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();
			
			String temp3data = "CREATE INDEX avid ON "+tempTableName3+" (avid)" ;
			
			preparedStmt1 = conn.prepareStatement(temp3data.toString());
			preparedStmt1.executeUpdate();
			
			if(staticParam.length() == 0 && nonStaticParam.length() ==0){
				
				if(flag){
					queryStrBuffer = new StringBuffer("select p.avid,p.created_on,p.asset_inst_name,p.description,"
							+ "group_concat(DISTINCT(t.grouppath)) as taxname,group_concat(DISTINCT(tg.tagname)) as tagname,p.versionable from "+tempTableName1+" p LEFT OUTER JOIN "
							+ tempTableName2+" t ON p.avid=t.avd LEFT OUTER JOIN "
							+ tempTableName3+" tg ON p.avid=tg.avid group by avid,p.apname,p.pvalue ORDER BY p.avid; ");
				}else{
					queryStrBuffer = new StringBuffer("select p.avid,p.created_on,p.asset_inst_name,p.description,p.version_name,"
							+ "group_concat(DISTINCT(t.grouppath)) as taxname,group_concat(DISTINCT(tg.tagname)) as tagname,p.versionable from "+tempTableName1+" p LEFT OUTER JOIN "
							+ tempTableName2+" t ON p.avid=t.avd LEFT OUTER JOIN "
							+ tempTableName3+" tg ON p.avid=tg.avid group by avid ORDER BY p.avid; ");
				}
				
			}
			else{
			if(flag){
				queryStrBuffer = new StringBuffer("select p.avid,p.created_on,p.asset_inst_name,p.description,p.apname,p.version_name,p.pvfile,p.paramtypeid,"
						+ "p.pvalue,p.ldap_attribute_id,p.asset_inst_id,t.grouppath as taxname,tg.tagname as tagname,p.versionable,p.icon_image_name from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.avid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.avid=tg.avid; ");
			}else{
				queryStrBuffer = new StringBuffer("select p.avid,p.created_on,p.asset_inst_name,p.description,p.version_name,p.pvfile,p.paramtypeid,p.pvalue,p.ldap_attribute_id,p.asset_inst_id,"
						+ "t.grouppath as taxname,tg.tagname as tagname,p.versionable from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.avid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.avid=tg.avid; ");
			}
			
			}
			
			preparedStmt = conn.prepareStatement(queryStrBuffer.toString());
			resultSet = preparedStmt.executeQuery();
			long latestAssetInstVerId = 0L;
			String latestAssetInstparam = "";
			resultSet = preparedStmt.executeQuery();
			StringBuilder ldapMappingFinalRes = null;
			while (resultSet.next()) {
				assetInstanceVersionsDetails = new AssetInstanceVersion();
				if(staticParam.length() == 0 && nonStaticParam.length() ==0){
					
				}
				else{
					assetInstanceVersionsDetails.setAssetInstanceId(resultSet
							.getLong("asset_inst_id"));
					if( resultSet.getLong("paramtypeid") == 9L ){						
						if(!latestAssetInstparam.equalsIgnoreCase("")){
							if(latestAssetInstparam.equalsIgnoreCase(resultSet.getString("apname"))){
								ldapMappingFinalRes.append(resultSet.getString("pvalue")+"~~~~"+resultSet.getString("ldap_attribute_id") + "``") ;
							}else{
								ldapMappingFinalRes = new StringBuilder(resultSet.getString("pvalue") +"~~~~"+resultSet.getString("ldap_attribute_id") + "``");
							}
						}else{
							ldapMappingFinalRes = new StringBuilder(resultSet.getString("pvalue") +"~~~~"+resultSet.getString("ldap_attribute_id") + "``");
						}
						assetInstanceVersionsDetails.setParamValue(ldapMappingFinalRes.toString());
						latestAssetInstparam = resultSet.getString("apname");						
					} else {
						assetInstanceVersionsDetails.setParamValue(resultSet
								.getString("pvalue"));
					}
					assetInstanceVersionsDetails.setAssetParamName(resultSet
							.getString("apname"));					
					assetInstanceVersionsDetails.setFileName(resultSet
							.getString("pvfile"));
					assetInstanceVersionsDetails.setParamTypeId(resultSet
							.getLong("paramtypeid"));
					
				}				
				
				assetInstanceVersionsDetails.setVersionName(resultSet
						.getString("version_name"));
				assetInstanceVersionsDetails.setDescription(resultSet
						.getString("description"));				
				assetInstanceVersionsDetails.setAssetInstVersionId(resultSet
						.getLong("avid"));				
				assetInstanceVersionsDetails.setAssetInstName(resultSet
						.getString("asset_inst_name"));
				
				assetInstanceVersionsDetails.setVersionable(resultSet.getBoolean("versionable"));
				//assetInstanceVersionsDetails.setIconImageName(resultSet.getString("icon_image_name"));
				assetInstanceVersionsDetails.setTaxonomyName(resultSet.getString("taxname"));
				assetInstanceVersionsDetails.setTagName(resultSet.getString("tagname"));
				assetInstanceVersionsDetails.setCreatedOn(resultSet.getTimestamp("created_on"));	
				
				assetInstanceVersionsListForGrid.add(assetInstanceVersionsDetails);

				if (log.isTraceEnabled()) {
					log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || "
							+ assetInstanceVersionsDetails.toString());
				}
			}
			
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || "
						+ assetInstanceVersionsListForGrid.toString());
			}
		} catch (SQLException e) {
			log.error("getAssetInstanceForFilterWithNonStaticParametersDao || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetInstanceForFilterWithNonStaticParametersDao || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetInstanceForFilterWithNonStaticParametersDao || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetInstanceForFilterWithNonStaticParametersDao || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			try{
				if(null != tempTableName1){
					preparedStmt = conn.prepareStatement("Drop table IF EXISTS "+tempTableName1);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName2){
					
					preparedStmt = conn.prepareStatement("Drop table IF EXISTS "+tempTableName2);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName3){
					preparedStmt = conn.prepareStatement("Drop table IF EXISTS "+tempTableName3);
					preparedStmt.executeUpdate();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
			try {
				preparedStmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedSt);
			DBConnection.closePreparedStatement(preparedStmt1);
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
			

		}
		log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || exit");
		return assetInstanceVersionsListForGrid;
	}
	
	
	/**
	 * @method getAssetInstanceForFilterWithNonStaticParametersDao
	 * @description get asset instance details for filter applied
	 * @param userName
	 * @param assetName
	 * @param assetParamName
	 * @param param1Values
	 * @param param2Values
	 * @param operators
	 * @param logicalSelect
	 * @param taxonomyNames
	 * @param showHideAssetParamName
	 * @param from
	 * @param conn
	 * @return AssetInstanceVersion
	 * @throws RepoproException
	 */
	@SuppressWarnings("resource")
	public List<AssetInstanceVersion> getFinalResultForCreateFilterAttributeSheetWithFilter(
			String userName, Long assetId , String assetName, String assetParamNames,
			String param1Values, String param2Values, String operators,
			String logicalSelect, String taxonomyNames,
			String showHideAssetParamName,
			boolean flag,
			boolean flagForUser,
			StringBuffer staticParam,
			StringBuffer nonStaticParam,
			String value,
			Connection conn)
					throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceForFilterWithNonStaticParametersDao ||begin  with userName : "
					+ userName+" assetName :"+assetName+" operators:"+operators+" assetParamNames:"+assetParamNames+
					" param1Values:"+param1Values+" param2Values:"+param2Values+" logicalSelect:"+logicalSelect+
					" taxonomyNames:"+taxonomyNames+" value:"+value);
		}

		Connection conn1 = null;
		ResultSet resultSet = null;
		PreparedStatement preparedStmt = null;
		ResultSet rsltSet = null;
		PreparedStatement preparedSt = null;
		AssetInstanceVersion assetInstanceVersionsDetails = null;
		List<AssetInstanceVersion> assetInstanceVersionsListForGrid = new ArrayList<AssetInstanceVersion>();
		AdminAccessName adminAccessName = null;
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		boolean adminflag = false;
		int andCount=1;
		List<AssetParamDef> apdList = new ArrayList<AssetParamDef>();
		
		StringBuffer queryStrBuffer = new StringBuffer("");
		
		String tempTableName1 = null;
		String tempTableName2 = null;
		String tempTableName3 = null;

		PreparedStatement preparedStmt1 = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			String[] assetParamNameList = null;
			if (!assetParamNames.equalsIgnoreCase("")) {
				assetParamNameList = assetParamNames.split("~~");
			}
			String[] param1ValuesList = null;
			if (!param1Values.equalsIgnoreCase("")) {
				param1ValuesList = param1Values.split("~~");
			}
			String[] param2ValuesList = null;
			if (!param2Values.equalsIgnoreCase("")) {
				param2ValuesList = param2Values.split("~~");
			}
			String[] operatorsList = null;
			if (!operators.equalsIgnoreCase("")) {
				operatorsList = operators.split("~~");
			}
			String[] logicalSelectList = null;
			if (!logicalSelect.equalsIgnoreCase("")) {
				logicalSelectList = logicalSelect.split("~~");
			}
			String[] taxonomyNamesList = null;
			if (!taxonomyNames.equalsIgnoreCase("")) {
				taxonomyNamesList = taxonomyNames.split("~~");
			}
			String modifiedvalue = "";
			if (value.contains("_")||value.contains("'")){
				modifiedvalue = value;
				modifiedvalue = modifiedvalue.replace("'", "\\'");
				modifiedvalue = modifiedvalue.replace("_", "\\_");
				modifiedvalue = modifiedvalue.replace("%", "\\%");
			}else{
				modifiedvalue = value;
			}
			String descriptionvalue = "";
			if (value.contains("&")||value.contains("'")||value.contains("<")||value.contains(">")||value.contains("\"")||value.contains("_")){
					descriptionvalue = value;
					descriptionvalue = descriptionvalue.replace("&", "&amp;");
					descriptionvalue = descriptionvalue.replace("'", "&#39;");
					descriptionvalue = descriptionvalue.replace("<", "&lt;");
					descriptionvalue = descriptionvalue.replace(">", "&gt;");
					descriptionvalue = descriptionvalue.replace("\"", "&quot;");
					descriptionvalue = descriptionvalue.replace("_", "\\_");
					descriptionvalue = descriptionvalue.replace("%", "\\%");
			}else{
				descriptionvalue = value;
			}
			
			
			if(flag){
				//create
				tempTableName1 = "table"+userName+System.currentTimeMillis();
				queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
				
				if(nonStaticParam.length() !=0){
					if (userName.equalsIgnoreCase("roleAnonymous")) {

						if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

							queryStrBuffer = queryStrBuffer.append("select * from (select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and ai3.public_access=1 and aiv3.asset_instance_version_id in (select * from  (");

							if(assetParamNameList.length > 1)
								queryStrBuffer.append("select distinct * from (");

							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i>0){
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equalsIgnoreCase("And"))
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

								String[] params=assetParamNameList[i].split("_");

								queryStrBuffer.append("((a.asset_param_id="+ params[0]);
								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
									}
								}else {
									if (operatorsList[i].equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else 
											queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
									}
								}
								queryStrBuffer.append(" ))");

							}
							if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
							queryStrBuffer.append(" union all ");
							queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and ai2.public_access=1 and asset_name=\"").append(assetName).append("\" and (");

							if (taxonomyNamesList.length > 0) {
								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id =  " + s + " or ";
								}
								queryStrBuffer.append(taxStr.substring(0,taxStr.length() - 4) + ")");

							}
							queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");

							queryStrBuffer
							.append(") AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
									+ Constants.GUEST
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

						} else if (!taxonomyNames.equalsIgnoreCase("")) {

							queryStrBuffer = queryStrBuffer.append("select * from (select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and ai3.public_access=1 and aiv3.asset_instance_version_id in (select * from (");
							queryStrBuffer.append("select distinct 	aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and ai2.public_access=1 and asset_name=\"").append(assetName).append("\" and  ( ");

							String taxStr = "";
							for (String s : taxonomyNamesList) {
								taxStr += "aivt.aiv_taxonomy_id = " + s + " or ";
							}
							queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4)+ ")");

							queryStrBuffer.append(") as tbl2)");

							queryStrBuffer
							.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
									+ Constants.GUEST
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

						} else {
							andCount=1;

							queryStrBuffer=queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id and ai.public_access=1 and aiv.asset_instance_version_id in ( select * from (");


							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i>0){
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equalsIgnoreCase("And"))
										andCount++;
								}

								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
								String[] params=assetParamNameList[i].split("_");
								queryStrBuffer.append("((a.asset_param_id="+ params[0]);
								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
									}
								}else {
									if (operatorsList[i].equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else
											queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
									}
								}
								queryStrBuffer.append(" ))");

							}
							queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
							queryStrBuffer.append(")"); 
							queryStrBuffer
							.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
									+ Constants.GUEST
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid  where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");
						}
					}else {
						preparedSt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ADMIN_RIGHT));
						if (log.isTraceEnabled()) {
							log.trace("filterForGetAssetInstanceForFilterWithNonStaticParametersDao || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.GET_ADMIN_RIGHT));
						}
						preparedSt.setString(Constants.ONE, userName);
						rsltSet = preparedSt.executeQuery();

						while (rsltSet.next()) {
							adminAccessName = new AdminAccessName();
							adminAccessName.setUserName(rsltSet.getString("user_name"));
							adminAccessName.setGroupName(rsltSet.getString("group_name"));
							adminAccessName.setRoleName(rsltSet.getString("role_name"));
							adminAccessNameList.add(adminAccessName);
							if (log.isTraceEnabled()) {
								log.trace("filterForGetAssetInstanceForFilterWithNonStaticParametersDao || returning resultset for admin check : "
										+ adminAccessName.toString());
							}
						}

						for (AdminAccessName adminAccess : adminAccessNameList) {
							if (adminAccess.getUserName().equalsIgnoreCase("admin")
									|| adminAccess.getGroupName().equalsIgnoreCase(
											"group-admin")
											|| adminAccess.getRoleName().equalsIgnoreCase(
													"role-admin")) {
								adminflag = true;
							}
						}

						if (adminflag) {


							if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

								queryStrBuffer = queryStrBuffer.append("SELECT * FROM (SELECT aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id" 
										+" AND aiv.asset_instance_version_id IN ( SELECT * FROM (");
								if(assetParamNameList.length > 1)
									queryStrBuffer.append("select distinct * from (");

								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i > 0) {
										queryStrBuffer.append(" union all ");
										if (logicalSelectList[i - 1].equalsIgnoreCase("And"))
											andCount++;
									}

									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

									String[] params=assetParamNameList[i].split("_");

									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}else{
											if(operatorsList[i].equals("=")){
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
											} else {
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
											}
										}
									}else {
										if (operatorsList[i].equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else 
												queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
										}
									}
									queryStrBuffer.append(" ))");

								}
								if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
								if(andCount>1)
									queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 

								queryStrBuffer.append(" union all ");
								queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on as createdOn from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

								if (taxonomyNamesList.length > 0) {
									String taxStr = "";
									for (String s : taxonomyNamesList) {
										taxStr += "aivt.aiv_taxonomy_id =" + s + " or ";
									}
									queryStrBuffer.append(taxStr.substring(0,taxStr.length() - 4)+ ")");
								}
								queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");

								queryStrBuffer
								.append(")As a LEFT OUTER JOIN  (SELECT aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "'))b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

							} else if (!taxonomyNames.equalsIgnoreCase("")) {

								queryStrBuffer = queryStrBuffer.append("select * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and aiv3.asset_instance_version_id in (select * from (");
								queryStrBuffer.append("select distinct aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and  ( ");

								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id =" + s + " or ";
								}

								queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4));
								queryStrBuffer.append(")");
								queryStrBuffer.append(") as tbl2)");
								queryStrBuffer
								.append(" )As a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname, pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "'))b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name limit");

							} else {
								andCount=1;

								queryStrBuffer = queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id and aiv.asset_instance_version_id in ( select * from (");
								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i>0){
										queryStrBuffer.append(" union all ");
										if (logicalSelectList[i - 1].equalsIgnoreCase("And"))								
											andCount++;
									}
									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

									String[] params=assetParamNameList[i].split("_");

									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}else{
											if(operatorsList[i].equals("=")){
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
											} else {
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
											}
										}
									}else {
										if (operatorsList[i].equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else
												queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
										}
									}
									queryStrBuffer.append(" ))");

								}
								queryStrBuffer.append(") as tbl ");
								if(andCount>1)
									queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
								queryStrBuffer.append(")"); 

								queryStrBuffer
								.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "'))b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");
							}


						} else {

							if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

								queryStrBuffer = queryStrBuffer.append(
										"select * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,max(aivga3.edit_access) as edit_access,max(aivga3.delete_access) as delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1  and aiv3.asset_instance_version_id in (select * from  ( ");
								if(assetParamNameList.length > 1)
									queryStrBuffer.append("select distinct * from (");
								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i > 0) {
										queryStrBuffer.append(" union all ");
										if(logicalSelectList[i-1].equalsIgnoreCase("And"))
											andCount++;
									}
									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
									String[] params = assetParamNameList[i].split("_");
									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}else{
											if(operatorsList[i].equals("=")){
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
											} else {
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
											}
										}
									}else {
										if (operatorsList[i]
												.equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer
											.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else 
												queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
										}
									}
									queryStrBuffer.append(" ))");

								}
								if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
								if(andCount>1)
									queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
								queryStrBuffer.append(" union all ");
								queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

								if (taxonomyNamesList.length > 0) {
									String taxStr = "";
									for (String s : taxonomyNamesList) {
										taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
									}
									queryStrBuffer.append(taxStr.substring(0,
											taxStr.length() - 4)+")");

								}
								queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");
								queryStrBuffer.append(" group by aiv3.asset_instance_version_id,ai3.asset_inst_name,ai3.asset_inst_id");
								queryStrBuffer
								.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id  WHERE p.user_name='"
										+ userName
										+ "' AND ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

							} else if (!taxonomyNames.equalsIgnoreCase("")) {

								queryStrBuffer = queryStrBuffer.append("select * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,max(aivga3.edit_access) as edit_access,max(aivga3.delete_access) as delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1 and aiv3.asset_instance_version_id in (select * from (");
								queryStrBuffer.append("select distinct aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and  ( ");

								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
								}
								queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4));
								queryStrBuffer.append(")");

								queryStrBuffer.append(" ) as tbl2) group by aiv3.asset_instance_version_id,ai3.asset_inst_name,ai3.asset_inst_id ");
								queryStrBuffer
								.append(")AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
										+ userName
										+ "' AND ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

							} else {
								andCount=1;

								queryStrBuffer=queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access,max(aivga.edit_access) as edit_access,max(aivga.delete_access) as delete_access,ad.versionable,ad.icon_image_name  from asset_instance_versions  aiv,asset_instance ai,asset_def ad,asset_instance_version_group_access aivga,user_groups ug,profile p where aiv.asset_instance_id=ai.asset_inst_id and ai.asset_id=ad.asset_id and ad.asset_id=ai.asset_id and p.user_id=ug.user_id and aiv.asset_instance_version_id=aivga.asset_instance_version_id and aivga.group_id=ug.group_id and p.user_name='"+userName+"'  and aivga.view_access=1 and aiv.asset_instance_version_id in ( select * from (");

								for (int i = 0; i < assetParamNameList.length; i++) {

									if (i > 0) {
										queryStrBuffer.append(" union all ");
										if(logicalSelectList[i-1].equalsIgnoreCase("And"))
											andCount++;
									}
									queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
									String[] params = assetParamNameList[i].split("_");
									queryStrBuffer.append("((a.asset_param_id="+ params[0]);

									if (param1ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date")){
											queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
										}else if(params[1].trim().equals("text")){
											queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
										}
										else if(params[1].trim().equals("rich text")){
											if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
												queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
											}else{
												queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
											}
										}else{
											if(operatorsList[i].equals("=")){
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
											} else {
												queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
											}
										}
									}else {
										if (operatorsList[i]
												.equalsIgnoreCase("is null")) {
											queryStrBuffer.append(" and b.fileContent = ''");
										} else {
											queryStrBuffer
											.append(" and b.fileContent != ''");
										}
									}
									if (param2ValuesList != null) {
										if (param2ValuesList[i].trim().length() > 0) {
											if(params[1].trim().equals("date"))
												queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
											else
												queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
										}
									}
									queryStrBuffer.append(" ))");

								}
								queryStrBuffer.append(") as tbl ");
								if(andCount>1)
								{
									queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
								}
								queryStrBuffer.append(") group by aiv.asset_instance_version_id,ai.asset_inst_name,ai.asset_inst_id");

								queryStrBuffer
								.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
										+ userName
										+ "' AND ad.asset_name='"
										+ assetName
										+ "' AND FIND_IN_SET (apd.asset_param_name,'"
										+ showHideAssetParamName
										+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");
							}
						}
					}
				}
				if(staticParam.length() !=0){
					String[] strArray = staticParam.toString().split(",");
					
					AssetParamDef apd = null;
					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'"); 
						preparedStmt = conn.prepareStatement(queryStBuff.toString());
						resultSet = preparedStmt.executeQuery();
						while(resultSet.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(resultSet.getLong("asset_param_id"));
							apd.setAssetParamName(resultSet.getString("asset_param_name"));
							apd.setIs_static(resultSet.getInt("is_static"));
							apd.setStaticValue(resultSet.getString("static_val"));
							apd.setParamTypeId(resultSet.getLong("param_type_id"));
							apd.setFileName(resultSet.getString("fileName"));
							apdList.add(apd);
						}
					}
				}
			}else{
				if(staticParam.length() !=0){
					if(nonStaticParam.length() ==0){
						//create
						tempTableName1 = "table"+userName+System.currentTimeMillis();
						queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
						if(userName.equalsIgnoreCase("roleAnonymous")){
							queryStrBuffer.append("SELECT aiv.asset_instance_version_id as avid,aiv.created_on,ai.asset_inst_name as asset_inst_name,aiv.version_name as version_name,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
									+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
									+ "ad.asset_name='"+assetName+"' and ai.public_access=1 ORDER BY  aiv.asset_instance_version_id");
							
							
						}else{
							if(flagForUser){//admin users
								queryStrBuffer.append("SELECT aiv.asset_instance_version_id as avid,aiv.created_on,ai.asset_inst_name as asset_inst_name,aiv.version_name as version_name,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
										+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
										+ "ad.asset_name='"+assetName+"' ORDER BY  aiv.asset_instance_version_id");
							}else{ // non admin users
								queryStrBuffer.append("SELECT aiv.asset_instance_version_id as avid,aiv.created_on,ai.asset_inst_name as asset_inst_name,aiv.version_name as version_name,aiv.description as description,ad.versionable as versionable from group_details gd ,"
										+ "asset_instance_version_group_access aivga,user_groups ug,profile p,asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
										+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE ad.asset_name='"+assetName+"' and p.user_name='"+userName+"' and "
										+ "p.user_id=ug.user_id and aivga.asset_instance_version_id=aiv.asset_instance_version_id and aivga.group_id=gd.group_id and "
										+ "ug.group_id=gd.group_id and aivga.view_access=1 ORDER BY  aiv.asset_instance_version_id");
							}
						}
					}

					String[] strArray = staticParam.toString().split(",");


					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'"); 
						preparedStmt = conn.prepareStatement(queryStBuff.toString());
						resultSet = preparedStmt.executeQuery();
						AssetParamDef apd = null;
						while(resultSet.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(resultSet.getLong("asset_param_id"));
							apd.setAssetParamName(resultSet.getString("asset_param_name"));
							apd.setIs_static(resultSet.getInt("is_static"));
							apd.setStaticValue(resultSet.getString("static_val"));
							apd.setParamTypeId(resultSet.getLong("param_type_id"));
							apd.setFileName(resultSet.getString("fileName"));
							apdList.add(apd);
						}
					}
				}
			}
			
			if(staticParam.length() == 0 && nonStaticParam.length() ==0){
				//create
				tempTableName1 = "table"+userName+System.currentTimeMillis();
				queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
				
				if(userName.equalsIgnoreCase("roleAnonymous")){

					if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

						queryStrBuffer = queryStrBuffer.append("select * from (select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and ai3.public_access=1 and aiv3.asset_instance_version_id in (select * from  (");

						if(assetParamNameList.length > 1)
							queryStrBuffer.append("select distinct * from (");

						for (int i = 0; i < assetParamNameList.length; i++) {

							if (i>0){
								queryStrBuffer.append(" union all ");
								if(logicalSelectList[i-1].equalsIgnoreCase("And"))
									andCount++;
							}
							queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

							String[] params=assetParamNameList[i].split("_");

							queryStrBuffer.append("((a.asset_param_id="+ params[0]);
							if (param1ValuesList[i].trim().length() > 0) {
								if(params[1].trim().equals("date")){
									queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
								}else if(params[1].trim().equals("text")){
									queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
								}
								else if(params[1].trim().equals("rich text")){
									if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
										queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
									}else{
										queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
									}
								}else{
									if(operatorsList[i].equals("=")){
										queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
									} else {
										queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
									}
								}
							}else {
								if (operatorsList[i].equalsIgnoreCase("is null")) {
									queryStrBuffer.append(" and b.fileContent = ''");
								} else {
									queryStrBuffer.append(" and b.fileContent != ''");
								}
							}
							if (param2ValuesList != null) {
								if (param2ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date"))
										queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
									else 
										queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
								}
							}
							queryStrBuffer.append(" ))");

						}
						if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
						if(andCount>1)
							queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
						queryStrBuffer.append(" union all ");
						queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and ai2.public_access=1 and asset_name=\"").append(assetName).append("\" and (");

						if (taxonomyNamesList.length > 0) {
							String taxStr = "";
							for (String s : taxonomyNamesList) {
								taxStr += "aivt.aiv_taxonomy_id =  " + s + " or ";
							}
							queryStrBuffer.append(taxStr.substring(0,taxStr.length() - 4) + ")");

						}
						queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");

						queryStrBuffer
						.append(") AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
								+ Constants.GUEST
								+ "' AND ad.asset_name='"
								+ assetName
								+ "' AND FIND_IN_SET (apd.asset_param_name,'"
								+ showHideAssetParamName
								+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

					} else if (!taxonomyNames.equalsIgnoreCase("")) {

						queryStrBuffer = queryStrBuffer.append("select * from (select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and ai3.public_access=1 and aiv3.asset_instance_version_id in (select * from (");
						queryStrBuffer.append("select distinct 	aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and ai2.public_access=1 and asset_name=\"").append(assetName).append("\" and  ( ");

						String taxStr = "";
						for (String s : taxonomyNamesList) {
							taxStr += "aivt.aiv_taxonomy_id = " + s + " or ";
						}
						queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4)+ ")");

						queryStrBuffer.append(") as tbl2)");

						queryStrBuffer
						.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
								+ Constants.GUEST
								+ "' AND ad.asset_name='"
								+ assetName
								+ "' AND FIND_IN_SET (apd.asset_param_name,'"
								+ showHideAssetParamName
								+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

					} else {
						andCount=1;

						queryStrBuffer=queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id and ai.public_access=1 and aiv.asset_instance_version_id in ( select * from (");


						for (int i = 0; i < assetParamNameList.length; i++) {

							if (i>0){
								queryStrBuffer.append(" union all ");
								if(logicalSelectList[i-1].equalsIgnoreCase("And"))
									andCount++;
							}

							queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
							String[] params=assetParamNameList[i].split("_");
							queryStrBuffer.append("((a.asset_param_id="+ params[0]);
							if (param1ValuesList[i].trim().length() > 0) {
								if(params[1].trim().equals("date")){
									queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
								}else if(params[1].trim().equals("text")){
									queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
								}
								else if(params[1].trim().equals("rich text")){
									if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
										queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
									}else{
										queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
									}
								}else{
									if(operatorsList[i].equals("=")){
										queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
									} else {
										queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
									}
								}
							}else {
								if (operatorsList[i].equalsIgnoreCase("is null")) {
									queryStrBuffer.append(" and b.fileContent = ''");
								} else {
									queryStrBuffer.append(" and b.fileContent != ''");
								}
							}
							if (param2ValuesList != null) {
								if (param2ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date"))
										queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
									else
										queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
								}
							}
							queryStrBuffer.append(" ))");

						}
						queryStrBuffer.append(") as tbl ");
						if(andCount>1)
							queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
						queryStrBuffer.append(")"); 
						queryStrBuffer
						.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn, ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='"
								+ Constants.GUEST
								+ "' AND ad.asset_name='"
								+ assetName
								+ "' AND FIND_IN_SET (apd.asset_param_name,'"
								+ showHideAssetParamName
								+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid  where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name limit");
					}
				}else{
					if(flagForUser){//admin users
						/*queryStrBuffer.append("SELECT aiv.asset_instance_version_id as avid,ai.asset_inst_name as asset_inst_name,aiv.version_name as version_name,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN "
								+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
								+ "ad.asset_name='"+assetName+"' ORDER BY  aiv.asset_instance_version_id");*/
						
						



						if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

							queryStrBuffer = queryStrBuffer.append("SELECT * FROM (SELECT aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id" 
									+" AND aiv.asset_instance_version_id IN ( SELECT * FROM (");
							if(assetParamNameList.length > 1)
								queryStrBuffer.append("select distinct * from (");

							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i > 0) {
									queryStrBuffer.append(" union all ");
									if (logicalSelectList[i - 1].equalsIgnoreCase("And"))
										andCount++;
								}

								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

								String[] params=assetParamNameList[i].split("_");

								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
									}
								}else {
									if (operatorsList[i].equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else 
											queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
									}
								}
								queryStrBuffer.append(" ))");

							}
							if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 

							queryStrBuffer.append(" union all ");
							queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

							if (taxonomyNamesList.length > 0) {
								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id =" + s + " or ";
								}
								queryStrBuffer.append(taxStr.substring(0,taxStr.length() - 4)+ ")");
							}
							queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");

							queryStrBuffer
							.append(")As a LEFT OUTER JOIN  (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "'))b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

						} else if (!taxonomyNames.equalsIgnoreCase("")) {

							queryStrBuffer = queryStrBuffer.append("select * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad where ad.asset_id=ai3.asset_id and aiv3.asset_instance_id=ai3.asset_inst_id and aiv3.asset_instance_version_id in (select * from (");
							queryStrBuffer.append("select distinct aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and  ( ");

							String taxStr = "";
							for (String s : taxonomyNamesList) {
								taxStr += "aivt.aiv_taxonomy_id =" + s + " or ";
							}

							queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4));
							queryStrBuffer.append(")");
							queryStrBuffer.append(") as tbl2)");
							queryStrBuffer
							.append(" )As a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname, pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "'))b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

						} else {
							andCount=1;

							queryStrBuffer = queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access ,ad.versionable,ad.icon_image_name from asset_instance_versions  aiv,asset_instance ai,asset_def ad where ad.asset_id=ai.asset_id and aiv.asset_instance_id=ai.asset_inst_id and aiv.asset_instance_version_id in ( select * from (");
							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i>0){
									queryStrBuffer.append(" union all ");
									if (logicalSelectList[i - 1].equalsIgnoreCase("And"))								
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");

								String[] params=assetParamNameList[i].split("_");

								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
									}
								}else {
									if (operatorsList[i].equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else
											queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
									}
								}
								queryStrBuffer.append(" ))");

							}
							queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
							queryStrBuffer.append(")"); 

							queryStrBuffer
							.append(" ) AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray  from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "'))b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");
						}


					
					}else{

						if (!taxonomyNames.equalsIgnoreCase("") && !assetParamNames.equalsIgnoreCase("")) {

							queryStrBuffer = queryStrBuffer.append(
									"select * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,max(aivga3.edit_access) as edit_access,max(aivga3.delete_access) as delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1  and aiv3.asset_instance_version_id in (select * from  ( ");
							if(assetParamNameList.length > 1)
								queryStrBuffer.append("select distinct * from (");
							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i > 0) {
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equalsIgnoreCase("And"))
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
								String[] params = assetParamNameList[i].split("_");
								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
									}
								}else {
									if (operatorsList[i]
											.equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer
										.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else 
											queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
									}
								}
								queryStrBuffer.append(" ))");

							}
							if(assetParamNameList.length > 1) queryStrBuffer.append(") as tbl ");
							if(andCount>1)
								queryStrBuffer.append("  GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount ); 
							queryStrBuffer.append(" union all ");
							queryStrBuffer.append(" select distinct aiv2.asset_instance_version_id,aiv2.created_on from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and (");

							if (taxonomyNamesList.length > 0) {
								String taxStr = "";
								for (String s : taxonomyNamesList) {
									taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
								}
								queryStrBuffer.append(taxStr.substring(0,
										taxStr.length() - 4)+")");

							}
							queryStrBuffer.append(") as tbl2  GROUP BY 1 HAVING COUNT(*) = 2)");
							queryStrBuffer.append(" group by aiv3.asset_instance_version_id,ai3.asset_inst_name,ai3.asset_inst_id");
							queryStrBuffer
							.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id  WHERE p.user_name='"
									+ userName
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

						} else if (!taxonomyNames.equalsIgnoreCase("")) {

							queryStrBuffer = queryStrBuffer.append("select * from(select aiv3.asset_instance_version_id avid,aiv3.created_on,ai3.asset_inst_name,ai3.asset_inst_id,aiv3.version_name,aiv3.description,ai3.public_access,max(aivga3.edit_access) as edit_access,max(aivga3.delete_access) as delete_access,ad3.versionable,ad3.icon_image_name from asset_instance_versions  aiv3,asset_instance ai3,asset_def ad3,asset_instance_version_group_access aivga3,user_groups ug3,profile p3 where aiv3.asset_instance_id=ai3.asset_inst_id and ai3.asset_id=ad3.asset_id and ad3.asset_id=ai3.asset_id and p3.user_id=ug3.user_id and aiv3.asset_instance_version_id=aivga3.asset_instance_version_id and aivga3.group_id=ug3.group_id and p3.user_name='"+userName+"'  and aivga3.view_access=1 and aiv3.asset_instance_version_id in (select * from (");
							queryStrBuffer.append("select distinct aiv2.asset_instance_version_id from asset_instance_versions aiv2, asset_inst_versions_taxonomy aivt, asset_def ad2, asset_instance ai2  where  aivt.asset_inst_version_id = aiv2.asset_instance_version_id and  ai2.asset_inst_id = aiv2.asset_instance_id and ad2.asset_id = ai2.asset_id and asset_name=\"").append(assetName).append("\" and  ( ");

							String taxStr = "";
							for (String s : taxonomyNamesList) {
								taxStr += "aivt.aiv_taxonomy_id=" + s + " or ";
							}
							queryStrBuffer.append(taxStr.substring(0, taxStr.length() - 4));
							queryStrBuffer.append(")");

							queryStrBuffer.append(" ) as tbl2) group by aiv3.asset_instance_version_id,ai3.asset_inst_name,ai3.asset_inst_id ");
							queryStrBuffer
							.append(")AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
									+ userName
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");

						} else {
							andCount=1;

							queryStrBuffer=queryStrBuffer.append("select * from(select aiv.asset_instance_version_id avid,aiv.created_on,ai.asset_inst_name,ai.asset_inst_id,aiv.version_name,aiv.description,ai.public_access,max(aivga.edit_access) as edit_access,max(aivga.delete_access) as delete_access,ad.versionable,ad.icon_image_name  from asset_instance_versions  aiv,asset_instance ai,asset_def ad,asset_instance_version_group_access aivga,user_groups ug,profile p where aiv.asset_instance_id=ai.asset_inst_id and ai.asset_id=ad.asset_id and ad.asset_id=ai.asset_id and p.user_id=ug.user_id and aiv.asset_instance_version_id=aivga.asset_instance_version_id and aivga.group_id=ug.group_id and p.user_name='"+userName+"'  and aivga.view_access=1 and aiv.asset_instance_version_id in ( select * from (");

							for (int i = 0; i < assetParamNameList.length; i++) {

								if (i > 0) {
									queryStrBuffer.append(" union all ");
									if(logicalSelectList[i-1].equalsIgnoreCase("And"))
										andCount++;
								}
								queryStrBuffer.append("select distinct a.asset_inst_version_id from asset_inst_params a,parameter_values b where a.asset_inst_param_id=b.asset_inst_param_id and ");
								String[] params = assetParamNameList[i].split("_");
								queryStrBuffer.append("((a.asset_param_id="+ params[0]);

								if (param1ValuesList[i].trim().length() > 0) {
									if(params[1].trim().equals("date")){
										queryStrBuffer.append(" and STR_TO_DATE(b.value,'%d/%m/%Y') "+operatorsList[i]+" STR_TO_DATE('"+param1ValuesList[i]+"','%d/%m/%Y')");
									}else if(params[1].trim().equals("text")){
										queryStrBuffer.append(" and REPLACE(b.value,'\\\\','')"+operatorsList[i]+" REPLACE('"+param1ValuesList[i]+"','\\\\','')");
									}
									else if(params[1].trim().equals("rich text")){
										if(operatorsList[i].equals("like")||operatorsList[i].equals("not like")){
											queryStrBuffer.append(" and (REPLACE(b.rtf_plain_text,'\\\\','') "+operatorsList[i]+" CONCAT('%', REPLACE('"+param1ValuesList[i]+"','\\\\',''),'%'))");
										}else{
											queryStrBuffer.append(" and (REPLACE('"+param1ValuesList[i]+"','\\\\','')"+operatorsList[i]+" REPLACE(b.rtf_plain_text,'\\\\',''))");
										}
									}else{
										if(operatorsList[i].equals("=")){
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',',')) ");
										} else {
											queryStrBuffer.append(" and FIND_IN_SET(REPLACE(REPLACE('" + param1ValuesList[i] + "',',',''),'\\\\',''), REPLACE(REPLACE(REPLACE(b.value,',',''),'\\\\',''),'~~',','))=0");
										}
									}
								}else {
									if (operatorsList[i]
											.equalsIgnoreCase("is null")) {
										queryStrBuffer.append(" and b.fileContent = ''");
									} else {
										queryStrBuffer
										.append(" and b.fileContent != ''");
									}
								}
								if (param2ValuesList != null) {
									if (param2ValuesList[i].trim().length() > 0) {
										if(params[1].trim().equals("date"))
											queryStrBuffer.append(" and STR_TO_DATE('"+param2ValuesList[i]+"','%d/%m/%Y')");
										else
											queryStrBuffer.append(" and REPLACE('"+param2ValuesList[i]+"','\\\\','')");
									}
								}
								queryStrBuffer.append(" ))");

							}
							queryStrBuffer.append(") as tbl ");
							if(andCount>1)
							{
								queryStrBuffer.append(" GROUP BY tbl.asset_inst_version_id HAVING COUNT(*) = "+andCount); 
							}
							queryStrBuffer.append(") group by aiv.asset_instance_version_id,ai.asset_inst_name,ai.asset_inst_id");

							queryStrBuffer
							.append(" )AS a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on as createdOn,ai.asset_inst_name as instname,aiv.version_name as versionname,apd.asset_param_name as apname,pv.value as pvalue,pv.ldap_attribute_id,pv.fileName as pvfile,apd.param_type_id as paramtypeid,apd.asset_param_id,apd.isarray from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id  JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id  JOIN asset_param_def apd ON aip.asset_param_id=apd.asset_param_id  JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN user_groups ug ON acg.group_id=ug.group_id  JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN profile p ON ug.user_id=p.user_id WHERE p.user_name='"
									+ userName
									+ "' AND ad.asset_name='"
									+ assetName
									+ "' AND FIND_IN_SET (apd.asset_param_name,'"
									+ showHideAssetParamName
									+ "') GROUP BY vid,apname,value)b ON a.avid=b.vid where a.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.avid like CONCAT('%','"+modifiedvalue+"','%') order by asset_inst_name,version_name");
						}
					}
				}
			}
			
			preparedStmt = conn.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp1data = "CREATE INDEX avid ON "+tempTableName1+" (avid)" ;
			
			preparedStmt1 = conn.prepareStatement(temp1data.toString());
			preparedStmt1.executeUpdate();
			
			tempTableName2 = "table"+userName+System.currentTimeMillis();
			queryStrBuffer = new StringBuffer("Create table "+tempTableName2+"(avd INT,grouppath TEXT)");

			preparedStmt = conn.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();
			
			String temp2data = "CREATE INDEX avd ON "+tempTableName2+" (avd)" ;
			
			preparedStmt1 = conn.prepareStatement(temp2data.toString());
			preparedStmt1.executeUpdate();

			String storedProcedure = "{call getAssetAttributes(?,?,?,?,?)}";
			CallableStatement callableStatement = conn.prepareCall(storedProcedure);
			callableStatement.setString(1, assetName);
			callableStatement.setString(2, userName);
			callableStatement.setBoolean(3, flagForUser);
			callableStatement.setString(4, tempTableName2);
			callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);
			callableStatement.execute();

			tempTableName3 = "table"+userName+System.currentTimeMillis();
			queryStrBuffer = new StringBuffer("Create table "+tempTableName3+" as ");

			queryStrBuffer.append("select aiv.asset_instance_version_id as avid,aiv.created_on,"
					+ "ai.asset_inst_name as asset_inst_name,group_concat(tg.tag_name) as tagname from asset_def ad JOIN "
					+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
					+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id LEFT OUTER JOIN "
					+ "tagging_master tg ON aiv.asset_instance_version_id=tg.asset_instance_version_id WHERE "
					+ "ad.asset_name='"+assetName+"' GROUP BY avid;");
			preparedStmt = conn.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();
			
			String temp3data = "CREATE INDEX avid ON "+tempTableName3+" (avid)" ;
			
			preparedStmt1 = conn.prepareStatement(temp3data.toString());
			preparedStmt1.executeUpdate();
			
			if(staticParam.length() == 0 && nonStaticParam.length() ==0){
				
				if(flag){
					queryStrBuffer = new StringBuffer("select p.avid,p.created_on,p.asset_inst_name,p.description,"
							+ "group_concat(DISTINCT(t.grouppath)) as taxname,group_concat(DISTINCT(tg.tagname)) as tagname,p.versionable from "+tempTableName1+" p LEFT OUTER JOIN "
							+ tempTableName2+" t ON p.avid=t.avd LEFT OUTER JOIN "
							+ tempTableName3+" tg ON p.avid=tg.avid group by avid,p.apname,p.pvalue ORDER BY p.avid; ");
				}else{
					queryStrBuffer = new StringBuffer("select p.avid,p.created_on,p.asset_inst_name,p.description,p.version_name,"
							+ "group_concat(DISTINCT(t.grouppath)) as taxname,group_concat(DISTINCT(tg.tagname)) as tagname,p.versionable from "+tempTableName1+" p LEFT OUTER JOIN "
							+ tempTableName2+" t ON p.avid=t.avd LEFT OUTER JOIN "
							+ tempTableName3+" tg ON p.avid=tg.avid group by avid ORDER BY p.avid; ");
				}
				
			}
			else{
			if(flag){
				queryStrBuffer = new StringBuffer("select p.avid,p.created_on,p.asset_inst_name,p.description,p.apname,p.version_name,p.pvfile,p.paramtypeid,"
						+ "p.pvalue,p.ldap_attribute_id,p.asset_inst_id,group_concat(DISTINCT(t.grouppath)) as taxname,group_concat(DISTINCT(tg.tagname)) as tagname,p.versionable,p.icon_image_name from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.avid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.avid=tg.avid group by avid,p.apname,p.pvalue ORDER BY p.avid; ");
			}else{
				queryStrBuffer = new StringBuffer("select p.avid,p.created_on,p.asset_inst_name,p.description,p.version_name,p.pvfile,p.paramtypeid,p.pvalue,p.asset_inst_id,"
						+ "group_concat(DISTINCT(t.grouppath)) as taxname,group_concat(DISTINCT(tg.tagname)) as tagname,p.versionable from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.avid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.avid=tg.avid group by avid ORDER BY p.avid; ");
			}
			
			}

			preparedStmt = conn.prepareStatement(queryStrBuffer.toString());
			resultSet = preparedStmt.executeQuery();
			long latestAssetInstVerId = 0L;
			String latestAssetInstparam = "";
			StringBuilder ldapMappingFinalRes = null;
			resultSet = preparedStmt.executeQuery();
			while (resultSet.next()) {
				assetInstanceVersionsDetails = new AssetInstanceVersion();
				if(staticParam.length() == 0 && nonStaticParam.length() ==0){
					
				}
				else{
					assetInstanceVersionsDetails.setAssetInstanceId(resultSet
							.getLong("asset_inst_id"));
					if( resultSet.getLong("paramtypeid") == 9L ){						
						if(!latestAssetInstparam.equalsIgnoreCase("")){
							if(latestAssetInstparam.equalsIgnoreCase(resultSet.getString("apname"))){
								ldapMappingFinalRes.append(resultSet.getString("pvalue")+"~~~~"+resultSet.getString("ldap_attribute_id") + "``") ;
							}else{
								ldapMappingFinalRes = new StringBuilder(resultSet.getString("pvalue") +"~~~~"+resultSet.getString("ldap_attribute_id") + "``");
							}
						}else{
							ldapMappingFinalRes = new StringBuilder(resultSet.getString("pvalue") +"~~~~"+resultSet.getString("ldap_attribute_id") + "``");
						}
						assetInstanceVersionsDetails.setParamValue(ldapMappingFinalRes.toString());
						latestAssetInstparam = resultSet.getString("apname");						
					} else {
						assetInstanceVersionsDetails.setParamValue(resultSet
								.getString("pvalue"));
					}
					assetInstanceVersionsDetails.setAssetParamName(resultSet
							.getString("apname"));
					assetInstanceVersionsDetails.setFileName(resultSet
							.getString("pvfile"));
					assetInstanceVersionsDetails.setParamTypeId(resultSet
							.getLong("paramtypeid"));
				}
				
				assetInstanceVersionsDetails.setVersionable(resultSet.getBoolean("versionable"));
				
				assetInstanceVersionsDetails.setVersionName(resultSet
						.getString("version_name"));
				assetInstanceVersionsDetails.setDescription(resultSet
						.getString("description"));
				assetInstanceVersionsDetails.setCreatedOn(resultSet.getTimestamp("created_on"));
				assetInstanceVersionsDetails
				.setAssetInstVersionId(resultSet.getLong("avid"));
				
				assetInstanceVersionsDetails.setAssetInstName(resultSet
						.getString("asset_inst_name"));
				
				assetInstanceVersionsDetails.setVersionable(resultSet.getBoolean("versionable"));
				//assetInstanceVersionsDetails.setIconImageName(resultSet.getString("icon_image_name"));
				assetInstanceVersionsDetails.setTaxonomyName(resultSet.getString("taxname"));
				assetInstanceVersionsDetails.setTagName(resultSet.getString("tagname"));
				
				
				assetInstanceVersionsListForGrid.add(assetInstanceVersionsDetails);

				if (log.isTraceEnabled()) {
					log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || "
							+ assetInstanceVersionsDetails.toString());
				}
			}
			
			
			
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || "
						+ assetInstanceVersionsListForGrid.toString());
			}
		} catch (SQLException e) {
			log.error("getAssetInstanceForFilterWithNonStaticParametersDao || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetInstanceForFilterWithNonStaticParametersDao || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetInstanceForFilterWithNonStaticParametersDao || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetInstanceForFilterWithNonStaticParametersDao || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			try{
				if(null != tempTableName1){
					preparedStmt = conn.prepareStatement("Drop table IF EXISTS "+tempTableName1);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName2){
					
					preparedStmt = conn.prepareStatement("Drop table IF EXISTS "+tempTableName2);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName3){
					preparedStmt = conn.prepareStatement("Drop table IF EXISTS "+tempTableName3);
					preparedStmt.executeUpdate();
				}
			}catch(SQLException se){
				se.printStackTrace();
			}
			try {
				preparedStmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedSt);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closePreparedStatement(preparedStmt1);
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
			

		}
		log.trace("getAssetInstanceForFilterWithNonStaticParametersDao || exit");
		return assetInstanceVersionsListForGrid;
	}
	
	
	@SuppressWarnings("resource")
	public List<AssetInstanceVersion> getFinalResultForBrowseGridAttributeSheeetWithFilter(Connection con, Long assetId , String assetName,boolean flag,boolean flagForUser,StringBuffer staticParam,StringBuffer nonStaticParam,String userName,boolean authorityFlag,String value){

		log.trace("getFinalResultForBrowseGridAttributeSheeet : begin");

		List<AssetInstanceVersion> assetAttributeList = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		StringBuffer queryStrBuffer = new StringBuffer("");
		LinkedHashMap<String,String> paramValues = null;
		List<AssetParamDef> apdList = new ArrayList<AssetParamDef>();
		AssetInstanceVersionDao assetInstVerDao = new AssetInstanceVersionDao();
		String assetInstanceVersionId = "";
		String tempTableName1 = null;
		String tempTableName2 = null;
		String tempTableName3 = null;
		StringBuilder richtextFinalRes = null;
		StringBuilder ldapMappingFinalRes = null;
		PreparedStatement preparedStmt1 = null;
		try{
			assetAttributeList = new ArrayList<AssetInstanceVersion>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridAttributeSheeet : " + Constants.LOG_CONNECTION_OPEN);
			}
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();

			//get global setting setting details
			if (log.isTraceEnabled()){
				log.trace("createAssetInstance || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, con);

			String modifiedvalue = "";
			if (value.contains("'")){
				modifiedvalue = value;
				modifiedvalue = modifiedvalue.replace("'", "\\'");
			}else{
				modifiedvalue = value;
			}
//			preparedStmt.setString(Constants.TWO, value);
			String descriptionvalue = "";
			if (value.contains("&")||value.contains("'")||value.contains("<")||value.contains(">")||value.contains("\"")){
				descriptionvalue = value;
				descriptionvalue = descriptionvalue.replace("&", "&amp;");
				descriptionvalue = descriptionvalue.replace("'", "&#39;");
				descriptionvalue = descriptionvalue.replace("<", "&lt;");
				descriptionvalue = descriptionvalue.replace(">", "&gt;");
				descriptionvalue = descriptionvalue.replace("\"", "&quot;");
			}else{
				descriptionvalue = value;
			}
			
			if(flag){
				//create
				tempTableName1 = "table"+userName+System.currentTimeMillis();
				queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");

				if(nonStaticParam.length() !=0){

					if(userName.equalsIgnoreCase("roleAnonymous")){
						queryStrBuffer.append("SELECT distinct a.vid,a.created_on, a.instname, a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,isstatic,staticval,"
								+ "paramtypeid,apdfilename,derivedattributecomputation,derivedassetlist,a.versionable,b.assetInstParamId from ( SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description , ad.versionable as versionable from asset_def ad JOIN asset_instance ai On ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id WHERE asset_name='"+assetName+"' AND ad.guest_flag=1 AND ai.public_access=1 ORDER BY "
								+ "ai.asset_inst_name)a LEFT OUTER JOIN ( SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname,"
								+ "aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname, pv.value as value, pv.ldap_attribute_id, pv.filename as pvfileName,"
								+ "apd.is_static as isstatic, apd.static_val as staticval, apd.param_type_id as paramtypeid, apd.derived_computed_description "
								+ "as derivedattributecomputation, apd.derived_asset_list as derivedassetlist,apd.filename as apdfilename,aip.asset_inst_param_id as assetInstParamId from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN "
								+ "asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='Guest' AND  "
								+ "ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"')GROUP BY vid,apname)b ON a.vid=b.vid where a.instname like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.vid like CONCAT('%','"+modifiedvalue+"','%') order By a.instname,a.versionname;");
					}else{
						if(flagForUser){ // admin users
							queryStrBuffer.append("SELECT a.vid,a.created_on,a.instname,a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,staticVal,"
									+"staticFilename,isStatic,paramtypeId,derivedattibuteandComputation,derivedassetlist,a.versionable,b.assetInstParamId from( SELECT aiv.asset_instance_version_id as "
									+"vid,aiv.created_on, ai.asset_inst_name as instname,aiv.version_name as versionname, aiv.description,ad.versionable as versionable from asset_def ad JOIN " 
									+ "asset_instance ai On ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id WHERE " 
									+ "asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on," 
									+ "ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description, apd.asset_param_name as apname,"
									+ "pv.value as value, pv.ldap_attribute_id, pv.fileName as pvfileName, apd.fileName as staticFilename, apd.static_val as staticVal," 
									+"apd.is_static as isStatic, apd.param_type_id as paramtypeId, apd.derived_computed_description as derivedattibuteandComputation,apd.derived_asset_list as derivedassetlist,aip.asset_inst_param_id as assetInstParamId from "
									+ "asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON "
									+ "ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN "
									+ "asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN parameter_values pv ON "
									+ "aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"+assetName+"' AND "
									+ "FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"'))b ON a.vid=b.vid where a.instname like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.vid like CONCAT('%','"+modifiedvalue+"','%') order By a.instname,a.versionname;");
						}else{
							queryStrBuffer.append("SELECT a.vid,a.created_on, a.instname, a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,isStatic,staticVal,paramtypeId,"
									+ "staticfileName,derivedattributecomputation,derivedassetlist,a.versionable,b.assetInstParamId from (SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname," 
									+"aiv.version_name as versionname, aiv.description , ad.versionable as versionable from asset_def ad JOIN asset_instance ai On ad.asset_id=ai.asset_id JOIN "
									+"asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id JOIN asset_instance_version_group_access aivga ON "
									+"aiv.asset_instance_version_id=aivga.asset_instance_version_id JOIN user_groups ug ON aivga.group_id=ug.group_id JOIN profile p ON "
									+"p.user_id=ug.user_id WHERE p.user_name='"+userName+"' AND aivga.view_access=1 AND asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN "
									+"(SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description, "
									+"apd.asset_param_name as apname, pv.value as value,pv.ldap_attribute_id,pv.fileName as pvfilename,apd.fileName as staticfileName,apd.is_static as isstatic,"
									+"apd.static_val as staticval,apd.param_type_id as paramtypeid,apd.derived_computed_description as derivedattributecomputation,apd.derived_asset_list as derivedassetlist,aip.asset_inst_param_id as assetInstParamId from " 
									+"asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON "
									+"ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN " 
									+"parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON "
									+"aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN "
									+"user_groups ug ON acg.group_id=ug.group_id JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN "
									+"profile p ON ug.user_id=p.user_id WHERE p.user_name='"+userName+"' AND ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"') GROUP BY " 
									+ "vid,apname,value)b ON a.vid=b.vid where a.instname like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.vid like CONCAT('%','"+modifiedvalue+"','%') order By a.instname,a.versionname;");
						}
					}
				}if(staticParam.length() != 0){
					String[] strArray = staticParam.toString().split(",");
					
					AssetParamDef apd = null;
					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'"); 
						preparedStmt = con.prepareStatement(queryStBuff.toString());
						rs = preparedStmt.executeQuery();
						while(rs.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(rs.getLong("asset_param_id"));
							apd.setAssetParamName(rs.getString("asset_param_name"));
							apd.setIs_static(rs.getInt("is_static"));
							apd.setStaticValue(rs.getString("static_val"));
							apd.setParamTypeId(rs.getLong("param_type_id"));
							apd.setFileName(rs.getString("fileName"));
							apdList.add(apd);
						}
					}
				}
			}else{
				if(staticParam.length() !=0){
					if(nonStaticParam.length() ==0){
						//create
						tempTableName1 = "table"+userName+System.currentTimeMillis();
						queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
						if(userName.equalsIgnoreCase("roleAnonymous")){
							queryStrBuffer.append("SELECT distinct aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN " 
									+"asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
									+"ad.asset_name='"+assetName+"' and ai.public_access=1 and (ai.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or aiv.description like CONCAT('%','"+descriptionvalue+"','%') or aiv.asset_instance_version_id like CONCAT('%','"+modifiedvalue+"','%')) order By ai.asset_inst_name,aiv.version_name;");
						}else{
							if(flagForUser){//admin users
								queryStrBuffer.append("SELECT distinct aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN " 
										+"asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE " 
										+"ad.asset_name='"+assetName+"' and (ai.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or aiv.description like CONCAT('%','"+descriptionvalue+"','%') or aiv.asset_instance_version_id like CONCAT('%','"+modifiedvalue+"','%')) order By ai.asset_inst_name,aiv.version_name;");
							}else{ // non admin users
								queryStrBuffer.append("SELECT distinct aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from group_details gd ,"
										+"asset_instance_version_group_access aivga,user_groups ug,profile p,asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN " 
										+"asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE ad.asset_name='"+assetName+"' and p.user_name='"+userName+"' and " 
										+"p.user_id=ug.user_id and aivga.asset_instance_version_id=aiv.asset_instance_version_id and aivga.group_id=gd.group_id and "
										+"ug.group_id=gd.group_id and aivga.view_access=1 and (ai.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or aiv.description like CONCAT('%','"+descriptionvalue+"','%') or aiv.asset_instance_version_id like CONCAT('%','"+modifiedvalue+"','%')) order By ai.asset_inst_name,aiv.version_name");
							}
						}
					}

					String[] strArray = staticParam.toString().split(",");

					AssetParamDef apd = null;
					for(String str : strArray){
						StringBuffer queryStBuff = new StringBuffer("Select * from asset_category_def acd left outer join asset_param_def apd on acd.asset_category_id = apd.asset_category_id left outer join asset_def ad on ad.asset_id = acd.asset_id where apd.asset_param_name = '"+str+"' and ad.asset_id='"+assetId+"'"); 
						preparedStmt = con.prepareStatement(queryStBuff.toString());
						rs = preparedStmt.executeQuery();
						while(rs.next()){
							apd = new AssetParamDef();
							apd.setAssetParamId(rs.getLong("asset_param_id"));
							apd.setAssetParamName(rs.getString("asset_param_name"));
							apd.setIs_static(rs.getInt("is_static"));
							apd.setStaticValue(rs.getString("static_val"));
							apd.setParamTypeId(rs.getLong("param_type_id"));
							apd.setFileName(rs.getString("fileName"));
							apdList.add(apd);
						}
					}
				}
			}
			
			if(staticParam.length() == 0){
				
				//create
				tempTableName1 = "table"+userName+System.currentTimeMillis();
				queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
				
				if(nonStaticParam.length() ==0){
					//create
					tempTableName1 = "table"+userName+System.currentTimeMillis();
					queryStrBuffer = new StringBuffer("Create table "+tempTableName1+" as ");
					if(userName.equalsIgnoreCase("roleAnonymous")){
						queryStrBuffer.append("SELECT distinct aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN " 
								+"asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE "
								+"ad.asset_name='"+assetName+"' and ai.public_access=1 and (ai.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or aiv.description like CONCAT('%','"+descriptionvalue+"','%') or aiv.asset_instance_version_id like CONCAT('%','"+modifiedvalue+"','%')) order By ai.asset_inst_name,aiv.version_name;");
					}else{
						if(flagForUser){//admin users
							queryStrBuffer.append("SELECT distinct aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from asset_def ad JOIN " 
									+"asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE " 
									+"ad.asset_name='"+assetName+"' and (ai.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or aiv.description like CONCAT('%','"+descriptionvalue+"','%') or aiv.asset_instance_version_id like CONCAT('%','"+modifiedvalue+"','%')) order By ai.asset_inst_name,aiv.version_name;");
						}else{ // non admin users
							queryStrBuffer.append("SELECT distinct aiv.asset_instance_version_id as vid,aiv.created_on,ai.asset_inst_name as instname,aiv.version_name as versionname,aiv.description as description,ad.versionable as versionable from group_details gd ,"
									+"asset_instance_version_group_access aivga,user_groups ug,profile p,asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN " 
									+"asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id WHERE ad.asset_name='"+assetName+"' and p.user_name='"+userName+"' and " 
									+"p.user_id=ug.user_id and aivga.asset_instance_version_id=aiv.asset_instance_version_id and aivga.group_id=gd.group_id and "
									+"ug.group_id=gd.group_id and aivga.view_access=1 and (ai.asset_inst_name like CONCAT('%','"+modifiedvalue+"','%') or aiv.description like CONCAT('%','"+descriptionvalue+"','%') or aiv.asset_instance_version_id like CONCAT('%','"+modifiedvalue+"','%')) order By ai.asset_inst_name,aiv.version_name");
						}
					}
				}else{

					if(userName.equalsIgnoreCase("roleAnonymous")){
						queryStrBuffer.append("SELECT distinct a.vid,a.created_on, a.instname, a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,isstatic,staticval,"
								+ "paramtypeid,apdfilename,derivedattributecomputation,derivedassetlist,a.versionable,b.assetInstParamId from ( SELECT aiv.asset_instance_version_id as vid, ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description , ad.versionable as versionable from asset_def ad JOIN asset_instance ai On ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id WHERE asset_name='"+assetName+"' AND ad.guest_flag=1 AND ai.public_access=1 ORDER BY "
								+ "ai.asset_inst_name)a LEFT OUTER JOIN ( SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname,"
								+ "aiv.version_name as versionname,aiv.description, apd.asset_param_name as apname, pv.value as value,pv.ldap_attribute_id, pv.filename as pvfileName,"
								+ "apd.is_static as isstatic, apd.static_val as staticval, apd.param_type_id as paramtypeid, apd.derived_computed_description "
								+ "as derivedattributecomputation, apd.derived_asset_list as derivedassetlist,apd.filename as apdfilename,aip.asset_inst_param_id as assetInstParamId from asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN "
								+ "asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups ag ON apd.asset_category_id=ag.category_id JOIN user_groups ug ON ag.group_id=ug.group_id JOIN group_details gd on ug.group_id=gd.group_id WHERE gd.group_name='Guest' AND  "
								+ "ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"')GROUP BY vid,apname)b ON a.vid=b.vid where a.instname like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.vid like CONCAT('%','"+modifiedvalue+"','%') order By a.instname,a.versionname;");
					}else{
						if(flagForUser){ // admin users
							queryStrBuffer.append("SELECT a.vid,a.created_on, a.instname,a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,staticVal,"
									+"staticFilename,isStatic,paramtypeId,derivedattibuteandComputation,derivedassetlist,a.versionable,b.assetInstParamId from( SELECT aiv.asset_instance_version_id as "
									+"vid,aiv.created_on, ai.asset_inst_name as instname,aiv.version_name as versionname, aiv.description,ad.versionable as versionable from asset_def ad JOIN " 
									+ "asset_instance ai On ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id WHERE " 
									+ "asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN (SELECT aiv.asset_instance_version_id as vid,aiv.created_on," 
									+ "ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description, apd.asset_param_name as apname,"
									+ "pv.value as value,pv.ldap_attribute_id, pv.fileName as pvfileName, apd.fileName as staticFilename, apd.static_val as staticVal," 
									+"apd.is_static as isStatic, apd.param_type_id as paramtypeId, apd.derived_computed_description as derivedattibuteandComputation,apd.derived_asset_list as derivedassetlist,aip.asset_inst_param_id as assetInstParamId from "
									+ "asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON "
									+ "ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aiv.asset_instance_version_id=aip.asset_inst_version_id JOIN "
									+ "asset_param_def apd ON aip.asset_param_id=apd.asset_param_id JOIN parameter_values pv ON "
									+ "aip.asset_inst_param_id=pv.asset_inst_param_id WHERE ad.asset_name='"+assetName+"' AND "
									+ "FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"'))b ON a.vid=b.vid where a.instname like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.vid like CONCAT('%','"+modifiedvalue+"','%') order By a.instname,a.versionname;");
						}else{
							queryStrBuffer.append("SELECT a.vid,a.created_on, a.instname, a.versionname, a.description, b.apname, b.value,b.ldap_attribute_id,pvfileName,isStatic,staticVal,paramtypeId,"
									+ "staticfileName,derivedattributecomputation,derivedassetlist,a.versionable,b.assetInstParamId from (SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname," 
									+"aiv.version_name as versionname, aiv.description , ad.versionable as versionable from asset_def ad JOIN asset_instance ai On ad.asset_id=ai.asset_id JOIN "
									+"asset_instance_versions aiv On ai.asset_inst_id=aiv.asset_instance_id JOIN asset_instance_version_group_access aivga ON "
									+"aiv.asset_instance_version_id=aivga.asset_instance_version_id JOIN user_groups ug ON aivga.group_id=ug.group_id JOIN profile p ON "
									+"p.user_id=ug.user_id WHERE p.user_name='"+userName+"' AND aivga.view_access=1 AND asset_name='"+assetName+"' ORDER BY ai.asset_inst_name)a LEFT OUTER JOIN "
									+"(SELECT aiv.asset_instance_version_id as vid,aiv.created_on, ai.asset_inst_name as instname, aiv.version_name as versionname, aiv.description, "
									+"apd.asset_param_name as apname, pv.value as value,pv.ldap_attribute_id,pv.fileName as pvfilename,apd.fileName as staticfileName,apd.is_static as isstatic,"
									+"apd.static_val as staticval,apd.param_type_id as paramtypeid,apd.derived_computed_description as derivedattributecomputation,apd.derived_asset_list as derivedassetlist,aip.asset_inst_param_id as assetInstParamId from " 
									+"asset_def ad JOIN asset_instance ai ON ad.asset_id=ai.asset_id JOIN asset_instance_versions aiv ON "
									+"ai.asset_inst_id=aiv.asset_instance_id JOIN asset_inst_params aip ON aip.asset_inst_version_id=aiv.asset_instance_version_id JOIN " 
									+"parameter_values pv ON aip.asset_inst_param_id=pv.asset_inst_param_id JOIN asset_param_def apd ON "
									+"aip.asset_param_id=apd.asset_param_id JOIN assetcategory_groups acg ON apd.asset_category_id=acg.category_id JOIN "
									+"user_groups ug ON acg.group_id=ug.group_id JOIN group_details gd ON acg.group_id=gd.group_id AND ug.group_id=gd.group_id JOIN "
									+"profile p ON ug.user_id=p.user_id WHERE p.user_name='"+userName+"' AND ad.asset_name='"+assetName+"' AND FIND_IN_SET (apd.asset_param_name,'"+nonStaticParam+"') GROUP BY " 
									+ "vid,apname,value)b ON a.vid=b.vid where a.instname like CONCAT('%','"+modifiedvalue+"','%') or a.description like CONCAT('%','"+descriptionvalue+"','%') or a.vid like CONCAT('%','"+modifiedvalue+"','%') order By a.instname,a.versionname;");
						}
					}
				}
				
			}
			
						
			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp1data = "CREATE INDEX vid ON "+tempTableName1+" (vid)" ;
			
			preparedStmt1 = con.prepareStatement(temp1data.toString());
			preparedStmt1.executeUpdate();
			
			tempTableName2 = "table"+userName+System.currentTimeMillis();
			queryStrBuffer = new StringBuffer("Create table "+tempTableName2+"(avd INT,grouppath TEXT)");

			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp2data = "CREATE INDEX avd ON "+tempTableName2+" (avd)" ;
			
			preparedStmt1 = con.prepareStatement(temp2data.toString());
			preparedStmt1.executeUpdate();
			
			String storedProcedure = "{call getAssetAttributes(?,?,?,?,?)}";
			CallableStatement callableStatement = con.prepareCall(storedProcedure);
			callableStatement.setString(1, assetName);
			callableStatement.setString(2, userName);
			callableStatement.setBoolean(3, authorityFlag);
			callableStatement.setString(4, tempTableName2);
			callableStatement.registerOutParameter(5, java.sql.Types.VARCHAR);
			callableStatement.execute();

			tempTableName3 = "table"+userName+System.currentTimeMillis();
			queryStrBuffer = new StringBuffer("Create table "+tempTableName3+" as ");

			queryStrBuffer.append("select aiv.asset_instance_version_id as vid,"
					+ "ai.asset_inst_name as instname,group_concat(tg.tag_name) as tagname from asset_def ad JOIN "
					+ "asset_instance ai ON ad.asset_id=ai.asset_id JOIN "
					+ "asset_instance_versions aiv ON ai.asset_inst_id=aiv.asset_instance_id LEFT OUTER JOIN "
					+ "tagging_master tg ON aiv.asset_instance_version_id=tg.asset_instance_version_id WHERE "
					+ "ad.asset_name='"+assetName+"' GROUP BY vid;");
			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			preparedStmt.executeUpdate();

			String temp3data = "CREATE INDEX vid ON "+tempTableName3+" (vid)" ;
			
			preparedStmt1 = con.prepareStatement(temp3data.toString());
			preparedStmt1.executeUpdate();
			
			
			if(flag){
				queryStrBuffer = new StringBuffer("select p.vid,p.created_on,p.instname,p.description,p.apname,p.versionname,p.pvfileName,p.staticVal,p.isStatic,p.paramtypeId,p.staticFilename,"
						+ "p.value,p.ldap_attribute_id,p.assetInstParamId,group_concat(DISTINCT(t.grouppath)) as taxname,group_concat(DISTINCT(tg.tagname)) as tagname,p.versionable from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.vid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.vid=tg.vid group by vid,p.apname,p.value ORDER BY p.vid; ");
			}else{
				queryStrBuffer = new StringBuffer("select p.vid,p.created_on,p.instname,p.description,p.versionname,"
						+ "group_concat(DISTINCT(t.grouppath)) as taxname,group_concat(DISTINCT(tg.tagname)) as tagname,p.versionable from "+tempTableName1+" p LEFT OUTER JOIN "
						+ tempTableName2+" t ON p.vid=t.avd LEFT OUTER JOIN "
						+ tempTableName3+" tg ON p.vid=tg.vid group by vid ORDER BY p.vid; ");
			}

			preparedStmt = con.prepareStatement(queryStrBuffer.toString());
			rs = preparedStmt.executeQuery();
			long latestAssetInstVerId = 0L;
			AssetInstanceVersion attributeExportVo = null;
			long latestAssetInstparamId = 0L;
			long latestAssetInstLdapparamId = 0L;
			while(rs.next()){
				attributeExportVo = new AssetInstanceVersion();
				attributeExportVo.setAssetInstVersionId(rs.getLong("vid"));
				attributeExportVo.setAssetInstName(rs.getString("instname"));
				attributeExportVo.setDescription(rs.getString("description"));
				attributeExportVo.setCreatedOn(rs.getTimestamp("created_on"));
				//					
				attributeExportVo.setTaxonomyName(rs.getString("taxname"));
				attributeExportVo.setTagName(rs.getString("tagname"));
				attributeExportVo.setVersionName(rs.getString("versionname"));
				attributeExportVo.setVersionable(rs.getBoolean("versionable"));
				paramValues = new LinkedHashMap<String, String>();
				assetInstanceVersionId = rs.getString("vid");
				if(flag){
					attributeExportVo.setAssetParamName(rs.getString("apname"));
					if(rs.getInt("isStatic") == 1){
						if(rs.getInt("paramtypeId") == 3)
						{
							
							paramValues.put(rs.getString("apname"), rs.getString("staticFilename"));
						}else{
							
							paramValues.put(rs.getString("apname"), rs.getString("staticVal"));
						}
					}else{
						if(rs.getInt("paramtypeId") == 3)
						{
							paramValues.put(rs.getString("apname"), rs.getString("pvfileName"));
						}
						else if(rs.getInt("paramtypeId") == 5){
							String derivedAttrVals = assetInstVerDao.getDerivedAttributeValues(userName, assetInstanceVersionId, assetName, rs.getString("apname"), con);
							paramValues.put(rs.getString("apname"), derivedAttrVals);
						}else if(rs.getInt("paramtypeId") == 6){
							String derivedCompVal = assetInstVerDao.getDerivedComputationValues(userName, assetInstanceVersionId, assetName, rs.getString("apname"), con);
							paramValues.put(rs.getString("apname"), derivedCompVal);
						}else if(rs.getInt("paramtypeId") == 8) {//browse search export
							String derivedAssetListValue = assetInstVerDao.getDerivedAttributeForAssetListValues(userName, assetInstanceVersionId, assetName, rs.getString("apname"), con);
							paramValues.put(rs.getString("apname"), derivedAssetListValue);
						}
						else if(rs.getInt("paramtypeId") == 7 || rs.getInt("paramtypeId") == 1){
							if(latestAssetInstparamId != 0){
								if(latestAssetInstparamId == rs.getLong("assetInstParamId")){
									richtextFinalRes.append(rs.getString("value") + "~~") ;
								}else{
									richtextFinalRes = new StringBuilder(rs.getString("value") + "~~");
								}
							}else{
								richtextFinalRes = new StringBuilder(rs.getString("value") + "~~");
							}
							paramValues.put(rs.getString("apname"), richtextFinalRes.toString());
							latestAssetInstparamId = rs.getLong("assetInstParamId");
						} else if(rs.getInt("paramtypeId") == 9){
							if(latestAssetInstLdapparamId != 0){
								if(latestAssetInstLdapparamId == rs.getLong("assetInstParamId")){
									ldapMappingFinalRes.append(rs.getString("value")+"~~~~"+rs.getString("ldap_attribute_id") + "``") ;
								}else{
									ldapMappingFinalRes = new StringBuilder(rs.getString("value") +"~~~~"+rs.getString("ldap_attribute_id") + "``");
								}
							}else{
								ldapMappingFinalRes = new StringBuilder(rs.getString("value") +"~~~~"+rs.getString("ldap_attribute_id") + "``");
							}
							paramValues.put(rs.getString("apname"), ldapMappingFinalRes.toString());
							latestAssetInstLdapparamId = rs.getLong("assetInstParamId");
						} else{
							if(rs.getString("apname") != null){
							
								paramValues.put(rs.getString("apname"), rs.getString("value"));
							}
						}
					}
					if(latestAssetInstVerId != rs.getLong("vid")){
						for(AssetParamDef apd : apdList){
							if(apd.getIs_static() == 1){
								if(apd.getParamTypeId() == 3){

									paramValues.put(apd.getAssetParamName(), apd.getFileName());
								}else{
									paramValues.put(apd.getAssetParamName(), apd.getStaticValue());
								}
							}
						}
					}
				}else{
					for(AssetParamDef apd : apdList){
						if(apd.getParamTypeId() == 3){
							paramValues.put(apd.getAssetParamName(), apd.getFileName());
						}else{
							paramValues.put(apd.getAssetParamName(), apd.getStaticValue());
						}
					}
				}

				attributeExportVo.setParamNamewithvalue(new TreeMap<String,String>(paramValues));
				assetAttributeList.add(attributeExportVo);

				latestAssetInstVerId = rs.getLong("vid");
				
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridAttributeSheeet : "+queryStrBuffer.toString());
			}

			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridAttributeSheeet : "+"Drop table table1;");
			}

		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeDbConnection(conn1);
			try{
				
				if(null != tempTableName1){
					preparedStmt = con.prepareStatement("Drop table IF EXISTS "+tempTableName1);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName2){
					
					preparedStmt = con.prepareStatement("Drop table IF EXISTS "+tempTableName2);
					preparedStmt.executeUpdate();
				}
				
				if(null != tempTableName3){
					preparedStmt = con.prepareStatement("Drop table IF EXISTS "+tempTableName3);
					preparedStmt.executeUpdate();
				}

				DBConnection.closeResultSet(rs);
				DBConnection.closePreparedStatement(preparedStmt);
				DBConnection.closePreparedStatement(preparedStmt1);
				if (log.isTraceEnabled()) {
					log.trace("getFinalResultForBrowseGridAttributeSheeet : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn1);
			}catch(SQLException e){
				if (log.isErrorEnabled()) {
					log.error("getFinalResultForBrowseGridAttributeSheeet : " + e.getMessage());
				}
				e.printStackTrace();
			}
		}	
		log.trace("getFinalResultForBrowseGridAttributeSheeet : End");
		return assetAttributeList;
	}
	
	
	public List<AssetInstRelationship> getFinalResultForBrowseGridSearchRelationshipSheeet(Connection con,String assetName,String userName, boolean accessFlag , String value){

		log.trace("getFinalResultForBrowseGridRelationshipSheeet : begin");
		ArrayList<AssetInstRelationship> al = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		try{
			al = new ArrayList<AssetInstRelationship>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridSearchRelationshipSheeet : " + Constants.LOG_CONNECTION_OPEN);
			}

			if(accessFlag){
				preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_BROWSEGRID_SEARCH));
				preparedStmt.setString(Constants.ONE, assetName);
				preparedStmt.setString(Constants.TWO, value);
				preparedStmt.setString(Constants.THREE, value);
				preparedStmt.setString(Constants.FOUR, value);
			}else{
				preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_BROWSEGRID_SEARCH_NON_ADMIN));
				preparedStmt.setString(Constants.ONE, assetName);
				preparedStmt.setString(Constants.TWO, userName);
				preparedStmt.setString(Constants.THREE, value);
				preparedStmt.setString(Constants.FOUR, value);
				preparedStmt.setString(Constants.FIVE, value);
			}
			rs = preparedStmt.executeQuery();
			AssetInstRelationship assetInsRel = null;
			while(rs.next()){
				assetInsRel = new AssetInstRelationship();
				assetInsRel.setSrcAssetName(rs.getString("src_asset"));
				assetInsRel.setSrcAssetId(rs.getLong("src_id"));
				assetInsRel.setSourceInstanceName(rs.getString("src_instname"));
				assetInsRel.setSourceVersionName(rs.getString("src_versioname"));
				assetInsRel.setSourceDescription(rs.getString("src_description"));
				assetInsRel.setType(rs.getString("type"));
				assetInsRel.setRelationShipName(rs.getString("relatiname"));
				assetInsRel.setDestAssetName(rs.getString("destassetname"));
				assetInsRel.setDestAssetId(rs.getLong("dest_id"));
				assetInsRel.setDestInstanceName(rs.getString("destinstname"));
				assetInsRel.setDestInstanceVersionName(rs.getString("destversioname"));
				assetInsRel.setDestdescription(rs.getString("destdescription"));
				al.add(assetInsRel);
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridSearchRelationshipSheeet : "+PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForBrowseGridSearchRelationshipSheeet : " + Constants.LOG_CONNECTION_CLOSE);
			}
		}	
		return al;
	}
	
	
	public List<AssetInstRelationship> getFinalResultForCreateFilterSearchRelationshipSheeet(Connection con,String assetName,List<AssetInstance> assetInstanceList,String userName, String value){

		log.trace("getFinalResultForCreateFilterSearchRelationshipSheeet : begin");
		ArrayList<AssetInstRelationship> al = null;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		try{
			AssetInstRelationship assetInsRel = null;
			al = new ArrayList<AssetInstRelationship>();
			if(con == null){
				conn1 = DBConnection.getInstance().getConnection();
				con = conn1; 
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForCreateFilterSearchRelationshipSheeet : " + Constants.LOG_CONNECTION_OPEN);
			}
			
			for(AssetInstance ai : assetInstanceList){
				if(userName.equalsIgnoreCase("admin")){
					preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER_SEARCH));
					preparedStmt.setString(Constants.ONE, assetName);
					preparedStmt.setLong(Constants.TWO, ai.getAssetInstVersionId());
					preparedStmt.setLong(Constants.THREE, ai.getAssetInstVersionId());
					preparedStmt.setLong(Constants.FOUR, ai.getAssetInstVersionId());
					preparedStmt.setLong(Constants.FIVE, ai.getAssetInstVersionId());
				}else{
					preparedStmt = con.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER_SEARCH_NON_ADMIN));
					preparedStmt.setString(Constants.ONE, assetName);
					preparedStmt.setString(Constants.TWO, userName);
					preparedStmt.setLong(Constants.THREE, ai.getAssetInstVersionId());
					preparedStmt.setLong(Constants.FOUR, ai.getAssetInstVersionId());
					preparedStmt.setLong(Constants.FIVE, ai.getAssetInstVersionId());
					preparedStmt.setLong(Constants.SIX, ai.getAssetInstVersionId());
				}
				rs = preparedStmt.executeQuery();
				while(rs.next()){
					assetInsRel = new AssetInstRelationship();
					assetInsRel.setSrcAssetName(rs.getString("src_asset"));
					assetInsRel.setSrcAssetId(rs.getLong("src_id"));
					assetInsRel.setSourceInstanceName(rs.getString("src_instname"));
					assetInsRel.setSourceVersionName(rs.getString("src_versioname"));
					assetInsRel.setSourceDescription(rs.getString("src_description"));
					assetInsRel.setType(rs.getString("type"));
					assetInsRel.setRelationShipName(rs.getString("relatiname"));
					assetInsRel.setDestAssetName(rs.getString("destassetname"));
					assetInsRel.setDestAssetId(rs.getLong("dest_id"));
					assetInsRel.setDestInstanceName(rs.getString("destinstname"));
					assetInsRel.setDestInstanceVersionName(rs.getString("destversioname"));
					assetInsRel.setDestdescription(rs.getString("destdescription"));
					al.add(assetInsRel);
				}
			}
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForCreateFilterSearchRelationshipSheeet : "+PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCE_RELATIONSHIPS));
			}
		}catch(IOException ioe){
			ioe.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getFinalResultForCreateFilterSearchRelationshipSheeet : " + Constants.LOG_CONNECTION_CLOSE);
			}
		}	
		return al;
	}
}
