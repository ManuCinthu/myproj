package com.thbs.repopro.util;

import java.util.List;

import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.exception.RepoproException;

public interface NotificationInterface{

	public String notifyOnParameterValueChanges(List<AssetInstanceVersion> parameterDetails)throws RepoproException;
	
	public String notifyOnParameterValueChangesBasedOnOtherParameter(List<AssetInstanceVersion> parameterDetails)throws RepoproException;
	
}
