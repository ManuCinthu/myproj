package com.thbs.repopro.util;

import java.security.Key;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class EncryptPassword {

	public String encryptPassword(String password) {
		String encryptedPassword = null;
		try {
			/*
			 * Encrypting the password
			 */
			final String ALGO = "AES";
			final byte[] keyValue = new byte[] { 'T', 'h', 'e', 'B', 'e', 's',
					't', 'S', 'e', 'c', 'r', 'e', 't', 'K', 'e', 'y' };
			Key key = new SecretKeySpec(keyValue, ALGO);
			
			Cipher c = Cipher.getInstance(ALGO);
			c.init(Cipher.ENCRYPT_MODE, key);
			byte[] encVal = c.doFinal(password.getBytes());
			encryptedPassword = Base64.getEncoder().encodeToString(encVal);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return encryptedPassword;
	}

	public boolean isNull(String string) {
		// TODO Auto-generated method stub
		return false;
	}
}
