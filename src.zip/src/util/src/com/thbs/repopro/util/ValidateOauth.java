package com.thbs.repopro.util;

public interface ValidateOauth {
	/**
	 * Implement this function for validating the 
	 * access token
	 */
	public String validateAccessToken(String accessToken);
}
