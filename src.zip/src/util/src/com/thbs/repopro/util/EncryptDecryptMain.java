package com.thbs.repopro.util;

import java.util.ArrayList;
import java.util.List;

public class EncryptDecryptMain{
	public static void main(String args[]){
		long input = 12;
		
		System.out.println("Input : "+input);
		
		List<String> test = new ArrayList<String>();
			EncryptKeys encryptKeys = new EncryptKeys();
			String encryptedStr = encryptKeys.encryptKey(input);
			String getStr = encryptKeys.randomSubscriptionKey();
			
			long res = encryptKeys.decryptKey("9404000018000170");
		    
			if(!test.contains(encryptedStr)){
				test.add(encryptedStr);				
			}
			
			String encryptedStaticStr = encryptKeys.encryptStaticKey(input);
			System.out.println("encryptedStaticStr : "+encryptedStaticStr);
			
		
	}
}

