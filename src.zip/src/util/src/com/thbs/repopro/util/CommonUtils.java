package com.thbs.repopro.util;

import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.Key;
import java.sql.Connection;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;
import javax.naming.directory.DirContext;
import javax.servlet.ServletContext;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.owasp.html.HtmlPolicyBuilder;
import org.owasp.html.PolicyFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;











import org.springframework.security.core.context.SecurityContextHolder;

//import com.sun.image.codec.jpeg.JPEGCodec;
//import com.sun.image.codec.jpeg.JPEGEncodeParam;
//import com.sun.image.codec.jpeg.JPEGImageEncoder;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstParams;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.AssetRelationshipDef;
import com.thbs.repopro.dto.GamificationDetails;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.LdapMapping;
import com.thbs.repopro.dto.NameValue;
import com.thbs.repopro.dto.ParameterValues;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.gamification.GamificationDao;
import com.thbs.repopro.ldap.LDAPConnection;
import com.thbs.repopro.ldap.LDAPUser;
import com.thbs.repopro.ldap.LDAPUtility;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.relationship.RelationshipDao;

public class CommonUtils {

	public static String LdapHost = "";
    public static String LdapPort = "";
	
	public static String LdapAuthenticationType = "";
	
	public static String LdapBaseDn = "";
	
	public static String LdapSearchFilter = "";
	
	public static String LdapUserId = "";
	
	public static String LdapFirstName ="";

	public static String LdapLastName ="";
	 
	public static String LdapEmail = "";
	
	public static String LdapDept ="";
	
	public static String LdapUserName = "";
	
	public static String LdapPassword = "";
	
	public static String LdapActiveDirectory = "";
	
	public static String LdapKeyRequired = "";
	
	public static String product_description = "";
	
	public static String LdapCertificateDetails = "";
	
	public static String LdapFullName = "";
	
	public static String LdapRefferal = "";
	
	public static String LdapTrustStorePassword = "";

	public static String LdapWildCardSearch = "";
	
	
	/* Start Properties read from repoPro.properties for SAML SSO */
	
	public static String trustStorePath = "";
	
	public static String trustStorePassword = "";
	
	public static String oAuthEndPoint = "";
	
	public static String clientId = "";
	
	public static String grantType = "";
	
	public static String clientSecret = "";
	
	public static String xpath = "";
	
	public static String samlAssertionFirstName = "";
	
	public static String samlAssertionLastName = "";
	
	public static String samlAssertionMailID = "";
	
	public static String samlID = "";
	
	public static String defaultDeptForSAML = "";
	
	public static String defaultFirstNameForSAML = "";
	
	public static String defaultLastNameForSAML = "";
	
	public static String defaultMailForSAML = "";
	
	public static String responseSkew = "";
	public static String encryptionKey = "";
	
	/* End Properties read from repoPro.properties for SAML SSO */
	
	public static String pluginClassName = "";
	
	public static String pluginPath = "";
	
	public static String customParameterPluginPath = "";
	
	public static String customParameterPluginNoficationClassName = "";
	
	
	static AssetDao assetDao = new AssetDao();
	RelationshipDao relationshipDao = new RelationshipDao();
	GamificationDao gamificationDao = new GamificationDao();
	Map<String, String> valMap = new LinkedHashMap<String, String>();

	Connection conn1 = null;
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );

	public String validationForDerivedAttribute(String text,String mainAssetName,String mainParamName,String oldAssetName)throws RepoproException{
		if(text == null) {
			log.warn("validationForDerivedAttribute || Derived Attribute Rule Should Not Be Null");
			return "Please Provide the Derived Attribute Rule!";
		}
		if(log.isTraceEnabled()){
			log.trace("validationForDerivedAttribute || "+ text+" Begin");
		}
		StringBuffer sb = new StringBuffer();
		Connection conn = null;
		try{
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAttribute || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AssetDao dao = new AssetDao();
			
			//parameter check whether it is used in rule --> modified by gomathi 15/03/2018
			AssetParamDef apdef = dao.getParamIdForAssetAndParamName(mainAssetName, mainParamName, conn);
			if(apdef != null){
			if(apdef.getParamTypeId()!= 5){
			List<AssetParamDef> derivedAttributes =  dao.getAllDerivedAttributes(conn);
			Pattern patternForDerivedAttribute = Pattern.compile(mainAssetName+"[\\{](?i)"+mainParamName+"[\\}]");
			Pattern patternForDerivedComputation = Pattern.compile(mainAssetName+"[\\.](?i)"+mainParamName+"(==)");
			for (AssetParamDef assetParamDef2 : derivedAttributes) {
				String rule = assetParamDef2.getDerivedAttributeComputation();
				if(assetParamDef2.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID){

					Matcher m = patternForDerivedAttribute.matcher(rule);
					if(m.find()){//destination parameter check 
						log.warn("validationForDerivedAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
					
					Matcher m1 = patternForDerivedComputation.matcher(rule);
					if(m1.find()){// source parameter check
						log.warn("validationForDerivedAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
				}
				if(assetParamDef2.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID){
					Matcher m = patternForDerivedComputation.matcher(rule);
					if(m.find()){
						log.warn("validationForDerivedAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
				}
			}
			
			List<AssetParamDef> allDerivedAttributeForAssetList = assetDao.getAllDerivedAttributeForAssetList(conn);
			Pattern patternForDerivedAssetListAttribute = Pattern.compile(mainAssetName+"[\\{](?i)"+mainParamName+"[\\}]");
			Pattern patternForDerivedAssetListAttribute1 = Pattern.compile(mainAssetName+"[\\[](?i)"+mainParamName+"[\\]]");
			
			for(AssetParamDef apd : allDerivedAttributeForAssetList) {
				String text1 = apd.getDerivedAssetListRule();
				if(apd.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)){
					
					Matcher m = patternForDerivedAssetListAttribute.matcher(text1);
					if(m.find()){//destination parameter check 
						log.warn("validationForDerivedAssetListAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
					
					Matcher m1 = patternForDerivedAssetListAttribute1.matcher(text1);
					if(m1.find()){ 
						log.warn("validationForDerivedAssetListAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
				}
			}
			}
			}
		
			
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAttribute || dao method called : getAllAssets() ");
			}
			List<AssetDef> assets =dao.getAllAssets(conn);
			boolean textFlag = text.startsWith("IF[");
			if(textFlag){
				Pattern p = Pattern.compile("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
				Matcher m = p.matcher(text);
				if(text.contains("ELSE IF[")){
					String[] splited = text.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
					if(!splited[splited.length-1].contains("IF[")){
						//ifElseIfElse splitting
						if (log.isTraceEnabled()) {
							log.trace("validationForDerivedAttribute || CommonUtils  method called : ifElseIfElseValidationForDerivedAttribute() :"+text+" assetName "+mainAssetName);
						}
						sb =ifElseIfElseValidationForDerivedAttribute(text, mainAssetName, sb,mainParamName,assets,oldAssetName);
					}else{
						if (log.isTraceEnabled()) {
							log.trace("validationForDerivedAttribute || CommonUtils  method called : ifElseIfValidationForDerivedAttribute(): "+text+" assetName "+mainAssetName);
						}
						//ifElseIf splitting
						sb =ifElseIfValidationForDerivedAttribute(text, mainAssetName, sb,mainParamName,assets,oldAssetName);
					}
				}else{
					//ifElsePattern Splitting
					String[] splited = text.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
					if(!splited[splited.length-1].contains("IF[")){
						if (log.isTraceEnabled()) {
							log.trace("validationForDerivedAttribute || called :  ifElseValidationForDerivedAttribute() : "+text+" assetName "+mainAssetName);
						}
						sb =ifElseValidationForDerivedAttribute(text, mainAssetName, sb,mainParamName,assets,oldAssetName);
					}else{
						if (log.isTraceEnabled()) {
							log.trace("validationForDerivedAttribute || called : ifRuleValidationFforDerivedAttribute() "+text+" assetName "+mainAssetName);
						}
						//if Rule valiation
						sb =ifRuleValidationFforDerivedAttribute(text, mainAssetName, sb, mainParamName,assets,oldAssetName);
					}
				}
			}else{
				if (log.isTraceEnabled()) {
					log.trace("validationForDerivedAttribute ||  called : normalRuleValidationForDerivedAttribute() "+text+" assetName "+mainAssetName);
				}
				//normal splitting
				sb =normalRuleValidationForDerivedAttribute(text, mainAssetName, sb,mainParamName,assets,oldAssetName);
			}
		}catch(Exception e){
			log.error("validationForDerivedAttribute ||  " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAttribute || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("validationForDerivedAttribute || End");
		}
		//String text = "IF[project.type==rest]project[delivers]service.count IF[Consumer Context.type==soap]Consumer context[uses]Provider.count ELSE[Bussines.type==rest]Bussines[consumes]Applicaton.count"; 
		return sb.toString();
	}
	public  StringBuffer ifElseIfElseValidationForDerivedAttribute(String text,String mainAssetName,StringBuffer sb,String mainParamName ,List<AssetDef> listOfAssets,String oldAssetName)throws RepoproException{
		if (log.isTraceEnabled()) {
			log.trace("ifElseIfElseValidationForDerivedAttribute || "+text+" Begins");
		}
		//ifElseIfElse splitting
		String ifElseIfEslePattern = "^((IF)"   //IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}][\\s]*[\\n]?)"
				+ "((ELSE IF)"           //ELSE IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}][\\s]*[\\n]?)+"
				+ "((ELSE)[\\s]"             //ELSE Condition
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}])?$";
		Pattern p = Pattern.compile(ifElseIfEslePattern);
		Matcher m =p.matcher(text);
		List<String> macroList = new ArrayList<String>();
		macroList.add("ASSETINSTVERSIONID");
		macroList.add("ASSETINSTNAME");
		macroList.add("OVERVIEW");
		if(sb.length()==0){

			if(!m.find()){
				if (log.isTraceEnabled()) {
					log.warn("Rule Pattern is not valid!");
				}
				sb.append("Rule Pattern is not valid!");
			}

			String[] splittedData = text.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
			//trimming spaces and making all are lower case letters
			for(int i =0;i<splittedData.length;i++){
				splittedData[i] = splittedData[i].trim().toLowerCase();
			}
			int ifConditionLength = 0 ;
			int elseIfConditionLength = 0;
			//finding condition lengths
			for (int i=0;i<splittedData.length;i++) {
				if(splittedData[i].contains("else if[")){
					elseIfConditionLength++;
				}else if(splittedData[i].contains("if[")){
					ifConditionLength++;
				}
			}
			Pattern p1 = Pattern.compile("\\{([^}]*)\\}");
			Matcher m1 = p1.matcher(text);
			List<String> listOfParams = new ArrayList<String>();
			while (m1.find()) {
				listOfParams.add(m1.group(1).trim());
			}
			if(sb.length()==0){
				//spiltting if rule and validations with database
				for(int i=0;i<ifConditionLength;i++){
					String lastParamName = listOfParams.get(i);
					boolean macroFlag = false;
					String macro = "";
					//macros
					if(lastParamName.startsWith("#")){
						if(lastParamName.endsWith("#")){
							macro = lastParamName.substring(1,lastParamName.length()-1);
							//macro  =macro.toUpperCase();
							if(macroList.contains(macro)){
								macroFlag = true;

							}else{
								if(log.isTraceEnabled()){
									log.warn("Invalid Macro, please enter correct Macro!");
								}
								sb.append("Invalid Macro, please enter correct Macro!");
							}
						}else{
							if(log.isTraceEnabled()){
								log.warn("Invalid Macro, please enter correct Macro!");
							}
							sb.append("Invalid Macro, please enter correct Macro!");
						}
					}else if(lastParamName.endsWith("#")){
						if(log.isTraceEnabled()){
							log.warn("Invalid Macro, please enter correct Macro!");
						}
						sb.append("Invalid Macro, please enter correct Macro!");
					}
					if(sb.length()==0){
						List<String> ruleAssetNames = new ArrayList<String>();
						List<String> relationNames = new ArrayList<String>();
						String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
						String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
						String[] splitted = splittedData[i].split("[\\[\\]]");
						for(int k=2;k<splitted.length;k=k+2){
							ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
						}
						for(int k=3;k<splitted.length;k=k+2){
							relationNames.add(splitted[k].trim().toLowerCase());
						}
						if(log.isTraceEnabled()){
							log.trace("ifElseIfElseValidationForDerivedAttribute || calling || commonValidationForConditionalPatternForDerivedAttribute with "+ifConditionAssetName+" with param "+paramName);
						}
						sb = commonValidationForConditionalPatternForDerivedAttribute(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,lastParamName,macroFlag);
					}
				}
			}
			if(sb.length()==0){
				//spiltting else if rule and validations with database
				for(int i =ifConditionLength;i<elseIfConditionLength+ifConditionLength;i++){

					String lastParamName = listOfParams.get(i).trim();
					boolean macroFlag = false;
					String macro = "";
					//macros
					if(lastParamName.startsWith("#")){
						if(lastParamName.endsWith("#")){
							macro = lastParamName.substring(1,lastParamName.length()-1);
							//	macro  =macro.toUpperCase();
							if(macroList.contains(macro)){
								macroFlag = true;

							}else{
								if(log.isTraceEnabled()){
									log.warn("Invalid Macro, please enter correct Macro!");
								}
								sb.append("Invalid Macro, please enter correct Macro!");
							}
						}else{
							if(log.isTraceEnabled()){
								log.warn("Invalid Macro, please enter correct Macro!");
							}
							sb.append("Invalid Macro, please enter correct Macro!");
						}
					}else if(lastParamName.endsWith("#")){
						if(log.isTraceEnabled()){
							log.warn("Invalid Macro, please enter correct Macro!");
						}
						sb.append("Invalid Macro, please enter correct Macro!");
					}
					if(sb.length()==0){
						List<String> ruleAssetNames = new ArrayList<String>();
						List<String> relationNames = new ArrayList<String>();

						String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
						String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
						String[] splitted = splittedData[i].split("[\\[\\]]");
						for(int k=2;k<splitted.length;k=k+2){
							ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
						}
						for(int k=3;k<splitted.length;k=k+2){
							relationNames.add(splitted[k].trim().toLowerCase());
						}
						if (log.isTraceEnabled()) {
							log.trace("ifElseIfElseValidationForDerivedAttribute || calling || commonValidationForConditionalPatternForDerivedAttribute "+ifConditionAssetName+" with param "+paramName);
						}
						//here i need to write validations
						sb = commonValidationForConditionalPatternForDerivedAttribute(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,lastParamName,macroFlag);
					}
				}
			}	
			//spiltting else rule and validations with database
			if(sb.length()==0){
				for(int i = ifConditionLength+elseIfConditionLength;i<ifConditionLength+elseIfConditionLength+1;i++){

					String lastParamName = listOfParams.get(i);

					boolean macroFlag = false;
					String macro = "";
					//macros
					if(lastParamName.startsWith("#")){
						if(lastParamName.endsWith("#")){
							macro = lastParamName.substring(1,lastParamName.length()-1);
							//macro  =macro.toUpperCase();
							if(macroList.contains(macro)){
								macroFlag = true;

							}else{
								if(log.isTraceEnabled()){
									log.warn("Invalid Macro, please enter correct Macro!");
								}
								sb.append("Invalid Macro, please enter correct Macro!");
							}
						}else{
							if(log.isTraceEnabled()){
								log.warn("Invalid Macro, please enter correct Macro!");
							}
							sb.append("Invalid Macro, please enter correct Macro!");
						}
					}else if(lastParamName.endsWith("#")){
						if(log.isTraceEnabled()){
							log.warn("Invalid Macro, please enter correct Macro!");
						}
						sb.append("Invalid Macro, please enter correct Macro!");
					}
					if(sb.length()==0){
						List<String> ruleAssetNames = new ArrayList<String>();
						List<String> relationNames = new ArrayList<String>();

						splittedData[i] = splittedData[i].replace("else", "").trim();
						String[] splitted = splittedData[i].split("[\\[\\]]");
						for(int k=0;k<splitted.length;k=k+2){
							ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
						}
						for(int k=1;k<splitted.length;k=k+2){
							relationNames.add(splitted[k].trim().toLowerCase());
						}
						if (log.isTraceEnabled()) {
							log.trace("ifElseIfElseValidationForDerivedAttribute || calling  ||  commonValidationForConditionalPatternForDerivedAttribute()"+ruleAssetNames+" relationNames "+relationNames+" assetName "+mainAssetName);
						}
						sb = commonValidationForConditionalPatternForDerivedAttribute(null, ruleAssetNames, relationNames, null, mainAssetName,mainParamName,oldAssetName,lastParamName,macroFlag);
					}
				}
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("ifElseIfElseValidationForDerivedAttribute || Exit");
		}
		return sb;
	}

	public  StringBuffer commonValidationForConditionalPatternForDerivedAttribute(String conditionAssetName,List<String> assetNames,List<String> relationNames,String paramName,String mainAssetName,String mainParamName,String oldAssetName,String lastParamName,boolean macroFlag)throws RepoproException{
		if (log.isTraceEnabled()) {
			log.trace("commonValidationForConditionalPatternForDerivedAttribute || "+conditionAssetName+" Begins");
		}
		Connection conn = null;
		StringBuffer sb = new StringBuffer();
		//Checking assetNames in Database
		List<AssetDef> assets = null;
		if(sb.length()==0){
			List<String> lowerCaseNames=null;
			try {
				if(log.isTraceEnabled()){
					log.trace("commonValidationForConditionalPatternForDerivedAttribute || dao method calling || getAllAssets" );
				}
				assets = assetDao.getAllAssets(conn);
			} catch (RepoproException e) {
				e.printStackTrace();
			}
			lowerCaseNames = new ArrayList<String>();

			for (int i = 0; i < assets.size(); i++) {
				String name =assets.get(i).getAssetName();
				name=name.toLowerCase().trim(); 
				lowerCaseNames.add(name);
			}
			if(sb.length()==0){
				for(int i=0;i<assetNames.size();i++){
					String name=assetNames.get(i);
					name=name.toLowerCase().trim();
					if(!lowerCaseNames.contains(name)){
						sb.append(assetNames.get(i)+",");
					}
				}
				if(sb.length()!=0){
					sb.deleteCharAt(sb.length()-1);
					if(log.isTraceEnabled()){
						log.warn("Asset/Assets not available in the repository!");
					}
					sb.append(" Asset/Assets not available in the repository!");
				}
			}
			if(sb.length()==0){
				if(mainAssetName!=null){
					if(!mainAssetName.trim().equalsIgnoreCase(assetNames.get(0).trim())){
						if(log.isTraceEnabled()){
							log.warn("Relation rule should be start with current asset!");
						}
						sb.append("Relation rule should be start with current asset!");
					}
				}
				if(sb.length()==0){
					if(conditionAssetName!=null){
						if(!conditionAssetName.trim().equalsIgnoreCase(assetNames.get(0).trim())){
							if(log.isTraceEnabled()){
								log.warn("Condition asset should be same as current asset!");
							}
							sb.append("Condition asset should be same as current asset!");
						}
					}
					if(mainParamName!=null){
						if(mainParamName.trim().equalsIgnoreCase(paramName)){
							if(log.isTraceEnabled()){
								log.warn(paramName+" : current parameter name can not used!");
							}
							sb.append(paramName+" : current parameter name can not used!");
						}
						
					}
				}
			}
			int firstName = 0;
			int lastAssetName = 1;
			int relatioName=0;
			for(int i =0;i<relationNames.size();i++){
				String srcAssetName = assetNames.get(firstName);
				String relationName = relationNames.get(relatioName);
				String destAssetName= assetNames.get(lastAssetName);
				boolean relFlag = false;
				if(!srcAssetName.equalsIgnoreCase(destAssetName)){
					relFlag = relationName.contains("^");
				}
				if(relFlag){
					if(log.isTraceEnabled()){
						log.warn("Rule Pattern is Invalid");
					}
					sb.append("Rule Pattern is Invalid");
					break;
				}
				firstName++;
				lastAssetName++;
				relatioName++;
			}

		}
		//Checking relationNames in Database
		if(sb.length()==0){
			List<String> lowerCaseRelationNames = null;
			lowerCaseRelationNames =new ArrayList<String>();
			List<AssetRelationshipDef> allRelationNames = null;
			try {
				if(log.isTraceEnabled()){
					log.trace("commonValidationForConditionalPatternForDerivedAttribute || dao called || getAllAssetRelationshipDef()");
				}
				allRelationNames = relationshipDao.getAllAssetRelationshipDef(conn);
			} catch (RepoproException e) {
				e.printStackTrace();
			}

			for (int i = 0; i < allRelationNames.size(); i++) {
				String relationName = allRelationNames.get(i).getDescription();
				lowerCaseRelationNames.add(relationName.toLowerCase().trim());
			}
			for (int i = 0; i < relationNames.size(); i++) {
				String relationName = relationNames.get(i);
				boolean relFlag = relationName.contains("^");
				if(relFlag){
					relationName = relationName.substring(1, relationName.length());
				}
				if(!lowerCaseRelationNames.contains(relationName))
					sb.append(relationNames.get(i)+",");
			}
			if(sb.length()!=0){
				sb.deleteCharAt(sb.length()-1);
				if(log.isTraceEnabled()){
					log.warn(" relationship name(s) not availble in the repository!");
				}
				sb.append(" relationship name(s) not availble in the repository!");
			}
		}
		//checking param is available in last AssetName or not 
		if(paramName!=null||conditionAssetName!=null){
			if(sb.length()==0){
				if(log.isTraceEnabled()){
					log.trace("commonValidationForConditionalPatternForDerivedAttribute || dao called || retParamIdForAssetAndParamName() with conditionAssetName "+conditionAssetName+" paramName "+paramName);
				}
				AssetParamDef paramDetails = assetDao.retParamIdForAssetAndParamName(conditionAssetName, paramName,conn);
				boolean flag =false;
				if(paramDetails!=null){
					if(paramDetails.getAssetParamName().toLowerCase().equalsIgnoreCase(paramName)){
						flag=true;
						if(paramDetails.isHasStaticValue()){
							if(log.isTraceEnabled()){
								log.warn("Static parameter should not allowed!");
							}
							sb.append("Static parameter should not allowed!");
						}else{
							if(paramDetails.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID||paramDetails.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID || paramDetails.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)){
								if(log.isTraceEnabled()){
									log.warn(paramName+" : derived parameters not allowed!");
								}
								sb.append(paramName+" : derived parameters not allowed!");
							}
						}
					}
				}else{
					flag = false;
				}
				if(!flag){
					if(log.isTraceEnabled()){
						log.warn(paramName+" is not available under "+conditionAssetName+" Asset!");
					}
					sb.append(paramName+" is not available under "+conditionAssetName+" Asset!");
				}

			}
		}
		if(!macroFlag){
			String lastAssetNames = assetNames.get(assetNames.size()-1);

			if(lastParamName!=null||lastAssetNames!=null){
				if(sb.length()==0){
					if(log.isTraceEnabled()){
						log.trace("commonValidationForConditionalPatternForDerivedAttribute || dao called || retParamIdForAssetAndParamName() with "+lastAssetNames+" param "+lastParamName);
					}
					AssetParamDef paramDetails = assetDao.retParamIdForAssetAndParamName(lastAssetNames, lastParamName,conn);
					boolean flag =false;
					if(paramDetails!=null){
						if(paramDetails.getAssetParamName().toLowerCase().equalsIgnoreCase(lastParamName)){
							flag=true;
							if(paramDetails.isHasStaticValue()){
								if(log.isTraceEnabled()){
									log.warn("Static parameter should not allowed!");
								}
								sb.append("Static parameter should not allowed!");
							}else{
								if(paramDetails.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID||paramDetails.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID || paramDetails.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)){
									if(log.isTraceEnabled()){
										log.warn(lastParamName+" : derived parameters not allowed!");
									}
									sb.append(lastParamName+" : derived parameters not allowed!");
								}
							}
						}
					}else{
						flag = false;
					}
					if(!flag){
						if(log.isTraceEnabled()){
							log.warn(lastParamName+" is not available under "+lastAssetNames+" Asset!");
						}
						sb.append(lastParamName+" is not available under "+lastAssetNames+" Asset!");
					}
				}
			}
		}
		//relationShip validation between assets
		if(sb.length()==0){
			int firstName = 0;
			int lastAssetName = 1;
			int relatioName=0;
			for(int i =0;i<relationNames.size();i++){
				String srcAssetName = assetNames.get(firstName);
				String relationName = relationNames.get(relatioName);
				boolean relFlag = relationName.contains("^");
				if(relFlag){
					relationName = relationName.substring(1, relationName.length());
				}
				String destAssetName= assetNames.get(lastAssetName);
				if(log.isTraceEnabled()){
					log.trace("commonValidationForConditionalPatternForDerivedAttribute || dao called || retAssetRelDefForAssetsByRelationName() with "+srcAssetName+" destAssetName "+destAssetName+" relationName "+relationName);
				}
				AssetRelationshipDef data =relationshipDao.retAssetRelDefForAssetsByRelationName(srcAssetName, destAssetName, relationName,conn);
				if(data==null){
					if(log.isTraceEnabled()){
						log.trace("commonValidationForConditionalPatternForDerivedAttribute || dao called || retAssetRelDefForAssetsByRelationName() with "+srcAssetName+" destAssetName "+destAssetName+" relationName "+relationName);
					}
					AssetRelationshipDef data1 =relationshipDao.retAssetRelDefForAssetsByRelationName(destAssetName, srcAssetName, relationName,conn);
					if(data1==null){
						if(log.isTraceEnabled()){
							log.warn(relationName+" relation not defined between "+destAssetName+" and "+srcAssetName+" assets");
						}
						sb.append(relationName+" relation not defined between "+destAssetName+" and "+srcAssetName+" assets");	
					}
				}
				firstName = firstName+1;
				relatioName = relatioName+1;
				lastAssetName = lastAssetName+1;
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("commonValidationForConditionalPatternForDerivedAttribute || Exit");
		}
		return sb;
	}
	public  StringBuffer ifElseIfValidationForDerivedAttribute(String text,String mainAssetName,StringBuffer sb,String mainParamName,List<AssetDef> listOfAssets,String oldAssetName)throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("ifElseIfValidationForDerivedAttribute || "+text+" Begins");
		}
		//ifElseIf splitting
		String ifElseIfPattern = "^((IF)" //IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/!~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]"
				+ "[\\s]*[\\n]?)"
				+ "((ELSE IF)"  //ELSE IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}])+$";
		Pattern p = Pattern.compile(ifElseIfPattern);
		Matcher m =p.matcher(text);
		if(!m.find()){
			if (log.isTraceEnabled()) {
				log.warn("Rule Pattern is not valid!");
			}
			sb.append("Rule Pattern is not valid!");
		}

		if(sb.length()==0){
			Pattern p1 = Pattern.compile("\\{([^}]*)\\}");
			Matcher m1 = p1.matcher(text);
			List<String> listOfParams = new ArrayList<String>();
			while (m1.find()) {
				listOfParams.add(m1.group(1).trim());
			}
			String[] splittedData = text.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");

			//trimming and making all letters are lower case
			for(int i=0;i<splittedData.length;i++){
				splittedData[i] = splittedData[i].trim().toLowerCase();
			}
			int ifLength= 0;
			int elseIfLength = 0;
			//finding length condition lengths
			for(int i=0;i<splittedData.length;i++){
				if(splittedData[i].contains("else if[")){
					elseIfLength++;
				}else{
					ifLength++;
				}
			}
			List<String> macroList = new ArrayList<String>();
			macroList.add("ASSETINSTVERSIONID");
			macroList.add("ASSETINSTNAME");
			macroList.add("OVERVIEW");
			if(sb.length()==0){
				//splitting if rule and validating with database
				for(int i=0;i<ifLength;i++){
					String lastParamName = listOfParams.get(i);
					boolean macroFlag = false;
					String macro = "";
					//macros
					if(lastParamName.startsWith("#")){
						if(lastParamName.endsWith("#")){
							macro = lastParamName.substring(1,lastParamName.length()-1);
							if(macroList.contains(macro)){
								macroFlag = true;
							}else{
								if (log.isTraceEnabled()) {
									log.warn("Invalid Macro, please enter correct Macro!");
								}
								sb.append("Invalid Macro, please enter correct Macro!");
							}
						}else{
							if (log.isTraceEnabled()) {
								log.warn("Invalid Macro, please enter correct Macro!");
							}
							sb.append("Invalid Macro, please enter correct Macro!");
						}
					}else if(lastParamName.endsWith("#")){
						if (log.isTraceEnabled()) {
							log.warn("Invalid Macro, please enter correct Macro!");
						}
						sb.append("Invalid Macro, please enter correct Macro!");
					}
					if(sb.length()==0){
						List<String> ruleAssetNames = new ArrayList<String>();
						List<String> relationNames = new ArrayList<String>();
						String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
						String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
						String[] splitted = splittedData[i].split("[\\[\\]]");
						for(int k=2;k<splitted.length;k=k+2){
							ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
						}
						for(int k=3;k<splitted.length;k=k+2){
							relationNames.add(splitted[k].trim().toLowerCase());
						}
						if(sb.length()==0){
							if (log.isTraceEnabled()) {
								log.trace("ifElseIfValidationForDerivedAttribute  || dao calling || commonValidationForConditionalPatternForDerivedAttribute() ifConditionAssetName "+ifConditionAssetName+"ruleAssetNames  "+ruleAssetNames+"relationNames "+relationNames+" mainAssetName "+mainAssetName);
							}
							sb = commonValidationForConditionalPatternForDerivedAttribute(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,lastParamName,macroFlag);
						}	
					}
				}
			}
			if(sb.length()==0){
				//splitting else if rule and validating with database
				for(int i=ifLength;i<elseIfLength+ifLength;i++){
					String lastParamName =listOfParams.get(i);
					boolean macroFlag = false;
					String macro = "";
					//macros
					if(lastParamName.startsWith("#")){
						if(lastParamName.endsWith("#")){
							macro = lastParamName.substring(1,lastParamName.length()-1);
							if(macroList.contains(macro)){
								macroFlag = true;

							}else{
								if (log.isTraceEnabled()) {
									log.warn("Invalid Macro, please enter correct Macro!");
								}
								sb.append("Invalid Macro, please enter correct Macro!");
							}
						}else{
							if (log.isTraceEnabled()) {
								log.warn("Invalid Macro, please enter correct Macro!");
							}
							sb.append("Invalid Macro, please enter correct Macro!");
						}
					}else if(lastParamName.endsWith("#")){
						if (log.isTraceEnabled()) {
							log.warn("Invalid Macro, please enter correct Macro!");
						}
						sb.append("Invalid Macro, please enter correct Macro!");
					}
					if(sb.length()==0){
						List<String> ruleAssetNames = new ArrayList<String>();
						List<String> relationNames = new ArrayList<String>();
						String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
						String paramValue= splittedData[i].substring(splittedData[i].indexOf("==")+2, splittedData[i].indexOf("]")).trim().toLowerCase();
						String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
						String[] splitted = splittedData[i].split("[\\[\\]]");
						for(int k=2;k<splitted.length;k=k+2){
							ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
						}
						for(int k=3;k<splitted.length;k=k+2){
							relationNames.add(splitted[k].trim().toLowerCase());
						}
						if(sb.length()==0){
							if (log.isTraceEnabled()) {
								log.trace("ifElseIfValidationForDerivedAttribute  ||  calling || commonValidationForConditionalPatternForDerivedAttribute() ifConditionAssetName "+ifConditionAssetName+"ruleAssetNames  "+ruleAssetNames+"relationNames "+relationNames+" mainAssetName "+mainAssetName);
							}
							//here i need to write ELSE IF validations
							sb = commonValidationForConditionalPatternForDerivedAttribute(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,lastParamName,macroFlag);
						}	
					}
				}
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("ifElseIfValidationForDerivedAttribute || Exit");
		}
		return sb;	
	}
	public  StringBuffer ifElseValidationForDerivedAttribute(String text,String mainAssetName,StringBuffer sb,String mainParamName,List<AssetDef> listOfAssets,String oldAssetName)throws RepoproException{


		if (log.isTraceEnabled()) {
			log.trace("ifElseValidationForDerivedAttribute || "+text+" Begins");
		}
		//ifElsePattern Splitting
		String ifElsePattern = "^((IF)"  //IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}][\\s]*[\\n]?)"
				+ "((ELSE)[\\s]"   //ELSE Condition
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}])?$"; 	
		Pattern p= Pattern.compile(ifElsePattern);
		Matcher m = p.matcher(text);
		if(!m.find()){
			if (log.isTraceEnabled()) {
				log.warn("Rule Pattern is not valid!");
			}
			sb.append("Rule Pattern is not valid");
		}
		if(sb.length()==0){

			String[] splittedData  = text.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
			int ifRuleLength = 0 ;
			//trimming spaces and making as all are lower cases
			for(int i = 0;i<splittedData.length;i++){
				splittedData[i] = splittedData[i].trim().toLowerCase();
				if(splittedData[i].contains("else")){

				}else{
					ifRuleLength++;
				}
			}
			Pattern p1 = Pattern.compile("\\{([^}]*)\\}");
			Matcher m1 = p1.matcher(text);
			List<String> listOfParams = new ArrayList<String>();

			while (m1.find()) {
				listOfParams.add(m1.group(1).trim());
			}
			List<String> macroList = new ArrayList<String>();
			macroList.add("ASSETINSTVERSIONID");
			macroList.add("ASSETINSTNAME");
			macroList.add("OVERVIEW");
			if(sb.length()==0){
				for(int i=0;i<ifRuleLength;i++){
					String lastParamName = listOfParams.get(i);
					boolean macroFlag = false;
					String macro = "";
					//macros
					if(lastParamName.startsWith("#")){
						if(lastParamName.endsWith("#")){
							macro = lastParamName.substring(1,lastParamName.length()-1);
							//macro  =macro.toUpperCase();
							if(macroList.contains(macro)){
								macroFlag = true;

							}else{
								if (log.isTraceEnabled()) {
									log.warn("Invalid Macro, please enter correct Macro!");
								}
								sb.append("Invalid Macro, please enter correct Macro!");
							}
						}else{
							if (log.isTraceEnabled()) {
								log.warn("Invalid Macro, please enter correct Macro!");
							}
							sb.append("Invalid Macro, please enter correct Macro!");
						}
					}else if(lastParamName.endsWith("#")){
						if (log.isTraceEnabled()) {
							log.warn("Invalid Macro, please enter correct Macro!");
						}
						sb.append("Invalid Macro, please enter correct Macro!");
					}
					if(sb.length()==0){

						List<String> ruleAssetNames = new ArrayList<String>();
						List<String> relationNames = new ArrayList<String>();
						String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
						String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
						String[] splitted = splittedData[i].split("[\\[\\]]");
						for(int k=2;k<splitted.length;k=k+2){
							ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
						}
						for(int k=3;k<splitted.length;k=k+2){
							relationNames.add(splitted[k].trim().toLowerCase());
						}
						if (log.isTraceEnabled()) {
							log.trace("ifElseValidationForDerivedAttribute  ||  calling || commonValidationForConditionalPatternForDerivedAttribute() with ifConditionAssetName "+ifConditionAssetName+"ruleAssetNames  "+ruleAssetNames+"relationNames "+relationNames+" mainAssetName "+mainAssetName);
						}
						sb = commonValidationForConditionalPatternForDerivedAttribute(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,lastParamName,macroFlag);
					}	
				}
			}
			for(int i = ifRuleLength;i<ifRuleLength+1;i++){

				String lastParamName = listOfParams.get(i);
				List<String> ruleAssetNames = new ArrayList<String>();
				List<String> relationNames = new ArrayList<String>();
				splittedData[i] = splittedData[i].replace("else", "").trim();
				String[] splitted = splittedData[i].split("[\\[\\]]");
				for(int k=0;k<splitted.length;k=k+2){
					ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
				}
				for(int k=1;k<splitted.length;k=k+2){
					relationNames.add(splitted[k].trim().toLowerCase());
				}
				if(sb.length()==0){
					boolean macroFlag = false;
					String macro = "";
					//macros
					if(lastParamName.startsWith("#")){
						if(lastParamName.endsWith("#")){
							macro = lastParamName.substring(1,lastParamName.length()-1);
							if(macroList.contains(macro)){
								macroFlag = true;

							}else{
								if(log.isTraceEnabled()){
									log.warn("Invalid Macro, please enter correct Macro!");
								}
								sb.append("Invalid Macro, please enter correct Macro!");
							}
						}else{
							if(log.isTraceEnabled()){
								log.warn("Invalid Macro, please enter correct Macro!");
							}
							sb.append("Invalid Macro, please enter correct Macro!");
						}
					}else if(lastParamName.endsWith("#")){
						if(log.isTraceEnabled()){
							log.warn("Invalid Macro, please enter correct Macro!");
						}
						sb.append("Invalid Macro, please enter correct Macro!");
					}

					//here i need to write validations
					if(sb.length()==0){
						if (log.isTraceEnabled()) {
							log.trace("ifElseValidationForDerivedAttribute  ||  calling || commonValidationForConditionalPatternForDerivedAttribute() with ruleAssetNames  "+ruleAssetNames+"relationNames "+relationNames+" mainAssetName "+mainAssetName);
						}
						sb =commonValidationForConditionalPatternForDerivedAttribute(null, ruleAssetNames, relationNames, null, mainAssetName,null,oldAssetName,lastParamName,macroFlag);
					}
				}

			}
		}
		if (log.isTraceEnabled()) {
			log.trace("ifElseValidationForDerivedAttribute || Exit");
		}
		return sb;
	}

	public  StringBuffer  ifRuleValidationFforDerivedAttribute(String text,String mainAssetName,StringBuffer sb,String mainParamName,List<AssetDef> listOfAssets,String oldAssetname)throws RepoproException{


		if (log.isTraceEnabled()) {
			log.trace("ifRuleValidationFforDerivedAttribute || "+text+ "Begins");
		}
		//If Pattern Splitting
		String IFpattern = "^((IF)"   //IF Condition
				+ "[\\[]"
				+ "[a-zA-Z0-9_\\n ]+"
				+ "[\\.]"
				+ "[a-zA-Z0-9\\n ]+"
				+ "(==)"
				+ "[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\p{L}+\\n ]+"
				+ "[\\]]"
				+ "([a-zA-Z0-9_\\n ]+"
				+ "[\\[][\\^]?[a-zA-Z0-9\\n ]+"
				+ "[\\]])+[a-zA-Z0-9_\\n ]+"
				+ "[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}][\\n]?)$";
				
				
		Pattern p = Pattern.compile(IFpattern);
		Matcher m = p.matcher(text);
		if(!m.find()){
			if(log.isTraceEnabled()){
				log.warn("Rule Pattern is not valid!");
			}
			sb.append("Rule Pattern is not valid!");
		}
		if(sb.length()==0){
			Pattern p1 = Pattern.compile("\\{([^}]*)\\}");
			Matcher m1 = p1.matcher(text);
			List<String> listOfParams = new ArrayList<String>();
			while (m1.find()) {
				listOfParams.add(m1.group(1).trim());
			}
			String[] splittedData = text.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
			//removing spaces and making all are lower cases letters
			for(int i=0;i<splittedData.length;i++){
				splittedData[i]=splittedData[i].trim().toLowerCase();
			}
			List<String> macroList = new ArrayList<String>();
			macroList.add("ASSETINSTVERSIONID");
			macroList.add("ASSETINSTNAME");
			macroList.add("OVERVIEW");
			if(sb.length()==0){
				//splitting if rule and validating with database
				for(int i=0;i<splittedData.length;i++){
					String lastParamName = listOfParams.get(i);
					boolean macroFlag = false;
					String macro = "";
					//macros
					if(lastParamName.startsWith("#")){
						if(lastParamName.endsWith("#")){
							macro = lastParamName.substring(1,lastParamName.length()-1);
							if(macroList.contains(macro)){
								macroFlag = true;

							}else{
								if(log.isTraceEnabled()){
									log.warn("Invalid Macro, please enter correct Macro!");
								}
								sb.append("Invalid Macro, please enter correct Macro!");
							}
						}else{
							if(log.isTraceEnabled()){
								log.warn("Invalid Macro, please enter correct Macro!");
							}
							sb.append("Invalid Macro, please enter correct Macro!");
						}
					}else if(lastParamName.endsWith("#")){
						if(log.isTraceEnabled()){
							log.warn("Invalid Macro, please enter correct Macro!");
						}
						sb.append("Invalid Macro, please enter correct Macro!");
					}
					if(sb.length()==0){
						List<String> ruleAssetNames = new ArrayList<String>();
						List<String> relationNames = new ArrayList<String>();
						String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
						String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
						String[] splitted = splittedData[i].split("[\\[\\]]");
						for(int k=2;k<splitted.length;k=k+2){
							ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));

						}
						for(int k=3;k<splitted.length;k=k+2){
							relationNames.add(splitted[k].trim().toLowerCase());
						}
						if(sb.length()==0){
							if(log.isTraceEnabled()){
								log.trace("ifRuleValidationFforDerivedAttribute || method calling || commonValidationForConditionalPatternForDerivedAttribute ifConditionAssetName "+ifConditionAssetName+" ruleAssetNames "+ruleAssetNames);
							}
							//here i need to write validations
							sb =commonValidationForConditionalPatternForDerivedAttribute(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetname,lastParamName,macroFlag);
						}
					}
				}
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("ifRuleValidationFforDerivedAttribute || Exit");
		}
		return sb;
	}


	public  StringBuffer normalRuleValidationForDerivedAttribute(String text,String mainAssetName,StringBuffer sb,String mainParamName,List<AssetDef> listOfAssets,String oldAssetName)throws RepoproException{



		if (log.isTraceEnabled()) {
			log.trace("normalRuleValidationForDerivedAttribute || "+text+" Begins");
		}
		//normal splitting
		String withOutIfPattern = "^([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+[a-zA-Z0-9_\\n ]+[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]$";
		Pattern p = Pattern.compile(withOutIfPattern);
		Matcher m = p.matcher(text);
		if(!m.find()){
			if(log.isTraceEnabled()){
				log.warn("Rule Pattern is not valid!");
			}
			sb.append("Rule Pattern is not valid!");
		}

		Pattern p1 = Pattern.compile("\\{([^}]*)\\}");
		Matcher m1 = p1.matcher(text);
		String lastParamName = null;
		while (m1.find()) {
			lastParamName = m1.group(1);
		}
		List<String> macroList = new ArrayList<String>();
		macroList.add("ASSETINSTVERSIONID");
		macroList.add("ASSETINSTNAME");
		macroList.add("OVERVIEW");
		if(sb.length()==0){

			boolean macroFlag = false;
			String macro = "";
			//macros
			if(lastParamName.startsWith("#")){
				if(lastParamName.endsWith("#")){
					macro = lastParamName.substring(1,lastParamName.length()-1);
					//macro  =macro.toUpperCase();
					if(macroList.contains(macro)){
						macroFlag = true;

					}else{
						if(log.isTraceEnabled()){
							log.warn("Invalid Macro, please enter correct Macro!");
						}
						sb.append("Invalid macro, please enter correct macro!");
					}
				}else{
					if(log.isTraceEnabled()){
						log.warn("Invalid Macro, please enter correct Macro!");
					}
					sb.append("Invalid Macro, please enter correct Macro!");
				}
			}else if(lastParamName.endsWith("#")){
				if(log.isTraceEnabled()){
					log.warn("Invalid Macro, please enter correct Macro!");
				}
				sb.append("Invalid Macro, please enter correct Macro!");
			}

			if(sb.length()==0){

				List<String> assetNames = new ArrayList<String>();
				List<String> relationNames = new ArrayList<String>();
				String[] splittedText = text.split("[\\[\\][\\{][\\}]]");
				for(int i =0;i<splittedText.length;i=i+2){
					assetNames.add(splittedText[i].toLowerCase().trim());
				}
				for(int i =1;i<splittedText.length-1;i=i+2){
					relationNames.add(splittedText[i].toLowerCase().trim());
				}
				if(log.isTraceEnabled()){
					log.trace("normalRuleValidationForDerivedAttribute || calling ||commonValidationForConditionalPatternForDerivedAttribute with assetNames "+assetNames+" relationNames "+relationNames);
				}
				sb =commonValidationForConditionalPatternForDerivedAttribute(null, assetNames, relationNames, null, mainAssetName,null,oldAssetName,lastParamName,macroFlag);
			}

		}
		if (log.isTraceEnabled()) {
			log.trace("normalRuleValidationForDerivedAttribute || Exit");
		}
		return sb;
	}



	public String validationForDerivedComputation(String text,String mainAssetName,String mainParamName,String oldAssetName)throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("validationForDerivedComputation || "+text+" Begins");
		}
		StringBuffer sb = new StringBuffer();
		Connection conn = null;

		List<AssetDef> assets = null;
		try {
			AssetDao dao = new AssetDao();
			//parameter check whether it is used in rule --> modified by gomathi 15/03/2018
			AssetParamDef apdef = dao.getParamIdForAssetAndParamName(mainAssetName, mainParamName, conn);
			if(apdef != null){
			if(apdef.getParamTypeId()!= 6){
			List<AssetParamDef> derivedAttributes =  dao.getAllDerivedAttributes(conn);
			Pattern patternForDerivedAttribute = Pattern.compile(mainAssetName+"[\\{](?i)"+mainParamName+"[\\}]");
			Pattern patternForDerivedComputation = Pattern.compile(mainAssetName+"[\\.](?i)"+mainParamName+"(==)");
			for (AssetParamDef assetParamDef2 : derivedAttributes) {
				String rule = assetParamDef2.getDerivedAttributeComputation();
				if(assetParamDef2.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID){

					Matcher m = patternForDerivedAttribute.matcher(rule);
					if(m.find()){//destination parameter check 
						log.warn("validationForDerivedAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
					
					Matcher m1 = patternForDerivedComputation.matcher(rule);
					if(m1.find()){// source parameter check
						log.warn("validationForDerivedAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
				}
				if(assetParamDef2.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID){
					Matcher m = patternForDerivedComputation.matcher(rule);
					if(m.find()){
						log.warn("validationForDerivedAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
				}
			}
			
			List<AssetParamDef> allDerivedAttributeForAssetList = assetDao.getAllDerivedAttributeForAssetList(conn);
			Pattern patternForDerivedAssetListAttribute = Pattern.compile(mainAssetName+"[\\{](?i)"+mainParamName+"[\\}]");
			Pattern patternForDerivedAssetListAttribute1 = Pattern.compile(mainAssetName+"[\\[](?i)"+mainParamName+"[\\]]");
			
			for(AssetParamDef apd : allDerivedAttributeForAssetList) {
				String text1 = apd.getDerivedAssetListRule();
				if(apd.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)){
					
					Matcher m = patternForDerivedAssetListAttribute.matcher(text1);
					if(m.find()){//destination parameter check 
						log.warn("validationForDerivedAssetListAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
					
					Matcher m1 = patternForDerivedAssetListAttribute1.matcher(text1);
					if(m1.find()){ 
						log.warn("validationForDerivedAssetListAttribute || Parameter already used in rule! So can't change parameter type");
						return "Parameter already used in rule! So cannot change parameter type!";
					}
				}
			}
			}
			}
			
		assets = dao.getAllAssets(conn);

		Pattern pat = Pattern.compile("(.count)[ ]*(ELSE)?");
		Matcher m = pat.matcher(text);
		if(m.find());
		boolean textFlag = text.startsWith("IF[");
		if(textFlag){
			if(text.contains("ELSEIF[")){
				if (log.isTraceEnabled()) {
					log.warn("Rule pattern is invalid !");
				}
				sb.append("Rule pattern is invalid !");
			}else if(text.contains("ELSE IF[")){
				String[] splited = text.split("\\.count");
				if(!splited[splited.length-1].contains("IF[")){
					if (log.isTraceEnabled()) {
						log.trace("validationForDerivedComputation || calling || ifElseIfElseValidationForDerviceComputation text "+text+" mainAssetName "+mainAssetName);
					}
					//ifElseIfElse splitting
					sb =ifElseIfElseValidationForDerviceComputation(text, mainAssetName, sb,mainParamName,assets,oldAssetName);
				}else{
					if (log.isTraceEnabled()) {
						log.trace("validationForDerivedComputation || calling || ifElseIfValidationForDerivedComputation text "+text+" mainAssetName "+mainAssetName);
					}
					//ifElseIf splitting
					sb =ifElseIfValidationForDerivedComputation(text, mainAssetName, sb,mainParamName,assets,oldAssetName);
				}
			}else{
				//ifElsePattern Splitting
				String[] splited = text.split("\\.count");
				if(!splited[splited.length-1].contains("IF[")){
					if (log.isTraceEnabled()) {
						log.trace("validationForDerivedComputation || calling || ifElseValidationForDerivedComputation text "+text+" mainAssetName "+mainAssetName);
					}
					sb =ifElseValidationForDerivedComputation(text, mainAssetName, sb,mainParamName,assets,oldAssetName);
				}else{
					if (log.isTraceEnabled()) {
						log.trace("validationForDerivedComputation || calling || ifRuleValidationFforDerivedComputation text "+text+" mainAssetName "+mainAssetName);
					}
					//if Rule valiation
					sb =ifRuleValidationFforDerivedComputation(text, mainAssetName, sb, mainParamName,assets,oldAssetName);
				}
			}
		}else{
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedComputation || calling || normalRuleValidationForDerivedComputation text "+text+" mainAssetName "+mainAssetName);
			}
			//normal splitting
			sb =normalRuleValidationForDerivedComputation(text, mainAssetName, sb,mainParamName,assets,oldAssetName);

		}
		
		}catch(Exception e){
			log.error("validationForDerivedAttribute ||  " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} 
		if (log.isTraceEnabled()) {
			log.trace("validationForDerivedComputation || Exit");
		}
		return sb.toString();
	}


	public  StringBuffer ifElseIfElseValidationForDerviceComputation(String text,String mainAssetName,StringBuffer sb,String mainParamName ,List<AssetDef> listOfAssets,String oldAssetName)throws RepoproException{


		if (log.isTraceEnabled()) {
			log.trace("ifElseIfElseValidationForDerviceComputation || "+text+" Begins");
		}
		//ifElseIfElse splitting
		String ifElseIfEslePattern = "^((IF)"   //IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+(.count)[\\s]*[\\n]?)"
				+ "((ELSE IF)"           //ELSE IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+(.count)[\\s]*)+"
				+ "((ELSE)[\\s]"             //ELSE Condition
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+(.count))?$";
		Pattern p = Pattern.compile(ifElseIfEslePattern);
		Matcher m =p.matcher(text);
		if(!m.find()){
			if (log.isTraceEnabled()) {
				log.warn("Rule Pattern is not valid!");
			}
			sb.append("Rule Pattern is not valid!");

		}
		String[] splittedData = text.split("\\.count");
		//trimming spaces and making all are lower case letters
		for(int i =0;i<splittedData.length;i++){
			splittedData[i] = splittedData[i].trim().toLowerCase();
		}
		int ifConditionLength = 0 ;
		int elseIfConditionLength = 0;
		//finding condition lengths
		for (int i=0;i<splittedData.length;i++) {
			if(splittedData[i].contains("else if[")){
				elseIfConditionLength++;
			}else if(splittedData[i].contains("if[")){
				ifConditionLength++;
			}
		}
		if(sb.length()==0){
			//spiltting if rule and validations with database
			for(int i=0;i<ifConditionLength;i++){
				List<String> ruleAssetNames = new ArrayList<String>();
				List<String> relationNames = new ArrayList<String>();
				String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
				String paramValue= splittedData[i].substring(splittedData[i].indexOf("==")+2, splittedData[i].indexOf("]")).trim().toLowerCase();
				String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
				String[] splitted = splittedData[i].split("[\\[\\]]");
				for(int k=2;k<splitted.length;k=k+2){
					ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
				}
				for(int k=3;k<splitted.length;k=k+2){
					relationNames.add(splitted[k].trim().toLowerCase());
				}

				if (log.isTraceEnabled()) {
					log.trace("ifElseIfElseValidationForDerviceComputation || calling || commonValidationForConditionalPattrn with ifConditionAssetName "+ifConditionAssetName+" ruleAssetNames"+ruleAssetNames);
				}
				sb = commonValidationForConditionalPattern(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,sb);
			}
		}
		if(sb.length()==0){

			//spiltting else if rule and validations with database
			for(int i =ifConditionLength;i<elseIfConditionLength+ifConditionLength;i++){
				List<String> ruleAssetNames = new ArrayList<String>();
				List<String> relationNames = new ArrayList<String>();
				String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
				String paramValue= splittedData[i].substring(splittedData[i].indexOf("==")+2, splittedData[i].indexOf("]")).trim().toLowerCase();
				String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
				String[] splitted = splittedData[i].split("[\\[\\]]");
				for(int k=2;k<splitted.length;k=k+2){
					ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
				}
				for(int k=3;k<splitted.length;k=k+2){
					relationNames.add(splitted[k].trim().toLowerCase());
				}
				if (log.isTraceEnabled()) {
					log.trace("ifElseIfElseValidationForDerviceComputation || calling || commonValidationForConditionalPattrn with ifConditionAssetName "+ifConditionAssetName+" ruleAssetNames"+ruleAssetNames);
				}
				//here i need to write validations
				sb = commonValidationForConditionalPattern(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,sb);
			}
		}	
		//spiltting else rule and validations with database
		if(sb.length()==0){
			for(int i = ifConditionLength+elseIfConditionLength;i<ifConditionLength+elseIfConditionLength+1;i++){
				List<String> ruleAssetNames = new ArrayList<String>();
				List<String> relationNames = new ArrayList<String>();
				splittedData[i] = splittedData[i].replace("else", "").trim();
				String[] splitted = splittedData[i].split("[\\[\\]]");
				for(int k=0;k<splitted.length;k=k+2){
					ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
				}
				for(int k=1;k<splitted.length;k=k+2){
					relationNames.add(splitted[k].trim().toLowerCase());
				}

				if (log.isTraceEnabled()) {
					log.trace("ifElseIfElseValidationForDerviceComputation || calling || commonValidationForConditionalPattrn with ruleAssetNames"+ruleAssetNames);
				}
				sb = commonValidationForConditionalPattern(null, ruleAssetNames, relationNames, null, mainAssetName,mainParamName,oldAssetName,sb);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("ifElseIfElseValidationForDerviceComputation || Exit");
		}
		return sb;
	}


	public  StringBuffer ifElseIfValidationForDerivedComputation(String text,String mainAssetName,StringBuffer sb,String mainParamName,List<AssetDef> listOfAssets,String oldAssetName)throws RepoproException{


		if (log.isTraceEnabled()) {
			log.trace("ifElseIfValidationForDerivedComputation || "+text+" Begins");
		}
		//ifElseIf splitting
		String ifElseIfPattern = "^((IF)" //IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+(.count)[\\n]?"
				+ "[\\s]*)"
				+ "((ELSE IF)"  //ELSE IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+(.count))+$";


		Pattern p = Pattern.compile(ifElseIfPattern);
		Matcher m =p.matcher(text);
		if(!m.find()){
			sb.append("Rule Pattern is not valid!");

			if (log.isTraceEnabled()) {
				log.warn("Rule Pattern is not valid!");
			}
		}
		if(sb.length()==0){
			//trimming and making all letters are lower case
			String[] splittedData = text.split("\\.count");
			for(int i=0;i<splittedData.length;i++){
				splittedData[i] = splittedData[i].trim().toLowerCase();
			}
			int ifLength= 0;
			int elseIfLength = 0;
			//finding length condition lengths
			for(int i=0;i<splittedData.length;i++){
				if(splittedData[i].contains("else if[")){
					elseIfLength++;
				}else{
					ifLength++;
				}
			}
			if(sb.length()==0){
				//splitting if rule and validating with database
				for(int i=0;i<ifLength;i++){
					List<String> ruleAssetNames = new ArrayList<String>();
					List<String> relationNames = new ArrayList<String>();
					String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
					String paramValue= splittedData[i].substring(splittedData[i].indexOf("==")+2, splittedData[i].indexOf("]")).trim().toLowerCase();
					String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
					String[] splitted = splittedData[i].split("[\\[\\]]");
					for(int k=2;k<splitted.length;k=k+2){
						ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
					}
					for(int k=3;k<splitted.length;k=k+2){
						relationNames.add(splitted[k].trim().toLowerCase());
					}
					if(sb.length()==0){
						if (log.isTraceEnabled()) {
							log.trace("ifElseIfValidationForDerivedComputation || calling  ||commonValidationForConditionalPattern with ifConditionAssetName "+ifConditionAssetName+" ruleAssetNames "+ruleAssetNames);
						}
						sb =commonValidationForConditionalPattern(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,sb);

					}	
				}
			}
			if(sb.length()==0){
				//splitting else if rule and validating with database
				for(int i=ifLength;i<elseIfLength+ifLength;i++){
					List<String> ruleAssetNames = new ArrayList<String>();
					List<String> relationNames = new ArrayList<String>();
					String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
					String paramValue= splittedData[i].substring(splittedData[i].indexOf("==")+2, splittedData[i].indexOf("]")).trim().toLowerCase();
					String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
					String[] splitted = splittedData[i].split("[\\[\\]]");
					for(int k=2;k<splitted.length;k=k+2){
						ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
					}
					for(int k=3;k<splitted.length;k=k+2){
						relationNames.add(splitted[k].trim().toLowerCase());
					}
					if(sb.length()==0){
						if (log.isTraceEnabled()) {
							log.trace("ifElseIfValidationForDerivedComputation || calling  ||commonValidationForConditionalPattern with ifConditionAssetName "+ifConditionAssetName+" ruleAssetNames "+ruleAssetNames);
						}
						//here i need to write ELSE IF validations
						sb =commonValidationForConditionalPattern(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,sb);
					}	
				}
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("ifElseIfValidationForDerivedComputation || Exit");
		}
		return sb;	
	}

	public  StringBuffer ifElseValidationForDerivedComputation(String text,String mainAssetName,StringBuffer sb,String mainParamName,List<AssetDef> listOfAssets,String oldAssetName)throws RepoproException{


		if (log.isTraceEnabled()) {
			log.trace("ifElseValidationForDerivedComputation || "+text+" Begins");
		}
		//ifElsePattern Splitting
		String ifElsePattern = "^((IF)"  //IF Condition
				+ "[\\[][a-zA-Z0-9_\\n ]+[\\.][a-zA-Z0-9\\n ]+(==)[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+[\\]]"
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+(.count)[\\s]*[\\n]?)"
				+ "((ELSE)[\\s]"   //ELSE Condition
				+ "([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+"
				+ "[a-zA-Z0-9_\\n ]+(.count))?$"; 	
		Pattern p= Pattern.compile(ifElsePattern);
		Matcher m = p.matcher(text);
		if(!m.find()){
			if (log.isTraceEnabled()) {
				log.warn("Rule Pattern is not valid");
			}
			sb.append("Rule Pattern is not valid");
		}
		if(sb.length()==0){

			String[] splittedData  = text.split("\\.count");
			int ifRuleLength = 0 ;
			//trimming spaces and making as all are lower cases
			for(int i = 0;i<splittedData.length;i++){
				splittedData[i] = splittedData[i].trim().toLowerCase();
				if(splittedData[i].contains("else")){

				}else{
					ifRuleLength++;
				}
			}
			if(sb.length()==0){
				for(int i=0;i<ifRuleLength;i++){
					List<String> ruleAssetNames = new ArrayList<String>();
					List<String> relationNames = new ArrayList<String>();
					String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
					String paramValue= splittedData[i].substring(splittedData[i].indexOf("==")+2, splittedData[i].indexOf("]")).trim().toLowerCase();
					String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
					String[] splitted = splittedData[i].split("[\\[\\]]");
					for(int k=2;k<splitted.length;k=k+2){
						ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
					}
					for(int k=3;k<splitted.length;k=k+2){
						relationNames.add(splitted[k].trim().toLowerCase());
					}
					if (log.isTraceEnabled()) {
						log.trace(" ifElseValidationForDerivedComputation ||calling || commonValidationForConditionalPattern with ifConditionAssetName "+ifConditionAssetName+" ruleAssetNames "+ruleAssetNames);
					}
					//here i need to write validations
					sb =commonValidationForConditionalPattern(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetName,sb);
				}
			}
			if(sb.length()==0){
				for(int i = ifRuleLength;i<ifRuleLength+1;i++){
					List<String> ruleAssetNames = new ArrayList<String>();
					List<String> relationNames = new ArrayList<String>();
					splittedData[i] = splittedData[i].replace("else", "").trim();
					String[] splitted = splittedData[i].split("[\\[\\]]");
					for(int k=0;k<splitted.length;k=k+2){
						ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
					}
					for(int k=1;k<splitted.length;k=k+2){
						relationNames.add(splitted[k].trim().toLowerCase());
					}

					if (log.isTraceEnabled()) {
						log.trace(" ifElseValidationForDerivedComputation ||calling || commonValidationForConditionalPattern with  ruleAssetNames "+ruleAssetNames);
					}
					//here i need to write validations
					sb =commonValidationForConditionalPattern(null, ruleAssetNames, relationNames, null, mainAssetName,null,oldAssetName,sb);
				}
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("ifElseValidationForDerivedComputation || Exit");
		}
		return sb;
	}

	public  StringBuffer  ifRuleValidationFforDerivedComputation(String text,String mainAssetName,StringBuffer sb,String mainParamName,List<AssetDef> listOfAssets,String oldAssetname)throws RepoproException{


		if (log.isTraceEnabled()) {
			log.trace("ifRuleValidationFforDerivedComputation || "+text+" Begins");
		}

		String IFpattern = "^((IF)"   //IF Condition
				+ "[\\[]"
				+ "[a-zA-Z0-9_\\n ]+"
				+ "[\\.]"
				+ "[a-zA-Z0-9\\n ]+"
				+ "(==)"
				+ "[:\"+#$/\\&@.(),-_a-zA-Z0-9<>/~~\\p{L}\\n ]+"
				+ "[\\]]"
				+ "([a-zA-Z0-9_\\n ]+"
				+ "[\\[][\\^]?[a-zA-Z0-9\\n ]+"
				+ "[\\]])+[a-zA-Z0-9_\\n ]+"
				//+ "[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}][\\n]?)$";	
				+"[\\.](count))$";

		Pattern p = Pattern.compile(IFpattern);
		Matcher m = p.matcher(text);
		if(!m.find()){
			if (log.isTraceEnabled()) {
				log.warn("Rule Pattern is not valid!");
			}
			sb.append("Rule Pattern is not valid!");
		}
		if(sb.length()==0){
			text = text.replace("IF", "").trim();
			String[] splittedData = text.split("\\.count");
			//removing spaces and making all are lower cases letters
			for(int i=0;i<splittedData.length;i++){
				splittedData[i]=splittedData[i].trim().toLowerCase();
			}
			if(sb.length()==0){
				//splitting if rule and validating with database
				for(int i=0;i<splittedData.length;i++){
					List<String> ruleAssetNames = new ArrayList<String>();
					List<String> relationNames = new ArrayList<String>();
					String paramName = splittedData[i].substring(splittedData[i].indexOf(".")+1, splittedData[i].indexOf("==")).trim().toLowerCase();
					String paramValue= splittedData[i].substring(splittedData[i].indexOf("==")+2, splittedData[i].indexOf("]")).trim().toLowerCase();
					String ifConditionAssetName =splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
					String[] splitted = splittedData[i].split("[\\[\\]]");
					for(int k=2;k<splitted.length;k=k+2){
						ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));

					}
					for(int k=3;k<splitted.length;k=k+2){
						relationNames.add(splitted[k].trim().toLowerCase());
					}
					if(sb.length()==0){
						if (log.isTraceEnabled()) {
							log.trace("ifRuleValidationFforDerivedComputation || calling || commonValidationForConditionalPattern with ifConditionAssetName "+ifConditionAssetName+" ruleAssetNames "+ruleAssetNames);
						}
						//here i need to write validations
						sb =commonValidationForConditionalPattern(ifConditionAssetName, ruleAssetNames, relationNames, paramName, mainAssetName,mainParamName,oldAssetname,sb);
					}
				}
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("ifRuleValidationFforDerivedComputation || Exit");
		}
		return sb;
	}


	public  StringBuffer normalRuleValidationForDerivedComputation(String text,String mainAssetName,StringBuffer sb,String mainParamName,List<AssetDef> listOfAssets,String oldAssetName)throws RepoproException{


		if (log.isTraceEnabled()) {
			log.trace("normalRuleValidationForDerivedComputation || "+text+" Begins");
		}
		//normal splitting
		String withOutIfPattern = "^([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+[a-zA-Z0-9_\\n ]+[\\.](count)$";
		Pattern p = Pattern.compile(withOutIfPattern);
		Matcher m = p.matcher(text);
		if(!m.find())
			sb.append("Rule Pattern is not valid!");
		if(sb.length()==0){
			List<String> assetNames = new ArrayList<String>();
			List<String> relationNames = new ArrayList<String>();

			String text1 = text.replace("IF", "").replace(".count", "").replace(".", "");
			String[] splittedText = text1.split("[\\[\\]]");
			for(int i =0;i<splittedText.length;i=i+2){
				assetNames.add(splittedText[i].toLowerCase().trim());
			}
			for(int i =1;i<splittedText.length;i=i+2){
				relationNames.add(splittedText[i].toLowerCase().trim());
			}
			if (log.isTraceEnabled()) {
				log.trace("normalRuleValidationForDerivedComputation || calling || commonValidationForConditionalPattern with assetNames "+assetNames+" relationNames "+relationNames);
			}
			sb =commonValidationForConditionalPattern(null, assetNames, relationNames, null, mainAssetName,oldAssetName,oldAssetName,sb);

		}
		if (log.isTraceEnabled()) {
			log.trace("normalRuleValidationForDerivedComputation || Exit");
		}
		return sb;
	}
	public  StringBuffer commonValidationForConditionalPattern(String conditionAssetName,List<String> assetNames,List<String> relationNames,String paramName,String mainAssetName,String mainParamName,String oldAssetName,StringBuffer sb)throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("commonValidationForConditionalPattern || "+ conditionAssetName +" Begin");
		}
		//Checking assetNames in Database
		Connection conn = null;
		if(sb.length()==0){
			List<String> lowerCaseNames=null;
			List<AssetDef> assets = null;
			try {
				if(log.isTraceEnabled()){
					log.trace("commonValidationForConditionalPattern ||dao method calling  getAllAssets ");
				}
				assets = assetDao.getAllAssets(conn);
			} catch (RepoproException e) {
				e.printStackTrace();
			}
			lowerCaseNames = new ArrayList<String>();

			for (int i = 0; i < assets.size(); i++) {
				String name =assets.get(i).getAssetName();
				name=name.toLowerCase().trim(); 
				lowerCaseNames.add(name);
			}

			if(sb.length()==0){
				for(int i=0;i<assetNames.size();i++){
					String name=assetNames.get(i);
					name=name.toLowerCase().trim();
					if(!lowerCaseNames.contains(name)){
						sb.append(assetNames.get(i)+",");
					}
				}
				if(sb.length()!=0){
					sb.deleteCharAt(sb.length()-1);
					if(log.isTraceEnabled()){
						log.warn(" Asset/Assets not available in the repository!");
					}
					sb.append(" Asset/Assets not available in the repository!");
				}
			}


			if(sb.length()==0){
				if(mainAssetName!=null){
					if(!mainAssetName.trim().equalsIgnoreCase(assetNames.get(0).trim())){
						if(log.isTraceEnabled()){
							log.warn("Relation rule should be start with current asset!");
						}
						sb.append("Relation rule should be start with current asset!");
					}
				}
				if(sb.length()==0){
					if(conditionAssetName!=null){
						if(!conditionAssetName.trim().equalsIgnoreCase(assetNames.get(0).trim())){
							if(log.isTraceEnabled()){
								log.warn("Condition asset should be same as current asset!");
							}
							sb.append("Condition asset should be same as current asset!");
						}
					}
				}
				if(mainParamName!=null){
					if(mainParamName.trim().equalsIgnoreCase(paramName)){
						if(log.isTraceEnabled()){
							log.warn(paramName+" : current parameter name can not used!");
						}
						sb.append(paramName+" : current parameter name can not used!");
					}
				}
			}

		}

		//Checking relationNames in Database
		if(sb.length()==0){
			List<String> lowerCaseRelationNames = null;
			lowerCaseRelationNames =new ArrayList<String>();
			List<AssetRelationshipDef> allRelationNames = null;
			try {
				if(log.isTraceEnabled()){
					log.trace(" commonValidationForConditionalPattern || dao calling ||getAllAssetRelationshipDef");
				}
				allRelationNames = relationshipDao.getAllAssetRelationshipDef(conn);
			} catch (RepoproException e) {
				e.printStackTrace();
			}

			for (int i = 0; i < allRelationNames.size(); i++) {
				String relationName = allRelationNames.get(i).getDescription();

				lowerCaseRelationNames.add(relationName.toLowerCase().trim());
			}

			for (int i = 0; i < relationNames.size(); i++) {
				String relationName = relationNames.get(i);
				boolean relFlag = relationName.contains("^");
				if(relFlag){
					relationName = relationName.substring(1,relationName.length());
				}
				if(!lowerCaseRelationNames.contains(relationName))
					sb.append(relationNames.get(i)+",");
			}
			if(sb.length()!=0){
				sb.deleteCharAt(sb.length()-1);
				if(log.isTraceEnabled()){
					log.warn(" relationship name(s) not availble in the repository!");
				}
				sb.append(" relationship name(s) not availble in the repository!");
			}
		}
		//checking param is available in last AssetName or not 
		if(paramName!=null||conditionAssetName!=null){
			if(sb.length()==0){

				if(log.isTraceEnabled()){
					log.trace(" commonValidationForConditionalPattern || dao calling ||retParamIdForAssetAndParamName with conditionAssetName"+conditionAssetName+" paramName "+paramName);
				}
				AssetParamDef paramDetails = assetDao.retParamIdForAssetAndParamName(conditionAssetName, paramName,conn);
				boolean flag =false;
				if(paramDetails!=null){
					if(paramDetails.getAssetParamName().toLowerCase().equalsIgnoreCase(paramName)){
						flag=true;
						if(paramDetails.isHasStaticValue()){
							if(log.isTraceEnabled()){
								log.warn("Static parameter should not allowed!");
							}
							sb.append("Static parameter should not allowed!");
						}else{
							if(paramDetails.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID||paramDetails.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID || paramDetails.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)){
								if(log.isTraceEnabled()){
									log.warn(paramName+" : derived parameters not allowed!");
								}
								sb.append(paramName+" : derived parameters not allowed!");
							}
						}
					}
				}else{
					flag = false;
				}
				if(!flag){
					if(log.isTraceEnabled()){
						log.warn(paramName+" is not available under "+conditionAssetName+" Asset!");
					}
					sb.append(paramName+" is not available under "+conditionAssetName+" Asset!");
				}
			}
		}
		//Please provide Derived attribute rule!
		if(paramName!=null||conditionAssetName!=null){
			if(sb.length()==0){
				if(log.isTraceEnabled()){
					log.trace(" commonValidationForConditionalPattern || dao calling ||retParamIdForAssetAndParamName with conditionAssetName"+conditionAssetName+" paramName "+paramName);
				}
				AssetParamDef paramDetails = assetDao.retParamIdForAssetAndParamName(conditionAssetName, paramName,conn);
				boolean flag =false;
				if(paramDetails!=null){
					if(paramDetails.getAssetParamName().toLowerCase().equalsIgnoreCase(paramName)){
						flag=true;
						if(paramDetails.isHasStaticValue()){
							if(log.isTraceEnabled()){
								log.warn("Static parameter should not allowed!");
							}
							sb.append("Static parameter should not allowed!");
						}else{
							if(paramDetails.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID||paramDetails.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID || paramDetails.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)){
								if(log.isTraceEnabled()){
									log.warn(paramName+" : derived parameters not allowed!");
								}
								sb.append(paramName+" : derived parameters not allowed!");
							}
						}
					}
				}else{
					flag = false;
				}
				if(!flag){
					if(log.isTraceEnabled()){
						log.warn(paramName+" is not available under "+conditionAssetName+" Asset!");
					}
					sb.append(paramName+" is not available under "+conditionAssetName+" Asset!");
				}
			}
		}
		//relationShip validation between assets
		if(sb.length()==0){
			int firstName = 0;
			int lastAssetName = 1;
			int relatioName=0;
			for(int i =0;i<relationNames.size();i++){
				String srcAssetName = assetNames.get(firstName);
				String relationName = relationNames.get(relatioName);
				boolean relFlag = relationName.contains("^");
				if(relFlag){
					relationName = relationName.substring(1,relationName.length());
				}
				String destAssetName= assetNames.get(lastAssetName);
				if(log.isTraceEnabled()){
					log.trace(" commonValidationForConditionalPattern || dao calling ||retAssetRelDefForAssetsByRelationName with srcAssetName "+srcAssetName+" destAssetName "+destAssetName+" relationName "+relationName);
				}
				AssetRelationshipDef data =relationshipDao.retAssetRelDefForAssetsByRelationName(srcAssetName, destAssetName, relationName,conn);
				if(data==null){
					if(log.isTraceEnabled()){
						log.trace(" commonValidationForConditionalPattern || dao calling ||retAssetRelDefForAssetsByRelationName with srcAssetName "+srcAssetName+" destAssetName "+destAssetName+" relationName "+relationName);
					}
					AssetRelationshipDef data1 =relationshipDao.retAssetRelDefForAssetsByRelationName(destAssetName, srcAssetName, relationName,conn);
					if(data1==null){
						if(log.isTraceEnabled()){
							log.warn(relationName+" relation not defined between "+destAssetName+" and "+srcAssetName+" assets");
						}
						sb.append(relationName+" relation not defined between "+destAssetName+" and "+srcAssetName+" assets");	
					}
				}
				firstName = firstName+1;
				relatioName = relatioName+1;
				lastAssetName = lastAssetName+1;
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("normalRuleValidationForDerivedComputation || Exit");
		}
		return sb;
	}
	//duplicates assets checking in Rule
	public static <T> List getDuplicate(Collection<T> list)throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getDuplicate || Begin ");
		}
		final List<T> duplicatedObjects = new ArrayList<T>();
		Set<T> set = new HashSet<T>() {
			@Override
			public boolean add(T e) {
				if (contains(e)) {
					duplicatedObjects.add(e);
				}
				return super.add(e);
			}
		};
		for (T t : list) {
			set.add(t);
		}
		if (log.isTraceEnabled()) {
			log.trace("getDuplicate || Exit");
		}
		return duplicatedObjects;
	}



	public static boolean isValidString(String tmpStr)
	{
		log.trace("isValidString : begin");
		boolean isValid = true;

		if(null == tmpStr || tmpStr.trim().equals("") || tmpStr.equalsIgnoreCase(Constants.NULL_STRING))
			isValid = false;

		log.trace("isValidString : Exit "+isValid);
		return isValid;
	}


	public static Response filterDependencyTreeAction(
			String assetName,
			Long assetInstanceVersionId,
			String relationId){
		if(log.isTraceEnabled()){
			log.trace("filterDependencyTreeAction by assetName :"+assetName+" assetInstanceVersionId"+assetInstanceVersionId);
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		RelationshipDao relationShipDao  = new RelationshipDao();
		List<String> jsonList = new ArrayList<String>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("filterDependencyTreeAction ||"+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			assetName = assetName.replaceAll("%20", " ");
			relationId = relationId.replaceAll("%20", " ");
			if(log.isTraceEnabled()){
				log.trace("filterDependencyTreeAction || dao calling method: ||getAssetInstanceAndVersionDetailsByVersionId with || "+assetInstanceVersionId);
			}
			String[] assetInstNameAndVersionName = relationShipDao.getAssetInstanceAndVersionDetailsByVersionId(assetInstanceVersionId, conn);
			String assetInstanceName = assetInstNameAndVersionName[0];
			String versionName = assetInstNameAndVersionName[1];
			if(log.isTraceEnabled()){
				log.trace("filterDependencyTreeAction || dao calling method getDependants with || "+assetInstanceVersionId);
			}
			List<AssetInstance> listai = relationShipDao.getDependants(assetInstanceVersionId,conn);
			JSONObject dependencyTreeJson = new JSONObject();

			try{
				AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
				Collection<JSONObject> assetInstanceJsonCollection = new ArrayList<JSONObject>();
				AssetDef assetDef = assetInstanceDao.retAssetDetail(assetName,conn);
				if(assetDef.isVersionable()==true)
					dependencyTreeJson.put("name",assetInstanceName+"~"+versionName);
				else
					dependencyTreeJson.put("name",assetInstanceName);
				
				dependencyTreeJson.put("colour", "yellow");
				if(listai.size()>0){
					dependencyTreeJson.put("isEnd", "1");
				}
				else{
					dependencyTreeJson.put("isEnd", "0");
				}
				dependencyTreeJson.put("icon", assetDef.getIconImageName());
				dependencyTreeJson.put("parentAssetId", assetDef.getAssetId());
				dependencyTreeJson.put("size", "10");
				ArrayList<Long> traversedAssetInstanceVersionId = new ArrayList<Long>();
				ArrayList<Long> recursedAssetInstanceVersionId = new ArrayList<Long>();
				for(AssetInstance assetInstance:listai){
					Long destAssetInstanceVersionId  = assetInstance.getAssetInstVersionId();
					traversedAssetInstanceVersionId = new ArrayList<Long>();
					recursedAssetInstanceVersionId = new ArrayList<Long>();
					traversedAssetInstanceVersionId.add(assetInstanceVersionId);
					traversedAssetInstanceVersionId.add(Long.valueOf(assetInstance.getAssetInstVersionId()).longValue());
					if(log.isTraceEnabled()){
						log.trace("filterDependencyTreeAction || dao calling method retAssetRelDefById with || "+assetInstance.getAssetRelationshipId());
					}
					AssetRelationshipDef assetRelationShipDef = relationShipDao.retAssetRelDefById(Long.valueOf(assetInstance.getAssetRelationshipId()),conn);
					Long fwdRelId = assetRelationShipDef.getFwdRelId();
					int charCount = 0;
					for(int i =0 ; i<relationId.length(); i++){
						if(relationId.charAt(i) == '!'){
							charCount++;
						}
					}
					String[] relId1 = new String[charCount+1];

					String[] parts = new String[charCount+1];
					relId1 = relationId.split("!");
					for(int i = 0 ; i <relId1.length;i++){
						String[] relId2 = new String[2];
						relId2 = relId1[i].split("\\-");
						relId1[i] = relId2[0];
						parts[i] = relId2[1]; 
					}
					int v = 0;
					int h = 0;
					for(h = 0 ;h < parts.length;h++){
						String fwdRelId1 = String.valueOf(fwdRelId);
						Long p = fwdRelId;
						if(assetInstance.getAssetRelationshipName().equals(relId1[h])){
							if(fwdRelId1.equals(String.valueOf(p))){
								if(assetInstance.getAssetRelationshipName().equals(relId1[h])){
									dependencyTreeJson.put("relationShip", "");
									JSONObject assetInstanceJson = new JSONObject();
									AssetDef assetDef1 = assetInstanceDao.retAssetDetail(assetInstance.getAssetName(),conn);
									if(assetDef1.isVersionable()==true)
										assetInstanceJson.put("name",assetInstance.getAssetInstName()+"~"+assetInstance.getVersionName());
									else
										assetInstanceJson.put("name",assetInstance.getAssetInstName());
									assetInstanceJson.put("size", "10");
									assetInstanceJson.put("relID",assetInstance.getAssetRelationshipName()+"|"+parts[h]);
									assetInstanceJson.put("assetName", assetDef1.getAssetName());
									assetInstanceJson.put("assetInstanceVersionId", assetInstance.getAssetInstVersionId());
									assetInstanceJson.put("versionName", assetInstance.getVersionName());
									if(log.isTraceEnabled()){
										log.trace("filterDependencyTreeAction || dao calling method getDependants with || "+destAssetInstanceVersionId);
									}
									List<AssetInstance> listofAssetInstances = relationShipDao.getDependants(destAssetInstanceVersionId,conn);
									if(listofAssetInstances.size()>0){
										assetInstanceJson.put("isEnd", "1");
									}
									else{
										assetInstanceJson.put("isEnd", "0");
									}
									if(p ==1){
										assetInstanceJson.put("colour", "grey");
										assetInstanceJson.put("relationShip", assetInstance.getAssetRelationshipName());
									}else if(p==3){
										assetInstanceJson.put("colour", "blue");
										assetInstanceJson.put("relationShip", assetInstance.getAssetRelationshipName());
									}else if(p==5){
										assetInstanceJson.put("colour", "red");
										assetInstanceJson.put("relationShip",assetInstance.getAssetRelationshipName());
									}else if(p==7){
										assetInstanceJson.put("colour", "green");
										assetInstanceJson.put("relationShip", assetInstance.getAssetRelationshipName());
									}
									assetInstanceJson.put("icon", assetDef1.getIconImageName());
									assetInstanceJson.put("childAssetId", assetDef1.getAssetId());
									recursedAssetInstanceVersionId = new ArrayList<Long>();
									assetInstanceJsonCollection.add(assetInstanceJson);
									assetInstanceJson = new JSONObject();
								}
							}
						}
					}
				}
				dependencyTreeJson.put("children", new JSONArray(assetInstanceJsonCollection));

			}catch (Exception e) {
				e.printStackTrace();
			}
			String jsonValue = dependencyTreeJson.toString();
			int idx = 0;
			int count = 0;
			while ((idx = jsonValue.indexOf(",\"children\":[]", idx)) != -1)
			{
				idx++;
				count++;
			}
			if(count > 1){
				jsonValue = jsonValue.replaceAll(",\"children\":\\[\\]","");
			}
			jsonValue = jsonValue.replaceAll(",\"children\":\\[\\]", "");

			jsonList.add(jsonValue);
			retStatScsFlr = 200;
			retScsFlr= "SUCCESS";
			retMsg="Retrived all Dependencies";
		} catch (Exception e) {
			log.error("SQL Exception on filterDependencyTreeAction ||"+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("filterDependencyTreeAction ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("filterDependencyTreeAction || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,new ArrayList(jsonList))).build();
	}




	public void CopyPropertiesForChildInstance(AssetInstanceVersion aiv1,
		     Long userId, String copyFromVersion, Long oldAivId, 
			String userName, int activeFlag, int versionableFlag,
			@Context ServletContext context, Connection conn)
					throws RepoproException{

		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("CopyPropertiesForChildInstance : "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			// copy properties for child instance
			String paramName;
			NameValue nv;

			ParameterValues pv = new ParameterValues();
			AssetParamDef apd = new AssetParamDef();

			// Fetch parameter definitions for the asset

			if (log.isTraceEnabled()) {
				log.trace("CopyPropertiesForChildInstanceUtil || called dao method : getParamsDetailByAssetName() by AssetName: "
						+ aiv1.getAssetName());
			}

			List<AssetParamDef> params = assetDao.getParamsDetailByAssetName(
					aiv1.getAssetName(), conn);

			for (AssetParamDef paramDef : params) {
				GamificationDetails gamePoint = new GamificationDetails();
				boolean flag = false;

				paramName = paramDef.getAssetParamName();

				// Fetch values for the particular parameter, asset instance and
				// version

				if (log.isTraceEnabled()) {
					log.trace("CopyPropertiesForChildInstanceUtil || called dao method : getParameterForAssetInstParamAndVersionId() : "
							+ paramName + "and" + oldAivId);
				}
          
				pv = assetDao.getParameterForAssetInstParamAndVersionId(
						paramName, oldAivId, conn);

				if (null != pv) {

					if (paramDef.isHasStaticValue()) {
						if (log.isTraceEnabled()) {
							log.trace("CopyPropertiesForChildInstanceUtil || called dao method : getParamIdForAssetAndParamName() : "
									+ aiv1.getAssetName() + "and" + paramName);
						}

						apd = assetDao.getParamIdForAssetAndParamName(
								aiv1.getAssetName(), paramName, conn);
					}
					nv = new NameValue();
					nv.setName(paramName);
					if (paramDef.getParamTypeId() == (Constants.FILE_TYPE)) {
						if (pv.getFileName() != null && pv.getFileName() != ""
								&& (pv.isImportant() == true)) {

							flag = true;
							gamePoint.setField("Parameter - " + paramName);
							gamePoint.setAction("Created");
						}
						nv.setFileName(pv.getFileName());
						nv.setFileMimeType(pv.getMimeType());
						nv.setByteValue(pv.getFileContent());

						if (pv.getFileName().endsWith(".png")
								|| pv.getFileName().endsWith(".jpg")
								|| pv.getFileName().endsWith(".jpeg")
								|| pv.getFileName().endsWith(".PNG")
								|| pv.getFileName().endsWith(".JPG")
								|| pv.getFileName().endsWith(".JPEG")) {

							if (paramDef.isHasStaticValue()) {

								FileOutputStream fos = new FileOutputStream(
										System.getProperty("java.io.tmpdir")
												+ apd.getAssetParamId()
														.toString() + "_"
												+ pv.getFileName());

								fos.write(pv.getFileContent());

								fos.close();
							} else {

								FileOutputStream fos = new FileOutputStream(
										System.getProperty("java.io.tmpdir")
												+ pv.getFileName());

								fos.write(pv.getFileContent());

								fos.close();
							}

							Image image;

							if (paramDef.isHasStaticValue()) {
								image = Toolkit.getDefaultToolkit().getImage(
										System.getProperty("java.io.tmpdir")
												+ apd.getAssetParamId()
														.toString() + "_"
												+ pv.getFileName());
							} else {

								image = Toolkit.getDefaultToolkit().getImage(
										System.getProperty("java.io.tmpdir")
												+ pv.getFileName());
							}

							MediaTracker mediaTracker = new MediaTracker(
									new Container());
							mediaTracker.addImage(image, 0);
							mediaTracker.waitForID(0);
							int thumbWidth = 60;
							int thumbHeight = 60;
							int quality = 100;

							double thumbRatio = (double) thumbWidth
									/ (double) thumbHeight;
							int imageWidth = image.getWidth(null);
							int imageHeight = image.getHeight(null);
							double imageRatio = (double) imageWidth
									/ (double) imageHeight;
							if (thumbRatio < imageRatio) {
								thumbHeight = (int) (thumbWidth / imageRatio);
							} else {
								thumbWidth = (int) (thumbHeight * imageRatio);
							}
							BufferedImage thumbImage = new BufferedImage(
									thumbWidth, thumbHeight,
									BufferedImage.TYPE_INT_RGB);
							Graphics2D graphics2D = thumbImage.createGraphics();
							graphics2D
									.setRenderingHint(
											RenderingHints.KEY_INTERPOLATION,
											RenderingHints.VALUE_INTERPOLATION_BILINEAR);
							graphics2D.drawImage(image, 0, 0, thumbWidth,
									thumbHeight, null);

							// save thumbnail image to outFilename
							//JPEGImageEncoder encoder;
							//JPEGEncodeParam param;
							BufferedOutputStream out;
							String sfile = "";

							File file4 = new File(
									System.getProperty("user.home")
											+ "/ThumbnailImages");
							if (!file4.exists()) {
								if (file4.mkdir()) {
									System.out
											.println("Directory thumbnailimages is created!");
								} else {
									System.out
											.println("Failed to create directory thumbnailimages!");
								}
							}

							if (paramDef.isHasStaticValue()) {
								out = new BufferedOutputStream(
										new FileOutputStream(context
												.getRealPath("")
												+ "/images/thumbnailImages/"
												+ apd.getAssetParamId()
														.toString()
												+ "_"
												+ pv.getFileName()));
								sfile = context.getRealPath("")
										+ "/images/thumbnailImages/"
										+ apd.getAssetParamId().toString()
										+ "_" + pv.getFileName();
								if(pv.getFileName().endsWith("jpg")){
									ImageIO.write(thumbImage, "jpg", new File(sfile));
								}else if(pv.getFileName().endsWith("png")){
									ImageIO.write(thumbImage, "png", new File(sfile));
								}else if(pv.getFileName().endsWith("jpeg")){
									ImageIO.write(thumbImage, "jpeg", new File(sfile));
								}else if(pv.getFileName().endsWith("JPG")){
									ImageIO.write(thumbImage, "JPG", new File(sfile));
								}else if(pv.getFileName().endsWith("PNG")){
									ImageIO.write(thumbImage, "PNG", new File(sfile));
								}else if(pv.getFileName().endsWith("JPEG")){
									ImageIO.write(thumbImage, "JPEG", new File(sfile));
								}
								/*encoder = JPEGCodec.createJPEGEncoder(out);
								param = encoder
										.getDefaultJPEGEncodeParam(thumbImage);
								quality = Math.max(0, Math.min(quality, 100));
								param.setQuality((float) quality / 100.0f,
										false);
								encoder.setJPEGEncodeParam(param);
								encoder.encode(thumbImage);*/
								// copy from above to user.home
							} else {

								out = new BufferedOutputStream(
										new FileOutputStream(context
												.getRealPath("")
												+ "/images/thumbnailImages/"
												+ pv.getFileName()));
								sfile = context.getRealPath("")
										+ "/images/thumbnailImages/"
										+ pv.getFileName();
								if(pv.getFileName().endsWith("jpg")){
									ImageIO.write(thumbImage, "jpg", new File(sfile));
								}else if(pv.getFileName().endsWith("png")){
									ImageIO.write(thumbImage, "png", new File(sfile));
								}else if(pv.getFileName().endsWith("jpeg")){
									ImageIO.write(thumbImage, "jpeg", new File(sfile));
								}else if(pv.getFileName().endsWith("JPG")){
									ImageIO.write(thumbImage, "JPG", new File(sfile));
								}else if(pv.getFileName().endsWith("PNG")){
									ImageIO.write(thumbImage, "PNG", new File(sfile));
								}else if(pv.getFileName().endsWith("JPEG")){
									ImageIO.write(thumbImage, "JPEG", new File(sfile));
								}
								//encoder = JPEGCodec.createJPEGEncoder(out);
								/*param = encoder
										.getDefaultJPEGEncodeParam(thumbImage);
								quality = Math.max(0, Math.min(quality, 100));
								param.setQuality((float) quality / 100.0f,
										false);
								encoder.setJPEGEncodeParam(param);
								encoder.encode(thumbImage);*/
								// copy from above to user.home
								java.util.Date date = new java.util.Date();
								String time = new Timestamp(date.getTime())
										.toString();
								valMap.put(paramName,
										time + "|" + pv.getFileName());
								// }
							}

							out.close();
							File sourceFile = new File(sfile);
							String name = sourceFile.getName();
							File targetFile = new File(
									System.getProperty("user.home")
											+ "/ThumbnailImages/" + name);
							FileUtils.copyFile(sourceFile, targetFile);

							if (paramDef.isHasStaticValue()) {

								File file1 = new File(
										System.getProperty("java.io.tmpdir")
												+ apd.getAssetParamId()
														.toString() + "_"
												+ pv.getFileName());
								if (file1.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");
							} else {

								File file1 = new File(
										System.getProperty("java.io.tmpdir")
												+ pv.getFileName());
								if (file1.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");
							}
						}
					} else {
						if(pv.getParamTypeId() == 7){
							if(pv.getHasArray() == 1){
							if (!pv.getRTFwithTags().isEmpty()&& (pv.isImportant() == true)) {

								flag = true;
								gamePoint.setField("Parameter - " + paramName);
								gamePoint.setAction("Created");

							}nv.setRTFwithTags(pv.getRTFwithTags());
							nv.setRTFwithOutTags(pv.getRTFwithOutTags());
							}else{
								if (!pv.getValue().isEmpty()&& (pv.isImportant() == true)) {

									flag = true;
									gamePoint.setField("Parameter - " + paramName);
									gamePoint.setAction("Created");

								}nv.setValue(pv.getValue()); // with tags 
								nv.setRTFPlainText(pv.getRTFPlainText()); // plain text without tags.
								
							}
						}else if (pv.getParamTypeId() == 1 ){
							if(pv.getHasArray() == 1){
							if (pv.getTextDataList() != null 
									&& (pv.isImportant() == true)) {

								flag = true;
								gamePoint.setField("Parameter - " + paramName);
								gamePoint.setAction("Created");

							}nv.setTextDataList(pv.getTextDataList());
							}else{
								if (pv.getValue() != null 
										&& (pv.isImportant() == true)) {

									flag = true;
									gamePoint.setField("Parameter - " + paramName);
									gamePoint.setAction("Created");

								}nv.setValue(pv.getValue());
								
							}
							
						}else if (pv.getParamTypeId() == 9 ){
							if (pv.getLdapMappingList() != null 
									&& (pv.isImportant() == true)) {

								flag = true;
								gamePoint.setField("Parameter - " + paramName);
								gamePoint.setAction("Created");

							}nv.setLdapMappingList(pv.getLdapMappingList());
							nv.setLdapMappingMap(pv.getLdapMappingMap());

						}else{
							if (!pv.getValue().isEmpty()
									&& (pv.isImportant() == true)) {

								flag = true;
								gamePoint.setField("Parameter - " + paramName);
								gamePoint.setAction("Created");

							}
							nv.setValue(pv.getValue());
						}
					}
					// Add parameter value
					// Get asset_param_id for asset type and parameter

					if (log.isTraceEnabled()) {
						log.trace("CopyPropertiesForChildInstanceUtil || called dao method : getParamIdForAssetAndParamName() : "
								+ aiv1.getAssetName() + "and" + nv.getName());
					}

					AssetParamDef param = assetDao
							.getParamIdForAssetAndParamName(
									aiv1.getAssetName(), nv.getName(), conn);

					// If the parameter has static value, update AssetParamDef
					if (param.isHasStaticValue()) {
						if (param.getParamTypeId() == (Constants.FILE_TYPE)) {
							param.setStaticFileContent(nv.getByteValue());
							param.setFileName(nv.getFileName());
						} else {
							param.setStaticValue(nv.getValue());
						}
						param.setLastUpdatedTime(new Timestamp(Calendar
								.getInstance().getTimeInMillis()));

						param.setModifyByUserId(userId);

						if (log.isTraceEnabled()) {
							log.trace("CopyPropertiesForChildInstanceUtil || called dao method : updateParameterInAssetParamDef()");
						}
						if (nv.getByteValue() != null) {
							InputStream myInputStream = new ByteArrayInputStream(
									nv.getByteValue());
							param.setImage(myInputStream);
						}

						assetDao.updateParameterInAssetParamDef(param,
								aiv1.getAssetName(), nv.getName(), conn);
					}

					else {
						AssetInstParams assetInstParams = new AssetInstParams();

						assetInstParams.setAssetInstVersionId(aiv1
								.getAssetInstVersionId());
						assetInstParams
								.setAssetParamId(param.getAssetParamId());
						assetInstParams.setLastUpdatedTime(new Timestamp(
								Calendar.getInstance().getTimeInMillis()));

						assetInstParams.setModifyByUserId(userId);

						if (log.isTraceEnabled()) {
							log.trace("CopyPropertiesForChildInstanceUtil || called dao method : addAssetInstParam() : "
									+ assetInstParams.toString());
						}

						assetDao.addAssetInstParam(assetInstParams, conn);
						ParameterValues paramValue = new ParameterValues();

						paramValue.setAssetInstParamId(assetInstParams
								.getAssetInstParamId());

						
						if(param.getParamTypeId() == 1){
							if(param.getHasArray() == 1){
							for (int i = 0; i < nv.getTextDataList().size(); i++) {
								paramValue.setValue(nv.getTextDataList().get(i));
								assetDao.addParameterValue(paramValue, conn);
							}
							}else{
								paramValue.setValue(nv.getValue());
								assetDao.addParameterValue(paramValue, conn);
							}
						}else if (param.getParamTypeId() == 7){
							if(param.getHasArray() == 1){
								for (int i = 0; i < nv.getRTFwithTags().size(); i++) {
									if(nv.getRTFwithTags().get(i) != null){
										paramValue.setRTFText(nv.getRTFwithTags().get(i));
									}else{
										paramValue.setRTFText("");
									} if(nv.getRTFwithOutTags().get(i) != null){
										paramValue.setRTFPlainText(nv.getRTFwithOutTags().get(i));
									}else{
										paramValue.setRTFPlainText("");
									}
									assetDao.addParameterValuesForRichText(paramValue, conn);
								}
							}else{
								paramValue.setRTFText(nv.getValue());
								paramValue.setRTFPlainText(nv.getRTFPlainText());
								assetDao.addParameterValuesForRichText(paramValue, conn);
							}
						}else if (param.getParamTypeId() == 9){
							AssetParamDef assetParamDef = assetDao.getParamIdForAssetAndParamName(aiv1.getAssetName(), param.getAssetParamName(), conn);
							List<LdapMapping> ldapAttributeList = assetDao.getLdapMappingAttributeList(assetParamDef.getLdapMappingId(), conn);

							if(!nv.getLdapMappingMap().isEmpty()){
								for (Map.Entry<String,Integer> entry : nv.getLdapMappingMap().entrySet()) {
									for(LdapMapping attribute:ldapAttributeList){
										if(entry.getValue() == attribute.getLdapAttributeId()) {
											paramValue.setValue(entry.getKey());
											paramValue.setLdapAttributeId(entry.getValue());
											assetDao.addParameterValueForLdapMapping(paramValue, conn);
										}
									}
								}
								// for adding revision history
								List<String> ldapmappinglist = nv.getLdapMappingMap().keySet().stream().collect(Collectors.toList());
								String ldapmappingdata = String.join("``", ldapmappinglist);
								param.setParamValue(ldapmappingdata);

							}else{
								List<String> ldapmappinglist = new ArrayList<String>();
								for(LdapMapping attribute:ldapAttributeList){
									paramValue.setValue("");
									paramValue.setLdapAttributeId(attribute.getLdapAttributeId());
									ldapmappinglist.add(paramValue.getValue());
									assetDao.addParameterValueForLdapMapping(paramValue, conn);
								}
								String ldapmappingdata = String.join("``", ldapmappinglist);
								param.setParamValue(ldapmappingdata);

							}

						}else if (param.getParamTypeId() == (Constants.FILE_TYPE)){
								if (nv.getByteValue() != null) {
									InputStream myInputStream = new ByteArrayInputStream(
											nv.getByteValue());
									paramValue.setImage(myInputStream);
									paramValue.setFileName(nv.getFileName());
								}
								assetDao.addParameterValue(paramValue, conn);	
							}else{	
								paramValue.setValue(nv.getValue());
								assetDao.addParameterValue(paramValue, conn);
							}
						}
					

				}// End of null check of parameter value
					// GamificationDetails gamepoint2 = new
					// GamificationDetails();
				if (flag == true && !userName.equals("admin")
						&& activeFlag == 1) {
					gamePoint.setPoints("1");
					gamePoint.setActivityTimestamp(new Timestamp(Calendar
							.getInstance().getTimeInMillis()).toString());

					gamePoint.setUserId(userId);
					gamePoint.setAssetId(String.valueOf(aiv1.getAssetId()));
					gamePoint.setAssetInstanceVersionId(aiv1
							.getAssetInstVersionId().toString());
					if (versionableFlag == 1) {
						gamePoint.setInstanceDetails(aiv1.getAssetName() + "~"
								+ aiv1.getAssetInstName() + "~"
								+ aiv1.getVersionName());
					} else {
						gamePoint.setInstanceDetails(aiv1.getAssetName() + "~"
								+ aiv1.getAssetInstName() + "~N/A");
					}

					if (log.isTraceEnabled()) {
						log.trace("CopyPropertiesForChildInstanceUtil || called dao method : addGamificationPoint() : "
								+ gamePoint.toString());
					}

					gamificationDao.addGamificationPoint(gamePoint, conn);

				}
			}// End of looping through parameter definitions

			if (!valMap.isEmpty()) {
				for (Map.Entry<String, String> entry : valMap.entrySet()) {

					if (log.isTraceEnabled()) {
						log.trace("CopyPropertiesForChildInstanceUtil || called dao method : getParameterForAssetInstParamAndVersionId() : "
								+ entry.getKey()
								+ "and"
								+ aiv1.getAssetInstVersionId());
					}
					pv = assetDao.getParameterForAssetInstParamAndVersionId(
							entry.getKey(), aiv1.getAssetInstVersionId(), conn);

					if (pv != null) {
						String splitVal = entry.getValue().substring(
								entry.getValue().indexOf("|") + 1);

						File oldfile = new File(context.getRealPath("")
								+ "/images/thumbnailImages/" + splitVal);

						File newfile = new File(context.getRealPath("")
								+ "/images/thumbnailImages/"
								+ pv.getAssetInstParamId().toString() + "_"
								+ splitVal);

						oldfile.renameTo(newfile);

						File oldfile1 = new File(
								System.getProperty("user.home")
										+ "/ThumbnailImages/" + splitVal);
						File newfile1 = new File(
								System.getProperty("user.home")
										+ "/ThumbnailImages/"
										+ pv.getAssetInstParamId().toString()
										+ "_" + splitVal);
						oldfile1.renameTo(newfile1);
					}
				}
			}

		}
		catch (RepoproException e1) {
			e1.printStackTrace();
			throw new RepoproException(e1.getMessage());
		} catch (Exception e1) {
			e1.printStackTrace();
			throw new RepoproException(e1.getMessage());
		}

	}
	public static Map<Long, List<String>> addValues(Long key,String value,Map<Long,List<String>> hashMap){
		List<String> tempList = null;
		if(hashMap.containsKey(key)){
			tempList = hashMap.get(key);
			if(tempList==null)
				tempList = new ArrayList<String>();
			tempList.add(value);
		}else{
			tempList = new ArrayList<String>();
			tempList.add(value);
		}
		hashMap.put(key, tempList);
		return hashMap;
	}
	
	public static String decrypt(String str) {
		String decryptedPassword = null;
		
		try {
			/*
			 * Decrypting the password
			 */
		final String ALGO = "AES";
		final byte[] keyValue = new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't',
				'S', 'e', 'c', 'r', 'e', 't', 'K', 'e', 'y' };
		Key key = new SecretKeySpec(keyValue, ALGO);

		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.DECRYPT_MODE, key);
		byte[] decordedValue =  Base64.getDecoder().decode(str.getBytes());
		byte[] decValue = c.doFinal(decordedValue);
		decryptedPassword = new String(decValue);
		}
		 catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		return decryptedPassword;

	}
	
	public static String encrypt(String str) {
		String encryptedPassword = null;
		
		try {
			final String ALGO = "AES";
			final byte[] keyValue = 
					new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };
			Key key = new SecretKeySpec(keyValue, ALGO);;
		    Cipher c = Cipher.getInstance(ALGO);
		    c.init(Cipher.ENCRYPT_MODE, key);
		    byte[] encVal = c.doFinal(str.getBytes());
		    encryptedPassword = Base64.getEncoder().encodeToString(encVal);
		}
		 catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		return encryptedPassword;

	}
	
	public static void deleteDir(String dirName)
	{	
		try{
		 deleteFile(dirName);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	private static boolean deleteFile(String sFilePath)
	  {
	    File oFile = new File(sFilePath);
	    
	    if(oFile.isDirectory())
	    {
	      File[] aFiles = oFile.listFiles();
	      for(File oFileCur: aFiles)
	      {
	         deleteFile(oFileCur.getAbsolutePath());
	      }
	    }
	   
	    return oFile.delete();
	  }
	
	public User userDetails(String token) throws Exception {
		UserDao userDao = new UserDao();
		User user = null;
		try {
			user = userDao.getUserDetailsByToken(token, null);
		} catch (RepoproException e) {
			e.printStackTrace();
			throw new Exception("User Details not found");
		}
		return user;
		
		
	}
	
	public User getUserDetailsFromOauth(String token) throws Exception {
		UserDao userDao = new UserDao();
		User user = null;
		try {
			user = userDao.getUserDetailsByOauthToken(token, null);
		} catch (RepoproException e) {
			e.printStackTrace();
			throw new Exception("User Details not found");
		}
		return user;
		
		
	}
	
	public Map<String,Integer> ldapDataconstruction(String searchString,String assetName,String paramName,Connection conn) throws Exception {
		
		LdapMapping LdapMapping = null;
		AssetDao assetDao = new AssetDao();
		AssetParamDef assetParamDef = new AssetParamDef();
		List<String> finalParamValList = new ArrayList<String>();
		Map<String,Integer> paramValList = new LinkedHashMap<String,Integer>();
		try {
			LDAPConnection ldapConnection = LDAPConnection.getInstance();
			DirContext dirContext = ldapConnection.getDirContext();
			LDAPUtility ldapUtility = new LDAPUtility();
			
			List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();

			assetParamDef = assetDao.getParamIdForAssetAndParamName(assetName, paramName, conn);
			
			List<LdapMapping> ldapAttributeList = assetDao.getLdapMappingAttributeList(assetParamDef.getLdapMappingId(), conn);
			
			List<String> ParamValList = new ArrayList<String>(Arrays.asList(searchString.split("~~")));
			
			String firstName = "";
			String lastName = "";
			String emailId = "";
			String dept = "";
			String userId = "";
			String userName = "";
			String fullName = "";
			int firstNameId = 0;
			int lastNameId = 0;
			int emailIdId = 0;
			int deptId = 0;
			int user_id = 0;
			int userNameId = 0;
			int fullNameId = 0;
			for(String searchdata:ParamValList) {
				listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,searchdata);

				if(listOfLDAPUsers.size() == 1){
					for(LDAPUser finaldata:listOfLDAPUsers) {
						for(LdapMapping attribute:ldapAttributeList){
							String attributeName = attribute.getAttributeName().substring(3);
							if(attributeName.equalsIgnoreCase(CommonUtils.LdapFirstName)) {
								if(firstName.equalsIgnoreCase("")) {
									firstName = finaldata.getFirstName();
								}else {
									firstName = firstName +"~~"+finaldata.getFirstName();
								}
								firstNameId = attribute.getLdapAttributeId();
							}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapLastName)) {
								if(lastName.equalsIgnoreCase("")) {
									lastName = finaldata.getLastName();
								}else {
									lastName = lastName +"~~"+finaldata.getLastName();
								}
								lastNameId = attribute.getLdapAttributeId();
							}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapEmail)) {
								if(emailId.equalsIgnoreCase("")) {
									emailId = finaldata.getEmail();
								}else {
									emailId = emailId +"~~"+finaldata.getEmail();
								}
								emailIdId = attribute.getLdapAttributeId();
							}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapDept)) {
								if(dept.equalsIgnoreCase("")) {
									dept = finaldata.getDept();
								}else {
									dept = dept +"~~"+finaldata.getDept();
								}
								deptId = attribute.getLdapAttributeId();
							}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapUserId)) {
								if(userId.equalsIgnoreCase("")) {
									userId = finaldata.getUserId();
								}else {
									userId = userId +"~~"+finaldata.getUserId();
								}
								user_id = attribute.getLdapAttributeId();
							}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapFullName)) {
								if(fullName.equalsIgnoreCase("")) {
									fullName = finaldata.getFirstName()+" "+finaldata.getLastName();
								}else {
									fullName = fullName +"~~"+finaldata.getFirstName()+" "+finaldata.getLastName();
								}
								fullNameId = attribute.getLdapAttributeId();
							}
						}
					}
				}
			}
			
			if(!firstName.equalsIgnoreCase("") && firstNameId!=0) {
			finalParamValList.add(firstName);
			paramValList.put(firstName, firstNameId);}
			
			if(!lastName.equalsIgnoreCase("") && lastNameId!=0) {
			finalParamValList.add(lastName);
			paramValList.put(lastName, lastNameId);}
			
			if(!emailId.equalsIgnoreCase("") && emailIdId!=0) {
			finalParamValList.add(emailId);
			paramValList.put(emailId, emailIdId);}
			
			if(!dept.equalsIgnoreCase("") && deptId!=0) {
			finalParamValList.add(dept);
			paramValList.put(dept, deptId);}
			
			if(!userId.equalsIgnoreCase("") && user_id!=0) {
			finalParamValList.add(userId);
			paramValList.put(userId, user_id);}
			
			if(!fullName.equalsIgnoreCase("") && fullNameId!=0) {
			finalParamValList.add(fullName);
			paramValList.put(fullName, fullNameId);}
			
		} catch (RepoproException e) {
			e.printStackTrace();
			throw new Exception("User Details not found");
		}
		return paramValList;
	}
	
	public String  CopyParameterForChildInstanceForCopyVersionNone(AssetInstanceVersion aiv1,
		     Long userId, String copyFromVersion, Long oldAivId, 
			String userName, int activeFlag, int versionableFlag,
			@Context ServletContext context, Connection conn)
					throws RepoproException{

		String newParamDataForRevision = "";
		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("CopyParameterForChildInstanceForCopyVersionNone : "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			// copy properties for child instance
			String paramName;
			NameValue nv;
			ParameterValues pv = new ParameterValues();
			AssetParamDef apd = new AssetParamDef();

			// Fetch parameter definitions for the asset

			if (log.isTraceEnabled()) {
				log.trace("CopyParameterForChildInstanceForCopyVersionNone || called dao method : getParamsDetailByAssetName() by AssetName: "
						+ aiv1.getAssetName());
			}

			List<AssetParamDef> params = assetDao.getParamsDetailByAssetName(
					aiv1.getAssetName(), conn);

			for (AssetParamDef paramDef : params) {
				if(paramDef.isHasMandatoryValue()){
				GamificationDetails gamePoint = new GamificationDetails();
				boolean flag = false;

				paramName = paramDef.getAssetParamName();

				// Fetch values for the particular parameter, asset instance and
				// version

				if (log.isTraceEnabled()) {
					log.trace("CopyParameterForChildInstanceForCopyVersionNone || called dao method : getParameterForAssetInstParamAndVersionId() : "
							+ paramName + "and" + oldAivId);
				}
         
				pv = assetDao.getParameterForAssetInstParamAndVersionId(
						paramName, oldAivId, conn);

				if (null != pv) {

					if (paramDef.isHasStaticValue()) {
						if (log.isTraceEnabled()) {
							log.trace("CopyParameterForChildInstanceForCopyVersionNone || called dao method : getParamIdForAssetAndParamName() : "
									+ aiv1.getAssetName() + "and" + paramName);
						}

						apd = assetDao.getParamIdForAssetAndParamName(
								aiv1.getAssetName(), paramName, conn);
					}
					nv = new NameValue();
					nv.setName(paramName);
					if (paramDef.getParamTypeId() == (Constants.FILE_TYPE)) {
						if (pv.getFileName() != null && pv.getFileName() != ""
								&& (pv.isImportant() == true)) {

							flag = true;
							gamePoint.setField("Parameter - " + paramName);
							gamePoint.setAction("Created");
						}
						nv.setFileName(pv.getFileName());
						nv.setFileMimeType(pv.getMimeType());
						nv.setByteValue(pv.getFileContent());

						if (pv.getFileName().endsWith(".png")
								|| pv.getFileName().endsWith(".jpg")
								|| pv.getFileName().endsWith(".jpeg")
								|| pv.getFileName().endsWith(".PNG")
								|| pv.getFileName().endsWith(".JPG")
								|| pv.getFileName().endsWith(".JPEG")) {

							if (paramDef.isHasStaticValue()) {

								FileOutputStream fos = new FileOutputStream(
										System.getProperty("java.io.tmpdir")
												+ apd.getAssetParamId()
														.toString() + "_"
												+ pv.getFileName());

								fos.write(pv.getFileContent());

								fos.close();
							} else {

								FileOutputStream fos = new FileOutputStream(
										System.getProperty("java.io.tmpdir")
												+ pv.getFileName());

								fos.write(pv.getFileContent());

								fos.close();
							}

							Image image;

							if (paramDef.isHasStaticValue()) {
								image = Toolkit.getDefaultToolkit().getImage(
										System.getProperty("java.io.tmpdir")
												+ apd.getAssetParamId()
														.toString() + "_"
												+ pv.getFileName());
							} else {

								image = Toolkit.getDefaultToolkit().getImage(
										System.getProperty("java.io.tmpdir")
												+ pv.getFileName());
							}

							MediaTracker mediaTracker = new MediaTracker(
									new Container());
							mediaTracker.addImage(image, 0);
							mediaTracker.waitForID(0);
							int thumbWidth = 60;
							int thumbHeight = 60;
							int quality = 100;

							double thumbRatio = (double) thumbWidth
									/ (double) thumbHeight;
							int imageWidth = image.getWidth(null);
							int imageHeight = image.getHeight(null);
							double imageRatio = (double) imageWidth
									/ (double) imageHeight;
							if (thumbRatio < imageRatio) {
								thumbHeight = (int) (thumbWidth / imageRatio);
							} else {
								thumbWidth = (int) (thumbHeight * imageRatio);
							}
							BufferedImage thumbImage = new BufferedImage(
									thumbWidth, thumbHeight,
									BufferedImage.TYPE_INT_RGB);
							Graphics2D graphics2D = thumbImage.createGraphics();
							graphics2D
									.setRenderingHint(
											RenderingHints.KEY_INTERPOLATION,
											RenderingHints.VALUE_INTERPOLATION_BILINEAR);
							graphics2D.drawImage(image, 0, 0, thumbWidth,
									thumbHeight, null);

							// save thumbnail image to outFilename
							//JPEGImageEncoder encoder;
							//JPEGEncodeParam param;
							BufferedOutputStream out;
							String sfile = "";

							File file4 = new File(
									System.getProperty("user.home")
											+ "/ThumbnailImages");
							if (!file4.exists()) {
								if (file4.mkdir()) {
									System.out
											.println("Directory thumbnailimages is created!");
								} else {
									System.out
											.println("Failed to create directory thumbnailimages!");
								}
							}

							if (paramDef.isHasStaticValue()) {
								out = new BufferedOutputStream(
										new FileOutputStream(context
												.getRealPath("")
												+ "/images/thumbnailImages/"
												+ apd.getAssetParamId()
														.toString()
												+ "_"
												+ pv.getFileName()));
								sfile = context.getRealPath("")
										+ "/images/thumbnailImages/"
										+ apd.getAssetParamId().toString()
										+ "_" + pv.getFileName();
								if(pv.getFileName().endsWith("jpg")){
									ImageIO.write(thumbImage, "jpg", new File(sfile));
								}else if(pv.getFileName().endsWith("png")){
									ImageIO.write(thumbImage, "png", new File(sfile));
								}else if(pv.getFileName().endsWith("jpeg")){
									ImageIO.write(thumbImage, "jpeg", new File(sfile));
								}else if(pv.getFileName().endsWith("JPG")){
									ImageIO.write(thumbImage, "JPG", new File(sfile));
								}else if(pv.getFileName().endsWith("PNG")){
									ImageIO.write(thumbImage, "PNG", new File(sfile));
								}else if(pv.getFileName().endsWith("JPEG")){
									ImageIO.write(thumbImage, "JPEG", new File(sfile));
								}
							
								/*encoder = JPEGCodec.createJPEGEncoder(out);
								param = encoder
										.getDefaultJPEGEncodeParam(thumbImage);
								quality = Math.max(0, Math.min(quality, 100));
								param.setQuality((float) quality / 100.0f,
										false);
								encoder.setJPEGEncodeParam(param);
								encoder.encode(thumbImage);*/
								// copy from above to user.home
							} else {

								out = new BufferedOutputStream(
										new FileOutputStream(context
												.getRealPath("")
												+ "/images/thumbnailImages/"
												+ pv.getFileName()));
								sfile = context.getRealPath("")
										+ "/images/thumbnailImages/"
										+ pv.getFileName();
								
								if(pv.getFileName().endsWith("jpg")){
									ImageIO.write(thumbImage, "jpg", new File(sfile));
								}else if(pv.getFileName().endsWith("png")){
									ImageIO.write(thumbImage, "png", new File(sfile));
								}else if(pv.getFileName().endsWith("jpeg")){
									ImageIO.write(thumbImage, "jpeg", new File(sfile));
								}else if(pv.getFileName().endsWith("JPG")){
									ImageIO.write(thumbImage, "JPG", new File(sfile));
								}else if(pv.getFileName().endsWith("PNG")){
									ImageIO.write(thumbImage, "PNG", new File(sfile));
								}else if(pv.getFileName().endsWith("JPEG")){
									ImageIO.write(thumbImage, "JPEG", new File(sfile));
								}

								/*encoder = JPEGCodec.createJPEGEncoder(out);
								param = encoder
										.getDefaultJPEGEncodeParam(thumbImage);
								quality = Math.max(0, Math.min(quality, 100));
								param.setQuality((float) quality / 100.0f,
										false);
								encoder.setJPEGEncodeParam(param);
								encoder.encode(thumbImage);*/
								// copy from above to user.home
								java.util.Date date = new java.util.Date();
								String time = new Timestamp(date.getTime())
										.toString();
								valMap.put(paramName,
										time + "|" + pv.getFileName());
								// }
							}

							out.close();
							File sourceFile = new File(sfile);
							String name = sourceFile.getName();
							File targetFile = new File(
									System.getProperty("user.home")
											+ "/ThumbnailImages/" + name);
							FileUtils.copyFile(sourceFile, targetFile);

							if (paramDef.isHasStaticValue()) {

								File file1 = new File(
										System.getProperty("java.io.tmpdir")
												+ apd.getAssetParamId()
														.toString() + "_"
												+ pv.getFileName());
								if (file1.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");
							} else {

								File file1 = new File(
										System.getProperty("java.io.tmpdir")
												+ pv.getFileName());
								if (file1.delete()) {
									System.out.println(" File deleted");
								} else
									System.out.println("File doesn't exists");
							}
						}
					} else {
						if(pv.getParamTypeId() == 7){
							if(pv.getHasArray() == 1){
							if (!pv.getRTFwithTags().isEmpty()&& (pv.isImportant() == true)) {

								flag = true;
								gamePoint.setField("Parameter - " + paramName);
								gamePoint.setAction("Created");

							}nv.setRTFwithTags(pv.getRTFwithTags());
							nv.setRTFwithOutTags(pv.getRTFwithOutTags());
							}else{
								if (!pv.getValue().isEmpty()&& (pv.isImportant() == true)) {

									flag = true;
									gamePoint.setField("Parameter - " + paramName);
									gamePoint.setAction("Created");

								}nv.setValue(pv.getValue()); // with tags 
								nv.setRTFPlainText(pv.getRTFPlainText()); // plain text without tags.
								
							}
						}else if (pv.getParamTypeId() == 1 ){
							if(pv.getHasArray() == 1){
							if (pv.getTextDataList() != null 
									&& (pv.isImportant() == true)) {

								flag = true;
								gamePoint.setField("Parameter - " + paramName);
								gamePoint.setAction("Created");

							}nv.setTextDataList(pv.getTextDataList());
							}else{
								if (pv.getValue() != null 
										&& (pv.isImportant() == true)) {

									flag = true;
									gamePoint.setField("Parameter - " + paramName);
									gamePoint.setAction("Created");

								}nv.setValue(pv.getValue());
								
							}
							
						}else if (pv.getParamTypeId() == 9 ){
							if (pv.getLdapMappingList() != null 
									&& (pv.isImportant() == true)) {

								flag = true;
								gamePoint.setField("Parameter - " + paramName);
								gamePoint.setAction("Created");

							}nv.setLdapMappingList(pv.getLdapMappingList());
							nv.setLdapMappingMap(pv.getLdapMappingMap());

						}else{
						if (!pv.getValue().isEmpty()
								&& (pv.isImportant() == true)) {

							flag = true;
							gamePoint.setField("Parameter - " + paramName);
							gamePoint.setAction("Created");

						}
						nv.setValue(pv.getValue());
						}
					}
					// Add parameter value
					// Get asset_param_id for asset type and parameter

					if (log.isTraceEnabled()) {
						log.trace("CopyParameterForChildInstanceForCopyVersionNone || called dao method : getParamIdForAssetAndParamName() : "
								+ aiv1.getAssetName() + "and" + nv.getName());
					}

					AssetParamDef param = assetDao
							.getParamIdForAssetAndParamName(
									aiv1.getAssetName(), nv.getName(), conn);

					// If the parameter has static value, update AssetParamDef
					if (param.isHasStaticValue()) {
						if (param.getParamTypeId() == (Constants.FILE_TYPE)) {
							param.setStaticFileContent(nv.getByteValue());
							param.setFileName(nv.getFileName());
						} else {
							param.setStaticValue(nv.getValue());
						}
						param.setLastUpdatedTime(new Timestamp(Calendar
								.getInstance().getTimeInMillis()));

						param.setModifyByUserId(userId);

						if (log.isTraceEnabled()) {
							log.trace("CopyPropertiesForChildInstanceUtil || called dao method : updateParameterInAssetParamDef()");
						}
						if (nv.getByteValue() != null) {
							InputStream myInputStream = new ByteArrayInputStream(
									nv.getByteValue());
							param.setImage(myInputStream);
						}

						assetDao.updateParameterInAssetParamDef(param,
								aiv1.getAssetName(), nv.getName(), conn);
					}

					else {
						AssetInstParams assetInstParams = new AssetInstParams();

						assetInstParams.setAssetInstVersionId(aiv1
								.getAssetInstVersionId());
						assetInstParams
								.setAssetParamId(param.getAssetParamId());
						assetInstParams.setLastUpdatedTime(new Timestamp(
								Calendar.getInstance().getTimeInMillis()));

						assetInstParams.setModifyByUserId(userId);

						if (log.isTraceEnabled()) {
							log.trace("CopyParameterForChildInstanceForCopyVersionNone || called dao method : addAssetInstParam() : "
									+ assetInstParams.toString());
						}

						assetDao.addAssetInstParam(assetInstParams, conn);
						ParameterValues paramValue = new ParameterValues();

						paramValue.setAssetInstParamId(assetInstParams
								.getAssetInstParamId());

						
						if(param.getParamTypeId() == 1){
							if(param.getHasArray() == 1){
							for (int i = 0; i < nv.getTextDataList().size(); i++) {
								paramValue.setValue(nv.getTextDataList().get(i));
								assetDao.addParameterValue(paramValue, conn);
							}// for adding revision history
							String textdata = String.join("~~", nv.getTextDataList());
							param.setParamValue(textdata);
							}else{
								paramValue.setValue(nv.getValue());
								param.setParamValue(nv.getValue());
								assetDao.addParameterValue(paramValue, conn);
							}
						}else if (param.getParamTypeId() == 7){
							if(param.getHasArray() == 1){
							for (int i = 0; i < nv.getRTFwithTags().size(); i++) {
							if(nv.getRTFwithTags().get(i) != null){
								paramValue.setRTFText(nv.getRTFwithTags().get(i));
							}else{
								paramValue.setRTFText("");
							} if(nv.getRTFwithOutTags().get(i) != null){
								paramValue.setRTFPlainText(nv.getRTFwithOutTags().get(i));
							}else{
								paramValue.setRTFPlainText("");
							}
							assetDao.addParameterValuesForRichText(paramValue, conn);
						}
							// for adding revision history
							String textdata = String.join("~~", nv.getRTFwithTags());
							param.setParamValue(textdata);
							}else{
								paramValue.setRTFText(nv.getValue());
								param.setParamValue(nv.getValue());
								paramValue.setRTFPlainText(nv.getRTFPlainText());
								assetDao.addParameterValuesForRichText(paramValue, conn);
							}
						}else if (param.getParamTypeId() == 9){
							AssetParamDef assetParamDef = assetDao.getParamIdForAssetAndParamName(aiv1.getAssetName(), param.getAssetParamName(), conn);
							List<LdapMapping> ldapAttributeList = assetDao.getLdapMappingAttributeList(assetParamDef.getLdapMappingId(), conn);

							if(!nv.getLdapMappingMap().isEmpty()){
								for (Map.Entry<String,Integer> entry : nv.getLdapMappingMap().entrySet()) {
									for(LdapMapping attribute:ldapAttributeList){
										if(entry.getValue() == attribute.getLdapAttributeId()) {
											paramValue.setValue(entry.getKey());
											paramValue.setLdapAttributeId(entry.getValue());
											assetDao.addParameterValueForLdapMapping(paramValue, conn);
										}
									}
								}
								// for adding revision history
								List<String> ldapmappinglist = nv.getLdapMappingMap().keySet().stream().collect(Collectors.toList());
								String ldapmappingdata = String.join("``", ldapmappinglist);
								param.setParamValue(ldapmappingdata);

							}else{
								List<String> ldapmappinglist = new ArrayList<String>();
								for(LdapMapping attribute:ldapAttributeList){
									paramValue.setValue("");
									paramValue.setLdapAttributeId(attribute.getLdapAttributeId());
									ldapmappinglist.add(paramValue.getValue());
									assetDao.addParameterValueForLdapMapping(paramValue, conn);
								}
								String ldapmappingdata = String.join("``", ldapmappinglist);
								param.setParamValue(ldapmappingdata);

							}

						}else if (param.getParamTypeId() == (Constants.FILE_TYPE)){
								if (nv.getByteValue() != null) {
									InputStream myInputStream = new ByteArrayInputStream(
											nv.getByteValue());
									paramValue.setImage(myInputStream);
									paramValue.setFileName(nv.getFileName());
								}
								param.setParamValue(nv.getFileName());
								assetDao.addParameterValue(paramValue, conn);	
							}else{	
								paramValue.setValue(nv.getValue());
								param.setParamValue(nv.getValue());
								assetDao.addParameterValue(paramValue, conn);
							}
						
						// parameter data revision history for non static
						
						
						if (param.getParamValue() != null) {
							if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
								newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
										+ param.getParamValue() + Constants.APPEND_STRING;
							}
						} else {
							if ((param.getParamTypeId() != 5) && param.getParamTypeId() != 6) {
								newParamDataForRevision = newParamDataForRevision + param.getAssetParamName() + ":"
										+ Constants.APPEND_STRING;
							}
						}
					}
					

				}// End of null check of parameter value
				else{
					if (paramDef.isHasStaticValue()) {
						if (paramDef.getParamTypeId() == (Constants.FILE_TYPE)) {
							// parameter data revision history for static file type
							if (paramDef.getFileName() != null) {
								if ((paramDef.getParamTypeId() != 5) && paramDef.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision + paramDef.getAssetParamName() + ":"
											+ paramDef.getFileName() + Constants.APPEND_STRING;
								}
							} else {
								if ((paramDef.getParamTypeId() != 5) && paramDef.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision + paramDef.getAssetParamName() + ":"
											+ Constants.APPEND_STRING;
								}
							}
						} else {
							// parameter data revision history for static other than file type
							if (paramDef.getStaticValue() != null) {
								if ((paramDef.getParamTypeId() != 5) && paramDef.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision + paramDef.getAssetParamName() + ":"
											+ paramDef.getStaticValue() + Constants.APPEND_STRING;
								}
							} else {
								if ((paramDef.getParamTypeId() != 5) && paramDef.getParamTypeId() != 6) {
									newParamDataForRevision = newParamDataForRevision + paramDef.getAssetParamName() + ":"
											+ Constants.APPEND_STRING;
								}
							}
						}
					}

				}
				
				// GamificationDetails gamepoint2 = new
					// GamificationDetails();
				if (flag == true && !userName.equals("admin")
						&& activeFlag == 1) {
					gamePoint.setPoints("1");
					gamePoint.setActivityTimestamp(new Timestamp(Calendar
							.getInstance().getTimeInMillis()).toString());

					gamePoint.setUserId(userId);
					gamePoint.setAssetId(String.valueOf(aiv1.getAssetId()));
					gamePoint.setAssetInstanceVersionId(aiv1
							.getAssetInstVersionId().toString());
					if (versionableFlag == 1) {
						gamePoint.setInstanceDetails(aiv1.getAssetName() + "~"
								+ aiv1.getAssetInstName() + "~"
								+ aiv1.getVersionName());
					} else {
						gamePoint.setInstanceDetails(aiv1.getAssetName() + "~"
								+ aiv1.getAssetInstName() + "~N/A");
					}

					if (log.isTraceEnabled()) {
						log.trace("CopyParameterForChildInstanceForCopyVersionNone || called dao method : addGamificationPoint() : "
								+ gamePoint.toString());
					}

					gamificationDao.addGamificationPoint(gamePoint, conn);

				}
				
				}//mandatory loop
			}// End of looping through parameter definitions

			if (!valMap.isEmpty()) {
				for (Map.Entry<String, String> entry : valMap.entrySet()) {

					if (log.isTraceEnabled()) {
						log.trace("CopyParameterForChildInstanceForCopyVersionNone || called dao method : getParameterForAssetInstParamAndVersionId() : "
								+ entry.getKey()
								+ "and"
								+ aiv1.getAssetInstVersionId());
					}
					pv = assetDao.getParameterForAssetInstParamAndVersionId(
							entry.getKey(), aiv1.getAssetInstVersionId(), conn);

					if (pv != null) {
						String splitVal = entry.getValue().substring(
								entry.getValue().indexOf("|") + 1);

						File oldfile = new File(context.getRealPath("")
								+ "/images/thumbnailImages/" + splitVal);

						File newfile = new File(context.getRealPath("")
								+ "/images/thumbnailImages/"
								+ pv.getAssetInstParamId().toString() + "_"
								+ splitVal);

						oldfile.renameTo(newfile);

						File oldfile1 = new File(
								System.getProperty("user.home")
										+ "/ThumbnailImages/" + splitVal);
						File newfile1 = new File(
								System.getProperty("user.home")
										+ "/ThumbnailImages/"
										+ pv.getAssetInstParamId().toString()
										+ "_" + splitVal);
						oldfile1.renameTo(newfile1);
					}
				}
			}

		}
		catch (RepoproException e1) {
			e1.printStackTrace();
			throw new RepoproException(e1.getMessage());
		} catch (Exception e1) {
			e1.printStackTrace();
			throw new RepoproException(e1.getMessage());
		}
		
		return newParamDataForRevision;
		
	}
	/**
	 * @method httpSanitizerForCkEditor
	 * @param httpUntrustString
	 * @return modified String
	 * @throws RepoproException
	 */
	public String httpSanitizerForCkEditor(String httpUntrustString) throws RepoproException
	{
		log.trace("httpSanitizerForCkEditor : begin");
		String safeHTML = "";
		try{
		//String textdata = StringEscapeUtils.unescapeHtml4(httpUntrustString);
		PolicyFactory policy = new HtmlPolicyBuilder()
		.allowElements("a","p","div","span","h1","h2","h3","h4","h5","h6","hr","abbr","address")
		.allowElements("strong","em","u","s","sub","sup","ol","li","ul")
		.allowElements("table","th","tr","td","thead","tbody","caption")
		.allowElements("pre")
		.allowUrlProtocols("https","http","ftp","news")
		.allowAttributes("href").onElements("a")
		.allowAttributes("target").onElements("a")
		.allowAttributes("style").onElements("p")
		.allowAttributes("style").onElements("span")
		.allowAttributes("border","cellpadding","cellspacing","style","summary").onElements("table")
		.allowAttributes("class","data-pbcklang","data-pbcktabsize").onElements("pre")
		.requireRelNofollowOnLinks()
		.toFactory();

		safeHTML = policy.sanitize(httpUntrustString);
		safeHTML = safeHTML.replace("&#64;","@");
		safeHTML = safeHTML.replace("&#34;","&quot;");
		safeHTML = safeHTML.replace("&#96;","`");
		safeHTML = safeHTML.replace("&#43;","+");
		safeHTML = safeHTML.replace("&#61;","=");
		
		//safeHTML = StringEscapeUtils.unescapeHtml4(safeHTML);
		log.trace("httpSanitizerForCkEditor : Exit ");
		}catch (Exception e1) {
			e1.printStackTrace();
			throw new RepoproException(e1.getMessage());
		}
		
		return safeHTML;
	}
	
	/**
	 * @method httpSanitizerForPlainText
	 * @param httpUntrustString
	 * @return modified String
	 * @throws RepoproException
	 */
	public  String httpSanitizerForPlainText(String httpUntrustString) throws RepoproException
	{
		log.trace("httpSanitizerForPlainText : begin");
		
		String safeHTML = "";
		try{
			PolicyFactory policy = new HtmlPolicyBuilder()
			.allowElements("a","p","div","span","b","i","h1","h2","h3","h4","h5","h6","br","hr","abbr","address","bdi")
			.allowElements("bdo","cite", "del","dfn","em","ins","kbd","mark", "q","s","samp","small")
			.allowElements("strong","sub","sup", "time","u","var","wbr","ul","li","ol","dl","dt","dd")
			.allowElements("table","th","tr","td","thead","tbody","tfoot","col","colgroup","header","footer")
			.allowElements("main","section","article","aside","details","dialog","summary")
			.allowUrlProtocols("https","http","ftp","news")
			.allowAttributes("href").onElements("a")
			.allowAttributes("dir").onElements("bdo")
			.allowAttributes("style").onElements("div")
			.requireRelNofollowOnLinks()
			.toFactory();
			safeHTML = policy.sanitize(httpUntrustString);
			
			safeHTML = StringEscapeUtils.unescapeHtml4(safeHTML);
		}catch (Exception e1) {
			e1.printStackTrace();
			throw new RepoproException(e1.getMessage());
		}
		log.trace("httpSanitizerForPlainText : Exit ");
		
		return safeHTML;
	}
	
	/**
	 * @method getUserNameFromNativeOroAuthMode 
	 * @param token
	 * @return username
	 * @throws RepoproException
	 */
	public String getUserNameFromNativeOroAuthMode(String token) throws RepoproException
	{
		log.trace("getUserNameFromNativeOroAuthMode : begin");

		Connection conn = null;
		String userName = "";
		GlobalSettingDao globalsettingDao = new GlobalSettingDao();
		UserDao userDao = new UserDao();
		boolean is_oAuth = false;
		List<GlobalSetting> globalSetting = null;
		try {
			globalSetting = globalsettingDao.getGlobalSetting(conn);

			for(GlobalSetting g : globalSetting){
				if(g.getMechanism().equalsIgnoreCase("oAuth")){
					is_oAuth = true;
					break;
				}
			}
			if(is_oAuth)
			{
				userName = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
				if(userName.equalsIgnoreCase("ROLE_ANONYMOUS")){
					userName = "guest";
				}
			}
			else
			{
				if(token != null){
					User userdata = userDetails(token);
					User username = userDao.getUserByUserId(userdata.getUserId(), null);
					userName = username.getUserName();
				}
				else
				{
					userName = "guest";
				}
			}
		}
		catch (Exception e1) {
			e1.printStackTrace();
			throw new RepoproException(e1.getMessage());
		}
		log.trace("getUserNameFromNativeOroAuthMode : Exit ");
		return userName;
	}
	
	
	public String validationForDerivedAssetListAttribute(String rule,String mainAssetName,String mainParamName,
			String oldAssetName, Connection conn, String userName) {
		
		if(rule == null) {
			log.warn("validationForDerivedAssetListAttribute || Derived Attribute Rule Should Not Be Null");
			return "Please Provide the Derived Attribute Rule!";
		}
		
		if(log.isTraceEnabled()){
			log.trace("validationForDerivedAssetListAttribute || Rule : "+rule
					+" mainAssetName "+mainAssetName+" mainParamName : "+mainParamName
					+" oldAssetName : "+oldAssetName);
		}
		StringBuffer sb = new StringBuffer();
		Connection conn1 = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAssetListAttribute || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			AssetDao assetDao = new AssetDao();
			
			AssetParamDef apdef = assetDao.getParamIdForAssetAndParamName(mainAssetName, mainParamName, conn);
			if(apdef != null) {
				if(apdef.getParamTypeId() != 8) {
					List<AssetParamDef> allDerivedAttributeForAssetList = assetDao.getAllDerivedAttributeForAssetList(conn);
					Pattern patternForDerivedAssetListAttribute = Pattern.compile(mainAssetName+"[\\{](?i)"+mainParamName+"[\\}]");
					Pattern patternForDerivedAssetListAttribute1 = Pattern.compile(mainAssetName+"[\\[](?i)"+mainParamName+"[\\]]");
					
					for(AssetParamDef apd : allDerivedAttributeForAssetList) {
						String text = apd.getDerivedAssetListRule();
						if(apd.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)){
							
							Matcher m = patternForDerivedAssetListAttribute.matcher(text);
							if(m.find()){//destination parameter check 
								log.warn("validationForDerivedAssetListAttribute || Parameter already used in rule! So can't change parameter type");
								return "Parameter already used in rule! So cannot change parameter type!";
							}
							
							Matcher m1 = patternForDerivedAssetListAttribute1.matcher(text);
							if(m1.find()){ 
								log.warn("validationForDerivedAssetListAttribute || Parameter already used in rule! So can't change parameter type");
								return "Parameter already used in rule! So cannot change parameter type!";
							}
						}
					}
					
					List<AssetParamDef> derivedAttributes =  assetDao.getAllDerivedAttributes(conn);
					Pattern patternForDerivedAttribute = Pattern.compile(mainAssetName+"[\\{](?i)"+mainParamName+"[\\}]");
					Pattern patternForDerivedComputation = Pattern.compile(mainAssetName+"[\\.](?i)"+mainParamName+"(==)");
					for (AssetParamDef assetParamDef2 : derivedAttributes) {
						String rule1 = assetParamDef2.getDerivedAttributeComputation();
						if(assetParamDef2.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID){

							Matcher m = patternForDerivedAttribute.matcher(rule1);
							if(m.find()){//destination parameter check 
								log.warn("validationForDerivedAttribute || Parameter already used in rule! So can't change parameter type");
								return "Parameter already used in rule! So cannot change parameter type!";
							}
							
							Matcher m1 = patternForDerivedComputation.matcher(rule1);
							if(m1.find()){// source parameter check
								log.warn("validationForDerivedAttribute || Parameter already used in rule! So can't change parameter type");
								return "Parameter already used in rule! So cannot change parameter type!";
							}
						}
						if(assetParamDef2.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID){
							Matcher m = patternForDerivedComputation.matcher(rule1);
							if(m.find()){
								log.warn("validationForDerivedAttribute || Parameter already used in rule! So can't change parameter type");
								return "Parameter already used in rule! So cannot change parameter type!";
							}
						}
					}
				}
			}
			
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAttribute || dao method called : getAllAssets() ");
			}
			
			List<AssetDef> assetsList = assetDao.getAllAssetNames(userName, conn);
			List<String> dbAssetNames = new ArrayList<String>();
			for(AssetDef ad : assetsList) {
				dbAssetNames.add(ad.getAssetName());
			}
						
			//List<String> dbAssetListNames = new ArrayList<String>();
			/*List<AssetParamDef> assetParamDefs = assetDao.getAssetListParameters(conn);
			for(AssetParamDef apd : assetParamDefs) {
				if(apd.getListTypeParamTypeId() == 2) {
					dbAssetListNames.add(apd.getAssetParamName());
				}
			}*/
			
			if(sb.length() == 0) {
				List<String> ruleAssetNames = new ArrayList<String>();
				List<String> ruleAssetListNames = new ArrayList<String>();
				String[] splittedText = rule.split("[\\[\\][\\{][\\}]]");
				for(int i =0;i<splittedText.length;i=i+2){
					ruleAssetNames.add(splittedText[i].toLowerCase().trim());
				}
				for(int i =1;i<splittedText.length-1;i=i+2){
					ruleAssetListNames.add(splittedText[i].toLowerCase().trim());
				}
				if(log.isTraceEnabled()){
					log.trace("normalRuleValidationForDerivedAttribute || calling commonValidationForDerivedAssetListAttribute"
							+ " with assetNames "+ruleAssetNames+" assetListNames "+ruleAssetListNames);
				}
				sb = commonValidationForDerivedAssetListAttribute(rule,mainAssetName,mainParamName,
						oldAssetName,dbAssetNames,ruleAssetNames,ruleAssetListNames,conn);
			}
			
			
			
		}catch(Exception e){
			log.error("validationForDerivedAssetListAttribute ||  " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAssetListAttribute || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("validationForDerivedAssetListAttribute || End");
		}
		return sb.toString();
	}
	
	
	public StringBuffer commonValidationForDerivedAssetListAttribute(String rule,String mainAssetName,
			String mainParamName,String oldAssetName,List<String> dbAssetNames,List<String> ruleAssetNames,
			List<String> ruleAssetListNames,Connection conn) {
		
		if(log.isTraceEnabled()) {
			log.trace("commonValidationForDerivedAssetListAttribute || Begin");
		}
		
		StringBuffer sb = new StringBuffer();
		
		String rulePattern = "^([a-zA-Z0-9_\\n ]+[\\[][\\^]?[a-zA-Z0-9\\n ]+[\\]])+[a-zA-Z0-9_\\n ]+[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]$";
		Pattern p = Pattern.compile(rulePattern);
		Matcher m = p.matcher(rule);
		if(!m.find()){
			if(log.isTraceEnabled()){
				log.warn("Rule Pattern is not valid!");
			}
			sb.append("Rule Pattern is not valid!");
		}

		Pattern p1 = Pattern.compile("\\{([^}]*)\\}");
		Matcher m1 = p1.matcher(rule);
		String lastParamName = null;
		while (m1.find()) {
			lastParamName = m1.group(1);
			lastParamName = lastParamName.trim();
		}
		
		//checking asset names in db
		if(sb.length()==0){
			List<String> lowerCaseDbAssetNames = new ArrayList<String>();
			for(int i=0;i<dbAssetNames.size();i++) {
				String name = dbAssetNames.get(i).toLowerCase().trim();
				lowerCaseDbAssetNames.add(name);
			}

			if(sb.length()==0){
				for(int i=0;i<ruleAssetNames.size();i++){
					String name = ruleAssetNames.get(i);
					name = name.toLowerCase().trim();
					if(!lowerCaseDbAssetNames.contains(name)){
						sb.append(ruleAssetNames.get(i)+",");
					}
				}
				if(sb.length()!=0){
					sb.deleteCharAt(sb.length()-1);
					if(log.isTraceEnabled()){
						log.warn(" Asset/Assets not available in the repository!");
					}
					sb.append(" Asset/Assets not available in the repository!");
				}
			}

			if(sb.length()==0){
				if(mainAssetName!=null){
					if(!mainAssetName.trim().equalsIgnoreCase(ruleAssetNames.get(0).trim())){
						if(log.isTraceEnabled()){
							log.warn("Rule should start with current asset!");
						}
						sb.append("Rule should start with current asset!");
					}
				}
			}
		}
		
		//checking assetlist names in db
		//if(sb.length()==0){
			/*List<String> lowerCaseAssetListNames = new ArrayList<String>();
			for(int i=0;i<dbAssetListNames.size();i++) {
				String name = dbAssetListNames.get(i).toLowerCase().trim();
				lowerCaseAssetListNames.add(name);
			}*/
			
			/*String[] splittedRule = rule.split("[\\[\\][\\{][\\}]]");
			String[] splittedRuleCopy = Arrays.copyOf(splittedRule, splittedRule.length-1);
			
			for(int i=1;i<splittedRuleCopy.length;i=i+2) {
				String srcAssetName = splittedRuleCopy[i-1].trim();
				String assetListName = splittedRuleCopy[i].trim();
				
				try {
					List<AssetParamDef> paramsList = assetDao.getParamsDetailByAssetName(srcAssetName,conn);
					List<String> dbParamNamesForAsset = new ArrayList<String>();
					for(AssetParamDef assetParamDef : paramsList) {
						dbParamNamesForAsset.add(assetParamDef.getAssetParamName());
					}
					
					if(sb.length() == 0) {
						if(!dbParamNamesForAsset.contains(assetListName)) {
							sb.append("Parameter not available in repository");
							break;
						}
					}
					if(sb.length() == 0) {
						for(AssetParamDef assetParamDef : paramsList) {
							if(assetParamDef.getAssetParamName().equalsIgnoreCase(assetListName)) {
								if(assetParamDef.getListTypeParamTypeId() != 2) {
									sb.append("Only assetList parameters allowed");
									break;
								}
							}
						}
					}
					
				}catch (RepoproException e) {
					e.printStackTrace();
				}
			}*/
			
			/*for(int i=0;i<ruleAssetListNames.size();i++) {
				String name = ruleAssetListNames.get(i);
				name = name.toLowerCase().trim();
				if(!lowerCaseAssetListNames.contains(name)){
					sb.append(ruleAssetListNames.get(i)+",");
				}
				if(sb.length()!=0){
					sb.deleteCharAt(sb.length()-1);
					if(log.isTraceEnabled()){
						log.warn(" AssetList parameters not available in the repository!");
					}
					sb.append(" AssetList parameters not available in the repository!");
				}
			}*/
		//}
		
		if(sb.length() == 0) {
			String lastAssetName = ruleAssetNames.get(ruleAssetNames.size()-1).trim();
			
			try {
				if(log.isTraceEnabled()) {
					log.trace("commonValidationForDerivedAssetListAttribute || dao method called : retParamIdForAssetAndParamName()");
				}
				AssetParamDef paramDetails = assetDao.retParamIdForAssetAndParamName(lastAssetName, lastParamName,conn);
				boolean flag = false;
				if(paramDetails != null) {
					if(paramDetails.getAssetParamName().equalsIgnoreCase(lastParamName)) {
						flag = true;
						if(paramDetails.isHasStaticValue()){
							if(log.isTraceEnabled()){
								log.warn("Static parameter is not allowed!");
							}
							sb.append("Static parameter is not allowed!");
						}else{
							if(paramDetails.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID||paramDetails.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID || paramDetails.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)){
								if(log.isTraceEnabled()){
									log.warn(lastParamName+" : derived parameters not allowed!");
								}
								sb.append(lastParamName+" : derived parameters not allowed!");
							}
						}
					}
				}else{
					flag = false;
				}
				if(!flag){
					if(log.isTraceEnabled()){
						log.warn(lastParamName+" is not available under "+lastAssetName+" Asset!");
					}
					sb.append(lastParamName+" is not available under "+lastAssetName+" Asset!");
				}
				
			} catch (RepoproException e) {
				e.printStackTrace();
			}
		}
		
		if(sb.length() == 0) {
			
			String[] splittedRule = rule.split("[\\[\\][\\{][\\}]]");
			String[] splittedRuleCopy = Arrays.copyOf(splittedRule, splittedRule.length-1);
			
			//validation for assetList parameter
			try {				
				for(int i=1;i<splittedRuleCopy.length;i=i+2) {
					String srcAssetName = splittedRuleCopy[i-1].trim();
					String assetListName = splittedRuleCopy[i].trim();
					
					if(log.isTraceEnabled()) {
						log.trace("commonValidationForDerivedAssetListAttribute || dao method called : getParamsDetailByAssetName()");
					}
					List<AssetParamDef> paramsList = assetDao.getParamsDetailByAssetName(srcAssetName, conn);
					List<String> dbParamNames = new ArrayList<String>();
					for(AssetParamDef assetParamDef : paramsList) {
						dbParamNames.add(assetParamDef.getAssetParamName().toLowerCase());
					}
					
					if(log.isTraceEnabled()) {
						log.trace("commonValidationForDerivedAssetListAttribute || dao method called : getAssetID()");
					}
					AssetDef assetDef = assetDao.getAssetID(splittedRuleCopy[i+1].trim(), conn);
					
					if(log.isTraceEnabled()) {
						log.trace("commonValidationForDerivedAssetListAttribute || dao method called : getParamIdForAssetAndParamName()");
					}
					AssetParamDef apd = assetDao.getParamIdForAssetAndParamName(srcAssetName, assetListName, conn);
					
					if(sb.length() == 0) {
						if(!dbParamNames.contains(assetListName.toLowerCase())) {
							sb.append("Parameter not available in repository");
							break;
						}else {
							if(apd.getListTypeParamTypeId() == 2) {
								if(apd.isHasStaticValue() == true) {
									sb.append("Static parameter is not allowed!");
								}else {
									if(assetDef.getAssetId() != null) {
										if(apd.getMappedAssetId().longValue() != assetDef.getAssetId().longValue()) {
											sb.append(assetListName+" is an assetList parameter and is not mapped to "+splittedRuleCopy[i+1].trim());break;
										}
									}
								}
							}else {
								/*sb.append(assetListName +" is not assetList parameter under "+ srcAssetName +" asset");break;*/
								sb.append("Only assetList parameters allowed");break;
							}
						}
					}
					
					/*if(sb.length() == 0) {
						for(AssetParamDef assetParamDef : paramsList) {
							if(assetParamDef.getAssetParamName().equalsIgnoreCase(assetListName)) {
								if(assetParamDef.getListTypeParamTypeId() != 2) {
									sb.append("Only assetList parameters allowed");
									break;
								}
							}
						}
					}*/
					
					/*if(sb.length() == 0) {
						AssetDef assetDef = assetDao.getAssetID(splittedRuleCopy[i+1].trim(), conn);
						AssetParamDef apd = assetDao.getParamIdForAssetAndParamName(srcAssetName, assetListName, conn);
						if(apd != null) {
							if(apd.getListTypeParamTypeId() == 2) {
								if(assetDef.getAssetId() != null) {
									if(apd.getMappedAssetId().longValue() != assetDef.getAssetId().longValue()) {
										sb.append(assetListName+" is an assetList parameter and is not mapped to "+splittedRuleCopy[i+1].trim());break;
									}
								}
							}else {
								sb.append(assetListName +" is not assetList parameter under "+ srcAssetName +" asset");break;
							}
						}else {
							sb.append(assetListName +" is not assetList parameter under "+ srcAssetName +" asset");break;
						}
					}*/
				}
				
			}catch(RepoproException e) {
				e.printStackTrace();
			}
		}
		return sb;
	}
	
	public boolean validateUploadedFileName(String fileName) throws RepoproException {
		boolean validFileName = true;
		String cleanFileName = httpSanitizerForPlainText(fileName);
		final List<String> ALLOWED_EXT = Arrays.asList("jpg","jpeg","png");
		
		if (cleanFileName.trim().isEmpty() || cleanFileName.trim().equalsIgnoreCase("")) {
			validFileName = false;
		} else {
			String[] ext = cleanFileName.split("\\.");
			if((ext.length > 2) || (ext[0].trim().equalsIgnoreCase("") || ext[0].trim().isEmpty())) {
				validFileName = false;	
			} else if (ext.length == 2 && !ALLOWED_EXT.contains(ext[1].toLowerCase())) {
				validFileName = false;								
			}		
		}	
				
		return validFileName;
		
	}	
}
