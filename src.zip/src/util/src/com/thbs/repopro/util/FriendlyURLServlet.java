package com.thbs.repopro.util;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FriendlyURLServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1303336364642378215L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String scheme = request.getScheme();             					// http
	    String serverName = request.getServerName();     					// hostname
	    String serverPort = String.valueOf(request.getServerPort());        // port number(8080)
	    String contextPath = request.getContextPath();						//context path(/repopro)
		String servletPath = request.getServletPath();						// servlet path(/view)
		//String requestURI = request.getRequestURI();						// URI (/repopro/view/asset/id)
		String requestURI = URLDecoder.decode(request.getRequestURI(), "UTF-8");
		String redirectURL=scheme.concat("://").concat(serverName).concat(":").concat(serverPort).concat(contextPath);
		
		Pattern assetpattern = Pattern.compile(contextPath+servletPath+"/([A-z0-9_ ]+)");
		Pattern assetInstpattern = Pattern.compile(contextPath+servletPath+"/([A-z0-9_ ]+)"+"/([0-9]+)");
		Matcher matcher = assetpattern.matcher(requestURI);
		if (matcher.matches()){
			String param = matcher.group(1);
				redirectURL += "/index.html?assetType="+param;
		}else{
			matcher = assetInstpattern.matcher(requestURI);
			if (matcher.matches()){
				String param = matcher.group(1);
				redirectURL += "/index.html?asset_instance_vers_id="+matcher.group(2)+"&assetType="+param;
			} else
				redirectURL += "/index.html?invalidURL=true";
		}
		response.sendRedirect(redirectURL);
	}
	
	

}
