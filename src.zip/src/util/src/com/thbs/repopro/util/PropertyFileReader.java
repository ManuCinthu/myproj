package com.thbs.repopro.util;

import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;

/**
 * @author THBS
 *
 */
public class PropertyFileReader {

	private final static Properties PROPERTIES = new Properties();

	private static PropertyFileReader propertyFileReader = null;

	private static String MASTER_CONFIG = "MasterConfig.properties";

	private PropertyFileReader() {
	}

	/**
	 * @return
	 */
	public static PropertyFileReader getInstance() {

		if (propertyFileReader == null) {
			Properties masterProperties = new Properties();
			propertyFileReader = new PropertyFileReader();
			try {
				masterProperties.load(Thread.currentThread()
						.getContextClassLoader()
						.getResourceAsStream(MASTER_CONFIG));
				Iterator<?> i = masterProperties.keySet().iterator();
				while (i.hasNext()) {
					String fName = (String) masterProperties.get((String) i
							.next());
					PROPERTIES
							.load(Thread.currentThread()
									.getContextClassLoader()
									.getResourceAsStream(fName));
				}
				masterProperties = null;
			}  catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return propertyFileReader;
	}

	/**
	 * @param key
	 * @return
	 */
	public String getValue(String key) {
		String value = null;

		value = (String) PropertyFileReader.PROPERTIES.get(key);
		return value;
	}
}
