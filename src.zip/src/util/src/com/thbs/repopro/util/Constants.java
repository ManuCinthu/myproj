package com.thbs.repopro.util;

import java.util.Collection;

/**
 * @author THBS
 *
 */
public class Constants {
	
	/* DBConstants */

	public static final String INVALID_REQUEST = "INVALID_REQUEST";
	public static final String USER_AUTHORIZATION = "USER_AUTHORIZATION";
	public static final int STATUS_FAILURE = 400;
	public static final String USER_NOT_AUTHORIZED="USER_NOT_AUTHORIZED";
	public static final String NOT_FOUND = "NOT_FOUND";

	/* I18 */	
	public static final String LANGUAGE = "LANGUAGE";
	public static final String COUNTRY_CODE = "COUNTRY_CODE";
	public static final String BUNDLE_NAME = "BUNDLE_NAME";
	public static final String CROSS_SITE_SCRIPTING = "xss";
	public static final String LDAP_CONFIG_ERROR ="Please check LDAP server configuration";

	/* Number Constants */
	public static final int ONE = 1;
	public static final int TWO = 2;
	public static final int THREE = 3;
	public static final int FOUR = 4;
	public static final int FIVE = 5;
	public static final int SIX = 6;
	public static final int SEVEN = 7;
	public static final int EIGHT = 8;
	public static final int NINE = 9;
	public static final int TEN = 10;
	public static final int ELEVEN = 11;
	public static final int TWELVE = 12;
	public static final int THIRTEEN = 13;
	public static final int FOURTEEN = 14;
	public static final int FIFTEEN = 15;
	public static final int SIXTEEN = 16;
	public static final int SEVENTEEN = 17;
	public static final int EIGHTEEN = 18;
	public static final int NINETEEN = 19;
	public static final int TWENTY = 20;
	public static final int TWENTYONE = 21;
	public static final int TWENTYTWO = 22;
	public static final int TWENTYTHREE = 23;
	public static final int TWENTYFOUR = 24;
	public static final int TWENTYFIVE = 25;
	public static final int TWENTYSIX = 26;
	public static final int TWENTYSEVEN = 27;
	public static final int TWENTYEIGHT = 28;
	public static final int TWENTYNINE = 29;
	public static final int THIRTY = 30;
	public static final int THIRTYONE = 31;
	public static final int THIRTYTWO = 32;
	public static final int THIRTYTHREE = 33;
	public static final int THIRTYFOUR = 34;
	public static final int THIRTYFIVE = 35;
	public static final int THIRTYSIX = 36;
	public static final int THIRTYSEVEN = 37;
	public static final int THIRTYEIGHT = 38;
	public static final int THIRTYNINE = 39;
	public static final int FOURTY = 40;
	
	public static final long DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID=5;	
	public static final long DERIVED_COMPUTATION_PARAMETER_TYPE_ID=6;
	public static final String NULL_STRING = "null";
	public static final long DERIVED_ASSET_LIST_ATTRIBUTE=8;

	/* Log4j Constants */
	public static final String LOG_CONNECTION_OPEN = "DB Connection Established";
	public static final String LOG_CONNECTION_CLOSE = "DB Connection Closed";
	public static final String LOG_CREATE_SQLEXCEPTION = "SQLException is caught and throws"
			+ " CreateContentException: ";
	public static final String LOG_UPDATE_SQLEXCEPTION = "SQLException is caught and throws"
			+ " UpdateContentException: ";
	public static final String LOG_DELETE_SQLEXCEPTION = "SQLException is caught and throws "
			+ "DeleteContentException: ";
	public static final String LOG_GET_SQLEXCEPTION = "SQLException is caught and throws"
			+ " DataNotFoundException: ";
	public static final String LOG_IOEXCEPTION = "IOException is caught: ";
	public static final String LOG_PROPERTYVETOEXCEPTION = "PropertyVetoException is caught : ";
	public static final String LOG_FILENOTFOUNDEXCEPTION = "FileNotFoundException is caught :";
	public static final String LOG_PARSEEXCEPTION = "ParseException is caught :";
	public static final String LOG_EXCEPTION = "Exception is caught : ";
	public static final String LOG_NUMBERFORMATEXCEPTION = "NumberFormatException is caught";
	
	/*Exception Constants*/
	public static final String DataNotFoundException = "Unable";
	public static final String CreateContentException = "Unable";
	public static final String UpdateContentException = "Unable";
	
	/* MessageConstants Repopro */
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String IO_OPERATION_FAILED = "IO_OPERATION_FAILED";
	public static final String INVALID_INPUT_FOR_PROPERTY_FILE = "INVALID_INPUT_FOR_PROPERTY_FILE";
	
	
	/* StatusCodes */
	public static final int UPDATE_STATUS_SUCCESS = 200;
	public static final int DELETE_STATUS_SUCCESS = 200;
	public static final int INSERT_STATUS_SUCCESS = 200;
	public static final int GET_STATUS_SUCCESS = 200;
	public static final int SAVE_STATUS_SUCCESS = 200;

	public static final int UPDATE_STATUS_FAILURE = 500;
	public static final int DELETE_STATUS_FAILURE = 500;
	public static final int INSERT_STATUS_FAILURE = 500;
	public static final int CREATE_STATUS_FAILURE = 500;
	public static final int GET_STATUS_FAILURE = 404;
	public static final int SAVE_STATUS_FAILURE = 500;
	public static final int UNAUTHORIZED  = 401;
	public static final int FORBIDDEN  = 403;
	
	/* filetype constants */
	public static final int FILE_TYPE = 3;
	public static final String APPEND_STRING = "&<!!>&";
	public static final String FORWARD_DEPENDENCY = "forward";
	
	/*Parameter*/
	
    public static final String DATE_TYPE = "date";
	
	public static final String LIST = "list";
	
	public static final String TEXT = "text";
	
	public static final String USER_LIST = "userlist";
	
	public static final String ASSET_LIST = "assetlist";
	
	public static final String CUSTOM_LIST = "customlist";
	
	public static final String CURRENT_OWNER = "Current Owner";
	
	public static final String LIFE_CYCLE_STATE = "State";
	
	public static final String DERIVED_ATTRIBUTE = "derived attribute";
	
	public static final String DERIVED_COMPUTATION = "derived computation";
	
	public static final String FILE = "file";
	
	/* Access Control - Groups (queries)*/
	public static final String GET_ALL_GROUPS = "GET_ALL_GROUPS";
	public static final String CREATE_GROUP = "CREATE_GROUP";
	public static final String UPDATE_GROUP = "UPDATE_GROUP";
	public static final String GET_GROUP_ID_BY_GROUP_NAME = "GET_GROUP_ID_BY_GROUP_NAME";
	public static final String DELETE_GROUP = "DELETE_GROUP";
	public static final String DELETE_GROUP_ROLES = "DELETE_GROUP_ROLES";
	public static final String GET_ALL_GROUP_ROLES = "GET_ALL_GROUP_ROLES";
	public static final String GET_USER_GROUPS_BY_GROUP_ID = "GET_USER_GROUPS_BY_GROUP_ID";
	public static final String GET_GROUP_ROLES_BY_GROUP_ID = "GET_GROUP_ROLES_BY_GROUP_ID";
	public static final String GET_GROUP_BY_ID = "GET_GROUP_BY_ID";
	public static final String GET_ALL_GROUPS_HAVING_EDIT_AI_PERMISSION = "GET_ALL_GROUPS_HAVING_EDIT_AI_PERMISSION";
	public static final String GET_GROUPS_BY_ASSET_CATEGORY = "GET_GROUPS_BY_ASSET_CATEGORY";
	public static final String CREATE_GROUP_ROLE = "CREATE_GROUP_ROLE";
	public static final String GET_GROUP_ROLES_BY_GROUP_ID_AND_ROLE_ID = "GET_GROUP_ROLES_BY_GROUP_ID_AND_ROLE_ID";
	public static final String DEL_GROUP_ROLES_BY_GROUP_ID_AND_ROLE_ID = "DEL_GROUP_ROLES_BY_GROUP_ID_AND_ROLE_ID";
	public static final String GET_ALL_GROUP_ROLES_BY_GROUP_ID = "GET_ALL_GROUP_ROLES_BY_GROUP_ID";
	public static final String RET_GROUP_ASSETS_ACCESS_BY_ASSET_ID = "RET_GROUP_ASSETS_ACCESS_BY_ASSET_ID";
	public static final String ADD_GROUP_ACCESS_AI_SUBMIT_DETAILS = "ADD_GROUP_ACCESS_AI_SUBMIT_DETAILS";
	public static final String DELETE_ASSET_GROUP_ACCESS_BY_ASSET_ID = "DELETE_ASSET_GROUP_ACCESS_BY_ASSET_ID";
	public static final String ADD_GROUPS_ASSET_ACCESS_SUBMIT = "ADD_GROUPS_ASSET_ACCESS_SUBMIT";
	public static final String GET_ASSET_GROUP_ACCESS_FOR_ASSET="GET_ASSET_GROUP_ACCESS_FOR_ASSET";
	
	/* Access Control - Groups (Messages)*/
	public static final String GROUP_NOT_CREATED = "GROUP_NOT_CREATED";
	public static final String GROUP_ROLE_NOT_CREATED = "GROUP_ROLE_NOT_CREATED";
	public static final String GROUP_NOT_UPDATED = "GROUP_NOT_UPDATED";
	public static final String GROUP_DELETED = "GROUP_DELETED";
	public static final String GROUP_NOT_DELETED = "GROUP_NOT_DELETED";
	public static final String GROUPS_NOT_FOUND = "GROUPS_NOT_FOUND";
	public static final String GROUP_ROLES_NOT_FOUND = "GROUP_ROLES_NOT_FOUND";
	public static final String GROUPS_HAVING_EDIT_AI_PERMISSION_NOT_FOUND = "GROUPS_HAVING_EDIT_AI_PERMISSION_NOT_FOUND";
	public static final String GROUPS_BY_ASSET_CATEGORY_NOT_FOUND = "GROUPS_BY_ASSET_CATEGORY_NOT_FOUND";
	public static final String INSERTION_OF_GROUP_ROLE_FUNCTION_FAILED = "INSERTION_OF_GROUP_ROLE_FUNCTION_FAILED";
	public static final String DELETION_OF_GROUP_ROLE_FUNCTION_FAILED = "DELETION_OF_GROUP_ROLE_FUNCTION_FAILED";
	public static final String GROUP_NAME_EXIST = "GROUP_NAME_EXIST";
	public static final String USER_GROUPS_NOT_FOUND = "USER_GROUPS_NOT_FOUND";
	public static final String GROUP_ROLE_NOT_DELETED = "GROUP_ROLE_NOT_DELETED";
	public static final String ROLE_FUNCTIONS_NOT_FOUND = "ROLE_FUNCTIONS_NOT_FOUND";
	public static final String USER_FUNCTION_NOT_FOUND = "USER_FUNCTION_NOT_FOUND";
	public static final String USER_ASSETS_NOT_FOUND = "USER_ASSETS_NOT_FOUND";
	public static final String RET_GROUP_ASSETS_ACCESS_BY_ASSET_ID_DETAILS_FAILED = "RET_GROUP_ASSETS_ACCESS_BY_ASSET_ID_DETAILS_FAILED";
	public static final String ADD_GROUP_ACCESS_AI_SUBMIT_DETAILS_FAILED = "ADD_GROUP_ACCESS_AI_SUBMIT_DETAILS_FAILED";
	
	/* Access Control - Groups (constants)*/
	public static final String GROUP_ROLES_SAVED = "GROUP_ROLES_SAVED";
	public static final String ALL_GROUPS_HAVING_EDIT_AI_PERMISSION_FETCHED = "ALL_GROUPS_HAVING_EDIT_AI_PERMISSION_FETCHED";
	public static final String ALL_GROUPS_BY_ASSET_CATEGORY_FETCHED = "ALL_GROUPS_BY_ASSET_CATEGORY_FETCHED";
	public static final String ALL_GROUP_ROLES_FETCHED = "ALL_GROUP_ROLES_FETCHED";
	public static final String ALL_GROUPS_FETCHED = "ALL_GROUPS_FETCHED";
	public static final String GROUP_UPDATED = "GROUP_UPDATED";
	public static final String GROUP_CREATED = "GROUP_CREATED";
	
	/* Subscription - Constants*/
	public static final String SUBSCRIBED_TO_ASSET = "SUBSCRIBED_TO_ASSET";
	public static final String UNSUBSCRIBED_FROM_ASSET = "UNSUBSCRIBED_FROM_ASSET";
	public static final String SUBSCRIBED_TO_ASSET_INSTANCE = "SUBSCRIBED_TO_ASSET_INSTANCE";
	public static final String UNSUBSCRIBED_FROM_ASSET_INSTANCE = "UNSUBSCRIBED_FROM_ASSET_INSTANCE";
	public static final String SUBSCRIBED_TO_TAXONOMY = "SUBSCRIBED_TO_TAXONOMY";
	public static final String UNSUBSCRIBED_FROM_TAXONOMY = "UNSUBSCRIBED_FROM_TAXONOMY";
	public static final String ALL_ASSET_INSTANCES_FETCHED = "ALL_ASSET_INSTANCES_FETCHED";

	/* Subscription - Messages */
	public static final String UNABLE_TO_SUBSCRIBE_TO_ASSET = "UNABLE_TO_SUBSCRIBE_TO_ASSET";
	public static final String USER_PROFILE_NOT_FOUND = "USER_PROFILE_NOT_FOUND";
	public static final String ASSET_NOT_FOUND = "ASSET_NOT_FOUND";
	public static final String USER_ASSETS_SUBSCRIPTION_DATA_NOT_FOUND = "USER_ASSETS_SUBSCRIPTION_DATA_NOT_FOUND";
	public static final String UNABLE_TO_UNSUBSCRIBE_FROM_ASSET = "UNABLE_TO_UNSUBSCRIBE_FROM_ASSET";
	public static final String ASSET_INSTANCE_NOT_FOUND = "ASSET_INSTANCE_NOT_FOUND";
	public static final String UNABLE_TO_SUBSCRIBE_TO_ASSET_INSTANCE = "UNABLE_TO_SUBSCRIBE_TO_ASSET_INSTANCE";
	public static final String USER_ASSET_INSTANCE_SUBSCRIPTION_DATA_NOT_FOUND = "USER_ASSET_INSTANCE_SUBSCRIPTION_DATA_NOT_FOUND";
	public static final String UNABLE_TO_UNSUBSCRIBE_FROM_ASSET_INSTANCE = "UNABLE_TO_UNSUBSCRIBE_FROM_ASSET_INSTANCE";
	public static final String UNABLE_TO_SUBSCRIBE_TO_TAXONOMY = "UNABLE_TO_SUBSCRIBE_TO_TAXONOMY";
	public static final String USER_TAXONOMY_SUBSCRIPTION_DATA_NOT_FOUND = "USER_TAXONOMY_SUBSCRIPTION_DATA_NOT_FOUND";
	public static final String UNABLE_TO_UNSUBSCRIBE_FROM_TAXONOMY = "UNABLE_TO_UNSUBSCRIBE_FROM_TAXONOMY";
	public static final String ASSET_INSTANCES_NOT_FOUND = "ASSET_INSTANCES_NOT_FOUND";
	public static final String REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE ="REPOPRO_ASSET_INSTANCE_SUBSCRIPTION_UPDATE";
	public static final String REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE = "REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE";

	/* Subscription - queries*/
	public static final String ASSET_SUBSCRIPTION = "ASSET_SUBSCRIPTION";
	public static final String RET_USER_ASSETS_SUBSCRIPTION = "RET_USER_ASSETS_SUBSCRIPTION";
	public static final String ASSET_UNSUBSCRIPTION = "ASSET_UNSUBSCRIPTION";
	public static final String RET_ASSET_INST_BY_ASSET_NAME_AND_INST_NAME = "RET_ASSET_INST_BY_ASSET_NAME_AND_INST_NAME";
	public static final String ASSET_INSTANCE_SUBSCRIPTION = "ASSET_INSTANCE_SUBSCRIPTION";
	public static final String RET_USER_ASSET_INSTANCE_SUBSCRIPTION = "RET_USER_ASSET_INSTANCE_SUBSCRIPTION";
	public static final String ASSET_INSTANCE_UNSUBSCRIPTION = "ASSET_INSTANCE_UNSUBSCRIPTION";
	public static final String TAXONOMY_SUBSCRIPTION = "TAXONOMY_SUBSCRIPTION";
	public static final String TAXONOMY_UNSUBSCRIPTION = "TAXONOMY_UNSUBSCRIPTION";
	public static final String GET_ALL_ASSET_INSTANCES = "GET_ALL_ASSET_INSTANCES";
	public static final String GET_ALL_ASSET_INSTANCES_FOR_SUBSCRIPTION = "GET_ALL_ASSET_INSTANCES_FOR_SUBSCRIPTION";
	public static final String RET_SUBSCRIBERS_FOR_ASSET = "RET_SUBSCRIBERS_FOR_ASSET";
	public static final String RET_SUBSCRIBERS_FOR_TAXONOMY = "RET_SUBSCRIBERS_FOR_TAXONOMY";
	public static final String RET_TAXONOMY_SUBSCRIPTION_BY_USER = "RET_TAXONOMY_SUBSCRIPTION_BY_USER";
	public static final String GET_ALL_ASSET_INSTANCES_FOR_SUBSCRIPTION_FOR_NON_ADMIN = "GET_ALL_ASSET_INSTANCES_FOR_SUBSCRIPTION_FOR_NON_ADMIN";
	public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION = "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION";
	public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_FOR_NON_ADMIN = "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_FOR_NON_ADMIN";
	
	/* Revision History - queries*/
	public static final String RET_ASSET_INST_NAME_AIV_ID = "RET_ASSET_INST_NAME_AIV_ID";
	public static final String RET_AIV_REVISION_HISTORY = "RET_AIV_REVISION_HISTORY";
	public static final String RET_REVISION_HISTORY_BY_REV_HISTORY_ID = "RET_REVISION_HISTORY_BY_REV_HISTORY_ID";
	public static final String RET_AIV_REVISION_HISTORY_BY_AIV_REV_HIST_ID ="RET_AIV_REVISION_HISTORY_BY_AIV_REV_HIST_ID";
	public static final String ADD_REVISION_DATA ="ADD_REVISION_DATA";
	public static final String DELETE_AIV_REV_HISTORY_BY_AIVID ="DELETE_AIV_REV_HISTORY_BY_AIVID";
	public static final String RET_REVISION_HISTORY_BY_AIV_ID_AND_REV_ID = "RET_REVISION_HISTORY_BY_AIV_ID_AND_REV_ID";

	/* Revision History - constants*/
	public static final String REVISION_HISTORY_FETCHED = "REVISION_HISTORY_FETCHED";
	public static final String REVISION_HISTORY_DETAILS_FETCHED = "REVISION_HISTORY_DETAILS_FETCHED";
	
	/* Revision History - Messages*/
	public static final String REVISION_HISTORY_NOT_FOUND = "REVISION_HISTORY_NOT_FOUND";
	public static final String PARAMS_NOT_FOUND = "PARAMS_NOT_FOUND";
	public static final String AIV_REV_HISTORY_BY_AIVID_NOT_DELETED = "AIV_REV_HISTORY_BY_AIVID_NOT_DELETED";
	public static final String RET_AIV_REVISION_HISTORY_BY_AIV_REV_HIST_ID_NOT_FOUND ="RET_AIV_REVISION_HISTORY_BY_AIV_REV_HIST_ID_NOT_FOUND";
	public static final String ADD_REVISION_DATA_NOT_CREATED ="ADD_REVISION_DATA_NOT_CREATED";
	

	/* assetInstance sql constants */
	public static final String INSERT_ASSET_INSTANCE = "INSERT_ASSET_INSTANCE";
	public static final String UPDATE_ASSET_INSTANCE_DESCRIPTION = "UPDATE_ASSET_INSTANCE_DESCRIPTION";
	public static final String DELETE_ASSET_INSTANCE = "DELETE_ASSET_INSTANCE";
	public static final String INSERT_ASSET_INSTANCE_VERSION = "INSERT_ASSET_INSTANCE_VERSION";
	public static final String RET_ASSET_BY_NAME = "RET_ASSET_BY_NAME";
	public static final String RET_ASSET_INST_VERSION_BY_ASSET_INSTANCE_AND_VERSION = "RET_ASSET_INST_VERSION_BY_ASSET_INSTANCE_AND_VERSION";
	public static final String RET_PROFILE_FOR_USER_NAME = "RET_PROFILE_FOR_USER_NAME";
	public static final String RET_ASSET_INST_VERSION = "RET_ASSET_INST_VERSION";
	public static final String ADD_RECENT_ACTIVITY = "ADD_RECENT_ACTIVITY";
	public static final String ADD_FAVOURITE_SERVICE = "ADD_FAVOURITE_SERVICE";
	public static final String ADD_SUBSCRIPTION = "ADD_SUBSCRIPTION";
	public static final String GET_ALL_SUBSCRIPTIONS_BY_ASSET_INSTANCE = "GET_ALL_SUBSCRIPTIONS_BY_ASSET_INSTANCE";
	public static final String GET_ALL_ASSET_INST_NAME_FOR_ADMIN = "GET_ALL_ASSET_INST_NAME_FOR_ADMIN";
	public static final String GET_ALL_ASSET_INST_NAME_FOR_GUEST = "GET_ALL_ASSET_INST_NAME_FOR_GUEST";
	public static final String GET_ALL_ASSET_INST_NAME_FOR_NON_ADMIN = "GET_ALL_ASSET_INST_NAME_FOR_NON_ADMIN";
	public static final String GET_ASSET_INST_ID_BY_NAME = "GET_ASSET_INST_ID_BY_NAME";
	
	/*assetInstance constants */
	public static final String DEFAULT_VERSION = "1.0";
	public static final String DEFAULT_VERSION_NOTES = "This is a default version created by system";
	public static final String ACTIVITY_MODIFY = "updated";
	public static final String ASSET_INSTANCE_DATA_NOT_INSERTED = " ASSET_INSTANCE_DATA_NOT_INSERTED";
	public static final String ASSET_INSTANCES_NOT_FETCHED = "ASSET_INSTANCES_NOT_FETCHED";
	public static final String GET_ASSET_ID_BY_ASSET_NAME = "GET_ASSET_ID_BY_ASSET_NAME";
	public static final String GET_ASSET_ID_AND_NAME_BY_ASSET_NAME = "GET_ASSET_ID_AND_NAME_BY_ASSET_NAME";
	public static final String GET_ASSET_ID_BY_ASSET_NAME_DATA_NOT_FOUND = "GET_ASSET_ID_BY_ASSET_NAME_DATA_NOT_FOUND";

	/* assetInstance MessageConstants  */
	public static final String INSERT_ASSET_INSTANCE_DETAILS_FAILED = "INSERT_ASSET_INSTANCE_DETAILS_FAILED";
	public static final String ASSET_INSTANCE_DATA_INSERTED = "ASSET_INSTANCE_DATA_INSERTED";
	public static final String UPDATE_ASSET_INSTANCE_NAME = "UPDATE_ASSET_INSTANCE_NAME";
	public static final String ASSET_INSTANCE_NAME_UPDATED = "ASSET_INSTANCE_NAME_UPDATED";
	public static final String UPDATE_ASSET_INSTANCE_NAME_FAILED = "UPDATE_ASSET_INSTANCE_NAME_FAILED";
	public static final String UPDATE_ASSET_INSTANCE_DESCRIPTION_FAILED = "UPDATE_ASSET_INSTANCE_DESCRIPTION_FAILED";
	public static final String ASSET_INSTANCE_DESC_UPDATED = "ASSET_INSTANCE_DESC_UPDATED";
	public static final String ASSET_INSTANCE_DATA_NOT_DELETED = "ASSET_INSTANCE_DATA_NOT_DELETED";
	public static final String ASSET_INSTANCE_DATA_DELETED = "ASSET_INSTANCE_DATA_DELETED";
	public static final String ASSET_INSTANCE_DATA_NOT_FOUND = "ASSET_INSTANCE_DATA_NOT_FOUND";
	public static final String ASSET_INST_VERSION_DATA_NOT_FOUND = "ASSET_INST_VERSION_DATA_NOT_FOUND";
	public static final String USER_DATA_NOT_FOUND = "USER_DATA_NOT_FOUND";
	public static final String ADD_RECENT_ACTIVITY_DETAILS_FAILED = "ADD_RECENT_ACTIVITY_DETAILS_FAILED";
	public static final String ADD_FAVOURITE_SERVICE_DETAILS_FAILED = "ADD_RECENT_ACTIVITY_DETAILS_FAILED";
	public static final String ADD_SUBSCRIPTION_DETAILS_FAILED = "ADD_SUBSCRIPTION_DETAILS_FAILED";
	public static final String ASSET_INST_NAME_ALREADY_EXISTS = "ASSET_INST_NAME_ALREADY_EXISTS";
	public static final String RENAME_ASSET_INSTANCE_NAME_IN_PARAM_VALUE_FAILED = "RENAME_ASSET_INSTANCE_NAME_IN_PARAM_VALUE_FAILED";

	
	/* role sql constants */
	public static final String GET_ALL_ROLE_DATA = "GET_ALL_ROLE_DATA";
	public static final String INSERT_ROLE_DATA = "INSERT_ROLE_DATA";
	public static final String UPDATE_ROLE = "UPDATE_ROLE";
	public static final String DELETE_ROLE = "DELETE_ROLE";
	public static final String RET_ROLE_FUNCTIONS_BY_ROLE_ID = "RET_ROLE_FUNCTIONS_BY_ROLE_ID";
	public static final String GET_GROUP_ROLES_BY_ROLE_ID = "GET_GROUP_ROLES_BY_ROLE_ID";
	public static final String GET_ROLE_DATA_BY_ROLE_ID = "GET_ROLE_DATA_BY_ROLE_ID";
	public static final String ADD_ROLE_FUNCTION_DATA = "ADD_ROLE_FUNCTION_DATA";
	public static final String RET_ALL_ROLE_FUNCTIONS = "RET_ALL_ROLE_FUNCTIONS";
	public static final String GET_FUNCTION_IDS_BY_FUNCTION_NAMES = "GET_FUNCTION_IDS_BY_FUNCTION_NAMES";
	public static final String GET_ROLE_IDS_BY_ROLE_NAMES = "GET_ROLE_IDS_BY_ROLE_NAMES";
	public static final String RET_ALL_ROLE_FUNCTIONS_BY_ROLE_ID = "RET_ALL_ROLE_FUNCTIONS_BY_ROLE_ID";
	public static final String DELETE_ROLE_FUNCTION_DATA = "DELETE_ROLE_FUNCTION_DATA";
	public static final String DELETE_FUNCTION_ROLE_BY_ID = "DELETE_FUNCTION_ROLE_BY_ID";
	public static final String RET_ALL_ROLE_FUNCTIONS_BY_USER_ID = "RET_ALL_ROLE_FUNCTIONS_BY_USER_ID";
	public static final String GET_ROLE_ID_BY_ROLE_NAME = "GET_ROLE_ID_BY_ROLE_NAME";

	/*role Constants  */
	public static final String ROLE_ID_NOT_EXISTS = "role id does not exists";
	public static final String ROLE_DATA_CREATED = "ROLE_DATA_CREATED";
	public static final String ROLE_DATA_UPDATED = "ROLE_DATA_UPDATED";
	public static final String ROLE_DELETED = "ROLE_DELETED";
	public static final String ROLE_FUNCTION_INSERTED = "ROLE_FUNCTION_INSERTED";
	public static final String LIST_BY_ROLE_ID = "LIST_BY_ROLE_ID";
	public static final String ROLES_NOT_FOUND = "ROLES_NOT_FOUND";
	public static final String ALL_ROLES_DATA_FETCHED = "ALL_ROLES_DATA_FETCHED";
	public static final String FUNCTION_DATA_NOT_FOUND = "FUNCTION_DATA_NOT_FOUND";
	public static final String ROLE_FUNCTION_SAVED_SUCCESSFULLY = "role function data saved successfully";
	
	/* role MessageConstants  */
	public static final String ROLE_DATA_NOT_FOUND = "ROLE_DATA_NOT_FOUND";
	public static final String INSERT_ROLE_DETAILS_FAILED = "INSERT_ROLE_DETAILS_FAILED";
	public static final String ROLE_NOT_CREATED = "ROLE_NOT_CREATED";
	public static final String UPDATE_ROLE_DETAILS_FAILED = "UPDATE_ROLE_DETAILS_FAILED";
	public static final String ROLE_NOT_UPDATED = "ROLE_NOT_UPDATED";
	public static final String ROLE_NOT_DELETED = "ROLE_NOT_DELETED";
	public static final String GROUP_DATA_NOT_FOUND = "GROUP_DATA_NOT_FOUND";
	public static final String ROLE_FUNCTION_DATA_NOT_FOUND = "ROLE_FUNCTION_DATA_NOT_FOUND";
	public static final String FUNCTION_ROLE_NOT_DELETED = "FUNCTION_ROLE_NOT_DELETED";
	public static final String ROLE_DATA_BY_ID_NOT_FOUND = "ROLE_DATA_BY_ID_NOT_FOUND";
	public static final String INSERT_ROLE_FUNCTION_DETAILS_FAILED = "INSERT_ROLE_FUNCTION_DETAILS_FAILED";
	public static final String ROLE_NAME_ALREADY_EXISTS = "ROLE_NAME_ALREADY_EXISTS";
	public static final String ROLE_MAPPPED_WITH_GROUP = "ROLE_MAPPPED_WITH_GROUP";
	public static final String GET_ROLE_ID_BY_ROLE_NAME_DATA_NOT_FOUND = "GET_ROLE_ID_BY_ROLE_NAME_DATA_NOT_FOUND";
	public static final String GET_FUN_IDS_BY_FUN_NAMES_DATA_NOT_FOUND = "GET_FUN_IDS_BY_FUN_NAMES_DATA_NOT_FOUND";
	public static final String GET_ROLE_IDS_BY_ROLE_NAMES_DATA_NOT_FOUND = "GET_ROLE_IDS_BY_ROLE_NAMES_DATA_NOT_FOUND";

		
	/* ManageGuest SQL constants */
	public static final String RET_ALL_ASSET_TYPES_FOR_GUEST = "RET_ALL_ASSET_TYPES_FOR_GUEST";
	public static final String UPDATE_GUEST_ACCESS = "UPDATE_GUEST_ACCESS";

	/* ManageGuest message constants */
	public static final String ASSET_DATA_NOT_FOUND = "ASSET_DATA_NOT_FOUND";
	public static final String UPDATE_GUEST_ACCESS_FAILED = "UPDATE_GUEST_ACCESS_FAILED";
	public static final String GLOBAL_SETTING_DATA_BY_SETTING_NAME_NOT_FOUND ="GLOBAL_SETTING_DATA_BY_SETTING_NAME_NOT_FOUND";
	
	
	/* ManageGuest constants */
	public static final String ALL_ASSET_DATA_FETCHED = "ALL_ASSET_DATA_FETCHED";
	public static final String GUEST_ACCESS_SAVED_SUCCESSFULLY = "GUEST_ACCESS_SAVED_SUCCESSFULLY";

	
	/* relationship sql constants */
	public static final String RET_ALL_RELATIONSHIP_DEFS = "RET_ALL_RELATIONSHIP_DEFS";
	public static final String RET_ALL_ASSET_RELATIONSHIP_DEFS = "RET_ALL_ASSET_RELATIONSHIP_DEFS";
	public static final String RET_ASSET_INST_RELATION_SHIP_FOR_ASSET = "RET_ASSET_INST_RELATION_SHIP_FOR_ASSET";
	public static final String DELETE_ASSET_RELATIONSHIP = "DELETE_ASSET_RELATIONSHIP";
	public static final String ADD_RELATION_DATA = "ADD_RELATION_DATA";
	public static final String UPDATE_RELATION_DATA = "UPDATE_RELATION_DATA";
	public static final String RET_ASSET_RELATIONSHIPDEF_BY_DEST_ASSETID = "RET_ASSET_RELATIONSHIPDEF_BY_DEST_ASSETID";
	public static final String RET_ASSET_RELATIONSHIPDEF_BY_SRC_ASSETID = "RET_ASSET_RELATIONSHIPDEF_BY_SRC_ASSETID";
	public static final String RET_ASSET_INST_RELATIONSHIP_FOR_ASSET = "RET_ASSET_INST_RELATIONSHIP_FOR_ASSET";
	public static final String GET_ALL_REVERSE_RELATIONSHIPS = "GET_ALL_REVERSE_RELATIONSHIPS";
	public static final String RET_RVR_ASSET_RELATIONSHIP_INSTANCE_FOR_ASSET_INSTANCE_VERSION_ID ="RET_RVR_ASSET_RELATIONSHIP_INSTANCE_FOR_ASSET_INSTANCE_VERSION_ID";
	public static final String ADD_ASSET_INST_RELATIONSHIP = "ADD_ASSET_INST_RELATIONSHIP";
	public static final String ADD_ASSET_INST_RELATIONSHIP_NOT_CREATED = "ADD_ASSET_INST_RELATIONSHIP_NOT_CREATED";
	public static final String RET_ALL_ASSET_RELATIONSHIP_DEFS_FOR_GRID = "RET_ALL_ASSET_RELATIONSHIP_DEFS_FOR_GRID";
	public static final String RET_RELATIONSHIP_DEFS_BY_REL_ID = "RET_RELATIONSHIP_DEFS_BY_REL_ID";
	public static final String DELETE_ASSET_INST_RELATIONSHIP = "DELETE_ASSET_INST_RELATIONSHIP";
	public static final String GET_ALL_RELATIONSHIPS_BY_ASSET_INSTANCE_VERSION_ID = "GET_ALL_RELATIONSHIPS_BY_ASSET_INSTANCE_VERSION_ID";;
	public static final String GET_ASSET_RELATIONSHIP_ID = "GET_ASSET_RELATIONSHIP_ID";
	public static final String RET_ALL_ARD_FOR_COMP_AGGR_RELATION = "RET_ALL_ARD_FOR_COMP_AGGR_RELATION";
	public static final String RET_ALL_ASSET_RELATIONSHIP_DEFS_FOR_GRID_FILTER = "RET_ALL_ASSET_RELATIONSHIP_DEFS_FOR_GRID_FILTER";

	
	/* relationship message constants */
	public static final String NO_RELATIONSHIP_DATA_FOUND = "NO_RELATIONSHIP_DATA_FOUND";
	public static final String ASSET_RELATION_NOT_DELETED = "ASSET_RELATION_NOT_DELETED";
	public static final String RELATIONSHIP_NOT_DELETED = "RELATIONSHIP_NOT_DELETED";
	public static final String RELATIONSHIP_DELETED = "RELATIONSHIP_DELETED";
	public static final String NO_RELATIONSHIP_DATA_PROVIDED = "NO_RELATIONSHIP_DATA_PROVIDED";
	public static final String NO_RELATIONSHIP_DATA_PROVIDED_TO_UPDATE = "NO_RELATIONSHIP_DATA_PROVIDED_TO_UPDATE";
	public static final String REVERSE_RELATIONSHIP_NOT_ALLOWED = "REVERSE_RELATIONSHIP_NOT_ALLOWED";
	public static final String ASSOCIATION_RELATIONSHIP_NOT_ALLOWED = "ASSOCIATION_RELATIONSHIP_NOT_ALLOWED";
	public static final String MANY_RELATIONSHIPS_NOT_ALLOWED = "MANY_RELATIONSHIPS_NOT_ALLOWED";
	public static final String CLASSIFICATION_RELATIONSHIP_NOT_ALLOWED = "CLASSIFICATION_RELATIONSHIP_NOT_ALLOWED";
	public static final String ASSOCIATION_OR_CLASSIFICATION_RELATIONSHIP_NOT_ALLOWED = "ASSOCIATION_OR_CLASSIFICATION_RELATIONSHIP_NOT_ALLOWED";
	public static final String COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED = "COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED";
	public static final String COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET = "COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET";
	public static final String COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET_AS_CHIlD = "COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET_AS_CHIlD";
	public static final String COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET_AS_PARENT = "COMPOSITION_OR_AGGREGATION_ASSET_RELATIONSHIP_NOT_ALLOWED_FOR_THIS_DEST_ASSET_AS_PARENT";
	public static final String PLEASE_SELECT_A_VERSIONABLE_ASSET_FOR_THIS_RELATIONSHIP_TYPE = "PLEASE_SELECT_A_VERSIONABLE_ASSET_FOR_THIS_RELATIONSHIP_TYPE";
	public static final String THIS_RELATIONSHIP_MAPPED_WITH_ASSET_INSTANCE = "THIS_RELATIONSHIP_MAPPED_WITH_ASSET_INSTANCE";
	public static final String RELATIONSHIP_BY_THIS_NAME_ALREADY_EXISTS = "RELATIONSHIP_BY_THIS_NAME_ALREADY_EXISTS";
	public static final String ALL_REVERSE_RELATIONSHIPS_FETCHED = "ALL_REVERSE_RELATIONSHIPS_FETCHED";
	public static final String REVERSE_RELATIONSHIPS_NOT_FOUND = "REVERSE_RELATIONSHIPS_NOT_FOUND";
	public static final String GET_ASSET_INSTANCE_NAME_AND_VERSION_NAME_BY_ASSET_INSTANCE_VERSION_ID = "GET_ASSET_INSTANCE_NAME_AND_VERSION_NAME_BY_ASSET_INSTANCE_VERSION_ID";
	public static final String NO_ASSET_INSTANCE_NAME_AND_VERSION_NAME_BY_AI_VERSION_ID = "NO_ASSET_INSTANCE_NAME_AND_VERSION_NAME_BY_AI_VERSION_ID";
	public static final String RET_ASSET_INST_BY_ASSET_NAME_AND_INST_NAME_MY = "RET_ASSET_INST_BY_ASSET_NAME_AND_INST_NAME_MY";
	public static final String NO_ASSET_INSTANCE__BY_ASSET_NAME_AND_ASSET_INST_NAME= "NO_ASSET_INSTANCE__BY_ASSET_NAME_AND_ASSET_INST_NAME";
	public static final String GET_ASSET_RELATION_SHIP_DEF_BY_ASSET_RELATION_SHIP_ID = "GET_ASSET_RELATION_SHIP_DEF_BY_ASSET_RELATION_SHIP_ID";
	public static final String RET_FWD_ASSET_RELATIONSHIP_INSTANCE_FOR_ASSET_INSTANCE_VERSION_ID_ALL_RELATIONTYPES="RET_FWD_ASSET_RELATIONSHIP_INSTANCE_FOR_ASSET_INSTANCE_VERSION_ID_ALL_RELATIONTYPES";
	public static final String UPDATE_DERIVED_RULE_FAILED = "UPDATE_DERIVED_RULE_FAILED";
	public static final String RELATIONSHIP_DATA_MODIFIED_SUCCESSFULLY = "RELATIONSHIP_DATA_MODIFIED_SUCCESSFULLY";

	/* relationship constants */
	public static final String RELATIONSHIP_NAMES_RETRIEVED_SUCCESSFULLY = "RELATIONSHIP_NAMES_RETRIEVED_SUCCESSFULLY";
	public static final String RELATIONSHIP_DATA_RETRIEVED_SUCCESSFULLY = "RELATIONSHIP_DATA_RETRIEVED_SUCCESSFULLY";
	public static final String RELATIONSHIP_MAPPPED_WITH_ASSET_INSTANCE = "THIS RELATIONSHIP CANNOT BE DELETED AS ASSET INSTANCE RELATIONSHIPS EXIST";
	public static final String RELATIONSHIP_DATA_SAVED_SUCCESSFULLY = "RELATIONSHIP_DATA_SAVED_SUCCESSFULLY";
	public static final String RELATIONSHIP_DATA_UPDATED_SUCCESSFULLY = "RELATIONSHIP_DATA_UPDATED_SUCCESSFULLY";
	
	/*taxonomy sql constants*/
	public static final String GET_ALL_TAXONOMIES = "GET_ALL_TAXONOMIES";
	public static final String GET_ALL_TAXONOMIES_BY_PARENT_TAXONOMY_ID = "GET_ALL_TAXONOMIES_BY_PARENT_TAXONOMY_ID";
	public static final String ADD_TAXONOMY_NAME = "ADD_TAXONOMY_NAME";
	public static final String GET_ALL_TAXONOMIES_BY_TAXONOMY_ID = "GET_ALL_TAXONOMIES_BY_TAXONOMY_ID";
	public static final String UPDATE_TAXONOMY_NAME = "UPDATE_TAXONOMY_NAME";
	public static final String DELETE_TAXONOMY_ID = "DELETE_TAXONOMY_ID";
	public static final String GET_ASSET_INSTANCE_TAXONOMY_FOR_GUEST = "GET_ASSET_INSTANCE_TAXONOMY_FOR_GUEST";
	public static final String GET_ASSET_INSTANCE_TAXONOMY_FOR_ADMIN = "GET_ASSET_INSTANCE_TAXONOMY_FOR_ADMIN";
	public static final String GET_ASSET_INSTANCE_TAXONOMY_FOR_NON_ADMIN_USER = "GET_ASSET_INSTANCE_TAXONOMY_FOR_NON_ADMIN_USER";
	public static final String GET_ALL_TAXONOMIES_BY_ASSETID = "GET_ALL_TAXONOMIES_BY_ASSETID";
	public static final String RET_TAXONOMY_SUBSCRIBER_BY_TAXID = "RET_TAXONOMY_SUBSCRIBER_BY_TAXID";
	public static final String GET_ALL_TAXONOMIES_USED_BY_ASSETS = "GET_ALL_TAXONOMIES_USED_BY_ASSETS";
	public static final String DELETE_ASSIGNED_TAXONOMIES_BY_ASSET_ID = "DELETE_ASSIGNED_TAXONOMIES_BY_ASSET_ID";
	public static final String ADD_ASSIGNED_TAXONOMIES_BY_ASSET_ID = "ADD_ASSIGNED_TAXONOMIES_BY_ASSET_ID";
	public static final String GET_ALL_TAXONOMIES_WITH_SUBSCRIPTION = "GET_ALL_TAXONOMIES_WITH_SUBSCRIPTION";
	public static final String CHEKING_RELATION_IN_DATABASE = "CHEKING_RELATION_IN_DATABASE";
	public static final String GET_TAXONOMY_ID_BY_NAME="GET_TAXONOMY_ID_BY_NAME";
	public static final String GET_RELATIONSHIP_ID_BY_TYPE = "GET_RELATIONSHIP_ID_BY_TYPE";
	public static final String GET_ASSET_RELATIONSHIP_ID_BY_DESC = "GET_ASSET_RELATIONSHIP_ID_BY_DESC";
	//public static final String GET_PARENT_TAXONOMY_ID_BY_TAXONOMY_ID = "GET_PARENT_TAXONOMY_ID_BY_TAXONOMY_ID";
	public static final String RET_TAXONOMY_DETAILS_BY_TAX_ID_AIV_ID = "RET_TAXONOMY_DETAILS_BY_TAX_ID_AIV_ID";
	
	/*taxonomy message constants*/
	public static final String TAXONOMY_DATA_NOT_FOUND = "TAXONOMY_DATA_NOT_FOUND";
	public static final String TAXONOMY_NAME_EXIST="TAXONOMY_NAME_EXIST";
	public static final String TAXONOMY_NOT_CREATED = "TAXONOMY_NOT_CREATED";
	public static final String TAXONOMY_NAME_NOT_UPDATED = "TAXONOMY_NAME_NOT_UPDATED";
	public static final String TAXONOMY_NOT_DELETED= "TAXONOMY_NOT_DELETED";
	public static final String TAXONOMYNAME_NOT_DELETED = "TAXONOMYNAME_NOT_DELETED";
	public static final String TAXONOMYNAME_DELETED = "TAXONOMYNAME_DELETED";
	public static final String TAXONOMY_SUBSCRIBER_NOT_FOUND = "TAXONOMY_SUBSCRIBER_NOT_FOUND";
	public static final String TAXONOMY_SUBJECT_UPDATE = "TAXONOMY_SUBJECT_UPDATE";
	public static final String TAXONOMY_DATA_BY_ASSET_ID_NOT_FOUND = "TAXONOMY_DATA_BY_ASSET_ID_NOT_FOUND";
	public static final String ASSET_INSTANCE_VERSION_TAXONOMY_ID_NOT_FOUND = "ASSET_INSTANCE_VERSION_TAXONOMY_ID_NOT_FOUND";
	public static final String GET_ASSETINSTANCES_ASSIGNED_FOR_TAXONOMY_FAILED = "GET_ASSETINSTANCES_ASSIGNED_FOR_TAXONOMY_FAILED";
	
	/*taxonomy constants*/
	public static final String TAXONOMY_CREATED = "TAXONOMY_CREATED";
	public static final String TAXONOMY_UPDATED = "TAXONOMY_UPDATED";
	public static final String TAXONOMY_DATA_OBTAINED= "TAXONOMY_DATA_OBTAINED";
	public static final String ASSET_INSTANCE_VERSIONNAME = "N/A";
    
	/* tagging sql constants */
	public static final String GET_ALL_TAGS = "GET_ALL_TAGS";
	public static final String DELETE_TAGS_DATA = "DELETE_TAGS_DATA";
	public static final String ADD_TAG_DATA = "ADD_TAG_DATA";

	/* tagging constants */
	public static final String TAGS_SAVED_SUCCESSFULLY = "TAGS_SAVED_SUCCESSFULLY";
	public static final String LIST_BY_ASSET_INSTANCE_VERSION_ID = "LIST_BY_ASSET_INSTANCE_VERSION_ID";

	/* tagging message constants */
	public static final String INSERT_TAGS_FAILED = "INSERT_TAGS_FAILED";
	public static final String NO_TAGS_FOUND = "NO_TAGS_FOUND";
	public static final String EMPTY_TAG_NAME_NOT_ALLOWED = "EMPTY_TAG_NAME_NOT_ALLOWED";
	public static final String DUPLICATE_TAGS_NOT_ALLOWED = "DUPLICATE_TAGS_NOT_ALLOWED";
	
	/* GlobalSetting message constants */
	public static final String GLOBAL_SETTING_DATA_NOT_FOUND = "GLOBAL_SETTING_DATA_NOT_FOUND";
	public static final String UPDATE_GLOBAL_SETTING_DATA_FAILED = "UPDATE_GLOBAL_SETTING_DATA_FAILED";

	/* GlobalSetting SQL constants */
	public static final String GET_GLOBAL_SETTING = "GET_GLOBAL_SETTING";
	public static final String GET_LOCK_TIME = "GET_LOCK_TIME";
	public static final String UPDATE_GLOBAL_SETTING = "UPDATE_GLOBAL_SETTING";
	public static final String UPDATE_LOCK_TIME = "UPDATE_LOCK_TIME";
	public static final String GET_GLOBAL_SETTING_BY_SETTING_NAME ="GET_GLOBAL_SETTING_BY_SETTING_NAME";

	/* GlobalSetting constants */
	public static final String ALL_GLOBAL_SETTING_DATA_FETCHED = "ALL_GLOBAL_SETTING_DATA_FETCHED ";
	public static final String GLOBAL_SETTING_DATA_UPDATED = "GLOBAL_SETTING_DATA_UPDATED ";
	

	/* HelpContents message constants */
	public static final String HELP_CONTENTS_DATA_NOT_FOUND = "HELP_CONTENTS_DATA_NOT_FOUND";
	public static final String INSERT_HELP_CONTENTS_DETAILS_FAILED = "INSERT_HELP_CONTENTS_DETAILS_FAILED";

	/* HelpContents constants */
	public static final String ALL_HELP_CONTENTS_DATA_FETCHED = "ALL_HELP_CONTENTS_DATA_FETCHED";
	public static final String HELP_CONTENTS_DATA_ADDED = "HELP_CONTENTS_DATA_ADDED";

	/* HelpContents SQL constants */
	public static final String GET_HELP_CONTENTS = "GET_HELP_CONTENTS";
	public static final String INSERT_HELP_CONTENTS_DATA = "INSERT_HELP_CONTENTS_DATA";

	
	/*Message Board Constants  */
	public static final String UPDATE_ADMIN_MESSAGE_MASTER = "UPDATE_ADMIN_MESSAGE_MASTER";
	public static final String UPDATE_MESSAGE_DETAILS_FAILED = "UPDATE_MESSAGE_DETAILS_FAILED";
	public static final String SHOW_MESSAGE_DETIALS ="SHOW_MESSAGE_DETIALS";
	public static final String MESSAGE_BOARD_DATA_ADDED ="MESSAGE_BOARD_DATA_ADDED";
	
	/*Message Board message constants  */
	public static final String INSERT_MESSAGE_BOARD_DATA_NOT_FOUND ="INSERT_MESSAGE_BOARD_DATA_NOT_FOUND";
	public static final String MESSAGE_DETIALS_NOT_FOUND ="MESSAGE_DETIALS_NOT_FOUND";
	
	/*Message Board SQL Constants*/
	public static final String GET_MESSAGE_DETIALS="GET_MESSAGE_DETIALS";
	public static final String INSERT_MESSAGE_BOARD_DATA ="INSERT_MESSAGE_BOARD_DATA";
	
	
	/*Gamification sql constants*/
	public static final String RET_GAMIFICATION_POINTS = "RET_GAMIFICATION_POINTS";
	public static final String RET_GAMIFICATION_DETAILS = "RET_GAMIFICATION_DETAILS";
	public static final String ADD_GAMIFICATION_POINT = "ADD_GAMIFICATION_POINT";
	public static final String RET_GAMIFICATION_DETAILS_EXPORT = "RET_GAMIFICATION_DETAILS_EXPORT";
	public static final String RET_GAMIFICATION_DETAILS_BY_USERID = "RET_GAMIFICATION_DETAILS_BY_USERID";
	public static final String RET_GAMIFICATION_DETAILS_FOR_LOGGED_IN_USER = "RET_GAMIFICATION_DETAILS_FOR_LOGGED_IN_USER";
	public static final String RET_GAMIFICATION_DETAILS_BY_USERID_FOR_LOGGED_IN_USER = "RET_GAMIFICATION_DETAILS_BY_USERID_FOR_LOGGED_IN_USER";
	
	/*Gamification Message constants*/
	public static final String GAMIFICATION_POINTS_DATA_NOT_FOUND = "GAMIFICATION_POINTS_DATA_NOT_FOUND";
	public static final String GAMIFICATION_DETAILS_DATA_NOT_FOUND = "GAMIFICATION_DETAILS_DATA_NOT_FOUND";
	public static final String ADD_GAMIFICATION_POINT_DETAILS_FAILED = "ADD_GAMIFICATION_POINT_DETAILS_FAILED";
	public static final String GAMIFICATION_DATA_INSERTED = "GAMIFICATION_DATA_INSERTED";
	
	/*Gamification constants*/
	public static final String RANKS_ADDED_SUCCESSFULLY = "RANKS_ADDED_SUCCESSFULLY";
	public static final String GAMIFICATION_DETAILS_RETREIEVED_SUCCESSFULLY = "GAMIFICATION_DETAILS_RETREIEVED_SUCCESSFULLY";
	public static final String RANKS_FETCHED_SUCCESSFULLY = "RANKS_FETCHED_SUCCESSFULLY";
	
	/*Favourites SQL constants*/
	public static final String INSERT_TO_ADD_FAVOURITES = "INSERT_TO_ADD_FAVOURITES";
	public static final String DELETE_FROM_ADD_FAVOURITES = "DELETE_FROM_ADD_FAVOURITES";
	public static final String GET_ALL_FAVOURITES_DATA = "GET_ALL_FAVOURITES_DATA";
	public static final String GET_MY_FAVOURITE = "GET_MY_FAVOURITE";
	public static final String GET_FAVOURITE_BY_ASSET_INST_ID = "GET_FAVOURITE_BY_ASSET_INST_ID";
	public static final String UPDATE_FAVOURITES = "UPDATE_FAVOURITES";
	public static final String RET_FAV_BASED_ON_ASSET_NAME = "RET_FAV_BASED_ON_ASSET_NAME";
	public static final String UPDATE_FAVOURITES_ASSET_NAME = "UPDATE_FAVOURITES_ASSET_NAME";
	
	/*Favourites   Constants*/
	public static final String FAVOURITES_DATA_DELETED = "FAVOURITES_DATA_DELETED";
	public static final String FAVOURITES_NOT_FOUND = "FAVOURITES_NOT_FOUND";
	public static final String ALL_FAVOURITES_DATA_FETCHED = "ALL_FAVOURITES_DATA_FETCHED";
	public static final String FAVOURITES_DATA_FETCHED = "FAVOURITES_DATA_FETCHED";
	public static final String FAVOURITES_ADDED = "FAVOURITES_ADDED";
	
	/*Favourites Message Constants*/
	public static final String INSERT_ADD_FAVOURITES_DETAILS_FAILED = "INSERT_ADD_FAVOURITES_DETAILS_FAILED";
	public static final String FAVOURITES_DATA_NOT_FOUND = "FAVOURITES_DATA_NOT_FOUND";
	public static final String FAVOURITES_DATA_NOT_DELETED = "FAVOURITES_DATA_NOT_DELETED";
	

	/* sqlConstants User */
	public static final String DELETE_USER_GROUPS_DATA = "DELETE_USER_GROUPS_DATA";
	public static final String ADD_USER_GROUPS_DATA = "ADD_USER_GROUPS_DATA";
	public static final String UPDATE_USER_ACTIVE_FLAG = "UPDATE_USER_ACTIVE_FLAG";
	public static final String UPDATE_DYNAMIC_WIDGETS ="UPDATE_DYNAMIC_WIDGETS";
	public static final String GET_USER_BY_USERNAME = "GET_USER_BY_USERNAME";
	public static final String GET_ALL_USERNAMES ="GET_ALL_USERNAMES";
	public static final String GET_ALL_ACTIVE_USERS = "GET_ALL_ACTIVE_USERS";
	public static final String GET_ALL_ACTIVE_USERS_FOR_EXPORT ="GET_ALL_ACTIVE_USERS_FOR_EXPORT";
	public static final String GET_USER_BY_USERNAME_AND_PASSWORD ="GET_USER_BY_USERNAME_AND_PASSWORD";
	public static final String GET_FUNCTIONS_FOR_USER_NAME ="GET_FUNCTIONS_FOR_USER_NAME";
	public static final String UPDATE_USER_SUBSCRIPTION_FLAG = "UPDATE_USER_SUBSCRIPTION_FLAG";
	public static final String GET_ATTEMPTS_COUNT = "GET_ATTEMPTS_COUNT";
	public static final String UPDATE_USER_ATTEMPT = "UPDATE_USER_ATTEMPT";
	public static final String GET_ALL_ACTIVE_USERS_FOR_LOGGED_IN_USER = "GET_ALL_ACTIVE_USERS_FOR_LOGGED_IN_USER";
	
	/* MessageConstants User */
	public static final String USER_NOT_CREATED = "USER_NOT_CREATED";
	public static final String USER_CREATED = "USER_CREATED";
	public static final String USER_NOT_FOUND = "USER_NOT_FOUND";
	public static final String USERS_FETCHED = "USERS_FETCHED";
	public static final String USER_NAME_EXIST = "USER_NAME_EXIST";
	public static final String EMAIL_EXIST = "EMAIL_EXIST";
	public static final String USER_NOT_UPDATED = "EMAIL_EXIST";
	public static final String USER_UPDATED = "USER_UPDATED";
	public static final String USER_PASSWORD_NOT_UPDATED = "USER_PASSWORD_NOT_UPDATED";
	public static final String USER_PASSWORD_UPDATED = "USER_PASSWORD_UPDATED";
	public static final String USER_NOT_DELETED = "USER_NOT_DELETED";
	public static final String USER_DELETED = "USER_DELETED";
	public static final String USER_BY_ID_FETCHED = "USER_BY_ID_FETCHED";
	public static final String INSERT_USER_GROUP_DETAILS_FAILED = "INSERT_USER_GROUP_DETAILS_FAILED";
	public static final String UPDATE_USER_ACTIVE_FLAG_FAILED = "UPDATE_USER_ACTIVE_FLAG_FAILED";
	public static final String UPDATE_DYNAMIC_WIDGETS_FAILED ="UPDATE_DYNAMIC_WIDGETS_FAILED";
	public static final String DYNAMIC_WIDGETS_UPDATED_SUCCESSFULLY ="DYNAMIC_WIDGETS_UPDATED_SUCCESSFULLY";
	public static final String USER_BY_NAME_AND_PASSWORD_NOT_FOUND ="USER_BY_NAME_AND_PASSWORD_NOT_FOUND";
	public static final String GET_FUNCTIONS_FOR_USER_NAME_NOT_FOUND ="GET_FUNCTIONS_FOR_USER_NAME_NOT_FOUND";
	public static final String USER_BY_NAME_NOT_FOUND ="USER_BY_NAME_NOT_FOUND";
	public static final String UPDATE_USER_SUBSCRIPTION_FLAG_FAILED = "UPDATE_USER_SUBSCRIPTION_FLAG_FAILED";
	public static final String USER_ATTEMPT_NOT_UPDATED = "USER_ATTEMPT_NOT_UPDATED";
	
	/*User Constants*/
	public static final String INSERT_USER = "INSERT_USER";
	public static final String GET_ALL_USERS = "GET_ALL_USERS";
	public static final String GET_ALL_USERS_FOR_GRID = "GET_ALL_USERS_FOR_GRID";
	public static final String UPDATE_USER_BY_ID = "UPDATE_USER_BY_ID";
	public static final String DELETE_USER_BY_NAME = "DELETE_USER_BY_NAME";
	public static final String GET_USER_BY_ID = "GET_USER_BY_ID";
	public static final String GET_USER_BY_NAME = "GET_USER_BY_NAME";
	public static final String USER_BY_NAME_FETCHED = "USER_BY_NAME_FETCHED";
	public static final String UPDATE_USER_PASSWORD_BY_ID = "UPDATE_USER_PASSWORD_BY_ID";
	public static final String RET_ALL_USER_GROUPS_BY_USER_ID = "RET_ALL_USER_GROUPS_BY_USER_ID";
	public static final String GET_USER_ID_BY_USER_NAME = "GET_USER_ID_BY_USER_NAME";
	public static final String GET_USER_ID_BY_USER_NAME_DATA_NOT_FOUND = "GET_USER_ID_BY_USER_NAME_DATA_NOT_FOUND";
	public static final String ASSOCIATED_GROUP_DATA_FETCHED = "ASSOCIATED_GROUP_DATA_FETCHED";
	public static final String ASSOCIATED_GROUP_DATA_NOT_FOUND = "ASSOCIATED_GROUP_DATA_NOT_FOUND";
	public static final String USER_ACCESS_SAVED_SUCCESSFULLY = "USER ACCESS SAVED SUCCESSFULLY";
	public static final String UPDATE_USER_PASSWORD_BY_USER_ID = "UPDATE_USER_PASSWORD_BY_USER_ID";
	public static final String LOCK_STATUS_UPDATED_SUCCESSFULLY = "LOCK_STATUS_UPDATED_SUCCESSFULLY";
	public static final String GET_ALL_FILTERED_USERS_FOR_GRID = "GET_ALL_FILTERED_USERS_FOR_GRID";
	public static final String GROUP_ROLE_DETAILS_FETCHED = "GROUP_ROLE_DETAILS_FETCHED";
	
	/*Asset Instance*/
	public static final String GET_ASSET_INSTANCE_FOR_GRID = "GET_ASSET_INSTANCE_FOR_GRID";
	public static final String ASSET_INSTANCE_FETCHED = "ASSET_INSTANCE_FETCHED";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID";
	public static final String GET_FILTERED_ASSET_INSTANCE_FOR_GRID = "GET_FILTERED_ASSET_INSTANCE_FOR_GRID";
	public static final String GET_FILTERED_AND_SHOW_HIDE_ASSET_INSTANCE_FOR_GRID = "GET_FILTERED_AND_SHOW_HIDE_ASSET_INSTANCE_FOR_GRID";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_ADMIN = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_ADMIN";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GUEST = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GUEST";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_ADMIN = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_ADMIN";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_NORMAL_USER = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_NORMAL_USER";
	public static final String GET_ASSET_INSTANCE_ACCESS_FOR_GUEST = "GET_ASSET_INSTANCE_ACCESS_FOR_GUEST";
	public static final String GET_ASSET_INSTANCE_ACCESS_FOR_LOGIN_USER = "GET_ASSET_INSTANCE_ACCESS_FOR_LOGIN_USER";
	public static final String ASSET_INSTANCE_ACCESS_NOT_FOUND = "ASSET_INSTANCE_ACCESS_NOT_FOUND";
	public static final String ASSET_INSTANCE_ACCESS_FETCHED = "ASSET_INSTANCE_ACCESS_FETCHED";
	
	/*assetinstance Constants*/
	public static final String REPOPRO_ASSET_INSTANCE_UPDATE = "REPOPRO_ASSET_INSTANCE_UPDATE";
	
	/*assetinstance messag*/
	public static final String ASSET_INSTANCE_ALREADY_EXIST ="ASSET_INSTANCE_ALREADY_EXIST";
	public static final String GET_ASSET_INSTANCE_ACCESS_FOR_GUEST_NOT_FOUND = "GET_ASSET_INSTANCE_ACCESS_FOR_GUEST_NOT_FOUND";
	public static final String GET_ASSET_INSTANCE_ACCESS_FOR_LOGIN_USER_NOT_FOUND = "GET_ASSET_INSTANCE_ACCESS_FOR_LOGIN_USER_NOT_FOUND";
	
	/*MailTemplate Sql constants*/
	public static final String GET_ALL_MailTemplate = "GET_ALL_MailTemplate";
	public static final String UPDATE_MAILTEMPLATE = "UPDATE_MAILTEMPLATE";
	
	/*MailTemplate message constants*/
	public static final String GET_MAILTEMPLATE_DETAILS_FAILED = "GET_MAILTEMPLATE_DETAILS_FAILED";
	public static final String UPDATE_MAILTEMPLATE_DETAILS_FAILED = "UPDATE_MAILTEMPLATE_DETAILS_FAILED";
	
	/*MailTemplate constants*/
	public static final String MAILTEMPLATE_DATA_FETCHED = "MAILTEMPLATE_DATA_FETCHED";
	public static final String MAILTEMPLATE_DATA_NOT_FOUND = "MAILTEMPLATE_DATA_NOT_FOUND";
	public static final String MAILTEMPLATE_DATA_UPDATED = "MAILTEMPLATE_DATA_UPDATED";
	
	
	/*QuickStats sql constants*/
	public static final String GET_ASSET_AND_COUNT_FOR_GUEST = "GET_ASSET_AND_COUNT_FOR_GUEST";
	public static final String GET_ADMIN_RIGHT = "GET_ADMIN_RIGHT";
	public static final String GET_ASSET_AND_COUNT_FOR_ADMIN = "GET_ASSET_AND_COUNT_FOR_ADMIN";
	public static final String GET_ASSET_AND_COUNT_FOR_NON_ADMIN_USER = "GET_ASSET_AND_COUNT_FOR_NON_ADMIN_USER";
	
	/*QuickStats message constants*/
	public static final String GET_QUICKSTATS_DETAILS_FAILED = "GET_QUICKSTATS_DETAILS_FAILED";
	
	/*QuickStats constants*/
	public static final String QUICKSTATS_DATA_FETCHED = "QUICKSTATS_DATA_FETCHED";
	public static final String QUICKSTATS_DATA_NOT_FOUND = "QUICKSTATS_DATA_NOT_FOUND";
	
	
	/*ShowHideColumn sql constants*/
	public static final String GET_ALL_SHOW_HIDE_DATA_FOR_ASSOCIATE_GROUP = "GET_ALL_SHOW_HIDE_DATA_FOR_ASSOCIATE_GROUP";
	public static final String GET_ALL_SHOW_HIDE_DATA_FOR_AIV_ID = "GET_ALL_SHOW_HIDE_DATA_FOR_AIV_ID";
	public static final String GET_ALL_SHOW_HIDE_PARAM_VALUES = "GET_ALL_SHOW_HIDE_PARAM_VALUES";
	public static final String GET_ALL_SHOW_HIDE_PARAM_VALUES_FOR_DEFAULT = "GET_ALL_SHOW_HIDE_PARAM_VALUES_FOR_DEFAULT";
	public static final String GET_ALL_PARAM_DETAILS_FOR_ADMIN= "GET_ALL_PARAM_DETAILS_FOR_ADMIN";
	public static final String GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN = "GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN";
	public static final String DELETE_ALL_SHOW_HIDE_DATA_FOR_ASSOCIATE_GROUP_BY_ASSETID_AND_USERID = "DELETE_ALL_SHOW_HIDE_DATA_FOR_ASSOCIATE_GROUP_BY_ASSETID_AND_USERID";
	public static final String ADD_SHOWHIDE_FOR_ASSOCIATE_GROUP_COLUMN = "ADD_SHOWHIDE_FOR_ASSOCIATE_GROUP_COLUMN";
	public static final String DELETE_ALL_SHOW_HIDE_DATA_FOR_AIVID_BY_ASSETID_AND_USERID = "DELETE_ALL_SHOW_HIDE_DATA_FOR_AIVID_BY_ASSETID_AND_USERID";
	public static final String ADD_SHOWHIDE_FOR_AIVID_COLUMN = "ADD_SHOWHIDE_FOR_AIVID_COLUMN";
	public static final String DELETE_ALL_SHOW_HIDE_PARAM_VALUES = "DELETE_ALL_SHOW_HIDE_PARAM_VALUES";
	public static final String ADD_ALL_SHOW_HIDE_PARAM_VALUES = "ADD_ALL_SHOW_HIDE_PARAM_VALUES";
	
	/*ShowHideColumn message constants*/
	public static final String GET_SHOWHIDE_FOR_ASSOCIATE_GROUPCOLUMN_DETAILS_FAILED = "GET_SHOWHIDE_FOR_ASSOCIATE_GROUPCOLUMN_DETAILS_FAILED";
	public static final String GET_SHOWHIDE_FOR_AIVID_COLUMN_DETAILS_FAILED = "GET_SHOWHIDE_FOR_AIVID_COLUMN_DETAILS_FAILED";
	public static final String GET_SHOWHIDE_COLUMN_DETAILS_FAILED = "GET_SHOWHIDE_COLUMN_DETAILS_FAILED";
	public static final String ADD_SHOWHIDE_FOR_ASSOCIATE_GROUPCOLUMN_DETAILS_FAILED = "ADD_SHOWHIDE_FOR_ASSOCIATE_GROUPCOLUMN_DETAILS_FAILED";
	public static final String ADD_SHOWHIDE_FOR_AIVID_COLUMN_DETAILS_FAILED = "ADD_SHOWHIDE_FOR_AIVID_COLUMN_DETAILS_FAILED";
	public static final String ADD_SHOWHIDE_COLUMN_DETAILS_FAILED = "ADD_SHOWHIDE_COLUMN_DETAILS_FAILED";
	
	/*ShowHideColumn constants*/
	public static final String SHOWCOLUMN_DATA_FETCHED = "SHOWCOLUMN_DATA_FETCHED";
	public static final String SHOWCOLUMN_DATA_ADDED = "SHOWCOLUMN_DATA_ADDED";

	
	/*filters sql constants*/
	public static final String GET_ALL_CUSTOMLIST = "GET_ALL_CUSTOMLIST";
	public static final String GET_ALL_USERLIST = "GET_ALL_USERLIST";
	public static final String GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_GUEST = "GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_GUEST";
	public static final String GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN = "GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN";
	public static final String GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN = "GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN";
	public static final String GET_ASSET_INSTANCE_FOR_ADMIN ="GET_ASSET_INSTANCE_FOR_ADMIN";
	public static final String GET_ASSET_INSTANCE_FOR_NON_ADMIN_USER = "GET_ASSET_INSTANCE_FOR_NON_ADMIN_USER";
	public static final String GET_ASSET_INSTANCE_FOR_GUEST = "GET_ASSET_INSTANCE_FOR_GUEST";
	public static final String GET_ALL_PARAM_DETAILS_FOR_GUEST = "GET_ALL_PARAM_DETAILS_FOR_GUEST";
	public static final String ADD_FILTER_SEARCH = "ADD_FILTER_SEARCH";
	public static final String GET_FILTER_SEARCH = "GET_FILTER_SEARCH";
	public static final String DELETE_FILTER_SEARCH  = "DELETE_FILTER_SEARCH";
	public static final String UPDATE_FILTERSEARCH = "UPDATE_FILTERSEARCH";
	public static final String GET_ALL_FILTER_SEARCH = "GET_ALL_FILTER_SEARCH";
	public static final String GET_FILTER_SEARCH_FOR_LOAD = "GET_FILTER_SEARCH_FOR_LOAD";
	public static final String GET_ALL_PARAM_DETAILS_BY_PARAM_ID = "GET_ALL_PARAM_DETAILS_BY_PARAM_ID";
	public static final String GET_PARAM_ID_BY_PARAM_NAME = "GET_PARAM_ID_BY_PARAM_NAME";
	
	/*filters message constants*/
	public static final String FILTER_DATA_NOT_FOUND = "FILTER_DATA_NOT_FOUND";
	public static final String GET_PARAM_DETAILS_FAILED = "GET_PARAM_DETAILS_FAILED";
	public static final String FILTER_SEARCH_NOT_DELETED = "FILTER_SEARCH_NOT_DELETED";
	public static final String FILTER_SEARCH_NOT_CREATED = "FILTER_SEARCH_NOT_CREATED";
	
	public static final String FILTERSEARCH_NOT_UPDATED = "FILTERSEARCH_NOT_UPDATED";
	public static final String FILTERSEARCH_DATA_NOT_DELETED = "FILTERSEARCH_DATA_NOT_DELETED";
	public static final String FILTER_SEARCH_NAME_ALREADY_EXISTS = "FILTER_SEARCH_NAME_ALREADY_EXISTS";

	/*filters constants*/
	public static final String FILTERLIST_DATA_FETCHED = "FILTERLIST_DATA_FETCHED";
	public static final String PARAMLIST_DATA_FETCHED = "PARAMLIST_DATA_FETCHED";
	public static final String GUEST = "guest";
	public static final String FILTER_SEARCH_NAME_EXIST = "FILTER_SEARCH_NAME_EXIST";
	public static final String FILTER_SEARCH_CREATED = "FILTER_SEARCH_CREATED";
	public static final String FILTER_SEARCH_DATA_NOT_FOUND = "FILTER_SEARCH_DATA_NOT_FOUND";
	public static final String FILTER_SEARCH_DATA_FETCHED = "FILTER_SEARCH_DATA_FETCHED";
	public static final String FILTER_SEARCH_DATA_UPDATED = "FILTER SEARCH DATA UPDATED";
	public static final String FILTERSEARCH_DATA_DELETED = "FILTERSEARCH_DATA_DELETED";
	
	
	/*image constants*/
	public static final String USERIMAGE_FILE_NAME = "/profileImages/";
	public static final String USERIMAGE_JPG_NAME = ".jpg";
	public static final String USERIMAGE_PNG_NAME = ".png";
	public static final String ASSET_IMAGE_FILE_NAME = "/assetImages/";
	public static final String ASSET_IMAGE_JPG_NAME = ".jpg";
	public static final String ASSET_IMAGE_PNG_NAME = ".png";
	
	/* Quick Search - Queries */
	public static final String RET_MATCHED_PROFILE = "RET_MATCHED_PROFILE";
	public static final String RET_MATCHED_ASSET = "RET_MATCHED_ASSET";
	public static final String RET_MATCHED_ASSET_FOR_GUEST = "RET_MATCHED_ASSET_FOR_GUEST";
	public static final String RET_MATCHED_ASSET_FOR_ASSET_TYPE = "RET_MATCHED_ASSET_FOR_ASSET_TYPE";
	public static final String RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST = "RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE = "RET_ALL_MATCHED_ASSET_INSTANCE";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS";
	public static final String GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS = "GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS";
	public static final String RET_ALL_MATCHED_TAXOXNOMY = "RET_ALL_MATCHED_TAXOXNOMY";
	public static final String RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET = "RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS";
	public static final String RET_ALL_MATCHED_PARAMETER = "RET_ALL_MATCHED_PARAMETER";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_GUEST = "RET_ALL_MATCHED_PARAMETER_FOR_GUEST";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS = "RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE = "RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST = "RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS = "RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS";
	public static final String RET_PARAM_NAMES_FOR_ASSET_BY_ADMIN = "RET_PARAM_NAMES_FOR_ASSET_BY_ADMIN";
	public static final String RET_PARAM_NAMES_FOR_ASSET_BY_GROUPS = "RET_PARAM_NAMES_FOR_ASSET_BY_GROUPS";
	public static final String RET_PARAM_NAMES_FOR_ASSET_BY_GROUPS_FOR_GUEST = "RET_PARAM_NAMES_FOR_ASSET_BY_GROUPS_FOR_GUEST";
	
	
	public static final String RET_MATCHED_PROFILE_WITH_LIMIT = "RET_MATCHED_PROFILE_WITH_LIMIT";
	public static final String RET_MATCHED_ASSET_WITH_LIMIT = "RET_MATCHED_ASSET_WITH_LIMIT";
	public static final String RET_MATCHED_ASSET_FOR_GUEST_WITH_LIMIT = "RET_MATCHED_ASSET_FOR_GUEST_WITH_LIMIT";
	public static final String RET_MATCHED_ASSET_FOR_ASSET_TYPE_WITH_LIMIT = "RET_MATCHED_ASSET_FOR_ASSET_TYPE_WITH_LIMIT";
	public static final String RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT = "RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_WITH_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST_WITH_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS_WITH_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_WITH_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITH_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITH_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_WITH_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_WITH_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST_WITH_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST_WITH_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS_WITH_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_TAXOXNOMY_WITH_LIMIT = "RET_ALL_MATCHED_TAXOXNOMY_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET_WITH_LIMIT = "RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET_WITH_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_WITH_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_WITH_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST_WITH_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST_WITH_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS_WITH_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_WITH_LIMIT = "RET_ALL_MATCHED_PARAMETER_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_GUEST_WITH_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_GUEST_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS_WITH_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_WITH_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITH_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITH_LIMIT";
	
	
	public static final String RET_MATCHED_PROFILE_WITHOUT_LIMIT = "RET_MATCHED_PROFILE_WITHOUT_LIMIT";
	public static final String RET_MATCHED_ASSET_WITHOUT_LIMIT = "RET_MATCHED_ASSET_WITHOUT_LIMIT";
	public static final String RET_MATCHED_ASSET_FOR_GUEST_WITHOUT_LIMIT = "RET_MATCHED_ASSET_FOR_GUEST_WITHOUT_LIMIT";
	public static final String RET_MATCHED_ASSET_FOR_ASSET_TYPE_WITHOUT_LIMIT = "RET_MATCHED_ASSET_FOR_ASSET_TYPE_WITHOUT_LIMIT";
	public static final String RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT = "RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_WITHOUT_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST_WITHOUT_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_WITHOUT_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT = "RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_WITHOUT_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_WITHOUT_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST_WITHOUT_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST_WITHOUT_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_TAXOXNOMY_WITHOUT_LIMIT = "RET_ALL_MATCHED_TAXOXNOMY_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET_WITHOUT_LIMIT = "RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET_WITHOUT_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_WITHOUT_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_WITHOUT_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST_WITHOUT_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST_WITHOUT_LIMIT";
	public static final String RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT = "RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_WITHOUT_LIMIT = "RET_ALL_MATCHED_PARAMETER_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_GUEST_WITHOUT_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_GUEST_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_WITHOUT_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT";
	public static final String RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT = "RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT";
	
	
	
	/* Quick Search - constants */
	public static final String SEARCH_DATA_NOT_FOUND = "SEARCH_DATA_NOT_FOUND";
	public static final String PARAMETER_DATA_NOT_FOUND = "PARAMETER_DATA_NOT_FOUND";
	public static final String TAGGING_DATA_NOT_FOUND = "TAGGING_DATA_NOT_FOUND";
	public static final String SEARCH_DATA_FETCHED = "SEARCH_DATA_FETCHED";
	
	/* Advanced Search - constants */
	public static final String GET_ADVANCED_SEARCH_DETAILS = "GET_ADVANCED_SEARCH_DETAILS";
	public static final String ADVANCED_SEARCH_DATA_NOT_FOUND = "ADVANCED_SEARCH_DATA_NOT_FOUND";
	public static final String ADVANCED_SEARCH_BY_USECASE_DATA_NOT_FOUND = "ADVANCED_SEARCH_BY_USECASE_DATA_NOT_FOUND";
	public static final String GET_ADVANCED_SEARCH_DETAILS_BY_USECASE = "GET_ADVANCED_SEARCH_DETAILS_BY_USECASE";
	public static final String ADVANCED_SEARCH_BY_USECASE_RETRIEVED_SUCCESSFULLY = "ADVANCED_SEARCH_BY_USECASE_RETRIEVED_SUCCESSFULLY";
	public static final String ADVANCED_SEARCH_RETRIEVED_SUCCESSFULLY = "ADVANCED_SEARCH_RETRIEVED_SUCCESSFULLY";
	public static final String ADVANCED_SEARCH_BY_USECASE_DETAILS_RETRIEVED_SUCCESSFULLY = "ADVANCED_SEARCH_BY_USECASE_DETAILS_RETRIEVED_SUCCESSFULLY";
	public static final String ADVANCED_SEARCH_DETAILS_NOT_FOUND = "ADVANCED_SEARCH_DETAILS_NOT_FOUND";
	public static final String USECASE_NOT_FOUND = "USECASE_NOT_FOUND";
	
	/* Quick Search - Matched constants */
	public static final String USER_ID_MATCHED = "USER_ID_MATCHED";
	public static final String USER_NAME_MATCHED = "USER_NAME_MATCHED";
	public static final String EMAIL_ID_MATCHED = "EMAIL_ID_MATCHED";
	public static final String FULL_NAME_MATCHED = "FULL_NAME_MATCHED";
	public static final String DEPT_MATCHED = "DEPT_MATCHED";
	public static final String ASSET_NAME_MATCHED = "ASSET_NAME_MATCHED";
	public static final String DESC_MATCHED = "DESC_MATCHED";
	public static final String ASSET_INST_NAME_MATCHED = "ASSET_INST_NAME_MATCHED";
	public static final String ASSET_INST_DESC_MATCHED = "ASSET_INST_DESC_MATCHED";
	public static final String VERSION_NAME_MATCHED = "VERSION_NAME_MATCHED";
	public static final String ASSET_PARAM_NAME_MATCHED = "ASSET_PARAM_NAME_MATCHED";
	public static final String VALUE_MATCHED = "VALUE_MATCHED";
	public static final String TAXONOMY_NAME_MATCHED = "TAXONOMY_NAME_MATCHED";
	
	
	/* Rating - queries */
	public static final String GET_ALL_RATINGS = "GET_ALL_RATINGS";
	public static final String RET_COUNT_OF_VERSION_RATING = "RET_COUNT_OF_VERSION_RATING";
	public static final String UPDATE_RATING = "UPDATE_RATING";
	public static final String ADD_RATING = "ADD_RATING";
	public static final String GET_USERS_COUNT = "GET_USERS_COUNT";

	/* Rating - Messages */
	public static final String RATINGS_NOT_FOUND = "RATINGS_NOT_FOUND";
	public static final String RATING_NOT_UPDATED = "RATING_NOT_UPDATED";
	public static final String RATING_NOT_ADDED = "RATING_NOT_ADDED";
	public static final String USER_COUNT_NOT_FOUND = "USER_COUNT_NOT_FOUND";
	
	/* Rating - Constants */
	public static final String ALL_RATINGS_FETCHED = "ALL_RATINGS_FETCHED";
	public static final String RATING_UPDATED = "RATING_UPDATED";
	public static final String RATING_ADDED = "RATING_ADDED";
	public static final String USER_COUNT_FETCHED = "USER_COUNT_FETCHED";
	
	
	/* Discussion Comments - Queries */
	public static final String GET_ALL_COMMENTS = "GET_ALL_COMMENTS";
	public static final String ADD_COMMENT = "ADD_COMMENT";
	public static final String REPLY_TO_COMMENT = "REPLY_TO_COMMENT";
	public static final String GET_PARENT_COMMENT_ID = "GET_PARENT_COMMENT_ID";
	public static final String GET_ALL_COMMENTS_FOR_LOGGED_IN_USER = "GET_ALL_COMMENTS_FOR_LOGGED_IN_USER";
	
	/* Discussion Comments - constants */
	public static final String ALL_COMMENTS_FETCHED = "ALL_COMMENTS_FETCHED";
	public static final String COMMENT_ADDED = "COMMENT_ADDED";
	public static final String REPLY_ADDED = "REPLY_ADDED";
	
	/* Discussion Comments - messages */
	public static final String COMMENTS_NOT_FOUND = "COMMENTS_NOT_FOUND";
	public static final String COMMENT_NOT_ADDED = "COMMENT_NOT_ADDED";
	public static final String REPLY_NOT_ADDED = "REPLY_NOT_ADDED";
	
	
	/* Asset instance version - sql constants */
	public static final String RET_TAXONOMY_ID_BY_ASSET_INST_VERSION_ID = "RET_TAXONOMY_ID_BY_ASSET_INST_VERSION_ID";
	public static final String REMOVE_ASSIGNED_TAXONOMY_NAME = "REMOVE_ASSIGNED_TAXONOMY_NAME";
	public static final String UPDATE_ASSIGNED_TAXONOMY_NAME = "UPDATE_ASSIGNED_TAXONOMY_NAME";
	public static final String ADD_ASSIGNED_TAXONOMY_NAME = "ADD_ASSIGNED_TAXONOMY_NAME";
	public static final String TAXONOMY_ASSIGNED_SUCCESSFULLY = "TAXONOMY_ASSIGNED_SUCCESSFULLY";
	public static final String GET_LOCKTIME_FROM_DB = "GET_LOCKTIME_FROM_DB";
	public static final String RET_ASSET_INST_VERSION_BY_ASSET_VERSION_ID = "RET_ASSET_INST_VERSION_BY_ASSET_VERSION_ID";
	public static final String LOCK_ASSET_INSTANCE_VERSION = "LOCK_ASSET_INSTANCE_VERSION";
	public static final String UNLOCK_ASSET_INSTANCE_VERSION = "UNLOCK_ASSET_INSTANCE_VERSION";
	public static final String ADD_ASSET_INSTANCE_VERSION ="ADD_ASSET_INSTANCE_VERSION";
	public static final String UPDATE_ASSET_INSTANCE_VERSION ="UPDATE_ASSET_INSTANCE_VERSION";
	public static final String UPDATE_ASSET_INSTANCE_VERSION_LOCK = "UPDATE_ASSET_INSTANCE_VERSION_LOCK";
	public static final String DELETE_ASSET_INSTANCE_VERSION ="DELETE_ASSET_INSTANCE_VERSION";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_INSTANCE_VERSION_ID ="GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_INSTANCE_VERSION_ID";
	public static final String GET_ASSET_INSTANCE_VERSIONS_BY_ASSET_INSTANCE_ID ="GET_ASSET_INSTANCE_VERSIONS_BY_ASSET_INSTANCE_ID";
	public static final String GET_ASSET_INSTANCE_NAME_BY_ASSET_NAME_AND_AIV_ID = "GET_ASSET_INSTANCE_NAME_BY_ASSET_NAME_AND_AIV_ID";
	public static final String GET_STATIC_AND_FILENAMES = "GET_STATIC_AND_FILENAMES";
	public static final String UPDATE_ASSET_PARAM_DEF ="UPDATE_ASSET_PARAM_DEF";
	public static final String ADD_ASSET_INST_PARAM ="ADD_ASSET_INST_PARAM";
	public static final String ADD_PARAMETER_VALUES ="ADD_PARAMETER_VALUES";
	public static final String GET_PARAM_DETAILS_BY_ASSET_NAME ="GET_PARAM_DETAILS_BY_ASSET_NAME";
	public static final String GET_PARAMETER_VALUES_BY_ASSET_PARAM_NAME_AND_VERSIONID ="GET_PARAMETER_VALUES_BY_ASSET_PARAM_NAME_AND_VERSIONID";
	public static final String GET_PARAM_ID_FOR_ASSET_AND_PARAM_NAME ="GET_PARAM_ID_FOR_ASSET_AND_PARAM_NAME";
	public static final String GET_CHILD_NAMES_FOR_ASSET_INSTANCE_BY_ASSET_ID_AND_VERSION_ID ="GET_CHILD_NAMES_FOR_ASSET_INSTANCE_BY_ASSET_ID_AND_VERSION_ID";
	public static final String GET_NON_STATIC_PARAM_DEFS = "GET_NON_STATIC_PARAM_DEFS";	
	public static final String GET_STATIC_PARAM_DEFS = "GET_STATIC_PARAM_DEFS";
	public static final String ADD_PARAMETER_VALUES_FOR_RICH_TEXT = "ADD_PARAMETER_VALUES_FOR_RICH_TEXT";
		
	public static final String FIND_ASSET_PARAM_DEF_BY_ASSET_NAME_AND_PARAM_NAME="FIND_ASSET_PARAM_DEF_BY_ASSET_NAME_AND_PARAM_NAME";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_NON_STATIC_PARAM_INFORMATION_BY_ASSET_NAME= "GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_NON_STATIC_PARAM_INFORMATION_BY_ASSET_NAME";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_STATIC_PARAM_INFORMATION_BY_ASSET_NAME_ADMIN= "GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_STATIC_PARAM_INFORMATION_BY_ASSET_NAME_ADMIN";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN= "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN";
    public static final String GET_ASSET_PARAM_DEFS_BY_PARAMETERS = "GET_ASSET_PARAM_DEFS_BY_PARAMETERS";
	public static final String GET_BASIC_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST = "GET_BASIC_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST";
	//public static final String UPDATE_ASSET_INSTANCE_VERSION_UPDATED_ON ="UPDATE_ASSET_INSTANCE_VERSION_UPDATED_ON";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_STATIC_PARAM_INFORMATION_BY_ASSET_NAME__NON_ADMIN= "GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_STATIC_PARAM_INFORMATION_BY_ASSET_NAME_NON_ADMIN";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN="GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST";
	public static final String GET_ASSET_PARAM_DEF_BY_ASSET_NAME_AND_ASSET_PARAM_NAME = "GET_ASSET_PARAM_DEF_BY_ASSET_NAME_AND_ASSET_PARAM_NAME";
	public static final String CHECKING_ACCESS_FOR_PARAM_NON_ADMIN_AND_GUEST = "CHECKING_ACCESS_FOR_PARAM_NON_ADMIN_AND_GUEST";
	public static final String CHECKING_ACCESS_FOR_PARAM_ADMIN_AND_GUEST = "CHECKING_ACCESS_FOR_PARAM_ADMIN_AND_GUEST";
	
	public static final String GET_ASSET_RELATIONSHIP_DEF_BY_RELATION_NAME = "GET_ASSET_RELATIONSHIP_DEF_BY_RELATION_NAME";
	public static final String RET_CATEGORY_NAMES_FOR_ASSET_BY_GROUPS_FOR_GUEST ="RET_CATEGORY_NAMES_FOR_ASSET_BY_GROUPS_FOR_GUEST";
	public static final String GETS_ASSET_DEF_BY_ASSET_NAME = "GETS_ASSET_DEF_BY_ASSET_NAME";
	public static final String RETRN_PARAM_VALUES_FOR_PARAMETER_NAME_AND_ASSET_INSTANCE_VERSION_ID = "RETRN_PARAM_VALUES_FOR_PARAMETER_NAME_AND_ASSET_INSTANCE_VERSION_ID";
	
	public static final String GET_PARAMETER_DETAILS_FOR_ADMIN_USER_NON_STATIC= "GET_PARAMETER_DETAILS_FOR_ADMIN_USER_NON_STATIC";
	public static final String GET_PARAMETER_DETAILS_FOR_GROUP_ADMIN_USER_FOR_NON_STATIC= "GET_PARAMETER_DETAILS_FOR_GROUP_ADMIN_USER_FOR_NON_STATIC";
	public static final String GET_PARAMETER_DETAILS_FOR_GUEST_USER_FOR_NON_STATIC= "GET_PARAMETER_DETAILS_FOR_GUEST_USER_FOR_NON_STATIC";
	public static final String GET_PARAMETER_DETAILS_FOR_NORMAL_USER_FOR_NON_STATIC= "GET_PARAMETER_DETAILS_FOR_NORMAL_USER_FOR_NON_STATIC";
	public static final String RET_GROUPS_WITH_AIV_ACCESS = "RET_GROUPS_WITH_AIV_ACCESS";
	public static final String DELETE_GROUPS_ACCESS = "DELETE_GROUPS_ACCESS";
	public static final String ADD_GROUPS_ACCESS = "ADD_GROUPS_ACCESS";
	//public static final String UPDATE_ASSET_INSTANCE_VERSION_UPDATED_ON ="UPDATE_ASSET_INSTANCE_VERSION_UPDATED_ON";
	public static final String UPDATE_PARAMETER_VALUES ="UPDATE_PARAMETER_VALUES";
	public static final String UPDATE_ASSET_INSTANCE_VERSION_UPDATED_ON ="UPDATE_ASSET_INSTANCE_VERSION_UPDATED_ON";
	public static final String RET_NUM_OF_DEPENDENTS_FOR_ASSET_INSTANCE_BASED_ON_ASSET_TYPE = "RET_NUM_OF_DEPENDENTS_FOR_ASSET_INSTANCE_BASED_ON_ASSET_TYPE";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS = "GET_ASSET_INSTANCE_VERSION_DETAILS";
	public static final String RET_TAXONOMY_DETAILS_BY_AIV_ID = "RET_TAXONOMY_DETAILS_BY_AIV_ID";
	public static final String DELETE_PARAMETER_VALUES = "DELETE_PARAMETER_VALUES";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_INSTANCE_NAME_AND_VERSION_ID = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_INSTANCE_NAME_AND_VERSION_ID";
	public static final String GET_ASSET_INSTANCE_VERSIONS_AND_VERSION_DETAILS = "GET_ASSET_INSTANCE_VERSIONS_AND_VERSION_DETAILS";
	public static final String GET_ASSET_INSTANCE_VERSIONS_AND_VERSION_DETAILS_FOR_NON_ADMIN = "GET_ASSET_INSTANCE_VERSIONS_AND_VERSION_DETAILS_FOR_NON_ADMIN";
	public static final String GET_ASSET_INSTANCE_VERSIONS_AND_VERSION_DETAILS_FOR_GUEST = "GET_ASSET_INSTANCE_VERSIONS_AND_VERSION_DETAILS_FOR_GUEST";
  	public static final String GET_LATEST_ASSET_INSTANCE_VERSION = "GET_LATEST_ASSET_INSTANCE_VERSION";

	/* Asset Instance Version - constants */
	public static final String PARAMETER_VALUES_NOT_DELETED = "PARAMETER_VALUES_NOT_DELETED";
	public static final String ASSET_INSTANCE_VERSION_LOCKED = "ASSET_INSTANCE_VERSION_LOCKED";
	public static final String ASSET_INSTANCE_VERSION_UNLOCKED = "ASSET_INSTANCE_VERSION_UNLOCKED";
	public static final String ASSET_INSTANCE_VERSION_CREATED ="ASSET_INSTANCE_VERSION_CREATED";
	public static final String ASSET_INSTANCE_VERSION_NAME_EXIST ="ASSET_INSTANCE_VERSION_NAME_EXIST";
	public static final String ASSET_INSTANCE_VERSION_UPDATED ="ASSET_INSTANCE_VERSION_UPDATED";
	public static final String ASSET_INSTANCE_VERSION_DELETED ="ASSET_INSTANCE_VERSION_DELETED";
	public static final String NO_CHANGES_TO_UPDATE ="NO_CHANGES_TO_UPDATE";
	public static final String ASSET_INSTANCE_VERSIONS_COMPARED ="ASSET_INSTANCE_VERSIONS_COMPARED";
	public static final String CHILD_NAMES_FOR_ASSET_INSTANCE_FETCHED ="CHILD_NAMES_FOR_ASSET_INSTANCE_FETCHED";
	public static final String ACTIVITY_CREATE = "created";
	public static final String ACTIVITY_DELETE = "deleted";
	public static final String ASSET_INSTANCE_VERSION_DETAILS_FETCHED = "ASSET_INSTANCE_VERSION_DETAILS_FETCHED";
	public static final String ASSET_INSTANCE_VERSIONS_FETCHED ="ASSET_INSTANCE_VERSIONS_FETCHED";
	public static final String DERIVED_COMPUTATION_FETCHED_SUCCESSFULLY = "DERIVED_COMPUTATION_FETCHED_SUCCESSFULLY";
	public static final String ASSET_INSTANCE_PARAMETERS_SUCCESSFULLY_FETCHED = "ASSET_INSTANCE_PARAMETERS_SUCCESSFULLY_FETCHED";
	public static final String DERIVED_ATTRIBUTE_FETCHED_SUCCESSFULLY = "DERIVED_ATTRIBUTE_FETCHED_SUCCESSFULLY";
	public static final String ASSET_INSTANCE_PROPERTIES_UPDATED_AND_UNLOCKED = "ASSET_INSTANCE_PROPERTIES_UPDATED_AND_UNLOCKED";
	public static final String ASSET_INSTANCE_PARAMETERS_FETCHED = "ASSET_INSTANCE_PARAMETERS_FETCHED";
	public static final String GROUP_ACCESS_SAVED = "GROUP_ACCESS_SAVED";
	public static final String GROUP_ACCESS_ASSET_FETCHED = "GROUP_ACCESS_ASSET_FETCHED";
	public static final String TAXONOMIES_BY_AIV_ID_FETCHED = "TAXONOMIES_BY_AIV_ID_FETCHED";
	public static final String RELATIONSHIPS_BY_AIV_ID_FETCHED = "RELATIONSHIPS_BY_AIV_ID_FETCHED";
	public static final String RELATIONSHIPS_BY_ASSET_ID_FETCHED = "RELATIONSHIPS_BY_ASSET_ID_FETCHED";
	public static final String ASSET_INSTANCE_PROPERTIES_UPDATED = "ASSET_INSTANCE_PROPERTIES_UPDATED";
	public static final String TAXONOMY_HIERARCHY_FETCHED = "TAXONOMY_HIERARCHY_FETCHED";
	public static final String GROUP_ACCESS_ASSETINSTANCE_FOUND = "GROUP_ACCESS_ASSETINSTANCE_FOUND";
	public static final String VERSION_NOT_AVAILABLE = "VERSION_NOT_AVAILABLE_TO_COPY";
	public static final String ASSET_NOT_VERSIONABLE = "ASSET_NOT_VERSIONABLE";
	public static final String NO_ADD_ACCESS = "NO_ADD_ACCESS"; 
	public static final String ASSET_INSTANCE_ACCESS_DEINED = "ASSET_INSTANCE_ACCESS_DEINED";
	
	/* Asset Instance Version message constants */
	public static final String GET_NON_STATIC_PARAM_DEFS_NOT_FETCHED = "GET_NON_STATIC_PARAM_DEFS_NOT_FETCHED";
	public static final String DERIVED_ATTRIBUTE_NOT_FETCHED = "DERIVED_ATTRIBUTE_NOT_FETCHED";
	public static final String NON_ADMIN_QUERY_DERIVED_ATTRIBUTE_FOR_MACROS_NOT_GENERATED = "NON_ADMIN_QUERY_DERIVED_ATTRIBUTE_FOR_MACROS_NOT_GENERATED";
	public static final String ASSET_PARAM_DEF_NOT_FETCHED ="ASSET_PARAM_DEF_NOT_FETCHED";
	public static final String DATA_FROM_DB_FOR_MACROS_NOT_FOUND = "DATA_FROM_DB_FOR_MACROS_NOT_FOUND";
	public static final String DATA_FROM_DB_NOT_FOUND = "DATA_FROM_DB_NOT_FOUND";
	public static final String ASSET_INSTANCE_VERSIONS_BASIC_INFORMATION_NOT_FETCHED ="ASSET_INSTANCE_VERSIONS_BASIC_INFORMATION_NOT_FETCHED";
	public static final String ASSET_INSTANCE_VERSION_STATIC_INFORMATION_NOT_FETCHED ="ASSET_INSTANCE_VERSION_STATIC_INFORMATION_NOT_FETCHED";
	public static final String ADMIN_RIGHTS_NOT_FOUND_BY_USER_NAME ="ADMIN_RIGHTS_NOT_FOUND_BY_USER_NAME";
	public static final String ASSET_INSTANCE_VERSION_DETAILS_NOT_FETCHED = "ASSET_INSTANCE_VERSION_DETAILS_NOT_FETCHED";
	public static final String ASSET_INSTANCE_VERSIONS_NOT_FETCHED ="ASSET_INSTANCE_VERSIONS_NOT_FETCHED";
	public static final String ASSET_INSTANCE_VERSION_NAME_NOT_FETCHED = "ASSET_INSTANCE_VERSION_NAME_NOT_FETCHED";
	public static final String ASSET_INSTANCE_VERSION_NOT_CREATED ="ASSET_INSTANCE_VERSION_NOT_CREATED";	
	public static final String ASSET_INSTANCE_VERSION_NOT_UPDATED ="ASSET_INSTANCE_VERSION_NOT_UPDATED";
	public static final String ASSET_INSTANCE_VERSION_NOT_DELETED ="ASSET_INSTANCE_VERSION_NOT_DELETED";
	public static final String PARAMETER_VALUES_NOT_CREATED ="PARAMETER_VALUES_NOT_CREATED";
	public static final String ASSET_INST_PARAMS_NOT_CREATED ="ASSET_INST_PARAMS_NOT_CREATED";
	public static final String ASSET_PARAM_DEF_NOT_UPDATED ="ASSET_PARAM_DEF_NOT_UPDATED";
	public static final String POSSIBLE_VALUES_NOT_UPDATED ="POSSIBLE_VALUES_NOT_UPDATED";
	public static final String POSSIBLE_VALUES_CREATED ="POSSIBLE_VALUES_CREATED";
	public static final String GET_PARAMETER_VALUES_DETAILS_NOT_FETCHED ="GET_PARAMETER_VALUES_DETAILS_NOT_FETCHED";
	public static final String GET_PARAM_ID_FOR_ASSET_AND_PARAM_NAME_NOT_FETCHED = "GET_PARAM_ID_FOR_ASSET_AND_PARAM_NAME_NOT_FETCHED";
	public static final String TAXONOMY_NOT_UPDATED = "TAXONOMY_NOT_UPDATED";
	public static final String CHILD_NAMES_FOR_ASSET_INSTANCE_NOT_FETCHED = "CHILD_NAMES_FOR_ASSET_INSTANCE_NOT_FETCHED";
	public static final String GET_STATIC_PARAM_DEFS_NOT_FETCHED = "GET_STATIC_PARAM_DEFS_NOT_FETCHED";
    public static final String DERIVED_COMPUTATION_NOT_FETCHED = "DERIVED_COMPUTATION_NOT_FETCHED";
	public static final String DERIVED_ATTRIBUTE_DYNAMIC_QUERY_FOR_GUEST_NOT_GENERATED="DERIVED_ATTRIBUTE_DYNAMIC_QUERY_FOR_GUEST_NOT_GENERATED";
	public static final String DYNAMIC_QUERY_FOR_DERIVED_ATTRIBUTE_NOT_GENERATED="DYNAMIC_QUERY_FOR_DERIVED_ATTRIBUTE_NOT_GENERATED";
	public static final String DYNAMIC_QUERY_FOR_GROUP_ADMIN_DERIVED_ATTRIBUTE_NOT_GENERATED="DYNAMIC_QUERY_FOR_GROUP_ADMIN_DERIVED_ATTRIBUTE_NOT_GENERATED";
	public static final String DYNAMIC_QUERY_FOR_DERIVED_COMPUTATION_NOT_GENERATED="DYNAMIC_QUERY_FOR_DERIVED_COMPUTATION_NOT_GENERATED";
	public static final String LOCKTIME_NOT_FOUND = "LOCKTIME_NOT_FOUND";
	public static final String UNABLE_TO_UPDATE_ASSET_INSTANCE_VERSION = "UNABLE_TO_UPDATE_ASSET_INSTANCE_VERSION";
	public static final String PARAMETER_VALUES_NOT_UPDATED = "PARAMETER_VALUES_NOT_UPDATED";
	public static final String TAXONOMY_HIERARCHY_NOT_FOUND = "TAXONOMY_HIERARCHY_NOT_FOUND";
	public static final String ASSET_DATA_NOT_PROVIDED = "ASSET_DATA_NOT_PROVIDED";
	
	/* Custom images - sql Constants */
	public static final String RET_LOGIN_COLOR_CONFIG = "RET_LOGIN_COLOR_CONFIG";
	public static final String UPDATE_LOGIN_COLOR_CONFIG = "UPDATE_LOGIN_COLOR_CONFIG";
	public static final String INSERT_LOGIN_COLOR_CONFIG = "INSERT_LOGIN_COLOR_CONFIG";
	
	/* Custom images - Constants */
	public static final String LOGIN_FONT_FRAME_COLOR_CONFIGURED = "LOGIN_FONT_FRAME_COLOR_CONFIGURED";
	public static final String LOGIN_LOGO_UPDATED = "LOGIN_LOGO_UPDATED";
	public static final String BACKGROUND_IMAGE_UPDATED = "BACKGROUND_IMAGE_UPDATED";
	public static final String HEADER_LOGO_UPDATED = "HEADER_LOGO_UPDATED";
	public static final String FAVICON_LOGO_UPDATED = "FAVICON_LOGO_UPDATED";
	public static final String LOGIN_FONT_FRAME_COLOR_FETCHED = "LOGIN_FONT_FRAME_COLOR_FETCHED";
	public static final String CUSTOM_IMAGES_UPDATED_SUCCESSFULLY = "CUSTOM_IMAGES_UPDATED_SUCCESSFULLY";
	
	/* Custom images - message constants */
	public static final String FAILED_TO_UPDATE_LOGIN_FONT_FRAME_COLOR = "FAILED_TO_UPDATE_LOGIN_FONT_FRAME_COLOR";
	public static final String LOGIN_COLOR_CONFIG_NOT_FOUND = "LOGIN_COLOR_CONFIG_NOT_FOUND";
	

	/*Asset instance attributes*/
	public static final String GET_ALL_ASSET_INSTANCE_ATTRIBUTES = "GET_ALL_ASSET_INSTANCE_ATTRIBUTES";
	public static final String GET_ASSET_PARAMS_FOR_ASSET = "GET_ASSET_PARAMS_FOR_ASSET";
	public static final String GET_ASSET_INSTANCE_VERSIONS_EXPORT = "GET_ASSET_INSTANCE_VERSIONS_EXPORT";
	public static final String GET_ASSET_PARAMS_EXPORT = "GET_ASSET_PARAMS_EXPORT";
	public static final String GET_ASSET_PARAM_VALUES = "GET_ASSET_PARAM_VALUES";
	public static final String GET_ASSET_PARAM_DETAILS = "GET_ASSET_PARAM_DETAILS";
	
	/* Asset instance */
	public static final String GET_ASSET_PARAM_DEF_BY_DERIVED_ATTRIBUTE_IS_NOT_NULL="GET_ASSET_PARAM_DEF_BY_DERIVED_ATTRIBUTE_IS_NOT_NULL";
	public static final String UPDATE_DERIVED_ATTRIBUTE_COMPUTATION_RULE_RELATION_NAME = "UPDATE_DERIVED_ATTRIBUTE_COMPUTATION_RULE_RELATION_NAME";
	public static final String ASSET_PARAMETERS_FETCHED = "ASSET_PARAMETERS_FETCHED";
	
	/*recent activity sql constants*/
	public static final String RET_RECENTACTIVITY_DETAILS_FOR_GUEST = "RET_RECENTACTIVITY_DETAILS_FOR_GUEST";
	public static final String RET_RECENTACTIVITY_DETAILS_FOR_ADMIN = "RET_RECENTACTIVITY_DETAILS_FOR_ADMIN";
	public static final String RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN = "RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN";
	public static final String RET_RECENTACTIVITY_FOR_GUEST = "RET_RECENTACTIVITY_FOR_GUEST";
	public static final String RET_RECENTACTIVITY_FOR_NON_ADMIN = "RET_RECENTACTIVITY_FOR_NON_ADMIN";
	public static final String RET_RECENTACTIVITY_FOR_ADMIN = "RET_RECENTACTIVITY_FOR_ADMIN";
	public static final String RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN_FOR_LOGGED_IN_USER = "RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN_FOR_LOGGED_IN_USER";
	public static final String RET_RECENTACTIVITY_FOR_NON_ADMIN_FOR_LOGGED_IN_USER = "RET_RECENTACTIVITY_FOR_NON_ADMIN_FOR_LOGGED_IN_USER";
	
	/*recent activity message constants*/
	public static final String RECENT_ACTIVITY_DETAILS_NOT_FOUND = "RECENT_ACTIVITY_DETAILS_NOT_FOUND";
	
	/*recent activity constants*/
	public static final String RECENT_ACTIVITY_DATA_FETCHED = "RECENT_ACTIVITY_DATA_FETCHED";
	
	/*recent activity Export sql constants*/
	public static final String RET_RECENTACTIVITY_DETAILS_FOR_GUEST_EXPORT = "RET_RECENTACTIVITY_DETAILS_FOR_GUEST_EXPORT";
	public static final String RET_RECENTACTIVITY_DETAILS_FOR_ADMIN_EXPORT = "RET_RECENTACTIVITY_DETAILS_FOR_ADMIN_EXPORT";
	public static final String RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN_EXPORT = "RET_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN_EXPORT";
	public static final String RET_RECENTACTIVITY_FOR_GUEST_EXPORT = "RET_RECENTACTIVITY_FOR_GUEST_EXPORT";
	public static final String RET_RECENTACTIVITY_FOR_NON_ADMIN_EXPORT = "RET_RECENTACTIVITY_FOR_NON_ADMIN_EXPORT";
	public static final String RET_RECENTACTIVITY_FOR_ADMIN_EXPORT = "RET_RECENTACTIVITY_FOR_ADMIN_EXPORT";

	/* Assets - queries */
	public static final String ADD_ASSET = "ADD_ASSET";
	public static final String GET_ALL_ASSETS = "GET_ALL_ASSETS";
	public static final String UPDATE_ASSET = "UPDATE_ASSET";
	public static final String DELETE_ASSET = "DELETE_ASSET";
	public static final String GET_ALL_SUBSCRIPTIONS_BY_ASSET = "GET_ALL_SUBSCRIPTIONS_BY_ASSET";
	public static final String GET_ASSETS_BY_ASSET_ID = "GET_ASSETS_BY_ASSET_ID";
	public static final String GET_ASSETS_BY_ASSET_NAME = "GET_ASSETS_BY_ASSET_NAME";
	public static final String GET_ALL_ASSET_NAMES = "GET_ALL_ASSET_NAMES";
	public static final String GET_ALL_ASSET_NAMES_FOR_GUEST = "GET_ALL_ASSET_NAMES_FOR_GUEST";
	public static final String GET_ADD_ACCESS_OF_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FOR_ADMIN = "GET_ADD_ACCESS_OF_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FOR_ADMIN";
	public static final String GET_ADD_ACCESS_OF_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FOR_NON_ADMIN = "GET_ADD_ACCESS_OF_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FOR_NON_ADMIN";
	public static final String RET_ALL_ASSET_INST_VERSIONS_FOR_ASSET = "RET_ALL_ASSET_INST_VERSIONS_FOR_ASSET";
	public static final String GET_ALL_FILTERED_SUBSCRIBED_ASSETS = "GET_ALL_FILTERED_SUBSCRIBED_ASSETS";
	public static final String RET_PARAM_VALUES_FOR_ASSET = "RET_PARAM_VALUES_FOR_ASSET";
	
	/* Assets - constants */
	public static final String ASSET_CREATED = "ASSET_CREATED";
	public static final String ASSET_UPDATED = "ASSET_UPDATED";
	public static final String ASSET_DELETED = "ASSET_DELETED";
	public static final String ALL_ASSETS_FETCHED = "ALL_ASSETS_FETCHED";
	public static final String ASSET_NAME_EXIST = "ASSET_NAME_EXIST";
	public static final String ASSET_CATEGORY_CAN_NOT_BE_NULL = "ASSET_CATEGORY_CAN_NOT_BE_NULL";
	public static final String ASSET_CATEGORY_PARAMETER_CAN_NOT_BE_NULL = "ASSET_CATEGORY_PARAMETER_CAN_NOT_BE_NULL";
	public static final String ASSET_PARAMETER_CAN_NOT_CREATED = "ASSET_PARAMETER_CAN_NOT_CREATED";
	public static final String ASSET_CATEGORY_CAN_NOT_CREATED = "ASSET_CATEGORY_CAN_NOT_CREATED";
	public static final String ADD_ACCESS_FOR_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FETCHED ="ADD_ACCESS_FOR_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FETCHED";
	public static final String DEST_ASSET_ACCESS_FOR_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FETCHED ="DEST_ASSET_ACCESS_FOR_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FETCHED";
	
	/* Assets - Messages */
	public static final String ASSET_NOT_CREATED = "ASSET_NOT_CREATED";
	public static final String ASSETS_NOT_FOUND = "ASSETS_NOT_FOUND";
	public static final String ASSET_NOT_UPDATED = "ASSET_NOT_UPDATED";
	public static final String ASSET_NOT_DELETED = "ASSET_NOT_DELETED";
	public static final String PARAM_ID_NOT_FOUND = "PARAM_ID_NOT_FOUND";
	public static final String REPOPRO_NEW_ASSET_TYPE_CREATED = "REPOPRO_NEW_ASSET_TYPE_CREATED"; 
	public static final String REPOPRO_ASSET_TYPE_DETAILS_UPDATED = "REPOPRO_ASSET_TYPE_DETAILS_UPDATED";
	public static final String REPOPRO_ASSET_TYPE_DELETED = "REPOPRO_ASSET_TYPE_DELETED";
	public static final String ADD_ACCESS_FOR_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_NOT_FOUND ="ADD_ACCESS_FOR_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_NOT_FOUND";
	
	/*Asset management sql constants*/
	public static final String GET_CATEGORYS_BY_ASSET_ID = "GET_CATEGORYS_BY_ASSET_ID";
	public static final String GET_ALL_DERIVED_ATTRIBUTES = "GET_ALL_DERIVED_ATTRIBUTES";
	public static final String GET_PARAMETERS_BY_ASSET_CATEGORY_ID = "GET_PARAMETERS_BY_ASSET_CATEGORY_ID";
	public static final String GET_ALL_ASSIGNED_TAXONOMIES_FOR_ASSET = "GET_ALL_ASSIGNED_TAXONOMIES_FOR_ASSET";
	public static final String DELETE_PARAMETER = "DELETE_PARAMETER";
	public static final String DELETE_ASSET_CATEGORY_DEF = "DELETE_ASSET_CATEGORY_DEF";
	public static final String GET_MAPPED_ASSET_PARAM_DEF_BY_ASSET_ID = "GET_MAPPED_ASSET_PARAM_DEF_BY_ASSET_ID";
	public static final String GET_CHECKED_GROUP_DETAILS_BY_ASSET_ID = "GET_CHECKED_GROUP_DETAILS_BY_ASSET_ID";
	public static final String GET_ASSET_ACCESS_GROUPS_BY_ASSET_ID = "GET_ASSET_ACCESS_GROUPS_BY_ASSET_ID";
	public static final String UPDATE_ASSET_PARAMETER_DEF = "UPDATE_ASSET_PARAMETER_DEF";
	public static final String UPDATE_ASSET_PARAMETER_DEFINITION = "UPDATE_ASSET_PARAMETER_DEFINITION";
	public static final String ADD_CATEGORY_DEFINITION = "ADD_CATEGORY_DEFINITION";
	public static final String ADD_PARAMETER_DEFINITION = "ADD_PARAMETER_DEFINITION";
	public static final String UPDATE_CATEGORY_DETAILS = "UPDATE_CATEGORY_DETAILS";
	public static final String UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE = "UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE";
	public static final String DELETE_CATEGORY_WISE_ACCESS_FOR_GROUP_BY_CATEGORY_ID = "DELETE_CATEGORY_WISE_ACCESS_FOR_GROUP_BY_CATEGORY_ID";
	public static final String ADD_CATEGORY_WISE_ACCESS_FOR_GROUPS_BY_CATEGORY_ID = "ADD_CATEGORY_WISE_ACCESS_FOR_GROUPS_BY_CATEGORY_ID";
	public static final String ADD_ASSET_CATEGORY_DEF = "ADD_ASSET_CATEGORY_DEF";
	public static final String UPDATE_ASSET_CATEGORY_DEF = "UPDATE_ASSET_CATEGORY_DEF";
	public static final String ADD_PARAMETER = "ADD_PARAMETER";
	public static final String GET_ASSET_PARAM_DEF_BY_ASSET_PARAM_ID = "GET_ASSET_PARAM_DEF_BY_ASSET_PARAM_ID";
	public static final String DELETE_PARAMETER_BY_PARAMETER_ID = "DELETE_PARAMETER_BY_PARAMETER_ID";
	public static final String UPDATE_ASSET_INST_PARAM = "UPDATE_ASSET_INST_PARAM";
	public static final String GET_ASSET_INST_PARAM_BY_PARAM_ID_AND_VERSION_ID ="GET_ASSET_INST_PARAM_BY_PARAM_ID_AND_VERSION_ID";
	public static final String GET_ASSET_CATEGORY_ACCESS_ASSET_CATEGORY_ID = "GET_ASSET_CATEGORY_ACCESS_ASSET_CATEGORY_ID";
	public static final String GET_CATEGORY_ID_BY_CAT_NAME_AND_ASSET_ID = "GET_CATEGORY_ID_BY_CAT_NAME_AND_ASSET_ID";
	public static final String UPDATE_ASSET_PARAM_DEF_DRAGGED_DISP_POSITION = "UPDATE_ASSET_PARAM_DEF_DRAGGED_DISP_POSITION";
	public static final String GET_ASSET_CATEGORY_EDIT_ACCESS_BY_CATEGORYID_AND_GROUPID = "GET_ASSET_CATEGORY_EDIT_ACCESS_BY_CATEGORYID_AND_GROUPID";
	public static final String GET_ASSET_CATEGORY_EDIT_ACCESS_BY_CATEGORYID_AND_GROUPID_IN_AIVPAGE = "GET_ASSET_CATEGORY_EDIT_ACCESS_BY_CATEGORYID_AND_GROUPID_IN_AIVPAGE";
	
	/*Asset management message constants*/
	public static final String ASSET_DEF_NOT_SELECTED = "ASSET_DEF_NOT_SELECTED";
	public static final String GET_CATEGORY_BY_ASSET__ID_NOT_SELECTED = "GET_CATEGORY_BY_ASSET__ID_NOT_SELECTED";
	public static final String DERIVED_ATTRIBUTES_NOT_SELECTED = "DERIVED_ATTRIBUTES_NOT_SELECTED";
	public static final String NO_ASSET_MAPPED_PARAMETERS_FOR_ASSET = "NO_ASSET_MAPPED_PARAMETERS_FOR_ASSET";
	public static final String PARAMETER_NOT_DELETED = "PARAMETER_NOT_DELETED";
	public static final String ASSET_CATEGORY_DEF_NOT_DELETED = "ASSET_CATEGORY_DEF_NOT_DELETED";
	public static final String GROUP_ACCESS_ASSET_NOT_FOUND = "GROUP_ACCESS_ASSET_NOT_FOUND";
	public static final String TAXONOMIES_NOT_FETCHED_BY_ASSET_ID = "TAXONOMIES_NOT_FETCHED_BY_ASSET_ID";
	public static final String CATEGORY_NOT_INSERTED = "CATEGORY_NOT_INSERTED";
	public static final String PARAMETER_NOT_INSERTED = "PARAMETER_NOT_INSERTED";
	public static final String ASSET_CATEGORY_NOT_UPDATED = "ASSET_CATEGORY_NOT_UPDATED";
	public static final String ASSET_PARAMETER_NOT_UPDATED = "ASSET_PARAMETER_NOT_UPDATED";
	public static final String UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE_NOT_UPDATED = "UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE_NOT_UPDATED";
	public static final String CATEGORY_WISE_ACCESS_NOT_ADDED = "CATEGORY_WISE_ACCESS_NOT_ADDED";
	public static final String ASSET_CATEGORY_DEF_NOT_ADDED = "ASSET_CATEGORY_DEF_NOT_ADDED";
	public static final String ASSET_CATEGORY_DEF_NOT_UPDATED = "ASSET_CATEGORY_DEF_NOT_UPDATED";
	public static final String ASSET_PARAM_DEF_NOT_CREATED = "ASSET_PARAM_DEF_NOT_CREATED";
	public static final String GET_ASSET_PARAM_DEF_BY_ASSET_PARAM_ID_NOT_SELECTED="GET_ASSET_PARAM_DEF_BY_ASSET_PARAM_ID_NOT_SELECTED";
	public static final String ASSET_PARAM_DEF_NOT_DELETED = "ASSET_PARAM_DEF_NOT_DELETED";
	public static final String GET_ASSET_INST_PARAM_BY_PARAM_ID_AND_VERSION_ID_NOT_FETCHED ="GET_ASSET_INST_PARAM_BY_PARAM_ID_AND_VERSION_ID_NOT_FETCHED";
	public static final String UPDATE_ASSET_INST_PARAM_NOT_UPDATED ="UPDATE_ASSET_INST_PARAM_NOT_UPDATED";
	public static final String GET_ASSET_CATEGORY_ACCESS_ASSET_CATEGORY_ID_NOT_FOUND = "GET_ASSET_CATEGORY_ACCESS_ASSET_CATEGORY_ID_NOT_FOUND";
	public static final String GET_CATEGORY_ID_BY_CAT_NAME_AND_ASSET_ID_NOT_FETCHED = "GET_CATEGORY_ID_BY_CAT_NAME_AND_ASSET_ID_NOT_FETCHED";
	public static final String UPDATE_ASSET_PARAM_DEF_DRAGGED_NOT_UPDATED = "UPDATE_ASSET_PARAM_DEF_DRAGGED_NOT_UPDATED";
	public static final String ASSET_INSTANCE_PARAMETERS_NOT_FETCHED = "NO_ASSET_INSTANCE_PARAMETERS_TO_DISPLAY";
	
	/*import profile message constants*/
	public static final String REPOPRO_IMPORT_USER_FAILURE = "REPOPRO_IMPORT_USER_FAILURE";
	public static final String REPOPRO_PROFILE_CREATED = "REPOPRO_PROFILE_CREATED";
	public static final String REPOPRO_PROFILE_UPDATED = "REPOPRO_PROFILE_UPDATED";
	public static final String REPOPRO_USER_IMPORT_SUCCESS = "REPOPRO_USER_IMPORT_SUCCESS";
	
	/*import profile constants*/
	public static final String IMPORT_DONE = "IMPORT_DONE";
	

	/*mail - Tempaltes*/
	public static final String EMAIL_HDR = "EMAIL_HDR";
	public static final String EMAIL_FTR = "EMAIL_FTR";
	public static final String EMAIL_NOTE = "EMAIL_NOTE";
	public static final String RET_MAIL_TEMPLATE_TEXT_NAME = "RET_MAIL_TEMPLATE_TEXT_NAME";
	public static final String REPOPRO_PROFILE_UPDATE = "REPOPRO_PROFILE_UPDATE";
	public static final String RET_MAIL_CONFIG_DATA = "RET_MAIL_CONFIG_DATA";
	public static final String REPOPRO_PASSWORD_RESET = "REPOPRO_PASSWORD_RESET";
	
	
	/*Asset instance relations*/
	public static final String GET_ALL_ASSET_INSTANCE_RELATIONSHIPS = "GET_ALL_ASSET_INSTANCE_RELATIONSHIPS";
	public static final String GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_BROWSE_GRID_NON_ADMIN = "GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_BROWSE_GRID_NON_ADMIN";
	
	public static final String GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER = "GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER";
	public static final String GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER_NON_ADMIN = "GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER_NON_ADMIN";
	
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN_EXPORT = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN_EXPORT";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST_EXPORT = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST_EXPORT";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN_EXPORT = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN_EXPORT";
	
	public static final String UPDATE_ASSET_INSTANCE_PUBLIC_ACCESS = "UPDATE_ASSET_INSTANCE_PUBLIC_ACCESS";
	public static final String GET_ASSET_INSTANCE_PUBLIC_ACCESS = "GET_ASSET_INSTANCE_PUBLIC_ACCESS";
	public static final String PUBLIC_ACCESS_TRUE = "TRUE";
	public static final String PUBLIC_ACCESS_FALSE = "FALSE";
	public static final String INSERT_INTO_USER_ASSET_INSTANCE_SUBSCRIPTION = "INSERT_INTO_USER_ASSET_INSTANCE_SUBSCRIPTION";
	public static final String DELETE_USER_ASSET_INSTANCE_SUBSCRIPTION = "DELETE_USER_ASSET_INSTANCE_SUBSCRIPTION";
	public static final String GET_USER_ASSET_INSTANCE_SUBSCRIPTION = "GET_USER_ASSET_INSTANCE_SUBSCRIPTION";
	public static final String SUBSCRIPTION_EXSISTS = "TRUE";
	public static final String SUBSCRIPTION_DOESNT_EXSISTS = "FALSE";
	
	/*asset Possible values*/
	public static final String GET_POSSIBLE_VALUES = "GET_POSSIBLE_VALUES";
	public static final String GET_POSSIBLE_VALUES_DATA_FETCHED = "GET_POSSIBLE_VALUES_DATA_FETCHED";
	public static final String GET_POSSIBLE_VALUES_NOT_FOUND = "GET_POSSIBLE_VALUES_NOT_FOUND";
	
	public static final String NO_ASSET_PARAM_DEF_IN_ASSET_PARAM_NAME = "NO_ASSET_PARAM_DEF_IN_ASSET_PARAM_NAME";
	public static final String NO_CATEGORIES_BY_FOR_ASSET_ID = "NO_CATEGORIES_BY_FOR_ASSET_ID";
	public static final String GET_CATEGORIES_BY_ASSET_ID = "GET_CATEGORIES_BY_ASSET_ID";
	
	/*Realtionship sql*/
	
	public static final String RET_RELATIONSHIPS_BY_SAME_ASSETIDS_FOR_ADMIN = "RET_RELATIONSHIPS_BY_SAME_ASSETIDS_FOR_ADMIN";
	public static final String RET_RELATIONSHIPS_BY_ASSETID_FOR_ADMIN = "RET_RELATIONSHIPS_BY_ASSETID_FOR_ADMIN";
	public static final String RET_RELATIONSHIPS_BY_SAME_ASSETIDS_FOR_NON_ADMIN = "RET_RELATIONSHIPS_BY_SAME_ASSETIDS_FOR_NON_ADMIN";
	public static final String RET_RELATIONSHIPS_BY_ASSETID_FOR_NON_ADMIN = "RET_RELATIONSHIPS_BY_ASSETID_FOR_NON_ADMIN";
	
    /*aiv sql constants*/
	public static final String RET_AIV_ACCESS_RIGHT = "RET_AIV_ACCESS_RIGHT";
	
	/*aiv message constants*/
	public static final String GROUP_ACCESS_ASSETINSTANCE_NOT_FOUND = "GROUP_ACCESS_ASSETINSTANCE_NOT_FOUND";
	public static final String DERIVED_COMPUTATION_VALIDATION_SUCCESS = "DERIVED_COMPUTATION_VALIDATION_SUCCESS";
	public static final String DERIVED_ATTRIBUTE_VALIDATION_SUCCESS = "DERIVED_ATTRIBUTE_VALIDATION_SUCCESS";
	
	/* Contact Us */
	public static final String MAIL_SENT_SUCCESS = "MAIL_SENT_SUCCESS";
	public static final String REPOPRO_CONTACT_US = "REPOPRO_CONTACT_US";
	public static final String UPDATE_POSSIBLE_VALUES = "UPDATE_POSSIBLE_VALUES";
	public static final String INSERT_POSSIBLE_VALUES = "INSERT_POSSIBLE_VALUES";
	public static final String DELETE_POSSIBLE_VALUES = "DELETE_POSSIBLE_VALUES";
	public static final String POSSIBLE_VALUES_NOT_DELETED = "POSSIBLE_VALUES_NOT_DELETED";
	public static final String GET_POSSIBLE_VALUES_BY_PARAM_ID = "GET_POSSIBLE_VALUES_BY_PARAM_ID";
	public static final String GET_POSSIBLE_VALUES_BY_PARAM_ID_NOT_SELECTED = "GET_POSSIBLE_VALUES_BY_PARAM_ID_NOT_SELECTED";
	public static final String SELECT_FILENAME_BY_ASSET_ID = "SELECT_FILENAME_BY_ASSET_ID";
	public static final String NO_FILE_NAME_SELECTED = "NO_FILE_NAME_SELECTED";
	public static final String GetCategoriesAndParamsByAssetId = "GetCategoriesAndParamsByAssetId";
	public static final String NOT_GetCategoriesAndParamsByAssetId = "NOT_GetCategoriesAndParamsByAssetId";

	public static final String GET_ASSET_LEVEL_ADD_ACCESS_FOR_LOGIN_USER = "GET_ASSET_LEVEL_ADD_ACCESS_FOR_LOGIN_USER";
	public static final String ASSET_GUEST_ACCESS_NOT_FOUND = "ASSET_GUEST_ACCESS_NOT_FOUND";
	public static final String ASSET_GUEST_ACCESS_FETCHED = "ASSET_GUEST_ACCESS_FETCHED";
	
	/*Full import sql constants*/
	public static final String GET_PARAMS_BY_ASSET_NAME = "GET_PARAMS_BY_ASSET_NAME";
	public static final String GET_ASSET_INST_VER_BY_ASSET_NAME  = "GET_ASSET_INST_VER_BY_ASSET_NAME";
	public static final String RET_POSSIBLE_VALUES_FOR_PARAMS = "RET_POSSIBLE_VALUES_FOR_PARAMS";
	public static final String RET_GLOBAL_SETTINGS_BY_SETTING_NAME_FOR_LOCK = "RET_GLOBAL_SETTINGS_BY_SETTING_NAME_FOR_LOCK";
	public static final String GET_PARAMETER_VALUES_FOR_ASSET_INST = "GET_PARAMETER_VALUES_FOR_ASSET_INST";
	public static final String ADD_TAG_DATA_FOR_IMPORT = "ADD_TAG_DATA_FOR_IMPORT";
	public static final String DELETE_TAGS_DATA_IMPORT = "DELETE_TAGS_DATA_IMPORT";
	
	/*Full import message constants*/
	public static final String PARAMETER_NOT_FOUND = "PARAMETER_NOT_FOUND";
	public static final String REPOPRO_IMPORT_XLSX_FAILED = "REPOPRO_IMPORT_XLSX_FAILED";
	public static final String REPOPRO_IMPORT_XLSX_SUCCESS = "REPOPRO_IMPORT_XLSX_SUCCESS";
	public static final String GLOBAL_UPLOAD_SUCCESS_MSG = "GLOBAL_UPLOAD_SUCCESS_MSG";
	public static final String GET_COUNT_OF_LOCKED_ASSET_INSTANCE_VERSION_ID = "GET_COUNT_OF_LOCKED_ASSET_INSTANCE_VERSION_ID";
	public static final String DOWNLOAD_LOCATION_FETCHED = "DOWNLOAD_LOCATION_FETCHED";
	
	/*Export*/
	public static final String GET_ALL_NONSTATIC_PARAM_DETAILS_EXPORT = "GET_ALL_NONSTATIC_PARAM_DETAILS_EXPORT";
	
	/*Relationship sql*/
	public static final String GET_ASSET_RELATION_SHIP_DEF_BY_ASSET_RELATION_SHIP_NAME = "GET_ASSET_RELATION_SHIP_DEF_BY_ASSET_RELATION_SHIP_NAME";
	
	public static final String GET_FILTER_SEARCH_ID_BY_SEARCH_NAME = "GET_FILTER_SEARCH_ID_BY_SEARCH_NAME";
	public static final String GET_ASSET_PARAM_ACCESS = "GET_ASSET_PARAM_ACCESS";
	public static final String GET_ASSET_PARAM_ID_BY_NAME = "GET_ASSET_PARAM_ID_BY_NAME";
	public static final String ASSET_INSTANCE_VERSION_NOT_FOUND = "ASSET_INSTANCE_VERSION_NOT_FOUND";
	public static final String RELATIONSHIP_NOT_FOUND = "RELATIONSHIP_NOT_FOUND";
	public static final String GET_ASSET_PARAM_ACCESS_FOR_GUEST = "GET_ASSET_PARAM_ACCESS_FOR_GUEST";
	public static final String TAXONOMY_NOT_PRESENT_TO_ADD = "TAXONOMY_NOT_PRESENT_TO_ADD";
	public static final String USER_NOT_AUTHENTICATED = "USER_NOT_AUTHENTICATED";
	public static final String NOT_AUTHENTICATED = "NOT_AUTHENTICATED";
	public static final String NOT_AUTHORIZED = "NOT_AUTHORIZED";
	
	
	/*LDAP*/
	public static final String LDAP_DETAILS_FETCHED = "LDAP_DETAILS_FETCHED";
	public static final String LDAP_DETAILS_NOT_FOUND = "LDAP_DETAILS_NOT_FOUND";
	
	public static final String GET_PARAMETERS_FOR_ASSET_AND_CATEGORY = "GET_PARAMETERS_FOR_ASSET_AND_CATEGORY";
	public static final String GET_PARAM_DETAILS_BY_PARAM_ID = "GET_PARAM_DETAILS_BY_PARAM_ID";
	public static final String DUPLICATE_ASSET_INSTANCE_RELATIONSHIP_DATA = "DUPLICATE_ASSET_INSTANCE_RELATIONSHIP_DATA";
	public static final String GET_TAXONOMY_NAME_BY_PARENT_ID = "GET_TAXONOMY_NAME_BY_PARENT_ID";
	
	public static final String GET_ALL_ASSET_INSTANCES_WITH_LATEST_VERSIONS = "GET_ALL_ASSET_INSTANCES_WITH_LATEST_VERSIONS";
	public static final String GET_SIBLINGS_OF_CHILD_ASSET_INSTANCE = "GET_SIBLINGS_OF_CHILD_ASSET_INSTANCE";
	
	/*Asset Category Access*/
	public static final String INVALID_OPERATOR = "INVALID_OPERATOR";
	public static final String INVALID_LOGICAL_OPERATOR = "INVALID_LOGICAL_OPERATOR";
	public static final String INVALID_GROUP_NAME = "INVALID_GROUP_NAME";
	public static final String GET_ASSET_CATEGORY_ACCESS_FOR_GUEST = "GET_ASSET_CATEGORY_ACCESS_FOR_GUEST";
	public static final String GET_ASSET_CATEGORY_ACCESS = "GET_ASSET_CATEGORY_ACCESS";
	public static final String INVALID_QUERY_PARAMETER_NAME = "INVALID_QUERY_PARAMETER_NAME";
	public static final String RELATIONSHIP_DATA_NOT_PROVIDED = "RELATIONSHIP_DATA_NOT_PROVIDED";
	public static final String PUBLIC_ACCESS_BLOCKED_AT_ASSET = "PUBLIC_ACCESS_BLOCKED_AT_ASSET";
	public static final String INCORRECT_FORMAT = "INCORRECT_FORMAT";
	public static final String INVALID_DATA = "INVALID_DATA";
	public static final String MAX_LENGTH_EXCEEDED = "MAX_LENGTH_EXCEEDED";
	public static final String PARAM_LIST_TYPE_INVALID = "PARAM_LIST_TYPE_INVALID";
	public static final String INVALID_PARAM_NAME = "INVALID_PARAM_NAME";
	public static final String INVALID_PARAM_TYPE = "INVALID_PARAM_TYPE";
	public static final String INVALID_TAXONOMY_NAME = "INVALID_TAXONOMY_NAME";
	public static final String RET_ASSET_INST = "RET_ASSET_INST";
	
	
	public static final String ASSET_PARAM_NAME_ALREADY_EXISTS = "DUPLICATE ASSET PARAM NAME";
	public static final String ASSET_CATEGORY_NAME_ALREADY_EXISTS = "DUPLICATE ASSET CATEGORY NAME";
	
	public static final String SPECIAL_CHARACTERS_NOT_ALLOWED = "SPECIAL_CHARACTERS_NOT_ALLOWED";
	public static final String SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_TAGS = "SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_TAGS";
	public static final String ENABLE_CONCURRENT_EDIT_LOCK = "ENABLE_CONCURRENT_EDIT_LOCK";
	public static final String ASSET_INSTANCE_VERSION_ALREADY_LOCKED = "ASSET_INSTANCE_VERSION_ALREADY_LOCKED";
	public static final String ASSET_INSTANCE_VERSION_ALREADY_UNLOCKED = "ASSET_INSTANCE_VERSION_ALREADY_UNLOCKED";
	public static final String ASSET_INSTANCE_DESC_UPDATED_ASSET_INSTANCE_VERSION_UNLOCKED = "ASSET_INSTANCE_DESC_UPDATED_AND_ASSET_INSTANCE_VERSION_UNLOCKED";
	public static final String ASSET_INSTANCE_PROPERTIES_UPDATED_ASSET_INSTANCE_VERSION_UNLOCKED = "ASSET_INSTANCE_PROPERTIES_UPDATED_ASSET_INSTANCE_VERSION_UNLOCKED";
	public static final String RELATIONSHIPS_UPDATED_ASSET_INSTANCE_VERSION_UNLOCKED = "RELATIONSHIPS_UPDATED_ASSET_INSTANCE_VERSION_UNLOCKED";
	public static final String TAXONOMY_ASSIGNED_SUCCESSFULLY_ASSET_INSTANCE_VERSION_UNLOCKED = "TAXONOMY_ASSIGNED_SUCCESSFULLY_ASSET_INSTANCE_VERSION_UNLOCKED";
	public static final String TAGS_SAVED_ASSET_INSTANCE_VERSION_UNLOCKED = "TAGS_SAVED_AND_ASSET_INSTANCE_VERSION_UNLOCKED";
	public static final String ASSET_INSTANCE_VERSION_UPDATED_AND_UNLOCKED = "ASSET_INSTANCE_VERSION_UPDATED_AND_UNLOCKED";
	public static final String ASSET_INSTANCE_DATA_UPDATED = "ASSET_INSTANCE_DATA_UPDATED";
	public static final String INVALID_PARAM2_DATA = "INVALID_PARAM2_DATA";
	public static final String SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_RELATIONSHIP_NAME = "SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_RELATIONSHIP_NAME";
	public static final String SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_TAXONOMY_NAME = "SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_TAXONOMY_NAME";
	public static final String NO_CHILD_ASSET_INSTANCE_NAME_AVAILABLE = "NO_CHILD_ASSET_INSTANCE_NAME_AVAILABLE";
	public static final String INVALID_EMAIL_ID = "INVALID_EMAIL_ID";
	public static final String INVALID_PASSWORD = "INVALID_PASSWORD";
	public static final String FAVOURITES_ALREADY_EXISTS = "FAVOURITES_ALREADY_EXISTS";
	public static final String DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED = "DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED";
	public static final String TAXONOMY_NOT_PRESENT_TO_DELETE = "TAXONOMY_NOT_PRESENT_TO_DELETE";
	public static final String TAXONOMY_NOT_PRESENT_TO_UPDATE = "TAXONOMY_NOT_PRESENT_TO_UPDATE";
	public static final String UNLOCK_ALL_ASSET_INSTANCE_VERSIONS = "UNLOCK_ALL_ASSET_INSTANCE_VERSIONS";
	public static final String UNABLE_TO_UNLOCK_ALL_ASSET_INSTANCE_VERSIONS = "UNABLE_TO_UNLOCK_ALL_ASSET_INSTANCE_VERSIONS";
	public static final String SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_SEARCH_NAME = "SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_SEARCH_NAME";
	public static final String INVALID_PARAM_VALUE = "INVALID_PARAM_VALUE";

	/*filter for browse grid sql queries*/
	/*Non static parameter*/
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_ADMIN_FOR_FILTER = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_ADMIN_FOR_FILTER";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GUEST_FOR_FILTER = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GUEST_FOR_FILTER";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_ADMIN_FOR_FILTER = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_ADMIN_FOR_FILTER";
	public static final String 	GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_NORMAL_USER_FOR_FILTER = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_NORMAL_USER_FOR_FILTER";

	/*Count for filter browse grid*/
	public static final String GET_COUNT_ASSET_INSTANCE_FOR_GRID_FOR_ADMIN_FOR_FILTER = "GET_COUNT_ASSET_INSTANCE_FOR_GRID_FOR_ADMIN_FOR_FILTER";
	public static final String GET_COUNT_ASSET_INSTANCE_FOR_GRID_FOR_GUEST_FOR_FILTER = "GET_COUNT_ASSET_INSTANCE_FOR_GRID_FOR_GUEST_FOR_FILTER";
	public static final String GET_COUNT_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_ADMIN_FOR_FILTER = "GET_COUNT_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_ADMIN_FOR_FILTER";
	public static final String 	GET_COUNT_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_NORMAL_USER_FOR_FILTER = "GET_COUNT_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_NORMAL_USER_FOR_FILTER";

	/*Static parameter*/
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_STATIC_PARAM_INFORMATION_BY_ASSET_NAME_ADMIN_FOR_FILTER = "GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_STATIC_PARAM_INFORMATION_BY_ASSET_NAME_ADMIN_FOR_FILTER";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST_FOR_FILTER = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST_FOR_FILTER";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN_FOR_FILTER = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN_FOR_FILTER";

	/*without parameter*/
	public static final String  GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN_FOR_FILTER = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_ADMIN_FOR_FILTER";

	
	public static final String ASSET_INSTANCE_VERSION_ID_TAGS_FETCHED = "ASSET_INSTANCE_VERSION_ID_TAGS_FETCHED";
	
	
	/*Filter - recent activity*/
	public static final String FILTER_RECENTACTIVITY_DETAILS_FOR_GUEST = "FILTER_RECENTACTIVITY_DETAILS_FOR_GUEST";
	public static final String FILTER_RECENTACTIVITY_DETAILS_FOR_ADMIN = "FILTER_RECENTACTIVITY_DETAILS_FOR_ADMIN";
	public static final String FILTER_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN = "FILTER_RECENTACTIVITY_DETAILS_FOR_NON_ADMIN";
	
	
	/*Filter - gamification*/
	public static final String FILTER_GAMIFICATION_DETAILS = "FILTER_GAMIFICATION_DETAILS";
	public static final String FILTER_GAMIFICATION_DETAILS_BY_USERID = "FILTER_GAMIFICATION_DETAILS_BY_USERID";
	
	
	public static final String ASSET_INSTANCE_DETAILS_UPDATED = "ASSET_INSTANCE_DETAILS_UPDATED";
	public static final String ALREADY_SUBSCRIBED = "ALREADY_SUBSCRIBED";
	public static final String SUBSCRIBE = "SUBSCRIBE";
	public static final String UNSUBSCRIBE = "UNSUBSCRIBE";
	public static final String ALREADY_UNSUBSCRIBED = "ALREADY_UNSUBSCRIBED";
	
	
	/*new Filter for grid page results queries for */
	public static final String RENAME_ASSET_INSTANCE_NAME_IN_PARAM_VALUE = "RENAME_ASSET_INSTANCE_NAME_IN_PARAM_VALUE";
	public static final String GET_ALL_SUBSCRIPTIONS_BY_TAXONOMY = "GET_ALL_SUBSCRIPTIONS_BY_TAXONOMY";
	
	/*new query for customized section in AIV page*/
	public static final String UPDATE_CUSTOM_SECTION_POSITION_STATUS = "UPDATE_CUSTOM_SECTION_POSITION_STATUS";
	public static final String CUSTOMIZED_LAYOUT_DATA_UPDATED_SUCCESSFULLY = "CUSTOMIZED_LAYOUT_DATA_UPDATED_SUCCESSFULLY";
	public static final String GET_CUSTOM_SECTION_POSITION_STATUS = "GET_CUSTOM_SECTION_POSITION_STATUS";
	public static final String CUSTOMIZED_LAYOUT_DATA_FETCHED_SUCCESSFULLY = "CUSTOMIZED_LAYOUT_DATA_FETCHED_SUCCESSFULLY";
	public static final String CUSTOMIZED_LAYOUT_DATA_NOT_FOUND = "CUSTOMIZED_LAYOUT_DATA_NOT_FOUND";
	public static final String CUSTOMIZED_LAYOUT_DATA_NOT_UPDATED = "CUSTOMIZED_LAYOUT_DATA_NOT_UPDATED";
	
	
	/*filter - Manage subscription taxonomy*/
	public static final String GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_SUBSCRIBE = "GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_SUBSCRIBE";
	public static final String GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_UNSUBSCRIBE = "GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_UNSUBSCRIBE";
	public static final String GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA = "GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA";
	public static final String GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_SUBSCRIBE_HIDE_UNUSED = "GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_SUBSCRIBE_HIDE_UNUSED";
	public static final String GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_UNSUBSCRIBE_HIDE_UNUSED = "GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_UNSUBSCRIBE_HIDE_UNUSED";
	public static final String GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_HIDE_UNUSED = "GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_HIDE_UNUSED";

	public static final String GET_SHOWHIDE_COLUMN_DETAILS_NOT_FOUND = "GET_SHOWHIDE_COLUMN_DETAILS_NOT_FOUND";
	
	public static final String GET_USER_FROM_DEFAULT_GROUP = "GET_USER_FROM_DEFAULT_GROUP";
	
	/*Taxonomy subscription*/
	public static final String GET_TAXONOMY_SUBSCRIPTION_DETAILS = "GET_TAXONOMY_SUBSCRIPTION_DETAILS";
	public static final String PROVIDE_VALID_OPTION = "PLEASE PROVIDE_VALID_OPTION";
	public static final String GET_ALL_TAXONOMIES_BY_TAXONOMY_ID_FOR_FILTER = "GET_ALL_TAXONOMIES_BY_TAXONOMY_ID_FOR_FILTER";
	public static final String GET_ALL_TAXONOMIES_FOR_FILTER = "GET_ALL_TAXONOMIES_FOR_FILTER";
	
    public static final String INSERT_TOKEN_DETAILS = "INSERT_TOKEN_DETAILS";
	public static final String DELETE_TOKEN_DETAILS = "DELETE_TOKEN_DETAILS";
    public static final String GET_USER_DETAILS_BY_TOKEN = "GET_USER_DETAILS_BY_TOKEN";
    
    public static final String INSERT_OAUTH_TOKEN_DETAILS = "INSERT_OAUTH_TOKEN_DETAILS";
    public static final String DELETE_OAUTH_TOKEN_DETAILS = "DELETE_OAUTH_TOKEN_DETAILS";
    public static final String GET_USER_DETAILS_BY_OAUTH_TOKEN = "GET_USER_DETAILS_BY_OAUTH_TOKEN";

    
    
    public static final String GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_BROWSEGRID_SEARCH = "GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_BROWSEGRID_SEARCH";
    public static final String GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_BROWSEGRID_SEARCH_NON_ADMIN = "GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_BROWSEGRID_SEARCH_NON_ADMIN";
    
    
    public static final String GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER_SEARCH = "GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER_SEARCH";
    public static final String GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER_SEARCH_NON_ADMIN = "GET_ALL_ASSET_INSTANCE_RELATIONSHIPS_CREATE_FILTER_SEARCH_NON_ADMIN";
    
    
    public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITH_SEARCH = "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITH_SEARCH";
    public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITHOUT_SEARCH = "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITHOUT_SEARCH";
    public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITH_SEARCH = "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITH_SEARCH";
    public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH = "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH";
    public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITH_SEARCH_ADMIN= "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITH_SEARCH_ADMIN";
    public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH_ADMIN= "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH_ADMIN";
    public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITH_SEARCH_ADMIN= "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITH_SEARCH_ADMIN";
    public static final String GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITHOUT_SEARCH_ADMIN= "GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITHOUT_SEARCH_ADMIN";
    public static final String GET_ALL_ASSET_INSTANCES_BY_SEARCH ="GET_ALL_ASSET_INSTANCES_BY_SEARCH";
    public static final String GET_ALL_FILTERED_USERS_FOR_GRID_EXPORT = "GET_ALL_FILTERED_USERS_FOR_GRID_EXPORT";
	
    /*filter rest api*/
    public static final String TAXONOMY_NOT_PRESENT_TO_SEARCH = "TAXONOMY_NOT_PRESENT_TO_SEARCH";
	
    /* properties REST api*/
    public static final String INVALID_ASSET_PARAM_NAME = "INVALID_ASSET_PARAM_NAME";
  	public static final String DERIVED_PARAMETERS_NOT_ALLOWED = "DERIVED_PARAMETERS_NOT_ALLOWED";
  	public static final String PROVIDE_MANDATORY_PARAMETERS = "PROVIDE_MANDATORY_PARAMETERS";
	public static final String ERROR_FLAG = "true";
	
	public static final String GET_PARAM_DETAILS_BY_ASSET_NAME_FOR_ADMIN = "GET_PARAM_DETAILS_BY_ASSET_NAME_FOR_ADMIN";
	public static final String GET_PARAM_DETAILS_BY_ASSET_NAME_FOR_NON_ADMIN = "GET_PARAM_DETAILS_BY_ASSET_NAME_FOR_NON_ADMIN";
	public static final String ASSET_PARAM_NOT_FOUND = "ASSET_PARAM_NOT_FOUND";
	public static final String PLEASE_PROVIDE_DESCRIPTION = "PLEASE_PROVIDE_DESCRIPTION";
	public static final String GET_PARAM_NAMES_VALUES_BY_PARAM_ID = "GET_PARAM_NAMES_VALUES_BY_PARAM_ID";
	public static final String GET_TAG_DETAILS_BY_AIV_ID = "GET_TAG_DETAILS_BY_AIV_ID";
	public static final String ASSET_INSTANCE_DETAILS_CREATED = "ASSET_INSTANCE_DETAILS_CREATED";
	public static final String RET_ASSET_INST_VERSION_BY_ASSET_VERSION_ID_AND_ASSETID = "RET_ASSET_INST_VERSION_BY_ASSET_VERSION_ID_AND_ASSETID";
	public static final String CHILD_ASSET_INSTANCE_DETAILS_CREATED = "CHILD_ASSET_INSTANCE_DETAILS_CREATED";
	public static final String STATIC_VALUES_CANNOT_BE_FILTERED = "STATIC_VALUES_CANNOT_BE_FILTERED";
	
	/*properties*/
	public static final String RET_ALL_NON_STATIC_PARAMETERS = "RET_ALL_NON_STATIC_PARAMETERS";
	public static final String RET_NON_STATIC_PARAMETER_DETAILS = "RET_NON_STATIC_PARAMETER_DETAILS";
	public static final String RET_STATIC_PARAMETER_DETAILS = "RET_STATIC_PARAMETER_DETAILS";
	
	/*grid rest queries*/
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_ADMIN_FOR_REST = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_ADMIN_FOR_REST";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GUEST_FOR_REST ="GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GUEST_FOR_REST";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_ADMIN_FOR_REST = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_ADMIN_FOR_REST";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_NORMAL_USER_FOR_REST = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_GROUP_NORMAL_USER_FOR_REST";
			
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_STATIC_PARAM_INFORMATION_BY_ASSET_NAME_ADMIN_FOR_REST = "GET_ASSET_INSTANCE_VERSION_DETAILS_WITH_STATIC_PARAM_INFORMATION_BY_ASSET_NAME_ADMIN_FOR_REST";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST_FOR_REST = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_FOR_GUEST_FOR_REST";
	public static final String GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN_FOR_REST = "GET_ASSET_INSTANCE_VERSION_DETAILS_BY_ASSET_NAME_NON_ADMIN_FOR_REST";
	public static final String LOCK_TIME_EXPIRED = "LOCK_TIME_EXPIRED";
	public static final String DEST_ASSET_ACCESS_AND_USER_COUNT_AND_VERSION_DETAILS_FETCHED = "DEST_ASSET_ACCESS_AND_USER_COUNT_AND_VERSION_DETAILS_FETCHED";
	public static final String ASSET_INSTANCE_VERSION_DATA_RETRIVED_SUCCESSFULLY = "ASSET_INSTANCE_VERSION_DATA_RETRIVED_SUCCESSFULLY";
	
	/*rest authentication */
	public static final String UPDATE_REST_API_AUTHENTICATION_MECHANISM = "UPDATE_REST_API_AUTHENTICATION_MECHANISM";
	public static final String GET_REST_API_AUTHENTICATION_MECHANISM = "GET_REST_API_AUTHENTICATION_MECHANISM";
	
	public static final String INSTANCE_DETAILS_MODIFIED = "INSTANCE_DETAILS_MODIFIED";
	public static final String GET_ADVANCED_SEARCH_DATA = "GET_ADVANCED_SEARCH_DATA";
	public static final String DOWNLOAD_FILE_PATH = System.getProperty("user.home") + "/DownloadFileFolder";
	
	/*Ldap mapping parameter details*/
	public static final String GET_LDAP_MAPPING_LIST = "GET_LDAP_MAPPING_LIST";
	public static final String GET_LDAP_MAPPING_ATTRIBUTE_LIST_BY_MAPPING_ID = "GET_LDAP_MAPPING_ATTRIBUTE_LIST_BY_MAPPING_ID";
	public static final String LDAP_MAPPING_DATA_NOT_FOUND = "LDAP_MAPPING_DATA_NOT_FOUND";
	public static final String LDAP_MAPPING_LIST_FETCHED = "LDAP_MAPPING_LIST_FETCHED";
	public static final String LDAP_MAPPING_NOT_FOUND = "LDAP_MAPPING_NOT_FOUND";
	public static final String LDAP_ATTRIBUTE_NOT_FOUND = "LDAP_ATTRIBUTE_NOT_FOUND";
	public static final String ADD_PARAMETER_VALUES_FOR_LDAP_MAPPING = "ADD_PARAMETER_VALUES_FOR_LDAP_MAPPING";
	public static final String GET_LDAP_MAPPING_ATTRIBUTE_LIST_BY_ATTRIBUTE_ID = "GET_LDAP_MAPPING_ATTRIBUTE_LIST_BY_ATTRIBUTE_ID";
	
	
	
	
	/* SQL */
	public static final String GET_ALL_DERIVED_ATTRIBUTES_FOR_ASSETLIST = "GET_ALL_DERIVED_ATTRIBUTES_FOR_ASSETLIST";
	//public static final String GET_ALL_ASSET_LIST_PARAMETERS = "GET_ALL_ASSET_LIST_PARAMETERS";
	public static final String UPDATE_ASSET_PARAMETER_DEF_DERIVED_ASSET_LIST_RULE = "UPDATE_ASSET_PARAMETER_DEF_DERIVED_ASSET_LIST_RULE";
	
	public static final String DERIVED_ATTRIBUTE_FOR_ASSET_LIST_FETCHED_SUCCESSFULLY = "DERIVED_ATTRIBUTE_FOR_ASSET_LIST_FETCHED_SUCCESSFULLY";
	
	
	/*Message*/
	//public static final String ASSETLIST_PARAMETERS_NOT_FOUND = "ASSETLIST_PARAMETERS_NOT_FOUND";
	public static final String DYNAMIC_QUERY_FOR_DERIVED_ATTRIBUTE_FOR_ASSET_LIST_NOT_GENERATED = "DYNAMIC_QUERY_FOR_DERIVED_ATTRIBUTE_FOR_ASSET_LIST_NOT_GENERATED";
	
	public static final String INVALID_SORT_BY_ATTRIBUTE = "INVALID_SORT_BY_ATTRIBUTE";
	public static final String INVALID_SORTING_ORDER = "INVALID_SORTING_ORDER";
	
	
	public static final String GET_RELATIONSHIPS_BY_DEST_AIV_ID = "GET_RELATIONSHIPS_BY_DEST_AIV_ID";
	
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_TOTAL_COUNT_FOR_ADMIN = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_TOTAL_COUNT_FOR_ADMIN";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_TOTAL_COUNT_FOR_GUEST = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_TOTAL_COUNT_FOR_GUEST";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_TOTAL_COUNT_FOR_GROUP_ADMIN = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_TOTAL_COUNT_FOR_GROUP_ADMIN";
	public static final String GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_TOTAL_COUNT_FOR_GROUP_NORMAL_USER = "GET_SHOW_AND_HIDE_ASSET_INSTANCE_FOR_GRID_FOR_TOTAL_COUNT_FOR_GROUP_NORMAL_USER";
	
	public static final String RET_GROUPS_WITH_AIV_ACCESS_FOR_MULTIPLE_INSTANCES = "RET_GROUPS_WITH_AIV_ACCESS_FOR_MULTIPLE_INSTANCES";
	public static final String GET_DEFAULT_FILTER_SEARCH = "GET_DEFAULT_FILTER_SEARCH";
	public static final String UPDATE_DEFAULT_FILTER_SEARCH_DETAILS = "UPDATE_DEFAULT_FILTER_SEARCH_DETAILS";
	
	
	/* Asset Representation SQL queries */
	public static final String ADD_ASSET_REPRESENTATION = "ADD_ASSET_REPRESENTATION";
	public static final String ADD_ASSET_REPRESENTATION_LINK = "ADD_ASSET_REPRESENTATION_LINK";
	public static final String GET_ALL_ASSET_REPRESENTATION = "GET_ALL_ASSET_REPRESENTATION";
	public static final String GET_ASSET_REPRESENTATION_BY_ASSETNAME = "GET_ASSET_REPRESENTATION_BY_ASSETNAME"; 
	public static final String GET_ASSET_REPRESENTATION_BY_NAME = "GET_ASSET_REPRESENTATION_BY_NAME";
	public static final String UPDATE_ASSET_REPRESENTATION = "UPDATE_ASSET_REPRESENTATION";
	public static final String DELETE_ASSET_REPRESENTATION = "DELETE_ASSET_REPRESENTATION";
	public static final String GET_ASSET_REPRESENTATION_BY_ID = "GET_ASSET_REPRESENTATION_BY_ID";
	public static final String UPDATE_ASSET_INSTANCE_REPRESENTATION = "UPDATE_ASSET_INSTANCE_REPRESENTATION";
	public static final String DELETE_ASSET_REPRESENTATION_LINK = "DELETE_ASSET_REPRESENTATION_LINK";
	public static final String GET_COUNT_OF_ASSET_REPRESENTATION_LINK_BY_REPRESENTATION_ID = "GET_COUNT_OF_ASSET_REPRESENTATION_LINK_BY_REPRESENTATION_ID";	
	
	public static final String JAR_FILE_PATH = System.getProperty("user.home") + "/asset_representation/";
	public static final String UPLOADED_JAR_SUPPORT_FILE_PATH = System.getProperty("user.home") + "/instance_representation/";
	
	public static final String ADD_ASSET_INSTANCE_REPRESENTATION = "ADD_ASSET_INSTANCE_REPRESENTATION";
	public static final String GET_ASSET_INSTANCE_REPRESENTATION_BY_AIVID = "GET_ASSET_INSTANCE_REPRESENTATION_BY_AIVID";
	public static final String GET_ALL_ASSET_INSTANCE_REPRESENTATION_LINKED_TO_ASSET = "GET_ALL_ASSET_INSTANCE_REPRESENTATION_LINKED_TO_ASSET";
	public static final String GET_ALL_ASSET_INSTANCE_LINKED_TO_REPRESENTATION = "GET_ALL_ASSET_INSTANCE_LINKED_TO_REPRESENTATION";
	public static final String DELETE_ASSET_INSTANCE_REPRESENTATION = "DELETE_ASSET_INSTANCE_REPRESENTATION";	
		
	/* Asset Representation API messages */
	public static final String GET_ALL_REPRESENTATION = "GET_ALL_REPRESENTATION";
	public static final String INVALID_ASSET_REPRESENTATION = "INVALID_ASSET_REPRESENTATION";
	public static final String ASSET_INSTANCE_REPRESENTATION_BY_AIVID_NOT_FOUND = "ASSET_INSTANCE_REPRESENTATION_BY_AIVID_NOT_FOUND";


	/* Parameter Rule */
	public static final String ADD_AIV_PARAMRULE = "ADD_AIV_PARAMRULE";
	public static final String UPDATE_AIV_PARAMRULE = "UPDATE_AIV_PARAMRULE";
	public static final String GET_AIV_PARAMRULE_BY_USERNAME_AND_AIVID = "GET_AIV_PARAMRULE_BY_USERNAME_AND_AIVID";
	public static final String GET_AIV_PARAMRULE_BY_AIVID = "GET_AIV_PARAMRULE_BY_AIVID";
	public static final String AIV_PARAM_RULE_CREATED_SUCCESSFULLY = "AIV_PARAM_RULE_CREATED_SUCCESSFULLY";
	public static final String AIV_PARAM_RULE_UPDATED_SUCCESSFULLY = "AIV_PARAM_RULE_UPDATED_SUCCESSFULLY";
	public static final String AIV_PARAM_RULE_NOT_FOUND = "AIV_PARAM_RULE_NOT_FOUND";
	public static final String AIV_PARAM_RULE_FETCHED_SUCCESSFULLY = "AIV_PARAM_RULE_FETCHED_SUCCESSFULLY";
	public static final String AIV_PARAM_RULE_NOT_UPDATED = "AIV_PARAM_RULE_NOT_UPDATED";
	public static final String AIV_PARAM_RULE_NOT_CREATED = "AIV_PARAM_RULE_NOT_CREATED";
	public static final String GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN_WITH_NOTIFY_ENABLED = "GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN_WITH_NOTIFY_ENABLED";
	public static final String GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN_WITH_NOTIFY_ENABLED = "GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN_WITH_NOTIFY_ENABLED";
	public static final String GET_ALL_PARAM_DETAILS_FOR_ADMIN_WITH_NOTIFY_ENABLED = "GET_ALL_PARAM_DETAILS_FOR_ADMIN_WITH_NOTIFY_ENABLED";
	public static final String GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN_WITH_NOTIFY_ENABLED = "GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN_WITH_NOTIFY_ENABLED";
	public static final String DELETE_AIV_PARAMRULE = "DELETE_AIV_PARAMRULE";
	public static final String PARAM_RULE_NOT_DELETED = "PARAM_RULE_NOT_DELETED";
	public static final String GET_AIV_PARAMRULE_BY_AIVID_AND_RULENAME = "GET_AIV_PARAMRULE_BY_AIVID_AND_RULENAME";
	public static final String DUPLICATE_RULE_SET_NAME = "DUPLICATE_RULE_SET_NAME";
	public static final String DELETE_AIV_RULE_SETS = "DELETE_AIV_RULE_SETS";
	public static final String GET_AIV_PARAMRULE_BY_USERNAME = "GET_AIV_PARAMRULE_BY_USERNAME";
	public static final String GET_AIVIDS_FOR_AIV_PARAMRULE_BY_USERNAME = "GET_AIVIDS_FOR_AIV_PARAMRULE_BY_USERNAME";
	
	public static final String RET_MATCHED_PROFILE_WITH_LIMIT_FOR_LOGGED_IN_USER = "RET_MATCHED_PROFILE_WITH_LIMIT_FOR_LOGGED_IN_USER";
	public static final String RET_MATCHED_PROFILE_WITHOUT_LIMIT_FOR_LOGGED_IN_USER = "RET_MATCHED_PROFILE_WITHOUT_LIMIT_FOR_LOGGED_IN_USER";
	public static final String RET_MATCHED_PROFILE_FOR_LOGGED_IN_USER = "RET_MATCHED_PROFILE_FOR_LOGGED_IN_USER";
	public static final String REPRESENTATION_DATA_NOT_FOUND = "REPRESENTATION_DATA_NOT_FOUND";
	
	/*Workflow SQL queries*/
	public static final String GET_ALL_WORKFLOWS = "GET_ALL_WORKFLOWS";
	public static final String ADD_WORKFLOW = "ADD_WORKFLOW";
	public static final String GET_WORKFLOW_BY_NAME = "GET_WORKFLOW_BY_NAME";
	public static final String GET_WORKFLOW_BY_ID = "GET_WORKFLOW_BY_ID";
	public static final String DELETE_WORKFLOW = "DELETE_WORKFLOW";
	public static final String UPDATE_WORKFLOW = "UPDATE_WORKFLOW";
	public static final String ADD_WORKFLOW_LINK = "ADD_WORKFLOW_LINK";
	public static final String DELETE_WORKFLOW_LINK = "DELETE_WORKFLOW_LINK";
	public static final String GET_ALL_ASSET_INSTANCES_FOR_ASSET = "GET_ALL_ASSET_INSTANCES_FOR_ASSET";
	public static final String UPDATE_INSTANCE_STATE = "UPDATE_INSTANCE_STATE";
	public static final String GET_ASSETS_LINKED_TO_WORKFLOW = "GET_ASSETS_LINKED_TO_WORKFLOW";
	public static final String RET_WORKFLOW_BY_AIV_ID = "RET_WORKFLOW_BY_AIV_ID";
	public static final String GET_WORKFLOW_ASSIGNED_TO_ASSET = "GET_WORKFLOW_ASSIGNED_TO_ASSET";
	public static final String GET_ALL_ASSETS_WITH_WORKFLOW = "GET_ALL_ASSETS_WITH_WORKFLOW";
	public static final String DELETE_WORKFLOW_LINK_FROM_ASSET = "DELETE_WORKFLOW_LINK_FROM_ASSET";
	public static final String GET_STATES_ASSIGNED_FOR_ASSET = "GET_STATES_ASSIGNED_FOR_ASSET";
	
	/*Workflow Messages*/
	public static final String WORKFLOW_ADDED_SUCCESSFULLY = "WORKFLOW_ADDED_SUCCESSFULLY";
	public static final String WORKFLOW_DELETED_SUCCESSFULLY = "WORKFLOW_DELETED_SUCCESSFULLY";
	public static final String WORKFLOW_NOT_DELETED = "WORKFLOW_NOT_DELETED";
	public static final String WORKFLOW_NAME_ALREADY_EXISTS = "WORKFLOW_NAME_ALREADY_EXISTS";
	public static final String WORKFLOW_UPDATED_SUCCESSFULLY = "WORKFLOW_UPDATED_SUCCESSFULLY";
	public static final String STATE_FETCHED_SUCCESSFULLY = "STATE_FETCHED_SUCCESSFULLY";
	public static final String STATE_UPDATED_SUCCESSFULLY = "STATE_UPDATED_SUCCESSFULLY";
	public static final String NO_STATES_TO_DISPLAY = "NO_STATES_TO_DISPLAY";
	
	/*Workflow Message Constants*/
	public static final String WORKFLOW_NOT_FOUND = "WORKFLOW_NOT_FOUND";
	public static final String WORKFLOW_NOT_ADDED = "WORKFLOW_NOT_ADDED";
	public static final String WORKFLOW_NOT_UPDATED = "WORKFLOW_NOT_UPDATED";
	public static final String WORKFLOW_LINK_NOT_ADDED = "WORKFLOW_LINK_NOT_ADDED";
	public static final String WORKFLOW_LINK_NOT_DELETED = "WORKFLOW_LINK_NOT_DELETED";
	
	
	/*Generic trigger SQL constants*/
	public static final String GET_ALL_STATES_BY_ASSET = "GET_ALL_STATES_BY_ASSET";
	public static final String GET_ALL_ASSET_PARAM_RULES = "GET_ALL_ASSET_PARAM_RULES";
	public static final String GET_PARAM_RULE_DETAILS = "GET_PARAM_RULE_DETAILS";
	public static final String GET_ALL_PARAM_RULES_BASED_ON_SEARCH = "GET_ALL_PARAM_RULES_BASED_ON_SEARCH";
	public static final String DELETE_ASSET_PARAM_RULE = "DELETE_ASSET_PARAM_RULE";
	public static final String ADD_ASSET_PARAM_RULE = "ADD_ASSET_PARAM_RULE";
	public static final String GET_USER_STATUS_BY_USERID = "GET_USER_STATUS_BY_USERID";
	public static final String GET_ALL_PARAM_RULES = "GET_ALL_PARAM_RULES";
	//public static final String GET_ALL_ASSET_INSTANCES_BY_STATE = "GET_ALL_ASSET_INSTANCES_BY_STATE";
	public static final String UPDATE_ASSET_PARAM_RULE = "UPDATE_ASSET_PARAM_RULE";
	
	/*Generic trigger Constants*/
	public static final String ASSET_PARAM_RULES_FETCHED_SUCCESSFULLY = "ASSET_PARAM_RULES_FETCHED_SUCCESSFULLY";
	public static final String ASSET_PARAM_RULE_DETAILS_FETCHED_SUCCESSFULLY = "ASSET_PARAM_RULE_DETAILS_FETCHED_SUCCESSFULLY";
	public static final String PARAM_RULE_SAVED_SUCCESSFULLY = "PARAM_RULE_SAVED_SUCCESSFULLY";
	
	/*Generic trigger Message constants*/
	public static final String PARAM_RULES_NOT_FOUND = "PARAM_RULES_NOT_FOUND";
	public static final String PARAM_RULES_NOT_SAVED = "PARAM_RULES_NOT_SAVED";
	
	
	/*Alerting Enahancement Queries*/
	public static final String GET_ALL_AIV_PARAMRULES = "GET_ALL_AIV_PARAMRULES";
	public static final String GET_AIV_PARAMRULESETS_BY_USERNAME_AND_AIVID = "GET_AIV_PARAMRULESETS_BY_USERNAME_AND_AIVID";

	/*Mail Configuration sql queries*/
	public static final String ADD_MAILCONFIG = "ADD_MAILCONFIG";
	public static final String GET_ALL_MAILCONFIG = "GET_ALL_MAILCONFIG";
	
	/*Mail Configuration Constants*/
	public static final String MAILCONFIG_NOT_FOUND = "MAILCONFIG_NOT_FOUND";
	public static final String MAILCONFIG_CANNOT_BE_ADDED = "MAILCONFIG_CANNOT_BE_ADDED";
	public static final String DETAILS_NOT_FOUND="DETAILS_NOT_FOUND";
	public static final String ALL_DETAILS_FETCHED="ALL_DETAILS_FETCHED";
	public static final String ADD_MAIL="ADD_MAIL";
	public static final String MAIL_NOT_CREATED="MAIL_NOT_CREATED";
	public static final String DELETE_MAIL_DETAILS="DELETE_MAIL_DETAILS";
	public static final String MAIL_DELETED_SUCCESSFULLY="MAIL_DELETED_SUCCESSFULLY";
	public static final String MAIL_NOT_DELETED="MAIL_NOT_DELETED";
	public static final String NO_DETAILS_EXITS="NO_DETAILS_EXITS";
	
	
	/* test mail*/
	public static final String TEST_MAIL_SENT = "TEST_MAIL_SENT";
	public static final String TEST_MAIL_SENT_SUCESSFULLY = "TEST_MAIL_SENT_SUCESSFULLY";
	public static final String TEST_MAIL_NOT_SENT="TEST_MAIL_NOT_SENT";
	
	/*Theme SQL Query*/
	public static final String INSERT_ALL_COLOR_CONFIG="INSERT_ALL_COLOR_CONFIG";
	public static final String GET_ALL_LOGIN_COLOR_CONFIG = "GET_ALL_LOGIN_COLOR_CONFIG";
	public static final String UPDATE_ALLTHEME_CONFIG = "UPDATE_ALLTHEME_CONFIG";
	public static final String UPDATE_THEME_LOGIN_CONFIG = "UPDATE_THEME_LOGIN_CONFIG";
	
	/*Theme message constants*/
	public static final String LOGIN_PAGE_COLOR_NOT_UPDATED="LOGIN_PAGE_COLOR_NOT_UPDATED";
	public static final String LOGIN_COLOR_UPDATED_SUCCESSFULLY = "LOGIN_COLOR_UPDATED_SUCCESSFULLY";
	
	
	public static final String THEME_DETAILS_NOT_UPDATED = "THEME_DETAILS_NOT_UPDATED";
	public static final String ALL_THEMECOLORS_UPDATED_SUCCESSFULLY = "ALL_THEMECOLORS_UPDATED_SUCCESSFULLY";
	public static final String LOGIN_DETAILS_FETCHED = "LOGIN_DETAILS_FETCHED";
	public static final String THEME_DETAILS_FETCHED = "THEME_DETAILS_FETCHED";
	public static final String THEME_DETAILS_NOT_FOUND = "THEME_DETAILS_NOT_FOUND";
	public static final String UPDATE_ALL_COLORCODES = "UPDATE_ALL_COLORCODES";
	public static final String FAILED_TO_UPDATE_COLOR_CODE = "FAILED_TO_UPDATE_COLOR_CODE";
	public static final String UPDATE_LOGIN_LOGOIMAGE = "UPDATE_LOGIN_LOGOIMAGE";
	public static final String UPDATE_BACKGROUND_IMAGE = "UPDATE_BACKGROUND_IMAGE";
	public static final String UPDATE_FAVICON_IMAGE = "UPDATE_FAVICON_IMAGE";
	public static final String UPDATE_LOGO_IMAGE = "UPDATE_LOGO_IMAGE";
	public static final String FAILED_TO_UPDATE_CUSTOM_IMAGES = "FAILED_TO_UPDATE_CUSTOM_IMAGES";
	public static final String THEME_FILE_NAME = "/semantic/images/login_Imgs/";
	

	/*Display list of matched rules constants*/
	public static final String MATCHED_RULES_FETCHED_SUCCESSFULLY = "MATCHED_RULES_FETCHED_SUCCESSFULLY";
	
}

