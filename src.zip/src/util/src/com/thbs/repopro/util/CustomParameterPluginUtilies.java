package com.thbs.repopro.util;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomParameterPluginUtilies {

	private final static Logger log = LoggerFactory.getLogger("timeBased");
	public static Class<NotificationInterface> customParameterImpl;

	public static Class<NotificationInterface> getplugin() {
		return customParameterImpl;
	}


	public static void setplugin() throws ClassNotFoundException {
		String notifyClassName = CommonUtils.customParameterPluginNoficationClassName;
		customParameterImpl = loadCustomParameterPulgin(notifyClassName);
	}
	
	
	@SuppressWarnings("unchecked")
	public static  Class<NotificationInterface> loadCustomParameterPulgin(String className) throws ClassNotFoundException {
		Class<NotificationInterface> result = null;
		try {
			URLClassLoader classLoader = getJarClassLoader();
			if (classLoader != null) {
				Class<?> clazz = classLoader.loadClass(className);
				if (NotificationInterface.class.isAssignableFrom(clazz)) {
					result = (Class<NotificationInterface>) clazz;
				} else {
					//Error logging for invalid plugin implementation
					if (log.isTraceEnabled()) {
						log.trace("Invalid plugin implementation");
					}
					
				}
			} else {
				//Error logging for URLClassLoader being null
				if (log.isTraceEnabled()) {
					log.trace("URLClassLoader : Null ");
				}

			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
			
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
		return result;

	}

	public static URLClassLoader getJarClassLoader() throws MalformedURLException {
		URLClassLoader urlClassLoader = null;
		String filepath = CommonUtils.customParameterPluginPath;
		if (filepath != null && !filepath.equals("")) {
			File file = new File(filepath);
			if (file.exists()) {
				URL jarfile = file.toURI().toURL();
				urlClassLoader = URLClassLoader.newInstance(new URL[] { jarfile },
						PluginUtlities.class.getClassLoader());
			} else {
				//Error logging for invalid file path
				if (log.isTraceEnabled()) {
					log.trace("getJarClassLoader : Plugin jar not found in the path ");
				}
			}
		}

		return urlClassLoader;

	}

}
