package com.thbs.repopro.util;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 * @author THBS
 *
 */
public class MessageUtil {

	/**
	 * @param key
	 * @return
	 */
	public static String getMessage(String key) {

		Locale locale = new Locale(PropertyFileReader.getInstance().getValue(
				Constants.LANGUAGE), PropertyFileReader.getInstance().getValue(
				Constants.COUNTRY_CODE));
		ResourceBundle labels = ResourceBundle.getBundle(PropertyFileReader
				.getInstance().getValue(Constants.BUNDLE_NAME), locale);
		return labels.getString(key);
	}
}
