package com.thbs.repopro.util;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import com.thbs.repopro.exception.RepoproException;



/**
 * @author THBS
 *
 */
public class DBConnection {

	private static DBConnection datasource;
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
//	private BoneCP connectionPool;	db.properties

	/**
	 * @throws IOException
	 * @throws SQLException
	 * @throws PropertyVetoException
	 * @throws MySQLSyntaxErrorException
	 */
	private DBConnection() throws IOException, SQLException, MySQLSyntaxErrorException,RepoproException,
			PropertyVetoException {
		try {
			Class.forName(PropertiesCache.getInstance().getProperty("DRIVER"));
			/*BoneCPConfig config = new BoneCPConfig();
			config.setJdbcUrl(PropertiesCache.getInstance().getProperty("URL"));
			config.setUsername(PropertiesCache.getInstance().getProperty("USERNAME"));
			config.setPassword(PropertiesCache.getInstance().getProperty("PASSWORD"));
			config.setMinConnectionsPerPartition(Constants.FIVE);
			config.setMaxConnectionsPerPartition(Constants.TEN);
			config.setAcquireIncrement(Constants.TEN);
			config.setPartitionCount(Constants.FIVE);

			connectionPool = new BoneCP(config);*/
		} 
		catch (Exception e) {
			e.printStackTrace();
			return;
		}

	}

	/**
	 * @return
	 * @throws IOException
	 * @throws SQLException
	 * @throws PropertyVetoException
	 */
	public static DBConnection getInstance() throws IOException,SQLException,MySQLSyntaxErrorException,RepoproException
			,PropertyVetoException {
		if (datasource == null) {
			datasource = new DBConnection();
			return datasource;
		} else {
			return datasource;
		}
	}

	/**
	 * @return
	 * @throws SQLException
	 */
	public Connection getConnection() throws RepoproException {
		Connection connection = null;
		try{
			 connection = DriverManager.getConnection(PropertiesCache.getInstance().getProperty("URL"), PropertiesCache.getInstance().getProperty("USERNAME"), PropertiesCache.getInstance().getProperty("PASSWORD"));
			connection.setAutoCommit(false);
		
		}catch (MySQLSyntaxErrorException e) {
			log.error("getConnection || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					e.getMessage());
		} catch (SQLException e) {
			log.error("getConnection || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} 
		catch (Exception e) {
			log.error("getConnection || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} 
		return connection;
//		return this.connectionPool.getConnection();
		
	}

	/**
	 * @param conn
	 */
	public static void closeDbConnection(Connection conn) {
		try {
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * @param pstmt
	 */
	public static void closePreparedStatement(PreparedStatement pstmt) {
		try {
			if (pstmt != null) {
				pstmt.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * @param rs
	 */
	public static void closeResultSet(ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
