package com.thbs.repopro.util;

import org.apache.commons.codec.binary.Base64;

import java.math.BigInteger;
import java.util.Random;

public class EncryptKeys{
	
	public String randomSubscriptionKey(){
		Random ran = new Random();
		int x = ran.nextInt(6) + 15;
		
		Random r = new Random();
        StringBuffer sb = new StringBuffer();
        while(sb.length() < x){
            sb.append(Integer.toHexString(r.nextInt()));
        }
        return sb.toString().substring(0, x);
	}
	
	public String encryptKey(long key) {
		Random randomGenerator = new Random();
//		randomGenerator.setSeed(System.currentTimeMillis());
		
		long x = key;
		x = x<<3; //8*x
		
		long z = randomGenerator.nextInt(2);
		x = x | (z << 0); //change 0th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 1); //change 1th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 2); //change 2th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 27); //change 27th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 28); //change 27th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 30); //change 27th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 40); //change 27th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 50); //change 27th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 58); //change 27th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 59); //change 27th bit to 1
		
		z = randomGenerator.nextInt(2);
		x = x | (z << 60); //change 27th bit to 1
		z = randomGenerator.nextInt(2);
		x = x | (z << 63); //change 27th bit to 1
		
//		EncryptPassword encryptPasswordDao = new EncryptPassword();
//		String resultEncript = encryptPasswordDao.encryptPassword(""+x);
		
//		byte[] byteArrayE = Base64.encodeBase64((""+x).getBytes());
//      String resultEncript = new String(byteArrayE);
		
		String resultEncript = Long.toHexString(x);

		return resultEncript;
	}
	
	public long decryptKey(String encriptedString) {
		long x;
//		DecryptPassword decryptPasswordDao = new DecryptPassword();
//		String resultDecript = decryptPasswordDao.decrypt(resultEncript);
		
//		byte[] byteArrayD = Base64.decodeBase64(encriptedString.getBytes());
//		String resultDecript = new String(byteArrayD);
		
		int y = 134217720;
		x = new BigInteger(encriptedString, 16).longValue();
		x =x&y;
		x = x >> 3;
		
		return x;
	}
	
	
	public String encryptStaticKey(long key) {
//		randomGenerator.setSeed(System.currentTimeMillis());
		
		long x = key;
		x = x<<3; //8*x
		
		long z = 1;
		x = x | (z << 0); //change 0th bit to 1
		
		z = 1;
		x = x | (z << 1); //change 1th bit to 1
		
		z = 1;
		x = x | (z << 2); //change 2th bit to 1
		
		z = 1;
		x = x | (z << 27); //change 27th bit to 1
		
		z = 1;
		x = x | (z << 28); //change 27th bit to 1
		
		z = 1;
		x = x | (z << 30); //change 27th bit to 1
		
		z = 1;
		x = x | (z << 40); //change 27th bit to 1
		
		z = 1;
		x = x | (z << 50); //change 27th bit to 1
		
		z = 1;
		x = x | (z << 58); //change 27th bit to 1
		
		z = 1;
		x = x | (z << 59); //change 27th bit to 1
		
		z = 1;
		x = x | (z << 60); //change 27th bit to 1
		z = 1;
		x = x | (z << 63); //change 27th bit to 1
		
//		EncryptPassword encryptPasswordDao = new EncryptPassword();
//		String resultEncript = encryptPasswordDao.encryptPassword(""+x);
		
//		byte[] byteArrayE = Base64.encodeBase64((""+x).getBytes());
//      String resultEncript = new String(byteArrayE);
		
		String resultEncript = Long.toHexString(x);

		return resultEncript;
	}
	
}
