package com.thbs.repopro.util;

import java.util.ArrayList;
import java.util.List;

public class RelationshipMyModel {
	private int statusCode;
	private String status; // (SUCCESS/FAILURE)
	private String message;
	private List<Object> result = new ArrayList<Object>();
	
	public RelationshipMyModel(int statusCode, String status, String message,
			List<Object> result) {
		this.statusCode = statusCode;
		this.status = status;
		this.message = message;
		this.result = result;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<Object> getResult() {
		return result;
	}
	public void setResult(List<Object> result) {
		this.result = result;
	}
	@Override
	public String toString() {
		return "RelationshipMyModel [statusCode=" + statusCode + ", status="
				+ status + ", message=" + message + ", result=" + result + "]";
	}
	
}
