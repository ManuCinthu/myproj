package com.thbs.repopro.util;

//Java program to demonstrate colored to negative conversion
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

public class InvertImage
{
	//public static void main(String args[])throws IOException
	public InputStream inverImage(InputStream input,String FileName)
	{
		BufferedImage img = null;
		File original = null;
		File inverted = null;
		String extension = "";
		InputStream targetStream = null;
		int ik = FileName.lastIndexOf('.');
		if (ik > 0) {
			extension = FileName.substring(ik+1);
		}
		// read image
		
		// Read from an input stream
	     /* InputStream is = new BufferedInputStream(
	          new FileInputStream("source.gif"));
	      image = ImageIO.read(is);*/
	      
		try
		{
			String invertedPath = System.getProperty("user.home") +  "/inverted."+extension;
		String filePath = addFileTOFolder(invertedPath, input);	
		original = new File(filePath);
			img = ImageIO.read(original);
			original.delete();
		}
		catch(IOException e)
		{
			System.out.println(e);
			original.delete();
		}

		// Get image width and height
		int width = img.getWidth();
		int height = img.getHeight();

		// Convert to negative
		for (int y = 0; y < height; y++)
		{
			for (int x = 0; x < width; x++)
			{
				int p = img.getRGB(x,y);
				int a = (p>>24)&0xff;
				int r = (p>>16)&0xff;
				int g = (p>>8)&0xff;
				int b = p&0xff;

				//subtract RGB from 255
				r = 255 - r;
				g = 255 - g;
				b = 255 - b;

				//set new RGB value
				p = (a<<24) | (r<<16) | (g<<8) | b;
				img.setRGB(x, y, p);
			}
		}

		// write image
		try
		{
			inverted = new File(System.getProperty("user.home")+"/inverted_new."+extension);
			ImageIO.write(img, extension, inverted);
			targetStream = new FileInputStream(inverted);
			//inverted.delete();
		}
		catch(IOException e)
		{
			inverted.delete();
			System.out.println(e);
		}
		return targetStream;
	}
	
	public static byte[] toByteArrayUsingJava(InputStream input)
			throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		int reads = input.read();
		while (reads != -1) {
			baos.write(reads);
			reads = input.read();
		}
		return baos.toByteArray();
	}
	
	
	public String addFileTOFolder(String fileName, InputStream inputStream) throws FileNotFoundException{
		FileOutputStream newImage;
		try {
			newImage = new FileOutputStream(fileName);
			newImage.write(this.toByteArrayUsingJava(inputStream));
			newImage.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return fileName;
	}

}

