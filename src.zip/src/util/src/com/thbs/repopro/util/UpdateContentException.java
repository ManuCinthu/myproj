package com.thbs.repopro.util;

/**
 * @author THBS
 *
 */
public class UpdateContentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param message
	 */
	public UpdateContentException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
