package com.thbs.repopro.util;

import java.util.Random;

public class PasswordGenerator {
	public static char[] randomPwdGenerator(){
		String numbers = "0123456789";
		Random random = new Random();
		char[] randomNumer = new char[6];
		for(int i=0;i<6;i++){
			randomNumer[i] = numbers.charAt(random.nextInt(numbers.length()));
		}
		return randomNumer;
	}
}
