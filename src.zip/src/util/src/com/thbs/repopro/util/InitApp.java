package com.thbs.repopro.util;

import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.MediaTracker;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.commons.io.FileUtils;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.LoginColorConfiguration;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.miscellaneous.CustomImagesDao;

public class InitApp extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5210751003043549270L;

	public void init() throws ServletException{
		
		UserDao userDao = new UserDao();
		List<User> usersList = null;
		Connection conn = null;
		List<AssetDef> assetList = null;
		List<LoginColorConfiguration> List=null ;
		CustomImagesDao customdao = new CustomImagesDao();

		
		AssetDao assetDao = new AssetDao();
		try {
			conn = DBConnection.getInstance().getConnection();
			BufferedImage image = null;
			
			assetList  = assetDao.getAllAssets(conn);
			
			File file4 = new File(System.getProperty("user.home")+"/ThumbnailImages");
	    	if (!file4.exists())
	    	{
	    		if (file4.mkdir()) {
	    			System.out.println("Directory thumbnailimages is created!");
	    		} else {
	    			System.out.println("Failed to create directory thumbnailimages!");
	    		}
	    	}
	    	
			String source = System.getProperty("user.home")+"/ThumbnailImages/";
							
			String target = getServletContext().getRealPath("")+"/images/thumbnailImages/";
			  
			File directory= new File(source);
			
			for (File file : directory.listFiles())
			{ 
				File sourceFile = new File(source+file.getName());
				String name = sourceFile.getName();
				
				if(name.equalsIgnoreCase("Thumbs.db"))
				{
				   continue;
				}
				File targetFile = new File(target+name);
				 try {
					FileUtils.copyFile(sourceFile, targetFile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
			
			
		/*	for (int i = 0; i < usersList.size(); i++) {
				
				if (usersList.get(i).getImageName() != null) {
					
					if(usersList.get(i).getImage() != null){
						
						image = ImageIO.read(usersList.get(i).getImage());

						if (usersList.get(i).getImageName().toLowerCase()
								.indexOf("jpg".toLowerCase()) != -1
								|| usersList.get(i).getImageName().toUpperCase()
								.indexOf("jpg".toUpperCase()) != -1) {

							String uploadedFileLocation = getServletContext()
									.getRealPath("")
									+ "/profileImages/"
									+ usersList.get(i).getUserId()+".jpg";

							ImageIO.write(image, "jpg", new File(
									uploadedFileLocation));

						} else if (usersList.get(i).getImageName().toLowerCase()
								.indexOf("png".toLowerCase()) != -1
								|| usersList.get(i).getImageName().toUpperCase()
								.indexOf("png".toUpperCase()) != -1) {
							String uploadedFileLocation = getServletContext()
									.getRealPath("")
									+ "/profileImages/"
									+ usersList.get(i).getUserId()+".png";

							ImageIO.write(image, "png", new File(
									uploadedFileLocation));

						}
					}
				}
			}
			*/
			//========
			
	
			
			List = customdao.getallThemeConfiguration(conn);
		

			File file41 = new File(System.getProperty("user.home")+"/ClientImages");
	    	if (!file41.exists())
	    	{
	    		if (file41.mkdir()) {
	    			System.out.println("Directory ClientImages is created!");
	    		} else {
	    			System.out.println("Failed to create directory ClientImages!");
	    		}
	    	}
	    	
			String source1 = System.getProperty("user.home")+"/ClientImages/";
							
			String target1 = getServletContext().getRealPath("")+Constants.THEME_FILE_NAME;
			File file1 = new File (getServletContext().getRealPath("")+"/semantic/css/"+"themes.css");
			  
			File directory1= new File(source1);
			
			for (File file : directory1.listFiles())
			{ 
				File sourceFile = new File(source1+file.getName());
				String name = sourceFile.getName();
				
				if(name.equalsIgnoreCase("Images.db"))
				{
				   continue;
				}
				File targetFile = new File(target1+name);
				 try {
					FileUtils.copyFile(sourceFile, targetFile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			for (int i = 0; i < List.size();i++) {
				
			
				String imagename="logoimage";
			
				if (List.get(i).getLogo_filename()!= null) {
					if(List.get(i).getLogoimage()!=null){
						
						image = ImageIO.read(List.get(i).getLogoimage());

						if(image!=null){
							if (List.get(i).getLogo_filename().toLowerCase()
									.indexOf("jpg".toLowerCase()) != -1
									|| List.get(i).getLogo_filename().toUpperCase()
									.indexOf("jpg".toUpperCase()) != -1) {

								String uploadedFileLocation = getServletContext()
										.getRealPath("")
										+Constants.THEME_FILE_NAME
										+imagename+Constants.USERIMAGE_JPG_NAME;
							//	System.out.println(uploadedFileLocation);
								
								ImageIO.write(image, "jpg", new File(
										uploadedFileLocation));
								
							} else if (List.get(i).getLogo_filename().toLowerCase()
									.indexOf("png".toLowerCase()) != -1
									|| List.get(i).getLogo_filename().toUpperCase()
									.indexOf("png".toUpperCase()) != -1) {
								String uploadedFileLocation = getServletContext()
										.getRealPath("")
										+ Constants.THEME_FILE_NAME
										+imagename+Constants.USERIMAGE_PNG_NAME;

								ImageIO.write(image, "png", new File(
										uploadedFileLocation));
								

							}
						}
					
					}
					
				}
			
			
			
					
						String imagename2="themefavicon";
					
						if (List.get(i).getFavicon_filename()!= null) {
							if(List.get(i).getFaviconimage()!=null){
								
								image = ImageIO.read(List.get(i).getFaviconimage());

								if(image!=null){
									if (List.get(i).getFavicon_filename().toLowerCase()
											.indexOf("jpg".toLowerCase()) != -1
											|| List.get(i).getFavicon_filename().toUpperCase()
											.indexOf("jpg".toUpperCase()) != -1) {

										String uploadedFileLocation = getServletContext()
												.getRealPath("")
												+ Constants.THEME_FILE_NAME
												//+ List.get(i)
												+imagename2+Constants.USERIMAGE_JPG_NAME;
										
										ImageIO.write(image, "jpg", new File(
												uploadedFileLocation));
										
									} else if (List.get(i).getFavicon_filename().toLowerCase()
											.indexOf("png".toLowerCase()) != -1
											|| List.get(i).getFavicon_filename().toUpperCase()
											.indexOf("png".toUpperCase()) != -1) {
										String uploadedFileLocation = getServletContext()
												.getRealPath("")
												+ Constants.THEME_FILE_NAME
												//+ List.get(i)
												+imagename2+Constants.USERIMAGE_PNG_NAME;

										ImageIO.write(image, "png", new File(
												uploadedFileLocation));
										
									}
								}
							}
					
					
							
								String imagename3="background";
							
								if (List.get(i).getBackgroundimg_filename()!= null) {
									if(List.get(i).getBackground_image()!=null){
										
										image = ImageIO.read(List.get(i).getBackground_image());

										if(List!=null){
											if (List.get(i).getBackgroundimg_filename().toLowerCase()
													.indexOf("jpg".toLowerCase()) != -1
													|| List.get(i).getBackgroundimg_filename().toUpperCase()
													.indexOf("jpg".toUpperCase()) != -1) {

												String uploadedFileLocation = getServletContext()
														.getRealPath("")
														+ Constants.THEME_FILE_NAME
														//+ List.get(i)
														+imagename3+Constants.USERIMAGE_JPG_NAME;
												
												ImageIO.write(image, "jpg", new File(
														uploadedFileLocation));
												
											} else if (List.get(i).getBackgroundimg_filename().toLowerCase()
													.indexOf("png".toLowerCase()) != -1
													|| List.get(i).getBackgroundimg_filename().toUpperCase()
													.indexOf("png".toUpperCase()) != -1) {
												String uploadedFileLocation = getServletContext()
														.getRealPath("")
														+ Constants.THEME_FILE_NAME
														//+ List.get(i)
														+imagename3+Constants.USERIMAGE_PNG_NAME;

												ImageIO.write(image, "png", new File(
														uploadedFileLocation));
												
											}
										}
									}
							
							
										String imagename4="loginlogo";
									
										if (List.get(i).getLoginPageLogo_filename()!= null) {
											if(List.get(i).getLoginPageLogo()!=null){
												
												image = ImageIO.read(List.get(i).getLoginPageLogo());

												if(image!=null){
													if (List.get(i).getLoginPageLogo_filename().toLowerCase()
															.indexOf("jpg".toLowerCase()) != -1
															|| List.get(i).getLoginPageLogo_filename().toUpperCase()
															.indexOf("jpg".toUpperCase()) != -1) {

														String uploadedFileLocation = getServletContext()
																.getRealPath("")
																+ Constants.THEME_FILE_NAME
																//+ List.get(i)
																+imagename4+Constants.USERIMAGE_JPG_NAME;
														
														ImageIO.write(image, "jpg", new File(
																uploadedFileLocation));
														
													} else if (List.get(i).getLoginPageLogo_filename().toLowerCase()
															.indexOf("png".toLowerCase()) != -1
															|| List.get(i).getLoginPageLogo_filename().toUpperCase()
															.indexOf("png".toUpperCase()) != -1) {
														String uploadedFileLocation = getServletContext()
																.getRealPath("")
																+ Constants.THEME_FILE_NAME
																//+ List.get(i)
																+imagename4+Constants.USERIMAGE_PNG_NAME;

														ImageIO.write(image, "png", new File(
																uploadedFileLocation));
														

													}
												}
										
											}
										}
								}
						}
						}
									
									
									
			
			
			for (int i = 0; i < assetList.size(); i++) {
				if (assetList.get(i).getIconImageName()!= null) {
					if(assetList.get(i).getIconImage()!=null){
						
						image = ImageIO.read(assetList.get(i).getIconImage());

						if(image!=null){
							if (assetList.get(i).getIconImageName().toLowerCase()
									.indexOf("jpg".toLowerCase()) != -1
									|| assetList.get(i).getIconImageName().toUpperCase()
									.indexOf("jpg".toUpperCase()) != -1) {

								String uploadedFileLocation = getServletContext()
										.getRealPath("")
										+ "/assetImages/"
										+ assetList.get(i).getAssetId()+".jpg";
							//	System.out.println(uploadedFileLocation);

								ImageIO.write(image, "jpg", new File(
										uploadedFileLocation));
								
							} else if (assetList.get(i).getIconImageName().toLowerCase()
									.indexOf("png".toLowerCase()) != -1
									|| assetList.get(i).getIconImageName().toUpperCase()
									.indexOf("png".toUpperCase()) != -1) {
								String uploadedFileLocation = getServletContext()
										.getRealPath("")
										+ "/assetImages/"
										+ assetList.get(i).getAssetId()+".png";

								ImageIO.write(image, "png", new File(
										uploadedFileLocation));
								

							}
						}
					}
					
					if(assetList.get(i).getInvertedIconImage() != null) { 
						image = ImageIO.read(assetList.get(i).getInvertedIconImage());
						
						if(image!=null){
							if (assetList.get(i).getIconImageName().toLowerCase()
									.indexOf("jpg".toLowerCase()) != -1
									|| assetList.get(i).getIconImageName().toUpperCase()
									.indexOf("jpg".toUpperCase()) != -1) {
								
								String uploadedFileLocation = getServletContext()
										.getRealPath("")
										+ "/assetImages/"
										+ "inverted_"+assetList.get(i).getAssetId()+".jpg";

								ImageIO.write(image, "jpg", new File(
										uploadedFileLocation));
							
							} else if (assetList.get(i).getIconImageName().toLowerCase()
									.indexOf("png".toLowerCase()) != -1
									|| assetList.get(i).getIconImageName().toUpperCase()
									.indexOf("png".toUpperCase()) != -1) {
								String uploadedFileLocation = getServletContext()
										.getRealPath("")
										+ "/assetImages/"
										+ "inverted_"+assetList.get(i).getAssetId()+".png";

								ImageIO.write(image, "png", new File(
										uploadedFileLocation));
								
							}
							
							
						}
					}
				}
			}
			
			List<AssetInstanceVersion> staticaiv = new ArrayList<AssetInstanceVersion>();
			List<AssetInstanceVersion> nonstaticaiv = new ArrayList<AssetInstanceVersion>();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			nonstaticaiv = assetInstanceVersionDao.retNonStaticParameterDetail(conn);
			staticaiv = assetInstanceVersionDao.retStaticParameterDetail(conn);
			
			for (int i = 0; i < nonstaticaiv.size(); i++) {
				
				if (nonstaticaiv.get(i).getFileName() != null) {
					
					if(nonstaticaiv.get(i).getFilecontent() != null){
						
						image = ImageIO.read(nonstaticaiv.get(i).getFilecontent());

						if (nonstaticaiv.get(i).getFileName() .toLowerCase()
								.indexOf("jpg".toLowerCase()) != -1
								|| nonstaticaiv.get(i).getFileName().toUpperCase()
								.indexOf("jpg".toUpperCase()) != -1) {

							String uploadedFileLocation = getServletContext()
									.getRealPath("")
									+ "/images/thumbnailImages/"
									+ nonstaticaiv.get(i).getAssetInstParamId()+"_"+nonstaticaiv.get(i).getFileName();
							MediaTracker mediaTracker = new MediaTracker(new Container());
							mediaTracker.addImage(image, 0);
							mediaTracker.waitForID(0);
							int thumbWidth = 60;
							int thumbHeight = 60;
							int quality = 100;

							double thumbRatio = (double) thumbWidth / (double) thumbHeight;
							int imageWidth = image.getWidth(null);
							int imageHeight = image.getHeight(null);
							double imageRatio = (double) imageWidth / (double) imageHeight;
							if (thumbRatio < imageRatio) {
								thumbHeight = (int) (thumbWidth / imageRatio);
							} else {
								thumbWidth = (int) (thumbHeight * imageRatio);
							}
							BufferedImage thumbImage = new BufferedImage(thumbWidth, thumbHeight, BufferedImage.TYPE_INT_RGB);
							Graphics2D graphics2D = thumbImage.createGraphics();
							graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
									RenderingHints.VALUE_INTERPOLATION_BILINEAR);
							graphics2D.drawImage(image, 0, 0, thumbWidth, thumbHeight, null);
							
							ImageIO.write(thumbImage, "jpg", new File(
									uploadedFileLocation));

						} else if (nonstaticaiv.get(i).getFileName().toLowerCase()
								.indexOf("png".toLowerCase()) != -1
								|| nonstaticaiv.get(i).getFileName().toUpperCase()
								.indexOf("png".toUpperCase()) != -1) {
							String uploadedFileLocation = getServletContext()
									.getRealPath("")
									+ "/images/thumbnailImages/"
									+ nonstaticaiv.get(i).getAssetInstParamId()+"_"+nonstaticaiv.get(i).getFileName();
							
							MediaTracker mediaTracker = new MediaTracker(new Container());
							mediaTracker.addImage(image, 0);
							mediaTracker.waitForID(0);
							int thumbWidth = 60;
							int thumbHeight = 60;
							int quality = 100;

							double thumbRatio = (double) thumbWidth / (double) thumbHeight;
							int imageWidth = image.getWidth(null);
							int imageHeight = image.getHeight(null);
							double imageRatio = (double) imageWidth / (double) imageHeight;
							if (thumbRatio < imageRatio) {
								thumbHeight = (int) (thumbWidth / imageRatio);
							} else {
								thumbWidth = (int) (thumbHeight * imageRatio);
							}
							BufferedImage thumbImage = new BufferedImage(thumbWidth, thumbHeight, BufferedImage.TYPE_INT_RGB);
							Graphics2D graphics2D = thumbImage.createGraphics();
							graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
									RenderingHints.VALUE_INTERPOLATION_BILINEAR);
							graphics2D.drawImage(image, 0, 0, thumbWidth, thumbHeight, null);
							
							ImageIO.write(thumbImage, "png", new File(
									uploadedFileLocation));

						}
					}
				}
			}
			for (int i = 0; i < staticaiv.size(); i++) {
				
				if (staticaiv.get(i).getFileName() != null) {
					
					if(staticaiv.get(i).getFilecontent() != null){
						
						image = ImageIO.read(staticaiv.get(i).getFilecontent());

						if (staticaiv.get(i).getFileName() .toLowerCase()
								.indexOf("jpg".toLowerCase()) != -1
								|| staticaiv.get(i).getFileName().toUpperCase()
								.indexOf("jpg".toUpperCase()) != -1) {

							String uploadedFileLocation = getServletContext()
									.getRealPath("")
									+ "/images/thumbnailImages/"
									+ staticaiv.get(i).getAssetParamId()+"_"+staticaiv.get(i).getFileName();
							MediaTracker mediaTracker = new MediaTracker(new Container());
							mediaTracker.addImage(image, 0);
							mediaTracker.waitForID(0);
							int thumbWidth = 60;
							int thumbHeight = 60;
							int quality = 100;

							double thumbRatio = (double) thumbWidth / (double) thumbHeight;
							int imageWidth = image.getWidth(null);
							int imageHeight = image.getHeight(null);
							double imageRatio = (double) imageWidth / (double) imageHeight;
							if (thumbRatio < imageRatio) {
								thumbHeight = (int) (thumbWidth / imageRatio);
							} else {
								thumbWidth = (int) (thumbHeight * imageRatio);
							}
							BufferedImage thumbImage = new BufferedImage(thumbWidth, thumbHeight, BufferedImage.TYPE_INT_RGB);
							Graphics2D graphics2D = thumbImage.createGraphics();
							graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
									RenderingHints.VALUE_INTERPOLATION_BILINEAR);
							graphics2D.drawImage(image, 0, 0, thumbWidth, thumbHeight, null);
							
							ImageIO.write(thumbImage, "jpg", new File(
									uploadedFileLocation));

						} else if (staticaiv.get(i).getFileName().toLowerCase()
								.indexOf("png".toLowerCase()) != -1
								|| staticaiv.get(i).getFileName().toUpperCase()
								.indexOf("png".toUpperCase()) != -1) {
							String uploadedFileLocation = getServletContext()
									.getRealPath("")
									+ "/images/thumbnailImages/"
									+ staticaiv.get(i).getAssetParamId()+"_"+staticaiv.get(i).getFileName();
							MediaTracker mediaTracker = new MediaTracker(new Container());
							mediaTracker.addImage(image, 0);
							mediaTracker.waitForID(0);
							int thumbWidth = 60;
							int thumbHeight = 60;
							int quality = 100;

							double thumbRatio = (double) thumbWidth / (double) thumbHeight;
							int imageWidth = image.getWidth(null);
							int imageHeight = image.getHeight(null);
							double imageRatio = (double) imageWidth / (double) imageHeight;
							if (thumbRatio < imageRatio) {
								thumbHeight = (int) (thumbWidth / imageRatio);
							} else {
								thumbWidth = (int) (thumbHeight * imageRatio);
							}
							BufferedImage thumbImage = new BufferedImage(thumbWidth, thumbHeight, BufferedImage.TYPE_INT_RGB);
							Graphics2D graphics2D = thumbImage.createGraphics();
							graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
									RenderingHints.VALUE_INTERPOLATION_BILINEAR);
							graphics2D.drawImage(image, 0, 0, thumbWidth, thumbHeight, null);
							
							ImageIO.write(thumbImage, "png", new File(
									uploadedFileLocation));

						}
					}
				}
			}
			//======================
			 String userHome = System.getProperty("user.home");
			 FileInputStream fstream = null;
			 CommonUtils util = new CommonUtils();
			 try{
				  fstream = new FileInputStream(userHome + "/RepoProLdap.txt");
				  // Get the object of DataInputStream
				  DataInputStream in = new DataInputStream(fstream);
				  BufferedReader br = new BufferedReader(new InputStreamReader(in));
				  String strLine;
				  //Read File Line By Line
				  while ((strLine = br.readLine()) != null)   {
				  // Print the content on the console
					  String[] keyValue = strLine.split("=",2);
					  if(keyValue[0].equalsIgnoreCase("LdapHost"))
						  CommonUtils.LdapHost = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapPort"))
						  CommonUtils.LdapPort = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapAuthenticationType"))
						  CommonUtils.LdapAuthenticationType = keyValue[1];	
					  else if(keyValue[0].equalsIgnoreCase("LdapBaseDn")){
						  CommonUtils.LdapBaseDn = keyValue[1];
					  }
					  else if(keyValue[0].equalsIgnoreCase("LdapSearchFilter")){
						  CommonUtils.LdapSearchFilter = keyValue[1];
					  }
					  else if(keyValue[0].equalsIgnoreCase("LdapAuthenticationUserName")){
						  CommonUtils.LdapUserName = keyValue[1];
					  }
					  else if(keyValue[0].equalsIgnoreCase("LdapAuthenticationPassword")){
						  CommonUtils.LdapPassword = keyValue[1];
					  }
					  else if(keyValue[0].equalsIgnoreCase("LdapActiveDirectory")){
						  CommonUtils.LdapActiveDirectory = keyValue[1];
					  }
					  else if(keyValue[0].equalsIgnoreCase("LdapUserName"))
						  CommonUtils.LdapUserId = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapFirstName"))
						  CommonUtils.LdapFirstName = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapLastName"))
						  CommonUtils.LdapLastName = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapEmail"))
						  CommonUtils.LdapEmail = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapDepartment"))
						  CommonUtils.LdapDept = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapKeyRequired"))
						  CommonUtils.LdapKeyRequired = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapCertificateDetails"))
						  CommonUtils.LdapCertificateDetails = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapFullName"))
						  CommonUtils.LdapFullName = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapRefferal"))
						  CommonUtils.LdapRefferal = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapTrustStorePassword"))
						  CommonUtils.LdapTrustStorePassword = keyValue[1];
					  else if(keyValue[0].equalsIgnoreCase("LdapWildCardSearch"))
						  CommonUtils.LdapWildCardSearch = keyValue[1];

					
				  }
			 }catch(IOException e){
				 	e.printStackTrace();			 
			 }
			//======================
			 
			 /* Start Properties read from repoPro.properties for SAML SSO */
			 
			 InputStream inputStream = null;
			 CommonUtils commonUtils = new CommonUtils();
				Properties p = new Properties();
				String home = System.getProperty("user.home");
				try {
					inputStream = new FileInputStream(home + "/RepoPro.properties");
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					p.load(inputStream);
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				commonUtils.trustStorePath = (String) p.get("TrustStorePath");
				commonUtils.trustStorePassword = (String) p.get("TrustStorePassword");
				commonUtils.oAuthEndPoint = (String) p.get("OAuth_Token_End_Point");
				commonUtils.clientId = (String) p.get("client_id");
				commonUtils.grantType = (String) p.get("grant_type");
				commonUtils.clientSecret = (String) p.get("client_secret");
				commonUtils.xpath = (String) p.get("samlXpath");
				commonUtils.samlAssertionFirstName = (String) p.get("samlFirstName");
				commonUtils.samlAssertionLastName = (String) p.get("samlLastName");
				commonUtils.samlAssertionMailID = (String) p.get("samlmailId");
				commonUtils.defaultDeptForSAML = (String) p.get("defaultDepartmentNameForSAML");
				commonUtils.defaultFirstNameForSAML = (String) p.get("defaultFirstNameForSAML");
				commonUtils.defaultLastNameForSAML = (String) p.get("defaultLastNameForSAML");
				commonUtils.defaultMailForSAML = (String) p.get("defaultEmailForSAML");
				CommonUtils.responseSkew = (String) p.get("responseSkew");
				commonUtils.encryptionKey = (String) p.get("encryptionKey");
				
				CommonUtils.pluginClassName = (String) p.get("oauth.plugin.class");
				CommonUtils.pluginPath = (String) p.get("oauth.plugin.path");
 
				/* End Properties read from repoPro.properties for SAML SSO */
				
				/*customparamter plugin path reader*/
				CommonUtils.customParameterPluginNoficationClassName = (String) p.get("customParameterNotification.plugin.class");
				CommonUtils.customParameterPluginPath = (String) p.get("customParameter.plugin.path");
				
					
					try {
						PluginUtlities.setplugin();
						CustomParameterPluginUtilies.setplugin();
					} catch (ClassNotFoundException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					
					/* End Properties read from oauth-server.properties oAuth */
					
					usersList = userDao.getUsers(true,conn);
					for (int i = 0; i < usersList.size(); i++) {
						
						if (usersList.get(i).getImageName() != null) {
							
							if(usersList.get(i).getImage() != null){
								
								image = ImageIO.read(usersList.get(i).getImage());

								if (usersList.get(i).getImageName().toLowerCase()
										.indexOf("jpg".toLowerCase()) != -1
										|| usersList.get(i).getImageName().toUpperCase()
										.indexOf("jpg".toUpperCase()) != -1) {

									String uploadedFileLocation = getServletContext()
											.getRealPath("")
											+ "/profileImages/"
											+ usersList.get(i).getUserId()+".jpg";

									ImageIO.write(image, "jpg", new File(
											uploadedFileLocation));

								} else if (usersList.get(i).getImageName().toLowerCase()
										.indexOf("png".toLowerCase()) != -1
										|| usersList.get(i).getImageName().toUpperCase()
										.indexOf("png".toUpperCase()) != -1) {
									String uploadedFileLocation = getServletContext()
											.getRealPath("")
											+ "/profileImages/"
											+ usersList.get(i).getUserId()+".png";

									ImageIO.write(image, "png", new File(
											uploadedFileLocation));

								}
							}
						}
					}
	
					
		}catch (Exception e) {
			e.printStackTrace();
			
		} finally {
				
			DBConnection.closeDbConnection(conn);
		}
		
		
	}
}
		
   	
	
	
	

