package com.thbs.repopro.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.thbs.repopro.dto.GroupDetails;

/**
 * @author THBS
 *
 */
public class MyModel {
	private int statusCode;
	private String status; // (SUCCESS/FAILURE)
	private String message;
	private List<Object> result = new ArrayList<Object>();
	private Map<String,String> paramValues;
	private HashMap<String, List<LinkedHashMap<String, String>>> finalMap;
	private Map<Long, Set<GroupDetails>> categoryValues ;

	public MyModel(int statusCode, String status, String message,
			List<Object> result, Map<String, String> paramValues,
			HashMap<String, List<LinkedHashMap<String, String>>> finalMap,
			Map<Long, Set<GroupDetails>> details) {
		super();
		this.statusCode = statusCode;
		this.status = status;
		this.message = message;
		this.result = result;
		this.paramValues = paramValues;
		this.finalMap = finalMap;
		this.categoryValues = details;
	}

/*	public MyModel(int statusCode, String status, String message,
			HashMap<String, List<LinkedHashMap<String, String>>> finalMap) {
		super();
		this.statusCode = statusCode;
		this.status = status;
		this.message = message;
		this.finalMap = finalMap;
	}*/

	public HashMap<String, List<LinkedHashMap<String, String>>> getFinalMap() {
		return finalMap;
	}

	public void setFinalMap(HashMap<String, List<LinkedHashMap<String, String>>> finalMap) {
		this.finalMap = finalMap;
	}

	public Map<Long, Set<GroupDetails>> getCategoryValues() {
		return categoryValues;
	}

	public void setCategoryValues(Map<Long, Set<GroupDetails>> categoryValues) {
		this.categoryValues = categoryValues;
	}

	public MyModel(int statusCode, String status, String message,
			Map<String, String> paramValues) {
		super();
		this.statusCode = statusCode;
		this.status = status;
		this.message = message;
		this.paramValues = paramValues;
	}

	public Map<String, String> getParamValues() {
		return paramValues;
	}

	public void setParamValues(Map<String, String> paramValues) {
		this.paramValues = paramValues;
	}

	/**
	 * 
	 */
	public MyModel() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param statusCode
	 * @param status
	 * @param message
	 */
	public MyModel(int statusCode, String status, String message) {
		this.statusCode = statusCode;
		this.status = status;
		this.message = message;
	}

	/**
	 * @param statusCode
	 * @param status
	 * @param message
	 * @param result
	 */
	public MyModel(int statusCode, String status, String message,
			List<Object> result) {
		this.statusCode = statusCode;
		this.status = status;
		this.message = message;
		this.result = result;
	}

	/**
	 * @return
	 */
	public int getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return
	 */
	public List<Object> getResult() {
		return result;
	}

	/**
	 * @param result
	 */
	public void setResult(List<Object> result) {
		this.result = result;
	}
	

	@Override
	public String toString() {
		return "MyModel [statusCode=" + statusCode + ", status=" + status + ", message=" + message + ", result="
				+ result + "]";
	}

}
