package com.thbs.repopro.util;


import java.sql.Connection;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Ordering;
import com.google.common.collect.TreeMultimap;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.gamification.GamificationDao;

public class LeaderBoardUtil {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	public static Map<String, Integer> getLeaderBoardRank(String userName) throws RepoproException{

		Connection conn = null;

		Map<String, Integer> mapList = new LinkedHashMap<String, Integer>();
		TreeMultimap<Integer, String> usr_percentage = TreeMultimap.create(
				Ordering.natural().reverse(), Ordering.natural());
		List<String> list = new LinkedList<String>();
		GamificationDao GamificationDao = new GamificationDao();
		UserDao userDao = new UserDao();
		List<User> userlist = new ArrayList<User>();
		try {
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getleaderboardRank || dao call of getAllUserProfiles() method to retrieve user list");
			}
			userlist = userDao.getAllActiveUsers(userName, conn);

			for (int i = 0; i < userlist.size(); i++) {
				if (log.isTraceEnabled()) {
					log.trace("getleaderboardRank || dao call of retGamificationPoints() method to calculate total points obtained by each user");
				}
				String Point = GamificationDao.retGamificationPoints(userlist
						.get(i).getUserId(), conn);

				if (Point != null) {
					int data = Integer.parseInt(Point);
					if (data > 0) {
						usr_percentage.put(data, userlist.get(i).getFullName()
								+ "~" + userlist.get(i).getUserId() + "~"
								+ userlist.get(i).getImageName() + "~" + userlist.get(i).getEncryptImage());
					}
				}

			}
			
			for (Entry<Integer, String> entry : usr_percentage.entries()) {

				list.add(entry.getKey() + "~" + entry.getValue());

			}

			int rank = 0;
			double weitage = -1;
			for (String value : list) {
				String gamePoint4 = value.substring(0, value.indexOf("~"));
				double val1 = Double.parseDouble(gamePoint4);

				if (val1 != weitage) {
					rank += 1;
				}

				mapList.put(value, rank);
				weitage = val1;
			}
		}  catch (RepoproException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}  catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return mapList;
	}
	
	
	public static Map<String, Integer> getLeaderBoardRankForExport(String userName) throws RepoproException{

		Connection conn = null;

		Map<String, Integer> mapList = new LinkedHashMap<String, Integer>();
		TreeMultimap<Integer, String> usr_percentage = TreeMultimap.create(
				Ordering.natural().reverse(), Ordering.natural());
		List<String> list = new LinkedList<String>();
		GamificationDao GamificationDao = new GamificationDao();
		UserDao userDao = new UserDao();
		List<User> userlist = new ArrayList<User>();
		try {
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getLeaderBoardRankForExport || dao call of getAllUserProfiles() method to retrieve user list");
			}
			userlist = userDao.getAllActiveUsersForExport(userName, conn);

			for (int i = 0; i < userlist.size(); i++) {
				if (log.isTraceEnabled()) {
					log.trace("getLeaderBoardRankForExport || dao call of retGamificationPoints() method to calculate total points obtained by each user");
				}
				String Point = GamificationDao.retGamificationPoints(userlist
						.get(i).getUserId(), conn);

				if (Point != null) {
					int data = Integer.parseInt(Point);
					if (data > 0) {
						usr_percentage.put(data, userlist.get(i).getFullName()
								+ "~" + userlist.get(i).getUserId() + "~"
								+ userlist.get(i).getImageName());
					}
				}

			}
			
			for (Entry<Integer, String> entry : usr_percentage.entries()) {

				list.add(entry.getKey() + "~" + entry.getValue());

			}

			int rank = 0;
			double weitage = -1;
			for (String value : list) {
				String gamePoint4 = value.substring(0, value.indexOf("~"));
				double val1 = Double.parseDouble(gamePoint4);

				if (val1 != weitage) {
					rank += 1;
				}

				mapList.put(value, rank);
				weitage = val1;
			}
		}  catch (RepoproException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}  catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return mapList;
	}
}
