package com.thbs.repopro.taxonomies;

import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.thbs.repopro.accesscontrol.RoleDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstVersionTaxonomy;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.dto.ParentModel;
import com.thbs.repopro.dto.TaggingMaster;
import com.thbs.repopro.dto.TaxonomyMaster;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.dto.UserTaxonomySubscription;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;

@Path("/taxonomy")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class TaxonomiesManager {
	private final static Logger log = LoggerFactory.getLogger("timeBased");
	boolean rr;
	ParentModel retPM = null;
	private	Map<Long, List<TaxonomyMaster>> allTaxs =  null;
	List<Long> associatedTaxId = new ArrayList<Long>();
	
	void recurse(TaxonomyMaster t){

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);
			allTaxs.put(t.getTaxonomyId(), chldrn);
			for(TaxonomyMaster i: chldrn)
				recurse(i);
		}
		catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("TaxonomiesManager || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

	}

	void  recurse1(TaxonomyMaster t){

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);

			for(TaxonomyMaster a: chldrn){

				TaxonomyMaster t1 = new TaxonomyMaster();
				t1.setTaxonomyId(a.getTaxonomyId());
				t1.setTaxonomyName(a.getTaxonomyName());
				recurse1(t1);
				associatedTaxId.add(a.getTaxonomyId());
				associatedTaxId.add(t.getTaxonomyId());

			}
			associatedTaxId.add(t.getTaxonomyId());

		}catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("TaxonomiesManager || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
	}
	
	
	/**
	 * @method getAllTaxonomies
	 * @description get the list of taxonomies
	 * @return success response
	 */
	@GET
	@Path("/getTaxonomy")
	public Response getAllTaxonomies() {

		log.trace("getAllTaxonomies || Begin");
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
		TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
		List<ParentModel> parentModels = new ArrayList<ParentModel>();
		List<Long> taxonomyIds = new ArrayList<Long>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomies() || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomies() || call of dao getAllTaxonomies method to get list of taxonomies");
			}
			allTxs = taxonomiesDao.getAllTaxonomies(conn);

			for (TaxonomyMaster tm1 : allTxs) {

				if (tm1.getTaxonomyId() != 1) {

					taxonomyIds.add(tm1.getTaxonomyId());
					Long taxonId1 = tm1.getParenttaxonomyId();
					String taxxName = tm1.getTaxonomyName() + "|"+ tm1.getTaxonomyId();
					String taxoonName = null;
					for (TaxonomyMaster t1 : allTxs) {
						if (t1.getTaxonomyId().equals(taxonId1)) {
							taxoonName = t1.getTaxonomyName() + "|"+ t1.getTaxonomyId();
						}
					}

					long longTaxId = 1;

					if (taxonId1 == longTaxId) {
						ParentModel parentModel1 = new ParentModel(taxxName,null);
						parentModels.add(parentModel1);
					} else {
						rr = false;
						recurse(parentModels, taxoonName, taxxName);
					}
				}
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomies() || " + parentModels.size()
						+ " taxonomies retrieved successfully");
			}
			conn.commit();
			retMsg = Constants.TAXONOMY_DATA_OBTAINED;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} catch (RepoproException e) {
			log.error("getAllTaxonomies ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllTaxonomies ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("getAllTaxonomies() ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllTaxonomies() || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(parentModels))).build();
	}

	
	/**
	 * @method getAllTaxonomiesWithSubcription
	 * @param userId
	 * @return success response
	 */
	@GET
	@Path("/getAllTaxonomiesWithSubcription")
	public Response getAllTaxonomiesWithSubcription(@QueryParam("userId") Long userId) {

		log.trace("getAllTaxonomiesWithSubcription || Begin");
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
		TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
		List<ParentModel> parentModels = new ArrayList<ParentModel>();
		List<Long> taxonomyIds = new ArrayList<Long>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubcription() || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubcription() || call of dao getAllTaxonomies method to get list of taxonomies");
			}
			allTxs = taxonomiesDao.getAllTaxonomiesWithSubscription(userId, conn);

			for (TaxonomyMaster tm1 : allTxs) {

				if (tm1.getTaxonomyId() != 1) {

					taxonomyIds.add(tm1.getTaxonomyId());
					Long taxonId1 = tm1.getParenttaxonomyId();
					String taxxName = tm1.getTaxonomyName() + "|"+ tm1.getTaxonomyId()+"|"+tm1.getSubscription();
					String taxoonName = null;
					for (TaxonomyMaster t1 : allTxs) {
						if (t1.getTaxonomyId().equals(taxonId1)) {
							taxoonName = t1.getTaxonomyName() + "|"+ t1.getTaxonomyId()+"|"+t1.getSubscription();
						}
					}

					long longTaxId = 1;

					if (taxonId1 == longTaxId) {
						ParentModel parentModel1 = new ParentModel(taxxName,null);
						parentModels.add(parentModel1);
					} else {
						rr = false;
						recurse(parentModels, taxoonName, taxxName);
					}
				}
			}
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubcription() || " + parentModels.size()
						+ " taxonomies retrieved successfully");
			}
			conn.commit();
			
			if (parentModels.isEmpty()) {
				retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.TAXONOMY_DATA_OBTAINED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAllTaxonomiesWithSubcription ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllTaxonomiesWithSubcription ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("getAllTaxonomiesWithSubcription() ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllTaxonomiesWithSubcription() || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(parentModels))).build();
	}
	
	/**
	 * @method getAllTaxonomiesWithSubcriptionUsedByAssets
	 * @param userId
	 * @return
	 */
	@GET
	@Path("/getAllTaxonomiesWithSubcriptionUsedByAsset")
	public Response getAllTaxonomiesWithSubcriptionUsedByAssets(@QueryParam("userName") String userName) {

		log.trace("getAllTaxonomiesWithSubcription || Begin");
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
	
		TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
		List<ParentModel> parentModels = new ArrayList<ParentModel>();
		List<Long> taxonomyIds = new ArrayList<Long>();
	    List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
		List<TaxonomyMaster> allTxsList = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster parentTaxonomy = new TaxonomyMaster();
		List<TaxonomyMaster> allTx1 = new ArrayList<TaxonomyMaster>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubcriptionUsedByAsset() || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubcriptionUsedByAsset() || call of dao method getAllTaxonomyUsedByAssets to get taxonomy list used by asset instance versions");
			}
			allTxs = taxonomiesDao.getAllTaxonomyUsedByAssets(conn);
			Long parentTaxId = 0L;
			for(TaxonomyMaster tm:allTxs){
				parentTaxonomy = taxonomiesDao.getTaxonomiesByParentId(tm.getParenttaxonomyId(), conn);
				parentTaxId = parentTaxonomy.getTaxonomyId();
				if(parentTaxId != 0 && parentTaxId != 1){
					while(parentTaxId != 1){
						if(!allTx1.contains(parentTaxonomy)){
							allTx1.add(parentTaxonomy);
						}
						parentTaxonomy = taxonomiesDao.getTaxonomiesByParentId(parentTaxonomy.getParenttaxonomyId(), conn); 
						parentTaxId = parentTaxonomy.getTaxonomyId();
					}
				}
			}
			allTx1.addAll(allTxs);
			Set<TaxonomyMaster> allDataSet = new HashSet<TaxonomyMaster>();
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubcriptionUsedByAsset() || call of dao method getAllTaxonomies to get taxonomy list");
			}
			allTxsList = taxonomiesDao.getAllTaxonomies(conn);
			allDataSet.addAll(allTx1);
			allTx1.clear();
			allTx1.addAll(allDataSet);
			Collections.sort(allTx1, new TaxonomyMaster());
			for (TaxonomyMaster tm1 : allTx1) {
				if (tm1.getTaxonomyId() != 1) {
                    TaxonomyMaster subscription = taxonomiesDao.getTaxonomiesWithSubscription(userName, tm1.getTaxonomyId(), conn);
                    if(subscription != null){
                    	taxonomyIds.add(tm1.getTaxonomyId());
                    	Long taxonId1 = tm1.getParenttaxonomyId();
                    	String taxxName = tm1.getTaxonomyName() + "|"+ tm1.getTaxonomyId()+"|"+subscription.getSubscription();
                    	String taxoonName = null;
                    	for (TaxonomyMaster t1 : allTxsList) {
                    		if (t1.getTaxonomyId().equals(taxonId1)) {
                    			TaxonomyMaster subData = taxonomiesDao.getTaxonomiesWithSubscription(userName, taxonId1, conn);
                    			if(subData != null){
                    				taxoonName = t1.getTaxonomyName() + "|"+ t1.getTaxonomyId()+"|"+subData.getSubscription();
                    				break;
                    			}
                    		}
                    	}

                    	long longTaxId = 1;

                    	if (taxonId1 == longTaxId) {
                    		ParentModel parentModel1 = new ParentModel(taxxName,null);
                    		parentModels.add(parentModel1);
                    	} else {
                    		rr = false;
                    		recurse(parentModels, taxoonName, taxxName);
                    	}
                    }
				}
			}
			
			if (parentModels.isEmpty()) {
				retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.TAXONOMY_DATA_OBTAINED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		
		} catch (RepoproException e) {
			log.error("getAllTaxonomiesWithSubcriptionUsedByAssets ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllTaxonomiesWithSubcriptionUsedByAssets ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("getAllTaxonomiesWithSubcriptionUsedByAssets() ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllTaxonomiesWithSubcriptionUsedByAssets() || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(parentModels))).build();
	}
	
	public void recurse(List<ParentModel> pm, String parentTaxName,
			String taxName) {

		for (int r = 0; !rr && r < pm.size(); r++) {
			if (pm.get(r).getLabel().equalsIgnoreCase(parentTaxName)) {

				ParentModel parentModel1 = new ParentModel(taxName, null);

				if (pm.get(r).getChildren() == null) {
					List<ParentModel> nn = new ArrayList<ParentModel>();
					pm.get(r).setChildren(nn);
				}
				pm.get(r).getChildren().add(parentModel1);
				rr = true;
				return;
			} else if (pm.get(r).getChildren() != null) {

				recurse(pm.get(r).getChildren(), parentTaxName, taxName);

			}
		}
	}
	
	
	/**
	 * @method addTaxonomyName
	 * @description add taxonomy details
	 * @param taxonomyName
	 * @param parentTaxonomyId
	 * @return success response
	 */
	@POST
	@Path("/addTaxonomyName")
	public Response addTaxonomyName(
			@QueryParam("taxonomyName") String taxonomyName,
			@QueryParam("parentTaxonomyId") Long parentTaxonomyId)throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyName ||taxonomyName:" + taxonomyName
					+ "parentTaxonomyId:" + parentTaxonomyId + " Begin");
		}

		Connection conn = null;
		List<TaxonomyMaster> taxonomiesManagerList = new ArrayList<TaxonomyMaster>();
		List<TaxonomyMaster> taxonomyList = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomyMaster = null;
		TaxonomyMaster taxonomyByParentId = null;
		boolean flagForDuplicateTaxonomyname = false;
		TaxonomiesDao dao = new TaxonomiesDao();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyName || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyName || dao method called : getTaxonomiesByParentId() to taxonomy by parent id");
			}
			
			taxonomyName = taxonomyName.trim();
			
			taxonomyByParentId = new TaxonomyMaster();
			taxonomyByParentId = dao.getTaxonomiesByParentId(parentTaxonomyId, conn);
			if(taxonomyByParentId.getTaxonomyName().equalsIgnoreCase(taxonomyName)){
				flagForDuplicateTaxonomyname = true;	
			}
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyName || dao method called : getAllTaxonomiesByParentId() to get list of taxonomies by parent id");
			}
			taxonomyList = dao.getAllTaxonomiesByParentId(parentTaxonomyId,conn);
			for (TaxonomyMaster taxonomy : taxonomyList) {
				if (taxonomy.getTaxonomyName().equalsIgnoreCase(taxonomyName)) {
					flagForDuplicateTaxonomyname = true;
				}
			}

			if (flagForDuplicateTaxonomyname == true) {
				log.warn("addTaxonomyName || Taxonomy by this name already exists, please provide different name");

				return Response
						.status(Status.OK)
						.entity(new MyModel(
								Constants.INSERT_STATUS_SUCCESS,
								Constants.FAILURE,
								MessageUtil
										.getMessage(Constants.TAXONOMY_NAME_EXIST))).build();

			} else {
				taxonomyMaster = new TaxonomyMaster();
				if (log.isTraceEnabled()) {
					log.trace("addTaxonomyName || dao method called : addTaxonomyName() to add taxonomy details");
				}
				taxonomyMaster = dao.addTaxonomyName(taxonomyName,parentTaxonomyId, conn);
				taxonomiesManagerList.add(taxonomyMaster);
			}
			
			List<String> emailIds = dao.getAllTaxonomySubscribers(conn, parentTaxonomyId);
			
			MailTemplateDao mailTemplateDao = new MailTemplateDao();
			String mailTemp = "";
			
			MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"addTaxonomyName");
			mailTemp = mtVo.getMailTemplate();
			mailTemp = mailTemp.replaceAll("%childTaxonomyName%", taxonomyName).replaceAll("%parentTaxonomyName%", taxonomyByParentId.getTaxonomyName());
			for(String emailId:emailIds){
				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
			}

			retMsg = Constants.TAXONOMY_CREATED;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;

			log.info(" addTaxonomyName|| added Taxonomy successfully");

			conn.commit();

		} catch (RepoproException e) {
			log.error("addTaxonomyName ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("addTaxonomyName ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyName || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyName ||taxonomyName:" + taxonomyName
					+ "parentTaxonomyId:" + parentTaxonomyId + "End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(taxonomiesManagerList))).build();

	}

	/**
	 * @method updateTaxonomyName
	 * @description update taxonomy name
	 * @param taxonomyName
	 * @param oldTaxonomyId
	 * @return success response
	 */
	@PUT
	@Path("/updateTaxonomyName")
	public Response updateTaxonomyName(
			@QueryParam("taxonomyName") String taxonomyName,
			@QueryParam("oldTaxonomyId") Long oldTaxonomyId)throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("updateTaxonomyName ||taxonomyName:" + taxonomyName
					+ "oldTaxonomyId:" + oldTaxonomyId + "Begin");
		}

		Connection conn = null;
		List<TaxonomyMaster> taxonomyList = new ArrayList<TaxonomyMaster>();
		List<TaxonomyMaster> taxonomyListByParentId = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomyByTaxId = null;
		TaxonomyMaster taxonomyByParentId = null;
		boolean flagForDuplicateTaxonomyname = false;
		TaxonomiesDao dao = new TaxonomiesDao();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			taxonomyByTaxId = new TaxonomyMaster();
			taxonomyByParentId = new TaxonomyMaster();

			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName ||call of  dao method getTaxonomiesByTaxId() to get taxonomy detail by taxonomy id");
			}
			taxonomyByTaxId = dao.getTaxonomiesByTaxId(oldTaxonomyId, conn);
			String oldTaxName = taxonomyByTaxId.getTaxonomyName();
			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName ||call of  dao method getAllTaxonomiesByParentId() to get list of taxonomies by taxonomy id");
			}
			taxonomyList = dao.getAllTaxonomiesByParentId(oldTaxonomyId, conn);

			for (TaxonomyMaster taxonomy : taxonomyList) {
				if (taxonomy.getTaxonomyName().equalsIgnoreCase(taxonomyName)) {
					flagForDuplicateTaxonomyname = true;
				}
			}

			Long parentId = taxonomyByTaxId.getParenttaxonomyId();

			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName ||call of  dao method getTaxonomiesByParentId() to get taxonomy detail by parent id");
			}
			taxonomyByParentId = dao.getTaxonomiesByParentId(parentId, conn);
			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName ||call of  dao method getAllTaxonomiesByParentId() to get list of taxonomies by parent id");
			}
			taxonomyListByParentId = dao.getAllTaxonomiesByParentId(parentId,conn);

			for (TaxonomyMaster val : taxonomyListByParentId) {
				if (!taxonomyName.equalsIgnoreCase(oldTaxName)
						&& taxonomyName.equalsIgnoreCase(val.getTaxonomyName())) {
					flagForDuplicateTaxonomyname = true;
				}
			}

			if (taxonomyName.equalsIgnoreCase(taxonomyByParentId.getTaxonomyName())) {
				flagForDuplicateTaxonomyname = true;
			}

			if (flagForDuplicateTaxonomyname == true) {
				log.warn("updateTaxonomyName || Taxonomy by this name already exists, please provide different name");

				return Response
						.status(Status.OK)
						.entity(new MyModel(
								Constants.INSERT_STATUS_SUCCESS,
								Constants.FAILURE,
								MessageUtil
										.getMessage(Constants.TAXONOMY_NAME_EXIST)))
						.build();

			} else {
				if (log.isTraceEnabled()) {
					log.trace("updateTaxonomyName ||call of  dao method updateTaxonomyName() to update taxonomy by taxonomy id");
				}
				dao.updateTaxonomyName(taxonomyName, oldTaxonomyId, conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName ||call of  dao method getAllTaxonomySubscribers() to get taxonomies subscribed");
			}
			List<String> emailIds = dao.getAllTaxonomySubscribers(conn, oldTaxonomyId);
			
			MailTemplateDao mailTemplateDao = new MailTemplateDao();
			String mailTemp = "";
			
			MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"renameTaxonomyName");
			mailTemp = mtVo.getMailTemplate();
			mailTemp = mailTemp.replaceAll("%oldTaxName%", oldTaxName).replaceAll("%newTaxName%", taxonomyName);
			for(String emailId:emailIds){
				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
			}

			retMsg = Constants.TAXONOMY_UPDATED;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			conn.commit();

		} catch (RepoproException e) {
			log.error("updateTaxonomyName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("updateTaxonomyName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateTaxonomyName ||taxonomyName:" + taxonomyName
					+ "parentTaxonomyId:" + oldTaxonomyId + "End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>())).build();
	}

	/**
	 * @method deleteTaxonomyName
	 * @description delete taxonomy by taxonomy id
	 * @param taxonomyId
	 * @return success response
	 */
	@DELETE
	@Path("/deleteTaxonomyName/{taxonomyId}")
	public Response deleteTaxonomyName(@PathParam("taxonomyId") Long taxonomyId)throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("deleteTaxonomyName || Begin with taxonomyId : "+ taxonomyId);
		}
		Connection conn = null;
		List<String> msgList = new ArrayList<String>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteTaxonomyName || "+ Constants.LOG_CONNECTION_OPEN);
			}

			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			TaxonomiesDao dao = new TaxonomiesDao();
			List<TaxonomyMaster> taxonomyList = new ArrayList<TaxonomyMaster>();

			if (log.isTraceEnabled()) {
				log.trace("deleteTaxonomyName ||call of  dao method getAllTaxonomies() to delete taxonomy by taxonomy id");
			}
			taxonomyList = dao.getAllTaxonomies(conn);
			List<Long> ids = new ArrayList<Long>();

			for (TaxonomyMaster val : taxonomyList) {
				if (val.getParenttaxonomyId() != null) {
					if (taxonomyId.equals(val.getParenttaxonomyId())) {
						ids.add(val.getTaxonomyId());
					}
				}
			}
			for (int j = 0; j < ids.size(); j++) {
				recursive(ids.get(j), ids,conn);
			}

			ids.add(taxonomyId);
			
			for (int i = 0; i < ids.size(); i++) {

				MailTemplateDao mdao = new MailTemplateDao();
				MailTemplate mtVo = mdao.retMailTemplateByTextName(conn, "removeTaxonomyName");
				String mailTemp = mtVo.getMailTemplate();
				TaxonomyMaster taxonomyMaster = new TaxonomyMaster();
				taxonomyMaster =  dao.getTaxonomiesByTaxId(taxonomyId,conn);
				mailTemp = mailTemp.replaceAll("%taxName%",taxonomyMaster.getTaxonomyName());
				List<String> emailIds = dao.getAllTaxonomySubscribers(conn,taxonomyId);
				for(String emailId:emailIds){
					MailConfig mailConfig = mdao.getMailConfig(conn);
					SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
				}
				msgList = dao.deleteTaxonomyName(ids.get(i), conn);
			}
			
			if (!(msgList.isEmpty())) {
				retMsg = Constants.TAXONOMYNAME_NOT_DELETED;
			} else {
				retMsg = Constants.TAXONOMYNAME_DELETED;
			}
			
			conn.commit();
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;

			log.info("deleteTaxonomyName || taxonomy with id " + taxonomyId
					+ " deleted successfully");

		} catch (RepoproException e) {
			log.error("deleteTaxonomyName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
			
		} catch (Exception e) {
			log.error("deleteTaxonomyName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteTaxonomyName || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteTaxonomyName || End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(msgList))).build();
	}

	public void recursive(Long val, List<Long> values,Connection conn) {
		TaxonomiesDao dao = new TaxonomiesDao();
		List<TaxonomyMaster> taxonomyList = new ArrayList<TaxonomyMaster>();
		Connection conn1 = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			taxonomyList = dao.getAllTaxonomies(conn);
			List<Long> ids = new ArrayList<Long>();
			for (TaxonomyMaster val1 : taxonomyList) {
				if (val.equals(val1.getParenttaxonomyId())) {
					ids.add(val1.getTaxonomyId());
				}
			}
			values.addAll(ids);
			if (!values.contains(val)) {
				for (int j = 0; j < ids.size(); j++){
					recursive(ids.get(j), values,conn);
				}
			}
		} catch (RepoproException e) {
			e.printStackTrace();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @method getAssetInstancesTaxonomy
	 * @description get asset instances for specific taxonomy
	 * @param userName
	 * @param taxonomyId
	 * @return success response
	 */
	@GET
	@Path("/getAssetInstancesTaxonomy")
	public Response getAssetInstancesAssignedForTaxonomy(
			@QueryParam("userName") String userName,
			@QueryParam("taxonomyId") Long taxonomyId) {

		if(log.isTraceEnabled()){
			log.trace("getAssetInstancesAssignedForTaxonomy || Begin with userName : "+ userName + "taxonomyId : "+ taxonomyId);
		}
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<AssetInstVersionTaxonomy> assetInstVersionTaxonomyList = new ArrayList<AssetInstVersionTaxonomy>();
		TaxonomiesDao taxonomiesDao = new TaxonomiesDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancesAssignedForTaxonomy() || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancesAssignedForTaxonomy() || call of dao getAssetInstancesAssignedForTaxonomy() method to get asset instance data for that specific taxonomy");
			}
			assetInstVersionTaxonomyList = taxonomiesDao.getAssetInstancesAssignedForTaxonomy(taxonomyId, userName,conn);
			
			if (assetInstVersionTaxonomyList.isEmpty()) {
				retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.TAXONOMY_DATA_OBTAINED;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAssetInstancesAssignedForTaxonomy ||  "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstancesAssignedForTaxonomy ||  "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("getAssetInstancesAssignedForTaxonomy() ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAssetInstancesAssignedForTaxonomy() || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetInstVersionTaxonomyList)))
				.build();
	}

	/**
	 * @method recieveAssignedTaxonomyNamesForAssets
	 * @description get list of taxonomies for specific asset
	 * @param assetId
	 * @return success response
	 */
	@GET
	@Path("/getAssetTaxonomy")
	public Response recieveAssignedTaxonomyNamesForAssets(
			@QueryParam("assetId") Long assetId) {

		log.trace("recieveAssignedTaxonomyNamesForAssets || ||Begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
		List<ParentModel> parentModels = new ArrayList<ParentModel>();
		List<ParentModel> parentModelAsset = new ArrayList<ParentModel>();
		List<ParentModel> copyPM = new ArrayList<ParentModel>();
		List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
		ParentModel retPm = null;
		List<Long> taxonomyIds = new ArrayList<Long>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("recieveAssignedTaxonomyNamesForAssets() || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("recieveAssignedTaxonomyNamesForAssets() || call of dao method getAllTaxonomies()");
			}
			allTxs = taxonomiesDao.getAllTaxonomies(conn);

			for (TaxonomyMaster tm1 : allTxs) {

				if (tm1.getTaxonomyId() != 1) {

					taxonomyIds.add(tm1.getTaxonomyId());
					Long taxonId1 = tm1.getParenttaxonomyId();
					String taxxName = tm1.getTaxonomyName() + "|"+ tm1.getTaxonomyId();
					String taxoonName = null;
					for (TaxonomyMaster t1 : allTxs) {
						if (t1.getTaxonomyId().equals(taxonId1)) {
							taxoonName = t1.getTaxonomyName() + "|"+ t1.getTaxonomyId();
						}
					}

					long longTaxId = 1;

					if (taxonId1 == longTaxId) {
						ParentModel parentModel1 = new ParentModel(taxxName,null);
						parentModels.add(parentModel1);
					} else {
						rr = false;
						recurse(parentModels, taxoonName, taxxName);
					}
				}
			}

			copyPM = parentModels;
			if (log.isTraceEnabled()) {
				log.trace("recieveAssignedTaxonomyNamesForAssets() || call of dao method getAllTaxonomiesByAssetId() to get all taxonomies used by specific asset");
			}
			allTxs = taxonomiesDao.getAllTaxonomiesByAssetId(assetId, conn);

			for (TaxonomyMaster tm1 : allTxs) {
				String taxxName = tm1.getTaxonomyName() + "|"+ tm1.getTaxonomyId();
				retPM = null;
				retPm = findmatchInPM(copyPM, taxxName);
				parentModelAsset.add(retPm);
			}

		
			if (parentModelAsset.isEmpty()) {
				retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.TAXONOMY_DATA_OBTAINED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("recieveAssignedTaxonomyNamesForAssets ||  "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("recieveAssignedTaxonomyNamesForAssets ||  "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("recieveAssignedTaxonomyNamesForAssets() ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("recieveAssignedTaxonomyNamesForAssets() || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(parentModelAsset))).build();
	}

	/**
	 * @method findmatchInPM
	 * @description to match taxonomies
	 * @param copyPM
	 * @param taxxName
	 * @return ParentModel
	 */
	private ParentModel findmatchInPM(List<ParentModel> copyPM, String taxxName) {
		boolean flag = false;
		for (int x = 0; x < copyPM.size(); x++) {
			if (copyPM.get(x).getLabel().equalsIgnoreCase(taxxName)) {
				retPM = copyPM.get(x);
				flag = true;
				break;
			} else {
				if (copyPM.get(x).getChildren() != null) {
					findmatchInPM(copyPM.get(x).getChildren(), taxxName);
				}
			}
		}
		return retPM;
	}

	/**
	 * @method getTaxonomiesUsedByAssets
	 * @description get list of taxonomies used to assets
	 * @return success response
	 */
	@GET
	@Path("/getTaxonomiesUsedByAssets")
	public Response getTaxonomiesUsedByAssets() {

		log.trace("getTaxonomiesUsedByAssets || ||Begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
		List<ParentModel> parentModels = new ArrayList<ParentModel>();
		List<Long> taxonomyIds = new ArrayList<Long>();
	    List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
		List<TaxonomyMaster> allTxsList = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster parentTaxonomy = new TaxonomyMaster();
		List<TaxonomyMaster> allTx1 = new ArrayList<TaxonomyMaster>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesUsedByAssets() || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesUsedByAssets() || call of dao method getAllTaxonomyUsedByAssets to get taxonomy list used by asset instance versions");
			}
			allTxs = taxonomiesDao.getAllTaxonomyUsedByAssets(conn);
			Long parentTaxId = 0L;
			for(TaxonomyMaster tm:allTxs){
				parentTaxonomy = taxonomiesDao.getTaxonomiesByParentId(tm.getParenttaxonomyId(), conn);
				parentTaxId = parentTaxonomy.getTaxonomyId();
				if(parentTaxId != 0 && parentTaxId != 1){
					while(parentTaxId != 1){
						if(!allTx1.contains(parentTaxonomy)){
							allTx1.add(parentTaxonomy);
						}
						parentTaxonomy = taxonomiesDao.getTaxonomiesByParentId(parentTaxonomy.getParenttaxonomyId(), conn); 
						parentTaxId = parentTaxonomy.getTaxonomyId();
					}
				}
			}
			allTx1.addAll(allTxs);
			Set<TaxonomyMaster> allDataSet = new HashSet<TaxonomyMaster>();
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesUsedByAssets() || call of dao method getAllTaxonomies to get taxonomy list");
			}
			allTxsList = taxonomiesDao.getAllTaxonomies(conn);
			allDataSet.addAll(allTx1);
			allTx1.clear();
			allTx1.addAll(allDataSet);
			Collections.sort(allTx1, new TaxonomyMaster());
			for (TaxonomyMaster tm1 : allTx1) {

				if (tm1.getTaxonomyId() != 1) {

					taxonomyIds.add(tm1.getTaxonomyId());
					Long taxonId1 = tm1.getParenttaxonomyId();
					String taxxName = tm1.getTaxonomyName() + "|"+ tm1.getTaxonomyId();
					String taxoonName = null;
					for (TaxonomyMaster t1 : allTxsList) {
						if (t1.getTaxonomyId().equals(taxonId1)) {
							taxoonName = t1.getTaxonomyName() + "|"+ t1.getTaxonomyId();
							break;
						}
					}

					long longTaxId = 1;

					if (taxonId1 == longTaxId) {
						ParentModel parentModel1 = new ParentModel(taxxName,null);
						parentModels.add(parentModel1);
					} else {
						rr = false;
						recurse(parentModels, taxoonName, taxxName);
					}
				}
			}
			
			if (parentModels.isEmpty()) {
				retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.TAXONOMY_DATA_OBTAINED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getTaxonomiesUsedByAssets ||  "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getTaxonomiesUsedByAssets ||  "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("getTaxonomiesUsedByAssets() ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getTaxonomiesUsedByAssets() || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(parentModels))).build();
	}

	/**
	 * @method getTaxonomySubscriptionForUser
	 * @param userName
	 * @return success response
	 */
	@GET
	@Path("/getTaxonomySubscriptionForUser")
	public Response getTaxonomySubscriptionForUser(@QueryParam("userName") String userName){
		
		if(log.isTraceEnabled()){
			log.trace("getTaxonomySubscriptionForUser || Begin with userName : "+ userName);
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<Long> taxIdList = new ArrayList<Long>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getTaxonomySubscriptionForUser || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			TaxonomiesDao dao = new TaxonomiesDao();
			
			if (log.isTraceEnabled()){
				log.trace("getTaxonomySubscriptionForUser || call of dao getTaxonomySubscriptionForUser()");
			}
			List<UserTaxonomySubscription> taxList = dao.getTaxonomySubscriptionForUser(userName, conn);
			
			for(UserTaxonomySubscription uts : taxList){
				taxIdList.add(uts.getTaxonomyId());
			}
			
			log.info("getTaxonomySubscriptionForUser || taxonomy ids fetched ");
			
			
		} catch(RepoproException e){
			log.error("getTaxonomySubscriptionForUser || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getTaxonomySubscriptionForUser || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomySubscriptionForUser || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if (taxIdList.isEmpty()) {
			retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.TAXONOMY_DATA_OBTAINED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		
		if(log.isTraceEnabled()){
			log.trace("getTaxonomySubscriptionForUser || end");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(taxIdList))).build();
	}

/***Wrapper function***/	
	@GET
	@Path("/getAllTaxonomiesWithSubcriptionMain")
	public Response getAllTaxonomiesWithSubcriptionMain(
			@QueryParam("userName") String userName) {
		log.trace("getAllTaxonomiesWithSubcriptionMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		/*RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean taxFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;*/

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubcriptionMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			} else {
				User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
				
				/*if(user != null){
					adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
					userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
				}
				
				for(UserFunction uf : userfunctionMappedWithRoleId){
					if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_TAXNMY")){
						taxFlag = true;
				        break;
					}
				}*/
				
				//if(taxFlag || adminFlag){
					response = this.getAllTaxonomiesWithSubcription(user.getUserId());
					return response;
				/*} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
				 	return Response.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
							.build();
			    }*/
			}
			
		} catch (RepoproException e) {
			log.error("getAllTaxonomiesWithSubcriptionMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllTaxonomiesWithSubcriptionMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubcriptionMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllTaxonomiesWithSubcriptionMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/**
	 * @method addTaxonomyNameMain
	 * @param taxonomyName
	 * @param userName
	 * @return success response
	 */
	@POST
	@Path("/addTaxonomyNameMain")
	public Response addTaxonomyNameMain(@QueryParam("taxonomyName") String taxonomyName,
			@HeaderParam("token") String token) {
		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyNameMain|| taxonomyName:"+taxonomyName+"|| Begin");
		}
		if(taxonomyName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		
		if(taxonomyName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean taxFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		User user = new User();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		taxonomyName = taxonomyName.trim();
		allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyNameMain || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")) {
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
			
			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
			
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_TAXNMY")){
					taxFlag = true;
			        break;
				}
			}
			
			if(taxFlag || adminFlag){
				if (!taxonomyName.equalsIgnoreCase("")) {
					if(taxonomyName.trim().length()>51){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();
					}
				}
				
				final List<TaxonomyMaster> tmList = taxonomiesDao.getAllTaxonomiesByParentId(1L,null);
				for(TaxonomyMaster t:tmList){
					recurse(t);
				}
				allTaxs.put((long) 1, tmList);
				
				Set<Long> hs = new HashSet<Long>();
				hs.addAll(associatedTaxId);
				associatedTaxId.clear();
				associatedTaxId.addAll(hs);

				String[] addedTaxIds = new String[]{};
				String[] addedTaxIds1 = new String[]{};
				AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();

				List<Long> idsForTaxon = new ArrayList<Long>();
				Long taxNextId = null;
				String taxName = "";
				if(taxonomyName.endsWith(","))
				{
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
				else
				{
					if(taxonomyName.length() > 0 )
					{
						addedTaxIds = taxonomyName.split(",");
						
						Set<String> hashset = new HashSet<String>(Arrays.asList(addedTaxIds));
						if(hashset.size() != addedTaxIds.length){
							return Response
								     .status(Status.BAD_REQUEST)
								     .entity(new MyModelRest(Constants.STATUS_FAILURE,
								       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
								     .build();
						}
						
						Boolean flag2 = true;

						for(int t =0; t< addedTaxIds.length && flag2; t++)
						{
							List<TaxonomyMaster> tmpTaxList = tmList;
							addedTaxIds1 = addedTaxIds[t].split("/");
							if(addedTaxIds1.length == 1){
								taxName = addedTaxIds1[0];
								taxNextId = 1L;
							}else{
								for(int h =0; h< addedTaxIds1.length; h++)
								{
									Boolean flag = false;
									taxName = addedTaxIds1[h];
									String newRegex = "^((?=[\\w+\\s])(?![\\[\\]\\?\\.\\\\@#^\\+\\=:;<>/_]).)*$";
									Pattern pattern = Pattern.compile(newRegex);
									Matcher matcher = pattern.matcher(taxName);

									if(!matcher.find()){
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_TAXONOMY_NAME)))
														.build();
									}
									for(TaxonomyMaster tm:tmpTaxList)
									{
										if(tm.getTaxonomyName().equalsIgnoreCase(taxName.trim())){
											flag = true;
											taxNextId = tm.getTaxonomyId();
											break;
										}
									}
									if(!flag && !(h == addedTaxIds1.length-1))
									{
										flag2 = false;
										retStat = Status.OK;
										retScsFlr = Constants.FAILURE;
										retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_ADD;
										retStatScsFlr = Constants.GET_STATUS_SUCCESS;
										return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

									}
									else
									{
										for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
										{
											if(entry.getKey() ==  taxNextId)
											{ 
												tmpTaxList = entry.getValue();
											}
										}
									}
									if(h == addedTaxIds1.length-1)
									{
										Boolean fl = false;
										Boolean f2 = false;

										if(associatedTaxId.contains(taxNextId)){

										}
										else{
											f2 = true;
										}

										for(Long Id:idsForTaxon)
										{
											if(Id.equals(taxNextId))
											{
												fl = true;
												break;
											}
										}
										if(fl)
										{
											retStat = Status.BAD_REQUEST;
											retScsFlr = Constants.FAILURE;
											retMsg = Constants.DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED;
											retStatScsFlr = Constants.STATUS_FAILURE;
											return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
											//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()); 
										}
										if(f2)
										{
											//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset"); 
										}
										else
										{
											idsForTaxon.add(taxNextId);
										}
									}
								}
							}
						}
					}
					else
					{
						idsForTaxon = Collections.<Long>emptyList();
					}
				}
				response = this.addTaxonomyName(taxName, taxNextId);
				//return response;
				MyModel modelRestTax = (MyModel) response.getEntity();
				
				retMsg = modelRestTax.getMessage();
				retStat = Status.OK;
				retScsFlr = modelRestTax.getStatus();
				retStatScsFlr = modelRestTax.getStatusCode();
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			

		} catch (RepoproException e) {
			log.error("addTaxonomyNameMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("addTaxonomyNameMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyNameMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyNameMain|| taxonomyName:"+taxonomyName+"|| End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/**
	 * @method updateTaxonomyNameMain
	 * @param taxonomyName
	 * @param oldTaxonomyName
	 * @param userName
	 * @return success response
	 */
	@PUT
	@Path("/updateTaxonomyNameMain")
	public Response updateTaxonomyNameMain(
			@QueryParam("taxonomyName") String taxonomyName,
			@QueryParam("oldTaxonomyName") String oldTaxonomyName,
			@HeaderParam("token") String token){
		if(taxonomyName == null || oldTaxonomyName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		
		if(taxonomyName.isEmpty() || oldTaxonomyName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		if (log.isTraceEnabled()) {
			log.trace("updateTaxonomyNameMain|| taxonomyName:"+taxonomyName+" oldTaxonomyName:"+oldTaxonomyName+"|| Begin");
		}
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean taxFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		User user = new User();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
		taxonomyName = taxonomyName.trim();
		oldTaxonomyName = oldTaxonomyName.trim();

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyNameMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")) {
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}

			TaxonomiesDao taxonomiesDao = new TaxonomiesDao();			

			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}

			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_TAXNMY")){
					taxFlag = true;
					break;
				}
			}

			if(taxFlag || adminFlag){
				String newRegex = "^((?=[\\w+\\s])(?![\\[\\]\\?\\.\\\\@#^\\+\\=:;<>/_]).)*$";
				Pattern pattern = Pattern.compile(newRegex);
				Matcher matcher = pattern.matcher(taxonomyName);

				if(!matcher.find()){
					return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_TAXONOMY_NAME)))
									.build();
				}

				if (!taxonomyName.equalsIgnoreCase("")) {
					if(taxonomyName.trim().length()>51){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();
					}
				}

				final List<TaxonomyMaster> tmList = taxonomiesDao.getAllTaxonomiesByParentId(1L,null);
				for(TaxonomyMaster t:tmList){
					recurse(t);
				}
				allTaxs.put((long) 1, tmList);

				Set<Long> hs = new HashSet<Long>();
				hs.addAll(associatedTaxId);
				associatedTaxId.clear();
				associatedTaxId.addAll(hs);

				String[] addedTaxIds = new String[]{};
				String[] addedTaxIds1 = new String[]{};
				AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();

				List<Long> idsForTaxon = new ArrayList<Long>();
				Long taxNextId = null;
				String taxName = "";
				if(oldTaxonomyName.endsWith(","))
				{
					return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
									.build();
				}
				else
				{
					if(oldTaxonomyName.length() > 0 )
					{
						addedTaxIds = oldTaxonomyName.split(",");
						Boolean flag2 = true;


						for(int t =0; t< addedTaxIds.length && flag2; t++)
						{
							List<TaxonomyMaster> tmpTaxList = tmList;
							addedTaxIds1 = addedTaxIds[t].split("/");

							for(int h =0; h< addedTaxIds1.length; h++)
							{
								Boolean flag = false;
								taxName = addedTaxIds1[h];

								for(TaxonomyMaster tm:tmpTaxList)
								{
									if(tm.getTaxonomyName().equalsIgnoreCase(taxName.trim())){
										flag = true;
										taxNextId = tm.getTaxonomyId();
										break;
									}
								}
								if(!flag)
								{
									flag2 = false;
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_ADD;
									retStatScsFlr = Constants.GET_STATUS_SUCCESS;
									return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

								}
								else
								{
									for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
									{
										if(entry.getKey() ==  taxNextId)
										{ 
											tmpTaxList = entry.getValue();
										}
									}
								}
								if(h == addedTaxIds1.length-1)
								{

									Boolean fl = false;
									Boolean f2 = false;

									if(associatedTaxId.contains(taxNextId)){

									}
									else{
										f2 = true;
									}

									for(Long Id:idsForTaxon)
									{
										if(Id.equals(taxNextId))
										{
											fl = true;
											break;
										}

									}
									if(fl)
									{
										//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()); 
									}
									if(f2)
									{
										//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset"); 
									}
									else
									{
										idsForTaxon.add(taxNextId);
									}
								}
							}
						}

					}

					else
					{
						idsForTaxon = Collections.<Long>emptyList();
					}
				}
				response = this.updateTaxonomyName(taxonomyName, taxNextId);
				
				MyModel modelRestTax = (MyModel) response.getEntity();
				
				retMsg = modelRestTax.getMessage();
				retStat = Status.OK;
				retScsFlr = modelRestTax.getStatus();
				retStatScsFlr = modelRestTax.getStatusCode();
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}


		} catch (RepoproException e) {
			log.error("updateTaxonomyNameMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			retScsFlr = Constants.FAILURE;
			retMsg = e.getMessage();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("updateTaxonomyNameMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			retScsFlr = Constants.FAILURE;
			retMsg = e.getMessage();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyNameMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateTaxonomyNameMain|| taxonomyName:"+taxonomyName+" oldTaxonomyName:"+oldTaxonomyName+"|| End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/**
	 * @method deleteTaxonomyNameMain
	 * @param taxonomyName
	 * @param userName
	 * @return success response
	 */
	@DELETE
	@Path("/deleteTaxonomyNameMain")
	public Response deleteTaxonomyNameMain(
			@QueryParam("taxonomyName") String taxonomyName,
			@HeaderParam("token") String token) {
		if(taxonomyName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		
		if(taxonomyName.trim().isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("deleteTaxonomyNameMain ||taxonomyName:"+taxonomyName+"|| Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		boolean taxFlag = false;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean adminFlag = false;
		User user = new User();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteTaxonomyNameMain || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user1 = userDao.getUserIdByUserName(userName, null);
				if(user1.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")) {
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
			
			user = userDao.retProfileForUserName(userName, conn);
			if(user.getUserId() == null){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			if(user != null){
				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
			
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_TAXNMY")){
					taxFlag = true;
			        break;
				}
			}
			
			if(taxFlag || adminFlag){
				final List<TaxonomyMaster> tmList = taxonomiesDao.getAllTaxonomiesByParentId(1L,null);
				for(TaxonomyMaster t:tmList){
					recurse(t);
				}
				allTaxs.put((long) 1, tmList);
				
				Set<Long> hs = new HashSet<Long>();
				hs.addAll(associatedTaxId);
				associatedTaxId.clear();
				associatedTaxId.addAll(hs);

				String[] addedTaxIds = new String[]{};
				String[] addedTaxIds1 = new String[]{};
				AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();

				List<Long> idsForTaxon = new ArrayList<Long>();
				Long taxNextId = null;
				String taxName = "";
				if(taxonomyName.endsWith(","))
				{
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
				else
				{
					if(taxonomyName.length() > 0 )
					{
							addedTaxIds = taxonomyName.split(",");
							Boolean flag2 = true;
							
							
							for(int t =0; t< addedTaxIds.length && flag2; t++)
							{
								List<TaxonomyMaster> tmpTaxList = tmList;
								addedTaxIds1 = addedTaxIds[t].split("/");

								for(int h =0; h< addedTaxIds1.length; h++)
								{
									Boolean flag = false;
									taxName = addedTaxIds1[h];
									
									for(TaxonomyMaster tm:tmpTaxList)
									{
										if(tm.getTaxonomyName().equalsIgnoreCase(taxName.trim())){
											flag = true;
											taxNextId = tm.getTaxonomyId();
											break;
										}
									}
									if(!flag)
									{
										flag2 = false;
										retStat = Status.OK;
										retScsFlr = Constants.FAILURE;
										retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_DELETE;
										retStatScsFlr = Constants.GET_STATUS_SUCCESS;
										return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

									}
									else
									{
										for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
										{
											if(entry.getKey() ==  taxNextId)
											{ 
												tmpTaxList = entry.getValue();
											}
										}
									}
									if(h == addedTaxIds1.length-1)
									{

										Boolean fl = false;
										Boolean f2 = false;

										if(associatedTaxId.contains(taxNextId)){

										}
										else{
											f2 = true;
										}

										for(Long Id:idsForTaxon)
										{
											if(Id.equals(taxNextId))
											{
												fl = true;
												break;
											}

										}
										if(fl)
										{
											//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()); 
										}
										if(f2)
										{
											//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset"); 
										}
										else
										{
											idsForTaxon.add(taxNextId);
										}
									}
								}
							}
						
					}

					else
					{
						idsForTaxon = Collections.<Long>emptyList();
					}
				}
				
				response = this.deleteTaxonomyName(taxNextId);
				MyModel modelRestTax = (MyModel) response.getEntity();
				
				retMsg = modelRestTax.getMessage();
				retStat = Status.OK;
				retScsFlr = modelRestTax.getStatus();
				retStatScsFlr = modelRestTax.getStatusCode();
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }

		} catch (RepoproException e) {
			log.error("deleteTaxonomyNameMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("deleteTaxonomyNameMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteTaxonomyNameMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("deleteTaxonomyNameMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/**
	 * @method getAssetInstancesAssignedForTaxonomyMain
	 * @param userName
	 * @param taxonomyName
	 * @return success response
	 */
	@GET
	@Path("/getAssetInstancesTaxonomyMain")
	public Response getAssetInstancesAssignedForTaxonomyMain(
			@QueryParam("taxonomyName") String taxonomyName,
			@HeaderParam("token") String token) {
		if(taxonomyName == null ){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		
		if(taxonomyName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getAssetInstancesAssignedForTaxonomyMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		taxonomyName = taxonomyName.trim();
		boolean taxFlag = false;
		boolean adminFlag = false;
		User user = new User();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		RoleDao roledao = new RoleDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancesAssignedForTaxonomyMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")) {
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			
			if(user != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_TAXNMY")){
					taxFlag = true;
			        break;
				}
			}
			
			
			if(taxFlag || adminFlag){
				TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
				Long taxonomyId = taxonomiesDao.getTaxonomyIdByName(taxonomyName,conn);
				if (taxonomyId == null) {
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("getAssetInstancesAssignedForTaxonomyMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,retMsg)).build();
				}
				response = this.getAssetInstancesAssignedForTaxonomy(userName, taxonomyId);
				MyModel modelRestTax = (MyModel) response.getEntity();
				retStat = Status.OK;
				List<Object> result = modelRestTax.getResult();
				JSONObject json = new JSONObject();
				JSONObject j1 = null;
				//Gson gson = new Gson();
				List<Object> finaldata = new ArrayList<Object>();
				for (int i = 0; i < result.size(); i++) {
					j1 = new JSONObject();
					AssetInstVersionTaxonomy aivt = new AssetInstVersionTaxonomy();
					aivt = (AssetInstVersionTaxonomy) result.get(i);
					j1.put("assetName", aivt.getAssetName());
					j1.put("assetInstanceName", aivt.getAssetInstanceName());
					j1.put("assetInstanceVersionName", aivt.getVersionName());
					j1.put("versionable", aivt.isVersionable());
					j1.put("overview", aivt.getOverview());
					finaldata.add(j1);
				}
				json.put("result", finaldata);
				// json.put("result", new JSONArray(gson.toJson(result)));
				json.put("message", modelRestTax.getMessage());
				json.put("status", modelRestTax.getStatus());
				json.put("statusCode", modelRestTax.getStatusCode());
				return Response.status(retStat).entity(json.toString()).build();
			}else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
		} catch (RepoproException e) {
			log.error("getAssetInstancesAssignedForTaxonomyMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstancesAssignedForTaxonomyMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancesAssignedForTaxonomyMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAssetInstancesAssignedForTaxonomyMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/**
	 * @method recieveAssignedTaxonomyNamesForAssetsMain
	 * @param assetName
	 * @param userName
	 * @return success response
	 */
	@GET
	@Path("/getAssetTaxonomyMain")
	public Response recieveAssignedTaxonomyNamesForAssetsMain(
			@QueryParam("assetName") String assetName, @HeaderParam("token") String token) {
		if(assetName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		
		if(assetName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("recieveAssignedTaxonomyNamesForAssetsMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean assetFlag = false;
		boolean adminFlag = false;
		User user = new User();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		RoleDao roledao = new RoleDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		assetName = assetName.trim();
		try {
			if (log.isTraceEnabled()) {
				log.trace("recieveAssignedTaxonomyNamesForAssetsMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			
			if(!userName.equalsIgnoreCase("guest")){
				user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")) {
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = new AssetDef();
			ad = assetDao.getAssetsByAssetName(assetName, conn);
			if (ad.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("recieveAssignedTaxonomyNamesForAssetsMain || End");
				return Response
						.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr,retMsg)).build();
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			
			if(user != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_ASSETS")){
			        assetFlag = true;
			        break;
				}
			}
			
			if(assetFlag || adminFlag){
				response = this.recieveAssignedTaxonomyNamesForAssets(ad.getAssetId());
				MyModel modelRestTax = (MyModel) response.getEntity();
				
				retMsg = modelRestTax.getMessage();
				retStat = Status.OK;
				retScsFlr = modelRestTax.getStatus();
				retStatScsFlr = modelRestTax.getStatusCode();
				List<Object> result = modelRestTax.getResult();
				JSONObject json = new JSONObject();
				Gson gson = new Gson();
		        json.put("result", new JSONArray(gson.toJson(result)));
				json.put("message", modelRestTax.getMessage());
				json.put("status", modelRestTax.getStatus());
				json.put("statusCode", modelRestTax.getStatusCode());
				return Response.status(retStat).entity(json.toString()).build();
				
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
		    }
			

		} catch (RepoproException e) {
			log.error("recieveAssignedTaxonomyNamesForAssetsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("recieveAssignedTaxonomyNamesForAssetsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("recieveAssignedTaxonomyNamesForAssetsMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("recieveAssignedTaxonomyNamesForAssetsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/**
	 * @method getFilteredTaxonomyForManageSubscription
	 * @description get list of taxonomies for specific asset
	 * @param assetId
	 * @return success response
	 */
	@GET
	@Encoded
	@Path("/getFilteredTaxonomyForManageSubscription")
	public Response recieveAssignedFilteredTaxonomyNamesForManageSubscription(
			@QueryParam("userName") String userName,
			@QueryParam("searchString") String searchString,
			@QueryParam("subscriptionFlag")String subscriptionFlag,
			@QueryParam("hideUnusedTaxFlag")boolean hideUnusedTaxFlag) {

		log.trace("recieveAssignedFilteredTaxonomyNamesForManageSubscription || ||Begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
		List<ParentModel> parentModels = new ArrayList<ParentModel>();
		List<Long> taxonomyIds = new ArrayList<Long>();
	    List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
		List<TaxonomyMaster> allTxsList = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster parentTaxonomy = new TaxonomyMaster();
		List<TaxonomyMaster> allTx1 = new ArrayList<TaxonomyMaster>();
		UserDao userDao = new UserDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("recieveAssignedFilteredTaxonomyNamesForManageSubscription() || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			
			searchString = URLDecoder.decode(searchString, "UTF-8");
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("recieveAssignedFilteredTaxonomyNamesForManageSubscription() || call of dao method getAllFilteredTaxonomiesBySearchData()");
			}
			User user = userDao.getUserIdByUserName(userName, conn);
			allTxs = taxonomiesDao.getAllFilteredTaxonomiesBySearchData(searchString,subscriptionFlag,user.getUserId(),hideUnusedTaxFlag, conn);
			
			Long parentTaxId = 0L;
			for(TaxonomyMaster tm:allTxs){
				parentTaxonomy = taxonomiesDao.getTaxonomiesByParentIdForFilter(tm.getParenttaxonomyId(), conn);
				parentTaxId = parentTaxonomy.getTaxonomyId();
				if(parentTaxId != 0 && parentTaxId != 1){
					while(parentTaxId != 1){
						if(!allTx1.contains(parentTaxonomy)){
							allTx1.add(parentTaxonomy);
						}
						parentTaxonomy = taxonomiesDao.getTaxonomiesByParentIdForFilter(parentTaxonomy.getParenttaxonomyId(), conn); 
						parentTaxId = parentTaxonomy.getTaxonomyId();
					}
				}
			}
			allTx1.addAll(allTxs);
			Set<TaxonomyMaster> allDataSet = new HashSet<TaxonomyMaster>();
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubcriptionUsedByAsset() || call of dao method getAllTaxonomies to get taxonomy list");
			}
			allTxsList = taxonomiesDao.getAllTaxonomiesForFilter(conn);
			allDataSet.addAll(allTx1);
			allTx1.clear();
			allTx1.addAll(allDataSet);
			Collections.sort(allTx1, new TaxonomyMaster());
			for (TaxonomyMaster tm1 : allTx1) {
				if (tm1.getTaxonomyId() != 1) {
					TaxonomyMaster subscription = taxonomiesDao.getTaxonomiesWithSubscription(userName, tm1.getTaxonomyId(), conn);
                    if(subscription != null){
                    	taxonomyIds.add(tm1.getTaxonomyId());
                    	Long taxonId1 = tm1.getParenttaxonomyId();
                    	String taxxName = tm1.getTaxonomyName() + "|"+ tm1.getTaxonomyId()+"|"+subscription.getSubscription();
                    	String taxoonName = null;
                    	for (TaxonomyMaster t1 : allTxsList) {
                    		if (t1.getTaxonomyId().equals(taxonId1)) {
                    			TaxonomyMaster subData = taxonomiesDao.getTaxonomiesWithSubscription(userName, taxonId1, conn);
                    			if(subData != null){
                    				taxoonName = t1.getTaxonomyName() + "|"+ t1.getTaxonomyId()+"|"+subData.getSubscription();
                    				break;
                    			}
                    		}
                    	}

                    	long longTaxId = 1;

                    	if (taxonId1 == longTaxId) {
                    		ParentModel parentModel1 = new ParentModel(taxxName,null);
                    		parentModels.add(parentModel1);
                    	} else {
                    		rr = false;
                    		recurse(parentModels, taxoonName, taxxName);
                    	}
                    }
				}
			}
			
		
			if (parentModels.isEmpty()) {
				retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.TAXONOMY_DATA_OBTAINED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("recieveAssignedFilteredTaxonomyNamesForManageSubscription ||  "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("recieveAssignedFilteredTaxonomyNamesForManageSubscription ||  "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("recieveAssignedFilteredTaxonomyNamesForManageSubscription() ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("recieveAssignedFilteredTaxonomyNamesForManageSubscription() || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(parentModels))).build();
	}
	
	/**
	 * @method getAllTaxonomiesMain
	 * @param token
	 * @return success response
	 */
	@GET
	@Path("/getAllTaxonomies")
	public Response getAllTaxonomiesMain(@HeaderParam("token") String token) {
		log.trace("getAllTaxonomiesMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean assetFlag = false;
		boolean adminFlag = false;
		User user = new User();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		RoleDao roledao = new RoleDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesMain || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), conn);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			
			if(!userName.equalsIgnoreCase("guest")){
				user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")) {
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			
			if(user != null){
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
			}
	        
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_TAXNMY")){
			        assetFlag = true;
			        break;
				}
			}
			
			if(assetFlag || adminFlag){
				response = this.getAllTaxonomies();
				MyModel modelRestTax = (MyModel) response.getEntity();

				retMsg = modelRestTax.getMessage();
				retStat = Status.OK;
				retScsFlr = modelRestTax.getStatus();
				retStatScsFlr = modelRestTax.getStatusCode();
				List<Object> result = modelRestTax.getResult();
				JSONObject json = new JSONObject();
				Gson gson = new Gson();
		        json.put("result", new JSONArray(gson.toJson(result)));
				json.put("message", modelRestTax.getMessage());
				json.put("status", modelRestTax.getStatus());
				json.put("statusCode", modelRestTax.getStatusCode());
				return Response.status(retStat).entity(json.toString()).build();
				
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }
			

		} catch (RepoproException e) {
			log.error("getAllTaxonomiesMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllTaxonomiesMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllTaxonomiesMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
}
