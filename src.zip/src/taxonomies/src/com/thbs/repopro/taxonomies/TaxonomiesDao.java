package com.thbs.repopro.taxonomies;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AdminAccessName;
import com.thbs.repopro.dto.AssetInstVersionTaxonomy;
import com.thbs.repopro.dto.TaxonomyMaster;
import com.thbs.repopro.dto.UserTaxonomySubscription;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class TaxonomiesDao {

	private static final Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method getAllTaxonomies
	 * @description get list of taxonomies
	 * @param conn
	 * @return List<TaxonomyMaster>
	 * @throws RepoproException
	 */
	public List<TaxonomyMaster> getAllTaxonomies(Connection conn)
			throws RepoproException {

		log.trace("getAllTaxonomies() || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomies() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_TAXONOMIES));
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomies() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES));
			}

			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				//taxonomy.setSubscription(rs.getString("subscribed"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getAllTaxonomies() ||" + taxonomy.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllTaxonomies() ||" + taxonomylist.toString());
			}

		} catch (SQLException e) {
			log.error("getAllTaxonomies || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllTaxonomies || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllTaxonomies || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllTaxonomies || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomies || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAllTaxonomies || End");

		return taxonomylist;
	}
	/**
	 * @method getAllTaxonomiesForFilter
	 * @param conn
	 * @return List<TaxonomyMaster>
	 * @throws RepoproException
	 */
	public List<TaxonomyMaster> getAllTaxonomiesForFilter(Connection conn)
			throws RepoproException {

		log.trace("getAllTaxonomiesForFilter() || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesForFilter() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_TAXONOMIES_FOR_FILTER));
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesForFilter() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES_FOR_FILTER));
			}

			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				taxonomy.setSubscription(rs.getString("subscribed"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getAllTaxonomiesForFilter() ||" + taxonomy.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllTaxonomiesForFilter() ||" + taxonomylist.toString());
			}

		} catch (SQLException e) {
			log.error("getAllTaxonomiesForFilter || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllTaxonomiesForFilter || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllTaxonomiesForFilter || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllTaxonomiesForFilter || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesForFilter || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAllTaxonomiesForFilter || End");

		return taxonomylist;
	}

	/**
	 * @method getAllTaxonomiesWithSubscription
	 * @param userId
	 * @param conn
	 * @return List<TaxonomyMaster>
	 * @throws RepoproException
	 */
	public List<TaxonomyMaster> getAllTaxonomiesWithSubscription(Long userId,Connection conn)
			throws RepoproException {

		log.trace("getAllTaxonomiesWithSubscription() || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubscription() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_TAXONOMIES_WITH_SUBSCRIPTION));
			preparedStmt.setLong(Constants.ONE, userId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubscription() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES_WITH_SUBSCRIPTION));
			}

			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				taxonomy.setSubscription(rs.getString("subscribed"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getAllTaxonomiesWithSubscription() ||" + taxonomy.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllTaxonomiesWithSubscription() ||" + taxonomylist.toString());
			}

		} catch (SQLException e) {
			log.error("getAllTaxonomiesWithSubscription || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllTaxonomiesWithSubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllTaxonomiesWithSubscription || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllTaxonomiesWithSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubscription || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAllTaxonomiesWithSubscription || End");

		return taxonomylist;
	}
	
	/**
	 * @method getTaxonomiesWithSubscription
	 * @param userId
	 * @param conn
	 * @return TaxonomyMaster
	 * @throws RepoproException
	 */
	public TaxonomyMaster getTaxonomiesWithSubscription(String userName,Long taxonomyId,Connection conn)
			throws RepoproException {

		log.trace("getAllTaxonomiesWithSubscription() || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		TaxonomyMaster taxonomy = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubscription() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_TAXONOMY_SUBSCRIPTION_DETAILS));
			preparedStmt.setString(Constants.ONE, userName);
			preparedStmt.setLong(Constants.TWO, taxonomyId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubscription() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_TAXONOMY_SUBSCRIPTION_DETAILS));
			}

			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				taxonomy.setSubscription(rs.getString("subscribed"));
				if (log.isTraceEnabled()) {
					log.trace("getAllTaxonomiesWithSubscription() ||" + taxonomy.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAllTaxonomiesWithSubscription || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllTaxonomiesWithSubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllTaxonomiesWithSubscription || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllTaxonomiesWithSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesWithSubscription || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAllTaxonomiesWithSubscription || End");

		return taxonomy;
	}

	/**
	 * @method getAllTaxonomiesByParentId
	 * @description get all taxonomies by parent id
	 * @param parentTaxonomyId
	 * @param conn
	 * @return List<TaxonomyMaster>
	 * @throws RepoproException
	 */
	public List<TaxonomyMaster> getAllTaxonomiesByParentId(
			Long parentTaxonomyId, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllTaxonomiesByParentId() ||parentTaxonomyId:"
					+ parentTaxonomyId + " ||Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesByParentId() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ALL_TAXONOMIES_BY_PARENT_TAXONOMY_ID));
			preparedStmt.setLong(Constants.ONE, parentTaxonomyId);
			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesByParentId() ||"
						+ PropertyFileReader
						.getInstance()
						.getValue(
								Constants.GET_ALL_TAXONOMIES_BY_PARENT_TAXONOMY_ID));
			}

			while (resultSet.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(resultSet.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(resultSet.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(resultSet.getLong("parent_taxonomy_id"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getAllTaxonomiesByParentId() ||"+ taxonomy.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAllTaxonomiesByParentId || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllTaxonomiesByParentId || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllTaxonomiesByParentId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllTaxonomiesByParentId || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomies || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getAllTaxonomiesByParentId() ||parentTaxonomyId:"
					+ parentTaxonomyId + " || End");
		}
		return taxonomylist;
	}

	/**
	 * @method getTaxonomiesByTaxId
	 * @description get taxonomy details by taxonomy id
	 * @param taxonomyId
	 * @param conn
	 * @return TaxonomyMaster
	 * @throws RepoproException
	 */
	public TaxonomyMaster getTaxonomiesByTaxId(Long taxonomyId, Connection conn)
			throws RepoproException {

		log.trace("getTaxonomiesByTaxId() ||taxonomyId" + taxonomyId
				+ "||Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByTaxId() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ALL_TAXONOMIES_BY_TAXONOMY_ID));
			preparedStmt.setLong(Constants.ONE, taxonomyId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByTaxId() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES_BY_TAXONOMY_ID));
			}


			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getTaxonomiesByTaxId() ||" + taxonomy.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getTaxonomiesByTaxId || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getTaxonomiesByTaxId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getTaxonomiesByTaxId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getTaxonomiesByTaxId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByTaxId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getTaxonomiesByTaxId() ||taxonomyId" + taxonomyId
					+ "|| End");
		}
		return taxonomy;
	}

	/**
	 * @method getTaxonomiesByParentId
	 * @description get taxonomy details by parent id
	 * @param taxonomyId
	 * @param conn
	 * @return TaxonomyMaster
	 * @throws RepoproException
	 */
	public TaxonomyMaster getTaxonomiesByParentId(Long taxonomyId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getTaxonomiesByParentId()||taxonomyId" + taxonomyId
					+ "||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByParentId() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ALL_TAXONOMIES_BY_TAXONOMY_ID));
			preparedStmt.setLong(Constants.ONE, taxonomyId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByParentId() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES_BY_TAXONOMY_ID));
			}

			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				//taxonomy.setSubscription(rs.getString("subscribed"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getTaxonomiesByParentId() ||" + taxonomy.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getTaxonomiesByParentId || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getTaxonomiesByParentId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getTaxonomiesByParentId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getTaxonomiesByParentId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByParentId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getTaxonomiesByParentId ||taxonomyId" + taxonomyId
					+ "|| End");
		}
		return taxonomy;
	}
	/**
	 * @method getTaxonomiesByParentIdForFilter
	 * @param taxonomyId
	 * @param conn
	 * @return TaxonomyMaster
	 * @throws RepoproException
	 */
	public TaxonomyMaster getTaxonomiesByParentIdForFilter(Long taxonomyId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getTaxonomiesByParentIdForFilter()||taxonomyId" + taxonomyId
					+ "||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByParentIdForFilter() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ALL_TAXONOMIES_BY_TAXONOMY_ID_FOR_FILTER));
			preparedStmt.setLong(Constants.ONE, taxonomyId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByParentIdForFilter() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES_BY_TAXONOMY_ID));
			}

			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				taxonomy.setSubscription(rs.getString("subscribed"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getTaxonomiesByParentIdForFilter() ||" + taxonomy.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getTaxonomiesByParentIdForFilter || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getTaxonomiesByParentIdForFilter || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getTaxonomiesByParentIdForFilter || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getTaxonomiesByParentIdForFilter || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByParentIdForFilter || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getTaxonomiesByParentIdForFilter ||taxonomyId" + taxonomyId
					+ "|| End");
		}
		return taxonomy;
	}

	/**
	 * @method addTaxonomyName
	 * @description add taxonomy name
	 * @param taxonomyname
	 * @param parentTaxonomyId
	 * @param conn
	 * @return TaxonomyMaster
	 * @throws RepoproException
	 */
	public TaxonomyMaster addTaxonomyName(String taxonomyname,
			Long parentTaxonomyId, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyName ||taxonomyname:" + taxonomyname
					+ "parentTaxonomyId:" + parentTaxonomyId + "||Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		TaxonomyMaster taxonomyMaster = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyName || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_TAXONOMY_NAME));

			pstmt.setString(Constants.ONE, taxonomyname);
			pstmt.setLong(Constants.TWO, parentTaxonomyId);

			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_TAXONOMY_NAME));
			}

			pstmt.executeUpdate();
			taxonomyMaster = new TaxonomyMaster();
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				taxonomyMaster.setTaxonomyId(rs.getLong(1));
			}

		} catch (SQLException e) {
			log.error("addTaxonomyName || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_NOT_CREATED));
		} catch (IOException e) {
			log.error("addTaxonomyName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addTaxonomyName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addTaxonomyName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addTaxonomyName || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("addTaxonomyName ||taxonomyname:" + taxonomyname
					+ " parentTaxonomyId:" + parentTaxonomyId + "||End");
		}
		return taxonomyMaster;
	}

	/**
	 * @method updateTaxonomyName
	 * @description update taxonomy name
	 * @param taxonomyname
	 * @param TaxonomyId
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateTaxonomyName(String taxonomyname, Long TaxonomyId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateTaxonomyName ||taxonomyname:" + taxonomyname
					+ " TaxonomyId:" + TaxonomyId + "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.UPDATE_TAXONOMY_NAME));

			pstmt.setString(Constants.ONE, taxonomyname);
			pstmt.setLong(Constants.TWO, TaxonomyId);

			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_TAXONOMY_NAME));
			}

			int result = pstmt.executeUpdate();
			

		} catch (SQLException e) {
			log.error("updateTaxonomyName || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_NAME_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateTaxonomyName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateTaxonomyName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateTaxonomyName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateTaxonomyName || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("updateTaxonomyName ||taxonomyname:" + taxonomyname
					+ "TaxonomyId:" + TaxonomyId + "|| End");
		}
	}

	/**
	 * @method deleteTaxonomyName
	 * @descripton delete taxonomy name by taxonomy id
	 * @param taxonomyId
	 * @param conn
	 * @return string
	 * @throws RepoproException
	 */
	public List<String> deleteTaxonomyName(Long taxonomyId, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteTaxonomyName || Begin with taxonomyId : "
					+ taxonomyId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		List<String> msg = new ArrayList<String>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteTaxonomyName || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_TAXONOMY_ID));

			pstmt.setLong(Constants.ONE, taxonomyId);

			if (log.isTraceEnabled()) {
				log.trace("deleteTaxonomyName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_TAXONOMY_ID));
			}

			int result = pstmt.executeUpdate();

		} catch (SQLException e) {
			log.error("deleteTaxonomyName || "
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteTaxonomyName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteTaxonomyName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteTaxonomyName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteTaxonomyName || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("deleteTaxonomyName || End");
		}
		return msg;
	}


	/**
	 * @method getAllTaxonomySubscribers
	 * @descripton get all taxonomy subscribers by taxonomy id
	 * @param taxonomyId
	 * @param conn
	 * @return string
	 * @throws RepoproException
	 */
	public List<String> getAllTaxonomySubscribers(Connection conn , Long taxonomyId)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllTaxonomySubscribers || Begin with taxonomyId : "
					+ taxonomyId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<String> subscriberMailIds = new ArrayList<String>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomySubscribers || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.RET_TAXONOMY_SUBSCRIBER_BY_TAXID));

			pstmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			pstmt.setLong(Constants.TWO, taxonomyId);

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomySubscribers || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_TAXONOMY_SUBSCRIBER_BY_TAXID));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				subscriberMailIds.add(rs.getString("decrypted_email_id")); 
			}


		} catch (SQLException e) {
			log.error("getAllTaxonomySubscribers || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_SUBSCRIBER_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllTaxonomySubscribers || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllTaxonomySubscribers || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllTaxonomySubscribers || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);    
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomySubscribers || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("getAllTaxonomySubscribers || End");
		}
		return subscriberMailIds;
	}

	/**
	 * @method getAssetInstancesAssignedForTaxonomy
	 * @description get asset instances assigned for taxonomy
	 * @param taxonomyId
	 * @param userName
	 * @param conn
	 * @return List<AssetInstVersionTaxonomy>
	 * @throws RepoproException
	 */
	public List<AssetInstVersionTaxonomy> getAssetInstancesAssignedForTaxonomy(
			Long taxonomyId, String userName, Connection conn)
					throws RepoproException {
		if(log.isTraceEnabled()){
			log.trace("getAssetInstancesAssignedForTaxonomy || begin with taxonomyId : "+ taxonomyId + " userName : "+ userName);
		}
		Connection conn1 = null;
		PreparedStatement preparedStm = null;
		PreparedStatement preparedSt = null;
		ResultSet resultSet = null;
		ResultSet relset = null;
		AdminAccessName adminAccessName = null;
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		AssetInstVersionTaxonomy assetInstVersionTaxonomy = null;
		List<AssetInstVersionTaxonomy> assetInstVersionTaxonomyList = new ArrayList<AssetInstVersionTaxonomy>();
		boolean flag = false;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancesAssignedForTaxonomy || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (userName.equalsIgnoreCase("roleAnonymous")) {

				preparedStm = conn
						.prepareStatement(PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_INSTANCE_TAXONOMY_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getAssetInstancesAssignedForTaxonomy || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ASSET_INSTANCE_TAXONOMY_FOR_GUEST));
				}

				preparedStm.setLong(Constants.ONE, taxonomyId);
				resultSet = preparedStm.executeQuery();
				while (resultSet.next()) {
					assetInstVersionTaxonomy = new AssetInstVersionTaxonomy();
					assetInstVersionTaxonomy.setAssetName(resultSet
							.getString("asset_name"));
					assetInstVersionTaxonomy.setAssetId(resultSet.getLong("asset_id"));
					assetInstVersionTaxonomy.setAssetInstVersionId(resultSet
							.getLong("asset_instance_version_id"));
					assetInstVersionTaxonomy.setAssetInstanceName(resultSet
							.getString("asset_inst_name"));
					assetInstVersionTaxonomy.setVersionable(resultSet
							.getBoolean("versionable"));
					if (assetInstVersionTaxonomy.isVersionable()) {
						assetInstVersionTaxonomy.setVersionName(resultSet
								.getString("version_name"));
					} else {
						assetInstVersionTaxonomy
						.setVersionName(Constants.ASSET_INSTANCE_VERSIONNAME);
					}
					assetInstVersionTaxonomy.setOverview(resultSet
							.getString("description"));

					assetInstVersionTaxonomyList.add(assetInstVersionTaxonomy);

					if (log.isTraceEnabled()) {
						log.trace("getAssetInstancesAssignedForTaxonomy || returning resultset  : "
								+ assetInstVersionTaxonomy.toString());
					}
				}

			} else {

				preparedStm = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ADMIN_RIGHT));
				if (log.isTraceEnabled()) {
					log.trace("getAssetInstancesAssignedForTaxonomy || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ADMIN_RIGHT));
				}
				preparedStm.setString(Constants.ONE, userName);
				resultSet = preparedStm.executeQuery();

				while (resultSet.next()) {
					adminAccessName = new AdminAccessName();
					adminAccessName.setUserName(resultSet
							.getString("user_name"));
					adminAccessName.setGroupName(resultSet
							.getString("group_name"));
					adminAccessName.setRoleName(resultSet
							.getString("role_name"));
					adminAccessNameList.add(adminAccessName);
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstancesAssignedForTaxonomy || returning resultset for admin check : "
								+ adminAccessName.toString());
					}
				}

				for (AdminAccessName adminAccess : adminAccessNameList) {
					if (adminAccess.getUserName().equalsIgnoreCase("admin")
							|| adminAccess.getGroupName().equalsIgnoreCase(
									"group-admin")
									|| adminAccess.getRoleName().equalsIgnoreCase(
											"role-admin")) {
						flag = true;
					}
				}

				if (flag) {
					preparedSt = conn
							.prepareStatement(PropertyFileReader
									.getInstance()
									.getValue(
											Constants.GET_ASSET_INSTANCE_TAXONOMY_FOR_ADMIN));
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstancesAssignedForTaxonomy || "
								+ PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_INSTANCE_TAXONOMY_FOR_ADMIN));
					}
					preparedSt.setLong(Constants.ONE, taxonomyId);
					relset = preparedSt.executeQuery();
					while (relset.next()) {
						assetInstVersionTaxonomy = new AssetInstVersionTaxonomy();
						assetInstVersionTaxonomy.setAssetName(relset
								.getString("asset_name"));
						assetInstVersionTaxonomy.setAssetId(relset.getLong("asset_id"));
						assetInstVersionTaxonomy.setAssetInstVersionId(relset
								.getLong("asset_instance_version_id"));
						assetInstVersionTaxonomy.setAssetInstanceName(relset
								.getString("asset_inst_name"));
						assetInstVersionTaxonomy.setVersionable(relset
							       .getBoolean("versionable"));
						if (assetInstVersionTaxonomy.isVersionable()) {
							assetInstVersionTaxonomy.setVersionName(relset
									.getString("version_name"));
						} else {
							assetInstVersionTaxonomy
							.setVersionName(Constants.ASSET_INSTANCE_VERSIONNAME);
						}
						assetInstVersionTaxonomy.setOverview(relset
								.getString("description"));

						assetInstVersionTaxonomyList
						.add(assetInstVersionTaxonomy);

						if (log.isTraceEnabled()) {
							log.trace("getAssetInstancesAssignedForTaxonomy || returning resultset  : "
									+ assetInstVersionTaxonomy.toString());
						}
					}

				} else {
					preparedSt = conn
							.prepareStatement(PropertyFileReader
									.getInstance()
									.getValue(
											Constants.GET_ASSET_INSTANCE_TAXONOMY_FOR_NON_ADMIN_USER));
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstancesAssignedForTaxonomy || "
								+ PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_INSTANCE_TAXONOMY_FOR_NON_ADMIN_USER));
					}

					preparedSt.setString(Constants.ONE, userName);
					preparedSt.setLong(Constants.TWO, taxonomyId);
					relset = preparedSt.executeQuery();
					while (relset.next()) {
						assetInstVersionTaxonomy = new AssetInstVersionTaxonomy();
						assetInstVersionTaxonomy.setAssetName(relset
								.getString("asset_name"));
						assetInstVersionTaxonomy.setAssetId(relset.getLong("asset_id"));
						assetInstVersionTaxonomy.setAssetInstVersionId(relset
								.getLong("asset_instance_version_id"));
						assetInstVersionTaxonomy.setAssetInstanceName(relset
								.getString("asset_inst_name"));
						assetInstVersionTaxonomy.setVersionable(relset
							       .getBoolean("versionable"));
						if (assetInstVersionTaxonomy.isVersionable()) {
							assetInstVersionTaxonomy.setVersionName(relset
									.getString("version_name"));
						} else {
							assetInstVersionTaxonomy
							.setVersionName(Constants.ASSET_INSTANCE_VERSIONNAME);
						}
						assetInstVersionTaxonomy.setOverview(relset
								.getString("description"));

						assetInstVersionTaxonomyList
						.add(assetInstVersionTaxonomy);

						if (log.isTraceEnabled()) {
							log.trace("getAssetInstancesAssignedForTaxonomy || returning resultset  : "
									+ assetInstVersionTaxonomy.toString());
						}
					}
				}

			}
			if (log.isDebugEnabled()) {
				log.debug("getAssetInstancesAssignedForTaxonomy || returning resultset  : "
						+ assetInstVersionTaxonomyList.toString());
			}
		} catch (SQLException e) {
			log.error("getAssetInstancesAssignedForTaxonomy ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.GET_ASSETINSTANCES_ASSIGNED_FOR_TAXONOMY_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getAssetInstancesAssignedForTaxonomy ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getAssetInstancesAssignedForTaxonomy ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getAssetInstancesAssignedForTaxonomy ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(relset);
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedSt);
			DBConnection.closePreparedStatement(preparedStm);
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancesAssignedForTaxonomy ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		log.trace("getAssetInstancesAssignedForTaxonomy || exit");

		return assetInstVersionTaxonomyList;
	}

	/**
	 * @method getAllTaxonomiesByAssetId
	 * @description get taxonomy by asset
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<TaxonomyMaster> getAllTaxonomiesByAssetId(Long assetId,
			Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAllTaxonomiesByAssetId() || Begin with assetId : "+ assetId);
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesByAssetId() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ALL_TAXONOMIES_BY_ASSETID));
			preparedStmt.setLong(Constants.ONE, assetId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesByAssetId() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES_BY_ASSETID));
			}

			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getAllTaxonomiesByAssetId() ||"
							+ taxonomy.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllTaxonomiesByAssetId() ||"
						+ taxonomylist.toString());
			}

		} catch (SQLException e) {
			log.error("getAllTaxonomiesByAssetId || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllTaxonomiesByAssetId || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllTaxonomiesByAssetId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllTaxonomiesByAssetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesByAssetId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		log.trace("getAllTaxonomiesByAssetId() || End");

		return taxonomylist;
	}

	/**
	 * @method getAllTaxonomyUsedByAssets
	 * @description get list of taxonomies used by assets
	 * @param conn
	 * @return List<TaxonomyMaster>
	 * @throws RepoproException
	 */
	public List<TaxonomyMaster> getAllTaxonomyUsedByAssets(Connection conn)
			throws RepoproException {

		log.trace("getAllTaxonomiesByAssetId() || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomyUsedByAssets() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ALL_TAXONOMIES_USED_BY_ASSETS));
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomyUsedByAssets() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES_USED_BY_ASSETS));
			}

			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getAllTaxonomyUsedByAssets() ||"
							+ taxonomy.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllTaxonomyUsedByAssets() ||"
						+ taxonomylist.toString());
			}

		} catch (SQLException e) {
			log.error("getAllTaxonomyUsedByAssets || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllTaxonomyUsedByAssets || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllTaxonomyUsedByAssets || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllTaxonomyUsedByAssets || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomyUsedByAssets || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		log.trace("getAllTaxonomyUsedByAssets() || End");

		return taxonomylist;
	}
	
	/**
	 * @method addassignedTaxonomies
	 * @descripton adding assigned  taxonomies name by taxonomy id
	 * @param taxonomyId,taxonomyName,assetId
	 * @param conn
	 * @throws RepoproException
	 */
	@SuppressWarnings("resource")
	public void addassignedTaxonomies(Long assetId,Map<Long,String> assignedTaxonomies, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addassignedTaxonomies || Begin with assetId : " + assetId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("addassignedTaxonomies || "+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_ASSIGNED_TAXONOMIES_BY_ASSET_ID));
			pstmt.setLong(Constants.ONE, assetId);
			if (log.isTraceEnabled()) {
				log.trace("addassignedTaxonomies || "+ PropertyFileReader.getInstance().getValue(Constants.DELETE_ASSIGNED_TAXONOMIES_BY_ASSET_ID));
			}
			int result = pstmt.executeUpdate();

			pstmt1 = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_ASSIGNED_TAXONOMIES_BY_ASSET_ID));
			Iterator<Entry<Long, String>> it = assignedTaxonomies.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();
				pstmt1.setLong(Constants.ONE, Long.parseLong(pair.getKey().toString()));
				pstmt1.setLong(Constants.TWO, assetId);
				pstmt1.executeUpdate();
			}
		} catch (SQLException e) {
			log.error("addassignedTaxonomies || "
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_NOT_DELETED));
		} catch (IOException e) {
			log.error("addassignedTaxonomies || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addassignedTaxonomies || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addassignedTaxonomies || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closePreparedStatement(pstmt1);
			if (log.isTraceEnabled()) {
				log.trace("addassignedTaxonomies || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("addassignedTaxonomies || End");
		}
	}



	/**
	 * @method : getTaxonomySubscriptionForUser
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<UserTaxonomySubscription> getTaxonomySubscriptionForUser(String userName, Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getTaxonomySubscriptionForUser || Begin with userName : "+ userName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		UserTaxonomySubscription uts = null;
		List<UserTaxonomySubscription> userTaxList = new ArrayList<UserTaxonomySubscription>();

		try {
			if (log.isTraceEnabled()){
				log.trace("getTaxonomySubscriptionForUser || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_TAXONOMY_SUBSCRIPTION_BY_USER));

			pstmt.setString(Constants.ONE, userName);

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomySubscriptionForUser || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_TAXONOMY_SUBSCRIPTION_BY_USER));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				uts = new UserTaxonomySubscription();
				uts.setUserTaxonomySubscriptionId(rs.getLong("user_taxonomy_subscription_id"));
				uts.setUserId(rs.getLong("user_id"));
				uts.setTaxonomyId(rs.getLong("taxonomy_id"));
				userTaxList.add(uts);

				if(log.isTraceEnabled()){
					log.trace("getTaxonomySubscriptionForUser || "+ uts.toString());
				}
			}

			if(log.isDebugEnabled()){
				log.debug("getTaxonomySubscriptionForUser || "+userTaxList.toString());
			}


		} catch (SQLException e) {
			log.error("getTaxonomySubscriptionForUser || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getTaxonomySubscriptionForUser || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getTaxonomySubscriptionForUser || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getTaxonomySubscriptionForUser || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomySubscriptionForUser || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getTaxonomySubscriptionForUser || end");
		}
		return userTaxList;
	}
	/**
	 * @method getTaxonomyId
	 * @param taxonomyName
	 * @param conn
	 * @throws RepoproException
	 */
	public Long getTaxonomyIdByName(String taxonomyName,Connection conn)
			throws RepoproException {

		log.trace("getTaxonomyIdByName() || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Long taxonomyId=null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomyIdByName() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_TAXONOMY_ID_BY_NAME));
			preparedStmt.setString(Constants.ONE,taxonomyName);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomyIdByName() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES));
			}

			while (rs.next()) {
				taxonomyId=rs.getLong("taxonomy_id");
			}
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomyIdByName() ||" + taxonomyId);
			}

		} catch (SQLException e) {
			log.error("getTaxonomyIdByName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getTaxonomyIdByName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getTaxonomyIdByName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getTaxonomyIdByName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomyIdByName || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getTaxonomyIdByName || End");

		return taxonomyId;
	}

	/*public Long getParentTaxIdByTaxId(Long taxonomyId, Connection conn)throws RepoproException {

		log.trace("getParentTaxIdByTaxId() || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Long parentTaxonomyId=null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getParentTaxIdByTaxId() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_PARENT_TAXONOMY_ID_BY_TAXONOMY_ID));
			preparedStmt.setLong(Constants.ONE,taxonomyId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getParentTaxIdByTaxId() ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAXONOMIES));
			}

			while (rs.next()) {
				parentTaxonomyId=rs.getLong("parent_taxonomy_id");
			}
			if (log.isTraceEnabled()) {
				log.trace("getParentTaxIdByTaxId() ||" + taxonomyId);
			}

		} catch (SQLException e) {
			log.error("getParentTaxIdByTaxId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getParentTaxIdByTaxId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getParentTaxIdByTaxId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getParentTaxIdByTaxId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getParentTaxIdByTaxId || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getParentTaxIdByTaxId || End");

		return parentTaxonomyId;
	}*/
	
	/**
	 * @method getAllTaxonomiesByParentId
	 * @description get all taxonomies by parent id
	 * @param parentTaxonomyId
	 * @param conn
	 * @return List<TaxonomyMaster>
	 * @throws RepoproException
	 */
	public TaxonomyMaster getTaxonomyNameByParentId(String taxonomyName,
			Long parentTaxonomyId, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getTaxonomyNameByParentId() ||parentTaxonomyId:"
					+ parentTaxonomyId + " ||Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		TaxonomyMaster taxonomy = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomyNameByParentId() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_TAXONOMY_NAME_BY_PARENT_ID));
			preparedStmt.setString(Constants.ONE, taxonomyName);
			preparedStmt.setLong(Constants.TWO, parentTaxonomyId);
			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomiesByParentId() ||"
						+ PropertyFileReader
						.getInstance()
						.getValue(
								Constants.GET_TAXONOMY_NAME_BY_PARENT_ID));
			}

			while (resultSet.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(resultSet.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(resultSet.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(resultSet.getLong("parent_taxonomy_id"));
				if (log.isTraceEnabled()) {
					log.trace("getAllTaxonomiesByParentId() ||"+ taxonomy.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAllTaxonomiesByParentId || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllTaxonomiesByParentId || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllTaxonomiesByParentId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllTaxonomiesByParentId || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllTaxonomies || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getAllTaxonomiesByParentId() ||parentTaxonomyId:"
					+ parentTaxonomyId + " || End");
		}
		return taxonomy;
	}
	
	
	/**
	 * @method : getTaxonomyDetailsByTaxIdAivId
	 * @param aivId
	 * @param taxonomyId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetInstVersionTaxonomy getTaxonomyDetailsByTaxIdAivId(Long aivId, String taxonomyId, Connection conn)
			throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getTaxonomyDetailsByTaxIdAivId() || aivId : "+ aivId +"\t taxonomyId" + taxonomyId + "||Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<AssetInstVersionTaxonomy> taxonomylist = new ArrayList<AssetInstVersionTaxonomy>();
		AssetInstVersionTaxonomy aivt = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomyDetailsByTaxIdAivId() ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RET_TAXONOMY_DETAILS_BY_TAX_ID_AIV_ID));
			preparedStmt.setLong(Constants.ONE, aivId);
			preparedStmt.setString(Constants.TWO, taxonomyId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getTaxonomyDetailsByTaxIdAivId() ||"
						+ PropertyFileReader.getInstance().getValue(Constants.RET_TAXONOMY_DETAILS_BY_TAX_ID_AIV_ID));
			}

			while (rs.next()) {
				aivt = new AssetInstVersionTaxonomy();
				aivt.setAssetInstVersionId(rs.getLong("asset_inst_version_id"));
				aivt.setAssetInstVersionTaxonomyId(rs.getLong("aiv_taxonomy_id"));
				taxonomylist.add(aivt);
				if (log.isTraceEnabled()) {
					log.trace("getTaxonomyDetailsByTaxIdAivId() ||" + aivt.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getTaxonomyDetailsByTaxIdAivId || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getTaxonomyDetailsByTaxIdAivId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getTaxonomyDetailsByTaxIdAivId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getTaxonomyDetailsByTaxIdAivId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomyDetailsByTaxIdAivId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getTaxonomyDetailsByTaxIdAivId() || End");
		}
		return aivt;
	}
	
	
	/**
	 * @method getAllFilteredTaxonomiesBySearchData
	 * @description get taxonomy by asset
	 * @param searchString
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<TaxonomyMaster> getAllFilteredTaxonomiesBySearchData(String searchString,String subsFlag,long userId,boolean hideFlag,
			Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAllFilteredTaxonomiesBySearchData() || Begin with assetId : "+ searchString);
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<TaxonomyMaster> taxonomylist = new ArrayList<TaxonomyMaster>();
		TaxonomyMaster taxonomy = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredTaxonomiesBySearchData() ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			
			if(hideFlag){
				if(subsFlag.equalsIgnoreCase("true")){
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(
									Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_SUBSCRIBE_HIDE_UNUSED));
					preparedStmt.setString(Constants.ONE, searchString);
					preparedStmt.setString(Constants.TWO, searchString);
					preparedStmt.setString(Constants.THREE, searchString);
					preparedStmt.setLong(Constants.FOUR, userId);
					rs = preparedStmt.executeQuery();

					if (log.isTraceEnabled()) {
						log.trace("getAllFilteredTaxonomiesBySearchData() ||"
								+ PropertyFileReader.getInstance().getValue(
										Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_SUBSCRIBE_HIDE_UNUSED));
					}
				}else if(subsFlag.equalsIgnoreCase("false")){
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(
									Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_UNSUBSCRIBE_HIDE_UNUSED));
					preparedStmt.setLong(Constants.ONE, userId);
					preparedStmt.setString(Constants.TWO, searchString);
					preparedStmt.setString(Constants.THREE, searchString);
					preparedStmt.setString(Constants.FOUR, searchString);
					rs = preparedStmt.executeQuery();

					if (log.isTraceEnabled()) {
						log.trace("getAllFilteredTaxonomiesBySearchData() ||"
								+ PropertyFileReader.getInstance().getValue(
										Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_UNSUBSCRIBE_HIDE_UNUSED));
					}
				}else{
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(
									Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_HIDE_UNUSED));
					preparedStmt.setLong(Constants.ONE, userId);
					preparedStmt.setString(Constants.TWO, "%"+searchString+"%");
					rs = preparedStmt.executeQuery();

					if (log.isTraceEnabled()) {
						log.trace("getAllFilteredTaxonomiesBySearchData() ||"
								+ PropertyFileReader.getInstance().getValue(
										Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_HIDE_UNUSED));
					}
				}
			}else{
				if(subsFlag.equalsIgnoreCase("true")){
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(
									Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_SUBSCRIBE));
					preparedStmt.setString(Constants.ONE, searchString);
					preparedStmt.setString(Constants.TWO, searchString);
					preparedStmt.setString(Constants.THREE, searchString);
					preparedStmt.setLong(Constants.FOUR, userId);
					rs = preparedStmt.executeQuery();

					if (log.isTraceEnabled()) {
						log.trace("getAllFilteredTaxonomiesBySearchData() ||"
								+ PropertyFileReader.getInstance().getValue(
										Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_SUBSCRIBE));
					}
				}else if(subsFlag.equalsIgnoreCase("false")){
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(
									Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_UNSUBSCRIBE));
					preparedStmt.setLong(Constants.ONE, userId);
					preparedStmt.setString(Constants.TWO, searchString);
					preparedStmt.setString(Constants.THREE, searchString);
					preparedStmt.setString(Constants.FOUR, searchString);
					rs = preparedStmt.executeQuery();

					if (log.isTraceEnabled()) {
						log.trace("getAllFilteredTaxonomiesBySearchData() ||"
								+ PropertyFileReader.getInstance().getValue(
										Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA_UNSUBSCRIBE));
					}
				}else{
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(
									Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA));
					preparedStmt.setLong(Constants.ONE, userId);
					preparedStmt.setString(Constants.TWO, "%"+searchString+"%");
					rs = preparedStmt.executeQuery();

					if (log.isTraceEnabled()) {
						log.trace("getAllFilteredTaxonomiesBySearchData() ||"
								+ PropertyFileReader.getInstance().getValue(
										Constants.GET_ALL_FILTERED_TAXONOMIES_BY_FILETR_DATA));
					}
				}
			}

			while (rs.next()) {
				taxonomy = new TaxonomyMaster();
				taxonomy.setTaxonomyId(rs.getLong("taxonomy_id"));
				taxonomy.setTaxonomyName(rs.getString("taxonomy_name"));
				taxonomy.setParenttaxonomyId(rs.getLong("parent_taxonomy_id"));
				taxonomy.setSubscription(rs.getString("subscribed"));
				taxonomylist.add(taxonomy);
				if (log.isTraceEnabled()) {
					log.trace("getAllFilteredTaxonomiesBySearchData() ||"
							+ taxonomy.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllFilteredTaxonomiesBySearchData() ||"
						+ taxonomylist.toString());
			}

		} catch (SQLException e) {
			log.error("getAllFilteredTaxonomiesBySearchData || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllFilteredTaxonomiesBySearchData || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllFilteredTaxonomiesBySearchData || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllFilteredTaxonomiesBySearchData || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredTaxonomiesBySearchData || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		log.trace("getAllFilteredTaxonomiesBySearchData() || End");

		return taxonomylist;
	}
	
}
