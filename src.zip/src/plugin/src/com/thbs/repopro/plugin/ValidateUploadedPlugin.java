package com.thbs.repopro.plugin;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.sql.Connection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AssetRepresentation;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.DBConnection;

public class ValidateUploadedPlugin {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	/**
	 * @param className
	 * @param jarPath
	 * @param files
	 * @param outputPath
	 * @return
	 * @throws Exception
	 */
	public boolean invokeMethodFromJar (String className, String jarPath, File file, String outputPath) throws Exception {
		Class<AssetRepresentationInterface> clazz = loadCustomPlugin(className,jarPath);
		boolean status = clazz.newInstance().generateView(file, outputPath);
		return status;
	}
	
	
	/**
	 * @param className
	 * @param jarPath
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Class<AssetRepresentationInterface> loadCustomPlugin (String className, String jarPath) throws Exception {
		Class<AssetRepresentationInterface> result = null;
		try {
			URLClassLoader classLoader = getJarClassLoader(jarPath);
			if (classLoader != null) {
				Class<?> clazz = classLoader.loadClass(className);
				if (AssetRepresentationInterface.class.isAssignableFrom(clazz)) {
					result = (Class<AssetRepresentationInterface>) clazz;	
					
					if(result.isInterface()) {
						log.error("loadCustomPlugin || " + "Invalid plugin implementation");
						throw new RepoproException("Invalid plugin implementation");
					}
					
				} else {
					//Error logging for invalid plugin implementation
					log.error("loadCustomPlugin || " + "Invalid plugin implementation");
					throw new RepoproException("Invalid plugin implementation");
				}
			} else {
				//Error logging for URLClassLoader being null
				log.error("loadCustomPlugin || " + "URLClassLoader : Null");
				throw new RepoproException("URLClassLoader : Null");

			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
			
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		return result;
	}
	
	/**
	 * @param jarPath
	 * @return
	 * @throws Exception
	 */
	public URLClassLoader getJarClassLoader(String jarPath) throws Exception {
		URLClassLoader urlClassLoader = null;
		String filepath = jarPath;
		if (filepath != null && !filepath.equals("")) {
			File file = new File(filepath);
			if (file.exists()) {
				URL jarfile = file.toURI().toURL();
				urlClassLoader = URLClassLoader.newInstance(new URL[] { jarfile },
						ValidateUploadedPlugin.class.getClassLoader());
			} else {
				//Error logging for invalid file path
				log.error("loadCustomPlugin || " + "Plugin jar not found in the path");
				throw new RepoproException("Plugin jar not found in the path");				
			}
		} 

		return urlClassLoader;
	}
	
	public static void main(String[] args) throws Exception {
		/*ValidateUploadedPlugin vup = new ValidateUploadedPlugin();
		File file = new File("D:\\test\\openapi.json");
		//"D:\\test\\swagger-view-plugin.jar" "D:\\test\\testjar\\testjar2.jar"
		vup.invokeMethodFromJar("com.plugin.view.main.PluginViewMain", "D:\\test\\swagger-view-plugin.jar", file, "D:\\test\\output\\");
		*/
		
		AssetRepresentation assetRep = new AssetRepresentation();
		assetRep.setAssetId((long) 1);
		assetRep.setJarName("swagger-view-plugin.jar");
		assetRep.setJarPath("D:\\test\\swagger-view-plugin.jar");		
		assetRep.setAllowedExtensions(".json~.yaml");
		assetRep.setImplementedClassName("com.plugin.view.main.PluginViewMain");
		
		AssetRepresentationDao ard = new AssetRepresentationDao();
		
		Connection conn = DBConnection.getInstance().getConnection();
		conn.setAutoCommit(false);
		
		ard.addAssetRepresentation(assetRep, conn);
		
		conn.commit();
		
		List<AssetRepresentation> assetlist = ard.getAllAssetRepresentations(conn);
		
		for (AssetRepresentation assetRepre : assetlist) {
			System.out.println(assetRepre.getJarName());
			String[] arr = assetRepre.getAllowedExtensions().split("~");
			for (String str : arr) {
				System.out.println(str);	
			}				
		}
	}

}
