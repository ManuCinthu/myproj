package com.thbs.repopro.plugin;

import java.io.File;

public interface AssetRepresentationInterface {
	
	/**
	 * @description To generate HTML output at specified path
	 * @param inputFiles
	 * @param outputPath
	 * @return boolean
	 * @throws Exception
	 */
	public boolean generateView(File inputFile, String outputPath) throws Exception;
}
