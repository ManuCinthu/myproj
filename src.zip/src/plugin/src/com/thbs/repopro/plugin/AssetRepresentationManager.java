package com.thbs.repopro.plugin;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.io.Files;
import com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException;
import com.thbs.repopro.dto.AssetInstanceRepresentation;
import com.thbs.repopro.dto.AssetRepresentation;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

import net.minidev.json.JSONArray;


@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Path("/assetrepresentationmanager")
public class AssetRepresentationManager {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	@GET
	@Path("/getallrepresentations")
	public Response getAllAssetRepresentationMain() throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("getAssetRepresentations || Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<AssetRepresentation> repList = null;
		Connection conn = null;
		
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetRepresentationDao assetRepDao = new AssetRepresentationDao();
			repList = assetRepDao.getAllAssetRepresentations(conn);		
			if(repList.isEmpty()) {
				retMsg = Constants.REPRESENTATION_DATA_NOT_FOUND;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}else {
				retMsg = Constants.GET_ALL_REPRESENTATION;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}
		}catch(Exception e){
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;					
		}finally {
			DBConnection.closeDbConnection(conn);
		}	
		
		
		if (log.isTraceEnabled()) {
			log.trace("getAssetRepresentations || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(repList)))
				.build();
		
	}
	

	@POST
	@Path("/validateuploadedjar")
	@Encoded
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response validateUploadedJar(@QueryParam ("implementedClassName") String implementedClassName, FormDataMultiPart dataMultiPart ){
		
		if (log.isTraceEnabled()) {
			log.trace("validateUploadedJar || Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		InputStream in = null;
		FileOutputStream outStream = null;
		File uploadedJar = null;
		
		try{
			
			FormDataBodyPart dataBodyPart = dataMultiPart.getField("uploadedjar");
			
			in = dataBodyPart.getEntityAs(InputStream.class);
			
			uploadedJar = File.createTempFile("uploadedJar", ".jar");			
			outStream = new FileOutputStream(uploadedJar);
			
			IOUtils.copy(in, outStream);
			
			ValidateUploadedPlugin vup = new ValidateUploadedPlugin();
			
			Class<AssetRepresentationInterface> clazz = vup.loadCustomPlugin(implementedClassName, uploadedJar.getAbsolutePath());
						
			retMsg = Constants.SUCCESS;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		} finally {
			try {
				in.close();
				outStream.close();
				uploadedJar.delete();
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}		
		
		
		if (log.isTraceEnabled()) {
			log.trace("validateUploadedJar || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
				.build();
		
	}
	
	@POST
	@Path("/addassetrepresentation")
	@Encoded
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response addAssetRepresentation(@FormDataParam ("repjson") String repjson, 
												FormDataMultiPart dataMultiPart ){
		
		if (log.isTraceEnabled()) {
			log.trace("addAssetVisualization || Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		InputStream in = null;
		FileOutputStream outStream = null;
		File uploadedJar = null;
		AssetRepresentationDao repDao = new AssetRepresentationDao();
		ValidateUploadedPlugin vup = new ValidateUploadedPlugin();
		String repName = null;
		String implClassName = null;
		org.json.JSONArray allowedExt = null;
		Connection conn = null;
		
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			String jsonData = repjson;
			JSONObject jsonObj = new JSONObject(jsonData);
			repName = (String) jsonObj.get("AssetrepName");
			implClassName = (String) jsonObj.get("ImplementedClassName");
			allowedExt =  jsonObj.getJSONArray("AllowedExtension");
			
			FormDataBodyPart dataBodyPart = dataMultiPart.getField("uploadedjar");
			
			AssetRepresentation assetRep = repDao.getAssetRepresentationByName(conn, repName);
			if(assetRep != null) {
				retStat = Status.CONFLICT;
				retMsg = "Visualization name already exists!";
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
			} else {			
				if (dataBodyPart != null) {
					InputStream tempIn = dataBodyPart.getEntityAs(InputStream.class);
					in = dataBodyPart.getEntityAs(InputStream.class);
					File tempJar = File.createTempFile("uploadedJar", ".jar");			
					FileOutputStream tempStream = new FileOutputStream(tempJar);				
					IOUtils.copy(tempIn, tempStream);
					tempJar.deleteOnExit();
					
					//Validate Uploaded Jar
					Class<AssetRepresentationInterface> clazz = vup.loadCustomPlugin(implClassName, tempJar.getAbsolutePath());
					
					//Copy Uploaded Jar to designated path
					File directory = new File(Constants.JAR_FILE_PATH);
					if(!directory.exists()) {
						directory.mkdir();
					}
					uploadedJar = new File(Constants.JAR_FILE_PATH + repName + ".jar"); 
					if (uploadedJar.exists()) {
						uploadedJar.delete();
					}					
					outStream = new FileOutputStream(uploadedJar);
					
					IOUtils.copy(in, outStream);
					
					//Validate Uploaded Jar
					Class<AssetRepresentationInterface> clazz1 = vup.loadCustomPlugin(implClassName, uploadedJar.getAbsolutePath());
					
					//Save Asset Visualization
					AssetRepresentation assetRepresentation = new AssetRepresentation();
					assetRepresentation.setRepresentationName(repName);
					assetRepresentation.setImplementedClassName(implClassName);
					assetRepresentation.setAllowedExtensions(allowedExt.toString());
					assetRepresentation.setJarName(uploadedJar.getName());
					assetRepresentation.setJarPath(uploadedJar.getPath());
					
					repDao.addAssetRepresentation(assetRepresentation, conn);
					
					conn.commit();
					retMsg = Constants.SUCCESS;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					
				} else {				
					retStat = Status.BAD_REQUEST;
					retMsg = "Uploaded Jar File Missing or invalid";
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;				
				}
			}
			
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = "Either Class Name or uploaded jar file is invalid!";
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		} finally {
			try {
				in.close();
				outStream.close();
				DBConnection.closeDbConnection(conn);
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}		
		
		
		if (log.isTraceEnabled()) {
			log.trace("addAssetVisualization || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
				.build();
		
	}
	
	@POST
	@Path("/updateassetrepresentation")
	@Encoded
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response updateAssetRepresentation(@FormDataParam ("repjson") String repjson, 
												FormDataMultiPart dataMultiPart ){
		
		if (log.isTraceEnabled()) {
			log.trace("addAssetVisualization || Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		InputStream in = null;
		FileOutputStream outStream = null;
		File uploadedJar = null;
		AssetRepresentationDao repDao = new AssetRepresentationDao();
		ValidateUploadedPlugin vup = new ValidateUploadedPlugin();
		String repId = null;
		String repName = null;
		String implClassName = null;
		org.json.JSONArray allowedExt = null;
		Connection conn = null;
		AssetRepresentation assetRepresentation = null;
		
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);		
			
			String jsonData = repjson;
			JSONObject jsonObj = new JSONObject(jsonData);
			repId = (String) jsonObj.get("RepresentId");
			repName = (String) jsonObj.get("AssetrepName");
			implClassName = (String) jsonObj.get("ImplementedClassName");
			allowedExt =  jsonObj.getJSONArray("AllowedExtension");
			
			assetRepresentation = repDao.getAssetRepresentationById(conn, Long.parseLong(repId));			
			
			FormDataBodyPart dataBodyPart = dataMultiPart.getField("uploadedjar");
					
			if (dataBodyPart != null) {
				InputStream tempIn = dataBodyPart.getEntityAs(InputStream.class);
				in = dataBodyPart.getEntityAs(InputStream.class);
				
				File tempJar = File.createTempFile("uploadedJar", ".jar");			
				FileOutputStream tempStream = new FileOutputStream(tempJar);				
				IOUtils.copy(tempIn, tempStream);
				tempJar.deleteOnExit(); 
				
				//Validate Uploaded Jar
				Class<AssetRepresentationInterface> clazz = vup.loadCustomPlugin(implClassName, tempJar.getAbsolutePath());				
								
				//Copy Uploaded Jar to designated path
				File directory = new File(Constants.JAR_FILE_PATH);
				if(!directory.exists()) {
					directory.mkdir();
				}
				uploadedJar = new File(Constants.JAR_FILE_PATH + repName + ".jar");   
				if (uploadedJar.exists()) {
					uploadedJar.delete();
				}
				outStream = new FileOutputStream(uploadedJar);				
				IOUtils.copy(in, outStream);	
				
			} else {
				if (!assetRepresentation.getRepresentationName().equalsIgnoreCase(repName)) {
					AssetRepresentation assetRep = repDao.getAssetRepresentationByName(conn, repName);
					if(assetRep != null) {
						retStat = Status.CONFLICT;
						retMsg = "Visualization name already exists!";
						retScsFlr = Constants.FAILURE;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;
					} else {
						uploadedJar = new File(assetRepresentation.getJarPath());						
						File renameJar = new File(Constants.JAR_FILE_PATH + repName + ".jar");
						FileUtils.copyFile(uploadedJar, renameJar);
						uploadedJar.delete();
						//uploadedJar.renameTo(renameJar);
						uploadedJar = new File(renameJar.getPath());
						
					}
				} else {
					uploadedJar = new File(assetRepresentation.getJarPath());
				}
			}									
			
			//Validate Uploaded Jar
			Class<AssetRepresentationInterface> clazz = vup.loadCustomPlugin(implClassName, uploadedJar.getAbsolutePath());
			
			//Save Asset Visualization
			assetRepresentation.setRepresentationName(repName);
			assetRepresentation.setImplementedClassName(implClassName);
			assetRepresentation.setAllowedExtensions(allowedExt.toString());
			assetRepresentation.setJarName(uploadedJar.getName());
			assetRepresentation.setJarPath(uploadedJar.getPath());
			
			repDao.updateAssetRepresentation(assetRepresentation, conn);
			
			conn.commit();
			retMsg = Constants.SUCCESS;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
							
				
			
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = "Either Class Name or uploaded jar file is invalid!";
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		} finally {
			try {
				if (in != null) {
					in.close();
					outStream.close();
				}	
				System.gc();
				/*uploadedJar = new File(assetRepresentation.getJarPath());
				if(uploadedJar.exists()){
					uploadedJar.delete();
				}*/
				DBConnection.closeDbConnection(conn);
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}		
		
		
		if (log.isTraceEnabled()) {
			log.trace("addAssetVisualization || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
				.build();
		
	}
	
	@DELETE
	@Path("/deleteassetrepresentation")
	public Response deleteAssetRepresentation(@QueryParam ("name") String name){
		
		if (log.isTraceEnabled()) {
			log.trace("addAssetVisualization || Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;		
		AssetRepresentationDao repDao = new AssetRepresentationDao();		
		Connection conn = null;
		boolean deleteStatus = false;
		
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetRepresentation assetRep = repDao.getAssetRepresentationByName(conn, name);
			
			if (assetRep != null) {
				File jarFile = new File(assetRep.getJarPath());
				if(jarFile.exists()){
					jarFile.delete();
				}			
			}
			repDao.deleteAssetInstanceLinkedToRepresentation(conn, assetRep.getAssetRepresentationId());
			deleteStatus = repDao.deleteAssetRepresentationByName(conn, name);	
			
			if (deleteStatus) {				
				conn.commit();
				retMsg = Constants.SUCCESS;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			} else {
				retStat = Status.NOT_MODIFIED;
				retMsg = "Visualization not deleted";
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		} finally {
			try {
				DBConnection.closeDbConnection(conn);
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}		
		
		
		if (log.isTraceEnabled()) {
			log.trace("addAssetVisualization || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
				.build();
		
	}	
	
	@GET
	@Path("/getrepresentationbyassetname")
	public Response getAssetRepByAssetName (@QueryParam ("assetName") String assetName) throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("getAssetRepByAssetName || Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<AssetRepresentation> repList = new ArrayList<>();
		AssetRepresentation assetRep = null;
		
		Connection conn = null;
		
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetRepresentationDao assetRepDao = new AssetRepresentationDao();
			assetRep = assetRepDao.getAssetRepresentationByAssetName(conn, assetName);		
			
			repList.add(assetRep);
			
			retMsg = Constants.GET_ALL_REPRESENTATION;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			
		}catch(Exception e){
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;					
		}finally {
			try {
				DBConnection.closeDbConnection(conn);
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}	
		
		
		if (log.isTraceEnabled()) {
			log.trace("getAssetRepByAssetName || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(repList)))
				.build();
		
	}
	
	@GET
	@Path("/getrepresentationbyname")
	public Response getAssetRepByName (@QueryParam ("name") String name) throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("getAssetRepByName || Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<AssetRepresentation> repList = new ArrayList<>();
		AssetRepresentation assetRep = null;
		
		Connection conn = null;
		
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetRepresentationDao assetRepDao = new AssetRepresentationDao();
			assetRep = assetRepDao.getAssetRepresentationByName(conn, name);		
			
			repList.add(assetRep);
			
			retMsg = Constants.GET_ALL_REPRESENTATION;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			
		}catch(Exception e){
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;		
		}finally {
			try {
				DBConnection.closeDbConnection(conn);
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}	
		
		
		if (log.isTraceEnabled()) {
			log.trace("getAssetRepByName || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(repList)))
				.build();
		
	}	
	
	@GET
	@Path("/getinstancerepresentationbyversionid")
	public Response getInstanceRepresentationByVersionId (@Context HttpServletRequest request, @QueryParam ("versionId") String versionId) throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("getInstanceRepresentationByVersionId || Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<AssetInstanceRepresentation> instRepList = new ArrayList<>();
		AssetInstanceRepresentation assetInstRep = null;
		
		Connection conn = null;
		
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetRepresentationDao assetRepDao = new AssetRepresentationDao();
			assetInstRep = assetRepDao.getAssetInstanceRepresentationByAivId(conn, Long.parseLong(versionId));
			if(assetInstRep != null) {
				String ipAddress = request.getScheme() + "://" + request.getHeader("host") + "/repopro/visualization/";
				assetInstRep.setIpAddress(ipAddress);
				instRepList.add(assetInstRep);
				retMsg = Constants.GET_ASSET_INSTANCE_REPRESENTATION_BY_AIVID;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}else {
				retMsg = Constants.ASSET_INSTANCE_REPRESENTATION_BY_AIVID_NOT_FOUND;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}
			
		}catch(Exception e){
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;					
		}finally {
			try {
				DBConnection.closeDbConnection(conn);
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}	
		
		
		if (log.isTraceEnabled()) {
			log.trace("getInstanceRepresentationByVersionId || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(instRepList)))
				.build();
		
	}

}
