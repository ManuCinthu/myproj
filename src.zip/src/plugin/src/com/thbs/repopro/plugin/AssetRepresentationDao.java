package com.thbs.repopro.plugin;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AssetInstanceRepresentation;
import com.thbs.repopro.dto.AssetRepresentation;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class AssetRepresentationDao {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	public AssetRepresentation addAssetRepresentation(AssetRepresentation assetRepresentation, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("addAssetRepresentation || "+ assetRepresentation.toString() +" Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addAssetRepresentation || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_ASSET_REPRESENTATION));
			
			pstmt.setString(Constants.ONE, assetRepresentation.getRepresentationName());
			pstmt.setString(Constants.TWO, assetRepresentation.getJarName());
			pstmt.setString(Constants.THREE, assetRepresentation.getJarPath());
			pstmt.setString(Constants.FOUR, assetRepresentation.getImplementedClassName());
			pstmt.setString(Constants.FIVE, assetRepresentation.getAllowedExtensions());
			
			pstmt.executeUpdate();

			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				assetRepresentation.setAssetRepresentationId(rs.getLong(1));
			}
			
			
		} catch (SQLException e) {
			log.error("addAssetRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
		} catch (IOException e) {
			log.error("addAssetRepresentation || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addAssetRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addAssetRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addAssetRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}	
		
		
		if(log.isTraceEnabled()){
			log.trace("addAssetRepresentation || "+ assetRepresentation.toString() +" End");
		}
		return assetRepresentation;
		
	}
	
	
	public void addAssetRepresentationLink (long assetId, long assetRepId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("addAssetRepresentationLink Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addAssetRepresentationLink || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_ASSET_REPRESENTATION_LINK));
			
			pstmt.setLong(Constants.ONE, assetId);
			pstmt.setLong(Constants.TWO, assetRepId);	
			
			pstmt.executeUpdate();			
			
		} catch (SQLException e) {
			log.error("addAssetRepresentationLink || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
		} catch (IOException e) {
			log.error("addAssetRepresentationLink || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addAssetRepresentationLink || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addAssetRepresentationLink || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addAssetRepresentationLink || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}	
		
		
		if(log.isTraceEnabled()){
			log.trace("addAssetRepresentation End");
		}
		
	}
	
	public List<AssetRepresentation> getAllAssetRepresentations(Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllAssetRepresentations || Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<AssetRepresentation> assetRepList = new ArrayList<AssetRepresentation>();
		AssetRepresentation assetRep = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRepresentations || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ALL_ASSET_REPRESENTATION));
			
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRepresentations || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_ASSET_REPRESENTATION));
			}
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				assetRep = new AssetRepresentation();
				assetRep.setAssetRepresentationId(rs.getLong("asset_representation_id"));
				assetRep.setRepresentationName(rs.getString("representation_name"));
				assetRep.setJarName(rs.getString("jar_name"));
				assetRep.setJarPath(rs.getString("jar_path"));
				assetRep.setAllowedExtensions(rs.getString("allowed_extensions"));
				assetRep.setImplementedClassName(rs.getString("implemented_class_name"));
				
				int checkIfLinkedToAsset = getCountOfAssetRepsentationLinkByRepresentationId(conn1, assetRep.getAssetRepresentationId());
				if(checkIfLinkedToAsset > 0) {
					assetRep.setLinkedToAsset(true);
				} else {
					assetRep.setLinkedToAsset(false);
				}
				assetRepList.add(assetRep);
				
				if (log.isTraceEnabled()) {
					log.trace("getAllAssetRepresentations || " + assetRep.toString());
				}
			}
			
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetRepresentations || " + assetRepList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getAllAssetRepresentations || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage("SQLException"));
		} catch (IOException e) {
			log.error("getAllAssetRepresentations || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetRepresentations || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetRepresentations || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRepresentations || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		
		
		if(log.isTraceEnabled()){
			log.trace("getAllAssetRepresentations || "+ assetRepList.toString() +" End");
		}
		return assetRepList;
		
	}
	
	public int getCountOfAssetRepsentationLinkByRepresentationId(Connection conn, Long assetRepresentationId) throws RepoproException {
		if(log.isTraceEnabled()){
			log.trace("getAssetRepresentationByAssetName || Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int countOfAssets = 0;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getCountOfAssetRepsentationLinkByRepresentationId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_COUNT_OF_ASSET_REPRESENTATION_LINK_BY_REPRESENTATION_ID));
			
			if (log.isTraceEnabled()) {
				log.trace("getCountOfAssetRepsentationLinkByRepresentationId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_COUNT_OF_ASSET_REPRESENTATION_LINK_BY_REPRESENTATION_ID));
			}
			
			pstmt.setLong(Constants.ONE, assetRepresentationId);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				countOfAssets = rs.getInt(1);
			}
			
			
		} catch (SQLException e) {
			log.error("getCountOfAssetRepsentationLinkByRepresentationId || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage("SQLException"));
		} catch (IOException e) {
			log.error("getCountOfAssetRepsentationLinkByRepresentationId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getCountOfAssetRepsentationLinkByRepresentationId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getCountOfAssetRepsentationLinkByRepresentationId || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getCountOfAssetRepsentationLinkByRepresentationId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		
		
		if(log.isTraceEnabled()){
			log.trace("getCountOfAssetRepsentationLinkByRepresentationId || "+ countOfAssets +" End");
		}
		return countOfAssets;
	}


	public AssetRepresentation getAssetRepresentationByAssetName (Connection conn, String assetName) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAssetRepresentationByAssetName || Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetRepresentation assetRep = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetRepresentationByAssetName || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_REPRESENTATION_BY_ASSETNAME));
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetRepresentationByAssetId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_REPRESENTATION_BY_ASSETNAME));
			}
			
			pstmt.setString(Constants.ONE, assetName);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				assetRep = new AssetRepresentation();
				assetRep.setAssetRepresentationId(rs.getLong("asset_representation_id"));
				assetRep.setAssetId(rs.getLong("asset_id"));
				assetRep.setRepresentationName(rs.getString("representation_name"));
				assetRep.setJarName(rs.getString("jar_name"));
				assetRep.setJarPath(rs.getString("jar_path"));
				assetRep.setAllowedExtensions(rs.getString("allowed_extensions"));
				assetRep.setImplementedClassName(rs.getString("implemented_class_name"));
				
				
				if (log.isTraceEnabled()) {
					log.trace("getAssetRepresentationByAssetName || " + assetRep.toString());
				}
			}	
			
			
		} catch (SQLException e) {
			log.error("getAssetRepresentationByAssetName || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage("SQLException"));
		} catch (IOException e) {
			log.error("getAssetRepresentationByAssetName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetRepresentationByAssetName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetRepresentationByAssetName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetRepresentationByAssetName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		
		
		if(log.isTraceEnabled()){
			log.trace("getAssetRepresentationByAssetName || "+ assetRep.toString() +" End");
		}
		return assetRep;
		
	}
	
public AssetRepresentation getAssetRepresentationById (Connection conn, Long representationId) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAssetRepresentationById || Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetRepresentation assetRep = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetRepresentationById || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_REPRESENTATION_BY_ID));
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetRepresentationByName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_REPRESENTATION_BY_ID));
			}
			
			pstmt.setLong(Constants.ONE, representationId);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				assetRep = new AssetRepresentation();
				assetRep.setAssetRepresentationId(rs.getLong("asset_representation_id"));
				assetRep.setRepresentationName(rs.getString("representation_name"));
				assetRep.setJarName(rs.getString("jar_name"));
				assetRep.setJarPath(rs.getString("jar_path"));
				assetRep.setAllowedExtensions(rs.getString("allowed_extensions"));
				assetRep.setImplementedClassName(rs.getString("implemented_class_name"));
				
				
				if (log.isTraceEnabled()) {
					log.trace("getAssetRepresentationByName || " + assetRep.toString());
				}
			}	
			
			
		} catch (SQLException e) {
			log.error("getAssetRepresentationById || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage("SQLException"));
		} catch (IOException e) {
			log.error("getAssetRepresentationById || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetRepresentationById || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetRepresentationById || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetRepresentationById || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		
		
		if(log.isTraceEnabled()){
			log.trace("getAssetRepresentationById || "+ assetRep.toString() +" End");
		}
		return assetRep;
		
	}
	
	
public AssetRepresentation getAssetRepresentationByName (Connection conn, String representationName) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAssetRepresentationByName || Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetRepresentation assetRep = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetRepresentationByName || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_REPRESENTATION_BY_NAME));
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetRepresentationByName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_REPRESENTATION_BY_NAME));
			}
			
			pstmt.setString(Constants.ONE, representationName);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				assetRep = new AssetRepresentation();
				assetRep.setAssetRepresentationId(rs.getLong("asset_representation_id"));
				assetRep.setRepresentationName(rs.getString("representation_name"));
				assetRep.setJarName(rs.getString("jar_name"));
				assetRep.setJarPath(rs.getString("jar_path"));
				assetRep.setAllowedExtensions(rs.getString("allowed_extensions"));
				assetRep.setImplementedClassName(rs.getString("implemented_class_name"));
				
				
				if (log.isTraceEnabled()) {
					log.trace("getAssetRepresentationByName || " + assetRep.toString());
				}
			}	
			
			
		} catch (SQLException e) {
			log.error("getAssetRepresentationByName || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage("SQLException"));
		} catch (IOException e) {
			log.error("getAssetRepresentationByName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetRepresentationByName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetRepresentationByName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetRepresentationByName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		
		
		if(log.isTraceEnabled()){
			log.trace("getAssetRepresentationByName || "+ assetRep.toString() +" End");
		}
		return assetRep;
		
	}
	
public AssetInstanceRepresentation addAssetInstanceRepresentation(AssetInstanceRepresentation assetInstanceRepresentation, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("addAssetInstanceRepresentation || "+ assetInstanceRepresentation.toString() +" Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_ASSET_INSTANCE_REPRESENTATION));
			
			pstmt.setLong(Constants.ONE, assetInstanceRepresentation.getAssetInstanceId());
			pstmt.setLong(Constants.TWO, assetInstanceRepresentation.getAssetInstanceVersionId());
			pstmt.setString(Constants.THREE, assetInstanceRepresentation.getUploadedFileName());
			pstmt.setString(Constants.FOUR, assetInstanceRepresentation.getUploadedFilePath());
			
			pstmt.executeUpdate();

			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				assetInstanceRepresentation.setAssetInstanceRepresentationId(rs.getLong(1));
			}
			
			
		} catch (SQLException e) {
			log.error("addAssetInstanceRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage("NOT CREATED"));
		} catch (IOException e) {
			log.error("addAssetInstanceRepresentation || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addAssetInstanceRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addAssetInstanceRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}	
		
		
		if(log.isTraceEnabled()){
			log.trace("addAssetInstanceRepresentation || "+ assetInstanceRepresentation.toString() +" End");
		}
		return assetInstanceRepresentation;
		
	}

public AssetInstanceRepresentation getAssetInstanceRepresentationByAivId (Connection conn, long aivId) throws RepoproException{
	
	if(log.isTraceEnabled()){
		log.trace("getAssetInstanceRepresentationByAivId || Begin");
	}
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	AssetInstanceRepresentation assetInstanceRep = null;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceRepresentationByAivId || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
				.getValue(Constants.GET_ASSET_INSTANCE_REPRESENTATION_BY_AIVID));
		
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceRepresentationByAivId || "
					+ PropertyFileReader.getInstance().getValue(
							Constants.GET_ASSET_INSTANCE_REPRESENTATION_BY_AIVID));
		}
		
		pstmt.setLong(Constants.ONE, aivId);
		
		rs = pstmt.executeQuery();
		
		while (rs.next()) {
			assetInstanceRep = new AssetInstanceRepresentation();
			assetInstanceRep.setAssetInstanceRepresentationId(rs.getLong("asset_instance_representation_id"));
			assetInstanceRep.setAssetInstanceId(rs.getLong("asset_instance_id"));
			assetInstanceRep.setAssetInstanceVersionId(rs.getLong("asset_instance_version_id"));
			assetInstanceRep.setUploadedFileName(rs.getString("uploaded_file_name"));
			assetInstanceRep.setUploadedFilePath(rs.getString("uploaded_file_path"));
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceRepresentationByAivId || " + assetInstanceRep.toString());
			}
		}	
		
		
	} catch (SQLException e) {
		log.error("getAssetInstanceRepresentationByAivId || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage("SQLException"));
	} catch (IOException e) {
		log.error("getAssetInstanceRepresentationByAivId || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("getAssetInstanceRepresentationByAivId || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("getAssetInstanceRepresentationByAivId || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closeResultSet(rs);
		DBConnection.closePreparedStatement(pstmt);
		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceRepresentationByAivId || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}
	
	
	if(log.isTraceEnabled()){
		log.trace("getAssetInstanceRepresentationByAivId || "+ assetInstanceRep.toString() +" End");
	}
	return assetInstanceRep;
	
}


public AssetRepresentation updateAssetRepresentation(AssetRepresentation assetRepresentation, Connection conn) throws RepoproException {
	
	if(log.isTraceEnabled()){
		log.trace("updateAssetRepresentation || "+ assetRepresentation.toString() +" Begin");
	}
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("updateAssetRepresentation || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
				.getValue(Constants.UPDATE_ASSET_REPRESENTATION));
		
		pstmt.setString(Constants.ONE, assetRepresentation.getRepresentationName());
		pstmt.setString(Constants.TWO, assetRepresentation.getJarName());
		pstmt.setString(Constants.THREE, assetRepresentation.getJarPath());
		pstmt.setString(Constants.FOUR, assetRepresentation.getImplementedClassName());
		pstmt.setString(Constants.FIVE, assetRepresentation.getAllowedExtensions());
		pstmt.setLong(Constants.SIX, assetRepresentation.getAssetRepresentationId());
		
		pstmt.executeUpdate();		
		
	} catch (SQLException e) {
		log.error("updateAssetRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
	} catch (IOException e) {
		log.error("updateAssetRepresentation || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("updateAssetRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("updateAssetRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closePreparedStatement(pstmt);
		if (log.isTraceEnabled()) {
			log.trace("updateAssetRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}	
	
	
	if(log.isTraceEnabled()){
		log.trace("addAssetRepresentation || "+ assetRepresentation.toString() +" End");
	}
	return assetRepresentation;
	
}

public boolean deleteAssetRepresentationByName (Connection conn, String name) throws RepoproException{
	
	if(log.isTraceEnabled()){
		log.trace("deleteAssetRepresentationByName || Begin");
	}
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	boolean deleteStatus = false;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRepresentationByName || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
				.getValue(Constants.DELETE_ASSET_REPRESENTATION));
		
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRepresentationByName || "
					+ PropertyFileReader.getInstance().getValue(
							Constants.DELETE_ASSET_REPRESENTATION));
		}
		
		pstmt.setString(Constants.ONE, name);		
		
		int rows = pstmt.executeUpdate();
		
		deleteStatus = true;		
		
	} catch (SQLException e) {
		log.error("deleteAssetRepresentationByName || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage("SQLException"));
	} catch (IOException e) {
		log.error("deleteAssetRepresentationByName || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("deleteAssetRepresentationByName || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("deleteAssetRepresentationByName || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closeResultSet(rs);
		DBConnection.closePreparedStatement(pstmt);
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRepresentationByName || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}
	
	
	if(log.isTraceEnabled()){
		log.trace("getAssetRepresentationByName || "+ deleteStatus +" End");
	}
	return deleteStatus;
	
}

public AssetInstanceRepresentation updateAssetInstanceRepresentation(AssetInstanceRepresentation assetInstanceRepresentation, Connection conn) throws RepoproException {
	
	if(log.isTraceEnabled()){
		log.trace("updateAssetInstanceRepresentation || "+ assetInstanceRepresentation.toString() +" Begin");
	}
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
				.getValue(Constants.UPDATE_ASSET_INSTANCE_REPRESENTATION));
		
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceRepresentation || "
					+ PropertyFileReader.getInstance().getValue(
							Constants.UPDATE_ASSET_INSTANCE_REPRESENTATION));
		}
		
		pstmt.setLong(Constants.ONE, assetInstanceRepresentation.getAssetInstanceId());
		pstmt.setLong(Constants.TWO, assetInstanceRepresentation.getAssetInstanceVersionId());
		pstmt.setString(Constants.THREE, assetInstanceRepresentation.getUploadedFileName());
		pstmt.setString(Constants.FOUR, assetInstanceRepresentation.getUploadedFilePath());
		pstmt.setLong(Constants.FIVE, assetInstanceRepresentation.getAssetInstanceRepresentationId());
		
		int rs = pstmt.executeUpdate();		
		
	} catch (SQLException e) {
		log.error("updateAssetInstanceRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
	} catch (IOException e) {
		log.error("updateAssetInstanceRepresentation || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("updateAssetInstanceRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("updateAssetInstanceRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closePreparedStatement(pstmt);
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}	
	
	
	if(log.isTraceEnabled()){
		log.trace("addAssetRepresentation || "+ assetInstanceRepresentation.toString() +" End");
	}
	return assetInstanceRepresentation;
	
}

public String saveAssetInstanceRepresentation (Connection conn, String assetName, Long instanceId, Long versionId, File file, String outputPath) throws RepoproException {
	String response = null;
	ValidateUploadedPlugin vup = new ValidateUploadedPlugin();
	AssetInstanceRepresentation assetInstanceRepresentation = null;
	Connection conn1 = null;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("saveAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		assetInstanceRepresentation = getAssetInstanceRepresentationByAivId(conn, versionId);
		
		if (assetInstanceRepresentation == null) {
			assetInstanceRepresentation = new AssetInstanceRepresentation();
			assetInstanceRepresentation.setAssetInstanceId(instanceId);
			assetInstanceRepresentation.setAssetInstanceVersionId(versionId);
			assetInstanceRepresentation.setUploadedFileName(file.getName());
			assetInstanceRepresentation.setUploadedFilePath(outputPath);
			
			addAssetInstanceRepresentation(assetInstanceRepresentation, conn);
		} else if (!assetInstanceRepresentation.getUploadedFileName().equalsIgnoreCase(file.getName())) {
			assetInstanceRepresentation.setUploadedFileName(file.getName());
			assetInstanceRepresentation.setUploadedFilePath(outputPath);
			//TODO: delete the previous existing files 
			FileUtils.cleanDirectory(new File(outputPath));
			updateAssetInstanceRepresentation(assetInstanceRepresentation, conn);
		}
		
		AssetRepresentation assetRep = getAssetRepresentationByAssetName(conn, assetName);
		
		vup.invokeMethodFromJar(assetRep.getImplementedClassName(), assetRep.getJarPath(), file, outputPath);
		
		response = outputPath;
		
	} catch (SQLException e) {
		log.error("saveAssetInstanceRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
	} catch (IOException e) {
		log.error("saveAssetInstanceRepresentation || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("saveAssetInstanceRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("saveAssetInstanceRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		if (log.isTraceEnabled()) {
			log.trace("saveAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}	
	
	if(log.isTraceEnabled()){
		log.trace("saveAssetInstanceRepresentation || "+ assetInstanceRepresentation.toString() +" End");
	}
	return response;
}

public String deleteAssetInstanceRepresentation (Connection conn, Long versionId) throws RepoproException {
	String response = null;
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
				.getValue(Constants.DELETE_ASSET_INSTANCE_REPRESENTATION));
		
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRepresentationByName || "
					+ PropertyFileReader.getInstance().getValue(
							Constants.DELETE_ASSET_INSTANCE_REPRESENTATION));
		}
		
		pstmt.setLong(Constants.ONE, versionId);
		
		int rows = pstmt.executeUpdate();		

		String outputPath = Constants.UPLOADED_JAR_SUPPORT_FILE_PATH + versionId + "/";
		
		FileUtils.forceDelete(new File(outputPath));
		
		response = outputPath;
		
	} catch (SQLException e) {
		log.error("deleteAssetInstanceRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
	} catch (IOException e) {
		log.error("deleteAssetInstanceRepresentation || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("deleteAssetInstanceRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("deleteAssetInstanceRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closePreparedStatement(pstmt);
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}	
	
	if(log.isTraceEnabled()){
		log.trace("deleteAssetInstanceRepresentation || "+ response +" End");
	}
	return response;
}

public void deleteAssetRepresentationLink (long assetId, long assetRepId, Connection conn) throws RepoproException{
	
	if(log.isTraceEnabled()){
		log.trace("deleteAssetRepresentationLink Begin");
	}
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRepresentationLink || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
				.getValue(Constants.DELETE_ASSET_REPRESENTATION_LINK));
		
		pstmt.setLong(Constants.ONE, assetId);
		pstmt.setLong(Constants.TWO, assetRepId);	
		
		pstmt.executeUpdate();			
		
	} catch (SQLException e) {
		log.error("deleteAssetRepresentationLink || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
	} catch (IOException e) {
		log.error("deleteAssetRepresentationLink || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("deleteAssetRepresentationLink || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("deleteAssetRepresentationLink || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closeResultSet(rs);
		DBConnection.closePreparedStatement(pstmt);
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetRepresentationLink || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}	
	
	
	if(log.isTraceEnabled()){
		log.trace("deleteAssetRepresentationLink End");
	}
	
}

public void deleteRepresentationOnChangeInAsset (String assetName, Connection conn) throws RepoproException{
	
	if(log.isTraceEnabled()){
		log.trace("deleteRepresentationOnChangeInAsset Begin");
	}
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	List<AssetInstanceRepresentation> assetInstRepList = new ArrayList<AssetInstanceRepresentation>();
	AssetInstanceRepresentation assetInstRep = null;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("deleteRepresentationOnChangeInAsset || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		
		pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
				.getValue(Constants.GET_ALL_ASSET_INSTANCE_REPRESENTATION_LINKED_TO_ASSET));
		
		pstmt.setString(Constants.ONE, assetName);
				
		rs = pstmt.executeQuery();	
		
		while (rs.next()) {
			assetInstRep = new AssetInstanceRepresentation();
			assetInstRep.setAssetInstanceRepresentationId(rs.getLong("asset_instance_representation_id"));
			assetInstRep.setAssetInstanceId(rs.getLong("asset_instance_id"));
			assetInstRep.setAssetInstanceVersionId(rs.getLong("asset_instance_version_id"));
			assetInstRep.setUploadedFileName(rs.getString("uploaded_file_name"));
			assetInstRep.setUploadedFilePath(rs.getString("uploaded_file_path"));
			
			assetInstRepList.add(assetInstRep);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetRepresentations || " + assetInstRep.toString());
			}
		}
		
		if (assetInstRepList.size() > 0) {
			for (AssetInstanceRepresentation air : assetInstRepList) {
				deleteAssetInstanceRepresentation(conn, air.getAssetInstanceVersionId());
			}
		}
		
		
	} catch (SQLException e) {
		log.error("deleteRepresentationOnChangeInAsset || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
	} catch (IOException e) {
		log.error("deleteRepresentationOnChangeInAsset || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("deleteRepresentationOnChangeInAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("deleteRepresentationOnChangeInAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closeResultSet(rs);
		DBConnection.closePreparedStatement(pstmt);
		if (log.isTraceEnabled()) {
			log.trace("deleteRepresentationOnChangeInAsset || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}	
	
	
	if(log.isTraceEnabled()){
		log.trace("deleteRepresentationOnChangeInAsset End");
	}
	
}

public List<AssetInstanceRepresentation> getAllAssetInstanceLinkedToRepresentation(Connection conn, long representationId) throws RepoproException{
	
	if(log.isTraceEnabled()){
		log.trace("getAllAssetInstanceLinkedToRepresentation || Begin");
	}
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	AssetInstanceRepresentation assetInstanceRep = null;
	List<AssetInstanceRepresentation> assetInstRepList = new ArrayList<AssetInstanceRepresentation>();
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("getAllAssetInstanceLinkedToRepresentation || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
				.getValue(Constants.GET_ASSET_INSTANCE_REPRESENTATION_BY_AIVID));
		
		if (log.isTraceEnabled()) {
			log.trace("getAllAssetInstanceLinkedToRepresentation || "
					+ PropertyFileReader.getInstance().getValue(
							Constants.GET_ALL_ASSET_INSTANCE_LINKED_TO_REPRESENTATION));
		}
		
		pstmt.setLong(Constants.ONE, representationId);
		
		rs = pstmt.executeQuery();
		
		while (rs.next()) {
			assetInstanceRep = new AssetInstanceRepresentation();
			assetInstanceRep.setAssetInstanceRepresentationId(rs.getLong("asset_instance_representation_id"));
			assetInstanceRep.setAssetInstanceId(rs.getLong("asset_instance_id"));
			assetInstanceRep.setAssetInstanceVersionId(rs.getLong("asset_instance_version_id"));
			assetInstanceRep.setUploadedFileName(rs.getString("uploaded_file_name"));
			assetInstanceRep.setUploadedFilePath(rs.getString("uploaded_file_path"));
			
			assetInstRepList.add(assetInstanceRep);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceLinkedToRepresentation || " + assetInstanceRep.toString());
			}
		}	
		
		
	} catch (SQLException e) {
		log.error("getAllAssetInstanceLinkedToRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage("SQLException"));
	} catch (IOException e) {
		log.error("getAllAssetInstanceLinkedToRepresentation || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("getAllAssetInstanceLinkedToRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("getAllAssetInstanceLinkedToRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closeResultSet(rs);
		DBConnection.closePreparedStatement(pstmt);
		if (log.isTraceEnabled()) {
			log.trace("getAllAssetInstanceLinkedToRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}
	
	
	if(log.isTraceEnabled()){
		log.trace("getAllAssetInstanceLinkedToRepresentation || "+ assetInstRepList.toString() +" End");
	}
	return assetInstRepList;
	
}

public void deleteAssetInstanceLinkedToRepresentation(Connection conn, long representationId) throws RepoproException{
	
	if(log.isTraceEnabled()){
		log.trace("deleteAssetInstanceLinkedToRepresentation || Begin");
	}
	Connection conn1 = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	PreparedStatement pstmtment = null;
	
	AssetInstanceRepresentation assetInstanceRep = null;
	List<AssetInstanceRepresentation> assetInstRepList = new ArrayList<AssetInstanceRepresentation>();
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
				.getValue(Constants.GET_ALL_ASSET_INSTANCE_LINKED_TO_REPRESENTATION));
		
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceLinkedToRepresentation || "
					+ PropertyFileReader.getInstance().getValue(
							Constants.GET_ALL_ASSET_INSTANCE_LINKED_TO_REPRESENTATION));
		}
		
		pstmt.setLong(Constants.ONE, representationId);
		
		rs = pstmt.executeQuery();
		
		while (rs.next()) {
			assetInstanceRep = new AssetInstanceRepresentation();
			assetInstanceRep.setAssetInstanceRepresentationId(rs.getLong("asset_instance_representation_id"));
			assetInstanceRep.setAssetInstanceId(rs.getLong("asset_instance_id"));
			assetInstanceRep.setAssetInstanceVersionId(rs.getLong("asset_instance_version_id"));
			assetInstanceRep.setUploadedFileName(rs.getString("uploaded_file_name"));
			assetInstanceRep.setUploadedFilePath(rs.getString("uploaded_file_path"));
			
			assetInstRepList.add(assetInstanceRep);
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceLinkedToRepresentation || " + assetInstanceRep.toString());
			}
		}
		
		if (assetInstRepList.size() > 0) {
			for (AssetInstanceRepresentation air : assetInstRepList) {
				FileUtils.forceDelete(new File(air.getUploadedFilePath()));
			}
		}
		
		if (assetInstRepList.size() > 0) {
			pstmtment = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_ASSET_INSTANCE_REPRESENTATION));
			for (AssetInstanceRepresentation air : assetInstRepList) {
				pstmtment.setLong(Constants.ONE, air.getAssetInstanceVersionId());
				pstmtment.addBatch();
			}
			int[] results = pstmtment.executeBatch();
		}
	} catch (SQLException e) {
		log.error("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage("SQLException"));
	} catch (IOException e) {
		log.error("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closeResultSet(rs);
		DBConnection.closePreparedStatement(pstmt);
		DBConnection.closePreparedStatement(pstmtment);
		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}
	if(log.isTraceEnabled()){
		log.trace("deleteAssetInstanceLinkedToRepresentation || "+ assetInstRepList.toString() +" End");
	}
	
}

public String copyAssetInstanceRepresentation (Connection conn, Long instanceId, Long fromVersionId, Long toVersionId) throws RepoproException {
	String response = null;
	AssetInstanceRepresentation assetInstanceRepresentation = null;
	Connection conn1 = null;
	
	try {
		if (log.isTraceEnabled()) {
			log.trace("copyAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_OPEN);
		}
		if (conn == null) {
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}

		AssetInstanceRepresentation assetInstRepFromDb = getAssetInstanceRepresentationByAivId(conn, fromVersionId);
		String outputPath = Constants.UPLOADED_JAR_SUPPORT_FILE_PATH + toVersionId + "/";
		
		if (assetInstRepFromDb != null) {
			assetInstanceRepresentation = new AssetInstanceRepresentation();
			assetInstanceRepresentation.setAssetInstanceId(instanceId);
			assetInstanceRepresentation.setAssetInstanceVersionId(toVersionId);
			assetInstanceRepresentation.setUploadedFileName(assetInstRepFromDb.getUploadedFileName());
			assetInstanceRepresentation.setUploadedFilePath(outputPath);
			
			addAssetInstanceRepresentation(assetInstanceRepresentation, conn);
			
			File srcDir = new File(assetInstRepFromDb.getUploadedFilePath());
			File destDir = new File(outputPath);
			
			FileUtils.copyDirectory(srcDir, destDir);
			
		}
		
		response = outputPath;
		
	} catch (SQLException e) {
		log.error("copyAssetInstanceRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
	} catch (IOException e) {
		log.error("copyAssetInstanceRepresentation || " + Constants.LOG_IOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("copyAssetInstanceRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION
				+ e.getMessage());
		e.printStackTrace();
		throw new RepoproException(
				MessageUtil
				.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("copyAssetInstanceRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		if (log.isTraceEnabled()) {
			log.trace("copyAssetInstanceRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
		}
		DBConnection.closeDbConnection(conn1);

	}	
	
	if(log.isTraceEnabled()){
		log.trace("copyAssetInstanceRepresentation || "+ assetInstanceRepresentation.toString() +" End");
	}
	return response;
}

}
