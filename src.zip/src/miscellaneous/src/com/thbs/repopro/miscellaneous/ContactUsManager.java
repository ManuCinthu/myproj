package com.thbs.repopro.miscellaneous;

import java.sql.Connection;
import java.sql.SQLException;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;

@Path("/contactUs")
public class ContactUsManager {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	
	/**
	 * @method : submitContactUs
	 * @param name
	 * @param emailId
	 * @param category
	 * @param content
	 * @return
	 */
	@POST
	@Path("/submitContactUs")
	public Response submitContactUs(@QueryParam("name") String name, @QueryParam("email") String emailId, 
			@QueryParam("category") String category, @QueryParam("content") String content){
		
		if(log.isTraceEnabled()){
			log.trace("submitContactUs || Begin with ");
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("submitContactUs || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			MailTemplateDao mailDao = new MailTemplateDao();
			MailConfig mailConfig = mailDao.getMailConfig(conn);
			
			String mailTemp = "Name: " + name + "\nEmail id: "+ emailId + "\nCategory: " + category + "\nContent/Query: "+ content +"\n";
			
			SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(Constants.REPOPRO_CONTACT_US), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
			
			log.info("submitContactUs || mail sent successfully");
			
			retMsg = Constants.MAIL_SENT_SUCCESS;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("submitContactUs || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch(Exception e){
			log.error("submitContactUs || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("submitContactUs || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
				.build();
	}

}
