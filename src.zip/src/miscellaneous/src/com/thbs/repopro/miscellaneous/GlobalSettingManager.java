package com.thbs.repopro.miscellaneous;

import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;
import com.thbs.repopro.util.PropertyFileReader;

@Path("/globalsettings")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class GlobalSettingManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	GlobalSettingDao globalsettingdao = new GlobalSettingDao();

	/**
	 * @method :getGlobalSettings
	 * @description :to get GlobalSettings data
	 * @return :globalsettinglist
	 */

	@GET
	public Response getGlobalSettings(){

		log.trace("getGlobalSettings || Begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<GlobalSetting> globalsettinglist = new ArrayList<GlobalSetting>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getGlobalSettings || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("getGlobalSettings || dao method called : getGlobalSetting  ");
			}
			globalsettinglist = globalsettingdao.getGlobalSetting(conn);

			if (log.isDebugEnabled()) {
				log.debug("getGlobalSettings || retrieved "
						+ globalsettinglist.size()
						+ " globalsetting data successfully ");
			}
			conn.commit();

		} catch (RepoproException e) {
			log.error("getGlobalSettings || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} catch (Exception e) {
			log.error("getGlobalSettings || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("getGlobalSettings ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (globalsettinglist.isEmpty()) {
			retMsg = Constants.GLOBAL_SETTING_DATA_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} else {
			retMsg = Constants.ALL_GLOBAL_SETTING_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		}

		log.trace("getGlobalSettings || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(globalsettinglist))).build();
	}

	/**
	 * @method :updateGlobalSettings
	 * @description :to update global settings data
	 * @param :globalsettingdata
	 * @return :Response success message
	 */

	@PUT
	public Response updateGlobalSettings(GlobalSetting globalsettingdata){

		if (globalsettingdata == null) {
			log.warn("updateGlobalSettings || globalsetting data is not provided for update ");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
									.getMessage(Constants.INVALID_REQUEST)))
					.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSettings || "
						+ globalsettingdata.toString() + "|| Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;

			try {
				if (log.isTraceEnabled()) {
					log.trace("updateGlobalSettings ||"
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("updateGlobalSettings || dao call for updateGlobalSetting() method");
				}
				AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
				globalsettingdao.updateGlobalSetting(globalsettingdata, conn);

				if (log.isTraceEnabled()) {
					log.info("UpdateGlobalSettings ||  globalsettingdata.toString() globalsettings is updated successfully ");
				}

				if(globalsettingdata.getGlobalLockSettingFlag() == 0){
					assetInstanceVersionDao.unlockAllAssetInstanceVersions(conn);
				}
				conn.commit();
				retMsg = Constants.GLOBAL_SETTING_DATA_UPDATED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			} catch (RepoproException e) {
				log.error("UpdateGlobalSettings || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch (Exception e) {
				log.error("UpdateGlobalSettings || " + Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("UpdateGlobalSettings ||"
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSettings || "
						+ globalsettingdata.toString() + "|| End");
			}

			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
					.build();

		}

	}
	
	
	/*** Wrapper function ***/
	@GET
	@Encoded
	@Path("/getGlobalSettingsMain")
	public Response getGlobalSettingsMain(@HeaderParam("token") String token) {
		
		log.trace("getGlobalSettingsMain || Begin");

		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("admin")){
				response = this.getGlobalSettings();
				
				MyModel res = (MyModel) response.getEntity();
				List<Object> data = res.getResult();
				List<Object> finalData = new ArrayList<Object>();
				
				JSONObject j1 = null;
				JSONObject json = new JSONObject();
				
				for(int i=0;i<data.size();i++){
					j1 = new JSONObject();
					GlobalSetting gs = new GlobalSetting();
					gs = (GlobalSetting) data.get(i);
					
					if(gs.getGlobalLdapSettingFlag() == 0){
						j1.put("globalLdapSettingFlag", false);
					}else{
						j1.put("globalLdapSettingFlag", true);
					}
					
					if(gs.getGlobalLockSettingFlag() == 0){
						j1.put("globalLockSettingFlag", false);
					}else{
						j1.put("globalLockSettingFlag", true);
					}
					
					j1.put("lockTime", gs.getLockTime());
					
					if(gs.getCircularImage() == 0){
						j1.put("circularImage", false);
					}else{
						j1.put("circularImage", true);
					}
					
					if(gs.getInvertedImage() == 0){
						j1.put("invertedImage", false);
					}else{
						j1.put("invertedImage", true);
					}
					
					if(gs.getSsoFlag() == 0){
						j1.put("ssoFlag", false);
					}else{
						j1.put("ssoFlag", true);
					}
					
					finalData.add(j1);
				}
				
				json.put("result", finalData);
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("getGlobalSettingsMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("getGlobalSettingsMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
		} catch (RepoproException e) {
			log.error("getGlobalSettingsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getGlobalSettingsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		log.trace("getGlobalSettingsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@PUT
	@Encoded
	@Path("/updateGlobalSettingsMain")
	public Response updateGlobalSettingsMain(
			@QueryParam("globalSettingsDetails") String globalSettingsDetails,
			@HeaderParam("token") String token) {
		
		if(globalSettingsDetails == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		try{
			globalSettingsDetails = URLDecoder.decode(globalSettingsDetails, "UTF-8");
			globalSettingsDetails = globalSettingsDetails.trim();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		if(globalSettingsDetails.isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		if(globalSettingsDetails != null){
			try {
				String jsonStr = globalSettingsDetails;
				JSONObject jsonObject = new JSONObject(jsonStr);
				if(!jsonObject.has("globalLdapSettingFlag") && !jsonObject.has("ssoFlag") 
						&& !jsonObject.has("globalLockSettingFlag") && !jsonObject.has("invertedImage")
						&& !jsonObject.has("circularImage")){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
				}
				/*if(!jsonObject.has("globalLockSettingFlag") && jsonObject.has("lockTime")){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
				}*/
			} catch (JSONException e) {
				e.printStackTrace();
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
			}
		}
				
		log.trace("updateGlobalSettingsMain || Begin");
		Connection conn = null;
		PreparedStatement preparedStmt = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSettingsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User userData = userDao.getUserIdByUserName(userName, null);
				if(userData.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("admin")){
				
				String jsonStr1 = globalSettingsDetails;
				JSONObject jsonObject = new JSONObject(jsonStr1);
				
				if(jsonObject.has("globalLockSettingFlag")){
					String globalLockSettingFlag = jsonObject.get("globalLockSettingFlag").toString();
					if(!globalLockSettingFlag.equalsIgnoreCase("true") && !globalLockSettingFlag.equalsIgnoreCase("false")){
						 return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					int globalLockSettingFlagVal;
					if(globalLockSettingFlag.equalsIgnoreCase("true")){
						globalLockSettingFlagVal = 1;
					}else{
						globalLockSettingFlagVal = 0;
					}
					
					if(globalLockSettingFlag.equalsIgnoreCase("false") && jsonObject.has("lockTime")){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.UPDATE_GLOBAL_SETTING));
					preparedStmt.setInt(Constants.ONE, globalLockSettingFlagVal);
					preparedStmt.setString(Constants.TWO, "lock");

					if (log.isTraceEnabled()) {
						log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
										Constants.UPDATE_GLOBAL_SETTING));
					}
					preparedStmt.executeUpdate();
				}
				
				if(jsonObject.has("lockTime")){
					String lockTime = jsonObject.get("lockTime").toString();
					lockTime = lockTime.trim();
					
					String globalLockSettingFlag = "false";
					if(jsonObject.has("globalLockSettingFlag")){
						globalLockSettingFlag = jsonObject.get("globalLockSettingFlag").toString();
						if(!globalLockSettingFlag.equalsIgnoreCase("true") && !globalLockSettingFlag.equalsIgnoreCase("false")){
							 return Response.status(Status.BAD_REQUEST)
								     .entity(new MyModelRest(Constants.STATUS_FAILURE,
								       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
						}
					}
					
					List<GlobalSetting> globalSettings = globalSettingDao.getGlobalSetting(conn);
					for(GlobalSetting gs : globalSettings){
						if(gs.getGlobalLockSettingFlag() != 0 || globalLockSettingFlag.equalsIgnoreCase("true")){
							
							if(lockTime.trim().length() > 4){
								return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
							}
							
							String newRegex = "^[0-9]+$";
							Pattern pattern = Pattern.compile(newRegex);
							Matcher matcher = pattern.matcher(lockTime);
							if(!matcher.find()){
								return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
							}
							
							if(Integer.parseInt(lockTime) == 0){
								return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
							}
							
							preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
									.getValue(Constants.UPDATE_LOCK_TIME));
							preparedStmt.setString(Constants.ONE, lockTime);

							if (log.isTraceEnabled()) {
								log.trace("updateLockTime ||" + PropertyFileReader.getInstance().getValue(
												Constants.UPDATE_LOCK_TIME));
							}
							preparedStmt.executeUpdate();
						}
					}
				}
				
				if(jsonObject.has("globalLdapSettingFlag")){
					
					String ldapFlag = jsonObject.get("globalLdapSettingFlag").toString();
					if(!ldapFlag.equalsIgnoreCase("true") && !ldapFlag.equalsIgnoreCase("false")){
						 return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					int ldapFlagVal;
					if(ldapFlag.equalsIgnoreCase("true")){
						ldapFlagVal = 1;
					}else{
						ldapFlagVal = 0;
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.UPDATE_GLOBAL_SETTING));

					preparedStmt.setInt(Constants.ONE, ldapFlagVal);
					preparedStmt.setString(Constants.TWO, "Ldap");

					if (log.isTraceEnabled()) {
						log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
										Constants.UPDATE_GLOBAL_SETTING));
					}
					preparedStmt.executeUpdate();
				}
				
				if(jsonObject.has("ssoFlag")){
					String ssoFlag = jsonObject.get("ssoFlag").toString();
					if(!ssoFlag.equalsIgnoreCase("true") && !ssoFlag.equalsIgnoreCase("false")){
						 return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					int ssoFlagVal;
					if(ssoFlag.equalsIgnoreCase("true")){
						ssoFlagVal = 1;
					}else{
						ssoFlagVal = 0;
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.UPDATE_GLOBAL_SETTING));
					preparedStmt.setInt(Constants.ONE, ssoFlagVal);
					preparedStmt.setString(Constants.TWO, "SAML");

					if (log.isTraceEnabled()) {
						log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
										Constants.UPDATE_GLOBAL_SETTING));
					}
					preparedStmt.executeUpdate();
				}
				
				if(jsonObject.has("circularImage")){
					String circularImageFlag = jsonObject.get("circularImage").toString();
					if(!circularImageFlag.equalsIgnoreCase("true") && !circularImageFlag.equalsIgnoreCase("false")){
						 return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					int circularImageFlagVal;
					if(circularImageFlag.equalsIgnoreCase("true")){
						circularImageFlagVal = 1;
					}else{
						circularImageFlagVal = 0;
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.UPDATE_GLOBAL_SETTING));
					preparedStmt.setInt(Constants.ONE, circularImageFlagVal);
					preparedStmt.setString(Constants.TWO, "circular Image");

					if (log.isTraceEnabled()) {
						log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
										Constants.UPDATE_GLOBAL_SETTING));
					}
					preparedStmt.executeUpdate();
				}
				
				if(jsonObject.has("invertedImage")){
					String invertedImageFlag = jsonObject.get("invertedImage").toString();
					if(!invertedImageFlag.equalsIgnoreCase("true") && !invertedImageFlag.equalsIgnoreCase("false")){
						 return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					int invertedImageFlagVal;
					if(invertedImageFlag.equalsIgnoreCase("true")){
						invertedImageFlagVal = 1;
					}else{
						invertedImageFlagVal = 0;
					}
					preparedStmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.UPDATE_GLOBAL_SETTING));
					preparedStmt.setInt(Constants.ONE, invertedImageFlagVal);
					preparedStmt.setString(Constants.TWO, "inverted Image");

					if (log.isTraceEnabled()) {
						log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
										Constants.UPDATE_GLOBAL_SETTING));
					}
					preparedStmt.executeUpdate();
				}
				
				conn.commit();
				
				JSONObject json = new JSONObject();
				
				json.put("message", Constants.GLOBAL_SETTING_DATA_UPDATED);
				json.put("status", Constants.SUCCESS);
				json.put("statusCode", Constants.GET_STATUS_SUCCESS);
				log.trace("updateGlobalSettingsMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}

			
		} catch (RepoproException e) {
			log.error("updateGlobalSettingsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("updateGlobalSettingsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSettingsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("updateGlobalSettingsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
}
