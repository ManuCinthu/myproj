package com.thbs.repopro.miscellaneous;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class MailTemplateDao {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method getMailTemplate
	 * @description retrieve list of mailTemplates
	 * @param conn
	 * @return List<MailTemplate>
	 * @throws RepoproException
	 */
	public List<MailTemplate> getMailTemplate(Connection conn)
			throws RepoproException {

		log.trace("getMailTemplate || begin");

		List<MailTemplate> mailTemplateList = new ArrayList<MailTemplate>();
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		MailTemplate mailTemplate = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getMailTemplate || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_MailTemplate));
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getMailTemplate || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_MailTemplate));
			}

			while (rs.next()) {
				mailTemplate = new MailTemplate();
				mailTemplate.setMailTemplateId(rs.getLong("mail_template_id"));
				mailTemplate.setFunctionalityName(rs
						.getString("functionality_name"));
				mailTemplate.setMailTemplate(rs.getString("mail_template"));

				mailTemplateList.add(mailTemplate);

				if (log.isTraceEnabled()) {
					log.trace("getMailTemplate || returning resultset  : "
							+ mailTemplate.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getMailTemplate || returning resultset  : "
						+ mailTemplateList.toString());
			}

		} catch (SQLException e) {
			log.error("getMailTemplate ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GET_MAILTEMPLATE_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getMailTemplate ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getMailTemplate ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getMailTemplate ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			
			if (log.isTraceEnabled()) {
				log.trace("getMailTemplate ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		log.trace("getMailTemplate || exit");

		return mailTemplateList;
	}

	/**
	 * @method updateMailTemplate
	 * @description update MailTemplates
	 * @param mailTemplateList
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateMailTemplate(List<MailTemplate> mailTemplateList,
			Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("updateMailTemplate ||" + mailTemplateList.toString()
					+ " || Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		MailTemplate mailTemplate = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("updateMailTemplate ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			mailTemplate = new MailTemplate();

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_MAILTEMPLATE));
			if (log.isTraceEnabled()) {
				log.trace("updateMailTemplate ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_MAILTEMPLATE));
			}
			for (int i = 0; i < mailTemplateList.size(); i++) {
				mailTemplate.setMailTemplateId(mailTemplateList.get(i)
						.getMailTemplateId());
				mailTemplate.setMailTemplate(mailTemplateList.get(i)
						.getMailTemplate());

				preparedStmt.setString(Constants.ONE,
						mailTemplate.getMailTemplate());
				preparedStmt.setLong(Constants.TWO,
						mailTemplate.getMailTemplateId());

				preparedStmt.executeUpdate();
			}

		} catch (SQLException e) {
			log.error("updateMailTemplate ||"
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.UPDATE_MAILTEMPLATE_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("updateMailTemplate ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("updateMailTemplate ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("updateMailTemplate ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("updateMailTemplate ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		
		if (log.isTraceEnabled()) {
			log.trace("updateMailTemplate ||" + mailTemplateList.toString()
					+ " ||End");
		}

	}
	
	
	/**
	 * @method retMailTemplateByTextName
	 * @descripton get mail template by functionality name
	 * @param functionalityName
	 * @param conn
	 * @return string
	 * @throws RepoproException
	 */
	public MailTemplate retMailTemplateByTextName(Connection conn , String functionalityName)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("retMailTemplateByTextName || Begin ");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MailTemplate mailVo = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("retMailTemplateByTextName || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.RET_MAIL_TEMPLATE_TEXT_NAME));

			pstmt.setString(Constants.ONE, functionalityName);

			if (log.isTraceEnabled()) {
				log.trace("retMailTemplateByTextName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_MAIL_TEMPLATE_TEXT_NAME));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				mailVo = new MailTemplate();
				mailVo.setMailTemplateId(rs.getLong("mail_template_id"));
				mailVo.setFunctionalityName(rs.getString("functionality_name"));
				mailVo.setMailTemplate(rs.getString("mail_template"));
				
				if (log.isTraceEnabled()) {
					log.trace("retMailTemplateByTextName || returning : "
							+ mailVo.toString());
				}
			}
		} catch (SQLException e) {
			log.error("retMailTemplateByTextName || "
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_MAILTEMPLATE_DETAILS_FAILED));
		} catch (IOException e) {
			log.error("retMailTemplateByTextName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retMailTemplateByTextName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retMailTemplateByTextName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			
			if (log.isTraceEnabled()) {
				log.trace("retMailTemplateByTextName || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("retMailTemplateByTextName || End");
		}
		return mailVo;
	}
	
	/**
	 * @method getMailConfig
	 * @descripton get mailConfig object
	 * @param conn
	 * @return MailConfig obj
	 * @throws RepoproException
	 */
	public MailConfig getMailConfig(Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getMailConfig : Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MailConfig mailConfig = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getMailConfig || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.RET_MAIL_CONFIG_DATA));

			if (log.isTraceEnabled()) {
				log.trace("getMailConfig || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_MAIL_CONFIG_DATA));
			}
			
			rs = pstmt.executeQuery();

			while (rs.next()) {
				mailConfig = new MailConfig();
				mailConfig.setUserName(rs.getString("user_name"));
				mailConfig.setPassword(rs.getString("password"));
				mailConfig.setAuthentication(rs.getString("auth"));
				mailConfig.setStartTLSEnable(rs.getString("start_TLS_enable"));
				mailConfig.setHost(rs.getString("host"));
				mailConfig.setPort(rs.getInt("port"));
				mailConfig.setBcc(rs.getString("bcc"));
				mailConfig.setSenderMailId(rs.getString("sender_mail_id"));
			}
		} catch (SQLException e) {
			log.error("getMailConfig || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_MAILTEMPLATE_DETAILS_FAILED));
		} catch (IOException e) {
			log.error("getMailConfig || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getMailConfig || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getMailConfig || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			
			if (log.isTraceEnabled()) {
				log.trace("getMailConfig || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("getMailConfig || End");
		}
		return mailConfig;
	}
}
