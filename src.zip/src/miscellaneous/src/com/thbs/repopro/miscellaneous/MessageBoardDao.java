package com.thbs.repopro.miscellaneous;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.MessageBoard;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class MessageBoardDao {

	private static final Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method :getAllMessageDetials by id
	 * @description :getAllMessageDetials
	 * @param conn
	 * @return List
	 * @throws DataNotFoundException
	 */
	public MessageBoard getAllMessageDetails(Connection conn)
			throws RepoproException {

		MessageBoard message = null;

		if (log.isTraceEnabled()) {
			log.trace("getAllMessageDetials || Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllMessageDetials ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_MESSAGE_DETIALS));
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("getAllMessageDetials ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_MESSAGE_DETIALS));
			}
			while (rs.next()) {
				message = new MessageBoard();
				message.setId(rs.getInt("id"));
				message.setCreatedOn(rs.getTimestamp("created_on"));
				message.setCreatedBy(rs.getString("created_by"));
				message.setAdminMessage(rs.getString("message"));
				message.setMaintenance(rs.getString("maintenance_banner"));
				message.setIson(rs.getInt("ison"));

				if (log.isTraceEnabled()) {
					log.trace("getAllMessageDetials :" + message.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getAllMessageDetials ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.MESSAGE_DETIALS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllMessageDetials ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllMessageDetials ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAllMessageDetials ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("getAllMessageDetials ||End");
		}
		return message;
	}

	/**
	 * @method: addMessageDetails
	 * @Descripton: to update the message details
	 * @param messageboard
	 * @param conn
	 * @return
	 * @throws CreateContentException
	 */

	public MessageBoard addMessageDetails(MessageBoard messageboard,
			Connection conn) throws  RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("addMessageDetails ||" + messageboard.toString()
					+ "|| Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addMessageDetails ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.INSERT_MESSAGE_BOARD_DATA));
			
			//preparedStmt.setInt(Constants.ONE, messageboard.getId());
			preparedStmt.setTimestamp(Constants.ONE, messageboard.getCreatedOn());
			preparedStmt.setString(Constants.TWO, messageboard.getCreatedBy());
			preparedStmt.setString(Constants.THREE, messageboard.getAdminMessage());
			preparedStmt.setString(Constants.FOUR, messageboard.getMaintenance());
			preparedStmt.setInt(Constants.FIVE, messageboard.getIson());
			preparedStmt.execute();
			
			rs = preparedStmt.getGeneratedKeys();
			
			if (rs != null && rs.next()) {
				messageboard.setId(rs.getInt(1));
			}

			if (log.isTraceEnabled()) {
				log.trace("addMessageDetails ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.INSERT_MESSAGE_BOARD_DATA));
			}

		} catch (SQLException e) {
			log.error("addMessageDetails ||"
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INSERT_MESSAGE_BOARD_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("addMessageDetails ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addMessageDetails ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addMessageDetails ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addMessageDetails ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {

			log.trace("addMessageDetails ||" + messageboard.toString()
					+ "||End");
		}
		return messageboard;
	}
	
	
	
}