package com.thbs.repopro.miscellaneous;

import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.MessageBoard;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;

@Path("/message")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class MessageBoardManager {
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method getAllMessageDetials
	 * @Description shows the latest message details
	 * @return
	 * @throws RepoproException
	 */
	@GET
	public Response getAllMessageDetials(){

		if (log.isTraceEnabled()) {
			log.trace("getAllMessageDetials ||  Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;

		MessageBoardDao messageDao = new MessageBoardDao();

		MessageBoard messageBoard = new MessageBoard();

		List<MessageBoard> messageboardlist = new ArrayList<MessageBoard>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllMessageDetials || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getAllMessageDetials || dao call of getAllMessageDetials() method retrieves detials about the message");
			}
			messageBoard = messageDao.getAllMessageDetails(conn);
			
			if(messageBoard != null){
				messageboardlist.add(messageBoard);
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getAllMessageDetials || retrieve messagedetials:"
						+ messageBoard.toString());
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllMessageDetials || retrieve message list "
						+ messageboardlist);
			}
			
			retStat = Status.OK;
			retMsg = Constants.SHOW_MESSAGE_DETIALS;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getAllMessageDetials || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getAllMessageDetials || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllMessageDetials||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if (messageboardlist.isEmpty()) {
			retMsg = Constants.MESSAGE_DETIALS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retStat = Status.OK;
			retMsg = Constants.SHOW_MESSAGE_DETIALS;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		
		if (log.isTraceEnabled()) {
			log.trace("getAllMessageDetials || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(messageboardlist))).build();

	}

	/**
	 * @method addMessage
	 * @Description updates the database
	 * @param messageBoardDto
	 * @return
	 * @throws RepoproException
	 */
	@POST
	public Response addAdminMessage(MessageBoard messageBoardDto){
		
		if (messageBoardDto == null) {
			log.warn("addAdminMessage || message details to be inserted not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
									.getMessage(Constants.INVALID_REQUEST)))
					.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("addAdminMessage ||" + messageBoardDto.toString() + " || Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			
			Connection conn = null;
			
			List<MessageBoard> jsonList = new ArrayList<MessageBoard>();
			
			MessageBoard messageboard = new MessageBoard();
			CommonUtils commonUtils = new CommonUtils();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			
			try {
				if (log.isTraceEnabled()) {
					log.trace("addAdminMessage ||" + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				
				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("addAdminMessage || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
				
				MessageBoardDao messageDao = new MessageBoardDao();
				MessageBoard allMessageDetails = messageDao.getAllMessageDetails(conn);
				String maintenance = "";
				int ison = 0;
				
				if(allMessageDetails.getMaintenance() != null){
					maintenance = allMessageDetails.getMaintenance();
					ison = allMessageDetails.getIson();
				}
				
				messageBoardDto.setMaintenance(maintenance);
				messageBoardDto.setIson(ison);
				
				if(globalsetting.getGlobalSettingFlag() == 1){
					String desc = commonUtils.httpSanitizerForCkEditor(messageBoardDto.getAdminMessage());
					messageBoardDto.setAdminMessage(desc);
				}
				
				if (log.isTraceEnabled()) {
					log.trace("addAdminMessage || call of dao method addMessageDetails()");
				}
				messageboard = messageDao.addMessageDetails(messageBoardDto, conn);
				
				retStat = Status.OK;
				retMsg = Constants.MESSAGE_BOARD_DATA_ADDED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				jsonList.add(messageboard);

				if (log.isInfoEnabled()) {
					log.info("addAdminMessage || message details " + messageboard.toString() + " inserted successfully ");
				}
				conn.commit();
			} catch (RepoproException e) {
				log.error("addAdminMessage || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}

			} catch (Exception e) {
				log.error("addAdminMessage || " + Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addAdminMessage : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("addAdminMessage ||" + messageBoardDto.toString()
						+ "|| End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(jsonList))).build();

		}
	}
	
	
	@POST
	@Path("/addBannerMessage")
	public Response addBannerMessage(MessageBoard messageBoard){
		
		if (messageBoard == null) {
			log.warn("addBannerMessage || message details to be inserted not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
									.getMessage(Constants.INVALID_REQUEST)))
					.build();
		} else {
			
			if (log.isTraceEnabled()) {
				log.trace("addBannerMessage ||" + messageBoard.toString() + " || Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			
			Connection conn = null;
			
			List<MessageBoard> jsonList = new ArrayList<MessageBoard>();
			
			MessageBoard messageboard = new MessageBoard();
			CommonUtils commonUtils = new CommonUtils();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			try {
				if (log.isTraceEnabled()) {
					log.trace("addBannerMessage ||" + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				
				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("addBannerMessage || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
				
				MessageBoardDao messageDao = new MessageBoardDao();
				
				MessageBoard allMessageDetails = messageDao.getAllMessageDetails(conn);
				String adminMessage = "";
				
				if(allMessageDetails.getAdminMessage() != null){
					adminMessage = allMessageDetails.getAdminMessage();
				}
				if(globalsetting.getGlobalSettingFlag() == 1){
					String bannerMessage = commonUtils.httpSanitizerForPlainText(messageBoard.getMaintenance());
					messageBoard.setMaintenance(bannerMessage);
				}
				messageBoard.setAdminMessage(adminMessage);
				
				if (log.isTraceEnabled()) {
					log.trace("addBannerMessage || call of dao method addMessageDetails()");
				}
				messageboard = messageDao.addMessageDetails(messageBoard, conn);
				
				retStat = Status.OK;
				retMsg = Constants.MESSAGE_BOARD_DATA_ADDED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				jsonList.add(messageboard);

				if (log.isInfoEnabled()) {
					log.info("addBannerMessage || message details " + messageboard.toString() + " inserted successfully ");
				}
				conn.commit();
				
				
			} catch (RepoproException e) {
				log.error("addBannerMessage || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}

			} catch (Exception e) {
				log.error("addBannerMessage || " + Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addBannerMessage : " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("addBannerMessage ||" + messageBoard.toString()
						+ "|| End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(jsonList))).build();
			
		}
		
		
	}
	
	
	/*** Wrapper function ***/
	@GET
	@Encoded
	@Path("/getAllMessageDetialsMain")
	public Response getAllMessageDetialsMain(@HeaderParam("token") String token) {
		
		log.trace("getAllMessageDetialsMain || Begin");

		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("admin")){
				response = this.getAllMessageDetials();
				
				MyModel res = (MyModel) response.getEntity();
				List<Object> data = res.getResult();
				List<Object> finalData = new ArrayList<Object>();
				
				JSONObject j1 = null;
				JSONObject json = new JSONObject();
				
				for(int i=0;i<data.size();i++){
					j1 = new JSONObject();
					MessageBoard messageBoard = new MessageBoard();
					messageBoard = (MessageBoard) data.get(i);
					
					j1.put("adminMessage", messageBoard.getAdminMessage());
					j1.put("createdBy", messageBoard.getCreatedBy());
					j1.put("createdOn", messageBoard.getCreatedOn());
					j1.put("ison", messageBoard.getIson());
					j1.put("maintenance", messageBoard.getMaintenance());
					
					finalData.add(j1);
				}
								
				json.put("result", finalData);
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("getAllMessageDetialsMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("getAllMessageDetialsMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
		} catch (RepoproException e) {
			log.error("getAllMessageDetialsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllMessageDetialsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		log.trace("getAllMessageDetialsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@POST
	@Encoded
	@Path("/addAdminMessageMain")
	public Response addAdminMessageMain(@QueryParam("adminMessage") String adminMessage,
			@HeaderParam("token") String token) {
		
		if(adminMessage == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		try{
			adminMessage = URLDecoder.decode(adminMessage, "UTF-8");
			adminMessage = adminMessage.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(adminMessage.isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
						
		log.trace("addAdminMessageMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("addAdminMessageMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User userData = userDao.getUserIdByUserName(userName, null);
				if(userData.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			LocalDateTime dateTime = LocalDateTime.now();
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String currentDateTime = dateTimeFormatter.format(dateTime);
						
			MessageBoard messageBoard = new MessageBoard();
			messageBoard.setCreatedBy(userName);
			messageBoard.setCreatedOn(Timestamp.valueOf(currentDateTime));
			
			if(userName.equalsIgnoreCase("admin")){
				
				String jsonStr1 = adminMessage;
				JSONObject jsonObject = new JSONObject(jsonStr1);
				
				if(jsonObject.has("adminMessage")){
					String adminMsg = jsonObject.get("adminMessage").toString();
					adminMsg = adminMsg.trim();
					if(adminMsg.length()>50000){
						return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
					}
					if(adminMsg.isEmpty()){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					messageBoard.setAdminMessage(adminMsg);
				}else{
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
				}
				
				response = this.addAdminMessage(messageBoard);
				MyModel res = (MyModel) response.getEntity();
				
				conn.commit();
				
				JSONObject json = new JSONObject();
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("addAdminMessageMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
		} catch (RepoproException e) {
			log.error("addAdminMessageMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addAdminMessageMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addAdminMessageMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("addAdminMessageMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@POST
	@Encoded
	@Path("/addBannerMessageMain")
	public Response addBannerMessageMain(@QueryParam("bannerMessage") String bannerMessage,
			@HeaderParam("token") String token) {
		
		if(bannerMessage == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		try{
			bannerMessage = URLDecoder.decode(bannerMessage, "UTF-8");
			bannerMessage = bannerMessage.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(bannerMessage.isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
						
		log.trace("addBannerMessageMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("addBannerMessageMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User userData = userDao.getUserIdByUserName(userName, null);
				if(userData.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			LocalDateTime dateTime = LocalDateTime.now();
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String currentDateTime = dateTimeFormatter.format(dateTime);
						
			MessageBoardDao messageBoardDao = new MessageBoardDao();
			MessageBoard msgBoard = messageBoardDao.getAllMessageDetails(conn);
			
			MessageBoard messageBoard = new MessageBoard();
			messageBoard.setCreatedBy(userName);
			messageBoard.setCreatedOn(Timestamp.valueOf(currentDateTime));
			
			if(userName.equalsIgnoreCase("admin")){
				
				String jsonStr1 = bannerMessage;
				JSONObject jsonObject = new JSONObject(jsonStr1);
				
				if(jsonObject.has("isOn")){
					String isOnFlag = jsonObject.get("isOn").toString();
					if(!isOnFlag.equalsIgnoreCase("true") && !isOnFlag.equalsIgnoreCase("false")){
						 return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					int isOnVal;
					if(isOnFlag.equalsIgnoreCase("true")){
						isOnVal = 1;
					}else{
						isOnVal = 0;
					}
					if(isOnFlag.equalsIgnoreCase("false") && jsonObject.has("bannerMessage")){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					messageBoard.setIson(isOnVal);
				}else{
					messageBoard.setIson(msgBoard.getIson());
					if(msgBoard.getIson() == 0 && jsonObject.has("bannerMessage")){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
				}
				
				if(jsonObject.has("bannerMessage")){
					String bannerMsg = jsonObject.get("bannerMessage").toString();
					bannerMsg = bannerMsg.trim();
					if(bannerMsg.length()>200){
						return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
					}
					if(bannerMsg.isEmpty()){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					messageBoard.setMaintenance(bannerMsg);
				}else{
					messageBoard.setMaintenance(msgBoard.getMaintenance());
				}
				
				response = this.addBannerMessage(messageBoard);
				MyModel res = (MyModel) response.getEntity();
				
				conn.commit();
				
				JSONObject json = new JSONObject();
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("addBannerMessageMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
		} catch (RepoproException e) {
			log.error("addBannerMessageMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (ClassCastException e) {
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		} catch (Exception e) {
			log.error("addBannerMessageMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addBannerMessageMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("addBannerMessageMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
}