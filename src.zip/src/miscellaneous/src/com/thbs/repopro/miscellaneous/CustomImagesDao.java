package com.thbs.repopro.miscellaneous;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.thbs.repopro.dto.LoginColorConfiguration;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class CustomImagesDao {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	
	/**
	 * @method : updateLoginFontFrameColor
	 * @param loginFontColorCode
	 * @param loginFrameColorCode
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateLoginFontFrameColor(String loginFontColorCode, String loginFrameColorCode, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("updateLoginFontFrameColor || Begin with loginFontColorCode : "
					+ loginFontColorCode +" \t loginFrameColorCode : "+ loginFrameColorCode);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("updateLoginFontFrameColor || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			LoginColorConfiguration loginColorConfig = retLoginColorConfiguration(conn);
			LoginColorConfiguration newloginColorConfig  = new LoginColorConfiguration();
			
			if(loginColorConfig != null){
				newloginColorConfig.setLoginColorConfigurationId(loginColorConfig.getLoginColorConfigurationId());
			}
			
			if(loginColorConfig == null){
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.INSERT_LOGIN_COLOR_CONFIG));
				pstmt.setString(Constants.ONE, loginFontColorCode);
				pstmt.setString(Constants.TWO, loginFrameColorCode);
				if (log.isTraceEnabled()) {
					log.trace("updateLoginFontFrameColor || "+PropertyFileReader.getInstance().
							getValue(Constants.INSERT_LOGIN_COLOR_CONFIG));
				}
			}else{
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.UPDATE_LOGIN_COLOR_CONFIG));
				pstmt.setString(Constants.ONE, loginFontColorCode);
				pstmt.setString(Constants.TWO, loginFrameColorCode);
				pstmt.setLong(Constants.THREE, newloginColorConfig.getLoginColorConfigurationId());
				if (log.isTraceEnabled()) {
					log.trace("updateLoginFontFrameColor || "+PropertyFileReader.getInstance().
							getValue(Constants.UPDATE_LOGIN_COLOR_CONFIG));
				}
			}
			
			
			if (log.isTraceEnabled()) {
				log.trace("updateLoginFontFrameColor || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_LOGIN_COLOR_CONFIG));
			}

			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("updateLoginFontFrameColor || " + Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.FAILED_TO_UPDATE_LOGIN_FONT_FRAME_COLOR));
		} catch (IOException e) {
			log.error("updateLoginFontFrameColor || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateLoginFontFrameColor || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateLoginFontFrameColor || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateLoginFontFrameColor || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("updateLoginFontFrameColor || end");
		}
		
	}
	
	
	/**
	 * @method : retLoginColorConfiguration
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public LoginColorConfiguration retLoginColorConfiguration(Connection conn) throws RepoproException{
		
		log.trace("retLoginColorConfiguration || Begin");
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		LoginColorConfiguration login = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("retLoginColorConfiguration || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_LOGIN_COLOR_CONFIG));
			
			if (log.isTraceEnabled()) {
				log.trace("retLoginColorConfiguration || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_LOGIN_COLOR_CONFIG));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				login = new LoginColorConfiguration();
				login.setLoginColorConfigurationId(rs.getLong("login_color_configuration_id"));
				login.setLoginFontColorCode(rs.getString("login_font_color_code"));
				login.setLoginFrameColorCode(rs.getString("login_frame_color_code"));
				
				if(log.isTraceEnabled()){
					log.trace("retLoginColorConfiguration || "+ login.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("retLoginColorConfiguration || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.LOGIN_COLOR_CONFIG_NOT_FOUND));
		} catch (IOException e) {
			log.error("retLoginColorConfiguration || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retLoginColorConfiguration || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retLoginColorConfiguration || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retLoginColorConfiguration || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		log.trace("retLoginColorConfiguration || end");
		return login;	
	}
	
	
	
public void updateColorcode(String loginFontColorCode, String loginFrameColorCode,String themecolor,String headingcolor,String Primary_Buttoncolor,String Primary_Button_text_color, String Secondary_Buttoncolor,String Secondary_Button_text_color, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("updateColorcode"
					+ loginFontColorCode+ loginFrameColorCode+themecolor+headingcolor+Primary_Buttoncolor+Primary_Button_text_color+Secondary_Buttoncolor+Secondary_Button_text_color);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("updateColorcode || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			LoginColorConfiguration loginColorConfig = new LoginColorConfiguration();
			if(loginColorConfig != null){
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.UPDATE_ALL_COLORCODES));
				pstmt.setString(Constants.ONE, loginFontColorCode);
				pstmt.setString(Constants.TWO, loginFrameColorCode);
				pstmt.setString(Constants.THREE, themecolor);
				pstmt.setString(Constants.FOUR, headingcolor);
				pstmt.setString(Constants.FIVE, Primary_Buttoncolor);
				pstmt.setString(Constants.SIX, Primary_Button_text_color);
				pstmt.setString(Constants.SEVEN,Secondary_Buttoncolor );
				pstmt.setString(Constants.EIGHT,Secondary_Button_text_color);
				
				
				if (log.isTraceEnabled()) {
					log.trace("updateColorcode || "+PropertyFileReader.getInstance().
							getValue(Constants.UPDATE_ALL_COLORCODES));
				
				}
				pstmt.executeUpdate();
				
			}
			
		} catch (SQLException e) {
			log.error("updateColorcode || " + Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.FAILED_TO_UPDATE_COLOR_CODE));
		} catch (IOException e) {
			log.error("updateColorcode || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateColorcode || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateColorcode || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateColorcode || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("updateColorcode || end");
		}
		
	}
	
	
	
public List<LoginColorConfiguration> getallThemeConfiguration(Connection conn) throws RepoproException{
	
		log.trace("getallThemeConfiguration || Begin");
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<LoginColorConfiguration> List = new ArrayList<LoginColorConfiguration>();
		LoginColorConfiguration login = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getallThemeConfiguration || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_LOGIN_COLOR_CONFIG));
			
			if (log.isTraceEnabled()) {
				log.trace("getallThemeConfiguration || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_LOGIN_COLOR_CONFIG));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				login = new LoginColorConfiguration();
				login.setLoginColorConfigurationId(rs.getLong("login_color_configuration_id"));
				login.setLoginFontColorCode(rs.getString("login_font_color_code"));
				login.setLoginFrameColorCode(rs.getString("login_frame_color_code"));
				login.setThemecolor(rs.getString("themecolor"));
				login.setHeadingcolor(rs.getString("headingcolor"));
				login.setPrimary_Buttoncolor(rs.getString("primary_button_color"));
				login.setPrimary_Button_text_color(rs.getString("primary_button_text_color"));
				login.setSecondary_Buttoncolor(rs.getString("secondary_button_color"));
				login.setSecondary_Button_text_color(rs.getString("secondary_button_text_color"));
				login.setLogoimage(rs.getBinaryStream("logoimage"));
				login.setLogo_filename(rs.getString("logo_image_name"));
				login.setFaviconimage(rs.getBinaryStream("faviconimage"));
				login.setFavicon_filename(rs.getString("favicon_image_name"));
				login.setBackground_image(rs.getBinaryStream("backgroundimage"));
				login.setBackgroundimg_filename(rs.getString("background_image_name"));
				login.setLoginPageLogo(rs.getBinaryStream("loginPageLogo"));
				login.setLoginPageLogo_filename(rs.getString("loginPagelogo_name"));
				List.add(login);
				
				
				if(log.isTraceEnabled()){
					log.trace("getallThemeConfiguration || "+ login.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getallThemeConfiguration || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.LOGIN_COLOR_CONFIG_NOT_FOUND));
		} catch (IOException e) {
			log.error("getallThemeConfiguration || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getallThemeConfiguration || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getallThemeConfiguration || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getallThemeConfiguration || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
				if(rs != null){
					rs.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		log.trace("getallThemeConfiguration || end");
		return List;	
	}



public void updateCustomImages(LoginColorConfiguration loginColorConfiguration, Connection conn) throws RepoproException{
	
	if(log.isTraceEnabled()){
		log.trace("updateCustomImages || Begin with loginColorConfiguration : "+loginColorConfiguration.toString());
	}
	
	Connection conn1 = null;
	PreparedStatement preparedStmt = null;
	PreparedStatement preparedStmt1 = null;
	PreparedStatement preparedStmt2 = null;
	PreparedStatement preparedStmt3 = null;
			
	try {
		if (log.isTraceEnabled()){
			log.trace("updateCustomImages || " + Constants.LOG_CONNECTION_OPEN);
		}
		if(conn == null){
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
		}
		
		List<LoginColorConfiguration> loginColorConfig = getallThemeConfiguration(conn);
		LoginColorConfiguration newloginColorConfigDto  = new LoginColorConfiguration();
		
		/*if(loginColorConfig != null){
			newloginColorConfigDto.setLoginColorConfigurationId(((LoginColorConfiguration) loginColorConfig).getLoginColorConfigurationId());
		}*/
		
		if(loginColorConfiguration.getLoginPageLogo_filename() != null && !(loginColorConfiguration.getLoginPageLogo_filename().equals(""))){
			
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_LOGIN_LOGOIMAGE));
			
			preparedStmt.setBinaryStream(Constants.ONE, loginColorConfiguration.getLoginPageLogo());
			preparedStmt.setString(Constants.TWO, loginColorConfiguration.getLoginPageLogo_filename());
			//preparedStmt.setLong(Constants.THREE, newloginColorConfigDto.getLoginColorConfigurationId());
			
			if (log.isTraceEnabled()) {
				log.trace("updateLoginFontFrameColor || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_LOGIN_LOGOIMAGE));
			}
			
			if (log.isTraceEnabled()) {
				log.trace("updateCustomImages || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_LOGIN_LOGOIMAGE));
			}
			preparedStmt.executeUpdate();
		}
		
		if(loginColorConfiguration.getBackgroundimg_filename() != null && !(loginColorConfiguration.getBackgroundimg_filename().equals(""))){
			
			preparedStmt1 = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_BACKGROUND_IMAGE));
			
			preparedStmt1.setBinaryStream(Constants.ONE, loginColorConfiguration.getBackground_image());
			preparedStmt1.setString(Constants.TWO, loginColorConfiguration.getBackgroundimg_filename());
		//	preparedStmt1.setLong(Constants.THREE, newloginColorConfigDto.getLoginColorConfigurationId());
			
			if (log.isTraceEnabled()) {
				log.trace("updateLoginFontFrameColor || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_BACKGROUND_IMAGE));
			}
			
			if (log.isTraceEnabled()) {
				log.trace("updateCustomImages || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_BACKGROUND_IMAGE));
			}
			preparedStmt1.executeUpdate();
		}
		
		if(loginColorConfiguration.getFavicon_filename() != null && !(loginColorConfiguration.getFavicon_filename().equals(""))){
			
			preparedStmt2 = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_FAVICON_IMAGE));
			
			preparedStmt2.setBinaryStream(Constants.ONE, loginColorConfiguration.getFaviconimage());
			preparedStmt2.setString(Constants.TWO, loginColorConfiguration.getFavicon_filename());
			//preparedStmt2.setLong(Constants.THREE, newloginColorConfigDto.getLoginColorConfigurationId());
			
			if (log.isTraceEnabled()) {
				log.trace("updateLoginFontFrameColor || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_FAVICON_IMAGE));
			}
			
			if (log.isTraceEnabled()) {
				log.trace("updateCustomImages || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_FAVICON_IMAGE));
			}
			preparedStmt2.executeUpdate();
		}
		
		if(loginColorConfiguration.getLogo_filename() != null && !(loginColorConfiguration.getLogo_filename().equals(""))){
			
			preparedStmt3 = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_LOGO_IMAGE));
			
			preparedStmt3.setBinaryStream(Constants.ONE, loginColorConfiguration.getLogoimage());
			preparedStmt3.setString(Constants.TWO, loginColorConfiguration.getLogo_filename());
			//preparedStmt3.setLong(Constants.THREE, newloginColorConfigDto.getLoginColorConfigurationId());
			
			if (log.isTraceEnabled()) {
				log.trace("updateLoginFontFrameColor || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_LOGO_IMAGE));
			}
			
			if (log.isTraceEnabled()) {
				log.trace("updateCustomImages || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_LOGO_IMAGE));
			}
			preparedStmt3.executeUpdate();
		}
		
		
	} catch (SQLException e) {
		log.error("updateCustomImages || " + Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(MessageUtil.getMessage(Constants.FAILED_TO_UPDATE_CUSTOM_IMAGES));
	} catch (IOException e) {
		log.error("updateCustomImages || " + Constants.LOG_IOEXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
	} catch (PropertyVetoException e) {
		log.error("updateCustomImages || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
	} catch (Exception e) {
		log.error("updateCustomImages || " + Constants.LOG_EXCEPTION + e.getMessage());
		e.printStackTrace();
		throw new RepoproException(e.getMessage());
	} finally {
		DBConnection.closePreparedStatement(preparedStmt3);
		DBConnection.closePreparedStatement(preparedStmt2);
		DBConnection.closePreparedStatement(preparedStmt1);
		DBConnection.closePreparedStatement(preparedStmt);
		DBConnection.closeDbConnection(conn1);
		if (log.isTraceEnabled()) {
			log.trace("updateCustomImages || " + Constants.LOG_CONNECTION_CLOSE);
		}
	}
	if(log.isTraceEnabled()){
		log.trace("updateLoginFontFrameColor || end");
	}
}

}
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

