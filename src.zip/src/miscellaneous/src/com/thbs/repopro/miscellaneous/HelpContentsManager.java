package com.thbs.repopro.miscellaneous;

import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.HelpContents;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;

@Path("/helpcontents")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class HelpContentsManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method :getHelpContents
	 * @description :to getHelpContents data
	 * @return :helpcontentslist
	 */

	@GET
	public Response getHelpContents() {

		log.trace("getHelpContents || Begin");

		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		HelpContents helpcontents = null;
		List<HelpContents> helpcontentslist = new ArrayList<HelpContents>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getHelpContents || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getHelpContents || dao call for getHelpContents() method ");
			}
			
			HelpContentsDao helpcontentsdao = new HelpContentsDao();
			
			helpcontents = helpcontentsdao.getHelpContents(conn);
			if(helpcontents != null){
				helpcontentslist.add(helpcontents);
			}
		   
			if (log.isDebugEnabled()) {
				log.debug("getHelpContents || fetched "
						+ helpcontentslist.size()
						+ " HelpContents data successfully ");
			}

			if(!helpcontentslist.isEmpty()) {
				retMsg = Constants.ALL_HELP_CONTENTS_DATA_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			} else {
				retMsg = Constants.HELP_CONTENTS_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			}
		}

		catch (RepoproException e) {
			log.error("getHelpContents || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		catch (Exception e) {
			log.error("getHelpContents || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("getHelpContents ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getHelpContents || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(helpcontentslist))).build();

	}

	/**
	 * @method :addNewHelpContents
	 * @description :to addNewHelpContents data
	 * @param :helpcontentsdata
	 * @return :Response success message
	 */

	@POST
	public Response addNewHelpContents(HelpContents helpcontentsdata) {

		if (helpcontentsdata == null) {
			log.warn("addNewHelpContents || helpcontentsdata is not provided for adding ");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
									.getMessage(Constants.INVALID_REQUEST)))
					.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("addNewHelpContents || "
						+ helpcontentsdata.toString() + "|| Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			List<HelpContents> jsonList = new ArrayList<HelpContents>();
			CommonUtils commonUtils = new CommonUtils();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			
			try {
				if (log.isTraceEnabled()) {
					log.trace("addNewHelpContents ||" + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				
				//get global setting setting details
				if (log.isTraceEnabled()){
					log.trace("addNewHelpContents || call of retGlobalSettingByName method");
				}
				GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
				
				if (log.isTraceEnabled()) {
					log.trace("addNewHelpContents || dao method called : addNewHelpContents ");
				}
				
				HelpContentsDao helpcontentsdao = new HelpContentsDao();

				if(globalsetting.getGlobalSettingFlag() == 1){
					String desc = commonUtils.httpSanitizerForCkEditor(helpcontentsdata.getHelp_Content());
					helpcontentsdata.setHelp_Content(desc);
				}
				
				HelpContents helpcontents = helpcontentsdao.addNewHelpContents(helpcontentsdata, conn);
				jsonList.add(helpcontents);
				if (log.isInfoEnabled()) {
					log.info("addNewHelpContents ||" + helpcontents.toString()
							+ " HelpContents data added successfully");

				}

				conn.commit();
				retStat = Status.OK;
				retMsg = Constants.HELP_CONTENTS_DATA_ADDED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}

			catch (RepoproException e) {
				log.error("addNewHelpContents || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}

			} catch (Exception e) {
				log.error("addNewHelpContents || " + Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addNewHelpContents ||" + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("addNewHelpContents || " + helpcontentsdata.toString() + "|| End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(jsonList))).build();

		}

	}
	
	
	/*** Wrapper function ***/
	@GET
	@Encoded
	@Path("/getHelpContentsMain")
	public Response getHelpContentsMain(@HeaderParam("token") String token) {
		
		log.trace("getHelpContentsMain || Begin");

		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("admin")){
				response = this.getHelpContents();
				
				MyModel res = (MyModel) response.getEntity();
				List<Object> data = res.getResult();
				List<Object> finalData = new ArrayList<Object>();
				
				JSONObject j1 = null;
				JSONObject json = new JSONObject();
				
				for(int i=0;i<data.size();i++){
					j1 = new JSONObject();
					HelpContents helpContents = new HelpContents();
					helpContents = (HelpContents) data.get(i);
					
					j1.put("helpContents", helpContents.getHelp_Content());
					j1.put("createdBy", helpContents.getCreated_By());
					j1.put("createdOn", helpContents.getCreated_On());
					
					finalData.add(j1);
				}
								
				json.put("result", finalData);
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("getHelpContentsMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("getHelpContentsMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
		} catch (RepoproException e) {
			log.error("getHelpContentsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getHelpContentsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		log.trace("getHelpContentsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@POST
	@Encoded
	@Path("/addNewHelpContentsMain")
	public Response addNewHelpContentsMain(@QueryParam("helpContents") String helpContents,
			@HeaderParam("token") String token) {
		
		if(helpContents == null){
			   return Response.status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		try{
			helpContents = URLDecoder.decode(helpContents, "UTF-8");
			helpContents = helpContents.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(helpContents.isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
						
		log.trace("addNewHelpContentsMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("addNewHelpContentsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if(!userName.equalsIgnoreCase("guest")){
				User userData = userDao.getUserIdByUserName(userName, null);
				if(userData.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			LocalDateTime dateTime = LocalDateTime.now();
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String currentDateTime = dateTimeFormatter.format(dateTime);
						
			HelpContents helpcontentsdata = new HelpContents();
			helpcontentsdata.setCreated_By(userName);
			helpcontentsdata.setCreated_On(Timestamp.valueOf(currentDateTime));
			
			if(userName.equalsIgnoreCase("admin")){
				
				String jsonStr1 = helpContents;
				JSONObject jsonObject = new JSONObject(jsonStr1);
				
				if(jsonObject.has("helpContents")){
					String helpContent = jsonObject.get("helpContents").toString();
					helpContent = helpContent.trim();
					if(helpContent.length()>50000){
						return Response.status(Status.BAD_REQUEST)
							     .entity(new MyModelRest(Constants.STATUS_FAILURE,
							       Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED))).build();
					}
					if(helpContent.isEmpty()){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					helpcontentsdata.setHelp_Content(helpContent);
				}else{
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
				}
				
				response = this.addNewHelpContents(helpcontentsdata);
				MyModel res = (MyModel) response.getEntity();
				
				conn.commit();
				
				JSONObject json = new JSONObject();
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("addNewHelpContentsMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
		} catch (RepoproException e) {
			log.error("addNewHelpContentsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addNewHelpContentsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addNewHelpContentsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("addNewHelpContentsMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

}
