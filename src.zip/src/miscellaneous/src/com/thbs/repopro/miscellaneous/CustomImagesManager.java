package com.thbs.repopro.miscellaneous;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.LoginColorConfiguration;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.MULTIPART_FORM_DATA})
@Path("/customimagesmanager")
public class CustomImagesManager {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	static int faviconCntr = 0;
	
	/**
	 * @method : getLoginFontFrameColor
	 * @return success response
	 */
	@GET
	@Path("/loginfontframecolor")
	public Response getLoginFontFrameColor(){
		
		if(log.isTraceEnabled()){
			log.trace("getLoginFontFrameColor || Begin");
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<LoginColorConfiguration> colorConfig = new ArrayList<LoginColorConfiguration>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getLoginFontFrameColor || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			CustomImagesDao dao = new CustomImagesDao();
			
			LoginColorConfiguration retLoginColorConfiguration = dao.retLoginColorConfiguration(conn);
			
			colorConfig.add(retLoginColorConfiguration);
			
			log.info("getLoginFontFrameColor || Login page - Login Font Color/Login Frame Color fetched successfully");
			
			retMsg = Constants.LOGIN_FONT_FRAME_COLOR_FETCHED;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("getLoginFontFrameColor || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getLoginFontFrameColor || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getLoginFontFrameColor || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getLoginFontFrameColor || end");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg,
						new ArrayList<Object>(colorConfig)))
				.build();
	}
	
	
	
	@PUT
	@Path("/allthemecolors")
	public Response allthemecolors(FormDataMultiPart formParams, @Context ServletContext context){
		
		if(log.isTraceEnabled()){
			log.trace("allthemecolors || Begin");
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("allthemecolors || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			conn = DBConnection.getInstance().getConnection();
			
			CustomImagesDao dao = new CustomImagesDao();
			LoginColorConfiguration loginColorConfiguration = new LoginColorConfiguration();
			
			String loginFontColorCode = "";
			String loginFrameColorCode = "";
			String headingcolor="";
			String themecolor = "";
			String Primary_Buttoncolor="";
		    String Primary_Button_text_color="";
			String Secondary_Buttoncolor="";
			String Secondary_Button_text_color="";
			
			
			FormDataBodyPart dataMultiPart;
			dataMultiPart = formParams.getField("loginFontColorCode");
			
			FormDataBodyPart dataMultiPart0;
			dataMultiPart0 = formParams.getField("loginFrameColorCode");
			FormDataBodyPart dataMultiPart4;
			dataMultiPart4 = formParams.getField("themecolor");
			FormDataBodyPart dataMultiPart3;
			dataMultiPart3 = formParams.getField("headingcolor");
			
			FormDataBodyPart dataMultiPart1;
			dataMultiPart1 = formParams.getField("Primary_Buttoncolor");
			
			FormDataBodyPart dataMultiPart2;
			dataMultiPart2 = formParams.getField("Primary_Button_text_color");
			
			
			FormDataBodyPart dataMultiPart10;
			dataMultiPart10 = formParams.getField("Secondary_Buttoncolor");
			
			FormDataBodyPart dataMultiPart20;
			dataMultiPart20 = formParams.getField("Secondary_Button_text_color");
			
			if(dataMultiPart != null){
				loginFontColorCode = formParams.getField("loginFontColorCode").getValue();
				loginColorConfiguration.setLoginFontColorCode(loginFontColorCode);
				//System.out.println(loginFontColorCode);
			}
			if(dataMultiPart0 != null){
				loginFrameColorCode = formParams.getField("loginFrameColorCode").getValue();
				loginColorConfiguration.setLoginFrameColorCode(loginFrameColorCode);
				//System.out.println(loginFrameColorCode);
			}
			if(dataMultiPart4 != null){
				themecolor = formParams.getField("themecolor").getValue();
				loginColorConfiguration.setThemecolor(themecolor);
				//System.out.println(themecolor);
			}
			if(dataMultiPart3 != null){
				headingcolor = formParams.getField("headingcolor").getValue();
				loginColorConfiguration.setHeadingcolor(headingcolor);
				
			}
			
			if(dataMultiPart1 != null){
				Primary_Buttoncolor = formParams.getField("Primary_Buttoncolor").getValue();
				loginColorConfiguration.setPrimary_Buttoncolor(Primary_Buttoncolor);
				
			}
			
			if(dataMultiPart2 != null){
				Primary_Button_text_color = formParams.getField("Primary_Button_text_color").getValue();
				loginColorConfiguration.setPrimary_Button_text_color(Primary_Button_text_color);
				
			}
			if(dataMultiPart10 != null){
				Secondary_Buttoncolor = formParams.getField("Secondary_Buttoncolor").getValue();
				loginColorConfiguration.setSecondary_Buttoncolor(Secondary_Buttoncolor);
				
			}
			if(dataMultiPart20 != null){
				Secondary_Button_text_color = formParams.getField("Secondary_Button_text_color").getValue();
				loginColorConfiguration.setSecondary_Button_text_color(Secondary_Button_text_color);
				
			}
			
			if(dataMultiPart!=null|| dataMultiPart0!=null ||dataMultiPart4 != null || dataMultiPart3 != null || dataMultiPart1!=null || dataMultiPart2!=null|| dataMultiPart10 != null ||dataMultiPart20 != null){
				
					if(log.isTraceEnabled()){
						log.trace("updateColorcode || dao method called : updateColorcode()");
					}
					dao.updateColorcode(loginFontColorCode, loginFrameColorCode,themecolor, headingcolor, Primary_Buttoncolor,Primary_Button_text_color, Secondary_Buttoncolor, Secondary_Button_text_color,  conn);
					conn.commit();
					
			}
			//loginColorConfiguration.setLoginFontColorCode(loginFontColorCode);
			
			FormDataBodyPart dataMultiPart5;
			dataMultiPart5 = formParams.getField("logoimage");
			
			if(dataMultiPart5 != null){
				if (formParams != null) {
					
					BufferedImage image = null;
					
					image = ImageIO.read(dataMultiPart5.getEntityAs(InputStream.class));
					String name = dataMultiPart5.getContentDisposition().getFileName();
					

					if(null != name && !(name.equals(""))){
						File file = new File(context.getRealPath("")+ Constants.THEME_FILE_NAME);
						String[] myFiles;
						String imagename="logoimage";
						if (file.isDirectory()) {
							myFiles = file.list();
							for (int i = 0; i < myFiles.length; i++) {
								File myFile = new File(file, myFiles[i]);
								if(myFile.getName().equalsIgnoreCase(imagename+".jpg")||myFile.getName().equalsIgnoreCase(imagename+".png"))
								{
									myFile.delete();
								}
							}
						}
						if (name.toLowerCase().indexOf("jpg".toLowerCase()) != -1
								|| name.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
							
							String uploadedFileLocation = context.getRealPath("")+Constants.THEME_FILE_NAME+imagename+Constants.USERIMAGE_JPG_NAME;
							
							ImageIO.write(image, "jpg", new File(uploadedFileLocation));
							} 
						
						else  if (file.isDirectory()) {
							myFiles = file.list();
							for (int i = 0; i < myFiles.length; i++) {
								File myFile = new File(file, myFiles[i]);
								if(myFile.getName().equalsIgnoreCase(imagename+".jpg")||myFile.getName().equalsIgnoreCase(imagename+".png"))
								{
									myFile.delete();
								}
							}
						}
						if (name.toLowerCase().indexOf("png".toLowerCase()) != -1
								|| name.toUpperCase().indexOf("png".toUpperCase()) != -1) {
							
                            String uploadedFileLocation = context.getRealPath("")+Constants.THEME_FILE_NAME+imagename+Constants.USERIMAGE_PNG_NAME;
                            ImageIO.write(image, "png", new File(uploadedFileLocation));
						}
						loginColorConfiguration.setLogoimage(dataMultiPart5.getEntityAs(InputStream.class));
						loginColorConfiguration.setLogo_filename(name);
						//System.out.println(uploadedFileLocation);
					}
				}
				
				File file41 = new File(System.getProperty("user.home")+"/ClientImages");
		    	if (!file41.exists())
		    	{
		    		if (file41.mkdir()) {
		    			System.out.println("Directory ClientImages is created!");
		    		} else {
		    			System.out.println("Failed to create directory ClientImages!");
		    		}
		    	}
			}
		
			FormDataBodyPart dataMultiPart6;
			dataMultiPart6 = formParams.getField("faviconimage");
			
			if(dataMultiPart6 != null){
				if (formParams != null) {
					
					BufferedImage image = null;
					
					image = ImageIO.read(dataMultiPart6.getEntityAs(InputStream.class));
					String name = dataMultiPart6.getContentDisposition().getFileName();
					
					if(null != name && !(name.equals(""))){
						File file = new File(context.getRealPath("")+ Constants.THEME_FILE_NAME);
						String[] myFiles;
						String imagename="themefavicon";
						if (file.isDirectory()) {
							myFiles = file.list();
							for (int i = 0; i < myFiles.length; i++) {
								File myFile = new File(file, myFiles[i]);
								if(myFile.getName().equalsIgnoreCase(imagename+".jpg")||myFile.getName().equalsIgnoreCase(imagename+".png"))
								{
									myFile.delete();
								}
							}
						}
						if (name.toLowerCase().indexOf("jpg".toLowerCase()) != -1
								|| name.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
							
							String uploadedFileLocation = context.getRealPath("")+Constants.THEME_FILE_NAME+imagename+Constants.USERIMAGE_JPG_NAME;
							
							ImageIO.write(image, "jpg", new File(uploadedFileLocation));
							

						} else
							if (file.isDirectory()) {
								myFiles = file.list();
								for (int i = 0; i < myFiles.length; i++) {
									File myFile = new File(file, myFiles[i]);
									if(myFile.getName().equalsIgnoreCase(imagename+".jpg")||myFile.getName().equalsIgnoreCase(imagename+".png"))
									{
										myFile.delete();
									}
								}
							}
						
						if (name.toLowerCase().indexOf("png".toLowerCase()) != -1
								|| name.toUpperCase().indexOf("png".toUpperCase()) != -1) {
							String uploadedFileLocation = context.getRealPath("")+Constants.THEME_FILE_NAME+imagename+Constants.USERIMAGE_PNG_NAME;
							
							ImageIO.write(image, "png", new File(uploadedFileLocation));
							
						}
						loginColorConfiguration.setFaviconimage(dataMultiPart6.getEntityAs(InputStream.class));
						loginColorConfiguration.setFavicon_filename(name);
					}
				}
				
				File file41 = new File(System.getProperty("user.home")+"/ClientImages");
		    	if (!file41.exists())
		    	{
		    		if (file41.mkdir()) {
		    			System.out.println("Directory ClientImages is created!");
		    		} else {
		    			System.out.println("Failed to create directory ClientImages!");
		    		}
		    	}				
			}
			FormDataBodyPart dataMultiPart7;
			dataMultiPart7 = formParams.getField("backgroundimage");
			if(null !=  dataMultiPart7 ){
				if (formParams != null) {
					
					BufferedImage image = null;
					
					image = ImageIO.read(dataMultiPart7.getEntityAs(InputStream.class));
					String name = dataMultiPart7.getContentDisposition().getFileName();
					
					if(null != name && !(name.equals(""))){
						File file = new File(context.getRealPath("")+ Constants.THEME_FILE_NAME);
						String[] myFiles;
						String imagename="background";
						if (file.isDirectory()) {
							myFiles = file.list();
							for (int i = 0; i < myFiles.length; i++) {
								File myFile = new File(file, myFiles[i]);
								if(myFile.getName().equalsIgnoreCase(imagename+".jpg")||myFile.getName().equalsIgnoreCase(imagename+".png"))
								{
									myFile.delete();
								}
							}
						}
						if (name.toLowerCase().indexOf("jpg".toLowerCase()) != -1
								|| name.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
							
							String uploadedFileLocation = context.getRealPath("")+Constants.THEME_FILE_NAME+imagename+Constants.USERIMAGE_JPG_NAME;
							
							ImageIO.write(image, "jpg", new File(uploadedFileLocation));
							

						} else
							if (file.isDirectory()) {
								myFiles = file.list();
								for (int i = 0; i < myFiles.length; i++) {
									File myFile = new File(file, myFiles[i]);
									if(myFile.getName().equalsIgnoreCase(imagename+".jpg")||myFile.getName().equalsIgnoreCase(imagename+".png"))
									{
										myFile.delete();
									}
								}
							}
						
						 if (name.toLowerCase().indexOf("png".toLowerCase()) != -1
								|| name.toUpperCase().indexOf("png".toUpperCase()) != -1) {
								String uploadedFileLocation = context.getRealPath("")+Constants.THEME_FILE_NAME+imagename+Constants.USERIMAGE_PNG_NAME;
								
							ImageIO.write(image, "png", new File(uploadedFileLocation));
						}
						loginColorConfiguration.setBackground_image(dataMultiPart7.getEntityAs(InputStream.class));
						loginColorConfiguration.setBackgroundimg_filename(name);
					}
				}
				
				File file41 = new File(System.getProperty("user.home")+"/ClientImages");
		    	if (!file41.exists())
		    	{
		    		if (file41.mkdir()) {
		    			System.out.println("Directory ClientImages is created!");
		    		} else {
		    			System.out.println("Failed to create directory ClientImages!");
		    		}
		    	}				
			
			}
		
			FormDataBodyPart dataMultiPart8;
			dataMultiPart8 = formParams.getField("loginPageLogo");
			if( dataMultiPart8 != null ){
				if (formParams != null) {
					
					BufferedImage image = null;
					
					image = ImageIO.read(dataMultiPart8.getEntityAs(InputStream.class));
					String name = dataMultiPart8.getContentDisposition().getFileName();
					if(null != name && !(name.equals(""))){
						File file = new File(context.getRealPath("")+ Constants.THEME_FILE_NAME);
						String[] myFiles;
						String imagename="loginlogo";
						if (file.isDirectory()) {
							myFiles = file.list();
							for (int i = 0; i < myFiles.length; i++) {
								File myFile = new File(file, myFiles[i]);
								if(myFile.getName().equalsIgnoreCase(imagename+".jpg")||myFile.getName().equalsIgnoreCase(imagename+".png"))
								{
									myFile.delete();
								}
							}
						}
						if (name.toLowerCase().indexOf("jpg".toLowerCase()) != -1
						|| name.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
							
							String uploadedFileLocation = context.getRealPath("")+Constants.THEME_FILE_NAME+imagename+Constants.USERIMAGE_JPG_NAME;
							
					        ImageIO.write(image, "jpg", new File(uploadedFileLocation));
					

				} else
					if (file.isDirectory()) {
						myFiles = file.list();
						for (int i = 0; i < myFiles.length; i++) {
							File myFile = new File(file, myFiles[i]);
							if(myFile.getName().equalsIgnoreCase(imagename+".jpg")||myFile.getName().equalsIgnoreCase(imagename+".png"))
							{
								myFile.delete();
							}
						}
					}
						 if (name.toLowerCase().indexOf("png".toLowerCase()) != -1
								|| name.toUpperCase().indexOf("png".toUpperCase()) != -1) {
							 String uploadedFileLocation = context.getRealPath("")+Constants.THEME_FILE_NAME+imagename+Constants.USERIMAGE_PNG_NAME;
								
							ImageIO.write(image, "png", new File(uploadedFileLocation));
							
						}
						loginColorConfiguration.setLoginPageLogo(dataMultiPart8.getEntityAs(InputStream.class));
						loginColorConfiguration.setLoginPageLogo_filename(name);
					}
				}
				File file41 = new File(System.getProperty("user.home")+"/ClientImages");
		    	if (!file41.exists())
		    	{
		    		if (file41.mkdir()) {
		    			System.out.println("Directory ClientImages is created!");
		    		} else {
		    			System.out.println("Failed to create directory ClientImages!");
		    		}
		    	}	
			}
			Color decode = Color.decode(themecolor);
			//Color decode2 = Color.decode(Secondary_Button_text_color);
			String str =".primary,.primary:hover,.ui.primary.buttons .button:focus, .ui.primary.button:focus,#submitSavedFilter,#openAddReviewModalButton:focus, #Newcomment:focus,button#openAddReviewModalButton:focus,.loginButtonColor{ background-color : "+ Primary_Buttoncolor +" !important;color: "+ Primary_Button_text_color +" !important;}" 
					+".loginPrimary,.ui.loginButtonColor.button:focus{ background-color : "+ Primary_Buttoncolor +" !important;color: "+ Primary_Button_text_color +" !important;}" 
					+".themeTextColor, .ui.basic.button , .ui.basic.button:hover,.tabsActiveColor,.sidebarSelectedItemColor { color : "+themecolor+" !important;}"
					+".action-button, input:checked ~ .geekmark{ background: "+themecolor+" !important;}"
					+".assetInstanceFloatingMenuSelected { border-right: 4px solid  "+themecolor+" !important;}"
					+"::-webkit-scrollbar-track { background-color: rgba("+decode.getRed()+","+decode.getGreen()+","+decode.getBlue()+", 0.2) !important;}"
					+"::-webkit-scrollbar-thumb { background-color: rgba("+decode.getRed()+","+decode.getGreen()+","+decode.getBlue()+", 0.8) !important;}"
					+"#sidebarCustom { border-right: 1px solid "+themecolor+" !important; }"
					+"button#addRuleBtn,#addRuleSetBtn, #updateRuleSetBtn { color: "+ themecolor +" !important;}"
					+".addRule{ color: "+ themecolor +" !important;}"
					+"#addRuleSet,#addRuleSet:hover,div#commentButtonAccess:focus{color: "+ themecolor +" !important;}"
					//+"i.add.icon,i.write.icon {color: "+ themecolor +" !important;}"
					+".themeBackgroundColor ,a#testMailID:focus{ background-color : " +themecolor+" !important;}"
					+"#workflowDropdown,#testMailID {border: 1px solid "+themecolor+" !important;color:"+themecolor+" !important;}"
					+".modalHeader {background-color: "+themecolor+" !important;color: "+Primary_Button_text_color+" !important;}"
					+".floatIcons {background-color: "+themecolor+"!important;color: "+Primary_Button_text_color+" !important;}"
					+".floatingIconsUL li a {background-color: "+themecolor+"!important;color: "+Primary_Button_text_color+" !important;}"
			+".bigIconImageCircleStyle_themeCircle { border: 1px solid "+themecolor+" !important; background-color: "+themecolor+" !important;}"
			+".mediumIconImageCircleStyle_asset_themeCircle { border: 1px solid "+themecolor+" !important; background-color: "+themecolor+" !important; }"
			+".smallIconImageCircleStyle_themeCircle { border: 1px solid "+themecolor+" !important;background-color: "+themecolor+" !important;}"
			+".quickStatClass { border: 1px solid "+themecolor+" !important; background-color: "+themecolor+" !important;}"
			//+".deleteEditIcon,.deleteEditIcon:hover{color: "+ Primary_Buttoncolor +" !important;}"
			+".deleteEditIcon:hover, .filterApply, .ms-selectall {color: "+ themecolor +" !important;}"
			+".basicButtonStyle,.basicButtonStyle:hover{box-shadow: 0px 0px 0px 1px "+ themecolor +" inset !important;}"
			+"a.login_anchor,a.login_anchor:hover{color: "+themecolor+" !important;}"
			+"#headingName{color: "+headingcolor+" !important;}"
			+".themeSecondary{background: "+Secondary_Buttoncolor+" !important; color: "+Secondary_Button_text_color+"!important;}"
			//+".cancel { background: "+Secondary_Buttoncolor+" !important; color: rgba("+decode2.getRed()+","+decode2.getGreen()+","+decode2.getBlue()+", 0.2) !important;}"
			+".actionClass .selection{background: "+Primary_Buttoncolor+" !important;color: "+ Primary_Button_text_color +" !important;}"
            +".themeText{color: "+ Primary_Button_text_color +" !important;}"
            +"#alertingSVG path{fill: "+ Primary_Button_text_color +" !important}"
            //+".ui.basic.primary.buttons .button, .ui.basic.primary.button,.ui.basic.primary.button:hover {box-shadow: 0px 0px 0px 1px "+themecolor+" inset !important;color: "+themecolor+" !important;}"
            +"#actionClassSelcted .themeText{color: "+ Primary_Button_text_color +" !important;}";

			
			
			File file = new File (context.getRealPath("")+"/semantic/css/"+"themes.css");
			
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(str);
			bw.close();
			
			dao.updateCustomImages(loginColorConfiguration, conn);
			conn.commit();
			
			log.info("allthemecolors || allthemecolors uploaded successfully");
			retMsg = Constants.ALL_THEMECOLORS_UPDATED_SUCCESSFULLY;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			
		} catch(RepoproException e){
			log.error("allthemecolors || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
		} catch(Exception e){
			log.error("allthemecolors || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("allthemecolors || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("allthemecolors || end");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
				.build();
	}
	

	
	
	
	
	
	@GET
	@Path("/getallThemeConfiguration")
	public Response getallThemeConfiguration(){
		
		if(log.isTraceEnabled()){
			log.trace("getallThemeConfiguration || Begin");
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<LoginColorConfiguration> List = new ArrayList<LoginColorConfiguration>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getallThemeConfiguration || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			CustomImagesDao dao = new CustomImagesDao();
			
			//LoginColorConfiguration getallThemeConfiguration = dao.getallThemeConfiguration(conn);
			
			//colorConfig.add(getallThemeConfiguration);
			List = dao.getallThemeConfiguration(conn);
			
			
			
			//log.info("getallThemeConfiguration || Login page - Login Font Color/Login Frame Color fetched successfully");
			log.info(" getallThemeConfiguration || retrieved "+ List.size() +" Login page - Login Font Color/Login Frame Color fetched successfully");
			retMsg = Constants.THEME_DETAILS_FETCHED;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("getallThemeConfiguration || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getallThemeConfiguration || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getallThemeConfiguration || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getallThemeConfiguration || end");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg,
						new ArrayList<Object>(List)))
				.build();
	}
	
	
	
	
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getThemeflag")
	public Response getmailconflag() {
		log.trace("getThemeflag || Begin ");
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		LoginColorConfiguration configList = null;
		boolean flag = false;
		HashMap<String, Boolean> flagstatus= new HashMap<String, Boolean>();
		List<Boolean> resultFlag = new ArrayList<Boolean>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getThemeflag || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			CustomImagesDao dao = new CustomImagesDao();
			if (log.isTraceEnabled()) {
				log.trace("getThemeflag || dao method called : getallmailconfig()");
			}
			configList = (LoginColorConfiguration) dao.getallThemeConfiguration(conn);
			
			if (configList != null) {
				flag = true;
			}
			flagstatus.put("themeAccessflag", flag);
		    resultFlag.add(flag);
			log.debug(" getThemeflag || retrieved "+ configList +" details successfully");

				retStat = Status.OK;
				retMsg = Constants.THEME_DETAILS_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			

			} catch(RepoproException e){
				log.error("getThemeflag || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
			} catch(Exception e){
				log.error("getThemeflag || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("getThemeflag || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			
		log.trace("getThemeflag || End");
		return Response.status(retStat)
                .entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(resultFlag))).build();
}

}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



