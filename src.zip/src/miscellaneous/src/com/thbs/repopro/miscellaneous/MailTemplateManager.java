package com.thbs.repopro.miscellaneous;

import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;

@Path("/mailTemplate")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON , MediaType.MULTIPART_FORM_DATA})
public class MailTemplateManager {
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method getMailTemplate
	 * @description get list of MailTemplate details
	 * @return success response
	 * @result success response
	 */
	@GET
	@Path("/allMailTemplate")
	public Response getMailTemplate() {

		log.trace("getMailTemplate || begin");

		MailTemplateDao mailTemplateDao = new MailTemplateDao();
		List<MailTemplate> mailTemplateList = null;
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getMailTemplate || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (log.isTraceEnabled()) {
				log.trace("getMailTemplate || dao method called : getMailTemplate()");
			}
			mailTemplateList = mailTemplateDao.getMailTemplate(conn);

			retStat = Status.OK;
			retMsg = Constants.MAILTEMPLATE_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			log.debug(" getMailTemplate  || retrieved "
					+ mailTemplateList.size() + " mailTemplates successfully");

			if (mailTemplateList.isEmpty()) {

				retStat = Status.OK;
				retMsg = Constants.MAILTEMPLATE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			}
		} catch (RepoproException e) {
			log.error("getMailTemplate || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getMailTemplate || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getMailTemplate || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getMailTemplate ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(mailTemplateList))).build();

	}

	/**
	 * @method updateMailTemplate
	 * @description update list of MailTemplates
	 * @param mailTemplateList
	 * @return success response
	 */
	@PUT
	@Path("/updateMailTemplate")
	public Response updateMailTemplate(List<MailTemplate> mailTemplateList)
			throws RepoproException {
		if (mailTemplateList == null) {
			log.warn("updateMailTemplate || roledata to be updated is not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
									.getMessage(Constants.INVALID_REQUEST)))
					.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("updateMailTemplate || Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			MailTemplateDao mailTemplateDao = new MailTemplateDao();

			try {
				if (log.isTraceEnabled()) {
					log.trace("updateMailTemplate ||"
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("updateMailTemplate || dao method called updateMailTemplate()");
				}

				mailTemplateDao.updateMailTemplate(mailTemplateList, conn);

				log.info(" updateMailTemplate  ||"
						+ mailTemplateList.toString()
						+ " mailTemplates data updated successfully");

				conn.commit();
				retMsg = Constants.MAILTEMPLATE_DATA_UPDATED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			} catch (RepoproException e) {
				log.error("updateMailTemplate || SQL Exception updateMailTemplate: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch (Exception e) {
				log.error("updateMailTemplate || SQL Exception updateMailTemplate: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateMailTemplate ||"
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("updateMailTemplate || End");
			}

			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
					.build();

		}
	}
	
	
	/*** Wrapper function ***/
	@GET
	@Encoded
	@Path("/getAllMailTemplateMain")
	public Response getAllMailTemplateMain(@HeaderParam("token") String token) {
		
		log.trace("getAllMailTemplateMain || Begin");

		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("admin")){
				response = this.getMailTemplate();
				
				MyModel res = (MyModel) response.getEntity();
				List<Object> data = res.getResult();
				List<Object> finalData = new ArrayList<Object>();
				
				JSONObject j1 = null;
				JSONObject json = new JSONObject();
				
				for(int i=0;i<data.size();i++){
					j1 = new JSONObject();
					MailTemplate mailTemplate = new MailTemplate();
					mailTemplate = (MailTemplate) data.get(i);
										
					Pattern pattern = Pattern.compile("%(.*?)%");
					Matcher matcher = pattern.matcher(mailTemplate.getMailTemplate());
					/*System.out.println(matcher.group(0)); 0 gives %abc% 1 gives abc*/
															
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("createAssetType")){
						j1.put("eventName","New Asset Type Created");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetType%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("updateAssetType")){
						j1.put("eventName","Asset Type Details Updated");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetType%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("deleteAssetType")){
						j1.put("eventName","Asset Type Deleted");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetType%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("createAssetInstanceNonVersion")){
						j1.put("eventName","New Asset Instance Created");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetType%, %assetInstName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("updateAssetInstDescForVersionableAsset")){
						j1.put("eventName","Asset Instance Description Updated (Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%, %versionName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("updateAssetInstDescForNonVersionableAsset")){
						j1.put("eventName","Asset Instance Description Updated (Non-Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("saveDependenciesForVersionableAsset")){
						j1.put("eventName","Relationships Updated (Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%, %versionName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("saveDependenciesForNonVersionableAsset")){
						j1.put("eventName","Relationships Updated (Non-Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("updateAssetInstanceName")){
						j1.put("eventName","Asset Instance Renamed");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%oldInstanceName%, %newInstanceName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("updatePropertiesForVersionableAsset")){
						j1.put("eventName","Property Values Updated (Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%, %versionName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("updatePropertiesForNonVersionableAsset")){
						j1.put("eventName","Property Values Updated (Non-Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("removeTaxonomyName")){
						j1.put("eventName","Taxonomy Node Deleted from Tree");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%taxName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("renameTaxonomyName")){
						j1.put("eventName","Taxonomy Node Renamed");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%taxName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("assignTaxNameForAssetInstanceForVersionableAsset")){
						j1.put("eventName","Taxonomy Assigned to Asset Instance (Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assignTaxName%, %assetInstName%, %versionName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("unassignTaxNameForAssetInstanceForVersionableAsset")){
						j1.put("eventName","Taxonomy Unassigned from Asset Instance (Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%unassignTaxName%, %assetInstName%, %versionName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("updateUserProfile")){
						j1.put("eventName","User Profile Updated");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%fullName%, %emailId%, %userName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("passwordReset")){
						j1.put("eventName","User Password Changed");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%newPassword%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("editAssetInstanceVersion")){
						j1.put("eventName","Version Edited for Asset Instance");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%, %versionName%, %newVersionName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("deleteAssetInstanceVersionForVersionableAsset")){
						j1.put("eventName","Asset Instance Deleted (Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%, %versionName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("deleteAssetInstanceVersionForNonVersionableAsset")){
						j1.put("eventName","Asset Instance Deleted (Non-Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("createAssetInstanceVersion")){
						j1.put("eventName","Create New Asset Instance Version");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%, %versionName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("assignTaxNameForAssetInstanceForNonVersionableAsset")){
						j1.put("eventName","Taxonomy Assigned to Asset Instance (Non-Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assignTaxName%, %assetInstName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("unassignTaxNameForAssetInstanceForNonVersionableAsset")){
						j1.put("eventName","Taxonomy Unassigned from Asset Instance (Non-Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%unassignTaxName%, %assetInstName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("addTaxonomyName")){
						j1.put("eventName","A taxonomy child has been added");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%childTaxonomyName%, %parentTaxonomyName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("updateAssetInstanceForNonVersionableAsset")){
						j1.put("eventName","Asset Instance has been updated (Non-Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%");
					}
					if(mailTemplate.getFunctionalityName().equalsIgnoreCase("updateAssetInstanceForVersionableAsset")){
						j1.put("eventName","Asset Instance has been updated (Versionable Asset)");
						j1.put("mailTemplate", mailTemplate.getMailTemplate());
						j1.put("macrosAvailable", "%assetInstName%,%versionName%");
					}
					
					finalData.add(j1);
				}
				
				json.put("result", finalData);
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("getAllMailTemplateMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("getAllMailTemplateMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
						
		} catch (RepoproException e) {
			log.error("getAllMailTemplateMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllMailTemplateMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		log.trace("getAllMailTemplateMain || End");
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/**
	 * @method updateGroupMain
	 * @description to update a Group
	 * @param groupNameBeforeUpdate
	 * @param updateGroup
	 * @return Response Success message 
	 */
	@PUT
	@Encoded
	@Path("/updateMailTemplateMain")
	public Response updateMailTemplateMain(@FormDataParam("mailTemplates") String mailTemplates,
			@HeaderParam("token") String token){
		
		if(mailTemplates == null){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
		}
		
		String event = null;
		String mailTemplate = null;
		
		try{
			mailTemplates = URLDecoder.decode(mailTemplates, "UTF-8");
			mailTemplates = mailTemplates.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(mailTemplates.trim().isEmpty()){
			return Response.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
		}
		
		if (log.isTraceEnabled()) {
			log.trace("updateMailTemplateMain || " + mailTemplates.toString() + " Begin");
		}

		Connection conn = null;
		UserDao userDao = new UserDao();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		
		try {
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (log.isTraceEnabled()) {
				log.trace("updateMailTemplateMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			/*conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);*/
			
			if (!userName.equalsIgnoreCase("guest")) {
				User user1 = userDao.getUserIdByUserName(userName, null);
				if (user1.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			MailTemplateDao mailTemplateDao = new MailTemplateDao();
			List<MailTemplate> mailTemplateList = new ArrayList<MailTemplate>();
			MailTemplate mailTemplateDto = new MailTemplate();
			
			if(userName.equalsIgnoreCase("admin")){
				
				String jsonStr = mailTemplates;
				JSONObject jsonObject = new JSONObject(jsonStr);
				
				String mailTemp = jsonObject.get("mailTemplates").toString();
				JSONArray mailTempArray = new JSONArray(mailTemp);
				for(int i=0;i<mailTempArray.length();i++){
					List<String> mtListFromBackend = new ArrayList<String>();
					if(mailTempArray.getJSONObject(i).has("event")){
						event = mailTempArray.getJSONObject(i).getString("event").toString();
						event = event.trim();
					}
					if(mailTempArray.getJSONObject(i).has("mailTemplate")){
						mailTemplate = mailTempArray.getJSONObject(i).getString("mailTemplate").toString();
					}
					if(event == null || mailTemplate == null){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME))).build();
					}
					if(event.trim().isEmpty() || mailTemplate.trim().isEmpty()){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
					
					if(event.equalsIgnoreCase("New Asset Type Created")){
						String functionalityName = "createAssetType";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Asset Type Details Updated")){
						String functionalityName = "updateAssetType";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Asset Type Deleted")){
						String functionalityName = "deleteAssetType";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("New Asset Instance Created")){
						String functionalityName = "createAssetInstanceNonVersion";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Asset Instance Description Updated (Versionable Asset)")){
						String functionalityName = "updateAssetInstDescForVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Asset Instance Description Updated (Non-Versionable Asset)")){
						String functionalityName = "updateAssetInstDescForNonVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Relationships Updated (Versionable Asset)")){
						String functionalityName = "saveDependenciesForVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Relationships Updated (Non-Versionable Asset)")){
						String functionalityName = "saveDependenciesForNonVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Asset Instance Renamed")){
						String functionalityName = "updateAssetInstanceName";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Property Values Updated (Versionable Asset)")){
						String functionalityName = "updatePropertiesForVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Property Values Updated (Non-Versionable Asset)")){
						String functionalityName = "updatePropertiesForNonVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Taxonomy Node Deleted from Tree")){
						String functionalityName = "removeTaxonomyName";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Taxonomy Node Renamed")){
						String functionalityName = "renameTaxonomyName";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Taxonomy Assigned to Asset Instance (Versionable Asset)")){
						String functionalityName = "assignTaxNameForAssetInstanceForVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Taxonomy Unassigned from Asset Instance (Versionable Asset)")){
						String functionalityName = "unassignTaxNameForAssetInstanceForVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("User Profile Updated")){
						String functionalityName = "updateUserProfile";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("User Password Changed")){
						String functionalityName = "passwordReset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Version Edited for Asset Instance")){
						String functionalityName = "editAssetInstanceVersion";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Asset Instance Deleted (Versionable Asset)")){
						String functionalityName = "deleteAssetInstanceVersionForVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Asset Instance Deleted (Non-Versionable Asset)")){
						String functionalityName = "deleteAssetInstanceVersionForNonVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Create New Asset Instance Version")){
						String functionalityName = "createAssetInstanceVersion";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Taxonomy Assigned to Asset Instance (Non-Versionable Asset)")){
						String functionalityName = "assignTaxNameForAssetInstanceForNonVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Taxonomy Unassigned from Asset Instance (Non-Versionable Asset)")){
						String functionalityName = "unassignTaxNameForAssetInstanceForNonVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("A taxonomy child has been added")){
						String functionalityName = "addTaxonomyName";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Asset Instance has been updated (Non-Versionable Asset)")){
						String functionalityName = "updateAssetInstanceForNonVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}
					else if(event.equalsIgnoreCase("Asset Instance has been updated (Versionable Asset)")){
						String functionalityName = "updateAssetInstanceForVersionableAsset";
						MailTemplate mt = mailTemplateDao.retMailTemplateByTextName(null, functionalityName);
						Pattern pattern1 = Pattern.compile("%(.*?)%");
						Matcher matcher1 = pattern1.matcher(mt.getMailTemplate());
						while (matcher1.find()) {
						    mtListFromBackend.add(matcher1.group(1));
						}
						
						Pattern pattern = Pattern.compile("%(.*?)%");
						Matcher matcher = pattern.matcher(mailTemplate);
						while (matcher.find()) {
						    if(!mtListFromBackend.contains(matcher.group(1))){
						    	return Response.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, "Unknown macro name found")).build();
						    }
						}
						mailTemplateDto.setMailTemplateId(mt.getMailTemplateId());
						mailTemplateDto.setMailTemplate(mailTemplate);
						mailTemplateList.add(mailTemplateDto);
					}else{
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, "Invalid Event Name")).build();
					}
				}
				response = this.updateMailTemplate(mailTemplateList);
				MyModel res = (MyModel) response.getEntity();
				JSONObject json = new JSONObject();
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("updateMailTemplateMain || End");
		        return Response.status(retStat).entity(json.toString()).build();
				
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			 	return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		    }

		} catch (RepoproException e) {
			log.error("updateMailTemplateMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("updateMailTemplateMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateMailTemplateMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateMailTemplateMain ||  End");
		}
		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

}
