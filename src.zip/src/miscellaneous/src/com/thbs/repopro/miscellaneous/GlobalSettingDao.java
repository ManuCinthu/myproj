package com.thbs.repopro.miscellaneous;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class GlobalSettingDao {

	private static final Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : getGlobalSetting
	 * @description : to get GlobalSetting data
	 * @param : conn
	 * @return : List<GlobalSetting> 
	 * @throws : RepoproException
	 */

	public List<GlobalSetting> getGlobalSetting(Connection conn)
			throws RepoproException {

		log.trace("getGlobalSetting || Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		ResultSet rs1 = null;
		PreparedStatement prestmt = null;
		ResultSet resultset = null;
		GlobalSetting globalsetting = null;
		List<GlobalSetting> globalsettingdata = new ArrayList<GlobalSetting>();
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getGlobalSetting ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_GLOBAL_SETTING));

			if (log.isTraceEnabled()) {
				log.trace("getGlobalSetting ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_GLOBAL_SETTING));
			}

			rs = preparedStmt.executeQuery();

			globalsetting = new GlobalSetting();
			while (rs.next()) {
				if (rs.getString("setting_name").equalsIgnoreCase("Ldap")) {
					globalsetting.setGlobalLdapSettingFlag(rs.getInt("active_flag"));
				} else if (rs.getString("setting_name").equalsIgnoreCase("lock")) {
					globalsetting.setGlobalLockSettingFlag(rs.getInt("active_flag"));
				}else if (rs.getString("setting_name").equalsIgnoreCase("SAML")){
					globalsetting.setSsoFlag(rs.getInt("active_flag"));
				}else if(rs.getString("setting_name").equalsIgnoreCase("Circular Image")){
					globalsetting.setCircularImage(rs.getInt("active_flag"));
				}else if(rs.getString("setting_name").equalsIgnoreCase("Inverted Image")){
					globalsetting.setInvertedImage(rs.getInt("active_flag"));
				}else if(rs.getString("setting_name").equalsIgnoreCase("xss")){
					globalsetting.setCrossSiteScriptProtection(rs.getInt("active_flag"));
				}else if(rs.getString("setting_name").equalsIgnoreCase("Guest Access")){
					globalsetting.setGuestAccess(rs.getInt("active_flag"));
				}
				if (log.isTraceEnabled()) {
					log.trace(" getGlobalSetting||Ldap and lock setting flags : "
							+ globalsetting.getGlobalLdapSettingFlag()
							+ " and "
							+ globalsetting.getGlobalLockSettingFlag()
							+ " are retrieved successfully ");
				}
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_LOCK_TIME));

			if (log.isTraceEnabled()) {
				log.trace("getGlobalSetting ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_LOCK_TIME));
			}

			rs1 = pstmt.executeQuery();

			while (rs1.next()) {

				globalsetting.setLockTime(rs1.getString("lock_time"));
				if (log.isTraceEnabled()) {
					log.trace("getGlobalSetting||locktime : "
							+ globalsetting.getLockTime()
							+ " is retrieved successfully   ");
				}
			}

			prestmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_REST_API_AUTHENTICATION_MECHANISM));
			if (log.isTraceEnabled()) {
				log.trace("getGlobalSetting ||"
						+ PropertyFileReader.getInstance().getValue(Constants.GET_REST_API_AUTHENTICATION_MECHANISM));
			}
			resultset = prestmt.executeQuery();
			while(resultset.next()) {
				globalsetting.setMechanism(resultset.getString("Mechanism"));
			}
			
			globalsettingdata.add(globalsetting);

			if (log.isDebugEnabled()) {
				log.debug("getGlobalSetting ||" + globalsettingdata.toString());
			}

		} catch (SQLException e) {

			log.error("getGlobalSetting ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GLOBAL_SETTING_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getGlobalSetting ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getGlobalSetting ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getGlobalSetting ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs1);
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeResultSet(resultset);
			DBConnection.closePreparedStatement(prestmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getGlobalSetting ||"
						+ Constants.LOG_CONNECTION_CLOSE);

			}
			
		}
		log.trace("getGlobalSetting || End");

		return globalsettingdata;
	}

	/**
	 * @method : updateGlobalSetting
	 * @description : to update GlobalSetting data
	 * @param : globalsetting
	 * @param : conn
	 * @throws : RepoproException
	 */

	public void updateGlobalSetting(GlobalSetting globalsetting, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateGlobalSetting || " + globalsetting.toString()
					+ " || Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		PreparedStatement pstmt = null;
		PreparedStatement prepareStmt = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_GLOBAL_SETTING));

			preparedStmt.setInt(Constants.ONE,
					globalsetting.getGlobalLdapSettingFlag());
			preparedStmt.setString(Constants.TWO, "Ldap");

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_GLOBAL_SETTING));
			}

			preparedStmt.executeUpdate();

			preparedStmt.setInt(Constants.ONE,
					globalsetting.getGlobalLockSettingFlag());
			preparedStmt.setString(Constants.TWO, "lock");

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_GLOBAL_SETTING));
			}

			preparedStmt.executeUpdate();

			if (globalsetting.getGlobalLockSettingFlag() != 0) {

				pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.UPDATE_LOCK_TIME));
				pstmt.setString(Constants.ONE, globalsetting.getLockTime());

				if (log.isTraceEnabled()) {
					log.trace("updateLockTime ||"
							+ PropertyFileReader.getInstance().getValue(
									Constants.UPDATE_LOCK_TIME));
				}

				pstmt.executeUpdate();
			}
			
			preparedStmt.setInt(Constants.ONE, globalsetting.getSsoFlag());
			preparedStmt.setString(Constants.TWO, "SAML");

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_GLOBAL_SETTING));
			}

			preparedStmt.executeUpdate();
			
			preparedStmt.setInt(Constants.ONE, globalsetting.getCircularImage());
			preparedStmt.setString(Constants.TWO, "circular Image");

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_GLOBAL_SETTING));
			}

			preparedStmt.executeUpdate();
			
			preparedStmt.setInt(Constants.ONE, globalsetting.getInvertedImage());
			preparedStmt.setString(Constants.TWO, "inverted Image");

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_GLOBAL_SETTING));
			}

			preparedStmt.executeUpdate();
			
			preparedStmt.setInt(Constants.ONE, globalsetting.getCrossSiteScriptProtection());
			preparedStmt.setString(Constants.TWO, "xss");

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_GLOBAL_SETTING));
			}

			preparedStmt.executeUpdate();
			
			prepareStmt =  conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_REST_API_AUTHENTICATION_MECHANISM));
			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_REST_API_AUTHENTICATION_MECHANISM));
			}
			prepareStmt.setString(Constants.ONE, globalsetting.getMechanism());
			prepareStmt.executeUpdate();
			
			/*guest access*/
			preparedStmt.setInt(Constants.ONE, globalsetting.getGuestAccess());
			preparedStmt.setString(Constants.TWO, "Guest Access");

			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||" + PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_GLOBAL_SETTING));
			}

			preparedStmt.executeUpdate();
			
			
		
		} catch (SQLException e) {
			log.error("updateGlobalSetting ||"
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.UPDATE_GLOBAL_SETTING_DATA_FAILED));
		} catch (IOException e) {

			log.error("updateGlobalSetting ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {

			log.error("updateGlobalSetting ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {

			log.error("updateGlobalSetting ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closePreparedStatement(prepareStmt);
			if (log.isTraceEnabled()) {
				log.trace("updateGlobalSetting ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}

		if (log.isTraceEnabled()) {
			log.trace("updateGlobalSetting || " + globalsetting.toString()
					+ " || End");
		}

	}

	
	/**
	 * @method : retGlobalSettingByName
	 * @param settingName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public GlobalSetting retGlobalSettingByName(String settingName,
			Connection conn) throws RepoproException {

		log.trace("retGlobalSettingByName|| Begin  with settingName"
				+ settingName);

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		GlobalSetting globalsetting = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retGlobalSettingByName ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_GLOBAL_SETTING_BY_SETTING_NAME));

			if (log.isTraceEnabled()) {
				log.trace("retGlobalSettingByName ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_GLOBAL_SETTING_BY_SETTING_NAME));
			}
			
			
			preparedStmt.setString(Constants.ONE,settingName );
			rs = preparedStmt.executeQuery();
			

			
			while (rs.next()) {
				globalsetting = new GlobalSetting();
				globalsetting.setGlobalLdapSettingFlag(rs.getInt("active_flag"));
				globalsetting.setGlobalSettingId(rs.getLong("id_global_settings"));
				globalsetting.setGlobalSettingName(rs.getString("setting_name"));
				globalsetting.setGlobalSettingFlag(rs.getLong("active_flag"));
				if (log.isTraceEnabled()) {
					log.trace("retGlobalSettingByName || global setting ldap flag is :"+ globalsetting.toString());
				}
			}
		} catch (SQLException e) {

			log.error("retGlobalSettingByName ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GLOBAL_SETTING_DATA_BY_SETTING_NAME_NOT_FOUND));
		} catch (IOException e) {
			log.error("retGlobalSettingByName ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retGlobalSettingByName ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retGlobalSettingByName ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("retGlobalSettingByName ||"
						+ Constants.LOG_CONNECTION_CLOSE);

			}
			
		}
		
		log.trace("retGlobalSettingByName || End");

		return globalsetting;

	}
}
