package com.thbs.repopro.miscellaneous;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.HelpContents;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class HelpContentsDao {

	private static final Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : getHelpContents
	 * @description : to get HelpContents data
	 * @param conn
	 * @return helpcontents
	 * @throws RepoproException
	 */
	public HelpContents getHelpContents(Connection conn)
			throws RepoproException {

		log.trace("getHelpContents|| Begin");

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		HelpContents helpcontents = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getHelpContents ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_HELP_CONTENTS));

			if (log.isTraceEnabled()) {
				log.trace("getHelpContents ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_HELP_CONTENTS));
			}

			rs = preparedStmt.executeQuery();

			while (rs.next()) {
				helpcontents = new HelpContents();
				helpcontents.setId(rs.getInt("id"));
				helpcontents.setCreated_On(rs.getTimestamp("created_on"));
				helpcontents.setCreated_By(rs.getString("created_by"));
				helpcontents.setHelp_Content(rs.getString("help_content"));

				if (log.isTraceEnabled()) {
					log.trace("getHelpContents ||" + helpcontents.toString()
							+ "data is retrieved successfully");
				}

			}

		} catch (SQLException e) {

			log.error("getHelpContents ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.HELP_CONTENTS_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getHelpContents ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INSERT_ROLE_DETAILS_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getHelpContents ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getHelpContents ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getHelpContents ||" + Constants.LOG_CONNECTION_CLOSE);

			}
		}
		log.trace("getHelpContents || End");

		return helpcontents;
	}

	/**
	 * @method : addNewHelpContents
	 * @description : to add new HelpContents data
	 * @param addhelpcontents
	 * @param conn
	 * @return addhelpcontents
	 * @throws RepoproException
	 */

	public HelpContents addNewHelpContents(HelpContents addhelpcontents,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addNewHelpContents || " + addhelpcontents.toString()
					+ "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addNewHelpContents ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance()
					.getValue(Constants.INSERT_HELP_CONTENTS_DATA));
			preparedStmt.setInt(Constants.ONE, addhelpcontents.getId());
			preparedStmt.setTimestamp(Constants.TWO,
					addhelpcontents.getCreated_On());
			preparedStmt.setString(Constants.THREE,
					addhelpcontents.getCreated_By());
			preparedStmt.setString(Constants.FOUR,
					addhelpcontents.getHelp_Content());
			preparedStmt.execute();

			if (log.isTraceEnabled()) {
				log.trace("addNewHelpContents ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.INSERT_HELP_CONTENTS_DATA));

			}

		} catch (SQLException e) {
			log.error("addNewHelpContents ||"
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INSERT_HELP_CONTENTS_DETAILS_FAILED));
		} catch (IOException e) {

			log.error("addNewHelpContents ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {

			log.error("addNewHelpContents ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {

			log.error("addNewHelpContents ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addNewHelpContents ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {
			log.trace("addNewHelpContents || " + addhelpcontents.toString()
					+ "|| End");
		}

		return addhelpcontents;
	}

}
