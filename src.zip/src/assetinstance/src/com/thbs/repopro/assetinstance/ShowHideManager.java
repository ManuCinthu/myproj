package com.thbs.repopro.assetinstance;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.ShowHideColumn;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

@Path("/showHideColumn")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class ShowHideManager {
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method getShowHideColumn
	 * @description to get list of saved parameters
	 * @param assetId
	 * @param userId
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/getShowHideColumn")
	public Response getShowHideColumn(@QueryParam("assetId") Long assetId,@QueryParam("userName") String userName){
		if(log.isTraceEnabled()){
			log.trace("getShowHideColumn||assetId:"+assetId+" userName:"+userName+" || begin");
		}
		ShowHideDao showHideDao = new ShowHideDao();
		List<ShowHideColumn> showHideColumnList = new ArrayList<ShowHideColumn>();
		ShowHideColumn showHideGroup = null;
		ShowHideColumn showHideAiv = null;
		ShowHideColumn showHideParam = null;
		ShowHideColumn showHideColumn = null;
		AssetInstanceVersionDao aiv = new AssetInstanceVersionDao();
		UserDao userDao = new UserDao();
		User userdata = new User();
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		Boolean userflag = false;
		int retStatScsFlr = 0;
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumn || "+ Constants.LOG_CONNECTION_OPEN);
			}
			showHideColumn = new ShowHideColumn();
			showHideColumn.setAssetId(assetId);
			userdata = userDao.retProfileForUserName(userName, conn);
			if(userdata!=null){
			  showHideColumn.setUserId(userdata.getUserId());
			}
			showHideGroup = new ShowHideColumn();
			showHideAiv = new ShowHideColumn();
			showHideParam = new ShowHideColumn();
			Boolean adminFlag = false;
			if(!userName.equals("roleAnonymous")){
				
				if (log.isTraceEnabled()) {
					log.trace("getShowHideColumn || dao call of findAdminRightsByUserName() to get admin rights for user");
				}
				userflag = aiv.findAdminRightsByUserName(userName, conn);
				if(userflag){
					adminFlag = true;
					if (log.isTraceEnabled()) {
						log.trace("getShowHideColumn || dao call of getShowHideForAssociateGroupcolumn() to get associate group value");
					}
					showHideGroup = showHideDao.getShowHideForAssociateGroupcolumn(showHideColumn, conn);
				}
				if (log.isTraceEnabled()) {
					log.trace("getShowHideColumn || dao call of getShowHideForAivIdColumn() to get associate aiv value");
				}
				showHideAiv = showHideDao.getShowHideForAivIdColumn(showHideColumn,conn);
				
			}
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumn || call of getShowHideParamValues() to get all param details");
			}
			showHideParam = getShowHideParamValues(showHideColumn,userName,conn);
			
			showHideColumn.setShowGroupDetails(showHideGroup.getShowGroupDetails());
			showHideColumn.setShowAivDetails(showHideAiv.getShowAivDetails());
			showHideColumn.setShowParamDetails(showHideParam.getShowParamDetails());
			showHideColumn.setAdminFalg(adminFlag);
			showHideColumnList.add(showHideColumn);
			
			if (showHideColumnList.isEmpty()) {
				retMsg = Constants.GET_SHOWHIDE_COLUMN_DETAILS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retStat = Status.OK;
				retMsg = Constants.SHOWCOLUMN_DATA_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			
			
			if (log.isDebugEnabled()) {
				log.debug("getShowHideColumn || param details "
						+ showHideColumn.toString() + " retrieved successfully");
			}

		} catch (RepoproException e) {
			log.error("getShowHideColumn || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getShowHideColumn || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumn || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getShowHideColumn ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(showHideColumnList))).build();

	}
	

//=========================================================================================================================================================
	/***Wrapper function***/
	/**
	 * @method getShowHideColumnMain
	 * @description to get list of saved parameters
	 * @param assetName
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/getShowHideColumn/assetNameAndUserName")
	public Response getShowHideColumnMain(
			@QueryParam("assetName") String assetName,
			@QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("getShowHideColumnMain || assetId:" + assetName
					+ " userName:" + userName + " || begin");
		}
		ShowHideDao showHideDao = new ShowHideDao();

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;

		int retStatScsFlr = 0;
		Response response = null;
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumnMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			Long assetId = showHideDao.getAssetIdByAssetName(assetName, conn);
			if (assetId == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getShowHideColumnMain || End");
				return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}
			response = this.getShowHideColumn(assetId, userName);
			return response;

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumn || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getShowHideColumnMain ||  exit ");

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
//=========================================================================================================================================================
	
	

	public ShowHideColumn getShowHideParamValues(ShowHideColumn showHideColumn,String userName,Connection conn)throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getShowHideParamValues||showHideColumn:"+showHideColumn.toString()+" userName:"+userName+" || begin");
		}
		ShowHideColumn showHideParamList = new ShowHideColumn();
		Connection conn1 = null;
		Map<Long,String> finalshowhidelist = new LinkedHashMap<Long,String>();
		ShowHideColumn showHideParam = new ShowHideColumn();
		ShowHideDao showHideDao = new ShowHideDao();
		try {

			if (log.isTraceEnabled()) {
				log.trace("getShowHideParamValues : "+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			showHideParamList = showHideDao.getShowHideParamsDetails(userName,showHideColumn.getAssetId(), conn);

			if(userName.equalsIgnoreCase("roleAnonymous")){
				showHideParam = showHideDao.getShowHideDefaultParams(showHideColumn,userName, conn);

				for (Map.Entry<Long, String> entry : showHideParam.getShowParamDetails().entrySet()) {
					Boolean bloked = true;
					for(Map.Entry<Long, String> dataSet : showHideParamList.getShowParamDetails().entrySet()){

						if(dataSet.getKey().equals(entry.getKey())){
							bloked = false;
							break;
						}
					}
					if(!bloked)
						finalshowhidelist.put(entry.getKey(),entry.getValue());
				}
			}else{

				showHideParam = showHideDao.getShowHideParamsForShowHide(showHideColumn, userName, conn);
				if(showHideParam.getShowParamDetails().size() == 0){
					showHideParam = showHideDao.getShowHideDefaultParams(showHideColumn,userName, conn);
					for (Map.Entry<Long, String> entry : showHideParam.getShowParamDetails().entrySet()) {
						Boolean bloked = true;
						for(Map.Entry<Long, String> dataSet : showHideParamList.getShowParamDetails().entrySet()){

							if(dataSet.getKey().equals(entry.getKey())){
								bloked = false;
								break;
							}
						}
						if(!bloked)
							finalshowhidelist.put(entry.getKey(),entry.getValue());
					}

				}else{
					for (Map.Entry<Long, String> entry : showHideParam.getShowParamDetails().entrySet()) {
						Boolean bloked = true;
						for(Map.Entry<Long, String> dataSet : showHideParamList.getShowParamDetails().entrySet()){

							if(dataSet.getKey().equals(entry.getKey())){
								bloked = false;
								break;
							}
						}
						if(!bloked)
							finalshowhidelist.put(entry.getKey(),entry.getValue());
					}
				}

			}
			showHideColumn.setShowParamDetails(finalshowhidelist);
			
			if (log.isDebugEnabled()) {
				log.debug("getShowHideParamValues || param details "
						+ showHideColumn.getShowParamDetails().toString() + " retrieved successfully");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally {
			if (log.isTraceEnabled()) {
				log.trace("getShowHideParamValues : "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getShowHideParamValues || Exit");
		}		
		return showHideColumn;
	}
	
	
	/**
	 * @method getShowHideColumnList
	 * @description to get list of parameters for specific asset
	 * @param assetId
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/getShowHideColumnList")
	public Response getShowHideColumnList(@QueryParam("assetId") Long assetId,
			@QueryParam("userName") String userName){

		log.trace("getShowHideColumnList || begin");

		ShowHideDao showHideDao = new ShowHideDao();
		List<ShowHideColumn> showHideColumnList = new ArrayList<ShowHideColumn>();

		ShowHideColumn showHideParam = null;

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumnList || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			showHideParam = new ShowHideColumn();
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumnList || call of dao getShowHideParamsDetails() method to obtain list of parameters for specific assetid");
			}
			showHideParam = showHideDao.getShowHideParamsDetails(userName,assetId, conn);

			showHideColumnList.add(showHideParam);
			if (log.isDebugEnabled()) {
				log.debug("getShowHideColumnList || list of parameters of count:"
						+ showHideParam.getShowParamDetails().size()
						+ " and parameter:"
						+ showHideParam.getShowParamDetails().toString()
						+ "that are accessable for user are displayed successfully");
			}
		
			if (showHideColumnList.isEmpty()) {
				retMsg = Constants.GET_SHOWHIDE_COLUMN_DETAILS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			} else {
				retMsg = Constants.SHOWCOLUMN_DATA_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			}
		} catch (RepoproException e) {
			log.error("getShowHideColumnList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getShowHideColumnList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumnList || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getShowHideColumnList ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(showHideColumnList))).build();

	}

	
	
	
	
	
	
//====================================================================================================================================================
	/***Wrapper function***/
	/**
	 * @method getShowHideColumnListMain
	 * @description to get list of parameters for specific asset
	 * @param assetId
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/getShowHideColumnList/assetAndUser")
	public Response getShowHideColumnListMain(@QueryParam("assetName") String assetName,
			@QueryParam("userName") String userName) {

		log.trace("getShowHideColumnListMain || begin");

		ShowHideDao showHideDao = new ShowHideDao();
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumnListMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			Long assetId = showHideDao.getAssetIdByAssetName(assetName, conn);
			if (assetId == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getShowHideColumnListMain || End");
				return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}

			response = this.getShowHideColumnList(assetId, userName);
			return response;

		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getShowHideColumnListMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getShowHideColumnListMain ||  exit ");

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

	}
//====================================================================================================================================================

	
	
	
	
	
	/**
	 * @method addShowHideColumnList
	 * @description to save list of parameters
	 * @param showHideColumn
	 * @return success response
	 * @throws RepoproException
	 */
	@POST
	@Path("/addShowHideColumnList")
	public Response addShowHideColumnList(ShowHideColumn showHideColumn){

		log.trace("addShowHideColumnList || begin");

		ShowHideDao showHideDao = new ShowHideDao();

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {

			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("addShowHideColumnList || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (log.isTraceEnabled()) {
				log.trace("addShowHideColumnList || call of dao addShowHideForAssociateGroupcolumn() method to add showHideForAssociateGroupcolumn details");
			}
			showHideDao.addShowHideForAssociateGroupcolumn(showHideColumn, conn);
			
			if (log.isTraceEnabled()) {
				log.trace("addShowHideColumnList || call of dao addShowHideForAivIdColumn() method to add ShowHideForAivIdColumn details");
			}
			showHideDao.addShowHideForAivIdColumn(showHideColumn, conn);
			
			if (log.isTraceEnabled()) {
				log.trace("addShowHideColumnList || call of dao addShowHideParams() method to add list of parameters");
			}
			showHideDao.addShowHideParams(showHideColumn, conn);

			if (log.isDebugEnabled()) {
				log.debug("addShowHideColumnList || list of parameters that are accessable for user are added successfully");
			}
			conn.commit();
			retStat = Status.OK;
			retMsg = Constants.SHOWCOLUMN_DATA_ADDED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
		} catch (RepoproException e) {
			log.error("addShowHideColumnList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				log.error("addShowHideColumnList || " + Constants.LOG_EXCEPTION + e.getMessage());
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addShowHideColumnList || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("addShowHideColumnList ||  exit ");

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

	}
}
