package com.thbs.repopro.assetinstance;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.GroupAssetAccess;
import com.thbs.repopro.dto.InstanceStatus;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;
import com.thbs.repopro.util.UpdateContentException;

public class AssetInstanceDao {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );

	/**
	 * @method : getAllAssetInstances
	 * @description : to get all asset instances
	 * @param assetId
	 * @param conn
	 * @return List
	 * @throws DataNotFoundException
	 */
	public List<AssetInstance> getAllAssetInstances(Long assetId, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstances || Begin with assetId : "+ assetId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetInstance ai = null;
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstances || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCES));

			pstmt.setLong(Constants.ONE, assetId);

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstances || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_ASSET_INSTANCES));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				ai = new AssetInstance();
				ai.setAssetInstId(rs.getLong("asset_inst_id"));
				ai.setAssetId(rs.getLong("asset_id"));
				ai.setAssetInstName(rs.getString("asset_inst_name"));
				ai.setRating(rs.getInt("rating"));
				ai.setDisplayPosition(rs.getInt("disp_position"));
				ai.setOwner(rs.getString("owner"));
				ai.setPublicAccess(rs.getBoolean("public_access"));

				assetInstanceList.add(ai);

				if(log.isTraceEnabled()){
					log.trace("getAllAssetInstances || "+ ai.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllAssetInstances || "+ assetInstanceList.toString());
			}


		} catch (SQLException e) {
			log.error("getAllAssetInstances || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetInstances || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllAssetInstances || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAllAssetInstances || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstances || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstances || End");
		}
		return assetInstanceList;
	}
	
	
	/**
	 * @method : getAllAssetInstancesForSubscription
	 * @description : to get all asset instances
	 * @param assetId
	 * @param conn
	 * @return List
	 * @throws DataNotFoundException
	 */
	public List<AssetInstance> getAllAssetInstancesForSubscription(Long assetId,String userName,int from, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesForSubscription || Begin with assetId : "+ assetId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetInstance ai = null;
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean flag = false;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesForSubscription || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			flag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			
			if(flag){
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCES_FOR_SUBSCRIPTION));

				pstmt.setLong(Constants.ONE, assetId);
				pstmt.setInt(Constants.TWO, from);

				if (log.isTraceEnabled()) {
					log.trace("getAllAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_ASSET_INSTANCES_FOR_SUBSCRIPTION));
				}

				rs = pstmt.executeQuery();
			}else{
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCES_FOR_SUBSCRIPTION_FOR_NON_ADMIN));

				pstmt.setString(Constants.ONE, userName);
				pstmt.setLong(Constants.TWO, assetId);
				pstmt.setInt(Constants.THREE, from);

				if (log.isTraceEnabled()) {
					log.trace("getAllAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_ASSET_INSTANCES_FOR_SUBSCRIPTION_FOR_NON_ADMIN));
				}

				rs = pstmt.executeQuery();
				
			}
			while(rs.next()){
				ai = new AssetInstance();
				ai.setAssetInstId(rs.getLong("asset_inst_id"));
				ai.setAssetId(rs.getLong("asset_id"));
				ai.setAssetInstName(rs.getString("asset_inst_name"));
				ai.setRating(rs.getInt("rating"));
				ai.setDisplayPosition(rs.getInt("disp_position"));
				ai.setOwner(rs.getString("owner"));
				ai.setPublicAccess(rs.getBoolean("public_access"));
				ai.setIconImageName(rs.getString("icon_image_name"));

				assetInstanceList.add(ai);

				if(log.isTraceEnabled()){
					log.trace("getAllAssetInstancesForSubscription || "+ ai.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllAssetInstancesForSubscription || "+ assetInstanceList.toString());
			}


		} catch (SQLException e) {
			log.error("getAllAssetInstancesForSubscription || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetInstancesForSubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllAssetInstancesForSubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAllAssetInstancesForSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesForSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesForSubscription || End");
		}
		return assetInstanceList;
	}


	/**
	 * @method : retAssetDetail
	 * @param assetName
	 * @param conn
	 * @return
	 * @throws RepoproException 
	 */
	public AssetDef retAssetDetail(String assetName,Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("retAssetDetail || Begin with assetName : "+ assetName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetDef adf = new AssetDef();
		try {
			if (log.isTraceEnabled()) {
				log.trace("retAssetDetail || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_ASSET_BY_NAME));

			pstmt.setString(Constants.ONE, assetName);

			if (log.isTraceEnabled()) {
				log.trace("retAssetDetail || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_ASSET_BY_NAME));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				adf.setAssetId(rs.getLong("asset_id"));
				adf.setAssetName(rs.getString("asset_name"));
				adf.setDescription(rs.getString("description"));
				adf.setGuestflag(rs.getBoolean("guest_flag"));
				//adf.setIconImage(rs.getBinaryStream("icon_image"));
				adf.setIconImageName(rs.getString("icon_image_name"));
				adf.setVersionable(rs.getBoolean("versionable"));

				if(log.isTraceEnabled()){
					log.trace("retAssetDetail || "+ adf.toString());
				}
			}


		} catch (SQLException e) {
			log.error("retAssetDetail ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.ASSET_DATA_NOT_FOUND));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("retAssetDetail ||" + Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("retAssetDetail ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("retAssetDetail ||" + Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retAssetDetail || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("retAssetDetail || End");
		}
		return adf;
	}

	/**
	 * @method deleteAssetInstance
	 * @description to delete Asset Instance 
	 * @param assetInstanceId
	 * @return 
	 * @throws RepoproException
	 */

	public int deleteAssetInstance(Long assetInstanceId, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstance || Begin with assetInstanceVersionId : " + assetInstanceId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result;
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_ASSET_INSTANCE));

			pstmt.setLong(Constants.ONE, assetInstanceId);

			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_ASSET_INSTANCE));
			}

			result = pstmt.executeUpdate();

		} catch (SQLException e) {
			log.error("deleteAssetInstance || "
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.ASSET_INSTANCE_DATA_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteAssetInstance || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteAssetInstance || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteAssetInstance || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("deleteAssetInstance || assetInstanceId :" + assetInstanceId + "||End");
		}
		return result;
	}


	/**
	 * @method getAllAssetInstanceByAssetNameAndUserName
	 * @description to get Asset Instance name in aiv page
	 * @param assetName ,userName , from ,to
	 * @return
	 * @throws RepoproException
	 */

	public List<AssetInstance> getAllAssetInstanceByAssetNameAndUserName(
			String assetName, String userName, int from , Connection conn)throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstanceByAssetNameAndUserName || Begin with assetName : "+ assetName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;


		AssetInstance ai = null;
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceByAssetNameAndUserName || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (userName.equalsIgnoreCase("roleAnonymous")) {
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ALL_ASSET_INST_NAME_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getAllAssetInstanceByAssetNameAndUserName || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ALL_ASSET_INST_NAME_FOR_GUEST));
				}
				pstmt.setString(Constants.ONE, assetName);
				pstmt.setInt(Constants.TWO, from);
				

				rs = pstmt.executeQuery();

				while (rs.next()) {
					ai = new AssetInstance();
					ai.setAssetId(rs.getLong("asset_id"));
					ai.setAssetInstName(rs.getString("asset_inst_name"));
					ai.setAssetInstVersionId(rs.getLong("version_id"));
					ai.setVersionName(rs.getString("version_name"));
					assetInstanceList.add(ai);

					if (log.isTraceEnabled()) {
						log.trace("getAllAssetInstanceByAssetNameAndUserName || "
								+ ai.toString());
					}

				}
				if (log.isDebugEnabled()) {
					log.debug("getAllAssetInstanceByAssetNameAndUserName || " + assetInstanceList.toString());
				}


			} else {
				Boolean flag = false;
				AssetInstanceVersionDao aiv = new AssetInstanceVersionDao();
				flag = aiv.findAdminRightsByUserName(userName, conn);
				if(flag){
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(
									Constants.GET_ALL_ASSET_INST_NAME_FOR_ADMIN));
					if (log.isTraceEnabled()) {
						log.trace("getAllAssetInstanceByAssetNameAndUserName || "
								+ PropertyFileReader.getInstance().getValue(
										Constants.GET_ALL_ASSET_INST_NAME_FOR_ADMIN));
					}
					pstmt.setString(Constants.ONE, assetName);
					pstmt.setInt(Constants.TWO, from);
				

					rs = pstmt.executeQuery();

					while (rs.next()) {
						ai = new AssetInstance();
						ai.setAssetId(rs.getLong("asset_id"));
						ai.setAssetInstName(rs.getString("asset_inst_name"));
						ai.setAssetInstVersionId(rs.getLong("version_id"));
						ai.setVersionName(rs.getString("version_name"));
						assetInstanceList.add(ai);

						if (log.isTraceEnabled()) {
							log.trace("getAllAssetInstanceByAssetNameAndUserName || "
									+ ai.toString());
						}

					}
					if (log.isDebugEnabled()) {
						log.debug("getAllAssetInstanceByAssetNameAndUserName || " + assetInstanceList.toString());
					}
				}
				else{
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(
									Constants.GET_ALL_ASSET_INST_NAME_FOR_NON_ADMIN));
					if (log.isTraceEnabled()) {
						log.trace("getAllAssetInstanceByAssetNameAndUserName || "
								+ PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ALL_ASSET_INST_NAME_FOR_NON_ADMIN));
					}
					pstmt.setString(Constants.ONE, assetName);
					pstmt.setString(Constants.TWO, userName);
					pstmt.setInt(Constants.THREE, from);
					
					rs = pstmt.executeQuery();

					while (rs.next()) {

						ai = new AssetInstance();
						ai.setAssetId(rs.getLong("asset_id"));
						ai.setAssetInstName(rs.getString("asset_inst_name"));
						ai.setAssetInstVersionId(rs.getLong("version_id"));
						ai.setVersionName(rs.getString("version_name"));
						assetInstanceList.add(ai);

						if (log.isTraceEnabled()) {
							log.trace("getAllAssetInstanceByAssetNameAndUserName || "
									+ ai.toString());
						}
					}
				}

				if (log.isDebugEnabled()) {
					log.debug("getAllAssetInstanceByAssetNameAndUserName || " + assetInstanceList.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAllAssetInstanceByAssetNameAndUserName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetInstanceByAssetNameAndUserName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllAssetInstanceByAssetNameAndUserName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAllAssetInstanceByAssetNameAndUserName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceByAssetNameAndUserName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstanceByAssetNameAndUserName || End");
		}
		return assetInstanceList;
	}
	/**
	 * @method retAssetInstanceByTypeAndName
	 * @description Retrieve assetInstance Details
	 * @param assetName
	 * @param assetInstName
	 * @param conn
	 * @return assetInstance object
	 * @throws DataNotFoundException
	 */
	public AssetInstance retAssetInstanceByTypeAndName(String assetName,
			String assetInstName, Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("retAssetInstanceByTypeAndName ||" + assetName + " "
					+ assetInstName + "||begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetInstance assetInstance = new AssetInstance();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retAssetInstanceByTypeAndName||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader
							.getInstance()
							.getValue(
									Constants.RET_ASSET_INST_BY_ASSET_NAME_AND_INST_NAME));
			preparedStmt.setString(Constants.ONE, assetName);
			preparedStmt.setString(Constants.TWO, assetInstName);
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("retAssetInstanceByTypeAndName||"
						+ PropertyFileReader
						.getInstance()
						.getValue(
								Constants.RET_ASSET_INST_BY_ASSET_NAME_AND_INST_NAME));
			}
			while (rs.next()) {
				assetInstance = new AssetInstance();
				assetInstance.setAssetInstId(rs.getLong("asset_inst_id"));
				assetInstance.setAssetId(rs.getLong("asset_id"));
				assetInstance.setAssetInstName(rs.getString("asset_inst_name"));
				assetInstance.setRating(rs.getInt("rating"));
				assetInstance.setDisplayPosition(rs.getInt("disp_position"));
				assetInstance.setOwner(rs.getString("owner"));
				assetInstance.setPublicAccess(rs.getBoolean("public_access"));
				assetInstance.setVersionable(rs.getBoolean("versionable"));
				if (log.isTraceEnabled()) {
					log.trace("retAssetInstanceByTypeAndName ||"
							+ assetInstance.toString());
				}
			}

		}catch (SQLException e) {
			log.error("retAssetInstanceByTypeAndName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCE_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retAssetInstanceByTypeAndName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("retAssetInstanceByTypeAndName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("retAssetInstanceByTypeAndName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("retAssetInstanceByTypeAndName ||" + assetName + " "
					+ assetInstName + "||exit");
		}
		return assetInstance;
	}
	
	
	/**
	 * @method addAssetInstance
	 * @description add assetInstance details
	 * @param assetDetReq
	 * @param conn
	 * @return integer value of executeQuery
	 * @throws CreateContentException
	 * @throws DataNotFoundException
	 */
	public AssetInstance addAssetInstance(AssetInstance assetInstance,
			Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("addAssetInstance ||" + assetInstance.toString() + "|| Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
				
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addAssetInstance || " + Constants.LOG_CONNECTION_OPEN);
			}
			int displayOrder = 0;
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.INSERT_ASSET_INSTANCE));

			preparedStmt.setLong(Constants.ONE, assetInstance.getAssetId());
			preparedStmt.setString(Constants.TWO,assetInstance.getAssetInstName());
			preparedStmt.setInt(Constants.THREE, 0);
			preparedStmt.setInt(Constants.FOUR, ++displayOrder);
			preparedStmt.setString(Constants.FIVE, assetInstance.getOwner());
			preparedStmt.setBoolean(Constants.SIX, true);
			preparedStmt.execute();
			rs = preparedStmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				assetInstance.setAssetInstId(rs.getLong(1));
			}

			if (log.isTraceEnabled()) {
				log.trace("addAssetInstance ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.INSERT_ASSET_INSTANCE));
			}

		} catch (SQLException e) {
			log.error("addAssetInstance || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INSERT_ASSET_INSTANCE_DETAILS_FAILED));
		} catch (IOException e) {
			log.error("addAssetInstance || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("addAssetInstance || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("addAssetInstance || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstance ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("addAssetInstance ||" + assetInstance.toString() + "|| End");
		}
		return assetInstance;
	}
	

	/**
	 * @method updateAssetInstanceName
	 * @description update assetInstance name
	 * @param newAssetInstanceName
	 * @param assetInstance
	 * @param conn
	 * @return integer value of updateQuery
	 * @throws UpdateContentException
	 */
	public int updateAssetInstanceName(AssetInstance assetInstance,
			Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceName ||" + assetInstance.toString() + "|| Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		int val = 0;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceName ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.UPDATE_ASSET_INSTANCE_NAME));
			
			preparedStmt.setString(Constants.ONE, assetInstance.getAssetInstName());
			preparedStmt.setLong(Constants.TWO, assetInstance.getAssetInstId());
			preparedStmt.setLong(Constants.THREE, assetInstance.getAssetId());
			val = preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceNameName ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_ASSET_INSTANCE_NAME));
			}


		}  catch (SQLException e) {
			log.error("updateAssetInstanceName || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UPDATE_ASSET_INSTANCE_NAME_FAILED));
		} catch (IOException e) {
			log.error("updateAssetInstanceName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("updateAssetInstanceName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("updateAssetInstanceName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}  finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceName ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceName ||" + assetInstance.toString()
					+ "|| End");
		}

		return val;

	}

	/**
	 * @method updateAssetInstanceDescription
	 * @description update assetInstance Description
	 * @param newAssetInstanceDesc
	 * @param assetInstVersionId
	 * @param conn
	 * @return integer value of excuteQuery
	 * @throws UpdateContentException
	 */
	public int updateAssetInstanceDescription(
			AssetInstanceVersion assetInstanceVersion, Connection conn)
					throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceDescription ||"
					+ assetInstanceVersion.toString() + "|| Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		int val = 0;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescription || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.UPDATE_ASSET_INSTANCE_DESCRIPTION));
			preparedStmt.setString(Constants.ONE,
					assetInstanceVersion.getDescription());
			preparedStmt.setTimestamp(Constants.TWO,
					new Timestamp(System.currentTimeMillis()));
			preparedStmt.setLong(Constants.THREE,
					assetInstanceVersion.getAssetInstVersionId());
			val = preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescription ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_ASSET_INSTANCE_DESCRIPTION));
			}

		} catch (SQLException e) {
			log.error("updateAssetInstanceDescription || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UPDATE_ASSET_INSTANCE_DESCRIPTION_FAILED));
		} catch (IOException e) {
			log.error("updateAssetInstanceDescription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("updateAssetInstanceDescription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("updateAssetInstanceDescription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}  finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isDebugEnabled()) {
				log.debug("updateAssetInstanceDescription || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceDescription ||"
					+ assetInstanceVersion.toString() + "|| exit");
		}
		return val;
	}

	/**
	 * @method : updateAssetInstancePublicAccessState
	 * @description : to update AssetInstance object
	 * @param assetInstance object
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateAssetInstancePublicAccessState(AssetInstance assetInstance, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("updateAssetInstancePublicAccessState || Begin with assetInstance : "+ assetInstance.toString());
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstancePublicAccessState || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_ASSET_INSTANCE_PUBLIC_ACCESS));
			pstmt.setBoolean(Constants.ONE, assetInstance.isPublicAccess());
			pstmt.setLong(Constants.TWO, assetInstance.getAssetInstId());

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstancePublicAccessState || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_ASSET_INSTANCE_PUBLIC_ACCESS));
			}
			pstmt.executeUpdate();

		}catch (SQLException e) {
			log.error("updateAssetInstancePublicAccessState || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		}catch (PropertyVetoException e) {
			log.error("updateAssetInstancePublicAccessState || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("updateAssetInstancePublicAccessState || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstancePublicAccessState || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("updateAssetInstancePublicAccessState || End");
		}
	}
	
	/**
	 * @method : getAssetInstancePublicAccessState
	 * @description : to get Asset Instance public access state
	 * @param assetInstanceId
	 * @param conn
	 * @returns AssetInstance object list
	 * @throws RepoproException
	 */
	public List<AssetInstance> getAssetInstancePublicAccessState(long assetInstanceId, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAssetInstancePublicAccessState || Begin with assetInstanceid : "+ assetInstanceId);
		}
		
		ResultSet rs = null;
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		List<AssetInstance> assetInsatnceList = new ArrayList<AssetInstance>();
		AssetInstance assetInstance = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancePublicAccessState || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ASSET_INSTANCE_PUBLIC_ACCESS));
			pstmt.setLong(Constants.ONE, assetInstanceId);

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancePublicAccessState || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ASSET_INSTANCE_PUBLIC_ACCESS));
			}
			rs = pstmt.executeQuery();
			while(rs.next()){
				assetInstance = new AssetInstance();
				assetInstance.setAssetInstId(rs.getLong("asset_inst_id"));
				assetInstance.setAssetInstName(rs.getString("asset_inst_name"));
				assetInstance.setPublicAccess(rs.getBoolean("public_access"));
				assetInsatnceList.add(assetInstance);
			}
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancePublicAccessState || " + assetInsatnceList.toString());
			}
		}catch (SQLException e) {
			log.error("getAssetInstancePublicAccessState || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		}catch (PropertyVetoException e) {
			log.error("getAssetInstancePublicAccessState || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAssetInstancePublicAccessState || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancePublicAccessState || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getAssetInstancePublicAccessState || End");
		}
		return assetInsatnceList;
	}
	
	/**
	 * @method : updateAssetInstSubscription
	 * @description : to update asset instance subscription
	 * @param userId
	 * @param assetInstanceId
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateAssetInstSubscription(long userId ,long assetInstanceId, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("updateAssetInstSubscription || Begin with userId : "+ userId+", assetInstanceId : "+assetInstanceId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstSubscription || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.INSERT_INTO_USER_ASSET_INSTANCE_SUBSCRIPTION));
			pstmt.setLong(Constants.ONE, userId);
			pstmt.setLong(Constants.TWO, assetInstanceId);

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstSubscription || "+PropertyFileReader.getInstance().
						getValue(Constants.INSERT_INTO_USER_ASSET_INSTANCE_SUBSCRIPTION));
			}
			pstmt.executeUpdate();

		}catch (SQLException e) {
			log.error("updateAssetInstSubscription || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		}catch (PropertyVetoException e) {
			log.error("updateAssetInstSubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("updateAssetInstSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("updateAssetInstSubscription || End");
		}
	}
	
	/**
	 * @method : deleteAssetInstSubscription
	 * @description : to delete asset instance subscription details
	 * @param userId
	 * @param assetInstanceId
	 * @param conn
	 * @throws RepoproException
	 */
	public void deleteAssetInstSubscription(long userId ,long assetInstanceId, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("deleteAssetInstSubscription || Begin with userId : "+ userId+", assetInstanceId : "+assetInstanceId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstSubscription || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_USER_ASSET_INSTANCE_SUBSCRIPTION));
			pstmt.setLong(Constants.ONE, userId);
			pstmt.setLong(Constants.TWO, assetInstanceId);

			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstSubscription || "+PropertyFileReader.getInstance().
						getValue(Constants.DELETE_USER_ASSET_INSTANCE_SUBSCRIPTION));
			}
			int result = pstmt.executeUpdate();
			
			
		}catch (SQLException e) {
			log.error("deleteAssetInstSubscription || " + Constants.LOG_DELETE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		}catch (PropertyVetoException e) {
			log.error("deleteAssetInstSubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("deleteAssetInstSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("deleteAssetInstSubscription || End");
		}
	}
	
	/**
	 * @method : getUserAssetInstanceSubscriptionDetails
	 * @description : to get asset instance subscription details
	 * @param userId
	 * @param assetInstanceId
	 * @param conn
	 * @return List of Asset Instance
	 * @throws RepoproException
	 */
	public List<AssetInstance> getUserAssetInstanceSubscriptionDetails(long userId ,long assetInstanceId, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getUserAssetInstanceSubscriptionDetails || Begin with userId : "+ userId+", assetInstanceId : "+assetInstanceId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		ArrayList<AssetInstance> aiList = new ArrayList<AssetInstance>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getUserAssetInstanceSubscriptionDetails || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_USER_ASSET_INSTANCE_SUBSCRIPTION));
			pstmt.setLong(Constants.ONE, userId);
			pstmt.setLong(Constants.TWO, assetInstanceId);

			if (log.isTraceEnabled()) {
				log.trace("getUserAssetInstanceSubscriptionDetails || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_USER_ASSET_INSTANCE_SUBSCRIPTION));
			}
			rs = pstmt.executeQuery();
			while(rs.next()){
				AssetInstance ai = new AssetInstance();
				ai.setAssetInstId(rs.getLong("asset_inst_id"));
				aiList.add(ai);
			}
			
		}catch (SQLException e) {
			log.error("getUserAssetInstanceSubscriptionDetails || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		}catch (PropertyVetoException e) {
			log.error("getUserAssetInstanceSubscriptionDetails || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getUserAssetInstanceSubscriptionDetails || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getUserAssetInstanceSubscriptionDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getUserAssetInstanceSubscriptionDetails || End");
		}
		return aiList;
	}
	

	/**
	 * @method : getAddAccessForCompositionAndAggregationAssetType
	 * @description : to get add access for composition and aggregation asset type
	 * @param userName
	 * @param assetId
	 * @param conn
	 * @return List of GroupAssetAccess
	 * @throws RepoproException
	 */
	
	public List<GroupAssetAccess> getAddAccessForCompositionAndAggregationAssetType(
			long assetId, String userName, Connection conn)throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAddAccessForCompositionAndAggregationAssetType || Begin with assetId : "+ assetId+ "and userName"+userName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<GroupAssetAccess> groupAssetAccessList = new ArrayList<GroupAssetAccess>();
		GroupAssetAccess groupAssetAccess = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAddAccessForCompositionAndAggregationAssetType || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}


			Boolean flag = false;
			AssetInstanceVersionDao aiv = new AssetInstanceVersionDao();
			flag = aiv.findAdminRightsByUserName(userName, conn);
			if(flag){
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ADD_ACCESS_OF_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FOR_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getAddAccessForCompositionAndAggregationAssetType || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ADD_ACCESS_OF_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FOR_ADMIN));
				}
				pstmt.setLong(Constants.ONE, assetId);

				rs = pstmt.executeQuery();

				while(rs.next()){

					groupAssetAccess = new GroupAssetAccess();
					groupAssetAccess.setAssetId(rs.getLong("asset_id"));
					groupAssetAccess.setAssetName(rs.getString("asset_name"));
					groupAssetAccess.setAddAccess((long) 1);
					groupAssetAccessList.add(groupAssetAccess);

					if (log.isTraceEnabled()) {
						log.trace("getAddAccessForCompositionAndAggregationAssetType || "
								+ groupAssetAccess.toString());
					}


				}
				if (log.isDebugEnabled()) {
					log.debug("getAddAccessForCompositionAndAggregationAssetType || " + groupAssetAccessList.toString());
				}
			}
			else{
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ADD_ACCESS_OF_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FOR_NON_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getAddAccessForCompositionAndAggregationAssetType || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ADD_ACCESS_OF_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FOR_NON_ADMIN));
				}
				pstmt.setString(Constants.ONE, userName);
				pstmt.setLong(Constants.TWO, assetId);


				rs = pstmt.executeQuery();

				while (rs.next()) {
					groupAssetAccess = new GroupAssetAccess();
					groupAssetAccess.setAssetId(rs.getLong("asset_id"));
					groupAssetAccess.setAssetName(rs.getString("asset_name"));
					groupAssetAccess.setAddAccess(rs.getLong("add_access"));
					groupAssetAccess.setEditAccess(rs.getLong("edit_access"));
					groupAssetAccess.setDeleteAccess(rs.getLong("delete_access"));
					groupAssetAccess.setViewAccess(rs.getLong("view_access"));
					//groupAssetAccess.setGroupId(rs.getLong("group_id"));
					//groupAssetAccess.setGroupName(rs.getString("group_name"));

					groupAssetAccessList.add(groupAssetAccess);

					if (log.isTraceEnabled()) {
						log.trace("getAddAccessForCompositionAndAggregationAssetType || "
								+ groupAssetAccess.toString());
					}

				}
			}

			if (log.isDebugEnabled()) {
				log.debug("getAddAccessForCompositionAndAggregationAssetType || " + groupAssetAccessList.toString());
			}


		} catch (SQLException e) {
			log.error("getAddAccessForCompositionAndAggregationAssetType || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ADD_ACCESS_FOR_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAddAccessForCompositionAndAggregationAssetType || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAddAccessForCompositionAndAggregationAssetType || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAddAccessForCompositionAndAggregationAssetType || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAddAccessForCompositionAndAggregationAssetType || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getAddAccessForCompositionAndAggregationAssetType || End");
		}
		return groupAssetAccessList;
	}

	/**
	 * @method : getAssetInstanceAccessForGuest
	 * @description : to get asset and instance level guest access 
	 * @param assetId
	 * @param assetInstId
	 * @param conn
	 * @throws RepoproException
	 */
	
	public Boolean getAssetInstanceAccessForGuest(Long assetInstVerId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceAccessForGuest || Begin with assetInstVerId : "
					+ assetInstVerId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Boolean flagForGuest = false;
		Boolean accestFlag = false;
		Boolean accestinstFlag = false;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAccessForGuest || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn
					.prepareStatement(PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ASSET_INSTANCE_ACCESS_FOR_GUEST));

			pstmt.setLong(Constants.ONE, assetInstVerId);

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAccessForGuest || "
						+ PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_INSTANCE_ACCESS_FOR_GUEST));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				accestinstFlag = rs.getBoolean("public_access");
				accestFlag = rs.getBoolean("guest_flag");

				if (accestFlag == true && accestinstFlag == true) {

					flagForGuest = true;

				}

				if (log.isTraceEnabled()) {
					log.trace("getAssetInstanceAccessForGuest ||retrieve flagForGuest"+flagForGuest+ "successfully");
				}
			}
			

		} catch (SQLException e) {
			log.error("getAssetInstanceAccessForGuest || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GET_ASSET_INSTANCE_ACCESS_FOR_GUEST_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetInstanceAccessForGuest || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAssetInstanceAccessForGuest || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAssetInstanceAccessForGuest || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAccessForGuest || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceAccessForGuest || End");
		}
		return flagForGuest;
	}

	
	/**
	 * @method : getAssetInstanceAccessForLoginUser
	 * @description : to get asset instance version access 
	 * @param assetInstVersionId
	 * @param userName
	 * @param conn
	 * @throws RepoproException
	 */

	public List<GroupAssetAccess>  getAssetInstanceAccessForLoginUser(
			Long assetInstVersionId, String userName, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceAccessForLoginUser || Begin with assetInstVersionId : "
					+ assetInstVersionId + "and userName : " + userName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<GroupAssetAccess> groupAssetAccessList = new ArrayList<GroupAssetAccess>();
		GroupAssetAccess groupAssetAccess = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAccessForLoginUser || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn
					.prepareStatement(PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ASSET_INSTANCE_ACCESS_FOR_LOGIN_USER));

			pstmt.setString(Constants.ONE, userName);
			pstmt.setLong(Constants.TWO, assetInstVersionId);

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAccessForLoginUser || "
						+ PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ASSET_INSTANCE_ACCESS_FOR_LOGIN_USER));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				groupAssetAccess = new GroupAssetAccess();
				groupAssetAccess.setViewAccess(rs.getLong("view_access"));
				groupAssetAccess.setEditAccess(rs.getLong("edit_access"));
				groupAssetAccess.setDeleteAccess(rs.getLong("delete_access"));

				groupAssetAccessList.add(groupAssetAccess);
				if (log.isTraceEnabled()) {
					log.trace("getAssetInstanceAccessForLoginUser ||  data is retrieved successfully");
				}
			}
			
			if (log.isDebugEnabled()) {
				log.debug("getAssetInstanceAccessForLoginUser ||  "+groupAssetAccessList.toString());
			}
		} catch (SQLException e) {
			log.error("getAssetInstanceAccessForLoginUser || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GET_ASSET_INSTANCE_ACCESS_FOR_LOGIN_USER_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetInstanceAccessForLoginUser || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAssetInstanceAccessForLoginUser || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAssetInstanceAccessForLoginUser || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAccessForLoginUser || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceAccessForLoginUser || End");
		}
		return groupAssetAccessList;
	}

	/**
	 * @method : getAssetLevelAddAccessForLoginUser
	 * @description : to get asset level add access for logged in user
	 * @param assetName
	 * @param userName
	 * @param conn
	 * @throws RepoproException
	 */
	
	public AssetInstance getAssetLevelAddAccessForLoginUser(String assetName,
			String userName, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAssetLevelAddAccessForLoginUser || Begin with assetName : "
					+ assetName + "and userName : " + userName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AssetInstance ai = null;
		List<AssetInstance> aiList = new ArrayList<AssetInstance>();
	
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetLevelAddAccessForLoginUser || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn
					.prepareStatement(PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ASSET_LEVEL_ADD_ACCESS_FOR_LOGIN_USER));

			pstmt.setString(Constants.ONE, userName);
			pstmt.setString(Constants.TWO, assetName);

			if (log.isTraceEnabled()) {
				log.trace("getAssetLevelAddAccessForLoginUser || "
						+ PropertyFileReader
						.getInstance()
						.getValue(
								Constants.GET_ASSET_LEVEL_ADD_ACCESS_FOR_LOGIN_USER));
			}

			rs = pstmt.executeQuery();

			if (!rs.next()) {
				ai = new AssetInstance();
				ai.setAddAccessFlag(false);
			}else{
				ai = new AssetInstance();
				ai.setAddAccessFlag(rs.getBoolean("add_access"));
				aiList.add(ai);
				if (log.isTraceEnabled()) {
					log.trace("getAssetLevelAddAccessForLoginUser ||  data is retrieved successfully");
				}
			}
			if(rs.next()){
				for(AssetInstance ai1 :aiList) {
					if(ai1.getAddAccessFlag()){
						ai = new AssetInstance();
						ai.setAddAccessFlag(true);
						break;
					}
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAssetLevelAddAccessForLoginUser || AddflagForLoginUser: "+ai.getAddAccessFlag());
			}
		} catch (SQLException e) {
			log.error("getAssetInstanceAccessForLoginUser || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GET_ASSET_INSTANCE_ACCESS_FOR_LOGIN_USER_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetLevelAddAccessForLoginUser || "
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAssetLevelAddAccessForLoginUser || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("getAssetLevelAddAccessForLoginUser || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetLevelAddAccessForLoginUser || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAssetLevelAddAccessForLoginUser || End");
		}
		return ai;
	}

	/**
	 * @method : getAssetInstIdByName
	 * @param assetInstanceName
	 * @param assetId
	 * @param conn
	 * @return assetInstId
	 * @throws RepoproException
	 */
	public Long getAssetInstIdByName(String assetInstanceName, long assetId,Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAssetInstIdByName || Begin ");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
        Long assetInstId = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstIdByName || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ASSET_INST_ID_BY_NAME));
			pstmt.setString(Constants.ONE,assetInstanceName);
			pstmt.setLong(Constants.TWO, assetId);

			/*if (log.isTraceEnabled()) {
				log.trace("getAssetInstIdByName ));
			}*/
			rs = pstmt.executeQuery();
			while(rs.next()){
				assetInstId=rs.getLong("asset_inst_id");
			}
			
		}catch (SQLException e) {
			log.error("getAssetInstIdByName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		}catch (PropertyVetoException e) {
			log.error("getAssetInstIdByName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAssetInstIdByName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstIdByName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getAssetInstIdByName || End");
		}
		return assetInstId;
	}
	
	
	/**
	 * @method : getAllAssetInstancesMain
	 * @param assetId
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<String> getAllAssetInstancesMain(Long mappedAssetId,String userName,Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesMain || Begin with assetId : "+ mappedAssetId );
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<String>assetInstanceNames = new ArrayList<String>();
		Boolean flag = false;
		 AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesMain || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			flag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			
			if(flag){
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCES));
			
			pstmt.setLong(Constants.ONE, mappedAssetId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesMain || " + PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_ASSET_INSTANCES));
			}
			rs = pstmt.executeQuery();
			
			}else{
				AssetDao ad = new AssetDao();
				AssetDef asset = new AssetDef();
				asset = ad.getAssetsByAssetId(mappedAssetId, conn);
				
				pstmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ASSET_INSTANCE_FOR_NON_ADMIN_USER));
				
				pstmt.setString(Constants.ONE, userName);
				pstmt.setString(Constants.TWO, asset.getAssetName());
				
				if (log.isTraceEnabled()) {
					log.trace("getAllAssetInstancesMain || "
							+ PropertyFileReader
							.getInstance().getValue(Constants.GET_ASSET_INSTANCE_FOR_NON_ADMIN_USER));
				}
				rs = pstmt.executeQuery();
				
			}
			
			while (rs.next()) {
				
				assetInstanceNames.add(rs.getString("asset_inst_name"));
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetInstancesMain || " + assetInstanceNames.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAllAssetInstancesMain || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetInstancesMain || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllAssetInstancesMain || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAllAssetInstancesMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesMain || End");
		}
		return assetInstanceNames;
	}
	
	/**
	 * @method : getAllAssetInstances
	 * @description : to get all asset instances
	 * @param assetId
	 * @param conn
	 * @return List
	 * @throws DataNotFoundException
	 */
	public List<AssetInstanceVersion> getAllAssetInstancesWithLatestVersionsNativeQuery(String assetName, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesWithLatestVersionsNativeQuery || Begin with assetName : "+ assetName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetInstanceVersion aiv = null;
		List<AssetInstanceVersion> assetInstanceverList = new ArrayList<AssetInstanceVersion>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesWithLatestVersionsNativeQuery || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCES_WITH_LATEST_VERSIONS));

			pstmt.setString(Constants.ONE, assetName);

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesWithLatestVersionsNativeQuery || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_ASSET_INSTANCES_WITH_LATEST_VERSIONS));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				aiv = new AssetInstanceVersion();
				aiv.setAssetInstanceId(rs.getLong("asset_instance_id"));
				aiv.setVersionName(rs.getString("version_name"));
				aiv.setAssetInstVersionId(rs.getLong("asset_instance_version_id"));
				aiv.setAssetInstName(rs.getString("asset_inst_name"));

				assetInstanceverList.add(aiv);

				if(log.isTraceEnabled()){
					log.trace("getAllAssetInstancesWithLatestVersionsNativeQuery || "+ aiv.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllAssetInstancesWithLatestVersionsNativeQuery || "+ assetInstanceverList.toString());
			}


		} catch (SQLException e) {
			log.error("getAllAssetInstancesWithLatestVersionsNativeQuery || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetInstancesWithLatestVersionsNativeQuery || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllAssetInstancesWithLatestVersionsNativeQuery || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAllAssetInstancesWithLatestVersionsNativeQuery || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesWithLatestVersionsNativeQuery || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesWithLatestVersionsNativeQuery || End");
		}
		return assetInstanceverList;
	}

	public AssetInstance retAssetInstance(Long assetId,
			String assetInstName, Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("retAssetInstance ||" + assetId + " "
					+ assetId + "||begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetInstance assetInstance = new AssetInstance();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retAssetInstance||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader
							.getInstance()
							.getValue(
									Constants.RET_ASSET_INST));
			preparedStmt.setLong(Constants.ONE, assetId);
			preparedStmt.setString(Constants.TWO, assetInstName);
			rs = preparedStmt.executeQuery();
			if (log.isTraceEnabled()) {
				log.trace("retAssetInstance||"
						+ PropertyFileReader
						.getInstance()
						.getValue(
								Constants.RET_ASSET_INST));
			}
			while (rs.next()) {
				assetInstance = new AssetInstance();
				assetInstance.setAssetInstId(rs.getLong("asset_inst_id"));
				assetInstance.setAssetId(rs.getLong("asset_id"));
				assetInstance.setAssetInstName(rs.getString("asset_inst_name"));
				assetInstance.setRating(rs.getInt("rating"));
				assetInstance.setDisplayPosition(rs.getInt("disp_position"));
				assetInstance.setOwner(rs.getString("owner"));
				assetInstance.setPublicAccess(rs.getBoolean("public_access"));
				if (log.isTraceEnabled()) {
					log.trace("retAssetInstance ||"
							+ assetInstance.toString());
				}
			}

		}catch (SQLException e) {
			log.error("retAssetInstance || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCE_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retAssetInstance || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("retAssetInstance || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("retAssetInstance || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("retAssetInstance ||" + assetId + " "
					+ assetInstName + "||exit");
		}
		return assetInstance;
	}


	public void renameInstanceNameinParamValueForAssetList(
			String newAssetInstanceName, String oldAssetInstName, Long assetId,
			Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("renameInstanceNameinParamValueForAssetList || Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		int val = 0;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("renameInstanceNameinParamValueForAssetList ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.RENAME_ASSET_INSTANCE_NAME_IN_PARAM_VALUE));
			
			
			preparedStmt.setString(Constants.ONE,oldAssetInstName);
			preparedStmt.setString(Constants.TWO, newAssetInstanceName);
			preparedStmt.setString(Constants.THREE, oldAssetInstName);
			preparedStmt.setString(Constants.FOUR, oldAssetInstName);
			preparedStmt.setString(Constants.FIVE, newAssetInstanceName);
			preparedStmt.setLong(Constants.SIX, assetId);
			
			val = preparedStmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("renameInstanceNameinParamValueForAssetList ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RENAME_ASSET_INSTANCE_NAME_IN_PARAM_VALUE));
			}


		}  catch (SQLException e) {
			log.error("renameInstanceNameinParamValueForAssetList || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.RENAME_ASSET_INSTANCE_NAME_IN_PARAM_VALUE_FAILED));
		} catch (IOException e) {
			log.error("renameInstanceNameinParamValueForAssetList || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("renameInstanceNameinParamValueForAssetList || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("renameInstanceNameinParamValueForAssetList || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}  finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("renameInstanceNameinParamValueForAssetList ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("renameInstanceNameinParamValueForAssetList || End");
		}


	}


	/**
	 * @method : getAllFilteredAssetInstancesForSubscription
	 * @description : to get all filtered asset instances
	 * @param assetId
	 * @param conn
	 * @return List
	 * @throws DataNotFoundException
	 */
	public List<AssetInstance> getAllFilteredAssetInstancesForSubscription(Long assetId,String userName,Long userId,String subscriptionFlag,String searchStr , int from, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAllFilteredAssetInstancesForSubscription || Begin with assetId : "+ assetId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetInstance ai = null;
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		boolean flagForAdmin = false;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetInstancesForSubscription || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			flagForAdmin = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
			
			if(flagForAdmin){
				if(subscriptionFlag.equals("true")){
					if(!searchStr.equals("")){
						pstmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITH_SEARCH_ADMIN));

						pstmt.setString(Constants.ONE, "%"+searchStr+"%");
						pstmt.setLong(Constants.TWO, assetId);
						pstmt.setInt(Constants.THREE, from);

						if (log.isTraceEnabled()) {
							log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
									getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITH_SEARCH_ADMIN));
						}
					}else{
						pstmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITHOUT_SEARCH_ADMIN));

						pstmt.setLong(Constants.ONE, assetId);
						pstmt.setInt(Constants.TWO, from);

						if (log.isTraceEnabled()) {
							log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
									getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITHOUT_SEARCH_ADMIN));
						}
					}
				}else if(subscriptionFlag.equals("false")){
					if(!searchStr.equals("")){
						pstmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITH_SEARCH_ADMIN));

						pstmt.setString(Constants.ONE, "%"+searchStr+"%");
						pstmt.setLong(Constants.TWO, assetId);
						pstmt.setInt(Constants.THREE, from);

						if (log.isTraceEnabled()) {
							log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
									getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITH_SEARCH_ADMIN));
						}
					}else{
						pstmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH_ADMIN));

						pstmt.setLong(Constants.ONE, assetId);
						pstmt.setInt(Constants.TWO, from);

						if (log.isTraceEnabled()) {
							log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
									getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH_ADMIN));
						}
					}
				}else{
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCES_BY_SEARCH));

					pstmt.setLong(Constants.ONE, assetId);
					pstmt.setString(Constants.TWO, "%"+searchStr+"%");
					pstmt.setInt(Constants.THREE, from);

					if (log.isTraceEnabled()) {
						log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
								getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH));
					}
				}
			}else{
				if(subscriptionFlag.equals("true")){
					if(!searchStr.equals("")){
						pstmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITH_SEARCH));

						
						pstmt.setLong(Constants.ONE, userId);
						pstmt.setLong(Constants.TWO, assetId);
						pstmt.setLong(Constants.THREE, assetId);
						pstmt.setString(Constants.FOUR, "%"+searchStr+"%");
						pstmt.setLong(Constants.FIVE, userId);
						pstmt.setInt(Constants.SIX, from);

						if (log.isTraceEnabled()) {
							log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
									getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITH_SEARCH));
						}
					}else{
						pstmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITHOUT_SEARCH));

						pstmt.setLong(Constants.ONE, userId);
						pstmt.setLong(Constants.TWO, assetId);
						pstmt.setLong(Constants.THREE, assetId);
						pstmt.setLong(Constants.FOUR, userId);
						pstmt.setInt(Constants.FIVE, from);

						if (log.isTraceEnabled()) {
							log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
									getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_SUBSCRIPTION_WITHOUT_SEARCH));
						}
					}
				}else if(subscriptionFlag.equals("false")){
					if(!searchStr.equals("")){
						pstmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITH_SEARCH));

						pstmt.setLong(Constants.ONE, userId);
						pstmt.setLong(Constants.TWO, assetId);
						pstmt.setLong(Constants.THREE, assetId);
						pstmt.setString(Constants.FOUR, "%"+searchStr+"%");
						pstmt.setLong(Constants.FIVE, userId);
						pstmt.setInt(Constants.SIX, from);

						if (log.isTraceEnabled()) {
							log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
									getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITH_SEARCH));
						}
					}else{
						pstmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH));

						pstmt.setLong(Constants.ONE, userId);
						pstmt.setLong(Constants.TWO, assetId);
						pstmt.setLong(Constants.THREE, assetId);
						pstmt.setLong(Constants.FOUR, userId);
						pstmt.setInt(Constants.FIVE, from);

						if (log.isTraceEnabled()) {
							log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
									getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH));
						}
					}
				}else{
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCES_BY_SEARCH));

					pstmt.setLong(Constants.ONE, assetId);
					pstmt.setString(Constants.TWO, "%"+searchStr+"%");
					pstmt.setInt(Constants.THREE, from);

					if (log.isTraceEnabled()) {
						log.trace("getAllFilteredAssetInstancesForSubscription || "+PropertyFileReader.getInstance().
								getValue(Constants.GET_ALL_FILTERED_ASSET_INSTANCES_FOR_UNSUBSCRIPTION_WITHOUT_SEARCH));
					}
				}
			}
			

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				ai = new AssetInstance();
				ai.setAssetInstId(rs.getLong("asset_inst_id"));
				ai.setAssetId(rs.getLong("asset_id"));
				ai.setAssetInstName(rs.getString("asset_inst_name"));
				ai.setRating(rs.getInt("rating"));
				ai.setDisplayPosition(rs.getInt("disp_position"));
				ai.setOwner(rs.getString("owner"));
				ai.setPublicAccess(rs.getBoolean("public_access"));
				ai.setIconImageName(rs.getString("icon_image_name"));

				assetInstanceList.add(ai);

				if(log.isTraceEnabled()){
					log.trace("getAllFilteredAssetInstancesForSubscription || "+ ai.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllFilteredAssetInstancesForSubscription || "+ assetInstanceList.toString());
			}


		} catch (SQLException e) {
			log.error("getAllFilteredAssetInstancesForSubscription || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllFilteredAssetInstancesForSubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllFilteredAssetInstancesForSubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAllFilteredAssetInstancesForSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetInstancesForSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getAllFilteredAssetInstancesForSubscription || End");
		}
		return assetInstanceList;
	}
	
	
	public List<AssetInstance> getAllAssetInstancesForAsset(Long assetId, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesForAsset || Begin with assetId : "+ assetId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetInstance ai = null;
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesForAsset || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ASSET_INSTANCES_FOR_ASSET));

			pstmt.setLong(Constants.ONE, assetId);

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesForAsset || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_ASSET_INSTANCES_FOR_ASSET));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				ai = new AssetInstance();
				ai.setAssetInstId(rs.getLong("asset_inst_id"));
				ai.setAssetId(rs.getLong("asset_id"));
				ai.setAssetInstName(rs.getString("asset_inst_name"));
				ai.setRating(rs.getInt("rating"));
				ai.setDisplayPosition(rs.getInt("disp_position"));
				ai.setOwner(rs.getString("owner"));
				ai.setPublicAccess(rs.getBoolean("public_access"));
				ai.setAssetInstVersionId(rs.getLong("asset_instance_version_id"));

				assetInstanceList.add(ai);

				if(log.isTraceEnabled()){
					log.trace("getAllAssetInstancesForAsset || "+ ai.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllAssetInstancesForAsset || "+ assetInstanceList.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAllAssetInstancesForAsset || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetInstancesForAsset || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAllAssetInstancesForAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAllAssetInstancesForAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesForAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesForAsset || End");
		}
		return assetInstanceList;
	}
	
	
	public Long retFirstState(Map<String, InstanceStatus> jsonStructure) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("retFirstState || Begin with jsonStructure : "+jsonStructure);
		}
		
		String instanceState = "";
		Long position = null;
		
		Map<Long,String> nextState = new HashMap<Long,String>();
		
		try {
			JSONObject jsonObject = new JSONObject(jsonStructure);
			
			for(int i=0;i<jsonObject.length();i++) {
				Iterator itr = jsonObject.keys();
				if(itr.hasNext()){
					position = Long.parseLong(itr.next().toString());
				}
			}
			
		} catch (Exception e) {
			log.error("retFirstState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(Constants.NO_STATES_TO_DISPLAY);
		} finally{
			if (log.isTraceEnabled()) {
				log.trace("retFirstState || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		if(log.isTraceEnabled()){
			log.trace("retFirstState || End");
		}
		return position;		
	}
	
	
	public Long retFirstStateOnLoad(Long currentState, String jsonStructure) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("retFirstState || Begin with jsonStructure : "+jsonStructure);
		}
		
		String instanceState = "";
		Long position = null;
		
		Map<Long,String> nextState = new HashMap<Long,String>();
		
		try {
			JSONArray jsonArray = new JSONArray(jsonStructure);
			
			Iterator itr = jsonArray.getJSONObject((int) (long) currentState).keys();
			if(itr.hasNext()){
				position = Long.parseLong(itr.next().toString());
			}
			
		} catch (Exception e) {
			log.error("retFirstState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally{
			if (log.isTraceEnabled()) {
				log.trace("retFirstState || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		if(log.isTraceEnabled()){
			log.trace("retFirstState || End");
		}
		return position;		
	}
	
	
	public Map<Long, String> retrieveNextState(Long currentState, String jsonStructure, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("retrieveNextState || Begin with currentState : "+currentState +"jsonStructure : "+jsonStructure);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String instanceState = "";
		int position;
		String nextState = "";
		Map<Long,String> nextStates = new HashMap<Long,String>();
				
		try {
			if (log.isTraceEnabled()) {
				log.trace("retrieveNextState || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			JSONObject jsonObject = new JSONObject(jsonStructure);
			
			//for(int i=0;i<jsonArray.length();i++) {
				String setOfElementDetails = jsonObject.get(currentState.toString()).toString();
				JSONObject elementDetailsObject = new JSONObject(setOfElementDetails);

				//for(int j=0; j<elementDetailsArray.length(); j++){
					//JSONObject elementDetailsJsonObj = elementDetailsObject.getJSONObject(j);

					instanceState = elementDetailsObject.getString("instanceState");
					JSONArray nextStateArray = elementDetailsObject.getJSONArray("next");
					for(int jj=0;jj<nextStateArray.length();jj++) {
						String nextStateJson = jsonObject.get(Long.toString(nextStateArray.getLong(jj))).toString();
						JSONObject nextStateJsonObject = new JSONObject(nextStateJson);

						//for(int k=0;k<nextStateJsonArray.length();k++){
							//JSONObject nextStateJsonObj = nextStateJsonObject.getString("instanceState");
							nextStates.put(nextStateArray.getLong(jj), nextStateJsonObject.getString("instanceState"));
						//}
					}
				//}
			//}
			
		} catch (SQLException e) {
			log.error("retrieveNextState || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(Constants.NO_STATES_TO_DISPLAY);
		} catch (IOException e) {
			log.error("retrieveNextState || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("retrieveNextState || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("retrieveNextState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retrieveNextState || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("retrieveNextState || End");
		}
		return nextStates;
	}
	
	
	public void updateAssetInstanceState(Long aivId, Long position, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("updateAssetInstanceState || Begin with aivId : "+aivId+" position : "+position);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceState || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_INSTANCE_STATE));

			pstmt.setLong(Constants.ONE, position);			
			pstmt.setLong(Constants.TWO, aivId);
			
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceState || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_INSTANCE_STATE));
			}

			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("updateAssetInstanceState || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(Constants.ASSET_INSTANCE_VERSION_NOT_UPDATED);
		} catch (IOException e) {
			log.error("updateAssetInstanceState || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("updateAssetInstanceState || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("updateAssetInstanceState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceState || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("updateAssetInstanceState || End");
		}
	}
	
	
	public void updateAssetInstanceStateToInitialState(Long assetId, Map<String, InstanceStatus> json, 
			Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("updateAssetInstanceState || Begin with assetId : "+assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceState || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			List<AssetInstance> instancesList = getAllAssetInstancesForAsset(assetId, conn);
			Long firstState = retFirstState(json);
			for(AssetInstance ai : instancesList) {
				updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
			}
			
		} catch (SQLException e) {
			log.error("updateAssetInstanceState || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(Constants.ASSET_INSTANCE_VERSION_NOT_UPDATED);
		} catch (IOException e) {
			log.error("updateAssetInstanceState || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("updateAssetInstanceState || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("updateAssetInstanceState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceState || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("updateAssetInstanceState || End");
		}
		
	}
	
}
