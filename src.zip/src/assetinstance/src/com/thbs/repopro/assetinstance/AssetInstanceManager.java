package com.thbs.repopro.assetinstance;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thbs.repopro.accesscontrol.GroupDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionRest;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionsManager;
import com.thbs.repopro.assetinstanceversion.FavouritesDao;
import com.thbs.repopro.assetinstanceversion.RatingManager;
import com.thbs.repopro.assetinstanceversion.RevisionHistoryDao;
import com.thbs.repopro.dto.AivDetailsComposite;
import com.thbs.repopro.dto.AivRevisionHistory;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetDetailRequest;
import com.thbs.repopro.dto.AssetInstRelationship;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetInstanceVersionRating;
import com.thbs.repopro.dto.AssetInstanceVersionTaxonomy;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.AssetRelationshipDef;
import com.thbs.repopro.dto.GamificationDetails;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.GroupAssetAccess;
import com.thbs.repopro.dto.GroupAssetInstVersionAccess;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.dto.ParameterValues;
import com.thbs.repopro.dto.RecentActivity;
import com.thbs.repopro.dto.RelationshipDef;
import com.thbs.repopro.dto.TaggingMaster;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserAssetInstanceSubscription;
import com.thbs.repopro.dto.Workflow;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.gamification.GamificationDao;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.miscellaneous.GlobalSettingManager;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.plugin.AssetRepresentationDao;
import com.thbs.repopro.recentactivity.RecentActivityDao;
import com.thbs.repopro.relationship.RelationshipDao;
import com.thbs.repopro.relationship.RelationshipManager;
import com.thbs.repopro.subscription.SubscriptionDao;
import com.thbs.repopro.tagging.TaggingDao;
import com.thbs.repopro.tagging.TaggingManager;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.CustomParameterPluginUtilies;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;
import com.thbs.repopro.util.UpdateContentException;
import com.thbs.repopro.workflow.WorkflowDao;

@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Path("/assetInstance")
public class AssetInstanceManager {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );

	/**
	 * @method : getAllAssetInstances
	 * @description : to get all the asset instances
	 * @param assetId
	 * @return
	 */
	@GET
	@Path("/getallassetinstances")
	public Response getAllAssetInstances(@QueryParam("assetId") Long assetId, 
			@QueryParam("userId") Long userId,
			@QueryParam("from") int from) {

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstances || Begin with assetId : "+ assetId);
		}

		Connection conn = null;

		UserAssetInstanceSubscription uais = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		List<UserAssetInstanceSubscription> subscriptionList = new ArrayList<UserAssetInstanceSubscription>();

		try {
			if (log.isTraceEnabled()){
				log.trace("getAllAssetInstances || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetInstanceDao dao = new AssetInstanceDao();
			SubscriptionDao subDao = new SubscriptionDao();
			UserDao userDao = new UserDao();
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstances || dao method called : getUserByUserId()");
			}
			User user = userDao.getUserByUserId(userId,conn);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstances || dao method called : getAllAssetInstancesForSubscription()");
			}

			assetInstanceList = dao.getAllAssetInstancesForSubscription(assetId,user.getUserName(), from, conn);

			if(!(assetInstanceList.isEmpty())){
				for(AssetInstance ai : assetInstanceList){
					if (log.isTraceEnabled()) {
						log.trace("getAllAssetInstances || dao method called : getAllSubscriptionsByAssetInstance()");
					}
					uais = subDao.getAllSubscriptionsByAssetInstance(ai.getAssetInstId(), userId, conn);
					uais.setAssetInstanceId(ai.getAssetInstId());
					uais.setAssetInstanceName(ai.getAssetInstName());
					uais.setUserId(userId);
					uais.setIconImageName(ai.getIconImageName());
					subscriptionList.add(uais);
				}
			}
			log.debug("getAllAssetInstances || retrieved "+ assetInstanceList.size() 
					+" asset instances successfully");

			retMsg = Constants.ALL_ASSET_INSTANCES_FETCHED;
			retScsFlr = Constants.FAILURE;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;


		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} catch(Exception e){
			log.error("getAllAssetInstances || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstances || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (subscriptionList.isEmpty()) {
			retMsg = Constants.ASSET_INSTANCE_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_ASSET_INSTANCES_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstances || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(subscriptionList))).build();
	}


	/**
	 * @method getAllAssetInstanceByAssetNameAndUserName
	 * @description to get all asset instance name 
	 * @param assetId , userName ,from ,to
	 * @return success response
	 * @throws RepoproException
	 */

	@GET
	@Encoded
	@Path("/getAllAssetInstancesForAivPage")
	public Response getAllAssetInstanceByAssetNameAndUserName(@QueryParam("assetName") String assetName, 
			@QueryParam("userName") String userName ,@QueryParam("from") int from)
					{

		if (log.isTraceEnabled()) {
			log.trace("getAllAssetInstanceByAssetNameAndUserName || begin  with assetName : "
					+ assetName+" userName : "+ userName +" from : "+ from );
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		Connection conn = null;
		List<AssetInstance> assetInstList = new ArrayList<AssetInstance>();

		try {
			
			assetName = URLDecoder.decode(assetName, "UTF-8");
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceByAssetNameAndUserName || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceByAssetNameAndUserName || dao method called : getAllAssetInstanceByAssetNameAndUserName by assetName: "
						+ assetName+"and userName"+userName);
			}

			assetInstList = assetInstanceDao.getAllAssetInstanceByAssetNameAndUserName(assetName ,userName ,from  , conn);

			conn.commit();
			if (log.isDebugEnabled()) {
				log.debug(" getAllAssetInstanceByAssetNameAndUserName  || retrieved "+ assetInstList.size()+ " asset instances successfully ");
			}

			if (assetInstList .isEmpty()){
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCES_NOT_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			}else{
				retStat = Status.OK;
				retMsg = Constants.ALL_ASSET_INSTANCES_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		}

		catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}

		catch (Exception e) {
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceByAssetNameAndUserName || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAllAssetInstanceByAssetNameAndUserName || End ");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetInstList)))
						.build();

	}
	/**
	 * @method addAssetInstance
	 * @description add assetInstance details
	 * @param assetInstance
	 * @return Response Success message
	 * @throws RepoproException
	 *//*
	@POST
	@Encoded
	@Path("/addAssetInstance")
	public Response addAssetInstance(AssetInstance assetInstance,
			@QueryParam("userName") String userName,@QueryParam("flagForChild") boolean flagForChild){
		if (assetInstance == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_REQUEST))).build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstance ||" + assetInstance.toString()+ " username : "+ userName + "|| Begin");
			}
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			List<String> jsonList = new ArrayList<String>();
			String jsonRslt;
			String versionName = assetInstance.getVersionName();
			GamificationDao gamificationDao = new GamificationDao();
			GroupDao groupDao = new GroupDao();
			AssetDao assetDao = new AssetDao();
			UserDao userDao = new UserDao();
			User user = new User();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			SubscriptionDao subscriptionDao = new SubscriptionDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			List<AssetInstance> assetInstancelist = new ArrayList<AssetInstance>();
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			RecentActivity recentActivity = new RecentActivity();
			String action = Constants.ACTIVITY_CREATE;
			String appendingMsg = "";
		
			try {
				String assetInstName = URLDecoder.decode(assetInstance.getAssetInstName(), "UTF-8");
				assetInstance.setAssetInstName(assetInstName);
				if(assetInstance.getParentAssetInstName()!= null){
					String parentInstName = URLDecoder.decode(assetInstance.getParentAssetInstName(), "UTF-8");
					assetInstance.setParentAssetInstName(parentInstName);
				}
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance : "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				AssetInstance assetInstanceData = null;

				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance: call dao getUserByUserId() method");
				}
				user = userDao.retProfileForUserName(userName, conn);

				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance: call dao getAssetsByAssetId() method");
				}
				AssetDef asset = assetDao.getAssetsByAssetId(assetInstance.getAssetId(), conn);
				if(asset == null){
					jsonRslt = Constants.ASSET_DATA_NOT_FOUND;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(Constants.GET_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.ASSET_DATA_NOT_FOUND),
									new ArrayList<Object>(jsonList))).build();
				}
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance : call dao retAssetInstanceByTypeAndName()  method");
				}
				assetInstanceData = assetInstanceDao.retAssetInstanceByTypeAndName(asset.getAssetName(),assetInstance.getAssetInstName(), conn);

				if (assetInstanceData.getAssetInstId() == null) {
					assetInstance.setAssetId(asset.getAssetId());
					assetInstance.setAssetInstName(assetInstance.getAssetInstName());
					assetInstance.setOwner(userName);
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstance : call dao addAssetInstance() method");
					}
					assetInstanceData = assetInstanceDao.addAssetInstance(assetInstance, conn);
				}else{
					if(assetInstanceData !=null){

						jsonRslt = Constants.ASSET_INSTANCE_ALREADY_EXIST;
						jsonList.add(jsonRslt);
						return Response
								.status(Status.OK)
								.entity(new MyModel(Constants.GET_STATUS_SUCCESS,
										Constants.FAILURE,
										MessageUtil
										.getMessage(Constants.ASSET_INSTANCE_ALREADY_EXIST),
										new ArrayList<Object>(jsonList))).build();

					}

				}

				AssetInstanceVersion aiv = new AssetInstanceVersion();
				if (assetInstanceData.getAssetInstId() != null) {
					aiv.setVersionName(versionName);
					aiv.setVersionNotes(Constants.DEFAULT_VERSION_NOTES);
					aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					if(flagForChild){
						aiv.setDescription(" This is a default overview created by system");
					}else{
						aiv.setDescription(assetInstance.getDescription());
					}
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstance : call dao addAssetInstanceVersion() method for adding asset instance version details");
					}
					assetInstanceVersionDao.addAssetInstanceVersions(aiv, assetInstanceData.getAssetInstId(), aiv.getDescription(), conn);
				}

				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance : call dao getAssetInstanceVersion() method for fetching asset instance version details:");
				}
				AssetInstanceVersion aivForAddingNewRevision = assetInstanceVersionDao
						.getAssetInstanceVersion(assetInstanceData.getAssetInstId(),assetInstance.getVersionName(), conn);

				RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
				RelationshipDao relationshipDao = new RelationshipDao();
				AivRevisionHistory aivRevHist = null;
				List<AssetRelationshipDef> assetRelationshipDefList = new ArrayList<AssetRelationshipDef>();
				
				if(assetInstance.getParentAssetId() != null){
				assetRelationshipDefList = relationshipDao.getAvailbleAssetRelationships(assetInstance.getParentAssetId(),assetInstance.getAssetId(), conn);
				}
				if(aivForAddingNewRevision != null){

					if(flagForChild == true){

						String usedByData ="",relationshipName = "";
						for(AssetRelationshipDef assetRelationshipDefVo : assetRelationshipDefList){
							if((assetRelationshipDefVo.getFwdRelId() == 1)
									|| (assetRelationshipDefVo.getFwdRelId() == 5)){

								relationshipName = assetRelationshipDefVo.getDescription();
							}
						}
						if(!asset.isVersionable()){
							usedByData = assetInstance.getParentAssetInstName()+"("+relationshipName+")";
						}else{
							usedByData = assetInstance.getParentAssetInstName()+"_"+assetInstance.getParentVersionName()+"("+relationshipName+")";
						}	
						aivRevHist = new AivRevisionHistory();
						aivRevHist.setAivId(aivForAddingNewRevision.getAssetInstVersionId());
						aivRevHist.setRevId(aivForAddingNewRevision.getVersionName()+".0");
						aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						aivRevHist.setChangedKey("N");
						aivRevHist.setOverviewData(aivForAddingNewRevision.getDescription());
						aivRevHist.setRelationshipData(null);
						aivRevHist.setParameterData(null);
						aivRevHist.setUserId(user.getUserId());
						aivRevHist.setUsedBy(usedByData);	
						if (log.isTraceEnabled()) {
							log.trace("addAssetInstance : call dao addRevisionData() method for adding revision data");
						}
						revisionHistoryDao.addRevisionData(aivRevHist, conn);
					}else{

						aivRevHist = new AivRevisionHistory();
						aivRevHist.setAivId(aivForAddingNewRevision.getAssetInstVersionId());
						aivRevHist.setRevId(aivForAddingNewRevision.getVersionName()+".0");
						aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						aivRevHist.setChangedKey("N");
						aivRevHist.setOverviewData(aivForAddingNewRevision.getDescription());
						aivRevHist.setRelationshipData(null);
						aivRevHist.setParameterData(null);
						aivRevHist.setUserId(user.getUserId());
						aivRevHist.setUsedBy(null);
						if (log.isTraceEnabled()) {
							log.trace("addAssetInstance : call dao addRevisionData() method for adding revision data");
						}
						revisionHistoryDao.addRevisionData(aivRevHist, conn);
					}
				}
				if(assetInstance.getParentAssetId() != null){

					aiv.setVersionName(assetInstance.getParentVersionName());
					aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));

					if (log.isTraceEnabled()) {
						log.trace("addAssetInstance || called dao method : updateAivUpdatedOn() by AssetInstanceVersionId: "
								+ assetInstance.getParentAssetInstVersionId());
					}
					assetInstanceVersionDao.updateAivUpdatedOn(aiv,
							assetInstance.getParentAssetInstVersionId(), conn);

					AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
					AssetInstRelationship assetInstRelationship = new AssetInstRelationship();

					assetInstRelationship.setDestAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId());
					assetInstRelationship.setSrcAssetInstVersionId(assetInstance.getParentAssetInstVersionId());

					for(AssetRelationshipDef assetRelationshipData:assetRelationshipDefList){

						assetInstRelationship.setAssetRelId(assetRelationshipData.getAssetRelId());
						if (log.isTraceEnabled()) {
							log.trace("addAssetInstance ||call method addAssetInstRelationship() to add asset instance relationship data");
						}
						relationshipDao.addAssetInstRelationship(assetInstRelationship, conn);

					}

					AssetInstanceVersion aivRel = new AssetInstanceVersion();
					aivRel.setSrcAssetInstanceVersionId(assetInstance.getParentAssetInstVersionId().toString());
					List<AssetInstance> aivos = retFwdDependents(aivRel,conn);

					String newRelationshipDataForRevision ="";
					int i = 1;
					for(AssetInstance aivo : aivos){
						AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
						if(i == aivos.size()){
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"["+aivo.getAssetRelationshipName()+"]";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+"["+aivo.getAssetRelationshipName()+"]";	
							}	
						}else{
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+"["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
							}
						}
						i++;
					}

					if (log.isTraceEnabled()) {
						log.trace("addAssetInstance ||call method addRevisionData() to add revision data");
					}
					assetInstanceVersionsManager.addRevisionData("R",Long.parseLong(aivRel.getSrcAssetInstanceVersionId()),assetInstance.getParentVersionName(),null, 
							newRelationshipDataForRevision, null, null,userName,user.getUserId(),conn);

				}


				if (!userName.equals("admin") && user.getActiveFlag().equalsIgnoreCase("1")) {

					GamificationDetails gamePoint = new GamificationDetails();

					gamePoint.setPoints("5");
					gamePoint.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
					gamePoint.setField("Asset Instance");
					gamePoint.setAction("Created");
					gamePoint.setUserId(user.getUserId());
					gamePoint.setAssetId(asset.getAssetId().toString());
					gamePoint.setAssetInstanceVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
					if (asset.isVersionable() == true) {
						gamePoint.setInstanceDetails(asset.getAssetName()+ "~" + assetInstance.getAssetInstName() + "~"+ versionName);
					} else {
						gamePoint.setInstanceDetails(asset.getAssetName()+ "~" + assetInstance.getAssetInstName()+ "~N/A");
					}
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstance : call dao addGamificationPoint() method for adding gamification point details");
					}
					gamificationDao.addGamificationPoint(gamePoint, conn);

				}

				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance : call dao retassetgroupsAccess() method for fetching assetGroupAccess details:");
				}
				List<GroupAssetAccess> groupAssetAccessList = groupDao.retassetgroupsAccess(asset.getAssetId(), conn);
				GroupAssetAccess groupAssetInstAccess = null;

				for (GroupAssetAccess ga : groupAssetAccessList) {
					groupAssetInstAccess = new GroupAssetAccess();
					groupAssetInstAccess.setAssetInstversionId(aivForAddingNewRevision.getAssetInstVersionId());
					groupAssetInstAccess.setEditAccess(ga.getEditAccess());
					groupAssetInstAccess.setViewAccess(ga.getViewAccess());
					groupAssetInstAccess.setDeleteAccess(ga.getDeleteAccess());
					groupAssetInstAccess.setGroupId(ga.getGroupId());
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstance : call dao addGroupsAccessAISubmit() method for adding groupAccess details");
					}
					groupDao.addGroupsAccessAISubmit(groupAssetInstAccess, conn);

				}

				MailTemplateDao mailTemplateDao = new MailTemplateDao();

				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstance : call dao getMailConfig() method ");
				}
				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				String mailTemp = null;
				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstance : call dao getAllSubscriptionsByAssetInstanceId() method ");
				}
				List<String> emailIds=subscriptionDao.getSubscribersForAsset(asset.getAssetId(), conn);
				if(asset.isVersionable()){
					if (log.isTraceEnabled()) {
						log.trace("addNewAssetInstance : call dao retMailTemplateByTextName() method ");
					}
					MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
					mailTemp = mtVo1.getMailTemplate();
					String instName = assetInstance.getAssetInstName();
					instName = instName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstance.getVersionName());
				}
				else {
					if (log.isTraceEnabled()) {
						log.trace("addNewAssetInstance : call dao retMailTemplateByTextName() method ");
					}
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstance.getAssetInstName();
					instName = instName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%",instName);
					mailTemp = mailTemp.replaceAll("%assetType%",asset.getAssetName()).replaceAll("%assetInstName%", instName);

				}
				if(emailIds!=null){
					for(String emailId:emailIds){
						if(asset.isVersionable()) {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
						else {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
					}
				}

				if (asset.isVersionable() == true) {
					String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ " Version " + assetInstance.getVersionName();
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(log);
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
					recentActivity.setUser_id(user.getUserId());
				} else {
					String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ appendingMsg;
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(log);
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
					recentActivity.setUser_id(user.getUserId());
				}
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance : call dao addRecentActivity() method to add recent activity details");
				}
				recentActivityDao.addRecentActivity(recentActivity, conn);


				assetInstance.setAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId());
				assetInstance.setAssetInstId(assetInstanceData.getAssetInstId());
				assetInstance.setAssetInstName(assetInstanceData.getAssetInstName());
				assetInstancelist.add(assetInstance);
				conn.commit();

				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_DATA_INSERTED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				if (log.isInfoEnabled()) {
					log.info("addAssetInstance:asset_instance Related details inserted successfully");
				}

				
			}
			catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			}
			catch (Exception e) {
				log.error("addAssetInstance: SQL Exception addAssetInstance: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
				
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("addAssetInstance" + assetInstance.toString() + " exit");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(assetInstancelist))).build();

		}
	}
*/
	/**
	 * @method addAssetInstance
	 * @description add assetInstance details
	 * @param assetInstance
	 * @return Response Success message
	 * @throws RepoproException
	 */
	@POST
	@Encoded
	@Path("/addAssetInstance")
	public Response addAssetInstance(AssetInstance assetInstance,
			@QueryParam("userName") String userName,@QueryParam("flagForChild") boolean flagForChild){
		if (assetInstance == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_REQUEST))).build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstance ||" + assetInstance.toString()+ " username : "+ userName + "|| Begin");
			}
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			
			List<AssetInstance> assetInstancelist = new ArrayList<AssetInstance>();
			
			try {
				String assetInstName = URLDecoder.decode(assetInstance.getAssetInstName(), "UTF-8");
				assetInstName = assetInstName.trim();
				assetInstance.setAssetInstName(assetInstName);
				if(assetInstance.getParentAssetInstName()!= null){
					String parentInstName = URLDecoder.decode(assetInstance.getParentAssetInstName(), "UTF-8");
					parentInstName = parentInstName.trim();
					assetInstance.setParentAssetInstName(parentInstName);
				}
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance : "+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				
				Response response = addAssetInstanceHelper(assetInstance, userName, flagForChild,false,true,conn);
				return response;
				
			}
			catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
			}
			catch (Exception e) {
				log.error("addAssetInstance: SQL Exception addAssetInstance: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstance : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				if(conn != null){
					DBConnection.closeDbConnection(conn);
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("addAssetInstance" + assetInstance.toString() + " exit");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(assetInstancelist))).build();

		}
	}
	
	public Response addAssetInstanceHelper(AssetInstance assetInstance,String userName,boolean flagForChild,boolean importFlag,boolean ChildRevFlag,Connection conn)throws RepoproException{
		
		if (assetInstance == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_REQUEST))).build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceHelper ||" + assetInstance.toString()+ " username : "+ userName + "|| Begin");
			}
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn1 = null;
			List<String> jsonList = new ArrayList<String>();
			String jsonRslt;
			String versionName = assetInstance.getVersionName();
			GamificationDao gamificationDao = new GamificationDao();
			GroupDao groupDao = new GroupDao();
			AssetDao assetDao = new AssetDao();
			UserDao userDao = new UserDao();
			User user = new User();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			SubscriptionDao subscriptionDao = new SubscriptionDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			List<AssetInstance> assetInstancelist = new ArrayList<AssetInstance>();
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			RecentActivity recentActivity = new RecentActivity();
			String action = Constants.ACTIVITY_CREATE;
			String appendingMsg = "";
		
			try {
				/*String assetInstName = URLDecoder.decode(assetInstance.getAssetInstName(), "UTF-8");
				assetInstance.setAssetInstName(assetInstName);
				if(assetInstance.getParentAssetInstName()!= null){
					String parentInstName = URLDecoder.decode(assetInstance.getParentAssetInstName(), "UTF-8");
					assetInstance.setParentAssetInstName(parentInstName);
				}*/
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceHelper : "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				if(conn == null){
					conn1 = DBConnection.getInstance().getConnection();
					conn = conn1;
				}
				conn.setAutoCommit(false);
				AssetInstance assetInstanceData = null;

				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceHelper: call dao getUserByUserId() method");
				}
				user = userDao.retProfileForUserName(userName, conn);

				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceHelper: call dao getAssetsByAssetId() method");
				}
				AssetDef asset = assetDao.getAssetsByAssetId(assetInstance.getAssetId(), conn);
				if(asset == null){
					jsonRslt = Constants.ASSET_DATA_NOT_FOUND;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(Constants.GET_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.ASSET_DATA_NOT_FOUND),
									new ArrayList<Object>(jsonList))).build();
				}
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceHelper : call dao retAssetInstanceByTypeAndName()  method");
				}
				assetInstanceData = assetInstanceDao.retAssetInstanceByTypeAndName(asset.getAssetName(),assetInstance.getAssetInstName(), conn);

				if (assetInstanceData.getAssetInstId() == null) {
					assetInstance.setAssetId(asset.getAssetId());
					assetInstance.setAssetInstName(assetInstance.getAssetInstName());
					assetInstance.setOwner(userName);
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper : call dao addAssetInstance() method");
					}
					assetInstanceData = assetInstanceDao.addAssetInstance(assetInstance, conn);
				}else{
					if(assetInstanceData !=null){

						jsonRslt = Constants.ASSET_INSTANCE_ALREADY_EXIST;
						jsonList.add(jsonRslt);
						return Response
								.status(Status.OK)
								.entity(new MyModel(Constants.GET_STATUS_SUCCESS,
										Constants.FAILURE,
										MessageUtil
										.getMessage(Constants.ASSET_INSTANCE_ALREADY_EXIST),
										new ArrayList<Object>(jsonList))).build();

					}

				}

				AssetInstanceVersion aiv = new AssetInstanceVersion();
				if (assetInstanceData.getAssetInstId() != null) {
					aiv.setVersionName(versionName);
					aiv.setVersionNotes(Constants.DEFAULT_VERSION_NOTES);
					aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					if(flagForChild){
						if(assetInstance.getDescription() != null){
							aiv.setDescription(assetInstance.getDescription());
						}else{
							aiv.setDescription(" This is a default overview created by system");
						}
					}else{
						aiv.setDescription(assetInstance.getDescription());
					}
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper : call dao addAssetInstanceVersion() method for adding asset instance version details");
					}
					assetInstanceVersionDao.addAssetInstanceVersions(aiv, assetInstanceData.getAssetInstId(), aiv.getDescription(), conn);
				}

				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceHelper : call dao getAssetInstanceVersion() method for fetching asset instance version details:");
				}
				AssetInstanceVersion aivForAddingNewRevision = assetInstanceVersionDao
						.getAssetInstanceVersion(assetInstanceData.getAssetInstId(),assetInstance.getVersionName(), conn);

				RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
				RelationshipDao relationshipDao = new RelationshipDao();
				AivRevisionHistory aivRevHist = null;
				List<AssetRelationshipDef> assetRelationshipDefList = new ArrayList<AssetRelationshipDef>();

				if(assetInstance.getParentAssetId() != null){
					assetRelationshipDefList = relationshipDao.getAvailbleAssetRelationships(assetInstance.getParentAssetId(),assetInstance.getAssetId(), conn);
				}
				
				if(aivForAddingNewRevision != null){

					if(flagForChild == true){
						if(ChildRevFlag == true){
							String usedByData ="",relationshipName = "";
							for(AssetRelationshipDef assetRelationshipDefVo : assetRelationshipDefList){
								if((assetRelationshipDefVo.getFwdRelId() == 1)
										|| (assetRelationshipDefVo.getFwdRelId() == 5)){

									relationshipName = assetRelationshipDefVo.getDescription();
								}
							}
							if(!asset.isVersionable()){
								usedByData = assetInstance.getParentAssetInstName()+"("+relationshipName+")";
							}else{
								usedByData = assetInstance.getParentAssetInstName()+"_"+assetInstance.getParentVersionName()+"("+relationshipName+")";
							}	
							aivRevHist = new AivRevisionHistory();
							aivRevHist.setAivId(aivForAddingNewRevision.getAssetInstVersionId());
							aivRevHist.setRevId(aivForAddingNewRevision.getVersionName()+".0");
							aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							aivRevHist.setChangedKey("N");
							aivRevHist.setOverviewData(aivForAddingNewRevision.getDescription());
							aivRevHist.setRelationshipData(null);
							aivRevHist.setParameterData(null);
							aivRevHist.setUserId(user.getUserId());
							aivRevHist.setUsedBy(usedByData);	
							if (log.isTraceEnabled()) {
								log.trace("addAssetInstanceHelper : call dao addRevisionData() method for adding revision data");
							}
							revisionHistoryDao.addRevisionData(aivRevHist, conn);
						}
					}else{
						if(importFlag == false){
							aivRevHist = new AivRevisionHistory();
							aivRevHist.setAivId(aivForAddingNewRevision.getAssetInstVersionId());
							aivRevHist.setRevId(aivForAddingNewRevision.getVersionName()+".0");
							aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							aivRevHist.setChangedKey("N");
							aivRevHist.setOverviewData(aivForAddingNewRevision.getDescription());
							aivRevHist.setRelationshipData(null);
							aivRevHist.setParameterData(null);
							aivRevHist.setUserId(user.getUserId());
							aivRevHist.setUsedBy(null);
							if (log.isTraceEnabled()) {
								log.trace("addAssetInstanceHelper : call dao addRevisionData() method for adding revision data");
							}
							revisionHistoryDao.addRevisionData(aivRevHist, conn);
						}
					}
				}
				if(assetInstance.getParentAssetId() != null){

					aiv.setVersionName(assetInstance.getParentVersionName());
					aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));

					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper || called dao method : updateAivUpdatedOn() by AssetInstanceVersionId: "
								+ assetInstance.getParentAssetInstVersionId());
					}
					assetInstanceVersionDao.updateAivUpdatedOn(aiv,
							assetInstance.getParentAssetInstVersionId(), conn);

					AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
					AssetInstRelationship assetInstRelationship = new AssetInstRelationship();

					assetInstRelationship.setDestAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId());
					assetInstRelationship.setSrcAssetInstVersionId(assetInstance.getParentAssetInstVersionId());

					for(AssetRelationshipDef assetRelationshipData:assetRelationshipDefList){

						assetInstRelationship.setAssetRelId(assetRelationshipData.getAssetRelId());
						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceHelper ||call method addAssetInstRelationship() to add asset instance relationship data");
						}
						relationshipDao.addAssetInstRelationship(assetInstRelationship, conn);

					}
					if(importFlag == false){
						AssetInstanceVersion aivRel = new AssetInstanceVersion();
						aivRel.setSrcAssetInstanceVersionId(assetInstance.getParentAssetInstVersionId().toString());
						List<AssetInstance> aivos = retFwdDependents(aivRel,conn);

						String newRelationshipDataForRevision ="";
						int i = 1;
						for(AssetInstance aivo : aivos){
							AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
							if(i == aivos.size()){
								if(!assetDef.isVersionable()){
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"["+aivo.getAssetRelationshipName()+"]";	
								}else{
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+"["+aivo.getAssetRelationshipName()+"]";	
								}	
							}else{
								if(!assetDef.isVersionable()){
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
								}else{
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+"["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
								}
							}
							i++;
						}

						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceHelper ||call method addRevisionData() to add revision data");
						}
						assetInstanceVersionsManager.addRevisionData("R",Long.parseLong(aivRel.getSrcAssetInstanceVersionId()),assetInstance.getParentVersionName(),null, 
								newRelationshipDataForRevision, null, null,userName,user.getUserId(),null,conn);
					}
					if(ChildRevFlag == false){

						AssetInstanceVersion aivRel = new AssetInstanceVersion();
						aivRel.setSrcAssetInstanceVersionId(assetInstance.getParentAssetInstVersionId().toString());
						List<AssetInstance> aivos = retFwdDependents(aivRel,conn);

						String newRelationshipDataForRevision ="";
						int i = 1;
						for(AssetInstance aivo : aivos){
							AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
							if(i == aivos.size()){
								if(!assetDef.isVersionable()){
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"["+aivo.getAssetRelationshipName()+"]";	
								}else{
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+"["+aivo.getAssetRelationshipName()+"]";	
								}	
							}else{
								if(!assetDef.isVersionable()){
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
								}else{
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+"["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
								}
							}
							i++;
						}

						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceHelper ||call method addRevisionData() to add revision data");
						}
						assetInstanceVersionsManager.addRevisionData("R",Long.parseLong(aivRel.getSrcAssetInstanceVersionId()),assetInstance.getParentVersionName(),null, 
								newRelationshipDataForRevision, null, null,userName,user.getUserId(),null,conn);
					
					}
				}


				if (!userName.equals("admin") && user.getActiveFlag().equalsIgnoreCase("1")) {

					GamificationDetails gamePoint = new GamificationDetails();

					gamePoint.setPoints("5");
					gamePoint.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
					gamePoint.setField("Asset Instance");
					gamePoint.setAction("Created");
					gamePoint.setUserId(user.getUserId());
					gamePoint.setAssetId(asset.getAssetId().toString());
					gamePoint.setAssetInstanceVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
					if (asset.isVersionable() == true) {
						gamePoint.setInstanceDetails(asset.getAssetName()+ "~" + assetInstance.getAssetInstName() + "~"+ versionName);
					} else {
						gamePoint.setInstanceDetails(asset.getAssetName()+ "~" + assetInstance.getAssetInstName()+ "~N/A");
					}
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper : call dao addGamificationPoint() method for adding gamification point details");
					}
					gamificationDao.addGamificationPoint(gamePoint, conn);

				}
				// description gamification point 
				//if(importFlag == true){
				if(!userName.equals("admin") && user.getActiveFlag().equalsIgnoreCase("1")){
					GamificationDetails gamePoint1 = new GamificationDetails();
					gamePoint1.setPoints("1");
					gamePoint1.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
					gamePoint1.setField("Overview");
					gamePoint1.setAction("Created");
					gamePoint1.setUserId(user.getUserId());
					gamePoint1.setAssetId(asset.getAssetId().toString());
					gamePoint1.setAssetInstanceVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
					if(asset.isVersionable() == true){
						gamePoint1.setInstanceDetails(assetInstance.getAssetName()+"~"+assetInstance.getAssetInstName()+"~"+assetInstance.getVersionName());
					}else{
						gamePoint1.setInstanceDetails(assetInstance.getAssetName()+"~"+assetInstance.getAssetInstName()+"~N/A");	
					}
					gamificationDao.addGamificationPoint(gamePoint1,conn);
				}
				//}

				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceHelper : call dao retassetgroupsAccess() method for fetching assetGroupAccess details:");
				}
				List<GroupAssetAccess> groupAssetAccessList = groupDao.retassetgroupsAccess(asset.getAssetId(), conn);
				GroupAssetAccess groupAssetInstAccess = null;

				for (GroupAssetAccess ga : groupAssetAccessList) {
					groupAssetInstAccess = new GroupAssetAccess();
					groupAssetInstAccess.setAssetInstversionId(aivForAddingNewRevision.getAssetInstVersionId());
					groupAssetInstAccess.setEditAccess(ga.getEditAccess());
					groupAssetInstAccess.setViewAccess(ga.getViewAccess());
					groupAssetInstAccess.setDeleteAccess(ga.getDeleteAccess());
					groupAssetInstAccess.setGroupId(ga.getGroupId());
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper : call dao addGroupsAccessAISubmit() method for adding groupAccess details");
					}
					groupDao.addGroupsAccessAISubmit(groupAssetInstAccess, conn);

				}
				if(importFlag == false){
					MailTemplateDao mailTemplateDao = new MailTemplateDao();

					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper : call dao getMailConfig() method ");
					}
					MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					String mailTemp = null;
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper : call dao getAllSubscriptionsByAssetInstanceId() method ");
					}
					List<String> emailIds=subscriptionDao.getSubscribersForAsset(asset.getAssetId(), conn);
					if(asset.isVersionable()){
						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceHelper : call dao retMailTemplateByTextName() method ");
						}
						MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
						mailTemp = mtVo1.getMailTemplate();
						String instName = assetInstance.getAssetInstName();
						instName = instName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstance.getVersionName());
					}
					else {
						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceHelper : call dao retMailTemplateByTextName() method ");
						}
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstance.getAssetInstName();
						instName = instName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%",instName);
						mailTemp = mailTemp.replaceAll("%assetType%",asset.getAssetName()).replaceAll("%assetInstName%", instName);

					}
					if(emailIds!=null){
						for(String emailId:emailIds){
							if(asset.isVersionable()) {
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
							else {
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
						}
					}
				}
				if(importFlag == false){
					if (asset.isVersionable() == true) {
						String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ " Version " + assetInstance.getVersionName();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setDescription(log);
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
						recentActivity.setUser_id(user.getUserId());
					} else {
						String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ appendingMsg;
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setDescription(log);
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
						recentActivity.setUser_id(user.getUserId());
					}
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper : call dao addRecentActivity() method to add recent activity details");
					}
					recentActivityDao.addRecentActivity(recentActivity, conn);
				}

				assetInstance.setAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId());
				assetInstance.setAssetInstId(assetInstanceData.getAssetInstId());
				assetInstance.setAssetInstName(assetInstanceData.getAssetInstName());
				assetInstancelist.add(assetInstance);

				if(importFlag == false){
					conn.commit();
				}
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_DATA_INSERTED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				if (log.isInfoEnabled()) {
					log.info("addAssetInstanceHelper:asset_instance Related details inserted successfully");
				}


			}catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					if(importFlag == false){
					    conn.rollback();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
					throw new RepoproException(e1.getMessage());
				}
				throw new RepoproException(e.getMessage());
			}catch (Exception e) {
				e.printStackTrace();
				log.error("addAssetInstanceHelper: SQL Exception addAssetInstance: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					if(importFlag == false){
					    conn.rollback();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
					throw new RepoproException(e1.getMessage());
				}
				throw new RepoproException(e.getMessage());
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceHelper : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				if(importFlag == false){
					DBConnection.closeDbConnection(conn);
				}
				if(conn1 != null){
					DBConnection.closeDbConnection(conn1);
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceHelper" + assetInstance.toString() + " exit");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(assetInstancelist))).build();

		}
	}

	/**
	 * @method addNewAssetInstance
	 * @param assetInstance
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@POST
	@Path("/addNewAssetInstance")
	public Response addNewAssetInstance(@QueryParam("assetId") Long assetId,
			@QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("addNewAssetInstance ||assetId:" +assetId+ "userName:"+userName+"|| Begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response response = null;
				
		try {
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstance : "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			response = addNewAssetInstanceHelper(assetId, userName,null,false, conn);
			conn.commit();
			//return response;
			
		} 
		catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}
		catch (Exception e) {
			log.error("addNewAssetInstance: SQL Exception addAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstance : "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if(retStatScsFlr == 500){
			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
		}else{
			return response;
		}
	}
	
	
	public Response addNewAssetInstanceHelper(Long assetId,
			String userName,String assetInstanceDesscription,boolean descFlag, Connection conn) throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("addNewAssetInstanceHelper ||assetId:" +assetId+ "userName:"+userName+"|| Begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<String> jsonList = new ArrayList<String>();
		String jsonRslt;
		String versionName = Constants.DEFAULT_VERSION;
		GamificationDao gamificationDao = new GamificationDao();
		GroupDao groupDao = new GroupDao();
		AssetDao assetDao = new AssetDao();
		UserDao userDao = new UserDao();
		User user = new User();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		SubscriptionDao subscriptionDao = new SubscriptionDao();
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		AssetInstance assetInstance = new AssetInstance();
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		RecentActivity recentActivity = new RecentActivity();
		String action = Constants.ACTIVITY_CREATE;
		String appendingMsg = "";
        Connection conn1 = null;
		try {
			if(conn == null){
				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstance : "+ Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			AssetInstance assetInstanceData = null;

			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceHelper: call dao getUserByUserId() method");
			}
			user = userDao.retProfileForUserName(userName, conn);

			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceHelper: call dao getAssetsByAssetId() method");
			}
			AssetDef asset = assetDao.getAssetsByAssetId(assetId, conn);
			if(asset == null){
				jsonRslt = Constants.ASSET_DATA_NOT_FOUND;
				jsonList.add(jsonRslt);
				return Response
						.status(Status.OK)
						.entity(new MyModel(Constants.GET_STATUS_SUCCESS,
								Constants.FAILURE,
								MessageUtil
								.getMessage(Constants.ASSET_DATA_NOT_FOUND),
								new ArrayList<Object>(jsonList))).build();
			}

			Random ran = new Random();
			int code= (100000 + ran.nextInt(900000));

			assetInstance.setAssetInstName(asset.getAssetName()+"_"+code);
			assetInstance.setVersionName(versionName);
			if(descFlag == true){
				assetInstance.setDescription(assetInstanceDesscription);
			}else{
			assetInstance.setDescription(" This is a default overview created by system ");
			}
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceHelper : call dao retAssetInstanceByTypeAndName()  method");
			}
			assetInstanceData = assetInstanceDao.retAssetInstanceByTypeAndName(asset.getAssetName(),assetInstance.getAssetInstName(), conn);

			if(assetInstanceData.getAssetInstId() != null){
				Random ran1 = new Random();
				int code1= (100000 + ran1.nextInt(900000));
				assetInstance.setAssetInstName(asset.getAssetName()+"_"+code1);
			}

			if (assetInstanceData.getAssetInstId() == null) {

				assetInstance.setAssetId(asset.getAssetId());
				assetInstance.setAssetInstName(assetInstance.getAssetInstName());
				assetInstance.setOwner(userName);
				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstanceHelper : call dao addAssetInstance() method");
				}
				assetInstanceData = assetInstanceDao.addAssetInstance(assetInstance, conn);

			}

			AssetInstanceVersion aiv = new AssetInstanceVersion();
			if (assetInstanceData.getAssetInstId() != null) {
				aiv.setVersionName(versionName);
				aiv.setVersionNotes(Constants.DEFAULT_VERSION_NOTES);
				aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstanceHelper : call dao addAssetInstanceVersion() method for adding asset instance version details");
				}
				assetInstanceVersionDao.addAssetInstanceVersions(aiv, assetInstanceData.getAssetInstId(), assetInstance.getDescription(), conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceHelper : call dao getAssetInstanceVersion() method for fetching asset instance version details:");
			}
			AssetInstanceVersion aivForAddingNewRevision = assetInstanceVersionDao
					.getAssetInstanceVersion(assetInstanceData.getAssetInstId(),assetInstance.getVersionName(), conn);

			RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
			AivRevisionHistory aivRevHist = null;

			if(aivForAddingNewRevision != null){

				aivRevHist = new AivRevisionHistory();
				aivRevHist.setAivId(aivForAddingNewRevision.getAssetInstVersionId());
				aivRevHist.setRevId(assetInstance.getVersionName()+".0");
				aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				aivRevHist.setChangedKey("N");
				aivRevHist.setOverviewData(aivForAddingNewRevision.getDescription());
				aivRevHist.setRelationshipData(null);
				aivRevHist.setParameterData(null);
				aivRevHist.setUserId(user.getUserId());
				aivRevHist.setUsedBy(null);
				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstanceHelper : call dao addRevisionData() method for adding revision data");
				}
				revisionHistoryDao.addRevisionData(aivRevHist, conn);

			}
			GamificationDetails gamePoint = null;

			if (!userName.equals("admin") && user.getActiveFlag().equalsIgnoreCase("1")) {

				gamePoint = new GamificationDetails();

				gamePoint.setPoints("5");
				gamePoint.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
				gamePoint.setField("Asset Instance");
				gamePoint.setAction("Created");
				gamePoint.setUserId(user.getUserId());
				gamePoint.setAssetId(asset.getAssetId().toString());
				gamePoint.setAssetInstanceVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
				if (asset.isVersionable() == true) {
					gamePoint.setInstanceDetails(asset.getAssetName()+ "~" + assetInstance.getAssetInstName() + "~"+ versionName);
				} else {
					gamePoint.setInstanceDetails(asset.getAssetName()+ "~" + assetInstance.getAssetInstName()+ "~N/A");
				}
				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstanceHelper : call dao addGamificationPoint() method for adding gamification point details");
				}
				gamificationDao.addGamificationPoint(gamePoint, conn);

			}

			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceHelper : call dao retassetgroupsAccess() method for fetching assetGroupAccess details:");
			}
			List<GroupAssetAccess> groupAssetAccessList = groupDao.retassetgroupsAccess(asset.getAssetId(), conn);
			GroupAssetAccess groupAssetInstAccess = null;

			for (GroupAssetAccess ga : groupAssetAccessList) {
				groupAssetInstAccess = new GroupAssetAccess();
				groupAssetInstAccess.setAssetInstversionId(aivForAddingNewRevision.getAssetInstVersionId());
				groupAssetInstAccess.setEditAccess(ga.getEditAccess());
				groupAssetInstAccess.setViewAccess(ga.getViewAccess());
				groupAssetInstAccess.setDeleteAccess(ga.getDeleteAccess());
				groupAssetInstAccess.setGroupId(ga.getGroupId());
				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstanceHelper : call dao addGroupsAccessAISubmit() method for adding groupAccess details");
				}
				groupDao.addGroupsAccessAISubmit(groupAssetInstAccess, conn);

			}

			MailTemplateDao mailTemplateDao = new MailTemplateDao();

			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceHelper : call dao getMailConfig() method ");
			}
			MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
			String mailTemp = null;
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceHelper : call dao getAllSubscriptionsByAssetInstanceId() method ");
			}
			List<String> emailIds=subscriptionDao.getSubscribersForAsset(assetId, conn);
			if(asset.isVersionable()){
				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstanceHelper : call dao retMailTemplateByTextName() method ");
				}
				MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
				mailTemp = mtVo1.getMailTemplate();
				String instName = assetInstance.getAssetInstName();
				instName = instName.replace("\\", "\\\\").replace("$", "\\$");
				mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstance.getVersionName());
			}
			else {
				if (log.isTraceEnabled()) {
					log.trace("addNewAssetInstanceHelper : call dao retMailTemplateByTextName() method ");
				}
				MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
				mailTemp = mtVo.getMailTemplate();
				String instName = assetInstance.getAssetInstName();
				instName = instName.replace("\\", "\\\\").replace("$", "\\$");
				mailTemp = mailTemp.replaceAll("%assetInstName%",instName);
				mailTemp = mailTemp.replaceAll("%assetType%",asset.getAssetName()).replaceAll("%assetInstName%", instName);

			}
			if(emailIds!=null){
				for(String emailId:emailIds){
					if(asset.isVersionable()) {
						SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
								MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

					}
					else {
						SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
								MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

					}
				}
			}

			if (asset.isVersionable() == true) {
				String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ " Version " + assetInstance.getVersionName();
				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setDescription(log);
				recentActivity.setAssetId(asset.getAssetId().toString());
				recentActivity.setAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
				recentActivity.setUser_id(user.getUserId());
			} else {
				String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ appendingMsg;
				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setDescription(log);
				recentActivity.setAssetId(asset.getAssetId().toString());
				recentActivity.setAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId().toString());
				recentActivity.setUser_id(user.getUserId());
			}
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceHelper : call dao addRecentActivity() method to add recent activity details");
			}
			recentActivityDao.addRecentActivity(recentActivity, conn);

			assetInstance.setAssetInstVersionId(aivForAddingNewRevision.getAssetInstVersionId());
			assetInstance.setAssetInstId(assetInstance.getAssetInstId());
			assetInstance.setAssetInstName(assetInstance.getAssetInstName());
			assetInstanceList.add(assetInstance);
			
			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_DATA_INSERTED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			if (log.isInfoEnabled()) {
				log.info("addNewAssetInstance Related details inserted successfully");
			}
			
		} 
		catch (RepoproException e) {
			log.error("addNewAssetInstanceHelper || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("addNewAssetInstanceHelper || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if(conn1 != null){
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceHelper || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		}

		if (log.isTraceEnabled()) {
			log.trace("addNewAssetInstanceHelper" + assetInstance.toString() + " exit");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetInstanceList))).build();
	}
	

	/**
	 * @method updateAssetInstanceName
	 * @description update assetInstance Name
	 * @param newAssetInstanceName
	 * @param assetInstance
	 * @return Response Success message
	 * @throws UpdateContentException
	 * @throws DataNotFoundException
	 */
	@PUT
	@Encoded
	@Path("/updateAssetInstanceName")
	public Response updateAssetInstanceName(@QueryParam("userId") Long userId,
			@QueryParam("newAssetInstanceName") String newAssetInstanceName,AssetInstance assetInstance){
		if (newAssetInstanceName == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceName" + newAssetInstanceName
						+ "AssetInstance:" + assetInstance.toString() + "userId : "+ userId +" Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;

			try {
				String assetInstName = URLDecoder.decode(assetInstance.getAssetInstName(), "UTF-8");
				assetInstName = assetInstName.trim();
				assetInstance.setAssetInstName(assetInstName);
				String assetName = URLDecoder.decode(assetInstance.getAssetName(), "UTF-8");
				assetName = assetName.trim();
				assetInstance.setAssetName(assetName);
				newAssetInstanceName = URLDecoder.decode(newAssetInstanceName, "UTF-8");
				newAssetInstanceName = newAssetInstanceName.trim();
				
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceName : "+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				
				Response response = updateAssetInstanceNameHelper(userId, newAssetInstanceName, assetInstance,false, conn);
				conn.commit();
				return response;
				
				
			}catch (RepoproException e) {
				log.error("updateAssetInstanceName: SQL Exception updateAssetInstanceName: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			}
			catch (Exception e) {
				log.error("updateAssetInstanceName: SQL Exception updateAssetInstanceName: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}

			} finally {
				if (log.isDebugEnabled()) {
					log.debug("updateAssetInstanceName : "+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceName" + newAssetInstanceName+"assetInstance" + assetInstance.toString() + " End");
			}
			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

		}
	}

	public Response updateAssetInstanceNameHelper(Long userId,String newAssetInstanceName,AssetInstance assetInstance,boolean importFlag,Connection conn) throws RepoproException{
		if (newAssetInstanceName == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceNameHelper" + newAssetInstanceName
						+ "AssetInstance:" + assetInstance.toString() + "userId : "+ userId +" Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn1 = null;

			List<String> jsonList = new ArrayList<String>();
			String action = Constants.ACTIVITY_MODIFY;
			String appendingMsg = "";
			AssetDao assetDao = new AssetDao();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			UserDao userDao = new UserDao();
			User user = new User();
			RecentActivity recentActivity = new RecentActivity();
			AssetInstance assetInstanceData = new AssetInstance();
			FavouritesDao favouritesDao = new FavouritesDao();
			String oldAssetInstanceName = null;
			AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();

			try {
				
				oldAssetInstanceName = assetInstance.getAssetInstName();
				
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceNameHelper : "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				if (conn == null) {
					conn1 = DBConnection.getInstance().getConnection();
					conn = conn1;
				}
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceNameHelper : call dao getAssetsByAssetId()  method to get asset details ");
				}
				AssetDef ad = assetDao.getAssetsByAssetId(assetInstance.getAssetId(), conn);

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceNameHelper : call dao getUserByUserId() method to get user details");
				}
				user = userDao.getUserByUserId(userId, conn);

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceNameHelper : call dao getAssetInstanceVersion()  method  to get asset instance version details");
				}
				AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceNameHelper : call dao retAssetInstanceByTypeAndName()  method to get data by asset name and assetinstancename");
				}
				assetInstanceData = assetInstanceDao.retAssetInstanceByTypeAndName(assetInstance.getAssetName(),newAssetInstanceName, conn);
				String oldName =  assetInstance.getAssetInstName();
				assetInstance.setAssetInstName(newAssetInstanceName);
				assetInstance.setOwner(user.getUserName());
				if(!newAssetInstanceName.equalsIgnoreCase(oldName)){
					if(assetInstanceData.getAssetInstId() != null){
						return Response
								.status(Status.OK)
								.entity(new MyModel(Constants.UPDATE_STATUS_SUCCESS,
										Constants.FAILURE,
										MessageUtil
										.getMessage(Constants.ASSET_INST_NAME_ALREADY_EXISTS),
										new ArrayList<Object>())).build();
					}
				}
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceNameHelper : call dao updateAssetInstanceName() method ");
				}
				int val = assetInstanceDao.updateAssetInstanceName(assetInstance, conn);

				if(val!=0){
					if(importFlag == false){
						SubscriptionDao subscriptionDao =  new SubscriptionDao();
						MailTemplateDao mailTemplateDao = new MailTemplateDao();
						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstanceNameHelper : call dao getAllSubscriptionsByAssetInstanceId() method to get subscribed user");
						}
						List<String> emailIds=subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstance.getAssetInstId(),conn);

						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstanceNameHelper : call dao retMailTemplateByTextName() method ");
						}
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceName");
						String mailTemp = mtVo.getMailTemplate();
						String instName = oldName;
						String instName1 = newAssetInstanceName;
						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstanceNameHelper : call dao getMailConfig() method ");
						}
						MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						instName = instName.replace("\\", "\\\\").replace("$", "\\$");
						instName1 = instName1.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%oldInstanceName%", instName).replaceAll("%newInstanceName%", instName1);
						if(emailIds!=null){
							for(String emailId:emailIds){
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
							}
						}
					}
					if(importFlag == false){
						if (ad.isVersionable() == true) {
							String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ " Version " + assetInstance.getVersionName();
							recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							recentActivity.setDescription(log);
							recentActivity.setAssetId(ad.getAssetId().toString());
							recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
							recentActivity.setUser_id(userId);
						} else {
							String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ appendingMsg;
							recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							recentActivity.setDescription(log);
							recentActivity.setAssetId(ad.getAssetId().toString());
							recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
							recentActivity.setUser_id(userId);
						}
						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstanceNameHelper : call dao addRecentActivity() method to add recent activity details");
						}
						recentActivityDao.addRecentActivity(recentActivity, conn);
					}
					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstanceNameHelper : call dao OnRenameAssetInstanceRenameFavourites() method to update favourites");
					}
					favouritesDao.OnRenameAssetInstanceRenameFavourites(assetInstance.getAssetName(),
							assetInstance.getAssetInstName(),assetInstance.getAssetInstId(),
							aiv.getAssetInstVersionId(),userId,conn);

					User username = userDao.getUserByUserId(userId, conn);
					if(importFlag == false){
						assetInstanceVersionsManager.addRevisionData("IR",aiv.getAssetInstVersionId(),assetInstance.getVersionName(), 
								null,null, null, null,username.getUserName(),userId,oldName+"<!!>"+assetInstance.getAssetInstName(),conn);
					}
					
					AssetInstanceVersion aivo = new AssetInstanceVersion();
					aivo.setVersionName(assetInstance.getVersionName());
					aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					aivo.setAssetInstVersionId(aiv.getAssetInstVersionId());
					assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
					
					// rename instance name in parameter values for asset list
					// Gomathi 06/02/2018
					
					assetInstanceDao.renameInstanceNameinParamValueForAssetList(newAssetInstanceName,oldAssetInstanceName,assetInstance.getAssetId(),conn);
					
					//conn.commit();
					retMsg = Constants.ASSET_INSTANCE_NAME_UPDATED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				}
				else{
					retMsg = Constants.UPDATE_ASSET_INSTANCE_NAME_FAILED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				}
				if (log.isInfoEnabled()) {
					log.info("updateAssetInstanceNameHelper:AssetInstanceName details updated successfully");
				}
			} 
			
			catch (RepoproException e) {
				log.error("updateAssetInstanceNameHelper: SQL Exception updateAssetInstanceName: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				throw new RepoproException(e.getMessage());
			}
			catch (Exception e) {
				log.error("updateAssetInstanceNameHelper: SQL Exception updateAssetInstanceName: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				throw new RepoproException(e.getMessage());
			} finally {
				if (log.isDebugEnabled()) {
					log.debug("updateAssetInstanceNameHelper : "+ Constants.LOG_CONNECTION_CLOSE);
				}
				if(conn1 != null){
					DBConnection.closeDbConnection(conn1);
				}
			}
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceNameHelper" + newAssetInstanceName+"assetInstance" + assetInstance.toString() + " End");
			}
			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(jsonList))).build();

		}
	}
	
	/**
	 * @method updateAssetInstanceDescription
	 * @description update assetInstance Description
	 * @param newAssetInstanceDesc
	 * @param assetInstVersionId
	 * @return Response Success message
	 * @throws UpdateContentException
	 * @throws DataNotFoundException
	 *//*
	@PUT
	@Path("/Description")
	public Response updateAssetInstanceDescription(AssetInstance assetInstance,@QueryParam("userName") String userName)throws RepoproException{
		if (assetInstance == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescription:"+assetInstance.toString()+"userName:"+userName+"Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null; 
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			AssetInstanceVersion aiv = null;
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			UserDao userDao = new UserDao();
			AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();

			try {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescription : "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescription : call dao getAssetInstanceVersion()  method");
				}
				aiv = assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

				User ubo = userDao.retProfileForUserName(userName,conn);
				String desc = "";
				if(!userName.equals("admin") && ubo.getActiveFlag().equalsIgnoreCase("1")){

					desc = aiv.getDescription();

				}

				aiv.setDescription(assetInstance.getNewDescription());

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescription ||call method addRevisionData() to add revision data");
				}
				assetInstanceVersionsManager.addRevisionData("O",aiv.getAssetInstVersionId(),assetInstance.getVersionName(), 
						assetInstance.getNewDescription(),null, null, null,userName,ubo.getUserId(),conn);


				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescription : call dao updateAssetInstanceDescription() method ");
				}

				int val = assetInstanceDao.updateAssetInstanceDescription(aiv, conn);

				AssetDef asset = new AssetDef();
				AssetDao assetDao = new AssetDao();

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescription : call dao getAssetsByAssetId() method to get asset details");
				}
				asset = assetDao.getAssetsByAssetId(assetInstance.getAssetId(), conn);
				if(val!=0){
					SubscriptionDao subscriptionDao =  new SubscriptionDao();
					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstanceDescription : call dao getMailConfig() method");
					}
					MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					String mailTemp = null;
					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstanceDescription : call dao getAllSubscriptionsByAssetInstanceId() method to get subscribed users");
					}
					List<String> emailIds=subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstance.getAssetInstId(),conn);
					if(asset.isVersionable()){
						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstanceDescription : call dao retMailTemplateByTextName() method");
						}
						MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstDescForVersionableAsset");
						mailTemp = mtVo1.getMailTemplate();
						String instName = assetInstance.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstance.getVersionName());
					}
					else{
						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstanceDescription : call dao retMailTemplateByTextName() method");
						}
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstDescForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstance.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%",instName);
					}
					if(emailIds!=null){
						for(String emailId:emailIds){
							if(asset.isVersionable())
							{
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
							else
							{
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
						}

					}

					if(!userName.equals("admin") && ubo.getActiveFlag().equalsIgnoreCase("1"))
					{
						if(desc == null){
							desc = "";
						}
						String oldValueImp = desc.trim().toString();
						String newValueImp = assetInstance.getNewDescription().trim().toString();
						int num = oldValueImp.compareTo(newValueImp);
						GamificationDetails gamePoint = new GamificationDetails();
						GamificationDao gamificationDao =  new GamificationDao();
						if(num < 0 || num > 0 )
						{
							gamePoint.setPoints("1");
							gamePoint.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
							gamePoint.setField("Overview");
							gamePoint.setAction("Updated");
							gamePoint.setUserId(ubo.getUserId());
							gamePoint.setAssetId(asset.getAssetId().toString());
							gamePoint.setAssetInstanceVersionId(aiv.getAssetInstVersionId().toString());
							if(asset.isVersionable() == true)
							{
								gamePoint.setInstanceDetails(assetInstance.getAssetName()+"~"+assetInstance.getAssetInstName()+"~"+assetInstance.getVersionName());
							}
							else
							{
								gamePoint.setInstanceDetails(assetInstance.getAssetName()+"~"+assetInstance.getAssetInstName()+"~N/A");	
							}
							if (log.isTraceEnabled()) {
								log.trace("updateAssetInstanceDescription : call dao addGamificationPoint() method to add game details");
							}
							gamificationDao.addGamificationPoint(gamePoint,conn);
						}
					}

					RecentActivityDao recentActivityDao = new RecentActivityDao();
					RecentActivity recentActivity = null;
					if(asset.isVersionable() == true){
						recentActivity = new RecentActivity();
						recentActivity.setUserName(ubo.getFullName());
						recentActivity.setAction("updated");
						recentActivity.setAssetName(assetInstance.getAssetName());
						recentActivity.setAssetInstName(assetInstance.getAssetInstName());
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
						String log = ubo.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
								+ ";" + recentActivity.getAssetInstName() + ";" + "version"+assetInstance.getVersionName(); 
						recentActivity.setDescription(log);
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setUser_id(ubo.getUserId());

					}
					else{
						recentActivity = new RecentActivity();
						recentActivity.setUserName(ubo.getFullName());
						recentActivity.setAction("updated");
						recentActivity.setAssetName(assetInstance.getAssetName());
						recentActivity.setAssetInstName(assetInstance.getAssetInstName());
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
						String log = ubo.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
								+ ";" + recentActivity.getAssetInstName(); 
						recentActivity.setDescription(log);
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setUser_id(ubo.getUserId());

					}
					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstanceDescription : call dao addRecentActivity() method to add recent activity details");
					}
					recentActivityDao.addRecentActivity(recentActivity,conn);

					conn.commit();
					retMsg = Constants.ASSET_INSTANCE_DESC_UPDATED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				}
				else{
					retMsg = Constants.UPDATE_ASSET_INSTANCE_DESCRIPTION_FAILED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				}
				if (log.isInfoEnabled()) {
					log.info("updateAssetInstanceDescription:AssetInstanceDescription details updated successfully");
				}
			}
			catch (RepoproException e) {
				log.error("updateAssetInstanceDescription: SQL Exception  updateAssetInstanceDescription: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			}
			catch (Exception e) {
				log.error("updateAssetInstanceDescription: SQL Exception updateAssetInstanceDescription: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				e.printStackTrace();
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
				
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescription : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescription:"+assetInstance.toString()+" userName:"+userName+"Exit");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

		}
	}
*/
	
	/**
	 * @method updateAssetInstanceDescription
	 * @description update assetInstance Description
	 * @param newAssetInstanceDesc
	 * @param assetInstVersionId
	 * @return Response Success message
	 * @throws UpdateContentException
	 * @throws DataNotFoundException
	 */
	@PUT
	@Path("/Description")
	public Response updateAssetInstanceDescription(AssetInstance assetInstance,@QueryParam("userName") String userName)throws RepoproException{
		if (assetInstance == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescription:"+assetInstance.toString()+"userName:"+userName+"Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null; 
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			try {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescription : "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				
				Response response = updateAssetInstanceDescriptionHelper(assetInstance, userName, false, conn);
				return response;
				
			}
			catch (RepoproException e) {
				log.error("updateAssetInstanceDescription: SQL Exception  updateAssetInstanceDescription: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				
			}
			catch (Exception e) {
				log.error("updateAssetInstanceDescription: SQL Exception updateAssetInstanceDescription: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				e.printStackTrace();
				
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescription : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				if(conn != null){
					DBConnection.closeDbConnection(conn);
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescription:"+assetInstance.toString()+" userName:"+userName+"Exit");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

		}
	}
	
	public Response updateAssetInstanceDescriptionHelper(AssetInstance assetInstance,String userName,
			boolean importFlag,Connection conn)throws RepoproException{
		if (assetInstance == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescriptionHelper:"+assetInstance.toString()+"userName:"+userName+"Begin");
			}

			Status retStat = Status.OK;
			String retMsg = null; 
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn1 = null;
			AssetInstanceVersion aiv = null;
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			UserDao userDao = new UserDao();
			AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();

			try {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescriptionHelper : "
							+ Constants.LOG_CONNECTION_OPEN);
				}
				if(conn == null){
					conn1 = DBConnection.getInstance().getConnection();
					conn = conn1;
				}
				conn.setAutoCommit(false);
				
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescriptionHelper : call dao getAssetInstanceVersion()  method");
				}
				aiv = assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

				User ubo = userDao.retProfileForUserName(userName,conn);
				String desc = "";
				if(!userName.equals("admin") && ubo.getActiveFlag().equalsIgnoreCase("1")){

					desc = aiv.getDescription();

				}

				aiv.setDescription(assetInstance.getNewDescription());
				if(importFlag == false){
					if (log.isTraceEnabled()) {
						log.trace("updateAssetInstanceDescriptionHelper ||call method addRevisionData() to add revision data");
					}
					assetInstanceVersionsManager.addRevisionData("O",aiv.getAssetInstVersionId(),assetInstance.getVersionName(), 
							assetInstance.getNewDescription(),null, null, null,userName,ubo.getUserId(),null,conn);
				}

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescriptionHelper : call dao updateAssetInstanceDescription() method ");
				}

				int val = assetInstanceDao.updateAssetInstanceDescription(aiv, conn);

				AssetDef asset = new AssetDef();
				AssetDao assetDao = new AssetDao();

				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescription : call dao getAssetsByAssetId() method to get asset details");
				}
				asset = assetDao.getAssetsByAssetId(assetInstance.getAssetId(), conn);
				if(val!=0){
					if(importFlag == false){
						SubscriptionDao subscriptionDao =  new SubscriptionDao();
						MailTemplateDao mailTemplateDao = new MailTemplateDao();
						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstanceDescriptionHelper : call dao getMailConfig() method");
						}
						MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						String mailTemp = null;
						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstanceDescriptionHelper : call dao getAllSubscriptionsByAssetInstanceId() method to get subscribed users");
						}
						List<String> emailIds=subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstance.getAssetInstId(),conn);
						if(asset.isVersionable()){
							if (log.isTraceEnabled()) {
								log.trace("updateAssetInstanceDescriptionHelper : call dao retMailTemplateByTextName() method");
							}
							MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstDescForVersionableAsset");
							mailTemp = mtVo1.getMailTemplate();
							String instName = assetInstance.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstance.getVersionName());
						}
						else{
							if (log.isTraceEnabled()) {
								log.trace("updateAssetInstanceDescriptionHelper : call dao retMailTemplateByTextName() method");
							}
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstDescForNonVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = assetInstance.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%",instName);
						}
						if(emailIds!=null){
							for(String emailId:emailIds){
								if(asset.isVersionable())
								{
									SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

								}
								else
								{
									SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

								}
							}

						}
					}
					if(!userName.equals("admin") && ubo.getActiveFlag().equalsIgnoreCase("1"))
					{
						if(desc == null){
							desc = "";
						}
						String oldValueImp = desc.trim().toString();
						String newValueImp = assetInstance.getNewDescription().trim().toString();
						int num = oldValueImp.compareTo(newValueImp);
						GamificationDetails gamePoint = new GamificationDetails();
						GamificationDao gamificationDao =  new GamificationDao();
						if(num < 0 || num > 0 )
						{
							gamePoint.setPoints("1");
							gamePoint.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()).toString());
							gamePoint.setField("Overview");
							gamePoint.setAction("Updated");
							gamePoint.setUserId(ubo.getUserId());
							gamePoint.setAssetId(asset.getAssetId().toString());
							gamePoint.setAssetInstanceVersionId(aiv.getAssetInstVersionId().toString());
							if(asset.isVersionable() == true)
							{
								gamePoint.setInstanceDetails(assetInstance.getAssetName()+"~"+assetInstance.getAssetInstName()+"~"+assetInstance.getVersionName());
							}
							else
							{
								gamePoint.setInstanceDetails(assetInstance.getAssetName()+"~"+assetInstance.getAssetInstName()+"~N/A");	
							}
							if (log.isTraceEnabled()) {
								log.trace("updateAssetInstanceDescriptionHelper : call dao addGamificationPoint() method to add game details");
							}
							gamificationDao.addGamificationPoint(gamePoint,conn);
						}
					}
					if(importFlag == false){
						RecentActivityDao recentActivityDao = new RecentActivityDao();
						RecentActivity recentActivity = null;
						if(asset.isVersionable() == true){
							recentActivity = new RecentActivity();
							recentActivity.setUserName(ubo.getFullName());
							recentActivity.setAction("updated");
							recentActivity.setAssetName(assetInstance.getAssetName());
							recentActivity.setAssetInstName(assetInstance.getAssetInstName());
							recentActivity.setAssetId(asset.getAssetId().toString());
							recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
							String log = ubo.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
									+ ";" + recentActivity.getAssetInstName() + ";" + "version"+assetInstance.getVersionName(); 
							recentActivity.setDescription(log);
							recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							recentActivity.setUser_id(ubo.getUserId());

						}
						else{
							recentActivity = new RecentActivity();
							recentActivity.setUserName(ubo.getFullName());
							recentActivity.setAction("updated");
							recentActivity.setAssetName(assetInstance.getAssetName());
							recentActivity.setAssetInstName(assetInstance.getAssetInstName());
							recentActivity.setAssetId(asset.getAssetId().toString());
							recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
							String log = ubo.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
									+ ";" + recentActivity.getAssetInstName(); 
							recentActivity.setDescription(log);
							recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							recentActivity.setUser_id(ubo.getUserId());

						}
						if (log.isTraceEnabled()) {
							log.trace("updateAssetInstanceDescriptionHelper : call dao addRecentActivity() method to add recent activity details");
						}
						recentActivityDao.addRecentActivity(recentActivity,conn);
					}
					if(importFlag == false){
						conn.commit();
					}
					retMsg = Constants.ASSET_INSTANCE_DESC_UPDATED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				}
				else{
					retMsg = Constants.UPDATE_ASSET_INSTANCE_DESCRIPTION_FAILED;
					retScsFlr = Constants.SUCCESS;
					retStat = Status.OK;
					retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				}
				if (log.isInfoEnabled()) {
					log.info("updateAssetInstanceDescriptionHelper:AssetInstanceDescription details updated successfully");
				}
			}
			catch (RepoproException e) {
				log.error("updateAssetInstanceDescriptionHelper: SQL Exception  updateAssetInstanceDescription: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					if(importFlag == false){
						conn.rollback();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
					throw new RepoproException(e1.getMessage());
				}
				throw new RepoproException(e.getMessage());
			}
			catch (Exception e) {
				log.error("updateAssetInstanceDescriptionHelper: SQL Exception updateAssetInstanceDescription: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				e.printStackTrace();
				try {
					if(importFlag == false){
						conn.rollback();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
					throw new RepoproException(e1.getMessage());
				}
				throw new RepoproException(e.getMessage());
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateAssetInstanceDescriptionHelper : "+ Constants.LOG_CONNECTION_CLOSE);
				}
				if(importFlag == false){
					DBConnection.closeDbConnection(conn);
				}
				if(conn1 != null){
					DBConnection.closeDbConnection(conn1);
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceDescriptionHelper:"+assetInstance.toString()+" userName:"+userName+"Exit");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

		}
	}

	
	
	
	/**
	 * @method deleteAssetInstance
	 * @description delete assetInstance details
	 * @param assetName
	 * @param assetInstanceName
	 * @return Response Success message
	 * @throws DeleteContentException
	 * @throws DataNotFoundException
	 */
	@DELETE
	@Encoded
	@Path("/deleteAssetInstance")
	public Response deleteAssetInstance(
			@QueryParam("userName") String userName,
			@QueryParam("assetId") Long assetId,
			@QueryParam("assetInstId") Long assetInstId,
			@QueryParam("assetInstName") String assetInstName){

		if (log.isDebugEnabled()) {
			log.debug("deleteAssetInstance :userName:"+userName+" assetId:"+assetId+" assetInstId:" + assetInstId +" assetInstName:"+assetInstName+" Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		int val = 0;
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		AssetDao assetDao = new AssetDao();
		RecentActivityDao recentActivityDao =  new RecentActivityDao();
		RecentActivity recentActivity = null;
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
		RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
		UserDao userDao = new UserDao();
		User user = new User();
		AssetDetailRequest  assetDetailRequest = new AssetDetailRequest();
		int versionflag = 0;
		RelationshipDao relationshipDao = new RelationshipDao();
		try {
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance : "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance : call dao method getAssetsByAssetId to get list of asset details");
			}
			AssetDef ad = assetDao.getAssetsByAssetId(assetId, conn);	
			if(ad.isVersionable() == true){
				versionflag = 1;
			}
			List<AssetInstanceVersion> versionList = new ArrayList<AssetInstanceVersion>();

			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance : call dao method getAssetInstanceVersions to get list of asset instance version");
			}
			versionList = assetInstanceVersionDao.getAssetInstanceVersions(assetInstId, conn);

			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance : call dao method retProfileForUserName to get user details");
			}
			user = userDao.retProfileForUserName(userName, conn);

			assetDetailRequest.setAssetInstName(assetInstName);
			assetDetailRequest.setAssetType(ad.getAssetName());
			AivRevisionHistory aivRevisionHistoryBO = new AivRevisionHistory();

			List<Long> versionIds = new ArrayList<Long>();
			
			for (AssetInstanceVersion version : versionList){

				assetDetailRequest.setVersionName(version.getVersionName());
				aivRevisionHistoryBO.setAivId(version.getAssetInstVersionId());

				if (log.isTraceEnabled()) {
					log.trace("deleteAssetInstanceVersions || dao method called : deleteAivRevHistoryByAivId()"
							+ aivRevisionHistoryBO.toString());
				}
				revisionHistoryDao.deleteAivRevHistoryByAivId(aivRevisionHistoryBO, conn);

				if (log.isTraceEnabled()) {
					log.trace("deleteAssetInstance : call dao method removeRelationshipDatas to remove relationship details");
				}
				assetInstanceVersionsManager.removeRelationshipDatas(assetDetailRequest,version.getAssetInstVersionId(), userName, 
						user.getUserId(),versionflag , conn);

				if (log.isTraceEnabled()) {
					log.trace("deleteAssetInstance : call dao method removeDependents to remove dependency details");
				}
				assetInstanceVersionsManager.removeDependents(assetDetailRequest, userName,user.getFullName(), user.getUserId(),version.getAssetInstVersionId(), assetInstId,
						versionflag, conn);

				if(ad.isVersionable() == true){
					recentActivity = new RecentActivity();
					recentActivity.setUserName(user.getFullName());
					recentActivity.setAction("deleted");
					recentActivity.setAssetName(ad.getAssetName());
					recentActivity.setAssetInstName(assetInstName);
					recentActivity.setAssetId(assetId.toString());
					recentActivity.setAssetInstVersionId(version.getAssetInstVersionId().toString());
					String logs = user.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
							+ ";" + assetInstName + ";" + "version"+version.getVersionName();
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(logs);
					recentActivity.setUser_id(user.getUserId());
					if (log.isTraceEnabled()) {
						log.trace("deleteAssetInstance : call dao method addRecentActivity");
					}
					recentActivityDao.addRecentActivity(recentActivity,conn);
				}
				if(ad.isVersionable() == false){
					recentActivity = new RecentActivity();
					recentActivity.setUserName(user.getFullName());
					recentActivity.setAction("deleted");
					recentActivity.setAssetName(ad.getAssetName());
					recentActivity.setAssetInstName(assetInstName);
					recentActivity.setAssetId(assetId.toString());
					recentActivity.setAssetInstVersionId(version.getAssetInstVersionId().toString());
					String logs = user.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
							+ ";" + assetInstName + ";" + "";
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(logs);
					recentActivity.setUser_id(user.getUserId());
					if (log.isTraceEnabled()) {
						log.trace("deleteAssetInstance : call dao method addRecentActivity");
					}
					recentActivityDao.addRecentActivity(recentActivity,conn);
				}
				
				versionIds.add(version.getAssetInstVersionId());
			}
			List<AssetInstRelationship> assetInstRelationship= new ArrayList<AssetInstRelationship>();
			for(AssetInstanceVersion versions : versionList){
				
				assetInstRelationship = relationshipDao.retRvrRelationsForAnAssetInstanceVersionId(versions.getAssetInstVersionId(),conn);
				
				for(AssetInstRelationship relationship:assetInstRelationship){
					
					AssetDef asset = assetInstanceDao.retAssetDetail(relationship.getAssetName(), conn);	
					
					if(asset.isVersionable() == true){
						recentActivity = new RecentActivity();
						recentActivity.setUserName(user.getFullName());
						recentActivity.setAction("updated");
						recentActivity.setAssetName(relationship.getAssetName());
						recentActivity.setAssetInstName(relationship.getAssetInstanceName());
						recentActivity.setAssetId(assetId.toString());
						recentActivity.setAssetInstVersionId(relationship.getSrcAssetInstVersionId().toString());
						String logs = user.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
								+ ";" + relationship.getAssetInstanceName() + ";" + "version"+relationship.getVersionName();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setDescription(logs);
						recentActivity.setUser_id(user.getUserId());
						if (log.isTraceEnabled()) {
							log.trace("deleteAssetInstance : call dao method addRecentActivity");
						}
						recentActivityDao.addRecentActivity(recentActivity,conn);
					}
					if(asset.isVersionable() == false){
						recentActivity = new RecentActivity();
						recentActivity.setUserName(user.getFullName());
						recentActivity.setAction("updated");
						recentActivity.setAssetName(relationship.getAssetName());
						recentActivity.setAssetInstName(relationship.getAssetInstanceName());
						recentActivity.setAssetId(assetId.toString());
						recentActivity.setAssetInstVersionId(relationship.getSrcAssetInstVersionId().toString());
						String logs = user.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
								+ ";" + relationship.getAssetInstanceName() + ";" + "";
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setDescription(logs);
						recentActivity.setUser_id(user.getUserId());
						if (log.isTraceEnabled()) {
							log.trace("deleteAssetInstance : call dao method addRecentActivity");
						}
						recentActivityDao.addRecentActivity(recentActivity,conn);
					}
				}
			}
			
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance : call dao method deleteAssetInstance to delete asset instance details");
			}
			val = assetInstanceDao.deleteAssetInstance(assetInstId, conn);
			
			SubscriptionDao subscriptionDao =  new SubscriptionDao();
			MailTemplateDao mailTemplateDao = new MailTemplateDao();
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance : call dao method getAllSubscriptionsByAssetInstanceId to get subscribed user list");
			}
			List<String> emailIds=subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstId,conn);
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance : call dao method retMailTemplateByTextName to get mail template");
			}
			MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"deleteAssetInstanceVersionForNonVersionableAsset");

			String mailTemp = mtVo.getMailTemplate();
			String instName = assetInstName;
			instName = instName.replace("\\", "\\\\").replace("$", "\\$");
			mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
			MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
			if(emailIds!=null){
				for(String emailId:emailIds){
					SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
							MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
				}
			}
			

			conn.commit();
			
			for(int i =0;i<versionIds.size();i++){
				String outputPath = Constants.UPLOADED_JAR_SUPPORT_FILE_PATH + versionIds.get(i) + "/";
				File instFile = new File(outputPath);
				if(instFile.exists()) {
					FileUtils.forceDelete(new File(outputPath));
				}
			}
			
			retMsg = Constants.ASSET_INSTANCE_DATA_DELETED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			if (log.isInfoEnabled()) {
				log.info("deleteAssetInstance:" + val+ "assetinstance rows deleted successfully");
			}
		} 
		
		catch (RepoproException e) {
			log.error("SQL Exception deleteAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}
		catch (Exception e) {
			log.error("SQL Exception deleteAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstance: "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isDebugEnabled()) {
			log.debug("deleteAssetInstance : " + assetInstName + " End");
		}

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/**
	 * @method saveDependency
	 * @description to save relationship dependency
	 * @param assetInstanceVersion
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 *//*
	@POST
	@Encoded
	@Path("/saveDependency")
	public Response saveDependency(AssetInstanceVersion assetInstanceVersion,
			@QueryParam("userName") String userName){
		if (assetInstanceVersion == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("saveDependency ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Begin");
			}
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;

			String versionName = assetInstanceVersion.getVersionName();
			AssetDao assetDao = new AssetDao();
			UserDao userDao = new UserDao();
			User user = new User();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			SubscriptionDao subscriptionDao = new SubscriptionDao();
			AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
			try {
				String assetInstName = URLDecoder.decode(assetInstanceVersion.getAssetInstName(), "UTF-8");
				assetInstanceVersion.setAssetInstName(assetInstName);
				String assetName = URLDecoder.decode(assetInstanceVersion.getAssetName(), "UTF-8");
				assetInstanceVersion.setAssetName(assetName);		
				
				if (log.isTraceEnabled()) {
					log.trace("saveDependency : "+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				if(assetInstanceVersion.getRemovedDestAssetInstVersionIds().size() == 0 && assetInstanceVersion.getAddDestAssetInstVersionIds().size() == 0){
					return Response
							.status(Status.OK)
							.entity(new MyModel(Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.ASSET_DATA_NOT_PROVIDED))).build();
				}

				if(assetInstanceVersion.getRemovedDestAssetInstVersionIds().size() > 0 && assetInstanceVersion.getRemovedRelationshipIds().size() > 0 ){
					if (log.isTraceEnabled()) {
						log.trace("saveDependency ||call helper method removeDependency() to remove DestAssetInstVersionIds");
					}
					removeDependency(assetInstanceVersion,userName,conn);
				}

				if(assetInstanceVersion.getAddDestAssetInstVersionIds().size() > 0 && assetInstanceVersion.getAddRelationshipIds().size() > 0){
					if (log.isTraceEnabled()) {
						log.trace("saveDependency ||call helper method addDependency() to add DestAssetInstVersionIds");
					}
					addDependency(assetInstanceVersion, userName,conn);
				}


				AssetInstanceVersion updateAssetInstVersiondata = new AssetInstanceVersion();

				updateAssetInstVersiondata.setVersionName(versionName);
				updateAssetInstVersiondata.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				if (log.isTraceEnabled()) {
					log.trace("saveDependency ||call dao method updateAivUpdatedOn() to update asset instance version data");
				}
				assetInstanceVersionDao.updateAivUpdatedOn(updateAssetInstVersiondata,Long.parseLong(assetInstanceVersion.getSrcAssetInstanceVersionId()), conn);

				if (log.isTraceEnabled()) {
					log.trace("saveDependency ||call Helper method retFwdDependents() to get srcassetinstanceversion dependents");
				}
				List<AssetInstance> aivos = retFwdDependents(assetInstanceVersion,conn);
				String newRelationshipDataForRevision ="";
				int i = 1;
				for(AssetInstance aivo : aivos){
					AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
					if(i == aivos.size()){
						if(!assetDef.isVersionable()){
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]";	
						}else{
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]";	
						}	
					}else{
						if(!assetDef.isVersionable()){
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
						}else{
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
						}
					}
					i++;
				}
				if (log.isTraceEnabled()) {
					log.trace("saveDependency ||call dao method retProfileForUserName() to get user profile data for specific user");
				}
				user = userDao.retProfileForUserName(userName, conn);
				if (log.isTraceEnabled()) {
					log.trace("saveDependency ||call method addRevisionData() to add revision data");
				}
				assetInstanceVersionsManager.addRevisionData("R",Long.parseLong(assetInstanceVersion.getSrcAssetInstanceVersionId()),versionName,null, 
						newRelationshipDataForRevision, null, null,userName,user.getUserId(),conn);

				if (log.isTraceEnabled()) {
					log.trace("saveDependency ||call method getAssetsByAssetId() to get asset details by assetid");
				}
				AssetDef asset = assetDao.getAssetsByAssetId(assetInstanceVersion.getAssetId(),conn);


				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				String mailTemp = null;
				if (log.isTraceEnabled()) {
					log.trace("saveDependency ||call method getAllSubscriptionsByAssetInstanceId() to get all subscribed mail ids by asssetInstanceId");
				}
				List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstanceVersion.getAssetInstanceId(),conn);
				if(asset.isVersionable()){
					if (log.isTraceEnabled()) {
						log.trace("saveDependency ||call method retMailTemplateByTextName() to get specific mailtemplate");
					}
					MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"saveDependenciesForVersionableAsset");
					mailTemp = mtVo1.getMailTemplate();
					String instName = assetInstanceVersion.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					instName = URLDecoder.decode(instName, "UTF-8");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstanceVersion.getVersionName());
				}
				else{
					if (log.isTraceEnabled()) {
						log.trace("saveDependency ||call method retMailTemplateByTextName() to get specific mailtemplate");
					}
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"saveDependenciesForNonVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstanceVersion.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%",instName);
				}
				if(emailIds!=null){
					for(String emailId:emailIds){
						if(asset.isVersionable())
						{
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.RELATIONSHIP_DATA_MODIFIED_SUCCESSFULLY),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
						else
						{
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.RELATIONSHIP_DATA_MODIFIED_SUCCESSFULLY),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
					}
				}

				RecentActivityDao recentActivityDao = new RecentActivityDao();
				RecentActivity recentActivity = new RecentActivity();
				if(asset.isVersionable() == true){
					recentActivity.setUserName(user.getFullName());
					recentActivity.setAction("updated");
					recentActivity.setAssetName(assetInstanceVersion.getAssetName());
					recentActivity.setAssetInstName(assetInstanceVersion.getAssetInstName());
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(assetInstanceVersion.getSrcAssetInstanceVersionId());
					String log = user.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
							+ ";" + recentActivity.getAssetInstName() + ";" + "version"+assetInstanceVersion.getVersionName(); 
					recentActivity.setDescription(log);
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setUser_id(user.getUserId());

				}
				else{
					recentActivity.setUserName(user.getFullName());
					recentActivity.setAction("updated");
					recentActivity.setAssetName(assetInstanceVersion.getAssetName());
					recentActivity.setAssetInstName(assetInstanceVersion.getAssetInstName());
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(assetInstanceVersion.getSrcAssetInstanceVersionId());
					String log = user.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
							+ ";" + recentActivity.getAssetInstName(); 
					recentActivity.setDescription(log);
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setUser_id(user.getUserId());

				}
				if (log.isTraceEnabled()) {
					log.trace("saveDependency ||call method addRecentActivity() to add recent activity details");
				}
				recentActivityDao.addRecentActivity(recentActivity,conn);

				conn.commit();
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_DATA_UPDATED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				if (log.isInfoEnabled()) {
					log.info("saveDependency||dependency  details inserted successfully");
				}

			}catch (RepoproException e) {
				log.error("saveDependency: SQL Exception addAssetInstance: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			}catch (Exception e) {
				log.error("saveDependency: SQL Exception addAssetInstance: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				e.printStackTrace();
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("saveDependency : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}

			if (log.isTraceEnabled()) {
				log.trace("saveDependency ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Exit");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

		}
	}
*/
	
	/**
	 * @method saveDependency
	 * @description to save relationship dependency
	 * @param assetInstanceVersion
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@POST
	@Encoded
	@Path("/saveDependency")
	public Response saveDependency(AssetInstanceVersion assetInstanceVersion,
			@QueryParam("userName") String userName){
		if (assetInstanceVersion == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("saveDependency ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Begin");
			}
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;

			try {
				String assetInstName = URLDecoder.decode(assetInstanceVersion.getAssetInstName(), "UTF-8");
				assetInstanceVersion.setAssetInstName(assetInstName);
				String assetName = URLDecoder.decode(assetInstanceVersion.getAssetName(), "UTF-8");
				assetInstanceVersion.setAssetName(assetName);		
				
				if (log.isTraceEnabled()) {
					log.trace("saveDependency : "+ Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				
				Response response = saveDependencyHelper(assetInstanceVersion, userName, false, conn);
				return response;
			}catch (RepoproException e) {
				log.error("saveDependency: SQL Exception addAssetInstance: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				
			}catch (Exception e) {
				log.error("saveDependency: SQL Exception addAssetInstance: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				e.printStackTrace();
			
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("saveDependency : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				if(conn != null){
					DBConnection.closeDbConnection(conn);
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("saveDependency ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Exit");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

		}
	}
	
	public Response saveDependencyHelper(AssetInstanceVersion assetInstanceVersion,String userName,Boolean importFlag,Connection conn)throws RepoproException{
		if (assetInstanceVersion == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("saveDependencyHelper ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Begin");
			}
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn1 = null;

			String versionName = assetInstanceVersion.getVersionName();
			AssetDao assetDao = new AssetDao();
			UserDao userDao = new UserDao();
			User user = new User();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			SubscriptionDao subscriptionDao = new SubscriptionDao();
			AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
			try {
				/*String assetInstName = URLDecoder.decode(assetInstanceVersion.getAssetInstName(), "UTF-8");
				assetInstanceVersion.setAssetInstName(assetInstName);
				String assetName = URLDecoder.decode(assetInstanceVersion.getAssetName(), "UTF-8");
				assetInstanceVersion.setAssetName(assetName);		
				*/
				if (log.isTraceEnabled()) {
					log.trace("saveDependencyHelper : "+ Constants.LOG_CONNECTION_OPEN);
				}
				if(conn == null){
					conn1 = DBConnection.getInstance().getConnection();
					conn = conn1;
				}
				conn.setAutoCommit(false);
				if(assetInstanceVersion.getRemovedDestAssetInstVersionIds().size() == 0 && assetInstanceVersion.getAddDestAssetInstVersionIds().size() == 0){
					return Response
							.status(Status.OK)
							.entity(new MyModel(Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.ASSET_DATA_NOT_PROVIDED))).build();
				}

				if(assetInstanceVersion.getRemovedDestAssetInstVersionIds().size() > 0 && assetInstanceVersion.getRemovedRelationshipIds().size() > 0 ){
					if (log.isTraceEnabled()) {
						log.trace("saveDependencyHelper ||call helper method removeDependency() to remove DestAssetInstVersionIds");
					}
					removeDependency(assetInstanceVersion,userName,conn);
				}

				if(assetInstanceVersion.getAddDestAssetInstVersionIds().size() > 0 && assetInstanceVersion.getAddRelationshipIds().size() > 0){
					if (log.isTraceEnabled()) {
						log.trace("saveDependencyHelper ||call helper method addDependency() to add DestAssetInstVersionIds");
					}
					addDependency(assetInstanceVersion, userName,conn);
				}


				AssetInstanceVersion updateAssetInstVersiondata = new AssetInstanceVersion();

				updateAssetInstVersiondata.setVersionName(versionName);
				updateAssetInstVersiondata.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				if (log.isTraceEnabled()) {
					log.trace("saveDependencyHelper ||call dao method updateAivUpdatedOn() to update asset instance version data");
				}
				assetInstanceVersionDao.updateAivUpdatedOn(updateAssetInstVersiondata,Long.parseLong(assetInstanceVersion.getSrcAssetInstanceVersionId()), conn);

				if (log.isTraceEnabled()) {
					log.trace("saveDependencyHelper ||call dao method retProfileForUserName() to get user profile data for specific user");
				}
				user = userDao.retProfileForUserName(userName, conn);
				
				if(importFlag == false){
					if (log.isTraceEnabled()) {
						log.trace("saveDependencyHelper ||call Helper method retFwdDependents() to get srcassetinstanceversion dependents");
					}
					List<AssetInstance> aivos = retFwdDependents(assetInstanceVersion,conn);
					String newRelationshipDataForRevision ="";
					int i = 1;
					for(AssetInstance aivo : aivos){
						AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
						if(i == aivos.size()){
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]";	
							}	
						}else{
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
							}
						}
						i++;
					}

					if (log.isTraceEnabled()) {
						log.trace("saveDependencyHelper ||call method addRevisionData() to add revision data");
					}
					assetInstanceVersionsManager.addRevisionData("R",Long.parseLong(assetInstanceVersion.getSrcAssetInstanceVersionId()),versionName,null, 
							newRelationshipDataForRevision, null, null,userName,user.getUserId(),null,conn);
				}
				if (log.isTraceEnabled()) {
					log.trace("saveDependencyHelper ||call method getAssetsByAssetId() to get asset details by assetid");
				}
				AssetDef asset = assetDao.getAssetsByAssetId(assetInstanceVersion.getAssetId(),conn);

				if(importFlag == false){
					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					String mailTemp = null;
					if (log.isTraceEnabled()) {
						log.trace("saveDependencyHelper ||call method getAllSubscriptionsByAssetInstanceId() to get all subscribed mail ids by asssetInstanceId");
					}
					List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(assetInstanceVersion.getAssetInstanceId(),conn);
					if(asset.isVersionable()){
						if (log.isTraceEnabled()) {
							log.trace("saveDependencyHelper ||call method retMailTemplateByTextName() to get specific mailtemplate");
						}
						MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"saveDependenciesForVersionableAsset");
						mailTemp = mtVo1.getMailTemplate();
						String instName = assetInstanceVersion.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						instName = URLDecoder.decode(instName, "UTF-8");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstanceVersion.getVersionName());
					}
					else{
						if (log.isTraceEnabled()) {
							log.trace("saveDependencyHelper ||call method retMailTemplateByTextName() to get specific mailtemplate");
						}
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"saveDependenciesForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstanceVersion.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%",instName);
					}
					if(emailIds!=null){
						for(String emailId:emailIds){
							if(asset.isVersionable())
							{
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.RELATIONSHIP_DATA_MODIFIED_SUCCESSFULLY),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
							else
							{
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.RELATIONSHIP_DATA_MODIFIED_SUCCESSFULLY),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
						}
					}
				}
				if(importFlag == false){
					RecentActivityDao recentActivityDao = new RecentActivityDao();
					RecentActivity recentActivity = new RecentActivity();
					if(asset.isVersionable() == true){
						recentActivity.setUserName(user.getFullName());
						recentActivity.setAction("updated");
						recentActivity.setAssetName(assetInstanceVersion.getAssetName());
						recentActivity.setAssetInstName(assetInstanceVersion.getAssetInstName());
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(assetInstanceVersion.getSrcAssetInstanceVersionId());
						String log = user.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
								+ ";" + recentActivity.getAssetInstName() + ";" + "version"+assetInstanceVersion.getVersionName(); 
						recentActivity.setDescription(log);
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setUser_id(user.getUserId());

					}
					else{
						recentActivity.setUserName(user.getFullName());
						recentActivity.setAction("updated");
						recentActivity.setAssetName(assetInstanceVersion.getAssetName());
						recentActivity.setAssetInstName(assetInstanceVersion.getAssetInstName());
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(assetInstanceVersion.getSrcAssetInstanceVersionId());
						String log = user.getFullName() + ";" + recentActivity.getAction() + ";" + recentActivity.getAssetName() 
								+ ";" + recentActivity.getAssetInstName(); 
						recentActivity.setDescription(log);
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setUser_id(user.getUserId());

					}
					if (log.isTraceEnabled()) {
						log.trace("saveDependencyHelper ||call method addRecentActivity() to add recent activity details");
					}
					recentActivityDao.addRecentActivity(recentActivity,conn);
				}
				if(importFlag == false){
					conn.commit();
				}
				retStat = Status.OK;
				retMsg = Constants.ASSET_INSTANCE_DATA_UPDATED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				if (log.isInfoEnabled()) {
					log.info("saveDependencyHelper||dependency  details inserted successfully");
				}

			}catch (RepoproException e) {
				log.error("saveDependencyHelper: SQL Exception addAssetInstance: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					if(importFlag == false){
						conn.rollback();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
					throw new RepoproException(e1.getMessage());
				}
				throw new RepoproException(e.getMessage());
			}catch (Exception e) {
				log.error("saveDependencyHelper: SQL Exception addAssetInstance: "
						+ Constants.LOG_EXCEPTION + e.getMessage());
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				e.printStackTrace();
				try {
					if(importFlag == false){
						conn.rollback();
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
					throw new RepoproException(e1.getMessage());
				}
				throw new RepoproException(e.getMessage());
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("saveDependencyHelper : "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				if(importFlag == false){
					DBConnection.closeDbConnection(conn);
				}
				if(conn1 != null){
					DBConnection.closeDbConnection(conn1);
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("saveDependencyHelper ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Exit");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

		}
	}
	
	
	
	public void removeDependency(AssetInstanceVersion assetInstanceVersion,String userName,Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("removeDependency ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Begin");
		}
	 	String versionName = Constants.DEFAULT_VERSION;
		Connection conn1 = null;
		RelationshipDao  relationshipDao = new RelationshipDao();
		AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();
		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("removeDependency : "+ Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			versionName = assetInstanceVersion.getVersionName();
			AssetDao assetDao = new AssetDao();
			UserDao userDao = new UserDao();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			User user = new User();
			if (log.isTraceEnabled()) {
				log.trace("removeDependency ||call dao method retProfileForUserName() to get user details");
			}
			user = userDao.retProfileForUserName(userName, conn);
			AssetRelationshipDef assetRelationshipDef =  new AssetRelationshipDef();
			RelationshipDef relationshipDef =  new RelationshipDef();
			AssetInstanceVersion assetInstanceVersiondata = new AssetInstanceVersion();

			if (log.isTraceEnabled()) {
				log.trace("removeDependency ||call dao method getAssetsByAssetId() to get asset details");
			}
			AssetDef srcAssetDef = assetDao.getAssetsByAssetId(assetInstanceVersion.getAssetId(),conn);
			int i = 0;
			for(Long destAssetInstVersionId : assetInstanceVersion.getRemovedDestAssetInstVersionIds())
			{
				Long assetRelationshipId = assetInstanceVersion.getRemovedRelationshipIds().get(i);
				if(destAssetInstVersionId != null)
				{
					
					if (log.isTraceEnabled()) {
						log.trace("removeDependency ||call dao method deleteAssetInstRelationship() to remove asset instance relationship");
					}
					int result = relationshipDao.deleteAssetInstRelationship(assetInstanceVersion.getSrcAssetInstanceVersionId(),destAssetInstVersionId,assetRelationshipId,conn);

					if (log.isTraceEnabled()) {
						log.trace("removeDependency ||call dao method retAssetRelDefById() to get fwdrelationship id");
					}
					assetRelationshipDef = relationshipDao.retAssetRelDefById(assetRelationshipId, conn);

					if (log.isTraceEnabled()) {
						log.trace("removeDependency ||call dao method getRelationshipsByRelId() to get fwdrelationship name");
					}
					relationshipDef = relationshipDao.getRelationshipsByRelId(assetRelationshipDef.getFwdRelId(), conn);
					if (log.isTraceEnabled()) {
						log.trace("removeDependency ||call helper method getAssetInstanceVersionDetails() to get version data");
					}
					assetInstanceVersiondata = assetInstanceVersionDao.getAssetInstanceVersionDetails(destAssetInstVersionId, conn1);
					String removedText = "";
					if(!srcAssetDef.isVersionable()){
						removedText = assetInstanceVersion.getAssetInstName()+"("+relationshipDef.getRelationName()+")";
					}else{
						removedText = assetInstanceVersion.getAssetInstName()+"_"+assetInstanceVersion.getVersionName()+"("+relationshipDef.getRelationName()+")";
					}
					if (log.isTraceEnabled()) {
						log.trace("removeDependency ||call helper method removeUsedByData() to update revision history");
					}
					assetInstanceVersionManager.removeUsedByData(assetInstanceVersiondata.getVersionName(), destAssetInstVersionId, user.getUserId(), removedText, userName, conn);
				}i++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally {
			if(conn1 != null){
			if (log.isTraceEnabled()) {
				log.trace("removeDependency : "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		}
		if (log.isTraceEnabled()) {
			log.trace("removeDependency ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Exit");
		}
	}

	public void addDependency(AssetInstanceVersion assetInstanceVersion,String userName,Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addDependency ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Begin");
		}
		String versionName = Constants.DEFAULT_VERSION;
		Connection conn1 = null;
		RelationshipDao  relationshipDao = new RelationshipDao();
		AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();
		AssetRelationshipDef assetRelationshipDef =  new AssetRelationshipDef();
		RelationshipDef relationshipDef =  new RelationshipDef();
		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("addDependency : "+ Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			versionName = assetInstanceVersion.getVersionName();
			AssetDao assetDao = new AssetDao();
			AssetInstRelationship assetInstRelationship = new AssetInstRelationship();
			UserDao userDao = new UserDao();
			User user = new User();

			if (log.isTraceEnabled()) {
				log.trace("addDependency ||call helper method retProfileForUserName() to get user data by username");
			}
			user = userDao.retProfileForUserName(userName, conn);

			assetInstRelationship.setSrcAssetInstVersionId(Long.parseLong(assetInstanceVersion.getSrcAssetInstanceVersionId()));

			if (log.isTraceEnabled()) {
				log.trace("addDependency ||call dao method getAssetsByAssetId() to get asset data");
			}
			AssetDef srcAssetDef = assetDao.getAssetsByAssetId(assetInstanceVersion.getAssetId(),conn);
			int i = 0;
			for(Long destAssetInstVersionId : assetInstanceVersion.getAddDestAssetInstVersionIds())
			{
				Long assetRelationshipId = assetInstanceVersion.getAddRelationshipIds().get(i);
				if(destAssetInstVersionId != null)
				{

					assetInstRelationship.setDestAssetInstVersionId(destAssetInstVersionId);
					assetInstRelationship.setAssetRelId(assetRelationshipId);
					if (log.isTraceEnabled()) {
						log.trace("addDependency ||call dao method addAssetInstRelationship() to add asset instance relationship");
					}
					relationshipDao.addAssetInstRelationship(assetInstRelationship,conn);

					if (log.isTraceEnabled()) {
						log.trace("addDependency ||call dao method retAssetRelDefById() to get fwd relationship id");
					}
					assetRelationshipDef = relationshipDao.retAssetRelDefById(assetRelationshipId, conn);

					if (log.isTraceEnabled()) {
						log.trace("addDependency ||call dao method addAssetInstRelationship() to get fwdrelationship name");
					}
					relationshipDef = relationshipDao.getRelationshipsByRelId(assetRelationshipDef.getFwdRelId(), conn);

					String addedText = "";
					if(!srcAssetDef.isVersionable()){
						addedText = assetInstanceVersion.getAssetInstName()+"("+relationshipDef.getRelationName()+")";
					}else{
						addedText = assetInstanceVersion.getAssetInstName()+"_"+assetInstanceVersion.getVersionName()+"("+relationshipDef.getRelationName()+")";
					}
					if (log.isTraceEnabled()) {
						log.trace("addDependency ||call helper method addUsedByData() to update revision history");
					}
					assetInstanceVersionManager.addUsedByData(destAssetInstVersionId,user.getUserId(),addedText, conn);
				}i++;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally {
			if(conn1 != null){
			if (log.isTraceEnabled()) {
				log.trace("addDependency : "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		}

		if (log.isTraceEnabled()) {
			log.trace("addDependency ||" + assetInstanceVersion.toString()+"username:"+userName+"|| Exit");
		}
	}

	public List<AssetInstance> retFwdDependents(AssetInstanceVersion assetInstanceVersion,Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("retFwdDependents ||" + assetInstanceVersion.toString()+"|| Begin");
		}
		Connection conn1 = null;
		RelationshipDao  relationshipDao = new RelationshipDao();
		List<AssetInstance> assetinstancelist = new ArrayList<AssetInstance>();
		AssetInstance assetInstance = null;
		try {

			if (log.isTraceEnabled()) {
				log.trace("retFwdDependents : "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			List<AssetInstRelationship> airs = null;
			if (log.isTraceEnabled()) {
				log.trace("retFwdDependents || call of dao method retFwdRelationsForAnAssetInstanceVersionId()");
			}
			airs = relationshipDao.retFwdRelationsForAnAssetInstanceVersionId(Long.parseLong(assetInstanceVersion.getSrcAssetInstanceVersionId()), conn);

			for(AssetInstRelationship air : airs){
				assetInstance = new AssetInstance();
				assetInstance.setAssetInstId(air.getAssetInstanceId());
				assetInstance.setAssetInstVersionId(air.getDestAssetInstVersionId());
				assetInstance.setAssetInstName(air.getAssetInstanceName());
				assetInstance.setAssetRelationshipName(air.getDescrption());
				assetInstance.setAssetRelationshipId(air.getAssetrelationShipId().toString());
				assetInstance.setAssetName(air.getAssetName());
				assetInstance.setVersionName(air.getVersionName());
				assetInstance.setAssetId(air.getAssetId());
				assetinstancelist.add(assetInstance);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally {
			if (log.isTraceEnabled()) {
				log.trace("retFwdDependents : "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("retFwdDependents ||" + assetInstanceVersion.toString()+"|| Exit");
		}		
		return assetinstancelist;
	}

	/**
	 * @method : updatePublicAccessValueForAssetInstance
	 * @description : to update public access value for an asset instance
	 * @param assetId
	 * @param assetInstanceId
	 * @param options
	 * @return
	 */
	@PUT
	@Path("/updatePublicAccessVal")
	public Response updatePublicAccessValueForAssetInstance(@QueryParam("assetId") Long assetId, 
			@QueryParam("assetInstanceId") long assetInstanceId,
			@QueryParam("options")String options){

		if(log.isTraceEnabled()){
			log.trace("updatePublicAccessVal || Begin with assetId : "+ assetId + " ,assetInstanceId : "+ assetInstanceId +",options : "+ options);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetDef assetDef = null;
		AssetInstance assetInstance = null;
		AssetDao assetDao = new AssetDao();
		AssetInstanceDao assetInstDao = new AssetInstanceDao();
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();

		try {
			if (log.isTraceEnabled()){
				log.trace("updatePublicAccessVal || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("updatePublicAccessVal || dao method called : getAssetsByAssetId()");
			}
			assetDef = assetDao.getAssetsByAssetId(assetId, conn); 
			log.info("updatePublicAccessVal || retrieved "+ assetDef.toString() 
					+" asset successfully");

			if (log.isTraceEnabled()) {
				log.trace("updatePublicAccessVal || dao method called : getAllAssetInstances()");
			}
			assetInstanceList = assetInstDao.getAllAssetInstances(assetId, conn);
			log.debug("updatePublicAccessVal || retrieved "+ assetInstanceList.size() 
					+" asset instance list retrieved successfully");

			for(AssetInstance assetInst : assetInstanceList){
				if(assetInst.getAssetInstId() == assetInstanceId){
					assetInstance = assetInst;
				}
			}

			/*if(options.equalsIgnoreCase("get")){
				assetInstance.isPublicAccess();
			}else */if(options.equalsIgnoreCase("enableAccess")){
				assetInstance.setPublicAccess(true);
			}else if(options.equalsIgnoreCase("disableAccess")){
				assetInstance.setPublicAccess(false);
			}
			if (log.isTraceEnabled()) {
				log.trace("updatePublicAccessVal || dao method called : updateAssetInstancePublicAccessState()");
			}
			assetInstDao.updateAssetInstancePublicAccessState(assetInstance,conn);
			if (log.isInfoEnabled()) {
				log.info("updatePublicAccessVal || updated : updateAssetInstancePublicAccessState() successfully");
			}

			conn.commit();
			retMsg = Constants.SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			
		}catch (RepoproException e) {
			log.error("updatePublicAccessVal || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
			}catch(Exception e){
			log.error("updatePublicAccessVal || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstances || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstances || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	}

	/**
	 * @method : getPublicAccessValueForAssetInstance
	 * @description : to get public access value for an asset instance
	 * @param assetInstanceId
	 * @returns publicAccess state
	 * @return
	 */
	@GET
	@Path("/getPublicAccessVal")
	public Response getPublicAccessValueForAssetInstance(@QueryParam("assetInstanceId") Long assetInstanceId){

		if(log.isTraceEnabled()){
			log.trace("getPublicAccessValueForAssetInstance || Begin with assetInstanceId : "+ assetInstanceId);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		String publicAccessFlag = "";

		AssetInstanceDao assetInstDao = new AssetInstanceDao();
		List<AssetInstance> assetInsatnceList = new ArrayList<AssetInstance>();
		List<String> jsonList = new ArrayList<String>();
		try {
			if (log.isTraceEnabled()){
				log.trace("getPublicAccessValueForAssetInstance || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getPublicAccessValueForAssetInstance || dao method called : getAssetInstancePublicAccessState()");
			}
			assetInsatnceList = assetInstDao.getAssetInstancePublicAccessState(assetInstanceId, conn);
			for(AssetInstance ai : assetInsatnceList){
				if(ai.isPublicAccess() == true){
					publicAccessFlag = Constants.PUBLIC_ACCESS_TRUE;
				}else{
					publicAccessFlag = Constants.PUBLIC_ACCESS_FALSE;
				}
			}
			log.debug("getPublicAccessValueForAssetInstance || retrieved "+ assetInsatnceList.toString() 
					+" successfully");

			retMsg = Constants.SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			jsonList.add(publicAccessFlag);
			
		}catch (RepoproException e) {
			log.error("getPublicAccessValueForAssetInstance || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getPublicAccessValueForAssetInstance || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getPublicAccessValueForAssetInstance || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("getPublicAccessValueForAssetInstance || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,new ArrayList<Object>(jsonList))).build();
	}

	/**
	 * @method : updateAssetInstanceForSubscriptionNotification
	 * @description : to update asset instance subscription
	 * @param userId
	 * @param assetInstanceId
	 * @return
	 */
	@POST
	@Path("/updateSubscriptionNotification")
	public Response updateAssetInstanceForSubscriptionNotification(@QueryParam("userId") Long userId,
			@QueryParam("assetInstanceId") long assetInstanceId){

		if(log.isTraceEnabled()){
			log.trace("updateAssetInstanceForSubscriptionNotification || Begin with userId : "+userId+" ,assetInstanceId : "+ assetInstanceId);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		AssetInstanceDao assetInstDao = new AssetInstanceDao();

		try {
			if (log.isTraceEnabled()){
				log.trace("updateAssetInstanceForSubscriptionNotification || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceForSubscriptionNotification || dao method called : updateAssetInstSubscription()");
			}
			assetInstDao.updateAssetInstSubscription(userId, assetInstanceId, conn);
			log.info("updateAssetInstanceForSubscriptionNotification || data inserted successfully ");

			conn.commit();
			retMsg = Constants.SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;


		}catch (RepoproException e) {
			log.error("updateAssetInstanceForSubscriptionNotification || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
					
		} catch(Exception e){
			log.error("updateAssetInstanceForSubscriptionNotification || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceForSubscriptionNotification || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("updateAssetInstanceForSubscriptionNotification || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg)).build();
	}

	/**
	 * @method : updateAssetInstanceForUnSubscriptionNotification
	 * @description : to unsubscribe asset instance
	 * @param userId
	 * @param assetInstanceId
	 * @return AssetInstance list
	 */
	@DELETE
	@Path("/updateUnSubscriptionNotification")
	public Response updateAssetInstanceForUnSubscriptionNotification(@QueryParam("userId") Long userId,
			@QueryParam("assetInstanceId") long assetInstanceId) {

		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceForUnSubscriptionNotification || Begin with userId : "
					+ userId + " ,assetInstanceId : " + assetInstanceId);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		AssetInstanceDao assetInstDao = new AssetInstanceDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceForUnSubscriptionNotification || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceForUnSubscriptionNotification || dao method called : updateAssetInstSubscription()");
			}
			assetInstDao.deleteAssetInstSubscription(userId, assetInstanceId,
					conn);

			log.info("updateAssetInstanceForSubscriptionNotification || data inserted successfully ");

			conn.commit();
			retMsg = Constants.SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("updateAssetInstanceForUnSubscriptionNotification || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceForUnSubscriptionNotification || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstanceForUnSubscriptionNotification || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/**
	 * @method : getUserAssetInstanceSubscription
	 * @description : to get user asset instance subscription
	 * @param userId
	 * @param assetInstanceId
	 * @return AssetInstance list
	 */
	@GET
	@Path("/getUserAssetInstanceSubscription")
	public Response getUserAssetInstanceSubscription(@QueryParam("userId") Long userId,
			@QueryParam("assetInstanceId") long assetInstanceId){

		if(log.isTraceEnabled()){
			log.trace("getUserAssetInstanceSubscription || Begin with userId : "+userId+" ,assetInstanceId : "+ assetInstanceId);
		}

		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		String subscriptionFlag = "";
		AssetInstanceDao assetInstDao = new AssetInstanceDao();
		List<AssetInstance> assetInstList = new ArrayList<AssetInstance>();
		List<String> jsonList = new ArrayList<String>();

		try {
			if (log.isTraceEnabled()){
				log.trace("getUserAssetInstanceSubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getUserAssetInstanceSubscription || dao method called : getUserAssetInstanceSubscriptionDetails()");
			}
			assetInstList = assetInstDao.getUserAssetInstanceSubscriptionDetails(userId, assetInstanceId, conn);

			retMsg = Constants.SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			if(assetInstList.size() !=  0){
				subscriptionFlag = Constants.SUBSCRIPTION_EXSISTS;
			}else{
				subscriptionFlag = Constants.SUBSCRIPTION_DOESNT_EXSISTS;
			}
			jsonList.add(subscriptionFlag);
			log.info("getUserAssetInstanceSubscription || data retrieved successfully ");

		}catch (RepoproException e) {
			log.error("getUserAssetInstanceSubscription || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getUserAssetInstanceSubscription || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getUserAssetInstanceSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("getUserAssetInstanceSubscription || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,new ArrayList<Object>(jsonList))).build();
	}


	/**
	 * @method getAddAccessForCompositionAndAggregationAssetType
	 * @description to get asset name and access For Composition And Aggregation Asset Type 
	 * @param assetId , userName 
	 * @return success response
	 * @throws RepoproException
	 */

	@GET
	@Path("/getAddAccessForCompositionAndAggregationAssetType")
	public Response getAddAccessForCompositionAndAggregationAssetType(@QueryParam("assetId") long assetId, 
			@QueryParam("userName") String userName) {

		if (log.isTraceEnabled()) {
			log.trace("getAddAccessForCompositionAndAggregationAssetType || begin  with assetId : "
					+ assetId + " userName : " + userName);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		Connection conn = null;
		List<GroupAssetAccess> assetGroupAccessList = new ArrayList<GroupAssetAccess>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAddAccessForCompositionAndAggregationAssetType || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getAddAccessForCompositionAndAggregationAssetType || dao method called : getAddAccessForCompositionAndAggregationAssetType by assetId: "
						+ assetId + "and userName" + userName);
			}

			assetGroupAccessList = assetInstanceDao
					.getAddAccessForCompositionAndAggregationAssetType(assetId,
							userName, conn);

			if (log.isInfoEnabled()) {
				log.info(" getAddAccessForCompositionAndAggregationAssetType  || retrieved "
						+ assetGroupAccessList.size() + " assets successfully ");
			}
			if (assetGroupAccessList.isEmpty()) {
				GroupAssetAccess groupAssetAccess = new GroupAssetAccess();
				groupAssetAccess.setAddAccess(0L);
				assetGroupAccessList.add(groupAssetAccess);
			}
		
			retStat = Status.OK;
			retMsg = Constants.ADD_ACCESS_FOR_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getAddAccessForCompositionAndAggregationAssetType || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAddAccessForCompositionAndAggregationAssetType || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAddAccessForCompositionAndAggregationAssetType || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAddAccessForCompositionAndAggregationAssetType || End ");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetGroupAccessList))).build();

	}

	/**
	 * @method getdestAssetAccessForCompositionAndAggregationType
	 * @description to get access For Composition And Aggregation Asset Type 
	 * @param assetId  
	 * @return success response
	 * @throws RepoproException
	 */

	@GET
	@Path("/getdestAssetAccessForCompositionAndAggregationType")
	public Response getdestAssetAccessForCompositionAndAggregationType(@QueryParam("assetId") long assetId){

		if (log.isTraceEnabled()) {
			log.trace("getdestAssetAccessForCompositionAndAggregationType || begin  with assetId : "
					+ assetId);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetRelationshipDef> ardForDestAsset = new ArrayList<AssetRelationshipDef>();
		AssetRelationshipDef relationship = new AssetRelationshipDef();
		Connection conn = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getdestAssetAccessForCompositionAndAggregationType || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getdestAssetAccessForCompositionAndAggregationType || dao call of retAssetRelationshipDefByDestAssetId() "
						+ "method to get list of asset relationship by destination asset id");
			}
			ardForDestAsset = relationshipDao
					.retAssetRelationshipDefByDestAssetId(assetId, conn);

			if (ardForDestAsset.isEmpty()){
				relationship.setAssetRelId(0L);
				relationship.setSrcAssetId(0L);
				relationship.setDestAssetId(0L);
				relationship.setFwdRelId(0L);
				relationship.setBwdRelId(0L);
				ardForDestAsset.add(relationship);
			}
				retStat = Status.OK;
				retMsg = Constants.DEST_ASSET_ACCESS_FOR_COMPOSITION_AND_AGGREGATION_ASSET_TYPE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			

			if (log.isDebugEnabled()) {
				log.debug(" getdestAssetAccessForCompositionAndAggregationType  || retrieved "+ ardForDestAsset.size()+ " asset relationship successfully ");
			}
		} catch (RepoproException e) {
			log.error("getdestAssetAccessForCompositionAndAggregationType || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getdestAssetAccessForCompositionAndAggregationType || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getdestAssetAccessForCompositionAndAggregationType || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getdestAssetAccessForCompositionAndAggregationType || End ");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(ardForDestAsset)))
						.build();

	}

	/**
	 * @method : getAllAssetInstanceNamesByAssetId
	 * @description : to get all the asset instances
	 * @param assetId
	 * @return List<AssetInstanceNames>
	 */
	@GET
	@Path("/getAllAssetInstanceNamesByAssetId")
	public Response getAllAssetInstanceNamesByAssetId(@QueryParam("assetId") Long mappedAssetId,@QueryParam("userName") String userName) {

		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstanceNamesByAssetId || Begin with assetId : "+ mappedAssetId);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceDao dao = new AssetInstanceDao();
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		List<String> AssetInstanceNames = new ArrayList<String>();

		try {
			if (log.isTraceEnabled()){
				log.trace("getAllAssetInstanceNamesByAssetId || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceNamesByAssetId || dao method called : getAllAssetInstances()");
			}

			AssetInstanceNames = dao.getAllAssetInstancesMain(mappedAssetId,userName, conn);

			/*for(AssetInstance aiList : assetInstanceList ){

				AssetInstanceNames.add(aiList.getAssetInstName());
			}*/
			log.info("getAllAssetInstanceNamesByAssetId || retrieved "+ assetInstanceList.size() 
					+" asset instances names successfully");

		} catch (RepoproException e) {
			log.error("getAllAssetInstanceNamesByAssetId || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getAllAssetInstanceNamesByAssetId || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceNamesByAssetId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (AssetInstanceNames.isEmpty()) {
			retMsg = Constants.ASSET_INSTANCE_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_ASSET_INSTANCES_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstanceNamesByAssetId || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(AssetInstanceNames))).build();
	}

	/**
	 * @method : getAssetAccessForGuestUser
	 * @description : to get asset and instance access
	 * @param assetInstVersionId
	 * @return 
	 */
	@GET
	@Path("/getAssetInstanceAccessForGuestAndLoginUser")
	public Response getAssetInstanceAccessForGuestAndLoginUser(
			@QueryParam("userName") String userName,
			@QueryParam("assetInstVersionId") Long assetInstVersionId) {

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceAccessForGuestAndLoginUser || Begin with assetInstVersionId : "
					+ assetInstVersionId);
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceDao dao = new AssetInstanceDao();
		AssetInstanceVersionDao aiv = new AssetInstanceVersionDao();
		AssetInstance assetInstance = new AssetInstance();
		ArrayList<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAccessForGuestAndLoginUser || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			Boolean flag = false;

			if (userName.equalsIgnoreCase("roleAnonymous")) {

				if (log.isTraceEnabled()) {
					log.trace("getAssetInstanceAccessForGuestAndLoginUser ||  called dao method  : getAssetInstanceAccessForGuest()");
				}
				Boolean flagForGuest = dao.getAssetInstanceAccessForGuest(assetInstVersionId, conn);
				assetInstance.setPublicAccess(flagForGuest);
				assetInstanceList.add(assetInstance);
			} else {
				if (log.isTraceEnabled()) {
					log.trace("getAssetInstanceAccessForGuestAndLoginUser ||  called dao method  : findAdminRightsByUserName() to get admin rights for user");
				}
				flag = aiv.findAdminRightsByUserName(userName, conn);
				if (flag) {
					assetInstance.setPublicAccess(flag);
				} else {
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceAccessForGuestAndLoginUser ||  called dao method  : getAssetInstanceAccessForLoginUser()");
					}
					Boolean flagForuser = false;
					List<GroupAssetAccess> gaList =  dao.getAssetInstanceAccessForLoginUser(assetInstVersionId, userName, conn);
					
					for(GroupAssetAccess ga : gaList){
						if(ga.getViewAccess() == 1L){
							flagForuser = true;
							break;
						}
					}
					assetInstance.setPublicAccess(flagForuser);
				}
				assetInstanceList.add(assetInstance);
			}

			log.debug("getAssetInstanceAccessForGuestAndLoginUser || retrieved "+ assetInstanceList.toString() 
					+" asset instance level access successfully");

		} catch (RepoproException e) {
			log.error("getAssetInstanceAccessForGuestAndLoginUser || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceAccessForGuestAndLoginUser || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceAccessForGuestAndLoginUser || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (assetInstanceList.isEmpty()) {
			retMsg = Constants.ASSET_INSTANCE_ACCESS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ASSET_INSTANCE_ACCESS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		if (log.isTraceEnabled()) {
			log.trace("getAssetInstanceAccessForGuestAndLoginUser || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetInstanceList))).build();
	}

	
	
	/**
	 * @method : getAssetLevelAddAccessForLoginUser
	 * @description : to get asset level add access 
	 * @param userName
	 * @param assetName
	 * @return 
	 */
	@GET
	@Path("/getAssetLevelAddAccessForLoginUser")
	public Response getAssetLevelAddAccessForLoginUser(
			@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName) {

		if (log.isTraceEnabled()) {
			log.trace("getAssetLevelAddAccessForLoginUser || Begin with assetName : "
					+ assetName +" and userName" +userName);
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceDao dao = new AssetInstanceDao();
		AssetInstanceVersionDao aiv = new AssetInstanceVersionDao();
		AssetInstance assetInstance = new AssetInstance();
		ArrayList<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetLevelAddAccessForLoginUser || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			Boolean flag = false;

			
				if (log.isTraceEnabled()) {
					log.trace("getAssetLevelAddAccessForLoginUser ||  called dao method  : findAdminRightsByUserName() to get admin rights for user");
				}
				flag = aiv.findAdminRightsByUserName(userName, conn);
				if (flag) {
					assetInstance.setEditAccessFlag(flag);
					assetInstance.setDeleteAccessFlag(flag);
					assetInstance.setAddAccessFlag(flag);
					assetInstanceList.add(assetInstance);	
				} else {
					if (log.isTraceEnabled()) {
						log.trace("getAssetLevelAddAccessForLoginUser ||  called dao method  : getAssetInstanceAccessForLoginUser()");
					}
					AssetInstance ai = dao
							.getAssetLevelAddAccessForLoginUser(
									assetName, userName, conn);
					assetInstanceList.add(ai);	

				}
			
			log.debug("getAssetLevelAddAccessForLoginUser || retrieved "+ assetInstanceList.toString() 
					+" asset instance level access successfully");

		} catch (RepoproException e) {
			log.error("getAssetLevelAddAccessForLoginUser || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetLevelAddAccessForLoginUser || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetLevelAddAccessForLoginUser || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (assetInstanceList.isEmpty()) {
			retMsg = Constants.ASSET_INSTANCE_ACCESS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ASSET_INSTANCE_ACCESS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		if (log.isTraceEnabled()) {
			log.trace("getAssetLevelAddAccessForLoginUser || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetInstanceList))).build();
	}

	/**
	 * @method : getAssetAccessForGuestUser
	 * @description : to get asset access for guest user
	 * @param assetInstVersionId
	 * @return 
	 */
	@GET
	@Path("/getAssetAccessForGuestUser")
	public Response getAssetAccessForGuestUser(
			@QueryParam("userName") String userName,
			@QueryParam("assetId") Long assetId) {

		if (log.isTraceEnabled()) {
			log.trace("getAssetAccessForGuestUser || Begin with assetId : "
					+ assetId + "and userName"+userName);
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
     	AssetDao assetDao = new AssetDao ();
		AssetDef ad = new AssetDef();
		List<AssetDef> assetList = new ArrayList<AssetDef>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetAccessForGuestUser || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			//Boolean flag = false;

			if (userName.equalsIgnoreCase("roleAnonymous")) {

				if (log.isTraceEnabled()) {
					log.trace("getAssetAccessForGuestUser ||  called dao method  : getAssetInstanceAccessForGuest()");
				}
				ad = assetDao.getAssetsByAssetId(assetId, conn);
				assetList.add(ad);
			} /*else {
				
			}*/

			log.info("getAssetAccessForGuestUser || retrieved asset  level guest access successfully");

		} catch (RepoproException e) {
			log.error("getAssetAccessForGuestUser || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} catch (Exception e) {
			log.error("getAssetAccessForGuestUser || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetAccessForGuestUser || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (assetList.isEmpty()) {
			retMsg = Constants.ASSET_GUEST_ACCESS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ASSET_GUEST_ACCESS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		if (log.isTraceEnabled()) {
			log.trace("getAssetAccessForGuestUser || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetList))).build();
	}
	
/***Wrapper function***/
	/*@GET
	@Path("/getAssetAccessForGuestUserMain")
	public Response getAssetAccessForGuestUserMain(
			@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName) {
		log.trace("getAssetAccessForGuestUserMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetAccessForGuestUserMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AssetDef ad = new AssetDef ();
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			AssetDao assetDao = new AssetDao();
			
			ad = assetDao.getAssetsByAssetName(assetName, conn);
			
			if (ad.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getAssetAccessForGuestUserMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			response = this.getAssetAccessForGuestUser(userName,ad.getAssetId());

			log.trace("getAssetAccessForGuestUserMain || End");
			return response;


		} catch (RepoproException e) {
			log.error("getAssetAccessForGuestUserMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetAccessForGuestUserMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetAccessForGuestUserMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getAssetAccessForGuestUserMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();		
	}*/

	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/getAssetInstanceSubscriptionStatus")
	public Response getAllAssetInstancesForSubscriptionMain(@QueryParam("assetName") String assetName, 
			@HeaderParam("token") String token,
			@QueryParam("from") String from) {
		if(assetName == null  || from == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}

		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(assetName.isEmpty() || from.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("getAllAssetInstancesForSubscriptionMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		assetName = assetName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesForSubscriptionMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			int fromrange = Integer.parseInt(from);
			conn = DBConnection.getInstance().getConnection();
			UserDao userDao = new UserDao();
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();			
			}else{
				User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("getAllAssetInstancesForSubscriptionMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
				AssetDef ad = new AssetDef ();
                AssetDao assetDao =new AssetDao();
		    	ad = assetDao.getAssetsByAssetName(assetName, conn);
		    	if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("getAllAssetInstancesForSubscriptionMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
		    	response = this.getAllAssetInstances(ad.getAssetId(),user.getUserId(),fromrange);
		    	
		    	MyModel res = (MyModel) response.getEntity();

				List<Object> data = res.getResult();
				JSONObject j1 = null;
				JSONObject json = new JSONObject();
				List<Object> finaldata = new ArrayList<Object>();
				for (int i = 0; i < data.size(); i++) {
					j1 = new JSONObject();
					UserAssetInstanceSubscription uais = new UserAssetInstanceSubscription();
					uais = (UserAssetInstanceSubscription) data.get(i);

					j1.put("userId", uais.getUserId());
					j1.put("assetInstanceId", uais.getAssetInstanceId());
					j1.put("assetInstanceName", uais.getAssetInstanceName());
					j1.put("subscriptionFlag", uais.getSubscriptionFlag());
					j1.put("iconImageName",uais.getIconImageName());

					finaldata.add(j1);

				}
				json.put("result", finaldata);
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());

				log.trace("getAllAssetInstancesForSubscriptionMain || End");
				return Response.status(retStat).entity(json.toString())
						.build();
		    	
			}
			
		} catch (RepoproException e) {
			log.error("getAllAssetInstancesForSubscriptionMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllAssetInstancesForSubscriptionMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesForSubscriptionMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllAssetInstancesForSubscriptionMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
	}

/***Wrapper function***/
	@POST
	@Encoded
	@Path("/add")
	public Response addNewAssetInstanceMain(@QueryParam("assetName") String assetName,
			@HeaderParam("token") String token) {
		if(assetName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(assetName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("addNewAssetInstanceMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
					
			
			response = this.addNewAssetInstanceMainHelper(assetName, token, true,null,false,conn);
			
			if(response.getEntity() instanceof MyModel){
				MyModel res = (MyModel) response.getEntity();
				JSONObject json = new JSONObject();
		    	json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());

				log.trace("addNewAssetInstanceMain || End");
				
				return Response.status(retStat).entity(json.toString())
						.build();
			}else{
				conn.commit();
				return response;
			}
				
		} catch (RepoproException e) {
			log.error("addNewAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("addNewAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("addNewAssetInstanceMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();		
	}
	
	
	public Response addNewAssetInstanceMainHelper(String assetName,String token, boolean responseFlag,String assetInstanceDescription,boolean descFlag,Connection conn)throws RepoproException{
		
		if(assetName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		if(assetName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("addNewAssetInstanceMainHelper || Begin");
		
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		assetName = assetName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		Connection conn1 = null;
		try {
			if(conn == null){
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceMainHelper || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
			}
			
			UserDao userDao = new UserDao();
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = new AssetDef();
		    ad  = assetDao.getAssetsByAssetName(assetName, conn);
			if (ad.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("addNewAssetInstanceMainHelper || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			Boolean addFlag = false;
			AssetInstanceVersionDao aivDao = new AssetInstanceVersionDao();
			AssetInstanceDao aiDao = new AssetInstanceDao();
			RelationshipDao relationshipDao = new RelationshipDao();
			
			List<AssetRelationshipDef> assetRelationshipDef = new ArrayList<AssetRelationshipDef>();
			assetRelationshipDef = relationshipDao.retAssetRelationshipDefByDestAssetId(ad.getAssetId(),null);
			for(AssetRelationshipDef relDef:assetRelationshipDef){
				if(relDef.getFwdRelId().equals(1L)||relDef.getFwdRelId().equals(5L)){
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			addFlag = aivDao.findAdminRightsByUserName(userName, conn);
			if(addFlag){
				//response = this.addNewAssetInstance(ad.getAssetId(),userName);
				response = this.addNewAssetInstanceHelper(ad.getAssetId(), userName,assetInstanceDescription,descFlag, conn);
		    	MyModel res = (MyModel) response.getEntity();
		    	List<Object> data = res.getResult();
		    	JSONObject json = new JSONObject();
		    	String assetInstName = "";
		    	String versionName = "";
				for (int i = 0; i < data.size(); i++) {
					AssetInstance ai = new AssetInstance();
					ai = (AssetInstance) data.get(i);
					assetInstName = ai.getAssetInstName();
					versionName = ai.getVersionName();
				}
		    	
		    	json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());

				/*log.trace("addNewAssetInstanceMainHelper || End");
				return Response.status(retStat).entity(json.toString())
						.build();*/
				List<AssetInstance> assetInstances = new ArrayList<AssetInstance>();
				log.trace("addNewAssetInstanceMainHelper || End");
				
				if(responseFlag == true) {
					return Response.status(retStat).entity(json.toString())
							.build();
				} else {
					AssetInstance assetInstance2 = new AssetInstance();
					assetInstance2.setAssetInstName(assetInstName);
					assetInstance2.setVersionName(versionName);
					assetInstances.add(assetInstance2);
					
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retMsg = Constants.ASSET_INST_NAME_MATCHED;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
									new ArrayList<Object>(assetInstances))).build();
				}
				
				
			}else{
				AssetInstance assetInstance = aiDao.getAssetLevelAddAccessForLoginUser(assetName, userName, conn);
				if(assetInstance.getAddAccessFlag() == true){
					//response = this.addNewAssetInstance(ad.getAssetId(),userName);
					response = this.addNewAssetInstanceHelper(ad.getAssetId(), userName,assetInstanceDescription,descFlag, conn);
					MyModel res = (MyModel) response.getEntity();
					List<Object> data = res.getResult();
			    	JSONObject json = new JSONObject();
			    	String assetInstName = "";
			    	String versionName = "";
					for (int i = 0; i < data.size(); i++) {
						AssetInstance ai = new AssetInstance();
						ai = (AssetInstance) data.get(i);
						assetInstName = ai.getAssetInstName();
						assetInstName = ai.getAssetInstName();
						versionName = ai.getVersionName();
					}
			    	
			    	json.put("message", res.getMessage());
					json.put("status", res.getStatus());
					json.put("statusCode", res.getStatusCode());
					List<AssetInstance> assetInstances = new ArrayList<AssetInstance>();
					log.trace("addNewAssetInstanceMainHelper || End");
					if(responseFlag == true) {
						return Response.status(retStat).entity(json.toString())
								.build();
					} else {
						
						AssetInstance assetInstance2 = new AssetInstance();
						assetInstance2.setAssetInstName(assetInstName);
						assetInstance2.setVersionName(versionName);
						assetInstances.add(assetInstance2);
						retStat = Status.OK;
						retScsFlr = Constants.SUCCESS;
						retMsg = Constants.ASSET_INST_NAME_MATCHED;
						retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
						return Response
								.status(retStat)
								.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
										new ArrayList<Object>(assetInstances))).build();
					}
					
					
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
		} catch (RepoproException e) {
			log.error("addNewAssetInstanceMainHelper || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addNewAssetInstanceMainHelper || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} finally {
			if(conn1 != null){
			if (log.isTraceEnabled()) {
				log.trace("addNewAssetInstanceMainHelper || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		}

		log.trace("addNewAssetInstanceMainHelper || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
		
	}
	
/***Wrapper function***/
	@DELETE
	@Encoded
	@Path("/delete")
	public Response deleteAssetInstanceMain(
			@HeaderParam("token") String token,
			@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName){
		if(assetName == null || assetInstName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			assetInstName = assetInstName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(assetName.isEmpty() || assetInstName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("deleteAssetInstanceMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			Boolean deleteFlag = false;
			UserDao userDao = new UserDao();
			
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response
						.status(retStat).entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg)).build();
			}
			else{
				AssetDao assetDao =new AssetDao();
				AssetInstanceDao assetInstDao =new AssetInstanceDao();
				User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("deleteAssetInstanceMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				 AssetDef ad = new AssetDef();
		    	 ad = assetDao.getAssetsByAssetName(assetName, conn);
				if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("deleteAssetInstanceMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
		    	Long assetInstId=assetInstDao.getAssetInstIdByName(assetInstName,ad.getAssetId(), conn);
				if (assetInstId == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("deleteAssetInstanceMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				List<AssetInstanceVersion> versionList = new ArrayList<AssetInstanceVersion>();
				versionList = assetInstVersionDao.getAssetInstanceVersions(assetInstId, conn);

				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				for(AssetInstanceVersion versionName:versionList){
					long assetInstVersionId = versionName.getAssetInstVersionId();
					groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
					for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
						if (groupAssetInstVersionAccessList.get(i).getDeleteAccess().equals(0L)) {
							deleteFlag = true;
							break;
						}
					}
				}
								
				if (!deleteFlag) {//has access 
					String assetInstanceName = URLEncoder.encode(assetInstName, "UTF-8");
			    	response = this.deleteAssetInstance(userName,ad.getAssetId(),assetInstId,assetInstanceName);
			    	MyModel res = (MyModel) response.getEntity();
			    	JSONObject json = new JSONObject();
			    	json.put("message", res.getMessage());
					json.put("status", res.getStatus());
					json.put("statusCode", res.getStatusCode());

					log.trace("deleteAssetInstanceMain || End");
					return Response.status(retStat).entity(json.toString())
							.build();
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("deleteAssetInstanceMain || End");
					return Response
							.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			
			}
		} catch (RepoproException e) {
			log.error("deleteAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("deleteAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("deleteAssetInstanceMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();		
	}
	
	/***Wrapper function***/
	@PUT
	@Encoded
	@Path("/updateInstanceName")
	public Response updateAssetInstanceNameMain(@HeaderParam("token") String token,
			@QueryParam("newAssetInstanceName") String newAssetInstanceName,@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName,@QueryParam("assetInstanceVersionName") String versionName){
		if(newAssetInstanceName == null || assetName == null|| assetInstName == null|| versionName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			newAssetInstanceName = URLDecoder.decode(newAssetInstanceName, "UTF-8");
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			versionName = URLDecoder.decode(versionName, "UTF-8");
			assetName = assetName.trim();
			versionName = versionName.trim();
			newAssetInstanceName = newAssetInstanceName.trim();
			assetInstName = assetInstName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(newAssetInstanceName.isEmpty() || assetName.isEmpty()|| assetInstName.isEmpty()|| versionName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("updateAssetInstanceNameMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		assetName = assetName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		AssetInstance instance = new AssetInstance();
		AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
		AssetInstance assetInstance = new AssetInstance();
		
		try {
			String assetInstName1 = URLDecoder.decode(assetInstName, "UTF-8");
			String newAssetInstanceName1 = URLDecoder.decode(newAssetInstanceName, "UTF-8");
			String assetName1 = URLDecoder.decode(assetName, "UTF-8");
			versionName = URLDecoder.decode(versionName, "UTF-8");
			
			assetInstName1 = assetInstName1.trim();
			assetName1 = assetName1.trim();
			newAssetInstanceName1 = newAssetInstanceName1.trim();
			assetName = assetName.trim();
			versionName = versionName.trim();
			newAssetInstanceName = newAssetInstanceName.trim();
			assetInstName = assetInstName.trim();
			
			if(newAssetInstanceName1.trim().length()>100){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
						.build();
			}
			
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceNameMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			Boolean editFlag = false;
			assetInstance.setAssetName(assetName1);
			assetInstance.setAssetInstName(assetInstName1);
			assetInstance.setVersionName(versionName);
			UserDao userDao = new UserDao();
			
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg)).build();	
			}else{
				AssetDao assetDao = new AssetDao();
				AssetInstanceDao assetInstDao =new AssetInstanceDao();
				User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateAssetInstanceNameMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				AssetDef ad = new AssetDef();
				ad = assetDao.getAssetsByAssetName(assetInstance.getAssetName(), conn);
				if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateAssetInstanceNameMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				Long assetInstId = assetInstDao.getAssetInstIdByName(assetInstance.getAssetInstName(),ad.getAssetId(), conn);
				if (assetInstId == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateAssetInstanceNameMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				instance.setAssetName(assetInstance.getAssetName());
				instance.setAssetInstName(assetInstance.getAssetInstName());
				instance.setAssetInstId(assetInstId);
				instance.setVersionName(assetInstance.getVersionName());
				instance.setAssetId(ad.getAssetId());
				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(instance, null);
				if (assetInstanceVer == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("updateAssetInstanceNameMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				long assetInstVersionId = assetInstanceVer.getAssetInstVersionId();
				groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
						editFlag = true;
						break;
					}
				}

				if (editFlag) {
					//if (newAssetInstanceName.matches("^(\\:'\"+#$/&(),-_.@)$"))
					/*String newRegex = "^((?=[\\w+\\s\\d+:'\"+#$/&(),-_.@\\p{L}])(?![\\[\\]\\?^=;<>]).)*$";
					Pattern pattern = Pattern.compile(newRegex);
					Matcher matcher = pattern.matcher(newAssetInstanceName1);
					
					if(!matcher.find()){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED)))
								.build();
					}*/
					
					String iChars = "`!%^*=[];{}|<>?~";

					for (int i = 0; i < newAssetInstanceName1.length(); i++){
						if (iChars.indexOf(newAssetInstanceName1.charAt(i)) != -1){
							return Response.status(Status.BAD_REQUEST)
									.entity(new MyModelRest(Constants.STATUS_FAILURE,
											Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED)))
									.build();
						}
					}
										
					instance.setAssetName(URLEncoder.encode(assetName, "UTF-8"));
					instance.setAssetInstName(URLEncoder.encode(assetInstName, "UTF-8"));
					newAssetInstanceName = URLEncoder.encode(newAssetInstanceName, "UTF-8");
					response = this.updateAssetInstanceName(user.getUserId(),newAssetInstanceName,instance);
					MyModel res = (MyModel) response.getEntity();
			    	JSONObject json = new JSONObject();
			    	if(res.getMessage().equalsIgnoreCase("ASSET_INST_NAME_ALREADY_EXISTS")){
			    		return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.ASSET_INST_NAME_ALREADY_EXISTS)))
								.build();
			    	}else{
			    		json.put("message", res.getMessage());
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());
			    	}

					log.trace("updateAssetInstanceNameMain || End");
					return Response.status(retStat).entity(json.toString())
							.build();

				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("updateAssetInstanceNameMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}

			}
		} catch (RepoproException e) {
			log.error("updateAssetInstanceNameMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("updateAssetInstanceNameMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceNameMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("updateAssetInstanceNameMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
	}

/***Wrapper function***/
	@PUT
	@Encoded
	@Path("/updatePublicAccess")
	public Response updatePublicAccessValueForAssetInstanceMain(@QueryParam("assetName") String assetName, 
			@QueryParam("assetInstanceName") String assetInstanceName,
			@QueryParam("options")String options,
			@HeaderParam("token") String token){
		if(assetName == null|| assetInstanceName == null || options == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
			assetInstanceName = URLDecoder.decode(assetInstanceName, "UTF-8");
			assetInstanceName = assetInstanceName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		if(assetName.isEmpty()|| assetInstanceName.isEmpty() || options.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("updatePublicAccessValueForAssetInstanceMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		options = options.trim();
		AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("updatePublicAccessValueForAssetInstanceMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			Boolean editFlag = false;
			UserDao userDao = new UserDao();
			
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
					User userdata = commonUtils.userDetails(token);
					User username = userDao.getUserByUserId( userdata.getUserId(), null);
					userName = username.getUserName();
				}else{
					userName = "guest";
				}*/
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response
						.status(retStat).entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg)).build();
			}
			AssetDao assetDao=new AssetDao();
			AssetInstanceDao assetInstDao = new AssetInstanceDao();
			AssetDef ad  = assetDao.getAssetsByAssetName(assetName, conn);
			if (ad.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("updatePublicAccessValueForAssetInstanceMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			Long assetInstanceId = assetInstDao.getAssetInstIdByName(assetInstanceName,ad.getAssetId(), conn);
			if (assetInstanceId == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("updatePublicAccessValueForAssetInstanceMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			List<AssetInstanceVersion> versionList = new ArrayList<AssetInstanceVersion>();
			versionList = assetInstVersionDao.getAssetInstanceVersions(assetInstanceId, conn);
			if (versionList.isEmpty()) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("updatePublicAccessValueForAssetInstanceMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			for(AssetInstanceVersion versionName:versionList){
				long assetInstVersionId = versionName.getAssetInstVersionId();
				groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
						editFlag = true;
						break;
					}
				}
			}
			if(!options.equalsIgnoreCase("enableAccess") && !options.equalsIgnoreCase("disableAccess")){
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.PROVIDE_VALID_OPTION;
				retStatScsFlr = Constants.STATUS_FAILURE;
				log.trace("updatePublicAccessValueForAssetInstanceMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			if (editFlag) {

				response = this.updatePublicAccessValueForAssetInstance(ad.getAssetId(), assetInstanceId,options);
				MyModel res = (MyModel) response.getEntity();
		    	JSONObject json = new JSONObject();
		    	json.put("message", "PUBLIC_ACCESS_UPDATED");
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());

				log.trace("updatePublicAccessValueForAssetInstanceMain || End");
				return Response.status(retStat).entity(json.toString())
						.build();
				
			} else {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;

				log.trace("updatePublicAccessValueForAssetInstanceMain || End");
				return Response
						.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
		} catch (RepoproException e) {
			log.error("updatePublicAccessValueForAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("updatePublicAccessValueForAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updatePublicAccessValueForAssetInstanceMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("updatePublicAccessValueForAssetInstanceMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
	}

/***Wrapper function***/
	@GET
	@Encoded
	@Path("/getPublicAccess")
	public Response getPublicAccessValueForAssetInstanceMain(@QueryParam("assetInstanceName") String assetInstanceName,
			@QueryParam("assetName") String assetName,@HeaderParam("token") String token){
		
		if(assetName == null|| assetInstanceName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
			assetInstanceName = URLDecoder.decode(assetInstanceName, "UTF-8");
			assetInstanceName = assetInstanceName.trim();

		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		if(assetName.isEmpty()|| assetInstanceName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("getPublicAccessValueForAssetInstanceMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();

		try {
			
			if (log.isTraceEnabled()) {
				log.trace("getPublicAccessValueForAssetInstanceMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			Boolean viewFlag = false;
			UserDao userDao = new UserDao();
			AssetDao assetDao = new AssetDao();
			AssetInstanceDao assetInstDao = new AssetInstanceDao();
			List<AssetInstance> assetInsatnceList = new  ArrayList<AssetInstance>();
			
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg)).build();
			}else{
				AssetDef ad = assetDao.getAssetsByAssetName(assetName, null);
                
				if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("getPublicAccessValueForAssetInstanceMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				if(ad.isGuestflag() == true){
					
					Long assetInstanceId = assetInstDao.getAssetInstIdByName(assetInstanceName,ad.getAssetId(), conn);
					if (assetInstanceId == null) {
						retStat = Status.NOT_FOUND;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;
						log.trace("getPublicAccessValueForAssetInstanceMain || End");
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}

					List<AssetInstanceVersion> versionList = new ArrayList<AssetInstanceVersion>();
					versionList = assetInstVersionDao.getAssetInstanceVersions(assetInstanceId, conn);
					if (versionList.isEmpty()) {
						retStat = Status.NOT_FOUND;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;
						log.trace("getPublicAccessValueForAssetInstanceMain || End");
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}
					List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
					for(AssetInstanceVersion versionName:versionList){
						long assetInstVersionId = versionName.getAssetInstVersionId();
						groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
						for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
							if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
								viewFlag = true;
								break;
							}
						}
					}
					if (viewFlag) {

						response = this.getPublicAccessValueForAssetInstance(assetInstanceId);

						MyModel res = (MyModel) response.getEntity();

						List<Object> data = res.getResult();
						JSONObject j1 = null;
						JSONObject json = new JSONObject();
						List<Object> finaldata = new ArrayList<Object>();
						for (int i = 0; i < data.size(); i++) {
							j1 = new JSONObject();

							j1.put("publicAccessFlag", data.toString());
							
							finaldata.add(j1);

						}
						json.put("result", finaldata);
						json.put("message", "PUBLIC_ACCESS_FETCHED");
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());

		               log.trace("getAllAssetInstancesForSubscriptionMain || End");
		               return Response.status(retStat).entity(json.toString()).build();
						
					} else {
						retStat = Status.FORBIDDEN;
						retMsg = Constants.USER_NOT_AUTHORIZED;
						retScsFlr = Constants.NOT_AUTHORIZED;
						retStatScsFlr = Constants.FORBIDDEN;
						log.trace("getPublicAccessValueForAssetInstanceMain || End");
						return Response
								.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}

				}else{
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.PUBLIC_ACCESS_BLOCKED_AT_ASSET;
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.UNAUTHORIZED;

					log.trace("getPublicAccessValueForAssetInstanceMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}
			}
		} catch (RepoproException e) {
			log.error("getPublicAccessValueForAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getPublicAccessValueForAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getPublicAccessValueForAssetInstanceMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getPublicAccessValueForAssetInstanceMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
	}
	

/***Wrapper function***/
	///
	@GET
	@Encoded
	@Path("/getNotificationStatus")
	public Response getUserAssetInstanceSubscriptionMain(@HeaderParam("token") String token,
			@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstanceName){
		if(assetName == null|| assetInstanceName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
			assetInstanceName = URLDecoder.decode(assetInstanceName, "UTF-8");
			assetInstanceName = assetInstanceName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(assetName.isEmpty()|| assetInstanceName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("getUserAssetInstanceSubscriptionMain || Begin");
 		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getUserAssetInstanceSubscriptionMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			Boolean viewFlag = false;
			UserDao userDao = new UserDao();
			
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg)).build();
			}
			else{
                AssetDao assetDao=new AssetDao();
		    	AssetInstanceDao assetInstDao =new AssetInstanceDao();
				User user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("getUserAssetInstanceSubscriptionMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
		    	AssetDef ad=assetDao.getAssetsByAssetName(assetName, conn);
		    	if (ad.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("getUserAssetInstanceSubscriptionMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
		    	Long assetInstanceId=assetInstDao.getAssetInstIdByName(assetInstanceName,ad.getAssetId(), conn);
		    	if (assetInstanceId == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("getUserAssetInstanceSubscriptionMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
		    	List<AssetInstanceVersion> versionList = new ArrayList<AssetInstanceVersion>();
				versionList = assetInstVersionDao.getAssetInstanceVersions(assetInstanceId, conn);
				if (versionList.isEmpty()) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;
					log.trace("getUserAssetInstanceSubscriptionMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
				for(AssetInstanceVersion versionName:versionList){
					long assetInstVersionId = versionName.getAssetInstVersionId();
					groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstVersionId, userName, null);
					for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
						if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
							viewFlag = true;
							break;
						}
					}
				}
				if (viewFlag) {

			    	response = this.getUserAssetInstanceSubscription(user.getUserId(),assetInstanceId);
					
			    	MyModel res = (MyModel) response.getEntity();
					List<Object> data = res.getResult();
					JSONObject j1 = null;
					JSONObject json = new JSONObject();
					List<Object> finaldata = new ArrayList<Object>();
					for (int i = 0; i < data.size(); i++) {
						j1 = new JSONObject();
						j1.put("subscriptionFlag", data.toString());
						finaldata.add(j1);
					}
					json.put("result", finaldata);
					json.put("message", "USER_ASSET_INSTANCE_SUBSCRIPTION_FETCHED");
					json.put("status", res.getStatus());
					json.put("statusCode", res.getStatusCode());
					log.trace("getUserAssetInstanceSubscriptionMain || End");
					return Response.status(retStat).entity(json.toString())
							.build();
					
				} else {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("getUserAssetInstanceSubscriptionMain || End");
					return Response
							.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
		} catch (RepoproException e) {
			log.error("getUserAssetInstanceSubscriptionMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getUserAssetInstanceSubscriptionMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getUserAssetInstanceSubscriptionMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getUserAssetInstanceSubscriptionMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
	}
	
	
/*
*//***Wrapper function***//*
	not exposed
	@GET
	@Path("/getAddAccessForCompositionAndAggregationAssetTypeMain")
	public Response getAddAccessForCompositionAndAggregationAssetTypeMain(@QueryParam("assetName") String assetName, 
			@QueryParam("userName") String userName )
	{
		log.trace("getAddAccessForCompositionAndAggregationAssetTypeMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAddAccessForCompositionAndAggregationAssetTypeMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = assetDao.getAssetsByAssetName(assetName, conn);
			if (ad.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				log.trace("getAddAccessForCompositionAndAggregationAssetTypeMain || End");
				return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			response = this.getAddAccessForCompositionAndAggregationAssetType(ad.getAssetId(), userName);
			return response;
			
		} catch (RepoproException e) {
			log.error("getAddAccessForCompositionAndAggregationAssetTypeMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAddAccessForCompositionAndAggregationAssetTypeMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAddAccessForCompositionAndAggregationAssetTypeMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAddAccessForCompositionAndAggregationAssetTypeMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
	}

*//***Wrapper function***//*
	not exposed
	@GET
	@Path("/getdestAssetAccessForCompositionAndAggregationTypeMain")
	public Response getdestAssetAccessForCompositionAndAggregationTypeMain(@QueryParam("assetName") String assetName,@QueryParam("userName") String userName){
		log.trace("getdestAssetAccessForCompositionAndAggregationTypeMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getdestAssetAccessForCompositionAndAggregationTypeMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = assetDao.getAssetsByAssetName(assetName, conn);
			if (ad.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				log.trace("getdestAssetAccessForCompositionAndAggregationTypeMain || End");
				return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			response = this.getdestAssetAccessForCompositionAndAggregationType(ad.getAssetId());
			return response;
		} catch (RepoproException e) {
			log.error("getdestAssetAccessForCompositionAndAggregationTypeMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getdestAssetAccessForCompositionAndAggregationTypeMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getdestAssetAccessForCompositionAndAggregationTypeMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAssetInstanceForFilterMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
	}*/

/***Wrapper function***  not required ,used in front end aiv page drop down/
	/*move to assetmanager*/
	@GET
	@Encoded
	@Path("/getAllAssetInstanceNamesByAssetIdMain")
	public Response getAllAssetInstanceNamesByAssetIdMain(@QueryParam("assetName") String assetName,
			@HeaderParam("token") String token) {
		if(assetName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(assetName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("getAllAssetInstanceNamesByAssetIdMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceNamesByAssetIdMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = assetDao.getAssetsByAssetName(assetName, conn);
			if (ad.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				log.trace("getAllAssetInstanceNamesByAssetIdMain || End");
				return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			if(userName.equalsIgnoreCase("admin")){
				//response = this.getAllAssetInstanceNamesByAssetId(ad.getAssetId(),userName);
				return response;
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
			}
		} catch (RepoproException e) {
			log.error("getAllAssetInstanceNamesByAssetIdMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllAssetInstanceNamesByAssetIdMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstanceNamesByAssetIdMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllAssetInstanceNamesByAssetIdMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	
	/***Wrapper function***/
	/*comp aggr type - adding instance*///composite api for adding child instance
	@POST
	@Encoded
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Path("/addChildAssetInstance")
	public Response addAssetInstanceMain(
			@QueryParam("childAssetName") String assetName,
			@QueryParam("childAssetInstanceName") String assetInstName,
			@QueryParam("parentAssetName") String parentAssetName,
			@QueryParam("parentAssetInstanceVersionName") String parentVersionName,
			@QueryParam("parentAssetInstanceName") String parentAssetInstName,
			@QueryParam("addOverviewDescription") String assetInstanceDescription,
			@QueryParam("assignTagDetails") String tagNames,
			//@QueryParam("unassignTagDetails") String unassignTagNames,
			@QueryParam("assignTaxonomyDetails") String assignTaxonomy,
			//@QueryParam("unassignTaxonomyDetails") String unassignTaxonomy,
			@QueryParam("parameterDetails") String parameterDetails,
			@QueryParam("addRelationshipData") String addRelationshipData,
			//@QueryParam("removeRelationshipData") String removeRelationshipData,
			@HeaderParam("token") String token,FormDataMultiPart formParams, @Context ServletContext context){
		
		if(assetName == null|| assetInstName == null ||  parentAssetName == null || parentVersionName == null || parentAssetInstName == null || assetInstanceDescription == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			parentAssetName = URLDecoder.decode(parentAssetName, "UTF-8");
			parentVersionName = URLDecoder.decode(parentVersionName, "UTF-8");
			parentAssetInstName = URLDecoder.decode(parentAssetInstName, "UTF-8");
			assetInstanceDescription = URLDecoder.decode(assetInstanceDescription, "UTF-8");
			assetInstanceDescription = assetInstanceDescription.trim();
			assetInstName = assetInstName.trim();
			parentAssetName = parentAssetName.trim();
			parentAssetInstName = parentAssetInstName.trim();
			parentVersionName = parentVersionName.trim();
			
			if(tagNames != null){
				tagNames = URLDecoder.decode(tagNames, "UTF-8");
			}
			if(assignTaxonomy != null){
				assignTaxonomy = URLDecoder.decode(assignTaxonomy, "UTF-8");
			}
			if(parameterDetails != null){
				parameterDetails = URLDecoder.decode(parameterDetails, "UTF-8");
			}
			if(addRelationshipData != null){
				addRelationshipData = URLDecoder.decode(addRelationshipData, "UTF-8");
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(assetName.isEmpty()|| assetInstName.isEmpty() || parentAssetName.isEmpty() || parentVersionName.isEmpty() || parentAssetInstName.isEmpty()||assetInstanceDescription.isEmpty() ){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		if(assetInstName.trim().length()>100){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
					.build();
		}
		
		log.trace("addAssetInstanceMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Boolean addFlag = false;
		boolean AssetRelationshipCheck = false;
		AssetInstance assetInstance = new AssetInstance();
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		parentAssetName = parentAssetName.trim();
		parentAssetInstName = parentAssetInstName.trim();
		parentVersionName = parentVersionName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		boolean flagForChild = true;
		Response updatePropertiesResponse = null;
		Response updateTagsResponse = null;
		Response updateTaxonomiesResponse = null;
		Response saveDependencyResponse = null;
		AssetInstanceVersionRest aivRest = new AssetInstanceVersionRest();
		Object parameterChangeNotification = null;
    	Object relatedParamChangeNotification = null;
		try {
			
			String assetInstName1 = assetInstName;
			String parentAssetInstName1 = parentAssetInstName;
			assetInstName1 = assetInstName1.trim();
			parentAssetInstName1 = parentAssetInstName1.trim();
			
			if(assetInstanceDescription != null){
				assetInstanceDescription = assetInstanceDescription.trim();
			}
			if(tagNames == null){
				tagNames = "";
			}
			if(assignTaxonomy == null){
				assignTaxonomy = "";
			}
			if(tagNames != null){
				tagNames = tagNames.trim();
			}
			if(assignTaxonomy != null){
				assignTaxonomy = assignTaxonomy.trim();
			}
			if(addRelationshipData != null){
				addRelationshipData = addRelationshipData.trim();
			}
			if(parameterDetails != null){
				parameterDetails = parameterDetails.trim();
			}
			
			String newInstanceKey = "";
			String relationshipdataKey = "";
			String propertiesKey = "";
			String newRelationshipDataForRevision = "";
			String newParamDataForRevision = "";
			String usedByData = "",relationshipName = "";
			
			AivRevisionHistory aivRevHist = new AivRevisionHistory();
			
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			//get global setting setting details
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceMain || call of dao retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
			
			if(globalsetting.getGlobalSettingFlag() == 1){
				assetInstanceDescription = commonUtils.httpSanitizerForPlainText(assetInstanceDescription);
			}
			
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName1);
			assetInstance.setVersionName(Constants.DEFAULT_VERSION);
			assetInstance.setOwner(userName);
			assetInstance.setParentAssetName(parentAssetName);
			assetInstance.setParentAssetInstName(parentAssetInstName1);
			assetInstance.setParentVersionName(parentVersionName);
			assetInstance.setDescription(assetInstanceDescription);
			UserDao userDao = new UserDao();
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			RecentActivity recentActivity = new RecentActivity();
			String action =  Constants.ACTIVITY_CREATE;
			String appendingMsg = "";
			Map<String, String> taxMap = new HashMap<String, String>();
			
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest"))
			{
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = new AssetDef();
		    ad  = assetDao.getAssetsByAssetName(assetInstance.getAssetName(), conn);
			if (ad.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("addAssetInstanceMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			AssetDef parentAsset = new AssetDef();
			parentAsset = assetDao.getAssetsByAssetName(assetInstance.getParentAssetName(), conn);
			if (parentAsset.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("addAssetInstanceMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetInstance parentInstance = new AssetInstance();
			parentInstance.setAssetName(assetInstance.getParentAssetName());
			parentInstance.setAssetInstName(assetInstance.getParentAssetInstName());
			parentInstance.setVersionName(assetInstance.getParentVersionName());
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(parentInstance, conn);
			if (assetInstanceVer == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_VERSION_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("addAssetInstanceMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			assetInstance.setAssetId(ad.getAssetId());
			assetInstance.setParentAssetId(parentAsset.getAssetId());
			assetInstance.setParentAssetInstVersionId(assetInstanceVer.getAssetInstVersionId());
			List<GroupAssetAccess> assetGroupAccessList = new ArrayList<GroupAssetAccess>();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			WorkflowDao workflowDao = new WorkflowDao();
			
			// parent instance view access
			 
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			Boolean viewFlag = false;
			
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstanceVersionsMain || dao method called : retAivAccessRights ");
			}
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVer.getAssetInstVersionId(), userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
					viewFlag = true;
					break;
				}
			}
			if(!viewFlag){
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			
			}
			// child add access
			assetGroupAccessList = assetInstanceDao.getAddAccessForCompositionAndAggregationAssetType(assetInstance.getParentAssetId(),userName, conn);
			for (int i = 0; i < assetGroupAccessList.size(); i++) {
				if(assetGroupAccessList.get(i).getAssetName().equalsIgnoreCase(assetName)){
				if (assetGroupAccessList.get(i).getAddAccess().equals(1L)) {
					addFlag = true;
					break;
				}
				}
			}
			for (int i = 0; i < assetGroupAccessList.size(); i++) {
				if (assetGroupAccessList.get(i).getAssetName().equalsIgnoreCase(assetInstance.getAssetName())) {
					AssetRelationshipCheck = true;
					break;
				}
			}
			if(addFlag && AssetRelationshipCheck ){
				/*String newRegex = "^((?=[\\w+\\s\\d+:'\"+#$/&(),-_.@\\p{L}])(?![\\[\\]\\?^=;<>]).)*$";
				Pattern pattern = Pattern.compile(newRegex);
				Matcher matcher = pattern.matcher(assetInstName1);
				if (!matcher.find()) {
					return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED)))
							.build();
				}*/
				
				String iChars = "`!%^*=[];{}|<>?~";

				for (int i = 0; i < assetInstName1.length(); i++){
					if (iChars.indexOf(assetInstName1.charAt(i)) != -1){
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED)))
								.build();
					}
				}
				
				//response = addAssetInstance(assetInstance,userName,flagForChild);
				response = addAssetInstanceHelper(assetInstance,userName,flagForChild,true,false,conn);
				MyModel res = (MyModel) response.getEntity();
		    	JSONObject json = new JSONObject();
		    	if(res.getStatus().equalsIgnoreCase("FAILURE")){
		    		return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE,res.getMessage()))
							.build();
		    	}else{
		    		/*json.put("message", res.getMessage());
					json.put("status", res.getStatus());
					json.put("statusCode", res.getStatusCode());*/
		    		
		    		//15-04-2018
		    		MyModel model = null;
					MyModelRest modelRestTag = null;
					MyModel modelRestTax = null;
					MyModelRest modelRestPro = null;
					int statusCode = 0;
					String statusMessage = "";
		    		MyModel res1 = (MyModel) response.getEntity();
					List<Object> result = res1.getResult();
					
					for (int i = 0; i < result.size(); i++) {
						AssetInstance ai = new AssetInstance();
						ai = (AssetInstance) result.get(i);
						assetInstance.setAssetInstId(ai.getAssetInstId());
						assetInstance.setAssetInstVersionId(ai.getAssetInstVersionId());
					}
		    		
					AssetDef asset = assetInstanceDao.retAssetDetail(assetName,conn);
					
					RelationshipDao relationshipDao = new RelationshipDao();
					List<AssetRelationshipDef> assetRelationshipDefList = new ArrayList<AssetRelationshipDef>();
					if(assetInstance.getParentAssetId() != null){
						assetRelationshipDefList = relationshipDao.getAvailbleAssetRelationships(assetInstance.getParentAssetId(),assetInstance.getAssetId(), conn);
					}
					
					Long firstState = null;
					Workflow workflow = workflowDao.retWorkflowByAivId(assetInstance.getAssetInstVersionId(), conn);
					if(workflow != null) {
						String jsonStructure = workflow.getJsonStructure();
						JSONObject jsonObject = new JSONObject(jsonStructure);
						
						for(int i=0;i<jsonObject.length();i++) {
							Iterator itr = jsonObject.keys();
							if(itr.hasNext()){
								firstState = Long.parseLong(itr.next().toString());
							}
						}
						assetInstanceDao.updateAssetInstanceState(assetInstance.getAssetInstVersionId(),firstState,conn);
					}
					
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper : call dao getAssetInstanceVersion() method for fetching asset instance version details:");
					}
					AssetInstanceVersion aivForAddingNewRevision = 
							assetInstVersionDao.getAssetInstanceVersion(assetInstance.getAssetInstId(),assetInstance.getVersionName(), conn);
					
					if(aivForAddingNewRevision != null){
						for(AssetRelationshipDef assetRelationshipDefVo : assetRelationshipDefList){
							if((assetRelationshipDefVo.getFwdRelId() == 1)|| (assetRelationshipDefVo.getFwdRelId() == 5)){
								relationshipName = assetRelationshipDefVo.getDescription();
							}
						}
						if(!asset.isVersionable()){
							usedByData = assetInstance.getParentAssetInstName()+"("+relationshipName+")";
						}else{
							usedByData = assetInstance.getParentAssetInstName()+"_"+assetInstance.getParentVersionName()+"("+relationshipName+")";
						}	
					}
					newInstanceKey = "N";
					
					if(tagNames.equalsIgnoreCase("")){
						retMsg = Constants.TAGS_SAVED_SUCCESSFULLY;
						retStat = Status.OK;
						retScsFlr = Constants.SUCCESS;
						retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
						updateTagsResponse =  Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}else{
						updateTagsResponse = aivRest.addTagsMainHelper(assetName, assetInstName1, assetInstance.getVersionName(), tagNames, "", token, true, true, conn);
					}
					
					if(updateTagsResponse.getEntity() instanceof MyModelRest){
						modelRestTag = (MyModelRest) updateTagsResponse.getEntity();
					}
					if(modelRestTag != null){
						statusCode = updateTagsResponse.getStatus();
						statusMessage = modelRestTag.getMessage();
					}
					
					MyModel taxRes = null;
					if(modelRestTag.getStatus().equalsIgnoreCase("SUCCESS")){
						
						if(assignTaxonomy.equalsIgnoreCase("")){
							retMsg = Constants.TAXONOMY_ASSIGNED_SUCCESSFULLY;
							retStat = Status.OK;
							retScsFlr = Constants.SUCCESS;
							retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
							updateTaxonomiesResponse =  Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
						}else{
							updateTaxonomiesResponse = aivRest.addTaxonomyForAssetInstanceVersionMainHelper(assetName, assetInstName1, assetInstance.getVersionName(), assignTaxonomy, "", token, true, false,conn);
							 taxRes = (MyModel) updateTaxonomiesResponse.getEntity();
							taxMap = taxRes.getParamValues();
						}
						
					} else {
						return updateTagsResponse;
					}
					
					if(updateTaxonomiesResponse.getEntity() instanceof MyModel){
						modelRestTax = (MyModel) updateTaxonomiesResponse.getEntity();
					}
					if(modelRestTax != null){
						statusCode = updateTaxonomiesResponse.getStatus();
						statusMessage = modelRestTax.getMessage();
					}
					
					if(modelRestTax.getStatus().equalsIgnoreCase("SUCCESS")){
						
						if(parameterDetails != null && !parameterDetails.isEmpty()){
							List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();
							User user = userDao.getUserIdByUserName(userName, conn);
							try{

								String jsonStr1 = parameterDetails;
								JSONObject obj1 = new JSONObject(jsonStr1);
								String aivList = obj1.get("propertiesList").toString();
								JSONArray aivListArray = new JSONArray(aivList);
								AssetInstanceVersion aiv2 = new AssetInstanceVersion();
								for (int i = 0; i < aivListArray.length(); i++) {
									Iterator itr = aivListArray.getJSONObject(i).keys();
									while (itr.hasNext()) {
										aiv2 = new AssetInstanceVersion();
										String value = null;
										if(aivListArray.getJSONObject(i).has("assetParamName")){
											aiv2.setAssetParamName(aivListArray.getJSONObject(i).get("assetParamName").toString());
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();

										}

										//valid parameter check 
										AssetParamDef paramCheck = assetDao.getParamIdForAssetAndParamName(assetName,aiv2.getAssetParamName(),conn);
										if(paramCheck == null || paramCheck.getAssetParamId() == null){
											return Response
													.status(Status.NOT_FOUND)
													.entity(new MyModelRest(Constants.GET_STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_ASSET_PARAM_NAME)))
															.build();
										}
										if(paramCheck.getParamTypeId() == 3){
											if(aivListArray.getJSONObject(i).has("fileName")){
												aiv2.setFileName(aivListArray.getJSONObject(i).get("fileName").toString());
												aiv2.setMandatory(paramCheck.isHasMandatoryValue());
											}else{
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))	.build();
											}
										}else{
											if(paramCheck.getParamTypeId() == 4){
												//if(paramCheck.getListTypeParamTypeId() != 4){
												ArrayList<String> listdata = new ArrayList<String>();  
												aiv2.setMandatory(paramCheck.isHasMandatoryValue());
												if(aivListArray.getJSONObject(i).has("paramValue")){
													value = aivListArray.getJSONObject(i).get("paramValue").toString();
												}else{
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																	.build();
												}

												if(value.length() != 0 && value.startsWith("[")){
													JSONArray valueArray = new JSONArray(value);
													if (valueArray != null) { 
														for (int j=0;j<valueArray.length();j++){ 
															listdata.add(valueArray.getString(j));
														} 
													}
													if(paramCheck.getListType() == 0){
														if(listdata.size()>1){
															return Response
																	.status(Status.BAD_REQUEST)
																	.entity(new MyModelRest(Constants.STATUS_FAILURE,
																			Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																			.build();
														}
													}
													String listString = "";
													for(String s : listdata){
														listString += s + "~~";
													}
													if (listString.endsWith("~~")) {
														listString = listString.substring(0, listString.length() - "~~".length());
													}
													aiv2.setParamValue(listString);
												}else{
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																	.build();

												}
												//}
											}else if(paramCheck.getParamTypeId() == 1){
												aiv2.setMandatory(paramCheck.isHasMandatoryValue());
												if(paramCheck.isHasStaticValue() == true){
													if(aivListArray.getJSONObject(i).has("paramValue")){
														String paramVal = "";
														if(globalsetting.getGlobalSettingFlag() == 1){
															paramVal = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
														}
														else{
															paramVal = aivListArray.getJSONObject(i).get("paramValue").toString();
														}
														aiv2.setParamValue(paramVal);	
													}else{
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																		.build();
													}
												}else{

													if(paramCheck.getHasArray() == 1){
														aiv2.setHasArray(paramCheck.getHasArray());
														String textdata1 = null;
														if(aivListArray.getJSONObject(i).has("paramValue")){
															String paramval = "";
															if(globalsetting.getGlobalSettingFlag() == 1){
																paramval = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
															}else{
																paramval = aivListArray.getJSONObject(i).get("paramValue").toString();
															}

															textdata1 = paramval;
														}else{
															return Response
																	.status(Status.BAD_REQUEST)
																	.entity(new MyModelRest(Constants.STATUS_FAILURE,
																			Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																			.build();
														}
														if(textdata1 != null){
															if(textdata1.startsWith("[")){
																JSONArray textdataJsonArray = new JSONArray(textdata1);
																List<String> textDataList = new ArrayList<String>();
																for(int ii=0;ii<textdataJsonArray.length();ii++){
																	textDataList.add(textdataJsonArray.getString(ii));
																}
																aiv2.setTextDataList(textDataList);
																// for adding revision history
																String textdata = String.join("~~", aiv2.getTextDataList());
																aiv2.setParamValue(textdata);
															}else{
																return Response
																		.status(Status.BAD_REQUEST)
																		.entity(new MyModelRest(Constants.STATUS_FAILURE,
																				Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																				.build();
															}
														}
													}else{
														aiv2.setHasArray(paramCheck.getHasArray());

														if(aivListArray.getJSONObject(i).has("paramValue")){
															String paramval = "";
															if(globalsetting.getGlobalSettingFlag() == 1){
																paramval = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
															}else{
																paramval = aivListArray.getJSONObject(i).get("paramValue").toString();
															}
															aiv2.setParamValue(paramval);	
														}else{
															return Response
																	.status(Status.BAD_REQUEST)
																	.entity(new MyModelRest(Constants.STATUS_FAILURE,
																			Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																			.build();
														}
													}
												}
											}else if (paramCheck.getParamTypeId() == 7){
												aiv2.setMandatory(paramCheck.isHasMandatoryValue());
												if(paramCheck.getHasArray() == 1){
													aiv2.setHasArray(paramCheck.getHasArray());
													List<String> listdatawithouttag = new ArrayList<String>();
													List<String> listdatawithtag = new ArrayList<String>();
													String richText = null;
													if(aivListArray.getJSONObject(i).has("paramValue")){
														richText = aivListArray.getJSONObject(i).get("paramValue").toString();
													}else{
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																		.build();
													}
													if(richText != null){
														if(richText.startsWith("[")){
															//	System.out.println("processed");
															JSONArray valueArray1 = new JSONArray(richText);

															if (valueArray1 != null) { 
																for (int j=0;j<valueArray1.length();j++){ 
																	String richText1 = "";
																	if(globalsetting.getGlobalSettingFlag() == 1){
																		richText1 = commonUtils.httpSanitizerForCkEditor(valueArray1.getString(j));
																	}else {
																		richText1 = valueArray1.getString(j);
																	}
																	listdatawithtag.add(richText1);
																	String textdata = Jsoup.parse(valueArray1.getString(j)).text();

																	listdatawithouttag.add(textdata);
																} 
																aiv2.setRTFwithTags(listdatawithtag);
																aiv2.setRTFwithOutTags(listdatawithouttag);
																// for adding revision history
																String textdata = String.join("~~", aiv2.getRTFwithTags());
																aiv2.setParamValue(textdata);
															}
														}else{
															return Response
																	.status(Status.BAD_REQUEST)
																	.entity(new MyModelRest(Constants.STATUS_FAILURE,
																			Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																			.build();
														}
													}

												}else{
													aiv2.setHasArray(paramCheck.getHasArray());

													String richText = "";
													if(aivListArray.getJSONObject(i).has("paramValue")){
														richText = aivListArray.getJSONObject(i).get("paramValue").toString();
														if(globalsetting.getGlobalSettingFlag() == 1){
															richText = commonUtils.httpSanitizerForCkEditor(richText);
														}
													}else{
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																		.build();
													}
													aiv2.setParamValue(richText);
													String textdata = null;
													if (richText != null) { 
														textdata = Jsoup.parse(richText).text();
														aiv2.setRTFPlainText(textdata);
													}
												}
											}else if(paramCheck.getParamTypeId() == 8) {
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.DERIVED_PARAMETERS_NOT_ALLOWED)))
																.build();
											}
											else if(paramCheck.getParamTypeId() == 9){
						        				String duplicateLdapVal = URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8");
						        				List<String> ParamValList = new ArrayList<String>(Arrays.asList(duplicateLdapVal.split("~~")));
						        				boolean duplicateFlag = false;
												Set<String> duplicate = new HashSet<String>();
												duplicate.addAll(ParamValList);
												if(duplicate.size()<ParamValList.size()){
													duplicateFlag = true;
												}
												if(duplicateFlag){
													retStat = Status.BAD_REQUEST;
													retScsFlr = Constants.FAILURE;
													retMsg = "DUPLICATE_DATA_NOT_ALLOWED";
													retStatScsFlr = Constants.STATUS_FAILURE;
													return Response.status(retStat)
															.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
															.build();
												}
						        				Map<String,Integer> finalParamValList = commonUtils.ldapDataconstruction(URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8"),assetName ,aivListArray.getJSONObject(i).get("assetParamName").toString(),conn);
						        				aiv2.setLdapMappingValue(finalParamValList);
						        				
						        			}
											else{
												if(aivListArray.getJSONObject(i).has("paramValue")){
													aiv2.setMandatory(paramCheck.isHasMandatoryValue());
													aiv2.setParamValue(aivListArray.getJSONObject(i).get("paramValue").toString());	
												}else{
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																	.build();
												}
											}

										}
										aiv2.setAssetInstVersionId(assetInstance.getAssetInstVersionId());
										aiv2.setConn(conn);
										aiv2.setLog(log);
										aiv2.setUserId(user.getUserId());
										aiv2.setAssetName(assetName);
										aiv2.setAssetInstName(assetInstName);									

										ListOfAssetInstanceProperties.add(aiv2);
										break;

									}
								}
							}catch(org.json.JSONException e){
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
												.build();

							} catch (RepoproException e) {
								e.printStackTrace();
								throw new RepoproException(e.getMessage());
							}

							if(CommonUtils.customParameterPluginNoficationClassName != null && CommonUtils.customParameterPluginPath != null){

								if(!CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") && !CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

									Class notificationInterface = CustomParameterPluginUtilies.getplugin();

									if(notificationInterface != null){
										Method method = null;
										Method relatedParamChangeMethod = null;
										try {
											method = notificationInterface.getMethod("notifyOnParameterValueChanges",new Class[]{List.class});
											relatedParamChangeMethod = notificationInterface.getMethod("notifyOnParameterValueChangesBasedOnOtherParameter",new Class[]{List.class});

										} catch (NoSuchMethodException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (SecurityException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}

										Object instance = null;
										try {
											instance = notificationInterface.newInstance();
										} catch (InstantiationException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (IllegalAccessException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}	


										try{
											parameterChangeNotification = method.invoke(instance,ListOfAssetInstanceProperties);

											if(parameterChangeNotification != null){
												JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

												if(jsonObject.has("Response Status")){
													String status = jsonObject.getString("Response Status");
													if(status.equalsIgnoreCase("failure")){
														retStat = Status.INTERNAL_SERVER_ERROR;;
														retScsFlr = status;
														retMsg = jsonObject.getString("Response Message");
														retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

														return Response.status(retStat)
																.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
													}
												}
											}


											relatedParamChangeNotification = relatedParamChangeMethod.invoke(instance,ListOfAssetInstanceProperties);
											if(relatedParamChangeNotification != null){
												JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

												if(jsonObject.has("Response Status")){
													String status = jsonObject.getString("Response Status");
													if(status.equalsIgnoreCase("failure")){
														retStat = Status.INTERNAL_SERVER_ERROR;;
														retScsFlr = status;
														retMsg = jsonObject.getString("Response Message");
														retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

														return Response.status(retStat)
																.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
													}
												}
											}
										}
										catch (IllegalAccessException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (IllegalArgumentException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (InvocationTargetException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}catch(Exception e){
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}
									}else{
										retStat = Status.BAD_REQUEST;
										retScsFlr = Constants.FAILURE;
										retMsg = "Invalid Plugin configuration";
										retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

										return Response.status(retStat)
												.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
									}
								}
								if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")|| CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

									retStat = Status.BAD_REQUEST;
									retScsFlr = Constants.FAILURE;
									retMsg = "Invalid Plugin configuration";
									retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

									return Response.status(retStat)
											.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
								}
							}
							if(CommonUtils.customParameterPluginNoficationClassName != null ){
								if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")){
									retStat = Status.BAD_REQUEST;
									retScsFlr = Constants.FAILURE;
									retMsg = "Invalid Plugin configuration";
									retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

									return Response.status(retStat)
											.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
								}
							}else if(CommonUtils.customParameterPluginPath != null){
								if(CommonUtils.customParameterPluginPath .equalsIgnoreCase("")){
									retStat = Status.BAD_REQUEST;
									retScsFlr = Constants.FAILURE;
									retMsg = "Invalid Plugin configuration";
									retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

									return Response.status(retStat)
											.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
								}
							}
						}
							updatePropertiesResponse = aivRest.updateAssetInstancePropertiesRestHelper(assetName, assetInstName1, assetInstance.getVersionName(), parameterDetails, formParams, context, token, false, false, conn);
					} else {
						//return updateTaxonomiesResponse;
						retMsg = taxRes.getMessage();
						retScsFlr = taxRes.getStatus();
						retStatScsFlr = taxRes.getStatusCode();
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					
					}
					MyModel propRes = null;
					String successChecking = null;
					//String responseMsg = "";
						if(updatePropertiesResponse.getEntity() instanceof MyModelRest){
							modelRestPro = (MyModelRest) updatePropertiesResponse.getEntity();
						}
						if(modelRestPro != null){
							statusCode = updatePropertiesResponse.getStatus();
							statusMessage = modelRestPro.getMessage();
							successChecking = modelRestPro.getStatus();
						}else{
							// mymodel

							propRes = (MyModel) updatePropertiesResponse.getEntity();

							successChecking = propRes.getStatus();
							/*String[] splitResponseMsg = propRes.getMessage().split("`~~`");
							if(splitResponseMsg.length==2){
								responseMsg = splitResponseMsg[1];
							}*/
							List<Object> data = propRes.getResult();
							for (int i = 0; i < data.size(); i++) {
								String revHis = new String();
								revHis = (String) data.get(i);
								newParamDataForRevision = revHis;
							}
							propertiesKey = "P";

						}
					boolean relationshipFlag = false;
					//if(modelRest.getStatus().equalsIgnoreCase("SUCCESS")||propRes.getStatus().equalsIgnoreCase("SUCCESS")){
					if(successChecking.equalsIgnoreCase("SUCCESS")){
					if(addRelationshipData != null){
							if(!addRelationshipData.isEmpty())
							relationshipFlag= true;
						}
						/*if(removeRelationshipData != null ){
							if(!removeRelationshipData.isEmpty())
							relationshipFlag = true;
						}*/
						
						if(relationshipFlag == true){
							
							// json construction for relationship Data
							String addreldatas = "";
							try{
							String jsonStr1 = addRelationshipData;
							JSONObject obj1 = new JSONObject(jsonStr1);
							String aivList = obj1.get("relationshipData").toString();
							JSONArray aivListArray = new JSONArray(aivList);
							AssetInstance relAI = new AssetInstance();
							List<AssetInstance> relAIList = new ArrayList<AssetInstance>();
							for (int i = 0; i < aivListArray.length(); i++) {
								Iterator itr = aivListArray.getJSONObject(i).keys();
								while (itr.hasNext()) {
									relAI = new AssetInstance();
									if(aivListArray.getJSONObject(i).has("assetName")){
										relAI.setAssetName(aivListArray.getJSONObject(i).get("assetName").toString());
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();

										}
									if(aivListArray.getJSONObject(i).has("assetInstanceName")){
										relAI.setAssetInstName(aivListArray.getJSONObject(i).get("assetInstanceName").toString());
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();

										}
									if(aivListArray.getJSONObject(i).has("assetInstanceVersionName")){
										relAI.setVersionName(aivListArray.getJSONObject(i).get("assetInstanceVersionName").toString());
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();

										}
									if(aivListArray.getJSONObject(i).has("relationshipName")){
										relAI.setAssetRelationshipName(aivListArray.getJSONObject(i).get("relationshipName").toString());
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();

										}
									relAIList.add(relAI);
									break;
								}
								
								
							}
							
							for(AssetInstance aiii : relAIList ){
								if(addreldatas.equalsIgnoreCase("")){
									addreldatas = aiii.getAssetName()+"|"+aiii.getAssetInstName()+"|"+aiii.getVersionName()+"|"+aiii.getAssetRelationshipName()+"~";
								}else{
									addreldatas = addreldatas + aiii.getAssetName()+"|"+aiii.getAssetInstName()+"|"+aiii.getVersionName()+"|"+aiii.getAssetRelationshipName()+"~";
								}
							}
							if(addreldatas.endsWith("~")){
								if (addreldatas != null && addreldatas.length() > 0 && addreldatas.charAt(addreldatas.length() - 1) == '~') {
									addreldatas = addreldatas.substring(0, addreldatas.length() - 1);
								}
							}
							}catch(org.json.JSONException e){
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
												.build();
								
							} 
							
							saveDependencyResponse = aivRest.saveDependencyHelper(assetName, assetInstName1, assetInstance.getVersionName(), addreldatas, null, token, conn);
							
							assetInstanceVer.setSrcAssetInstanceVersionId(String.valueOf(assetInstance.getAssetInstVersionId()));
							List<AssetInstance> aivos = retFwdDependents(assetInstanceVer,conn);
							int i = 1;
							for(AssetInstance aivo : aivos){
								AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
								if(i == aivos.size()){
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]";	
									}	
								}else{
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
									}
								}
								i++;
							}
							relationshipdataKey = "R";
							
						}else{
							json.put("message", Constants.CHILD_ASSET_INSTANCE_DETAILS_CREATED/*+responseMsg*/);
							json.put("status", Constants.SUCCESS);
							json.put("statusCode", Constants.GET_STATUS_SUCCESS);
							  JSONObject j1 = null;
						        List<Object> finaldata = new ArrayList<Object>();
						        	j1 = new JSONObject();
						        	j1.put("assetInstanceId", assetInstance.getAssetInstId());
						        	j1.put("assetInstanceVersionId", assetInstance.getAssetInstVersionId());
						        	
						        	finaldata.add(j1);
								json.put("result", finaldata);
							
							String changeKey = "";
							changeKey = newInstanceKey+","+relationshipdataKey+","+propertiesKey;
							
							List<String> list = Arrays.asList(changeKey.split(","));
							List<String> finallist = new ArrayList<String>();
							for(String emptydata:list){
								if(!emptydata.equalsIgnoreCase("")){
									finallist.add(emptydata);
								}
							}
							String listString = String.join(",", finallist);
							
							AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();
							
					        User user = userDao.retProfileForUserName(userName, conn);
					        
					        /*assetInstanceVersionManager.addRevisionData(listString, assetInstanceVer.getAssetInstVersionId(), assetInstanceVer.getVersionName(), 
				        			overview,newRelationshipDataForRevision, newParamDataForRevision, null, userName,user.getUserId(),"", conn);*/
							
					        RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
							aivRevHist = new AivRevisionHistory();
							aivRevHist.setAivId(assetInstance.getAssetInstVersionId());
							aivRevHist.setRevId(assetInstance.getVersionName()+".0");
							aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							aivRevHist.setChangedKey(listString);
							aivRevHist.setOverviewData(assetInstance.getDescription());
							if(!newRelationshipDataForRevision.equalsIgnoreCase("")){
								aivRevHist.setRelationshipData(newRelationshipDataForRevision);
							}else{
								aivRevHist.setRelationshipData(null);
							}
							if(!newParamDataForRevision.equalsIgnoreCase("")){
								aivRevHist.setParameterData(newParamDataForRevision);
							}else{
								aivRevHist.setParameterData(null);
							}
							aivRevHist.setUserId(user.getUserId());
							aivRevHist.setUsedBy(usedByData);
							if (log.isTraceEnabled()) {
								log.trace("addAssetInstanceHelper : call dao addRevisionData() method for adding revision data");
							}
							revisionHistoryDao.addRevisionData(aivRevHist, conn);
					        
							AssetInstanceVersion aivo = new AssetInstanceVersion();
							aivo.setVersionName("1.0");
							aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							aivo.setAssetInstVersionId(aivRevHist.getAivId());
							assetInstVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
							
							//recent activity
							if (asset.isVersionable() == true) {
								String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ " Version " + assetInstance.getVersionName();
								recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								recentActivity.setDescription(log);
								recentActivity.setAssetId(asset.getAssetId().toString());
								recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
								recentActivity.setUser_id(user.getUserId());
							} else {
								String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ appendingMsg;
								recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								recentActivity.setDescription(log);
								recentActivity.setAssetId(asset.getAssetId().toString());
								recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
								recentActivity.setUser_id(user.getUserId());
							}
							
							recentActivityDao.addRecentActivity(recentActivity, conn);
							
							conn.commit();
							
							MailTemplateDao mailTemplateDao = new MailTemplateDao();
							SubscriptionDao subscriptionDao = new SubscriptionDao();

							MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
							String mailTemp = null;

							// add child instance

							AssetInstanceVersion aiv = assetInstVersionDao
									.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);
							List<String> emailIds = subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);

							if (aiv.getVersionable() == true) {
								MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(
										conn, "createAssetInstanceVersion");
								mailTemp = mtVo1.getMailTemplate();
								String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
							} else {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(
										conn, "createAssetInstanceNonVersion");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%assetType%", aiv.getAssetName());
							}
							if (emailIds != null) {
								for (String emailId : emailIds) {
									if (aiv.getVersionable() == true) {
										SendEmail.sendTextMail(
														mailConfig,emailId,
														MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
														MessageUtil.getMessage(Constants.EMAIL_HDR)
																+ mailTemp+ "\n"+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
									} else {
										SendEmail.sendTextMail(
														mailConfig,emailId,
														MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
														MessageUtil.getMessage(Constants.EMAIL_HDR)
																+ mailTemp+ "\n"+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
									}
								}
							}
							
							// taxonomy mail

							String assignTax = "";
							String unassignTax = "";
							String addTax = "";
							String removedTax = "";
							List<String> emailIdsList = new ArrayList<String>();
							List<String> emailIds1List = new ArrayList<String>();
							for(Map.Entry<String, String> entry : taxMap.entrySet()){
								assignTax = entry.getKey();
								unassignTax = entry.getValue();
							}
							//added taxonomies
							if(!assignTax.equalsIgnoreCase("")){
								String addedTaxEmail = "";
								String[] addTaxFinal = assignTax.split("~~");
								addTax = addTaxFinal[0];
								if(addTaxFinal.length == 2){
									addedTaxEmail = addTaxFinal[1];
								}
								emailIdsList = Arrays.asList(addedTaxEmail.split(","));
							}
							
							//unassigned taxonomies
							if(!unassignTax.equalsIgnoreCase("")){
								String[] unassignTaxFinal = unassignTax.split("~~");
								removedTax = unassignTaxFinal[0];
								String unassignTaxEmail = "";

								if(unassignTaxFinal.length == 2){
									unassignTaxEmail = unassignTaxFinal[1];
								}

								emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
							}
							//AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);

							if (!emailIdsList.isEmpty()) {
								//HashSet<String> listToSet = new HashSet<String>(emailIdsList);

								//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
								//String mailTemp = "";

								if (aiv.getVersionable() == true) {
									MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
											"assignTaxNameForAssetInstanceForVersionableAsset");
									mailTemp = mtVo.getMailTemplate();
									String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
									mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
											.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
								} else {
									MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
											"assignTaxNameForAssetInstanceForNonVersionableAsset");
									mailTemp = mtVo.getMailTemplate();
									String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
									mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",
											instName);
								}

								for (String emailId : emailIdsList) {
									//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
									if (addTax != "") {
										SendEmail.sendTextMail(mailConfig, emailId,
												MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
												MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
														+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
									}
								}
							}

							if (!emailIds1List.isEmpty()) {
								//HashSet<String> listToSet = new HashSet<String>(emailIds1List);

								//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
							//	String mailTemp = "";

								if (aiv.getVersionable() == true) {
									MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
											"unassignTaxNameForAssetInstanceForVersionableAsset");
									mailTemp = mtVo.getMailTemplate();
									String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
									mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
											.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
								} else {
									MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
											"unassignTaxNameForAssetInstanceForNonVersionableAsset");
									mailTemp = mtVo.getMailTemplate();
									String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
									mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
											.replaceAll("%assetInstName%", instName);
								}

								for (String emailId : emailIds1List) {

									//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
									if (removedTax != "") {
										SendEmail.sendTextMail(mailConfig, emailId,
												MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
												MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
														+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
									}
								}
							}
							if(parameterChangeNotification != null){
								JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

								if(jsonObject.has("Response Status")){
									String status = jsonObject.getString("Response Status");
									if(status.equalsIgnoreCase("success")){
										if(jsonObject.has("Notification")){
											String result1 = jsonObject.getString("Notification");
											result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
											if(!result1.equalsIgnoreCase("\"\"")){
												JSONObject maillist = new JSONObject(result1);
												if(maillist.has("Parameter changed")){
													String oldValue = maillist.getString("Old Value");
													List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
													String newValue = 	maillist.getString("New Value");
													List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
													String instanceName = maillist.getString("AssetInstanceName");
													String assetType = maillist.getString("Assetname");
													JSONArray emailArray = maillist.getJSONArray("Email Id");
													if(oldValue.equalsIgnoreCase("")){
														for(int j=0;j<emailArray.length();j++){
															SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																	MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																	MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																			+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
														}
													}else{
														for(int j=0;j<emailArray.length();j++){
															SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																	MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																	MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																			+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
														}
													}
												}
											}
										}
									}
								}
							}
							
							if(relatedParamChangeNotification != null){
								JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

								if(jsonObject.has("Response Status")){
									String status = jsonObject.getString("Response Status");
									if(status.equalsIgnoreCase("success")){
										if(jsonObject.has("Notification")){
											String result1 = jsonObject.getString("Notification");
											result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
											if(!result1.equalsIgnoreCase("\"\"")){
												JSONObject maillist = new JSONObject(result1);
												if(maillist.has("Parameter changed")){
													String oldValue = maillist.getString("Old Value");
													List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
													String newValue = 	maillist.getString("New Value");
													List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
													String instanceName = maillist.getString("AssetInstanceName");
													String assetType = maillist.getString("Assetname");
													JSONArray emailArray = maillist.getJSONArray("Email Id");
													if(oldValue.equalsIgnoreCase("")){
														for(int j=0;j<emailArray.length();j++){
															SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																	MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																	MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																			+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
														}
													}else{
														for(int j=0;j<emailArray.length();j++){
															SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																	MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																	MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																			+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
														}
													}
												}
											}
										}
									}
								}
							}
							return Response.status(retStat).entity(json.toString())
									.build();
						}
					} else {
						return updatePropertiesResponse;
					}
					
					MyModelRest modelRestSave = null;
					
					if(saveDependencyResponse.getEntity() instanceof MyModelRest){
						modelRestSave = (MyModelRest) saveDependencyResponse.getEntity();
					}
					if(modelRestSave != null){
						statusCode = saveDependencyResponse.getStatus();
						statusMessage = modelRestSave.getMessage();
					}
					if(modelRestSave.getStatus().equalsIgnoreCase("SUCCESS")){
						json.put("message", Constants.CHILD_ASSET_INSTANCE_DETAILS_CREATED/*+responseMsg*/);
						json.put("status", Constants.SUCCESS);
						json.put("statusCode", Constants.GET_STATUS_SUCCESS);
						  JSONObject j1 = null;
					        List<Object> finaldata = new ArrayList<Object>();
					        	j1 = new JSONObject();
					        	j1.put("assetInstanceId", assetInstance.getAssetInstId());
					        	j1.put("assetInstanceVersionId", assetInstance.getAssetInstVersionId());
					        	
					        	finaldata.add(j1);
							json.put("result", finaldata);
						
						String changeKey = "";
						changeKey = newInstanceKey+","+relationshipdataKey+","+propertiesKey;
						
						List<String> list = Arrays.asList(changeKey.split(","));
						List<String> finallist = new ArrayList<String>();
						for(String emptydata:list){
							if(!emptydata.equalsIgnoreCase("")){
								finallist.add(emptydata);
							}
						}
						String listString = String.join(",", finallist);
						
						AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();
						
				        User user = userDao.retProfileForUserName(userName, conn);
				        
				        /*assetInstanceVersionManager.addRevisionData(listString, assetInstanceVer.getAssetInstVersionId(), assetInstanceVer.getVersionName(), 
			        			overview,newRelationshipDataForRevision, newParamDataForRevision, null, userName,user.getUserId(),"", conn);*/
						
				        RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
						aivRevHist = new AivRevisionHistory();
						aivRevHist.setAivId(assetInstance.getAssetInstVersionId());
						aivRevHist.setRevId(assetInstance.getVersionName()+".0");
						aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						aivRevHist.setChangedKey(listString);
						aivRevHist.setOverviewData(assetInstance.getDescription());
						if(!newRelationshipDataForRevision.equalsIgnoreCase("")){
							aivRevHist.setRelationshipData(newRelationshipDataForRevision);
						}else{
							aivRevHist.setRelationshipData(null);
						}
						if(!newParamDataForRevision.equalsIgnoreCase("")){
							aivRevHist.setParameterData(newParamDataForRevision);
						}else{
							aivRevHist.setParameterData(null);
						}
						aivRevHist.setUserId(user.getUserId());
						aivRevHist.setUsedBy(usedByData);
						if (log.isTraceEnabled()) {
							log.trace("addAssetInstanceHelper : call dao addRevisionData() method for adding revision data");
						}
						revisionHistoryDao.addRevisionData(aivRevHist, conn);
				        
						AssetInstanceVersion aivo = new AssetInstanceVersion();
						aivo.setVersionName("1.0");
						aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						aivo.setAssetInstVersionId(aivRevHist.getAivId());
						assetInstVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
						
						//recent activity
						if (asset.isVersionable() == true) {
							String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ " Version " + assetInstance.getVersionName();
							recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							recentActivity.setDescription(log);
							recentActivity.setAssetId(asset.getAssetId().toString());
							recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
							recentActivity.setUser_id(user.getUserId());
						} else {
							String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ appendingMsg;
							recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							recentActivity.setDescription(log);
							recentActivity.setAssetId(asset.getAssetId().toString());
							recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
							recentActivity.setUser_id(user.getUserId());
						}
						
						recentActivityDao.addRecentActivity(recentActivity, conn);
						
						conn.commit();
						
						MailTemplateDao mailTemplateDao = new MailTemplateDao();
						SubscriptionDao subscriptionDao = new SubscriptionDao();

						MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						String mailTemp = null;

						// add child instance

						AssetInstanceVersion aiv = assetInstVersionDao
								.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);
						List<String> emailIds = subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);

						if (aiv.getVersionable() == true) {
							MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(
									conn, "createAssetInstanceVersion");
							mailTemp = mtVo1.getMailTemplate();
							String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
						} else {
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(
									conn, "createAssetInstanceNonVersion");
							mailTemp = mtVo.getMailTemplate();
							String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%assetType%", aiv.getAssetName());
						}
						if (emailIds != null) {
							for (String emailId : emailIds) {
								if (aiv.getVersionable() == true) {
									SendEmail.sendTextMail(
													mailConfig,emailId,
													MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
													MessageUtil.getMessage(Constants.EMAIL_HDR)
															+ mailTemp+ "\n"+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								} else {
									SendEmail.sendTextMail(
													mailConfig,emailId,
													MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
													MessageUtil.getMessage(Constants.EMAIL_HDR)
															+ mailTemp+ "\n"+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								}
							}
						}
						
						// taxonomy mail

						String assignTax = "";
						String unassignTax = "";
						String addTax = "";
						String removedTax = "";
						List<String> emailIdsList = new ArrayList<String>();
						List<String> emailIds1List = new ArrayList<String>();
						for(Map.Entry<String, String> entry : taxMap.entrySet()){
							assignTax = entry.getKey();
							unassignTax = entry.getValue();
						}
						//added taxonomies
						if(!assignTax.equalsIgnoreCase("")){
							String addedTaxEmail = "";
							String[] addTaxFinal = assignTax.split("~~");
							addTax = addTaxFinal[0];
							if(addTaxFinal.length == 2){
								addedTaxEmail = addTaxFinal[1];
							}
							emailIdsList = Arrays.asList(addedTaxEmail.split(","));
						}
						
						//unassigned taxonomies
						if(!unassignTax.equalsIgnoreCase("")){
							String[] unassignTaxFinal = unassignTax.split("~~");
							removedTax = unassignTaxFinal[0];
							String unassignTaxEmail = "";

							if(unassignTaxFinal.length == 2){
								unassignTaxEmail = unassignTaxFinal[1];
							}

							emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
						}
						//AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);

						if (!emailIdsList.isEmpty()) {
							//HashSet<String> listToSet = new HashSet<String>(emailIdsList);

							//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
							//String mailTemp = "";

							if (aiv.getVersionable() == true) {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"assignTaxNameForAssetInstanceForVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
										.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
							} else {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"assignTaxNameForAssetInstanceForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",
										instName);
							}

							for (String emailId : emailIdsList) {
								//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
								if (addTax != "") {
									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								}
							}
						}

						if (!emailIds1List.isEmpty()) {
							//HashSet<String> listToSet = new HashSet<String>(emailIds1List);

							//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
						//	String mailTemp = "";

							if (aiv.getVersionable() == true) {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"unassignTaxNameForAssetInstanceForVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
										.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
							} else {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"unassignTaxNameForAssetInstanceForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
										.replaceAll("%assetInstName%", instName);
							}

							for (String emailId : emailIds1List) {

								//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
								if (removedTax != "") {
									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								}
							}
						}
						if(parameterChangeNotification != null){
							JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

							if(jsonObject.has("Response Status")){
								String status = jsonObject.getString("Response Status");
								if(status.equalsIgnoreCase("success")){
									if(jsonObject.has("Notification")){
										String result1 = jsonObject.getString("Notification");
										result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
										if(!result1.equalsIgnoreCase("\"\"")){
											JSONObject maillist = new JSONObject(result1);
											if(maillist.has("Parameter changed")){
												String oldValue = maillist.getString("Old Value");
												List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
												String newValue = 	maillist.getString("New Value");
												List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
												String instanceName = maillist.getString("AssetInstanceName");
												String assetType = maillist.getString("Assetname");
												JSONArray emailArray = maillist.getJSONArray("Email Id");
												if(oldValue.equalsIgnoreCase("")){
													for(int j=0;j<emailArray.length();j++){
														SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																		+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
													}
												}else{
													for(int j=0;j<emailArray.length();j++){
														SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																		+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
													}
												}
											}
										}
									}
								}
							}
						}
						
						if(relatedParamChangeNotification != null){
							JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

							if(jsonObject.has("Response Status")){
								String status = jsonObject.getString("Response Status");
								if(status.equalsIgnoreCase("success")){
									if(jsonObject.has("Notification")){
										String result1 = jsonObject.getString("Notification");
										result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
										if(!result1.equalsIgnoreCase("\"\"")){
											JSONObject maillist = new JSONObject(result1);
											if(maillist.has("Parameter changed")){
												String oldValue = maillist.getString("Old Value");
												List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
												String newValue = 	maillist.getString("New Value");
												List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
												String instanceName = maillist.getString("AssetInstanceName");
												String assetType = maillist.getString("Assetname");
												JSONArray emailArray = maillist.getJSONArray("Email Id");
												if(oldValue.equalsIgnoreCase("")){
													for(int j=0;j<emailArray.length();j++){
														SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																		+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
													}
												}else{
													for(int j=0;j<emailArray.length();j++){
														SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																		+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
													}
												}
											}
										}
									}
								}
							}
						}
						return Response.status(retStat).entity(json.toString())
								.build();
					}else{
						return saveDependencyResponse;
					}
							
		    	}
			}else if(!addFlag){
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}else if(!AssetRelationshipCheck){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						.build();
			}
		} catch (RepoproException e) {
			log.error("addAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addAssetInstanceMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("addAssetInstanceMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();		
	}
	
	
	/*** Wrapper function ***/
	@GET
	@Encoded
	@Path("/getVersions")
	public Response getAssetInstanceVersionsMain(@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetName") String assetName,@HeaderParam("token") String token) {
		if(assetName == null|| assetInstName == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			assetName = assetName.trim();
			assetInstName = assetInstName.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(assetName.isEmpty()|| assetInstName.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		log.trace("getAssetInstanceVersionsMain || Begin");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		assetName = assetName.trim();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (!userName.equalsIgnoreCase("guest")) {
				User user = userDao.getUserIdByUserName(userName, null);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}

			Response response = null;
			AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
			AssetDao assetDao = new AssetDao();
			AssetInstanceDao assetInstDao = new AssetInstanceDao();
			 AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			List<AssetInstance> assetInsatnceList = new ArrayList<AssetInstance>();
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionsMain || dao method called : getAssetInstanceVersion ");
			}
			AssetDef assetDef = assetDao.getAssetsByAssetName(assetName, null);
			if (assetDef.getAssetId() == null) {

				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAssetInstanceVersionsMain || Begin");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();

			}
			if (userName.equalsIgnoreCase("roleAnonymous")) {
				if (assetDef.isGuestflag() != true) {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("getAssetInstanceVersionsMain || Begin");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
			}

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceVersionsMain || dao method called : getAssetInstanceVersion ");
			}

			Long assetInstId = assetInstDao.getAssetInstIdByName(assetInstName,
					assetDef.getAssetId(), null);

			if (assetInstId == null) {

				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("getAssetInstanceVersionsMain || Begin");
				return Response.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
						.build();
			}

			if (userName.equalsIgnoreCase("roleAnonymous")) {
				assetInsatnceList = assetInstDao
						.getAssetInstancePublicAccessState(assetInstId, null);
				for (AssetInstance ai : assetInsatnceList) {
					if (ai.isPublicAccess() == true) {

						response = aivManager.getAssetInstanceVersions(
								assetInstId, userName);
						
						MyModel res = (MyModel) response.getEntity();

						List<Object> data = res.getResult();
						JSONObject j1 = null;
						JSONObject json = new JSONObject();
						List<Object> finaldata = new ArrayList<Object>();
						for (int i = 0; i < data.size(); i++) {
							j1 = new JSONObject();
							AssetInstanceVersion aiv = new AssetInstanceVersion();
							aiv = (AssetInstanceVersion) data.get(i);

							j1.put("assetInstanceName",assetInstName);
							j1.put("description", aiv.getDescription());
							if(aiv.getVersionable() == true){
								j1.put("assetInstanceVersionName", aiv.getVersionName());
							}else{
								j1.put("assetInstanceVersionName", "N/A");
							}
							j1.put("assetName", assetName);
							j1.put("assetInstanceVersionId", aiv.getAssetInstVersionId());
							j1.put("versionNotes", aiv.getVersionNotes());
							j1.put("updatedOn",aiv.getUpdatedOn());
							j1.put("createdOn",aiv.getCreatedOn());
							finaldata.add(j1);

						}
						json.put("result", finaldata);
						json.put("message", res.getMessage());
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());

						log.trace("getAssetInstanceVersionsMain || End");
						return Response.status(retStat).entity(json.toString())
								.build();
						
					} else {

						retStat = Status.FORBIDDEN;
						retMsg = Constants.USER_NOT_AUTHORIZED;
						retScsFlr = Constants.NOT_AUTHORIZED;
						retStatScsFlr = Constants.FORBIDDEN;

						log.trace("getAssetInstanceVersionsMain || End");
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr,
										retMsg)).build();
					}
				}
			} else if(userName.equalsIgnoreCase("admin")) {
				response = aivManager.getAssetInstanceVersions(assetInstId, userName);
				MyModel res = (MyModel) response.getEntity();

				List<Object> data = res.getResult();
				JSONObject j1 = null;
				JSONObject json = new JSONObject();
				List<Object> finaldata = new ArrayList<Object>();
				for (int i = 0; i < data.size(); i++) {
					j1 = new JSONObject();
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv = (AssetInstanceVersion) data.get(i);

					j1.put("assetInstanceName",assetInstName);
					j1.put("description", aiv.getDescription());
					if(aiv.getVersionable() == true){
						j1.put("assetInstanceVersionName", aiv.getVersionName());
					}else{
						j1.put("assetInstanceVersionName", "N/A");
					}
					j1.put("assetName", assetName);
					j1.put("assetInstanceVersionId", aiv.getAssetInstVersionId());
					j1.put("versionNotes", aiv.getVersionNotes());
					j1.put("updatedOn",aiv.getUpdatedOn());
					j1.put("createdOn",aiv.getCreatedOn());

					finaldata.add(j1);

				}
				json.put("result", finaldata);
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());

				log.trace("getAssetInstanceVersionsMain || End");
				return Response.status(retStat).entity(json.toString())
						.build();
				
			}else{
				Boolean flag = false;
				List<AssetInstanceVersion> assetInstVersionList1 = new ArrayList<AssetInstanceVersion>();
			
				flag = assetInstanceVersionDao.findAdminRightsByUserName(userName, null);

				if (flag) {
					assetInstVersionList1 = assetInstanceVersionDao
							.getAssetInstanceVersions(assetInstId, null);
				
				JSONObject j1 = null;
				JSONObject json = new JSONObject();
				List<Object> finaldata = new ArrayList<Object>();
				for (int i = 0; i < assetInstVersionList1.size(); i++) {
					j1 = new JSONObject();
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv = (AssetInstanceVersion) assetInstVersionList1.get(i);

					j1.put("assetInstanceName",assetInstName);
					j1.put("description", aiv.getDescription());
					if(aiv.getVersionable() == true){
						j1.put("assetInstanceVersionName", aiv.getVersionName());
					}else{
						j1.put("assetInstanceVersionName", "N/A");
					}
					j1.put("assetName", assetName);
					j1.put("assetInstanceVersionId", aiv.getAssetInstVersionId());
					j1.put("versionNotes", aiv.getVersionNotes());
					j1.put("updatedOn",aiv.getUpdatedOn());
					j1.put("createdOn",aiv.getCreatedOn());
					finaldata.add(j1);
				}
				if(assetInstVersionList1.isEmpty()){
					json.put("message",Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED);
					json.put("status",Constants.SUCCESS);
					json.put("statusCode",Constants.GET_STATUS_SUCCESS );
				}else{
					json.put("message", Constants.ASSET_INSTANCE_VERSIONS_FETCHED);
					json.put("status", Constants.SUCCESS);
					json.put("statusCode",Constants.GET_STATUS_SUCCESS );
				}
				json.put("result", finaldata);
				log.trace("getAssetInstanceVersionsMain || End");
				return Response.status(retStat).entity(json.toString())
						.build();
			}else{
				
				List<AssetInstanceVersion> aivList = assetInstanceVersionDao.getAssetInstanceVersions(assetInstId,
						null);
				for (AssetInstanceVersion ai : aivList) {
				List<GroupAssetAccess> groupAssetAccessList = assetInstDao.getAssetInstanceAccessForLoginUser(ai.getAssetInstVersionId(), userName,null);
				for(GroupAssetAccess ga : groupAssetAccessList){
					if (ga.getViewAccess() == 1L) {
						assetInstVersionList1.add(ai);
						break;
					}
				}
				
				}
				
				JSONObject j1 = null;
				JSONObject json = new JSONObject();
				List<Object> finaldata = new ArrayList<Object>();
				for (int i = 0; i < assetInstVersionList1.size(); i++) {
					j1 = new JSONObject();
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv = (AssetInstanceVersion) assetInstVersionList1.get(i);

					j1.put("assetInstanceName",assetInstName);
					j1.put("description", aiv.getDescription());
					if(aiv.getVersionable() == true){
						j1.put("assetInstanceVersionName", aiv.getVersionName());
					}else{
						j1.put("assetInstanceVersionName", "N/A");
					}
					j1.put("assetName", assetName);
					j1.put("assetInstanceVersionId", aiv.getAssetInstVersionId());
					j1.put("versionNotes", aiv.getVersionNotes());
					j1.put("updatedOn",aiv.getUpdatedOn());
					j1.put("createdOn",aiv.getCreatedOn());
					finaldata.add(j1);
				}
				if(assetInstVersionList1.isEmpty()){
					json.put("message",Constants.ASSET_INSTANCE_VERSIONS_NOT_FETCHED);
					json.put("status",Constants.SUCCESS);
					json.put("statusCode",Constants.GET_STATUS_SUCCESS );
				}else{
					json.put("message", Constants.ASSET_INSTANCE_VERSIONS_FETCHED);
					json.put("status", Constants.SUCCESS);
					json.put("statusCode",Constants.GET_STATUS_SUCCESS );
				}
				json.put("result", finaldata);
				log.trace("getAssetInstanceVersionsMain || End");
				return Response.status(retStat).entity(json.toString())
						.build();
				
			}
				
			}

		} catch (RepoproException e) {
			log.error("getAssetInstanceVersionsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetInstanceVersionsMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}

		log.trace("getAssetInstanceVersionsMain || End");

		return Response.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

	}

	/**
	 * @method : getAllFilteredAssetInstancesForSubscription
	 * @description : to get all filtered the asset instances for subscription
	 * @param assetId , userId , searchString , subscriptionFlag , from
	 * @return
	 */
	@GET
	@Encoded
	@Path("/getAllFilteredAssetInstancesForSubscription")
	public Response getAllFilteredAssetInstancesForSubscription(@QueryParam("userName")String userName,
			@QueryParam("assetId") Long assetId, 
			@QueryParam("userId") Long userId,
			@QueryParam("searchString")String searchString,
			@QueryParam("subscriptionFlag")String subscriptionFlag,
			@QueryParam("from") int from) {

		if(log.isTraceEnabled()){
			log.trace("getAllFilteredAssetInstancesForSubscription || Begin with assetId : "+ assetId);
		}
		
		Connection conn = null;

		UserAssetInstanceSubscription uais = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		List<UserAssetInstanceSubscription> subscriptionList = new ArrayList<UserAssetInstanceSubscription>();

		try {
			if (log.isTraceEnabled()){
				log.trace("getAllFilteredAssetInstancesForSubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			String actualValue = URLDecoder.decode(searchString, "UTF-8");
			String value = "";
			if (searchString.contains("_") || searchString.contains("%")){
				value = actualValue;
				value = value.replace("_", "\\_");
				value = value.replace("%", "\\%");
			}else{
				value = actualValue;
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetInstanceDao dao = new AssetInstanceDao();
			SubscriptionDao subDao = new SubscriptionDao();
			UserDao userDao = new UserDao();
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetInstancesForSubscription || dao method called : getUserByUserId()");
			}
			User user = userDao.getUserByUserId(userId,conn);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetInstancesForSubscription || dao method called : getAllFilteredAssetInstancesForSubscription()");
			}
			
			assetInstanceList = dao.getAllFilteredAssetInstancesForSubscription(assetId,user.getUserName(),user.getUserId(),subscriptionFlag,value, from, conn);

			if(!(assetInstanceList.isEmpty())){
				for(AssetInstance ai : assetInstanceList){
					if (log.isTraceEnabled()) {
						log.trace("getAllFilteredAssetInstancesForSubscription || dao method called : getAllSubscriptionsByAssetInstance()");
					}
					uais = subDao.getAllSubscriptionsByAssetInstance(ai.getAssetInstId(), userId, conn);
					uais.setAssetInstanceId(ai.getAssetInstId());
					uais.setAssetInstanceName(ai.getAssetInstName());
					uais.setUserId(userId);
					uais.setIconImageName(ai.getIconImageName());
					if(subscriptionFlag.equalsIgnoreCase("true")){
						if(uais.getSubscriptionFlag().equalsIgnoreCase("subscribed")){
							subscriptionList.add(uais);
						}
					}else if(subscriptionFlag.equalsIgnoreCase("false")){
						if(!uais.getSubscriptionFlag().equalsIgnoreCase("subscribed")){
							subscriptionList.add(uais);
						}
					}else{
						subscriptionList.add(uais);
					}
				}
			}
			log.debug("getAllFilteredAssetInstancesForSubscription || retrieved "+ assetInstanceList.size() 
					+" asset instances successfully");

			retMsg = Constants.ALL_ASSET_INSTANCES_FETCHED;
			retScsFlr = Constants.FAILURE;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;


		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;

		} catch(Exception e){
			log.error("getAllFilteredAssetInstancesForSubscription || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetInstancesForSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (subscriptionList.isEmpty()) {
			retMsg = Constants.ASSET_INSTANCE_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_ASSET_INSTANCES_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		if(log.isTraceEnabled()){
			log.trace("getAllFilteredAssetInstancesForSubscription || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(subscriptionList))).build();
	}
	
	
	/**
	 * @method : addInstanceUpdatePropertiesRelationships
	 * @param assetName
	 * @param assetInstName
	 * @param versionName
	 * @param parameterDetails
	 * @param formParams
	 * @param context
	 * @param destinationAsset
	 * @param addRelationshipData
	 * @param removeRelationshipData
	 * @param token
	 * @return
	 */
	@POST
	@Encoded
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Path("/create")
	public Response addInstanceUpdatePropertiesRelationships(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName,
			//@QueryParam("assetInstanceVersionName") String versionName,
			@QueryParam("parameterDetails") String parameterDetails,
			@QueryParam("addOverviewDescription") String assetInstanceDescription,
			@QueryParam("tagNames") String tagNames,
			@QueryParam("taxonomyName") String taxonomyName,
			FormDataMultiPart formParams, @Context ServletContext context,
			@QueryParam("addRelationshipData") String addRelationshipData,
			@QueryParam("removeRelationshipData") String removeRelationshipData,
			@HeaderParam("token") String token){
		
		if(assetName == null || assetInstName == null || assetInstanceDescription == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			assetInstanceDescription = URLDecoder.decode(assetInstanceDescription, "UTF-8");
			assetInstanceDescription = assetInstanceDescription.trim();
			assetInstName = assetInstName.trim();
			
			if(tagNames != null){
				tagNames = URLDecoder.decode(tagNames, "UTF-8");
				tagNames = tagNames.trim();
			}
			if(taxonomyName != null){
				taxonomyName = URLDecoder.decode(taxonomyName, "UTF-8");
				taxonomyName = taxonomyName.trim();
			}
			if(parameterDetails != null){
				parameterDetails = URLDecoder.decode(parameterDetails, "UTF-8");
				parameterDetails = parameterDetails.trim();
			}
			if(addRelationshipData != null){
				addRelationshipData = URLDecoder.decode(addRelationshipData, "UTF-8");
				addRelationshipData = addRelationshipData.trim();
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(assetName.trim().isEmpty() || assetInstName.trim().isEmpty() || assetInstanceDescription.trim().isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		if(assetInstName.trim().length()>100){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.MAX_LENGTH_EXCEEDED)))
					.build();
		}
				
		log.trace("addInstanceUpdatePropertiesRelationships || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
		Object parameterChangeNotification = null;
    	Object relatedParamChangeNotification = null;
		try {
			
			MailTemplateDao mailTemplateDao = new MailTemplateDao();
			SubscriptionDao subscriptionDao = new SubscriptionDao();

			MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
			String mailTemp = null;
			
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (log.isTraceEnabled()) {
				log.trace("addInstanceUpdatePropertiesRelationships : " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("guest")) {
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			String newInstanceKey = "";
			String relationshipdataKey = "";
			String propertiesKey = "";
			Map<String, String> taxMap = new HashMap<String, String>();
			String overview = "";
			String newRelationshipDataForRevision = "";
			String newParamDataForRevision = "";
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			AssetInstanceManager aiManager = new AssetInstanceManager();
			AssetInstanceVersionRest aivRest = new AssetInstanceVersionRest();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetDao assetDao = new AssetDao();
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			WorkflowDao workflowDao = new WorkflowDao();
			AivRevisionHistory aivRevHist = new AivRevisionHistory();
			Boolean descFlag = false;
			if(assetInstanceDescription != null){
				if(!assetInstanceDescription.isEmpty())
					descFlag = true;
			}
			//assetInstanceManager.addAssetInstanceHelper(ai,userName,false,true,conn);
			
			AssetInstance ai = new AssetInstance();
			ai.setAssetName(assetName);

			AssetDef asset = assetInstanceDao.retAssetDetail(assetName, conn);
			if(asset.getAssetId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("addInstanceUpdatePropertiesRelationships || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			//get global setting setting details
			if (log.isTraceEnabled()){
				log.trace("addInstanceUpdatePropertiesRelationships || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
			
			if(globalsetting.getGlobalSettingFlag() == 1){
				assetInstanceDescription = commonUtils.httpSanitizerForPlainText(assetInstanceDescription);
			}
			ai.setAssetId(asset.getAssetId());
			ai.setAssetInstName(assetInstName);
			ai.setVersionName(Constants.DEFAULT_VERSION);
			ai.setOwner(userName);
			ai.setDescription(assetInstanceDescription);
			String versionName = ai.getVersionName();
			
			RelationshipDao relationshipDao = new RelationshipDao();
			List<AssetRelationshipDef> assetRelationshipDef = new ArrayList<AssetRelationshipDef>();
			assetRelationshipDef = relationshipDao.retAssetRelationshipDefByDestAssetId(asset.getAssetId(),null);
			for(AssetRelationshipDef relDef:assetRelationshipDef){
				if(relDef.getFwdRelId().equals(1L)||relDef.getFwdRelId().equals(5L)){
					retStat = Status.BAD_REQUEST;
					retMsg = "Child instance should be created with parent asset instance details";
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.STATUS_FAILURE;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			boolean addFlag = false;
			addFlag = assetInstVersionDao.findAdminRightsByUserName(userName, conn);
			if(!addFlag){
				AssetInstance assetInstance2 = assetInstanceDao.getAssetLevelAddAccessForLoginUser(assetName, userName, conn);
				if(assetInstance2.getAddAccessFlag() == false){
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
			
			String iChars = "`!%^*=[];{}|<>?~";

			for (int i = 0; i < assetInstName.length(); i++){
				if (iChars.indexOf(assetInstName.charAt(i)) != -1){
					return Response.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED)))
							.build();
				}
			}
			
			response = aiManager.addAssetInstanceHelper(ai,userName,false,true,false,conn);
			
			JSONObject json = new JSONObject();
			Response updatePropertiesResponse = null;
			Response updateTagsResponse = null;
			Response updateTaxonomiesResponse = null;
			Object result =  response.getEntity();
			MyModel model = null;
			MyModelRest modelRest = null;
			MyModel modelRestTax = null;
			MyModelRest modelRestTag = null;
			MyModelRest modelRestPro = null;
			MyModelRest modelRestSave = null;
			if(response.getEntity() instanceof MyModel){
				model = (MyModel) response.getEntity();
			}else if(response.getEntity() instanceof MyModelRest){
				modelRest = (MyModelRest) response.getEntity();
			}
			int statusCode = 0;
			String statusMessage = "";
			if(model !=null ){
				statusCode = response.getStatus();
				statusMessage = model.getMessage();
			}else if(modelRest != null){
				statusCode = response.getStatus();
				statusMessage = modelRest.getMessage();
			}
			
			if(Constants.ASSET_INSTANCE_ALREADY_EXIST.equalsIgnoreCase(statusMessage)){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.ASSET_INSTANCE_ALREADY_EXIST)))
						.build();
			}
			
			List<Object> data1 = model.getResult();
			
			for (int i = 0; i < data1.size(); i++) {
				AssetInstance ai1 = new AssetInstance();
				ai1 = (AssetInstance) data1.get(i);
				assetInstance.setAssetInstId(ai1.getAssetInstId());
				assetInstance.setAssetInstVersionId(ai1.getAssetInstVersionId());
				assetInstance.setVersionName(ai1.getVersionName());
			}
			//revision history string  for add instance
			AssetInstanceVersion aivForAddingNewRevision = assetInstVersionDao
					.getAssetInstanceVersion(assetInstance.getAssetInstId(),assetInstance.getVersionName(), conn);
			
			Long firstState = null;
			Workflow workflow = workflowDao.retWorkflowByAivId(assetInstance.getAssetInstVersionId(), conn);
			if(workflow != null) {
				String jsonStructure = workflow.getJsonStructure();
				JSONObject jsonObject = new JSONObject(jsonStructure);
				
				for(int i=0;i<jsonObject.length();i++) {
					Iterator itr = jsonObject.keys();
					if(itr.hasNext()){
						firstState = Long.parseLong(itr.next().toString());
					}
				}
				assetInstanceDao.updateAssetInstanceState(assetInstance.getAssetInstVersionId(),firstState,conn);
			}
			
			if(aivForAddingNewRevision != null){
				newInstanceKey = "N";
				overview = aivForAddingNewRevision.getDescription();
			}
			
			if((statusCode == 200) && (Constants.ASSET_INSTANCE_ALREADY_EXIST.equalsIgnoreCase(statusMessage))){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.ASSET_INSTANCE_ALREADY_EXIST)))
						.build();
				
			} else {
				MyModel res = (MyModel) response.getEntity();
						    	
				JSONObject j1 = new JSONObject(res);
				if(tagNames != null && !tagNames.isEmpty()){
				
					updateTagsResponse = aivRest.addTagsMainHelper(assetName, assetInstName, versionName, tagNames, "",token,true, false, conn);
					
				}else{
					retMsg = Constants.TAGS_SAVED_SUCCESSFULLY;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					updateTagsResponse =  Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
				
			}
					
			
			if(updateTagsResponse.getEntity() instanceof MyModelRest){
				modelRestTag = (MyModelRest) updateTagsResponse.getEntity();
			}
			if(modelRestTag != null){
				statusCode = updateTagsResponse.getStatus();
				statusMessage = modelRestTag.getMessage();
				
			}
			MyModel taxRes = null;
			if(modelRestTag.getStatus().equalsIgnoreCase("SUCCESS")){
				if(taxonomyName !=null && !taxonomyName.isEmpty()){
					//if(!taxonomyName.isEmpty())
					updateTaxonomiesResponse = aivRest.addTaxonomyForAssetInstanceVersionMainHelper(assetName, assetInstName, versionName, taxonomyName,"", token,true,false,conn);
					taxRes = (MyModel) updateTaxonomiesResponse.getEntity();
					taxMap = taxRes.getParamValues();
				}else{
					retMsg = Constants.TAXONOMY_ASSIGNED_SUCCESSFULLY;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					updateTaxonomiesResponse =  Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			} else {
				return updateTagsResponse;
			}
			
			if(updateTaxonomiesResponse.getEntity() instanceof MyModel){
				modelRestTax = (MyModel) updateTaxonomiesResponse.getEntity();
			}
			if(modelRestTax != null){
				statusCode = updateTaxonomiesResponse.getStatus();
				statusMessage = modelRestTax.getMessage();
				
			}
			
			if(modelRestTax.getStatus().equalsIgnoreCase("SUCCESS")){
				if(parameterDetails != null && !parameterDetails.isEmpty()){
				List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();
				User user = userDao.getUserIdByUserName(userName, conn);
				try{

					String jsonStr1 = parameterDetails;
					JSONObject obj1 = new JSONObject(jsonStr1);
					String aivList = obj1.get("propertiesList").toString();
					JSONArray aivListArray = new JSONArray(aivList);
					AssetInstanceVersion aiv2 = new AssetInstanceVersion();
					for (int i = 0; i < aivListArray.length(); i++) {
						Iterator itr = aivListArray.getJSONObject(i).keys();
						while (itr.hasNext()) {
							aiv2 = new AssetInstanceVersion();
							String value = null;
							if(aivListArray.getJSONObject(i).has("assetParamName")){
								aiv2.setAssetParamName(aivListArray.getJSONObject(i).get("assetParamName").toString());
							}else{
								return Response
										.status(Status.BAD_REQUEST)
										.entity(new MyModelRest(Constants.STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
												.build();

							}

							//valid parameter check 
							AssetParamDef paramCheck = assetDao.getParamIdForAssetAndParamName(assetName,aiv2.getAssetParamName(),conn);
							if(paramCheck == null || paramCheck.getAssetParamId() == null){
								return Response
										.status(Status.NOT_FOUND)
										.entity(new MyModelRest(Constants.GET_STATUS_FAILURE,
												Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_ASSET_PARAM_NAME)))
												.build();
							}
							if(paramCheck.getParamTypeId() == 3){
								if(aivListArray.getJSONObject(i).has("fileName")){
									aiv2.setFileName(aivListArray.getJSONObject(i).get("fileName").toString());
									aiv2.setMandatory(paramCheck.isHasMandatoryValue());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))	.build();
								}
							}else{
								if(paramCheck.getParamTypeId() == 4){
									//if(paramCheck.getListTypeParamTypeId() != 4){
									ArrayList<String> listdata = new ArrayList<String>();  
									aiv2.setMandatory(paramCheck.isHasMandatoryValue());
									if(aivListArray.getJSONObject(i).has("paramValue")){
										value = aivListArray.getJSONObject(i).get("paramValue").toString();
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();
									}

									if(value.length() != 0 && value.startsWith("[")){
										JSONArray valueArray = new JSONArray(value);
										if (valueArray != null) { 
											for (int j=0;j<valueArray.length();j++){ 
												listdata.add(valueArray.getString(j));
											} 
										}
										if(paramCheck.getListType() == 0){
											if(listdata.size()>1){
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
										}
										String listString = "";
										for(String s : listdata){
											listString += s + "~~";
										}
										if (listString.endsWith("~~")) {
											listString = listString.substring(0, listString.length() - "~~".length());
										}
										aiv2.setParamValue(listString);
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();

									}
									//}
								}else if(paramCheck.getParamTypeId() == 1){
									aiv2.setMandatory(paramCheck.isHasMandatoryValue());
									if(paramCheck.isHasStaticValue() == true){
										if(aivListArray.getJSONObject(i).has("paramValue")){
											String paramVal = "";
											if(globalsetting.getGlobalSettingFlag() == 1){
												paramVal = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
											}
											else{
												paramVal = aivListArray.getJSONObject(i).get("paramValue").toString();
											}
											aiv2.setParamValue(paramVal);	
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();
										}
									}else{

										if(paramCheck.getHasArray() == 1){
											aiv2.setHasArray(paramCheck.getHasArray());
											String textdata1 = null;
											if(aivListArray.getJSONObject(i).has("paramValue")){
												String paramval = "";
												if(globalsetting.getGlobalSettingFlag() == 1){
													paramval = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
												}else{
													paramval = aivListArray.getJSONObject(i).get("paramValue").toString();
												}

												textdata1 = paramval;
											}else{
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
											if(textdata1 != null){
												if(textdata1.startsWith("[")){
													JSONArray textdataJsonArray = new JSONArray(textdata1);
													List<String> textDataList = new ArrayList<String>();
													for(int ii=0;ii<textdataJsonArray.length();ii++){
														textDataList.add(textdataJsonArray.getString(ii));
													}
													aiv2.setTextDataList(textDataList);
													// for adding revision history
													String textdata = String.join("~~", aiv2.getTextDataList());
													aiv2.setParamValue(textdata);
												}else{
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																	.build();
												}
											}
										}else{
											aiv2.setHasArray(paramCheck.getHasArray());

											if(aivListArray.getJSONObject(i).has("paramValue")){
												String paramval = "";
												if(globalsetting.getGlobalSettingFlag() == 1){
													paramval = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
												}else{
													paramval = aivListArray.getJSONObject(i).get("paramValue").toString();
												}
												aiv2.setParamValue(paramval);	
											}else{
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
										}
									}
								}else if (paramCheck.getParamTypeId() == 7){
									aiv2.setMandatory(paramCheck.isHasMandatoryValue());
									if(paramCheck.getHasArray() == 1){
										aiv2.setHasArray(paramCheck.getHasArray());
										List<String> listdatawithouttag = new ArrayList<String>();
										List<String> listdatawithtag = new ArrayList<String>();
										String richText = null;
										if(aivListArray.getJSONObject(i).has("paramValue")){
											richText = aivListArray.getJSONObject(i).get("paramValue").toString();
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();
										}
										if(richText != null){
											if(richText.startsWith("[")){
												//	System.out.println("processed");
												JSONArray valueArray1 = new JSONArray(richText);

												if (valueArray1 != null) { 
													for (int j=0;j<valueArray1.length();j++){ 
														String richText1 = "";
														if(globalsetting.getGlobalSettingFlag() == 1){
															richText1 = commonUtils.httpSanitizerForCkEditor(valueArray1.getString(j));
														}else {
															richText1 = valueArray1.getString(j);
														}
														listdatawithtag.add(richText1);
														String textdata = Jsoup.parse(valueArray1.getString(j)).text();

														listdatawithouttag.add(textdata);
													} 
													aiv2.setRTFwithTags(listdatawithtag);
													aiv2.setRTFwithOutTags(listdatawithouttag);
													// for adding revision history
													String textdata = String.join("~~", aiv2.getRTFwithTags());
													aiv2.setParamValue(textdata);
												}
											}else{
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
										}

									}else{
										aiv2.setHasArray(paramCheck.getHasArray());

										String richText = "";
										if(aivListArray.getJSONObject(i).has("paramValue")){
											richText = aivListArray.getJSONObject(i).get("paramValue").toString();
											if(globalsetting.getGlobalSettingFlag() == 1){
												richText = commonUtils.httpSanitizerForCkEditor(richText);
											}
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();
										}
										aiv2.setParamValue(richText);
										String textdata = null;
										if (richText != null) { 
											textdata = Jsoup.parse(richText).text();
											aiv2.setRTFPlainText(textdata);
										}
									}
								}else if(paramCheck.getParamTypeId() == 8) {
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.DERIVED_PARAMETERS_NOT_ALLOWED)))
													.build();
								}
								else if(paramCheck.getParamTypeId() == 9){
			        				String duplicateLdapVal = URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8");
			        				List<String> ParamValList = new ArrayList<String>(Arrays.asList(duplicateLdapVal.split("~~")));
			        				boolean duplicateFlag = false;
									Set<String> duplicate = new HashSet<String>();
									duplicate.addAll(ParamValList);
									if(duplicate.size()<ParamValList.size()){
										duplicateFlag = true;
									}
									if(duplicateFlag){
										retStat = Status.BAD_REQUEST;
										retScsFlr = Constants.FAILURE;
										retMsg = "DUPLICATE_DATA_NOT_ALLOWED";
										retStatScsFlr = Constants.STATUS_FAILURE;
										return Response.status(retStat)
												.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
												.build();
									}
			        				Map<String,Integer> finalParamValList = commonUtils.ldapDataconstruction(URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8"),assetName ,aivListArray.getJSONObject(i).get("assetParamName").toString(),conn);
			        				aiv2.setLdapMappingValue(finalParamValList);
			        				
			        			}
								else{
									if(aivListArray.getJSONObject(i).has("paramValue")){
										aiv2.setMandatory(paramCheck.isHasMandatoryValue());
										aiv2.setParamValue(aivListArray.getJSONObject(i).get("paramValue").toString());	
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();
									}
								}

							}
							aiv2.setAssetInstVersionId(assetInstance.getAssetInstVersionId());
		        			aiv2.setConn(conn);
		        			aiv2.setLog(log);
		        			aiv2.setUserId(user.getUserId());
		        			aiv2.setAssetName(assetName);
		        			aiv2.setAssetInstName(assetInstName);
							ListOfAssetInstanceProperties.add(aiv2);
							break;

						}
					}
				}catch(org.json.JSONException e){
					return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
									.build();

				} catch (RepoproException e) {
					e.printStackTrace();
					throw new RepoproException(e.getMessage());
				}

				if(CommonUtils.customParameterPluginNoficationClassName != null && CommonUtils.customParameterPluginPath != null){

    				if(!CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") && !CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

    					Class notificationInterface = CustomParameterPluginUtilies.getplugin();

    					if(notificationInterface != null){
    						Method method = null;
    						Method relatedParamChangeMethod = null;
    						try {
    							method = notificationInterface.getMethod("notifyOnParameterValueChanges",new Class[]{List.class});
    							relatedParamChangeMethod = notificationInterface.getMethod("notifyOnParameterValueChangesBasedOnOtherParameter",new Class[]{List.class});
    							
    						} catch (NoSuchMethodException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						} catch (SecurityException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						}

    						Object instance = null;
    						try {
    							instance = notificationInterface.newInstance();
    						} catch (InstantiationException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						} catch (IllegalAccessException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						}	


    						try{
    							parameterChangeNotification = method.invoke(instance,ListOfAssetInstanceProperties);
    							
    							if(parameterChangeNotification != null){
    								JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

    								if(jsonObject.has("Response Status")){
    									String status = jsonObject.getString("Response Status");
    									if(status.equalsIgnoreCase("failure")){
    										retStat = Status.INTERNAL_SERVER_ERROR;;
    				        				retScsFlr = status;
    				        				retMsg = jsonObject.getString("Response Message");
    				        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

    				        				return Response.status(retStat)
    				        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
    									}
    								}
    							}
    							
    							
    							relatedParamChangeNotification = relatedParamChangeMethod.invoke(instance,ListOfAssetInstanceProperties);
    							if(relatedParamChangeNotification != null){
    								JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

    								if(jsonObject.has("Response Status")){
    									String status = jsonObject.getString("Response Status");
    									if(status.equalsIgnoreCase("failure")){
    										retStat = Status.INTERNAL_SERVER_ERROR;;
    				        				retScsFlr = status;
    				        				retMsg = jsonObject.getString("Response Message");
    				        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

    				        				return Response.status(retStat)
    				        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
    									}
    								}
    							}
    						}
    						catch (IllegalAccessException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						} catch (IllegalArgumentException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						} catch (InvocationTargetException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						}catch(Exception e){
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						}
    					}else{
    						retStat = Status.BAD_REQUEST;
	        				retScsFlr = Constants.FAILURE;
	        				retMsg = "Invalid Plugin configuration";
	        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	        				return Response.status(retStat)
	        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
    					}
    				}
    				if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")|| CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

	    				retStat = Status.BAD_REQUEST;
	    				retScsFlr = Constants.FAILURE;
	    				retMsg = "Invalid Plugin configuration";
	    				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	    				return Response.status(retStat)
	    						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	    			}
    			}
				if(CommonUtils.customParameterPluginNoficationClassName != null){
					
					if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")){

	    				retStat = Status.BAD_REQUEST;
	    				retScsFlr = Constants.FAILURE;
	    				retMsg = "Invalid Plugin configuration";
	    				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	    				return Response.status(retStat)
	    						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	    			}
        		}else if(CommonUtils.customParameterPluginPath != null){
        			if( CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

	    				retStat = Status.BAD_REQUEST;
	    				retScsFlr = Constants.FAILURE;
	    				retMsg = "Invalid Plugin configuration";
	    				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	    				return Response.status(retStat)
	    						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	    			}
        		}
				}
				updatePropertiesResponse = aivRest.updateAssetInstancePropertiesRestHelper(assetName, assetInstName, versionName, parameterDetails, formParams, context, token, false, false, conn);
			
			} else {
				//return updateTaxonomiesResponse;
				retMsg = taxRes.getMessage();
				retScsFlr = taxRes.getStatus();
				retStatScsFlr = taxRes.getStatusCode();
				return  Response.status(updateTaxonomiesResponse.getStatus()).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			String statusCheckingPro = null;
			//String responseMsg = "";
				if(updatePropertiesResponse.getEntity() instanceof MyModelRest){
					modelRestPro = (MyModelRest) updatePropertiesResponse.getEntity();
				}

				if(modelRestPro != null){
					statusCode = updatePropertiesResponse.getStatus();
					statusMessage = modelRestPro.getMessage();
					statusCheckingPro = modelRestPro.getStatus();
				}else{
					MyModel propRes = (MyModel) updatePropertiesResponse.getEntity();
					statusCheckingPro =  propRes.getStatus();
					/*String[] splitResponseMsg = propRes.getMessage().split("`~~`");
				if(splitResponseMsg.length==2){
					responseMsg = splitResponseMsg[1];
				}*/
					List<Object> data = propRes.getResult();
					for (int i = 0; i < data.size(); i++) {
						String revHis = new String();
						revHis = (String) data.get(i);
						newParamDataForRevision = revHis;
					}
					propertiesKey = "P";
				}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, versionName, conn);
			
			Response saveDependencyResponse = null;
			if(statusCheckingPro.equalsIgnoreCase("SUCCESS")){
				if(addRelationshipData != null && !addRelationshipData.isEmpty()){
					//if(!addRelationshipData.isEmpty())
					// json construction for relationship Data
					String addreldatas = "";
					try{
					String jsonStr1 = addRelationshipData;
					JSONObject obj1 = new JSONObject(jsonStr1);
					String aivList = obj1.get("relationshipData").toString();
					JSONArray aivListArray = new JSONArray(aivList);
					AssetInstance relAI = new AssetInstance();
					List<AssetInstance> relAIList = new ArrayList<AssetInstance>();
					for (int i = 0; i < aivListArray.length(); i++) {
						Iterator itr = aivListArray.getJSONObject(i).keys();
						while (itr.hasNext()) {
							relAI = new AssetInstance();
							if(aivListArray.getJSONObject(i).has("assetName")){
								relAI.setAssetName(aivListArray.getJSONObject(i).get("assetName").toString());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();

								}
							if(aivListArray.getJSONObject(i).has("assetInstanceName")){
								relAI.setAssetInstName(aivListArray.getJSONObject(i).get("assetInstanceName").toString());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();

								}
							if(aivListArray.getJSONObject(i).has("assetInstanceVersionName")){
								relAI.setVersionName(aivListArray.getJSONObject(i).get("assetInstanceVersionName").toString());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();

								}
							if(aivListArray.getJSONObject(i).has("relationshipName")){
								relAI.setAssetRelationshipName(aivListArray.getJSONObject(i).get("relationshipName").toString());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();

								}
							relAIList.add(relAI);
							break;
						}
						
						
					}
					
					for(AssetInstance aiii : relAIList ){
						if(addreldatas.equalsIgnoreCase("")){
							addreldatas = aiii.getAssetName()+"|"+aiii.getAssetInstName()+"|"+aiii.getVersionName()+"|"+aiii.getAssetRelationshipName()+"~";
						}else{
							addreldatas = addreldatas + aiii.getAssetName()+"|"+aiii.getAssetInstName()+"|"+aiii.getVersionName()+"|"+aiii.getAssetRelationshipName()+"~";
						}
					}
					if(addreldatas.endsWith("~")){
						if (addreldatas != null && addreldatas.length() > 0 && addreldatas.charAt(addreldatas.length() - 1) == '~') {
							addreldatas = addreldatas.substring(0, addreldatas.length() - 1);
						}
					}
					}catch(org.json.JSONException e){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();
						
					} 
						saveDependencyResponse = aivRest.saveDependencyHelper(assetName, assetInstName, versionName, addreldatas, removeRelationshipData, token,conn);
					
						assetInstanceVer.setSrcAssetInstanceVersionId(String.valueOf(assetInstanceVer.getAssetInstVersionId()));
						List<AssetInstance> aivos = retFwdDependents(assetInstanceVer,conn);
						int i = 1;
						for(AssetInstance aivo : aivos){
							AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
							if(i == aivos.size()){
								if(!assetDef.isVersionable()){
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]";	
								}else{
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]";	
								}	
							}else{
								if(!assetDef.isVersionable()){
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
								}else{
									newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
								}
							}
							i++;
						}
						relationshipdataKey = "R";
					

				}else{
					json.put("message", Constants.ASSET_INSTANCE_DETAILS_CREATED/*+responseMsg*/);
					json.put("status", Constants.SUCCESS);
					json.put("statusCode", Constants.GET_STATUS_SUCCESS);
			        JSONObject j1 = null;
			        List<Object> finaldata = new ArrayList<Object>();
			        	j1 = new JSONObject();
			        	j1.put("assetInstanceId", assetInstance.getAssetInstId());
			        	j1.put("assetInstanceVersionId", assetInstance.getAssetInstVersionId());
			        	
			        	finaldata.add(j1);
					json.put("result", finaldata);

					String changeKey = "";
					changeKey = newInstanceKey+","+relationshipdataKey+","+propertiesKey;

					List<String> list = Arrays.asList(changeKey.split(","));
					List<String> finallist = new ArrayList<String>();
					for(String emptydata:list){
						if(!emptydata.equalsIgnoreCase("")){
							finallist.add(emptydata);
						}
					}
					String listString = String.join(",", finallist);

					AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();

					User user = userDao.retProfileForUserName(userName, conn);

					/*assetInstanceVersionManager.addRevisionData(listString, assetInstanceVer.getAssetInstVersionId(), assetInstanceVer.getVersionName(), 
							overview,newRelationshipDataForRevision, newParamDataForRevision, null, userName,user.getUserId(),"", conn);*/
					
					RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
					aivRevHist = new AivRevisionHistory();
					aivRevHist.setAivId(assetInstance.getAssetInstVersionId());
					aivRevHist.setRevId(assetInstance.getVersionName()+".0");
					aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					aivRevHist.setChangedKey(listString);
					aivRevHist.setOverviewData(overview);
					if(!newRelationshipDataForRevision.equalsIgnoreCase("")){
						aivRevHist.setRelationshipData(newRelationshipDataForRevision);
					}else{
						aivRevHist.setRelationshipData(null);
					}
					if(!newParamDataForRevision.equalsIgnoreCase("")){
						aivRevHist.setParameterData(newParamDataForRevision);
					}else{
						aivRevHist.setParameterData(null);
					}
					aivRevHist.setUserId(user.getUserId());
					aivRevHist.setUsedBy(null);
					if (log.isTraceEnabled()) {
						log.trace("addAssetInstanceHelper : call dao addRevisionData() method for adding revision data");
					}
					revisionHistoryDao.addRevisionData(aivRevHist, conn);
					
					AssetInstanceVersion aivo = new AssetInstanceVersion();
					aivo.setVersionName("1.0");
					aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					aivo.setAssetInstVersionId(aivRevHist.getAivId());
					assetInstVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
					
					//recent activity
					RecentActivity recentActivity = new RecentActivity();
					String action =  Constants.ACTIVITY_CREATE;
					RecentActivityDao recentActivityDao = new RecentActivityDao();
					String appendingMsg = "";
					
					if (asset.isVersionable() == true) {
						String log = user.getFullName() + ";" + action + ";"+ assetName + ";"+ assetInstName + ";"+ " Version " + assetInstance.getVersionName();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setDescription(log);
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
						recentActivity.setUser_id(user.getUserId());
					} else {
						String log = user.getFullName() + ";" + action + ";"+ assetName + ";"+ assetInstName + ";"+ appendingMsg;
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setDescription(log);
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
						recentActivity.setUser_id(user.getUserId());
					}
					
					recentActivityDao.addRecentActivity(recentActivity, conn);
					
					conn.commit();
					
					// normal mail for instance update 
					/*MailTemplateDao mailTemplateDao = new MailTemplateDao();
					SubscriptionDao subscriptionDao = new SubscriptionDao();

					MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					String mailTemp = null;
					*/
					AssetInstanceVersion aiv = assetInstVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(),conn);
					List<String> emailIds=subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);

					if(aiv.getVersionable() == true){
						MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
						mailTemp = mtVo1.getMailTemplate();
						String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
					}else{
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
						mailTemp = mtVo.getMailTemplate();
						String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%assetType%", aiv.getAssetName());
					}
					if(emailIds!=null){
						for(String emailId:emailIds){
							if(aiv.getVersionable() == true) {
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
							else {
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
						}
					}
					
					// taxonomy mail

					String assignTax = "";
					String unassignTax = "";
					String addTax = "";
					String removedTax = "";
					List<String> emailIdsList = new ArrayList<String>();
					List<String> emailIds1List = new ArrayList<String>();
					for(Map.Entry<String, String> entry : taxMap.entrySet()){
						assignTax = entry.getKey();
						unassignTax = entry.getValue();
					}
					//added taxonomies
					if(!assignTax.equalsIgnoreCase("")){
						String addedTaxEmail = "";
						String[] addTaxFinal = assignTax.split("~~");
						addTax = addTaxFinal[0];
						if(addTaxFinal.length == 2){
							addedTaxEmail = addTaxFinal[1];
						}
						emailIdsList = Arrays.asList(addedTaxEmail.split(","));
					}
					
					
					//unassigned taxonomies
					if(!unassignTax.equalsIgnoreCase("")){
						String[] unassignTaxFinal = unassignTax.split("~~");
						removedTax = unassignTaxFinal[0];
						String unassignTaxEmail = "";

						if(unassignTaxFinal.length == 2){
							unassignTaxEmail = unassignTaxFinal[1];
						}

						emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
					}
					//AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);


					if (!emailIdsList.isEmpty()) {
						//HashSet<String> listToSet = new HashSet<String>(emailIdsList);

						//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
						//String mailTemp = "";

						if (aiv.getVersionable() == true) {
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"assignTaxNameForAssetInstanceForVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
									.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
						} else {
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"assignTaxNameForAssetInstanceForNonVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",
									instName);
						}

						for (String emailId : emailIdsList) {
							//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
							if (addTax != "") {
								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
							}
						}
					}

					if (!emailIds1List.isEmpty()) {
						//HashSet<String> listToSet = new HashSet<String>(emailIds1List);

						//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
					//	String mailTemp = "";

						if (aiv.getVersionable() == true) {
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"unassignTaxNameForAssetInstanceForVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
									.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
						} else {
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"unassignTaxNameForAssetInstanceForNonVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
									.replaceAll("%assetInstName%", instName);
						}

						for (String emailId : emailIds1List) {

							//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
							if (removedTax != "") {
								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
							}
						}
					}
					if(parameterChangeNotification != null){
						JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

						if(jsonObject.has("Response Status")){
							String status = jsonObject.getString("Response Status");
							if(status.equalsIgnoreCase("success")){
								if(jsonObject.has("Notification")){
									String result1 = jsonObject.getString("Notification");
									result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
									if(!result1.equalsIgnoreCase("\"\"")){
										JSONObject maillist = new JSONObject(result1);
										if(maillist.has("Parameter changed")){
											String oldValue = maillist.getString("Old Value");
											List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
											String newValue = 	maillist.getString("New Value");
											List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
											String instanceName = maillist.getString("AssetInstanceName");
											String assetType = maillist.getString("Assetname");
											JSONArray emailArray = maillist.getJSONArray("Email Id");
											if(oldValue.equalsIgnoreCase("")){
												for(int j=0;j<emailArray.length();j++){
													SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
															MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
															MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																	+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
												}
											}else{
												for(int j=0;j<emailArray.length();j++){
													SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
															MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
															MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																	+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
												}
											}
										}
									}
								}
							}
						}
					}
					
					if(relatedParamChangeNotification != null){
						JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

						if(jsonObject.has("Response Status")){
							String status = jsonObject.getString("Response Status");
							if(status.equalsIgnoreCase("success")){
								if(jsonObject.has("Notification")){
									String result1 = jsonObject.getString("Notification");
									result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
									if(!result1.equalsIgnoreCase("\"\"")){
										JSONObject maillist = new JSONObject(result1);
										if(maillist.has("Parameter changed")){
											String oldValue = maillist.getString("Old Value");
											List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
											String newValue = 	maillist.getString("New Value");
											List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
											String instanceName = maillist.getString("AssetInstanceName");
											String assetType = maillist.getString("Assetname");
											JSONArray emailArray = maillist.getJSONArray("Email Id");
											if(oldValue.equalsIgnoreCase("")){
												for(int j=0;j<emailArray.length();j++){
													SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
															MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
															MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																	+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
												}
											}else{
												for(int j=0;j<emailArray.length();j++){
													SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
															MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
															MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																	+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
												}
											}
										}
									}
								}
							}
						}
					}
					
					return Response.status(retStat).entity(json.toString())
							.build();
				}
			} else{
				return updatePropertiesResponse;
			}
			
			if(saveDependencyResponse.getEntity() instanceof MyModelRest){
				modelRestSave = (MyModelRest) saveDependencyResponse.getEntity();
			}
			if(modelRestSave != null){
				statusCode = saveDependencyResponse.getStatus();
				statusMessage = modelRestSave.getMessage();
			}
			if(modelRestSave.getStatus().equalsIgnoreCase("SUCCESS")){
				json.put("message", Constants.ASSET_INSTANCE_DETAILS_CREATED/*+responseMsg*/);
				json.put("status", Constants.SUCCESS);
				json.put("statusCode", Constants.GET_STATUS_SUCCESS);

				 JSONObject j1 = null;
			        List<Object> finaldata = new ArrayList<Object>();
			        	j1 = new JSONObject();
			        	j1.put("assetInstanceId", assetInstance.getAssetInstId());
			        	j1.put("assetInstanceVersionId", assetInstance.getAssetInstVersionId());
			        	
			        	finaldata.add(j1);
					json.put("result", finaldata);
				
				String changeKey = "";
				changeKey = newInstanceKey+","+relationshipdataKey+","+propertiesKey;

				List<String> list = Arrays.asList(changeKey.split(","));
				List<String> finallist = new ArrayList<String>();
				for(String emptydata:list){
					if(!emptydata.equalsIgnoreCase("")){
						finallist.add(emptydata);
					}
				}
				String listString = String.join(",", finallist);

				AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();

				User user = userDao.retProfileForUserName(userName, conn);

				/*assetInstanceVersionManager.addRevisionData(listString, assetInstanceVer.getAssetInstVersionId(), assetInstanceVer.getVersionName(), 
						overview,newRelationshipDataForRevision, newParamDataForRevision, null, userName,user.getUserId(),"", conn);*/


				RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
				aivRevHist = new AivRevisionHistory();
				aivRevHist.setAivId(assetInstance.getAssetInstVersionId());
				aivRevHist.setRevId(assetInstance.getVersionName()+".0");
				aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				aivRevHist.setChangedKey(listString);
				aivRevHist.setOverviewData(overview);
				if(!newRelationshipDataForRevision.equalsIgnoreCase("")){
					aivRevHist.setRelationshipData(newRelationshipDataForRevision);
				}else{
					aivRevHist.setRelationshipData(null);
				}
				if(!newParamDataForRevision.equalsIgnoreCase("")){
					aivRevHist.setParameterData(newParamDataForRevision);
				}else{
					aivRevHist.setParameterData(null);
				}
				aivRevHist.setUserId(user.getUserId());
				aivRevHist.setUsedBy(null);
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceHelper : call dao addRevisionData() method for adding revision data");
				}
				revisionHistoryDao.addRevisionData(aivRevHist, conn);

				//recent activity
				RecentActivity recentActivity = new RecentActivity();
				String action =  Constants.ACTIVITY_CREATE;
				RecentActivityDao recentActivityDao = new RecentActivityDao();
				String appendingMsg = "";
				
				if (asset.isVersionable() == true) {
					String log = user.getFullName() + ";" + action + ";"+ assetName + ";"+ assetInstName + ";"+ " Version " + assetInstance.getVersionName();
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(log);
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
					recentActivity.setUser_id(user.getUserId());
				} else {
					String log = user.getFullName() + ";" + action + ";"+ assetName + ";"+ assetInstName + ";"+ appendingMsg;
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(log);
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
					recentActivity.setUser_id(user.getUserId());
				}
				
				recentActivityDao.addRecentActivity(recentActivity, conn);
				
				conn.commit(); 
				
				// normal mail for instance update 
				
				/*MailTemplateDao mailTemplateDao = new MailTemplateDao();
				SubscriptionDao subscriptionDao = new SubscriptionDao();

				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				String mailTemp = null;
				*/
				AssetInstanceVersion aiv = assetInstVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(),conn);
				List<String> emailIds=subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);

				if(aiv.getVersionable() == true){
					MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
					mailTemp = mtVo1.getMailTemplate();
					String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
				}else{
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
					mailTemp = mtVo.getMailTemplate();
					String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%assetType%", aiv.getAssetName());
				}
				if(emailIds!=null){
					for(String emailId:emailIds){
						if(aiv.getVersionable() == true) {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
						else {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
					}
				}
				
				// taxonomy mail

				String assignTax = "";
				String unassignTax = "";
				String addTax = "";
				String removedTax = "";
				List<String> emailIdsList = new ArrayList<String>();
				List<String> emailIds1List = new ArrayList<String>();
				for(Map.Entry<String, String> entry : taxMap.entrySet()){
					assignTax = entry.getKey();
					unassignTax = entry.getValue();
				}
				//added taxonomies
				if(!assignTax.equalsIgnoreCase("")){
					String addedTaxEmail = "";
					String[] addTaxFinal = assignTax.split("~~");
					addTax = addTaxFinal[0];
					if(addTaxFinal.length == 2){
						addedTaxEmail = addTaxFinal[1];
					}
					emailIdsList = Arrays.asList(addedTaxEmail.split(","));
				}
				
				
				//unassigned taxonomies
				if(!unassignTax.equalsIgnoreCase("")){
					String[] unassignTaxFinal = unassignTax.split("~~");
					removedTax = unassignTaxFinal[0];
					String unassignTaxEmail = "";

					if(unassignTaxFinal.length == 2){
						unassignTaxEmail = unassignTaxFinal[1];
					}

					emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
				}
				//AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);


				if (!emailIdsList.isEmpty()) {
					//HashSet<String> listToSet = new HashSet<String>(emailIdsList);

					//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
					//String mailTemp = "";

					if (aiv.getVersionable() == true) {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"assignTaxNameForAssetInstanceForVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
								.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
					} else {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"assignTaxNameForAssetInstanceForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",
								instName);
					}

					for (String emailId : emailIdsList) {
						//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						if (addTax != "") {
							SendEmail.sendTextMail(mailConfig, emailId,
									MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
											+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
					}
				}

				if (!emailIds1List.isEmpty()) {
					//HashSet<String> listToSet = new HashSet<String>(emailIds1List);

					//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
				//	String mailTemp = "";

					if (aiv.getVersionable() == true) {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"unassignTaxNameForAssetInstanceForVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
								.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
					} else {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"unassignTaxNameForAssetInstanceForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
								.replaceAll("%assetInstName%", instName);
					}

					for (String emailId : emailIds1List) {

						//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						if (removedTax != "") {
							SendEmail.sendTextMail(mailConfig, emailId,
									MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
											+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
					}
				}
				
				if(parameterChangeNotification != null){
					JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result1 = jsonObject.getString("Notification");
								result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
								if(!result1.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result1);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}
				
				if(relatedParamChangeNotification != null){
					JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result1 = jsonObject.getString("Notification");
								result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
								if(!result1.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result1);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}
				
				
				return Response.status(retStat).entity(json.toString())
						.build();
			}else{
				return saveDependencyResponse;
			}
			
			
			
					
		}catch (RepoproException e) {
			log.error("addInstanceUpdatePropertiesRelationships: SQL Exception addAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}catch (Exception e) {
			log.error("addInstanceUpdatePropertiesRelationships: SQL Exception addAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addInstanceUpdatePropertiesRelationships : " + Constants.LOG_CONNECTION_CLOSE);
			}
			if(conn != null){
				DBConnection.closeDbConnection(conn);
			}
		}

		if (log.isTraceEnabled()) {
			log.trace("addInstanceUpdatePropertiesRelationships || Exit");
		}

		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/**
	 * @method createAssetInstance
	 * @param queryParamValue
	 * @param formDataValue
	 * @param bodyParts
	 * @param context
	 * @return Response
	 */
	@POST
	@Encoded
	@Path("/updateAssetInstance")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	public Response createAssetInstance(@FormDataParam("assetInstanceDetails") String assetInstanceDetails,
			FormDataMultiPart bodyParts,@Context ServletContext context){

		if (log.isTraceEnabled()) {
			log.trace("createAssetInstance || Begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("createAssetInstance : "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			CommonUtils commonUtils = new CommonUtils();
			AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
			TaggingDao taggingDao = new TaggingDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			AssetDao assetDao = new AssetDao();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			UserDao userDao = new UserDao();
			AssetInstanceVersion assetInstanceVersion = new AssetInstanceVersion();
			AssetInstance assetInstance = new AssetInstance();
			TaggingMaster taggingMaster = new TaggingMaster();
			List<Long> addDestassetinstversionIds = new ArrayList<Long>();
			List<Long> removeDestassetinstversionIds = new ArrayList<Long>();
			List<Long> addRelationshipIds = new ArrayList<Long>();
			List<Long> removeRelationshipIds = new ArrayList<Long>();
			Map<Long, String> names = new HashMap<Long, String>();
			AivRevisionHistory aivRevHist = new AivRevisionHistory();
			String instanceRenameKey = "";
			String newInstanceKey = "";
			String overviewKey = "";
			String relationshipdataKey = "";
			String propertiesKey = "";
			String instanceRenameing = "";		
			String overview = "";
			String newRelationshipDataForRevision = "";
			String newParamDataForRevision = "";
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			RecentActivity recentActivity = new RecentActivity();
			WorkflowDao workflowDao = new WorkflowDao();
			String action = "";
			String appendingMsg = "";
			Map<String, String> taxMap = new HashMap<String, String>();
			String jsonStr = assetInstanceDetails;
			JSONObject obj = new JSONObject(jsonStr);

			//flag to differentiate between add and update function
			String jsonAddFlag = obj.getString("addFlag");
			
			Long assetId = obj.getLong("assetId");
			Long userId = obj.getLong("userId");
			int activeFlag = obj.getInt("activeFlag");
			String assetName = URLDecoder.decode(obj.get("assetName").toString(), "UTF-8");
			String userName = obj.get("userName").toString();
			String versionName = obj.get("versionName").toString();
			String assetInstName = URLDecoder.decode(obj.get("assetInstName").toString(), "UTF-8");
		
			String addRelationship = "";
			String addDestAivIds = "";
			String removeRelationship = "";
			String removeDestAivIds = "";
			if(jsonStr.contains("addRelationshipIds")){
				addRelationship =  obj.get("addRelationshipIds").toString();
				JSONArray addRelationshipArray = new JSONArray(addRelationship);
				if (addRelationshipArray != null) { 
					for (int i=0;i<addRelationshipArray.length();i++){ 
						addRelationshipIds.add(Long.parseLong(addRelationshipArray.getString(i)));
					} 
				} 
			}
			if(jsonStr.contains("addDestAivIds")){
				addDestAivIds =  obj.get("addDestAivIds").toString();
				JSONArray addDestAivIdsArray = new JSONArray(addDestAivIds);
				if (addDestAivIdsArray != null) { 
					for (int i=0;i<addDestAivIdsArray.length();i++){ 
						addDestassetinstversionIds.add(Long.parseLong(addDestAivIdsArray.getString(i)));
					} 
				} 
			}
			if(jsonStr.contains("removeRelationshipIds")){
				removeRelationship =  obj.get("removeRelationshipIds").toString();
				JSONArray removeRelationshipArray = new JSONArray(removeRelationship);
				if (removeRelationshipArray != null) { 
					for (int i=0;i<removeRelationshipArray.length();i++){ 
						removeRelationshipIds.add(Long.parseLong(removeRelationshipArray.getString(i)));
					} 
				} 
			}
			if(jsonStr.contains("removeDestAivIds")){
				removeDestAivIds =  obj.get("removeDestAivIds").toString();
				JSONArray removeDestAivIdsArray = new JSONArray(removeDestAivIds);
				if (removeDestAivIdsArray != null) { 
					for (int i=0;i<removeDestAivIdsArray.length();i++){ 
						removeDestassetinstversionIds.add(Long.parseLong(removeDestAivIdsArray.getString(i)));
					} 
				}
			}
			
			//get user details
			if (log.isTraceEnabled()) {
				log.trace("createAssetInstance: call dao getUserIdByUserName() method to fetch user details");
			}
			User user = userDao.getUserIdByUserName(userName, null);
			
			if (log.isTraceEnabled()) {
				log.trace("createAssetInstance: call dao retAssetDetail() method to fetch asset details");
			}
			AssetDef asset = assetInstanceDao.retAssetDetail(assetName,conn);
			
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setAssetId(assetId);
			assetInstance.setVersionName(versionName);
			assetInstance.setAssetName(assetName);
			
			//get global setting setting details
			if (log.isTraceEnabled()){
				log.trace("createAssetInstance || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
			
			//to add new instance
			if(jsonAddFlag.equals("true")){
				action = Constants.ACTIVITY_CREATE;
				String descSafeHTML = "";
				
				if(globalsetting.getGlobalSettingFlag() == 1){
					descSafeHTML = commonUtils.httpSanitizerForCkEditor(obj.get("description").toString());
				}else{
					descSafeHTML = obj.get("description").toString();
				}

				if(descSafeHTML.equalsIgnoreCase("")){
					retMsg = Constants.PLEASE_PROVIDE_DESCRIPTION;
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
				assetInstance.setDescription(descSafeHTML);
				if (log.isTraceEnabled()) {
					log.trace("createAssetInstance: call dao addAssetInstanceHelper() method to create asset instance");
				}
				Response response = addAssetInstanceHelper(assetInstance,userName,false,true,false,conn);
				MyModel res = (MyModel) response.getEntity();
				List<Object> data = res.getResult();
				if(res.getStatus().equals("FAILURE")){
					return response;
				}
				for (int i = 0; i < data.size(); i++) {
					AssetInstance ai = new AssetInstance();
					ai = (AssetInstance) data.get(i);
					assetInstance.setAssetInstId(ai.getAssetInstId());
					assetInstance.setAssetInstVersionId(ai.getAssetInstVersionId());
				}
				//revision history string  for add instance
				AssetInstanceVersion aivForAddingNewRevision = assetInstanceVersionDao
						.getAssetInstanceVersion(assetInstance.getAssetInstId(),assetInstance.getVersionName(), conn);
				if(aivForAddingNewRevision != null){
					newInstanceKey = "N";
					overview = aivForAddingNewRevision.getDescription();
				}
			}
			
			//to update existing instance name and description
			else if(jsonAddFlag.equals("false")){
				action = Constants.ACTIVITY_MODIFY;
				Long assetInstanceId = obj.getLong("assetInstanceId");
				Long assetInstVersionId = obj.getLong("assetInstVersionId");
				
				boolean lockFlag = false;
				List<GlobalSetting> globalSetting = globalSettingDao.getGlobalSetting(conn);
				for(GlobalSetting g : globalSetting){
					if(g.getGlobalLockSettingFlag() == 1){
						lockFlag = true;
						break;
					}
				}
				
				if(lockFlag){
					AssetInstanceVersion aiv = assetInstanceVersionDao.retAssetInstanceVersion(assetInstVersionId, userName, conn);
					if(aiv.getLockedBy() == null){
						retMsg = Constants.ASSET_INSTANCE_VERSION_ALREADY_UNLOCKED;
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retStatScsFlr = Constants.GET_STATUS_SUCCESS;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}
					
					if(!aiv.getLockedBy().equalsIgnoreCase(userName)){
						retMsg = Constants.ASSET_INSTANCE_VERSION_ALREADY_LOCKED;
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retStatScsFlr = Constants.GET_STATUS_SUCCESS;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}
					
					LocalDateTime dateTime = LocalDateTime.now();
					LocalDateTime lockTime = aiv.getLockTime().toLocalDateTime();
					if(aiv.getLockedBy().equalsIgnoreCase(userName)){
						if(dateTime.isAfter(lockTime)){
							retMsg = Constants.LOCK_TIME_EXPIRED;
							retStat = Status.OK;
							retScsFlr = Constants.FAILURE;
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
					}
				}
								
				assetInstance.setAssetInstId(assetInstanceId);
				assetInstance.setAssetInstVersionId(assetInstVersionId);
				String oldName = assetInstance.getAssetInstName();
				if(!obj.get("newAssetInstanceName").toString().equalsIgnoreCase("")){
					//String newAssetInstanceName = obj.get("newAssetInstanceName").toString();
					String newAssetInstanceName = URLDecoder.decode(obj.get("newAssetInstanceName").toString(), "UTF-8");
					Response instanceResponse = updateAssetInstanceNameHelper(userId, newAssetInstanceName, assetInstance,true, conn);
					MyModel instanceRes = (MyModel) instanceResponse.getEntity();
					if(instanceRes.getStatus().equals("FAILURE")){
						return instanceResponse;
					}
					instanceRenameing = oldName+"<!!>"+assetInstance.getAssetInstName();
					instanceRenameKey = "IR";
				}
		        if(!obj.get("newDescription").toString().equalsIgnoreCase("")){
		        	
		        	String newDescription = obj.get("newDescription").toString();
		        	if(globalsetting.getGlobalSettingFlag() == 1){
		        		newDescription = commonUtils.httpSanitizerForCkEditor(newDescription);  
		        	}
					//String newdescSafeHTML = commonUtils.httpSanitizerForCkEditor(obj.get("newDescription").toString());

		        	assetInstance.setNewDescription(newDescription);
		        	Response descResponse = updateAssetInstanceDescriptionHelper(assetInstance,userName,true,conn);
		        	MyModel descRes = (MyModel) descResponse.getEntity();
		        	if(descRes.getStatus().equals("FAILURE")){
		        		return descResponse;
		        	}
		        	overview = assetInstance.getNewDescription();
		        	overviewKey = "O";
		        }
			}
			
	        obj.put("assetInstanceVersionId",assetInstance.getAssetInstVersionId());
	        
	        //to update tags
	        if(jsonStr.contains("tagNames")){
	        	String tagNames = obj.get("tagNames").toString();
	        	if(!tagNames.equalsIgnoreCase("")){
	        		String[] keyValuePairs = tagNames.split(",");
	        		Long j = 1L;
	        		for(String pair : keyValuePairs)                        
	        		{
	        			names.put(j, pair);
	        			j++;
	        		}
	        	}
	        	taggingMaster.setAssetInstanceVersionId(assetInstance.getAssetInstVersionId());
	        	taggingMaster.setTagNames(names);
	        	taggingMaster.setUserId(userId);
	        	taggingDao.addTags(taggingMaster, conn);
	        }
	        
	       //to update taxonomies
	        if(jsonStr.contains("TaxonomyIds")){
				String TaxonomyIds = obj.get("TaxonomyIds").toString();
	        	Response taxResponse = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(assetInstance.getAssetInstVersionId(),
	        			TaxonomyIds,asset.isVersionable(),assetInstance.getVersionName(),assetInstance.getAssetInstName(),true,conn);
	        	MyModel taxRes = (MyModel) taxResponse.getEntity();
	        	taxMap = taxRes.getParamValues();
		        if(taxRes.getStatus().equals("FAILURE")){
		        	return taxResponse;
		        }
	        }
	        //to update instance relationship data
	       
	        if(!removeDestassetinstversionIds.isEmpty() || !addDestassetinstversionIds.isEmpty() 
	        		|| !removeRelationshipIds.isEmpty() || !addRelationshipIds.isEmpty()){
	        	assetInstanceVersion.setRemovedDestAssetInstVersionIds(removeDestassetinstversionIds);
	        	assetInstanceVersion.setAddDestAssetInstVersionIds(addDestassetinstversionIds);
	        	assetInstanceVersion.setRemovedRelationshipIds(removeRelationshipIds);
	        	assetInstanceVersion.setAddRelationshipIds(addRelationshipIds);
	        	assetInstanceVersion.setSrcAssetInstanceVersionId(assetInstance.getAssetInstVersionId().toString());
	        	assetInstanceVersion.setAssetId(assetInstance.getAssetId());
	        	assetInstanceVersion.setAssetName(assetName);
	        	assetInstanceVersion.setAssetInstanceId(assetInstance.getAssetInstId());
	        	assetInstanceVersion.setVersionName(assetInstance.getVersionName());
	        	assetInstanceVersion.setAssetInstName(assetInstance.getAssetInstName());
	        	assetInstanceVersion.setAssetName(assetInstance.getAssetName());
	        	Response relResponse = saveDependencyHelper(assetInstanceVersion,userName,true,conn);
	        	MyModel relRes = (MyModel) relResponse.getEntity();
	        	if(relRes.getStatus().equals("FAILURE")){
	        		return relResponse;
	        	}

				if (log.isTraceEnabled()) {
					log.trace("saveDependencyHelper ||call Helper method retFwdDependents() to get srcassetinstanceversion dependents");
				}
				List<AssetInstance> aivos = retFwdDependents(assetInstanceVersion,conn);
				int i = 1;
				for(AssetInstance aivo : aivos){
					AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
					if(i == aivos.size()){
						if(!assetDef.isVersionable()){
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]";	
						}else{
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]";	
						}	
					}else{
						if(!assetDef.isVersionable()){
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
						}else{
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
						}
					}
					i++;
				}
				relationshipdataKey = "R";
	        }
	        
	        //to update parameter values
	        //mandatory parameter validation at object level
	        
	        	List<AssetParamDef> assetParamdef = assetDao.getParamsDetails(userName,assetId,conn);
	        	if(jsonAddFlag.equals("true")){
	        		if(obj.get("parameterList").toString().equalsIgnoreCase("")){	
	        			for(AssetParamDef mandatoryCheck:assetParamdef){
	        				if(mandatoryCheck.isHasMandatoryValue()){
	        					boolean editFlag = false;
	        					if(!userName.equalsIgnoreCase("admin")){
	        						List<GroupDetails> gd = assetDao.getAssetCategoryEditAccessForPropertiesAivPage(userName,mandatoryCheck.getAssetCategoryId(), conn);
	        						for(GroupDetails gd1 : gd){
	        							if(gd1.getEditAccess() == 1L){
	        								editFlag = true;
	        								break;
	        							}
	        						}
	        					}else{
	        						editFlag = true;
	        					}
	        					if(editFlag){
	        						if(mandatoryCheck.isHasMandatoryValue()){
	        							return Response
	        									.status(Status.OK)
	        									.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        											Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        											.build();
	        						}
	        					}

	        				}// mandatory 
	        			}// for loop 
	        		}
	        	}else{
	        	// as per rest api changes 

        		if(obj.get("parameterList").toString().equalsIgnoreCase("")){	
        			for(AssetParamDef mandatoryCheck:assetParamdef){
        				if(mandatoryCheck.isHasMandatoryValue()){
        					boolean editFlag = false;
        					if(!userName.equalsIgnoreCase("admin")){
            					List<GroupDetails> gd = assetDao.getAssetCategoryEditAccessForPropertiesAivPage(userName,mandatoryCheck.getAssetCategoryId(), conn);
            					for(GroupDetails gd1 : gd){
            						if(gd1.getEditAccess() == 1L){
            							editFlag = true;
            							break;
            						}
            					}
            				}else{
            					editFlag = true;
            				}
        					if(editFlag){
								
								if(mandatoryCheck.isHasStaticValue()){
									
									AssetParamDef ap = assetDao.getParamIdForAssetAndParamName(
											assetName, mandatoryCheck.getAssetParamName(), conn);
									
									if(ap.getParamTypeId() == 3){
										if(ap.getFileName()== null ||ap.getFileName().equalsIgnoreCase("")){
											return Response
													.status(Status.OK)
													.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
															.build();

										}
										
									}else{
										if(ap.getStaticValue() == null || ap.getStaticValue().equalsIgnoreCase("")){
											return Response
													.status(Status.OK)
													.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
															.build();
										}
									}
								}// end of static loop
								else{
								ParameterValues	pv = assetDao.getParameterForAssetInstParamAndVersionId(
											mandatoryCheck.getAssetParamName(), assetInstance.getAssetInstVersionId(), conn);
								
									if(mandatoryCheck.getParamTypeId() == 3){
										if(pv == null || pv.getFileName() == null || pv.getFileName().equalsIgnoreCase("")){
											return Response
													.status(Status.OK)
													.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
															.build();

										}
									}else if(mandatoryCheck.getParamTypeId() == 1 && mandatoryCheck.getHasArray()== 1){
										if(pv == null || pv.getTextDataList() == null|| pv.getTextDataList().isEmpty()){

											return Response
													.status(Status.OK)
													.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
															.build();

										}
									}else if(mandatoryCheck.getParamTypeId() == 7 && mandatoryCheck.getHasArray()== 1){
										if(pv == null ||pv.getRTFwithTags() == null|| pv.getRTFwithTags().isEmpty()){
											return Response
													.status(Status.OK)
													.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
															.build();
										}
									}else if(mandatoryCheck.getParamTypeId() == 9){
										if(pv == null ||pv.getLdapMappingMap() == null|| pv.getLdapMappingMap().isEmpty()){
											return Response
													.status(Status.OK)
													.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
															.build();
										}
									}
									else{
										if(pv == null ||pv.getValue() == null|| pv.getValue().equalsIgnoreCase("")){
											return Response
													.status(Status.OK)
													.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
															.build();
										}
								}
							}// end of non-static loop
							}//edit access loop
        					
        				}// mandatory 
        			}// entire for loop
        		}
	       }
	        
	        	
	      //parameter list construction from hidden variable
	        	Object parameterChangeNotification = null;
	        	Object relatedParamChangeNotification = null;
	          if(!obj.get("parameterList").toString().equalsIgnoreCase("")){
	        	List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();
	        	AssetInstanceVersion aiv = null;
	        	String newFileNameForImageOnly = "";
	        	String aivParameterList = obj.get("parameterList").toString();
	        	JSONArray aivParameterListArray = new JSONArray(aivParameterList);
	        	for (int i = 0; i < aivParameterListArray.length(); i++) {
	        		Iterator itr = aivParameterListArray.getJSONObject(i).keys();
	        		while (itr.hasNext()) {
	        			aiv = new AssetInstanceVersion();
	        			Object keyName = itr.next();

	        			aiv.setAsset_category_name(aivParameterListArray.getJSONObject(i).get("asset_category_name").toString());
	        			aiv.setAssetParamId(aivParameterListArray.getJSONObject(i).getLong("assetParamId"));
	        			aiv.setAssetParamName(aivParameterListArray.getJSONObject(i).get("assetParamName").toString());
	        			aiv.setIsStatic(aivParameterListArray.getJSONObject(i).getInt("isStatic"));
	        			aiv.setParamTypeId(aivParameterListArray.getJSONObject(i).getLong("paramTypeId"));

	        			if (aiv.getParamTypeId() == 3){
	        				newFileNameForImageOnly = aivParameterListArray.getJSONObject(i).get("newFileName").toString();
	        				if(!aivParameterListArray.getJSONObject(i).get("fileName").toString().isEmpty() && !newFileNameForImageOnly.isEmpty()){
	        					aiv.setFileName(newFileNameForImageOnly);
	        				} else if(!newFileNameForImageOnly.isEmpty()){
	        					aiv.setFileName(newFileNameForImageOnly);
	        				} else {
	        					aiv.setFileName(aivParameterListArray.getJSONObject(i).get("fileName").toString());
	        				}
	        			}else if(aiv.getParamTypeId() == 7){
	        				aiv.setHasArray(aivParameterListArray.getJSONObject(i).getInt("isArray"));
	        				if(aiv.getHasArray() == 1){
	        					JSONObject richTextdataJsonObject = aivParameterListArray.getJSONObject(i).getJSONObject("rich_text_data");
	        					JSONArray withTagArray = null;
	        					JSONArray withoutTagArray = null;
	        					if(richTextdataJsonObject.has("without_tag")){
	        						withoutTagArray = richTextdataJsonObject.getJSONArray("without_tag");
	        					}
	        					if(richTextdataJsonObject.has("with_tag")){
	        						withTagArray = richTextdataJsonObject.getJSONArray("with_tag");
	        					}
	        					if(withTagArray != null){
	        						List<String> withTags = new ArrayList<String>();
	        						for(int j=0;j<withTagArray.length();j++){
	        							String textString = withTagArray.getJSONObject(j).get("textField").toString();
	        							textString = URLDecoder.decode(textString, "UTF-8");
	        							if(globalsetting.getGlobalSettingFlag() == 1){
	        								textString = commonUtils.httpSanitizerForCkEditor(textString);
	        							}
	        							withTags.add(textString);
	        						}
	        						aiv.setRTFwithTags(withTags);
	        						// for adding revision history
	        						String textdata = String.join("~~", aiv.getRTFwithTags());
	        						aiv.setParamValue(textdata);
	        					}
	        					if(withoutTagArray != null){
	        						List<String> withoutTags = new ArrayList<String>();
	        						for(int k=0;k<withoutTagArray.length();k++){
	        							String textString = withoutTagArray.getJSONObject(k).get("textField").toString();
	        							withoutTags.add(URLDecoder.decode(textString, "UTF-8"));
	        						}
	        						aiv.setRTFwithOutTags(withoutTags);
	        					}
	        				}else{
	        					JSONObject richTextdataJsonObject = aivParameterListArray.getJSONObject(i).getJSONObject("rich_text_data");
	        					String withTagArray = null;
	        					String withoutTagArray = null;
	        					//String safeHTML = null;
	        					if(richTextdataJsonObject.has("without_tag")){
	        						withoutTagArray = richTextdataJsonObject.get("without_tag").toString();
	        					}
	        					if(richTextdataJsonObject.has("with_tag")){
	        						withTagArray = richTextdataJsonObject.get("with_tag").toString();
	        						if(globalsetting.getGlobalSettingFlag() == 1){
	        							withTagArray = commonUtils.httpSanitizerForCkEditor(URLDecoder.decode(withTagArray, "UTF-8"));
	        						}else{
	        							withTagArray = URLDecoder.decode(withTagArray, "UTF-8");
	        						}
	        					}
	        					aiv.setRTFPlainText(URLDecoder.decode(withoutTagArray, "UTF-8"));
	        					aiv.setParamValue(withTagArray);
	        				}
	        			}else if (aiv.getParamTypeId() == 1){
	        				if(aiv.getIsStatic() == 1){
	        					String encodeval = URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(), "UTF-8");
	        					if(globalsetting.getGlobalSettingFlag() == 1){
    								encodeval = commonUtils.httpSanitizerForPlainText(encodeval);
    							}
	        					aiv.setParamValue(encodeval);
	        				}else{
	        					aiv.setHasArray(aivParameterListArray.getJSONObject(i).getInt("isArray"));
	        					if(aiv.getHasArray() == 1){
	        						JSONArray textdataJsonArray = aivParameterListArray.getJSONObject(i).getJSONArray("text_data");
	        						List<String> textDataList = new ArrayList<String>();
	        						for(int ii=0;ii<textdataJsonArray.length();ii++){
	        							String encodeval = URLDecoder.decode(textdataJsonArray.getString(ii), "UTF-8");
	        							if(globalsetting.getGlobalSettingFlag() == 1){
	        								encodeval = commonUtils.httpSanitizerForPlainText(encodeval);
	        							}
	        							textDataList.add(encodeval);
	        						}
	        						aiv.setTextDataList(textDataList);
	        						
	        						// for adding revision history
	        						String textdata = String.join("~~", aiv.getTextDataList());
	        						
	        						aiv.setParamValue(textdata);
	        					}else{
	        						String encodeval = URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(), "UTF-8");
	        						if(globalsetting.getGlobalSettingFlag() == 1){
	        							encodeval = commonUtils.httpSanitizerForPlainText(encodeval);
	        						}
	        						aiv.setParamValue(encodeval);
	        					}
	        				}
	        			}else if(aiv.getParamTypeId() == 9){
	        				
	        				//Map<String,Integer> finalParamValList = commonUtils.ldapDataconstruction(URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8"),assetName ,aiv.getAssetParamName(),conn);
	        				
	        				Map<String,Integer> finalParamValList = new HashMap<String, Integer>();
	        				String paramVal = URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8");

	        				ObjectMapper mapper = new ObjectMapper();
	        				finalParamValList = mapper.readValue(paramVal, new TypeReference<Map<String, Integer>>(){});
	        					        				
	        				aiv.setLdapMappingValue(finalParamValList);
	        				
	        			}else {
	        				aiv.setParamValue(URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8"));
	        			}
	        			aiv.setAssetInstVersionId(assetInstance.getAssetInstVersionId());
	        			aiv.setConn(conn);
	        			aiv.setLog(log);
	        			aiv.setUserId(userId);
	        			aiv.setAssetName(assetName);
	        			aiv.setAssetInstName(assetInstName);
	        			ListOfAssetInstanceProperties.add(aiv);
	        			break;
	        		}
	        	}
	        	//mandatory parameter validation at each parameter
	        	
	        	//if(jsonAddFlag.equals("true")){
	        		for(AssetParamDef mandatoryCheck:assetParamdef){ 
	        			if(mandatoryCheck.isHasMandatoryValue()){
	        			boolean editFlag = false;
	        			if(!userName.equalsIgnoreCase("admin")){
	        				List<GroupDetails> gd = assetDao.getAssetCategoryEditAccessForPropertiesAivPage(userName,mandatoryCheck.getAssetCategoryId(), conn);
	        				for(GroupDetails gd1 : gd){
	        					if(gd1.getEditAccess() == 1L){
	        						editFlag = true;
	        						break;
	        					}
	        				}
	        			}else{
	        				editFlag = true;
	        			}
	        			if(editFlag){
	        				//if(mandatoryCheck.isHasMandatoryValue()){
	        					for(AssetInstanceVersion data:ListOfAssetInstanceProperties){
	        						if(mandatoryCheck.getAssetParamId().equals(data.getAssetParamId())){
	        							if(data.getParamTypeId() == 3){
	        								if(data.getFileName().equalsIgnoreCase("")){
	        									return Response
	        											.status(Status.OK)
	        											.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        													Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        													.build();
	        								}
	        							}else if(data.getParamTypeId() == 7){
	        								if(data.getHasArray() == 1){
	        									if(data.getRTFwithTags().get(0).equalsIgnoreCase("")){
	        										return Response
	        												.status(Status.OK)
	        												.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        														Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        														.build();
	        									}

	        								}else{
	        									if(data.getRTFPlainText().equalsIgnoreCase("")){
	        										return Response
	        												.status(Status.OK)
	        												.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        														Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        														.build();

	        									}
	        								}
	        							}else if(data.getParamTypeId() == 1){
	        								if(data.getHasArray() == 1){
	        									if(data.getTextDataList().get(0).equalsIgnoreCase("")){
	        										return Response
	        												.status(Status.OK)
	        												.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        														Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        														.build();
	        									}

	        								}else{
	        									if(data.getParamValue().equalsIgnoreCase("")){
	        										return Response
	        												.status(Status.OK)
	        												.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        														Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        														.build();

	        									}
	        								}
	        							}else if(data.getParamTypeId() == 9){
	        								if(data.getLdapMappingValue().isEmpty()){
	        									return Response
	        											.status(Status.OK)
	        											.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        													Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        											.build();
	        								}

	        							}else{
	        								if(data.getParamTypeId() != 5 && data.getParamTypeId() != 6){
	        									if(data.getParamValue().equalsIgnoreCase("")){
	        										return Response
	        												.status(Status.OK)
	        												.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        														Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        														.build();

	        									}
	        								}
	        							}
	        						}
	        					}
	        				//}
	        			}
	        		}// mandatory loop
	        		}
	        		
	        		
		        	
	        		if(CommonUtils.customParameterPluginNoficationClassName != null && CommonUtils.customParameterPluginPath != null){

	    				if(!CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") && !CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

	    					Class notificationInterface = CustomParameterPluginUtilies.getplugin();

	    					if(notificationInterface != null){
	    						Method method = null;
	    						Method relatedParamChangeMethod = null;
	    						try {
	    							method = notificationInterface.getMethod("notifyOnParameterValueChanges",new Class[]{List.class});
	    							relatedParamChangeMethod = notificationInterface.getMethod("notifyOnParameterValueChangesBasedOnOtherParameter",new Class[]{List.class});
	    							
	    						} catch (NoSuchMethodException e) {
	    							// TODO Auto-generated catch block
	    							e.printStackTrace();
	    							throw new RepoproException(e.getMessage());
	    						} catch (SecurityException e) {
	    							// TODO Auto-generated catch block
	    							e.printStackTrace();
	    							throw new RepoproException(e.getMessage());
	    						}

	    						Object instance = null;
	    						try {
	    							instance = notificationInterface.newInstance();
	    						} catch (InstantiationException e) {
	    							// TODO Auto-generated catch block
	    							e.printStackTrace();
	    							throw new RepoproException(e.getMessage());
	    						} catch (IllegalAccessException e) {
	    							// TODO Auto-generated catch block
	    							e.printStackTrace();
	    							throw new RepoproException(e.getMessage());
	    						}	


	    						try{
	    							parameterChangeNotification = method.invoke(instance,ListOfAssetInstanceProperties);
	    							
	    							if(parameterChangeNotification != null){
	    								JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

	    								if(jsonObject.has("Response Status")){
	    									String status = jsonObject.getString("Response Status");
	    									if(status.equalsIgnoreCase("failure")){
	    										retStat = Status.INTERNAL_SERVER_ERROR;;
	    				        				retScsFlr = status;
	    				        				retMsg = jsonObject.getString("Response Message");
	    				        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	    				        				return Response.status(retStat)
	    				        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	    									}
	    								}
	    							}
	    							
	    							
	    							relatedParamChangeNotification = relatedParamChangeMethod.invoke(instance,ListOfAssetInstanceProperties);
	    							if(relatedParamChangeNotification != null){
	    								JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

	    								if(jsonObject.has("Response Status")){
	    									String status = jsonObject.getString("Response Status");
	    									if(status.equalsIgnoreCase("failure")){
	    										retStat = Status.INTERNAL_SERVER_ERROR;;
	    				        				retScsFlr = status;
	    				        				retMsg = jsonObject.getString("Response Message");
	    				        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	    				        				return Response.status(retStat)
	    				        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	    									}
	    								}
	    							}
	    						}
	    						catch (IllegalAccessException e) {
	    							// TODO Auto-generated catch block
	    							e.printStackTrace();
	    							throw new RepoproException(e.getMessage());
	    						} catch (IllegalArgumentException e) {
	    							// TODO Auto-generated catch block
	    							e.printStackTrace();
	    							throw new RepoproException(e.getMessage());
	    						} catch (InvocationTargetException e) {
	    							// TODO Auto-generated catch block
	    							e.printStackTrace();
	    							throw new RepoproException(e.getMessage());
	    						}catch(Exception e){
	    							e.printStackTrace();
	    							throw new RepoproException(e.getMessage());
	    						}
	    					}else{
	    						retStat = Status.BAD_REQUEST;
		        				retScsFlr = Constants.FAILURE;
		        				retMsg = "Invalid Plugin configuration";
		        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

		        				return Response.status(retStat)
		        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	    					}
	    				}
	    				if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") || CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

		    				retStat = Status.BAD_REQUEST;
		    				retScsFlr = Constants.FAILURE;
		    				retMsg = "Invalid Plugin configuration";
		    				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

		    				return Response.status(retStat)
		    						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
		    			}
	    			}
	        		if(CommonUtils.customParameterPluginNoficationClassName != null ){
	        			if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")){
	        				retStat = Status.BAD_REQUEST;
	        				retScsFlr = Constants.FAILURE;
	        				retMsg = "Invalid Plugin configuration";
	        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	        				return Response.status(retStat)
	        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	        			}
	        		}else if(CommonUtils.customParameterPluginPath != null){
	        			if(CommonUtils.customParameterPluginPath .equalsIgnoreCase("")){
	        				retStat = Status.BAD_REQUEST;
	        				retScsFlr = Constants.FAILURE;
	        				retMsg = "Invalid Plugin configuration";
	        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	        				return Response.status(retStat)
	        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	        			}
	        		}
	        	//update properties values
	        	Response propResponse = assetInstanceVersionsManager.updatePropertiesHelper(obj.toString(), ListOfAssetInstanceProperties, bodyParts, context, true, conn);
	        	MyModel propRes = (MyModel) propResponse.getEntity();
	        	if(propRes.getStatus().equals("FAILURE")){
	        		return propResponse;
	        	}
	        	List<Object> data = propRes.getResult();
	        	for (int i = 0; i < data.size(); i++) {
					String revHis = new String();
					revHis = (String) data.get(i);
					newParamDataForRevision = revHis;
				}
	        	propertiesKey = "P";
	        }
	          
	        String changeKey = "";  
	        if(jsonAddFlag.equals("true")){
		        changeKey = newInstanceKey+","+relationshipdataKey+","+propertiesKey;
		    }else{
		    	changeKey = instanceRenameKey+","+overviewKey+","+relationshipdataKey+","+propertiesKey;
		    }
	        List<String> list = Arrays.asList(changeKey.split(","));
	        List<String> finallist = new ArrayList<String>();
	        for(String emptydata:list){
	        	if(!emptydata.equalsIgnoreCase("")){
	        		finallist.add(emptydata);
	        	}
	        }
	        String listString = String.join(",", finallist);
	        
	        AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();
	        RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
	        if(jsonAddFlag.equals("true")){
	        	aivRevHist = new AivRevisionHistory();
				aivRevHist.setAivId(assetInstance.getAssetInstVersionId());
				aivRevHist.setRevId(assetInstance.getVersionName()+".0");
				aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				aivRevHist.setChangedKey(listString);
				aivRevHist.setOverviewData(overview);
				if(!newRelationshipDataForRevision.equalsIgnoreCase("")){
					aivRevHist.setRelationshipData(newRelationshipDataForRevision);
				}else{
					aivRevHist.setRelationshipData(null);
				}
				if(!newParamDataForRevision.equalsIgnoreCase("")){
					aivRevHist.setParameterData(newParamDataForRevision);
				}else{
					aivRevHist.setParameterData(null);
				}
				aivRevHist.setUserId(userId);
				aivRevHist.setUsedBy(null);
				if (log.isTraceEnabled()) {
					log.trace("addAssetInstanceHelper : call dao addRevisionData() method for adding revision data");
				}
				revisionHistoryDao.addRevisionData(aivRevHist, conn);
				
				AssetInstanceVersion aivo = new AssetInstanceVersion();
				aivo.setVersionName("1.0");
				aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				aivo.setAssetInstVersionId(aivRevHist.getAivId());
				assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
	        
	        }else{
	        	assetInstanceVersionManager.addRevisionData(listString, assetInstance.getAssetInstVersionId(), assetInstance.getVersionName(), 
	        			overview,newRelationshipDataForRevision, newParamDataForRevision, null, userName,userId,instanceRenameing, conn);
	        	
	        	AssetInstanceVersion aivo = new AssetInstanceVersion();
				aivo.setVersionName(assetInstance.getVersionName());
				aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				aivo.setAssetInstVersionId(assetInstance.getAssetInstVersionId());
				assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
	        }
	       
	        //recent activity
			if (asset.isVersionable() == true) {
				String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ " Version " + assetInstance.getVersionName();
				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setDescription(log);
				recentActivity.setAssetId(asset.getAssetId().toString());
				recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
				recentActivity.setUser_id(userId);
			} else {
				String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ appendingMsg;
				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setDescription(log);
				recentActivity.setAssetId(asset.getAssetId().toString());
				recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
				recentActivity.setUser_id(userId);
			}
			
			recentActivityDao.addRecentActivity(recentActivity, conn);
			
			if(jsonAddFlag.equals("true")) {
				Long firstState = null;
				Workflow workflow = workflowDao.retWorkflowByAivId(assetInstance.getAssetInstVersionId(), conn);
				if(workflow != null) {
					String jsonStructure = workflow.getJsonStructure();
					JSONObject jsonObject = new JSONObject(jsonStructure);
					
					for(int i=0;i<jsonObject.length();i++) {
						Iterator itr = jsonObject.keys();
						if(itr.hasNext()){
							firstState = Long.parseLong(itr.next().toString());
						}
					}
					assetInstanceDao.updateAssetInstanceState(assetInstance.getAssetInstVersionId(),firstState,conn);
				}
			}
			
			conn.commit();
			
			//TODO: Asset Visualization
			AssetRepresentationDao repDao = new AssetRepresentationDao();
			FormDataBodyPart dataMultiPart = null;
			
			if (bodyParts != null) {
				dataMultiPart = bodyParts.getField("uploadedJarSupportFile");			
				if(dataMultiPart != null){
					String fileName = dataMultiPart.getContentDisposition().getFileName();
					InputStream in = dataMultiPart.getEntityAs(InputStream.class);
					String outputPath = Constants.UPLOADED_JAR_SUPPORT_FILE_PATH + assetInstance.getAssetInstVersionId() + "/";
					File directory = new File(outputPath);
					if (!directory.exists()) {
						directory.mkdir();
					}
					
					File uploadedJarSupportFile = new File(Constants.UPLOADED_JAR_SUPPORT_FILE_PATH + fileName);
					FileOutputStream outStream = new FileOutputStream(uploadedJarSupportFile);
					
					IOUtils.copy(in,outStream);
					
					repDao.saveAssetInstanceRepresentation(conn, assetName, assetInstance.getAssetInstId(), assetInstance.getAssetInstVersionId(), uploadedJarSupportFile, outputPath);
					
					in.close();
					outStream.close();
					FileUtils.forceDelete(uploadedJarSupportFile);
				}
			}

			conn.commit();
			
			// mail template
			MailTemplateDao mailTemplateDao = new MailTemplateDao();
			SubscriptionDao subscriptionDao = new SubscriptionDao();

			MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
			String mailTemp = null;
			if(jsonAddFlag.equals("true")){
				// add instance

				AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(),conn);
				List<String> emailIds=subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);

				if(aiv.getVersionable() == true){
					MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
					mailTemp = mtVo1.getMailTemplate();
					String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
				}else{
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
					mailTemp = mtVo.getMailTemplate();
					String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%assetType%", aiv.getAssetName());
				}
				if(emailIds!=null){
					for(String emailId:emailIds){
						if(aiv.getVersionable() == true) {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
						else {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
					}
				}
			}else{ 
				// update instance
				AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);
				List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(aiv.getAssetInstanceId(), conn);

				if(aiv.getVersionable() == true){
					MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForVersionableAsset");
					if(instanceRenameKey.equalsIgnoreCase("IR")){
						mailTemp =  "%oldInstanceName%_%versionName% has been renamed to %newInstanceName%_%versionName% and details has been modified";
					}else{
						mailTemp = mtVo1.getMailTemplate();
					}
					String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					String oldInstName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					if(instanceRenameKey.equalsIgnoreCase("IR")){
						mailTemp = mailTemp.replaceAll("%oldInstanceName%", oldInstName).replaceAll("%versionName%", aiv.getVersionName()).replaceAll("%newInstanceName%", instName);
					}else{
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());

					}
					}else{
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForNonVersionableAsset");
					//mailTemp = mtVo.getMailTemplate();
					if(instanceRenameKey.equalsIgnoreCase("IR")){
						mailTemp =  "%oldInstanceName% has been renamed to %newInstanceName% and details has been modified";
					}else{
						mailTemp = mtVo.getMailTemplate();
					}
					String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					String oldInstName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					//mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
					if(instanceRenameKey.equalsIgnoreCase("IR")){
						mailTemp = mailTemp.replaceAll("%oldInstanceName%", oldInstName).replaceAll("%newInstanceName%", instName);
					}else{
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());

					}
				}
				if(emailIds!=null){
					for(String emailId:emailIds){
						if(aiv.getVersionable() == true) {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
						else {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
					}
				}
			}
			
			// taxonomy mail

			String assignTax = "";
			String unassignTax = "";
			String addTax = "";
			String removedTax = "";
			List<String> emailIdsList = new ArrayList<String>();
			List<String> emailIds1List = new ArrayList<String>();
			for(Map.Entry<String, String> entry : taxMap.entrySet()){
				assignTax = entry.getKey();
				unassignTax = entry.getValue();
			}
			//added taxonomies
			if(!assignTax.equalsIgnoreCase("")){
				String addedTaxEmail = "";
				String[] addTaxFinal = assignTax.split("~~");
				addTax = addTaxFinal[0];
				if(addTaxFinal.length == 2){
					addedTaxEmail = addTaxFinal[1];
				}
				emailIdsList = Arrays.asList(addedTaxEmail.split(","));
			}
			
			
			//unassigned taxonomies
			if(!unassignTax.equalsIgnoreCase("")){
				String[] unassignTaxFinal = unassignTax.split("~~");
				removedTax = unassignTaxFinal[0];
				String unassignTaxEmail = "";

				if(unassignTaxFinal.length == 2){
					unassignTaxEmail = unassignTaxFinal[1];
				}

				emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
			}
			AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);


			if (!emailIdsList.isEmpty()) {
				//HashSet<String> listToSet = new HashSet<String>(emailIdsList);

				//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
				//String mailTemp = "";

				if (aiv1.getVersionable() == true) {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"assignTaxNameForAssetInstanceForVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
							.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", versionName);
				} else {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"assignTaxNameForAssetInstanceForNonVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",
							instName);
				}

				for (String emailId : emailIdsList) {
					//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					if (addTax != "") {
						SendEmail.sendTextMail(mailConfig, emailId,
								MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
								MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
										+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
					}
				}
			}

			if (!emailIds1List.isEmpty()) {
				//HashSet<String> listToSet = new HashSet<String>(emailIds1List);

				//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
			//	String mailTemp = "";

				if (aiv1.getVersionable() == true) {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"unassignTaxNameForAssetInstanceForVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
							.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", versionName);
				} else {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"unassignTaxNameForAssetInstanceForNonVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
							.replaceAll("%assetInstName%", instName);
				}

				for (String emailId : emailIds1List) {

					//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					if (removedTax != "") {
						SendEmail.sendTextMail(mailConfig, emailId,
								MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
								MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
										+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
					}
				}
			}
		
			
			if(parameterChangeNotification != null){
				JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

				if(jsonObject.has("Response Status")){
					String status = jsonObject.getString("Response Status");
					if(status.equalsIgnoreCase("success")){
						if(jsonObject.has("Notification")){
							String result = jsonObject.getString("Notification");
							result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
							if(!result.equalsIgnoreCase("\"\"")){
								JSONObject maillist = new JSONObject(result);
								if(maillist.has("Parameter changed")){
									String oldValue = maillist.getString("Old Value");
									List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
									String newValue = 	maillist.getString("New Value");
									List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
									String instanceName = maillist.getString("AssetInstanceName");
									String assetType = maillist.getString("Assetname");
									JSONArray emailArray = maillist.getJSONArray("Email Id");
									if(oldValue.equalsIgnoreCase("")){
										for(int j=0;j<emailArray.length();j++){
											SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
													MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
													MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}else{
										for(int j=0;j<emailArray.length();j++){
											SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
													MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
													MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}
								}
							}
						}
					}
				}
			}
			
			if(relatedParamChangeNotification != null){
				JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

				if(jsonObject.has("Response Status")){
					String status = jsonObject.getString("Response Status");
					if(status.equalsIgnoreCase("success")){
						if(jsonObject.has("Notification")){
							String result = jsonObject.getString("Notification");
							result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
							if(!result.equalsIgnoreCase("\"\"")){
								JSONObject maillist = new JSONObject(result);
								if(maillist.has("Parameter changed")){
									String oldValue = maillist.getString("Old Value");
									List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
									String newValue = 	maillist.getString("New Value");
									List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
									String instanceName = maillist.getString("AssetInstanceName");
									String assetType = maillist.getString("Assetname");
									JSONArray emailArray = maillist.getJSONArray("Email Id");
									if(oldValue.equalsIgnoreCase("")){
										for(int j=0;j<emailArray.length();j++){
											SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
													MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
													MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}else{
										for(int j=0;j<emailArray.length();j++){
											SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
													MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
													MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}
								}
							}
						}
					}
				}
			}
			
			
			assetInstanceList.add(assetInstance);
			
			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_DATA_INSERTED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			
		}catch (RepoproException e) {
			log.error("createAssetInstance: SQL Exception createAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}catch (Exception e) {
			log.error("createAssetInstance: SQL Exception createAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}finally {
			if (log.isTraceEnabled()) {
				log.trace("createAssetInstance : "+ Constants.LOG_CONNECTION_CLOSE);
			}
			if(conn != null){
				DBConnection.closeDbConnection(conn);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("createAssetInstance || exit");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,new ArrayList<Object>(assetInstanceList))).build();
	}
	@PUT
	@Encoded
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Path("/update")
	public Response updateInstancePropertiesRelationships(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("assetInstanceVersionName") String assetInstanceVersionName,
			@QueryParam("updateOverviewDescription") String assetInstanceDescription,
			@QueryParam("assignTagDetails") String tagNames,
			@QueryParam("unassignTagDetails") String unassignTagNames,
			@QueryParam("assignTaxonomyDetails") String assignTaxonomy,
			@QueryParam("unassignTaxonomyDetails") String unassignTaxonomy,
			@QueryParam("parameterDetails") String parameterDetails,
			@QueryParam("addRelationshipData") String addRelationshipData,
			@QueryParam("removeRelationshipData") String removeRelationshipData,
			@HeaderParam("token") String token,FormDataMultiPart formParams, @Context ServletContext context){
		
		if(assetName == null ||assetInstName == null ||assetInstanceVersionName == null ){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			assetInstName = assetInstName.trim();
			if(assetInstanceDescription != null){
				assetInstanceDescription = URLDecoder.decode(assetInstanceDescription, "UTF-8");
				assetInstanceDescription = assetInstanceDescription.trim();
			}
			assetInstanceVersionName = URLDecoder.decode(assetInstanceVersionName, "UTF-8");
			assetInstanceVersionName = assetInstanceVersionName.trim();
			if(tagNames != null){
				tagNames = URLDecoder.decode(tagNames, "UTF-8");
				tagNames = tagNames.trim();
			}
			if(unassignTagNames != null){
				unassignTagNames = URLDecoder.decode(unassignTagNames, "UTF-8");
				unassignTagNames = unassignTagNames.trim();
			}
			if(assignTaxonomy != null){
				assignTaxonomy = URLDecoder.decode(assignTaxonomy, "UTF-8");
				assignTaxonomy = assignTaxonomy.trim();
			}
			if(unassignTaxonomy != null){
				unassignTaxonomy = URLDecoder.decode(unassignTaxonomy, "UTF-8");
				unassignTaxonomy = unassignTaxonomy.trim();
			}
			if(parameterDetails != null){
				parameterDetails = URLDecoder.decode(parameterDetails, "UTF-8");
				parameterDetails = parameterDetails.trim();
			}
			if(addRelationshipData != null){
				addRelationshipData = URLDecoder.decode(addRelationshipData, "UTF-8");
				addRelationshipData = addRelationshipData.trim();
			}
			if(removeRelationshipData != null){
				removeRelationshipData = URLDecoder.decode(removeRelationshipData, "UTF-8");
				removeRelationshipData = removeRelationshipData.trim();
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
		if(assetName.trim().isEmpty() || assetInstName.trim().isEmpty() ||assetInstanceVersionName.trim().isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		try{
			CommonUtils commonUtils = new CommonUtils();
			String userName = "";
			UserDao userDao = new UserDao();
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			
			
			boolean editFlag = false;
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersion assetInstanceVer1 = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetInstanceVersionName, null);
			if (assetInstanceVer1 == null) {
				log.trace("updateInstancePropertiesRelationships || End");
				return Response.status(Status.NOT_FOUND)
						.entity(new MyModelRest(Constants.GET_STATUS_FAILURE, Constants.FAILURE, Constants.ASSET_INSTANCE_VERSION_NOT_FOUND))
						.build();
			}
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			groupAssetInstVersionAccessList = assetInstVersionDao.retAivAccessRights(assetInstanceVer1.getAssetInstVersionId(), userName, null);

			for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
				if (groupAssetInstVersionAccessList.get(i).getEditAccess().equals(1L)) {
					editFlag = true;
					break;
				}
			}
			
			if(editFlag == false){
				log.trace("updateInstancePropertiesRelationships || End");
				return Response.status(Status.FORBIDDEN)
						.entity(new MyModelRest(Constants.FORBIDDEN, Constants.NOT_AUTHORIZED, Constants.USER_NOT_AUTHORIZED)).build();
			}
			
			if(parameterDetails == null  && assetInstanceDescription == null && addRelationshipData == null &&removeRelationshipData == null && tagNames == null && unassignTagNames == null && assignTaxonomy == null && unassignTaxonomy == null){
				
				AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetInstanceVersionName, null);
				if (assetInstanceVer == null) {
					log.trace("updateInstancePropertiesRelationships || End");
					return Response.status(Status.NOT_FOUND)
							.entity(new MyModelRest(Constants.GET_STATUS_FAILURE, Constants.FAILURE, Constants.ASSET_INSTANCE_VERSION_NOT_FOUND))
							.build();
				}
				
				return Response.status(Status.OK).entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
								Constants.SUCCESS, Constants.ASSET_INSTANCE_DETAILS_UPDATED)).build();
			}
			if(parameterDetails != null  && assetInstanceDescription != null && addRelationshipData != null &&removeRelationshipData != null && tagNames!= null && assignTaxonomy!= null && unassignTaxonomy!= null ){
				if(parameterDetails.isEmpty()&& assetInstanceDescription.isEmpty() && addRelationshipData.isEmpty() &&removeRelationshipData.isEmpty() && tagNames.isEmpty() && unassignTagNames.isEmpty() && assignTaxonomy.isEmpty() && unassignTaxonomy.isEmpty()){
					
					AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetInstanceVersionName, null);
					if (assetInstanceVer == null) {
						log.trace("updateInstancePropertiesRelationships || End");
						return Response.status(Status.NOT_FOUND)
								.entity(new MyModelRest(Constants.GET_STATUS_FAILURE, Constants.FAILURE, Constants.ASSET_INSTANCE_VERSION_NOT_FOUND))
								.build();
					}
					
					return Response.status(Status.OK)
							.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
									Constants.SUCCESS, Constants.ASSET_INSTANCE_DETAILS_UPDATED)).build();
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		log.trace("updateInstancePropertiesRelationships || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		CommonUtils commonUtils = new CommonUtils();
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();
		String userName = "";
		UserDao userDao = new UserDao();
		Object parameterChangeNotification = null;
    	Object relatedParamChangeNotification = null;
		if(assetInstanceDescription != null){
			assetInstanceDescription = assetInstanceDescription.trim();
		}
		if(tagNames == null){
			tagNames = "";
		}
		if(unassignTagNames == null){
			unassignTagNames = "";
		}
		if(assignTaxonomy == null){
			assignTaxonomy = "";
		}
		if(unassignTaxonomy == null){
			unassignTaxonomy = "";
		}
		
		if(tagNames != null){
			tagNames = tagNames.trim();
		}
		if(unassignTagNames != null){
			unassignTagNames = unassignTagNames.trim();
		}
		if(assignTaxonomy != null){
			assignTaxonomy = assignTaxonomy.trim();
		}
		if(unassignTaxonomy != null){
			unassignTaxonomy = unassignTaxonomy.trim();
		}
		if(addRelationshipData != null){
			addRelationshipData = addRelationshipData.trim();
		}
		if(removeRelationshipData != null){
			removeRelationshipData = removeRelationshipData.trim();
		}
		if(assetInstanceDescription != null){
			assetInstanceDescription = assetInstanceDescription.trim();
		}
		if(parameterDetails != null){
			parameterDetails = parameterDetails.trim();
		}
		try {
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);

			if (log.isTraceEnabled()) {
				log.trace("updateInstancePropertiesRelationships : " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			if(userName.equalsIgnoreCase("guest")) {
				userName= "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			AssetInstanceVersionRest aivRest = new AssetInstanceVersionRest();
			JSONObject json = new JSONObject();
			Response updatePropertiesResponse = null;
			MyModel model = null;
			MyModelRest modelRest = null;
			MyModelRest modelRestTag = null;
			MyModel modelRestTax = null;
			MyModelRest modelRestPro = null;
			MyModelRest modelRestSave = null;
			int statusCode = 0;
			String statusMessage = "";
			Response updatedescResponse = null;
			Response updateTagsResponse = null;
			Response updateTaxonomiesResponse = null;
			//Object result =  response.getEntity();
			Response saveDependencyResponse = null;
			AssetInstanceManager aiManager = new AssetInstanceManager();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			String overviewKey = "";
			String relationshipdataKey = "";
			String propertiesKey = "";
			Map<String, String> taxMap = new HashMap<String, String>();
			String overview = "";
			String newRelationshipDataForRevision = "";
			String newParamDataForRevision = "";
			
			AssetDao assetDao = new AssetDao();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetinstDetails(assetName, assetInstName, assetInstanceVersionName, null);
			if (assetInstanceVer == null) {
				log.trace("updateInstancePropertiesRelationships || End");
				return Response.status(Status.NOT_FOUND)
						.entity(new MyModelRest(Constants.GET_STATUS_FAILURE, Constants.FAILURE, 
								Constants.ASSET_INSTANCE_VERSION_NOT_FOUND)).build();
			}
			
			AssetDef asset = assetInstanceDao.retAssetDetail(assetName, conn);
			if(asset.getAssetId() == null){
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;

				log.trace("addInstanceUpdatePropertiesRelationships || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr,
								retMsg)).build();
			}
			//get global setting setting details
			if (log.isTraceEnabled()){
				log.trace("addInstanceUpdatePropertiesRelationships || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
			
			AssetInstanceVersion aiv = assetInstVersionDao.retAssetInstanceVersion(assetInstanceVer.getAssetInstVersionId(), userName, conn);
			String description = aiv.getDescription();
			
			if(description == null || description.equals("")){
				return Response.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE, Constants.FAILURE, 
								Constants.PLEASE_PROVIDE_DESCRIPTION)).build();
			}
			
			if(assetInstanceDescription != null && !assetInstanceDescription.isEmpty()){
				if(!assetInstanceDescription.equalsIgnoreCase("")){
					if(globalsetting.getGlobalSettingFlag() == 1){
						assetInstanceDescription = commonUtils.httpSanitizerForPlainText(assetInstanceDescription);
					}
					updatedescResponse = aivRest.updateAssetInstanceDescriptionMainHelper(assetName, assetInstName, assetInstanceVersionName, assetInstanceDescription, token,true,conn);
					overview = assetInstanceDescription;
		        	overviewKey = "O";
				}
			}else{
				retMsg = Constants.ASSET_INSTANCE_DESC_UPDATED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
				updatedescResponse = Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr,retMsg)).build();
			}
			
			if(updatedescResponse.getEntity() instanceof MyModelRest){
				modelRest = (MyModelRest) updatedescResponse.getEntity();
			}
			if(modelRest != null){
				statusCode = updatedescResponse.getStatus();
				statusMessage = modelRest.getMessage();
			}
			
			if(modelRest.getStatus().equalsIgnoreCase("SUCCESS")){
				
				if(tagNames.equalsIgnoreCase("") && unassignTagNames.equalsIgnoreCase("")){
					retMsg = Constants.TAGS_SAVED_SUCCESSFULLY;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					updateTagsResponse =  Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}else{
					updateTagsResponse = aivRest.addTagsMainHelper(assetName, assetInstName, assetInstanceVersionName, tagNames, unassignTagNames, token, true, true, conn);
				}
				
			}else {
				return updatedescResponse;
			}
					
			if(updateTagsResponse.getEntity() instanceof MyModelRest){
				modelRestTag = (MyModelRest) updateTagsResponse.getEntity();
			}
			if(modelRestTag != null){
				statusCode = updateTagsResponse.getStatus();
				statusMessage = modelRestTag.getMessage();
			}
			MyModel taxRes = null;
			if(modelRestTag.getStatus().equalsIgnoreCase("SUCCESS")){
				
				if(assignTaxonomy.equalsIgnoreCase("") && unassignTaxonomy.equalsIgnoreCase("")){
					retMsg = Constants.TAXONOMY_ASSIGNED_SUCCESSFULLY;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					updateTaxonomiesResponse =  Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
				}else{
					updateTaxonomiesResponse = aivRest.addTaxonomyForAssetInstanceVersionMainHelper(assetName, assetInstName, assetInstanceVersionName, assignTaxonomy, unassignTaxonomy, token, true, true,conn);
					 taxRes = (MyModel) updateTaxonomiesResponse.getEntity();
					taxMap = taxRes.getParamValues();
				}
				
			} else {
				return updateTagsResponse;
			}
			
			if(updateTaxonomiesResponse.getEntity() instanceof MyModel){
				modelRestTax = (MyModel) updateTaxonomiesResponse.getEntity();
			}
			if(modelRestTax != null){
				statusCode = updateTaxonomiesResponse.getStatus();
				statusMessage = modelRestTax.getMessage();
			}
			
			if(modelRestTax.getStatus().equalsIgnoreCase("SUCCESS")){
				if(parameterDetails != null && !parameterDetails.isEmpty()){
					List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();

					try{
						User user = userDao.getUserIdByUserName(userName, conn);
						String jsonStr1 = parameterDetails;
						JSONObject obj1 = new JSONObject(jsonStr1);
						String aivList = obj1.get("propertiesList").toString();
						JSONArray aivListArray = new JSONArray(aivList);
						AssetInstanceVersion aiv2 = new AssetInstanceVersion();
						for (int i = 0; i < aivListArray.length(); i++) {
							Iterator itr = aivListArray.getJSONObject(i).keys();
							while (itr.hasNext()) {
								aiv2 = new AssetInstanceVersion();
								String value = null;
								if(aivListArray.getJSONObject(i).has("assetParamName")){
									aiv2.setAssetParamName(aivListArray.getJSONObject(i).get("assetParamName").toString());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();

								}

								//valid parameter check 
								AssetParamDef paramCheck = assetDao.getParamIdForAssetAndParamName(assetName,aiv2.getAssetParamName(),conn);
								if(paramCheck == null || paramCheck.getAssetParamId() == null){
									return Response
											.status(Status.NOT_FOUND)
											.entity(new MyModelRest(Constants.GET_STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_ASSET_PARAM_NAME)))
													.build();
								}
								if(paramCheck.getParamTypeId() == 3){
									if(aivListArray.getJSONObject(i).has("fileName")){
										aiv2.setFileName(aivListArray.getJSONObject(i).get("fileName").toString());
										aiv2.setMandatory(paramCheck.isHasMandatoryValue());
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))	.build();
									}
								}else{
									if(paramCheck.getParamTypeId() == 4){
										//if(paramCheck.getListTypeParamTypeId() != 4){
										ArrayList<String> listdata = new ArrayList<String>();  
										aiv2.setMandatory(paramCheck.isHasMandatoryValue());
										if(aivListArray.getJSONObject(i).has("paramValue")){
											value = aivListArray.getJSONObject(i).get("paramValue").toString();
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();
										}

										if(value.length() != 0 && value.startsWith("[")){
											JSONArray valueArray = new JSONArray(value);
											if (valueArray != null) { 
												for (int j=0;j<valueArray.length();j++){ 
													listdata.add(valueArray.getString(j));
												} 
											}
											if(paramCheck.getListType() == 0){
												if(listdata.size()>1){
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																	.build();
												}
											}
											String listString = "";
											for(String s : listdata){
												listString += s + "~~";
											}
											if (listString.endsWith("~~")) {
												listString = listString.substring(0, listString.length() - "~~".length());
											}
											aiv2.setParamValue(listString);
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();

										}
										//}
									}else if(paramCheck.getParamTypeId() == 1){
										aiv2.setMandatory(paramCheck.isHasMandatoryValue());
										if(paramCheck.isHasStaticValue() == true){
											if(aivListArray.getJSONObject(i).has("paramValue")){
												String paramVal = "";
												if(globalsetting.getGlobalSettingFlag() == 1){
													paramVal = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
												}
												else{
													paramVal = aivListArray.getJSONObject(i).get("paramValue").toString();
												}
												aiv2.setParamValue(paramVal);	
											}else{
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
										}else{

											if(paramCheck.getHasArray() == 1){
												aiv2.setHasArray(paramCheck.getHasArray());
												String textdata1 = null;
												if(aivListArray.getJSONObject(i).has("paramValue")){
													String paramval = "";
													if(globalsetting.getGlobalSettingFlag() == 1){
														paramval = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
													}else{
														paramval = aivListArray.getJSONObject(i).get("paramValue").toString();
													}

													textdata1 = paramval;
												}else{
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																	.build();
												}
												if(textdata1 != null){
													if(textdata1.startsWith("[")){
														JSONArray textdataJsonArray = new JSONArray(textdata1);
														List<String> textDataList = new ArrayList<String>();
														for(int ii=0;ii<textdataJsonArray.length();ii++){
															textDataList.add(textdataJsonArray.getString(ii));
														}
														aiv2.setTextDataList(textDataList);
														// for adding revision history
														String textdata = String.join("~~", aiv2.getTextDataList());
														aiv2.setParamValue(textdata);
													}else{
														return Response
																.status(Status.BAD_REQUEST)
																.entity(new MyModelRest(Constants.STATUS_FAILURE,
																		Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																		.build();
													}
												}
											}else{
												aiv2.setHasArray(paramCheck.getHasArray());

												if(aivListArray.getJSONObject(i).has("paramValue")){
													String paramval = "";
													if(globalsetting.getGlobalSettingFlag() == 1){
														paramval = commonUtils.httpSanitizerForPlainText(aivListArray.getJSONObject(i).get("paramValue").toString());
													}else{
														paramval = aivListArray.getJSONObject(i).get("paramValue").toString();
													}
													aiv2.setParamValue(paramval);	
												}else{
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																	.build();
												}
											}
										}
									}else if (paramCheck.getParamTypeId() == 7){
										aiv2.setMandatory(paramCheck.isHasMandatoryValue());
										if(paramCheck.getHasArray() == 1){
											aiv2.setHasArray(paramCheck.getHasArray());
											List<String> listdatawithouttag = new ArrayList<String>();
											List<String> listdatawithtag = new ArrayList<String>();
											String richText = null;
											if(aivListArray.getJSONObject(i).has("paramValue")){
												richText = aivListArray.getJSONObject(i).get("paramValue").toString();
											}else{
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
											if(richText != null){
												if(richText.startsWith("[")){
													//	System.out.println("processed");
													JSONArray valueArray1 = new JSONArray(richText);

													if (valueArray1 != null) { 
														for (int j=0;j<valueArray1.length();j++){ 
															String richText1 = "";
															if(globalsetting.getGlobalSettingFlag() == 1){
																richText1 = commonUtils.httpSanitizerForCkEditor(valueArray1.getString(j));
															}else {
																richText1 = valueArray1.getString(j);
															}
															listdatawithtag.add(richText1);
															String textdata = Jsoup.parse(valueArray1.getString(j)).text();

															listdatawithouttag.add(textdata);
														} 
														aiv2.setRTFwithTags(listdatawithtag);
														aiv2.setRTFwithOutTags(listdatawithouttag);
														// for adding revision history
														String textdata = String.join("~~", aiv2.getRTFwithTags());
														aiv2.setParamValue(textdata);
													}
												}else{
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(Constants.STATUS_FAILURE,
																	Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																	.build();
												}
											}

										}else{
											aiv2.setHasArray(paramCheck.getHasArray());

											String richText = "";
											if(aivListArray.getJSONObject(i).has("paramValue")){
												richText = aivListArray.getJSONObject(i).get("paramValue").toString();
												if(globalsetting.getGlobalSettingFlag() == 1){
													richText = commonUtils.httpSanitizerForCkEditor(richText);
												}
											}else{
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(Constants.STATUS_FAILURE,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
											aiv2.setParamValue(richText);
											String textdata = null;
											if (richText != null) { 
												textdata = Jsoup.parse(richText).text();
												aiv2.setRTFPlainText(textdata);
											}
										}
									}else if(paramCheck.getParamTypeId() == 8) {
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.DERIVED_PARAMETERS_NOT_ALLOWED)))
														.build();
									}
									else if(paramCheck.getParamTypeId() == 9){
				        				String duplicateLdapVal = URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8");
				        				List<String> ParamValList = new ArrayList<String>(Arrays.asList(duplicateLdapVal.split("~~")));
				        				boolean duplicateFlag = false;
										Set<String> duplicate = new HashSet<String>();
										duplicate.addAll(ParamValList);
										if(duplicate.size()<ParamValList.size()){
											duplicateFlag = true;
										}
										if(duplicateFlag){
											retStat = Status.BAD_REQUEST;
											retScsFlr = Constants.FAILURE;
											retMsg = "DUPLICATE_DATA_NOT_ALLOWED";
											retStatScsFlr = Constants.STATUS_FAILURE;
											return Response.status(retStat)
													.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg))
													.build();
										}
				        				Map<String,Integer> finalParamValList = commonUtils.ldapDataconstruction(URLDecoder.decode(aivListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8"),assetName ,aivListArray.getJSONObject(i).get("assetParamName").toString(),conn);
				        				aiv.setLdapMappingValue(finalParamValList);
				        				
				        			}
									else{
										if(aivListArray.getJSONObject(i).has("paramValue")){
											aiv2.setMandatory(paramCheck.isHasMandatoryValue());
											aiv2.setParamValue(aivListArray.getJSONObject(i).get("paramValue").toString());	
										}else{
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(Constants.STATUS_FAILURE,
															Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
															.build();
										}
									}

								}
								aiv2.setAssetInstVersionId(aiv.getAssetInstVersionId());
								aiv2.setConn(conn);
								aiv2.setLog(log);
								aiv2.setUserId(user.getUserId());
								aiv2.setAssetName(assetName);
								aiv2.setAssetInstName(assetInstName);
								ListOfAssetInstanceProperties.add(aiv2);
								break;

							}
						}
					}catch(org.json.JSONException e){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();

					} catch (RepoproException e) {
						e.printStackTrace();
						throw new RepoproException(e.getMessage());
					}

					if(CommonUtils.customParameterPluginNoficationClassName != null && CommonUtils.customParameterPluginPath != null){

						if(!CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") && !CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

							Class notificationInterface = CustomParameterPluginUtilies.getplugin();

							if(notificationInterface != null){
								Method method = null;
								Method relatedParamChangeMethod = null;
								try {
									method = notificationInterface.getMethod("notifyOnParameterValueChanges",new Class[]{List.class});
									relatedParamChangeMethod = notificationInterface.getMethod("notifyOnParameterValueChangesBasedOnOtherParameter",new Class[]{List.class});

								} catch (NoSuchMethodException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									throw new RepoproException(e.getMessage());
								} catch (SecurityException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									throw new RepoproException(e.getMessage());
								}

								Object instance = null;
								try {
									instance = notificationInterface.newInstance();
								} catch (InstantiationException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									throw new RepoproException(e.getMessage());
								} catch (IllegalAccessException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									throw new RepoproException(e.getMessage());
								}	


								try{
									parameterChangeNotification = method.invoke(instance,ListOfAssetInstanceProperties);

									if(parameterChangeNotification != null){
										JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

										if(jsonObject.has("Response Status")){
											String status = jsonObject.getString("Response Status");
											if(status.equalsIgnoreCase("failure")){
												retStat = Status.INTERNAL_SERVER_ERROR;;
												retScsFlr = status;
												retMsg = jsonObject.getString("Response Message");
												retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

												return Response.status(retStat)
														.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
											}
										}
									}


									relatedParamChangeNotification = relatedParamChangeMethod.invoke(instance,ListOfAssetInstanceProperties);
									if(relatedParamChangeNotification != null){
										JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

										if(jsonObject.has("Response Status")){
											String status = jsonObject.getString("Response Status");
											if(status.equalsIgnoreCase("failure")){
												retStat = Status.INTERNAL_SERVER_ERROR;;
												retScsFlr = status;
												retMsg = jsonObject.getString("Response Message");
												retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

												return Response.status(retStat)
														.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
											}
										}
									}
								}
								catch (IllegalAccessException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									throw new RepoproException(e.getMessage());
								} catch (IllegalArgumentException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									throw new RepoproException(e.getMessage());
								} catch (InvocationTargetException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
									throw new RepoproException(e.getMessage());
								}catch(Exception e){
									e.printStackTrace();
									throw new RepoproException(e.getMessage());
								}
							}else{
								retStat = Status.BAD_REQUEST;
								retScsFlr = Constants.FAILURE;
								retMsg = "Invalid Plugin configuration";
								retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

								return Response.status(retStat)
										.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
							}
						}
						if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")|| CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

							retStat = Status.BAD_REQUEST;
							retScsFlr = Constants.FAILURE;
							retMsg = "Invalid Plugin configuration";
							retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

							return Response.status(retStat)
									.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
						}
					}
					if(CommonUtils.customParameterPluginNoficationClassName != null ){
						if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")){
							retStat = Status.BAD_REQUEST;
							retScsFlr = Constants.FAILURE;
							retMsg = "Invalid Plugin configuration";
							retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

							return Response.status(retStat)
									.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
						}
					}else if(CommonUtils.customParameterPluginPath != null){
						if(CommonUtils.customParameterPluginPath .equalsIgnoreCase("")){
							retStat = Status.BAD_REQUEST;
							retScsFlr = Constants.FAILURE;
							retMsg = "Invalid Plugin configuration";
							retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

							return Response.status(retStat)
									.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
						}
					}
				}	
					updatePropertiesResponse = aivRest.updateAssetInstancePropertiesRestHelper(assetName, assetInstName, assetInstanceVersionName, parameterDetails, formParams, context, token, false, false, conn);
			} else {
				//return updateTaxonomiesResponse;
				retMsg = taxRes.getMessage();
				retScsFlr = taxRes.getStatus();
				retStatScsFlr = taxRes.getStatusCode();
				return  Response.status(updateTaxonomiesResponse.getStatus()).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			
			if(updatePropertiesResponse.getEntity() instanceof MyModelRest){
				modelRestPro = (MyModelRest) updatePropertiesResponse.getEntity();
			}
			String StatuscheckingPro = null;
			//String responseMsg = "";
				if(modelRestPro != null){
					statusCode = updatePropertiesResponse.getStatus();
					statusMessage = modelRestPro.getMessage();
					StatuscheckingPro = modelRestPro.getStatus();
				}else{
					MyModel propRes = (MyModel) updatePropertiesResponse.getEntity();
					StatuscheckingPro = propRes.getStatus();
					/*String[] splitResponseMsg = propRes.getMessage().split("`~~`");
				if(splitResponseMsg.length==2){
					responseMsg = splitResponseMsg[1];
				}*/
					List<Object> data = propRes.getResult();
					for (int i = 0; i < data.size(); i++) {
						String revHis = new String();
						revHis = (String) data.get(i);
						newParamDataForRevision = revHis;
					}
					propertiesKey = "P";

				}
			boolean relationshipFlag = false;
			if(StatuscheckingPro.equalsIgnoreCase("SUCCESS")){
				if(addRelationshipData != null){
					if(!addRelationshipData.isEmpty())
					relationshipFlag= true;
				}
				if(removeRelationshipData != null ){
					if(!removeRelationshipData.isEmpty())
					relationshipFlag = true;
				}
				
				if(relationshipFlag == true){
					
					String addreldatas = "";
					String removereldatas = "";
                     // json construction for relationship Data
					try{
					if(addRelationshipData != null){
						if(!addRelationshipData.isEmpty()){
					String jsonStr1 = addRelationshipData;
					JSONObject obj1 = new JSONObject(jsonStr1);
					String aivList = obj1.get("relationshipData").toString();
					JSONArray aivListArray = new JSONArray(aivList);
					AssetInstance relAI = new AssetInstance();
					List<AssetInstance> relAIList = new ArrayList<AssetInstance>();
					for (int i = 0; i < aivListArray.length(); i++) {
						Iterator itr = aivListArray.getJSONObject(i).keys();
						while (itr.hasNext()) {
							relAI = new AssetInstance();
							if(aivListArray.getJSONObject(i).has("assetName")){
								relAI.setAssetName(aivListArray.getJSONObject(i).get("assetName").toString());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();

								}
							if(aivListArray.getJSONObject(i).has("assetInstanceName")){
								relAI.setAssetInstName(aivListArray.getJSONObject(i).get("assetInstanceName").toString());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();

								}
							if(aivListArray.getJSONObject(i).has("assetInstanceVersionName")){
								relAI.setVersionName(aivListArray.getJSONObject(i).get("assetInstanceVersionName").toString());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();

								}
							if(aivListArray.getJSONObject(i).has("relationshipName")){
								relAI.setAssetRelationshipName(aivListArray.getJSONObject(i).get("relationshipName").toString());
								}else{
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(Constants.STATUS_FAILURE,
													Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
													.build();

								}
							relAIList.add(relAI);
							break;
						}
						
						
					}
					
					for(AssetInstance aiii : relAIList ){
						if(addreldatas.equalsIgnoreCase("")){
							addreldatas = aiii.getAssetName()+"|"+aiii.getAssetInstName()+"|"+aiii.getVersionName()+"|"+aiii.getAssetRelationshipName()+"~";
						}else{
							addreldatas = addreldatas + aiii.getAssetName()+"|"+aiii.getAssetInstName()+"|"+aiii.getVersionName()+"|"+aiii.getAssetRelationshipName()+"~";
						}
					}
					if(addreldatas.endsWith("~")){
						if (addreldatas != null && addreldatas.length() > 0 && addreldatas.charAt(addreldatas.length() - 1) == '~') {
							addreldatas = addreldatas.substring(0, addreldatas.length() - 1);
						}
					}
					}
					}
					}
					catch(org.json.JSONException e){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();
						
					} 
					
					// remove relationship data
					try{
					if(removeRelationshipData != null ){
						if(!removeRelationshipData.isEmpty()){
						String jsonStr1 = removeRelationshipData;
						JSONObject obj1 = new JSONObject(jsonStr1);
						String aivList = obj1.get("relationshipData").toString();
						JSONArray aivListArray = new JSONArray(aivList);
						AssetInstance relAI = new AssetInstance();
						List<AssetInstance> relAIList = new ArrayList<AssetInstance>();
						for (int i = 0; i < aivListArray.length(); i++) {
							Iterator itr = aivListArray.getJSONObject(i).keys();
							while (itr.hasNext()) {
								relAI = new AssetInstance();
								if(aivListArray.getJSONObject(i).has("assetName")){
									relAI.setAssetName(aivListArray.getJSONObject(i).get("assetName").toString());
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();

									}
								if(aivListArray.getJSONObject(i).has("assetInstanceName")){
									relAI.setAssetInstName(aivListArray.getJSONObject(i).get("assetInstanceName").toString());
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();

									}
								if(aivListArray.getJSONObject(i).has("assetInstanceVersionName")){
									relAI.setVersionName(aivListArray.getJSONObject(i).get("assetInstanceVersionName").toString());
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();

									}
								if(aivListArray.getJSONObject(i).has("relationshipName")){
									relAI.setAssetRelationshipName(aivListArray.getJSONObject(i).get("relationshipName").toString());
									}else{
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(Constants.STATUS_FAILURE,
														Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
														.build();

									}
								relAIList.add(relAI);
								break;
							}
							
							
						}
						
						for(AssetInstance aiii : relAIList ){
							if(removereldatas.equalsIgnoreCase("")){
								removereldatas = aiii.getAssetName()+"|"+aiii.getAssetInstName()+"|"+aiii.getVersionName()+"|"+aiii.getAssetRelationshipName()+"~";
							}else{
								removereldatas = removereldatas + aiii.getAssetName()+"|"+aiii.getAssetInstName()+"|"+aiii.getVersionName()+"|"+aiii.getAssetRelationshipName()+"~";
							}
						}
						if(removereldatas.endsWith("~")){
							if (removereldatas != null && removereldatas.length() > 0 && removereldatas.charAt(removereldatas.length() - 1) == '~') {
								removereldatas = removereldatas.substring(0, removereldatas.length() - 1);
							}
						}
						}
					}
					}
					catch(org.json.JSONException e){
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();
						
					} 
					
					saveDependencyResponse = aivRest.saveDependencyHelper(assetName, assetInstName, assetInstanceVersionName, addreldatas, removereldatas, token, conn);
					
					assetInstanceVer.setSrcAssetInstanceVersionId(String.valueOf(assetInstanceVer.getAssetInstVersionId()));
					List<AssetInstance> aivos = retFwdDependents(assetInstanceVer,conn);
					int i = 1;
					for(AssetInstance aivo : aivos){
						AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
						if(i == aivos.size()){
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]";	
							}	
						}else{
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
							}
						}
						i++;
					}
					relationshipdataKey = "R";
					
					
				}else{
					json.put("message", Constants.ASSET_INSTANCE_DETAILS_UPDATED/*+responseMsg*/);
					json.put("status", Constants.SUCCESS);
					json.put("statusCode", Constants.GET_STATUS_SUCCESS);
					
					String changeKey = "";
					changeKey = overviewKey+","+relationshipdataKey+","+propertiesKey;
					
					List<String> list = Arrays.asList(changeKey.split(","));
					List<String> finallist = new ArrayList<String>();
					for(String emptydata:list){
						if(!emptydata.equalsIgnoreCase("")){
							finallist.add(emptydata);
						}
					}
					String listString = String.join(",", finallist);
					
					AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();
					
			        User user = userDao.retProfileForUserName(userName, conn);
			        
			        assetInstanceVersionManager.addRevisionData(listString, assetInstanceVer.getAssetInstVersionId(), assetInstanceVer.getVersionName(), 
		        			overview,newRelationshipDataForRevision, newParamDataForRevision, null, userName,user.getUserId(),"", conn);
			      //recent activity
					RecentActivity recentActivity = new RecentActivity();
					String action =  Constants.ACTIVITY_MODIFY;
					RecentActivityDao recentActivityDao = new RecentActivityDao();
					String appendingMsg = "";
					
					if (asset.isVersionable() == true) {
						String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstanceVer.getAssetInstName() + ";"+ " Version " + assetInstanceVer.getVersionName();
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setDescription(log);
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(assetInstanceVer.getAssetInstVersionId().toString());
						recentActivity.setUser_id(user.getUserId());
					} else {
						String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstanceVer.getAssetInstName() + ";"+ appendingMsg;
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setDescription(log);
						recentActivity.setAssetId(asset.getAssetId().toString());
						recentActivity.setAssetInstVersionId(assetInstanceVer.getAssetInstVersionId().toString());
						recentActivity.setUser_id(user.getUserId());
					}
					
					recentActivityDao.addRecentActivity(recentActivity, conn);
			        
					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					SubscriptionDao subscriptionDao = new SubscriptionDao();

					MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					String mailTemp = null;
					
					AssetInstanceVersion aiv1 = assetInstVersionDao.getAssetInstanceVersionDetails(assetInstanceVer.getAssetInstVersionId(), conn);
					List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(aiv1.getAssetInstanceId(), conn);

					if(aiv1.getVersionable() == true){
						MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForVersionableAsset");
						mailTemp = mtVo1.getMailTemplate();
						String instName = aiv1.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv1.getVersionName());
					}else{
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = aiv1.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
					}
					if(emailIds!=null){
						for(String emailId:emailIds){
							if(aiv1.getVersionable() == true) {
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
							else {
								SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

							}
						}
					}
					
					// taxonomy mail

					String assignTax = "";
					String unassignTax = "";
					String addTax = "";
					String removedTax = "";
					List<String> emailIdsList = new ArrayList<String>();
					List<String> emailIds1List = new ArrayList<String>();
					for(Map.Entry<String, String> entry : taxMap.entrySet()){
						assignTax = entry.getKey();
						unassignTax = entry.getValue();
					}
					//added taxonomies
					if(!assignTax.equalsIgnoreCase("")){
						String addedTaxEmail = "";
						String[] addTaxFinal = assignTax.split("~~");
						addTax = addTaxFinal[0];
						if(addTaxFinal.length == 2){
							addedTaxEmail = addTaxFinal[1];
						}
						emailIdsList = Arrays.asList(addedTaxEmail.split(","));
					}
					
					
					//unassigned taxonomies
					if(!unassignTax.equalsIgnoreCase("")){
						String[] unassignTaxFinal = unassignTax.split("~~");
						removedTax = unassignTaxFinal[0];
						String unassignTaxEmail = "";

						if(unassignTaxFinal.length == 2){
							unassignTaxEmail = unassignTaxFinal[1];
						}

						emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
					}
					//AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);


					if (!emailIdsList.isEmpty()) {
						//HashSet<String> listToSet = new HashSet<String>(emailIdsList);

						//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
						//String mailTemp = "";

						if (aiv1.getVersionable() == true) {
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"assignTaxNameForAssetInstanceForVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
									.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstanceVersionName);
						} else {
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"assignTaxNameForAssetInstanceForNonVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",
									instName);
						}

						for (String emailId : emailIdsList) {
							//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
							if (addTax != "") {
								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
							}
						}
					}

					if (!emailIds1List.isEmpty()) {
						//HashSet<String> listToSet = new HashSet<String>(emailIds1List);

						//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
					//	String mailTemp = "";

						if (aiv1.getVersionable() == true) {
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"unassignTaxNameForAssetInstanceForVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
									.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstanceVersionName);
						} else {
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
									"unassignTaxNameForAssetInstanceForNonVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
									.replaceAll("%assetInstName%", instName);
						}

						for (String emailId : emailIds1List) {

							//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
							if (removedTax != "") {
								SendEmail.sendTextMail(mailConfig, emailId,
										MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
												+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
							}
						}
					}
				
					
					conn.commit();
					if(parameterChangeNotification != null){
						JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

						if(jsonObject.has("Response Status")){
							String status = jsonObject.getString("Response Status");
							if(status.equalsIgnoreCase("success")){
								if(jsonObject.has("Notification")){
									String result1 = jsonObject.getString("Notification");
									result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
									if(!result1.equalsIgnoreCase("\"\"")){
										JSONObject maillist = new JSONObject(result1);
										if(maillist.has("Parameter changed")){
											String oldValue = maillist.getString("Old Value");
											List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
											String newValue = 	maillist.getString("New Value");
											List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
											String instanceName = maillist.getString("AssetInstanceName");
											String assetType = maillist.getString("Assetname");
											JSONArray emailArray = maillist.getJSONArray("Email Id");
											if(oldValue.equalsIgnoreCase("")){
												for(int j=0;j<emailArray.length();j++){
													SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
															MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
															MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																	+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
												}
											}else{
												for(int j=0;j<emailArray.length();j++){
													SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
															MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
															MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																	+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
												}
											}
										}
									}
								}
							}
						}
					}
					
					if(relatedParamChangeNotification != null){
						JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

						if(jsonObject.has("Response Status")){
							String status = jsonObject.getString("Response Status");
							if(status.equalsIgnoreCase("success")){
								if(jsonObject.has("Notification")){
									String result1 = jsonObject.getString("Notification");
									result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
									if(!result1.equalsIgnoreCase("\"\"")){
										JSONObject maillist = new JSONObject(result1);
										if(maillist.has("Parameter changed")){
											String oldValue = maillist.getString("Old Value");
											List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
											String newValue = 	maillist.getString("New Value");
											List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
											String instanceName = maillist.getString("AssetInstanceName");
											String assetType = maillist.getString("Assetname");
											JSONArray emailArray = maillist.getJSONArray("Email Id");
											if(oldValue.equalsIgnoreCase("")){
												for(int j=0;j<emailArray.length();j++){
													SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
															MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
															MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																	+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
												}
											}else{
												for(int j=0;j<emailArray.length();j++){
													SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
															MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
															MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																	+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
												}
											}
										}
									}
								}
							}
						}
					}
					return Response.status(retStat).entity(json.toString())
							.build();
				}
			} else {
				return updatePropertiesResponse;
			}
			
			if(saveDependencyResponse.getEntity() instanceof MyModelRest){
				modelRestSave = (MyModelRest) saveDependencyResponse.getEntity();
			}
			if(modelRestSave != null){
				statusCode = saveDependencyResponse.getStatus();
				statusMessage = modelRestSave.getMessage();
			}
			
			
			if(modelRestSave.getStatus().equalsIgnoreCase("SUCCESS")){
				json.put("message", Constants.ASSET_INSTANCE_DETAILS_UPDATED/*+responseMsg*/);
				json.put("status", Constants.SUCCESS);
				json.put("statusCode", Constants.GET_STATUS_SUCCESS);
				
				String changeKey = "";
				changeKey = overviewKey+","+relationshipdataKey+","+propertiesKey;
				
				List<String> list = Arrays.asList(changeKey.split(","));
				List<String> finallist = new ArrayList<String>();
				for(String emptydata:list){
					if(!emptydata.equalsIgnoreCase("")){
						finallist.add(emptydata);
					}
				}
				String listString = String.join(",", finallist);
				
				AssetInstanceVersionsManager assetInstanceVersionManager = new AssetInstanceVersionsManager();
				
		        User user = userDao.retProfileForUserName(userName, conn);
		        
		        assetInstanceVersionManager.addRevisionData(listString, assetInstanceVer.getAssetInstVersionId(), assetInstanceVer.getVersionName(), 
	        			overview,newRelationshipDataForRevision, newParamDataForRevision, null, userName,user.getUserId(),"", conn);
				

				//recent activity
				RecentActivity recentActivity = new RecentActivity();
				String action =  Constants.ACTIVITY_MODIFY;
				RecentActivityDao recentActivityDao = new RecentActivityDao();
				String appendingMsg = "";
				
				if (asset.isVersionable() == true) {
					String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstanceVer.getAssetInstName() + ";"+ " Version " + assetInstanceVer.getVersionName();
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(log);
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(assetInstanceVer.getAssetInstVersionId().toString());
					recentActivity.setUser_id(user.getUserId());
				} else {
					String log = user.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ assetInstanceVer.getAssetInstName() + ";"+ appendingMsg;
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(log);
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(assetInstanceVer.getAssetInstVersionId().toString());
					recentActivity.setUser_id(user.getUserId());
				}
				
				recentActivityDao.addRecentActivity(recentActivity, conn);
		        
				conn.commit();
				
				// mail 
				
				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				SubscriptionDao subscriptionDao = new SubscriptionDao();

				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				String mailTemp = null;
				
				AssetInstanceVersion aiv1 = assetInstVersionDao.getAssetInstanceVersionDetails(assetInstanceVer.getAssetInstVersionId(), conn);
				List<String> emailIds = subscriptionDao.getAllSubscriptionsByAssetInstanceId(aiv1.getAssetInstanceId(), conn);

				if(aiv1.getVersionable() == true){
					MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForVersionableAsset");
					mailTemp = mtVo1.getMailTemplate();
					String instName = aiv1.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv1.getVersionName());
				}else{
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForNonVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = aiv1.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
				}
				if(emailIds!=null){
					for(String emailId:emailIds){
						if(aiv1.getVersionable() == true) {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
						else {
							SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
					}
				}
				
				// taxonomy mail

				String assignTax = "";
				String unassignTax = "";
				String addTax = "";
				String removedTax = "";
				List<String> emailIdsList = new ArrayList<String>();
				List<String> emailIds1List = new ArrayList<String>();
				for(Map.Entry<String, String> entry : taxMap.entrySet()){
					assignTax = entry.getKey();
					unassignTax = entry.getValue();
				}
				//added taxonomies
				if(!assignTax.equalsIgnoreCase("")){
					String addedTaxEmail = "";
					String[] addTaxFinal = assignTax.split("~~");
					addTax = addTaxFinal[0];
					if(addTaxFinal.length == 2){
						addedTaxEmail = addTaxFinal[1];
					}
					emailIdsList = Arrays.asList(addedTaxEmail.split(","));
				}
				
				//unassigned taxonomies
				if(!unassignTax.equalsIgnoreCase("")){
					String[] unassignTaxFinal = unassignTax.split("~~");
					removedTax = unassignTaxFinal[0];
					String unassignTaxEmail = "";

					if(unassignTaxFinal.length == 2){
						unassignTaxEmail = unassignTaxFinal[1];
					}

					emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
				}
				//AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);


				if (!emailIdsList.isEmpty()) {
					//HashSet<String> listToSet = new HashSet<String>(emailIdsList);

					//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
					//String mailTemp = "";

					if (aiv1.getVersionable() == true) {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"assignTaxNameForAssetInstanceForVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
								.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstanceVersionName);
					} else {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"assignTaxNameForAssetInstanceForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",
								instName);
					}

					for (String emailId : emailIdsList) {
						//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						if (addTax != "") {
							SendEmail.sendTextMail(mailConfig, emailId,
									MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
											+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
					}
				}

				if (!emailIds1List.isEmpty()) {
					//HashSet<String> listToSet = new HashSet<String>(emailIds1List);
					//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
				//	String mailTemp = "";

					if (aiv1.getVersionable() == true) {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"unassignTaxNameForAssetInstanceForVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
								.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", assetInstanceVersionName);
					} else {
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
								"unassignTaxNameForAssetInstanceForNonVersionableAsset");
						mailTemp = mtVo.getMailTemplate();
						String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
						mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
								.replaceAll("%assetInstName%", instName);
					}

					for (String emailId : emailIds1List) {

						//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						if (removedTax != "") {
							SendEmail.sendTextMail(mailConfig, emailId,
									MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
											+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
					}
				}
				if(parameterChangeNotification != null){
					JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result1 = jsonObject.getString("Notification");
								result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
								if(!result1.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result1);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}
				
				if(relatedParamChangeNotification != null){
					JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result1 = jsonObject.getString("Notification");
								result1 = result1.substring(result1.indexOf("[")+1, result1.lastIndexOf("]"));
								if(!result1.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result1);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}
				return Response.status(retStat).entity(json.toString())
						.build();
			}else{
				return saveDependencyResponse;
			}
					
		}catch (RepoproException e) {
			log.error("updateInstancePropertiesRelationships: SQL Exception addAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}catch (Exception e) {
			log.error("updateInstancePropertiesRelationships: SQL Exception addAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateInstancePropertiesRelationships : " + Constants.LOG_CONNECTION_CLOSE);
			}
			if(conn != null){
				DBConnection.closeDbConnection(conn);
			}
		}

		if (log.isTraceEnabled()) {
			log.trace("updateInstancePropertiesRelationships || Exit");
		}

		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	/**
	 * @method createChildAssetInstance
	 * @param assetInstanceDetails
	 * @param bodyParts
	 * @param context
	 * @return success response
	 */
	@POST
	@Encoded
	@Path("/updateChildAssetInstance")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
	public Response createChildAssetInstance(@FormDataParam("assetInstanceDetails") String assetInstanceDetails,
			FormDataMultiPart bodyParts,@Context ServletContext context){

		if (log.isTraceEnabled()) {
			log.trace("createChildAssetInstance || Begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("createChildAssetInstance : "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			CommonUtils commonUtils = new CommonUtils();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
			TaggingDao taggingDao = new TaggingDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			AssetDao assetDao = new AssetDao();
			UserDao userDao = new UserDao();
			AssetInstanceVersion assetInstanceVersion = new AssetInstanceVersion();
			AssetInstance assetInstance = new AssetInstance();
			TaggingMaster taggingMaster = new TaggingMaster();
			List<Long> addDestassetinstversionIds = new ArrayList<Long>();
			List<Long> removeDestassetinstversionIds = new ArrayList<Long>();
			List<Long> addRelationshipIds = new ArrayList<Long>();
			List<Long> removeRelationshipIds = new ArrayList<Long>();
			Map<Long, String> names = new HashMap<Long, String>();
			AivRevisionHistory aivRevHist = new AivRevisionHistory();
			String newInstanceKey = "";
			String relationshipdataKey = "";
			String propertiesKey = "";
			String newRelationshipDataForRevision = "";
			String newParamDataForRevision = "";
			String usedByData = "",relationshipName = "";
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			RecentActivity recentActivity = new RecentActivity();
			WorkflowDao workflowDao = new WorkflowDao();
			String action =  Constants.ACTIVITY_CREATE;
			String appendingMsg = "";
			Map<String, String> taxMap = new HashMap<String, String>();
			String jsonStr = assetInstanceDetails;
			JSONObject obj = new JSONObject(jsonStr);
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();

			String assetName = URLDecoder.decode(obj.get("assetName").toString(),"UTF-8");
			String assetInstName = URLDecoder.decode(obj.get("assetInstName").toString(),"UTF-8");
			String owner = obj.get("owner").toString();
			String userName = owner;
			String versionName = obj.get("versionName").toString();
			Long parentAssetInstVersionId = obj.getLong("parentAssetInstVersionId");
			Long parentAssetId = obj.getLong("parentAssetId");
			String parentVersionName = obj.get("parentVersionName").toString();
			String parentAssetInstName = URLDecoder.decode(obj.get("parentAssetInstName").toString(),"UTF-8");

			String addRelationship = "";
			String addDestAivIds = "";
			String removeRelationship = "";
			String removeDestAivIds = "";
			if(jsonStr.contains("addRelationshipIds")){
				addRelationship =  obj.get("addRelationshipIds").toString();
				JSONArray addRelationshipArray = new JSONArray(addRelationship);
				if (addRelationshipArray != null) { 
					for (int i=0;i<addRelationshipArray.length();i++){ 
						addRelationshipIds.add(Long.parseLong(addRelationshipArray.getString(i)));
					} 
				} 
			}
			if(jsonStr.contains("addDestAivIds")){
				addDestAivIds =  obj.get("addDestAivIds").toString();
				JSONArray addDestAivIdsArray = new JSONArray(addDestAivIds);
				if (addDestAivIdsArray != null) { 
					for (int i=0;i<addDestAivIdsArray.length();i++){ 
						addDestassetinstversionIds.add(Long.parseLong(addDestAivIdsArray.getString(i)));
					} 
				} 
			}
			if(jsonStr.contains("removeRelationshipIds")){
				removeRelationship =  obj.get("removeRelationshipIds").toString();
				JSONArray removeRelationshipArray = new JSONArray(removeRelationship);
				if (removeRelationshipArray != null) { 
					for (int i=0;i<removeRelationshipArray.length();i++){ 
						removeRelationshipIds.add(Long.parseLong(removeRelationshipArray.getString(i)));
					} 
				} 
			}
			if(jsonStr.contains("removeDestAivIds")){
				removeDestAivIds =  obj.get("removeDestAivIds").toString();
				JSONArray removeDestAivIdsArray = new JSONArray(removeDestAivIds);
				if (removeDestAivIdsArray != null) { 
					for (int i=0;i<removeDestAivIdsArray.length();i++){ 
						removeDestassetinstversionIds.add(Long.parseLong(removeDestAivIdsArray.getString(i)));
					} 
				}
			}
			
			//get user details
			User user = userDao.getUserIdByUserName(userName, null);
			
			//get child asset details
			AssetDef asset = assetInstanceDao.retAssetDetail(assetName,conn);
			
			//child details
			assetInstance.setAssetId(asset.getAssetId());
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(versionName);
			//paraent details
			assetInstance.setParentAssetId(parentAssetId);
			assetInstance.setParentAssetInstName(parentAssetInstName);
			assetInstance.setParentAssetInstVersionId(parentAssetInstVersionId);
			assetInstance.setParentVersionName(parentVersionName);
			
			//get global setting setting details
			if (log.isTraceEnabled()){
				log.trace("createChildAssetInstance || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);
			
			
			//to add new child asset instance
			String description = obj.get("description").toString();
			if(globalsetting.getGlobalSettingFlag() == 1){
				description = commonUtils.httpSanitizerForCkEditor(obj.get("description").toString());
			}
			if(description.equalsIgnoreCase("")){
				retMsg = Constants.PLEASE_PROVIDE_DESCRIPTION;
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			}
			assetInstance.setDescription(description);
			Response response = addAssetInstanceHelper(assetInstance,userName,true,true,false, conn);
			MyModel res = (MyModel) response.getEntity();
			List<Object> result = res.getResult();
			if(res.getStatus().equals("FAILURE")){
				return response;
			}
			for (int i = 0; i < result.size(); i++) {
				AssetInstance ai = new AssetInstance();
				ai = (AssetInstance) result.get(i);
				assetInstance.setAssetInstId(ai.getAssetInstId());
				assetInstance.setAssetInstVersionId(ai.getAssetInstVersionId());
			}
			
			RelationshipDao relationshipDao = new RelationshipDao();
			List<AssetRelationshipDef> assetRelationshipDefList = new ArrayList<AssetRelationshipDef>();
			if(assetInstance.getParentAssetId() != null){
				assetRelationshipDefList = relationshipDao.getAvailbleAssetRelationships(assetInstance.getParentAssetId(),assetInstance.getAssetId(), conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceHelper : call dao getAssetInstanceVersion() method for fetching asset instance version details:");
			}
			AssetInstanceVersion aivForAddingNewRevision = assetInstanceVersionDao
					.getAssetInstanceVersion(assetInstance.getAssetInstId(),assetInstance.getVersionName(), conn);
			if(aivForAddingNewRevision != null){
				for(AssetRelationshipDef assetRelationshipDefVo : assetRelationshipDefList){
					if((assetRelationshipDefVo.getFwdRelId() == 1)|| (assetRelationshipDefVo.getFwdRelId() == 5)){
						relationshipName = assetRelationshipDefVo.getDescription();
					}
				}
				if(!asset.isVersionable()){
					usedByData = assetInstance.getParentAssetInstName()+"("+relationshipName+")";
				}else{
					usedByData = assetInstance.getParentAssetInstName()+"_"+assetInstance.getParentVersionName()+"("+relationshipName+")";
				}	
			}
			newInstanceKey = "N";
			
	        obj.put("assetInstanceVersionId",assetInstance.getAssetInstVersionId());
	        
	        //to update tags
	        if(jsonStr.contains("tagNames")){
	        	String tagNames = obj.get("tagNames").toString();
	        	if(!tagNames.equalsIgnoreCase("")){
	        		String[] keyValuePairs = tagNames.split(",");
	        		Long j = 1L;
	        		for(String pair : keyValuePairs)                        
	        		{
	        			names.put(j, pair);
	        			j++;
	        		}
	        	}
	        	taggingMaster.setAssetInstanceVersionId(assetInstance.getAssetInstVersionId());
	        	taggingMaster.setTagNames(names);
	        	taggingMaster.setUserId(user.getUserId());
	        	taggingDao.addTags(taggingMaster, conn);
	        }
	        
	       //to update taxonomies
	        if(jsonStr.contains("TaxonomyIds")){
				String TaxonomyIds = obj.get("TaxonomyIds").toString();
	        	Response taxResponse = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(assetInstance.getAssetInstVersionId(),
	        			TaxonomyIds,asset.isVersionable(),assetInstance.getVersionName(),assetInstance.getAssetInstName(),true,conn);
	        	MyModel taxRes = (MyModel) taxResponse.getEntity();
	        	taxMap = taxRes.getParamValues();
	        	if(taxRes.getStatus().equals("FAILURE")){
		        	return taxResponse;
		        }
	        }
	        
	        //to update instance relationship data
	        if(!removeDestassetinstversionIds.isEmpty() || !addDestassetinstversionIds.isEmpty() 
	        		|| !removeRelationshipIds.isEmpty() || !addRelationshipIds.isEmpty()){
	        	assetInstanceVersion.setRemovedDestAssetInstVersionIds(removeDestassetinstversionIds);
	        	assetInstanceVersion.setAddDestAssetInstVersionIds(addDestassetinstversionIds);
	        	assetInstanceVersion.setRemovedRelationshipIds(removeRelationshipIds);
	        	assetInstanceVersion.setAddRelationshipIds(addRelationshipIds);
	        	assetInstanceVersion.setSrcAssetInstanceVersionId(assetInstance.getAssetInstVersionId().toString());
	        	assetInstanceVersion.setAssetId(assetInstance.getAssetId());
	        	assetInstanceVersion.setAssetInstanceId(assetInstance.getAssetInstId());
	        	assetInstanceVersion.setVersionName(assetInstance.getVersionName());
	        	assetInstanceVersion.setAssetInstName(assetInstance.getAssetInstName());
	        	Response relResponse = saveDependencyHelper(assetInstanceVersion,userName,true,conn);
	        	MyModel relRes = (MyModel) relResponse.getEntity();
	        	if(relRes.getStatus().equals("FAILURE")){
	        		return relResponse;
	        	}
	        	if (log.isTraceEnabled()) {
					log.trace("saveDependencyHelper ||call Helper method retFwdDependents() to get srcassetinstanceversion dependents");
				}
				List<AssetInstance> aivos = retFwdDependents(assetInstanceVersion,conn);
				int i = 1;
				for(AssetInstance aivo : aivos){
					AssetDef assetDef = assetDao.getAssetsByAssetId(aivo.getAssetId(), conn);
					if(i == aivos.size()){
						if(!assetDef.isVersionable()){
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]";	
						}else{
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]";	
						}	
					}else{
						if(!assetDef.isVersionable()){
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
						}else{
							newRelationshipDataForRevision = newRelationshipDataForRevision + aivo.getAssetName()+"-->"+aivo.getAssetInstName()+"_"+aivo.getVersionName()+" ["+aivo.getAssetRelationshipName()+"]"+"&<!!>&";	
						}
					}
					i++;
				}
				relationshipdataKey = "R";
	        }
			
	        //to update parameter values
	        //mandatory parameter validation at object level
        	List<AssetParamDef> assetParamdef = assetDao.getParamsDetails(userName,asset.getAssetId(),conn);
        	if(obj.get("parameterList").toString().equalsIgnoreCase("")){	
        		for(AssetParamDef mandatoryCheck:assetParamdef){
        			boolean editFlag = false;
        			if(!userName.equalsIgnoreCase("admin")){
        				List<GroupDetails> gd = assetDao.getAssetCategoryEditAccessForPropertiesAivPage(userName,mandatoryCheck.getAssetCategoryId(), conn);
        				for(GroupDetails gd1 : gd){
        					if(gd1.getEditAccess() == 1L){
        						editFlag = true;
        						break;
        					}
        				}
        			}else{
        				editFlag = true;
        			}
        			if(editFlag){
        				if(mandatoryCheck.isHasMandatoryValue()){
        					return Response
        							.status(Status.OK)
        							.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
        									Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
        									.build();

        				}
        			}
        		}
        	}
        	
	      //parameter list construction from hidden variable
        	Object parameterChangeNotification = null;
        	Object relatedParamChangeNotification = null;
	          if(!obj.get("parameterList").toString().equalsIgnoreCase("")){
	        	List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();
	        	AssetInstanceVersion aiv = null;
	        	String newFileNameForImageOnly = "";
	        	String aivParameterList = obj.get("parameterList").toString();
	        	JSONArray aivParameterListArray = new JSONArray(aivParameterList);
	        	for (int i = 0; i < aivParameterListArray.length(); i++) {
	        		Iterator itr = aivParameterListArray.getJSONObject(i).keys();
	        		while (itr.hasNext()) {
	        			aiv = new AssetInstanceVersion();
	        			Object keyName = itr.next();

	        			aiv.setAsset_category_name(aivParameterListArray.getJSONObject(i).get("asset_category_name").toString());
	        			aiv.setAssetParamId(aivParameterListArray.getJSONObject(i).getLong("assetParamId"));
	        			aiv.setAssetParamName(aivParameterListArray.getJSONObject(i).get("assetParamName").toString());
	        			aiv.setIsStatic(aivParameterListArray.getJSONObject(i).getInt("isStatic"));
	        			aiv.setParamTypeId(aivParameterListArray.getJSONObject(i).getLong("paramTypeId"));

	        			if (aiv.getParamTypeId() == 3){
	        				newFileNameForImageOnly = aivParameterListArray.getJSONObject(i).get("newFileName").toString();
	        				if(!aivParameterListArray.getJSONObject(i).get("fileName").toString().isEmpty() && !newFileNameForImageOnly.isEmpty()){
	        					aiv.setFileName(newFileNameForImageOnly);
	        				} else if(!newFileNameForImageOnly.isEmpty()){
	        					aiv.setFileName(newFileNameForImageOnly);
	        				} else {
	        					aiv.setFileName(aivParameterListArray.getJSONObject(i).get("fileName").toString());
	        				}
	        			}else if(aiv.getParamTypeId() == 7){
	        				aiv.setHasArray(aivParameterListArray.getJSONObject(i).getInt("isArray"));
	        				if(aiv.getHasArray() == 1){
	        					JSONObject richTextdataJsonObject = aivParameterListArray.getJSONObject(i).getJSONObject("rich_text_data");
	        					JSONArray withTagArray = null;
	        					JSONArray withoutTagArray = null;
	        					if(richTextdataJsonObject.has("without_tag")){
	        						withoutTagArray = richTextdataJsonObject.getJSONArray("without_tag");
	        					}
	        					if(richTextdataJsonObject.has("with_tag")){
	        						withTagArray = richTextdataJsonObject.getJSONArray("with_tag");
	        					}
	        					if(withTagArray != null){
	        						List<String> withTags = new ArrayList<String>();
	        						for(int j=0;j<withTagArray.length();j++){
	        							String textString = withTagArray.getJSONObject(j).get("textField").toString();
	        							textString = URLDecoder.decode(textString, "UTF-8");
	        							if(globalsetting.getGlobalSettingFlag() == 1){
	        								textString = commonUtils.httpSanitizerForCkEditor(textString);
	        							}
	        							withTags.add(textString);
	        						}
	        						aiv.setRTFwithTags(withTags);
	        						// for adding revision history
	        						String textdata = String.join("~~", aiv.getRTFwithTags());
	        						aiv.setParamValue(textdata);
	        					}
	        					if(withoutTagArray != null){
	        						List<String> withoutTags = new ArrayList<String>();
	        						for(int k=0;k<withoutTagArray.length();k++){
	        							String textString = withoutTagArray.getJSONObject(k).get("textField").toString();
	        							withoutTags.add(URLDecoder.decode(textString, "UTF-8"));
	        						}
	        						aiv.setRTFwithOutTags(withoutTags);
	        					}
	        				}else{
	        					JSONObject richTextdataJsonObject = aivParameterListArray.getJSONObject(i).getJSONObject("rich_text_data");
	        					String withTagArray = null;
	        					String withoutTagArray = null;
	        					//String safeHTML = null;

	        					if(richTextdataJsonObject.has("without_tag")){
	        						withoutTagArray = richTextdataJsonObject.get("without_tag").toString();
	        					}
	        					if(richTextdataJsonObject.has("with_tag")){
	        						withTagArray = richTextdataJsonObject.get("with_tag").toString();
        							if(globalsetting.getGlobalSettingFlag() == 1){
        								withTagArray = commonUtils.httpSanitizerForCkEditor(URLDecoder.decode(withTagArray, "UTF-8"));
        							}
	        					}
	        					aiv.setRTFPlainText(URLDecoder.decode(withoutTagArray, "UTF-8"));
	        					aiv.setParamValue(withTagArray);
	        				}
	        			}else if (aiv.getParamTypeId() == 1){
	        				if(aiv.getIsStatic() == 1){
	        					String encodeval = URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(), "UTF-8");
	        					if(globalsetting.getGlobalSettingFlag() == 1){
    								encodeval = commonUtils.httpSanitizerForPlainText(encodeval);
    							}
	        					aiv.setParamValue(encodeval);
	        				}else{
	        					aiv.setHasArray(aivParameterListArray.getJSONObject(i).getInt("isArray"));
	        					if(aiv.getHasArray() == 1){
	        						JSONArray textdataJsonArray = aivParameterListArray.getJSONObject(i).getJSONArray("text_data");
	        						List<String> textDataList = new ArrayList<String>();
	        						for(int ii=0;ii<textdataJsonArray.length();ii++){
	        							String encodeval = URLDecoder.decode(textdataJsonArray.getString(ii), "UTF-8");
	        							String safeHTML = commonUtils.httpSanitizerForPlainText(encodeval);
	        							textDataList.add(safeHTML);
	        						}
	        						aiv.setTextDataList(textDataList);
	        						// for adding revision history
	        						String textdata = String.join("~~", aiv.getTextDataList());
	        						aiv.setParamValue(textdata);
	        					}else{

	        						String encodeval = URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(), "UTF-8");
        							if(globalsetting.getGlobalSettingFlag() == 1){
        								encodeval = commonUtils.httpSanitizerForPlainText(encodeval);
        							}
	        						aiv.setParamValue(encodeval);
	        					}
	        				}
	        			}else if(aiv.getParamTypeId() == 9){
	        				
	        				//Map<String,Integer> finalParamValList = commonUtils.ldapDataconstruction(URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8"),assetName ,aiv.getAssetParamName(),conn);
	        				
	        				Map<String,Integer> finalParamValList = new HashMap<String, Integer>();
	        				String paramVal = URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8");

	        				ObjectMapper mapper = new ObjectMapper();
	        				finalParamValList = mapper.readValue(paramVal, new TypeReference<Map<String, Integer>>(){});
	        				
	        				aiv.setLdapMappingValue(finalParamValList);
	        				
	        			}else {
	        				aiv.setParamValue(URLDecoder.decode(aivParameterListArray.getJSONObject(i).get("paramValue").toString(),"UTF-8"));
	        			}
	        			aiv.setAssetInstVersionId(assetInstance.getAssetInstVersionId());
	        			aiv.setConn(conn);
	        			aiv.setLog(log);
	        			aiv.setUserId(user.getUserId());
	        			aiv.setAssetInstName(assetInstName);
	        			aiv.setAssetName(assetName);
	        			ListOfAssetInstanceProperties.add(aiv);
	        			break;
	        		}
	        	}
	        	//mandatory parameter validation at each parameter
	        	for(AssetParamDef mandatoryCheck:assetParamdef){
	        		boolean editFlag = false;
	        		if(!userName.equalsIgnoreCase("admin")){
	        			List<GroupDetails> gd = assetDao.getAssetCategoryEditAccessForPropertiesAivPage(userName,mandatoryCheck.getAssetCategoryId(), conn);
	        			for(GroupDetails gd1 : gd){
	        				if(gd1.getEditAccess() == 1L){
	        					editFlag = true;
	        					break;
	        				}
	        			}
	        		}else{
	        			editFlag = true;
	        		}
	        		if(editFlag){
	        			if(mandatoryCheck.isHasMandatoryValue()){
	        				for(AssetInstanceVersion data:ListOfAssetInstanceProperties){
	        					if(mandatoryCheck.getAssetParamId().equals(data.getAssetParamId())){
	        						if(data.getParamTypeId() == 3){
	        							if(data.getFileName().equalsIgnoreCase("")){
	        								return Response
	        										.status(Status.OK)
	        										.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        												Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        												.build();
	        							}
	        						}else if(data.getParamTypeId() == 7){
	        							if(data.getHasArray() == 1){
	        								if(data.getRTFwithTags().get(0).equalsIgnoreCase("")){
	        									return Response
	        											.status(Status.OK)
	        											.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        													Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        													.build();
	        								}

	        							}else{
	        								if(data.getRTFPlainText().equalsIgnoreCase("")){
	        									return Response
	        											.status(Status.OK)
	        											.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        													Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        													.build();

	        								}
	        							}
	        						}else if(data.getParamTypeId() == 1){
	        							if(data.getHasArray() == 1){
	        								if(data.getTextDataList().get(0).equalsIgnoreCase("")){
	        									return Response
	        											.status(Status.OK)
	        											.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        													Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        													.build();
	        								}

	        							}else{
	        								if(data.getParamValue().equalsIgnoreCase("")){
	        									return Response
	        											.status(Status.OK)
	        											.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        													Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        													.build();

	        								}
	        							}
	        						}else if(data.getParamTypeId() == 9){
	        							if(data.getLdapMappingValue().isEmpty()){
	        								return Response
	        										.status(Status.OK)
	        										.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        												Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        										.build();
	        							}

	        						}else{
	        							if(data.getParamTypeId() != 5 && data.getParamTypeId() != 6){
	        								if(data.getParamValue().equalsIgnoreCase("")){
	        									return Response
	        											.status(Status.OK)
	        											.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
	        													Constants.FAILURE, MessageUtil.getMessage(Constants.PROVIDE_MANDATORY_PARAMETERS)))
	        													.build();

	        								}
	        							}
	        						}
	        					}
	        				}
	        			}
	        		}
	        	}
	        	
	        	
	        	if(CommonUtils.customParameterPluginNoficationClassName != null && CommonUtils.customParameterPluginPath != null){

    				if(!CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") && !CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

    					Class notificationInterface = CustomParameterPluginUtilies.getplugin();

    					if(notificationInterface != null){
    						Method method = null;
    						Method relatedParamChangeMethod = null;
    						try {
    							method = notificationInterface.getMethod("notifyOnParameterValueChanges",new Class[]{List.class});
    							relatedParamChangeMethod = notificationInterface.getMethod("notifyOnParameterValueChangesBasedOnOtherParameter",new Class[]{List.class});
    							
    						} catch (NoSuchMethodException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						} catch (SecurityException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						}

    						Object instance = null;
    						try {
    							instance = notificationInterface.newInstance();
    						} catch (InstantiationException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						} catch (IllegalAccessException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						}	


    						try{
    							parameterChangeNotification = method.invoke(instance,ListOfAssetInstanceProperties);
    							
    							if(parameterChangeNotification != null){
    								JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

    								if(jsonObject.has("Response Status")){
    									String status = jsonObject.getString("Response Status");
    									if(status.equalsIgnoreCase("failure")){
    										retStat = Status.INTERNAL_SERVER_ERROR;;
    				        				retScsFlr = status;
    				        				retMsg = jsonObject.getString("Response Message");
    				        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

    				        				return Response.status(retStat)
    				        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
    									}
    								}
    							}
    							
    							
    							relatedParamChangeNotification = relatedParamChangeMethod.invoke(instance,ListOfAssetInstanceProperties);
    							if(relatedParamChangeNotification != null){
    								JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

    								if(jsonObject.has("Response Status")){
    									String status = jsonObject.getString("Response Status");
    									if(status.equalsIgnoreCase("failure")){
    										retStat = Status.INTERNAL_SERVER_ERROR;;
    				        				retScsFlr = status;
    				        				retMsg = jsonObject.getString("Response Message");
    				        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

    				        				return Response.status(retStat)
    				        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
    									}
    								}
    							}
    						}
    						catch (IllegalAccessException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						} catch (IllegalArgumentException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						} catch (InvocationTargetException e) {
    							// TODO Auto-generated catch block
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						}catch(Exception e){
    							e.printStackTrace();
    							throw new RepoproException(e.getMessage());
    						}
    					}else{
    						retStat = Status.BAD_REQUEST;
	        				retScsFlr = Constants.FAILURE;
	        				retMsg = "Invalid Plugin configuration";
	        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	        				return Response.status(retStat)
	        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
    					}
    				}
    				if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")|| CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

	    				retStat = Status.BAD_REQUEST;
	    				retScsFlr = Constants.FAILURE;
	    				retMsg = "Invalid Plugin configuration";
	    				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

	    				return Response.status(retStat)
	    						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	    			}
    			}
	        	if(CommonUtils.customParameterPluginNoficationClassName != null ){
        			if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")){
        				retStat = Status.BAD_REQUEST;
        				retScsFlr = Constants.FAILURE;
        				retMsg = "Invalid Plugin configuration";
        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

        				return Response.status(retStat)
        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
        			}
        		}else if(CommonUtils.customParameterPluginPath != null){
        			if(CommonUtils.customParameterPluginPath .equalsIgnoreCase("")){
        				retStat = Status.BAD_REQUEST;
        				retScsFlr = Constants.FAILURE;
        				retMsg = "Invalid Plugin configuration";
        				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;

        				return Response.status(retStat)
        						.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
        			}
        		}
    			//update properties values
	        	Response propResponse = assetInstanceVersionsManager.updatePropertiesHelper(obj.toString(), ListOfAssetInstanceProperties, bodyParts, context, true, conn);
	        	MyModel propRes = (MyModel) propResponse.getEntity();
	        	if(propRes.getStatus().equals("FAILURE")){
	        		return propResponse;
	        	}
	        	List<Object> data = propRes.getResult();
	        	for (int i = 0; i < data.size(); i++) {
					String revHis = new String();
					revHis = (String) data.get(i);
					newParamDataForRevision = revHis;
				}
	        	propertiesKey = "P";
	        }
	          
	        String changeKey = "";  
		    changeKey = newInstanceKey+","+relationshipdataKey+","+propertiesKey;
	        List<String> list = Arrays.asList(changeKey.split(","));
	        List<String> finallist = new ArrayList<String>();
	        for(String emptydata:list){
	        	if(!emptydata.equalsIgnoreCase("")){
	        		finallist.add(emptydata);
	        	}
	        }
	        String listString = String.join(",", finallist);
	        
	        RevisionHistoryDao revisionHistoryDao = new RevisionHistoryDao();
	        aivRevHist = new AivRevisionHistory();
			aivRevHist.setAivId(assetInstance.getAssetInstVersionId());
			aivRevHist.setRevId(assetInstance.getVersionName()+".0");
			aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			aivRevHist.setChangedKey(listString);
			aivRevHist.setOverviewData(assetInstance.getDescription());
			if(!newRelationshipDataForRevision.equalsIgnoreCase("")){
				aivRevHist.setRelationshipData(newRelationshipDataForRevision);
			}else{
				aivRevHist.setRelationshipData(null);
			}
			if(!newParamDataForRevision.equalsIgnoreCase("")){
				aivRevHist.setParameterData(newParamDataForRevision);
			}else{
				aivRevHist.setParameterData(null);
			}
			aivRevHist.setUserId(user.getUserId());
			if(!usedByData.equalsIgnoreCase("")){
				aivRevHist.setUsedBy(usedByData);
			}else{
				aivRevHist.setUsedBy(null);
			}
			
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstanceHelper : call dao addRevisionData() method for adding revision data");
			}
			revisionHistoryDao.addRevisionData(aivRevHist, conn);
			
			AssetInstanceVersion aivo = new AssetInstanceVersion();
			aivo.setVersionName("1.0");
			aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			aivo.setAssetInstVersionId(aivRevHist.getAivId());
			assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
			
			//recent activity
			if (asset.isVersionable() == true) {
				String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ " Version " + assetInstance.getVersionName();
				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setDescription(log);
				recentActivity.setAssetId(asset.getAssetId().toString());
				recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
				recentActivity.setUser_id(user.getUserId());
			} else {
				String log = user.getFullName() + ";" + action + ";"+ assetInstance.getAssetName() + ";"+ assetInstance.getAssetInstName() + ";"+ appendingMsg;
				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setDescription(log);
				recentActivity.setAssetId(asset.getAssetId().toString());
				recentActivity.setAssetInstVersionId(assetInstance.getAssetInstVersionId().toString());
				recentActivity.setUser_id(user.getUserId());
			}
			
			recentActivityDao.addRecentActivity(recentActivity, conn);
			
			Long firstState = null;
			Workflow workflow = workflowDao.retWorkflowByAivId(assetInstance.getAssetInstVersionId(), conn);
			if(workflow != null) {
				String jsonStructure = workflow.getJsonStructure();
				JSONObject jsonObject = new JSONObject(jsonStructure);

				for(int i=0;i<jsonObject.length();i++) {
					Iterator itr = jsonObject.keys();
					if(itr.hasNext()){
						firstState = Long.parseLong(itr.next().toString());
					}
				}
				assetInstanceDao.updateAssetInstanceState(assetInstance.getAssetInstVersionId(),firstState,conn);
			}

			conn.commit();
			
			//TODO: Asset Visualization
			AssetRepresentationDao repDao = new AssetRepresentationDao();
			FormDataBodyPart dataMultiPart = null;
			
			if (bodyParts != null) {
				dataMultiPart = bodyParts.getField("uploadedJarSupportFile");			
				if(dataMultiPart != null){
					String fileName = dataMultiPart.getContentDisposition().getFileName();
					InputStream in = dataMultiPart.getEntityAs(InputStream.class);
					String outputPath = Constants.UPLOADED_JAR_SUPPORT_FILE_PATH + assetInstance.getAssetInstVersionId() + "/";
					File directory = new File(outputPath);
					if (!directory.exists()) {
						directory.mkdir();
					}
					
					//TODO: change output path
					File uploadedJarSupportFile = new File(Constants.UPLOADED_JAR_SUPPORT_FILE_PATH + fileName);
					FileOutputStream outStream = new FileOutputStream(uploadedJarSupportFile);
					
					IOUtils.copy(in,outStream);
					
					repDao.saveAssetInstanceRepresentation(conn, assetName, assetInstance.getAssetInstId(), assetInstance.getAssetInstVersionId(), uploadedJarSupportFile, outputPath);
					
					in.close();
					outStream.close();
					FileUtils.forceDelete(uploadedJarSupportFile);
				}
			}

			conn.commit();	
			
			// mail template
			MailTemplateDao mailTemplateDao = new MailTemplateDao();
			SubscriptionDao subscriptionDao = new SubscriptionDao();

			MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
			String mailTemp = null;

			// add child instance

			AssetInstanceVersion aiv = assetInstanceVersionDao
					.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);
			List<String> emailIds = subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);

			if (aiv.getVersionable() == true) {
				MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(
						conn, "createAssetInstanceVersion");
				mailTemp = mtVo1.getMailTemplate();
				String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
				mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
			} else {
				MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(
						conn, "createAssetInstanceNonVersion");
				mailTemp = mtVo.getMailTemplate();
				String instName = aiv.getAssetInstName().replace("\\", "\\\\").replace("$", "\\$");
				mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%assetType%", aiv.getAssetName());
			}
			if (emailIds != null) {
				for (String emailId : emailIds) {
					if (aiv.getVersionable() == true) {
						SendEmail.sendTextMail(
										mailConfig,emailId,
										MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR)
												+ mailTemp+ "\n"+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
					} else {
						SendEmail.sendTextMail(
										mailConfig,emailId,
										MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
										MessageUtil.getMessage(Constants.EMAIL_HDR)
												+ mailTemp+ "\n"+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
					}
				}
			}
						

			// taxonomy mail

			String assignTax = "";
			String unassignTax = "";
			String addTax = "";
			String removedTax = "";
			List<String> emailIdsList = new ArrayList<String>();
			List<String> emailIds1List = new ArrayList<String>();
			for(Map.Entry<String, String> entry : taxMap.entrySet()){
				assignTax = entry.getKey();
				unassignTax = entry.getValue();
			}
			//added taxonomies
			if(!assignTax.equalsIgnoreCase("")){
				String addedTaxEmail = "";
				String[] addTaxFinal = assignTax.split("~~");
				addTax = addTaxFinal[0];
				if(addTaxFinal.length == 2){
					addedTaxEmail = addTaxFinal[1];
				}
				emailIdsList = Arrays.asList(addedTaxEmail.split(","));
			}
			
			
			//unassigned taxonomies
			if(!unassignTax.equalsIgnoreCase("")){
				String[] unassignTaxFinal = unassignTax.split("~~");
				removedTax = unassignTaxFinal[0];
				String unassignTaxEmail = "";

				if(unassignTaxFinal.length == 2){
					unassignTaxEmail = unassignTaxFinal[1];
				}

				emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
			}
			AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersionDetails(assetInstance.getAssetInstVersionId(), conn);


			if (!emailIdsList.isEmpty()) {
				//HashSet<String> listToSet = new HashSet<String>(emailIdsList);

				//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
				//String mailTemp = "";

				if (aiv1.getVersionable() == true) {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"assignTaxNameForAssetInstanceForVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
							.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", versionName);
				} else {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"assignTaxNameForAssetInstanceForNonVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",
							instName);
				}

				for (String emailId : emailIdsList) {
					//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					if (addTax != "") {
						SendEmail.sendTextMail(mailConfig, emailId,
								MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
								MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
										+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
					}
				}
			}

			if (!emailIds1List.isEmpty()) {
				//HashSet<String> listToSet = new HashSet<String>(emailIds1List);

				//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);
			//	String mailTemp = "";

				if (aiv1.getVersionable() == true) {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"unassignTaxNameForAssetInstanceForVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
							.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", versionName);
				} else {
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
							"unassignTaxNameForAssetInstanceForNonVersionableAsset");
					mailTemp = mtVo.getMailTemplate();
					String instName = assetInstName.replace("\\", "\\\\").replace("$", "\\$");
					mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
							.replaceAll("%assetInstName%", instName);
				}

				for (String emailId : emailIds1List) {

					//MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
					if (removedTax != "") {
						SendEmail.sendTextMail(mailConfig, emailId,
								MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
								MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
										+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
					}
				}
			}
			

			if(parameterChangeNotification != null){
				JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

				if(jsonObject.has("Response Status")){
					String status = jsonObject.getString("Response Status");
					if(status.equalsIgnoreCase("success")){
						if(jsonObject.has("Notification")){
							String notification = jsonObject.getString("Notification");
							notification = notification.substring(notification.indexOf("[")+1, notification.lastIndexOf("]"));
							if(!notification.equalsIgnoreCase("\"\"")){
								JSONObject maillist = new JSONObject(notification);
								if(maillist.has("Parameter changed")){
									String oldValue = maillist.getString("Old Value");
									List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
									String newValue = 	maillist.getString("New Value");
									List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
									String instanceName = maillist.getString("AssetInstanceName");
									String assetType = maillist.getString("Assetname");
									JSONArray emailArray = maillist.getJSONArray("Email Id");
									if(oldValue.equalsIgnoreCase("")){
										for(int j=0;j<emailArray.length();j++){
											SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
													MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
													MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}else{
										for(int j=0;j<emailArray.length();j++){
											SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
													MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
													MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}
								}
							}
						}
					}
				}
			}
			
			if(relatedParamChangeNotification != null){
				JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

				if(jsonObject.has("Response Status")){
					String status = jsonObject.getString("Response Status");
					if(status.equalsIgnoreCase("success")){
						if(jsonObject.has("Notification")){
							String notification = jsonObject.getString("Notification");
							notification = notification.substring(notification.indexOf("[")+1, notification.lastIndexOf("]"));
							if(!notification.equalsIgnoreCase("\"\"")){
								JSONObject maillist = new JSONObject(notification);
								if(maillist.has("Parameter changed")){
									String oldValue = maillist.getString("Old Value");
									List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
									String newValue = 	maillist.getString("New Value");
									List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
									String instanceName = maillist.getString("AssetInstanceName");
									String assetType = maillist.getString("Assetname");
									JSONArray emailArray = maillist.getJSONArray("Email Id");
									if(oldValue.equalsIgnoreCase("")){
										for(int j=0;j<emailArray.length();j++){
											SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
													MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
													MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}else{
										for(int j=0;j<emailArray.length();j++){
											SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
													MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
													MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}
								}
							}
						}
					}
				}
			}
			
			
			assetInstanceList.add(assetInstance);
			
			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_DATA_INSERTED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			
		}catch (RepoproException e) {
			log.error("createChildAssetInstance: SQL Exception createChildAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}catch (Exception e) {
			log.error("createChildAssetInstance: SQL Exception createChildAssetInstance: "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}finally {
			if (log.isTraceEnabled()) {
				log.trace("createChildAssetInstance : "+ Constants.LOG_CONNECTION_CLOSE);
			}
			if(conn != null){
				DBConnection.closeDbConnection(conn);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("createChildAssetInstance || exit");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,new ArrayList<Object>(assetInstanceList))).build();
	}
	
	@GET
	@Encoded
	@Path("/getAivBasicDetails")
	public Response getAivBasicDetails(@QueryParam("assetInstanceName") String assetInstName,@QueryParam("userName") String userName,
			@QueryParam("assetInstVersionId") long assetInstVersionId){

		if (log.isTraceEnabled()) {
			log.trace("getAivBasicDetails || begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetRelationshipDef> ardForDestAsset = new ArrayList<AssetRelationshipDef>();
		AssetRelationshipDef relationship = new AssetRelationshipDef();
		Connection conn = null;
		AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
		RatingManager ratingManager = new RatingManager();
		AssetInstanceVersionRating  aivfinal = new AssetInstanceVersionRating();
		GlobalSettingManager globalSettingManger = new GlobalSettingManager();
		List<AssetInstanceVersionRating> assetInstVerDetailsListFinal = new ArrayList<AssetInstanceVersionRating>();
		try {
			
			AssetInstanceVersion assetInstanceVersion = null;
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			String assetInst = URLDecoder.decode(assetInstName, "UTF-8");
			assetInstanceVersion = assetInstanceVersionDao.getAssetInstanceVersionDetailsInAivpage(assetInstVersionId,assetInst,null);
			
			if(assetInstanceVersion == null){
				 retStat = Status.OK;
				 retMsg = Constants.ASSET_INSTANCE_NOT_FOUND;
				 retScsFlr = Constants.SUCCESS;
				 retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				 
				 return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
									new ArrayList<Object>(assetInstVerDetailsListFinal))).build();
			}
			
			//getAssetInstanceAccessForGuestAndLoginUser
			 Boolean publicAccessFlag = false;
			Response res = this.getAssetInstanceAccessForGuestAndLoginUser(userName, assetInstVersionId);
			 MyModel model = (MyModel) res.getEntity();
			 List<Object> data = model.getResult();
			  for (int i = 0; i < data.size(); i++) {
				  AssetInstance assetInstance = new AssetInstance();
				  assetInstance = (AssetInstance) data.get(i);
				  publicAccessFlag = assetInstance.isPublicAccess();  
			   }
			 
			 if(publicAccessFlag){
			
			//getDestAssetAcessAndUserCountAndVersionDetails
			ardForDestAsset = relationshipDao
					.retAssetRelationshipDefByDestAssetId(assetInstanceVersion.getAssetId(), conn);
			boolean destAccess = false;

			if (ardForDestAsset.isEmpty()){
				/*relationship.setAssetRelId(0L);
				relationship.setSrcAssetId(0L);
				relationship.setDestAssetId(0L);
				relationship.setFwdRelId(0L);
				relationship.setBwdRelId(0L);
				ardForDestAsset.add(relationship);*/
				destAccess = false;
			}else{
				for(AssetRelationshipDef ad : ardForDestAsset ){
					if(ad.getFwdRelId() == 1 || ad.getFwdRelId() == 5){
						destAccess = true;
						break;
					}
				}
			}
			
			//retAivAccessRights
			Response userAccessRightsRes = aivManager.retAivAccessRights(assetInstVersionId, userName);
			MyModel userAccessRightsModel = (MyModel) userAccessRightsRes.getEntity();
		    List<Object> userAccessRightsData = userAccessRightsModel.getResult();
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
		   
		   for (int i = 0; i < userAccessRightsData.size(); i++) {
			   GroupAssetInstVersionAccess groupAssetInstVersionAccess = new GroupAssetInstVersionAccess();
			   groupAssetInstVersionAccess = (GroupAssetInstVersionAccess) userAccessRightsData.get(i);
			   groupAssetInstVersionAccessList.add(groupAssetInstVersionAccess);
		   }
			aivfinal.setUserAccessRights(groupAssetInstVersionAccessList);
			
			// getAssetInstanceVersionsAndDetails
			Response aivDetailsres = aivManager.getAssetInstanceVersionsAndDeatis(assetInstVersionId, assetInstName, userName);
			 MyModel aivDetailModel = (MyModel) aivDetailsres.getEntity();
		      List<Object> aivDetailData = aivDetailModel.getResult();
		      List<AssetInstanceVersion> aivdeList = new ArrayList<AssetInstanceVersion>();
		   
		   for (int i = 0; i < aivDetailData.size(); i++) {
			   AssetInstanceVersion aiv = new AssetInstanceVersion();
			   aiv = (AssetInstanceVersion) aivDetailData.get(i);
			   aivdeList.add(aiv);
		   }
			aivfinal.setAivDetailsList(aivdeList);
			
			
			//getSiblingsOfChildAssetInstance
			Response siblingOfChildInstRes = aivManager.getSiblingsOfChildAssetInstance(assetInstanceVersion.getAssetName(), assetInstName, assetInstanceVersion.getVersionName());
			
			   MyModel siblingOfChildInstModel = (MyModel) siblingOfChildInstRes.getEntity();
			      List<Object> siblingOfChildInstData = siblingOfChildInstModel.getResult();
			      List<AssetInstanceVersion> siblingOfChildInstList = new ArrayList<AssetInstanceVersion>();
			   
			   for (int i = 0; i < siblingOfChildInstData.size(); i++) {
				   AssetInstanceVersion siblingOfChildInst = new AssetInstanceVersion();
				   siblingOfChildInst = (AssetInstanceVersion) siblingOfChildInstData.get(i);
				   siblingOfChildInstList.add(siblingOfChildInst);
			   }
			   aivfinal.setSiblingsOfChildAssetInstance(siblingOfChildInstList);
			
			
			//getChildNamesForAssetInstance
			Response ChildNamesForAssetInstRes = aivManager.getChildNamesForAssetInstance(assetInstanceVersion.getAssetId(), assetInstVersionId);
			
			   MyModel  ChildNamesForAssetInstModel = (MyModel) ChildNamesForAssetInstRes.getEntity();
			      List<Object> ChildNamesForAssetInstData = ChildNamesForAssetInstModel.getResult();
			      List<AssetInstanceVersion> ChildNamesForAssetInstList = new ArrayList<AssetInstanceVersion>();
			   
			   for (int i = 0; i < ChildNamesForAssetInstData.size(); i++) {
				   AssetInstanceVersion ChildNamesForAssetInst = new AssetInstanceVersion();
				   ChildNamesForAssetInst = (AssetInstanceVersion) ChildNamesForAssetInstData.get(i);
				   ChildNamesForAssetInstList.add(ChildNamesForAssetInst);
			   }
				aivfinal.setChildInstanceNameList(ChildNamesForAssetInstList);
			
			
			
			// getuserscount
			Response userCountRes = ratingManager.getUsersCount(assetInstVersionId);
			   MyModel userCountModel = (MyModel) userCountRes.getEntity();
			      List<Object> userCountData = userCountModel.getResult();
			      List<AssetInstanceVersionRating> aivRatingList = new ArrayList<AssetInstanceVersionRating>();
			   
			   for (int i = 0; i < userCountData.size(); i++) {
				   AssetInstanceVersionRating aivRating = new AssetInstanceVersionRating();
				   aivRating = (AssetInstanceVersionRating) userCountData.get(i);
				   aivRatingList.add(aivRating);
			   }
				aivfinal.setAivRatingList(aivRatingList);
			
				
			//globalSetting
				Response globalSettingRes = globalSettingManger.getGlobalSettings();
				 MyModel globalSettingModel = (MyModel) globalSettingRes.getEntity();
				 List<Object> globalSettingData = globalSettingModel.getResult();
				  List<GlobalSetting> globalSettinglist = new ArrayList<GlobalSetting>();
				  for (int i = 0; i < globalSettingData.size(); i++) {
					  GlobalSetting globalSetting = new GlobalSetting();
					  globalSetting = (GlobalSetting) globalSettingData.get(i);
					  globalSettinglist.add(globalSetting);
				   }
					aivfinal.setGlobalSetting(globalSettinglist);
				
			//retAssetInstanceVersion (lock/unlock)
			Response lockUnlockRes = aivManager.retAssetInstanceVersion(assetInstVersionId, userName);
			 MyModel lockUnlockModel = (MyModel) lockUnlockRes.getEntity();
		      List<Object> lockUnlockModelData = lockUnlockModel.getResult();
		      List<AssetInstanceVersion> aivlockList = new ArrayList<AssetInstanceVersion>();
		   
		   for (int i = 0; i < lockUnlockModelData.size(); i++) {
			   AssetInstanceVersion aiv = new AssetInstanceVersion();
			   aiv = (AssetInstanceVersion) lockUnlockModelData.get(i);
			   aivlockList.add(aiv);
		   }
			aivfinal.setLockUnlockStatus(aivlockList);
			
			
			//getCustomizedSectionData
			Response customizedRes = aivManager.getCustomizedSectionDataForAIV(userName);
			 MyModel customizedModel = (MyModel) customizedRes.getEntity();
		      List<Object> customizedData = customizedModel.getResult();
		      List<User> customizedList = new ArrayList<User>();
				
		   
		   for (int i = 0; i < customizedData.size(); i++) {
			   User user = new User();
			   user = (User) customizedData.get(i);
			   customizedList.add(user);
		   }
			aivfinal.setCustomizedSectionData(customizedList);
			
			
			aivfinal.setDestAccessFlag(destAccess);
			assetInstVerDetailsListFinal.add(aivfinal);

			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_VERSION_DETAILS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			 }else{
				 retStat = Status.OK;
				 retMsg = Constants.ASSET_INSTANCE_ACCESS_DEINED;
				 retScsFlr = Constants.SUCCESS;
				 retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			 }
			
		} catch (RepoproException e) {
			log.error("getAivBasicDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAivBasicDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAivBasicDetails || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAivBasicDetails || End ");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetInstVerDetailsListFinal))).build();

	}
	/**
	 * @method aiv details
	 * @param assetName
	 * @param assetInstName
	 * @param userName
	 * @param assetInstVersionId
	 * @param versionName
	 * @return success response
	 */
	@GET
	@Path("/getAivDetails")
	public Response getAivDetails(@QueryParam("assetName") String assetName,
			@QueryParam("assetInstName") String assetInstName,
			@QueryParam("userName") String userName,
			@QueryParam("assetInstVersionId") long assetInstVersionId,
			@QueryParam("versionName") String versionName){

		if (log.isTraceEnabled()) {
			log.trace("getAivDetails ||assetName:"+assetName+" assetInstName:"+assetInstName+" userName:"+userName+" assetInstVersionId:"+assetInstVersionId+" versionName:"+versionName+"||begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
		TaggingManager tag = new TaggingManager();
		RelationshipManager rel = new RelationshipManager();
		List<AivDetailsComposite> aivlist = new ArrayList<AivDetailsComposite>();

		try {
			
			AssetDao asset = new AssetDao();
			AssetDef assetDef = asset.getAssetsByAssetName(assetName, null);
			
			AssetInstance assetInstance = new AssetInstance();
			AssetInstanceVersionDao assetInstVersionDao = new AssetInstanceVersionDao();
			assetInstance.setAssetName(assetName);
			assetInstance.setAssetInstName(assetInstName);
			assetInstance.setVersionName(versionName);
			if (log.isTraceEnabled()) {
				log.trace("getAivDetails ||call of getAssetInstanceVersion method to get instance details");
			}
			AssetInstanceVersion assetInstanceVer = assetInstVersionDao.getAssetInstanceVersion(assetInstance, null);
			
			AivDetailsComposite aiv = new AivDetailsComposite();
			

			/*Description*/
			if (log.isTraceEnabled()) {
				log.trace("getAivDetails ||call of getAssetInstanceVersionDetails method to get instance description");
			}
			Response descreponse = aivManager.getAssetInstanceVersionDetails(assetInstVersionId,assetInstName);
	    	MyModel descres = (MyModel) descreponse.getEntity();
	    	List<Object> data = descres.getResult();
	    	List<AssetInstanceVersion> overviewlist = new ArrayList<AssetInstanceVersion>();
			
			for (int i = 0; i < data.size(); i++) {
				AssetInstanceVersion overview = new AssetInstanceVersion();
				overview = (AssetInstanceVersion) data.get(i);
				overviewlist.add(overview);
			}
			aiv.setOverview(overviewlist);
			
			/*TaggingMaster*/
			if (log.isTraceEnabled()) {
				log.trace("getAivDetails ||call of getAllTags method to get instance tag details");
			}
			Response tagreponse = tag.getAllTags(assetInstVersionId);
			MyModel tegres = (MyModel) tagreponse.getEntity();
	    	List<Object> tagdata = tegres.getResult();
	    	List<TaggingMaster> taglist = new ArrayList<TaggingMaster>();
			
			for (int i = 0; i < tagdata.size(); i++) {
				TaggingMaster tagData = new TaggingMaster();
				tagData = (TaggingMaster) tagdata.get(i);
				taglist.add(tagData);
			}
			aiv.setTags(taglist);
			
			
			/*AssetInstanceVersionTaxonomy*/
			if (log.isTraceEnabled()) {
				log.trace("getAivDetails ||call of retTaxonomyIdByAssetInstVersionId method to get instance taxonomy details");
			}
			Response taxreponse = aivManager.retTaxonomyIdByAssetInstVersionId(assetInstVersionId);
			MyModel taxres = (MyModel) taxreponse.getEntity();
	    	List<Object> taxdata = taxres.getResult();
	    	List<AssetInstanceVersionTaxonomy> taxlist = new ArrayList<AssetInstanceVersionTaxonomy>();
			
			for (int i = 0; i < taxdata.size(); i++) {
				AssetInstanceVersionTaxonomy taxData = new AssetInstanceVersionTaxonomy();
				taxData = (AssetInstanceVersionTaxonomy) taxdata.get(i);
				taxlist.add(taxData);
			}
			aiv.setTaxonomy(taxlist);
			
			
			/*properties*/
			if (log.isTraceEnabled()) {
				log.trace("getAivDetails ||call of getAssetInstancePropertiesDetails method to get instance property details");
			}
			Response propreponse = aivManager.getAssetInstancePropertiesDetails(userName, assetName, assetInstVersionId);
			MyModel propres = (MyModel) propreponse.getEntity();
	    	List<Object> propdata = propres.getResult();
	    	List<AssetInstanceVersion> proplist = new ArrayList<AssetInstanceVersion>();
			
			for (int i = 0; i < propdata.size(); i++) {
				AssetInstanceVersion propData = new AssetInstanceVersion();
				propData = (AssetInstanceVersion) propdata.get(i);
				proplist.add(propData);
			}
			aiv.setProperties(proplist);
			
			/*AssetRelationshipDef*/
			if (log.isTraceEnabled()) {
				log.trace("getAivDetails ||call of getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId method to get instance relationship details");
			}
			Response relreponse = rel.getAllRelationshipNamesAndRelationShipIdByAssetInstVersionId(assetInstVersionId);
			MyModel relres = (MyModel) relreponse.getEntity();
	    	List<Object> reldata = relres.getResult();
	    	List<AssetRelationshipDef> rellist = new ArrayList<AssetRelationshipDef>();
			
			for (int i = 0; i < reldata.size(); i++) {
				AssetRelationshipDef relData = new AssetRelationshipDef();
				relData = (AssetRelationshipDef) reldata.get(i);
				rellist.add(relData);
			}
			aiv.setRelationships(rellist);
			
			/*load relationship*/
			if(aiv.getRelationships()!= null){
				List<String> reltionshipId = new ArrayList<String>();
				for(int i =0;i<aiv.getRelationships().size();i++){
					reltionshipId.add(aiv.getRelationships().get(i).getDescription()+"-"+aiv.getRelationships().get(i).getAssetRelId());
				}
				String relId = "";
				relId = String.join("!", reltionshipId);
				if (log.isTraceEnabled()) {
					log.trace("getAivDetails ||call of filterDependencyTreeActionOnLoad method to get instance on loadrelationship details");
				}
				Response relloadreponse = rel.filterDependencyTreeActionOnLoad(assetName, assetInstVersionId, relId.toString());
				MyModel relloadres = (MyModel) relloadreponse.getEntity();
				List<Object> relloaddata = relloadres.getResult();
				List<String> relloadlist = new ArrayList<String>();

				for (int i = 0; i < relloaddata.size(); i++) {
					String relloadData = new String();
					relloadData = (String) relloaddata.get(i);
					relloadlist.add(relloadData);
				}
				aiv.setOnloadrelationships(relloadlist);
			}
			
			/*version details*/
			if (log.isTraceEnabled()) {
				log.trace("getAivDetails ||call of getAssetInstanceVersions method to get instance on version details");
			}
			Response versionresponse = aivManager.getAssetInstanceVersions(assetInstanceVer.getAssetInstanceId(), userName);
			MyModel versionres = (MyModel) versionresponse.getEntity();
	    	List<Object> versiondata = versionres.getResult();
	    	List<AssetInstanceVersion> versionlist = new ArrayList<AssetInstanceVersion>();
			
			for (int i = 0; i < versiondata.size(); i++) {
				AssetInstanceVersion versionData = new AssetInstanceVersion();
				versionData = (AssetInstanceVersion) versiondata.get(i);
				versionlist.add(versionData);
			}
			aiv.setVersionDetails(versionlist);
			
			
			/*reverse relationship*/
			if (log.isTraceEnabled()) {
				log.trace("getAivDetails ||call of getAllReverseRelationships method to get instance reverse relationship details");
			}
			Response revrelresponse = rel.getAllReverseRelationships(assetInstVersionId);
			MyModel revrelres = (MyModel) revrelresponse.getEntity();
	    	List<Object> revreldata = revrelres.getResult();
	    	List<AssetInstanceVersion> revrellist = new ArrayList<AssetInstanceVersion>();
			
			for (int i = 0; i < revreldata.size(); i++) {
				AssetInstanceVersion revrelData = new AssetInstanceVersion();
				revrelData = (AssetInstanceVersion) revreldata.get(i);
				revrellist.add(revrelData);
			}
			aiv.setReverseRelationship(revrellist);
			
			aivlist.add(aiv);

			///*AivRevisionHistory*/Response revHisreponse = rev.retAllRevisionHistory(assetName, assetInstVersionId);
			
			///*DiscussionComment*/Response dissComreponse = disc.listAllComments(assetInstVersionId);
			
			///*User*/Response customreponse = aivManager.getCustomizedSectionDataForAIV(userName);
			
			retStat = Status.OK;
			retMsg = Constants.ASSET_INSTANCE_VERSION_DATA_RETRIVED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} catch (RepoproException e) {
			log.error("getAivDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAivDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAivDetails || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("getAivDetails ||assetName:"+assetName+" assetInstName:"+assetInstName+" userName:"+userName+" assetInstVersionId:"+assetInstVersionId+" versionName:"+versionName+"||end");

		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(aivlist))).build();

	}
	
}
