package com.thbs.repopro.assetinstance;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.ShowHideColumn;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class ShowHideDao {
	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method getShowHideForAssociateGroupcolumn
	 * @description to get value of AssociateGroupcolumn
	 * @param showHideColumn
	 * @param conn
	 * @return showHideColumn
	 * @throws RepoproException
	 */
	public ShowHideColumn getShowHideForAssociateGroupcolumn(
			ShowHideColumn showHideColumn, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getShowHideForAssociateGroupcolumn ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "||begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		Map<Long, String> groupValues = new TreeMap<Long, String>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getShowHideForAssociateGroupcolumn || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedSt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_SHOW_HIDE_DATA_FOR_ASSOCIATE_GROUP));
			if (log.isTraceEnabled()) {
				log.trace("getShowHideForAssociateGroupcolumn || "
						+ PropertyFileReader.getInstance().getValue(Constants.GET_ALL_SHOW_HIDE_DATA_FOR_ASSOCIATE_GROUP));
			}
			preparedSt.setLong(Constants.ONE, showHideColumn.getAssetId());
			preparedSt.setLong(Constants.TWO, showHideColumn.getUserId());

			rs = preparedSt.executeQuery();

			if (rs.next()) {
				groupValues.put(rs.getLong("asset_id"), rs.getString("value"));
			}
			showHideColumn.setShowGroupDetails(groupValues);

			if (log.isTraceEnabled()) {
				log.trace("getShowHideForAssociateGroupcolumn || "+ showHideColumn.toString());
			}
		} catch (SQLException e) {
			log.error("getShowHideForAssociateGroupcolumn ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.GET_SHOWHIDE_FOR_ASSOCIATE_GROUPCOLUMN_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getShowHideForAssociateGroupcolumn ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getShowHideForAssociateGroupcolumn ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getShowHideForAssociateGroupcolumn ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getShowHideForAssociateGroupcolumn ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getShowHideForAssociateGroupcolumn ||userId:"
					+ showHideColumn.getUserId() + "assetId:"+ showHideColumn.getAssetId() + "||exit");
		}

		return showHideColumn;
	}

	/**
	 * @method getShowHideForAivIdColumn
	 * @description to get value of AivIdColumn
	 * @param showHideColumn
	 * @param conn
	 * @return showHideColumn
	 * @throws RepoproException
	 */
	public ShowHideColumn getShowHideForAivIdColumn(
			ShowHideColumn showHideColumn, Connection conn)
					throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getShowHideForAivIdColumn ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "||begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		Map<Long, String> aivValues = new TreeMap<Long, String>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getShowHideForAivIdColumn || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedSt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_SHOW_HIDE_DATA_FOR_AIV_ID));
			if (log.isTraceEnabled()) {
				log.trace("getShowHideForAivIdColumn || "
						+ PropertyFileReader.getInstance().getValue(Constants.GET_ALL_SHOW_HIDE_DATA_FOR_AIV_ID));
			}
			preparedSt.setLong(Constants.ONE, showHideColumn.getAssetId());
			preparedSt.setLong(Constants.TWO, showHideColumn.getUserId());

			rs = preparedSt.executeQuery();

			if (rs.next()) {
				aivValues.put(rs.getLong("asset_id"), rs.getString("value"));
			}
			showHideColumn.setShowAivDetails(aivValues);

			if (log.isTraceEnabled()) {
				log.trace("getShowHideForAivIdColumn || "+ showHideColumn.toString());
			}
		} catch (SQLException e) {
			log.error("getShowHideForAivIdColumn ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_SHOWHIDE_FOR_AIVID_COLUMN_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getShowHideForAivIdColumn ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getShowHideForAivIdColumn ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getShowHideForAivIdColumn ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getShowHideForAivIdColumn ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getShowHideForAivIdColumn ||userId:"
					+ showHideColumn.getUserId() + "assetId:"+ showHideColumn.getAssetId() + "||exit");
		}

		return showHideColumn;
	}

	/**
	 * @method getShowHideParams
	 * @description to get saved parameters list
	 * @param showHideColumn
	 * @param conn
	 * @return showHideColumn
	 * @throws RepoproException
	 */
	public ShowHideColumn getShowHideParamsForShowHide(ShowHideColumn showHideColumn,String userName,
			Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getShowHideParamsForShowHide ||userId:"
					+ showHideColumn.getUserId() +" assetId:"+ showHideColumn.getAssetId() + "||begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		Map<Long, String> paramValues = new LinkedHashMap<Long, String>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getShowHideParams || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedSt = conn.prepareStatement(
					PropertyFileReader.getInstance().getValue(Constants.GET_ALL_SHOW_HIDE_PARAM_VALUES));
			if (log.isTraceEnabled()) {
				log.trace("getShowHideParams || "
						+ PropertyFileReader.getInstance().getValue(Constants.GET_ALL_SHOW_HIDE_PARAM_VALUES));
			}
			preparedSt.setLong(Constants.ONE, showHideColumn.getAssetId());
			preparedSt.setLong(Constants.TWO, showHideColumn.getUserId());

			rs = preparedSt.executeQuery();
			while(rs.next()){
				paramValues.put(rs.getLong("paramId"),
						rs.getString("paramName"));
			}
			showHideColumn.setShowParamDetails(paramValues);
			if (log.isTraceEnabled()) {
				log.trace("getShowHideParamsForShowHide || " + showHideColumn.toString());
			}
		} catch (SQLException e) {
			log.error("getShowHideParamsForShowHide ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.GET_SHOWHIDE_COLUMN_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getShowHideParamsForShowHide ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getShowHideParamsForShowHide ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getShowHideParamsForShowHide ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getShowHideParamsForShowHide ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getShowHideParamsForShowHide ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "||exit");
		}

		return showHideColumn;
	}
	/**
	 * 
	 * @param showHideColumn
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public ShowHideColumn getShowHideDefaultParams(ShowHideColumn showHideColumn,String userName,
			Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getShowHideDefaultParams ||userId:"
					+ showHideColumn.getUserId() +" assetId:"+ showHideColumn.getAssetId() + "||begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		Map<Long, String> paramValues = new LinkedHashMap<Long, String>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getShowHideDefaultParams || "
						+ Constants.LOG_CONNECTION_OPEN);
			}


			preparedSt = conn.prepareStatement(
					PropertyFileReader.getInstance().getValue(Constants.GET_ALL_SHOW_HIDE_PARAM_VALUES_FOR_DEFAULT));
			if (log.isTraceEnabled()) {
				log.trace("getShowHideDefaultParams || "
						+ PropertyFileReader.getInstance().getValue(Constants.GET_ALL_SHOW_HIDE_PARAM_VALUES_FOR_DEFAULT));
			}
			preparedSt.setLong(Constants.ONE, showHideColumn.getAssetId());
			rs = preparedSt.executeQuery();

			while (rs.next()) {

				paramValues.put(rs.getLong("asset_param_id"),
						rs.getString("asset_param_name"));
			}
			showHideColumn.setShowParamDetails(paramValues);
			if (log.isTraceEnabled()) {
				log.trace("getShowHideDefaultParams || " + showHideColumn.toString());
			}
		} catch (SQLException e) {
			log.error("getShowHideDefaultParams ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.GET_SHOWHIDE_COLUMN_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getShowHideDefaultParams ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getShowHideDefaultParams ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getShowHideDefaultParams ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getShowHideDefaultParams ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getShowHideDefaultParams ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "||exit");
		}

		return showHideColumn;
	}
	/**
	 * @method getShowHideParamsDetails
	 * @description to get all parameters list
	 * @param showHideColumn
	 * @param conn
	 * @return showHideColumn
	 * @throws RepoproException
	 */
	public ShowHideColumn getShowHideParamsDetails(String userName,
			Long assetId, Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getShowHideParamsDetails ||userName:" + userName
					+ " assetId:" + assetId + " || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		Map<Long, String> paramValues = new TreeMap<Long, String>();
		ShowHideColumn showHideColumn = new ShowHideColumn();

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getShowHideParamsDetails || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (userName.equalsIgnoreCase("admin")) {
				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_FOR_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getShowHideParamsDetails || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ALL_PARAM_DETAILS_FOR_ADMIN));
				}
				preparedStmt.setLong(Constants.ONE, assetId);
				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					paramValues.put(resultSet.getLong("asset_param_id"),
							resultSet.getString("asset_param_name"));

				}

			} else if(userName.equalsIgnoreCase("roleAnonymous")){

				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getShowHideParamsDetails || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ALL_PARAM_DETAILS_FOR_ADMIN));
				}
				preparedStmt.setLong(Constants.ONE, assetId);
				preparedStmt.setString(Constants.TWO, "Guest");
				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					paramValues.put(resultSet.getLong("asset_param_id"),
							resultSet.getString("asset_param_name"));

				}

			}else {
				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getShowHideParamsDetails || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN));
				}
				preparedStmt.setLong(Constants.ONE, assetId);
				preparedStmt.setString(Constants.TWO, userName);
				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					paramValues.put(resultSet.getLong("asset_param_id"),
							resultSet.getString("asset_param_name"));
				}
			}
			showHideColumn.setShowParamDetails(paramValues);
			if (log.isTraceEnabled()) {
				log.trace("getShowHideParamsDetails || "
						+ showHideColumn.toString());
			}
		} catch (SQLException e) {
			log.error("getShowHideParamsDetails ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.GET_SHOWHIDE_COLUMN_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getShowHideParamsDetails ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getShowHideParamsDetails ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getShowHideParamsDetails ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getShowHideParamsDetails ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getShowHideParamsDetails ||userName:" + userName
					+ " assetId:" + assetId + " ||exit");
		}
		return showHideColumn;
	}

	/**
	 * @method addShowHideForAssociateGroupcolumn
	 * @description to save value of AssociateGroupcolumn
	 * @param showHideColumn
	 * @param conn
	 * @return showHideColumn
	 * @throws RepoproException
	 */
	public ShowHideColumn addShowHideForAssociateGroupcolumn(
			ShowHideColumn showHideColumn, Connection conn)
					throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addShowHideForAssociateGroupcolumn ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "value:"
					+ showHideColumn.getShowGroupDetails().values() + "||begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		PreparedStatement preparedStmt = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAssociateGroupcolumn || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedSt = conn
					.prepareStatement(PropertyFileReader
							.getInstance()
							.getValue(
									Constants.DELETE_ALL_SHOW_HIDE_DATA_FOR_ASSOCIATE_GROUP_BY_ASSETID_AND_USERID));
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAssociateGroupcolumn || "
						+ PropertyFileReader
						.getInstance()
						.getValue(Constants.DELETE_ALL_SHOW_HIDE_DATA_FOR_ASSOCIATE_GROUP_BY_ASSETID_AND_USERID));
			}
			preparedSt.setLong(Constants.ONE, showHideColumn.getUserId());
			preparedSt.setLong(Constants.TWO, showHideColumn.getAssetId());

			int v = preparedSt.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAssociateGroupcolumn ||" + v
						+ "rows deleted successfully");
			}
			if(!showHideColumn.getShowGroupDetails().isEmpty()){

				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.ADD_SHOWHIDE_FOR_ASSOCIATE_GROUP_COLUMN));

				if (log.isTraceEnabled()) {
					log.trace("addShowHideForAssociateGroupcolumn || "
							+ PropertyFileReader
							.getInstance().getValue(Constants.ADD_SHOWHIDE_FOR_ASSOCIATE_GROUP_COLUMN));
				}
				preparedStmt.setLong(Constants.ONE, showHideColumn.getUserId());
				preparedStmt.setLong(Constants.TWO, showHideColumn.getAssetId());
				for (String groupValue : showHideColumn.getShowGroupDetails().values()) {

					preparedStmt.setString(Constants.THREE, groupValue);

				}

				preparedStmt.execute();
			}
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAssociateGroupcolumn ||"
						+ showHideColumn.getShowGroupDetails().size()+ " rows added successfully");
			}
		} catch (SQLException e) {
			log.error("addShowHideForAssociateGroupcolumn ||"
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.ADD_SHOWHIDE_FOR_ASSOCIATE_GROUPCOLUMN_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addShowHideForAssociateGroupcolumn ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addShowHideForAssociateGroupcolumn ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addShowHideForAssociateGroupcolumn ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAssociateGroupcolumn ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("addShowHideForAssociateGroupcolumn ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "value:"
					+ showHideColumn.getShowGroupDetails().values() + "||exit");
		}

		return showHideColumn;
	}

	/**
	 * @method addShowHideForAivIdColumn
	 * @description to save value of AivIdColumn
	 * @param showHideColumn
	 * @param conn
	 * @return showHideColumn
	 * @throws RepoproException
	 */
	public ShowHideColumn addShowHideForAivIdColumn(
			ShowHideColumn showHideColumn, Connection conn)
					throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addShowHideForAivIdColumn ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "||begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		PreparedStatement preparedStmt = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAivIdColumn || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedSt = conn
					.prepareStatement(PropertyFileReader
							.getInstance()
							.getValue(
									Constants.DELETE_ALL_SHOW_HIDE_DATA_FOR_AIVID_BY_ASSETID_AND_USERID));
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAivIdColumn || "
						+ PropertyFileReader
						.getInstance()
						.getValue(
								Constants.DELETE_ALL_SHOW_HIDE_DATA_FOR_AIVID_BY_ASSETID_AND_USERID));
			}
			preparedSt.setLong(Constants.ONE, showHideColumn.getUserId());
			preparedSt.setLong(Constants.TWO, showHideColumn.getAssetId());

			int v = preparedSt.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAivIdColumn || " + v
						+ "rows deleted successfully");
			}
			if(!showHideColumn.getShowAivDetails().isEmpty()){
				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.ADD_SHOWHIDE_FOR_AIVID_COLUMN));
				if (log.isTraceEnabled()) {
					log.trace("addShowHideForAivIdColumn || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.ADD_SHOWHIDE_FOR_AIVID_COLUMN));
				}
				preparedStmt.setLong(Constants.ONE, showHideColumn.getUserId());
				preparedStmt.setLong(Constants.TWO, showHideColumn.getAssetId());

				for (String aivValue : showHideColumn.getShowAivDetails().values()) {
					preparedStmt.setString(Constants.THREE, aivValue);
				}


				preparedStmt.execute();
			}
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAivIdColumn || "
						+ showHideColumn.getShowAivDetails().size()
						+ "rows added successfully");
			}
		} catch (SQLException e) {
			log.error("addShowHideForAivIdColumn ||"
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.ADD_SHOWHIDE_FOR_AIVID_COLUMN_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addShowHideForAivIdColumn ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addShowHideForAivIdColumn ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addShowHideForAivIdColumn ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("addShowHideForAivIdColumn ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("addShowHideForAivIdColumn ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "||exit");
		}

		return showHideColumn;
	}

	/**
	 * @method addShowHideParams
	 * @description to save parameters
	 * @param showHideColumn
	 * @param conn
	 * @return showHideColumn
	 * @throws RepoproException
	 */
	public ShowHideColumn addShowHideParams(ShowHideColumn showHideColumn,
			Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("addShowHideParams ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "||begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		PreparedStatement preparedStmt = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("addShowHideParams || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedSt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_ALL_SHOW_HIDE_PARAM_VALUES));
			if (log.isTraceEnabled()) {
				log.trace("addShowHideParams || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_ALL_SHOW_HIDE_PARAM_VALUES));
			}
			preparedSt.setLong(Constants.ONE, showHideColumn.getUserId());
			preparedSt.setLong(Constants.TWO, showHideColumn.getAssetId());

			int v = preparedSt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("addShowHideParams ||" + v + " rows deleted successfully");
			}
			if(!showHideColumn.getShowParamDetails().isEmpty()){
				preparedStmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.ADD_ALL_SHOW_HIDE_PARAM_VALUES));
				if (log.isTraceEnabled()) {
					log.trace("addShowHideParams ||"
							+ PropertyFileReader.getInstance().getValue(
									Constants.ADD_ALL_SHOW_HIDE_PARAM_VALUES));
				}

				for (Long paramId : showHideColumn.getShowParamDetails().keySet()) {

					preparedStmt.setLong(Constants.ONE, showHideColumn.getUserId());
					preparedStmt.setLong(Constants.TWO, showHideColumn.getAssetId());
					preparedStmt.setLong(Constants.THREE, paramId);
					preparedStmt.execute();

				}
			}
			if (log.isTraceEnabled()) {
				log.trace("addShowHideParams ||"
						+ showHideColumn.getShowParamDetails().size()
						+ " rows added successfully");
			}
		} catch (SQLException e) {
			log.error("addShowHideParams ||"
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.GET_SHOWHIDE_COLUMN_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addShowHideParams ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addShowHideParams ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addShowHideParams ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("addShowHideParams ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("addShowHideParams ||userId:"
					+ showHideColumn.getUserId() + "assetId:"
					+ showHideColumn.getAssetId() + "||exit");
		}

		return showHideColumn;
	}
	
	/**
	 * @method getAssetIdByAssetName
	 * @param assetName
	 * @param conn
	 * @return Long
	 * @throws RepoproException
	 */
	public Long getAssetIdByAssetName(String assetName, Connection conn) throws RepoproException {
	
		if (log.isTraceEnabled()) {
			log.trace("getAssetIdByAssetname || Begin with assetName : "+ assetName);
		}
		
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Long assetId = null;
		
		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetIdByAssetname ||" + Constants.LOG_CONNECTION_OPEN);
			}
			
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(
							Constants.GET_ASSET_ID_BY_ASSET_NAME));
			
			preparedStmt.setString(Constants.ONE, assetName);
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetIdByAssetname ||" + PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_ID_BY_ASSET_NAME));
			}
			
			rs = preparedStmt.executeQuery();
			
			while (rs.next()) {
				
				assetId = rs.getLong("asset_id");
				
			}
			
		}catch(SQLException e){
			
			e.printStackTrace();
			log.error("getAssetIdByAssetname ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_ASSET_ID_BY_ASSET_NAME_DATA_NOT_FOUND));
			
		}catch(IOException e){
			
			log.error("getAssetIdByAssetname ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		}catch(PropertyVetoException e){
			
			log.error("getAssetIdByAssetname ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			
		}catch(Exception e){
			
			log.error("getAssetIdByAssetname ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
			
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getAssetIdByAssetname || "+ Constants.LOG_CONNECTION_CLOSE);
			}
		}
		return assetId;
	}

}
