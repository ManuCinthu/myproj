package com.thbs.repopro.asset;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.jettison.json.JSONException;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.GroupDao;
import com.thbs.repopro.accesscontrol.GroupManager;
import com.thbs.repopro.accesscontrol.RoleDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.assetinstanceversion.FavouritesDao;
import com.thbs.repopro.dto.AivParamRule;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstVersionTaxonomy;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.AssetParamRule;
import com.thbs.repopro.dto.AssetRelationshipDef;
import com.thbs.repopro.dto.AssetRepresentation;
import com.thbs.repopro.dto.Category;
import com.thbs.repopro.dto.FilterData;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.GroupAssetAccess;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.LdapMapping;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.dto.ParameterData;
import com.thbs.repopro.dto.PossibleValues;
import com.thbs.repopro.dto.RecentActivity;
import com.thbs.repopro.dto.SavedSearch;
import com.thbs.repopro.dto.TaxonomyMaster;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserAssetSubscription;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.dto.Workflow;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.plugin.AssetRepresentationDao;
import com.thbs.repopro.recentactivity.RecentActivityDao;
import com.thbs.repopro.relationship.RelationshipDao;
import com.thbs.repopro.subscription.SubscriptionDao;
import com.thbs.repopro.taxonomies.TaxonomiesDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.InvertImage;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;
import com.thbs.repopro.workflow.WorkflowDao;


@Path("/assetType")
public class AssetManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");
	private	Map<Long, List<TaxonomyMaster>> allTaxs =  null;
	List<Long> associatedTaxId = new ArrayList<Long>();
	void recurse(TaxonomyMaster t)throws RepoproException{

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);
			allTaxs.put(t.getTaxonomyId(), chldrn);
			for(TaxonomyMaster i: chldrn)
				recurse(i);
		}
		catch (RepoproException e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("recurse || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

	}

	void  recurse1(TaxonomyMaster t) throws RepoproException{

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);
			TaxonomyMaster t1 = null;
			for(TaxonomyMaster a: chldrn){

				t1 = new TaxonomyMaster();
				t1.setTaxonomyId(a.getTaxonomyId());
				t1.setTaxonomyName(a.getTaxonomyName());
				recurse1(t1);
				associatedTaxId.add(a.getTaxonomyId());
				associatedTaxId.add(t.getTaxonomyId());

			}
			associatedTaxId.add(t.getTaxonomyId());

		}catch (RepoproException e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("recurse1 || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
	}
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getAssetIdByAssetName")
	public Response getAssetIdByAssetName(@QueryParam("assetName") String assetName) {
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<AssetDef> assetDefList = new ArrayList<AssetDef>();
		try {
			AssetDao assetDao = new AssetDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetIdByAssetName || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetIdByAssetName || dao method called : getAssetID(assetName)");
			}
			AssetDef assetDef = assetDao.getAssetID(assetName, conn);
			 assetDefList.add(assetDef);
			if (assetDefList.isEmpty()) {
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.ASSET_INSTANCE_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			
		} catch (RepoproException e) {
			log.error("getAssetIdByAssetName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetIdByAssetName || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetIdByAssetName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(assetDefList)))
				.build();
		
	}
	
	/**
	 * @method : getAllAssets
	 * @description : to get all the assets
	 * @return Response success message
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getAllAssetsForSubscription")
	public Response getAllAssetsForSubscription(@QueryParam("userId") Long userId) {

		log.trace("getAllAssetsForSubscription || Begin");

		Connection conn = null;

		UserAssetSubscription uas = null;

		List<AssetDef> assetList = new ArrayList<AssetDef>();
		List<UserAssetSubscription> subscriptionList = new ArrayList<UserAssetSubscription>();

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsForSubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetDao dao = new AssetDao();
			SubscriptionDao subDao = new SubscriptionDao();
			UserDao userDao = new UserDao();

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsForSubscription || dao method called : getUserByUserId()");
			}
			User userByUserId = userDao.getUserByUserId(userId, conn);

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsForSubscription || dao method called : getAllAssets()");
			}
			assetList = dao.getAllAssetsForSubscription(conn);

			for (AssetDef ad : assetList) {
				uas = subDao.getAllSubscriptionsByAsset(ad.getAssetId(),userId, conn);
				uas.setAssetId(ad.getAssetId());
				uas.setAssetName(ad.getAssetName());
				uas.setUserId(userId);
				uas.setNotifyFlag(userByUserId.isSubscribe());
				uas.setIconImageName(ad.getIconImageName());
				subscriptionList.add(uas);
			}

			log.debug(" getAllAssetsForSubscription || retrieved " + assetList.size()
					+ " assets successfully");


			retMsg = Constants.ALL_ASSETS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getAllAssetsForSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllAssetsForSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsForSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (assetList.isEmpty()) {
			retMsg = Constants.ASSETS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_ASSETS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		log.trace("getAllAssets || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(subscriptionList))).build();
	}


	/**
	 * @method : getAllAssets
	 * @description : to get all the assets
	 * @return Response success message
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getallassets")
	public Response getAllAssets() {
		log.trace("getAllAssets || Begin ");
		Connection conn = null;
		List<AssetDef> assetList = new ArrayList<AssetDef>();

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()){
				log.trace("getAllAssets || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetDao dao = new AssetDao();

			if (log.isTraceEnabled()) {
				log.trace("getAllAssets || dao method called : getAllAssets()");
			}
			assetList = dao.getAllAssets(conn);

			log.debug(" getAllAssets || retrieved "+ assetList.size() +" assets successfully");

			retMsg = Constants.ALL_ASSETS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch(RepoproException e){
			log.error("getAllAssets || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getAllAssets || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (assetList.isEmpty()) {
			retMsg = Constants.ASSETS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_ASSETS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		log.trace("getAllAssets || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(assetList))).build();
	}




	/**
	 * @method getFilterList
	 * @description get filter parameter values
	 * @param assetName
	 * @param paramName
	 * @param listName
	 * @param userName
	 * @return success response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getFilterList")
	public Response getFilterList(@QueryParam("assetName") String assetName,
			@QueryParam("paramName") String paramName,
			@QueryParam("listName") String listName,
			@QueryParam("userName") String userName,
			@QueryParam("MappedAssetId") Long MappedAssetId)  {

		log.trace("getFilterList || begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetDao assetDao = new AssetDao();
		List<AssetParamDef> filterList = new ArrayList<AssetParamDef>();
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getFilterList || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (log.isTraceEnabled()) {
				log.trace("getFilterList || dao method called : getFilterList()");
			}

			filterList = assetDao.getFilterList(assetName, paramName, listName,userName,MappedAssetId,conn);


			if (log.isInfoEnabled()) {
				log.info("getFilterList ||parameter values:"
						+ filterList.size() + " retrieved successfully");
			}

			retStat = Status.OK;
			retMsg = Constants.FILTERLIST_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getFilterList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getFilterList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getFilterList || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getFilterList ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(filterList))).build();

	}

	/**
	 * @method getParamList
	 * @description get parameters list
	 * @param assetId
	 * @param userName
	 * @return success response
	 * @
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getParamList")
	public Response getParamList(@QueryParam("assetId") Long assetId,
			@QueryParam("userName") String userName)  {

		log.trace("getParamList || begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetDao assetDao = new AssetDao();
		List<AssetParamDef> paramList = new ArrayList<AssetParamDef>();
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getParamList || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (log.isTraceEnabled()) {
				log.trace("getParamList || dao method called : getParamsDetails()");
			}

			paramList = assetDao.getParamsDetails(userName, assetId, conn);

			Collections.sort(paramList, new AssetParamDef());

			if (log.isDebugEnabled()) {
				log.debug("getParamList ||parameters list:" + paramList.size()
						+ " retrieved successfully");
			}
			retStat = Status.OK;
			retMsg = Constants.PARAMLIST_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getParamList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getParamList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getParamList || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getParamList ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(paramList))).build();

	}

	/**
	 * @method addFilterSearch
	 * @description to add filter search data
	 * @param savedSearch
	 * @return success response
	 */
	@POST
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/addFilterSearch")
	public Response addFilterSearch(SavedSearch savedSearch)
	{

		if (savedSearch == null) {
			log.warn("addFilterSearch || search data to be added is not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("addFilterSearch || " + savedSearch.toString()
						+ " Begin");
			}

			Connection conn = null;
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			AssetDao assetDao = new AssetDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			List<SavedSearch> getsearchlist = new ArrayList<SavedSearch>();
			List<SavedSearch> searchlist = new ArrayList<SavedSearch>();
			String jsonRslt;
			List<String> jsonList = new ArrayList<String>();
			boolean flag = false;
			try {
				if (log.isTraceEnabled()) {
					log.trace("addFilterSearch || "
							+ Constants.LOG_CONNECTION_OPEN);
				}

				savedSearch.setParam1Value(URLDecoder.decode(savedSearch.getParam1Value(),"UTF-8"));
				savedSearch.setParam2Value(URLDecoder.decode(savedSearch.getParam2Value(),"UTF-8"));
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				getsearchlist = assetDao.getFilterSearchList(savedSearch.getUserName(),conn);
				for (int i = 0; i < getsearchlist.size(); i++) {
					if (getsearchlist.get(i).getSearchName()
							.equalsIgnoreCase(savedSearch.getSearchName())) {
						flag = true;
					}
				}
				if (flag) {
					log.warn("addFilterSearch || filter search  by this name already exists, please provide different name");

					jsonRslt = Constants.FILTER_SEARCH_NAME_EXIST;
					jsonList.add(jsonRslt);

					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.FILTER_SEARCH_NAME_ALREADY_EXISTS),
									new ArrayList<Object>(jsonList))).build();

				} else {
					if (log.isTraceEnabled()) {
						log.trace("addFilterSearch ||dao call of retAssetDetail() method to get asset details");
					}
					AssetDef asset = assetInstanceDao.retAssetDetail(savedSearch.getAssetName(), conn);
					savedSearch.setAssetId(asset.getAssetId());
					if (log.isTraceEnabled()) {
						log.trace("addFilterSearch ||dao call of addFilterSearch() method");
					}
					savedSearch = assetDao.addFilterSearch(savedSearch, conn);
					searchlist.add(savedSearch);
				}

				retMsg = Constants.FILTER_SEARCH_CREATED;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				if (log.isDebugEnabled()) {
					log.debug(" addFilterSearch || " + savedSearch.toString()
							+ " added filter search data successfully");
				}
				conn.commit();

			} catch (RepoproException e) {
				log.error("addFilterSearch ||  " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			} catch (Exception e) {
				log.error("addFilterSearch ||  " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addFilterSearch || "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("addFilterSearch || " + savedSearch.toString()
						+ " End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(searchlist))).build();

		}

	}

	/**
	 * @method getFilterSearch
	 * @description get filter search data
	 * @param searchName
	 * @param userName
	 * @return success response
	 * @
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getFilterSearch")
	public Response getFilterSearch(@QueryParam("assetName") String assetName,
			@QueryParam("userName") String userName)  {
		if (log.isTraceEnabled()) {
			log.trace("getFilterSearch ||assetName:" + assetName + ",userName:"
					+ userName + "||Begin");
		}
		Connection conn = null;
		List<SavedSearch> searchList = new ArrayList<SavedSearch>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		AssetInstanceDao  assetInstanceDao = new AssetInstanceDao();
		AssetDef asset = new AssetDef();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearch || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearch || dao method called : retAssetDetail() to get asset details");
			}
			asset = assetInstanceDao.retAssetDetail(assetName, conn);
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearch || dao method called : getFilterSearch()");
			}
			searchList = dao.getFilterSearch(asset.getAssetId(), userName, conn);
			TaxonomyMaster tax = new TaxonomyMaster();
			List<String> finaltax = new ArrayList<String>();
			for(SavedSearch search:searchList){
				if(search.getTaxValue()!=null && search.getTaxValue().length()>0){
					String[]taxs = search.getTaxValue().split("~");
					for(String taxdata:taxs){
						String taxId = taxdata.substring( 0, taxdata.indexOf(":"));
						tax = taxonomyDao.getTaxonomiesByTaxId(Long.parseLong(taxId), conn);
						String taxname = tax.getTaxonomyId()+":"+tax.getTaxonomyName();
						finaltax.add(taxname);
					}
					String res = String.join("~", finaltax);
					search.setTaxValue(res);
				}
			}
			if (log.isDebugEnabled()) {
				log.debug(" getFilterSearch || retrieved " + searchList.size()
						+ " FilterSearch data successfully");
			}
		} catch (RepoproException e) {
			log.error("getFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearch || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (searchList.isEmpty()) {
			retMsg = Constants.FILTER_SEARCH_DATA_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.FILTER_SEARCH_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		if (log.isTraceEnabled()) {
			log.trace("getFilterSearch ||assetName:" + assetName + ",userName:"
					+ userName + "|| End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(searchList))).build();
	}

	/**
	 * @method getFilterSearchForLoad
	 * @description get filter search data for load
	 * @param assetName
	 * @param searchName
	 * @param userName
	 * @return success response
	 * @
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getFilterSearchForLoad")
	public Response getFilterSearchForLoad(
			@QueryParam("assetName") String assetName,
			@QueryParam("searchName") String searchName,
			@QueryParam("userName") String userName)  {
		if (log.isTraceEnabled()) {
			log.trace("getFilterSearchForLoad ||assetName:" + assetName
					+ ",searchName:" + searchName + ",userName:" + userName
					+ "||Begin");
		}
		Connection conn = null;
		List<SavedSearch> searchList = new ArrayList<SavedSearch>();
		SavedSearch savedSearch = new SavedSearch();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetParamDef paramdetaileddata = null;
		AssetInstanceDao  assetInstanceDao = new AssetInstanceDao();
		AssetDef asset = new AssetDef();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchForLoad || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearch || dao method called : retAssetDetail() to get asset details");
			}
			asset = assetInstanceDao.retAssetDetail(assetName, conn);

			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchForLoad || dao method called : getFilterSearchForLoad()");
			}
			paramdetaileddata = new AssetParamDef();
			savedSearch = dao.getFilterSearchForLoad(asset.getAssetId(), userName,
					searchName, conn);

			TaxonomyMaster tax = new TaxonomyMaster();
			List<String> finaltax = new ArrayList<String>();
			TaxonomiesDao taxonomyDao = new TaxonomiesDao();
			
			if (savedSearch != null) {
				if(savedSearch.getTaxValue()!=null && savedSearch.getTaxValue().length()>0){
					String[]taxs = savedSearch.getTaxValue().split("~");
					for(String taxdata:taxs){
						String taxId = taxdata.substring( 0, taxdata.indexOf(":"));
						tax = taxonomyDao.getTaxonomiesByTaxId(Long.parseLong(taxId), conn);
						String taxname = tax.getTaxonomyId()+":"+tax.getTaxonomyName();
						finaltax.add(taxname);
					}
					String res = String.join("~", finaltax);
					savedSearch.setTaxValue(res);
				}

				String paramvalue = savedSearch.getParamsValue();
				if(!paramvalue.equalsIgnoreCase("")){
					String[] splited = paramvalue.split("~");
					for (int i = 0; i < splited.length; i++) {

						String paramIdValue = splited[i].split("_")[0];
						long paramId = Long.parseLong(paramIdValue);
						paramdetaileddata = dao.getParamNameByParamId(paramId, conn);
						if(paramdetaileddata!=null){
							splited[i] = paramdetaileddata.getAssetParamName() + "_"+paramdetaileddata.getMappedAssetId()+"_" + splited[i];
						}
					}

					StringBuilder finalparamvalue = new StringBuilder();
					for (int i = 0; i < splited.length; i++) {
						if (i > 0) {
							finalparamvalue.append("~");
						}
						String param = splited[i];
						finalparamvalue.append(param);
					}
					savedSearch.setParamsValue(finalparamvalue.toString());
				}

				searchList.add(savedSearch);
			}

			if (log.isInfoEnabled()) {
				log.info(" getFilterSearchForLoad || retrieved "
						+ searchList.size()
						+ " FilterSearch search data successfully");
			}
		} catch (RepoproException e) {
			log.error("getFilterSearchForLoad || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getFilterSearchForLoad || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchForLoad || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (searchList.isEmpty()) {
			retMsg = Constants.FILTER_SEARCH_DATA_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.FILTER_SEARCH_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		if (log.isTraceEnabled()) {
			log.trace("getFilterSearchForLoad ||assetName:" + assetName
					+ ",searchName:" + searchName + ",userName:" + userName
					+ "|| End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(searchList))).build();
	}

	/**
	 * @method updateFilterSearch
	 * @description update FilterSearch data
	 * @param savedSearch
	 * @return success response
	 * @
	 */
	@PUT
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/updateFilterSearch")
	public Response updateFilterSearch(SavedSearch savedSearch)
	{

		if (savedSearch == null) {
			log.warn("updateFilterSearch || FilterSearch data to be updated not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {
			if (log.isTraceEnabled()) {
				log.trace("updateFilterSearch || " + savedSearch.toString()
						+ " Begin");
			}

			Connection conn = null;
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;

			try {
				if (log.isTraceEnabled()) {
					log.trace("updateFilterSearch || "
							+ Constants.LOG_CONNECTION_OPEN);
				}

				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				AssetDao dao = new AssetDao();

				if (log.isTraceEnabled()) {
					log.trace("updateFilterSearch || dao method called : updateFilterSearch()");
				}
				savedSearch.setParam1Value(URLDecoder.decode(savedSearch.getParam1Value(),"UTF-8"));
				savedSearch.setParam2Value(URLDecoder.decode(savedSearch.getParam2Value(),"UTF-8"));
				dao.updateFilterSearch(savedSearch, conn);

				retMsg = Constants.FILTER_SEARCH_DATA_UPDATED;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				if (log.isDebugEnabled()) {
					log.debug("updateFilterSearch || " + savedSearch.toString()
							+ " updated filter search data successfully");
				}
				conn.commit();

			} catch (RepoproException e) {
				log.error("updateFilterSearch || " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch (Exception e) {
				log.error("updateFilterSearch || " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateFilterSearch || "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("updateFilterSearch || " + savedSearch.toString()
						+ " End");
			}

			return Response.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
					.build();
		}

	}

	/**
	 * @method deleteFilterSearch
	 * @description delete filter search with specific search id
	 * @param searchId
	 * @return success response
	 * @
	 */
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/deleteFilterSearch")
	public Response deleteFilterSearch(@QueryParam("searchId") Long searchId)
	{

		if (log.isTraceEnabled()) {
			log.trace("deleteFilterSearch || searchId" + searchId + "||Begin");
		}

		Connection conn = null;
		List<String> msgList = new ArrayList<String>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteFilterSearch || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetDao dao = new AssetDao();

			if (log.isTraceEnabled()) {
				log.trace("deleteFilterSearch || dao method called : deleteFilterSearch()");
			}
			msgList = dao.deleteFilterSearch(searchId, conn);

			if (!(msgList.isEmpty())) {
				retMsg = Constants.FILTERSEARCH_DATA_NOT_DELETED;
			} else {
				retMsg = Constants.FILTERSEARCH_DATA_DELETED;
			}
			conn.commit();
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			if (log.isInfoEnabled()) {
				log.info("deleteFilterSearch || filter search with searchid:"
						+ searchId + " deleted successfully");
			}
		} catch (RepoproException e) {
			log.error("deleteFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("deleteFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteFilterSearch || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteFilterSearch || searchId" + searchId + "||End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(msgList))).build();
	}


	/**
	 * @method : getAssetDetails
	 * @description : to get assetDetails
	 * @param assetId
	 * @return
	 */

	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getassetdetails/{assetId}")
	public Response getAssetDetails(@PathParam("assetId")Long assetId){
		if(log.isTraceEnabled()){
			log.trace("getAssetDetails || Begin with assetId : "+ assetId);
		}
		AssetDef def = null;	
		Connection conn = null;

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try{
			if (log.isTraceEnabled()) {
				log.trace("getAssetDetails || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getAssetDetails || dao method called : getAssetDefByAssetId()");
			}
			def = dao.getAssetsByAssetId(assetId, conn);

			if (log.isTraceEnabled()) {
				log.trace("getAssetDetails || dao method called : getCategoryByAssetID() :"+assetId);
			}
			List<Category> listOfCategories = dao.getCategoryByAssetID(assetId, conn);
			for(int i=0;i<listOfCategories.size();i++){
				Category category = listOfCategories.get(i);
				Long catgoryId = category.getCategoryId();
				if (log.isTraceEnabled()) {
					log.trace("getAssetDetails || dao method called : getAssetParameterDefsByCategoryID() :"+catgoryId);
				}
				List<AssetParamDef> listOfParamDefs = dao.getAssetParameterDefsByCategoryID(catgoryId, conn);
				for (int j = 0; j <listOfParamDefs.size(); j++) {
					AssetParamDef assetParamDef = listOfParamDefs.get(j);

					if(assetParamDef.getParamTypeId().toString().equals("4")){

						if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){

							List<PossibleValues> customValues = dao.getAllPossibleValuesByParamId(assetParamDef.getAssetParamId(),conn);
							assetParamDef.setCustomListValues(customValues);
						}
						
						//Start add condition for multiSelectFlag harish
						/*boolean multiSelectFlag = dao.enableOrDisableSingleMulti(def.getAssetName(),assetParamDef.getAssetParamName(),assetParamDef.getParamTypeId(), conn);
						if(multiSelectFlag == true){
							if(assetParamDef.getListType() == 0){
								assetParamDef.setMultiSelectFlag(true);	
							}
							if(assetParamDef.getListType() == 1){
								assetParamDef.setMultiSelectFlag(true);	
							}
						}else{
							if(assetParamDef.getListType() == 1){
								assetParamDef.setMultiSelectFlag(false);
							}
						}*/
						//End add condition for multiSelectFlag
					}
					/*if(assetParamDef.getParamTypeId().toString().equals("1")||assetParamDef.getParamTypeId().toString().equals("7")){
						if(assetParamDef.getHasArray() == 1){
							boolean isArrayFlag = dao.enableOrDisableIsArray(def.getAssetName(),assetParamDef.getAssetParamName(),assetParamDef.getParamTypeId(), conn);
							assetParamDef.setHasArrayFlag(isArrayFlag);
						}
					}*/
					assetParamDef.setAssetCategoryId(catgoryId);
					String paramName = assetParamDef.getAssetParamName();
					if (log.isTraceEnabled()) {
						log.trace("getAssetDetails || dao method called : getAllDerivedAttributes()");
					}
					List<AssetParamDef> derivedAttributes =  dao.getAllDerivedAttributes(conn);
					if(log.isTraceEnabled()) {
						log.trace("getAssetDetails || dao method called getAllDerivedAttributeForAssetList()");
					}
					List<AssetParamDef> allDerivedAttributesForAssetList = dao.getAllDerivedAttributeForAssetList(conn);
					
					Pattern patternForDerivedAttribute = Pattern.compile("(?i)"+def.getAssetName()+"[\\{](?i)"+paramName+"[\\}]");
					Pattern patternForDerivedComputation = Pattern.compile("(?i)"+def.getAssetName()+"[\\.](?i)"+paramName+"(==)");
					for (AssetParamDef assetParamDef2 : derivedAttributes) {
						String rule = assetParamDef2.getDerivedAttributeComputation();
						if(assetParamDef2.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID){

							Matcher m = patternForDerivedAttribute.matcher(rule);
							if(m.find()){//destination parameter check 
								category.setFlagForCategoryRuleUsage(true);
								def.setFlagForAssetUsageInRule(true);
								assetParamDef.setFlagForParameterUsageInRule(true);
							}
							//changes modified by gomathi 15/03/2017
							Matcher m1 = patternForDerivedComputation.matcher(rule);
							if(m1.find()){// source parameter check
								def.setFlagForAssetUsageInRule(true);
								assetParamDef.setFlagForParameterUsageInRule(true);
								category.setFlagForCategoryRuleUsage(true);
							}
						}
						if(assetParamDef2.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID){
							Matcher m = patternForDerivedComputation.matcher(rule);
							if(m.find()){
								def.setFlagForAssetUsageInRule(true);
								assetParamDef.setFlagForParameterUsageInRule(true);
								category.setFlagForCategoryRuleUsage(true);
							}
						}
					}
					
					Pattern assetListParameterPattern = Pattern.compile("(?i)"+def.getAssetName()+"[\\{](?i)"+paramName+"[\\}]");
					Pattern assetListParameterPattern2 = Pattern.compile("(?i)"+def.getAssetName()+"[\\[](?i)"+paramName+"[\\]]");
					
					for(AssetParamDef apd : allDerivedAttributesForAssetList) {
						String assetListRule = apd.getDerivedAssetListRule();
						if(apd.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
							Matcher m = assetListParameterPattern.matcher(assetListRule);
							if(m.find()){ 
								category.setFlagForCategoryUsageInAssetListRule(true);
								def.setFlagForAssetUsageInAssetListRule(true);
								assetParamDef.setFlagForParameterUsageInAssetListRule(true);
							}
							
							Matcher m1 = assetListParameterPattern2.matcher(assetListRule);
							if(m1.find()){
								assetParamDef.setFlagForParameterUsageInAssetListRule(true);
								category.setFlagForCategoryUsageInAssetListRule(true);
								def.setFlagForAssetUsageInAssetListRule(true);
							}
						}
					}
					
					listOfParamDefs.set(j, assetParamDef);

					for(int jj=0;jj<derivedAttributes.size();jj++){

						AssetParamDef apd = derivedAttributes.get(jj);
						String rule = apd.getDerivedAttributeComputation();

						Pattern assetPattern1 = Pattern.compile("[\\]]"+def.getAssetName()+"[\\{]");
						Matcher m1 = assetPattern1.matcher(rule);
						if(m1.find()){
							def.setFlagForAssetUsageInRule(true);
							break;
						}

						Pattern assetPattern2 = Pattern.compile("[\\]]"+def.getAssetName()+"[\\[]");
						Matcher m2 = assetPattern2.matcher(rule);
						if(m2.find()){
							def.setFlagForAssetUsageInRule(true);
							break;
						}
					}
					
					for(int kk=0;kk<allDerivedAttributesForAssetList.size();kk++) {
						AssetParamDef assetParamDef2 = allDerivedAttributesForAssetList.get(kk);
						String assetListRule = assetParamDef2.getDerivedAssetListRule();
						
						Pattern assetPattern1 = Pattern.compile("[\\]](?i)"+def.getAssetName()+"[\\{]");
						Matcher m1 = assetPattern1.matcher(assetListRule);
						if(m1.find()){
							def.setFlagForAssetUsageInAssetListRule(true);
							break;
						}
						
						Pattern assetPattern2 = Pattern.compile("[\\]](?i)"+def.getAssetName()+"[\\[]");
						Matcher m2 = assetPattern2.matcher(assetListRule);
						if(m2.find()){
							def.setFlagForAssetUsageInAssetListRule(true);
							break;
						}
					}
				}
				category.setListOfAssetParamDefs(listOfParamDefs);
				listOfCategories.set(i, category);
			}
			def.setCategories(listOfCategories);

			//group access for an asset
			GroupDao gd = new GroupDao();
			List<Map<String, Long>>  mapValues = gd.getGroupAccessByAssetId(assetId, conn);

			def.setGroupAccessForAsset(mapValues);

			AssetDao assetDao = new AssetDao();

			Map<Long, List<String>> checkedGroupDetails = assetDao.getCheckedGroupDetailsByAssetId(assetId, conn);

			GroupDao groupDao = new GroupDao();
			List<GroupDetails> allGroups = groupDao.getAllGroups(conn);
			Map<Long,Set<GroupDetails>> details = new HashMap<Long, Set<GroupDetails>>();
			Map<Long,String> values = assetDao.getCheckedGroupDetailsByAssetIdWithCategories(assetId,conn);

			List<Long> list = new ArrayList<Long>(checkedGroupDetails.keySet());

			for(int i = 0;i<checkedGroupDetails.keySet().size();i++){
				Set<GroupDetails> listOfGds = new HashSet<GroupDetails>();
				Long categoryId =list.get(i);
				List<String> groups = checkedGroupDetails.get(categoryId);
				for(int j=0;j<groups.size();j++){
					for(int k=0;k<allGroups.size();k++){
						GroupDetails groupDetailsMapped = new GroupDetails();
						//GroupDetails groupDetailsMapped = allGroups.get(k);
						if(groups.get(j).equalsIgnoreCase(allGroups.get(k).getGroupName())){
							groupDetailsMapped.setMappedWithUser(true);
							groupDetailsMapped.setCategoryName(values.get(categoryId));
							groupDetailsMapped.setDescription(allGroups.get(k).getDescription());
							groupDetailsMapped.setGroupId((allGroups.get(k).getGroupId()));
							groupDetailsMapped.setGroupName(allGroups.get(k).getGroupName());
							listOfGds.add(groupDetailsMapped);
						}else{
							groupDetailsMapped.setCategoryName(values.get(categoryId));
							groupDetailsMapped.setDescription(allGroups.get(k).getDescription());
							groupDetailsMapped.setGroupId((allGroups.get(k).getGroupId()));
							groupDetailsMapped.setGroupName(allGroups.get(k).getGroupName());
							listOfGds.add(groupDetailsMapped);
						}
					}

				}
				details.put(categoryId, listOfGds);
			}
			def.setCategoriesWithAccess(details);

			//getting assigned taxonomies for asset
			def.setAssetAssignedTaxonomies(assetDao.getTaxonomiesByAssetId(assetId, conn));

			boolean flag = assetDao.enableOrdisableAssetVersionBasedonAssetRelation(def.getAssetName(), conn);
			def.setRelFlag(flag);
			
			//Asset Visualization
			AssetRepresentationDao repDao = new AssetRepresentationDao();
			def.setAssetRepresentation(repDao.getAssetRepresentationByAssetName(conn, def.getAssetName()));
			
			//To disable enable workflow option
			WorkflowDao workflowDao = new WorkflowDao();
			Workflow retWorkflowAssignedToAsset = workflowDao.retWorkflowAssignedToAsset(assetId, conn);
			if(retWorkflowAssignedToAsset.getWorkflowId() != 0) {
				def.setFlagIfWorkflowAssigned(true);
			}
			
			/*boolean isArrayFlag = assetDao.enableOrDisableIsArray(def.getAssetName(), conn);
			def.setIsArrayFlag(isArrayFlag);
*/
			log.info("Successfully get the assetDetails "+def);
			
		}catch (RepoproException e) {
			log.error("getAssetDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			log.error("getAssetDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("getAssetDetails || End");
		}
		List<AssetDef> def1 =  new  ArrayList<AssetDef>();
		def1.add(def);
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg,new ArrayList<Object>(def1)))
				.build();
	}



	/**
	 * @method : deleteAsset
	 * @description : to delete an asset
	 * @param assetId
	 * @return
	 */
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/deleteasset/{assetId}/{assetName}")
	public Response deleteAsset(@PathParam("assetId") Long assetId,
			@PathParam("assetName") String assetName,  @QueryParam("userId") Long userId) 
	{

		if(log.isTraceEnabled()){
			log.trace("deleteAsset || Begin with assetId : "+ assetId+" and assetName :"+assetName);
		}
		Connection conn = null;
		List<String> msgList = new ArrayList<String>();
		//
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		User user = new User();
		String action = Constants.ACTIVITY_DELETE;
		RecentActivity recentActivity = new RecentActivity();
		RecentActivityDao recentActivityDao = new RecentActivityDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("deleteAsset || dao method called : getAllDerivedAttributes()");
			}
			if (log.isTraceEnabled()) {
				log.trace("deleteAsset || dao method called : getCategoryByAssetID() "+assetId);
			}
			List<AssetParamDef> listdefs = dao.getMappedParametersWithAssetId(assetId, conn);
			if(listdefs.size()!=0){
				//retStatScsFlr=Constants.GET_STATUS_SUCCESS;
				msgList.add("ASSET IS MAPPED WITH PARAMETER WE CAN NOT DELETE THIS ASSET");
				return Response
						.status(retStat)
						.entity(new MyModel(Constants.DELETE_STATUS_FAILURE,
								Constants.FAILURE, Constants.ASSET_NOT_DELETED,
								new ArrayList<Object>(msgList))).build();
			}else{

				List<Category> allCategories = dao.getCategoryByAssetID(assetId, conn);
				List<AssetParamDef> allDefs = null;
				for (Category category : allCategories) {
					Long categoryId = category.getCategoryId();
					if (log.isTraceEnabled()) {
						log.trace("deleteAsset || dao method called : getAssetParameterDefsByCategoryID() "+categoryId);
					}
					allDefs = dao.getAssetParameterDefsByCategoryID(categoryId, conn);

					List<String> deletedParameter = null;
					for (AssetParamDef assetParamDef : allDefs) {
						if (log.isTraceEnabled()) {
							log.trace("deleteAsset || dao method called : deleteParameter1() "+assetParamDef.getAssetParamId());
						}
						deletedParameter = dao.deleteParameter1(assetParamDef.getAssetParamId(),conn);
						if(deletedParameter.size()!=0){
							Status retStatParameter = Status.EXPECTATION_FAILED;
							retMsg = "Internal problems";
							return Response
									.status(retStatParameter)
									.entity(new MyModel(Constants.DELETE_STATUS_FAILURE,Constants.FAILURE,retMsg))
									.build();
						}
					}
				}

				for (Category category : allCategories) {
					Long catLongID = category.getCategoryId();
					if (log.isTraceEnabled()) {
						log.trace("deleteAsset || dao method called : deleteCategory() "+catLongID);
					}
					int deletedCategories = dao.deleteCategory(catLongID, conn);
					if(deletedCategories==0){
						Status retStatCategory = Status.EXPECTATION_FAILED;
						retMsg = "Internal Problems";
						return Response
								.status(retStatCategory)
								.entity(new MyModel(Constants.DELETE_STATUS_FAILURE,Constants.FAILURE,retMsg))
								.build();
					}
				}
				
				//TODO: delete all linked instance visualization folders
				AssetRepresentationDao repDao = new AssetRepresentationDao();
				repDao.deleteRepresentationOnChangeInAsset(assetName, conn);

				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				List<String> emailIds = new ArrayList<String>();

				UserDao userDao = new UserDao();
				SubscriptionDao subscriptionDao = new SubscriptionDao();

				user = userDao.getUserByUserId(userId, conn);
				emailIds = subscriptionDao.getSubscribersForAsset(assetId, conn);

				if(!emailIds.isEmpty()){
					String mailTemp = "";
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"deleteAssetType");
					mailTemp = mtVo.getMailTemplate();
					mailTemp = mailTemp.replaceAll("%assetType%", assetName);

					for(String emailId:emailIds){
						MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);

						SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_TYPE_DELETED), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

					}
				}

				String log1 = user.getFullName() + ";" + action + ";"+ assetName + ";"+ "" + ";"+ "";
				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setDescription(log1);
				recentActivity.setAssetId(assetId.toString());
				recentActivity.setAssetInstVersionId("");
				recentActivity.setUser_id(userId);

				if (log.isTraceEnabled()) {
					log.trace("deleteAsset || dao method called : addRecentActivity() ");
				}
				recentActivityDao.addRecentActivity(recentActivity, conn);

				if (log.isTraceEnabled()) {
					log.trace("deleteAsset || dao method called : deleteAsset() "+assetId+" assetName "+assetName);
				}
				msgList = dao.deleteAsset(assetId,assetName, conn);	

				if(!(msgList.isEmpty())){
					retMsg = Constants.ASSET_NOT_DELETED;
				}else{
					retMsg = Constants.ASSET_DELETED;
					conn.commit();
				}
				retMsg = Constants.ASSET_DELETED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK; 
				retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
				log.info("deleteAsset || Asset with id "+ assetId +" deleted successfully");
			}



		} catch (RepoproException e) {
			log.error("deleteAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("deleteAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("deleteAsset || End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg,new ArrayList<Object>(msgList)))
				.build();
	}
	/**
	 * @method : addAsset
	 * @description : to add a new asset
	 * @param addAsset
	 * @return Response success message
	 * @throws IOException 
	 * @throws JSONException 
	 */
	@SuppressWarnings("unused")
	@POST
	@Encoded
	@Path("/addasset")
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response addAsset(@FormDataParam("assetName")String assetName,
			/*@QueryParam("description")String description,*/
			@FormDataParam("versionable")Boolean versionable,
			@FormDataParam("guestflag")Boolean guestflag,
			@FormDataParam("ratingDescription")String ratingDescription,
			@FormDataParam("enableWorkflow") Boolean enableWorkflow,
			@FormDataParam("hiddenVariableForCategoryObject")String hiddenVariableForCategoryObject,
			FormDataMultiPart bodyParts ,
			@Context HttpServletRequest request) throws RepoproException, IOException, JSONException{

		AssetDef addAsset = null;
		String extension = "";
		if(assetName!=null)
			addAsset = new AssetDef();
		InputStream file = null;
		FormDataBodyPart dataMultiPart = null;
		String NewFileName = null;
		CommonUtils commonUtils = new CommonUtils();
		if (bodyParts != null) {
			dataMultiPart = bodyParts.getField("iconImageName1");
			if(dataMultiPart != null){
				NewFileName = dataMultiPart.getContentDisposition()
						.getFileName();
	
				if (!NewFileName.isEmpty()|| NewFileName.length() != 0) {
					// File name validation
					boolean validFileName = commonUtils.validateUploadedFileName(NewFileName);
					if (validFileName) {
						InvertImage invertImage = new InvertImage();
						file = invertImage.inverImage(dataMultiPart
								.getEntityAs(InputStream.class), dataMultiPart
								.getContentDisposition().getFileName());
						
						//InputStream targetStream = new FileInputStream(file);
						 
						addAsset.setIconImage(dataMultiPart
								.getEntityAs(InputStream.class));
						addAsset.setIconImageName(dataMultiPart
								.getContentDisposition().getFileName());
						addAsset.setInvertedIconImage(file);
					} else {
						log.warn("addAsset || File with invalid File Name is uploaded");
						return Response
								.status(Status.BAD_REQUEST).entity(new MyModel(Constants.STATUS_FAILURE,Constants.FAILURE, 
										MessageUtil.getMessage(Constants.INVALID_REQUEST)))
										.build();
					}				
				}
			}
		}

		addAsset.setAssetName(assetName.trim());
		//addAsset.setDescription(description);
		if(versionable==null){
			addAsset.setVersionable(false);
		}else{
			addAsset.setVersionable(true);
		}
		if(guestflag==null){
			addAsset.setGuestflag(false);
		}else{
			addAsset.setGuestflag(true);
		}
		
		if(enableWorkflow == null) {
			addAsset.setEnableWorkflow(false);
		}else {
			addAsset.setEnableWorkflow(true);
		}
		
		String jsonStr = hiddenVariableForCategoryObject;
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();

		try{
		/*	description = URLDecoder.decode(description,"UTF-8");
			addAsset.setDescription(description);*/ /*DEEKSHA 20.Feb.2018*/
			JSONObject obj = new JSONObject(jsonStr);
			String descriptionVal = (String) obj.get("description");
		//	System.out.println("descriptionVal ::" +descriptionVal);

			//get global setting setting details
			if (log.isTraceEnabled()){
				log.trace("addAsset || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, null);
			
			if(globalsetting.getGlobalSettingFlag() == 1){
				descriptionVal = commonUtils.httpSanitizerForCkEditor(descriptionVal);
			}
			addAsset.setDescription(descriptionVal);
			
			if(globalsetting.getGlobalSettingFlag() == 1){
				ratingDescription = commonUtils.httpSanitizerForPlainText(ratingDescription);
			}
			
			addAsset.setRatingDescription(ratingDescription);
			
			String categoriesArray = obj.get("categories").toString();
			String assetAssignedTaxonomies = obj.get("assetAssignedTaxonomies").toString();
			JSONArray assetAssignedTaxonomiesArray = new JSONArray(assetAssignedTaxonomies);
			Map<Long,String> map = new HashMap<Long, String>();
			for(int i=0; i<assetAssignedTaxonomiesArray.length(); i++){
				@SuppressWarnings("rawtypes")
				Iterator itr = assetAssignedTaxonomiesArray.getJSONObject(i).keys();
				while (itr.hasNext()) {
					Object keyName = itr.next();
					map.put((Long)Long.parseLong(keyName.toString()),assetAssignedTaxonomiesArray.getJSONObject(i).get(keyName.toString()).toString());
				}
			}
			addAsset.setAssetAssignedTaxonomies(map);
			
			List<Map<String, Long>> groupAccess = new ArrayList<Map<String,Long>>();

			String groupAccessForAsset = obj.get("groupAccessForAsset").toString();
			JSONArray groupAccessForAssetArray = new JSONArray(groupAccessForAsset);
			for(int i=0; i<groupAccessForAssetArray.length(); i++){
				GroupDetails gd = new GroupDetails();
				Map<String,Long> groupAccesForRow = new HashMap<String, Long>();
				JSONObject jsonObj = groupAccessForAssetArray.getJSONObject(i);
				groupAccesForRow.put("group_id", (Long)((Integer)jsonObj.getInt("group_id")).longValue());
				groupAccesForRow.put("add_access", (Long)((Integer)jsonObj.getInt("add_access")).longValue());
				groupAccesForRow.put("edit_access", (Long)((Integer)jsonObj.getInt("edit_access")).longValue());
				groupAccesForRow.put("view_access", (Long)((Integer)jsonObj.getInt("view_access")).longValue());
				groupAccesForRow.put("delete_access", (Long)((Integer)jsonObj.getInt("delete_access")).longValue());
				groupAccess.add(groupAccesForRow);
			}
			addAsset.setGroupAccessForAsset(groupAccess);
			JSONArray array = new JSONArray(categoriesArray); 
			List<Category> listOfCategories = new ArrayList<Category>();
			for(int i=0; i<array.length(); i++){ 
				Category category = new Category();
				JSONObject jsonObj = array.getJSONObject(i);
				category.setActionForCategory(jsonObj.getString("actionForCategory"));
				category.setCategoryName(jsonObj.getString("categoryName"));
				category.setCategoryAction(jsonObj.getString("categoryAction"));
				category.setDisp_position(jsonObj.getInt("disp_position"));
				addAsset.setUserName(jsonObj.getString("userName"));

				String parametersArray = jsonObj.get("listOfAssetParamDefs").toString();
				JSONArray parametersJsonArray = new JSONArray(parametersArray); 
				List<AssetParamDef> listOfDefs = new ArrayList<AssetParamDef>();
				for(int j=0; j<parametersJsonArray.length(); j++){ 
					AssetParamDef apd = new AssetParamDef();
					JSONObject ParamjsonObj = parametersJsonArray.getJSONObject(j);
					apd.setActionForParameter(ParamjsonObj.getString("actionForParameter"));
					apd.setAssetParamName(ParamjsonObj.getString("assetParamName"));
					apd.setDefaultView(ParamjsonObj.getInt("defaultView"));
					apd.setIs_static(ParamjsonObj.getInt("is_static"));
					apd.setHasImportantValue(ParamjsonObj.getBoolean("hasImportantValue"));
					apd.setHasMandatoryValue(ParamjsonObj.getBoolean("hasMandatoryValue"));
					apd.setNotifyOnRuleValidate(ParamjsonObj.getBoolean("notifyOnRuleValidate"));
					String paramDescription = "";
					if(globalsetting.getGlobalSettingFlag() == 1){
						paramDescription = commonUtils.httpSanitizerForPlainText(ParamjsonObj.getString("description"));
					}else{
						paramDescription = ParamjsonObj.getString("description");
					}
					apd.setDescription(paramDescription);
					apd.setParamTypeId((long)ParamjsonObj.getInt("paramTypeId"));
					apd.setListType(ParamjsonObj.getInt("singlemultiple"));
					apd.setLastUpdatedTime(new Timestamp(new Date().getTime()));
					apd.setHasArray(ParamjsonObj.getInt("isArray"));
					Integer val1 = ParamjsonObj.getInt("listTypeParamTypeId");

					apd.setListTypeParamTypeId(val1.longValue());
					if(apd.getParamTypeId().toString().equals("4")){
						if(apd.getListTypeParamTypeId().toString().equals("1")){
							List<PossibleValues> listOfCustoms = new ArrayList<PossibleValues>(); 
							String customListArray = ParamjsonObj.get("custListItems").toString();
							JSONArray customArray = new JSONArray(parametersArray); 

							String[] split = customListArray.split("\n");

							for(int k=0; k<split.length; k++){ 
								PossibleValues p = new PossibleValues();
								p.setValue(split[k]);
								if(globalsetting.getGlobalSettingFlag() == 1){
									String customdata = commonUtils.httpSanitizerForPlainText(split[k]);
									p.setValue(customdata);
								}
								listOfCustoms.add(p);
							}
							apd.setCustomListValues(listOfCustoms);
						}
					}
					Integer mapedAsseId = ParamjsonObj.getInt("mappedAssetId");
					apd.setMappedAssetId(mapedAsseId.longValue());

					apd.setLdapMappingId(ParamjsonObj.getInt("ldapMappingId"));
					
					apd.setModifyByUserId(((Integer)ParamjsonObj.getInt("modifyByUserId")).longValue());
					if(ParamjsonObj.getString("derivedAttributeComputation").equals("")){
						apd.setDerivedAttributeComputation(null);	
					}else{
						apd.setDerivedAttributeComputation(ParamjsonObj.getString("derivedAttributeComputation"));
					}
					
					if(ParamjsonObj.getString("derivedAssetListRule").equals("")) {
						apd.setDerivedAssetListRule(null);
					}else {
						apd.setDerivedAssetListRule(ParamjsonObj.getString("derivedAssetListRule"));
					}
					
					apd.setParamTypeId(ParamjsonObj.getLong("paramTypeId"));
					apd.setSize(ParamjsonObj.getInt("size"));
					listOfDefs.add(apd);
					category.setListOfAssetParamDefs(listOfDefs);
				}
				listOfCategories.add(category);
			}
			addAsset.setCategories(listOfCategories);
			
			//TODO: Asset Visualization
			String assetRepresentionJson = obj.get("assetVisualization").toString();
			JSONArray assetRepresentionArray = new JSONArray(assetRepresentionJson);
			JSONObject assetRepresentionObj = assetRepresentionArray.getJSONObject(0);
			String representationName = assetRepresentionObj.getString("AssetrepName");
			if(!representationName.isEmpty() && !representationName.equalsIgnoreCase("")){
				AssetRepresentation assetRep = new AssetRepresentation();
				assetRep.setRepresentationName(representationName);
				addAsset.setAssetRepresentation(assetRep);
			} else {
				addAsset.setAssetRepresentation(null);
			}
			
			
			
		}catch(org.json.JSONException e){
			e.printStackTrace();
		}
		if(addAsset == null) { 
			log.warn("addAsset || Asset data to be added is not provided");
			return Response
					.status(Status.BAD_REQUEST).entity(new MyModel(Constants.STATUS_FAILURE,Constants.FAILURE, 
							MessageUtil.getMessage(Constants.INVALID_REQUEST)))
							.build();
		}else{

			if(log.isTraceEnabled()){
				log.trace("addAsset || "+ addAsset+" Begin");
			}

			Connection conn = null;
			List<String> result = new ArrayList<String>();
			List<AssetDef> assetDefListObj = new ArrayList<AssetDef>();
			TaxonomiesDao tdao = new TaxonomiesDao();
			AssetDao dao = new AssetDao();
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			AssetDef addAsset1 = null;
			GroupDao groupDao = new GroupDao();
			User user = new User();
			String action = Constants.ACTIVITY_CREATE;
			RecentActivity recentActivity = new RecentActivity();
			RecentActivityDao recentActivityDao = new RecentActivityDao();

			try {
				if (log.isTraceEnabled()) {
					log.trace("addAsset || " + Constants.LOG_CONNECTION_OPEN);
				}

				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				boolean flagForDuplicateAsset = false;


				String jsonRslt;
				List<String> jsonList = new ArrayList<String>();

				List<AssetDef> assetDefList = new ArrayList<AssetDef>();

				if (log.isTraceEnabled()) {
					log.trace("addAsset || dao method called : getAllAssets()");
				}
				assetDefList = dao.getAllAssets(conn);

				for(AssetDef list : assetDefList){
					if(list.getAssetName().equalsIgnoreCase(addAsset.getAssetName())){
						flagForDuplicateAsset = true;
					}
				}
				if(flagForDuplicateAsset == true){
					log.warn("addAsset || Asset by this name already exists, please provide different name");
					result.add("Asset by this name already exists, please provide different name");

					jsonRslt = Constants.ASSET_NAME_EXIST;	
					jsonList.add(jsonRslt);

					return Response
							.status(Status.OK)
							.entity(new MyModel(Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE, MessageUtil
									.getMessage(Constants.ASSET_NAME_EXIST), new ArrayList<Object>(jsonList)))
									.build();
				}else{ 

					List<Category> categories = addAsset.getCategories();
					if(categories==null){
						retMsg = Constants.ASSET_CATEGORY_CAN_NOT_BE_NULL;
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
						return Response
								.status(retStat)
								.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
								.build();
					}

					for(int i=0;i<categories.size();i++){
						Category cat = categories.get(i);
						if(cat.getListOfAssetParamDefs()==null){
							retMsg = Constants.ASSET_CATEGORY_PARAMETER_CAN_NOT_BE_NULL;
							retStat = Status.OK;
							retScsFlr = Constants.FAILURE;
							retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
							return Response
									.status(retStat)
									.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
									.build();
						}
					}
					addAsset1 = dao.addAsset(addAsset, conn);
					int displsyPosition = 0;
					Long assetId = addAsset1.getAssetId();
					for(int i=0;i<categories.size();i++){

						if (log.isTraceEnabled()) {
							log.trace("addCategoryDefinition || dao method called : addCategoryDefinition() ");
						}
						Long categoryId = dao.addCategoryDefinition(addAsset1, categories.get(i), conn, displsyPosition);

						// default select of group admin for category 
						//if(!categoryName.equalsIgnoreCase(BusinessConstants.DUMMY_CATEGORY)){

						List<GroupDetails> groupDetailsBos = groupDao.getAllGroups(conn);
						for(GroupDetails groupDetailsBo : groupDetailsBos){
							if(groupDetailsBo.getGroupName().equalsIgnoreCase("group-admin")){
								if (log.isTraceEnabled()) {
									log.trace("addCategoryDefinition || dao method called : addCategoryWiseAccessForAsset() ");
								}
								dao.addCategoryWiseAccessForAsset(categoryId, groupDetailsBo.getGroupId(), conn);
							}
						}
						//}

						if(categoryId!=0){
							displsyPosition++;
							int paramdisplayPosition = 0;
							List<AssetParamDef> paramDefs = categories.get(i).getListOfAssetParamDefs();
							for(int j=0;j<paramDefs.size();j++){
								AssetParamDef assetParamDef = paramDefs.get(j);
								if (log.isTraceEnabled()) {
									log.trace("addParameterDefinition || dao method called : addParameterDefinition() " + assetParamDef.toString());
								}
								Long parameterId = dao.addParameterDefinition(addAsset1, categoryId, assetParamDef,addAsset.getUserId(),paramdisplayPosition,conn);
								if(assetParamDef.getParamTypeId().toString().equals("4")){
									if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){

										List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
										for (PossibleValues possibleValues : customListValues) {
											dao.insertPossibleValues(parameterId, possibleValues.getValue(), conn);
										}
									}
								}

								if(parameterId==0){
									retMsg = Constants.ASSET_PARAMETER_CAN_NOT_CREATED;
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
									return Response
											.status(retStat)
											.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(paramDefs)))
											.build();
								}else{
									paramDefs.get(j).setAssetCategoryId(categoryId);;
									paramDefs.get(j).setAssetParamId(parameterId);
								}
								paramdisplayPosition++;
							}
							categories.get(i).setParameters(paramDefs);
							categories.get(i).setCategoryId(categoryId);
						}else{
							retMsg = Constants.ASSET_CATEGORY_CAN_NOT_CREATED;
							retStat = Status.OK;
							retScsFlr = Constants.FAILURE;
							retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
							return Response.status(retStat).entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(categories))).build();
						}
					}
					retMsg = Constants.ASSET_CREATED;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;

					addAsset.setAssetId(assetId);
					addAsset.setCategories(categories);

					//group asset access
					groupDao.addGroupsAssetAccessSubmit(assetId, addAsset.getGroupAccessForAsset(), conn);
				}
				//adding assigned taxonomies
				tdao.addassignedTaxonomies(addAsset.getAssetId(),addAsset.getAssetAssignedTaxonomies(),conn);


				log.info(" addAsset || "+ addAsset.toString() +" added asset successfully");
				/*if(NewFileName != null) {
					if(!NewFileName.equals("")){
						BufferedImage image = null;
						image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
						if(image!=null){
							String uploadedFileLocation = request.getRealPath("");
							if (NewFileName.toLowerCase().indexOf("jpg".toLowerCase()) != -1
									|| NewFileName.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
								uploadedFileLocation = uploadedFileLocation
										+ Constants.ASSET_IMAGE_FILE_NAME +addAsset1.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
								ImageIO.write(image, "jpg", new File(
										uploadedFileLocation));
							} else if (NewFileName.toLowerCase().indexOf("png".toLowerCase()) != -1 || NewFileName.toUpperCase().indexOf(
									"png".toUpperCase()) != -1) {
								uploadedFileLocation = uploadedFileLocation
										+ Constants.ASSET_IMAGE_FILE_NAME +addAsset1.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
								ImageIO.write(image, "png", new File(uploadedFileLocation));
							}
						}	
					}
				}*/

				if(NewFileName != null) {
					if(!NewFileName.equals("")){
						BufferedImage image = null;
						BufferedImage invertedImage = null;
						image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
						int ik = addAsset.getIconImageName().lastIndexOf('.');
						if (ik > 0) {
							extension = addAsset.getIconImageName().substring(ik+1);
						}
						
						InputStream newImg = new FileInputStream(System.getProperty("user.home") +"/inverted_new."+extension);
						invertedImage = ImageIO.read(newImg);
						if(image!=null){
							String uploadedFileLocation = request.getRealPath("");
							String uploadedInvertedFileLocation = request.getRealPath("");
							
							
							if (NewFileName.toLowerCase().indexOf("jpg".toLowerCase()) != -1
									|| NewFileName.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
								uploadedFileLocation = uploadedFileLocation
										+ Constants.ASSET_IMAGE_FILE_NAME +addAsset1.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
								ImageIO.write(image, "jpg", new File(
										uploadedFileLocation));
								
								//inverted images
								if(invertedImage != null) {
									uploadedInvertedFileLocation = uploadedInvertedFileLocation
											+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+addAsset1.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
									ImageIO.write(invertedImage, "jpg", new File(
											uploadedInvertedFileLocation));
								}

							} else if (NewFileName.toLowerCase().indexOf("png".toLowerCase()) != -1 || NewFileName.toUpperCase().indexOf(
									"png".toUpperCase()) != -1) {
								uploadedFileLocation = uploadedFileLocation
										+ Constants.ASSET_IMAGE_FILE_NAME +addAsset1.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
								ImageIO.write(image, "png", new File(uploadedFileLocation));
								
								//inverted images
								if(invertedImage != null) {
									uploadedInvertedFileLocation = uploadedInvertedFileLocation
											+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+addAsset1.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
									ImageIO.write(invertedImage, "png", new File(uploadedInvertedFileLocation));

								}
							}
						}	
					}
				}
				
				//TODO: Asset Visualization	
				if (addAsset.getAssetRepresentation() != null) {
					AssetRepresentationDao repDao = new AssetRepresentationDao();
					AssetRepresentation assetRepDb = repDao.getAssetRepresentationByName(conn, addAsset.getAssetRepresentation().getRepresentationName());
					
					if (assetRepDb != null){
						repDao.addAssetRepresentationLink(addAsset1.getAssetId(), assetRepDb.getAssetRepresentationId(), conn);
					} else {
						retMsg = Constants.INVALID_ASSET_REPRESENTATION;
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;
						return Response
								.status(retStat)
								.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
								.build();
					}
				}
				
				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				List<String> emailIds = new ArrayList<String>();

				UserDao userDao = new UserDao();
				SubscriptionDao subscriptionDao = new SubscriptionDao();

				user = userDao.retProfileForUserName(addAsset.getUserName(), conn);

				List<User> usersList = userDao.getUsers(false, conn);

				for(User u : usersList){
					if(u.isSubscribe() == true && u.getActiveFlag().equals("1")){
						emailIds.add(u.getEmailId());
					}
				}

				if(!emailIds.isEmpty()){
					String mailTemp = "";
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetType");
					mailTemp = mtVo.getMailTemplate();
					mailTemp = mailTemp.replaceAll("%assetType%", addAsset.getAssetName());

					for(String emailId:emailIds){
						MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);

						SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(Constants.REPOPRO_NEW_ASSET_TYPE_CREATED), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

					}
				}

				String log1 = user.getFullName() + ";" + action + ";"+ addAsset.getAssetName() + ";"+ "" + ";" + "";
				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setDescription(log1);
				recentActivity.setAssetId(addAsset.getAssetId().toString());
				recentActivity.setAssetInstVersionId("");
				recentActivity.setUser_id(user.getUserId());

				if (log.isTraceEnabled()) {
					log.trace("addAsset || dao method called : addRecentActivity() ");
				}
				recentActivityDao.addRecentActivity(recentActivity, conn);
				conn.commit();
				assetDefListObj.add(addAsset); /*SUSHMITHA 18.Feb.2018*/
				File deletedFile = new File(System.getProperty("user.home")+"/inverted_new."+extension);
				//System.out.println("deletedFile::" +deletedFile.getAbsolutePath());
				if(deletedFile.exists()) {
					deletedFile.delete();
				}
				File deleteOriginalFile = new File(System.getProperty("user.home")+"/inverted"+"."+extension);
			//	System.out.println("deleteOrigialFile::" +deleteOriginalFile.getAbsolutePath());
				if(deleteOriginalFile.exists()) {
					deleteOriginalFile.delete();
				}
				//file.delete();
			} catch(RepoproException e){
				log.error("addAsset ||  " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				//file.delete();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch(Exception e){
				log.error("addAsset ||  " + Constants.LOG_EXCEPTION + e.getMessage());
				//file.delete();
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addAsset || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if(log.isTraceEnabled()){
				log.trace("addAsset || "+ addAsset.toString() +" End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(assetDefListObj)))
					.build();
		}//end of else
	}//end of addAsset()

	/**
	 * @method : updateAsset
	 * @description : to update an asset
	 * @param updateAsset
	 * @return Response success message
	 * @throws JSONException 
	 */
	@SuppressWarnings("unused")
	@POST
	@Path("/updateasset")
	@Encoded
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response updateAsset(@FormDataParam("assetName")String assetName,
			/*@QueryParam("description")String description,*/
			@FormDataParam("versionable")Boolean versionable,
			@FormDataParam("guestflag")Boolean guestflag,
			@FormDataParam("enableWorkflow") Boolean enableWorkflow,
			@FormDataParam("ratingDescription")String ratingDescription,
			@FormDataParam("hiddenVariableForCategoryObject")String hiddenVariableForCategoryObject,
			FormDataMultiPart bodyParts ,
			@Context HttpServletRequest request) throws RepoproException, IOException, JSONException{
		AssetDef  updateAsset = null;
		if(assetName!=null)
			updateAsset = new AssetDef();
		FormDataBodyPart dataMultiPart = null;
		AssetDao dao = new AssetDao();
		CommonUtils commonUtils = new CommonUtils();
		String NewFileName = null;
		if (bodyParts != null) {
			dataMultiPart = bodyParts.getField("iconImageName1");
			if(dataMultiPart != null){
				NewFileName = dataMultiPart.getContentDisposition()
						.getFileName();
				if (!NewFileName.isEmpty()|| NewFileName.length() != 0) {
					// File name validation
					boolean validFileName = commonUtils.validateUploadedFileName(NewFileName);
					if (!validFileName){
						log.warn("addAsset || File with invalid File Name is uploaded");
						return Response
								.status(Status.BAD_REQUEST).entity(new MyModel(Constants.STATUS_FAILURE,Constants.FAILURE, 
										MessageUtil.getMessage(Constants.INVALID_REQUEST)))
										.build();
					}
				}
			}
		}
		//System.out.println("hiddenVariableForCategoryObject>>>>>>>>"+hiddenVariableForCategoryObject.toString());
		updateAsset.setAssetName(assetName.trim());
		String extension = "";
		//updateAsset.setDescription(description);
		if(versionable==null){
			updateAsset.setVersionable(false);
		}else{
			updateAsset.setVersionable(true);
		}
		if(guestflag==null){
			updateAsset.setGuestflag(false);
		}else{
			updateAsset.setGuestflag(true);
		}
		
		if(enableWorkflow == null) {
			updateAsset.setEnableWorkflow(false);
		}else {
			updateAsset.setEnableWorkflow(true);
		}
		
		//updateAsset.setRatingDescription(ratingDescription);

		GlobalSettingDao globalSettingDao = new GlobalSettingDao();

		String jsonStr = hiddenVariableForCategoryObject;
		try{
			//description = URLDecoder.decode(description,"UTF-8");
			//updateAsset.setDescription(description); /*DEEKSHA 20.Feb.2018*/
			JSONObject obj = new JSONObject(jsonStr);			

			//get global setting setting details
			if (log.isTraceEnabled()){
				log.trace("updateAsset || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, null);
			
			//Fetching Assigned Taxonomies for Asset
			String descriptionVal = obj.get("description").toString();
			//System.out.println("descriptionVal edit::" +descriptionVal);
			//updateAsset.setDescription(descriptionVal);
			if(globalsetting.getGlobalSettingFlag() == 1){
				descriptionVal = commonUtils.httpSanitizerForCkEditor(descriptionVal);
			}
			updateAsset.setDescription(descriptionVal);
			
			if(globalsetting.getGlobalSettingFlag() == 1){
				ratingDescription = commonUtils.httpSanitizerForPlainText(ratingDescription);
			}
			updateAsset.setRatingDescription(ratingDescription);
			
			
			String categoriesArray = obj.get("categories").toString();
			String assetAssignedTaxonomies = obj.get("assetAssignedTaxonomies").toString();
			JSONArray assetAssignedTaxonomiesArray = new JSONArray(assetAssignedTaxonomies);
			Map<Long,String> map = new HashMap<Long, String>();
			for(int i=0; i<assetAssignedTaxonomiesArray.length(); i++){
				Iterator itr = assetAssignedTaxonomiesArray.getJSONObject(i).keys();
				while (itr.hasNext()) {
					Object keyName = itr.next();
					map.put((Long)Long.parseLong(keyName.toString()),assetAssignedTaxonomiesArray.getJSONObject(i).get(keyName.toString()).toString());
				}
			}
			updateAsset.setAssetAssignedTaxonomies(map);

			//Fetching group Access for Asset
			List<Map<String, Long>> groupAccess = new ArrayList<Map<String,Long>>();
			String groupAccessForAsset = obj.get("groupAccessForAsset").toString();
			JSONArray groupAccessForAssetArray = new JSONArray(groupAccessForAsset);
			for(int i=0; i<groupAccessForAssetArray.length(); i++){
				GroupDetails gd = new GroupDetails();
				Map<String,Long> groupAccesForRow = new HashMap<String, Long>();
				JSONObject jsonObj = groupAccessForAssetArray.getJSONObject(i);
				groupAccesForRow.put("group_id", (Long)((Integer)jsonObj.getInt("group_id")).longValue());
				groupAccesForRow.put("add_access", (Long)((Integer)jsonObj.getInt("add_access")).longValue());
				groupAccesForRow.put("edit_access", (Long)((Integer)jsonObj.getInt("edit_access")).longValue());
				groupAccesForRow.put("view_access", (Long)((Integer)jsonObj.getInt("view_access")).longValue());
				groupAccesForRow.put("delete_access", (Long)((Integer)jsonObj.getInt("delete_access")).longValue());
				groupAccess.add(groupAccesForRow);
			}
			updateAsset.setGroupAccessForAsset(groupAccess);

			//fetching dragged parms for asset


			String draggedPrams = obj.get("draggedParams").toString();
			JSONArray draggedPramsJsonArray = new JSONArray(draggedPrams); 
			List<AssetParamDef> newlist = new ArrayList<AssetParamDef>();
			for(int k=0; k<draggedPramsJsonArray.length(); k++){ 
				AssetParamDef apdnew = new AssetParamDef();
				JSONObject ParamjsonObj = draggedPramsJsonArray.getJSONObject(k);
				apdnew.setAssetCategoryName(ParamjsonObj.getString("catName"));
				apdnew.setAssetParamId(ParamjsonObj.getLong("paramId"));

				newlist.add(apdnew);
			}
			updateAsset.setDraggedPramms(newlist);




			//Fetching CategoryAccess for Asset
			Map<Long, Set<GroupDetails>> categoriesWithAccess  = new HashMap<Long, Set<GroupDetails>>();
			String categoryAccess = obj.get("categoriesWithAccess").toString();
			JSONArray CatAccess = new JSONArray(categoryAccess);

			for(int i=0; i<CatAccess.length(); i++){
				Iterator itr = CatAccess.getJSONObject(i).keys();
				while (itr.hasNext()) {
					Object keyName = itr.next();
					String setOfGroupDetails = CatAccess.getJSONObject(i).get(keyName.toString()).toString();
					JSONArray GroupDetailsArray = new JSONArray(setOfGroupDetails);

					Set<GroupDetails>  groupDetails = new HashSet<GroupDetails>();

					for(int j=0; j<GroupDetailsArray.length(); j++){
						JSONObject groupDetailsjsonObj = GroupDetailsArray.getJSONObject(j);

						GroupDetails gd = new GroupDetails();
						gd.setGroupId((long)groupDetailsjsonObj.getInt("groupId"));
						gd.setMappedWithUser(groupDetailsjsonObj.getBoolean("mappedWithUser"));
						gd.setGroupName(groupDetailsjsonObj.getString("groupName"));
						gd.setCategoryName(groupDetailsjsonObj.getString("categoryName"));
						gd.setEditAccess(groupDetailsjsonObj.getLong("edit_access"));
						groupDetails.add(gd);
					}
					categoriesWithAccess.put((Long)Long.parseLong(keyName.toString()),groupDetails);
				}
			}

			updateAsset.setCategoriesWithAccess(categoriesWithAccess);

			JSONArray array = new JSONArray(categoriesArray); 
			List<Category> listOfCategories = new ArrayList<Category>();
			for(int i=0; i<array.length(); i++){ 
				Category category = new Category();
				JSONObject jsonObj = array.getJSONObject(i);
				category.setActionForCategory(jsonObj.getString("actionForCategory"));
				category.setCategoryName(jsonObj.getString("categoryName"));
				category.setCategoryAction(jsonObj.getString("categoryAction"));
				category.setDisp_position(jsonObj.getInt("disp_position"));
				updateAsset.setAssetId((long)jsonObj.getInt("AssetId"));
				updateAsset.setUserName(jsonObj.getString("userName"));
				category.setCategoryId((long)jsonObj.getInt("categoryId"));

				String parametersArray = jsonObj.get("listOfAssetParamDefs").toString();
				JSONArray parametersJsonArray = new JSONArray(parametersArray); 
				List<AssetParamDef> listOfDefs = new ArrayList<AssetParamDef>();
				for(int j=0; j<parametersJsonArray.length(); j++){ 
					AssetParamDef apd = new AssetParamDef();
					JSONObject ParamjsonObj = parametersJsonArray.getJSONObject(j);
					apd.setActionForParameter(ParamjsonObj.getString("actionForParameter"));
					apd.setAssetParamName(ParamjsonObj.getString("assetParamName"));
					apd.setDefaultView(ParamjsonObj.getInt("defaultView"));
					String paramDescription = "";
					if(globalsetting.getGlobalSettingFlag() == 1){
						paramDescription = commonUtils.httpSanitizerForPlainText(ParamjsonObj.getString("description"));
					}else{
						paramDescription = ParamjsonObj.getString("description");
					}
					apd.setDescription(paramDescription);
					//apd.setDescription(ParamjsonObj.getString("description"));
					apd.setIs_static(ParamjsonObj.getInt("is_static"));
					apd.setHasImportantValue(ParamjsonObj.getBoolean("hasImportantValue"));
					apd.setHasMandatoryValue(ParamjsonObj.getBoolean("hasMandatoryValue"));
					apd.setNotifyOnRuleValidate(ParamjsonObj.getBoolean("notifyOnRuleValidate"));
					apd.setLastUpdatedTime(new Timestamp(new Date().getTime()));
					apd.setDisplayPosition(ParamjsonObj.getInt("displayPosition"));
					apd.setListTypeParamTypeId((long)ParamjsonObj.getInt("listTypeParamTypeId"));
					apd.setParamTypeId((long)ParamjsonObj.getInt("paramTypeId"));
					apd.setHasArray(ParamjsonObj.getInt("isArray"));
					apd.setListType(ParamjsonObj.getInt("singlemultiple"));
					if(apd.getParamTypeId().toString().equals("4")){
						if(apd.getListTypeParamTypeId().toString().equals("1")){
							List<PossibleValues> listOfCustoms = new ArrayList<PossibleValues>(); 
							String customListArray = ParamjsonObj.get("custListItems").toString();
							JSONArray customArray = new JSONArray(parametersArray); 

							String[] split = customListArray.split("\n");

							for(int k=0; k<split.length; k++){ 
								PossibleValues p = new PossibleValues();
								p.setValue(split[k]);
								if(globalsetting.getGlobalSettingFlag() == 1){
									String customdata = commonUtils.httpSanitizerForPlainText(split[k]);
									p.setValue(customdata);
								}
								listOfCustoms.add(p);
							}
							apd.setCustomListValues(listOfCustoms);
						}
					}

					//assetParamId
					apd.setAssetParamId((long)ParamjsonObj.getInt("assetParamId"));
					apd.setAssetCategoryId((long)ParamjsonObj.getInt("assetCategoryId"));
					//assetCategoryId
					Integer mapedAsseId = ParamjsonObj.getInt("mappedAssetId");
					apd.setMappedAssetId(mapedAsseId.longValue()); // Long.valueOf("")

					apd.setLdapMappingId(ParamjsonObj.getInt("ldapMappingId"));
					
					apd.setModifyByUserId(((Integer)ParamjsonObj.getInt("modifyByUserId")).longValue());
					if(ParamjsonObj.getString("derivedAttributeComputation").equals("")){
						apd.setDerivedAttributeComputation(null);	
					}else{
						//System.out.println("encoder >>>>"+ParamjsonObj.getString("derivedAttributeComputation"));
						//String decoder =  URLDecoder.decode(ParamjsonObj.getString("derivedAttributeComputation"),"UTF-8");
						//System.out.println("decoder>>>>"+decoder);
						apd.setDerivedAttributeComputation(ParamjsonObj.getString("derivedAttributeComputation"));
					}
					
					if(ParamjsonObj.getString("derivedAssetListRule").equals("")) {
						apd.setDerivedAssetListRule(null);
					}else {
						apd.setDerivedAssetListRule(ParamjsonObj.getString("derivedAssetListRule"));
					}
					apd.setParamTypeId((long)ParamjsonObj.getInt("paramTypeId"));
					apd.setSize(ParamjsonObj.getInt("size"));
					listOfDefs.add(apd);

				}
				category.setListOfAssetParamDefs(listOfDefs);
				listOfCategories.add(category);
			}
			updateAsset.setCategories(listOfCategories);
			
			//TODO: Asset Visualization
			String assetRepresentionJson = obj.get("assetVisualization").toString();
			JSONArray assetRepresentionArray = new JSONArray(assetRepresentionJson);
			JSONObject assetRepresentionObj = assetRepresentionArray.getJSONObject(0);
			String representationName = assetRepresentionObj.getString("AssetrepName");
			if(!representationName.isEmpty() && !representationName.equalsIgnoreCase("")){
				AssetRepresentation assetRep = new AssetRepresentation();
				assetRep.setRepresentationName(representationName);
				updateAsset.setAssetRepresentation(assetRep);
			} else {
				updateAsset.setAssetRepresentation(null);
			}

		}catch(org.json.JSONException e){
			e.printStackTrace();
		}

		if(updateAsset == null) {
			log.warn("updateAsset || Asset data to be updated not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, 
							MessageUtil.getMessage(Constants.INVALID_REQUEST)))
							.build();
		}else{
			if(log.isTraceEnabled()){
				log.trace("updateAsset || "+ updateAsset+" Begin");
			}
			Connection conn = null;
			List<String> result = new ArrayList<String>();
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			RelationshipDao relationshipDao = new RelationshipDao();
			User user = new User();
			String action = Constants.ACTIVITY_MODIFY;
			RecentActivity recentActivity = new RecentActivity();
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			FavouritesDao favouritesDao = new FavouritesDao();
			WorkflowDao workflowDao = new WorkflowDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			InputStream fileInverted = null;
			try {
				if (log.isTraceEnabled()) {
					log.trace("updateAsset || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("updateAsset || dao method called : getAssetDefByAssetId() "+updateAsset.getAssetId());
				}
				AssetDef oldAssetDef = dao.getAssetsByAssetId(updateAsset.getAssetId(), conn);

				boolean flagForDuplicateAsset = false;

				GroupDao groupDao = new GroupDao();
				String jsonRslt;
				List<String> jsonList = new ArrayList<String>();

				List<AssetDef> assetDefList = new ArrayList<AssetDef>();

				if (log.isTraceEnabled()) {
					log.trace("addAsset || dao method called : getAllAssets()");
				}
				assetDefList = dao.getAllAssets(conn);
				if(!oldAssetDef.getAssetName().equalsIgnoreCase(updateAsset.getAssetName().trim()))
					for(AssetDef list : assetDefList){
						if(list.getAssetName().equalsIgnoreCase(updateAsset.getAssetName().trim())){
							flagForDuplicateAsset = true;
							break;
						}
					}
				if(flagForDuplicateAsset == true){
					log.warn("Update || Asset by this name already exists, please provide different name");
					result.add("Asset by this name already exists, please provide different name");

					jsonRslt = Constants.ASSET_NAME_EXIST;	
					jsonList.add(jsonRslt);

					return Response
							.status(Status.OK)
							.entity(new MyModel(Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE, MessageUtil
									.getMessage(Constants.ASSET_NAME_EXIST), new ArrayList<Object>(jsonList)))
									.build();
				}
				String oldAssetName = oldAssetDef.getAssetName();
				String newAssetName = updateAsset.getAssetName();

				Long assetId = updateAsset.getAssetId();
				if (bodyParts != null) {
					dataMultiPart = bodyParts.getField("iconImageName1");
					if(dataMultiPart != null){
						NewFileName = dataMultiPart.getContentDisposition()
								.getFileName();
						if (!NewFileName.isEmpty()|| NewFileName.length() != 0) {
							
							InvertImage invertImage = new InvertImage();
							fileInverted = invertImage.inverImage(dataMultiPart
									.getEntityAs(InputStream.class), dataMultiPart
									.getContentDisposition().getFileName());
							//InputStream targetStream = new FileInputStream(file);
							updateAsset.setIconImage(dataMultiPart
									.getEntityAs(InputStream.class));
							updateAsset.setIconImageName(NewFileName);
							updateAsset.setInvertedIconImage(fileInverted);
						}
						if(NewFileName.equals("")||NewFileName.length() == 0){
							AssetDef ad1 = dao.getFileNameByAssetId(assetId, conn);
								updateAsset.setIconImageName(ad1.getIconImageName());
								updateAsset.setIconImage(ad1.getIconImage());
								updateAsset.setInvertedIconImage(ad1.getInvertedIconImage());
							}
					}
				}

				dao.updateAsset(updateAsset, conn);
				List<Category> listOfCategories1 = updateAsset.getCategories();
				if(listOfCategories1==null){
					retMsg = "We can not create asset with out categories";
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
							.build(); 

				}

				if(listOfCategories1.size()==0){
					retMsg = "We can not create asset with out categories";
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
							.build(); 
				}

				Map<String, String> changedParamNames = new HashMap<String, String>();
				List<String> delCatName = new ArrayList<String>();
				List<Long> catID = new ArrayList<Long>();
				List<AssetParamDef> apf = new ArrayList<AssetParamDef>();
				List<AssetParamDef> listofDefs = dao.getCategoryNameAndParametersByAssetId(assetId, conn);
				for(int i=0;i<listOfCategories1.size();i++){
					Category category = listOfCategories1.get(i);
					String actionForCategory = category.getActionForCategory();
					/*for(int ll=0;i<listofDefs.size();ll++){
						AssetParamDef assetParam  =listofDefs.get(ll);

					}*/
					if(actionForCategory!=null){
						if(actionForCategory.equalsIgnoreCase("DELETE")){//deletion category
							delCatName.add(category.getCategoryName());
							Map<Long, Set<GroupDetails>> catWiseAccess = updateAsset.getCategoriesWithAccess();
							catWiseAccess.remove(category.getCategoryId());

							apf = category.getListOfAssetParamDefs();
							catID.add(category.getCategoryId());
							/*List<AssetParamDef> paramdefs =category.getListOfAssetParamDefs();
							for (AssetParamDef assetParamDef : paramdefs) {
								if (log.isTraceEnabled()) {
									log.trace("updateAsset || dao method called : deleteParameter() "+updateAsset.getAssetId());
								}
								dao.deleteParameter(assetParamDef.getAssetParamId(), conn);
							}
							if (log.isTraceEnabled()) {
								log.trace("updateAsset || dao method called : deleteCategory() "+category.getCategoryId());
							}
							dao.deleteCategory(category.getCategoryId(), conn);*/
						}
						else if(actionForCategory.equalsIgnoreCase("ADD")){//adding category
							if (log.isTraceEnabled()) {
								log.trace("updateAsset || dao method called : addCategory() category "+category +" assetid "+assetId);
							}


							//Map<Long, Set<GroupDetails>> catWiseAccess = updateAsset.getCategoriesWithAccess();

							Long assetCategoryId = dao.addCategory(category, assetId, conn);

							// default check of group admin for category

							List<GroupDetails> groupDetailsBos = groupDao.getAllGroups(conn);
							for(GroupDetails groupDetailsBo : groupDetailsBos){
								if(groupDetailsBo.getGroupName().equalsIgnoreCase("group-admin")){
									if (log.isTraceEnabled()) {
										log.trace("addCategoryDefinition || dao method called : addCategoryWiseAccessForAsset() ");
									}
									dao.addCategoryWiseAccessForAsset(assetCategoryId, groupDetailsBo.getGroupId(), conn);
								}
							}

							List<AssetParamDef> paramdefs = category.getListOfAssetParamDefs();
							for (AssetParamDef assetParamDef : paramdefs) {
								assetParamDef.setAssetCategoryId(assetCategoryId);
								if (log.isTraceEnabled()) {
									log.trace("updateAsset || dao method called : addParameter() "+assetParamDef);
								}

								if (assetParamDef.getActionForParameter()
										.equalsIgnoreCase("NO CHANGES")) {

									dao.UpdateParameterDragged(assetParamDef,
											conn);
								}
								if (assetParamDef.getActionForParameter()
										.equalsIgnoreCase("ADD")) {
									int paramId = dao.addParameter(assetParamDef, conn);
									if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){

										List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
										for (PossibleValues possibleValues : customListValues) {
											dao.insertPossibleValues((long)paramId, possibleValues.getValue(), conn);
										}
									}
								}
							}
						}
						else if(actionForCategory.equalsIgnoreCase("UPDATE")){

							List<AssetParamDef> paramDefs = category.getListOfAssetParamDefs();
							if (log.isTraceEnabled()) {
								log.trace("updateAsset || dao method called : getAllDerivedAttributes() ");
							}

							List<AssetParamDef> allDerivedAttributes = dao.getAllDerivedAttributes(conn);	
							dao.updateCategory(category, assetId, conn);
							for (AssetParamDef assetParamDef : paramDefs) {

								String actionForParameter = assetParamDef.getActionForParameter();
								AssetParamDef backendParamDef = dao.getAssetParamDefByAssetParamId(assetParamDef.getAssetParamId(), conn);
								changedParamNames.put(backendParamDef.getAssetParamName(),assetParamDef.getAssetParamName());
								if(actionForParameter!=null){
									if(actionForParameter.equalsIgnoreCase("NO CHANGES"))
									{
										if (log.isTraceEnabled()) {
											log.trace("updateAsset || dao method called : UpdateParameterDragged() "+assetParamDef.toString());
										}
										
										// commented updateParameterDefinition for drag and drop issue .
										int paramId = dao.updateParameterDefinition(assetParamDef, conn);
										//dao.UpdateParameterDragged(assetParamDef, conn);

										/*

									if (log.isTraceEnabled()) {
										log.trace("updateAsset || dao method called : deleteParameter() "+assetParamDef.getAssetParamId());
									}
									int paramId = dao.deleteParameter(assetParamDef.getAssetParamId(), conn);
									if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){
										List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
										for (PossibleValues possibleValues : customListValues) {
											dao.deletePossibleValues((long)paramId,conn);
										}
									}
									assetParamDef.setAssetCategoryId(category.getCategoryId());
									if (log.isTraceEnabled()) {
										log.trace("updateAsset || dao method called : addParameter() "+assetParamDef);
									}
									int paramId1=dao.addParameter(assetParamDef, conn);
									if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){
										List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
										for (PossibleValues possibleValues : customListValues) {
											dao.insertPossibleValues((long)paramId1, possibleValues.getValue(), conn);
										}
									}

										 */
									}

									if(actionForParameter.equalsIgnoreCase("UPDATE")){

										/*	for (AssetParamDef derivedDef : allDerivedAttributes) {

											if(derivedDef.getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){
												Long parameterID = assetParamDef.getAssetParamId();
												if (log.isTraceEnabled()) {
													log.trace("updateAsset || dao method called : getAssetParamDefByAssetParamId() "+parameterID);
												}
												AssetParamDef backendParamDef = dao.getAssetParamDefByAssetParamId(parameterID, conn);
												Long assetParamId  = backendParamDef.getAssetParamId();
												Pattern  p = Pattern.compile(oldAssetDef.getAssetName()+"[\\{]"+backendParamDef.getAssetParamName()+"[\\}]");
												String rule = derivedDef.getDerivedAttributeComputation();
												Matcher m = p.matcher(rule);
												boolean flagForParameterCheck = false;

												rule = rule.replaceAll("[\\}](ELSE )(?i)"+oldAssetName+"[\\[]", "}ELSE "+newAssetName+"[");
												rule = rule.replaceAll("(?i)"+oldAssetName+"[\\[]", newAssetName+"[");
												rule = rule.replaceAll("[\\]](?i)"+oldAssetName+"[\\[]","]"+newAssetName+"[");
												rule = rule.replaceAll("[\\[](?i)"+oldAssetName+"[\\.]", "["+newAssetName+".");
												rule = rule.replaceAll("[\\]](?i)"+oldAssetName+"[\\{]", "]"+newAssetName+"{");

												if(m.find()){
													rule = rule.replaceAll("[\\{](?i)"+oldAssetName+"[\\}]", "{"+newAssetName+"}");
													flagForParameterCheck = true;
												}
												boolean flagForAssetNameChecking =  oldAssetName.equalsIgnoreCase(newAssetName);
												if(flagForAssetNameChecking){
													flagForAssetNameChecking = false;
												}

												if( flagForAssetNameChecking || flagForParameterCheck){
													if (log.isTraceEnabled()) {
														log.trace("updateAsset || dao method called : modifingRuleById() "+parameterID);
													}
													dao.modifingRuleById(assetParamId, rule, conn);
												}
											}else if(derivedDef.getParamTypeId().equals(Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID)){
												Long parameterID = assetParamDef.getAssetParamId();
												if (log.isTraceEnabled()) {
													log.trace("updateAsset || dao method called : getAssetParamDefByAssetParamId() "+parameterID);
												}
												AssetParamDef backendParamDef = dao.getAssetParamDefByAssetParamId(parameterID, conn);
												Long assetParamId  = backendParamDef.getAssetParamId();
												String rule = derivedDef.getDerivedAttributeComputation();
												Pattern  p = Pattern.compile(backendParamDef.getAssetParamName()+"==");
												boolean flagForDerivedComputationCheck = false;

												Matcher m = p.matcher(rule);
												if(m.find()){
													rule = rule.replaceAll(backendParamDef.getAssetParamName()+"==",assetParamDef.getAssetParamName()+"==");
													flagForDerivedComputationCheck = true;
												}

												boolean flagForAssetNameChecking =  oldAssetName.equalsIgnoreCase(newAssetName);

												if(flagForAssetNameChecking){
													flagForAssetNameChecking = false;
												}
												rule = rule.replaceAll("(?i)"+oldAssetName+"[\\[]", newAssetName+"[");
												rule = rule.replaceAll("(ELSE )(?i)"+oldAssetName+"[\\[]", "ELSE "+newAssetName+"[");
												rule = rule.replaceAll("[\\]](?i)"+oldAssetName+"[\\[]", "]"+newAssetName+"[");
												rule = rule.replaceAll("[\\[](?i)"+oldAssetName+"[\\.]", "["+newAssetName+".");
												rule = rule.replaceAll("[\\]](?i)"+oldAssetName+".count", "]"+newAssetName+".count");

												if(flagForAssetNameChecking || flagForDerivedComputationCheck){
													if (log.isTraceEnabled()) {
														log.trace("updateAsset || dao method called : modifingRuleById() "+parameterID);
													}
													dao.modifingRuleById(assetParamId, rule, conn);
												}

											}
										}*/
										assetParamDef.setAssetCategoryId(category.getCategoryId());

										if((backendParamDef.getIs_static() == assetParamDef.getIs_static())){

											if (log.isTraceEnabled()) {
												log.trace("updateAsset || dao method called : updateParameterDefinition() "+assetParamDef);
											}

											int paramId = dao.updateParameterDefinition(assetParamDef, conn);

										}else{
											if (log.isTraceEnabled()) {
												log.trace("updateAsset || dao method called : updateParameter() "+assetParamDef);
											}
											int paramId = dao.updateParameter(assetParamDef, conn);
										}

										//int paramId = dao.updateParameter(assetParamDef, conn);// satic values empty whn parameter update
										if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){

											dao.deletePossibleValues((long)assetParamDef.getAssetParamId(),conn);

											List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
											for (PossibleValues possibleValues : customListValues) {
												//dao.updatePossibleValues((long)assetParamDef.getAssetParamId(), possibleValues.getValue(), possibleValues.getValueId(), conn);
												dao.insertPossibleValues((long)assetParamDef.getAssetParamId(), possibleValues.getValue(), conn);
											}
										}
									}else if (actionForParameter.equalsIgnoreCase("DELETE")) {
										if (log.isTraceEnabled()) {
											log.trace("updateAsset || dao method called : deleteParameter() "+assetParamDef.getAssetParamId());
										}
										int paramId = dao.deleteParameter(assetParamDef.getAssetParamId(), conn);
										if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){
											List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
											for (PossibleValues possibleValues : customListValues) {
												dao.deletePossibleValues((long)assetParamDef.getAssetParamId(),conn);
											}
										}
									}else if(actionForParameter.equalsIgnoreCase("ADD")){
										assetParamDef.setAssetCategoryId(category.getCategoryId());
										if (log.isTraceEnabled()) {
											log.trace("updateAsset || dao method called : addParameter() "+assetParamDef);
										}
										int paramId=dao.addParameter(assetParamDef, conn);
										if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){
											List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
											for (PossibleValues possibleValues : customListValues) {
												dao.insertPossibleValues((long)paramId, possibleValues.getValue(), conn);
											}
										}
									}
								}
							}
						}
					}
				}

				//delete cat and parameter 
				for(Long Categoryid :catID){
				for (AssetParamDef assetParamDef : apf) {
					if (log.isTraceEnabled()) {
						log.trace("updateAsset || dao method called : deleteParameter() "+updateAsset.getAssetId());
					}
					dao.deleteParameter(assetParamDef.getAssetParamId(), conn);
				}
				if (log.isTraceEnabled()) {
					log.trace("updateAsset || dao method called : deleteCategory() "+Categoryid);
				}
				dao.deleteCategory(Categoryid, conn);
				}
				
				//drag and drop 
				Boolean delFlag ;
				if (updateAsset.getDraggedPramms() != null){

					List<AssetParamDef> newlist1 = new ArrayList<AssetParamDef>();
					newlist1 = updateAsset.getDraggedPramms();
					for(AssetParamDef aa:newlist1 ){
						 delFlag = false;
						for(String delCat : delCatName){
							if(aa.getAssetCategoryName().equalsIgnoreCase(delCat)){
								delFlag = true;
								break;
							}
						}
						if(!delFlag){
						Long catId = dao.getCatgoryIdByCatNameAndAssetId(aa.getAssetCategoryName(),updateAsset.getAssetId(),conn);
						aa.setAssetCategoryId(catId);
						dao.UpdateParameterDragged(aa, conn);
						}
					}
				}

				List<AssetParamDef> listofDefs1 = relationshipDao.getAssetParamDefByDerivedAttributeIsNotNull(conn);
				// List<AssetParamDef> listofDefs1 = dao.getCategoryNameAndParametersByAssetId(assetId, conn);

				for (int k = 0; k < listofDefs1.size(); k++) {

					AssetParamDef def = listofDefs1.get(k);
					String rules1 = def.getDerivedAttributeComputation();


					for (Map.Entry<String, String> entry : changedParamNames.entrySet()){
						if(def.getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){
							String[] rules = rules1.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\]]");
							for (int i = 0; i < rules.length; i++) {
								if(rules[i].startsWith("IF")){
									rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");
								}else if(rules[i].startsWith("ELSE IF")){
									rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");

								}
							}

						}

					}

					for (Map.Entry<String, String> entry : changedParamNames.entrySet()){

						if(def.getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){

							String[] rules = rules1.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\]]");
							for (int i = 0; i < rules.length; i++) {
								if(rules[i].startsWith("IF")){
									rules1 = rules1.replaceAll(oldAssetName+"[\\{](?i)"+entry.getKey()+"[\\}]", newAssetName+"{"+entry.getValue()+"}");
								}else if(rules[i].startsWith("ELSE IF")){
									rules1 = rules1.replaceAll(oldAssetName+"[\\{](?i)"+entry.getKey()+"[\\}]", newAssetName+"{"+entry.getValue()+"}");

								}else if(rules[i].startsWith("ELSE")){
									rules1 = rules1.replaceAll(oldAssetName+"[\\{](?i)"+entry.getKey()+"[\\}]", newAssetName+"{"+entry.getValue()+"}");
								}else{
									rules1 = rules1.replaceAll(oldAssetName+"[\\{](?i)"+entry.getKey()+"[\\}]", newAssetName+"{"+entry.getValue()+"}");
								}
							}
						}

					}

					for (Map.Entry<String, String> entry : changedParamNames.entrySet()){
						if(def.getParamTypeId().equals(Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID)){
							String[] rules = rules1.split("\\.count");
							for (int i = 0; i < rules.length; i++) {
								if(rules[i].startsWith("IF")){
									rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");
								}else if(rules[i].startsWith("ELSE IF")){
									rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");
								}
							}

						}

					}

					// ("Before : "+rules1);
					for (Map.Entry<String, String> entry : changedParamNames.entrySet()){
						// (entry.getKey() + "/" + entry.getValue());
						if(def.getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){



							/*if(!oldAssetName.equalsIgnoreCase(newAssetName))
								rules1 = rules1.replaceAll("[\\{](?i)"+entry.getKey()+"[\\}]", "{"+entry.getValue()+"}");*/

							rules1 = rules1.replaceAll("[\\}](ELSE )(?i)"+oldAssetName+"[\\[]", "}ELSE "+newAssetName+"[");
							rules1 = rules1.replaceAll("(?i)"+oldAssetName+"[\\[]", newAssetName+"[");
							rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+"[\\[]","]"+newAssetName+"[");
							rules1 = rules1.replaceAll("[\\[](?i)"+oldAssetName+"[\\.]", "["+newAssetName+".");
							rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+"[\\{]", "]"+newAssetName+"{");
						}
						if(def.getParamTypeId().equals(Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID)){
							/*if(!oldAssetName.equalsIgnoreCase(newAssetName))
								rules1 = rules1.replaceAll("(?i)[\\.]"+entry.getKey()+"[\\=]", "."+entry.getValue()+"=");*/
							//rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");
							rules1 = rules1.replaceAll("(?i)"+oldAssetName+"[\\[]", newAssetName+"[");
							rules1 = rules1.replaceAll("(ELSE )(?i)"+oldAssetName+"[\\[]", "ELSE "+newAssetName+"[");
							rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+"[\\[]", "]"+newAssetName+"[");
							rules1 = rules1.replaceAll("[\\[](?i)"+oldAssetName+"[\\.]", "["+newAssetName+".");
							rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+".count", "]"+newAssetName+".count");
						}


					}
					//def.setDerivedComputedDescription(rules1);
					// ("After : "+rules1);
					//parameterDefController.updateParamDefRule(def);

					dao.modifingRuleById(def.getAssetParamId(), rules1, conn);
				}
				
				List<AssetParamDef> assetParamDefs = dao.getAllDerivedAttributeForAssetList(conn);
				for(int i=0;i<assetParamDefs.size();i++) {
					
					AssetParamDef def = assetParamDefs.get(i);
					String rules1 = def.getDerivedAssetListRule();
					
					for (Map.Entry<String, String> entry : changedParamNames.entrySet()) {
						if(def.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
							rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\[]"+entry.getKey()+"[\\]]", newAssetName+"["+entry.getValue()+"]");
							//rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\[]"+entry.getKey()+"[\\]]", oldAssetName+"["+entry.getValue()+"]");
							rules1 = rules1.replaceAll(oldAssetName+"[\\{](?i)"+entry.getKey()+"[\\}]", newAssetName+"{"+entry.getValue()+"}");
						}
					}
					
					/*for (Map.Entry<String, String> entry : changedParamNames.entrySet()) {
						if(def.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
							rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\[]"+entry.getKey()+"[\\]]", newAssetName+"["+entry.getValue()+"]");
							rules1 = rules1.replaceAll("(?i)[\\[]"+entry.getKey()+"[\\]]", "["+entry.getValue()+"]");
						}
					}
					
					for (Map.Entry<String, String> entry : changedParamNames.entrySet()) {
						if(def.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
							rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\[]"+entry.getKey()+"[\\]]", newAssetName+"["+entry.getValue()+"]");
							rules1 = rules1.replaceAll("(?i)[\\[]"+entry.getKey()+"[\\]]", "["+entry.getValue()+"]");
						}
					}*/
					
					for (Map.Entry<String, String> entry : changedParamNames.entrySet()) {
						if(def.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
							rules1 = rules1.replaceAll("(?i)"+oldAssetName+"[\\[]", newAssetName+"[");
							rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+"[\\[]","]"+newAssetName+"[");
							rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+"[\\{]", "]"+newAssetName+"{");
						}
					}
					dao.modifyingDerivedAssetListRuleById(rules1,def.getAssetParamId(),conn);
				}
				
				
				
				
				//adding assigned group access for asset 

				groupDao.addGroupsAssetAccessSubmit(assetId, updateAsset.getGroupAccessForAsset(), conn);

				// adding assigned taxonomies
				TaxonomiesDao tdao = new TaxonomiesDao();
				tdao.addassignedTaxonomies(assetId, updateAsset.getAssetAssignedTaxonomies(), conn);

				//add categorywiseaccessfor groups by categoryId
				List<Category> categories = updateAsset.getCategories();

				for (int k = 0; k < categories.size(); k++) {
					Category cat = categories.get(k);
					if(!(cat.getActionForCategory().equalsIgnoreCase("ADD")||cat.getActionForCategory().equalsIgnoreCase("DELETE"))){
						if(!cat.getCategoryName().equalsIgnoreCase("DUMMY_CATEGORY")){
							Map<Long, Set<GroupDetails>> selectedGroups = updateAsset.getCategoriesWithAccess();
							Set<GroupDetails> groupDetails = selectedGroups.get(cat.getCategoryId());
							Map<Long,String> map1 = new HashMap<Long, String>();
							Iterator<GroupDetails> itr = groupDetails.iterator();
							while(itr.hasNext()){
								GroupDetails gd = itr.next();
								if(gd.isMappedWithUser()){
									map1.put(gd.getGroupId(),gd.getEditAccess().toString());
								}
							}
							dao.addCategoryWiseAccessForGroups(cat.getCategoryId(),map1 , conn);
						}
					}
				}
				// conn.commit();
				/*if(NewFileName != null) {
					if(!NewFileName.equals("")){
						BufferedImage image = null;
						image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
						if(image!=null){
							String uploadedFileLocation = request.getRealPath("");
							if (NewFileName.toLowerCase().indexOf("jpg".toLowerCase()) != -1
									|| NewFileName.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
								uploadedFileLocation = uploadedFileLocation
										+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
								ImageIO.write(image, "jpg", new File(
										uploadedFileLocation));
								//inverted 
								uploadedFileLocation = uploadedFileLocation
										+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
								ImageIO.write(image, "jpg", new File(
										uploadedFileLocation));
								
								
							} else if (NewFileName.toLowerCase().indexOf("png".toLowerCase()) != -1 || NewFileName.toUpperCase().indexOf(
									"png".toUpperCase()) != -1) {
								uploadedFileLocation = uploadedFileLocation
										+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
								ImageIO.write(image, "png", new File(uploadedFileLocation));
							}
						}	
					}
				}*/
				if(NewFileName != null) {
					if(!NewFileName.equals("")){
						BufferedImage image = null;
						BufferedImage invertedImage = null;
						image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
						int ik = updateAsset.getIconImageName().lastIndexOf('.');
						if (ik > 0) {
							extension = updateAsset.getIconImageName().substring(ik+1);
						}
						
						InputStream newImg = new FileInputStream(System.getProperty("user.home") +"/inverted_new."+extension);
						invertedImage = ImageIO.read(newImg);
						
						File deletedFile1 = new File(System.getProperty("user.home")+"/inverted_new."+extension);
						if(deletedFile1.exists()) {
							deletedFile1.delete();
						}
						
						if(image!=null){
							String uploadedFileLocation = request.getRealPath("");
							String uploadedInvertedFileLocation = request.getRealPath("");
							String serverPath = request.getRealPath("");
							
							if (NewFileName.toLowerCase().indexOf("jpg".toLowerCase()) != -1
									|| NewFileName.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
								uploadedFileLocation = uploadedFileLocation
										+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
								
								//To delete existing
								File originalFile = new File(serverPath
										+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME);
								
							//	File originalFile = new File(uploadedFileLocation);
								if(originalFile.exists()){
									originalFile.delete();
								}
								
								ImageIO.write(image, "jpg", new File(
										uploadedFileLocation));
								
								//inverted images
								if(invertedImage != null) {
									uploadedInvertedFileLocation = uploadedInvertedFileLocation
											+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
									
									File originalFileInverted = new File(serverPath
											+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+updateAsset.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME);
									
									//File originalFileInverted = new File(uploadedInvertedFileLocation);
									if(originalFileInverted.exists()){
										originalFileInverted.delete();
									}
									
									ImageIO.write(invertedImage, "jpg", new File(
											uploadedInvertedFileLocation));
								}

							} else if (NewFileName.toLowerCase().indexOf("png".toLowerCase()) != -1 || NewFileName.toUpperCase().indexOf(
									"png".toUpperCase()) != -1) {
								uploadedFileLocation = uploadedFileLocation
										+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
								//To delete existing
								File originalFile = new File(serverPath
										+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME);
								if(originalFile.exists()){
									originalFile.delete();
								}
								ImageIO.write(image, "png", new File(uploadedFileLocation));
								
								//inverted images
								if(invertedImage != null) {
									uploadedInvertedFileLocation = uploadedInvertedFileLocation
											+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+updateAsset.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
									
									//To delete existing
									File originalFileInverted = new File(serverPath
											+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME);
									if(originalFileInverted.exists()){
										originalFileInverted.delete();
									}
									ImageIO.write(invertedImage, "png", new File(uploadedInvertedFileLocation));

								}
							}
						}	
					}
				}
				
				//TODO: Asset Visualization
				if (updateAsset.getAssetRepresentation() != null) {
					AssetRepresentationDao repDao = new AssetRepresentationDao();
					AssetRepresentation assetRepDb = repDao.getAssetRepresentationByName(conn, updateAsset.getAssetRepresentation().getRepresentationName());
					
					if (assetRepDb != null){
						AssetRepresentation assetRep = repDao.getAssetRepresentationByAssetName(conn, updateAsset.getAssetName());
						if (assetRep != null) {
							if (assetRep.getAssetRepresentationId() != assetRepDb.getAssetRepresentationId()) {
								repDao.deleteRepresentationOnChangeInAsset(updateAsset.getAssetName(), conn);
								repDao.deleteAssetRepresentationLink(updateAsset.getAssetId(), assetRep.getAssetRepresentationId(), conn);								
								repDao.addAssetRepresentationLink(updateAsset.getAssetId(), assetRepDb.getAssetRepresentationId(), conn);
							}
						} else {
							repDao.addAssetRepresentationLink(updateAsset.getAssetId(), assetRepDb.getAssetRepresentationId(), conn);
						}						
					} else {
						retMsg = Constants.INVALID_ASSET_REPRESENTATION;
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;
						return Response
								.status(retStat)
								.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
								.build();
					}
				}
				
				
				/*if (log.isTraceEnabled()) {
					log.trace("updateAsset || dao method called : getAllDerivedAttributes()");
				}*/
				retMsg = Constants.ASSET_UPDATED;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				log.info("updateAsset || " + updateAsset.toString() + " updated asset successfully");
				conn.commit();

				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				List<String> emailIds = new ArrayList<String>();

				UserDao userDao = new UserDao();
				SubscriptionDao subscriptionDao = new SubscriptionDao();

				user = userDao.retProfileForUserName(updateAsset.getUserName(), conn);
				emailIds = subscriptionDao.getSubscribersForAsset(updateAsset.getAssetId(), conn);

				if(!emailIds.isEmpty()){
					String mailTemp = "";
					MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetType");
					mailTemp = mtVo.getMailTemplate();
					mailTemp = mailTemp.replaceAll("%assetType%", updateAsset.getAssetName());

					for(String emailId:emailIds){
						MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);

						SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_TYPE_DETAILS_UPDATED), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

					}
				}

				String log1 = user.getFullName() + ";" + action + ";"+ updateAsset.getAssetName() + ";"+ "" + ";"+ "";
				recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				recentActivity.setDescription(log1);
				recentActivity.setAssetId(updateAsset.getAssetId().toString());
				recentActivity.setAssetInstVersionId("");
				recentActivity.setUser_id(user.getUserId());

				if (log.isTraceEnabled()) {
					log.trace("updateAsset || dao method called : addRecentActivity() ");
				}
				recentActivityDao.addRecentActivity(recentActivity, conn);

				favouritesDao.OnRenameAssetRenameFavourites(oldAssetName, newAssetName, conn);
				
				if(oldAssetDef.getEnableWorkflow() == true) {
					if(updateAsset.getEnableWorkflow() == false) {
						List<AssetInstance> instancesList = assetInstanceDao.
								getAllAssetInstancesForAsset(updateAsset.getAssetId(), conn);
						for(AssetInstance ai : instancesList) {
							workflowDao.deleteAssetInstanceLinkFromWorkflow(ai.getAssetInstVersionId(), conn);
						}
					}
				}

				conn.commit();
				/*File deletedFile = new File(System.getProperty("user.home")+"/inverted_new."+extension);
				if(deletedFile.exists()) {
					deletedFile.delete();
				}
				File deleteOrigialFile = new File(System.getProperty("user.home")+"/"+"inverted"+"."+extension);
				if(deleteOrigialFile.exists()) {
					deleteOrigialFile.delete();
				}
*/
				File deletedFile = new File(System.getProperty("user.home")+"/inverted_new."+extension);
				//System.out.println("deletedFile::" +deletedFile.getAbsolutePath());
				if(deletedFile.exists()) {
					deletedFile.delete();
				}
				File deleteOriginalFile = new File(System.getProperty("user.home")+"/inverted."+extension);
			//	System.out.println("deleteOrigialFile::" +deleteOriginalFile.getAbsolutePath());
				if(deleteOriginalFile.exists()) {
					deleteOriginalFile.delete();
				}	
				
				File deletedFile1 = new File(System.getProperty("user.home")+"/inverted_new."+extension);
			//	System.out.println("deletedFile1::" +deletedFile1.getAbsolutePath());
				if(deletedFile1.exists()) {
					deletedFile1.delete();
				}
				
			} catch(RepoproException e){
				log.error("updateAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch(Exception e){
				log.error("updateAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateAsset || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if(log.isTraceEnabled()){
				log.trace("updateAsset || "+ updateAsset.toString() +" End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(result)))
					.build();
		}
	}

	/**
	 * @method getPossibleValuesForAsset
	 * @description to return possible values 
	 * @param assetId
	 * @param assetParamId
	 * @return success response
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getPossibleValues")
	public Response getPossibleValuesForAsset(
			@QueryParam("assetId") long assetId,
			@QueryParam("assetParamId") String assetParamId)  {
		if (log.isTraceEnabled()) {
			log.trace("getPossibleValuesForAsset ||assetId:" + assetId
					+ ",assetId:" + assetId + ",assetParamId:" + assetParamId
					+ "||Begin");
		}
		Connection conn = null;
		List<PossibleValues> possibleValuesList = new ArrayList<PossibleValues>();
		PossibleValues finalValues = null;
		AssetDao assetDao = new AssetDao();
        List<PossibleValues> possibleValues = new ArrayList<PossibleValues>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForAsset || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForAsset || dao method called : getPossibleValuesForAsset()");
			}
		    String[] assetparamIds	= assetParamId.split("~~");
			
			for (String ParamIds : assetparamIds) {
				StringBuffer sb = new StringBuffer();
				finalValues = new PossibleValues();
				Long ParamId = Long.valueOf(ParamIds);

				possibleValues = assetDao.getPossibleValuesForAsset(assetId,ParamId, conn);
				for (PossibleValues pvList : possibleValues) {
					sb.append(pvList.getValue() + "~~");
					if(pvList.getListType() == 0)
						finalValues.setMultiSelectFlag(true);	//single
					if(pvList.getListType() == 1)
						finalValues.setMultiSelectFlag(false);	//multiple
				}
				String str = sb.toString();
				str = str.substring(0, str.length() - 2);

				finalValues.setAssetParamId(ParamId);
				finalValues.setValue(str);
				possibleValuesList.add(finalValues);
			}
			
			if (log.isInfoEnabled()) {
				log.info(" getPossibleValuesForAsset || retrieved "
						+ possibleValues.size()
						+ " getPossibleValuesForAsset search data successfully");
			}
		} catch (RepoproException e) {
			log.error("getPossibleValuesForAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getPossibleValuesForAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForAsset || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (possibleValues.isEmpty()) {
			retMsg = MessageUtil.getMessage(Constants.GET_POSSIBLE_VALUES_NOT_FOUND);
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} else {
			retMsg = MessageUtil.getMessage(Constants.GET_POSSIBLE_VALUES_DATA_FETCHED);
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		if (log.isTraceEnabled()) {
			log.trace("getPossibleValuesForAsset ||assetId:" + assetId
					+ ",asssetParamIs:" + assetParamId + "|| End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(possibleValuesList))).build();
	}
	/**
	 * @method getCategoryAccessByAssetId
	 * @description get category access
	 * @param assetId
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/CategoryaccessbyAssetid")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getCategoryAccessByAssetId(@QueryParam("assetId") Long assetId)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getCategoryAccessByAssetId || assetId" + assetId + "||Begin");
		}
		AssetDao d = new AssetDao();
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Map<Long,Set<GroupDetails>> details = new LinkedHashMap<Long, Set<GroupDetails>>();
		GroupDao gd = new GroupDao();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getCategoryAccessByAssetId || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);


			if (log.isTraceEnabled()) {
				log.trace("getCategoryAccessByAssetId || dao method called : getCategoriesByassetId()");
			}
			GroupDao groupDao = new GroupDao();
			List<GroupDetails> allGroups = groupDao.getAllGroups(conn);

		//	if(allGroups.size()>=3){
				Map<Long, List<String>> checkedGroupDetails = d.getCheckedGroupDetailsByAssetId(assetId, conn);


				if(checkedGroupDetails.size()!=0){

					Map<Long,String> values = d.getCheckedGroupDetailsByAssetIdWithCategories(assetId,conn);

					List<Long> list = new ArrayList<Long>(checkedGroupDetails.keySet());
					if(checkedGroupDetails.size()!=0){
						for(int i = 0;i<checkedGroupDetails.keySet().size();i++){
							Set<GroupDetails> listOfGds = new LinkedHashSet<GroupDetails>();
							Long categoryId =list.get(i);
							List<String> groups = checkedGroupDetails.get(categoryId);
							for(int j=0;j<allGroups.size();j++){
								boolean flag =false;
								for(int k=0;k<groups.size();k++){
									GroupDetails groupDetailsMapped = new GroupDetails();
									if(groups.get(k).equalsIgnoreCase(allGroups.get(j).getGroupName())){
										groupDetailsMapped.setMappedWithUser(true);
									// dao call required to fetch edit value 
										GroupDetails gdetails = d.getAssetCategoryEditAccess(categoryId,allGroups.get(j).getGroupId(), conn);
										if(gdetails != null){
										groupDetailsMapped.setEditAccess(gdetails.getEditAccess());
										}
										groupDetailsMapped.setCategoryName(values.get(categoryId));
										groupDetailsMapped.setDescription(allGroups.get(j).getDescription());
										groupDetailsMapped.setGroupId((allGroups.get(j).getGroupId()));
										groupDetailsMapped.setGroupName(allGroups.get(j).getGroupName());
										listOfGds.add(groupDetailsMapped);
										flag =true;
										break;
									}
									if(flag){
										break;
									}
									if(groups.size()==k+1){
 										if(!flag){
											groupDetailsMapped.setCategoryName(values.get(categoryId));
											groupDetailsMapped.setDescription(allGroups.get(j).getDescription());
											groupDetailsMapped.setGroupId((allGroups.get(j).getGroupId()));
											groupDetailsMapped.setGroupName(allGroups.get(j).getGroupName());
											listOfGds.add(groupDetailsMapped);
										}

									}
								}
							}
							details.put(categoryId, listOfGds);
						}
					}
					AssetDao ad = new AssetDao();
					AssetDef def = ad.getAsset(assetId, conn);
					if(values.size()<def.getCategories().size()){

						for(int iii=0;iii<def.getCategories().size();iii++){
							Category c = def.getCategories().get(iii);

							if(!values.containsKey(c.getCategoryId())){
								List<GroupDetails> gg = new ArrayList<GroupDetails>();
								for (int jjj = 0; jjj < allGroups.size(); jjj++) {

									GroupDetails groupDetailsMapped =new GroupDetails();

									groupDetailsMapped.setCategoryName(c.getCategoryName());
									groupDetailsMapped.setDescription(allGroups.get(jjj).getDescription());
									groupDetailsMapped.setGroupId((allGroups.get(jjj).getGroupId()));
									groupDetailsMapped.setGroupName(allGroups.get(jjj).getGroupName());
									/*if (allGroups.get(jjj).getGroupName().equalsIgnoreCase("group-admin")) {
										groupDetailsMapped.setMappedWithUser(true);
									}*/
									gg.add(groupDetailsMapped);
								}
								details.put(c.getCategoryId(), new LinkedHashSet<GroupDetails>(gg));
							}
						}

					}


				}
				else{
					AssetDao ad = new AssetDao();
					AssetDef def = ad.getAsset(assetId, conn);
					List<Category> categories = def.getCategories();
					for (int i = 0; i < categories.size(); i++) {
						Category cat = categories.get(i);
						List<GroupDetails> gp = new ArrayList<GroupDetails>(allGroups);
						if(!cat.getCategoryName().equalsIgnoreCase("DUMMY_CATEGORY")){
							for (int j = 0; j < gp.size(); j++) {
								GroupDetails g= new GroupDetails(gp.get(j));
								g.setMappedWithUser(false);
								g.setCategoryName(cat.getCategoryName());
								gp.set(j,g);
							}
							details.put(cat.getCategoryId(), new LinkedHashSet<GroupDetails>(gp));
						}
					}
				}
				// commented by Gomathi 04/05/2018 
				//group-admin will be checked always if we unselect also ,when no group is created.
			/*}else{ 
				AssetDao ad = new AssetDao();
				AssetDef def = ad.getAsset(assetId, conn);
				List<GroupDetails> gp = new ArrayList<GroupDetails>(allGroups);
				List<Category> cats = def.getCategories();
				for (int i = 0; i < cats.size(); i++) {
					Category category =cats.get(i);

					if(!category.getCategoryName().equalsIgnoreCase("DUMMY_CATEGORY")){
						for (int j = 0; j < gp.size(); j++) {
							GroupDetails g= new GroupDetails(gp.get(j));
							if(g.getGroupName().equalsIgnoreCase("Group-admin")){
								g.setMappedWithUser(true);	
							}else{
								g.setMappedWithUser(false);
							}

							g.setCategoryName(category.getCategoryName());
							gp.set(j,g );
						}
						details.put(category.getCategoryId(), new LinkedHashSet<GroupDetails>(gp));
					}
				}

			}*/

			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getCategoryAccessByAssetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getCategoryAccessByAssetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getCategoryAccessByAssetId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("getCategoryAccessByAssetId  End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						null, null, null, details)).build();
	}




	/**
	 * @method : getAllAssetNames
	 * @param userName
	 * @return
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getAllAssetNames")
	public Response getAllAssetNames(@QueryParam("userName") String userName){

		if(log.isTraceEnabled()){
			log.trace("getAllAssetNames || Begin with userName : "+ userName);
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<AssetDef> assetlist = new ArrayList<AssetDef>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetNames || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetDao dao = new AssetDao();

			if(log.isTraceEnabled()){
				log.trace("getAllAssetNames || dao method called : getAllAssetNames()");
			}
			assetlist = dao.getAllAssetNames(userName, conn);

			if(log.isDebugEnabled()){
				log.debug("getAllAssetNames || retrieved "+ assetlist.size() +"assets");
			}

		} catch (RepoproException e) {
			log.error("getAllAssetNames || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllAssetNames || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetNames || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (assetlist.isEmpty()) {
			retMsg = Constants.ASSETS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_ASSETS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		log.trace("getAllAssetNames || end");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(assetlist))).build();
	}

	/**
	 * @method validationForDerivedAttribute
	 * @param text
	 * @param mainAssetName
	 * @param oldAssetName
	 * @return
	 */
	@POST
	@Consumes({ MediaType.APPLICATION_JSON})
	@Path("/validationForDerivedPattern")
	public Response validationForDerivedAttribute(AssetParamDef text,
			@QueryParam("mainAssetName")String mainAssetName,
			@QueryParam("oldAssetName")String oldAssetName){

		if(log.isTraceEnabled()){
			log.trace("validationForDerivedAttribute || Begin with text : "+ text);
		}

		CommonUtils commonUtils = new CommonUtils();
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<Object> responseMessage = new ArrayList<Object>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAttribute || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if(log.isTraceEnabled()){
				log.trace("validationForDerivedAttribute || dao method called : validationForDerivedAttribute()");
			}
			String responseAlertMessage = commonUtils.validationForDerivedAttribute(text.getDerivedAttributeComputation(), mainAssetName, text.getAssetParamName(), oldAssetName);
			responseMessage.add(responseAlertMessage);

			retStat = Status.OK;
			retMsg = Constants.DERIVED_ATTRIBUTE_VALIDATION_SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("validationForDerivedAttribute || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("validationForDerivedAttribute || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAttribute || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("validationForDerivedAttribute || end");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,responseMessage)).build();
	}

	/**
	 * @method validationForDerivedComputation
	 * @param text
	 * @param mainAssetName
	 * @param oldAssetName
	 * @return
	 * @throws RepoproException
	 */
	@POST
	@Path("/validationForDerivedComputationPattern")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response validationForDerivedComputation(AssetParamDef text,
			@QueryParam("mainAssetName")String mainAssetName,
			@QueryParam("oldAssetName")String oldAssetName)throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("validationForDerivedComputation || Begin with text : "+ text);
		}
		CommonUtils commonUtils = new CommonUtils();
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<Object> responseMessage = new ArrayList<Object>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedComputation || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if(log.isTraceEnabled()){
				log.trace("validationForDerivedComputation || dao method called : validationForDerivedComputation()");
			}
			String responseAlertMessage = commonUtils.validationForDerivedComputation(text.getDerivedAttributeComputation(), mainAssetName, text.getAssetParamName(), oldAssetName);
			responseMessage.add(responseAlertMessage);

			retStat = Status.OK;
			retMsg = Constants.DERIVED_COMPUTATION_VALIDATION_SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} catch (RepoproException e) {
			log.error("validationForDerivedComputation || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("validationForDerivedComputation || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAttribute || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("validationForDerivedAttribute || end");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,responseMessage)).build();

	}

	@POST
	@Path("/validateChangetoStaticforMappedDerivedParam")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response validateChangetoStaticforMappedDerivedParam(@QueryParam("isStatic") int isStatic, @QueryParam("assetParamName") String assetParamName,@QueryParam("assetName") String assetName, @QueryParam("parameterId") Long parameterId, @QueryParam("paramTypeId") Long paramTypeId, @QueryParam("listTypeParamTypeId") Long listTypeParamTypeId) throws RepoproException
	{

		if(log.isTraceEnabled()){
			log.trace("validateChangetoStaticforMappedDerivedParam || Begin with assetParamName : "+ assetParamName);
		}

		List<Object> responseMessage = new ArrayList<Object>();
		String result = "";
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetDao assetDao = new AssetDao();
		List<AssetParamDef> paramdefs = null;
		try {
			paramdefs = assetDao.getAllDerivedAttributes(conn);
		} catch (RepoproException e1) {
			e1.printStackTrace();
		}
		try {

			for (int j = 0; j < paramdefs.size(); j++) {
				AssetParamDef def = paramdefs.get(j);
				String rule = def.getDerivedAttributeComputation();
				//(rule);
				if(def.getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){

					Pattern p1 = Pattern.compile("\\{([^}]*)\\}");
					Matcher m1 = p1.matcher(rule);
					List<String> listOfParams = new ArrayList<String>();
					while (m1.find()) {
						listOfParams.add(m1.group(1));
					}

					if (isStatic == 1) {
						if (rule.startsWith("IF[")) {
							if (rule.contains("ELSE IF[")) {
								String[] splited = rule
										.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
								if (!splited[splited.length - 1].contains("IF[")) {
									// ifElseIfElse splitting
									String[] splittedData = rule
											.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
									// trimming spaces and making all are lower case
									// letters
									for (int i = 0; i < splittedData.length; i++) {
										splittedData[i] = splittedData[i].trim()
												.toLowerCase();
									}
									int ifConditionLength = 0;
									int elseIfConditionLength = 0;
									// finding condition lengths
									for (int i = 0; i < splittedData.length; i++) {
										if (splittedData[i].contains("else if[")) {
											elseIfConditionLength++;
										} else if (splittedData[i].contains("if[")) {
											ifConditionLength++;
										}
									}
									// spiltting if rule and validations with
									// database
									for (int i = 0; i < ifConditionLength; i++) {
										String paramName = splittedData[i]
												.substring(
														splittedData[i]
																.indexOf(".") + 1,
																splittedData[i]
																		.indexOf("=="))
																		.trim().toLowerCase();
										//Changed by Karthikeyan
										String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
										String lastparamName = listOfParams.get(i);
										if (lastparamName.trim().equalsIgnoreCase(assetParamName) && ruleAssetName.trim().equalsIgnoreCase(assetName)) {
											result = lastparamName
													+ " :changing to static is not allowed since it is already used in a rule!";
											break;
										}

										if (isStatic == 1) {
											if (paramName.trim().equalsIgnoreCase(assetParamName) && ruleAssetName.trim().equalsIgnoreCase(assetName)) {
												result = paramName
														+ " :changing to static is not allowed since it is already used in a rule!";
												break;
											}
										}
									}
									if (result.equalsIgnoreCase("")) {
										// spiltting else if rule and validations
										// with database
										for (int i = ifConditionLength; i < elseIfConditionLength
												+ ifConditionLength; i++) {
											String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
											String lastparamName = listOfParams
													.get(i);
											//Changed by Karthikeyan
											if (lastparamName.trim()
													.equalsIgnoreCase(
															assetParamName) && ruleAssetName.trim().equalsIgnoreCase(assetName)) {
												result = lastparamName
														+ " :changing to static is not allowed since it is already used in a rule!";
												break;
											}

											String paramName = splittedData[i]
													.substring(
															splittedData[i]
																	.indexOf(".") + 1,
																	splittedData[i]
																			.indexOf("=="))
																			.trim().toLowerCase();

											if (isStatic == 1) {
												if (paramName
														.trim()
														.equalsIgnoreCase(
																assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
													result = paramName
															+ " :changing to static is not allowed since it is already used in a rule!";
													break;
												}
											}
										}
									}
									if(result.equalsIgnoreCase("")){
										for (int i = ifConditionLength+elseIfConditionLength;i<ifConditionLength+elseIfConditionLength+1;i++){

											List<String> ruleAssetNames = new ArrayList<String>();
											List<String> relationNames = new ArrayList<String>();

											splittedData[i] = splittedData[i].replace("else", "").trim();
											String[] splitted = splittedData[i].split("[\\[\\]]");
											for(int k=0;k<splitted.length;k=k+2){
												ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
											}
											for(int k=1;k<splitted.length;k=k+2){
												relationNames.add(splitted[k].trim().toLowerCase());
											}
											String destAssetName = ruleAssetNames.get(ruleAssetNames.size()-1);//from rule
											String lastparamName = listOfParams.get(i);//from rule
											
											if (isStatic == 1){
												if(destAssetName.equalsIgnoreCase(assetName) && lastparamName.equalsIgnoreCase(assetParamName)){
													result = lastparamName+ " :changing to static is not allowed since it is already used in a rule!";
													break;
												}
											}

										}
									}
								} else {
									// ifElseIf splitting
									// trimming and making all letters are lower
									// case
									String[] splittedData = rule
											.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
									for (int i = 0; i < splittedData.length; i++) {
										splittedData[i] = splittedData[i].trim()
												.toLowerCase();
									}
									int ifLength = 0;
									int elseIfLength = 0;
									// finding length condition lengths
									for (int i = 0; i < splittedData.length; i++) {
										if (splittedData[i].contains("else if[")) {
											elseIfLength++;
										} else {
											ifLength++;
										}
									}
									// splitting if rule and validating with
									// database
									for (int i = 0; i < ifLength; i++) {

										String lastparamName = listOfParams.get(i);
										String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
										if (lastparamName.trim().equalsIgnoreCase(
												assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
											result = lastparamName
													+ " :changing to static is not allowed since it is already used in a rule!";
											break;
										}
										String paramName = splittedData[i]
												.substring(
														splittedData[i]
																.indexOf(".") + 1,
																splittedData[i]
																		.indexOf("=="))
																		.trim().toLowerCase();

										if (isStatic == 1) {
											if (paramName.trim().equalsIgnoreCase(
													assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
												result = paramName
														+ " :changing to static is not allowed since it is already used in a rule!";
												break;
											}
										}

									}
									// splitting else if rule and validating with
									// database
									if (result.equalsIgnoreCase("")) {

										for (int i = ifLength; i < elseIfLength
												+ ifLength; i++) {
											String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
											String lastparamName = listOfParams
													.get(i);
											if (lastparamName.trim()
													.equalsIgnoreCase(
															assetParamName) && ruleAssetName.trim().equalsIgnoreCase(assetName)) {
												result = lastparamName
														+ " :changing to static is not allowed since it is already used in a rule!";
												break;
											}

											String paramName = splittedData[i]
													.substring(
															splittedData[i]
																	.indexOf(".") + 1,
																	splittedData[i]
																			.indexOf("=="))
																			.trim().toLowerCase();

											if (isStatic == 1) {
												if (paramName
														.trim()
														.equalsIgnoreCase(
																assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
													result = paramName
															+ " :changing to static is not allowed since it is already used in a rule!";
													break;
												}
											}
										}
									}
								}
							} else {
								// ifElsePattern Splitting
								String[] splited = rule
										.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
								if (!splited[splited.length - 1].contains("IF[")) {
									String[] splittedData = rule
											.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
									int ifRuleLength = 0;
									// trimming spaces and making as all are lower
									// cases
									for (int i = 0; i < splittedData.length; i++) {
										splittedData[i] = splittedData[i].trim()
												.toLowerCase();
										if (splittedData[i].contains("else")) {
										} else {
											ifRuleLength++;
										}
									}
									for (int i = 0; i < ifRuleLength; i++) {

										String lastparamName = listOfParams.get(i);
										String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
										if (lastparamName.trim().equalsIgnoreCase(
												assetParamName) && ruleAssetName.trim().equalsIgnoreCase(assetName)) {
											result = lastparamName
													+ " :changing to static is not allowed since it is already used in a rule!";
											break;
										}

										String paramName = splittedData[i]
												.substring(
														splittedData[i]
																.indexOf(".") + 1,
																splittedData[i]
																		.indexOf("=="))
																		.trim().toLowerCase();


										if (isStatic == 1) {
											if (paramName.trim().equalsIgnoreCase(
													assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
												result = paramName
														+ " :changing to static is not allowed since it is already used in a rule!";
												break;
											}
										}
									}
									
									if(result.equalsIgnoreCase("")) {
										for(int i = ifRuleLength;i<ifRuleLength+1;i++){
											
											List<String> ruleAssetNames = new ArrayList<String>();
											List<String> relationNames = new ArrayList<String>();

											splittedData[i] = splittedData[i].replace("else", "").trim();
											String[] splitted = splittedData[i].split("[\\[\\]]");
											for(int k=0;k<splitted.length;k=k+2){
												ruleAssetNames.add(splitted[k].trim().toLowerCase().replace(".", ""));
											}
											for(int k=1;k<splitted.length;k=k+2){
												relationNames.add(splitted[k].trim().toLowerCase());
											}
											String destAssetName = ruleAssetNames.get(ruleAssetNames.size()-1);//from rule
											String lastparamName = listOfParams.get(i);//from rule
											
											if (isStatic == 1){
												if(destAssetName.equalsIgnoreCase(assetName) && lastparamName.equalsIgnoreCase(assetParamName)){
													result = lastparamName+ " :changing to static is not allowed since it is already used in a rule!";
													break;
												}
											}
										}
									}
								} else {
									// if Rule validation
									rule = rule.replace("IF", "").trim();
									String[] splittedData = rule
											.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\}]");
									// removing spaces and making all are lower
									// cases letters
									for (int i = 0; i < splittedData.length; i++) {
										splittedData[i] = splittedData[i].trim()
												.toLowerCase();
									}
									// splitting if rule and validating with
									// database
									if (result.equalsIgnoreCase("")) {
										for (int i = 0; i < splittedData.length; i++) {

											String lastparamName = listOfParams
													.get(i);
											String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
											if (lastparamName.trim()
													.equalsIgnoreCase(
															assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
												result = lastparamName
														+ " :changing to static is not allowed since it is already used in a rule!";
												break;
											}

											String paramName = splittedData[i]
													.substring(
															splittedData[i]
																	.indexOf(".") + 1,
																	splittedData[i]
																			.indexOf("=="))
																			.trim().toLowerCase();


											if (isStatic == 1) {
												if (paramName
														.trim()
														.equalsIgnoreCase(
																assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
													result = paramName
															+ " :changing to static is not allowed since it is already used in a rule!";
													break;
												}
											}
										}
									}
								}
							}
						}else{
							String[] SplittedData = rule.split("[\\[\\]\\{\\}]");

							String destinationParamName = SplittedData[SplittedData.length-1];
							//Changed by Karthikeyan
							String ruleAsset = SplittedData[SplittedData.length-2];
							if (destinationParamName.trim()
									.equalsIgnoreCase(
											assetParamName) && ruleAsset.trim().equalsIgnoreCase(assetName) ) {
								result = destinationParamName
										+ " :changing to static is not allowed since it is already used in a rule!";
								break;
							}
						}
					}

				} else if(def.getParamTypeId().equals(Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID)){

					if (rule.startsWith("IF[")) {
						if (rule.contains("ELSE IF[")) {
							String[] splited = rule.split("\\.count");
							if (!splited[splited.length - 1].contains("IF[")) {
								// ifElseIfElse splitting
								String[] splittedData = rule.split("\\.count");
								// trimming spaces and making all are lower case
								// letters
								for (int i = 0; i < splittedData.length; i++) {
									splittedData[i] = splittedData[i].trim()
											.toLowerCase();
								}
								int ifConditionLength = 0;
								int elseIfConditionLength = 0;
								// finding condition lengths
								for (int i = 0; i < splittedData.length; i++) {
									if (splittedData[i].contains("else if[")) {
										elseIfConditionLength++;
									} else if (splittedData[i].contains("if[")) {
										ifConditionLength++;
									}
								}
								// spiltting if rule and validations with database
								for (int i = 0; i < ifConditionLength; i++) {
									String paramName = splittedData[i]
											.substring(
													splittedData[i].indexOf(".") + 1,
													splittedData[i].indexOf("=="))
													.trim().toLowerCase();
									String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
									if (isStatic == 1) {
										if (paramName.trim().equalsIgnoreCase(
												assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
											result = paramName
													+ " :changing to static is not allowed since it is already used in a rule!";
											break;
										}
									}
								}
								if (result.equalsIgnoreCase("")) {
									// spiltting else if rule and validations with
									// database
									for (int i = ifConditionLength; i < elseIfConditionLength
											+ ifConditionLength; i++) {
										String paramName = splittedData[i]
												.substring(
														splittedData[i]
																.indexOf(".") + 1,
																splittedData[i]
																		.indexOf("=="))
																		.trim().toLowerCase();
										String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
										if (isStatic == 1) {
											if (paramName.trim().equalsIgnoreCase(
													assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
												result = paramName
														+ " :changing to static is not allowed since it is already used in a rule!";
												break;
											}
										}
									}
								}
							} else {
								// ifElseIf splitting
								// trimming and making all letters are lower case
								String[] splittedData = rule.split("\\.count");
								for (int i = 0; i < splittedData.length; i++) {
									splittedData[i] = splittedData[i].trim()
											.toLowerCase();
								}
								int ifLength = 0;
								int elseIfLength = 0;
								// finding length condition lengths
								for (int i = 0; i < splittedData.length; i++) {
									if (splittedData[i].contains("else if[")) {
										elseIfLength++;
									} else {
										ifLength++;
									}
								}
								// splitting if rule and validating with database
								for (int i = 0; i < ifLength; i++) {
									String paramName = splittedData[i]
											.substring(
													splittedData[i].indexOf(".") + 1,
													splittedData[i].indexOf("=="))
													.trim().toLowerCase();
									String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
									if (isStatic == 1) {
										if (paramName.trim().equalsIgnoreCase(
												assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
											result = paramName
													+ " :changing to static is not allowed since it is already used in a rule!";
											break;
										}
									}

								}
								// splitting else if rule and validating with
								// database
								if (result.equalsIgnoreCase("")) {
									for (int i = ifLength; i < elseIfLength
											+ ifLength; i++) {
										String paramName = splittedData[i]
												.substring(
														splittedData[i]
																.indexOf(".") + 1,
																splittedData[i]
																		.indexOf("=="))
																		.trim().toLowerCase();
										String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
										if (isStatic == 1) {
											if (paramName.trim().equalsIgnoreCase(
													assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
												result = paramName
														+ " :changing to static is not allowed since it is already used in a rule!";
												break;
											}
										}
									}
								}
							}
						} else {
							// ifElsePattern Splitting
							String[] splited = rule.split("\\.count");
							if (!splited[splited.length - 1].contains("IF[")) {
								String[] splittedData = rule.split("\\.count");
								int ifRuleLength = 0;
								// trimming spaces and making as all are lower cases
								for (int i = 0; i < splittedData.length; i++) {
									splittedData[i] = splittedData[i].trim()
											.toLowerCase();
									if (splittedData[i].contains("else")) {
									} else {
										ifRuleLength++;
									}
								}
								for (int i = 0; i < ifRuleLength; i++) {
									String paramName = splittedData[i]
											.substring(
													splittedData[i].indexOf(".") + 1,
													splittedData[i].indexOf("=="))
													.trim().toLowerCase();
									String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
									if (isStatic == 1) {
										if (paramName.trim().equalsIgnoreCase(
												assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
											result = paramName
													+ " :changing to static is not allowed since it is already used in a rule!";
											break;
										}
									}
								}
							} else {
								// if Rule validation
								rule = rule.replace("IF", "").trim();
								String[] splittedData = rule.split("\\.count");
								// removing spaces and making all are lower cases
								// letters
								for (int i = 0; i < splittedData.length; i++) {
									splittedData[i] = splittedData[i].trim()
											.toLowerCase();
								}
								// splitting if rule and validating with database
								if (result.equalsIgnoreCase("")) {
									for (int i = 0; i < splittedData.length; i++) {
										String paramName = splittedData[i]
												.substring(
														splittedData[i]
																.indexOf(".") + 1,
																splittedData[i]
																		.indexOf("=="))
																		.trim().toLowerCase();
										String ruleAssetName = splittedData[i].substring(splittedData[i].indexOf("[")+1, splittedData[i].indexOf(".")).trim().toLowerCase();
										if (isStatic == 1) {
											if (paramName.trim().equalsIgnoreCase(
													assetParamName)&& ruleAssetName.trim().equalsIgnoreCase(assetName)) {
												result = paramName
														+ " :changing to static is not allowed since it is already used in a rule!";
												break;
											}
										}
									}
								}
							}
						}

					}

				}
			}
			
			List<AssetParamDef> allDerivedAttributesForAssetList = assetDao.getAllDerivedAttributeForAssetList(conn);
			
			for(int i=0;i<allDerivedAttributesForAssetList.size();i++) {
				AssetParamDef apd = allDerivedAttributesForAssetList.get(i);
				String rule = apd.getDerivedAssetListRule();
				
				if (isStatic == 1) {
					if(apd.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
						String[] splittedData = rule.split("[\\[\\]\\{\\}]");
						String destinationParamName = splittedData[splittedData.length-1];

						String ruleAsset = splittedData[splittedData.length-2];
						if (destinationParamName.trim().equalsIgnoreCase(assetParamName) 
								&& ruleAsset.trim().equalsIgnoreCase(assetName) ) {
							result = destinationParamName + " : changing to static is not allowed since it is already used in a rule!";
							break;
						}
						
						for(int k =1;k<splittedData.length;k=k+2){
							String srcAssetName = splittedData[k-1].trim();
							String assetListName = splittedData[k].trim();
							
							if(assetListName.trim().equalsIgnoreCase(assetParamName) 
									&& srcAssetName.trim().equalsIgnoreCase(assetName)) {
								result = assetListName + " : changing to static is not allowed since it is already used in a rule!";
								break;
							}
						}
						
					}
				}else {
					AssetParamDef apd1 = assetDao.getAssetParamDefByAssetParamId(parameterId, conn);
					if(apd1.getParamTypeId() != paramTypeId) {
						if(apd.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
							String[] splittedData = rule.split("[\\[\\]\\{\\}]");

							for(int k =1;k<splittedData.length-1;k=k+2){
								String srcAssetName = splittedData[k-1].trim();
								String assetListName = splittedData[k].trim();

								if(assetListName.trim().equalsIgnoreCase(assetParamName) 
										&& srcAssetName.trim().equalsIgnoreCase(assetName)) {
									result = assetListName + " : Parameter already used in rule! So cannot change parameter type! !";
									break;
								}
							}
						}
					}
					if(apd1.getParamTypeId() == paramTypeId) {
						if(apd1.getListTypeParamTypeId() != listTypeParamTypeId) {
							if(apd.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
								String[] splittedData = rule.split("[\\[\\]\\{\\}]");

								for(int k =1;k<splittedData.length;k=k+2){
									String srcAssetName = splittedData[k-1].trim();
									String assetListName = splittedData[k].trim();

									if(assetListName.trim().equalsIgnoreCase(assetParamName) 
											&& srcAssetName.trim().equalsIgnoreCase(assetName)) {
										result = assetListName + " : Parameter already used in rule! So cannot change parameter type! !";
										break;
									}
								}
							}
						}
					}
				}
			}


			responseMessage.add(result);
			retStat = Status.OK;
			retMsg = "Success";
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		catch (Exception e) {
			log.error("validateChangetoStaticforMappedDerivedParam || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("validateChangetoStaticforMappedDerivedParam || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("validateChangetoStaticforMappedDerivedParam || end");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,responseMessage)).build();
	}

	/**
	 * @method getPossibleValuesForParam
	 * @description getPossibleValuesForParam
	 * @param userId
	 *            the requested user id
	 * @return Response List<AssetParamDef>
	 * @throws RepoproException
	 */
	@GET
	@Path("/getPossibleValuesForParam/{assetName}")
	public List<Object> getPossibleValuesForParam(@PathParam("assetName") String assetName, @QueryParam("assetParamName") String assetParamName, @QueryParam("listName") String listName) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getPossibleValuesForParam || begin with userId : "+assetName.toString());
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetDao assetDao = new AssetDao();
		List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();
		UserDao userDao = new UserDao();
		List<Object> finalList = new ArrayList<Object>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForParam || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if(null != listName)
			{	
				if(listName.equalsIgnoreCase("CUSTOM_LIST") && assetName != null)
				{
					List<AssetParamDef> assetParamDef = assetDao.getPossibleValuesForParam(assetName, assetParamName, conn);
					List<Object> assetParam = new ArrayList<Object>();
					for(AssetParamDef assetParamValues : assetParamDef)
					{
						assetParam.add(new String(assetParamValues.getParamValue()));
					}
					finalList = assetParam;
				}
				else if(listName.equalsIgnoreCase("ASSET_LIST"))
				{	
					List<AssetDef> assetDefs = assetDao.getAllAssetNames("Admin", conn);
					List<Object> assetNames = new ArrayList<Object>();
					for(AssetDef assetDef : assetDefs)
					{
						assetNames.add(new String(assetDef.getAssetName()));
					}
					finalList = assetNames;
				}
				else
				{	
					List<User> user = userDao.getAllActiveUser(conn);
					List<Object> userName = new ArrayList<Object>();
					for(User userList : user)
					{
						userName.add(new String(userList.getUserName()));
					}
					finalList = userName;
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getPossibleValuesForParam || user : "+ assetParamDefList.toString());
			}
			log.debug(" getPossibleValuesForParam  || retrieved "+assetParamDefList.size()+" user by userId successfully || assetName : "+assetName.toString());

			retStat = Status.OK;
			retMsg = Constants.USER_BY_ID_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} 
		catch (RepoproException e) {
			log.error("getPossibleValuesForParam || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}
		catch (Exception e) {
			log.error("getPossibleValuesForParam || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForParam || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}	
		if (log.isTraceEnabled()) {
			log.trace("getUserByUserId  || exit");
		}
		return finalList;
	}

	/***Wrapper function***/
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getAllAssetsForSubscriptionMain")
	public Response getAllAssetsForSubscriptionMain(@QueryParam("userName") String userName) {
		if(userName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(userName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getAllAssetsForSubscriptionMain || Begin");
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsForSubscriptionMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			} else {
				User user = userDao.getUserIdByUserName(userName, conn);

				if (user.getUserId() == null) {
					retStat = Status.OK;	
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.USER_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("getAllAssetsForSubscriptionMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

				}

				response = this.getAllAssetsForSubscription(user.getUserId());
				
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        JSONObject j1 = null;
		        JSONObject json = new JSONObject();
		        List<Object> finaldata = new ArrayList<Object>();
		        for (int i = 0; i < data.size(); i++) {
		        	j1 = new JSONObject();
		        	UserAssetSubscription uas = new UserAssetSubscription();
		        	uas = (UserAssetSubscription) data.get(i);
		        	
		        	j1.put("assetName", uas.getAssetName());
		        	j1.put("iconImageName", uas.getIconImageName());
		        	j1.put("notifyFlag", uas.getNotifyFlag());
		        	j1.put("subscriptionFlag", uas.getSubscriptionFlag());
		        	
		        	finaldata.add(j1);
		        }
		        json.put("result", finaldata);
		        json.put("message", res.getMessage());
		        json.put("status", res.getStatus());
		        json.put("statusCode", res.getStatusCode());

		        log.trace("getAllAssetsForSubscriptionMain || End");
		        return Response.status(retStat).entity(json.toString())
		          .build();
			}
		} catch (RepoproException e) {
			log.error("getAllAssetsForSubscriptionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllAssetsForSubscriptionMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsForSubscriptionMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAllAssetsForSubscriptionMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}


	/***Wrapper function***/
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getFilterListMain")
	public Response getFilterListMain(@QueryParam("assetName") String assetName,
			@QueryParam("paramName") String paramName, @QueryParam("listName") String listName,
			@QueryParam("userName") String userName,@QueryParam("mappedAssetName") String mappedAssetName) {

		if(assetName == null || paramName == null || listName == null|| userName == null||mappedAssetName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(assetName.isEmpty() || paramName.isEmpty() || listName.isEmpty()|| userName.isEmpty()||mappedAssetName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getFilterListMain || Begin");
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response response = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getFilterListMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			} 

			AssetDao assetDao = new AssetDao();
			AssetDef MappedAssetId = assetDao.getAssetsByAssetName(mappedAssetName, conn);
			if (MappedAssetId.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getFilterListMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			boolean paramFlag = false;
			List<AssetParamDef> paramList = new ArrayList<AssetParamDef>();
			AssetDef paramAssetId = assetDao.getAssetsByAssetName(mappedAssetName, conn);
			if (paramAssetId.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getFilterListMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			if(!(listName.equalsIgnoreCase("customlist")|| listName.equalsIgnoreCase("userlist")||listName.equalsIgnoreCase("assetlist"))){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.PARAM_LIST_TYPE_INVALID;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getFilterListMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			paramList = assetDao.getParamsDetails(userName, paramAssetId.getAssetId(), conn);
			for(AssetParamDef paramdata:paramList){
				if(paramdata.getAssetParamName().equalsIgnoreCase(paramName)){
					paramFlag = true;
					break;
				}
			}
			if(paramFlag){
				response = this.getFilterList(assetName, paramName, listName, userName, MappedAssetId.getAssetId());
				log.trace("getFilterListMain || End");
				return response;
			}else{
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.INVALID_PARAM_NAME;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}

		} catch (RepoproException e) {
			log.error("getFilterListMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getFilterListMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getFilterListMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getFilterListMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/***Wrapper function not required filter drop down param ***/
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getParamListMain")
	public Response getParamListMain(@QueryParam("userName") String userName,
			@QueryParam("assetName") String assetName) {
		if(assetName == null || userName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(assetName.isEmpty() || userName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getParamListMain || Begin");
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getParamListMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = assetDao.getAssetsByAssetName(assetName, conn);
			if (ad.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getParamListMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			response = this.getParamList(ad.getAssetId(), userName);
			log.trace("getParamListMain || End");
			return response;

		} catch (RepoproException e) {
			log.error("getParamListMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getParamListMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getParamListMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getParamListMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/***Wrapper function***/
	@POST
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/addFilterSearchMain")
	public Response addFilterSearchMain(
			@QueryParam("searchName") String searchName,@QueryParam("paramsValue") String paramsValue,
			@QueryParam("operatorsValue") String operatorsValue,@QueryParam("param1Value") String param1Value,
			@QueryParam("logicalSelectValue") String logicalSelectValue,@QueryParam("assetName") String assetName,
			@QueryParam("param2Value") String param2Value,@QueryParam("taxValue") String taxValue,
			@QueryParam("userName") String userName) {
		if(searchName == null||assetName == null|| userName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(paramsValue != null){
			if(paramsValue == null|| operatorsValue == null|| param1Value == null||logicalSelectValue == null){
				   return Response
				     .status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
				     .build();
			}
		}
		if(searchName.isEmpty()||assetName.isEmpty()||userName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("addFilterSearchMain || Begin");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response response = null;
		SavedSearch savedSearch = new SavedSearch();
		AssetDao assetDao = new AssetDao();
		List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
		
		String newRegex = "^((?=[\\w+\\s/])(?![\\[\\]\\?\\.\\\\@#^\\+\\=:;<>/_]).)*$";
		Pattern pattern = Pattern.compile(newRegex);
		Matcher matcher = pattern.matcher(searchName);
		if(!matcher.find()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_SEARCH_NAME)))
					.build();
		}
		
		allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
		List<AssetInstVersionTaxonomy>   assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
		try {
			savedSearch.setSearchName(searchName);
			savedSearch.setParamsValue(paramsValue);
			savedSearch.setOperatorsValue(operatorsValue);
			savedSearch.setParam1Value(param1Value);
			savedSearch.setLogicalSelectValue(logicalSelectValue);
			savedSearch.setAssetName(assetName);
			if(param2Value != null){
				savedSearch.setParam2Value(param2Value);
			}
			savedSearch.setTaxValue(taxValue);
			savedSearch.setPublicValue(0);
			savedSearch.setUserName(userName);
			AssetParamDef paramdetaileddata = new AssetParamDef();
			String paramvalue = savedSearch.getParamsValue();
			List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();
			AssetDef asset = assetDao.getAssetsByAssetName(assetName, conn);
			if(asset.getAssetId() == null){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			if(!paramvalue.equalsIgnoreCase("")){
				String[] splited = paramvalue.split("~");
				for (int i = 0; i < splited.length; i++) {
					String paramName = splited[i].split("_")[0];
					paramdetaileddata = assetDao.getAssetParamIdByName(paramName,assetName, conn);
					if(paramdetaileddata!=null){
						AssetParamDef assetParamDef = assetDao.getParamDetailsByParamId(paramdetaileddata.getAssetParamId(),conn);
						assetParamDefList = assetDao.getParamsDetails(userName,asset.getAssetId(),conn);
						boolean paramflag = false;
						for(AssetParamDef assetparamdata:assetParamDefList){
							if(paramName.equalsIgnoreCase(assetparamdata.getAssetParamName())){
								paramflag = true;
								break;
							}
						}
						if(paramflag = false){
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						
						if(!assetParamDef.getTypeName().equalsIgnoreCase(splited[i].split("_")[1])){
							retStat = Status.OK;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.INVALID_PARAM_TYPE;
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						if(splited[i].split("_")[2].equalsIgnoreCase(" ")){
							if(!(splited[i].split("_")[1].equalsIgnoreCase("text")||splited[i].split("_")[1].equalsIgnoreCase("file")
									||splited[i].split("_")[1].equalsIgnoreCase("list")||splited[i].split("_")[1].equalsIgnoreCase("date"))){
								retStat = Status.OK;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_PARAM_TYPE;
								retStatScsFlr = Constants.GET_STATUS_SUCCESS;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
							splited[i] = paramdetaileddata.getAssetParamId() + "_"+splited[i].split("_")[1]+"_"+"0";
						}else{
							if(!(splited[i].split("_")[1].equalsIgnoreCase("text")||splited[i].split("_")[1].equalsIgnoreCase("file")
									||splited[i].split("_")[1].equalsIgnoreCase("list")||splited[i].split("_")[1].equalsIgnoreCase("date"))){
								retStat = Status.OK;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_PARAM_TYPE;
								retStatScsFlr = Constants.GET_STATUS_SUCCESS;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
							if(splited[i].split("_")[1].equalsIgnoreCase("list")){
								String list = "0";
								if(!(splited[i].split("_")[2].equalsIgnoreCase("customlist")||splited[i].split("_")[2].equalsIgnoreCase("assetlist")||splited[i].split("_")[2].equalsIgnoreCase("userlist"))){
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retMsg = Constants.PARAM_LIST_TYPE_INVALID;
									retStatScsFlr = Constants.GET_STATUS_SUCCESS;
									return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
								}
								if(splited[i].split("_")[2].equalsIgnoreCase("customlist")){
									list = "1";
								}else if(splited[i].split("_")[2].equalsIgnoreCase("assetlist")){
									list = "2";
								}else if(splited[i].split("_")[2].equalsIgnoreCase("userlist")){
									list = "3";
								}
								splited[i] = paramdetaileddata.getAssetParamId() + "_"+splited[i].split("_")[1]+"_"+list;
							}
						}
					}else{
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.INVALID_PARAM_NAME;
						retStatScsFlr = Constants.GET_STATUS_SUCCESS;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
					}
				}

				StringBuilder finalparamvalue = new StringBuilder();
				for (int i = 0; i < splited.length; i++) {
					if (i > 0) {
						finalparamvalue.append("~");
					}
					String param = splited[i];
					finalparamvalue.append(param);
				}
				savedSearch.setParamsValue(finalparamvalue.toString());
			}

			
			TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
			String taxonomyValue = savedSearch.getTaxValue();
			final List<TaxonomyMaster> tmList = taxonomiesDao.getAllTaxonomiesByParentId(1L,conn);
			if(!taxonomyValue.equalsIgnoreCase("")){
				for(TaxonomyMaster t:tmList){
					recurse(t);
				}
				allTaxs.put((long) 1, tmList);
				allTxs = taxonomiesDao.getAllTaxonomiesByAssetId(asset.getAssetId(), conn);

				for(TaxonomyMaster t:allTxs)
				{
					recurse1(t); 
				}
				Set<Long> hs = new HashSet<Long>();
				hs.addAll(associatedTaxId);
				associatedTaxId.clear();
				associatedTaxId.addAll(hs);
				
				String[] addedTaxIds = new String[]{};
				String[] addedTaxIds1 = new String[]{};
				AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();
				List<Long> idsForTaxon = new ArrayList<Long>();
				if(taxonomyValue.endsWith(","))
				{
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
				else
				{
					if(taxonomyValue.length() > 0 )
					{
						if(!allTxs.isEmpty())
						{
							addedTaxIds = taxonomyValue.split(",");
							Boolean flag2 = true;
							for(int t =0; t< addedTaxIds.length && flag2; t++)
							{
								List<TaxonomyMaster> tmpTaxList = tmList;
								addedTaxIds1 = addedTaxIds[t].split("/");

								for(int h =0; h< addedTaxIds1.length; h++)
								{
									Boolean flag = false;
									Long taxNextId = null;
									for(TaxonomyMaster tm:tmpTaxList)
									{
										if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
											flag = true;
											aiatVo.setTaxonomyName(tm.getTaxonomyName());
											taxNextId = tm.getTaxonomyId();
											break;
										}
									}
									if(!flag)
									{
										retStat = Status.OK;
										retScsFlr = Constants.FAILURE;
										retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_ADD;
										retStatScsFlr = Constants.GET_STATUS_SUCCESS;
										return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
									}
									else
									{
										for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
										{
											if(entry.getKey() ==  taxNextId)
											{ 
												tmpTaxList = entry.getValue();
											}
										}
									}
									if(h == addedTaxIds1.length-1)
									{
										Boolean fl = false;
										Boolean f2 = false;
										if(associatedTaxId.contains(taxNextId)){

										}
										else{
											f2 = true;
										}
										for(Long Id:idsForTaxon)
										{
											if(Id.equals(taxNextId))
											{
												fl = true;
												break;
											}
										}
										if(fl)
										{
											retStat = Status.OK;
											retScsFlr = Constants.FAILURE;
											retMsg = Constants.DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED;
											retStatScsFlr = Constants.GET_STATUS_SUCCESS;
											return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
										}
										if(f2)
										{
											JSONObject json = new JSONObject();

											json.put("message", "No taxonomy is associated with "+assetName+" asset");
											json.put("status", Constants.SUCCESS);
											json.put("statusCode", Constants.UPDATE_STATUS_SUCCESS);
											return Response.status(retStat).entity(json.toString())
													.build();
										}
										else
										{
											idsForTaxon.add(taxNextId);
										}
									}
								}
							}
						}
						else{
							JSONObject json = new JSONObject();

							json.put("message", "No taxonomy is associated with "+assetName+" asset");
							json.put("status", Constants.SUCCESS);
							json.put("statusCode", Constants.UPDATE_STATUS_SUCCESS);
							return Response.status(retStat).entity(json.toString())
									.build();
						}
					}
					else
					{
						idsForTaxon = Collections.<Long>emptyList();
					}
					aiatVo.setTaxonIds(idsForTaxon);
					assetInstassignList.add(aiatVo);
					List<String> taxonomy = new ArrayList<String>();
					for(int i=0;i<assetInstassignList.size();i++){
						for(int j=0;j<assetInstassignList.get(i).getTaxonIds().size();j++){
							TaxonomyMaster names=taxonomiesDao.getTaxonomiesByTaxId(assetInstassignList.get(i).getTaxonIds().get(j), conn);
							String tax = null;
							tax = assetInstassignList.get(i).getTaxonIds().get(j) + ":"+names.getTaxonomyName();
							taxonomy.add(tax);
						}
					}
					StringBuilder finaltaxvalue = new StringBuilder();
					for (int i = 0; i < taxonomy.size(); i++) {
						if (i > 0) {
							finaltaxvalue.append("~");
						}
						String finaltaxonomy = taxonomy.get(i);
						finaltaxvalue.append(finaltaxonomy);
					}
					savedSearch.setTaxValue(finaltaxvalue.toString());
				}
			}
			
			boolean operatorflag = false;
			String paramdata = savedSearch.getParamsValue();
			if(!paramdata.equalsIgnoreCase("")){
				String[] splitedope = null;
				String[] splited = paramdata.split("~");
				int j=0;
				for (int i = 0; i < splited.length; i++) {
					String operatorValue = savedSearch.getOperatorsValue();
					if(!operatorValue.equalsIgnoreCase("")){
						splitedope = operatorValue.split("~");
						//for (int j = 0; j < splitedope.length; j++) {
							String operator = splitedope[j];
							if(splited[i].split("_")[1].equalsIgnoreCase("text") || splited[i].split("_")[1].equalsIgnoreCase("date")){
								if(operator.matches("(?i)=|!=|<|>|<=|>=|Between")){
									splitedope[j] = operator;
									operatorflag = true;
								}
							}else if(splited[i].split("_")[1].equalsIgnoreCase("rich text") ){
								if(operator.matches("(?i)=|!=|like|not like")){
									splitedope[j] = operator;
									operatorflag = true;
								}
							}else if(splited[i].split("_")[1].equalsIgnoreCase("file")){
								if(operator.matches("(?i)is null|is not null")){
									splitedope[j] = operator;
									operatorflag = true;
								}
							}else if(splited[i].split("_")[1].equalsIgnoreCase("list")){
								if(operator.matches("(?i)=|!=")){
									splitedope[j] = operator;
									operatorflag = true;
								}
							}
							j++;
						}
					//}
				}
				if(!operatorflag){
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_OPERATOR;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}

				StringBuilder finaloperatorvalue = new StringBuilder();
				for (int k = 0; k < splitedope.length; k++) {
					if (k > 0) {
						finaloperatorvalue.append("~");
					}
					String operator = splitedope[k];
					finaloperatorvalue.append(operator);
				}
				savedSearch.setOperatorsValue(finaloperatorvalue.toString());
			}
			
			boolean logicalflag = false;
			String logicalopeValue = savedSearch.getLogicalSelectValue();
			if(!logicalopeValue.equalsIgnoreCase("")){
				String[] splitedlogical = logicalopeValue.split("~");
				for (int j = 0; j < splitedlogical.length; j++) {
					String logicalOperator = splitedlogical[j];
					if(!logicalOperator.matches("(?i)And|or")){
						splitedlogical[j] = logicalOperator;
						logicalflag = true;
					}
				}
				if(logicalflag){
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_LOGICAL_OPERATOR;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}else{
					StringBuilder finallogicaloperator = new StringBuilder();
					for (int k = 0; k < splitedlogical.length; k++) {
						if (k > 0) {
							finallogicaloperator.append("~");
						}
						String operator = splitedlogical[k];
						finallogicaloperator.append(operator);
					}
					savedSearch.setLogicalSelectValue(finallogicaloperator.toString());
				}
			}
			
			String paramval = savedSearch.getParamsValue();
			String param1value = savedSearch.getParam1Value();
			if(!paramval.equalsIgnoreCase("")){
				String[] splitedparam1val = param1value.split("~");
				String[] splitedparamval = paramval.split("~");
				int j=0;
				for (int i = 0; i < splitedparamval.length; i++) {
					if(!splitedparam1val[j].split("`")[1].equalsIgnoreCase(splitedparamval[i].split("_")[1])){
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.INVALID_PARAM_TYPE;
						retStatScsFlr = Constants.GET_STATUS_SUCCESS;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
					}
					j++;
				}
			}
			
			String param2data = savedSearch.getParam2Value();
			if(param2data != null){
				if(!param2data.equalsIgnoreCase("")){
					String[] splitedope = null;
					String[] splited = param2data.split("~");
					int j=0;
					for (int i = 0; i < splited.length; i++) {
						String operatorValue = savedSearch.getOperatorsValue();
						if(!operatorValue.equalsIgnoreCase("")){
							splitedope = operatorValue.split("~");
							String operator = splitedope[j];
							if(!operator.equalsIgnoreCase("Between")){
								if(!splited[i].equalsIgnoreCase("undefined")){
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retMsg = Constants.INVALID_PARAM2_DATA;
									retStatScsFlr = Constants.GET_STATUS_SUCCESS;
									return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
								}
							}
							j++;
						}
					}
				}
			}
			if (log.isTraceEnabled()) {
				log.trace("addFilterSearchMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
			} else {
				response = this.addFilterSearch(savedSearch);
				return response;	
			}
		} catch (RepoproException e) {
			log.error("addFilterSearchMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("addFilterSearchMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addFilterSearchMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("addFilterSearchMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/***Wrapper function***/
	@PUT
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/updateFilterSearchMain")
	public Response updateFilterSearchMain(@QueryParam("searchName") String searchName,@QueryParam("paramsValue") String paramsValue,
			@QueryParam("operatorsValue") String operatorsValue,@QueryParam("param1Value") String param1Value,
			@QueryParam("logicalSelectValue") String logicalSelectValue,@QueryParam("assetName") String assetName,
			@QueryParam("param2Value") String param2Value,@QueryParam("taxValue") String taxValue,
			@QueryParam("userName") String userName) {
		if(searchName == null || assetName == null|| userName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(paramsValue != null){
			if(paramsValue == null|| operatorsValue == null|| param1Value == null||param2Value == null||logicalSelectValue == null){
				   return Response
				     .status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
				     .build();
			}
		}
		if(searchName.isEmpty()||assetName.isEmpty()||userName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("updateFilterSearchMain || Begin");
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response response = null;
		SavedSearch savedSearch = new SavedSearch();
		List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();

		String newRegex = "^((?=[\\w+\\s/])(?![\\[\\]\\?\\.\\\\@#^\\+\\=:;<>/_]).)*$";
		Pattern pattern = Pattern.compile(newRegex);
		Matcher matcher = pattern.matcher(searchName);
		
		if(!matcher.find()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.SPECIAL_CHARACTERS_NOT_ALLOWED_FOR_SEARCH_NAME)))
					.build();
		}
		
		allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
		List<AssetInstVersionTaxonomy>   assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
		try {
			savedSearch.setSearchName(searchName);
			savedSearch.setParamsValue(paramsValue);
			savedSearch.setOperatorsValue(operatorsValue);
			savedSearch.setParam1Value(param1Value);
			savedSearch.setLogicalSelectValue(logicalSelectValue);
			savedSearch.setAssetName(assetName);
			if(param2Value != null){
				savedSearch.setParam2Value(param2Value);
			}
			savedSearch.setTaxValue(taxValue);
			savedSearch.setPublicValue(0);
			savedSearch.setUserName(userName);
			AssetDao assetDao = new AssetDao();
			SavedSearch searchdata = assetDao.getFilterSearchIdByName(searchName,null);
			if(searchdata == null){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.SEARCH_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			savedSearch.setSearchId(searchdata.getSearchId());
			
			AssetParamDef paramdetaileddata = new AssetParamDef();
			String paramvalue = savedSearch.getParamsValue();
			List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();
			AssetDef asset = assetDao.getAssetsByAssetName(assetName, conn);
			if(asset.getAssetId() == null){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			if(!paramvalue.equalsIgnoreCase("")){
				String[] splited = paramvalue.split("~");
				for (int i = 0; i < splited.length; i++) {
					String paramName = splited[i].split("_")[0];
					paramdetaileddata = assetDao.getAssetParamIdByName(paramName,assetName, conn);
					if(paramdetaileddata!=null){
						AssetParamDef assetParamDef = assetDao.getParamDetailsByParamId(paramdetaileddata.getAssetParamId(),conn);
						assetParamDefList = assetDao.getParamsDetails(userName,asset.getAssetId(),conn);
						boolean paramflag = false;
						for(AssetParamDef assetparamdata:assetParamDefList){
							if(paramName.equalsIgnoreCase(assetparamdata.getAssetParamName())){
								paramflag = true;
								break;
							}
						}
						if(paramflag = false){
							retStat = Status.FORBIDDEN;
							retMsg = Constants.USER_NOT_AUTHORIZED;
							retScsFlr = Constants.NOT_AUTHORIZED;
							retStatScsFlr = Constants.FORBIDDEN;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						
						if(!assetParamDef.getTypeName().equalsIgnoreCase(splited[i].split("_")[1])){
							retStat = Status.OK;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.INVALID_PARAM_TYPE;
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						if(splited[i].split("_")[2].equalsIgnoreCase(" ")){
							if(!(splited[i].split("_")[1].equalsIgnoreCase("text")||splited[i].split("_")[1].equalsIgnoreCase("file")
									||splited[i].split("_")[1].equalsIgnoreCase("list")||splited[i].split("_")[1].equalsIgnoreCase("date"))){
								retStat = Status.OK;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_PARAM_TYPE;
								retStatScsFlr = Constants.GET_STATUS_SUCCESS;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
							splited[i] = paramdetaileddata.getAssetParamId() + "_"+splited[i].split("_")[1]+"_"+"0";
						}else{
							if(!(splited[i].split("_")[1].equalsIgnoreCase("text")||splited[i].split("_")[1].equalsIgnoreCase("file")
									||splited[i].split("_")[1].equalsIgnoreCase("list")||splited[i].split("_")[1].equalsIgnoreCase("date"))){
								retStat = Status.OK;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_PARAM_TYPE;
								retStatScsFlr = Constants.GET_STATUS_SUCCESS;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
							if(splited[i].split("_")[1].equalsIgnoreCase("list")){
								String list = "0";
								if(!(splited[i].split("_")[2].equalsIgnoreCase("customlist")||splited[i].split("_")[2].equalsIgnoreCase("assetlist")||splited[i].split("_")[2].equalsIgnoreCase("userlist"))){
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retMsg = Constants.PARAM_LIST_TYPE_INVALID;
									retStatScsFlr = Constants.GET_STATUS_SUCCESS;
									return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
								}
								if(splited[i].split("_")[2].equalsIgnoreCase("customlist")){
									list = "1";
								}else if(splited[i].split("_")[2].equalsIgnoreCase("assetlist")){
									list = "2";
								}else if(splited[i].split("_")[2].equalsIgnoreCase("userlist")){
									list = "3";
								}
								splited[i] = paramdetaileddata.getAssetParamId() + "_"+splited[i].split("_")[1]+"_"+list;
							}
						}
					}else{
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.INVALID_PARAM_NAME;
						retStatScsFlr = Constants.GET_STATUS_SUCCESS;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
					}
				}

				StringBuilder finalparamvalue = new StringBuilder();
				for (int i = 0; i < splited.length; i++) {
					if (i > 0) {
						finalparamvalue.append("~");
					}
					String param = splited[i];
					finalparamvalue.append(param);
				}
				savedSearch.setParamsValue(finalparamvalue.toString());
			}
			
			TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
			String taxonomyValue = savedSearch.getTaxValue();
			final List<TaxonomyMaster> tmList = taxonomiesDao.getAllTaxonomiesByParentId(1L,conn);
			if(!taxonomyValue.equalsIgnoreCase("")){
				for(TaxonomyMaster t:tmList){
					recurse(t);
				}
				allTaxs.put((long) 1, tmList);
				allTxs = taxonomiesDao.getAllTaxonomiesByAssetId(asset.getAssetId(), conn);

				for(TaxonomyMaster t:allTxs)
				{
					recurse1(t); 
				}
				Set<Long> hs = new HashSet<Long>();
				hs.addAll(associatedTaxId);
				associatedTaxId.clear();
				associatedTaxId.addAll(hs);
				
				String[] addedTaxIds = new String[]{};
				String[] addedTaxIds1 = new String[]{};
				AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();
				List<Long> idsForTaxon = new ArrayList<Long>();
				if(taxonomyValue.endsWith(","))
				{
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
				else
				{
					if(taxonomyValue.length() > 0 )
					{
						if(!allTxs.isEmpty())
						{
							addedTaxIds = taxonomyValue.split(",");
							Boolean flag2 = true;
							for(int t =0; t< addedTaxIds.length && flag2; t++)
							{
								List<TaxonomyMaster> tmpTaxList = tmList;
								addedTaxIds1 = addedTaxIds[t].split("/");

								for(int h =0; h< addedTaxIds1.length; h++)
								{
									Boolean flag = false;
									Long taxNextId = null;
									for(TaxonomyMaster tm:tmpTaxList)
									{
										if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
											flag = true;
											aiatVo.setTaxonomyName(tm.getTaxonomyName());
											taxNextId = tm.getTaxonomyId();
											break;
										}
									}
									if(!flag)
									{
										retStat = Status.OK;
										retScsFlr = Constants.FAILURE;
										retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_ADD;
										retStatScsFlr = Constants.GET_STATUS_SUCCESS;
										return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
									}
									else
									{
										for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
										{
											if(entry.getKey() ==  taxNextId)
											{ 
												tmpTaxList = entry.getValue();
											}
										}
									}
									if(h == addedTaxIds1.length-1)
									{
										Boolean fl = false;
										Boolean f2 = false;
										if(associatedTaxId.contains(taxNextId)){

										}
										else{
											f2 = true;
										}
										for(Long Id:idsForTaxon)
										{
											if(Id.equals(taxNextId))
											{
												fl = true;
												break;
											}
										}
										if(fl)
										{
											retStat = Status.OK;
											retScsFlr = Constants.FAILURE;
											retMsg = Constants.DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED;
											retStatScsFlr = Constants.GET_STATUS_SUCCESS;
											return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
										}
										if(f2)
										{
											
											JSONObject json = new JSONObject();
											
											json.put("message", "No taxonomy is associated with "+assetName+" asset");
											json.put("status", Constants.SUCCESS);
											json.put("statusCode", Constants.UPDATE_STATUS_SUCCESS);
											return Response.status(retStat).entity(json.toString())
													.build();
										}
										else
										{
											idsForTaxon.add(taxNextId);
										}
									}
								}
							}
						}
						else{
							JSONObject json = new JSONObject();
							
							json.put("message", "No taxonomy is associated with "+assetName+" asset");
							json.put("status", Constants.SUCCESS);
							json.put("statusCode", Constants.UPDATE_STATUS_SUCCESS);
							return Response.status(retStat).entity(json.toString())
									.build();
						}
					}
					else
					{
						idsForTaxon = Collections.<Long>emptyList();
					}
					aiatVo.setTaxonIds(idsForTaxon);
					assetInstassignList.add(aiatVo);
					List<String> taxonomy = new ArrayList<String>();
					for(int i=0;i<assetInstassignList.size();i++){
						for(int j=0;j<assetInstassignList.get(i).getTaxonIds().size();j++){
							TaxonomyMaster names=taxonomiesDao.getTaxonomiesByTaxId(assetInstassignList.get(i).getTaxonIds().get(j), conn);
							String tax = null;
							tax = assetInstassignList.get(i).getTaxonIds().get(j) + ":"+names.getTaxonomyName();
							taxonomy.add(tax);
						}
					}
					StringBuilder finaltaxvalue = new StringBuilder();
					for (int i = 0; i < taxonomy.size(); i++) {
						if (i > 0) {
							finaltaxvalue.append("~");
						}
						String finaltaxonomy = taxonomy.get(i);
						finaltaxvalue.append(finaltaxonomy);
					}
					savedSearch.setTaxValue(finaltaxvalue.toString());
				}
			}
			
			boolean operatorflag = false;
			String paramdata = savedSearch.getParamsValue();
			if(!paramdata.equalsIgnoreCase("")){
				String[] splitedope = null;
				String[] splited = paramdata.split("~");
				int j=0;
				for (int i = 0; i < splited.length; i++) {
					String operatorValue = savedSearch.getOperatorsValue();
					if(!operatorValue.equalsIgnoreCase("")){
						splitedope = operatorValue.split("~");
						String operator = splitedope[j];
						if(splited[i].split("_")[1].equalsIgnoreCase("text") || splited[i].split("_")[1].equalsIgnoreCase("date")){
							if(operator.matches("(?i)=|!=|<|>|<=|>=|Between")){
								splitedope[j] = operator;
								operatorflag = true;
							}
						}else if(splited[i].split("_")[1].equalsIgnoreCase("rich text") ){
							if(operator.matches("(?i)=|!=|like|not like")){
								splitedope[j] = operator;
								operatorflag = true;
							}
						}else if(splited[i].split("_")[1].equalsIgnoreCase("file")){
							if(operator.matches("(?i)is null|is not null")){
								splitedope[j] = operator;
								operatorflag = true;
							}
						}else if(splited[i].split("_")[1].equalsIgnoreCase("list")){
							if(operator.matches("(?i)=|!=")){
								splitedope[j] = operator;
								operatorflag = true;
							}
						}
						j++;
					}
				}
				if(!operatorflag){
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_OPERATOR;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}

				StringBuilder finaloperatorvalue = new StringBuilder();
				for (int k = 0; k < splitedope.length; k++) {
					if (k > 0) {
						finaloperatorvalue.append("~");
					}
					String operator = splitedope[k];
					finaloperatorvalue.append(operator);
				}
				savedSearch.setOperatorsValue(finaloperatorvalue.toString());
			}
			
			boolean logicalflag = false;
			String logicalopeValue = savedSearch.getLogicalSelectValue();
			if(!logicalopeValue.equalsIgnoreCase("")){
				String[] splitedlogical = logicalopeValue.split("~");
				for (int j = 0; j < splitedlogical.length; j++) {
					String logicalOperator = splitedlogical[j];
					if(!logicalOperator.matches("(?i)And|or")){
						splitedlogical[j] = logicalOperator;
						logicalflag = true;
					}
				}
				if(logicalflag){
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.INVALID_LOGICAL_OPERATOR;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}else{
					StringBuilder finallogicaloperator = new StringBuilder();
					for (int k = 0; k < splitedlogical.length; k++) {
						if (k > 0) {
							finallogicaloperator.append("~");
						}
						String operator = splitedlogical[k];
						finallogicaloperator.append(operator);
					}
					savedSearch.setLogicalSelectValue(finallogicaloperator.toString());
				}
			}
			String paramval = savedSearch.getParamsValue();
			String param1value = savedSearch.getParam1Value();
			if(!paramval.equalsIgnoreCase("")){
				String[] splitedparam1val = param1value.split("~");
				String[] splitedparamval = paramval.split("~");
				int j=0;
				for (int i = 0; i < splitedparamval.length; i++) {
					if(!splitedparam1val[j].split("`")[1].equalsIgnoreCase(splitedparamval[i].split("_")[1])){
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.INVALID_PARAM_TYPE;
						retStatScsFlr = Constants.GET_STATUS_SUCCESS;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
					}
					j++;
				}
			}
			
			String param2data = savedSearch.getParam2Value();
			if(param2data != null){
				if(!param2data.equalsIgnoreCase("")){
					String[] splitedope = null;
					String[] splited = param2data.split("~");
					int j=0;
					for (int i = 0; i < splited.length; i++) {
						String operatorValue = savedSearch.getOperatorsValue();
						if(!operatorValue.equalsIgnoreCase("")){
							splitedope = operatorValue.split("~");
							String operator = splitedope[j];
							if(!operator.equalsIgnoreCase("Between")){
								if(!splited[i].equalsIgnoreCase("undefined")){
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retMsg = Constants.INVALID_PARAM2_DATA;
									retStatScsFlr = Constants.GET_STATUS_SUCCESS;
									return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
								}
							}
							j++;
						}
					}
				}
			}
			if (log.isTraceEnabled()) {
				log.trace("updateFilterSearchMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			} else {
				response = this.updateFilterSearch(savedSearch);
				return response;
			}
		} catch (RepoproException e) {
			log.error("updateFilterSearchMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("updateFilterSearchMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateFilterSearchMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("updateFilterSearchMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/***Wrapper function***/
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/deleteFilterSearchMain")
	public Response deleteFilterSearchMain(@QueryParam("searchName") String searchName,@QueryParam("userName") String userName) {
		if(searchName == null || userName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(searchName.isEmpty()||userName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("deleteFilterSearchMain || Begin");
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteFilterSearchMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			AssetDao ad = new AssetDao();
			conn.setAutoCommit(false);

			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			} 

			SavedSearch search = ad.getFilterSearchIdByName(searchName , conn);

			if (search == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.SEARCH_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("deleteFilterSearchMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			if(!search.getUserName().equalsIgnoreCase(userName)){
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			response = this.deleteFilterSearch(search.getSearchId());
			return response;

		} catch (RepoproException e) {
			log.error("deleteFilterSearchMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("deleteFilterSearchMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteFilterSearchMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("deleteFilterSearchMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/***Wrapper function***/
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/fetchAssetDetails")
	public Response getAssetDetailsMain(@QueryParam("assetName") String assetName,@HeaderParam("token") String token) {
		if(assetName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(assetName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getAssetDetailsMain || Begin");
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetDetailsMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = assetDao.getAssetsByAssetName(assetName, conn);
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			if (ad.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getAssetDetailsMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			response = this.getAssetDetails(ad.getAssetId());
			MyModel res = (MyModel) response.getEntity();
	        List<Object> data = res.getResult();
	        JSONObject j1 = null;
	        JSONObject json = new JSONObject();
	        Map<Long,String> catmap = new HashMap<Long,String>();
	        List<Object> finaldata = new ArrayList<Object>();
	        for (int i = 0; i < data.size(); i++) {
	        	j1 = new JSONObject();
	        	List<Object> catList = new ArrayList<Object>();
	        	AssetDef def = null;
	        	def = (AssetDef) data.get(i);
	        	
	        	j1.put("assetName", def.getAssetName());
	        	j1.put("description", def.getDescription());
	        	j1.put("versionableFlag", def.isVersionable());
	        	j1.put("guestFlag", def.isGuestflag());
	        	j1.put("iconImageName", def.getIconImageName());
	        	j1.put("ratingDescription", def.getRatingDescription());
	        	j1.put("flagForAssetUsageInRule", def.isFlagForAssetUsageInRule());
	        	List<Category> catdata = new ArrayList<Category>();
	        	catdata.addAll(def.getCategories());
	        	
	        	//category loop
	        	for(int j = 0 ; j < catdata.size() ; j++){
	        		List<Object> cat = new ArrayList<Object>();
					
	        		JSONObject catitem = new JSONObject();
	        		catmap.put(catdata.get(j).getCategoryId(), catdata.get(j).getCategoryName());
					catitem.put("categoryName",catdata.get(j).getCategoryName());
					catitem.put("catDisplayPosition",catdata.get(j).getDisp_position());
					catitem.put("flagForCategoryRuleUsage", catdata.get(j).isFlagForCategoryRuleUsage());
					List<AssetParamDef> para = new ArrayList<AssetParamDef>();
					para.addAll(catdata.get(j).getListOfAssetParamDefs());
					for(AssetParamDef paras:para){
						JSONObject param = new JSONObject();
						param.put("assetParamName", paras.getAssetParamName());
						param.put("paramDescription", paras.getDescription());
						param.put("defaultView",paras.getDefaultView());
						param.put("hasImportantValue",paras.isHasImportantValue());
						param.put("hasMandatoryValue",paras.isHasMandatoryValue());
						param.put("is_Array", paras.getHasArray());
						param.put("is_static",paras.getIs_static());
						 if(paras.getParamTypeId() == 1L){
							 param.put("paramTypeName", "text");
						 }else if(paras.getParamTypeId() == 2L){
							 param.put("paramTypeName", "date");
						 }else if(paras.getParamTypeId() == 3L){
							 param.put("paramTypeName", "file");
						 }else if(paras.getParamTypeId() == 4L){
							 param.put("paramTypeName", "list");
						 }else if(paras.getParamTypeId() == 5L){
							 param.put("paramTypeName", "derived attribute");
						 }else if(paras.getParamTypeId() == 6L){
							 param.put("paramTypeName", "derived computation");
						 }else if(paras.getParamTypeId() == 7L){
							 param.put("paramTypeName", "rich text");
						 }
					
						 if(paras.getListTypeParamTypeId() == 1L){
							 param.put("listTypeParamTypeName", "customlist");
						 }else if (paras.getListTypeParamTypeId() == 2L){
							 param.put("listTypeParamTypeName", "assetlist");
						 }else if (paras.getListTypeParamTypeId() == 3L){
							 param.put("listTypeParamTypeName", "userlist");
						 }
						
						param.put("size",paras.getSize());
						if(paras.getMappedAssetId() != 0){
							AssetDef aa = assetDao.getAssetsByAssetId(paras.getMappedAssetId() ,conn);
							param.put("mappedAssetName",aa.getAssetName());
						}
						if(paras.getCustomListValues() != null){
							ArrayList<String> sb = new ArrayList<String>();
							List<PossibleValues> pvs = new ArrayList<PossibleValues>();
							pvs = paras.getCustomListValues();
							for(PossibleValues pv : pvs ){
								sb.add(pv.getValue());
								}
							
								param.put("customListValues", sb);	
						}
						param.put("derivedAttributeComputation", paras.getDerivedAttributeComputation());
						param.put("flagForParameterUsageInRule",paras.isFlagForParameterUsageInRule());
						param.put("paramDisplayPosition",paras.getDisplayPosition());
						
						cat.add(param);
					} // parameter loop ends
					catitem.put("parameterDataList", cat);
					catList.add(catitem);

				}// category loop ends
				j1.put("categoryDetailsList", catList);	
				
				//Associated Taxonomies
				 Map<Long, String> assetAssignedTaxonomies = def.getAssetAssignedTaxonomies();
				 List<Long> taxonomies = new ArrayList<Long>();
				 for (Map.Entry<Long, String> entry : assetAssignedTaxonomies.entrySet()) {
					 taxonomies.add(entry.getKey());
				 }
				 List<String> taxdata = new ArrayList<String>();
				 TaxonomiesDao taxonomyDao = new TaxonomiesDao();
				 String taxIds = StringUtils.join(taxonomies, ',');
					String[] splittaxs = taxIds.split(",");
					
					if(splittaxs!=null){
						Long parentTaxId = 0L;
						Long childtaxId = 0L;
						for(int j = 0; j < splittaxs.length; j++){
							if(!splittaxs[j].isEmpty() && splittaxs[j]!=null){
								if(j<splittaxs.length){
									ArrayList<String> mylist = new ArrayList<String>();
									TaxonomyMaster taxonomy = taxonomyDao.getTaxonomiesByTaxId(Long.parseLong(splittaxs[j]), null);
									childtaxId = taxonomy.getTaxonomyId();
									while(!childtaxId.equals(1L)){
										TaxonomyMaster parentTaxonomy = taxonomyDao.getTaxonomiesByTaxId(childtaxId, null);
										parentTaxId = parentTaxonomy.getParenttaxonomyId();
										mylist.add(parentTaxonomy.getTaxonomyName());
										childtaxId = parentTaxId;
									}
									String taxValue = "";
									for(int p=mylist.size()-1;p>=0;p--){
										taxValue = taxValue + mylist.get(p).concat("/");
									}
									if (taxValue.endsWith("/")) {
										taxValue = taxValue.substring(0, taxValue.length() - "/".length());
								     }
									//aivTaxonomyList.get(j).setTaxonomyName(taxValue);
									taxdata.add(taxValue);
								}
							}
						}
					}
				 j1.put("assetAssignedTaxonomies",taxdata);
				

				//Category-wise Access 
				Response r1 = null;
				r1 = this.getCategoryAccessByAssetId(ad.getAssetId());
				MyModel catRes = (MyModel) r1.getEntity();
		        				
				 Map<Long, Set<GroupDetails>> cataccess = catRes.getCategoryValues();
				 Map<String, Set<JSONObject>> cataccessFianl = new LinkedHashMap<String, Set<JSONObject>>();
						 
				 for (Map.Entry<Long, Set<GroupDetails>> entry : cataccess.entrySet()) {
					 
					 Set<JSONObject> listOfGds = new HashSet<JSONObject>();
					 Set<GroupDetails> groupDetailsMapped = new HashSet<GroupDetails>();
					 groupDetailsMapped = entry.getValue(); 
					 
					 for(GroupDetails gd2 : groupDetailsMapped){
						 JSONObject gdobj = new JSONObject();
						 gdobj.put("group_name", gd2.getGroupName());
					 	gdobj.put("mappedWithUser", gd2.isMappedWithUser());
						
					 listOfGds.add(gdobj);
					 cataccessFianl.put(catmap.get(entry.getKey()), listOfGds) ;
				 }
				 }
				j1.put("categoriesWithAccess",cataccessFianl);
				
																
				// Default Access Settings For New Instances 
				
				GroupManager gm = new GroupManager();
				Response r2 = null;
				r2 = gm.getAllGroupsWithAllAccessForEditAsset(ad.getAssetId());
				MyModel defaultAccessRes = (MyModel) r2.getEntity();
				List<Object> ob = defaultAccessRes.getResult();
				List<Object> finalGroupAccess = new ArrayList<Object>();
				JSONObject js = null;
				for(int n =0;n<ob.size();n++){
					GroupAssetAccess gaa = new GroupAssetAccess();
					gaa = (GroupAssetAccess)ob.get(n);
					 js = new JSONObject();
					 js.put("group_name", gaa.getGroupName());
					 js.put("view_access", gaa.getViewAccess());
					 js.put("add_access", gaa.getAddAccess());
					 js.put("edit_access", gaa.getEditAccess());
					 js.put("delete_access", gaa.getDeleteAccess());
					
					finalGroupAccess.add(js);
				}
				j1.put("groupAccessForAsset", finalGroupAccess);
				
	        	}// main obj loop ends
	        	finaldata.add(j1);
	        json.put("result", finaldata);
	        json.put("message", "Asset details fetched successfully");
	        json.put("status", "SUCCESS");
	        json.put("statusCode", 200);

	        log.trace("getAssetInstanceVersionDetailsMain || End");
	        return Response.status(retStat).entity(json.toString())
	          .build();
			
		} catch (RepoproException e) {
			log.error("getAssetDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAssetDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAssetDetailsMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getAssetDetailsMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/***Wrapper function***/
	@DELETE
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/delete")
	public Response deleteAssetMain(@QueryParam("assetName") String assetName, @HeaderParam("token") String token) {
		
		if(assetName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(assetName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("deleteAssetMain || Begin");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response response = null;
		Boolean adminFlag = false;
		Boolean roleFlag = false;
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<String> msgList = new ArrayList<String>();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		assetName = assetName.trim();
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			} else {
				
				User user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}

				AssetDao assetDao = new AssetDao();
				AssetDef ad = assetDao.getAssetsByAssetName(assetName, conn);
				if (ad.getAssetId() == null) {
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_SUCCESS;

					log.trace("deleteAssetMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

				}

				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
				if(!adminFlag){
					if(user != null){
						userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
					}

					for(UserFunction uf : userfunctionMappedWithRoleId){
						if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_ASSETS")){
							roleFlag = true;
							break;
						}
					}
				}
				if(adminFlag || roleFlag ){
					AssetDef ad1 = this.fetchDetailstoDeleteAsset(ad.getAssetId(),null);
					if(ad1.isFlagForAssetUsageInRule()){

						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						//retMsg = Constants.ASSET_NOT_DELETED;
						retMsg = "ASSET IS MAPPED WITH RULE WE CAN NOT DELETE THIS ASSET";
						retStatScsFlr = Constants.GET_STATUS_SUCCESS;
						//msgList.add("ASSET IS MAPPED WITH RULE WE CAN NOT DELETE THIS ASSET");
						log.trace("deleteAssetMain || End");
						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();


					}else{
						response = this.deleteAsset(ad.getAssetId(), assetName, user.getUserId());
						
						MyModel res = (MyModel) response.getEntity();				
						JSONObject json = new JSONObject();
						 List<Object> data = res.getResult();
						 
						 if(!data.isEmpty()){
						json.put("message", data.toString());
						 }else{
						json.put("message", res.getMessage());
						 }
						json.put("status", res.getStatus());
						json.put("statusCode", res.getStatusCode());
						log.trace("deleteAssetMain || End");
						
						return Response.status(retStat).entity(json.toString())
								.build();
						
					}
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("deleteAssetMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
		} catch (RepoproException e) {
			log.error("deleteAssetMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("deleteAssetMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("deleteAssetMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/***Wrapper function  (not required  used in frontend aiv page drop down)***/
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getPossibleValuesForAssetMain")
	public Response getPossibleValuesForAssetMain(@QueryParam("assetName") String assetName,
			@QueryParam("assetParamName") String assetParamName,@QueryParam("userName") String userName) {
		if(assetName == null ||assetParamName == null || userName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(assetName.isEmpty()||assetParamName.isEmpty()||userName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModelRest(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getAssetDetailsMain || Begin");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		Response response = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForAssetMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			AssetDao assetDao = new AssetDao();
			AssetDef ad = assetDao.getAssetsByAssetName(assetName, conn);
			if (ad.getAssetId() == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

				log.trace("getPossibleValuesForAssetMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			if(userName != "admin"){
				AssetParamDef apd  =  assetDao.getAssetParamAccess(userName,assetParamName,assetName,conn);
				if(apd.getAssetParamId() != null){
					//response = this.getPossibleValuesForAsset(ad.getAssetId(), apd.getAssetParamId());
					return response;
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					response = Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}else{
				AssetParamDef apd = assetDao.getAssetParamIdByName(assetParamName,assetName,conn);
				if(apd.getAssetParamId() != null){
					//response = this.getPossibleValuesForAsset(ad.getAssetId(), apd.getAssetParamId());
					return response;
				}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					response = Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
			}
		} catch (RepoproException e) {
			log.error("getPossibleValuesForAssetMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getPossibleValuesForAssetMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForAssetMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getPossibleValuesForAssetMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	/***Wrapper function***/
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getFilterSearchForLoadMain")
	public Response getFilterSearchForLoadMain(@QueryParam("assetName") String assetName,
			@QueryParam("searchName") String searchName, @QueryParam("userName") String userName) {
		if(assetName == null ||searchName == null || userName == null){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		if(assetName.isEmpty()||searchName.isEmpty()||userName.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		log.trace("getFilterSearchForLoadMain || Begin");

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		AssetDao assetDao = new AssetDao();
		AssetParamDef paramdetaileddata = null;
		AssetDef asset = new AssetDef();
		SavedSearch savedSearch = new SavedSearch();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchForLoadMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			} 
			SavedSearch searchdata = assetDao.getFilterSearchIdByName(searchName, conn);
			if (searchdata == null) {
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.SEARCH_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				log.trace("getFilterSearchForLoadMain || End");
				return Response
						.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			asset = assetDao.getAssetsByAssetName(assetName, conn);
			if(searchdata.getAssetId() != asset.getAssetId()){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.SEARCH_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				log.trace("getFilterSearchForLoadMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}

			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchForLoad || dao method called : getFilterSearchForLoad()");
			}
			paramdetaileddata = new AssetParamDef();
			savedSearch = assetDao.getFilterSearchForLoad(asset.getAssetId(), userName,searchName, conn);
			if(savedSearch == null){
				retStat = Status.OK;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.SEARCH_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				log.trace("getFilterSearchForLoadMain || End");
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

			}
			TaxonomyMaster tax = new TaxonomyMaster();
			List<String> finaltax = new ArrayList<String>();
			TaxonomiesDao taxonomyDao = new TaxonomiesDao();

			if(savedSearch.getTaxValue()!=null && savedSearch.getTaxValue().length()>0){
				String[]taxs = savedSearch.getTaxValue().split("~");
				for(String taxdata:taxs){
					String taxId = taxdata.substring( 0, taxdata.indexOf(":"));
					tax = taxonomyDao.getTaxonomiesByTaxId(Long.parseLong(taxId), conn);
					String taxname = tax.getTaxonomyId()+":"+tax.getTaxonomyName();
					finaltax.add(taxname);
				}
				String res = String.join("~", finaltax);
				savedSearch.setTaxValue(res);
			}

			String paramvalue = savedSearch.getParamsValue();
			if(!paramvalue.equalsIgnoreCase("")){
				String[] splited = paramvalue.split("~");
				for (int i = 0; i < splited.length; i++) {

					String paramIdValue = splited[i].split("_")[0];
					long paramId = Long.parseLong(paramIdValue);
					paramdetaileddata = assetDao.getParamNameByParamId(paramId, conn);
					if(paramdetaileddata!=null){
						splited[i] = paramdetaileddata.getAssetParamName() + "_"+paramdetaileddata.getMappedAssetId()+"_" + splited[i];
					}
				}

				StringBuilder finalparamvalue = new StringBuilder();
				for (int i = 0; i < splited.length; i++) {
					if (i > 0) {
						finalparamvalue.append("~");
					}
					String param = splited[i];
					finalparamvalue.append(param);
				}
				savedSearch.setParamsValue(finalparamvalue.toString());
			}

			List<FilterData> finalparameterEquation = new ArrayList<FilterData>();
			List<ParameterData> parameterEquation = new ArrayList<ParameterData>();
			List<String> taxdata = new ArrayList<String>();
			FilterData finalparam = new FilterData();

			if(savedSearch != null){
				String paramnames = savedSearch.getParamsValue();
				String[] splittaxs = null;
				String[] splitparam2value = null;
				String[] splitparamnames = paramnames.split("~");
				String[] splitoperator = savedSearch.getOperatorsValue().split("~");
				String[] splitparam1value = savedSearch.getParam1Value().split("~");
				if(savedSearch.getParam2Value()!=null){
					splitparam2value = savedSearch.getParam2Value().split("~");
				}
				String[] splitlogicalvalue = savedSearch.getLogicalSelectValue().split("~");
				if(savedSearch.getTaxValue()!=null && savedSearch.getTaxValue().length()>0){
					splittaxs = savedSearch.getTaxValue().split("~");
				}
				for (int i = 0; i < splitparamnames.length; i++) {
					ParameterData paramval = new ParameterData();
					String param = splitparamnames[i].split("_")[0];
					if(!param.equalsIgnoreCase("")){
						paramval.setParameterName(param);
						paramval.setParameterType(splitparamnames[i].split("_")[3]);
						if(splitoperator[i].equalsIgnoreCase("is null")){
							splitoperator[i] = "is Empty";
						}else if(splitoperator[i].equalsIgnoreCase("is not null")){
							splitoperator[i] = "is not Empty";
						}
						String operator = splitoperator[i];
						paramval.setOperatorValue(operator);
						String param2value = "";
						String param1value = splitparam1value[i].split("`")[0];
						if(splitparam2value != null){
							param2value = splitparam2value[i];
						}
						if(!param2value.equalsIgnoreCase("undefined")){
							String paramdata[] = new String[]{param1value,param2value};
							paramval.setParameterValues(paramdata);
						}else{
							String paramdata[] = new String[]{param1value};
							paramval.setParameterValues(paramdata);
						}

						if(!savedSearch.getLogicalSelectValue().isEmpty() && savedSearch.getLogicalSelectValue()!=null){
							if(i<splitlogicalvalue.length){
								String logicaloperator = splitlogicalvalue[i];
								paramval.setLogicalOperator(logicaloperator);
							}
						}
						parameterEquation.add(paramval);
					}
				}
				if(splittaxs!=null){
					Long parentTaxId = 0L;
					Long childtaxId = 0L;
					for(int j = 0; j < splittaxs.length; j++){
						if(!savedSearch.getTaxValue().isEmpty() && savedSearch.getTaxValue()!=null){
							if(j<splittaxs.length){
								ArrayList<String> mylist = new ArrayList<String>();
								TaxonomyMaster taxonomy = taxonomyDao.getTaxonomiesByTaxId(Long.parseLong(splittaxs[j].split(":")[0]), null);
								childtaxId = taxonomy.getTaxonomyId();
								while(!childtaxId.equals(1L)){
									TaxonomyMaster parentTaxonomy = taxonomyDao.getTaxonomiesByTaxId(childtaxId, null);
									parentTaxId = parentTaxonomy.getParenttaxonomyId();
									mylist.add(parentTaxonomy.getTaxonomyName());
									childtaxId = parentTaxId;
								}
								String taxValue = "";
								for(int i=mylist.size()-1;i>=0;i--){
									taxValue = taxValue + mylist.get(i).concat("/");
								}
								if (taxValue.endsWith("/")) {
									taxValue = taxValue.substring(0, taxValue.length() - "/".length());
							     }
								taxdata.add(taxValue);
							}
						}
					}
				}
				finalparam.setTaxonomyValueList(taxdata);
				finalparam.setParameterData(parameterEquation);
				finalparameterEquation.add(finalparam);
				
				List<Object> paramlist = null;
				List<ParameterData> data = null;
				JSONObject json = new JSONObject();
				for(int i = 0 ; i < finalparameterEquation.size() ; i++){
					JSONObject item = new JSONObject();
					paramlist = new ArrayList<Object>();
					data = new ArrayList<ParameterData>();
					data.addAll(finalparameterEquation.get(i).getParameterData());
					for(int j = 0 ; j < data.size() ; j++){
						JSONObject paramData= new JSONObject();
						paramData.put("logicalOperator", data.get(j).getLogicalOperator());
						paramData.put("operatorValue", data.get(j).getOperatorValue());
						paramData.put("parameterName", data.get(j).getParameterName());
						paramData.put("parameterType", data.get(j).getParameterType());
						paramData.put("parameterValues", data.get(j).getParameterValues());
						paramlist.add(paramData);
					}
					item.put("parameterData",paramlist);
					item.put("taxonomyValueList", finalparameterEquation.get(i).getTaxonomyValueList());
					json.put("result",item);
				}
				json.put("statusCode", Constants.GET_STATUS_SUCCESS);
				json.put("status", Constants.SUCCESS);
				json.put("message", Constants.SEARCH_DATA_FETCHED);
				
				return Response.status(retStat).entity(json.toString()).build();
				/*return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
								new ArrayList<Object>(finalparameterEquation))).build();*/
			}
		} catch (RepoproException e) {
			log.error("getFilterSearchForLoadMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getFilterSearchForLoadMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchForLoadMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("getFilterSearchForLoadMain || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}

	
	public AssetDef fetchDetailstoDeleteAsset(Long assetId , Connection conn1){

		if(log.isTraceEnabled()){
			log.trace("fetchDetailstoDeleteAsset || Begin with assetId : "+ assetId);
		}
	
		AssetDef def = null;	
		Connection conn = null;
		
		try{
			if (log.isTraceEnabled()) {
				log.trace("fetchDetailstoDeleteAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn1 == null){
			conn = DBConnection.getInstance().getConnection();
			
			}
			
			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("fetchDetailstoDeleteAsset || dao method called : getAssetDefByAssetId()");
			}
			def = dao.getAssetsByAssetId(assetId, conn);

			if (log.isTraceEnabled()) {
				log.trace("fetchDetailstoDeleteAsset || dao method called : getCategoryByAssetID() :"+assetId);
			}
			List<Category> listOfCategories = dao.getCategoryByAssetID(assetId, conn);
			for(int i=0;i<listOfCategories.size();i++){
				Category category = listOfCategories.get(i);
				Long catgoryId = category.getCategoryId();
				if (log.isTraceEnabled()) {
					log.trace("fetchDetailstoDeleteAsset || dao method called : getAssetParameterDefsByCategoryID() :"+catgoryId);
				}
				List<AssetParamDef> listOfParamDefs = dao.getAssetParameterDefsByCategoryID(catgoryId, conn);
				for (int j = 0; j <listOfParamDefs.size(); j++) {
					AssetParamDef assetParamDef = listOfParamDefs.get(j);

					if(assetParamDef.getParamTypeId().toString().equals("4")){
						
						if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){
							
							List<PossibleValues> customValues = dao.getAllPossibleValuesByParamId(assetParamDef.getAssetParamId(),conn);
							assetParamDef.setCustomListValues(customValues);
						}
						
					}
					
					assetParamDef.setAssetCategoryId(catgoryId);
					String paramName = assetParamDef.getAssetParamName();
					if (log.isTraceEnabled()) {
						log.trace("fetchDetailstoDeleteAsset || dao method called : getAllDerivedAttributes()");
					}
					List<AssetParamDef> derivedAttributes =  dao.getAllDerivedAttributes(conn);
					
					if(log.isTraceEnabled()) {
						log.trace("fetchDetailstoDeleteAsset || dao method called getAllDerivedAttributeForAssetList()");
					}
					List<AssetParamDef> allDerivedAttributesForAssetList = dao.getAllDerivedAttributeForAssetList(conn);
					
					Pattern patternForDerivedAttribute = Pattern.compile(def.getAssetName()+"[\\{](?i)"+paramName+"[\\}]");
					Pattern patternForDerivedComputation = Pattern.compile(def.getAssetName()+"[\\.](?i)"+paramName+"(==)");
					for (AssetParamDef assetParamDef2 : derivedAttributes) {
						String rule = assetParamDef2.getDerivedAttributeComputation();
						if(assetParamDef2.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID){

							Matcher m = patternForDerivedAttribute.matcher(rule);
							if(m.find()){//destination parameter check 
								category.setFlagForCategoryRuleUsage(true);
								def.setFlagForAssetUsageInRule(true);
								assetParamDef.setFlagForParameterUsageInRule(true);
							}
							//changes modified by gomathi 15/03/2017
							Matcher m1 = patternForDerivedComputation.matcher(rule);
							if(m1.find()){// source parameter check
								def.setFlagForAssetUsageInRule(true);
								assetParamDef.setFlagForParameterUsageInRule(true);
								category.setFlagForCategoryRuleUsage(true);
							}
						}
						if(assetParamDef2.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID){
							Matcher m = patternForDerivedComputation.matcher(rule);
							if(m.find()){
								def.setFlagForAssetUsageInRule(true);
								assetParamDef.setFlagForParameterUsageInRule(true);
								category.setFlagForCategoryRuleUsage(true);
							}
						}
					}
					
					
					Pattern assetListParameterPattern = Pattern.compile("(?i)"+def.getAssetName()+"[\\{](?i)"+paramName+"[\\}]");
					Pattern assetListParameterPattern2 = Pattern.compile("(?i)"+"[\\[](?i)"+paramName+"[\\]]");
					
					for(AssetParamDef apd : allDerivedAttributesForAssetList) {
						String assetListRule = apd.getDerivedAssetListRule();
						if(apd.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
							Matcher m = assetListParameterPattern.matcher(assetListRule);
							if(m.find()){
								category.setFlagForCategoryUsageInAssetListRule(true);
								def.setFlagForAssetUsageInAssetListRule(true);
								assetParamDef.setFlagForParameterUsageInAssetListRule(true);
							}
							
							Matcher m1 = assetListParameterPattern2.matcher(assetListRule);
							if(m1.find()){
								assetParamDef.setFlagForParameterUsageInAssetListRule(true);
							}
						}
					}
					
					listOfParamDefs.set(j, assetParamDef);

					for(int jj=0;jj<derivedAttributes.size();jj++){

						AssetParamDef apd = derivedAttributes.get(jj);
						String rule = apd.getDerivedAttributeComputation();

						Pattern assetPattern1 = Pattern.compile("[\\]]"+def.getAssetName()+"[\\{]");
						Matcher m1 = assetPattern1.matcher(rule);
						if(m1.find()){
							def.setFlagForAssetUsageInRule(true);
							break;
						}

						Pattern assetPattern2 = Pattern.compile("[\\]]"+def.getAssetName()+"[\\[]");
						Matcher m2 = assetPattern2.matcher(rule);
						if(m2.find()){
							def.setFlagForAssetUsageInRule(true);
							break;
						}
					}
					
					for(int kk=0;kk<allDerivedAttributesForAssetList.size();kk++) {
						AssetParamDef apd = allDerivedAttributesForAssetList.get(kk);
						String assetListRule = apd.getDerivedAssetListRule();
						
						Pattern assetPattern1 = Pattern.compile("[\\]](?i)"+def.getAssetName()+"[\\{]");
						Matcher m1 = assetPattern1.matcher(assetListRule);
						if(m1.find()){
							def.setFlagForAssetUsageInAssetListRule(true);
							break;
						}

						Pattern assetPattern2 = Pattern.compile("[\\]](?i)"+def.getAssetName()+"[\\[]");
						Matcher m2 = assetPattern2.matcher(assetListRule);
						if(m2.find()){
							def.setFlagForAssetUsageInAssetListRule(true);
							break;
						}
					}
					
				}
				category.setListOfAssetParamDefs(listOfParamDefs);
				listOfCategories.set(i, category);
			}
			def.setCategories(listOfCategories);

			AssetDao assetDao = new AssetDao();
			
			boolean flag = assetDao.enableOrdisableAssetVersionBasedonAssetRelation(def.getAssetName(), conn);
			def.setRelFlag(flag);

			log.info("Successfully get the assetDetails "+def);
		}catch (RepoproException e) {
			log.error("fetchDetailstoDeleteAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			log.error("fetchDetailstoDeleteAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("fetchDetailstoDeleteAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("fetchDetailstoDeleteAsset || End");
		}
		
		return def;
	}
	
	//***Wrapper function***//*
		@POST
		@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
		@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
		@Path("/add")
		public Response addAssetMain(@QueryParam("assetName") String assetName,
				@FormDataParam("CategoryObject")String CategoryObject,
				FormDataMultiPart bodyParts,
				@HeaderParam("token") String token,
				@Context HttpServletRequest request) {
			 
			if(assetName == null||CategoryObject == null ){
				   return Response
				     .status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
				     .build();
			}
			
			if(assetName.isEmpty()|| CategoryObject.isEmpty()){
				   return Response
				     .status(Status.BAD_REQUEST)
				     .entity(new MyModelRest(Constants.STATUS_FAILURE,
				       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
				     .build();
			}
			if(assetName.trim().length()>50){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, "MAX LENGTH EXCEEDED FOR ASSET NAME"))
						.build();
			}
			
			log.trace("addAssetMain || Begin");
			
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			Connection conn = null;
			Boolean adminFlag = false;
			GroupDao groupdao = new GroupDao(); 
			Boolean roleFlag = false;
			RoleDao roledao = new RoleDao();
			AssetDao assetdao = new AssetDao();
			AssetDef addAsset1 = null;
			GroupDao groupDao = new GroupDao();
			User user = new User();
			List<String> result = new ArrayList<String>();
			String action = Constants.ACTIVITY_CREATE;
			TaxonomiesDao tdao = new TaxonomiesDao();
			RecentActivity recentActivity = new RecentActivity();
			RecentActivityDao recentActivityDao = new RecentActivityDao();
			String jsonRslt;
			List<String> jsonList = new ArrayList<String>();
			CommonUtils commonutil = new CommonUtils();
			List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			String userName = "";
			allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
			List<AssetInstVersionTaxonomy>   assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
			assetName = assetName.trim();
			try {
				if (log.isTraceEnabled()) {
					log.trace("addAssetMain || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);
				UserDao userDao = new UserDao();
				if(token != null){
					User userdata = commonutil.userDetails(token);
					User username = userDao.getUserByUserId( userdata.getUserId(), null);
					userName = username.getUserName();
				}else{
					userName = "guest";
				}
				
				if (userName.equalsIgnoreCase("guest")) {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				} else {
					
					 user = userDao.getUserIdByUserName(userName, conn);
					if (user.getUserId() == null) {
						retStat = Status.UNAUTHORIZED;
						retMsg = Constants.USER_NOT_AUTHENTICATED;
						retScsFlr = Constants.NOT_AUTHENTICATED;
						retStatScsFlr = Constants.UNAUTHORIZED;
						return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
					}
			
					
					adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName, conn);
					if(!adminFlag){
					if(user != null){
						userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user.getUserId(), conn);
					}
			        
					for(UserFunction uf : userfunctionMappedWithRoleId){
						if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_ASSETS")){
					        roleFlag = true;
					        break;
						}
					}
					}
					if(adminFlag || roleFlag ){
						
						//add asset logic 
						
						AssetDef addAsset = null;
						if(assetName!=null)
							addAsset = new AssetDef();
						InputStream file = null;
						String extension = "";
						FormDataBodyPart dataMultiPart = null;
						String NewFileName = null;
						if (bodyParts != null) {
							dataMultiPart = bodyParts.getField("iconImageName");
							if(dataMultiPart != null){
								NewFileName = dataMultiPart.getContentDisposition().getFileName();
					
								InvertImage invertImage = new InvertImage();
								file = invertImage.inverImage(dataMultiPart
										.getEntityAs(InputStream.class), dataMultiPart
										.getContentDisposition().getFileName());
								
								if (!NewFileName.isEmpty()|| NewFileName.length() != 0) {
									addAsset.setIconImage(dataMultiPart
											.getEntityAs(InputStream.class));
									addAsset.setIconImageName(dataMultiPart
											.getContentDisposition().getFileName());
									addAsset.setInvertedIconImage(file);
								}
							}
						}else{
							NewFileName = "";
						}

						addAsset.setAssetName(assetName);
						
						
						String jsonStr = CategoryObject;
						List<String> dupliacteparam = new ArrayList<String>();
						boolean duplicateParamFalg = false;
						List<String> dupliactecat = new ArrayList<String>();
						boolean duplicateCatFalg = false;
						try{
							
						JSONParser parser = new JSONParser();
						org.json.simple.JSONObject json = (org.json.simple.JSONObject) parser.parse(jsonStr);
						JSONObject json1 = new JSONObject(jsonStr);
						
						if(json1.has("assetDescription") && !json1.getString("assetDescription").toString().isEmpty()){
							if(json1.getString("assetDescription").toString().length()>25001){
								  return Response
										     .status(Status.OK)
										     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
										       Constants.FAILURE, "MAX LENGTH EXCEEDED FOR ASSET DESCRIPTION"))
										     .build();
							}
							addAsset.setDescription(json1.getString("assetDescription").toString());
						}else{
							retStat = Status.OK;
							retScsFlr = Constants.FAILURE;
							retMsg = "PROVIDE ASSET DESCRIPTION";
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						
						if(json1.has("versionableFlag")){
							addAsset.setVersionable(json1.getBoolean("versionableFlag"));
							
						}else{
							addAsset.setVersionable(false);
						}
						if(json1.has("guestFlag")){
							addAsset.setGuestflag(json1.getBoolean("guestFlag"));
						}else{
							addAsset.setGuestflag(false);
						}
						
						if(json1.has("ratingDescription") && !json1.getString("ratingDescription").toString().isEmpty()){
							if(json1.getString("ratingDescription").toString().length()>201){
								  return Response
										     .status(Status.OK)
										     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
										       Constants.FAILURE, "MAX LENGTH EXCEEDED FOR RATING DESCRIPTION"))
										     .build();
							}
							
							addAsset.setRatingDescription(json1.getString("ratingDescription").toString());
						}else{
							addAsset.setRatingDescription("Overall experience in terms of using the asset instance and the quality of its documentation: 5-Outstanding, 4-Excellent, 3-Acceptable, 2-Inadequate, 1-Very Poor");
						}
						
						Map<Long,String> tax = new HashMap<Long,String>(); 
						if(json.get("assetAssignedTaxonomies") != null){
						String assetAssignedTaxonomies = json.get("assetAssignedTaxonomies").toString();
						if(assetAssignedTaxonomies.length() != 0 && !assetAssignedTaxonomies.startsWith("[")){
							retStat = Status.OK;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.INVALID_DATA;
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						
						}
						JSONArray taxArray = new JSONArray(assetAssignedTaxonomies);
						String assetAssignedTaxonomies1 = "";
						for(int g = 0;g<taxArray.length();g++){
							assetAssignedTaxonomies1 = assetAssignedTaxonomies1.concat(taxArray.getString(g)+",");
						}
						if(assetAssignedTaxonomies1.length() != 0){
						TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
						String taxonomyValue = assetAssignedTaxonomies1;
						final List<TaxonomyMaster> tmList = taxonomiesDao.getAllTaxonomiesByParentId(1L,conn);
						if(!taxonomyValue.equalsIgnoreCase("")){
							for(TaxonomyMaster t:tmList){
								recurse(t);
							}
							allTaxs.put((long) 1, tmList);
							
							String[] addedTaxIds = new String[]{};
							String[] addedTaxIds1 = new String[]{};
							AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();
							List<Long> idsForTaxon = new ArrayList<Long>();
							/*if(taxonomyValue.endsWith(","))
							{
								retStat = Status.OK;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_DATA;
								retStatScsFlr = Constants.GET_STATUS_SUCCESS;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							}*/
							//else
							//{
								if(taxonomyValue.length() > 0 )
								{
										addedTaxIds = taxonomyValue.split(",");
										Boolean flag2 = true;
										for(int t =0; t< addedTaxIds.length && flag2; t++)
										{
											List<TaxonomyMaster> tmpTaxList = tmList;
											addedTaxIds1 = addedTaxIds[t].split("/");

											for(int h =0; h< addedTaxIds1.length; h++)
											{
												Boolean flag = false;
												Long taxNextId = null;
												for(TaxonomyMaster tm:tmpTaxList)
												{
													if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
														flag = true;
														aiatVo.setTaxonomyName(tm.getTaxonomyName());
														taxNextId = tm.getTaxonomyId();
														break;
													}
												}
												if(!flag)
												{
													retStat = Status.OK;
													retScsFlr = Constants.FAILURE;
													retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
													retStatScsFlr = Constants.GET_STATUS_SUCCESS;
													return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
												}
												else
												{
													for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
													{
														if(entry.getKey() ==  taxNextId)
														{ 
															tmpTaxList = entry.getValue();
														}
													}
												}
												if(h == addedTaxIds1.length-1)
												{
													Boolean fl = false;
													Boolean f2 = false;
													
													for(Long Id:idsForTaxon)
													{
														if(Id.equals(taxNextId))
														{
															fl = true;
															break;
														}
													}
													if(fl)
													{
														retStat = Status.OK;
														retScsFlr = Constants.FAILURE;
														retMsg = Constants.DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED;
														retStatScsFlr = Constants.GET_STATUS_SUCCESS;
														return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
													}
													
													else
													{
														idsForTaxon.add(taxNextId);
													}
												}
											}
										}
									
								}
								else
								{
									idsForTaxon = Collections.<Long>emptyList();
								}
								aiatVo.setTaxonIds(idsForTaxon);
								assetInstassignList.add(aiatVo);
								for(int i=0;i<assetInstassignList.size();i++){
									for(int j=0;j<assetInstassignList.get(i).getTaxonIds().size();j++){
										TaxonomyMaster names=taxonomiesDao.getTaxonomiesByTaxId(assetInstassignList.get(i).getTaxonIds().get(j), conn);
										tax.put(assetInstassignList.get(i).getTaxonIds().get(j),names.getTaxonomyName());
									}
								}
							//}
						}
						
						addAsset.setAssetAssignedTaxonomies(tax);
						}else{
							addAsset.setAssetAssignedTaxonomies(tax);
						}
						}else{
							addAsset.setAssetAssignedTaxonomies(tax);
						}
					
						
						List<Map<String, Long>> groupAccess = new ArrayList<Map<String,Long>>();
						
						if(json.get("groupAccessForAsset") != null ){
						String groupAccessForAsset = json.get("groupAccessForAsset").toString();
						JSONArray groupAccessForAssetArray = new JSONArray(groupAccessForAsset);
						for(int i=0; i<groupAccessForAssetArray.length(); i++){
							GroupDetails gd = new GroupDetails();
							int group_id;
							 String group_name = null;
							Map<String,Long> groupAccesForRow = new HashMap<String, Long>();
							JSONObject jsonObj = groupAccessForAssetArray.getJSONObject(i);
							if(jsonObj.has("group_name")){
						    group_name =  jsonObj.getString("group_name");
							}else{
								retStat = Status.OK;
					            retScsFlr = Constants.FAILURE;
					            retMsg = Constants.GROUP_DATA_NOT_FOUND;
					            retStatScsFlr = Constants.GET_STATUS_SUCCESS;
					            return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
						   group_id = groupdao.getGroupIdByGroupName(group_name ,null);
						   if(group_id == 0 ){
								retStat = Status.OK;
					            retScsFlr = Constants.FAILURE;
					            retMsg = Constants.GROUP_DATA_NOT_FOUND;
					            retStatScsFlr = Constants.GET_STATUS_SUCCESS;
					            return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
							}
							groupAccesForRow.put("group_id", (long) group_id);
							if(jsonObj.has("add_access")){
							groupAccesForRow.put("add_access", (Long)((Integer)jsonObj.getInt("add_access")).longValue());
							}else{
								groupAccesForRow.put("add_access" ,0L);
							}
							if(jsonObj.has("edit_access")){
								groupAccesForRow.put("edit_access", (Long)((Integer)jsonObj.getInt("edit_access")).longValue());
								}else{
									groupAccesForRow.put("edit_access" ,0L);
								}
							if(jsonObj.has("view_access")){
								groupAccesForRow.put("view_access", (Long)((Integer)jsonObj.getInt("view_access")).longValue());
								}else{
									groupAccesForRow.put("view_access" ,0L);
								}
							if(jsonObj.has("delete_access")){
								groupAccesForRow.put("delete_access", (Long)((Integer)jsonObj.getInt("delete_access")).longValue());
								}else{
									groupAccesForRow.put("delete_access" ,0L);
								}
							groupAccess.add(groupAccesForRow);
						}
						addAsset.setGroupAccessForAsset(groupAccess);
						}
						addAsset.setUserName(userName);
						addAsset.setUserId(user.getUserId());
						
						if(json.get("categories") != null ){
						String categoriesArray = json.get("categories").toString();
						JSONArray array = new JSONArray(categoriesArray); 
						List<Category> listOfCategories = new ArrayList<Category>();
						for(int i=0; i<array.length(); i++){ 

							String paramTypeName = null;
							String listTypeParamName = null;
							String mapped_Asset_Name = null;
							Category category = new Category();
							JSONObject jsonObj = array.getJSONObject(i);
							if(jsonObj.has("categoryName")&& !json1.getString("categoryName").toString().isEmpty()){
								if(json1.getString("categoryName").toString().length()>51){
									  return Response
											     .status(Status.OK)
											     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
											       Constants.FAILURE, "MAX LENGTH EXCEEDED FOR ASSET CATEGORY NAME"))
											     .build();
								}
							category.setCategoryName(jsonObj.getString("categoryName"));
							}else{
								  return Response
										     .status(Status.OK)
										     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
										       Constants.FAILURE, "PROVIDE ASSET CATEGORY NAME"))
										     .build();
							}

							dupliactecat.add(category.getCategoryName());
							String parametersArray = null;
							if(jsonObj.has("category_disp_position")){
							category.setCatDisp(jsonObj.getString("category_disp_position"));
							}
							if(jsonObj.has("parameterdatas")){
							parametersArray = jsonObj.get("parameterdatas").toString();
							}else{
								  return Response
										     .status(Status.OK)
										     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
										       Constants.FAILURE,Constants.ASSET_CATEGORY_PARAMETER_CAN_NOT_BE_NULL))
										     .build();
							}
							JSONArray parametersJsonArray = new JSONArray(parametersArray); 
							List<AssetParamDef> listOfDefs = new ArrayList<AssetParamDef>();
							for(int j=0; j<parametersJsonArray.length(); j++){ 
								AssetParamDef apd = new AssetParamDef();
								JSONObject ParamjsonObj = parametersJsonArray.getJSONObject(j);
								if(ParamjsonObj.has("assetParamName") && !json1.getString("assetParamName").toString().isEmpty()){
									if(json1.getString("assetParamName").toString().length()>51){
										  return Response
												     .status(Status.OK)
												     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
												       Constants.FAILURE, "MAX LENGTH EXCEEDED FOR ASSET PARAMETER NAME"))
												     .build();
									}
								apd.setAssetParamName(ParamjsonObj.getString("assetParamName"));
								}else{
									  return Response
											     .status(Status.OK)
											     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
											       Constants.FAILURE,"PROVIDE ASSET PARAMETER NAME"))
											     .build();
								}
								dupliacteparam.add(apd.getAssetParamName());
								if(ParamjsonObj.has("parameter_disp_position")){
									apd.setParamDisp(ParamjsonObj.getString("parameter_disp_position"));
								}
								if(ParamjsonObj.has("defaultView")){
								apd.setDefaultView(ParamjsonObj.getInt("defaultView"));
								}else{
									apd.setDefaultView(0);
								}
								if(ParamjsonObj.has("is_static")){
									apd.setIs_static(ParamjsonObj.getInt("is_static"));
									}else{
										apd.setIs_static(0);
									}
								if(ParamjsonObj.has("hasImportantValue")){
									apd.setHasImportantValue(ParamjsonObj.getBoolean("hasImportantValue"));
									}else{
										apd.setHasImportantValue(false);
									}
								if(ParamjsonObj.has("hasMandatoryValue")){
									apd.setHasMandatoryValue(ParamjsonObj.getBoolean("hasMandatoryValue"));
									}else{
										apd.setHasMandatoryValue(true);
									}
								if(ParamjsonObj.has("is_Array")){
									apd.setHasArray(ParamjsonObj.getInt("is_Array"));
									}else{
										apd.setHasArray(0);
									}
								if(ParamjsonObj.has("paramDescription") && !json1.getString("paramDescription").toString().isEmpty()){
									if(json1.getString("paramDescription").toString().length()>10001){
										  return Response
												     .status(Status.OK)
												     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
												       Constants.FAILURE, "MAX LENGTH EXCEEDED FOR ASSET PARAMETER DESCRIPTION"))
												     .build();
									}
									apd.setDescription(ParamjsonObj.getString("paramDescription"));
									}else{
										  return Response
												     .status(Status.OK)
												     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
												       Constants.FAILURE, "PROVIDE PARAMETER DESCRIPTION"))
												     .build();
									}
								if(ParamjsonObj.has("paramTypeName")){
									paramTypeName = ParamjsonObj.getString("paramTypeName");
									}else{
										  return Response
												     .status(Status.OK)
												     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
												       Constants.FAILURE,"PROVIDE PARAMETER TYPE"))
												     .build();
									}
								
								if(paramTypeName.equalsIgnoreCase("text")){
									apd.setParamTypeId(1L);
								}else if(paramTypeName.equalsIgnoreCase("date")){
									apd.setParamTypeId(2L);
								}else if(paramTypeName.equalsIgnoreCase("file")){
									apd.setParamTypeId(3L);
								}else if(paramTypeName.equalsIgnoreCase("list")){
									apd.setParamTypeId(4L);
								}else if(paramTypeName.equalsIgnoreCase("derived attribute")){
									apd.setParamTypeId(5L);
								}else if(paramTypeName.equalsIgnoreCase("derived computation")){
									apd.setParamTypeId(6L);
								}else if(paramTypeName.equalsIgnoreCase("rich text")){
									apd.setParamTypeId(7L);
								}
							
								
								// validation
								if(apd.getIs_static() == 1 && apd.isHasImportantValue()){
									  return Response
											     .status(Status.OK)
											     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
											       Constants.FAILURE, "BOTH STATIC AND IMPORTANT CANNOT BE TRUE"))
											     .build();
								}
								
								if(apd.getIs_static() == 1 && apd.getParamTypeId() == 7){
									  return Response
											     .status(Status.OK)
											     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
											       Constants.FAILURE, "Rich text static is not yet implemented"))
											     .build();
								}
								
									if (apd.getParamTypeId() == 1L) {
										if (ParamjsonObj.has("size")) {
											if(ParamjsonObj.getInt("size") == 0){
												return Response
														.status(Status.OK).entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
																Constants.FAILURE,"TEXT SIZE CANNOT BE ZERO")).build();
											
											}else{
												int x= ParamjsonObj.getInt("size");
												if(x>9999){
													return Response
															.status(Status.OK).entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
																	Constants.FAILURE,"MAXIMUM TEXT SIZE EXCEED")).build();
												}
											}
											
											apd.setSize(ParamjsonObj.getInt("size"));
										} else {
											return Response
													.status(Status.OK).entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE,"PROVIDE TEXT SIZE")).build();
										}
									} else{
										apd.setSize(0);
									}
								
								apd.setLastUpdatedTime(new Timestamp(new Date().getTime()));
								apd.setMappedAssetId(0L);// by default set 0
								//list type validation
								
								if(apd.getParamTypeId() == 4L){
									if(ParamjsonObj.has("listTypeParamTypeName")){
										listTypeParamName =  ParamjsonObj.getString("listTypeParamTypeName");
										if(listTypeParamName.equalsIgnoreCase("customlist")){
											apd.setListTypeParamTypeId(1L); 
										}else if(listTypeParamName.equalsIgnoreCase("assetlist")){
											apd.setListTypeParamTypeId(2L); 
										}else if(listTypeParamName.equalsIgnoreCase("userlist")){
											apd.setListTypeParamTypeId(3L); 
										}
									}else{
										return Response
												.status(Status.OK)
												.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
														Constants.FAILURE,"PROVIDE PARAMETER LIST TYPE"))
														.build();
									}
								}else{
									apd.setListTypeParamTypeId(0L);
								}
								
								if(apd.getParamTypeId().toString().equals("4")){
									if(apd.getListTypeParamTypeId().toString().equals("1")){
										if(ParamjsonObj.has("customListValues")){
											List<PossibleValues> listOfCustoms = new ArrayList<PossibleValues>(); 
											String customListArray = ParamjsonObj.get("customListValues").toString();
											if(customListArray.length() != 0 && customListArray.startsWith("[")){
												JSONArray customArray = new JSONArray(customListArray); 
											
												if (customArray != null) { 
													   for (int r=0;r<customArray.length();r++){ 
														   PossibleValues p = new PossibleValues();
															p.setValue(customArray.getString(r));
															listOfCustoms.add(p);
													   } 
												}
												apd.setCustomListValues(listOfCustoms);
												
											}else{
												return Response
														.status(Status.OK)
														.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
																Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
																.build();
											}
											
										}else{
											return Response
													.status(Status.OK)
													.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE,"PROVIDE CUSTOM LIST VALUES"))
															.build();
										}
									}
									if (apd.getListTypeParamTypeId().toString().equals("2")){
										if(ParamjsonObj.has("mappedAssetName")){
											mapped_Asset_Name = ParamjsonObj.getString("mappedAssetName");
											AssetDef assetDefid = assetdao.getAssetsByAssetName(mapped_Asset_Name, null);
											if(assetDefid == null){
												return Response
														.status(Status.OK)
														.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
																Constants.FAILURE,"INVALID MAPPED ASSET NAME"))
																.build();
											}
											apd.setMappedAssetId(assetDefid.getAssetId());

										}else{ 
											return Response
													.status(Status.OK)
													.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
															Constants.FAILURE,"PROVIDE MAPEED ASSET NAME"))
															.build();}
									}
								}
								apd.setModifyByUserId(user.getUserId());
							
								if(ParamjsonObj.has("derivedAttributeComputation")){
								if(ParamjsonObj.getString("derivedAttributeComputation").equals("")){
									apd.setDerivedAttributeComputation(null);	
								}else{
									apd.setDerivedAttributeComputation(ParamjsonObj.getString("derivedAttributeComputation"));
								}
								}else{
									apd.setDerivedAttributeComputation(null);	
								}
								
								
								// derived attribute and computation rule check 
							
								String message = "";
								if(apd.getDerivedAttributeComputation()!= null){
									if(apd.getParamTypeId().toString().equals("5")){
							           	 message = commonutil.validationForDerivedAttribute(apd.getDerivedAttributeComputation(),assetName,apd.getAssetParamName(),null);
									}else if(apd.getParamTypeId().toString().equals("6")){
								          message = commonutil.validationForDerivedComputation(apd.getDerivedAttributeComputation(),assetName,apd.getAssetParamName(),null);
									}
								
								if(message != null){
									 return Response
										     .status(Status.OK)
										     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
										       Constants.FAILURE, message))
										     .build();
								}
								}
								listOfDefs.add(apd);
								category.setListOfAssetParamDefs(listOfDefs);
							}
							listOfCategories.add(category);
						}
						addAsset.setCategories(listOfCategories);
						}else{
							  return Response
									     .status(Status.OK)
									     .entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
									       Constants.FAILURE,Constants.ASSET_CATEGORY_CAN_NOT_BE_NULL))
									     .build();
						}
					}catch(Exception e){
						return Response
								.status(Status.OK)
								.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
										.build();
						
					}
						//asset category dupliation check
						
						for(int i=0;i<dupliactecat.size();i++){
							for(int j= i+1 ;j<dupliactecat.size() ; j++){
								if(dupliactecat.get(i).equalsIgnoreCase(dupliactecat.get(j))){
									duplicateCatFalg = true;
									break;
								}
							}
						}
						if(duplicateCatFalg){

							log.warn("addAsset || Assetcategory  by this name already exists,please provide different name ");
							//result.add("Assetcategory  by this name already exists, please provide different name");
						//	jsonRslt = Constants.ASSET_CATEGORY_NAME_ALREADY_EXISTS;	

							return Response
									.status(Status.OK)
									.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
											Constants.FAILURE,"DUPLICATE CATEGORY NAME EXIST"))
											.build();
					
						}
						
						// parameter duplication check
						for(int i=0;i<dupliacteparam.size();i++){
							for(int j= i+1 ;j<dupliacteparam.size() ; j++){
								if(dupliacteparam.get(i).equalsIgnoreCase(dupliacteparam.get(j))){
									duplicateParamFalg = true;
									break;
								}
							}
							
						}
						if(duplicateParamFalg){

							log.warn("addAsset || AssetParam  by this name already exists,please provide different name ");
							//result.add("AssetParam  by this name already exists, please provide different name");
							//jsonRslt = Constants.ASSET_PARAM_NAME_ALREADY_EXISTS;	
							//jsonList.add(jsonRslt);

							return Response
									.status(Status.OK)
									.entity(new MyModelRest(Constants.INSERT_STATUS_SUCCESS,
											Constants.FAILURE,"DUPLICATE PARAMETER NAME EXIST"))
											.build();
						}
						
					if(addAsset == null) { 
							log.warn("addAsset || Asset data to be added is not provided");
							return Response
									.status(Status.OK).entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,Constants.FAILURE, 
											MessageUtil.getMessage(Constants.INVALID_DATA)))
											.build();
						}else{
							boolean flagForDuplicateAsset = false;
							List<AssetDef> assetDefList = new ArrayList<AssetDef>();

							if (log.isTraceEnabled()) {
								log.trace("addAsset || dao method called : getAllAssets()");
							}
							assetDefList = assetdao.getAllAssets(conn);

							for(AssetDef list : assetDefList){
								if(list.getAssetName().equalsIgnoreCase(addAsset.getAssetName())){
									flagForDuplicateAsset = true;
								}
							}
							if(flagForDuplicateAsset == true){
								log.warn("addAsset || Asset by this name already exists, please provide different name");
								//result.add("Asset by this name already exists, please provide different name");
								//jsonRslt = Constants.ASSET_NAME_EXIST;	
								return Response
										.status(Status.OK)
										.entity(new MyModelRest(Constants.GET_STATUS_SUCCESS,
												Constants.FAILURE, MessageUtil
												.getMessage(Constants.ASSET_NAME_EXIST)))
												.build();
							}else{ 

								List<Category> categories = addAsset.getCategories();
								if(categories==null){
									retMsg = Constants.ASSET_CATEGORY_CAN_NOT_BE_NULL;
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retStatScsFlr = Constants.GET_STATUS_SUCCESS;
									return Response
											.status(retStat)
											.entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg))
											.build();
								}
								
								// dispay position check 
								
								ArrayList<Integer> newcatArray = new ArrayList<Integer>();
								
								for(Category cat : categories){
									if(cat.getCatDisp() != null){
									newcatArray.add(Integer.parseInt(cat.getCatDisp()));
									}
								}

								for(int i=0;i<categories.size();i++){
									Category cat = categories.get(i);
									if(cat.getListOfAssetParamDefs()==null){
										retMsg = Constants.ASSET_CATEGORY_PARAMETER_CAN_NOT_BE_NULL;
										retStat = Status.OK;
										retScsFlr = Constants.FAILURE;
										retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
										return Response
												.status(retStat)
												.entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg))
												.build();
									}
								}
								addAsset1 = assetdao.addAsset(addAsset, conn);
								int catDisplsyPosition = 0;
								Long assetId = addAsset1.getAssetId();
								for(int i=0;i<categories.size();i++){

									Boolean checkflag = false;

									if (log.isTraceEnabled()) {
										log.trace("addCategoryDefinition || dao method called : addCategoryDefinition() ");
									}
									Long categoryId ;
									if(categories.get(i).getCatDisp() != null){
										//int catvalue = Integer.parseInt(categories.get(i).getCatDisp().toString());
										categoryId = assetdao.addCategoryDefinition(addAsset1, categories.get(i), conn, Integer.parseInt(categories.get(i).getCatDisp()));									
									}
									else{
										checkflag = checkInArray(catDisplsyPosition, newcatArray,catDisplsyPosition);
										categoryId = assetdao.addCategoryDefinition(addAsset1, categories.get(i), conn, catDisplsyPosition);
										catDisplsyPosition++;
									}

									// default select of group admin for category 
									//if(!categoryName.equalsIgnoreCase(BusinessConstants.DUMMY_CATEGORY)){

									List<GroupDetails> groupDetailsBos = groupDao.getAllGroups(conn);
									for(GroupDetails groupDetailsBo : groupDetailsBos){
										if(groupDetailsBo.getGroupName().equalsIgnoreCase("group-admin")){
											if (log.isTraceEnabled()) {
												log.trace("addCategoryDefinition || dao method called : addCategoryWiseAccessForAsset() ");
											}
											assetdao.addCategoryWiseAccessForAsset(categoryId, groupDetailsBo.getGroupId(), conn);
										}
									}
									//}

									if(categoryId!=0){
										//catDisplsyPosition++;

										ArrayList<Integer> newparamArray = new ArrayList<Integer>();
										int paramdisplayPosition = 0;
										List<AssetParamDef> paramDefs = categories.get(i).getListOfAssetParamDefs();
										for(int j=0;j<paramDefs.size();j++){
											for(AssetParamDef apd8 : paramDefs ){
												if(apd8.getParamDisp() != null){
													newparamArray.add(Integer.parseInt(apd8.getParamDisp()));
												}
											}
											AssetParamDef assetParamDef = paramDefs.get(j);

											if (log.isTraceEnabled()) {
												log.trace("addParameterDefinition || dao method called : addParameterDefinition() " + assetParamDef.toString());
											}
											Long parameterId ;
											if(assetParamDef.getParamDisp() != null){
												parameterId = assetdao.addParameterDefinition(addAsset1, categoryId, assetParamDef,addAsset.getUserId(),Integer.parseInt(assetParamDef.getParamDisp()),conn);
											}else{
												checkflag = checkInArray(paramdisplayPosition, newparamArray,paramdisplayPosition);
												parameterId = assetdao.addParameterDefinition(addAsset1, categoryId, assetParamDef,addAsset.getUserId(),paramdisplayPosition,conn);
												paramdisplayPosition++;
											}
											if(assetParamDef.getParamTypeId().toString().equals("4")){
												if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){

													List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
													for (PossibleValues possibleValues : customListValues) {
														assetdao.insertPossibleValues(parameterId, possibleValues.getValue(), conn);
													}
												}
											}

											if(parameterId==0){
												retMsg = Constants.ASSET_PARAMETER_CAN_NOT_CREATED;
												retStat = Status.OK;
												retScsFlr = Constants.FAILURE;
												retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
												return Response
														.status(retStat)
														.entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg))
														.build();
											}else{
												paramDefs.get(j).setAssetCategoryId(categoryId);;
												paramDefs.get(j).setAssetParamId(parameterId);
											}
											//paramdisplayPosition++;
										}
										categories.get(i).setParameters(paramDefs);
										categories.get(i).setCategoryId(categoryId);
									}else{
										retMsg = Constants.ASSET_CATEGORY_CAN_NOT_CREATED;
										retStat = Status.OK;
										retScsFlr = Constants.FAILURE;
										retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
										return Response.status(retStat).entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg)).build();
									}

								}
								retMsg = Constants.ASSET_CREATED;
								retStat = Status.OK;
								retScsFlr = Constants.SUCCESS;
								retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;

								addAsset.setAssetId(assetId);
								addAsset.setCategories(categories);

								//group asset access
								groupDao.addGroupsAssetAccessSubmit(assetId, addAsset.getGroupAccessForAsset(), conn);
							}
							//adding assigned taxonomies
							
							tdao.addassignedTaxonomies(addAsset.getAssetId(),addAsset.getAssetAssignedTaxonomies(),conn);
							
							log.info(" addAsset || "+ addAsset.toString() +" added asset successfully");
							
							if(NewFileName != null) {
								if(!NewFileName.equals("")){
									BufferedImage image = null;
									BufferedImage invertedImage = null;
									image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
									int ik = addAsset.getIconImageName().lastIndexOf('.');
									if (ik > 0) {
										extension = addAsset.getIconImageName().substring(ik+1);
									}
									
									InputStream newImg = new FileInputStream(System.getProperty("user.home") +"/inverted_new."+extension);
									invertedImage = ImageIO.read(newImg);
									if(image!=null){
										String uploadedFileLocation = request.getRealPath("");
										String uploadedInvertedFileLocation = request.getRealPath("");
										
										
										if (NewFileName.toLowerCase().indexOf("jpg".toLowerCase()) != -1
												|| NewFileName.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
											uploadedFileLocation = uploadedFileLocation
													+ Constants.ASSET_IMAGE_FILE_NAME +addAsset1.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
											ImageIO.write(image, "jpg", new File(
													uploadedFileLocation));
											
											//inverted images
											if(invertedImage != null) {
												uploadedInvertedFileLocation = uploadedInvertedFileLocation
														+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+addAsset1.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
												ImageIO.write(invertedImage, "jpg", new File(
														uploadedInvertedFileLocation));
											}

										} else if (NewFileName.toLowerCase().indexOf("png".toLowerCase()) != -1 || NewFileName.toUpperCase().indexOf(
												"png".toUpperCase()) != -1) {
											uploadedFileLocation = uploadedFileLocation
													+ Constants.ASSET_IMAGE_FILE_NAME +addAsset1.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
											ImageIO.write(image, "png", new File(uploadedFileLocation));
											
											//inverted images
											if(invertedImage != null) {
												uploadedInvertedFileLocation = uploadedInvertedFileLocation
														+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+addAsset1.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
												ImageIO.write(invertedImage, "png", new File(uploadedInvertedFileLocation));

											}
										}
									}	
								}
							}

						}
					
					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					List<String> emailIds = new ArrayList<String>();

					List<User> usersList = userDao.getUsers(false, conn);

					for(User u : usersList){
						if(u.isSubscribe() == true){
							emailIds.add(u.getEmailId());
						}
					}

					if(!emailIds.isEmpty()){
						String mailTemp = "";
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetType");
						mailTemp = mtVo.getMailTemplate();
						mailTemp = mailTemp.replaceAll("%assetType%", addAsset.getAssetName());

						for(String emailId:emailIds){
							MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);

							SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(Constants.REPOPRO_NEW_ASSET_TYPE_CREATED), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
					}

					String log1 = user.getFullName() + ";" + action + ";"+ addAsset.getAssetName() + ";"+ "" + ";" + "";
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(log1);
					recentActivity.setAssetId(addAsset.getAssetId().toString());
					recentActivity.setAssetInstVersionId("");
					recentActivity.setUser_id(user.getUserId());

					if (log.isTraceEnabled()) {
						log.trace("addAsset || dao method called : addRecentActivity() ");
					}
					recentActivityDao.addRecentActivity(recentActivity, conn);
					conn.commit();
					
					// end add logic	
						
					}else{
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					log.trace("deleteAssetInstanceVersionsMain || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}	
				}
					
			}catch(RepoproException e){
				log.error("addAssetMain ||  " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} catch(Exception e){
				log.error("addAssetMain ||  " + Constants.LOG_EXCEPTION + e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addAssetMain || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if(log.isTraceEnabled()){
				log.trace("addAssetMain ||  End");
			}
		
			return Response
					.status(retStat)
					.entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg))
					.build();
		}

		
	public boolean checkInArray(int currentState, ArrayList<Integer> newcatArray,int catDisplsyPosition )
	{   Boolean falg1 = false;
		for (Integer i : newcatArray)
		{
			if (i == currentState)

			{
				falg1 = true;
			}
			
			if(falg1){
					 catDisplsyPosition++;
					 checkInArray(catDisplsyPosition, newcatArray,catDisplsyPosition);
			}
		}
		return false;
	}

	@PUT
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML ,MediaType.MULTIPART_FORM_DATA})
	@Path("/update")
	public Response updateAssetMain(@QueryParam("assetName") String assetName,
			@QueryParam("newAssetName") String newassetname,
			@FormDataParam("CategoryObject")String CategoryObject,
			@HeaderParam("token") String token,
			FormDataMultiPart bodyParts,
			@Context HttpServletRequest request) {
				
		if(assetName == null|| CategoryObject == null ){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
			     .build();
		}
		
		if(assetName.isEmpty()|| CategoryObject.isEmpty()){
			   return Response
			     .status(Status.BAD_REQUEST)
			     .entity(new MyModel(Constants.STATUS_FAILURE,
			       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
			     .build();
		}
		
		log.trace("updateAssetMain || Begin");
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		String extension = "";
		try {

			if (log.isTraceEnabled()) {
				log.trace("updateAssetMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			UserDao userDao = new UserDao();
			List<String> result = new ArrayList<String>();
			List<String> jsonList = new ArrayList<String>();
			AssetDao assetdao = new AssetDao();
			GroupDao groupDao = new GroupDao();
			RoleDao roledao = new RoleDao();
			Boolean adminFlag = false;
			Boolean roleFlag = false;
			User user = new User();
			String jsonRslt;
			CommonUtils commonutil = new CommonUtils();
			List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			List<AssetInstVersionTaxonomy> assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
			String userName = "";
			allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
			if(token != null){
				User userdata = commonutil.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				return Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			} else {
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}

				adminFlag = assetInstanceVersionDao.findAdminRightsByUserName(
						userName, conn);
				if (!adminFlag) {
					if (user != null) {
						userfunctionMappedWithRoleId = roledao
								.retAllRoleFunctionsMappedWithUserId(
										user.getUserId(), conn);
					}

					for (UserFunction uf : userfunctionMappedWithRoleId) {
						if (uf.getFunctionDescription().equalsIgnoreCase(
								"ROLE_MNG_ASSETS")) {
							roleFlag = true;
							break;
						}
					}
				}

				if (adminFlag || roleFlag) {

					// update asset logic
					
					AssetDef updateAsset = null;
					if (assetName != null)
						updateAsset = new AssetDef();
					String jsonStr = CategoryObject;
					List<String> dupliacteparam = new ArrayList<String>();
					boolean duplicateParamFalg = false;
					List<String> dupliactecat = new ArrayList<String>();
					boolean duplicateCatFalg = false;
					try {

						AssetDef assetDef = assetdao.getAssetsByAssetName(assetName, null);
						if (assetDef.getAssetId() == null) {
							retStat = Status.OK;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.ASSET_DATA_NOT_FOUND;
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;

							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

						}
						updateAsset.setAssetId(assetDef.getAssetId());
						
						
						JSONParser parser = new JSONParser();
						org.json.simple.JSONObject json = (org.json.simple.JSONObject) parser
								.parse(jsonStr);
						JSONObject json1 = new JSONObject(jsonStr);
                   
						if(json1.has("description")){
							updateAsset.setDescription(json1.getString("description"));
						}else{
							retStat = Status.OK;
							retScsFlr = Constants.FAILURE;
							retMsg = "PROVIDE ASSET DESCRIPTION";
							retStatScsFlr = Constants.GET_STATUS_SUCCESS;
							return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						
						if (json1.has("versionableFlag")) {
							updateAsset.setVersionable(json1.getBoolean("versionableFlag"));
						} else {
							updateAsset.setVersionable(false);
						}
						if (json1.has("guestFlag")) {
							updateAsset.setGuestflag(json1.getBoolean("guestFlag"));
						} else {
							updateAsset.setGuestflag(false);
						}

						if (json1.has("ratingDescription")) {
							updateAsset.setRatingDescription(json1.getString("ratingDescription").toString());
						} else {
							updateAsset.setRatingDescription("Overall experience in terms of using the asset instance and the quality of its documentation: 5-Outstanding, 4-Excellent, 3-Acceptable, 2-Inadequate, 1-Very Poor");
						}

						Map<Long, String> tax = new HashMap<Long, String>();
						if (json.get("assetAssignedTaxonomies") != null) {
							String assetAssignedTaxonomies = json.get("assetAssignedTaxonomies").toString();
							if(assetAssignedTaxonomies.length() != 0 && !assetAssignedTaxonomies.startsWith("[")){
								retStat = Status.OK;
								retScsFlr = Constants.FAILURE;
								retMsg = Constants.INVALID_DATA;
								retStatScsFlr = Constants.GET_STATUS_SUCCESS;
								return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							
							}
							JSONArray taxArray = new JSONArray(assetAssignedTaxonomies);
							String assetAssignedTaxonomies1 = "";
							for(int g = 0;g<taxArray.length();g++){
								assetAssignedTaxonomies1 = assetAssignedTaxonomies1.concat(taxArray.getString(g)+",");
							}
							if (assetAssignedTaxonomies1.length() != 0) {
								TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
								String taxonomyValue = assetAssignedTaxonomies1;
								final List<TaxonomyMaster> tmList = taxonomiesDao
										.getAllTaxonomiesByParentId(1L, conn);
								if (!taxonomyValue.equalsIgnoreCase("")) {
									for(TaxonomyMaster t:tmList){
										recurse(t);
									}
									allTaxs.put((long) 1, tmList);
									
									String[] addedTaxIds = new String[]{};
									String[] addedTaxIds1 = new String[]{};
									AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();
									List<Long> idsForTaxon = new ArrayList<Long>();
									/*if(taxonomyValue.endsWith(","))
									{
										retStat = Status.OK;
										retScsFlr = Constants.FAILURE;
										retMsg = Constants.INVALID_DATA;
										retStatScsFlr = Constants.GET_STATUS_SUCCESS;
										return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
									}*/
									//else
									//{
										if(taxonomyValue.length() > 0 )
										{
												addedTaxIds = taxonomyValue.split(",");
												Boolean flag2 = true;
												for(int t =0; t< addedTaxIds.length && flag2; t++)
												{
													List<TaxonomyMaster> tmpTaxList = tmList;
													addedTaxIds1 = addedTaxIds[t].split("/");

													for(int h =0; h< addedTaxIds1.length; h++)
													{
														Boolean flag = false;
														Long taxNextId = null;
														for(TaxonomyMaster tm:tmpTaxList)
														{
															if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
																flag = true;
																aiatVo.setTaxonomyName(tm.getTaxonomyName());
																taxNextId = tm.getTaxonomyId();
																break;
															}
														}
														if(!flag)
														{
															retStat = Status.OK;
															retScsFlr = Constants.FAILURE;
															retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
															retStatScsFlr = Constants.GET_STATUS_SUCCESS;
															return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
														}
														else
														{
															for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
															{
																if(entry.getKey() ==  taxNextId)
																{ 
																	tmpTaxList = entry.getValue();
																}
															}
														}
														if(h == addedTaxIds1.length-1)
														{
															Boolean fl = false;
															Boolean f2 = false;
															
															for(Long Id:idsForTaxon)
															{
																if(Id.equals(taxNextId))
																{
																	fl = true;
																	break;
																}
															}
															if(fl)
															{
																retStat = Status.OK;
																retScsFlr = Constants.FAILURE;
																retMsg = Constants.DUPLICATE_TAXONOMY_DATA_NOT_ALLOWED;
																retStatScsFlr = Constants.GET_STATUS_SUCCESS;
																return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
															}
															
															else
															{
																idsForTaxon.add(taxNextId);
															}
														}
													}
												}
											
										}
										else
										{
											idsForTaxon = Collections.<Long>emptyList();
										}
										aiatVo.setTaxonIds(idsForTaxon);
										assetInstassignList.add(aiatVo);
										for(int i=0;i<assetInstassignList.size();i++){
											for(int j=0;j<assetInstassignList.get(i).getTaxonIds().size();j++){
												TaxonomyMaster names=taxonomiesDao.getTaxonomiesByTaxId(assetInstassignList.get(i).getTaxonIds().get(j), conn);
												tax.put(assetInstassignList.get(i).getTaxonIds().get(j),names.getTaxonomyName());
											}
										}
									//}
								}

								updateAsset.setAssetAssignedTaxonomies(tax);
							} else {
								updateAsset.setAssetAssignedTaxonomies(tax);
							}
						} else {
							updateAsset.setAssetAssignedTaxonomies(tax);
						}

						List<Map<String, Long>> groupAccess = new ArrayList<Map<String, Long>>();

						if (json.get("groupAccessForAsset") != null) {
							String groupAccessForAsset = json.get("groupAccessForAsset").toString();
							JSONArray groupAccessForAssetArray = new JSONArray(groupAccessForAsset);
							for (int i = 0; i < groupAccessForAssetArray.length(); i++) {
								GroupDetails gd = new GroupDetails();
								int group_id;
								String group_name = null;
								Map<String, Long> groupAccesForRow = new HashMap<String, Long>();
								JSONObject jsonObj = groupAccessForAssetArray.getJSONObject(i);
								if (jsonObj.has("group_name")) {
									group_name = jsonObj.getString("group_name");
								} else {
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retMsg = Constants.GROUP_DATA_NOT_FOUND;
									retStatScsFlr = Constants.GET_STATUS_SUCCESS;
									return Response
											.status(retStat)
											.entity(new MyModelRest(retStatScsFlr, retScsFlr,retMsg)).build();
								}
								group_id = groupDao.getGroupIdByGroupName(group_name, null);
								if (group_id == 0) {
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retMsg = Constants.GROUP_DATA_NOT_FOUND;
									retStatScsFlr = Constants.GET_STATUS_SUCCESS;
									return Response
											.status(retStat)
											.entity(new MyModelRest(retStatScsFlr, retScsFlr,retMsg)).build();
								}
								groupAccesForRow.put("group_id",(long) group_id);
								if (jsonObj.has("add_access")) {
									groupAccesForRow.put("add_access",
											(Long) ((Integer) jsonObj.getInt("add_access")).longValue());
								} else {
									groupAccesForRow.put("add_access", 0L);
								}
								if (jsonObj.has("edit_access")) {
									groupAccesForRow.put("edit_access",
											(Long) ((Integer) jsonObj.getInt("edit_access")).longValue());
								} else {
									groupAccesForRow.put("edit_access", 0L);
								}
								if (jsonObj.has("view_access")) {
									groupAccesForRow.put("view_access",
											(Long) ((Integer) jsonObj.getInt("view_access")).longValue());
								} else {
									groupAccesForRow.put("view_access", 0L);
								}
								if (jsonObj.has("delete_access")) {
									groupAccesForRow.put("delete_access",
											(Long) ((Integer) jsonObj.getInt("delete_access")).longValue());
								} else {
									groupAccesForRow.put("delete_access", 0L);
								}
								groupAccess.add(groupAccesForRow);
							}
							updateAsset.setGroupAccessForAsset(groupAccess);
						}
						
						List<Category> catdao = assetdao.getCategoriesByassetId(updateAsset.getAssetId(),null);
						Map<String ,Long> catmapaccess = new HashMap<String ,Long>();
						
						for(Category cat : catdao){
							catmapaccess.put(cat.getCategoryName(), cat.getCategoryId());
						}
						
						//Fetching CategoryAccess for Asset
						Map<Long, Set<GroupDetails>> categoriesWithAccess  = new HashMap<Long, Set<GroupDetails>>();
						if (json.get("categoriesWithAccess") != null) {
						String categoryAccess = json.get("categoriesWithAccess").toString();
						JSONObject CatAccess = new JSONObject(categoryAccess);
						JSONArray CatAccessArray = new JSONArray("["+CatAccess.toString()+"]");
						
						for(int i=0; i<CatAccessArray.length(); i++){
							Iterator itr = CatAccessArray.getJSONObject(i).keys();
							while (itr.hasNext()) {
								Object keyName = itr.next();
								String setOfGroupDetails = CatAccessArray.getJSONObject(i).get(keyName.toString()).toString();
								JSONArray GroupDetailsArray = new JSONArray(setOfGroupDetails);

								Set<GroupDetails>  groupDetails = new HashSet<GroupDetails>();

								for(int j=0; j<GroupDetailsArray.length(); j++){
									JSONObject groupDetailsjsonObj = GroupDetailsArray.getJSONObject(j);

									GroupDetails gd = new GroupDetails();
									
									gd.setMappedWithUser(groupDetailsjsonObj.getBoolean("mappedWithUser"));
									gd.setGroupName(groupDetailsjsonObj.getString("group_name"));
									 long group_id = groupDao.getGroupIdByGroupName(gd.getGroupName(), null);
									if (group_id == 0) {
										retStat = Status.OK;
										retScsFlr = Constants.FAILURE;
										retMsg = Constants.GROUP_DATA_NOT_FOUND;
										retStatScsFlr = Constants.GET_STATUS_SUCCESS;
										return Response
												.status(retStat)
												.entity(new MyModelRest(retStatScsFlr, retScsFlr,retMsg)).build();
									}
									gd.setGroupId(group_id);
									gd.setCategoryName(keyName.toString());
									groupDetails.add(gd);
								}
								categoriesWithAccess.put(catmapaccess.get(keyName.toString()),groupDetails);
							}
						}

						updateAsset.setCategoriesWithAccess(categoriesWithAccess);
						}
					
						
						
						updateAsset.setUserName(userName);
						updateAsset.setUserId(user.getUserId());

						if (json.get("categoryDetailsList") != null) {
							String categoriesArray = json.get("categoryDetailsList").toString();
							JSONArray array = new JSONArray(categoriesArray);
							List<Category> listOfCategories = new ArrayList<Category>();
							for (int i = 0; i < array.length(); i++) {

								String paramTypeName = null;
								String listTypeParamName = null;
								String mapped_Asset_Name = null;
								Category category = new Category();
								JSONObject jsonObj = array.getJSONObject(i);
								if (jsonObj.has("categoryName")) {
	                                category.setCategoryName(jsonObj.getString("categoryName"));
	                                category.setCategoryId(catmapaccess.get(category.getCategoryName())); 
								} else {
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(
													Constants.STATUS_FAILURE,Constants.FAILURE,
													MessageUtil.getMessage(Constants.INVALID_DATA))).build();
								}
								dupliactecat.add(category.getCategoryName());
								if(jsonObj.has("actionForCategory"))
								category.setActionForCategory(jsonObj.getString("actionForCategory"));
								String parametersArray = null;
								if (jsonObj.has("catDisplayPosition")) {
									category.setCatDisp(jsonObj.getString("catDisplayPosition"));
								}
								if (jsonObj.has("parameterDataList")) {
									parametersArray = jsonObj.get("parameterDataList").toString();
								} else {
									return Response
											.status(Status.BAD_REQUEST)
											.entity(new MyModelRest(
													Constants.STATUS_FAILURE,Constants.FAILURE,
													MessageUtil.getMessage(Constants.INVALID_DATA))).build();
								}
								JSONArray parametersJsonArray = new JSONArray(parametersArray);
								List<AssetParamDef> listOfDefs = new ArrayList<AssetParamDef>();
								for (int j = 0; j < parametersJsonArray.length(); j++) {
									AssetParamDef apd = new AssetParamDef();
									JSONObject ParamjsonObj = parametersJsonArray.getJSONObject(j);
									if (ParamjsonObj.has("assetParamName")) {
										apd.setAssetParamName(ParamjsonObj.getString("assetParamName"));
									} else {
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(
														Constants.STATUS_FAILURE,Constants.FAILURE,
														MessageUtil.getMessage(Constants.INVALID_DATA))).build();
									}
									dupliacteparam.add(apd.getAssetParamName());
									if(jsonObj.has("actionForParameter"))
										apd.setActionForParameter(jsonObj.getString("actionForParameter"));
									if (ParamjsonObj.has("paramDisplayPosition")) {
										apd.setParamDisp(ParamjsonObj.getString("paramDisplayPosition"));
									}
									if (ParamjsonObj.has("defaultView")) {
										apd.setDefaultView(ParamjsonObj.getInt("defaultView"));
									} else {
										apd.setDefaultView(0);
									}
									if (ParamjsonObj.has("is_static")) {
										apd.setIs_static(ParamjsonObj.getInt("is_static"));
									} else {
										apd.setIs_static(0);
									}
									if (ParamjsonObj.has("hasImportantValue")) {
										apd.setHasImportantValue(ParamjsonObj.getBoolean("hasImportantValue"));
									} else {
										apd.setHasImportantValue(false);
									}
									if (ParamjsonObj.has("hasMandatoryValue")) {
										apd.setHasMandatoryValue(ParamjsonObj.getBoolean("hasMandatoryValue"));
									} else {
										apd.setHasMandatoryValue(true);
									}
									if (ParamjsonObj.has("paramDescription")) {
										apd.setDescription(ParamjsonObj.getString("paramDescription"));
									} else {
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(
														Constants.STATUS_FAILURE,Constants.FAILURE,
														MessageUtil.getMessage(Constants.INVALID_DATA))).build();
									}
									if (ParamjsonObj.has("paramTypeName")) {
										paramTypeName = ParamjsonObj.getString("paramTypeName");
									} else {
										return Response
												.status(Status.BAD_REQUEST)
												.entity(new MyModelRest(
														Constants.STATUS_FAILURE,Constants.FAILURE,
														MessageUtil.getMessage(Constants.INVALID_DATA))).build();
									}

									if (paramTypeName.equalsIgnoreCase("text")) {
										apd.setParamTypeId(1L);
									} else if (paramTypeName.equalsIgnoreCase("date")) {
										apd.setParamTypeId(2L);
									} else if (paramTypeName.equalsIgnoreCase("file")) {
										apd.setParamTypeId(3L);
									} else if (paramTypeName.equalsIgnoreCase("list")) {
										apd.setParamTypeId(4L);
									} else if (paramTypeName.equalsIgnoreCase("derived attribute")) {
										apd.setParamTypeId(5L);
									} else if (paramTypeName.equalsIgnoreCase("derived computation")) {
										apd.setParamTypeId(6L);
									}

									if (apd.getParamTypeId() == 1L) {
										if (ParamjsonObj.has("size")) {
											apd.setSize(ParamjsonObj.getInt("size"));
										} else {
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(
															Constants.STATUS_FAILURE,Constants.FAILURE,
															MessageUtil.getMessage(Constants.INVALID_DATA))).build();
										}
									} else {
										apd.setSize(0);
									}

									apd.setLastUpdatedTime(new Timestamp(new Date().getTime()));

									// list type validation

									if (apd.getParamTypeId() == 4L) {
										if (ParamjsonObj.has("listTypeParamTypeName")) {
											listTypeParamName = ParamjsonObj
													.getString("listTypeParamTypeName");
											if (listTypeParamName.equalsIgnoreCase("customlist")) {
												apd.setListTypeParamTypeId(1L);
											} else if (listTypeParamName.equalsIgnoreCase("assetlist")) {
												apd.setListTypeParamTypeId(2L);
											} else if (listTypeParamName.equalsIgnoreCase("userlist")) {
												apd.setListTypeParamTypeId(3L);
											}
										} else {
											// apd.setListTypeParamTypeId( 0L);
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(
															Constants.STATUS_FAILURE,Constants.FAILURE,
															MessageUtil.getMessage(Constants.INVALID_DATA))).build();
										}
									}

									if (apd.getParamTypeId().toString().equals("4")) {
										if (apd.getListTypeParamTypeId().toString().equals("1")) {
											if (ParamjsonObj.has("customListValues")) {
												List<PossibleValues> listOfCustoms = new ArrayList<PossibleValues>();
												String customListArray = ParamjsonObj.get("customListValues").toString();
												if (customListArray.length() == 0) {
													return Response
															.status(Status.BAD_REQUEST)
															.entity(new MyModelRest(
																	Constants.STATUS_FAILURE,Constants.FAILURE,
																	MessageUtil.getMessage(Constants.INVALID_DATA))).build();
												}
												JSONArray customArray = new JSONArray(
														parametersArray);

												String[] split = customListArray.split(",");

												for (int k = 0; k < split.length; k++) {
													PossibleValues p = new PossibleValues();
													p.setValue(split[k]);
													listOfCustoms.add(p);
												}
												apd.setCustomListValues(listOfCustoms);
											} else {
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(
																Constants.STATUS_FAILURE,Constants.FAILURE,
																MessageUtil.getMessage(Constants.INVALID_DATA))).build();
											}
										}
										if (apd.getListTypeParamTypeId().toString().equals("2")) {
											if (ParamjsonObj.has("mappedAssetName")) {
												mapped_Asset_Name = ParamjsonObj.getString("mappedAssetName");
												AssetDef assetDefid = assetdao
														.getAssetsByAssetName(mapped_Asset_Name,null);
												apd.setMappedAssetId(assetDefid.getAssetId());

											} else {
												return Response
														.status(Status.BAD_REQUEST)
														.entity(new MyModelRest(
																Constants.STATUS_FAILURE,Constants.FAILURE,
																MessageUtil.getMessage(Constants.INVALID_DATA))).build();
											}
										} else {
											apd.setMappedAssetId(0L);
										}
									}

									apd.setModifyByUserId(user.getUserId());

									if (ParamjsonObj.has("derivedAttributeComputation")) {
										if (ParamjsonObj.getString("derivedAttributeComputation").equals("")) {
											apd.setDerivedAttributeComputation(null);
										} else {
											apd.setDerivedAttributeComputation(ParamjsonObj.getString("derivedAttributeComputation"));
										}
									} else {
										apd.setDerivedAttributeComputation(null);
									}

									// derived attribute and computation rule
									// check

									String message = "";
									if (apd.getDerivedAttributeComputation() != null) {
										if (apd.getParamTypeId().toString().equals("5")) {
											message = commonutil
													.validationForDerivedAttribute(apd.getDerivedAttributeComputation(),assetName,apd.getAssetParamName(),null);
										} else if (apd.getParamTypeId().toString().equals("6")) {
											message = commonutil
													.validationForDerivedComputation(
															apd.getDerivedAttributeComputation(),assetName,apd.getAssetParamName(),null);
										}

										if (message != null) {
											return Response
													.status(Status.BAD_REQUEST)
													.entity(new MyModelRest(
															Constants.STATUS_FAILURE,
															Constants.FAILURE,message)).build();
										}
									}
									listOfDefs.add(apd);
									category.setListOfAssetParamDefs(listOfDefs);
								}
								listOfCategories.add(category);
							}
							updateAsset.setCategories(listOfCategories);
						} else {
							return Response
									.status(Status.OK)
									.entity(new MyModelRest(
											Constants.STATUS_FAILURE,Constants.FAILURE,
											MessageUtil.getMessage(Constants.INVALID_DATA))).build();
						}
					} catch (org.json.JSONException e) {
						e.printStackTrace();
					}
					// asset category dupliation check

					for (int i = 0; i < dupliactecat.size(); i++) {
						for (int j = i + 1; j < dupliactecat.size(); j++) {
							if (dupliactecat.get(i).equalsIgnoreCase(
									dupliactecat.get(j))) {
								duplicateCatFalg = true;
								break;
							}
						}
					}
					if (duplicateCatFalg) {

						log.warn("addAsset || Assetcategory  by this name already exists,please provide different name ");
						result.add("Assetcategory  by this name already exists, please provide different name");
						//jsonRslt = Constants.ASSET_CATEGORY_NAME_ALREADY_EXISTS;
						//jsonList.add(jsonRslt);
						return Response
								.status(Status.OK)
								.entity(new MyModelRest(
										Constants.GET_STATUS_SUCCESS,
										Constants.FAILURE,
										Constants.ASSET_CATEGORY_NAME_ALREADY_EXISTS)).build();
					}

					// parameter duplication check
					for (int i = 0; i < dupliacteparam.size(); i++) {
						for (int j = i + 1; j < dupliacteparam.size(); j++) {
							if (dupliacteparam.get(i).equalsIgnoreCase(
									dupliacteparam.get(j))) {
								duplicateParamFalg = true;
								break;
							}
						}

					}
					if (duplicateParamFalg) {

						log.warn("addAsset || AssetParam  by this name already exists,please provide different name ");
						result.add("AssetParam  by this name already exists, please provide different name");
						//jsonRslt = Constants.ASSET_PARAM_NAME_ALREADY_EXISTS;
						//jsonList.add(jsonRslt);

						return Response
								.status(Status.OK)
								.entity(new MyModelRest(
										Constants.INSERT_STATUS_SUCCESS,
										Constants.FAILURE,Constants.ASSET_PARAM_NAME_ALREADY_EXISTS))
								.build();

					}

					if (log.isTraceEnabled()) {
						log.trace("updateAsset || dao method called : getAssetDefByAssetId() "
								+ updateAsset.getAssetId());
					}

					AssetDef addAsset1 = null;
					String action = Constants.ACTIVITY_CREATE;
					RecentActivity recentActivity = new RecentActivity();
					RecentActivityDao recentActivityDao = new RecentActivityDao();
					TaxonomiesDao taxDao = new TaxonomiesDao();
					List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
					FormDataBodyPart dataMultiPart = null;
					String NewFileName = null;
					RelationshipDao relationshipDao = new RelationshipDao();
					FavouritesDao favouritesDao = new FavouritesDao();
					allTaxs = new LinkedHashMap<Long, List<TaxonomyMaster>>();
					InputStream fileInverted = null;

					 
					if(newassetname != null && newassetname.length() != 0){
					updateAsset.setAssetName(newassetname);
					}else{
						updateAsset.setAssetName(assetName);
					}
				
					AssetDef assetDef = assetdao.getAssetsByAssetName(assetName, null);
					if (assetDef.getAssetId() == null) {
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.ASSET_DATA_NOT_FOUND;
						retStatScsFlr = Constants.GET_STATUS_SUCCESS;

						return Response
								.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();

					}
					updateAsset.setAssetId(assetDef.getAssetId());
					AssetDef oldAssetDef = assetdao.getAssetsByAssetId(
							updateAsset.getAssetId(), conn);

					boolean flagForDuplicateAsset = false;

					Map<String, String> changedParamNames = new HashMap<String, String>();

					List<AssetDef> assetDefList = new ArrayList<AssetDef>();

					if (log.isTraceEnabled()) {
						log.trace("updateAsset || dao method called : getAllAssets()");
					}
					assetDefList = assetdao.getAllAssets(conn);
					if (!oldAssetDef.getAssetName().equalsIgnoreCase(
							updateAsset.getAssetName().trim()))
						for (AssetDef list : assetDefList) {
							if (list.getAssetName().equalsIgnoreCase(
									updateAsset.getAssetName().trim())) {
								flagForDuplicateAsset = true;
								break;
							}
						}
					if (flagForDuplicateAsset == true) {
						log.warn("Update || Asset by this name already exists, please provide different name");
						result.add("Asset by this name already exists, please provide different name");
						//jsonRslt = Constants.ASSET_NAME_EXIST;
						//jsonList.add(jsonRslt);

						return Response
								.status(Status.OK)
								.entity(new MyModelRest(
										Constants.GET_STATUS_SUCCESS,
										Constants.FAILURE,
										Constants.ASSET_NAME_EXIST)).build();
					}
					String oldAssetName = oldAssetDef.getAssetName();
					String newAssetName = updateAsset.getAssetName();
					
					Long assetId = updateAsset.getAssetId();
					if (bodyParts != null) {
						dataMultiPart = bodyParts.getField("iconImageName");
						if(dataMultiPart != null){
							NewFileName = dataMultiPart.getContentDisposition()
									.getFileName();
							if (!NewFileName.isEmpty()|| NewFileName.length() != 0) {
								
								InvertImage invertImage = new InvertImage();
								fileInverted = invertImage.inverImage(dataMultiPart
										.getEntityAs(InputStream.class), dataMultiPart
										.getContentDisposition().getFileName());
								//InputStream targetStream = new FileInputStream(file);
								updateAsset.setIconImage(dataMultiPart
										.getEntityAs(InputStream.class));
								updateAsset.setIconImageName(NewFileName);
								updateAsset.setInvertedIconImage(fileInverted);
							}
							if(NewFileName.equals("")||NewFileName.length() == 0){
								AssetDef ad1 = assetdao.getFileNameByAssetId(assetId, conn);
									updateAsset.setIconImageName(ad1.getIconImageName());
									updateAsset.setIconImage(ad1.getIconImage());
									updateAsset.setInvertedIconImage(ad1.getInvertedIconImage());
								}
						}
					}

					assetdao.updateAsset(updateAsset, conn);
					List<Category> listOfCategories1 = updateAsset.getCategories();
					if(listOfCategories1==null){
						retMsg = "We can not create asset with out categories";
						return Response
								.status(retStat)
								.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
								.build(); 

					}

					if(listOfCategories1.size()==0){
						retMsg = "We can not create asset with out categories";
						return Response
								.status(retStat)
								.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg))
								.build(); 
					}

					
					List<String> delCatName = new ArrayList<String>();
					List<Long> catID = new ArrayList<Long>();
					List<AssetParamDef> apf = new ArrayList<AssetParamDef>();
					List<AssetParamDef> listofDefs = assetdao.getCategoryNameAndParametersByAssetId(assetId, conn);
					for(int i=0;i<listOfCategories1.size();i++){
						Category category = listOfCategories1.get(i);
						String actionForCategory = category.getActionForCategory();
						/*for(int ll=0;i<listofDefs.size();ll++){
							AssetParamDef assetParam  =listofDefs.get(ll);

						}*/
						if(actionForCategory!=null){
							if(actionForCategory.equalsIgnoreCase("DELETE")){//deletion category
								delCatName.add(category.getCategoryName());
								Map<Long, Set<GroupDetails>> catWiseAccess = updateAsset.getCategoriesWithAccess();
								catWiseAccess.remove(category.getCategoryId());

								//apf = category.getListOfAssetParamDefs();
								//catID.add(category.getCategoryId());
								List<AssetParamDef> paramdefs =category.getListOfAssetParamDefs();
								for (AssetParamDef assetParamDef : paramdefs) {
									if (log.isTraceEnabled()) {
										log.trace("updateAsset || dao method called : deleteParameter() "+updateAsset.getAssetId());
									}
									assetdao.deleteParameter(assetParamDef.getAssetParamId(), conn);
								}
								if (log.isTraceEnabled()) {
									log.trace("updateAsset || dao method called : deleteCategory() "+category.getCategoryId());
								}
								assetdao.deleteCategory(category.getCategoryId(), conn);
							}
							else if(actionForCategory.equalsIgnoreCase("ADD")){//adding category
								if (log.isTraceEnabled()) {
									log.trace("updateAsset || dao method called : addCategory() category "+category +" assetid "+assetId);
								}


								//Map<Long, Set<GroupDetails>> catWiseAccess = updateAsset.getCategoriesWithAccess();

								Long assetCategoryId = assetdao.addCategory(category, assetId, conn);

								// default check of group admin for category

								List<GroupDetails> groupDetailsBos = groupDao.getAllGroups(conn);
								for(GroupDetails groupDetailsBo : groupDetailsBos){
									if(groupDetailsBo.getGroupName().equalsIgnoreCase("group-admin")){
										if (log.isTraceEnabled()) {
											log.trace("addCategoryDefinition || dao method called : addCategoryWiseAccessForAsset() ");
										}
										assetdao.addCategoryWiseAccessForAsset(assetCategoryId, groupDetailsBo.getGroupId(), conn);
									}
								}

								List<AssetParamDef> paramdefs = category.getListOfAssetParamDefs();
								for (AssetParamDef assetParamDef : paramdefs) {
									assetParamDef.setAssetCategoryId(assetCategoryId);
									if (log.isTraceEnabled()) {
										log.trace("updateAsset || dao method called : addParameter() "+assetParamDef);
									}

									if (assetParamDef.getActionForParameter()
											.equalsIgnoreCase("NO CHANGES")) {

										assetdao.UpdateParameterDragged(assetParamDef,
												conn);
									}
									if (assetParamDef.getActionForParameter()
											.equalsIgnoreCase("ADD")) {
										int paramId = assetdao.addParameter(assetParamDef, conn);
										if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){

											List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
											for (PossibleValues possibleValues : customListValues) {
												assetdao.insertPossibleValues((long)paramId, possibleValues.getValue(), conn);
											}
										}
									}
								}
							}
							else if(actionForCategory.equalsIgnoreCase("UPDATE")){

								List<AssetParamDef> paramDefs = category.getListOfAssetParamDefs();
								if (log.isTraceEnabled()) {
									log.trace("updateAsset || dao method called : getAllDerivedAttributes() ");
								}

								List<AssetParamDef> allDerivedAttributes = assetdao.getAllDerivedAttributes(conn);	
								assetdao.updateCategory(category, assetId, conn);
								for (AssetParamDef assetParamDef : paramDefs) {

									String actionForParameter = assetParamDef.getActionForParameter();
									AssetParamDef backendParamDef = assetdao.getAssetParamDefByAssetParamId(assetParamDef.getAssetParamId(), conn);
									changedParamNames.put(backendParamDef.getAssetParamName(),assetParamDef.getAssetParamName());
									if(actionForParameter!=null){
										if(actionForParameter.equalsIgnoreCase("NO CHANGES"))
										{
											if (log.isTraceEnabled()) {
												log.trace("updateAsset || dao method called : UpdateParameterDragged() "+assetParamDef.toString());
											}
											
											// commented updateParameterDefinition for drag and drop issue .
											int paramId = assetdao.updateParameterDefinition(assetParamDef, conn);
											//dao.UpdateParameterDragged(assetParamDef, conn);

											/*

										if (log.isTraceEnabled()) {
											log.trace("updateAsset || dao method called : deleteParameter() "+assetParamDef.getAssetParamId());
										}
										int paramId = dao.deleteParameter(assetParamDef.getAssetParamId(), conn);
										if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){
											List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
											for (PossibleValues possibleValues : customListValues) {
												dao.deletePossibleValues((long)paramId,conn);
											}
										}
										assetParamDef.setAssetCategoryId(category.getCategoryId());
										if (log.isTraceEnabled()) {
											log.trace("updateAsset || dao method called : addParameter() "+assetParamDef);
										}
										int paramId1=dao.addParameter(assetParamDef, conn);
										if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){
											List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
											for (PossibleValues possibleValues : customListValues) {
												dao.insertPossibleValues((long)paramId1, possibleValues.getValue(), conn);
											}
										}

											 */
										}

										if(actionForParameter.equalsIgnoreCase("UPDATE")){

											/*	for (AssetParamDef derivedDef : allDerivedAttributes) {

												if(derivedDef.getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){
													Long parameterID = assetParamDef.getAssetParamId();
													if (log.isTraceEnabled()) {
														log.trace("updateAsset || dao method called : getAssetParamDefByAssetParamId() "+parameterID);
													}
													AssetParamDef backendParamDef = dao.getAssetParamDefByAssetParamId(parameterID, conn);
													Long assetParamId  = backendParamDef.getAssetParamId();
													Pattern  p = Pattern.compile(oldAssetDef.getAssetName()+"[\\{]"+backendParamDef.getAssetParamName()+"[\\}]");
													String rule = derivedDef.getDerivedAttributeComputation();
													Matcher m = p.matcher(rule);
													boolean flagForParameterCheck = false;

													rule = rule.replaceAll("[\\}](ELSE )(?i)"+oldAssetName+"[\\[]", "}ELSE "+newAssetName+"[");
													rule = rule.replaceAll("(?i)"+oldAssetName+"[\\[]", newAssetName+"[");
													rule = rule.replaceAll("[\\]](?i)"+oldAssetName+"[\\[]","]"+newAssetName+"[");
													rule = rule.replaceAll("[\\[](?i)"+oldAssetName+"[\\.]", "["+newAssetName+".");
													rule = rule.replaceAll("[\\]](?i)"+oldAssetName+"[\\{]", "]"+newAssetName+"{");

													if(m.find()){
														rule = rule.replaceAll("[\\{](?i)"+oldAssetName+"[\\}]", "{"+newAssetName+"}");
														flagForParameterCheck = true;
													}
													boolean flagForAssetNameChecking =  oldAssetName.equalsIgnoreCase(newAssetName);
													if(flagForAssetNameChecking){
														flagForAssetNameChecking = false;
													}

													if( flagForAssetNameChecking || flagForParameterCheck){
														if (log.isTraceEnabled()) {
															log.trace("updateAsset || dao method called : modifingRuleById() "+parameterID);
														}
														dao.modifingRuleById(assetParamId, rule, conn);
													}
												}else if(derivedDef.getParamTypeId().equals(Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID)){
													Long parameterID = assetParamDef.getAssetParamId();
													if (log.isTraceEnabled()) {
														log.trace("updateAsset || dao method called : getAssetParamDefByAssetParamId() "+parameterID);
													}
													AssetParamDef backendParamDef = dao.getAssetParamDefByAssetParamId(parameterID, conn);
													Long assetParamId  = backendParamDef.getAssetParamId();
													String rule = derivedDef.getDerivedAttributeComputation();
													Pattern  p = Pattern.compile(backendParamDef.getAssetParamName()+"==");
													boolean flagForDerivedComputationCheck = false;

													Matcher m = p.matcher(rule);
													if(m.find()){
														rule = rule.replaceAll(backendParamDef.getAssetParamName()+"==",assetParamDef.getAssetParamName()+"==");
														flagForDerivedComputationCheck = true;
													}

													boolean flagForAssetNameChecking =  oldAssetName.equalsIgnoreCase(newAssetName);

													if(flagForAssetNameChecking){
														flagForAssetNameChecking = false;
													}
													rule = rule.replaceAll("(?i)"+oldAssetName+"[\\[]", newAssetName+"[");
													rule = rule.replaceAll("(ELSE )(?i)"+oldAssetName+"[\\[]", "ELSE "+newAssetName+"[");
													rule = rule.replaceAll("[\\]](?i)"+oldAssetName+"[\\[]", "]"+newAssetName+"[");
													rule = rule.replaceAll("[\\[](?i)"+oldAssetName+"[\\.]", "["+newAssetName+".");
													rule = rule.replaceAll("[\\]](?i)"+oldAssetName+".count", "]"+newAssetName+".count");

													if(flagForAssetNameChecking || flagForDerivedComputationCheck){
														if (log.isTraceEnabled()) {
															log.trace("updateAsset || dao method called : modifingRuleById() "+parameterID);
														}
														dao.modifingRuleById(assetParamId, rule, conn);
													}

												}
											}*/
											assetParamDef.setAssetCategoryId(category.getCategoryId());

											if((backendParamDef.getIs_static() == assetParamDef.getIs_static())){

												if (log.isTraceEnabled()) {
													log.trace("updateAsset || dao method called : updateParameterDefinition() "+assetParamDef);
												}

												int paramId = assetdao.updateParameterDefinition(assetParamDef, conn);

											}else{
												if (log.isTraceEnabled()) {
													log.trace("updateAsset || dao method called : updateParameter() "+assetParamDef);
												}
												int paramId = assetdao.updateParameter(assetParamDef, conn);
											}

											//int paramId = dao.updateParameter(assetParamDef, conn);// satic values empty whn parameter update
											if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){

												assetdao.deletePossibleValues((long)assetParamDef.getAssetParamId(),conn);

												List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
												for (PossibleValues possibleValues : customListValues) {
													//dao.updatePossibleValues((long)assetParamDef.getAssetParamId(), possibleValues.getValue(), possibleValues.getValueId(), conn);
													assetdao.insertPossibleValues((long)assetParamDef.getAssetParamId(), possibleValues.getValue(), conn);
												}
											}
										}else if (actionForParameter.equalsIgnoreCase("DELETE")) {
											if (log.isTraceEnabled()) {
												log.trace("updateAsset || dao method called : deleteParameter() "+assetParamDef.getAssetParamId());
											}
											int paramId = assetdao.deleteParameter(assetParamDef.getAssetParamId(), conn);
											if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){
												List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
												for (PossibleValues possibleValues : customListValues) {
													assetdao.deletePossibleValues((long)assetParamDef.getAssetParamId(),conn);
												}
											}
										}else if(actionForParameter.equalsIgnoreCase("ADD")){
											assetParamDef.setAssetCategoryId(category.getCategoryId());
											if (log.isTraceEnabled()) {
												log.trace("updateAsset || dao method called : addParameter() "+assetParamDef);
											}
											int paramId=assetdao.addParameter(assetParamDef, conn);
											if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){
												List<PossibleValues> customListValues = assetParamDef.getCustomListValues();
												for (PossibleValues possibleValues : customListValues) {
													assetdao.insertPossibleValues((long)paramId, possibleValues.getValue(), conn);
												}
											}
										}
									}
								}
							}
						}
					}

					
					List<AssetParamDef> listofDefs1 = relationshipDao.getAssetParamDefByDerivedAttributeIsNotNull(conn);
					// List<AssetParamDef> listofDefs1 = dao.getCategoryNameAndParametersByAssetId(assetId, conn);

					for (int k = 0; k < listofDefs1.size(); k++) {

						AssetParamDef def = listofDefs1.get(k);
						String rules1 = def.getDerivedAttributeComputation();

						for (Map.Entry<String, String> entry : changedParamNames.entrySet()){
							if(def.getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){
								String[] rules = rules1.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\]]");
								for (int i = 0; i < rules.length; i++) {
									if(rules[i].startsWith("IF")){
										rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");
									}else if(rules[i].startsWith("ELSE IF")){
										rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");

									}
								}
							}

						}

						for (Map.Entry<String, String> entry : changedParamNames.entrySet()){

							if(def.getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){

								String[] rules = rules1.split("[\\{][#]?[a-zA-Z0-9_ ]+[#]?[\\]]");
								for (int i = 0; i < rules.length; i++) {
									if(rules[i].startsWith("IF")){
										rules1 = rules1.replaceAll(oldAssetName+"[\\{](?i)"+entry.getKey()+"[\\}]", newAssetName+"{"+entry.getValue()+"}");
									}else if(rules[i].startsWith("ELSE IF")){
										rules1 = rules1.replaceAll(oldAssetName+"[\\{](?i)"+entry.getKey()+"[\\}]", newAssetName+"{"+entry.getValue()+"}");

									}else if(rules[i].startsWith("ELSE")){
										rules1 = rules1.replaceAll(oldAssetName+"[\\{](?i)"+entry.getKey()+"[\\}]", newAssetName+"{"+entry.getValue()+"}");
									}else{
										rules1 = rules1.replaceAll(oldAssetName+"[\\{](?i)"+entry.getKey()+"[\\}]", newAssetName+"{"+entry.getValue()+"}");
									}
								}
							}

						}

						for (Map.Entry<String, String> entry : changedParamNames.entrySet()){
							if(def.getParamTypeId().equals(Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID)){
								String[] rules = rules1.split("\\.count");
								for (int i = 0; i < rules.length; i++) {
									if(rules[i].startsWith("IF")){
										rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");
									}else if(rules[i].startsWith("ELSE IF")){
										rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");
									}
								}

							}

						}

						// ("Before : "+rules1);
						for (Map.Entry<String, String> entry : changedParamNames.entrySet()){
							// (entry.getKey() + "/" + entry.getValue());
							if(def.getParamTypeId().equals(Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID)){



								/*if(!oldAssetName.equalsIgnoreCase(newAssetName))
									rules1 = rules1.replaceAll("[\\{](?i)"+entry.getKey()+"[\\}]", "{"+entry.getValue()+"}");*/

								rules1 = rules1.replaceAll("[\\}](ELSE )(?i)"+oldAssetName+"[\\[]", "}ELSE "+newAssetName+"[");
								rules1 = rules1.replaceAll("(?i)"+oldAssetName+"[\\[]", newAssetName+"[");
								rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+"[\\[]","]"+newAssetName+"[");
								rules1 = rules1.replaceAll("[\\[](?i)"+oldAssetName+"[\\.]", "["+newAssetName+".");
								rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+"[\\{]", "]"+newAssetName+"{");
							}
							if(def.getParamTypeId().equals(Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID)){
								/*if(!oldAssetName.equalsIgnoreCase(newAssetName))
									rules1 = rules1.replaceAll("(?i)[\\.]"+entry.getKey()+"[\\=]", "."+entry.getValue()+"=");*/
								//rules1 = rules1.replaceAll(oldAssetName+"(?i)[\\.]"+entry.getKey()+"[\\=]", newAssetName+"."+entry.getValue()+"=");
								rules1 = rules1.replaceAll("(?i)"+oldAssetName+"[\\[]", newAssetName+"[");
								rules1 = rules1.replaceAll("(ELSE )(?i)"+oldAssetName+"[\\[]", "ELSE "+newAssetName+"[");
								rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+"[\\[]", "]"+newAssetName+"[");
								rules1 = rules1.replaceAll("[\\[](?i)"+oldAssetName+"[\\.]", "["+newAssetName+".");
								rules1 = rules1.replaceAll("[\\]](?i)"+oldAssetName+".count", "]"+newAssetName+".count");
							}


						}
						//def.setDerivedComputedDescription(rules1);
						// ("After : "+rules1);
						//parameterDefController.updateParamDefRule(def);

						assetdao.modifingRuleById(def.getAssetParamId(), rules1, conn);
					}
					//adding assigned group access for asset 

					groupDao.addGroupsAssetAccessSubmit(assetId, updateAsset.getGroupAccessForAsset(), conn);

					// adding assigned taxonomies
					TaxonomiesDao tdao = new TaxonomiesDao();
					tdao.addassignedTaxonomies(assetId, updateAsset.getAssetAssignedTaxonomies(), conn);

					//add categorywiseaccessfor groups by categoryId
					List<Category> categories = updateAsset.getCategories();

					for (int k = 0; k < categories.size(); k++) {
						Category cat = categories.get(k);
						if(cat.getActionForCategory() == null){
							cat.setActionForCategory("NO CHANGES");
						}
							//if(cat.getActionForCategory().equalsIgnoreCase("UPDATE")){
						if(!(cat.getActionForCategory().equalsIgnoreCase("ADD")||cat.getActionForCategory().equalsIgnoreCase("DELETE"))){
							//if(!cat.getCategoryName().equalsIgnoreCase("DUMMY_CATEGORY")){
								Map<Long, Set<GroupDetails>> selectedGroups = updateAsset.getCategoriesWithAccess();
								Set<GroupDetails> groupDetails = selectedGroups.get(cat.getCategoryId());
								Map<Long,String> map1 = new HashMap<Long, String>();
								Iterator<GroupDetails> itr = groupDetails.iterator();
								while(itr.hasNext()){
									GroupDetails gd = itr.next();
									if(gd.isMappedWithUser()){
										map1.put(gd.getGroupId(),"");
									}
								}
								assetdao.addCategoryWiseAccessForGroups(cat.getCategoryId(),map1 , conn);
							//}
						}
						
					}
					
					if(NewFileName != null) {
						if(!NewFileName.equals("")){
							BufferedImage image = null;
							BufferedImage invertedImage = null;
							image = ImageIO.read(dataMultiPart.getEntityAs(InputStream.class));
							int ik = updateAsset.getIconImageName().lastIndexOf('.');
							if (ik > 0) {
								extension = updateAsset.getIconImageName().substring(ik+1);
							}
							
							InputStream newImg = new FileInputStream(System.getProperty("user.home") +"/inverted_new."+extension);
							invertedImage = ImageIO.read(newImg);
							
							File deletedFile1 = new File(System.getProperty("user.home")+"/inverted_new."+extension);
							if(deletedFile1.exists()) {
								deletedFile1.delete();
							}
							
							if(image!=null){
								String uploadedFileLocation = request.getRealPath("");
								String uploadedInvertedFileLocation = request.getRealPath("");
								String serverPath = request.getRealPath("");
								
								if (NewFileName.toLowerCase().indexOf("jpg".toLowerCase()) != -1
										|| NewFileName.toUpperCase().indexOf("jpg".toUpperCase()) != -1) {
									uploadedFileLocation = uploadedFileLocation
											+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
									
									//To delete existing
									File originalFile = new File(serverPath
											+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME);
									
								//	File originalFile = new File(uploadedFileLocation);
									if(originalFile.exists()){
										originalFile.delete();
									}
									
									ImageIO.write(image, "jpg", new File(
											uploadedFileLocation));
									
									//inverted images
									if(invertedImage != null) {
										uploadedInvertedFileLocation = uploadedInvertedFileLocation
												+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME ;
										
										File originalFileInverted = new File(serverPath
												+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+updateAsset.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME);
										
										//File originalFileInverted = new File(uploadedInvertedFileLocation);
										if(originalFileInverted.exists()){
											originalFileInverted.delete();
										}
										
										ImageIO.write(invertedImage, "jpg", new File(
												uploadedInvertedFileLocation));
									}

								} else if (NewFileName.toLowerCase().indexOf("png".toLowerCase()) != -1 || NewFileName.toUpperCase().indexOf(
										"png".toUpperCase()) != -1) {
									uploadedFileLocation = uploadedFileLocation
											+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
									//To delete existing
									File originalFile = new File(serverPath
											+ Constants.ASSET_IMAGE_FILE_NAME +updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME);
									if(originalFile.exists()){
										originalFile.delete();
									}
									ImageIO.write(image, "png", new File(uploadedFileLocation));
									
									//inverted images
									if(invertedImage != null) {
										uploadedInvertedFileLocation = uploadedInvertedFileLocation
												+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+updateAsset.getAssetId()+Constants.ASSET_IMAGE_PNG_NAME;
										
										//To delete existing
										File originalFileInverted = new File(serverPath
												+ Constants.ASSET_IMAGE_FILE_NAME +"inverted_"+updateAsset.getAssetId()+Constants.ASSET_IMAGE_JPG_NAME);
										if(originalFileInverted.exists()){
											originalFileInverted.delete();
										}
										ImageIO.write(invertedImage, "png", new File(uploadedInvertedFileLocation));

									}
								}
							}	
						}
					}
					
					
					retMsg = Constants.ASSET_UPDATED;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					log.info("updateAsset || " + updateAsset.toString() + " updated asset successfully");
					conn.commit();

					MailTemplateDao mailTemplateDao = new MailTemplateDao();
					List<String> emailIds = new ArrayList<String>();

					
					SubscriptionDao subscriptionDao = new SubscriptionDao();

					user = userDao.retProfileForUserName(updateAsset.getUserName(), conn);
					emailIds = subscriptionDao.getSubscribersForAsset(updateAsset.getAssetId(), conn);

					if(!emailIds.isEmpty()){
						String mailTemp = "";
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetType");
						mailTemp = mtVo.getMailTemplate();
						mailTemp = mailTemp.replaceAll("%assetType%", updateAsset.getAssetName());

						for(String emailId:emailIds){
							MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);

							SendEmail.sendTextMail(mailConfig, emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_TYPE_DETAILS_UPDATED), MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

						}
					}

					String log1 = user.getFullName() + ";" + action + ";"+ updateAsset.getAssetName() + ";"+ "" + ";"+ "";
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setDescription(log1);
					recentActivity.setAssetId(updateAsset.getAssetId().toString());
					recentActivity.setAssetInstVersionId("");
					recentActivity.setUser_id(user.getUserId());

					if (log.isTraceEnabled()) {
						log.trace("updateAsset || dao method called : addRecentActivity() ");
					}
					recentActivityDao.addRecentActivity(recentActivity, conn);

					favouritesDao.OnRenameAssetRenameFavourites(oldAssetName, newAssetName, conn);

					conn.commit();
					
	
					File deletedFile = new File(System.getProperty("user.home")+"/inverted_new."+extension);
					if(deletedFile.exists()) {
						deletedFile.delete();
					}
					File deleteOriginalFile = new File(System.getProperty("user.home")+"/inverted."+extension);
					if(deleteOriginalFile.exists()) {
						deleteOriginalFile.delete();
					}	
					
					File deletedFile1 = new File(System.getProperty("user.home")+"/inverted_new."+extension);
					if(deletedFile1.exists()) {
						deletedFile1.delete();
					}
				}
			}
		}catch(RepoproException e){
			log.error("updateAssetMain ||  " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch(Exception e){
			log.error("updateAssetMain ||  " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("updateAssetMain ||  End");
		}
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg))
				.build();	
	}


	/**
	 * @method : getAllFilteredAssets
	 * @description : to get all the assets
	 * @return Response success message
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Encoded
	@Path("/getAllFilteredAssetsForSubscription")
	public Response getAllFilteredAssetsForSubscription(@QueryParam("userName")String userName,@QueryParam("userId") Long userId,@QueryParam("searchString") String searchString,@QueryParam("subscriptionFlag")String flag) {

		log.trace("getAllFilteredAssetsForSubscription || Begin");

		Connection conn = null;

		UserAssetSubscription uas = null;

		List<AssetDef> assetList = new ArrayList<AssetDef>();
		List<UserAssetSubscription> subscriptionList = new ArrayList<UserAssetSubscription>();

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetsForSubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			String actualValue = URLDecoder.decode(searchString, "UTF-8");
			String value = "";
			if (searchString.contains("_") || searchString.contains("%")){
				value = actualValue;
				value = value.replace("_", "\\_");
				value = value.replace("%", "\\%");
			}else{
				value = actualValue;
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetDao dao = new AssetDao();
			SubscriptionDao subDao = new SubscriptionDao();
			UserDao userDao = new UserDao();

			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetsForSubscription || dao method called : getUserByUserId()");
			}
			User userByUserId = userDao.getUserByUserId(userId, conn);

			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetsForSubscription || dao method called : getAllFilteredAssetsForSubscription()");
			}
			assetList = dao.getAllFilteredAssetsForSubscription(value,conn);

			for (AssetDef ad : assetList) {
				uas = subDao.getAllSubscriptionsByAsset(ad.getAssetId(),userId, conn);
				uas.setAssetId(ad.getAssetId());
				uas.setAssetName(ad.getAssetName());
				uas.setUserId(userId);
				uas.setNotifyFlag(userByUserId.isSubscribe());
				uas.setIconImageName(ad.getIconImageName());
				if(flag.equalsIgnoreCase("true")){
					if(uas.getSubscriptionFlag().equalsIgnoreCase("subscribed")){
						subscriptionList.add(uas);
					}
				}else if(flag.equalsIgnoreCase("false")){
					if(!uas.getSubscriptionFlag().equalsIgnoreCase("subscribed")){
						subscriptionList.add(uas);
					}
				}else{
					subscriptionList.add(uas);
				}
				
			}

			log.debug(" getAllFilteredAssetsForSubscription || retrieved " + assetList.size()
					+ " assets successfully");


			retMsg = Constants.ALL_ASSETS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getAllFilteredAssetsForSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAllFilteredAssetsForSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetsForSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (assetList.isEmpty()) {
			retMsg = Constants.ASSETS_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.ALL_ASSETS_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}

		log.trace("getAllFilteredAssetsForSubscription || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(subscriptionList))).build();
	}

	
	/**
	 * @method : getAllAssets
	 * @description : to get all the assets
	 * @return Response success message
	 */
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/fetchallassetsdetails")
	public Response fetchAllAssetsDetails(@QueryParam("userName") String userName) {
		log.trace("fetchAllAssetsDetails || Begin ");
		Connection conn = null;
		List<AssetDef> assetList = new ArrayList<AssetDef>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()){
				log.trace("fetchAllAssetsDetails || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			Boolean flag = false;
			AssetDao dao = new AssetDao();
			AssetInstanceDao assetInstDao = new AssetInstanceDao();
			AssetInstanceVersionDao aiv = new AssetInstanceVersionDao();
			RelationshipDao relationshipDao = new RelationshipDao();
			
			if (log.isTraceEnabled()) {
				log.trace("fetchAllAssetsDetails || dao method called : fetchAllAssetsDetails()");
			}
			assetList = dao.fetchAllAssetsDetails(conn);
		
			// checking where asset have add access

			flag = aiv.findAdminRightsByUserName(userName, conn);
			if(flag == false){
				for(int i =0;i<assetList.size();i++){
					AssetInstance ai = assetInstDao.getAssetLevelAddAccessForLoginUser(assetList.get(i).getAssetName(), userName, conn);
					if(ai.getAddAccessFlag() == false){
						assetList.remove(i);
						i=i-1;
					}
				}
			}
			
			// checking destiantion asset acess for composition and aggregation type 
			for(int j =0;j<assetList.size();j++){
				boolean destFalg = false;
				List<AssetRelationshipDef> ardForDestAsset = new ArrayList<AssetRelationshipDef>();
				ardForDestAsset = relationshipDao.retAssetRelationshipDefByDestAssetId(assetList.get(j).getAssetId(), conn);
				for(AssetRelationshipDef ard :ardForDestAsset ){
					if(ard.getFwdRelId() == 1L || ard.getFwdRelId() == 5L){
						destFalg = true;
						break;
					}
				}
				if(destFalg){
					assetList.remove(j);
					j=j-1;
				}
			}

			log.debug(" fetchAllAssetsDetails || retrieved "+ assetList.size() +" assets successfully");


			if (assetList.isEmpty()) {
				retMsg = Constants.ASSETS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.ALL_ASSETS_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}

		} catch(RepoproException e){
			log.error("fetchAllAssetsDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("fetchAllAssetsDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("fetchAllAssetsDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		log.trace("fetchAllAssetsDetails || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(assetList))).build();
	}


	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/enableOrDisableSingleMultiSelectListAndIsArray")
	public Response enableOrDisableSingleMultiSelectListAndIsArray(@QueryParam("assetId") Long assetId) {
		log.trace("enableOrDisableSingleMultiSelectListAndIsArray || Begin ");
		Connection conn = null;
		List<AssetDef> assetList = new ArrayList<AssetDef>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetDef def = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("enableOrDisableSingleMultiSelectListAndIsArray || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("enableOrDisableSingleMultiSelectListAndIsArray || dao method called : getAssetDefByAssetId()");
			}
			def = dao.getAssetsByAssetId(assetId, conn);

			if (log.isTraceEnabled()) {
				log.trace("enableOrDisableSingleMultiSelectListAndIsArray || dao method called : getCategoryByAssetID() :"+assetId);
			}
			List<Category> listOfCategories = dao.getCategoryByAssetID(assetId, conn);
			for(int i=0;i<listOfCategories.size();i++){
				Category category = listOfCategories.get(i);
				Long catgoryId = category.getCategoryId();
				if (log.isTraceEnabled()) {
					log.trace("enableOrDisableSingleMultiSelectListAndIsArray || dao method called : getAssetParameterDefsByCategoryID() :"+catgoryId);
				}
				List<AssetParamDef> listOfParamDefs = dao.getAssetParameterDefsByCategoryID(catgoryId, conn);
				for (int j = 0; j <listOfParamDefs.size(); j++) {
					AssetParamDef assetParamDef = listOfParamDefs.get(j);

					if(assetParamDef.getParamTypeId().toString().equals("4")){

						if(assetParamDef.getListTypeParamTypeId().toString().equals("1")){

							List<PossibleValues> customValues = dao.getAllPossibleValuesByParamId(assetParamDef.getAssetParamId(),conn);
							assetParamDef.setCustomListValues(customValues);
						}
						
						//Start add condition for multiSelectFlag harish
						if(assetParamDef.getIs_static() == 1){
							if(assetParamDef.getStaticValue()!= null){
								if(assetParamDef.getStaticValue().contains("~~")){
									assetParamDef.setMultiSelectFlag(false);
								}else{
									assetParamDef.setMultiSelectFlag(true);
								}
							}else{
								assetParamDef.setMultiSelectFlag(true);
							}
							
						}else{
						boolean multiSelectFlag = dao.enableOrDisableSingleMulti(def.getAssetName(),assetParamDef.getAssetParamName(),assetParamDef.getParamTypeId(), conn);
						if(multiSelectFlag == true){
							if(assetParamDef.getListType() == 0){
								assetParamDef.setMultiSelectFlag(true);	
							}
							if(assetParamDef.getListType() == 1){
								assetParamDef.setMultiSelectFlag(true);	
							}
						}else{
							if(assetParamDef.getListType() == 1){
								assetParamDef.setMultiSelectFlag(false);
							}
						}
					}
						//End add condition for multiSelectFlag
					}
					listOfParamDefs.set(j, assetParamDef);
					if(assetParamDef.getParamTypeId().toString().equals("1")||assetParamDef.getParamTypeId().toString().equals("7")){
						if(assetParamDef.getHasArray() == 1){
							boolean isArrayFlag = dao.enableOrDisableIsArray(def.getAssetName(),assetParamDef.getAssetParamName(),assetParamDef.getParamTypeId(), conn);
							assetParamDef.setHasArrayFlag(isArrayFlag);
						}
					}else if(assetParamDef.getParamTypeId().toString().equals("9")) {
						boolean multiSelectFlag = dao.enableOrDisableSingleMulti(def.getAssetName(),assetParamDef.getAssetParamName(),assetParamDef.getParamTypeId(), conn);
						if(multiSelectFlag == true){
							if(assetParamDef.getListType() == 0){
								assetParamDef.setMultiSelectFlag(true);	
							}
							if(assetParamDef.getListType() == 1){
								assetParamDef.setMultiSelectFlag(true);	
							}
						}else{
							if(assetParamDef.getListType() == 1){
								assetParamDef.setMultiSelectFlag(false);
							}
						}


						boolean mappingFlag = dao.enableOrDisableIsArray(def.getAssetName(),assetParamDef.getAssetParamName(),assetParamDef.getParamTypeId(), conn);
						assetParamDef.setMappingFlag(mappingFlag);
					}
					assetParamDef.setAssetCategoryId(catgoryId);
					
				category.setListOfAssetParamDefs(listOfParamDefs);
				listOfCategories.set(i, category);
			}
			}
			def.setCategories(listOfCategories);

			log.info("Successfully get the assetDetails "+def);
			
		} catch(RepoproException e){
			log.error("enableOrDisableSingleMultiSelectListAndIsArray || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("enableOrDisableSingleMultiSelectListAndIsArray || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("enableOrDisableSingleMultiSelectListAndIsArray || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		List<AssetDef> def1 =  new  ArrayList<AssetDef>();
		def1.add(def);
		log.trace("enableOrDisableSingleMultiSelectListAndIsArray || End");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(def1))).build();
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getLdapMappingList")
	public Response getLdapMappingList() {
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<LdapMapping> ldapMappingList = new ArrayList<LdapMapping>();
		try {
			AssetDao assetDao = new AssetDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingList || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingList || dao method called : getAssetID(assetName)");
			}
			ldapMappingList = assetDao.getLdapMappingList(conn);
			
			if (ldapMappingList.isEmpty()) {
				retMsg = Constants.LDAP_MAPPING_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.LDAP_MAPPING_LIST_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			
		} catch (RepoproException e) {
			log.error("getLdapMappingList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getLdapMappingList || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingList || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(ldapMappingList)))
				.build();
		
	}

	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getLdapMappingAttributeList")
	public Response getLdapMappingAttributeList(@QueryParam("ldapMappingId") int ldapMappingId) {
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		List<LdapMapping> ldapMappingAttributeList = new ArrayList<LdapMapping>();
		try {
			AssetDao assetDao = new AssetDao();
			
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingList || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingList || dao method called : getAssetID(assetName)");
			}
			ldapMappingAttributeList = assetDao.getLdapMappingAttributeList(ldapMappingId, conn);
			
			if (ldapMappingAttributeList.isEmpty()) {
				retMsg = Constants.LDAP_ATTRIBUTE_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.LDAP_MAPPING_LIST_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			
		} catch (RepoproException e) {
			log.error("getLdapMappingList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getLdapMappingList || " + Constants.LOG_EXCEPTION + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingList || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg, new ArrayList<Object>(ldapMappingAttributeList)))
				.build();
		
	}
	
	
	/**
	 * @method validationForDerivedAttribute
	 * @param text
	 * @param mainAssetName
	 * @param oldAssetName
	 * @return
	 */
	@POST
	@Consumes({ MediaType.APPLICATION_JSON})
	@Path("/validationForDerivedPatternForAssetList")
	public Response validationForDerivedAttributeForAssetList(@QueryParam("userName") String userName,
			AssetParamDef assetParamDef,
			@QueryParam("mainAssetName")String mainAssetName,
			@QueryParam("oldAssetName")String oldAssetName){

		if(log.isTraceEnabled()){
			log.trace("validationForDerivedAttributeForAssetList || Begin with text : "+ assetParamDef.toString());
		}

		CommonUtils commonUtils = new CommonUtils();
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<Object> responseMessage = new ArrayList<Object>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAttributeForAssetList || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			if(log.isTraceEnabled()){
				log.trace("validationForDerivedAttribute || dao method called : validationForDerivedAttribute()");
			}
			String responseAlertMessage = commonUtils.validationForDerivedAssetListAttribute(assetParamDef.getDerivedAssetListRule(), mainAssetName, assetParamDef.getAssetParamName(), oldAssetName, conn, userName);
			responseMessage.add(responseAlertMessage);

			retStat = Status.OK;
			retMsg = Constants.DERIVED_ATTRIBUTE_VALIDATION_SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("validationForDerivedAttributeForAssetList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("validationForDerivedAttributeForAssetList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("validationForDerivedAttributeForAssetList || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("validationForDerivedAttributeForAssetList || end");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,responseMessage)).build();
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getDefaultFilterSearch")
	public Response getDefaultFilterSearch(@QueryParam("assetName") String assetName,
			@QueryParam("userName") String userName)  {
		if (log.isTraceEnabled()) {
			log.trace("getDefaultFilterSearch ||assetName:" + assetName + ",userName:"
					+ userName + "||Begin");
		}
		Connection conn = null;
		List<SavedSearch> searchList = new ArrayList<SavedSearch>();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		AssetInstanceDao  assetInstanceDao = new AssetInstanceDao();
		AssetDef asset = new AssetDef();
		int defaultUserFilterView = 1;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getDefaultFilterSearch || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			
			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getDefaultFilterSearch || dao method called : retAssetDetail() to get asset details");
			}
			asset = assetInstanceDao.retAssetDetail(assetName, conn);
			if (log.isTraceEnabled()) {
				log.trace("getDefaultFilterSearch || dao method called : getFilterSearch()");
			}
			searchList = dao.getDefaultFilterSearch(asset.getAssetId(), userName,defaultUserFilterView, conn);
			TaxonomyMaster tax = new TaxonomyMaster();
			List<String> finaltax = new ArrayList<String>();
			for(SavedSearch search:searchList){
				if(search.getTaxValue()!=null && search.getTaxValue().length()>0){
					String[]taxs = search.getTaxValue().split("~");
					for(String taxdata:taxs){
						String taxId = taxdata.substring( 0, taxdata.indexOf(":"));
						tax = taxonomyDao.getTaxonomiesByTaxId(Long.parseLong(taxId), conn);
						String taxname = tax.getTaxonomyId()+":"+tax.getTaxonomyName();
						finaltax.add(taxname);
					}
					String res = String.join("~", finaltax);
					search.setTaxValue(res);
				}
			}
			if (log.isDebugEnabled()) {
				log.debug(" getDefaultFilterSearch || retrieved " + searchList.size()
						+ " FilterSearch data successfully");
			}
		} catch (RepoproException e) {
			log.error("getDefaultFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getDefaultFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getDefaultFilterSearch || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (searchList.isEmpty()) {
			retMsg = Constants.FILTER_SEARCH_DATA_NOT_FOUND;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} else {
			retMsg = Constants.FILTER_SEARCH_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		}
		if (log.isTraceEnabled()) {
			log.trace("getDefaultFilterSearch ||assetName:" + assetName + ",userName:"
					+ userName + "|| End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(searchList))).build();
	}
	
	@POST
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/addAivParamRule")
	public Response addAivParamRule(List<AivParamRule> aivParamRule)
	{

		if (aivParamRule == null) {
			log.warn("addAivParamRule || search data to be added is not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("addAivParamRule || " + aivParamRule.toString()+ " Begin");
			}

			Connection conn = null;
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			AssetDao assetDao = new AssetDao();
			List<AivParamRule> AivParamRulelist = new ArrayList<AivParamRule>();
			try {
				if (log.isTraceEnabled()) {
					log.trace("addAivParamRule || "+ Constants.LOG_CONNECTION_OPEN);
				}

				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("addAivParamRule ||dao call of addAivParamRule() method");
				}
				
				AivParamRulelist = assetDao.addAivParamRule(aivParamRule, conn);
				HashSet<String> rulenames = new HashSet<String>();
				for(AivParamRule rule:AivParamRulelist) {
					rulenames.add(rule.getParamRuleName());
				}
				
				if(rulenames.size() != AivParamRulelist.size()) {
					retMsg = Constants.DUPLICATE_RULE_SET_NAME;
					retStat = Status.OK;
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
				}else {
					retMsg = Constants.AIV_PARAM_RULE_CREATED_SUCCESSFULLY;
					retStat = Status.OK;
					retScsFlr = Constants.SUCCESS;
					retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				}
				
				if (log.isDebugEnabled()) {
					log.debug(" addAivParamRule || " + aivParamRule.toString()+ " added aivParamRule successfully");
				}
				conn.commit();

			} catch (RepoproException e) {
				log.error("addParamRule ||  " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			} catch (Exception e) {
				log.error("addAivParamRule ||  " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addAivParamRule || "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("addAivParamRule || " + aivParamRule.toString()+ " End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(AivParamRulelist))).build();

		}

	}
	/*@PUT
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/updateAivParamRule")
	public Response updateAivParamRule(AivParamRule aivParamRule)
	{

		if (aivParamRule == null) {
			log.warn("updateAivParamRule || search data to be added is not provided");
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			if (log.isTraceEnabled()) {
				log.trace("updateAivParamRule || " + aivParamRule.toString()+ " Begin");
			}

			Connection conn = null;
			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			AssetDao assetDao = new AssetDao();
			List<AivParamRule> AivParamRulelist = new ArrayList<AivParamRule>();
			try {
				if (log.isTraceEnabled()) {
					log.trace("updateAivParamRule || "+ Constants.LOG_CONNECTION_OPEN);
				}

				aivParamRule.setParamRuleParam1Value(URLDecoder.decode(aivParamRule.getParamRuleParam1Value(),"UTF-8"));
				
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);


				if (log.isTraceEnabled()) {
					log.trace("updateAivParamRule ||dao call of addAivParamRule() method");
				}
				assetDao.updateAivParamRule(aivParamRule, conn);
				
				AivParamRulelist.add(aivParamRule);

				retMsg = Constants.AIV_PARAM_RULE_UPDATED_SUCCESSFULLY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
				
				if (log.isDebugEnabled()) {
					log.debug(" updateAivParamRule || " + aivParamRule.toString()+ " added aivParamRule successfully");
				}
				conn.commit();

			} catch (RepoproException e) {
				log.error("updateAivParamRule ||  " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			} catch (Exception e) {
				log.error("updateAivParamRule ||  " + Constants.LOG_EXCEPTION
						+ e.getMessage());
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			} finally {
				if (log.isTraceEnabled()) {
					log.trace("updateAivParamRule || "
							+ Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("updateAivParamRule || " + aivParamRule.toString()+ " End");
			}

			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(AivParamRulelist))).build();

		}

	}*/
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getAivParamRule")
	public Response getAivParamRule(@QueryParam("userName") String userName,@QueryParam("aivId") int aivId)  {
		if (log.isTraceEnabled()) {
			log.trace("getAivParamRule ||userName:" + userName+ "aivId:"+aivId+"||Begin");
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<AivParamRule> aivParamRuleList = new ArrayList<AivParamRule>();
		List<AivParamRule> finalAivParamRuleList = new ArrayList<AivParamRule>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || dao method called : retAssetDetail() to get asset details");
			}
			
			aivParamRuleList = dao.getAivParamRule(userName, aivId, conn);
			if(!aivParamRuleList.isEmpty()) {
				for(AivParamRule rule:aivParamRuleList) {
					String[]param = rule.getParamRuleValue().split("~~");
					String paramname="";
					for(String ids:param) {
						String[]paramids = ids.split("_");
						String paramId = paramids[0];

						if(!paramId.equals("0")) {
							AssetParamDef assetParamDef = dao.getParamDetailsByParamId(Long.parseLong(paramId), conn);
							if(paramname.equalsIgnoreCase("")) {
								paramname = assetParamDef.getAssetParamName()+"~~";
							}else {
								paramname = paramname+assetParamDef.getAssetParamName()+"~~";
							}
						}else {
							if(paramname.equalsIgnoreCase("")) {
								paramname = "State"+"~~";
							}else {
								paramname = paramname+"State"+"~~";
							}
						}
					}
					if ((paramname != null) && (paramname.length() > 0)) {
					rule.setParamName(paramname.substring(0, paramname.length() - 1));
					finalAivParamRuleList.add(rule);}
				}
			}
			if (log.isInfoEnabled()) {
				log.info(" getAivParamRule || retrieved "
						+ aivParamRuleList.size()+ " FilterSearch search data successfully");
			}
			if (finalAivParamRuleList.isEmpty()) {
				retMsg = Constants.AIV_PARAM_RULE_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.AIV_PARAM_RULE_FETCHED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAivParamRule ||userName:" + userName+ "aivId:"+aivId+"||End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(finalAivParamRuleList))).build();
	}

	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getParamListWithNotiFyEnabled")
	public Response getParamsWithNotiFyEnabled(@QueryParam("assetId") Long assetId,
			@QueryParam("userName") String userName)  {

		log.trace("getParamList || begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AssetDao assetDao = new AssetDao();
		List<AssetParamDef> paramList = new ArrayList<AssetParamDef>();
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("getParamsWithNotiFyEnabled || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (log.isTraceEnabled()) {
				log.trace("getParamsWithNotiFyEnabled || dao method called : getParamsDetails()");
			}

			paramList = assetDao.getParamsWithNotiFyEnabled(userName, assetId, conn);

			Collections.sort(paramList, new AssetParamDef());

			if (log.isDebugEnabled()) {
				log.debug("getParamsWithNotiFyEnabled ||parameters list:" + paramList.size()
						+ " retrieved successfully");
			}
			retStat = Status.OK;
			retMsg = Constants.PARAMLIST_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("getParamsWithNotiFyEnabled || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getParamsWithNotiFyEnabled || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getParamsWithNotiFyEnabled || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("getParamsWithNotiFyEnabled ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(paramList))).build();

	}
	/*@DELETE
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/DeleteAivParamRule")
	public Response DeleteAivParamRule(@QueryParam("paramRuleId") int paramRuleId)
	{

		if (log.isTraceEnabled()) {
			log.trace("DeleteAivParamRule || paramRuleId:" + paramRuleId + "||Begin");
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("DeleteAivParamRule || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			AssetDao dao = new AssetDao();

			if (log.isTraceEnabled()) {
				log.trace("DeleteAivParamRule || dao method called : deleteFilterSearch()");
			}
			dao.DeleteAivParamRule(paramRuleId, conn);
			
			conn.commit();
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			
			if (log.isInfoEnabled()) {
				log.info("DeleteAivParamRule || filter search with paramRuleId:"
						+ paramRuleId + " deleted successfully");
			}
			
		} catch (RepoproException e) {
			log.error("DeleteAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch (Exception e) {
			log.error("DeleteAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("DeleteAivParamRule || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("DeleteAivParamRule || paramRuleId:" + paramRuleId + "||End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}*/
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getAivParamRuleByRuleName")
	public Response getAivParamRuleByAivIdAndRulename(@QueryParam("userName") String userName,@QueryParam("aivId") int aivId,@QueryParam("ruleName") String ruleName)  {
		if (log.isTraceEnabled()) {
			log.trace("getAivParamRule ||userName:" + userName+ "aivId:"+aivId+"||Begin");
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		AivParamRule aivParamRule = null;
		List<AivParamRule> aivParamRuleList = new ArrayList<AivParamRule>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || dao method called : retAssetDetail() to get asset details");
			}
			
			aivParamRule = dao.getAivParamRuleByRuleName(aivId,ruleName,userName, conn);
			if(aivParamRule != null) {

				String[]param = aivParamRule.getParamRuleValue().split("~~");
				String paramname="";
				for(String ids:param) {
					String[]paramids = ids.split("_");
					String paramId = paramids[0];
					if(!paramId.equals("0")) {
						AssetParamDef assetParamDef = dao.getParamDetailsByParamId(Long.parseLong(paramId), conn);
						if(paramname.equalsIgnoreCase("")) {
							paramname = assetParamDef.getAssetParamName()+"~~";
						}else {
							paramname = paramname+assetParamDef.getAssetParamName()+"~~";
						}
					}else {
						if(paramname.equalsIgnoreCase("")) {
							paramname = "State"+"~~";
						}else {
							paramname = paramname+"State"+"~~";
						}
					}
				}
				if ((paramname != null) && (paramname.length() > 0)) {
					aivParamRule.setParamName(paramname.substring(0, paramname.length() - 2));
					aivParamRuleList.add(aivParamRule);
				}
			}
			if (log.isInfoEnabled()) {
				log.info(" getAivParamRule || retrieved "
						+ aivParamRuleList.size()+ " FilterSearch search data successfully");
			}
			if (aivParamRuleList.isEmpty()) {
				retMsg = Constants.AIV_PARAM_RULE_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.AIV_PARAM_RULE_FETCHED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAivParamRule ||userName:" + userName+ "aivId:"+aivId+"||End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(aivParamRuleList))).build();
	}
	
	
	@GET
	@Path("/getAllStatesOfWorkflow")
	public Response getAllStatesOfWorkflow(@QueryParam("assetId") Long assetId) {
		
		if(log.isTraceEnabled()) {
			log.trace("getAllStatesOfWorkflow || Begin with assetId : "+assetId);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		List<String> workflowNames = new ArrayList<String>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			WorkflowDao workflowDao = new WorkflowDao();
			if(log.isTraceEnabled()) {
				log.trace("getAllStatesOfWorkflow || dao method called : getAllStatesOfWorkflow() to get all states of a workflow");
			}
			workflowNames = workflowDao.getAllStatesOfWorkflow(assetId, conn);
			
			retStat = Status.OK;
			retMsg = Constants.STATE_FETCHED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("getAllStatesOfWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getAllStatesOfWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllStatesOfWorkflow || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("getAllStatesOfWorkflow || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(workflowNames))).build();
	}
	
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/getAllAssetParamRules")
	public Response getAllAssetParamRules(@QueryParam("assetId") Long assetId) {
		
		if(log.isTraceEnabled()) {
			log.trace("getAllAssetParamRules || Begin with assetId : "+assetId);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		JSONObject json = new JSONObject();
		List<JSONObject> paramRulesList = new ArrayList<JSONObject>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetDao assetDao = new AssetDao();
			if(log.isTraceEnabled()) {
				log.trace("getAllAssetParamRules || dao method called : getAllAssetParamRulesUI()");
			}
			paramRulesList = assetDao.getAllAssetParamRulesUI(assetId, conn);
			
			json.put("result", paramRulesList);
	        json.put("message", Constants.ASSET_PARAM_RULES_FETCHED_SUCCESSFULLY);
	        json.put("status", Constants.SUCCESS);
	        json.put("statusCode", Constants.GET_STATUS_SUCCESS);
	        
			
		} catch(RepoproException e){
			log.error("getAllAssetParamRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getAllAssetParamRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetParamRules || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("getAllAssetParamRules || End");
		}
		return Response.status(retStat).entity(json.toString()).build();
	}
	
	
	@GET
	@Path("/getParamRuleDetails")
	public Response getParamRuleDetails(@QueryParam("paramRuleId") Long paramRuleId) {
		
		if(log.isTraceEnabled()) {
			log.trace("getParamRuleDetails || Begin with paramRuleId : "+paramRuleId);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		AssetParamRule assetParamRule = null;
		List<AssetParamRule> paramRuleDetails = new ArrayList<AssetParamRule>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetDao assetDao = new AssetDao();
			if(log.isTraceEnabled()) {
				log.trace("getParamRuleDetails || dao method called : getParamRuleDetails() to get the rule details");
			}
			assetParamRule = assetDao.getParamRuleDetails(paramRuleId, conn);
			
			if(assetParamRule != null) {
				String[] splitAssetParamName = assetParamRule.getAssetParamName().split("~");
				for(int i=0;i<splitAssetParamName.length;i++) {
					String paramId = splitAssetParamName[i].split("_")[0];
					AssetParamDef assetParamDef = assetDao.getParamDetailsByParamId(Long.parseLong(paramId), conn);
					if(assetParamDef != null && assetParamDef.getParamTypeId() != 3) {
						splitAssetParamName[i] = assetParamDef.getAssetParamName()+"_"+splitAssetParamName[i];
					}
				}
				
				StringBuilder finalParamName = new StringBuilder();
				for (int i = 0; i<splitAssetParamName.length; i++) {
					if (i > 0) {
						finalParamName.append("~");
					}
					String param = splitAssetParamName[i];
					finalParamName.append(param);
				}
				assetParamRule.setParameterName(finalParamName.toString());

				paramRuleDetails.add(assetParamRule);
			}
			
			retStat = Status.OK;
			retMsg = Constants.ASSET_PARAM_RULE_DETAILS_FETCHED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
		} catch(RepoproException e){
			log.error("getParamRuleDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getParamRuleDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getParamRuleDetails || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("getParamRuleDetails || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(paramRuleDetails))).build();
	}
	
	
	@GET
	@Path("/getParamRuleBasedOnSearch")
	public Response getParamRuleBasedOnSearch(@QueryParam("assetId") Long assetId, @QueryParam("searchString") String searchString) {
		
		if(log.isTraceEnabled()) {
			log.trace("getParamRuleBasedOnSearch || Begin with assetId : "+assetId+" \t searchString : "+searchString);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		List<AssetParamRule> paramRulesList = new ArrayList<AssetParamRule>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetDao assetDao = new AssetDao();
			if(log.isTraceEnabled()) {
				log.trace("getParamRuleBasedOnSearch || dao method called : getParamRuleBasedOnSearch() to get the rule(s)"
						+ "based on key searched");
			}
			paramRulesList = assetDao.getParamRuleBasedOnSearch(assetId, searchString, conn);
			
			for(AssetParamRule apr : paramRulesList) {
				String[] splitAssetParamName = apr.getAssetParamName().split("~");
				for(int i=0;i<splitAssetParamName.length;i++) {
					String paramId = splitAssetParamName[i].split("_")[0];
					AssetParamDef assetParamDef = assetDao.getParamDetailsByParamId(Long.parseLong(paramId), conn);
					if(assetParamDef != null && assetParamDef.getParamTypeId() != 3) {
						splitAssetParamName[i] = assetParamDef.getAssetParamName()+"_"+splitAssetParamName[i];
					}
				}
				
				StringBuilder finalParamName = new StringBuilder();
				for (int i = 0; i<splitAssetParamName.length; i++) {
					if (i > 0) {
						finalParamName.append("~");
					}
					String param = splitAssetParamName[i];
					finalParamName.append(param);
				}
				apr.setParameterName(finalParamName.toString());
			}
			
			retStat = Status.OK;
			retMsg = Constants.ASSET_PARAM_RULES_FETCHED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("getParamRuleBasedOnSearch || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getParamRuleBasedOnSearch || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getParamRuleBasedOnSearch || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("getParamRuleBasedOnSearch || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(paramRulesList))).build();
	}
	
	
	@PUT
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/saveParamRules")
	public Response saveParamRules(@QueryParam("assetId") Long assetId, List<AssetParamRule> paramRulesList) {
		
		if(log.isTraceEnabled()) {
			log.trace("saveParamRules || Begin with assetId :"+assetId+"\t paramRulesList : "+paramRulesList.toString());
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetDao assetDao = new AssetDao();
			if(log.isTraceEnabled()) {
				log.trace("saveParamRules || dao method called : saveParamRules()");
			}
			assetDao.saveParamRules(assetId, paramRulesList, conn);
			
			conn.commit();
			
			retStat = Status.OK;
			retMsg = Constants.PARAM_RULE_SAVED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("saveParamRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("saveParamRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("saveParamRules || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("saveParamRules || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	}
	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Path("/getAivParamRuleSets")
	public Response getAivParamRuleSets(@QueryParam("userName") String userName,@QueryParam("aivId") int aivId)  {
		if (log.isTraceEnabled()) {
			log.trace("getAivParamRule ||userName:" + userName+ "aivId:"+aivId+"||Begin");
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<AivParamRule> aivParamRuleList = new ArrayList<AivParamRule>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleSets || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleSets || dao method called : retAssetDetail() to get asset details");
			}
			
			aivParamRuleList = dao.getAivParamRuleSets(userName, aivId, conn);
			
			if (aivParamRuleList.isEmpty()) {
				retMsg = Constants.AIV_PARAM_RULE_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.AIV_PARAM_RULE_FETCHED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("getAivParamRuleSets || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("getAivParamRuleSets || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleSets || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAivParamRuleSets ||userName:" + userName+ "aivId:"+aivId+"||End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(aivParamRuleList))).build();
	}
	
	
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_JSON })
	@Path("/getAllMatchedRules")
	public Response getAllMatchedRules(@QueryParam("userName") String userName) {
		
		if(log.isTraceEnabled()) {
			log.trace("getAllMatchedRules || Begin with userName: "+userName);
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		JSONObject json = new JSONObject();		
		List<JSONObject> allMatchedRules = new ArrayList<JSONObject>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetDao assetDao = new AssetDao();
			
			if(log.isTraceEnabled()) {
				log.trace("getAllMatchedRules || dao method called getAllMatchedAivParamRules() "
						+ "to get matched rules at instance level");
			}
			allMatchedRules.addAll(assetDao.getAllMatchedAivParamRules(userName, conn));
			
			if(userName.equalsIgnoreCase("admin")) {
				if(log.isTraceEnabled()) {
					log.trace("getAllMatchedRules || dao method called getAllMatchedAssetParamRules() "
							+ "to get matched rules at asset level");
				}
				allMatchedRules.addAll(assetDao.getAllMatchedAssetParamRules(conn));
			}
			
			json.put("result", allMatchedRules);
	        json.put("message", Constants.MATCHED_RULES_FETCHED_SUCCESSFULLY);
	        json.put("status", Constants.SUCCESS);
	        json.put("statusCode", Constants.GET_STATUS_SUCCESS);
	        
			
		} catch(RepoproException e){
			log.error("getAllMatchedRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getAllMatchedRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllMatchedRules || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response.status(retStat)
				.entity(json.toString()).build();
	}
}
