package com.thbs.repopro.asset;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.core.Response;

import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.GroupDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionsManager;
import com.thbs.repopro.dto.AdminAccessName;
import com.thbs.repopro.dto.AivParamRule;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstParams;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.AssetParamRule;
import com.thbs.repopro.dto.AssetRelationshipDef;
import com.thbs.repopro.dto.Category;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.LdapMapping;
import com.thbs.repopro.dto.ParameterValues;
import com.thbs.repopro.dto.PossibleValues;
import com.thbs.repopro.dto.SavedSearch;
import com.thbs.repopro.dto.Workflow;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.relationship.RelationshipDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.InvertImage;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.PropertyFileReader;
import com.thbs.repopro.workflow.WorkflowDao;

public class AssetDao {

	private final static Logger log = LoggerFactory.getLogger("timeBased");
	
	/**
	 * @method : getAssetID
	 * @description : to get asset name
	 * @param assetName
	 * @param conn
	 * @throws RepoproException
	 */
	public AssetDef getAssetID(String assetName, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAssetID || " + assetName + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AssetDef assetDef = new AssetDef();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetID || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_ID_AND_NAME_BY_ASSET_NAME));

			pstmt.setString(Constants.ONE, assetName);
			
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetID || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_ID_AND_NAME_BY_ASSET_NAME));
			}

			rs =pstmt.executeQuery();

			if (rs != null && rs.next()) {
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setAssetName(rs.getString("asset_name"));
			}

		} catch (SQLException e) {
			log.error("getAssetID || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
		} catch (IOException e) {
			log.error("getAssetID || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetID || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetID || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetID || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("getAssetID || " + assetDef.toString() + " End");
		}
		return assetDef;

	}

	/**
	 * @method : addAsset
	 * @description : to add new asset
	 * @param addAsset
	 * @param conn
	 * @throws RepoproException
	 */
	public AssetDef addAsset(AssetDef addAsset, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addAsset || " + addAsset.toString() + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("addAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_ASSET));

			pstmt.setString(Constants.ONE, addAsset.getAssetName());
			pstmt.setString(Constants.TWO, addAsset.getDescription());
			pstmt.setBinaryStream(Constants.THREE, addAsset.getIconImage());
			pstmt.setInt(Constants.FOUR, 0);
			if(addAsset.isVersionable()){
				pstmt.setInt(Constants.FIVE, 1);
			}else{
				pstmt.setInt(Constants.FIVE, 0);
			}
			pstmt.setString(Constants.SIX, addAsset.getIconImageName());
			pstmt.setString(Constants.SEVEN, addAsset.getRatingDescription());
			if(addAsset.isGuestflag()){
				pstmt.setInt(Constants.EIGHT, 1);
				pstmt.setInt(Constants.NINE, 1);
			}else{
				pstmt.setInt(Constants.EIGHT, 0);
				pstmt.setInt(Constants.NINE, 0);	

			}
			pstmt.setBinaryStream(Constants.TEN, addAsset.getInvertedIconImage());
			if(addAsset.getEnableWorkflow()) {
				pstmt.setInt(Constants.ELEVEN, 1);
			}else {
				pstmt.setInt(Constants.ELEVEN, 0);
			}
						
			if (log.isTraceEnabled()) {
				log.trace("addAsset || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_ASSET));
			}

			pstmt.executeUpdate();

			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				addAsset.setAssetId(rs.getLong(1));
			}

			/*
			 * AssetVo avo = new AssetVo();
			 * avo.setAssetName(addAsset.getAsset_name());
			 * avo.setAssetDescription(addAsset.getDescription());
			 * avo.setIsSystemAsset(addAsset.isIs_system_asset());
			 * avo.setVersionable(addAsset.isVersionable());
			 * avo.setSelectIcon(addAsset.getIcon_image().toString());
			 * avo.setRatingDescription(addAsset.getRating_description());
			 * avo.trim();
			 */

		} catch (SQLException e) {
			log.error("addAsset || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_NOT_CREATED));
		} catch (IOException e) {
			log.error("addAsset || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("addAsset || " + addAsset.toString() + " End");
		}
		return addAsset;

	}// end of addAsset()
	/**
	 * @method : getAllAssets
	 * @description : to get all the assets
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetDef> getAllAssetsForSubscription(Connection conn) throws RepoproException {

		log.trace("getAllAssetsForSubscription || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<AssetDef> assetList = new ArrayList<AssetDef>();
		AssetDef assetDef = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsForSubscription || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ALL_ASSETS));

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsForSubscription || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_ASSETS));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				assetDef = new AssetDef();
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setAssetName(rs.getString("asset_name"));
				assetDef.setDescription(rs.getString("description"));
				assetDef.setIconImage(rs.getBinaryStream("icon_image"));
				assetDef.setSystemAsset(rs.getBoolean("is_system_asset"));
				assetDef.setVersionable(rs.getBoolean("versionable"));
				assetDef.setIconImageName(rs.getString("icon_image_name"));
				assetDef.setRatingDescription(rs
						.getString("rating_description"));
				assetList.add(assetDef);

				if (log.isTraceEnabled()) {
					log.trace("getAllAssetsForSubscription || " + assetDef.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetsForSubscription || " + assetList.toString());
			}

		} catch (SQLException e) {
			log.error("getAllAssetsForSubscription || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetsForSubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetsForSubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetsForSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsForSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAllAssetsForSubscription || End");
		return assetList;
	}


	/**
	 * @method : getAllAssets
	 * @description : to get all the assets
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetDef> getAllAssets(Connection conn) throws RepoproException{

		log.trace("getAllAssets || Begin  ");
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<AssetDef> assetList = new ArrayList<AssetDef>();
		AssetDef assetDef = null;
		InvertImage invertImage = new InvertImage();
	//	GlobalSettingDao globalSettingDao = new GlobalSettingDao();
		InputStream file = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets || "+ Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			/*List<GlobalSetting> globalSetting = globalSettingDao.getGlobalSetting(conn);
			
			GlobalSetting globalSetting2 = globalSettingDao.retGlobalSettingByName("Inverted Image", conn);
			if(globalSetting2 != null) {
				if(globalSetting2.getGlobalSettingId() != null) {
					invertedFlag = (long) globalSetting2.getInvertedImage();
					
				}
			}*/
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ASSETS));
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_ASSETS));
			}
			rs = pstmt.executeQuery();
			while(rs.next()){
				assetDef = new AssetDef();
				
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setAssetName(rs.getString("asset_name"));
				assetDef.setDescription(rs.getString("description"));
					
				assetDef.setInvertedIconImage(rs.getBinaryStream("inverted_icon_image"));
				
				assetDef.setIconImage(rs.getBinaryStream("icon_image"));
				assetDef.setSystemAsset(rs.getBoolean("is_system_asset"));
				assetDef.setVersionable(rs.getBoolean("versionable"));
				assetDef.setIconImageName(rs.getString("icon_image_name"));
				//assetDef.setInvertedIconImage(rs.getBinaryStream("inverted_icon_image"));
				
				/*if(assetDef.getIconImage() != null && assetDef.getIconImageName() != null) {
					if(rs.getBinaryStream("inverted_icon_image") == null){
					file = invertImage.inverImage(assetDef.getIconImage(), assetDef.getIconImageName());
					assetDef.setInvertedIconImage(file);
					
					
					}
					
				} else {
					assetDef.setInvertedIconImage(rs.getBinaryStream("inverted_icon_image"));
				}*/
				assetDef.setParentAssetId(rs.getLong("parent_asset_id"));
				assetDef.setRatingDescription(rs.getString("rating_description"));
				assetDef.setGuestflag(rs.getBoolean("guest_flag"));
				assetDef.setQuicksearchflag(rs.getBoolean("quick_search_flag"));
				assetList.add(assetDef);

				if (log.isTraceEnabled()) {
					log.trace("getAllAssets || "+ assetDef.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssets || "+ assetList.toString());
			}
			Map<Long, Map<Long, String>> categoryGroupValues = null;
			GroupDao gd = new GroupDao();
			List<AssetParamDef> listOfDerivedComputation = getAllDerivedAttributes(conn1);
			if(log.isTraceEnabled()) {
				log.trace("getAllAssets || dao method called getAllDerivedAttributeForAssetList()");
			}
			List<AssetParamDef> allDerivedAttributesForAssetList = getAllDerivedAttributeForAssetList(conn);
			
			for (int j=0;j<assetList.size();j++) {
				AssetDef adf =assetList.get(j) ;
				if (log.isTraceEnabled()) {
					log.trace("getAllAssets  || dao method calling  getCategoryByAssetID(assetId)");
				}
				List<Category> listOfCategories =  getCategoryByAssetID(adf.getAssetId(), conn1);

				for (int k=0;k<listOfCategories.size();k++) {
					Category  category= listOfCategories.get(k);
					if (log.isTraceEnabled()) {
						log.trace("getAllAssets  || dao method calling  getAssetParameterDefsByCategoryID(categoryId)");
					}
					if (log.isTraceEnabled()) {
						log.trace("getAllAssets  || dao method calling  getAssetParameterDefsByCategoryID(category.getCategoryId())");
					}
					List<AssetParamDef> listOfParamDefs = getAssetParameterDefsByCategoryID(category.getCategoryId(), conn1);
					boolean flagForCategaryCheck = false;
					boolean flagForCategoryCheckInAssetListRule = false;
					for(int zz=0;zz<listOfParamDefs.size();zz++){
						AssetParamDef paramDef = listOfParamDefs.get(zz);
						Pattern patternForDerivedComputation = Pattern.compile("(?i)"+adf.getAssetName()+"[\\.](?i)"+paramDef.getAssetParamName()+"(==)");
						Pattern parameterPattern = Pattern.compile("(?i)"+adf.getAssetName()+"[\\{](?i)"+paramDef.getAssetParamName()+"[\\}]");
						for (AssetParamDef assetParamDef : listOfDerivedComputation) {
							if(assetParamDef.getParamTypeId().equals("5")||assetParamDef.getParamTypeId().equals("6")){
								String rule = assetParamDef.getDerivedAttributeComputation();
								Matcher m = parameterPattern.matcher(rule);
								if(m.find()){
									listOfParamDefs.get(zz).setFlagForParameterUsageInRule(true);
									adf.setFlagForAssetUsageInRule(true);
									flagForCategaryCheck = true;
									assetList.set(j,adf );
								}
								Matcher m1 = patternForDerivedComputation.matcher(rule);
								if(m1.find()){
									listOfParamDefs.get(zz).setFlagForParameterUsageInRule(true);
								}
							}
						}
						
						Pattern assetListParameterPattern1 = Pattern.compile("(?i)"+adf.getAssetName()+"[\\{](?i)"+paramDef.getAssetParamName()+"[\\}]");
						Pattern assetListParameterPattern2 = Pattern.compile("(?i)"+adf.getAssetName()+"[\\[](?i)"+paramDef.getAssetParamName()+"[\\]]");
						
						for(AssetParamDef apd : allDerivedAttributesForAssetList) {
							if(apd.getParamTypeId().equals(Constants.DERIVED_ASSET_LIST_ATTRIBUTE)) {
								String assetListRule = apd.getDerivedAssetListRule();
								Matcher m = assetListParameterPattern1.matcher(assetListRule);
								if(m.find()){
									listOfParamDefs.get(zz).setFlagForParameterUsageInAssetListRule(true);
									adf.setFlagForAssetUsageInAssetListRule(true);
									flagForCategoryCheckInAssetListRule = true;
									assetList.set(j,adf );
								}
								
								Matcher m1 = assetListParameterPattern2.matcher(assetListRule);
								if(m1.find()){
									listOfParamDefs.get(zz).setFlagForParameterUsageInAssetListRule(true);
									//adf.setFlagForAssetUsageInAssetListRule(true);
									//flagForCategoryCheckInAssetListRule = true;
								}
							}
						}
					}
					if(flagForCategaryCheck)
						category.setFlagForCategoryRuleUsage(true);
					if(flagForCategoryCheckInAssetListRule) {
						category.setFlagForCategoryUsageInAssetListRule(true);
					}
					category.setParameters(listOfParamDefs);
					listOfCategories.set(k, category);
				}
				adf.setCategories(listOfCategories);
				assetList.set(j, adf);
			}
			for (int i = 0; i < assetList.size(); i++) {
				AssetDef ad = assetList.get(i);
				for(int j=0;j<listOfDerivedComputation.size();j++){
					AssetParamDef apd = listOfDerivedComputation.get(j);
					String rule = apd.getDerivedAttributeComputation();
					Pattern assetPattern1 = Pattern.compile("[\\]](?i)"+ad.getAssetName()+"[\\{]");
					Matcher m1 = assetPattern1.matcher(rule);
					if(m1.find()){
						assetList.get(i).setFlagForAssetUsageInRule(true);
					}
					Pattern assetPattern2 = Pattern.compile("[\\]](?i)"+ad.getAssetName()+"[\\[]");
					Matcher m2 = assetPattern2.matcher(rule);
					if(m2.find()){
						assetList.get(i).setFlagForAssetUsageInRule(true);
					}
					Pattern assetPattern3 = Pattern.compile("[\\]](?i)"+ad.getAssetName()+"[\\.]");
					Matcher m3 = assetPattern3.matcher(rule);
					if(m3.find()){
						assetList.get(i).setFlagForAssetUsageInRule(true);
					}
				}
				
				for(int k=0;k<allDerivedAttributesForAssetList.size();k++) {
					AssetParamDef apd = allDerivedAttributesForAssetList.get(k);
					String assetListRule = apd.getDerivedAssetListRule();
					Pattern assetListRulePattern1 = Pattern.compile("[\\]](?i)"+ad.getAssetName()+"[\\{]");
					Matcher m1 = assetListRulePattern1.matcher(assetListRule);
					if(m1.find()){
						assetList.get(i).setFlagForAssetUsageInAssetListRule(true);
					}
					Pattern assetListRulePattern2 = Pattern.compile("[\\]](?i)"+ad.getAssetName()+"[\\[]");
					Matcher m2 = assetListRulePattern2.matcher(assetListRule);
					if(m2.find()){
						assetList.get(i).setFlagForAssetUsageInAssetListRule(true);
					}
				}
			}
			for(int kk=0;kk<assetList.size();kk++){
				AssetDef ad1 = assetList.get(kk);
				List<Category> categories = ad1.getCategories();
				for(int mm=0;mm<categories.size();mm++){
					Category cat =categories.get(mm);
					if (log.isTraceEnabled()) {
						log.trace("getAllAssets  || dao method calling  getCategoryAccessByAssetId(cat.getCategoryId(),categoryGroupValues)");
					}
					categoryGroupValues  = gd.getCategoryAccessByAssetId(cat.getCategoryId(),categoryGroupValues, conn);
				}
				assetList.set(kk, ad1);
				categoryGroupValues = null;
			}
			GroupDetails groupDetailsMapped = null;
			AssetDao assetDao = new AssetDao();
			for(int kk=0;kk<assetList.size();kk++){
				AssetDef def =assetList.get(kk);
				Map<Long, List<String>> checkedGroupDetails = assetDao.getCheckedGroupDetailsByAssetId(def.getAssetId(), conn);

				GroupDao groupDao = new GroupDao();
				List<GroupDetails> allGroups = groupDao.getAllGroups(conn);

				Map<Long,String> values = assetDao.getCheckedGroupDetailsByAssetIdWithCategories(def.getAssetId(),conn);

				Map<Long,Set<GroupDetails>> details = new HashMap<Long, Set<GroupDetails>>();
				List<Long> list = new ArrayList<Long>(checkedGroupDetails.keySet());

				for(int i = 0;i<checkedGroupDetails.keySet().size();i++){
					Set<GroupDetails> listOfGds = new HashSet<GroupDetails>();
					Long categoryId =list.get(i);
					List<String> groups = checkedGroupDetails.get(categoryId);
					for(int j=0;j<groups.size();j++){
						for(int k=0;k<allGroups.size();k++){
							groupDetailsMapped = new GroupDetails();
							if(groups.get(j).equalsIgnoreCase(allGroups.get(k).getGroupName())){
								groupDetailsMapped.setMappedWithUser(true);
								groupDetailsMapped.setCategoryName(values.get(categoryId));
								groupDetailsMapped.setDescription(allGroups.get(k).getDescription());
								groupDetailsMapped.setGroupId((allGroups.get(k).getGroupId()));
								groupDetailsMapped.setGroupName(allGroups.get(k).getGroupName());
								listOfGds.add(groupDetailsMapped);
							}else{
								groupDetailsMapped.setCategoryName(values.get(categoryId));
								groupDetailsMapped.setDescription(allGroups.get(k).getDescription());
								groupDetailsMapped.setGroupId((allGroups.get(k).getGroupId()));
								groupDetailsMapped.setGroupName(allGroups.get(k).getGroupName());
								listOfGds.add(groupDetailsMapped);
							}
						}

					}
					details.put(categoryId, listOfGds);
				}
				def.setCategoriesWithAccess(details);

				def.setAssetAssignedTaxonomies(assetDao.getTaxonomiesByAssetId(def.getAssetId(), conn));

				List<Map<String, Long>>  mapValues = gd.getGroupAccessByAssetId(def.getAssetId(), conn);
				def.setGroupAccessForAsset(mapValues);
				assetList.set(kk, def);


			}
		} catch (SQLException e) {
			log.error("getAllAssets || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssets || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssets || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllAssets || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try{
				if(pstmt != null){
					pstmt.close();
				}
			}catch(SQLException ex){
				ex.printStackTrace();
			}
		}
		log.trace("getAllAssets || End");
		return assetList;
	}




	/**
	 * @method : getAssetsByAssetId
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetDef getAssetsByAssetId(long assetId, Connection conn)
			throws RepoproException {

		log.trace("getAssetsByAssetId || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetDef assetDef = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetsByAssetId || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSETS_BY_ASSET_ID));
			pstmt.setLong(Constants.ONE, assetId);
			if (log.isTraceEnabled()) {
				log.trace("getAssetsByAssetId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSETS_BY_ASSET_ID));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				assetDef = new AssetDef();
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setAssetName(rs.getString("asset_name"));
				assetDef.setDescription(rs.getString("description"));
				assetDef.setIconImage(rs.getBinaryStream("icon_image"));
				assetDef.setSystemAsset(rs.getBoolean("is_system_asset"));
				assetDef.setVersionable(rs.getBoolean("versionable"));
				assetDef.setIconImageName(rs.getString("icon_image_name"));
				assetDef.setRatingDescription(rs.getString("rating_description"));
				assetDef.setIconImage(rs.getBinaryStream("icon_image"));
				assetDef.setIconImageName(rs.getString("icon_image_name"));
				String fileName = assetDef.getIconImageName();
				if(fileName!=null)
				if(!fileName.startsWith("C:\\")){
					fileName = "C:\\fakepath\\"+fileName;
				}
				
				assetDef.setIconImageName(fileName);
				if(rs.getInt("guest_flag")==1){
					assetDef.setGuestflag(true);
				}
				if(rs.getInt("enable_workflow")==1){
					assetDef.setEnableWorkflow(true);
				}
				assetDef.setQuicksearchflag(rs.getBoolean("quick_search_flag"));

				if (log.isTraceEnabled()) {
					log.trace("getAssetsByAssetId || " + assetDef.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAssetsByAssetId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetsByAssetId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetsByAssetId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetsByAssetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetsByAssetId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAssetsByAssetId || End");
		return assetDef;
	}
	/**
	 * @method : updateAsset
	 * @description : to update an asset
	 * @param updateAsset
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateAsset(AssetDef updateAsset, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateAsset || " + updateAsset.toString() + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAsset || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.UPDATE_ASSET));
			pstmt.setString(Constants.ONE, updateAsset.getAssetName());
			pstmt.setString(Constants.TWO, updateAsset.getDescription());
			pstmt.setBinaryStream(Constants.THREE, updateAsset.getIconImage());
			pstmt.setInt(Constants.FOUR, 0);
			pstmt.setBoolean(Constants.FIVE, updateAsset.isVersionable());
			pstmt.setString(Constants.SIX, updateAsset.getIconImageName());
			pstmt.setString(Constants.SEVEN, updateAsset.getRatingDescription());
			if(updateAsset.isGuestflag()){
				pstmt.setInt(Constants.EIGHT, 1);
				pstmt.setInt(Constants.NINE, 1);
			}else{
				pstmt.setInt(Constants.EIGHT, 0);
				pstmt.setInt(Constants.NINE, 0);
			}
			pstmt.setBinaryStream(Constants.TEN, updateAsset.getInvertedIconImage());
			if(updateAsset.getEnableWorkflow()) {
				pstmt.setInt(Constants.ELEVEN, 1);
			}else {
				pstmt.setInt(Constants.ELEVEN, 0);
			}
			
			pstmt.setLong(Constants.TWELVE, updateAsset.getAssetId());

			if (log.isTraceEnabled()) {
				log.trace("updateAsset || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_ASSET));
			}

			int result = pstmt.executeUpdate();
			if (result == 0) {
				log.warn("Update Asset || Asset is not updated and throws RepoproException");
			}

		} catch (SQLException e) {
			log.error("updateAsset || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateAsset || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateAsset || End");
		}

	}

	/**
	 * @method : deleteAsset
	 * @description : to delete an asset
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<String> deleteAsset(Long assetId, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteAsset || Begin with assetId : " + assetId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		List<String> msg = new ArrayList<String>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_ASSET));

			pstmt.setLong(Constants.ONE, assetId);

			if (log.isTraceEnabled()) {
				log.trace("deleteAsset || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_ASSET));
			}

			int result = pstmt.executeUpdate();

			if (result == 0) {
				log.warn("deleteAsset || Asset with id " + assetId
						+ " already deleted ");
				msg.add("Asset with " + assetId + " already deleted");
			}

		} catch (SQLException e) {
			log.error("deleteAsset || " + Constants.LOG_DELETE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteAsset || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("deleteAsset || End");
		}
		return msg;
	}

	/**
	 * @method getFilterList
	 * @description get list of parameter values for filters
	 * @param assetName
	 * @param paramName
	 * @param listName
	 * @param userName
	 * @param mappedAssetId
	 * @param conn
	 * @return List<AssetParamDef>
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getFilterList(String assetName,
			String paramName, String listName, String userName,Long mappedAssetId, Connection conn)
					throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getFilterList ||assetName:" + assetName + " paramName:"
					+ paramName + " listName:" + listName + " userName:"
					+ userName + "||Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		ResultSet result = null;
		List<AssetParamDef> filterList = new ArrayList<AssetParamDef>();
		AssetParamDef values = null;
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		AdminAccessName adminAccessName = null;
		boolean flag = false;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getFilterList || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (listName.equalsIgnoreCase("CUSTOMLIST")) {

				pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_CUSTOMLIST));
				pstmt.setString(Constants.ONE, paramName);
				pstmt.setString(Constants.TWO, assetName);
				if (log.isTraceEnabled()) {
					log.trace("getFilterList || "
							+ PropertyFileReader.getInstance().getValue(Constants.GET_ALL_CUSTOMLIST));
				}
				rs = pstmt.executeQuery();
				while (rs.next()) {
					values = new AssetParamDef();
					values.setAssetParamId(rs.getLong("asset_param_id"));
					values.setAssetParamName(rs.getString("asset_param_name"));
					values.setParamValue(rs.getString("value"));
					filterList.add(values);

					if (log.isTraceEnabled()) {
						log.trace("getFilterList || " + values.toString());
					}
				}

			} else if (listName.equalsIgnoreCase("NATIVEUSERLIST")) {

				pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.GET_ALL_USERS));
				
				pstmt.setString(Constants.ONE, CommonUtils.encryptionKey);
				pstmt.setString(Constants.TWO, CommonUtils.encryptionKey);
				pstmt.setString(Constants.THREE, CommonUtils.encryptionKey);
				pstmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
				
				if (log.isTraceEnabled()) {
					log.trace("getFilterList || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ALL_USERS));
				}
				rs = pstmt.executeQuery();
				while (rs.next()) {
					values = new AssetParamDef();
					values.setParamValue(rs.getString("user_name"));
					filterList.add(values);

					if (log.isTraceEnabled()) {
						log.trace("getFilterList || " + values.toString());
					}
				}
			} else {
				
				AssetDef asset = new AssetDef();
				asset = getAssetsByAssetId(mappedAssetId, conn);

				if (userName.equalsIgnoreCase("roleAnonymous")) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.GET_ASSET_INSTANCE_FOR_GUEST));
					pstmt.setString(Constants.ONE, asset.getAssetName());
					if (log.isTraceEnabled()) {
						log.trace("getAllAssets || "
								+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_INSTANCE_FOR_GUEST));
					}
					rs = pstmt.executeQuery();
					while (rs.next()) {
						values = new AssetParamDef();
						values.setParamValue(rs.getString("asset_inst_name"));
						filterList.add(values);

						if (log.isTraceEnabled()) {
							log.trace("getFilterList || " + values.toString());
						}
					}
				} else {
					pstm = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.GET_ADMIN_RIGHT));
					if (log.isTraceEnabled()) {
						log.trace("getFilterList || "
								+ PropertyFileReader.getInstance().getValue(
										Constants.GET_ADMIN_RIGHT));
					}
					pstm.setString(Constants.ONE, userName);
					result = pstm.executeQuery();

					while (result.next()) {
						adminAccessName = new AdminAccessName();
						adminAccessName.setUserName(result
								.getString("user_name"));
						adminAccessName.setGroupName(result
								.getString("group_name"));
						adminAccessName.setRoleName(result
								.getString("role_name"));
						adminAccessNameList.add(adminAccessName);
						if (log.isTraceEnabled()) {
							log.trace("getFilterList || returning resultset for admin check : "
									+ adminAccessName.toString());
						}
					}

					for (AdminAccessName adminAccess : adminAccessNameList) {
						if (adminAccess.getUserName().equalsIgnoreCase("admin")
								|| adminAccess.getGroupName().equalsIgnoreCase(
										"group-admin")
										|| adminAccess.getRoleName().equalsIgnoreCase(
												"role-admin")) {
							flag = true;
						}
					}

					if (flag) {
						pstmt = conn
								.prepareStatement(PropertyFileReader
										.getInstance().getValue(Constants.GET_ASSET_INSTANCE_FOR_ADMIN));
						if (log.isTraceEnabled()) {
							log.trace("getFilterList || "
									+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_INSTANCE_FOR_ADMIN));
						}
						pstmt.setString(Constants.ONE, asset.getAssetName());
						rs = pstmt.executeQuery();
						while (rs.next()) {
							values = new AssetParamDef();
							values.setParamValue(rs.getString("asset_inst_name"));
							filterList.add(values);
							if (log.isTraceEnabled()) {
								log.trace("getFilterList || "
										+ values.toString());
							}
						}

					} else {
						pstmt = conn
								.prepareStatement(PropertyFileReader
										.getInstance().getValue(Constants.GET_ASSET_INSTANCE_FOR_NON_ADMIN_USER));
						if (log.isTraceEnabled()) {
							log.trace("getFilterList || "
									+ PropertyFileReader
									.getInstance().getValue(Constants.GET_ASSET_INSTANCE_FOR_NON_ADMIN_USER));
						}
						pstmt.setString(Constants.ONE, userName);
						pstmt.setString(Constants.TWO, asset.getAssetName());
						rs = pstmt.executeQuery();
						while (rs.next()) {
							values = new AssetParamDef();
							values.setParamValue(rs.getString("asset_inst_name"));
							filterList.add(values);
							if (log.isTraceEnabled()) {
								log.trace("getFilterList || "
										+ values.toString());
							}
						}
					}
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getFilterList || " + filterList.toString());
			}
		} catch (SQLException e) {
			log.error("getFilterList || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.FILTER_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getFilterList || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getFilterList || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getFilterList || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(result);
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstm);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getFilterList || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("getFilterList ||assetName:" + assetName + " paramName:"
					+ paramName + " listName:" + listName + " userName:"
					+ userName + "||End");
		}
		return filterList;
	}

	/**
	 * @method getParamsDetails
	 * @description get list of parameters
	 * @param userName
	 * @param assetId
	 * @param conn
	 * @return List<AssetParamDef>
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getParamsDetails(String userName, Long assetId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getParamsDetails ||userName:" + userName + " assetId:"
					+ assetId + " || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		AssetParamDef assetParamDef = null;
		List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParamsDetails || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (userName.equalsIgnoreCase("admin")) {
				preparedSt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ALL_PARAM_DETAILS_FOR_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ALL_PARAM_DETAILS_FOR_ADMIN));
				}
				preparedSt.setLong(Constants.ONE, assetId);

				rs = preparedSt.executeQuery();

				while (rs.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(rs
							.getString("asset_param_name"));
					assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
					assetParamDef.setListTypeParamTypeId(rs
							.getLong("list_param_type_id"));
					assetParamDef.setHasImportantValue(rs
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(rs
							.getBoolean("is_default_view"));
					assetParamDef.setMappedAssetId(rs
							.getLong("mapped_asset_id"));
					assetParamDef.setTypeName(rs.getString("type_name"));
					assetParamDef.setHasArray(rs.getInt("isArray"));
					assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
					if (assetParamDef.getParamTypeId() != 4) {
						assetParamDefList.add(assetParamDef);
					}

					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "
								+ assetParamDef.toString());
					}

				}
				preparedStmt = conn
						.prepareStatement(PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN));
				}
				preparedStmt.setLong(Constants.ONE, assetId);

				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(resultSet
							.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(resultSet
							.getString("asset_param_name"));
					assetParamDef.setHasImportantValue(resultSet
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(resultSet.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(resultSet
							.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(resultSet
							.getBoolean("is_default_view"));
					assetParamDef.setListTypeParamTypeId(resultSet
							.getLong("list_param_type_id"));
					assetParamDef.setParamTypeId(resultSet
							.getLong("param_type_id"));
					assetParamDef.setTypeName(resultSet.getString("type_name"));
					assetParamDef.setListTypeName(resultSet
							.getString("list_type_name"));
					assetParamDef.setMappedAssetId(resultSet
							.getLong("mapped_asset_id"));
					assetParamDef.setAssetCategoryId(resultSet.getLong("asset_category_id"));
					assetParamDef.setHasArray(resultSet.getInt("isArray"));
					assetParamDefList.add(assetParamDef);

					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "
								+ assetParamDef.toString());
					}
				}

			} else if (userName.equalsIgnoreCase("roleAnonymous")) {
				preparedSt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ALL_PARAM_DETAILS_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ALL_PARAM_DETAILS_FOR_GUEST));
				}
				preparedSt.setLong(Constants.ONE, assetId);
				preparedSt.setString(Constants.TWO, Constants.GUEST);
				rs = preparedSt.executeQuery();

				while (rs.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(rs
							.getString("asset_param_name"));
					assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
					assetParamDef.setListTypeParamTypeId(rs
							.getLong("list_param_type_id"));
					assetParamDef.setHasImportantValue(rs
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(rs
							.getBoolean("is_default_view"));
					assetParamDef.setMappedAssetId(rs
							.getLong("mapped_asset_id"));
					assetParamDef.setTypeName(rs.getString("type_name"));
					assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
					assetParamDef.setHasArray(rs.getInt("isArray"));
					if (assetParamDef.getParamTypeId() != 4) {
						assetParamDefList.add(assetParamDef);
					}

					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "
								+ assetParamDef.toString());
					}

				}
				preparedStmt = conn
						.prepareStatement(PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_GUEST));
				}
				preparedStmt.setLong(Constants.ONE, assetId);
				preparedStmt.setString(Constants.TWO, Constants.GUEST);
				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(resultSet
							.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(resultSet
							.getString("asset_param_name"));
					assetParamDef.setHasImportantValue(resultSet
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(resultSet.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(resultSet
							.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(resultSet
							.getBoolean("is_default_view"));
					assetParamDef.setListTypeParamTypeId(resultSet
							.getLong("list_param_type_id"));
					assetParamDef.setParamTypeId(resultSet
							.getLong("param_type_id"));
					assetParamDef.setTypeName(resultSet.getString("type_name"));
					assetParamDef.setListTypeName(resultSet
							.getString("list_type_name"));
					assetParamDef.setMappedAssetId(resultSet
							.getLong("mapped_asset_id"));
					assetParamDef.setAssetCategoryId(resultSet.getLong("asset_category_id"));
					assetParamDef.setHasArray(resultSet.getInt("isArray"));
					assetParamDefList.add(assetParamDef);
					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "
								+ assetParamDef.toString());
					}
				}

			} else {
				preparedSt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN));
				}
				preparedSt.setLong(Constants.ONE, assetId);
				preparedSt.setString(Constants.TWO, userName);
				rs = preparedSt.executeQuery();

				while (rs.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(rs
							.getString("asset_param_name"));
					assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
					assetParamDef.setListTypeParamTypeId(rs
							.getLong("list_param_type_id"));
					assetParamDef.setHasImportantValue(rs
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(rs
							.getBoolean("is_default_view"));
					assetParamDef.setMappedAssetId(rs
							.getLong("mapped_asset_id"));
					assetParamDef.setTypeName(rs.getString("type_name"));
					assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
					assetParamDef.setHasArray(rs.getInt("isArray"));
					if (assetParamDef.getParamTypeId() != 4) {
						assetParamDefList.add(assetParamDef);
					}

					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "
								+ assetParamDef.toString());
					}

				}
				preparedStmt = conn
						.prepareStatement(PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN));
				}
				preparedStmt.setLong(Constants.ONE, assetId);
				preparedStmt.setString(Constants.TWO, userName);
				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(resultSet
							.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(resultSet
							.getString("asset_param_name"));
					assetParamDef.setHasImportantValue(resultSet
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(resultSet.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(resultSet
							.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(resultSet
							.getBoolean("is_default_view"));
					assetParamDef.setListTypeParamTypeId(resultSet
							.getLong("list_param_type_id"));
					assetParamDef.setParamTypeId(resultSet
							.getLong("param_type_id"));
					assetParamDef.setTypeName(resultSet.getString("type_name"));
					assetParamDef.setListTypeName(resultSet
							.getString("list_type_name"));
					assetParamDef.setMappedAssetId(resultSet
							.getLong("mapped_asset_id"));
					assetParamDef.setAssetCategoryId(resultSet.getLong("asset_category_id"));
					assetParamDef.setHasArray(resultSet.getInt("isArray"));
					assetParamDefList.add(assetParamDef);

					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "
								+ assetParamDef.toString());
					}
				}

			}

			if (log.isDebugEnabled()) {
				log.debug("getParamsDetails || " + assetParamDefList.toString());
			}
		} catch (SQLException e) {
			log.error("getParamsDetails ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_PARAM_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getParamsDetails ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getParamsDetails ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamsDetails ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getParamsDetails ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if (preparedStmt != null) {
					preparedStmt.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("getParamsDetails ||userName:" + userName + " assetId:"
					+ assetId + " ||exit");
		}
		return assetParamDefList;
	}


	/**
	 * @method : getParamNameByParamId
	 * @param paramId
	 * @param conn
	 * @return AssetParamDef
	 * @throws RepoproException
	 */
	public AssetParamDef getParamNameByParamId(Long paramId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getParamNameByParamId ||paramId:" + paramId
					+  " || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		AssetParamDef assetParamDef = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParamNameByParamId || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedSt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ALL_PARAM_DETAILS_BY_PARAM_ID));
			if (log.isTraceEnabled()) {
				log.trace("getParamsDetails || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_PARAM_DETAILS_BY_PARAM_ID));
			}
			preparedSt.setLong(Constants.ONE, paramId);

			rs = preparedSt.executeQuery();

			while (rs.next()) {
				assetParamDef = new AssetParamDef();
				assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
				assetParamDef.setAssetParamName(rs
						.getString("asset_param_name"));
				assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
				assetParamDef.setListTypeParamTypeId(rs
						.getLong("list_param_type_id"));
				assetParamDef.setHasImportantValue(rs
						.getBoolean("is_important"));
				assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
				assetParamDef.setHasdefViewValue(rs
						.getBoolean("is_default_view"));
				assetParamDef.setMappedAssetId(rs.getLong("mapped_asset_id"));

				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || " + assetParamDef.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getParamNameByParamId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_PARAM_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getParamNameByParamId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getParamNameByParamId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamNameByParamId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getParamNameByParamId ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getParamNameByParamId ||paramId:" + paramId
					+ " ||exit");
		}
		return assetParamDef;
	}

	/**
	 * @method addFilterSearch
	 * @description add filter search data
	 * @param savedSearch
	 * @param conn
	 * @return SavedSearch
	 * @throws RepoproException
	 */
	public SavedSearch addFilterSearch(SavedSearch savedSearch, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addFilterSearch || " + savedSearch.toString() + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		PreparedStatement pstm = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("addFilterSearch || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if(savedSearch.getDefaultUserFilterView()==1L) {
				pstm = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.UPDATE_DEFAULT_FILTER_SEARCH_DETAILS));
				pstm.setLong(Constants.ONE, 0);
				pstm.setString(Constants.TWO, savedSearch.getAssetName());
				pstm.setString(Constants.THREE, savedSearch.getUserName());
				
				int result = pstm.executeUpdate();
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_FILTER_SEARCH));

			pstmt.setString(Constants.ONE, savedSearch.getSearchName());
			pstmt.setString(Constants.TWO, savedSearch.getParamsValue());
			pstmt.setString(Constants.THREE, savedSearch.getOperatorsValue());
			pstmt.setString(Constants.FOUR, savedSearch.getParam1Value());
			pstmt.setString(Constants.FIVE, savedSearch.getLogicalSelectValue());
			pstmt.setString(Constants.SIX, savedSearch.getAssetName());
			pstmt.setString(Constants.SEVEN, savedSearch.getParam2Value());
			pstmt.setString(Constants.EIGHT, savedSearch.getTaxValue());
			pstmt.setString(Constants.NINE, savedSearch.getUserName());
			pstmt.setLong(Constants.TEN, savedSearch.getAssetId());
			pstmt.setLong(Constants.ELEVEN, savedSearch.getDefaultUserFilterView());
			if (log.isTraceEnabled()) {
				log.trace("addFilterSearch || "+ PropertyFileReader.getInstance().getValue(Constants.ADD_FILTER_SEARCH));
			}

			pstmt.executeUpdate();

			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				savedSearch.setSearchId(rs.getLong(1));
			}

		} catch (SQLException e) {
			log.error("addFilterSearch || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.FILTER_SEARCH_NOT_CREATED));
		} catch (IOException e) {
			log.error("addFilterSearch || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addFilterSearch || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closePreparedStatement(pstm);
			if (log.isTraceEnabled()) {
				log.trace("addFilterSearch || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);			
		}

		if (log.isTraceEnabled()) {
			log.trace("addFilterSearch || " + savedSearch.toString() + " End");
		}
		return savedSearch;

	}

	/**
	 * @method getFilterSearchList
	 * @description get list of filter search list
	 * @param conn
	 * @return List<SavedSearch>
	 * @throws RepoproException
	 */
	public List<SavedSearch> getFilterSearchList(String userName,Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getFilterSearchList ||  Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		SavedSearch savedSearch = null;
		List<SavedSearch> searchlist = new ArrayList<SavedSearch>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchList || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ALL_FILTER_SEARCH));

			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchList || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_FILTER_SEARCH));
			}
			pstmt.setString(Constants.ONE, userName);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				savedSearch = new SavedSearch();
				savedSearch.setSearchId(rs.getLong("search_id"));
				savedSearch.setSearchName(rs.getString("search_name"));
				savedSearch.setParamsValue(rs.getString("params_value"));
				savedSearch.setOperatorsValue(rs.getString("operators_value"));
				savedSearch.setParam1Value(rs.getString("param1_value"));
				savedSearch.setLogicalSelectValue(rs
						.getString("logical_select_value"));
				savedSearch.setAssetName(rs.getString("asset_name"));
				savedSearch.setParam2Value(rs.getString("param2_value"));
				savedSearch.setTaxValue(rs.getString("taxonomy_value"));
				savedSearch.setUserName(rs.getString("userName"));
				searchlist.add(savedSearch);
				if (log.isTraceEnabled()) {
					log.trace("getFilterSearchList || "
							+ savedSearch.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getFilterSearchList || " + searchlist.toString());
			}
		} catch (SQLException e) {
			log.error("getFilterSearchList || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.FILTER_SEARCH_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getFilterSearchList || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getFilterSearchList || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getFilterSearchList || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchList || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("getFilterSearchList || " + searchlist.toString()
					+ " End");
		}
		return searchlist;

	}

	/**
	 * @method getFilterSearch
	 * @description get filter search data
	 * @param searchName
	 * @param conn
	 * @return SavedSearch
	 * @throws RepoproException
	 */
	public List<SavedSearch> getFilterSearch(Long assetId, String userName,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getFilterSearch ||||assetId:" + assetId
					+ ",userName:" + userName + "Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		SavedSearch savedSearch = null;
		List<SavedSearch> searchList = new ArrayList<SavedSearch>();
		AssetDef assetDef = new AssetDef();
		try {
			assetDef = getAssetsByAssetId(assetId, conn1);
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearch || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_FILTER_SEARCH));
			pstmt.setString(Constants.ONE, assetDef.getAssetName());
			pstmt.setString(Constants.TWO, userName);
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearch || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_FILTER_SEARCH));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				savedSearch = new SavedSearch();
				savedSearch.setSearchId(rs.getLong("search_id"));
				savedSearch.setSearchName(rs.getString("search_name"));
				savedSearch.setParamsValue(rs.getString("params_value"));
				savedSearch.setOperatorsValue(rs.getString("operators_value"));
				savedSearch.setParam1Value(rs.getString("param1_value"));
				savedSearch.setLogicalSelectValue(rs
						.getString("logical_select_value"));
				savedSearch.setParam2Value(rs.getString("param2_value"));
				savedSearch.setTaxValue(rs.getString("taxonomy_value"));
				savedSearch.setDefaultUserFilterView(rs.getInt("default_User_FilterView"));
				searchList.add(savedSearch);
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || " + savedSearch.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getFilterSearch || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.FILTER_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getFilterSearch || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getFilterSearch || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearch || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("getFilterSearch ||assetId:" + assetId + ",userName:"
					+ userName + " End");
		}
		return searchList;

	}

	/**
	 * @method getFilterSearchForLoad
	 * @description get filter search data for load
	 * @param assetName
	 * @param userName
	 * @param searchName
	 * @param conn
	 * @return SavedSearch
	 * @throws RepoproException
	 */
	public SavedSearch getFilterSearchForLoad(Long assetId,
			String userName, String searchName, Connection conn)
					throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getFilterSearchForLoad ||assetId:" + assetId
					+ ",userName:" + userName + ",searchName:" + searchName
					+ "||Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		SavedSearch savedSearch = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchForLoad || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_FILTER_SEARCH_FOR_LOAD));
			pstmt.setLong(Constants.ONE, assetId);
			pstmt.setString(Constants.TWO, searchName);
			pstmt.setString(Constants.THREE, userName);

			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchForLoad || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_FILTER_SEARCH_FOR_LOAD));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				savedSearch = new SavedSearch();
				savedSearch.setSearchId(rs.getLong("search_id"));
				savedSearch.setSearchName(rs.getString("search_name"));
				savedSearch.setParamsValue(rs.getString("params_value"));
				savedSearch.setOperatorsValue(rs.getString("operators_value"));
				savedSearch.setParam1Value(rs.getString("param1_value"));
				savedSearch.setLogicalSelectValue(rs
						.getString("logical_select_value"));
				savedSearch.setAssetName(rs.getString("asset_name"));
				savedSearch.setParam2Value(rs.getString("param2_value"));
				savedSearch.setTaxValue(rs.getString("taxonomy_value"));
				savedSearch.setUserName(rs.getString("userName"));
				savedSearch.setDefaultUserFilterView(rs.getInt("default_User_FilterView"));
				if (log.isTraceEnabled()) {
					log.trace("getFilterSearchForLoad || "
							+ savedSearch.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getFilterSearchForLoad || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.FILTER_SEARCH_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getFilterSearchForLoad || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getFilterSearchForLoad || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getFilterSearchForLoad || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchForLoad || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("getFilterSearchForLoad ||assetId:" + assetId
					+ ",userName:" + userName + ",searchName:" + searchName
					+ "||End");
		}
		return savedSearch;

	}

	/**
	 * @method updateFilterSearch
	 * @description update filter search data
	 * @param savedSearch
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateFilterSearch(SavedSearch savedSearch, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateFilterSearch || " + savedSearch.toString()
					+ "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstm = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateFilterSearch || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if(savedSearch.getDefaultUserFilterView()==1L) {
				pstm = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.UPDATE_DEFAULT_FILTER_SEARCH_DETAILS));
				pstm.setLong(Constants.ONE, 0);
				pstm.setString(Constants.TWO, savedSearch.getAssetName());
				pstm.setString(Constants.THREE, savedSearch.getUserName());
				
				int deleteResult = pstm.executeUpdate();
			}
			
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.UPDATE_FILTERSEARCH));

			pstmt.setString(Constants.ONE, savedSearch.getSearchName());
			pstmt.setString(Constants.TWO, savedSearch.getParamsValue());
			pstmt.setString(Constants.THREE, savedSearch.getOperatorsValue());
			pstmt.setString(Constants.FOUR, savedSearch.getParam1Value());
			pstmt.setString(Constants.FIVE, savedSearch.getLogicalSelectValue());
			pstmt.setString(Constants.SIX, savedSearch.getAssetName());
			pstmt.setString(Constants.SEVEN, savedSearch.getParam2Value());
			pstmt.setString(Constants.EIGHT, savedSearch.getTaxValue());
			pstmt.setString(Constants.NINE, savedSearch.getUserName());
			pstmt.setInt(Constants.TEN, savedSearch.getDefaultUserFilterView());
			pstmt.setLong(Constants.ELEVEN, savedSearch.getSearchId());
			if (log.isTraceEnabled()) {
				log.trace("updateFilterSearch || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_FILTERSEARCH));
			}

			int result = pstmt.executeUpdate();
			if (result == 0) {
				log.warn("updateFilterSearch || FilterSearch is not updated and throws RepoproException");
				throw new RepoproException(
						MessageUtil
						.getMessage(Constants.FILTERSEARCH_NOT_UPDATED));
			}

		} catch (SQLException e) {
			log.error("updateFilterSearch || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.FILTERSEARCH_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateFilterSearch || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateFilterSearch || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateFilterSearch || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("updateFilterSearch ||" + savedSearch.toString() + " End");
		}

	}

	/**
	 * @method deleteFilterSearch
	 * @description to delete filter search data
	 * @param searchId
	 * @param conn
	 * @return List<String> success or failure message
	 * @throws RepoproException
	 */
	public List<String> deleteFilterSearch(Long searchId, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteFilterSearch || Begin with SearchId : " + searchId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		List<String> msg = new ArrayList<String>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteFilterSearch || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_FILTER_SEARCH));

			pstmt.setLong(Constants.ONE, searchId);

			if (log.isTraceEnabled()) {
				log.trace("deleteFilterSearch || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_FILTER_SEARCH));
			}

			int result = pstmt.executeUpdate();

			if (result == 0) {
				log.warn("deleteFilterSearch || search with id " + searchId
						+ " already deleted ");
				msg.add("filter search with " + searchId + " already deleted");
			}

		} catch (SQLException e) {
			log.error("deleteFilterSearch || "
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.FILTERSEARCH_DATA_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteFilterSearch || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteFilterSearch || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteFilterSearch || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("deleteFilterSearch ||SearchId :" + searchId + "||End");
		}
		return msg;
	}


	/**
	 * @method : retParamIdForAssetAndParamName
	 * @param conditionAssetName
	 * @param parameterName
	 * @param conn
	 * @return
	 * @throws RepoproException 
	 */
	public AssetParamDef retParamIdForAssetAndParamName(String conditionAssetName,String parameterName,Connection conn) throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("retParamIdForAssetAndParamName ||   begin with "+conditionAssetName +" "+parameterName);
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		AssetParamDef assetParamDef = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retParamIdForAssetAndParamName ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAM_DEF_BY_ASSET_NAME_AND_ASSET_PARAM_NAME));
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_PARAM_DEF_BY_ASSET_NAME_AND_ASSET_PARAM_NAME));

			preparedStmt.setString(1, conditionAssetName);
			preparedStmt.setString(2, parameterName);
			rs = preparedStmt.executeQuery();

			while (rs.next()) {
				assetParamDef = new AssetParamDef();
				assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
				assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
				assetParamDef.setAssetParamName(rs.getString("asset_param_name"));
				assetParamDef.setDescription(rs.getString("description"));
				assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
				assetParamDef.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
				assetParamDef.setHasArray(rs.getInt("isArray"));
				assetParamDef.setListType(rs.getInt("LIST_TYPE"));
				assetParamDef.setLdapMappingId(rs.getInt("ldap_mapping_id"));

			}

			if (log.isTraceEnabled()) {
				log.trace("retParamIdForAssetAndParamName ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (log.isTraceEnabled()) {
				log.trace("retParamIdForAssetAndParamName ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAM_DEF_BY_ASSET_NAME_AND_ASSET_PARAM_NAME));
			}

		} catch (SQLException e) {
			log.error("retParamIdForAssetAndParamName || "
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.PARAM_ID_NOT_FOUND));
		} catch (IOException e) {
			log.error("retParamIdForAssetAndParamName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retParamIdForAssetAndParamName || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retParamIdForAssetAndParamName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isDebugEnabled()) {
			log.debug("retParamIdForAssetAndParamName || exit");
		}
		return assetParamDef;
	}


	/**
	 * @method : getParamsDetailByAssetName
	 * @param assetName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getParamsDetailByAssetName(String assetName,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getParamsDetailByAssetId || assetName:" + assetName
					+ " || begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		AssetParamDef assetParamDef = null;
		List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParamsDetailByAssetId || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedSt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_PARAM_DETAILS_BY_ASSET_NAME));
			if (log.isTraceEnabled()) {
				log.trace("getParamsDetailByAssetId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_PARAM_DETAILS_BY_ASSET_NAME));
			}
			preparedSt.setString(Constants.ONE, assetName);

			rs = preparedSt.executeQuery();

			while (rs.next()) {
				assetParamDef = new AssetParamDef();
				assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
				assetParamDef.setAssetParamName(rs
						.getString("asset_param_name"));
				assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
				assetParamDef.setDescription(rs.getString("description"));
				assetParamDef.setAssetCategoryName(rs.getString("asset_category_name"));
				assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
				assetParamDef.setListTypeParamTypeId(rs
						.getLong("list_param_type_id"));
				assetParamDef.setHasImportantValue(rs
						.getBoolean("is_important"));
				assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
				assetParamDef.setHasdefViewValue(rs
						.getBoolean("is_default_view"));
				assetParamDef.setMappedAssetId(rs.getLong("mapped_asset_id"));
				assetParamDef.setModifyByUserId(rs.getLong("static_modify_by_user_id"));
				assetParamDef.setLastUpdatedTime(rs.getTimestamp("static_last_updated_time"));
				assetParamDef.setFileName(rs.getString("fileName"));
				assetParamDef.setSize(rs.getInt("size"));
				assetParamDef.setQuickLink(rs.getBoolean("quick_link"));
				assetParamDef.setDisplayPosition(rs.getInt("disp_position"));
				assetParamDef.setSystemParam(rs.getBoolean("is_system_param"));
				assetParamDef.setMimetype(rs.getString("mimetype"));
				assetParamDef.setStaticValue(rs.getString("static_val"));
				assetParamDef.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				assetParamDef.setStaticFileContent(rs.getBytes("static_file_content"));
				assetParamDef.setHasArray(rs.getInt("isArray"));
				assetParamDef.setDerivedAssetListRule(rs.getString("derived_asset_list"));
				assetParamDef.setLdapMappingId(rs.getInt("ldap_mapping_id"));
				assetParamDefList.add(assetParamDef);


				if (log.isTraceEnabled()) {
					log.trace("getParamsDetailByAssetId || " + assetParamDef.toString());
				}

			}

			if (log.isDebugEnabled()) {
				log.debug("getParamsDetailByAssetId || "
						+ assetParamDefList.toString());
			}

		} catch (SQLException e) {
			log.error("getParamsDetailByAssetId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_PARAM_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getParamsDetailByAssetId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getParamsDetailByAssetId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamsDetailByAssetId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getParamsDetailByAssetId ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getParamsDetailByAssetId || assetName:" + assetName
					+ " ||exit");
		}
		return assetParamDefList;
	}


	/**
	 * @method : getParameterForAssetInstParamAndVersionId
	 * @param paramName
	 * @param VersionId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public ParameterValues getParameterForAssetInstParamAndVersionId(String paramName , long VersionId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getParameterForAssetInstParamAndVersionId || paramName:" + paramName+ "and VersionId:"+VersionId
					+ " || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		ParameterValues parameterValue = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParameterForAssetInstParamAndVersionId || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedSt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_PARAMETER_VALUES_BY_ASSET_PARAM_NAME_AND_VERSIONID));

			if (log.isTraceEnabled()) {
				log.trace("getParameterForAssetInstParamAndVersionId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_PARAMETER_VALUES_BY_ASSET_PARAM_NAME_AND_VERSIONID));
			}

			preparedSt.setLong(Constants.ONE, VersionId);
			preparedSt.setString(Constants.TWO, paramName);

			rs = preparedSt.executeQuery();
			ArrayList<String> pvArrayList = new ArrayList<String>();
			ArrayList<String> textdataLists = new ArrayList<String>();
			ArrayList<String> ldapMappingLists = new ArrayList<String>();
			ArrayList<String> pvArrayListWithouttags = new ArrayList<String>();
			Map<String,Integer> ldapMappingMap = new LinkedHashMap<String,Integer>();
			while (rs.next()) {
				
				parameterValue = new ParameterValues();
				parameterValue.setAssetParamId(rs.getLong("asset_param_id"));
				parameterValue.setParameterValuesId(rs.getLong("parameter_values_id"));
				parameterValue.setAssetInstParamId(rs.getLong("asset_inst_param_id"));
				//parameterValue.setValue(rs.getString("value"));
				parameterValue.setFileName(rs.getString("fileName"));
				parameterValue.setMimeType(rs.getString("mimetype"));
				parameterValue.setFileContent(rs.getBytes("fileContent"));
				parameterValue.setImportant(rs.getBoolean("is_important"));
				parameterValue.setMandatory(rs.getBoolean("is_mandatory"));
				parameterValue.setAssetParamName(rs.getString("asset_param_name"));
				parameterValue.setModifyByUserId(rs.getLong("modify_by_user_id"));
				parameterValue.setParamTypeId(rs.getLong("param_type_id"));
				parameterValue.setLastUpdatedTime(rs.getTimestamp("last_updated_time"));
				parameterValue.setHasArray(rs.getInt("isArray"));
				if(rs.getLong("param_type_id") == 7L){
					if(rs.getInt("isArray") == 1){
						pvArrayList.add(rs.getString("value"));
						pvArrayListWithouttags.add(rs.getString("rtf_plain_text"));
						parameterValue.setRTFwithTags(pvArrayList);
						parameterValue.setRTFwithOutTags(pvArrayListWithouttags);
					}else{
						parameterValue.setValue(rs.getString("value"));
						parameterValue.setRTFPlainText(rs.getString("rtf_plain_text"));
					}
				}else if(rs.getLong("param_type_id") == 1L){
					if(rs.getInt("isArray") == 1){
					textdataLists.add(rs.getString("value"));
					parameterValue.setTextDataList(textdataLists);
					}else{
						parameterValue.setValue(rs.getString("value"));
					}
				}else if(rs.getLong("param_type_id") == 9L){
					ldapMappingLists.add(rs.getString("value"));
					ldapMappingMap.put(rs.getString("value"), rs.getInt("ldap_attribute_id"));
					parameterValue.setLdapMappingList(ldapMappingLists);
					parameterValue.setLdapMappingMap(ldapMappingMap);
				}else{
					parameterValue.setValue(rs.getString("value"));
				}
				if (log.isTraceEnabled()) {
					log.trace("getParameterForAssetInstParamAndVersionId || " + parameterValue.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getParameterForAssetInstParamAndVersionId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_PARAMETER_VALUES_DETAILS_NOT_FETCHED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getParameterForAssetInstParamAndVersionId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getParameterForAssetInstParamAndVersionId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParameterForAssetInstParamAndVersionId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getParameterForAssetInstParamAndVersionId ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getParameterForAssetInstParamAndVersionId ||  paramName:" + paramName+ "and VersionId:"+VersionId
					+ " ||exit");
		}
		return parameterValue;
	}


	/**
	 * @method : getParamIdForAssetAndParamName
	 * @param assetName
	 * @param paramName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetParamDef getParamIdForAssetAndParamName(String assetName,
			String paramName,Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getParamIdForAssetAndParamName || paramName:" + paramName+ "and assetName:"+assetName
					+ " || begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		AssetParamDef assetParamDef = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParamIdForAssetAndParamName || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedSt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_PARAM_ID_FOR_ASSET_AND_PARAM_NAME));
			if (log.isTraceEnabled()) {
				log.trace("getParamIdForAssetAndParamName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_PARAM_ID_FOR_ASSET_AND_PARAM_NAME));
			}
			preparedSt.setString(Constants.ONE, assetName);
			preparedSt.setString(Constants.TWO, paramName);


			rs = preparedSt.executeQuery();

			while (rs.next()) {
				assetParamDef = new AssetParamDef();
				assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
				assetParamDef.setAssetParamName(rs.getString("asset_param_name"));
				assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
				assetParamDef.setDescription(rs.getString("description"));
				assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
				assetParamDef.setListTypeParamTypeId(rs
						.getLong("list_param_type_id"));
				assetParamDef.setHasImportantValue(rs
						.getBoolean("is_important"));
				assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
				assetParamDef.setHasdefViewValue(rs
						.getBoolean("is_default_view"));
				assetParamDef.setMappedAssetId(rs.getLong("mapped_asset_id"));
				assetParamDef.setModifyByUserId(rs.getLong("static_modify_by_user_id"));
				assetParamDef.setLastUpdatedTime(rs.getTimestamp("static_last_updated_time"));
				assetParamDef.setFileName(rs.getString("fileName"));
				assetParamDef.setSize(rs.getInt("size"));
				assetParamDef.setQuickLink(rs.getBoolean("quick_link"));
				assetParamDef.setDisplayPosition(rs.getInt("disp_position"));
				assetParamDef.setSystemParam(rs.getBoolean("is_system_param"));
				assetParamDef.setMimetype(rs.getString("mimetype"));
				assetParamDef.setStaticValue(rs.getString("static_val"));
				assetParamDef.setHasArray(rs.getInt("isArray"));
				assetParamDef.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				assetParamDef.setStaticFileContent(rs.getBytes("static_file_content"));
				assetParamDef.setListType(rs.getInt("list_type"));
				assetParamDef.setDerivedAssetListRule(rs.getString("derived_asset_list"));
				assetParamDef.setLdapMappingId(rs.getInt("ldap_mapping_id"));
			}

			if (log.isTraceEnabled()) {
				log.trace("getParamIdForAssetAndParamName || " + assetParamDef.toString());
			}

		} catch (SQLException e) {
			log.error("getParamIdForAssetAndParamName ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_PARAM_ID_FOR_ASSET_AND_PARAM_NAME_NOT_FETCHED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getParamIdForAssetAndParamName ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getParamIdForAssetAndParamName ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamIdForAssetAndParamName ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getParamIdForAssetAndParamName ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getParamIdForAssetAndParamName ||  paramName:" + paramName+ "and assetName:"+assetName
					+ " ||exit");
		}
		return assetParamDef;
	}


	/**
	 * @method : updateParameterInAssetParamDef
	 * @param param
	 * @param assetName
	 * @param paramName
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateParameterInAssetParamDef(AssetParamDef param, String assetName, String paramName , Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateParameterInAssetParamDef || " +param.toString()+ "Begin" );
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateParameterInAssetParamDef || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.UPDATE_ASSET_PARAM_DEF));

			pstmt.setString(Constants.ONE, param.getStaticValue());
			pstmt.setBinaryStream(Constants.TWO, param.getImage());
			pstmt.setString(Constants.THREE,param.getFileName());
			pstmt.setString(Constants.FOUR,param.getMimetype());
			pstmt.setTimestamp(Constants.FIVE,param.getLastUpdatedTime() );
			pstmt.setLong(Constants.SIX,param.getModifyByUserId() );
			pstmt.setString(Constants.SEVEN,assetName );
			pstmt.setString(Constants.EIGHT,paramName );
			

			if (log.isTraceEnabled()) {
				log.trace("updateParameterInAssetParamDef || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_ASSET_PARAM_DEF));
			}

			int result = pstmt.executeUpdate();
			
			if (result == 0) {
				log.warn("updateParameterInAssetParamDef || AssetParamDef is not updated and throws RepoproException");
			}

		} catch (SQLException e) {
			log.error("updateParameterInAssetParamDef || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_PARAM_DEF_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateParameterInAssetParamDef || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateParameterInAssetParamDef || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateParameterInAssetParamDef || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateParameterInAssetParamDef || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateParameterInAssetParamDef ||" +param.toString() + " End");
		}
	}


	/**
	 * @method : addAssetInstParam
	 * @param assetInstParams
	 * @param conn
	 * @throws RepoproException
	 */
	public AssetInstParams addAssetInstParam(AssetInstParams assetInstParams,
			Connection conn)throws RepoproException {


		if (log.isTraceEnabled()) {
			log.trace("addAssetInstParam || " + assetInstParams.toString() + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addAssetInstParam || " + Constants.LOG_CONNECTION_OPEN);
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_ASSET_INST_PARAM));

			pstmt.setLong(Constants.ONE, assetInstParams.getAssetInstVersionId());
			pstmt.setLong(Constants.TWO, assetInstParams.getAssetParamId());
			pstmt.setTimestamp(Constants.THREE, assetInstParams.getLastUpdatedTime());
			pstmt.setLong(Constants.FOUR, assetInstParams.getModifyByUserId());

			if (log.isTraceEnabled()) {
				log.trace("addAssetInstParam || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_ASSET_INST_PARAM));
			}

			pstmt.executeUpdate();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				assetInstParams.setAssetInstParamId(rs.getLong(1));
			}


		} catch (SQLException e) {
			log.error("addAssetInstParam || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INST_PARAMS_NOT_CREATED));
		} catch (IOException e) {
			log.error("addAssetInstParam || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addAssetInstParam || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addAssetInstParam || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addAssetInstParam || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("addAssetInstParam || " + assetInstParams.toString() + " End");
		}
		return assetInstParams;
	}


	/**
	 * @method : addParameterValue
	 * @param paramValue
	 * @param conn
	 * @throws RepoproException
	 */
	public void addParameterValue(ParameterValues paramValue, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addParameterValue || " + paramValue.toString() + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}


			if (log.isTraceEnabled()) {
				log.trace("addParameterValue || " + Constants.LOG_CONNECTION_OPEN);
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_PARAMETER_VALUES));


			pstmt.setLong(Constants.ONE, paramValue.getAssetInstParamId());
			pstmt.setString(Constants.TWO, paramValue.getValue());
			pstmt.setBinaryStream(Constants.THREE, paramValue.getImage());
			pstmt.setString(Constants.FOUR, paramValue.getFileName());
			pstmt.setString(Constants.FIVE, paramValue.getMimeType());


			if (log.isTraceEnabled()) {
				log.trace("addParameterValue || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_PARAMETER_VALUES));
			}

			pstmt.executeUpdate();
		
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				paramValue.setParameterValuesId(rs.getLong(1));
			}


		} catch (SQLException e) {
			log.error("addParameterValue || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_VALUES_NOT_CREATED));
		} catch (IOException e) {
			log.error("addParameterValue || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addParameterValue || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addParameterValue || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addParameterValue || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("addParameterValue || " + paramValue.toString() + " End");
		}
	}

	public void addParameterValueForLdapMapping(ParameterValues paramValue, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addParameterValueForLdapMapping || " + paramValue.toString() + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}


			if (log.isTraceEnabled()) {
				log.trace("addParameterValueForLdapMapping || " + Constants.LOG_CONNECTION_OPEN);
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_PARAMETER_VALUES_FOR_LDAP_MAPPING));


			pstmt.setLong(Constants.ONE, paramValue.getAssetInstParamId());
			pstmt.setString(Constants.TWO, paramValue.getValue());
			pstmt.setBinaryStream(Constants.THREE, paramValue.getImage());
			pstmt.setString(Constants.FOUR, paramValue.getFileName());
			pstmt.setString(Constants.FIVE, paramValue.getMimeType());
			pstmt.setInt(Constants.SIX, paramValue.getLdapAttributeId());


			if (log.isTraceEnabled()) {
				log.trace("addParameterValueForLdapMapping || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_PARAMETER_VALUES_FOR_LDAP_MAPPING));
			}

			pstmt.executeUpdate();
		
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				paramValue.setParameterValuesId(rs.getLong(1));
			}


		} catch (SQLException e) {
			log.error("addParameterValueForLdapMapping || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_VALUES_NOT_CREATED));
		} catch (IOException e) {
			log.error("addParameterValueForLdapMapping || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addParameterValueForLdapMapping || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addParameterValueForLdapMapping || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addParameterValueForLdapMapping || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("addParameterValueForLdapMapping || " + paramValue.toString() + " End");
		}
	}

	/**
	 * @method : getCategoryByAssetID
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<Category> getCategoryByAssetID(Long assetId, Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getCategoryByAssetID || "+ assetId.toString() +" Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		List<Category> listOfCategories = new ArrayList<Category>();
		Category category = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getCategoryByAssetID || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_CATEGORYS_BY_ASSET_ID));
			if (log.isTraceEnabled()) {
				log.trace("getCategoryByAssetID || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_CATEGORYS_BY_ASSET_ID));
			}
			pstmt.setLong(Constants.ONE, assetId);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				category = new Category();
				category.setAssetId(result.getLong("asset_id"));
				category.setCategoryId(result.getLong("asset_category_id"));
				category.setCategoryName(result.getString("asset_category_name"));
				category.setDescription(result.getString("description"));
				category.setDisp_position(result.getInt("disp_position"));
				listOfCategories.add(category);
				if (log.isTraceEnabled()) {
					log.trace("getCategoryByAssetID || "+ category);
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getCategoryByAssetID || "+ listOfCategories);
			}
		} catch (SQLException e) {
			log.error("getCategoryByAssetID || " + Constants.LOG_UPDATE_SQLEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.GET_CATEGORY_BY_ASSET__ID_NOT_SELECTED));
		} catch (IOException e) {
			log.error("getCategoryByAssetID || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getCategoryByAssetID || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getCategoryByAssetID || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getCategoryByAssetID || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("getCategoryByAssetID || End");
		}
		return listOfCategories;
	}


	/**
	 * @method : getAllDerivedAttributes
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getAllDerivedAttributes(Connection conn) throws RepoproException{

		log.trace("getAllDerivedAttributes || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		List<AssetParamDef> listOfDerivedAttributes = new ArrayList<AssetParamDef>();
		AssetParamDef paramDef = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllDerivedAttributes || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_DERIVED_ATTRIBUTES));

			if (log.isTraceEnabled()) {
				log.trace("getAllDerivedAttributes || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_DERIVED_ATTRIBUTES));
			}

			ResultSet rs = pstmt.executeQuery();
			if (rs==null) {
				log.warn("Getting All Derived Attributes || Derived Attributes is not Selected and throws RepoproException");
			}

			while(rs.next()){
				paramDef = new AssetParamDef();

				paramDef.setAssetParamId(rs.getLong("asset_param_id"));
				paramDef.setAssetCategoryId(rs.getLong("asset_category_id"));
				paramDef.setAssetParamName(rs.getString("asset_param_name"));
				paramDef.setDefaultView(rs.getInt("is_default_view"));
				paramDef.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				paramDef.setDescription(rs.getString("description"));
				paramDef.setDisplayPosition(rs.getInt("disp_position"));
				paramDef.setFileName(rs.getString("fileName"));
				paramDef.setSystemParam(rs.getBoolean("is_system_param"));
				paramDef.setStaticValue(rs.getString("static_val"));
				paramDef.setSize(rs.getInt("size"));
				paramDef.setHasImportantValue(rs.getBoolean("is_important"));
			    paramDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				paramDef.setQuickLink(rs.getBoolean("quick_link"));
				paramDef.setParamTypeId(rs.getLong("param_type_id"));
				paramDef.setListTypeParamTypeId(rs.getLong("list_param_type_id"));
				listOfDerivedAttributes.add(paramDef);
				if(log.isTraceEnabled()){
					log.trace("getAllDerivedAttributes "+paramDef);
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllDerivedAttributes "+listOfDerivedAttributes);
			}

			log.debug("Successfully retrived the all Derived attributes "+listOfDerivedAttributes);


		} catch (SQLException e) {
			log.error("getAllDerivedAttributes || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.DERIVED_ATTRIBUTES_NOT_SELECTED));
		} catch (IOException e) {
			log.error("getAllDerivedAttributes || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllDerivedAttributes || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllDerivedAttributes || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllDerivedAttributes || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAllDerivedAttributes || End");
		}
		return listOfDerivedAttributes;

	}


	/**
	 * @method : getAssetParameterDefsByCategoryID
	 * @param categoryId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getAssetParameterDefsByCategoryID(Long categoryId, Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getAssetParameterDefsByCategoryID || "+ categoryId.toString() +" Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		List<AssetParamDef> listOfAssetParamDefs = new ArrayList<AssetParamDef>();
		AssetParamDef adf = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetParameterDefsByCategoryID || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_PARAMETERS_BY_ASSET_CATEGORY_ID));

			if (log.isTraceEnabled()) {
				log.trace("getAssetParameterDefsByCategoryID || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_PARAMETERS_BY_ASSET_CATEGORY_ID));
			}

			pstmt.setLong(Constants.ONE, categoryId);

			ResultSet result = pstmt.executeQuery();
			while (result.next()) {

				adf = new AssetParamDef();

				adf.setAssetParamId(result.getLong("asset_param_id"));
				adf.setAssetCategoryId(result.getLong("asset_category_id"));
				adf.setAssetParamName(result.getString("asset_param_name"));
				adf.setDescription(result.getString("description"));
				adf.setParamTypeId(result.getLong("param_type_id"));
				adf.setListTypeParamTypeId(result.getLong("list_param_type_id"));
				adf.setMappedAssetId(result.getLong("mapped_asset_id"));
				adf.setSize(result.getInt("size"));
				adf.setQuickLink(result.getBoolean("quick_link"));
				adf.setDisplayPosition(result.getInt("disp_position"));
				adf.setSystemParam(result.getBoolean("is_system_param"));
				adf.setIs_static(result.getInt("is_static"));
				adf.setHasImportantValue(result.getBoolean("is_important"));
				adf.setHasMandatoryValue(result.getBoolean("is_mandatory"));
				adf.setDefaultView(result.getInt("is_default_view"));
				adf.setStaticValue(result.getString("static_val"));
				adf.setStaticFileContent(result.getBytes("static_file_content"));
				adf.setFileName(result.getString("fileName"));
				adf.setMimetype(result.getString("mimetype"));
				adf.setHasArray(result.getInt("isArray"));
				adf.setListType(result.getInt("list_type"));
				adf.setLastUpdatedTime(result.getTimestamp("static_last_updated_time"));
				adf.setDerivedAttributeComputation(result.getString("derived_computed_description"));
				adf.setDerivedAssetListRule(result.getString("derived_asset_list"));
				adf.setLdapMappingId(result.getInt("ldap_mapping_id"));
				adf.setNotifyOnRuleValidate(result.getBoolean("notify"));
				if(log.isTraceEnabled()){
					log.trace("getAssetParameterDefsByCategoryID "+adf);
				}
				listOfAssetParamDefs.add(adf);
			}
			if (log.isDebugEnabled()) {
				log.debug("getAssetParameterDefsByCategoryID || "+ listOfAssetParamDefs);
			}
		} catch (SQLException e) {
			log.error("getAssetParameterDefsByCategoryID || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_CATEGORY_BY_ASSET__ID_NOT_SELECTED));
		} catch (IOException e) {
			log.error("getAssetParameterDefsByCategoryID || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetParameterDefsByCategoryID || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetParameterDefsByCategoryID || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetParameterDefsByCategoryID || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAssetParameterDefsByCategoryID || End");
		}
		return listOfAssetParamDefs;
	}


	/**
	 * @method : getTaxonomiesByAssetId
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException 
	 */
	public Map<Long,String> getTaxonomiesByAssetId(Long assetId,Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getTaxonomiesByAssetId || Begin with assetId : "+ assetId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		Map<Long,String> assignedTaxonomies = new HashMap<Long, String>();

		try {
			if(log.isTraceEnabled()){
				log.trace("getTaxonomiesByAssetId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSIGNED_TAXONOMIES_FOR_ASSET));
			pstmt.setLong(Constants.ONE, assetId);
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByAssetId || "+PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSIGNED_TAXONOMIES_FOR_ASSET));
			}
			ResultSet result = pstmt.executeQuery();
			while(result.next()) {
				Long taxonomyId = result.getLong("taxonomy_id");
				String taxonomyName = result.getString("taxonomy_name");

				assignedTaxonomies.put(taxonomyId, taxonomyName);

				if(log.isTraceEnabled()){
					log.trace("getTaxonomiesByAssetId "+assignedTaxonomies);
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getTaxonomiesByAssetId "+assignedTaxonomies);
			}

		} catch (SQLException e) {
			log.error("getTaxonomiesByAssetId || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_BY_ASSET_ID_NOT_FOUND));
		} catch (IOException e) {
			log.error("getTaxonomiesByAssetId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getTaxonomiesByAssetId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getTaxonomiesByAssetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getTaxonomiesByAssetId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getTaxonomiesByAssetId || End");
		}
		return assignedTaxonomies;
	}


	/**
	 * @method : getMappedParametersWithAssetId
	 * @description : to get mapped parameters
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getMappedParametersWithAssetId(Long assetId,Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getMappedParametersWithAssetId || Begin with assetId : "+ assetId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AssetParamDef ad = null;
		List<AssetParamDef> listOfDefs = new ArrayList<AssetParamDef>();

		try {
			if (log.isTraceEnabled()){
				log.trace("getMappedParametersWithAssetId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_MAPPED_ASSET_PARAM_DEF_BY_ASSET_ID));


			if (log.isTraceEnabled()) {
				log.trace("getMappedParametersWithAssetId || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_MAPPED_ASSET_PARAM_DEF_BY_ASSET_ID));
			}
			pstmt.setLong(Constants.ONE, assetId);
			rs =  pstmt.executeQuery();

			while(rs.next()){
				ad = new AssetParamDef();
				ad.setAssetParamId(rs.getLong("asset_param_id"));
				listOfDefs.add(ad);
			}

		} catch (SQLException e) {
			log.error("getMappedParametersWithAssetId || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.NO_ASSET_MAPPED_PARAMETERS_FOR_ASSET));
		} catch (IOException e) {
			log.error("getMappedParametersWithAssetId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getMappedParametersWithAssetId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getMappedParametersWithAssetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closeResultSet(rs);
			if (log.isTraceEnabled()) {
				log.trace("getMappedParametersWithAssetId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if(log.isTraceEnabled()){
			log.trace("getMappedParametersWithAssetId || End");
		}
		return listOfDefs;
	}


	/**
	 * @method : deleteAsset
	 * @description : to delete an asset
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<String> deleteAsset(Long assetId,String assetName, Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("deleteAsset || Begin with assetId : "+ assetId+" , "+assetName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		List<String> msg = new ArrayList<String>();

		try {
			if (log.isTraceEnabled()){
				log.trace("deleteAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_ASSET));

			pstmt.setLong(Constants.ONE, assetId);

			if (log.isTraceEnabled()) {
				log.trace("deleteAsset || "+PropertyFileReader.getInstance().
						getValue(Constants.DELETE_ASSET));
			}

			int result = pstmt.executeUpdate();

			if (result == 0) {
				log.warn("deleteAsset || Asset with id "+ assetId +" already deleted ");
				msg.add("Asset with "+ assetId +" already deleted");
			}


		} catch (SQLException e) {
			log.error("deleteAsset || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteAsset || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("deleteAsset || End");
		}
		return msg;
	}

	/**
	 * @method : deleteCategory
	 * @param categoryID
	 * @param conn
	 * @return
	 */
	public int deleteCategory(Long  categoryID,Connection conn){

		if(log.isTraceEnabled()){
			log.trace("deleteCategory || Begin with categoryID : "+ categoryID);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0 ;

		try {
			if (log.isTraceEnabled()){
				log.trace("deleteCategory || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_ASSET_CATEGORY_DEF));
			pstmt.setLong(1,categoryID);
			result = pstmt.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("deleteCategory || "+PropertyFileReader.getInstance().
						getValue(Constants.DELETE_ASSET_CATEGORY_DEF));
			}

			log.info("Category successfully deleted ");

		} catch (SQLException e) {
			log.error("deleteCategory || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.ASSET_CATEGORY_DEF_NOT_DELETED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("deleteCategory || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("deleteCategory || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("deleteCategory || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteCategory || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("deleteCategory || End");
		}

		return result;

	}



	/**
	 * @method : getCheckedGroupDetailsByAssetId
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public Map<Long,List<String>> getCheckedGroupDetailsByAssetId(Long assetId,Connection conn)throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("getCheckedGroupDetailsByAssetId || begin with assetId : "
					+ assetId);
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		Map<Long,List<String>> map = new LinkedHashMap<Long, List<String>>();

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getCheckedGroupDetailsByAssetId || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_CHECKED_GROUP_DETAILS_BY_ASSET_ID));

			preparedStmt.setLong(Constants.ONE, assetId);

			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getCheckedGroupDetailsByAssetId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_CHECKED_GROUP_DETAILS_BY_ASSET_ID));
			}

			while (resultSet.next()) {
				String categoryName = resultSet.getString("asset_category_name");
				Long categoryId = resultSet.getLong("asset_category_id");
				String groupName = resultSet.getString("group_name");

				map = CommonUtils.addValues(categoryId, groupName, map);

				if (log.isTraceEnabled()) {
					log.trace("getCheckedGroupDetailsByAssetId || map : " + map.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getCheckedGroupDetailsByAssetId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_DATA_NOT_FOUND));

		} catch (IOException e) {
			log.error("getCheckedGroupDetailsByAssetId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("getCheckedGroupDetailsByAssetId || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("getCheckedGroupDetailsByAssetId ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getCheckedGroupDetailsByAssetId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getCheckedGroupDetailsByAssetId || exit");

		return map;

	}

	/**
	 * @method updateParameter
	 * @param adf
	 * @param conn
	 * @return int
	 */
	public int updateParameter(AssetParamDef adf,Connection conn)throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("updateParameter || Begin with AssetParamDef : "+ adf.toString());
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0 ;
		try {
			if (log.isTraceEnabled()){
				log.trace("updateParameter || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();								
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_ASSET_PARAMETER_DEF));
			pstmt.setString(Constants.ONE, adf.getAssetParamName());
			pstmt.setString(Constants.TWO,adf.getDescription());
			pstmt.setLong(Constants.THREE,adf.getParamTypeId());
			if(adf.getListTypeParamTypeId() == 0){
				pstmt.setString(Constants.FOUR,null);
			}else{
				pstmt.setLong(Constants.FOUR,adf.getListTypeParamTypeId());
			}
			
			
			if(adf.getMappedAssetId() == 0){
				pstmt.setString(Constants.FIVE,null);
			}else{
				pstmt.setLong(Constants.FIVE,adf.getMappedAssetId());
			}
			
			/*if(adf.getListTypeName()!=null){
				if(adf.getListTypeName().equalsIgnoreCase("ASSET_LIST")){
					pstmt.setLong(Constants.FOUR, adf.getListTypeParamTypeId());	
				}else if(adf.getListTypeName().equalsIgnoreCase("CUSTOM_LIST")){
					
				}else {
					pstmt.setLong(Constants.FOUR, adf.getListTypeParamTypeId());	
				}
			}else{
				pstmt.setNull(Constants.FOUR, 0);	
			}*/

			
			/*if(adf.getMappedAssetId()==0){
				pstmt.setNull(Constants.FIVE, 0);
			}else{
				pstmt.setLong(Constants.FIVE, adf.getMappedAssetId());
			}*/
			pstmt.setInt(Constants.SIX, adf.getSize());
			pstmt.setBoolean(Constants.SEVEN, adf.isQuickLink());
			pstmt.setInt(Constants.EIGHT,adf.getDisplayPosition());
			
			
			if(adf.isSystemParam()){
				pstmt.setInt(Constants.NINE, 1);	
			}else{
				pstmt.setInt(Constants.NINE, 0);
			}
		
			pstmt.setInt(Constants.TEN, adf.getIs_static());
			if(adf.isHasImportantValue()){
				pstmt.setInt(Constants.ELEVEN, 1);
			}else{
				pstmt.setInt(Constants.ELEVEN, 0);
			}
			
			
			if(adf.getDefaultView()==1){
				pstmt.setInt(Constants.TWELVE, 1);
				
			}else{
				pstmt.setInt(Constants.TWELVE, 0);
			}
			
			
			pstmt.setString(Constants.THIRTEEN, adf.getStaticValue());
			pstmt.setBytes(Constants.FOURTEEN,adf.getStaticFileContent());
			pstmt.setString(Constants.FIFTEEN, adf.getFileName());
			pstmt.setString(Constants.SIXTEEN,adf.getMimetype());
			pstmt.setTimestamp(Constants.SEVENTEEN,adf.getLastUpdatedTime());
			pstmt.setString(Constants.EIGHTEEN,adf.getDerivedAttributeComputation());
			

			if(adf.isHasMandatoryValue()){
				pstmt.setInt(Constants.NINETEEN, 1);
			}else{
				pstmt.setInt(Constants.NINETEEN, 0);
			}
			pstmt.setInt(Constants.TWENTY, adf.getHasArray());
			pstmt.setLong(Constants.TWENTYONE, adf.getAssetCategoryId());
			
			pstmt.setLong(Constants.TWENTYTWO, adf.getLdapMappingId());
			pstmt.setString(Constants.TWENTYTHREE, adf.getDerivedAssetListRule());
			pstmt.setLong(Constants.TWENTYFOUR, adf.getAssetParamId());

			//result = pstmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateParameter || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_ASSET_PARAMETER_DEF));
			}
			result = pstmt.executeUpdate();
			if(result==1){
				log.info("parameter successfully update!");
			}
		} catch (SQLException e) {
			log.error("updateParameter || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.ASSET_PARAM_DEF_NOT_UPDATED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("updateParameter || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("updateParameter || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("updateParameter || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateParameter || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("updateParameter || End");
		}

		return result;
	}
	
	
	public void updatePossibleValues(Long assetparamId,String customListValues , Long valueId, Connection conn)throws RepoproException{
		

		if(log.isTraceEnabled()){
			log.trace("updatePossibleValues || Begin with AssetParamDef : "+ assetparamId.toString());
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0 ;
		try {
			if (log.isTraceEnabled()){
				log.trace("updatePossibleValues || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_POSSIBLE_VALUES));
			pstmt.setString(Constants.ONE, customListValues);
			pstmt.setLong(Constants.TWO,assetparamId);
			pstmt.setLong(Constants.THREE, valueId);

			result = pstmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updatePossibleValues || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_POSSIBLE_VALUES));
			}
			result = pstmt.executeUpdate();
			if(result==1){
				log.info("parameter successfully update!");
			}
		} catch (SQLException e) {
			log.error("updatePossibleValues || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.ASSET_PARAM_DEF_NOT_UPDATED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("updatePossibleValues || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("updatePossibleValues || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("updatePossibleValues || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updatePossibleValues || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("updatePossibleValues || End");
		}
	
	}
	
	
	public List<PossibleValues> getAllPossibleValuesByParamId(Long assetparamId ,Connection conn)throws RepoproException{
		

		if(log.isTraceEnabled()){
			log.trace("getAllPossibleValuesByParamId || Begin with AssetParamDef : "+ assetparamId.toString());
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<PossibleValues> customListValues = new ArrayList<PossibleValues>();
		PossibleValues pv = null;
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllPossibleValuesByParamId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_POSSIBLE_VALUES_BY_PARAM_ID));
			pstmt.setLong(Constants.ONE,assetparamId);

			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				pv = new PossibleValues();
				pv.setValueId(rs.getLong("value_id"));
				pv.setValue(rs.getString("value"));
				pv.setAssetParamId(rs.getLong("asset_param_id"));
				customListValues.add(pv);
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllPossibleValuesByParamId || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_POSSIBLE_VALUES_BY_PARAM_ID));
			}
		
		} catch (SQLException e) {
			log.error("getAllPossibleValuesByParamId || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.GET_POSSIBLE_VALUES_BY_PARAM_ID_NOT_SELECTED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("getAllPossibleValuesByParamId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("getAllPossibleValuesByParamId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("getAllPossibleValuesByParamId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllPossibleValuesByParamId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("getAllPossibleValuesByParamId || End");
		}
	return customListValues;
	}
	
	
	public void insertPossibleValues(Long assetparamId,String customListValues ,Connection conn){
		

		if(log.isTraceEnabled()){
			log.trace("insertPossibleValues || Begin with AssetParamDef : "+ assetparamId.toString());
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0 ;
		try {
			if (log.isTraceEnabled()){
				log.trace("insertPossibleValues || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.INSERT_POSSIBLE_VALUES));
			pstmt.setLong(Constants.ONE, assetparamId);
			pstmt.setString(Constants.TWO,customListValues);

			if (log.isTraceEnabled()) {
				log.trace("insertPossibleValues || "+PropertyFileReader.getInstance().
						getValue(Constants.INSERT_POSSIBLE_VALUES));
			}
			result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("insertPossibleValues || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.ASSET_PARAM_DEF_NOT_UPDATED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("insertPossibleValues || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("insertPossibleValues || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("insertPossibleValues || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("insertPossibleValues || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("insertPossibleValues || End");
		}

	
	}
	public void deletePossibleValues(Long assetparamId,Connection conn){
		

		if(log.isTraceEnabled()){
			log.trace("deletePossibleValues || Begin with AssetParamDef : "+ assetparamId.toString());
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0 ;
		try {
			if (log.isTraceEnabled()){
				log.trace("deletePossibleValues || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_POSSIBLE_VALUES));
			pstmt.setLong(Constants.ONE,assetparamId);

			result = pstmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("deletePossibleValues || "+PropertyFileReader.getInstance().
						getValue(Constants.DELETE_POSSIBLE_VALUES));
			}
			
		} catch (SQLException e) {
			log.error("deletePossibleValues || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.POSSIBLE_VALUES_NOT_DELETED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("deletePossibleValues || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("deletePossibleValues || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("deletePossibleValues || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deletePossibleValues || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("deletePossibleValues || End");
		}

	
	}
	

	/**
	 * @method : addCategoryDefinition
	 * @description : to add Category
	 * @param addAsset,category
	 * @param conn
	 * @throws RepoproException
	 */
	public Long addCategoryDefinition(AssetDef addAsset,Category category, Connection conn,int displsyPosition) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("addCategoryDefintion || Begin with Category ID : "+ category.getCategoryId());
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		Long categoryId = null  ;

		try {
			if (log.isTraceEnabled()){
				log.trace("addCategoryDefintion || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_CATEGORY_DEFINITION));

			pstmt.setLong(Constants.ONE, addAsset.getAssetId());
			pstmt.setString(Constants.TWO, category.getCategoryName());
			pstmt.setInt(Constants.THREE, displsyPosition);
			pstmt.setString(Constants.FOUR, category.getDescription());

			ResultSet rs = null;

			if (log.isTraceEnabled()) {
				log.trace("addCategoryDefintion || "+PropertyFileReader.getInstance().
						getValue(Constants.ADD_CATEGORY_DEFINITION));
			}

			int result = pstmt.executeUpdate();

			rs = pstmt.getGeneratedKeys();
			if(rs != null && rs.next()){
				categoryId = 	rs.getLong(1);
			}

			if (result == 0) {
				log.warn("addCategoryDefintion || Category with id "+ categoryId+" already inserted");
			}             


		} catch (SQLException e) {
			log.error("addCategoryDefintion || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.CATEGORY_NOT_INSERTED));
		} catch (IOException e) {
			log.error("addCategoryDefintion || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addCategoryDefintion || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addCategoryDefintion || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addCategoryDefintion || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}

		if(log.isTraceEnabled()){
			log.trace("addCategoryDefinition || End");
		}
		return categoryId;
	}
	/**
	 * @method : addParameterDefinition
	 * @description : to add Parameter
	 * @param addAsset,category,parameter
	 * @param conn
	 * @throws RepoproException
	 */
	public Long addParameterDefinition(AssetDef assetdef, Long assetCategoryId,AssetParamDef  assetParamDef,Long userId,int dispPosition,Connection connection) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("addParameterDefinition || Begin with parameter ID : "+ assetCategoryId);
		}
		Connection conn=null;
		PreparedStatement pstmt = null;
		Long parameterId = null ;

		try {
			if (log.isTraceEnabled()){
				log.trace("addParameterDefinition || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(connection == null){
				conn = DBConnection.getInstance().getConnection();
				connection = conn;
			}

			pstmt = connection.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_PARAMETER_DEFINITION));

			ResultSet rs = null;

			if (log.isTraceEnabled()) {
				log.trace("addParameterDefinition || "+PropertyFileReader.getInstance().
						getValue(Constants.ADD_PARAMETER_DEFINITION));
			}
			pstmt.setLong(Constants.ONE, assetCategoryId);
			pstmt.setString(Constants.TWO, assetParamDef.getAssetParamName());
			pstmt.setString(Constants.THREE, assetParamDef.getDescription());
			pstmt.setLong(Constants.FOUR, assetParamDef.getParamTypeId());
			
			if(assetParamDef.getListTypeParamTypeId()== 0){
				pstmt.setNull(Constants.FIVE, 0);	
			}else{
				pstmt.setLong(Constants.FIVE, assetParamDef.getListTypeParamTypeId());	
			}
			if(assetParamDef.getMappedAssetId()==0){
				pstmt.setNull(Constants.SIX, 0);
			}else{
				pstmt.setLong(Constants.SIX, assetParamDef.getMappedAssetId());
			}
			pstmt.setLong(Constants.SEVEN, assetParamDef.getSize());
			pstmt.setBoolean(Constants.EIGHT, assetParamDef.isQuickLink());
			pstmt.setLong(Constants.NINE, dispPosition);
			pstmt.setBoolean(Constants.TEN, assetParamDef.isSystemParam());
			pstmt.setInt(Constants.ELEVEN, assetParamDef.getIs_static());
			pstmt.setBoolean(Constants.TWELVE, assetParamDef.isHasImportantValue());
			pstmt.setInt(Constants.THIRTEEN, assetParamDef.getDefaultView());
			pstmt.setString(Constants.FOURTEEN, assetParamDef.getStaticValue());
			pstmt.setBytes(Constants.FIFTEEN, assetParamDef.getStaticFileContent());
			pstmt.setString(Constants.SIXTEEN, assetParamDef.getFileName());
			pstmt.setString(Constants.SEVENTEEN, assetParamDef.getMimetype());
			pstmt.setTimestamp(Constants.EIGHTEEN, assetParamDef.getLastUpdatedTime());
			pstmt.setLong(Constants.NINETEEN, assetParamDef.getModifyByUserId());	
			pstmt.setString(Constants.TWENTY, assetParamDef.getDerivedAttributeComputation());
			pstmt.setBoolean(Constants.TWENTYONE, assetParamDef.isHasMandatoryValue());
			pstmt.setInt(Constants.TWENTYTWO, assetParamDef.getHasArray());
			pstmt.setInt(Constants.TWENTYTHREE, assetParamDef.getListType());
			pstmt.setInt(Constants.TWENTYFOUR, assetParamDef.getLdapMappingId());
			pstmt.setString(Constants.TWENTYFIVE, assetParamDef.getDerivedAssetListRule());
			pstmt.setBoolean(Constants.TWENTYSIX, assetParamDef.isNotifyOnRuleValidate());
			
			int result = 0;
			result = pstmt.executeUpdate();
			rs = pstmt.getGeneratedKeys();
			if(rs != null && rs.next()){
				parameterId = rs.getLong(1);
			}

			if (result == 0) {
				log.warn("addParameterDefinition || Parameter with id "+ assetParamDef.getAssetParamId()+" already inserted");
			}

		} catch (SQLException e) {
			log.error("addParameterDefinition || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_NOT_INSERTED));
		} catch (IOException e) {
			log.error("addParameterDefinition || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addParameterDefinition || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addParameterDefinition || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addParameterDefinition || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
			try {
				if(pstmt != null){
					pstmt.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}

		if(log.isTraceEnabled()){
			log.trace("addParameterDefinition || End");
		}
		return parameterId;
	}
	/**
	 * @method : updateAsset
	 * @description : to update an asset
	 * @param updateAsset
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateCategoryDetails(AssetDef updateAsset,Category category,int categorydisplayPosition, Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("updateCategoryDetails || "+ category.toString() +" Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateCategoryDetails || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_CATEGORY_DETAILS));

			pstmt.setLong(Constants.ONE, updateAsset.getAssetId());
			pstmt.setString(Constants.TWO, category.getCategoryName());
			pstmt.setString(Constants.THREE, "dfdfdcd");
			pstmt.setInt(Constants.FOUR, categorydisplayPosition);
			pstmt.setLong(Constants.FIVE, category.getCategoryId());
			if (log.isTraceEnabled()) {
				log.trace("updateCategoryDetails || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_CATEGORY_DETAILS));
			}
			int result = pstmt.executeUpdate();
			if (result == 0) {
				log.warn("Update Asset Category || Asset Category is not updated and throws RepoproException");
			}
		} catch (SQLException e) {
			log.error("updateCategoryDetails || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_CATEGORY_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateCategoryDetails || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateCategoryDetails || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("updateCategoryDetails || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateCategoryDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("updateCategoryDetails || End");
		}

	}


	/**
	 * @method : updateParamDefRule
	 * @description : to update derived type value
	 * @param updateRule
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateParamDefRule(AssetParamDef assetParamDef, Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("updateParamDefRule || "+ assetParamDef.toString() +" Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateParamDefRule || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE));

			pstmt.setString(Constants.ONE, assetParamDef.getDerivedAttributeComputation());
			pstmt.setLong(Constants.TWO, assetParamDef.getAssetParamId());


			if (log.isTraceEnabled()) {
				log.trace("updateParamDefRule || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE));
			}

			int result = pstmt.executeUpdate();
			if (result == 0) {
				log.warn("updateParamDefRule || updateParamDefRule is not updated and throws RepoproException");
			}


		} catch (SQLException e ) {
			log.error("updateParamDefRule || " + Constants.LOG_UPDATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateParamDefRule || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateParamDefRule || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("updateParamDefRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateParamDefRule || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("updateParamDefRule || End");
		}

	}

	/**
	 * @method addCategoryWiseAccessForGroups
	 * @param categoryId
	 * @param groupIdAndGroupName
	 * @param conn
	 */
	@SuppressWarnings({ "resource", "rawtypes" })
	public void addCategoryWiseAccessForGroups(Long categoryId,Map<Long,String> groupIdAndGroupName,Connection conn){

		if(log.isTraceEnabled()){
			log.trace("addCategoryWiseAccessForGroups || Begin with categoryId : "+ categoryId);
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		try {
			if(log.isTraceEnabled()){
				log.trace("addCategoryWiseAccessForGroups || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_CATEGORY_WISE_ACCESS_FOR_GROUP_BY_CATEGORY_ID));
			pstmt.setLong(Constants.ONE, categoryId);

			if (log.isTraceEnabled()) {
				log.trace("addCategoryWiseAccessForGroups || "+PropertyFileReader.getInstance().getValue(Constants.DELETE_CATEGORY_WISE_ACCESS_FOR_GROUP_BY_CATEGORY_ID));
			}
			int result = pstmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("addCategoryWiseAccessForGroups || "+PropertyFileReader.getInstance().getValue(Constants.ADD_CATEGORY_WISE_ACCESS_FOR_GROUPS_BY_CATEGORY_ID));
			}

			pstmt1 = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.ADD_CATEGORY_WISE_ACCESS_FOR_GROUPS_BY_CATEGORY_ID));
			pstmt1.setLong(Constants.ONE, categoryId);

			Iterator<Entry<Long, String>> it = groupIdAndGroupName.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pair = (Map.Entry)it.next();
				Long groupId = Long.parseLong(pair.getKey().toString());
				Long editaccess = Long.parseLong(pair.getValue().toString());
				//String groupName=pair.getValue().toString();
				pstmt1.setLong(Constants.ONE, categoryId);
				pstmt1.setLong(Constants.TWO, groupId);
				//pstmt1.setLong(Constants.THREE, 1L);// if entry is happening then by default , view will be there.
				pstmt1.setLong(Constants.THREE, editaccess);
				pstmt1.executeUpdate();
			}


			if(log.isDebugEnabled()){
				log.debug("addCategoryWiseAccessForGroups "+groupIdAndGroupName);
			}

		} catch (SQLException e) {
			log.error("addCategoryWiseAccessForGroups || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.CATEGORY_WISE_ACCESS_NOT_ADDED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("addCategoryWiseAccessForGroups || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("addCategoryWiseAccessForGroups || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("addCategoryWiseAccessForGroups || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			DBConnection.closePreparedStatement(pstmt1);
			if (log.isTraceEnabled()) {
				log.trace("addCategoryWiseAccessForGroups || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("addCategoryWiseAccessForGroups || End");
		}
	}
	/**
	 * @method : deleteParameter
	 * @description : to delete an Parameter
	 * @param assetParameterId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<String> deleteParameter1(Long assetParameterId, Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("deleteParameter || Begin with deleteParameter : "+ assetParameterId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		List<String> msg = new ArrayList<String>();

		try {
			if (log.isTraceEnabled()){
				log.trace("deleteParameter || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_PARAMETER));

			pstmt.setLong(Constants.ONE, assetParameterId);

			if (log.isTraceEnabled()) {
				log.trace("deleteParameter || "+PropertyFileReader.getInstance().
						getValue(Constants.DELETE_PARAMETER));
			}

			int result = pstmt.executeUpdate();

			if (result == 0) {
				log.warn("deleteParameter || Parameter with id "+ assetParameterId +" already deleted ");
				msg.add("Parameter with "+ assetParameterId +" already deleted");
			}


		} catch (SQLException e) {
			log.error("deleteParameter || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteParameter || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteParameter || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteParameter || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteParameter || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("deleteCategory || End");
		}
		return msg;
	}
	/**
	 * @method addCategory
	 * @param category
	 * @param assetId
	 * @param conn
	 * @return Long
	 */
	public Long addCategory(Category category,Long assetId,Connection conn){

		if(log.isTraceEnabled()){
			log.trace("addCategory || Begin with Category : "+ category.toString());
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long assetCategoryId = null ;
		try {
			if (log.isTraceEnabled()){
				log.trace("addCategory || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.ADD_ASSET_CATEGORY_DEF));
			pstmt.setString(2,category.getCategoryName());
			pstmt.setString(3,category.getDescription());
			pstmt.setInt(4, category.getDisp_position());
			pstmt.setLong(1, assetId);
			pstmt.execute();
			rs = pstmt.getGeneratedKeys();

			if (rs != null && rs.next()) {
				assetCategoryId = rs.getLong(1);
			}


			if (log.isTraceEnabled()) {
				log.trace("addCategory || "+PropertyFileReader.getInstance().
						getValue(Constants.ADD_ASSET_CATEGORY_DEF));
			}
			log.error("Category successfully Added ");
		} catch (SQLException e) {
			log.error("addCategory || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.ASSET_CATEGORY_DEF_NOT_ADDED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("addCategory || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("addCategory || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("addCategory || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addCategory || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("addCategory || End");
		}
		return assetCategoryId;
	}
	/**
	 * @method updateCategory
	 * @param category
	 * @param assetId
	 * @param conn
	 * @return Long
	 */
	public Long updateCategory(Category category,Long assetId,Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("updateCategory || Begin with Category : "+ category.toString()+" assetId:"+assetId);
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Long assetCategoryId = null ;
		try {
			if (log.isTraceEnabled()){
				log.trace("updateCategory || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_ASSET_CATEGORY_DEF));

			pstmt.setString(1,category.getCategoryName());
			pstmt.setString(2,category.getDescription());
			pstmt.setInt(3, category.getDisp_position());
			pstmt.setLong(4, assetId);
			pstmt.setLong(5, category.getCategoryId());

			pstmt.executeUpdate();

			rs = pstmt.getGeneratedKeys();

			if (rs != null && rs.next()) {
				assetCategoryId = rs.getLong(1);
			}


			if (log.isTraceEnabled()) {
				log.trace("updateCategory || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_ASSET_CATEGORY_DEF));
			}

		} catch (SQLException e) {
			log.error("updateCategory || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_CATEGORY_DEF_NOT_UPDATED));

		} catch (IOException e) {
			log.error("updateCategory || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("updateCategory || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			log.error("updateCategory || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateCategory || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("updateCategory || End");
		}
		return assetCategoryId;
	}

	/**
	 * @method addParameter
	 * @param adf
	 * @param conn
	 * @return int
	 */
	public int addParameter(AssetParamDef adf,Connection conn){

		if(log.isTraceEnabled()){
			log.trace("addParameter || Begin with AssetParamDef : "+ adf.toString());
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0 ;
		ResultSet rs = null;
		try {
			if (log.isTraceEnabled()){
				log.trace("addParameter || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.ADD_PARAMETER));
			pstmt.setLong(Constants.ONE, adf.getAssetCategoryId());
			pstmt.setString(Constants.TWO, adf.getAssetParamName());
			pstmt.setString(Constants.THREE,adf.getDescription());
			pstmt.setLong(Constants.FOUR,adf.getParamTypeId());

			if(adf.getListTypeParamTypeId()==0){
				pstmt.setNull(Constants.FIVE,0);
			}else{
				pstmt.setLong(Constants.FIVE,adf.getListTypeParamTypeId());
				
				
			}

			if(adf.getMappedAssetId()==0){
				pstmt.setNull(Constants.SIX, 0);
			}else{
				pstmt.setLong(Constants.SIX, adf.getMappedAssetId());
			}

			pstmt.setInt(Constants.SEVEN, adf.getSize());
			pstmt.setBoolean(Constants.EIGHT, adf.isQuickLink());
			pstmt.setInt(Constants.NINE,adf.getDisplayPosition());
			if(adf.isSystemParam()){
				pstmt.setInt(Constants.TEN, 1);	
			}else{
				pstmt.setInt(Constants.TEN, 0);
			}
			
			
			pstmt.setInt(Constants.ELEVEN, adf.getIs_static());
			
			if(adf.isHasImportantValue()){
				pstmt.setInt(Constants.TWELVE, 1);
			}else{
				pstmt.setInt(Constants.TWELVE, 0);
			}
			
			if(adf.getDefaultView()==1){
				pstmt.setInt(Constants.THIRTEEN, 1);
				
			}else{
				pstmt.setInt(Constants.THIRTEEN, 0);
			}
			
			pstmt.setString(Constants.FOURTEEN, adf.getStaticValue());
			pstmt.setBytes(Constants.FIFTEEN,adf.getStaticFileContent());
			pstmt.setString(Constants.SIXTEEN, adf.getFileName());
			pstmt.setString(Constants.SEVENTEEN,adf.getMimetype());
			pstmt.setTimestamp(Constants.EIGHTEEN,adf.getLastUpdatedTime());
			pstmt.setString(Constants.NINETEEN,adf.getDerivedAttributeComputation());
			if(adf.isHasMandatoryValue()){
				pstmt.setInt(Constants.TWENTY, 1);
			}else{
				pstmt.setInt(Constants.TWENTY, 0);
			}
			pstmt.setInt(Constants.TWENTYONE,adf.getHasArray());
			pstmt.setInt(Constants.TWENTYTWO, adf.getListType());
			pstmt.setInt(Constants.TWENTYTHREE, adf.getLdapMappingId());
			pstmt.setString(Constants.TWENTYFOUR, adf.getDerivedAssetListRule());
			if(adf.isNotifyOnRuleValidate()){
				pstmt.setInt(Constants.TWENTYFIVE, 1);
			}else{
				pstmt.setInt(Constants.TWENTYFIVE, 0);
			}
			 pstmt.executeUpdate();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				result = (int) rs.getLong(1);
				
			}
			
			if (log.isTraceEnabled()) {
				log.trace("addParameter || "+PropertyFileReader.getInstance().
						getValue(Constants.ADD_PARAMETER));
			}


		} catch (SQLException e) {
			log.error("addParameter || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.ASSET_PARAM_DEF_NOT_CREATED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("addParameter || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("addParameter || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("addParameter || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addParameter || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("addParameter || End");
		}

		return result;


	}

	/**
	 * @method getAssetParamDefByAssetParamId
	 * @param assetParameterId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetParamDef getAssetParamDefByAssetParamId(Long assetParameterId,Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getAssetParamDefByAssetParamId || "+ assetParameterId.toString() +" Begin");
		}
		AssetParamDef assetParamDef = new AssetParamDef();
		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDefByAssetParamId || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ASSET_PARAM_DEF_BY_ASSET_PARAM_ID));


			pstmt.setLong(Constants.ONE,assetParameterId);

			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDefByAssetParamId || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ASSET_PARAM_DEF_BY_ASSET_PARAM_ID));
			}

			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
				assetParamDef.setAssetParamId(result.getLong("asset_param_id"));
				assetParamDef.setAssetParamName(result.getString("asset_param_name"));
				assetParamDef.setDerivedAttributeComputation(result.getString("derived_computed_description"));
				assetParamDef.setDescription(result.getString("description"));
				assetParamDef.setIs_static(result.getInt("is_static"));
				assetParamDef.setParamTypeId(result.getLong("param_type_id"));
				assetParamDef.setListTypeParamTypeId(result.getLong("list_param_type_id"));
			}


		} catch (SQLException e) {
			log.error("getAssetParamDefByAssetParamId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_ASSET_PARAM_DEF_BY_ASSET_PARAM_ID_NOT_SELECTED));
		} catch (IOException e) {
			log.error("getAssetParamDefByAssetParamId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetParamDefByAssetParamId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAssetParamDefByAssetParamId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamDefByAssetParamId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("getAssetParamDefByAssetParamId || End");
		}
		return assetParamDef;
	}
	/**
	 * @method deleteParameter
	 * @param assetParameterID
	 * @param conn
	 * @return int
	 */
	public int deleteParameter(Long assetParameterID,Connection conn) {

		if(log.isTraceEnabled()){
			log.trace("deleteParameter || Begin with assetParameterID : "+ assetParameterID);
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0 ;
		try {
			if (log.isTraceEnabled()){
				log.trace("deleteParameter || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_PARAMETER_BY_PARAMETER_ID));
			pstmt.setLong(Constants.ONE, assetParameterID);

			if (log.isTraceEnabled()) {
				log.trace("deleteParameter || "+PropertyFileReader.getInstance().
						getValue(Constants.DELETE_PARAMETER_BY_PARAMETER_ID));
			}
			result = pstmt.executeUpdate();
			log.info("Parameter Successfully Deleted" );
		} catch (SQLException e) {
			log.error("deleteParameter || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.ASSET_PARAM_DEF_NOT_DELETED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("deleteParameter || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("deleteParameter || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("deleteParameter || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteParameter || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("deleteParameter || End");
		}

		return result;
	}
	/**
	 * @method modifingRuleById
	 * @param assetParamId
	 * @param rule
	 * @param conn
	 * @return int
	 */
	public int modifingRuleById(Long assetParamId,String rule,Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("modifingRuleById|| Begin with assetParamId : "+ assetParamId);
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			if (log.isTraceEnabled()){
				log.trace("modifingRuleById || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE));

			pstmt.setString(1,rule);
			pstmt.setLong(2, assetParamId);
			result = pstmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("modifingRuleById || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE));
			}

			log.info("Successfully modified the derived attribute rule");
		} catch (SQLException e) {
			log.error("modifingRuleById || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE_NOT_UPDATED));

		} catch (IOException e) {
			log.error("modifingRuleById || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("modifingRuleById || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			log.error("modifingRuleById || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("modifingRuleById || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if(log.isTraceEnabled()){
			log.trace("modifingRuleById || End");
		}
		return result;
	}

	/**
	 * @method : getPossibleValuesForAsset
	 * @param assetId
	 * @param assetParamId
	 * @param conn
	 * @return list of PossibleValues
	 */
	public List<PossibleValues> getPossibleValuesForAsset(long assetId,long assetParamId,Connection conn) throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("getPossibleValuesForAsset ||   begin with assetId : "+assetId +",assetParamId : "+assetParamId);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		PossibleValues posVal = null;
		List<PossibleValues> possibleValues = new ArrayList<PossibleValues>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForAsset ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_POSSIBLE_VALUES));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_POSSIBLE_VALUES));

			preparedStmt.setLong(1, assetId);
			preparedStmt.setLong(2, assetParamId);

			rs = preparedStmt.executeQuery();

			while (rs.next()) {
				posVal = new PossibleValues();
				posVal.setValueId(rs.getLong("value_id"));
				posVal.setAssetParamId(rs.getLong("asset_param_id"));
				posVal.setValue(rs.getString("value"));
				posVal.setIconImageName(rs.getString("icon_image_name"));
				posVal.setListType(rs.getInt("list_type"));
				possibleValues.add(posVal);
			}

			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForAsset ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForAsset ||"+ PropertyFileReader.getInstance().getValue(Constants.GET_ASSET_PARAM_DEF_BY_ASSET_NAME_AND_ASSET_PARAM_NAME));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getPossibleValuesForAsset ||"
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_ASSET_PARAM_DEF_IN_ASSET_PARAM_NAME));

		} catch (IOException e) {
			log.error("getPossibleValuesForAsset ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("getPossibleValuesForAsset ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			log.error("getPossibleValuesForAsset ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isDebugEnabled()) {
			log.debug("getPossibleValuesForAsset || exit");
		}
		return possibleValues;
	}

	/**
	 * @method : getCategoriesByassetId
	 * @description : to get categories
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<Category> getCategoriesByassetId(Long assetId,Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getCategoriesByassetId || Begin with assetId : "+ assetId);
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Category> listCat = new ArrayList<Category>();
		Category c = null;
		try {
			if (log.isTraceEnabled()){
				log.trace("getCategoriesByassetId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_CATEGORIES_BY_ASSET_ID));


			if (log.isTraceEnabled()) {
				log.trace("getCategoriesByassetId || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_CATEGORIES_BY_ASSET_ID));
			}
			pstmt.setLong(Constants.ONE, assetId);
			rs =  pstmt.executeQuery();

			while(rs.next()){
				c = new Category();
				c.setAssetId(rs.getLong("asset_id"));
				c.setCategoryId(rs.getLong("asset_category_id"));
				c.setCategoryName(rs.getString("asset_category_name"));
				c.setDisp_position(rs.getInt("disp_position"));
				listCat.add(c);
			}

		} catch (SQLException e) {
			log.error("getCategoriesByassetId || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.NO_CATEGORIES_BY_FOR_ASSET_ID));
		} catch (IOException e) {
			log.error("getCategoriesByassetId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getCategoriesByassetId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getCategoriesByassetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getCategoriesByassetId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("getCategoriesByassetId || End");
		}
		return listCat;
	}


	/**
	 * @method : getCheckedGroupDetailsByAssetIdWithCategories
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public Map<Long,String> getCheckedGroupDetailsByAssetIdWithCategories(Long assetId,Connection conn)throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("getCheckedGroupDetailsByAssetIdWithCategories || begin with assetId : "
					+ assetId);
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		Map<Long,String> map = new LinkedHashMap<Long, String>();

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getCheckedGroupDetailsByAssetIdWithCategories || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_CHECKED_GROUP_DETAILS_BY_ASSET_ID));

			preparedStmt.setLong(Constants.ONE, assetId);

			resultSet = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getCheckedGroupDetailsByAssetIdWithCategories || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_CHECKED_GROUP_DETAILS_BY_ASSET_ID));
			}

			while (resultSet.next()) {
				String categoryName = resultSet.getString("asset_category_name");
				Long categoryId = resultSet.getLong("asset_category_id");
				String groupName = resultSet.getString("group_name");
				if(!map.containsKey(categoryId)){
					map.put(categoryId, categoryName);
				}

				if (log.isTraceEnabled()) {
					log.trace("getCheckedGroupDetailsByAssetIdWithCategories || map : " + map.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getCheckedGroupDetailsByAssetIdWithCategories || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GROUP_DATA_NOT_FOUND));

		} catch (IOException e) {
			log.error("getCheckedGroupDetailsByAssetIdWithCategories || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("getCheckedGroupDetailsByAssetIdWithCategories || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			e.printStackTrace();
			log.error("getCheckedGroupDetailsByAssetIdWithCategories ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getCheckedGroupDetailsByAssetId || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getCheckedGroupDetailsByAssetIdWithCategories || exit");

		return map;

	}

	/**
	 * @method : updateParameterValues
	 * @param pv
	 * @param conn
	 * @throws RepoproException
	 */
	public void updateParameterValues(ParameterValues pv, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateParameterValues || " +pv.toString()+ "Begin" );
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateParameterValues || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.UPDATE_PARAMETER_VALUES));

			pstmt.setString(Constants.ONE, pv.getValue());
			pstmt.setBinaryStream(Constants.TWO, pv.getImage());
			pstmt.setString(Constants.THREE,pv.getFileName());
			pstmt.setString(Constants.FOUR,pv.getMimeType());
			pstmt.setLong(Constants.FIVE,pv.getParameterValuesId());
			pstmt.setLong(Constants.SIX,pv.getAssetInstParamId());


			if (log.isTraceEnabled()) {
				log.trace("updateParameterValues || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_PARAMETER_VALUES));
			}

			int result = pstmt.executeUpdate();
			
			if (result == 0) {
				log.warn("updateParameterValues || AssetParamDef is not updated and throws RepoproException");
			}

		} catch (SQLException e) {
			log.error("updateParameterValues || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_VALUES_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateParameterValues || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateParameterValues || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateParameterValues || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateParameterValues || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateParameterValues ||" +pv.toString() + " End");
		}
	}


	/**
	 * @method : getAllAssetNames
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetDef> getAllAssetNames(String userName, Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("getAllAssetNames || Begin with userName : "+ userName);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<AssetDef> assetList = new ArrayList<AssetDef>();
		AssetDef assetDef = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetNames || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if(userName.equalsIgnoreCase("roleAnonymous")){
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_ASSET_NAMES_FOR_GUEST));

				if (log.isTraceEnabled()) {
					log.trace("getAllAssetNames || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_ASSET_NAMES_FOR_GUEST));
				}


			}else{
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_ASSET_NAMES));

				if (log.isTraceEnabled()) {
					log.trace("getAllAssetNames || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_ASSET_NAMES));
				}

			}

			rs = pstmt.executeQuery();
			while(rs.next()){
				assetDef = new AssetDef();
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setAssetName(rs.getString("asset_name"));
				assetDef.setDescription(rs.getString("description"));
				assetDef.setIconImage(rs.getBinaryStream("icon_image"));
				assetDef.setSystemAsset(rs.getBoolean("is_system_asset"));
				assetDef.setVersionable(rs.getBoolean("versionable"));
				assetDef.setIconImageName(rs.getString("icon_image_name"));
				assetDef.setParentAssetId(rs.getLong("parent_asset_id"));
				assetDef.setRatingDescription(rs.getString("rating_description"));
				assetDef.setGuestflag(rs.getBoolean("guest_flag"));
				assetDef.setQuicksearchflag(rs.getBoolean("quick_search_flag"));
				assetList.add(assetDef);

				if (log.isTraceEnabled()) {
					log.trace("getAllAssetNames || "+ assetDef.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetNames || "+ assetList.toString());
			}


		} catch (SQLException e) {
			log.error("getAllAssetNames || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_VALUES_NOT_UPDATED));
		} catch (IOException e) {
			log.error("getAllAssetNames || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetNames || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetNames || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetNames || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return assetList;
	}


	/**
	 * @method : retInstParam
	 * @param assetParamId
	 * @param assetInstVerId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetInstParams retInstParam(Long assetParamId ,Long assetInstVerId,Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("retInstParam || assetParamId:" + assetParamId+ "and assetParamId:"+assetInstVerId
					+ " || begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		AssetInstParams assetinstparams = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("retInstParam || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedSt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_INST_PARAM_BY_PARAM_ID_AND_VERSION_ID));
			if (log.isTraceEnabled()) {
				log.trace("retInstParam || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_INST_PARAM_BY_PARAM_ID_AND_VERSION_ID));
			}
			preparedSt.setLong(Constants.ONE, assetInstVerId);
			preparedSt.setLong(Constants.TWO, assetParamId);


			rs = preparedSt.executeQuery();

			if(!rs.next()){
				assetinstparams = new AssetInstParams();
				assetinstparams.setAssetInstParamId(null);

			}else{
				assetinstparams = new AssetInstParams();
				assetinstparams.setAssetInstParamId(rs.getLong("asset_inst_param_id"));
				assetinstparams.setAssetInstVersionId(assetInstVerId);
				assetinstparams.setAssetParamId(assetParamId);
			}

			if (log.isTraceEnabled()) {
				log.trace("retInstParam || " + assetinstparams.toString());
			}

		} catch (SQLException e) {
			log.error("retInstParam ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_ASSET_INST_PARAM_BY_PARAM_ID_AND_VERSION_ID_NOT_FETCHED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("retInstParam ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("retInstParam ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("retInstParam ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("retInstParam ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("retInstParam ||  assetParamId:" + assetParamId+ "and assetInstVerId:"+assetInstVerId
					+ " ||exit");
		}
		return assetinstparams;
	}



	/**
	 * @method : updateAssetInstParam
	 * @param assetInstParams
	 * @return
	 * @throws RepoproException
	 */
	public void updateAssetInstParam(AssetInstParams assetInstParams,
			Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstParam || " +assetInstParams.toString()+ "Begin" );
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstParam || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.UPDATE_ASSET_INST_PARAM));

			pstmt.setLong(Constants.ONE, assetInstParams.getAssetInstVersionId());
			pstmt.setLong(Constants.TWO,assetInstParams.getAssetParamId());
			pstmt.setTimestamp(Constants.THREE,assetInstParams.getLastUpdatedTime());
			pstmt.setLong(Constants.FOUR,assetInstParams.getModifyByUserId());
			pstmt.setLong(Constants.FIVE, assetInstParams.getAssetInstParamId());

			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstParam || "
						+ PropertyFileReader.getInstance().getValue(Constants.UPDATE_ASSET_INST_PARAM));
			}

			int result = pstmt.executeUpdate();
			
			if (result == 0) {
				log.warn("updateAssetInstParam || assetInstParams is not updated and throws RepoproException");
			}

		} catch (SQLException e) {
			log.error("updateAssetInstParam || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UPDATE_ASSET_INST_PARAM_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateAssetInstParam || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateAssetInstParam || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateAssetInstParam || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateAssetInstParam || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("updateAssetInstParam ||" +assetInstParams.toString() + " End");
		}



	}

	@SuppressWarnings("resource")
	public AssetDef getAsset(Long assetId,Connection conn) throws RepoproException{
		AssetDef def = null;	

		if (log.isTraceEnabled()) {
			log.trace("getAsset || " +assetId.toString()+ "Begin" );
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			
			if (log.isTraceEnabled()) {
				log.trace("getAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			conn.setAutoCommit(false);
			AssetDao dao = new AssetDao();
			if (log.isTraceEnabled()) {
				log.trace("getAsset || dao method called : getAssetDefByAssetId()");
			}
			def = dao.getAssetsByAssetId(assetId, conn);

			if (log.isTraceEnabled()) {
				log.trace("getAsset || dao method called : getCategoryByAssetID() :"+assetId);
			}
			List<Category> listOfCategories = dao.getCategoryByAssetID(assetId, conn);
			for(int i=0;i<listOfCategories.size();i++){
				Category category = listOfCategories.get(i);
				Long catgoryId = category.getCategoryId();
				if (log.isTraceEnabled()) {
					log.trace("getAsset || dao method called : getAssetParameterDefsByCategoryID() :"+catgoryId);
				}
				List<AssetParamDef> listOfParamDefs = dao.getAssetParameterDefsByCategoryID(catgoryId, conn);
				for (int j = 0; j <listOfParamDefs.size(); j++) {
					AssetParamDef assetParamDef = listOfParamDefs.get(j);

					assetParamDef.setAssetCategoryId(catgoryId);
					String paramName = assetParamDef.getAssetParamName();
					if (log.isTraceEnabled()) {
						log.trace("getAsset || dao method called : getAllDerivedAttributes()");
					}
					List<AssetParamDef> derivedAttributes =  dao.getAllDerivedAttributes(conn);
					Pattern patternForDerivedAttribute = Pattern.compile(def.getAssetName()+"[\\{](?i)"+paramName+"[\\}]");
					Pattern patternForDerivedComputation = Pattern.compile(def.getAssetName()+"[\\.](?i)"+paramName+"(==)");
					for (AssetParamDef assetParamDef2 : derivedAttributes) {
						String rule = assetParamDef2.getDerivedAttributeComputation();
						if(assetParamDef2.getParamTypeId()==Constants.DERIVED_ATTRIBUTE_PARAMETER_TYPE_ID){

							Matcher m = patternForDerivedAttribute.matcher(rule);
							if(m.find()){
								category.setFlagForCategoryRuleUsage(true);
								def.setFlagForAssetUsageInRule(true);
								assetParamDef.setFlagForParameterUsageInRule(true);
							}
						}
						if(assetParamDef2.getParamTypeId()==Constants.DERIVED_COMPUTATION_PARAMETER_TYPE_ID){
							Matcher m = patternForDerivedComputation.matcher(rule);
							if(m.find()){
								assetParamDef.setFlagForParameterUsageInRule(true);
							}
						}
					}
					listOfParamDefs.set(j, assetParamDef);

					for(int jj=0;jj<derivedAttributes.size();jj++){

						AssetParamDef apd = derivedAttributes.get(jj);
						String rule = apd.getDerivedAttributeComputation();

						Pattern assetPattern1 = Pattern.compile("[\\]]"+def.getAssetName()+"[\\{]");
						Matcher m1 = assetPattern1.matcher(rule);
						if(m1.find()){
							def.setFlagForAssetUsageInRule(true);
						}

						Pattern assetPattern2 = Pattern.compile("[\\]]"+def.getAssetName()+"[\\[]");
						Matcher m2 = assetPattern2.matcher(rule);
						if(m2.find()){
							def.setFlagForAssetUsageInRule(true);
						}
					}
				}
				category.setListOfAssetParamDefs(listOfParamDefs);
				listOfCategories.set(i, category);
			}
			def.setCategories(listOfCategories);
		}catch (SQLException e) {
			log.error("getAsset || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UPDATE_ASSET_INST_PARAM_NOT_UPDATED));
		} catch (IOException e) {
			log.error("getAsset || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAsset || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAsset || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAsset ||" +def.toString() + " End");
		}
		return def;
	}
	/**
	 * @method : getFileNameByAssetId
	 * @param assetId
	 * @param conn
	 */
	public AssetDef getFileNameByAssetId(long assetId,Connection conn) throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("getFileNameByAssetId ||   begin with assetId : ");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetDef ad = null;
		try {
			if (conn == null) {
				if (log.isTraceEnabled()) {
					log.trace("getFileNameByAssetId ||"
							+ Constants.LOG_CONNECTION_OPEN);
				}
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getFileNameByAssetId ||"+ PropertyFileReader.getInstance().getValue(Constants.SELECT_FILENAME_BY_ASSET_ID));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.SELECT_FILENAME_BY_ASSET_ID));

			preparedStmt.setLong(Constants.ONE, assetId);

			rs = preparedStmt.executeQuery();

			while (rs.next()) {
				ad = new AssetDef();
				ad.setIconImageName(rs.getString("icon_image_name"));
				ad.setIconImage(rs.getBinaryStream("icon_image"));
			}

			

			if (log.isTraceEnabled()) {
				log.trace("getFileNameByAssetId ||"+ PropertyFileReader.getInstance().getValue(Constants.SELECT_FILENAME_BY_ASSET_ID));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getFileNameByAssetId ||"
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NO_FILE_NAME_SELECTED));

		} catch (IOException e) {
			log.error("getFileNameByAssetId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("getFileNameByAssetId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			log.error("getFileNameByAssetId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isDebugEnabled()) {
			log.debug("getFileNameByAssetId || exit");
		}
		return ad;
	}

	/**
	 * @method : getCategoryNameAndParametersByAssetId
	 * @param assetId
	 * @param conn
	 */
	public List<AssetParamDef> getCategoryNameAndParametersByAssetId(long assetId,Connection conn) throws RepoproException{

		if (log.isTraceEnabled()) {
			log.trace("getCategoryNameAndParametersByAssetId ||   begin with assetId : ");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		AssetParamDef apd = null;
		List<AssetParamDef> listOfParamDefs  =new ArrayList<AssetParamDef>();
		String fileName = "";
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getCategoryNameAndParametersByAssetId ||"+ PropertyFileReader.getInstance().getValue(Constants.GetCategoriesAndParamsByAssetId));
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GetCategoriesAndParamsByAssetId));

			preparedStmt.setLong(1, assetId);

			rs = preparedStmt.executeQuery();
			while (rs.next()) {
				apd = new AssetParamDef();
				apd.setLdapMappingId(rs.getInt("ldap_mapping_id"));
				apd.setAssetParamName(rs.getString("paramName"));
				apd.setAssetParamId(rs.getLong("paramId"));
				apd.setAssetCategoryName(rs.getString("catName"));
				apd.setAssetCategoryId(rs.getLong("catId"));
				apd.setMappedAssetId(rs.getLong("mapped_asset_id"));
				apd.setParamTypeId(rs.getLong("param_type_id"));
				apd.setListTypeParamTypeId(rs.getLong("list_param_type_id"));
				apd.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				apd.setSize(rs.getInt("size"));
				apd.setAssetParamId(rs.getLong("asset_param_id"));
				apd.setHasStaticValue(rs.getBoolean("is_static"));
				apd.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				apd.setHasArray(rs.getInt("isArray"));
				apd.setListType(rs.getInt("LIST_TYPE"));
				apd.setLdapMappingId(rs.getInt("ldap_mapping_id"));
				
				listOfParamDefs.add(apd);
			}

			if (log.isTraceEnabled()) {
				log.trace("getCategoryNameAndParametersByAssetId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (log.isTraceEnabled()) {
				log.trace("getCategoryNameAndParametersByAssetId ||"+ PropertyFileReader.getInstance().getValue(Constants.GetCategoriesAndParamsByAssetId));
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getCategoryNameAndParametersByAssetId ||"
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.NOT_GetCategoriesAndParamsByAssetId));

		} catch (IOException e) {
			log.error("getCategoryNameAndParametersByAssetId ||"
					+ Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("getCategoryNameAndParametersByAssetId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			log.error("getCategoryNameAndParametersByAssetId ||"
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace(Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isDebugEnabled()) {
			log.debug("getCategoryNameAndParametersByAssetId || exit");
		}
		return listOfParamDefs;
	}
	
	
	/**
	 * @method : enableOrdisableAssetVersionBasedonAssetRelation
	 * @param assetName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public boolean enableOrdisableAssetVersionBasedonAssetRelation(String assetName, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("enableOrdisableAssetVersionBasedonAssetRelation || Begin with assetName : "+ assetName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		boolean val = false;
		
		RelationshipDao rdao = new RelationshipDao();
		List<String> assetNameList = new ArrayList<String>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("enableOrdisableAssetVersionBasedonAssetRelation || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if(log.isTraceEnabled()){
				log.trace("enableOrdisableAssetVersionBasedonAssetRelation || dao method called : "
						+ "retAllAssetRelationshipDefsForAggregationAndCompositionType()");
			}
			List<AssetRelationshipDef> ardList = rdao.retAllAssetRelationshipDefsForAggregationAndCompositionType(conn);
			
			if (!ardList.isEmpty()) {
				for (AssetRelationshipDef ard : ardList) {
					assetNameList.add(ard.getSrcAssetName());
					assetNameList.add(ard.getDestAssetName());
				}

				for (String assetName1 : assetNameList) {
					if (assetName1.equalsIgnoreCase(assetName)) {
						val = true;
						break;
					} else {
						val = getAllAssetInstancesForassetName(assetName, conn);
					}
				}

				return val;
			} else {
				return getAllAssetInstancesForassetName(assetName, conn);
			}
			
			
		} catch (SQLException e) {
			log.error("enableOrdisableAssetVersionBasedonAssetRelation || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.NO_RELATIONSHIP_DATA_FOUND));
		} catch (IOException e) {
			log.error("enableOrdisableAssetVersionBasedonAssetRelation || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("enableOrdisableAssetVersionBasedonAssetRelation || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("enableOrdisableAssetVersionBasedonAssetRelation || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("enableOrdisableAssetVersionBasedonAssetRelation || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
	}
	
	
	/**
	 * @method : getAllAssetInstancesForassetName
	 * @param assetName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public boolean getAllAssetInstancesForassetName(String assetName, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesForassetName || Begin with assetName : "+ assetName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetInstanceVersion aiv = null;
		List<AssetInstanceVersion> aivs = new ArrayList<AssetInstanceVersion>();
		
		List<Long> assetInstIds = new ArrayList<Long>();
		Set<Long> setToReturn = new HashSet<Long>();
		Set<Long> set1 = new HashSet<Long>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllAssetInstancesForassetName || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_ALL_ASSET_INST_VERSIONS_FOR_ASSET));
			
			pstmt.setString(Constants.ONE, assetName);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesForassetName || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_ALL_ASSET_INST_VERSIONS_FOR_ASSET));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				aiv = new AssetInstanceVersion();
				aiv.setAssetInstanceId(rs.getLong("asset_inst_id"));
				aiv.setAssetInstVersionId(rs.getLong("asset_instance_version_id"));
				aiv.setDescription(rs.getString("description"));
				aiv.setOwner(rs.getString("owner"));
				aiv.setUpdatedOn(rs.getTimestamp("updated_on"));
				aiv.setVersionName(rs.getString("version_name"));
				aiv.setAssetInstName(rs.getString("asset_inst_name"));
				aiv.setAssetName(rs.getString("asset_name"));
				aiv.setAssetId(rs.getLong("asset_id"));
				aiv.setVersionable(rs.getBoolean("versionable"));
				aivs.add(aiv);
				if(log.isTraceEnabled()){
					log.trace("getAllAssetInstancesForassetName || "+ aiv.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllAssetInstancesForassetName || "+ aivs.toString());
			}
			
			if (!aivs.isEmpty()) {
				for (AssetInstanceVersion aiv1 : aivs) {
					assetInstIds.add(aiv1.getAssetInstanceId());
				}

				for (Long yourInt : assetInstIds) {
					if (!set1.add(yourInt)) {
						setToReturn.add(yourInt);
					}
				}

				if (setToReturn.isEmpty()) {
					return false;
				}
				else {
					return true;
				}
			}
			
		} catch (SQLException e) {
			log.error("getAllAssetInstancesForassetName || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetInstancesForassetName || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetInstancesForassetName || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetInstancesForassetName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetInstancesForassetName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAllAssetInstancesForassetName || end");
		}
		return false;
	}
	
	/**
	 * @method getParamsByAsset
	 * @description get list of parameters
	 * @param userName
	 * @param assetId
	 * @param conn
	 * @return List<AssetParamDef>
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getParamsByAsset(String assetName,Connection conn) throws RepoproException {

		
		if (log.isTraceEnabled()) {
			log.trace("getParamsByAsset || begin with assetName : "+assetName.toString());
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		AssetParamDef assetParamDef = null;
		List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();
		try {
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParamsByAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_PARAMS_BY_ASSET_NAME));
			
			preparedStmt.setString(Constants.ONE, assetName);
			
			resultSet = preparedStmt.executeQuery();
			
			if (log.isTraceEnabled()) {
				log.trace("getParamsByAsset || "+PropertyFileReader.getInstance().getValue(Constants.GET_PARAMS_BY_ASSET_NAME));
			}
			while (resultSet.next()) {
				assetParamDef = new AssetParamDef();
				assetParamDef.setAssetParamId(resultSet.getLong("asset_param_id"));
				assetParamDef.setAssetParamName(resultSet.getString("assetParamName"));
				assetParamDef.setParamTypeId(resultSet.getLong("param_type_id"));
				/*assetParamDef.setListTypeParamTypeId(resultSet
						.getLong("list_param_type_id"));
				assetParamDef.setHasImportantValue(resultSet
						.getBoolean("is_important"));
				assetParamDef.setHasStaticValue(resultSet.getBoolean("is_static"));
				assetParamDef.setHasdefViewValue(resultSet
						.getBoolean("is_default_view"));
				assetParamDef.setMappedAssetId(resultSet
						.getLong("mapped_asset_id"));
				assetParamDef.setParamTypeId(resultSet.getLong("param_type_id"));*/
				assetParamDef.setLdapMappingId(resultSet.getInt("ldap_mapping_id"));
				assetParamDefList.add(assetParamDef);
				
				if (log.isTraceEnabled()) {
					log.trace("getParamsByAsset || "+ assetParamDef.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getParamsByAsset || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAMETER_NOT_FOUND));
			
		} catch (IOException e) {
			log.error("getParamsByAsset || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		} catch (PropertyVetoException e) {
			log.error("getParamsByAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamsByAsset ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
			
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getParamsByAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		
		log.trace("getParamsByAsset || exit");
		
		return assetParamDefList;
	
	}
	/**
	 * @method getPossibleValuesForParam
	 * @description get list of values
	 * @param userName
	 * @param assetId
	 * @param conn
	 * @return List<AssetParamDef>
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getPossibleValuesForParam(String assetName, String assetParamName, Connection conn) throws RepoproException {

		
		if (log.isTraceEnabled()) {
			log.trace("getPossibleValuesForParam || begin with assetName : "+assetName.toString());
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		AssetParamDef assetParamDef = null;
		List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();
		try {
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForParam || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_POSSIBLE_VALUES_FOR_PARAMS));
			
			preparedStmt.setString(Constants.ONE, assetParamName);
			preparedStmt.setString(Constants.TWO, assetName);
			
			resultSet = preparedStmt.executeQuery();
			
			if (log.isTraceEnabled()) {
				log.trace("getPossibleValuesForParam || "+PropertyFileReader.getInstance().getValue(Constants.RET_POSSIBLE_VALUES_FOR_PARAMS));
			}
		
			while (resultSet.next()) {
				assetParamDef = new AssetParamDef();
				/*assetParamDef.setAssetParamId(resultSet.getLong("asset_param_id"));
				assetParamDef.setAssetParamName(resultSet
						.getString("asset_param_name"));
				assetParamDef.setParamTypeId(resultSet.getLong("param_type_id"));
				assetParamDef.setListTypeParamTypeId(resultSet
						.getLong("list_param_type_id"));
				assetParamDef.setHasImportantValue(resultSet
						.getBoolean("is_important"));
				assetParamDef.setHasStaticValue(resultSet.getBoolean("is_static"));
				assetParamDef.setHasdefViewValue(resultSet
						.getBoolean("is_default_view"));
				assetParamDef.setMappedAssetId(resultSet
						.getLong("mapped_asset_id"));
				assetParamDef.setTypeName(resultSet.getString("type_name"));*/
				assetParamDef.setParamValue(resultSet.getString("value"));
				//assetParamDef.setMappedAssetId(resultSet.getLong("mapped_asset_id"));
				
				assetParamDefList.add(assetParamDef);
				
				if (log.isTraceEnabled()) {
					log.trace("getParamsByAsset || "+ assetParamDef.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getParamsByAsset || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.USER_NOT_FOUND));
			
		} catch (IOException e) {
			log.error("getParamsByAsset || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		} catch (PropertyVetoException e) {
			log.error("getParamsByAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamsByAsset ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
			
		} finally {
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getParamsByAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
			log.trace("getParamsByAsset || exit");
		
		return assetParamDefList;
	
	}
	/**
	 * @method getParamValuesForAssetInst
	 * @description get list of values
	 * @param assetName,assetInstName,versionName
	 * @param conn
	 * @return List<AssetParamDef>
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getParamValuesForAssetInst(String assetName, String assetInstName, String versionName, Connection conn) throws RepoproException {

		
		if (log.isTraceEnabled()) {
			log.trace("getParamValuesForAssetInst || begin with assetName : "+assetName.toString());
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		AssetParamDef assetParamDef = null;
		List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();
		try {
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParamValuesForAssetInst || " + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_PARAMETER_VALUES_FOR_ASSET_INST));
			
			preparedStmt.setString(Constants.ONE, assetName);
			preparedStmt.setString(Constants.TWO, assetInstName);
			preparedStmt.setString(Constants.THREE, versionName);
			
			resultSet = preparedStmt.executeQuery();
			
			if (log.isTraceEnabled()) {
				log.trace("getParamValuesForAssetInst || "+PropertyFileReader.getInstance().getValue(Constants.GET_PARAMETER_VALUES_FOR_ASSET_INST));
			}
			while (resultSet.next()) {
				assetParamDef = new AssetParamDef();
				assetParamDef.setAssetName(resultSet.getString("asset_name"));
				assetParamDef.setAssetInstName(resultSet.getString("instname"));
				assetParamDef.setVersionName(resultSet.getString("versionname"));
				assetParamDef.setAssetParamName(resultSet.getString("asset_param_name"));
				assetParamDef.setParamValue(resultSet.getString("value"));
				assetParamDef.setParamTypeId(resultSet.getLong("param_type_id"));
				assetParamDef.setFileName(resultSet.getString("fileName"));
				
				assetParamDefList.add(assetParamDef);
				
				if (log.isTraceEnabled()) {
					log.trace("getParamValuesForAssetInst || "
							+ assetParamDef.toString());
				}

			}
			
		} catch (SQLException e) {
			log.error("getParamValuesForAssetInst || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAMETER_NOT_FOUND));
			
		} catch (IOException e) {
			log.error("getParamValuesForAssetInst || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		} catch (PropertyVetoException e) {
			log.error("getParamValuesForAssetInst || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamValuesForAssetInst ||  " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getParamValuesForAssetInst || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(preparedStmt != null){
					preparedStmt.close();
				}
				if(resultSet != null){
					resultSet.close();  
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}                                                                                                             log.trace("getParamValuesForAssetInst || exit");
		
		return assetParamDefList;
	}
	public void UpdateParameterDragged(AssetParamDef apd, Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("UpdateParameterDragged || " +apd.toString()+ "Begin" );
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("UpdateParameterDragged || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.UPDATE_ASSET_PARAM_DEF_DRAGGED_DISP_POSITION));

			pstmt.setLong(Constants.ONE, apd.getAssetCategoryId());
			pstmt.setLong(Constants.TWO, apd.getAssetParamId());
			


			if (log.isTraceEnabled()) {
				log.trace("UpdateParameterDragged || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.UPDATE_ASSET_PARAM_DEF_DRAGGED_DISP_POSITION));
			}

			int result = pstmt.executeUpdate();
			
			/*if (result == 0) {
				log.warn("UpdateParameterDragged || AssetParamDef is not updated and throws RepoproException");
				throw new RepoproException(
						MessageUtil
						.getMessage(Constants.UPDATE_ASSET_PARAM_DEF_DRAGGED_NOT_UPDATED));
			}*/

		} catch (SQLException e) {
			log.error("UpdateParameterDragged || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UPDATE_ASSET_PARAM_DEF_DRAGGED_NOT_UPDATED));
		} catch (IOException e) {
			log.error("UpdateParameterDragged || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("UpdateParameterDragged || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("UpdateParameterDragged || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("UpdateParameterDragged || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("UpdateParameterDragged ||" +apd.toString() + " End");
		}
	}
	
	public Long getCatgoryIdByCatNameAndAssetId(String catName , long assetId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getCatgoryIdByCatName || catName:" + catName+ "and assetId:"+assetId
					+ " || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		Long catId = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getCatgoryIdByCatNameAndAssetId || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedSt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_CATEGORY_ID_BY_CAT_NAME_AND_ASSET_ID));

			if (log.isTraceEnabled()) {
				log.trace("getCatgoryIdByCatNameAndAssetId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_CATEGORY_ID_BY_CAT_NAME_AND_ASSET_ID));
			}

			preparedSt.setLong(Constants.ONE, assetId);
			preparedSt.setString(Constants.TWO, catName);

			rs = preparedSt.executeQuery();

			while (rs.next()) {
				catId = rs.getLong("asset_category_id");

				if (log.isTraceEnabled()) {
					log.trace("getCatgoryIdByCatNameAndAssetId || retrived category id :" +catId );
				}
			}

		} catch (SQLException e) {
			log.error("getCatgoryIdByCatNameAndAssetId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_CATEGORY_ID_BY_CAT_NAME_AND_ASSET_ID_NOT_FETCHED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getCatgoryIdByCatNameAndAssetId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getCatgoryIdByCatNameAndAssetId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getCatgoryIdByCatNameAndAssetId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getCatgoryIdByCatNameAndAssetId ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getCatgoryIdByCatNameAndAssetId || exit");
		}
		return catId;
	}
	

	/**
	 * @method updateParameterDefinition
	 * @param adf
	 * @param conn
	 * @return int
	 */
	public int updateParameterDefinition(AssetParamDef adf,Connection conn)throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("updateParameterDefinition || Begin with AssetParamDef : "+ adf.toString());
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0 ;
		try {
			if (log.isTraceEnabled()){
				log.trace("updateParameterDefinition || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_ASSET_PARAMETER_DEFINITION));
			pstmt.setString(Constants.ONE, adf.getAssetParamName());
			pstmt.setString(Constants.TWO,adf.getDescription());
			pstmt.setLong(Constants.THREE,adf.getParamTypeId());
			if(adf.getListTypeParamTypeId() == 0){
				pstmt.setString(Constants.FOUR,null);
			}else{
				pstmt.setLong(Constants.FOUR,adf.getListTypeParamTypeId());
			}
			
			
			if(adf.getMappedAssetId() == 0){
				pstmt.setString(Constants.FIVE,null);
			}else{
				pstmt.setLong(Constants.FIVE,adf.getMappedAssetId());
			}
			
			/*if(adf.getListTypeName()!=null){
				if(adf.getListTypeName().equalsIgnoreCase("ASSET_LIST")){
					pstmt.setLong(Constants.FOUR, adf.getListTypeParamTypeId());	
				}else if(adf.getListTypeName().equalsIgnoreCase("CUSTOM_LIST")){
					
				}else {
					pstmt.setLong(Constants.FOUR, adf.getListTypeParamTypeId());	
				}
			}else{
				pstmt.setNull(Constants.FOUR, 0);	
			}*/

			
			/*if(adf.getMappedAssetId()==0){
				pstmt.setNull(Constants.FIVE, 0);
			}else{
				pstmt.setLong(Constants.FIVE, adf.getMappedAssetId());
			}*/
			pstmt.setInt(Constants.SIX, adf.getSize());
			pstmt.setBoolean(Constants.SEVEN, adf.isQuickLink());
			pstmt.setInt(Constants.EIGHT,adf.getDisplayPosition());
			
			
			if(adf.isSystemParam()){
				pstmt.setInt(Constants.NINE, 1);	
			}else{
				pstmt.setInt(Constants.NINE, 0);
			}
		
			pstmt.setInt(Constants.TEN, adf.getIs_static());
			if(adf.isHasImportantValue()){
				pstmt.setInt(Constants.ELEVEN, 1);
			}else{
				pstmt.setInt(Constants.ELEVEN, 0);
			}
			
			
			if(adf.getDefaultView()==1){
				pstmt.setInt(Constants.TWELVE, 1);
				
			}else{
				pstmt.setInt(Constants.TWELVE, 0);
			}
			
			
			//pstmt.setString(Constants.THIRTEEN, adf.getStaticValue());
			//pstmt.setBytes(Constants.FOURTEEN,adf.getStaticFileContent());
			//pstmt.setString(Constants.FIFTEEN, adf.getFileName());
			//pstmt.setString(Constants.SIXTEEN,adf.getMimetype());
			pstmt.setTimestamp(Constants.THIRTEEN,adf.getLastUpdatedTime());
			pstmt.setString(Constants.FOURTEEN,adf.getDerivedAttributeComputation());
			
			if(adf.isHasMandatoryValue()){
				pstmt.setInt(Constants.FIFTEEN, 1);
			}else{
				pstmt.setInt(Constants.FIFTEEN, 0);
			}
			pstmt.setInt(Constants.SIXTEEN, adf.getHasArray());
			pstmt.setLong(Constants.SEVENTEEN, adf.getAssetCategoryId());
			pstmt.setInt(Constants.EIGHTEEN, adf.getListType());
			pstmt.setLong(Constants.NINETEEN,  adf.getLdapMappingId());
			pstmt.setString(Constants.TWENTY, adf.getDerivedAssetListRule());
			if(adf.isNotifyOnRuleValidate()){
				pstmt.setInt(Constants.TWENTYONE, 1);
			}else{
				pstmt.setInt(Constants.TWENTYONE, 0);
			}
			pstmt.setLong(Constants.TWENTYTWO,adf.getAssetParamId());


			//result = pstmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("updateParameterDefinition || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_ASSET_PARAMETER_DEFINITION));
			}
			result = pstmt.executeUpdate();
			if(result==1){
				log.info("parameter successfully update!");
			}
		} catch (SQLException e) {
			log.error("updateParameterDefinition || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(
						MessageUtil.getMessage(Constants.ASSET_PARAM_DEF_NOT_UPDATED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (IOException e) {
			log.error("updateParameterDefinition || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (PropertyVetoException e) {
			log.error("updateParameterDefinition || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} catch (Exception e) {
			log.error("updateParameterDefinition || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			try {
				throw new RepoproException(e.getMessage());
			} catch (RepoproException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateParameterDefinition || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if(pstmt != null){
					pstmt.close();
				}
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
		}
		if(log.isTraceEnabled()){
			log.trace("updateParameterDefinition || End");
		}

		return result;
	}
	
	
	/**
	 * @method addCategoryWiseAccessForAsset
	 * @description to add default category access for asset
	 * @param assetCatId ,groupId
	 * @throws RepoproException
	 */

	public void addCategoryWiseAccessForAsset(Long assetCatId,Long groupId, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addCategoryWiseAccessForAsset ||   Begin ");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("addCategoryWiseAccessForAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_CATEGORY_WISE_ACCESS_FOR_GROUPS_BY_CATEGORY_ID));

			pstmt.setLong(Constants.ONE,assetCatId );
			pstmt.setLong(Constants.TWO,groupId);
			pstmt.setLong(Constants.THREE,0L); // BY default group admin will be checked ,but no edit access will be provided.

			if (log.isTraceEnabled()) {
				log.trace("addCategoryWiseAccessForAsset || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_CATEGORY_WISE_ACCESS_FOR_GROUPS_BY_CATEGORY_ID));
			}

			pstmt.execute();
			
			
		} catch (SQLException e) {
			log.error("addCategoryWiseAccessForAsset || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.CATEGORY_WISE_ACCESS_NOT_ADDED));
		} catch (IOException e) {
			log.error("addCategoryWiseAccessForAsset || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addCategoryWiseAccessForAsset || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addCategoryWiseAccessForAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addCategoryWiseAccessForAsset || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("addCategoryWiseAccessForAsset ||   End");
		}
		
	}
	/**
	 * @method : getAssetsByAssetName
	 * @param assetName
	 * @param conn
	 * @return assetId
	 * @throws RepoproException
	 */
	public AssetDef getAssetsByAssetName(String assetName, Connection conn)
			throws RepoproException {

		log.trace("getAssetsByAssetName || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
        AssetDef assetDef = new AssetDef();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetsByAssetName || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSETS_BY_ASSET_NAME));
			pstmt.setString(Constants.ONE, assetName);
			if (log.isTraceEnabled()) {
				log.trace("getAssetsByAssetName || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSETS_BY_ASSET_NAME));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setVersionable(rs.getBoolean("versionable"));
				assetDef.setGuestflag(rs.getBoolean("guest_flag"));
		
				if (log.isTraceEnabled()) {
					log.trace("getAssetsByAssetName || " + assetDef.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAssetsByAssetName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetsByAssetName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetsByAssetName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetsByAssetId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetsByAssetId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAssetsByAssetName || End");
		return assetDef;
	}

	/**
	 * @method : getFilterSearchIdByName
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public SavedSearch getFilterSearchIdByName(String searchName, Connection conn)
			throws RepoproException {

		log.trace("getFilterSearchNameById || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		SavedSearch savedSearch = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchIdByName || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_FILTER_SEARCH_ID_BY_SEARCH_NAME));
			pstmt.setString(Constants.ONE, searchName);
		
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchNameById || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_FILTER_SEARCH_ID_BY_SEARCH_NAME));
			}
			
			rs = pstmt.executeQuery();

			while (rs.next()) {
				savedSearch = new SavedSearch();
				savedSearch.setSearchId(rs.getLong("search_id"));
				savedSearch.setAssetId(rs.getLong("asset_id"));

				if (log.isTraceEnabled()) {
					log.trace("getFilterSearchIdByName || " + savedSearch.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getFilterSearchIdByName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getFilterSearchIdByName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getFilterSearchIdByName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getFilterSearchIdByName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getFilterSearchIdByName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getFilterSearchIdByName || End");
		return savedSearch;
	}
	
	
	/**
	 * @method : getAssetParamAccess
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetParamDef getAssetParamAccess(String userName,String paramName ,String assetName , Connection conn)
			throws RepoproException {

		log.trace("getAssetParamAccess || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetParamDef apd = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamAccess || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if(userName.equalsIgnoreCase("roleAnonymous")){
				
				pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.GET_ASSET_PARAM_ACCESS_FOR_GUEST));
				
				
				pstmt.setString(Constants.ONE, paramName);
				pstmt.setString(Constants.TWO, assetName);
			
				if (log.isTraceEnabled()) {
					log.trace("getAssetParamAccess || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ASSET_PARAM_ACCESS_FOR_GUEST));
				}
				
			}else{
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_PARAM_ACCESS));
			
			pstmt.setString(Constants.ONE, userName);
			pstmt.setString(Constants.TWO, paramName);
			pstmt.setString(Constants.THREE, assetName);
		
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamAccess || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_PARAM_ACCESS));
			}
			}
			
			rs = pstmt.executeQuery();

			while (rs.next()) {
				apd = new AssetParamDef();
				apd.setAssetParamId(rs.getLong("asset_param_id"));
				

				if (log.isTraceEnabled()) {
					log.trace("getAssetParamAccess || " + apd.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAssetParamAccess || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetParamAccess || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetParamAccess || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetParamAccess || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamAccess || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAssetParamAccess || End");
		return apd;
	}
	
	
	/**
	 * @method : getAssetParamIdByName
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetParamDef getAssetParamIdByName(String paramName ,String assetName , Connection conn)
			throws RepoproException {

		log.trace("getAssetParamIdByName || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetParamDef apd = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamIdByName || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_PARAM_ID_BY_NAME));
			
		
			pstmt.setString(Constants.ONE, paramName);
			pstmt.setString(Constants.TWO, assetName);
		
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamAccess || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_PARAM_ID_BY_NAME));
			}
			
			rs = pstmt.executeQuery();

			while (rs.next()) {
				apd = new AssetParamDef();
				apd.setAssetParamId(rs.getLong("asset_param_id"));
				

				if (log.isTraceEnabled()) {
					log.trace("getAssetParamAccess || " + apd.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAssetParamIdByName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetParamIdByName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetParamIdByName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetParamIdByName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetParamIdByName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAssetParamIdByName || End");
		return apd;
	}
	/**
	 * @method getParametersForAssetAndCategory
	 * @param assetName
	 * @param category
	 * @param conn
	 * @return List<AssetParamDef>
	 * @throws RepoproException
	 */
	public List<AssetParamDef> getParametersForAssetAndCategory(String assetName ,String category , Connection conn)
			throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getParametersForAssetAndCategory ||assetName:"+assetName+" category:"+category+"||Begin");
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetParamDef assetParamDef = null;
		List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getParametersForAssetAndCategory || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_PARAMETERS_FOR_ASSET_AND_CATEGORY));
			
			pstmt.setString(Constants.ONE, assetName);
			pstmt.setString(Constants.TWO, category);
		
			if (log.isTraceEnabled()) {
				log.trace("getParametersForAssetAndCategory || "
						+ PropertyFileReader.getInstance().getValue(Constants.GET_PARAMETERS_FOR_ASSET_AND_CATEGORY));
			}
			
			rs = pstmt.executeQuery();

			while (rs.next()) {
				assetParamDef = new AssetParamDef();
				assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
				assetParamDef.setAssetParamName(rs.getString("asset_param_name"));
				assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
				assetParamDef.setDescription(rs.getString("description"));
				assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
				assetParamDef.setListTypeParamTypeId(rs.getLong("list_param_type_id"));
				assetParamDef.setHasImportantValue(rs.getBoolean("is_important"));
				assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
				assetParamDef.setHasdefViewValue(rs.getBoolean("is_default_view"));
				assetParamDef.setMappedAssetId(rs.getLong("mapped_asset_id"));
				assetParamDef.setModifyByUserId(rs.getLong("static_modify_by_user_id"));
				assetParamDef.setLastUpdatedTime(rs.getTimestamp("static_last_updated_time"));
				assetParamDef.setFileName(rs.getString("fileName"));
				assetParamDef.setSize(rs.getInt("size"));
				assetParamDef.setQuickLink(rs.getBoolean("quick_link"));
				assetParamDef.setDisplayPosition(rs.getInt("disp_position"));
				assetParamDef.setSystemParam(rs.getBoolean("is_system_param"));
				assetParamDef.setMimetype(rs.getString("mimetype"));
				assetParamDef.setStaticValue(rs.getString("static_val"));
				assetParamDef.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				assetParamDef.setStaticFileContent(rs.getBytes("static_file_content"));
				assetParamDef.setTypeName(rs.getString("type_name"));
				assetParamDefList.add(assetParamDef);

				if (log.isTraceEnabled()) {
					log.trace("getParametersForAssetAndCategory || " + assetParamDef.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getParametersForAssetAndCategory || " + assetParamDefList.toString());
			}
		} catch (SQLException e) {
			log.error("getParametersForAssetAndCategory || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getParametersForAssetAndCategory || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getParametersForAssetAndCategory || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getParametersForAssetAndCategory || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getParametersForAssetAndCategory || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getParametersForAssetAndCategory || End");
		return assetParamDefList;
	}
	/**
	 * @method getParamDetailsByParamId
	 * @param paramId
	 * @param conn
	 * @return AssetParamDef
	 * @throws RepoproException
	 */
	public AssetParamDef getParamDetailsByParamId(Long paramId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getParamDetailsByParamId ||paramId:" + paramId+  " || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		AssetParamDef assetParamDef = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParamDetailsByParamId || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			preparedSt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_PARAM_DETAILS_BY_PARAM_ID));
			if (log.isTraceEnabled()) {
				log.trace("getParamDetailsByParamId || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_PARAM_DETAILS_BY_PARAM_ID));
			}
			preparedSt.setLong(Constants.ONE, paramId);

			rs = preparedSt.executeQuery();

			while (rs.next()) {
				assetParamDef = new AssetParamDef();
				assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
				assetParamDef.setAssetParamName(rs.getString("asset_param_name"));
				assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
				assetParamDef.setListTypeParamTypeId(rs.getLong("list_param_type_id"));
				assetParamDef.setHasImportantValue(rs.getBoolean("is_important"));
				assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
				assetParamDef.setHasdefViewValue(rs.getBoolean("is_default_view"));
				assetParamDef.setMappedAssetId(rs.getLong("mapped_asset_id"));
				assetParamDef.setTypeName(rs.getString("type_name"));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || " + assetParamDef.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getParamDetailsByParamId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_PARAM_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getParamDetailsByParamId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getParamDetailsByParamId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamDetailsByParamId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getParamDetailsByParamId ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getParamDetailsByParamId ||paramId:" + paramId+ " ||exit");
		}
		return assetParamDef;
	}
	/**
	 * @method : getAssetCategoryAccess
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public AssetParamDef getAssetCategoryAccess(String userName,String categoryName ,String assetName , Connection conn)
			throws RepoproException {

		log.trace("getAssetCategoryAccess || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetParamDef apd = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetCategoryAccess || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if(userName.equalsIgnoreCase("roleAnonymous")){
				
				pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.GET_ASSET_CATEGORY_ACCESS_FOR_GUEST));
				
				
				pstmt.setString(Constants.ONE, categoryName);
				pstmt.setString(Constants.TWO, assetName);
			
				if (log.isTraceEnabled()) {
					log.trace("getAssetCategoryAccess || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ASSET_CATEGORY_ACCESS_FOR_GUEST));
				}
				
			}else{
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_CATEGORY_ACCESS));
			
			pstmt.setString(Constants.ONE, userName);
			pstmt.setString(Constants.TWO, categoryName);
			pstmt.setString(Constants.THREE, assetName);
		
			if (log.isTraceEnabled()) {
				log.trace("getAssetCategoryAccess || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_CATEGORY_ACCESS));
			}
			}
			
			rs = pstmt.executeQuery();

			while (rs.next()) {
				apd = new AssetParamDef();
				apd.setAssetCategoryId(rs.getLong("asset_category_id"));
				

				if (log.isTraceEnabled()) {
					log.trace("getAssetCategoryAccess || " + apd.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAssetCategoryAccess || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetCategoryAccess || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetCategoryAccess || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetCategoryAccess || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetCategoryAccess || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAssetCategoryAccess || End");
		return apd;
	}

/**
	 * @method : getAllAssets
	 * @description : to get all the assets
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<AssetDef> getAllFilteredAssetsForSubscription(String searchString,Connection conn) throws RepoproException {

		log.trace("getAllFilteredAssetsForSubscription || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<AssetDef> assetList = new ArrayList<AssetDef>();
		AssetDef assetDef = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetsForSubscription || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ALL_FILTERED_SUBSCRIBED_ASSETS));
			
			pstmt.setString(Constants.ONE, "%"+searchString+"%");

			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetsForSubscription || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_FILTERED_SUBSCRIBED_ASSETS));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				assetDef = new AssetDef();
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setAssetName(rs.getString("asset_name"));
				assetDef.setDescription(rs.getString("description"));
				assetDef.setIconImage(rs.getBinaryStream("icon_image"));
				assetDef.setSystemAsset(rs.getBoolean("is_system_asset"));
				assetDef.setVersionable(rs.getBoolean("versionable"));
				assetDef.setIconImageName(rs.getString("icon_image_name"));
				assetDef.setRatingDescription(rs
						.getString("rating_description"));
				assetList.add(assetDef);

				if (log.isTraceEnabled()) {
					log.trace("getAllFilteredAssetsForSubscription || " + assetDef.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllFilteredAssetsForSubscription || " + assetList.toString());
			}

		} catch (SQLException e) {
			log.error("getAllFilteredAssetsForSubscription || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllFilteredAssetsForSubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllFilteredAssetsForSubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllFilteredAssetsForSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllFilteredAssetsForSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAllFilteredAssetsForSubscription || End");
		return assetList;
	}
	
	
	/**
	 * @method : deleteParameterValues
	 * @param assetInstParamId
	 * @param conn
	 * @throws RepoproException
	 */
	public void deleteParameterValues(Long assetInstParamId, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("deleteParameterValues || " + assetInstParamId + "Begin" );
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteParameterValues || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_PARAMETER_VALUES));

			pstmt.setLong(Constants.ONE, assetInstParamId);
			
			if (log.isTraceEnabled()) {
				log.trace("deleteParameterValues || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_PARAMETER_VALUES));
			}

			int result = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("deleteParameterValues || "
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_VALUES_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteParameterValues || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteParameterValues || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteParameterValues || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteParameterValues || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteParameterValues || End");
		}
	}
	
	
	/**
	 * @method : addParameterValuesForRichText
	 * @param paramValue
	 * @param conn
	 * @throws RepoproException
	 */
	public void addParameterValuesForRichText(ParameterValues paramValue, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addParameterValuesForRichText || " + paramValue.toString() + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try{
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addParameterValuesForRichText || " + Constants.LOG_CONNECTION_OPEN);
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.ADD_PARAMETER_VALUES_FOR_RICH_TEXT));


			pstmt.setLong(Constants.ONE, paramValue.getAssetInstParamId());
			pstmt.setString(Constants.TWO, paramValue.getRTFText());
			pstmt.setBinaryStream(Constants.THREE, paramValue.getImage());
			pstmt.setString(Constants.FOUR, paramValue.getFileName());
			pstmt.setString(Constants.FIVE, paramValue.getMimeType());
			pstmt.setString(Constants.SIX, paramValue.getRTFPlainText());


			if (log.isTraceEnabled()) {
				log.trace("addParameterValuesForRichText || " + PropertyFileReader.getInstance().getValue(
								Constants.ADD_PARAMETER_VALUES_FOR_RICH_TEXT));
			}

			pstmt.executeUpdate();
		
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				paramValue.setParameterValuesId(rs.getLong(1));
			}


		} catch (SQLException e) {
			log.error("addParameterValuesForRichText || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_VALUES_NOT_CREATED));
		} catch (IOException e) {
			log.error("addParameterValuesForRichText || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addParameterValuesForRichText || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addParameterValuesForRichText || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addParameterValuesForRichText || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if (log.isTraceEnabled()) {
			log.trace("addParameterValuesForRichText || " + paramValue.toString() + " End");
		}
	}
	
	
	/**
	 * @method : enableOrDisableIsArray
	 * @param assetName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public boolean enableOrDisableIsArray(String assetName,String assetParamName,Long paramTypeId,Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("enableOrDisableIsArray || Begin with assetName : "+ assetName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		boolean val = false;
		
		AssetInstanceVersion aiv = null;
		List<AssetInstanceVersion> aivList = new ArrayList<AssetInstanceVersion>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("enableOrDisableIsArray || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_PARAM_VALUES_FOR_ASSET));
			
			pstmt.setString(Constants.ONE, assetName);
			pstmt.setLong(Constants.TWO, paramTypeId);
			pstmt.setString(Constants.THREE, assetParamName);
			
			if (log.isTraceEnabled()) {
				log.trace("enableOrDisableIsArray || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_PARAM_VALUES_FOR_ASSET));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				aiv = new AssetInstanceVersion();
				aiv.setAssetName(rs.getString("asset_name"));
				aiv.setAssetParamName(rs.getString("asset_param_name"));
				aiv.setParamValue(rs.getString("value"));
				aiv.setAssetParamId(rs.getLong("asset_param_id"));
				aivList.add(aiv);
				if(log.isTraceEnabled()){
					log.trace("enableOrDisableIsArray || "+ aiv.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("enableOrDisableIsArray || "+ aivList.toString());
			}
			if(aivList.size()==1){
				if(!aivList.get(0).getParamValue().equalsIgnoreCase("")){
					val = true;
				}
			}else if(!aivList.isEmpty()){
				val = true;
			}
		} catch (SQLException e) {
			log.error("enableOrDisableIsArray || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAMETER_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("enableOrDisableIsArray || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("enableOrDisableIsArray || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("enableOrDisableIsArray || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("enableOrDisableIsArray || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return val;
	}
	/**
	 * @method getParameteresByAssetName
	 * @param assetName
	 * @param userName
	 * @param conn
	 * @return List<AssetInstanceVersion>
	 * @throws RepoproException
	 */
	public List<AssetInstanceVersion> getParameteresByAssetName(String assetName,String userName,Connection conn)
			throws RepoproException {

		log.trace("getParameteresByAssetName || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetInstanceVersion versionDetails = null;
		List<AssetInstanceVersion> listOfAssetInstanceVersions = new ArrayList<AssetInstanceVersion>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getParameteresByAssetName || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if(userName.equalsIgnoreCase("admin")){
				pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.GET_PARAM_DETAILS_BY_ASSET_NAME_FOR_ADMIN));
				pstmt.setString(Constants.ONE, assetName);
				if (log.isTraceEnabled()) {
					log.trace("getParameteresByAssetName || "+ PropertyFileReader.getInstance().getValue(Constants.GET_PARAM_DETAILS_BY_ASSET_NAME_FOR_ADMIN));
				}
				rs = pstmt.executeQuery();
			}else{
				pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
						.getValue(Constants.GET_PARAM_DETAILS_BY_ASSET_NAME_FOR_NON_ADMIN));
				pstmt.setString(Constants.ONE, userName);
				pstmt.setString(Constants.TWO, assetName);
				if (log.isTraceEnabled()) {
					log.trace("getParameteresByAssetName || "+ PropertyFileReader.getInstance().getValue(Constants.GET_PARAM_DETAILS_BY_ASSET_NAME_FOR_NON_ADMIN));
				}
				rs = pstmt.executeQuery();
			}
			
			while (rs.next()) {
				versionDetails = new AssetInstanceVersion();
				versionDetails.setAsset_category_name(rs.getString("asset_category_name"));
				versionDetails.setCat_disp(rs.getInt("cat_disp_position"));
				versionDetails.setCategoryId(rs.getLong("asset_category_id"));
				if(userName.equalsIgnoreCase("admin")){
					versionDetails.setEditAccessFlag(true);	
				}else if(userName.equalsIgnoreCase("roleAnonymous")){
					versionDetails.setEditAccessFlag(false);	
				}else{
				List<GroupDetails> gd = this.getAssetCategoryEditAccessForPropertiesAivPage(userName,versionDetails.getCategoryId(), conn);
				   for(GroupDetails gd1 : gd){
					   if(gd1.getEditAccess() == 1L){
						   versionDetails.setEditAccessFlag(true);	
						   break;
					   }
				   }
				}
				versionDetails.setStaticValue(rs.getString("static_val"));
				versionDetails.setApdFileName(rs.getString("fileName"));
				versionDetails.setParam_disp(rs.getInt("disp_position"));
				versionDetails.setAssetParamName(rs.getString("asset_param_name"));
				versionDetails.setIsStatic(rs.getInt("is_static"));
				versionDetails.setParamTypeId(rs.getLong("param_type_id"));
				versionDetails.setListTypeParamTypeId(rs.getLong("list_param_type_id"));
				versionDetails.setMappedAssetId(rs.getLong("mapped_asset_id"));
				versionDetails.setAssetParamId(rs.getLong("asset_param_id"));
				versionDetails.setImportant(rs.getBoolean("is_important"));
				versionDetails.setMandatory(rs.getBoolean("is_mandatory"));
				versionDetails.setParamTextSize(rs.getInt("size"));
				versionDetails.setDescription(rs.getString("description"));
				versionDetails.setHasArray(rs.getInt("isArray"));
				//harish
				versionDetails.setListType(rs.getInt("list_type"));
				if(versionDetails.getParamTypeId()==4L || versionDetails.getParamTypeId()==9L) {
					if(versionDetails.getListType() == 0)
						versionDetails.setSingleMultipleFlag(true);
					else if(versionDetails.getListType() == 1)
						versionDetails.setSingleMultipleFlag(false);
				}
				if(rs.getLong("param_type_id") == 4L){
					if(rs.getLong("list_param_type_id") == 4){ // to show count for ldap userlist type 
						String ldapValue = rs.getString("static_val");
						if(ldapValue != null){
							if(!ldapValue.trim().isEmpty()){
								String[] ldapCount = ldapValue.split("~~");
								versionDetails.setLdapUserListCount(ldapCount.length);
							}
						}
					}
				}
				listOfAssetInstanceVersions.add(versionDetails);
			}

		} catch (SQLException e) {
			log.error("getParameteresByAssetName || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getParameteresByAssetName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getParameteresByAssetName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getParameteresByAssetName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getParameteresByAssetName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getParameteresByAssetName || End");
		return listOfAssetInstanceVersions;
	}
	public GroupDetails getAssetCategoryEditAccess(Long categoryID ,Long groupID , Connection conn)
			throws RepoproException {

		log.trace("getAssetCategoryEditAccess || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		GroupDetails gd = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetCategoryEditAccess || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_CATEGORY_EDIT_ACCESS_BY_CATEGORYID_AND_GROUPID));


			pstmt.setLong(Constants.ONE, categoryID);
			pstmt.setLong(Constants.TWO, groupID);

			if (log.isTraceEnabled()) {
				log.trace("getAssetCategoryEditAccess || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_CATEGORY_EDIT_ACCESS_BY_CATEGORYID_AND_GROUPID));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				gd = new GroupDetails();
				gd.setEditAccess(rs.getLong("edit_access"));
				if (log.isTraceEnabled()) {
					log.trace("getAssetCategoryEditAccess for category id: "+categoryID +"edit access is"+ gd.getEditAccess());
				}
			}
		} catch (SQLException e) {
			log.error("getAssetCategoryEditAccess || " + Constants.LOG_GET_SQLEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetCategoryEditAccess || " + Constants.LOG_IOEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetCategoryEditAccess || " + Constants.LOG_PROPERTYVETOEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetCategoryEditAccess || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetCategoryEditAccess || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAssetCategoryEditAccess || End");
		return gd;
	}
	
	public List<GroupDetails> getAssetCategoryEditAccessForPropertiesAivPage(String userName ,Long categoryID , Connection conn)
			throws RepoproException {

		log.trace("getAssetCategoryEditAccessForPropertiesAivPage || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		List<GroupDetails> gd = new ArrayList<GroupDetails>();
		GroupDetails gd1 = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetCategoryEditAccessForPropertiesAivPage || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ASSET_CATEGORY_EDIT_ACCESS_BY_CATEGORYID_AND_GROUPID_IN_AIVPAGE));


			pstmt.setString(Constants.ONE, userName);
			pstmt.setLong(Constants.TWO, categoryID);
			

			if (log.isTraceEnabled()) {
				log.trace("getAssetCategoryEditAccess || "
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSET_CATEGORY_EDIT_ACCESS_BY_CATEGORYID_AND_GROUPID_IN_AIVPAGE));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				gd1 = new GroupDetails();
				gd1.setEditAccess(rs.getLong("edit_access"));
				gd1.setGroupId(rs.getLong("group_id"));
				gd.add(gd1);
				
			}
		} catch (SQLException e) {
			log.error("getAssetCategoryEditAccessForPropertiesAivPage || " + Constants.LOG_GET_SQLEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetCategoryEditAccessForPropertiesAivPage || " + Constants.LOG_IOEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetCategoryEditAccessForPropertiesAivPage || " + Constants.LOG_PROPERTYVETOEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetCategoryEditAccessForPropertiesAivPage || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetCategoryEditAccessForPropertiesAivPage || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getAssetCategoryEditAccessForPropertiesAivPage || End");
		return gd;
	}
	/**
	 * @method getParameteresByAssetName
	 * @param assetName
	 * @param userName
	 * @param conn
	 * @return List<AssetInstanceVersion>
	 * @throws RepoproException
	 */
	public List<AssetDef> fetchAllAssetsDetails(Connection conn)
			throws RepoproException {

		log.trace("fetchAllAssetsDetails || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetDef assetDef = null;
		List<AssetDef> assetdefList = new ArrayList<AssetDef>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("fetchAllAssetsDetails || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ASSETS));
			if (log.isTraceEnabled()) {
				log.trace("getAllAssets || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_ASSETS));
			}
			rs = pstmt.executeQuery();
			while(rs.next()){
				assetDef = new AssetDef();

				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setAssetName(rs.getString("asset_name"));
				assetDef.setInvertedIconImage(rs.getBinaryStream("inverted_icon_image"));
				assetDef.setIconImage(rs.getBinaryStream("icon_image"));
				assetDef.setIconImageName(rs.getString("icon_image_name"));
				assetDef.setDescription(rs.getString("description"));
				assetdefList.add(assetDef);

			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssets || "+ assetdefList.toString());
			}

		} catch (SQLException e) {
			log.error("fetchAllAssetsDetails || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("fetchAllAssetsDetails || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("fetchAllAssetsDetails || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("fetchAllAssetsDetails || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("fetchAllAssetsDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("fetchAllAssetsDetails || End");
		return assetdefList;
	}
	
/**
	 * @method : enableOrDisableSingleMulti
	 * @param assetName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public boolean enableOrDisableSingleMulti(String assetName,String assetParamName,Long paramTypeId,Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("enableOrDisableSingleMulti || Begin with assetName : "+ assetName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		boolean val = true;
		
		AssetInstanceVersion aiv = null;
		//List<AssetInstanceVersion> aivList = new ArrayList<AssetInstanceVersion>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("enableOrDisableSingleMulti || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_PARAM_VALUES_FOR_ASSET));
			
			pstmt.setString(Constants.ONE, assetName);
			pstmt.setLong(Constants.TWO, paramTypeId);
			pstmt.setString(Constants.THREE, assetParamName);
			
			if (log.isTraceEnabled()) {
				log.trace("enableOrDisableSingleMulti || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_PARAM_VALUES_FOR_ASSET));
			}

			rs = pstmt.executeQuery();
			
			while(rs.next()){
				aiv = new AssetInstanceVersion();
				aiv.setAssetName(rs.getString("asset_name"));
				aiv.setAssetParamName(rs.getString("asset_param_name"));
				aiv.setParamValue(rs.getString("value"));
				aiv.setAssetParamId(rs.getLong("asset_param_id"));
				if(aiv.getParamValue() != null){
					if(aiv.getParamValue().contains("~~")){
						val = false;
						break;
					}
					//aivList.add(aiv);
				}
				if(log.isTraceEnabled()){
					log.trace("enableOrDisableSingleMulti || "+ aiv.toString());
				}
			}
			
			//harish
			/*if(aivList.size()<1) { 
				val = true;
			} else if(aivList.size()==1) {
				if(aivList.get(0).getParamValue().contains("~~"))
					val = false;
				else
					val = true;
			} else if(aivList.size()>1){
				for(AssetInstanceVersion value:aivList) {
					val=true;
					if(value.getParamValue().contains("~~")) {
						val=false;
						break;
					}
				}
			}*/

			
		} catch (SQLException e) {
			log.error("enableOrDisableSingleMulti || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAMETER_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("enableOrDisableSingleMulti || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("enableOrDisableSingleMulti || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("enableOrDisableSingleMulti || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("enableOrDisableSingleMulti || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return val;
	}
	
	public List<LdapMapping> getLdapMappingList(Connection conn)
			throws RepoproException {

		log.trace("getLdapMappingList || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		LdapMapping ldapMapping = null;
		List<LdapMapping> ldapMappingList = new ArrayList<LdapMapping>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingList || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_LDAP_MAPPING_LIST));
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingList || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_LDAP_MAPPING_LIST));
			}
			rs = pstmt.executeQuery();
			while(rs.next()){
				ldapMapping = new LdapMapping();

				ldapMapping.setLdapMappingId(rs.getInt("ldap_mapping_id"));
				ldapMapping.setMappingName(rs.getString("ldap_mapping_names"));
				ldapMappingList.add(ldapMapping);

			}
			if (log.isDebugEnabled()) {
				log.debug("getLdapMappingList || "+ ldapMappingList.toString());
			}

		} catch (SQLException e) {
			log.error("getLdapMappingList || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.LDAP_MAPPING_NOT_FOUND));
		} catch (IOException e) {
			log.error("getLdapMappingList || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getLdapMappingList || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getLdapMappingList || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingList || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getLdapMappingList || End");
		return ldapMappingList;
	}
	
	public List<LdapMapping> getLdapMappingAttributeList(int mappingId,Connection conn)
			throws RepoproException {

		log.trace("getLdapMappingAttributeList || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		LdapMapping ldapMapping = null;
		List<LdapMapping> ldapMappingList = new ArrayList<LdapMapping>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingAttributeList || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_LDAP_MAPPING_ATTRIBUTE_LIST_BY_MAPPING_ID));
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingAttributeList || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_LDAP_MAPPING_ATTRIBUTE_LIST_BY_MAPPING_ID));
			}
			pstmt.setInt(Constants.ONE,mappingId);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				ldapMapping = new LdapMapping();
				ldapMapping.setLdapAttributeId(rs.getInt("attribute_id"));
				ldapMapping.setLdapMappingId(rs.getInt("ldap_mapping_id"));
				ldapMapping.setAttributeName(rs.getString("ldap_mapping_attributes"));
				ldapMapping.setAttributeDisplayName(rs.getString("ldap_mapping_displayname"));
				ldapMappingList.add(ldapMapping);

			}
			if (log.isDebugEnabled()) {
				log.debug("getLdapMappingAttributeList || "+ ldapMappingList.toString());
			}

		} catch (SQLException e) {
			log.error("getLdapMappingAttributeList || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.LDAP_ATTRIBUTE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getLdapMappingAttributeList || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getLdapMappingAttributeList || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getLdapMappingAttributeList || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingAttributeList || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getLdapMappingAttributeList || End");
		return ldapMappingList;
	}
	
	public LdapMapping getLdapMappingAttributeByattributeId(int attributeId,Connection conn)
			throws RepoproException {

		log.trace("getLdapMappingAttributeByattributeId || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		LdapMapping ldapMapping = null;
		List<LdapMapping> ldapMappingList = new ArrayList<LdapMapping>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingAttributeByattributeId || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_LDAP_MAPPING_ATTRIBUTE_LIST_BY_ATTRIBUTE_ID));
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingAttributeByattributeId || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_LDAP_MAPPING_ATTRIBUTE_LIST_BY_ATTRIBUTE_ID));
			}
			pstmt.setInt(Constants.ONE,attributeId);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
				ldapMapping = new LdapMapping();
				ldapMapping.setLdapAttributeId(rs.getInt("attribute_id"));
				ldapMapping.setLdapMappingId(rs.getInt("ldap_mapping_id"));
				ldapMapping.setAttributeName(rs.getString("ldap_mapping_attributes"));
				ldapMapping.setAttributeDisplayName(rs.getString("ldap_mapping_displayname"));
			}
			
			if (log.isDebugEnabled()) {
				log.debug("getLdapMappingAttributeByattributeId || "+ ldapMappingList.toString());
			}

		} catch (SQLException e) {
			log.error("getLdapMappingAttributeByattributeId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.LDAP_ATTRIBUTE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getLdapMappingAttributeByattributeId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getLdapMappingAttributeByattributeId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getLdapMappingAttributeByattributeId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getLdapMappingAttributeByattributeId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		log.trace("getLdapMappingAttributeByattributeId || End");
		return ldapMapping;
	}
	
	
public List<AssetParamDef> getAllDerivedAttributeForAssetList(Connection conn) throws RepoproException{
		
		log.trace("getAllDerivedAttributeForAssetList || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		List<AssetParamDef> listOfDerivedAssetListAttributes = new ArrayList<AssetParamDef>();
		AssetParamDef paramDef = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllDerivedAttributeForAssetList || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_DERIVED_ATTRIBUTES_FOR_ASSETLIST));

			if (log.isTraceEnabled()) {
				log.trace("getAllDerivedAttributeForAssetList || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_DERIVED_ATTRIBUTES_FOR_ASSETLIST));
			}

			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				paramDef = new AssetParamDef();
				
				paramDef.setAssetParamId(rs.getLong("asset_param_id"));
				paramDef.setAssetCategoryId(rs.getLong("asset_category_id"));
				paramDef.setAssetParamName(rs.getString("asset_param_name"));
				paramDef.setDefaultView(rs.getInt("is_default_view"));
				paramDef.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				paramDef.setDescription(rs.getString("description"));
				paramDef.setDisplayPosition(rs.getInt("disp_position"));
				paramDef.setFileName(rs.getString("fileName"));
				paramDef.setSystemParam(rs.getBoolean("is_system_param"));
				paramDef.setStaticValue(rs.getString("static_val"));
				paramDef.setSize(rs.getInt("size"));
				paramDef.setHasImportantValue(rs.getBoolean("is_important"));
			    paramDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				paramDef.setQuickLink(rs.getBoolean("quick_link"));
				paramDef.setParamTypeId(rs.getLong("param_type_id"));
				paramDef.setListTypeParamTypeId(rs.getLong("list_param_type_id"));
				paramDef.setDerivedAssetListRule(rs.getString("derived_asset_list"));
				listOfDerivedAssetListAttributes.add(paramDef);
				if(log.isTraceEnabled()){
					log.trace("getAllDerivedAttributeForAssetList "+paramDef.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllDerivedAttributeForAssetList "+listOfDerivedAssetListAttributes);
			}

			log.debug("Successfully retrived the all Derived attributes "+listOfDerivedAssetListAttributes);


		} catch (SQLException e) {
			log.error("getAllDerivedAttributeForAssetList || " + Constants.LOG_UPDATE_SQLEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.DERIVED_ATTRIBUTES_NOT_SELECTED));
		} catch (IOException e) {
			log.error("getAllDerivedAttributeForAssetList || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllDerivedAttributeForAssetList || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllDerivedAttributeForAssetList || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllDerivedAttributeForAssetList || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAllDerivedAttributeForAssetList || End");
		}
		return listOfDerivedAssetListAttributes;
	}
	
	
	/*public List<AssetParamDef> getAssetListParameters(Connection conn) throws RepoproException{
		
		log.trace("getAssetListParameters || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		List<AssetParamDef> assetListParameters = new ArrayList<AssetParamDef>();
		AssetParamDef paramDef = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetListParameters || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ASSET_LIST_PARAMETERS));

			if (log.isTraceEnabled()) {
				log.trace("getAssetListParameters || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_ASSET_LIST_PARAMETERS));
			}

			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()){
				paramDef = new AssetParamDef();
				
				paramDef.setAssetParamId(rs.getLong("asset_param_id"));
				paramDef.setAssetCategoryId(rs.getLong("asset_category_id"));
				paramDef.setAssetParamName(rs.getString("asset_param_name"));
				paramDef.setDescription(rs.getString("description"));
				paramDef.setParamTypeId(rs.getLong("param_type_id"));
				paramDef.setListTypeParamTypeId(rs.getLong("list_param_type_id"));
				paramDef.setMappedAssetId(rs.getLong("mapped_asset_id"));
				paramDef.setSize(rs.getInt("size"));
				paramDef.setQuickLink(rs.getBoolean("quick_link"));
				paramDef.setDisplayPosition(rs.getInt("disp_position"));
				paramDef.setSystemParam(rs.getBoolean("is_system_param"));
				paramDef.setStaticValue(rs.getString("static_val"));
				paramDef.setHasImportantValue(rs.getBoolean("is_important"));
				paramDef.setDefaultView(rs.getInt("is_default_view"));
				paramDef.setFileName(rs.getString("fileName"));
				paramDef.setDerivedAttributeComputation(rs.getString("derived_computed_description"));
				paramDef.setDerivedAssetListRule(rs.getString("derived_asset_list"));
			    paramDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
				
				assetListParameters.add(paramDef);
				if(log.isTraceEnabled()){
					log.trace("getAssetListParameters "+paramDef.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAssetListParameters "+assetListParameters.toString());
			}

			log.debug("Successfully retrived the all assetlist attributes "+assetListParameters.toString());


		} catch (SQLException e) {
			log.error("getAssetListParameters || " + Constants.LOG_UPDATE_SQLEXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETLIST_PARAMETERS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetListParameters || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetListParameters || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAssetListParameters || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetListParameters || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAssetListParameters || End");
		}
		return assetListParameters;		
	}*/
	
	
	/**
	 * @method : modifyingDerivedAssetListRuleById
	 * @param assetParamId
	 * @param rule
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public int modifyingDerivedAssetListRuleById(String rule,Long assetParamId,Connection conn) throws RepoproException{

		if(log.isTraceEnabled()){
			log.trace("modifyingDerivedAssetListRuleById || Begin with assetParamId : "+ assetParamId);
		}
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		int result = 0;
		try {
			if (log.isTraceEnabled()){
				log.trace("modifyingDerivedAssetListRuleById || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_ASSET_PARAMETER_DEF_DERIVED_ASSET_LIST_RULE));

			pstmt.setString(Constants.ONE, rule);
			pstmt.setLong(Constants.TWO, assetParamId);
			result = pstmt.executeUpdate();

			if (log.isTraceEnabled()) {
				log.trace("modifyingDerivedAssetListRuleById || "+PropertyFileReader.getInstance().
						getValue(Constants.UPDATE_ASSET_PARAMETER_DEF_DERIVED_ASSET_LIST_RULE));
			}

			log.info("Successfully modified the derived attribute rule");
		} catch (SQLException e) {
			log.error("modifyingDerivedAssetListRuleById || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UPDATE_ASSET_PARAMETER_DEF_DERIVED_RULE_NOT_UPDATED));

		} catch (IOException e) {
			log.error("modifyingDerivedAssetListRuleById || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		} catch (PropertyVetoException e) {
			log.error("modifyingDerivedAssetListRuleById || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));

		} catch (Exception e) {
			log.error("modifyingDerivedAssetListRuleById || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());

		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("modifyingDerivedAssetListRuleById || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("modifyingDerivedAssetListRuleById || End");
		}
		return result;
	}
	
	public List<SavedSearch> getDefaultFilterSearch(Long assetId, String userName,int defaultUserFilterView,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getDefaultFilterSearch ||||assetId:" + assetId
					+ ",userName:" + userName +" defaultUserFilterView:"+defaultUserFilterView+ "Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		SavedSearch savedSearch = null;
		List<SavedSearch> searchList = new ArrayList<SavedSearch>();
		AssetDef assetDef = new AssetDef();
		try {
			assetDef = getAssetsByAssetId(assetId, conn1);
			if (log.isTraceEnabled()) {
				log.trace("getDefaultFilterSearch || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_DEFAULT_FILTER_SEARCH));
			pstmt.setString(Constants.ONE, assetDef.getAssetName());
			pstmt.setString(Constants.TWO, userName);
			pstmt.setInt(Constants.THREE, defaultUserFilterView);
			if (log.isTraceEnabled()) {
				log.trace("getDefaultFilterSearch || "+ PropertyFileReader.getInstance().getValue(Constants.GET_DEFAULT_FILTER_SEARCH));
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				savedSearch = new SavedSearch();
				savedSearch.setSearchId(rs.getLong("search_id"));
				savedSearch.setSearchName(rs.getString("search_name"));
				savedSearch.setParamsValue(rs.getString("params_value"));
				savedSearch.setOperatorsValue(rs.getString("operators_value"));
				savedSearch.setParam1Value(rs.getString("param1_value"));
				savedSearch.setLogicalSelectValue(rs
						.getString("logical_select_value"));
				savedSearch.setParam2Value(rs.getString("param2_value"));
				savedSearch.setTaxValue(rs.getString("taxonomy_value"));
				savedSearch.setDefaultUserFilterView(rs.getInt("default_User_FilterView"));
				savedSearch.setUserName(rs.getString("userName"));
				savedSearch.setAssetName(rs.getString("asset_name"));
				savedSearch.setAssetId(rs.getLong("asset_id"));
				searchList.add(savedSearch);
				if (log.isTraceEnabled()) {
					log.trace("getDefaultFilterSearch || " + savedSearch.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getDefaultFilterSearch || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.FILTER_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getDefaultFilterSearch || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getDefaultFilterSearch || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getDefaultFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getDefaultFilterSearch || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("getDefaultFilterSearch ||assetId:" + assetId + ",userName:"
					+ userName +" defaultUserFilterView:"+defaultUserFilterView+  " End");
		}
		return searchList;

	}
	
	public List<AssetParamDef> getParamRuleDetails(String userName, Long assetId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getParamRuleDetails ||userName:" + userName + " assetId:"
					+ assetId + " || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		AssetParamDef assetParamDef = null;
		List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParamRuleDetails || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (userName.equalsIgnoreCase("admin")) {
				preparedSt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_FOR_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getParamRuleDetails || "+ PropertyFileReader.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_FOR_ADMIN));
				}
				preparedSt.setLong(Constants.ONE, assetId);

				rs = preparedSt.executeQuery();

				while (rs.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(rs
							.getString("asset_param_name"));
					assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
					assetParamDef.setListTypeParamTypeId(rs
							.getLong("list_param_type_id"));
					assetParamDef.setHasImportantValue(rs
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(rs
							.getBoolean("is_default_view"));
					assetParamDef.setMappedAssetId(rs
							.getLong("mapped_asset_id"));
					assetParamDef.setTypeName(rs.getString("type_name"));
					assetParamDef.setHasArray(rs.getInt("isArray"));
					assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
					if (assetParamDef.getParamTypeId() != 4) {
						assetParamDefList.add(assetParamDef);
					}

					if (log.isTraceEnabled()) {
						log.trace("getParamRuleDetails || "	+ assetParamDef.toString());
					}
				}
				preparedStmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getParamRuleDetails || "+ PropertyFileReader
							.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN));
				}
				preparedStmt.setLong(Constants.ONE, assetId);

				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(resultSet
							.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(resultSet
							.getString("asset_param_name"));
					assetParamDef.setHasImportantValue(resultSet
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(resultSet.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(resultSet
							.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(resultSet
							.getBoolean("is_default_view"));
					assetParamDef.setListTypeParamTypeId(resultSet
							.getLong("list_param_type_id"));
					assetParamDef.setParamTypeId(resultSet
							.getLong("param_type_id"));
					assetParamDef.setTypeName(resultSet.getString("type_name"));
					assetParamDef.setListTypeName(resultSet
							.getString("list_type_name"));
					assetParamDef.setMappedAssetId(resultSet
							.getLong("mapped_asset_id"));
					assetParamDef.setAssetCategoryId(resultSet.getLong("asset_category_id"));
					assetParamDef.setHasArray(resultSet.getInt("isArray"));
					assetParamDefList.add(assetParamDef);

					if (log.isTraceEnabled()) {
						log.trace("getParamRuleDetails || "+ assetParamDef.toString());
					}
				}

			} else if (userName.equalsIgnoreCase("roleAnonymous")) {
				preparedSt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getParamRuleDetails || "+ PropertyFileReader.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_FOR_GUEST));
				}
				preparedSt.setLong(Constants.ONE, assetId);
				preparedSt.setString(Constants.TWO, Constants.GUEST);
				rs = preparedSt.executeQuery();

				while (rs.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(rs
							.getString("asset_param_name"));
					assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
					assetParamDef.setListTypeParamTypeId(rs
							.getLong("list_param_type_id"));
					assetParamDef.setHasImportantValue(rs
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(rs
							.getBoolean("is_default_view"));
					assetParamDef.setMappedAssetId(rs
							.getLong("mapped_asset_id"));
					assetParamDef.setTypeName(rs.getString("type_name"));
					assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
					assetParamDef.setHasArray(rs.getInt("isArray"));
					if (assetParamDef.getParamTypeId() != 4) {
						assetParamDefList.add(assetParamDef);
					}

					if (log.isTraceEnabled()) {
						log.trace("getParamRuleDetails || "+ assetParamDef.toString());
					}

				}
				preparedStmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "+ PropertyFileReader
							.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_GUEST));
				}
				preparedStmt.setLong(Constants.ONE, assetId);
				preparedStmt.setString(Constants.TWO, Constants.GUEST);
				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(resultSet
							.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(resultSet
							.getString("asset_param_name"));
					assetParamDef.setHasImportantValue(resultSet
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(resultSet.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(resultSet
							.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(resultSet
							.getBoolean("is_default_view"));
					assetParamDef.setListTypeParamTypeId(resultSet
							.getLong("list_param_type_id"));
					assetParamDef.setParamTypeId(resultSet
							.getLong("param_type_id"));
					assetParamDef.setTypeName(resultSet.getString("type_name"));
					assetParamDef.setListTypeName(resultSet
							.getString("list_type_name"));
					assetParamDef.setMappedAssetId(resultSet
							.getLong("mapped_asset_id"));
					assetParamDef.setAssetCategoryId(resultSet.getLong("asset_category_id"));
					assetParamDef.setHasArray(resultSet.getInt("isArray"));
					assetParamDefList.add(assetParamDef);
					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "+ assetParamDef.toString());
					}
				}

			} else {
				preparedSt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "+ PropertyFileReader
							.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN));
				}
				preparedSt.setLong(Constants.ONE, assetId);
				preparedSt.setString(Constants.TWO, userName);
				rs = preparedSt.executeQuery();

				while (rs.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(rs
							.getString("asset_param_name"));
					assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
					assetParamDef.setListTypeParamTypeId(rs
							.getLong("list_param_type_id"));
					assetParamDef.setHasImportantValue(rs
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(rs
							.getBoolean("is_default_view"));
					assetParamDef.setMappedAssetId(rs
							.getLong("mapped_asset_id"));
					assetParamDef.setTypeName(rs.getString("type_name"));
					assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
					assetParamDef.setHasArray(rs.getInt("isArray"));
					if (assetParamDef.getParamTypeId() != 4) {
						assetParamDefList.add(assetParamDef);
					}

					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "+ assetParamDef.toString());
					}

				}
				preparedStmt = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "+ PropertyFileReader
							.getInstance().getValue(Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN));
				}
				preparedStmt.setLong(Constants.ONE, assetId);
				preparedStmt.setString(Constants.TWO, userName);
				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(resultSet
							.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(resultSet
							.getString("asset_param_name"));
					assetParamDef.setHasImportantValue(resultSet
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(resultSet.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(resultSet
							.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(resultSet
							.getBoolean("is_default_view"));
					assetParamDef.setListTypeParamTypeId(resultSet
							.getLong("list_param_type_id"));
					assetParamDef.setParamTypeId(resultSet
							.getLong("param_type_id"));
					assetParamDef.setTypeName(resultSet.getString("type_name"));
					assetParamDef.setListTypeName(resultSet
							.getString("list_type_name"));
					assetParamDef.setMappedAssetId(resultSet
							.getLong("mapped_asset_id"));
					assetParamDef.setAssetCategoryId(resultSet.getLong("asset_category_id"));
					assetParamDef.setHasArray(resultSet.getInt("isArray"));
					assetParamDefList.add(assetParamDef);

					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "+ assetParamDef.toString());
					}
				}

			}

			if (log.isDebugEnabled()) {
				log.debug("getParamsDetails || " + assetParamDefList.toString());
			}
		} catch (SQLException e) {
			log.error("getParamsDetails ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_PARAM_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getParamsDetails ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getParamsDetails ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamsDetails ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getParamsDetails ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if (preparedStmt != null) {
					preparedStmt.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("getParamsDetails ||userName:" + userName + " assetId:"
					+ assetId + " ||exit");
		}
		return assetParamDefList;
	}
	
	public List<AivParamRule> addAivParamRule(List<AivParamRule> aivParamRule, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("addAivParamRule || " + aivParamRule.toString() + " Begin");
		}

		Connection conn1 = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("addAivParamRule || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			for(AivParamRule rule:aivParamRule) {
				if(rule.getActionForRuleSet().equalsIgnoreCase("DELETE")) {
					pst = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.DELETE_AIV_PARAMRULE));
					pst.setInt(Constants.ONE,rule.getParamRuleId());
					pst.executeUpdate();
					
				}else if(rule.getActionForRuleSet().equalsIgnoreCase("UPDATE")) {
					pst = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.UPDATE_AIV_PARAMRULE));
					pst.setString(Constants.ONE, rule.getParamRuleName());
					pst.setString(Constants.TWO, rule.getParamRuleValue());
					pst.setString(Constants.THREE, rule.getParamRuleOperatorValue());
					pst.setString(Constants.FOUR, rule.getParamRuleParam1Value());
					pst.setString(Constants.FIVE, rule.getParamRulelogicalOperators());
					pst.setInt(Constants.SIX, rule.getAssetId());
					pst.setString(Constants.SEVEN, rule.getUserName());
					pst.setInt(Constants.EIGHT, rule.getAivId());
					pst.setString(Constants.NINE, rule.getScheduler());
					pst.setInt(Constants.TEN, rule.getParamRuleId());
					pst.executeUpdate();
					
				}else if(rule.getActionForRuleSet().equalsIgnoreCase("ADD")) {
					pst = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.ADD_AIV_PARAMRULE));
					pst.setString(Constants.ONE, rule.getParamRuleName());
					pst.setString(Constants.TWO, rule.getParamRuleValue());
					pst.setString(Constants.THREE, rule.getParamRuleOperatorValue());
					pst.setString(Constants.FOUR, rule.getParamRuleParam1Value());
					pst.setString(Constants.FIVE, rule.getParamRulelogicalOperators());
					pst.setInt(Constants.SIX, rule.getAssetId());
					pst.setString(Constants.SEVEN, rule.getUserName());
					pst.setInt(Constants.EIGHT, rule.getAivId());
					pst.setString(Constants.NINE, rule.getScheduler());
					pst.executeUpdate();
					
					rs = pst.getGeneratedKeys();
					if (rs != null && rs.next()) {
						rule.setParamRuleId(rs.getInt(1));
					}
				}
			}
		} catch (SQLException e) {
			log.error("addAivParamRule || " + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_CREATED));
		} catch (IOException e) {
			log.error("addAivParamRule || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addAivParamRule || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pst);
			if (log.isTraceEnabled()) {
				log.trace("addAivParamRule || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);			
		}

		if (log.isTraceEnabled()) {
			log.trace("addAivParamRule || " + aivParamRule.toString() + " End");
		}
		return aivParamRule;
	}
	
	/*public void updateAivParamRule(AivParamRule aivParamRule, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("updateAivParamRule || " + aivParamRule.toString()+ "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("updateAivParamRule || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.UPDATE_AIV_PARAMRULE));

			pstmt.setString(Constants.ONE, aivParamRule.getParamRuleName());
			pstmt.setString(Constants.TWO, aivParamRule.getParamRuleValue());
			pstmt.setString(Constants.THREE, aivParamRule.getParamRuleOperatorValue());
			pstmt.setString(Constants.FOUR, aivParamRule.getParamRuleParam1Value());
			pstmt.setString(Constants.FIVE, aivParamRule.getParamRulelogicalOperators());
			pstmt.setString(Constants.SIX, aivParamRule.getAssetName());
			pstmt.setString(Constants.SEVEN, aivParamRule.getUserName());
			pstmt.setInt(Constants.EIGHT, aivParamRule.getAivId());
			pstmt.setString(Constants.NINE, aivParamRule.getScheduler());
			pstmt.setInt(Constants.TEN, aivParamRule.getParamRuleId());
			
			if (log.isTraceEnabled()) {
				log.trace("updateAivParamRule || "
						+ PropertyFileReader.getInstance().getValue(Constants.UPDATE_FILTERSEARCH));
			}

			int result = pstmt.executeUpdate();
			

		} catch (SQLException e) {
			log.error("updateAivParamRule || "
					+ Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateAivParamRule || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateAivParamRule || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateAivParamRule || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("updateAivParamRule ||" + aivParamRule.toString() + " End");
		}
	}*/
	public List<AivParamRule> getAivParamRule(String userName,int aivId, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAivParamRule || userName:" + userName+ " aivId:"+aivId+"|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AivParamRule aivParamRule = null;
		List<AivParamRule> aivParamRuleList = new ArrayList<AivParamRule>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_AIV_PARAMRULE_BY_USERNAME_AND_AIVID));

			pstmt.setString(Constants.ONE, userName);
			pstmt.setInt(Constants.TWO, aivId);
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "+ PropertyFileReader.getInstance().getValue(Constants.GET_AIV_PARAMRULE_BY_USERNAME_AND_AIVID));
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				aivParamRule = new AivParamRule();
				aivParamRule.setParamRuleId(rs.getInt("param_rule_id"));
				aivParamRule.setParamRuleName(rs.getString("param_rule_name"));
				aivParamRule.setParamRuleValue(rs.getString("param_rule_value"));
				aivParamRule.setParamRuleOperatorValue(rs.getString("param_rule_operator_value"));
				aivParamRule.setParamRulelogicalOperators(rs.getString("logical_select_value"));
				aivParamRule.setParamRuleParam1Value(rs.getString("param_rule_param1_value"));
				aivParamRule.setAssetId(rs.getInt("asset_id"));
				aivParamRule.setUserName(rs.getString("user_name"));
				aivParamRule.setAivId(rs.getInt("aivId"));
				aivParamRule.setScheduler(rs.getString("scheduler"));
				aivParamRuleList.add(aivParamRule);
				if (log.isTraceEnabled()) {
					log.trace("getAivParamRule || " + aivParamRule.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getAivParamRule || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAivParamRule || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAivParamRule || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getAivParamRule ||userName:" + userName+ " aivId:"+aivId+"|| End");
		}
		return aivParamRuleList;
	}
	
	public List<AivParamRule> getAivParamRuleByAivid(int aivId, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAivParamRuleByAivid ||aivId: " + aivId+ "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AivParamRule aivParamRule = null;
		List<AivParamRule> aivParamRuleList =  new ArrayList<AivParamRule>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleByAivid || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_AIV_PARAMRULE_BY_AIVID));

			pstmt.setInt(Constants.ONE, aivId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleByAivid || "+ PropertyFileReader.getInstance().getValue(Constants.GET_AIV_PARAMRULE_BY_AIVID));
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				aivParamRule = new AivParamRule();
				aivParamRule.setParamRuleId(rs.getInt("param_rule_id"));
				aivParamRule.setParamRuleName(rs.getString("param_rule_name"));
				aivParamRule.setParamRuleValue(rs.getString("param_rule_value"));
				aivParamRule.setParamRuleOperatorValue(rs.getString("param_rule_operator_value"));
				aivParamRule.setParamRulelogicalOperators(rs.getString("logical_select_value"));
				aivParamRule.setParamRuleParam1Value(rs.getString("param_rule_param1_value"));
				aivParamRule.setAssetId(rs.getInt("asset_id"));
				aivParamRule.setUserName(rs.getString("user_name"));
				aivParamRule.setAivId(rs.getInt("aivId"));
				aivParamRule.setScheduler(rs.getString("scheduler"));
				aivParamRuleList.add(aivParamRule);
				if (log.isTraceEnabled()) {
					log.trace("getAivParamRuleByAivid || " + aivParamRule.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getAivParamRuleByAivid || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAivParamRuleByAivid || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAivParamRuleByAivid || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAivParamRuleByAivid || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleByAivid || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getAivParamRuleByAivid ||aivId:" + aivId+ " End");
		}
		return aivParamRuleList;
	}
	
	public List<AssetParamDef> getParamsWithNotiFyEnabled(String userName, Long assetId,
			Connection conn) throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getParamsWithNotiFyEnabled ||userName:" + userName + " assetId:"
					+ assetId + " || begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet resultSet = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		AssetParamDef assetParamDef = null;
		List<AssetParamDef> assetParamDefList = new ArrayList<AssetParamDef>();

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getParamsWithNotiFyEnabled || "
						+ Constants.LOG_CONNECTION_OPEN);
			}

			if (userName.equalsIgnoreCase("admin")) {
				preparedSt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ALL_PARAM_DETAILS_FOR_ADMIN_WITH_NOTIFY_ENABLED));
				if (log.isTraceEnabled()) {
					log.trace("getParamsWithNotiFyEnabled || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ALL_PARAM_DETAILS_FOR_ADMIN_WITH_NOTIFY_ENABLED));
				}
				preparedSt.setLong(Constants.ONE, assetId);

				rs = preparedSt.executeQuery();

				while (rs.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(rs
							.getString("asset_param_name"));
					assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
					assetParamDef.setListTypeParamTypeId(rs
							.getLong("list_param_type_id"));
					assetParamDef.setHasImportantValue(rs
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(rs
							.getBoolean("is_default_view"));
					assetParamDef.setMappedAssetId(rs
							.getLong("mapped_asset_id"));
					assetParamDef.setTypeName(rs.getString("type_name"));
					assetParamDef.setHasArray(rs.getInt("isArray"));
					assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
					if (assetParamDef.getParamTypeId() != 4) {
						assetParamDefList.add(assetParamDef);
					}

					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "
								+ assetParamDef.toString());
					}

				}
				preparedStmt = conn
						.prepareStatement(PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN_WITH_NOTIFY_ENABLED));
				if (log.isTraceEnabled()) {
					log.trace("getParamsDetails || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_ADMIN_WITH_NOTIFY_ENABLED));
				}
				preparedStmt.setLong(Constants.ONE, assetId);

				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(resultSet
							.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(resultSet
							.getString("asset_param_name"));
					assetParamDef.setHasImportantValue(resultSet
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(resultSet.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(resultSet
							.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(resultSet
							.getBoolean("is_default_view"));
					assetParamDef.setListTypeParamTypeId(resultSet
							.getLong("list_param_type_id"));
					assetParamDef.setParamTypeId(resultSet
							.getLong("param_type_id"));
					assetParamDef.setTypeName(resultSet.getString("type_name"));
					assetParamDef.setListTypeName(resultSet
							.getString("list_type_name"));
					assetParamDef.setMappedAssetId(resultSet
							.getLong("mapped_asset_id"));
					assetParamDef.setAssetCategoryId(resultSet.getLong("asset_category_id"));
					assetParamDef.setHasArray(resultSet.getInt("isArray"));
					assetParamDef.setNotifyOnRuleValidate(resultSet.getBoolean("notify"));
					assetParamDefList.add(assetParamDef);

					if (log.isTraceEnabled()) {
						log.trace("getParamsDetails || "
								+ assetParamDef.toString());
					}
				}

			} else if (userName.equalsIgnoreCase("roleAnonymous")) {
				preparedSt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ALL_PARAM_DETAILS_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getParamsWithNotiFyEnabled || "
							+ PropertyFileReader.getInstance().getValue(
									Constants.GET_ALL_PARAM_DETAILS_FOR_GUEST));
				}
				preparedSt.setLong(Constants.ONE, assetId);
				preparedSt.setString(Constants.TWO, Constants.GUEST);
				rs = preparedSt.executeQuery();

				while (rs.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(rs
							.getString("asset_param_name"));
					assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
					assetParamDef.setListTypeParamTypeId(rs
							.getLong("list_param_type_id"));
					assetParamDef.setHasImportantValue(rs
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(rs
							.getBoolean("is_default_view"));
					assetParamDef.setMappedAssetId(rs
							.getLong("mapped_asset_id"));
					assetParamDef.setTypeName(rs.getString("type_name"));
					assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
					assetParamDef.setHasArray(rs.getInt("isArray"));
					if (assetParamDef.getParamTypeId() != 4) {
						assetParamDefList.add(assetParamDef);
					}

					if (log.isTraceEnabled()) {
						log.trace("getParamsWithNotiFyEnabled || "+ assetParamDef.toString());
					}

				}
				preparedStmt = conn
						.prepareStatement(PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_GUEST));
				if (log.isTraceEnabled()) {
					log.trace("getParamsWithNotiFyEnabled || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_GUEST));
				}
				preparedStmt.setLong(Constants.ONE, assetId);
				preparedStmt.setString(Constants.TWO, Constants.GUEST);
				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(resultSet
							.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(resultSet
							.getString("asset_param_name"));
					assetParamDef.setHasImportantValue(resultSet
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(resultSet.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(resultSet
							.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(resultSet
							.getBoolean("is_default_view"));
					assetParamDef.setListTypeParamTypeId(resultSet
							.getLong("list_param_type_id"));
					assetParamDef.setParamTypeId(resultSet
							.getLong("param_type_id"));
					assetParamDef.setTypeName(resultSet.getString("type_name"));
					assetParamDef.setListTypeName(resultSet
							.getString("list_type_name"));
					assetParamDef.setMappedAssetId(resultSet
							.getLong("mapped_asset_id"));
					assetParamDef.setAssetCategoryId(resultSet.getLong("asset_category_id"));
					assetParamDef.setHasArray(resultSet.getInt("isArray"));
					assetParamDef.setNotifyOnRuleValidate(resultSet.getBoolean("notify"));

					assetParamDefList.add(assetParamDef);
					if (log.isTraceEnabled()) {
						log.trace("getParamsWithNotiFyEnabled || "
								+ assetParamDef.toString());
					}
				}

			} else {
				preparedSt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(
								Constants.GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN_WITH_NOTIFY_ENABLED));
				if (log.isTraceEnabled()) {
					log.trace("getParamsWithNotiFyEnabled || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ALL_PARAM_DETAILS_FOR_NON_ADMIN_WITH_NOTIFY_ENABLED));
				}
				preparedSt.setLong(Constants.ONE, assetId);
				preparedSt.setString(Constants.TWO, userName);
				rs = preparedSt.executeQuery();

				while (rs.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(rs.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(rs
							.getString("asset_param_name"));
					assetParamDef.setParamTypeId(rs.getLong("param_type_id"));
					assetParamDef.setListTypeParamTypeId(rs
							.getLong("list_param_type_id"));
					assetParamDef.setHasImportantValue(rs
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(rs.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(rs.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(rs
							.getBoolean("is_default_view"));
					assetParamDef.setMappedAssetId(rs
							.getLong("mapped_asset_id"));
					assetParamDef.setTypeName(rs.getString("type_name"));
					assetParamDef.setAssetCategoryId(rs.getLong("asset_category_id"));
					assetParamDef.setHasArray(rs.getInt("isArray"));
					if (assetParamDef.getParamTypeId() != 4) {
						assetParamDefList.add(assetParamDef);
					}

					if (log.isTraceEnabled()) {
						log.trace("getParamsWithNotiFyEnabled || "
								+ assetParamDef.toString());
					}

				}
				preparedStmt = conn
						.prepareStatement(PropertyFileReader
								.getInstance()
								.getValue(
										Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN_WITH_NOTIFY_ENABLED));
				if (log.isTraceEnabled()) {
					log.trace("getParamsWithNotiFyEnabled || "
							+ PropertyFileReader
							.getInstance()
							.getValue(
									Constants.GET_ALL_PARAM_DETAILS_WITH_PARAM_TYPE_FOR_NON_ADMIN_WITH_NOTIFY_ENABLED));
				}
				preparedStmt.setLong(Constants.ONE, assetId);
				preparedStmt.setString(Constants.TWO, userName);
				resultSet = preparedStmt.executeQuery();

				while (resultSet.next()) {
					assetParamDef = new AssetParamDef();
					assetParamDef.setAssetParamId(resultSet
							.getLong("asset_param_id"));
					assetParamDef.setAssetParamName(resultSet
							.getString("asset_param_name"));
					assetParamDef.setHasImportantValue(resultSet
							.getBoolean("is_important"));
					assetParamDef.setHasMandatoryValue(resultSet.getBoolean("is_mandatory"));
					assetParamDef.setHasStaticValue(resultSet
							.getBoolean("is_static"));
					assetParamDef.setHasdefViewValue(resultSet
							.getBoolean("is_default_view"));
					assetParamDef.setListTypeParamTypeId(resultSet
							.getLong("list_param_type_id"));
					assetParamDef.setParamTypeId(resultSet
							.getLong("param_type_id"));
					assetParamDef.setTypeName(resultSet.getString("type_name"));
					assetParamDef.setListTypeName(resultSet
							.getString("list_type_name"));
					assetParamDef.setMappedAssetId(resultSet
							.getLong("mapped_asset_id"));
					assetParamDef.setAssetCategoryId(resultSet.getLong("asset_category_id"));
					assetParamDef.setHasArray(resultSet.getInt("isArray"));
					assetParamDef.setNotifyOnRuleValidate(resultSet.getBoolean("notify"));

					assetParamDefList.add(assetParamDef);

					if (log.isTraceEnabled()) {
						log.trace("getParamsWithNotiFyEnabled || "
								+ assetParamDef.toString());
					}
				}

			}

			if (log.isDebugEnabled()) {
				log.debug("getParamsWithNotiFyEnabled || " + assetParamDefList.toString());
			}
		} catch (SQLException e) {
			log.error("getParamsWithNotiFyEnabled ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.GET_PARAM_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getParamsWithNotiFyEnabled ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getParamsWithNotiFyEnabled ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getParamsWithNotiFyEnabled ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			DBConnection.closeResultSet(resultSet);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("getParamsWithNotiFyEnabled ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			try {
				if (preparedStmt != null) {
					preparedStmt.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("getParamsWithNotiFyEnabled ||userName:" + userName + " assetId:"
					+ assetId + " ||exit");
		}
		return assetParamDefList;
	}
	
	/*public void DeleteAivParamRule(int paramRuleId, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("DeleteAivParamRule || Begin with paramRuleId : " + paramRuleId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		List<String> msg = new ArrayList<String>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("DeleteAivParamRule || "+ Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.DELETE_AIV_PARAMRULE));

			pstmt.setLong(Constants.ONE, paramRuleId);

			if (log.isTraceEnabled()) {
				log.trace("DeleteAivParamRule || "
						+ PropertyFileReader.getInstance().getValue(Constants.DELETE_AIV_PARAMRULE));
			}

			int result = pstmt.executeUpdate();


		} catch (SQLException e) {
			log.error("DeleteAivParamRule || "
					+ Constants.LOG_DELETE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.PARAM_RULE_NOT_DELETED));
		} catch (IOException e) {
			log.error("DeleteAivParamRule || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteFilterSearch || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteFilterSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("DeleteAivParamRule || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}

		if (log.isTraceEnabled()) {
			log.trace("DeleteAivParamRule ||paramRuleId :" + paramRuleId + "||End");
		}
	}*/
	
	public AivParamRule getAivParamRuleByRuleName(int aivId,String ruleName,String userName,Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAivParamRuleByAivid ||aivId: " + aivId+ "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AivParamRule aivParamRule = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleByAivid || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_AIV_PARAMRULE_BY_AIVID_AND_RULENAME));

			pstmt.setInt(Constants.ONE, aivId);
			pstmt.setString(Constants.TWO, ruleName);
			pstmt.setString(Constants.THREE, userName);
			
			
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleByAivid || "+ PropertyFileReader.getInstance().getValue(Constants.GET_AIV_PARAMRULE_BY_AIVID));
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				aivParamRule = new AivParamRule();
				aivParamRule.setParamRuleId(rs.getInt("param_rule_id"));
				aivParamRule.setParamRuleName(rs.getString("param_rule_name"));
				aivParamRule.setParamRuleValue(rs.getString("param_rule_value"));
				aivParamRule.setParamRuleOperatorValue(rs.getString("param_rule_operator_value"));
				aivParamRule.setParamRulelogicalOperators(rs.getString("logical_select_value"));
				aivParamRule.setParamRuleParam1Value(rs.getString("param_rule_param1_value"));
				aivParamRule.setAssetId(rs.getInt("asset_id"));
				aivParamRule.setUserName(rs.getString("user_name"));
				aivParamRule.setAivId(rs.getInt("aivId"));
				aivParamRule.setScheduler(rs.getString("scheduler"));
				if (log.isTraceEnabled()) {
					log.trace("getAivParamRuleByAivid || " + aivParamRule.toString());
				}
			}
		} catch (SQLException e) {
			log.error("getAivParamRuleByAivid || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAivParamRuleByAivid || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAivParamRuleByAivid || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAivParamRuleByAivid || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleByAivid || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getAivParamRuleByAivid ||aivId:" + aivId+ " End");
		}
		return aivParamRule;
	}
	
	
	public List<AssetParamRule> getAllAssetParamRules(Long assetId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getAllAssetParamRules || Begin with assetId : "+assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetParamRule assetParamRule = null;
		List<AssetParamRule> paramRulesList = new ArrayList<AssetParamRule>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetParamRules || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			UserDao userDao = new UserDao();
						
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_PARAM_RULES));
			
			pstmt.setLong(Constants.ONE, assetId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetParamRules || " + PropertyFileReader.getInstance()
							.getValue(Constants.GET_ALL_ASSET_PARAM_RULES));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				assetParamRule = new AssetParamRule();
				assetParamRule.setParamRuleId(rs.getInt("asset_param_rule_id"));
				assetParamRule.setParamRuleName(rs.getString("asset_param_rule_name"));
				assetParamRule.setAssetParamName(rs.getString("asset_param_name"));
				assetParamRule.setOperatorValue(rs.getString("operators_value"));
				assetParamRule.setParam1Value(rs.getString("param1_value"));
				assetParamRule.setLogicalOperator(rs.getString("logical_operator"));
				assetParamRule.setParam2Value(rs.getString("param2_value"));
				assetParamRule.setAssetId(rs.getLong("asset_id"));
				assetParamRule.setScheduler(rs.getString("scheduler"));
				
				JSONArray jsonArray = new JSONArray(rs.getString("user_list"));
				assetParamRule.setSelectedUserIds(jsonArray);
				assetParamRule.setUserList(userDao.getUserStatusByUserId(jsonArray.join(","), conn));
				
				paramRulesList.add(assetParamRule);
				
				if(log.isTraceEnabled()) {
					log.trace("getAllAssetParamRules || "+assetParamRule.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllAssetParamRules || "+paramRulesList.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAllAssetParamRules || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAM_RULES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetParamRules || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetParamRules || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetParamRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetParamRules || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return paramRulesList;
	}
	
	
	public AssetParamRule getParamRuleDetails(Long paramRuleId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getParamRuleDetails || Begin with paramRuleId : "+paramRuleId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetParamRule assetParamRule = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getParamRuleDetails || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			UserDao userDao = new UserDao();
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_PARAM_RULE_DETAILS));
			
			pstmt.setLong(Constants.ONE, paramRuleId);
			
			if (log.isTraceEnabled()) {
				log.trace("getParamRuleDetails || " + PropertyFileReader.getInstance()
							.getValue(Constants.GET_PARAM_RULE_DETAILS));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				assetParamRule = new AssetParamRule();
				assetParamRule.setParamRuleId(rs.getInt("asset_param_rule_id"));
				assetParamRule.setParamRuleName(rs.getString("asset_param_rule_name"));
				assetParamRule.setAssetParamName(rs.getString("asset_param_name"));
				assetParamRule.setOperatorValue(rs.getString("operators_value"));
				assetParamRule.setParam1Value(rs.getString("param1_value"));
				assetParamRule.setLogicalOperator(rs.getString("logical_operator"));
				assetParamRule.setParam2Value(rs.getString("param2_value"));
				assetParamRule.setAssetId(rs.getLong("asset_id"));
				assetParamRule.setScheduler(rs.getString("scheduler"));

				JSONArray jsonArray = new JSONArray(rs.getString("user_list"));
				assetParamRule.setUserList(userDao.getUserStatusByUserId(jsonArray.join(","), conn));
				
				if(log.isTraceEnabled()) {
					log.trace("getParamRuleDetails || "+assetParamRule.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getParamRuleDetails || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAM_RULES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getParamRuleDetails || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getParamRuleDetails || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getParamRuleDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getParamRuleDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return assetParamRule;
	}
	
	
	public List<AssetParamRule> getParamRuleBasedOnSearch(Long assetId, String searchString, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getParamRuleBasedOnSearch || Begin with assetId : "+assetId+" \t searchString : "+searchString);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetParamRule assetParamRule = null;
		List<AssetParamRule> paramRulesList = new ArrayList<AssetParamRule>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getParamRuleBasedOnSearch || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			UserDao userDao = new UserDao();
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_PARAM_RULES_BASED_ON_SEARCH));
			
			pstmt.setLong(Constants.ONE, assetId);
			pstmt.setString(Constants.TWO, "%"+searchString+"%");
			
			if (log.isTraceEnabled()) {
				log.trace("getParamRuleBasedOnSearch || " + PropertyFileReader.getInstance()
							.getValue(Constants.GET_ALL_PARAM_RULES_BASED_ON_SEARCH));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				assetParamRule = new AssetParamRule();
				assetParamRule.setParamRuleId(rs.getInt("asset_param_rule_id"));
				assetParamRule.setParamRuleName(rs.getString("asset_param_rule_name"));
				assetParamRule.setAssetParamName(rs.getString("asset_param_name"));
				assetParamRule.setOperatorValue(rs.getString("operators_value"));
				assetParamRule.setParam1Value(rs.getString("param1_value"));
				assetParamRule.setLogicalOperator(rs.getString("logical_operator"));
				assetParamRule.setParam2Value(rs.getString("param2_value"));
				assetParamRule.setAssetId(rs.getLong("asset_id"));
				assetParamRule.setScheduler(rs.getString("scheduler"));
				
				JSONArray jsonArray = new JSONArray(rs.getString("user_list"));
				assetParamRule.setUserList(userDao.getUserStatusByUserId(jsonArray.join(","), conn));
				
				paramRulesList.add(assetParamRule);
				
				if(log.isTraceEnabled()) {
					log.trace("getParamRuleBasedOnSearch || "+assetParamRule.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllAssetParamRules || "+paramRulesList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getParamRuleBasedOnSearch || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAM_RULES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getParamRuleBasedOnSearch || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getParamRuleBasedOnSearch || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getParamRuleBasedOnSearch || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getParamRuleBasedOnSearch || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return paramRulesList;
	}
	
	
	public void saveParamRules(Long assetId, List<AssetParamRule> paramRulesList, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("saveParamRules || Begin with paramRulesList : "+paramRulesList.toString());
		}
		
		Connection conn1 = null;
		PreparedStatement pstmtAdd = null;
		PreparedStatement pstmtUpdate = null;
		PreparedStatement pstmtDelete = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("saveParamRules || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			/*pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_ASSET_PARAM_RULE));
			pstmt.setLong(Constants.ONE, assetId);

			if (log.isTraceEnabled()) {
				log.trace("saveParamRules || "+ PropertyFileReader.getInstance().getValue(Constants.DELETE_ASSET_PARAM_RULE));
			}
			pstmt.executeUpdate();*/
			
			/*pstmt1 = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.ADD_ASSET_PARAM_RULE));
			
			for(AssetParamRule rule : paramRulesList) {
				
				pstmt1.setString(Constants.ONE, rule.getParamRuleName());
				pstmt1.setString(Constants.TWO, rule.getAssetParamName());
				pstmt1.setString(Constants.THREE, rule.getOperatorValue());
				pstmt1.setString(Constants.FOUR, rule.getParam1Value());
				pstmt1.setString(Constants.FIVE, rule.getLogicalOperator());
				pstmt1.setString(Constants.SIX, rule.getParam2Value());
				pstmt1.setLong(Constants.SEVEN, rule.getAssetId());
				pstmt1.setString(Constants.EIGHT, rule.getScheduler());
				pstmt1.setString(Constants.NINE, Arrays.toString(rule.getUserIds()));

				if (log.isTraceEnabled()) {
					log.trace("saveParamRules || "+ PropertyFileReader.getInstance().getValue(Constants.ADD_ASSET_PARAM_RULE));
				}
				pstmt1.addBatch();
			}
			pstmt1.executeBatch();*/
			
			pstmtAdd = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.ADD_ASSET_PARAM_RULE));
			pstmtUpdate = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_ASSET_PARAM_RULE));
			pstmtDelete = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_ASSET_PARAM_RULE));
			
			for(AssetParamRule rule : paramRulesList) {
				
				if(rule.getActionForRule().equalsIgnoreCase("No Changes")) {
					
				}else if(rule.getActionForRule().equalsIgnoreCase("Add")) {
					
					pstmtAdd.setString(Constants.ONE, rule.getParamRuleName());
					pstmtAdd.setString(Constants.TWO, rule.getAssetParamName());
					pstmtAdd.setString(Constants.THREE, rule.getOperatorValue());
					pstmtAdd.setString(Constants.FOUR, rule.getParam1Value());
					pstmtAdd.setString(Constants.FIVE, rule.getLogicalOperator());
					pstmtAdd.setString(Constants.SIX, rule.getParam2Value());
					pstmtAdd.setLong(Constants.SEVEN, rule.getAssetId());
					pstmtAdd.setString(Constants.EIGHT, rule.getScheduler());
					pstmtAdd.setString(Constants.NINE, Arrays.toString(rule.getUserIds()));
					
					pstmtAdd.addBatch();
					
				}else if(rule.getActionForRule().equalsIgnoreCase("Update")) {
					
					pstmtUpdate.setString(Constants.ONE, rule.getParamRuleName());
					pstmtUpdate.setString(Constants.TWO, rule.getAssetParamName());
					pstmtUpdate.setString(Constants.THREE, rule.getOperatorValue());
					pstmtUpdate.setString(Constants.FOUR, rule.getParam1Value());
					pstmtUpdate.setString(Constants.FIVE, rule.getLogicalOperator());
					pstmtUpdate.setString(Constants.SIX, rule.getParam2Value());
					pstmtUpdate.setLong(Constants.SEVEN, rule.getAssetId());
					pstmtUpdate.setString(Constants.EIGHT, rule.getScheduler());
					pstmtUpdate.setString(Constants.NINE, Arrays.toString(rule.getUserIds()));
					pstmtUpdate.setLong(Constants.TEN, rule.getParamRuleId());
					
					pstmtUpdate.addBatch();
					
				}else if(rule.getActionForRule().equalsIgnoreCase("Delete")) {
					
					pstmtDelete.setLong(Constants.ONE, rule.getParamRuleId());
					pstmtDelete.addBatch();
				}
			}
			
			pstmtAdd.executeBatch();
			pstmtUpdate.executeBatch();
			pstmtDelete.executeBatch();
			
		} catch (SQLException e) {
			log.error("saveParamRules || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAM_RULES_NOT_SAVED));
		} catch (IOException e) {
			log.error("saveParamRules || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("saveParamRules || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("saveParamRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmtDelete);
			DBConnection.closePreparedStatement(pstmtUpdate);
			DBConnection.closePreparedStatement(pstmtAdd);
			if (log.isTraceEnabled()) {
				log.trace("saveParamRules || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
	}
	
	
	public List<AssetParamRule> getAllParamRules(Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getAllParamRules || Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AssetParamRule assetParamRule = null;
		List<AssetParamRule> paramRulesList = new ArrayList<AssetParamRule>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllParamRules || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			UserDao userDao = new UserDao();
						
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_PARAM_RULES));
						
			if (log.isTraceEnabled()) {
				log.trace("getAllParamRules || " + PropertyFileReader.getInstance()
							.getValue(Constants.GET_ALL_PARAM_RULES));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				assetParamRule = new AssetParamRule();
				assetParamRule.setParamRuleId(rs.getInt("asset_param_rule_id"));
				assetParamRule.setParamRuleName(rs.getString("asset_param_rule_name"));
				assetParamRule.setAssetParamName(rs.getString("asset_param_name"));
				assetParamRule.setOperatorValue(rs.getString("operators_value"));
				assetParamRule.setParam1Value(rs.getString("param1_value"));
				assetParamRule.setLogicalOperator(rs.getString("logical_operator"));
				assetParamRule.setParam2Value(rs.getString("param2_value"));
				assetParamRule.setAssetId(rs.getLong("asset_id"));
				assetParamRule.setScheduler(rs.getString("scheduler"));
				
				JSONArray jsonArray = new JSONArray(rs.getString("user_list"));
				assetParamRule.setSelectedUserIds(jsonArray);
				assetParamRule.setUserList(userDao.getUserStatusByUserId(jsonArray.join(","), conn));
				
				paramRulesList.add(assetParamRule);
				
				if(log.isTraceEnabled()) {
					log.trace("getAllParamRules || "+assetParamRule.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllParamRules || "+paramRulesList.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAllParamRules || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAM_RULES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllParamRules || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllParamRules || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllParamRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllParamRules || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return paramRulesList;
	}
	
	
	public AssetDef getAssetDetailsByAssetId(long assetId, Connection conn) throws RepoproException {

		log.trace("getAssetDetailsByAssetId || Begin");

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetDef assetDef = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetDetailsByAssetId || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSETS_BY_ASSET_ID));
			pstmt.setLong(Constants.ONE, assetId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetDetailsByAssetId || " + PropertyFileReader.getInstance().getValue(
								Constants.GET_ASSETS_BY_ASSET_ID));
			}

			rs = pstmt.executeQuery();

			while (rs.next()) {
				assetDef = new AssetDef();
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setAssetName(rs.getString("asset_name"));
				assetDef.setDescription(rs.getString("description"));
				assetDef.setIconImage(rs.getBinaryStream("icon_image"));
				assetDef.setSystemAsset(rs.getBoolean("is_system_asset"));
				assetDef.setVersionable(rs.getBoolean("versionable"));
				assetDef.setIconImageName(rs.getString("icon_image_name"));
				assetDef.setRatingDescription(rs.getString("rating_description"));
				assetDef.setIconImage(rs.getBinaryStream("icon_image"));
				assetDef.setIconImageName(rs.getString("icon_image_name"));
				
				if (log.isTraceEnabled()) {
					log.trace("getAssetDetailsByAssetId || " + assetDef.toString());
				}
			}

		} catch (SQLException e) {
			log.error("getAssetDetailsByAssetId || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetDetailsByAssetId || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetDetailsByAssetId || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetDetailsByAssetId || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetDetailsByAssetId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		log.trace("getAssetDetailsByAssetId || End");
		return assetDef;
	}
	public List<AivParamRule> getAllAivParamRules(Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAivParamRule || Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AivParamRule aivParamRule = null;
		List<AivParamRule> aivParamRuleList = new ArrayList<AivParamRule>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_ALL_AIV_PARAMRULES));

			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "+ PropertyFileReader.getInstance().getValue(Constants.GET_AIV_PARAMRULE_BY_USERNAME_AND_AIVID));
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				aivParamRule = new AivParamRule();
				aivParamRule.setParamRuleId(rs.getInt("param_rule_id"));
				aivParamRule.setParamRuleName(rs.getString("param_rule_name"));
				aivParamRule.setParamRuleValue(rs.getString("param_rule_value"));
				aivParamRule.setParamRuleOperatorValue(rs.getString("param_rule_operator_value"));
				aivParamRule.setParamRulelogicalOperators(rs.getString("logical_select_value"));
				aivParamRule.setParamRuleParam1Value(rs.getString("param_rule_param1_value"));
				aivParamRule.setAssetId(rs.getInt("asset_id"));
				aivParamRule.setUserName(rs.getString("user_name"));
				aivParamRule.setAivId(rs.getInt("aivId"));
				aivParamRule.setScheduler(rs.getString("scheduler"));
				aivParamRuleList.add(aivParamRule);
				if (log.isTraceEnabled()) {
					log.trace("getFilterList || " + aivParamRule.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getAivParamRule || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAivParamRule || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAivParamRule || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAivParamRule || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRule || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getAivParamRule || End");
		}
		return aivParamRuleList;
	}
	public List<AivParamRule> getAivParamRuleSets(String userName,int aivId, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAivParamRuleSets || userName:" + userName+ " aivId:"+aivId+"|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AivParamRule aivParamRule = null;
		List<AivParamRule> aivParamRuleList = new ArrayList<AivParamRule>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleSets || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_AIV_PARAMRULESETS_BY_USERNAME_AND_AIVID));

			pstmt.setString(Constants.ONE, userName);
			pstmt.setInt(Constants.TWO, aivId);
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleSets || "+ PropertyFileReader.getInstance().getValue(Constants.GET_AIV_PARAMRULE_BY_USERNAME_AND_AIVID));
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				aivParamRule = new AivParamRule();
				aivParamRule.setParamRuleId(rs.getInt("param_rule_id"));
				aivParamRule.setParamRuleName(rs.getString("param_rule_name"));
				
				aivParamRuleList.add(aivParamRule);
				if (log.isTraceEnabled()) {
					log.trace("getAivParamRuleSets || " + aivParamRule.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getAivParamRuleSets || "
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAivParamRuleSets || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAivParamRuleSets || "
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAivParamRuleSets || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRuleSets || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);

		}
		if (log.isTraceEnabled()) {
			log.trace("getAivParamRuleSets ||userName:" + userName+ " aivId:"+aivId+"|| End");
		}
		return aivParamRuleList;
	}
	
	
	public List<JSONObject> getAllAssetParamRulesUI(Long assetId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getAllAssetParamRulesUI || Begin with assetId : "+assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		JSONObject jsonObject = null;
		List<JSONObject> jsonObjectList = new ArrayList<JSONObject>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetParamRulesUI || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
						
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_ASSET_PARAM_RULES));
			
			pstmt.setLong(Constants.ONE, assetId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetParamRulesUI || " + PropertyFileReader.getInstance()
							.getValue(Constants.GET_ALL_ASSET_PARAM_RULES));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				jsonObject = new JSONObject();
				jsonObject.put("paramRuleId", rs.getInt("asset_param_rule_id"));
				jsonObject.put("paramRuleName", rs.getString("asset_param_rule_name"));
				jsonObjectList.add(jsonObject);
				
				if(log.isTraceEnabled()) {
					log.trace("getAllAssetParamRulesUI || "+jsonObject.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllAssetParamRulesUI || "+jsonObjectList.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAllAssetParamRulesUI || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAM_RULES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetParamRulesUI || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetParamRulesUI || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetParamRulesUI || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetParamRulesUI || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return jsonObjectList;
	}
	
	
	public List<AivParamRule> getAivParamRulesByUserName(String userName, Connection conn)throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAivParamRulesByUserName || userName:" + userName+ " || Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		AivParamRule aivParamRule = null;
		List<AivParamRule> aivParamRuleList = new ArrayList<AivParamRule>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRulesByUserName || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_AIV_PARAMRULE_BY_USERNAME));

			pstmt.setString(Constants.ONE, userName);
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRulesByUserName || "+ PropertyFileReader.getInstance()
					.getValue(Constants.GET_AIV_PARAMRULE_BY_USERNAME));
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				aivParamRule = new AivParamRule();
				aivParamRule.setParamRuleId(rs.getInt("param_rule_id"));
				aivParamRule.setParamRuleName(rs.getString("param_rule_name"));
				aivParamRule.setParamRuleValue(rs.getString("param_rule_value"));
				aivParamRule.setParamRuleOperatorValue(rs.getString("param_rule_operator_value"));
				aivParamRule.setParamRulelogicalOperators(rs.getString("logical_select_value"));
				aivParamRule.setParamRuleParam1Value(rs.getString("param_rule_param1_value"));
				aivParamRule.setAssetId(rs.getInt("asset_id"));
				aivParamRule.setUserName(rs.getString("user_name"));
				aivParamRule.setAivId(rs.getInt("aivId"));
				aivParamRule.setScheduler(rs.getString("scheduler"));
				aivParamRuleList.add(aivParamRule);
				if (log.isTraceEnabled()) {
					log.trace("getAivParamRulesByUserName || " + aivParamRule.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getAivParamRulesByUserName || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAivParamRulesByUserName || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAivParamRulesByUserName || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAivParamRulesByUserName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAivParamRulesByUserName || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAivParamRulesByUserName ||userName:" + userName+ " || End");
		}
		return aivParamRuleList;
	}
	
	
	public List<JSONObject> getAllMatchedAssetParamRules(Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getAllMatchedAssetParamRules || Begin");
		}
		
		Connection conn1 = null;
		Response response = null;
		String userName = "admin";
		
		AssetDao assetDao = new AssetDao();
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		WorkflowDao workflowDao = new WorkflowDao();
		AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
		
		List<Long> assetIds = new ArrayList<Long>();
		List<JSONObject> allMatchedRules = new ArrayList<JSONObject>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllMatchedAssetParamRules || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if(log.isTraceEnabled()) {
				log.trace("getAllMatchedAssetParamRules || calling getAllParamRules() method to get all the rules set at asset level");
			}
			List<AssetParamRule> allParamRules = assetDao.getAllParamRules(conn);
			for(AssetParamRule assetParamRule : allParamRules) {
				assetIds.add(assetParamRule.getAssetId());
			}
			
			Set<Long> uniqueAssetIds = new HashSet<Long>(assetIds);
			
			for(Long assetId : uniqueAssetIds) {
				if(log.isTraceEnabled()) {
					log.trace("getAllMatchedAssetParamRules || calling getAssetDetailsByAssetId() method to get asset details");
				}
				AssetDef assetDef = assetDao.getAssetDetailsByAssetId(assetId, conn);
				
				if(log.isTraceEnabled()) {
					log.trace("getAllMatchedAssetParamRules || calling getAllAssetParamRules() method to get rules by assetId");
				}
				List<AssetParamRule> allAssetParamRules = assetDao.getAllAssetParamRules(assetId, conn);
				
				if(log.isTraceEnabled()) {
					log.trace("getAllMatchedAssetParamRules || calling getAllAssetInstancesForAsset() method to get all instances of the asset");
				}
				List<AssetInstance> allAssetInstances = assetInstanceDao.getAllAssetInstancesForAsset(assetId, conn);
				for(AssetInstance ai : allAssetInstances) {
					if(log.isTraceEnabled()) {
						log.trace("getAllMatchedAssetParamRules || calling getAssetInstancePropertiesDetails() method to get the properties");
					}
					response = aivManager.getAssetInstancePropertiesDetails(userName, assetDef.getAssetName(),ai.getAssetInstVersionId());
					
					MyModel res = (MyModel) response.getEntity();
			        List<Object> data = res.getResult();
					
					String paramId = "";String typeId = "";
					
					for(AssetParamRule apr : allAssetParamRules) {
						boolean resultFlag = true;
						
						String[] paramName = apr.getAssetParamName().split("~");
						String[] operator = apr.getOperatorValue().split("~");
						String[] param1Value = apr.getParam1Value().split("~");
						String[] logicalOperator = apr.getLogicalOperator().split("~");
						
						for(int k1=0;k1<paramName.length;k1++) {
							boolean notifyFlag = false;

							String[] param = paramName[k1].split("_");
							paramId = param[0];
							typeId = param[1];
							
							if(paramId.equals("0")) {//workflow
								if(log.isTraceEnabled()) {
									log.trace("getAllMatchedAssetParamRules || calling getWorkflowDetailsForAsset() method to get the workflow associated with the asset");
								}
								Workflow workflowDetails = workflowDao.getWorkflowDetailsForAsset(assetId, conn);
								if(workflowDetails != null) {
									if(log.isTraceEnabled()) {
										log.trace("getAllMatchedAssetParamRules || calling getStateIdByStateName() method to get the stateId based on the state name");
									}
									Long stateId = workflowDao.getStateIdByStateName(workflowDetails.getJsonStructure(), param1Value[k1], conn);
									
									if(log.isTraceEnabled()) {
										log.trace("getAllMatchedAssetParamRules || calling getAssetInstancesByState() method to get the instances that are at same state");
									}
									List<AssetInstance> instancesList = workflowDao.getAssetInstancesByState(ai.getAssetInstVersionId(), stateId, operator[k1], conn);
									if(!instancesList.isEmpty()) {
										notifyFlag = true;
									}
								}
								
							}else {//parameter
						        for (int i=0; i<data.size();i++) {
						        	AssetInstanceVersion aiv = new AssetInstanceVersion();
						        	aiv = (AssetInstanceVersion) data.get(i);
						        	
						        	if(aiv.getParamTypeId() == 5 && typeId.equals("5") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
						        		
						        		String paramValue = "";
						        		String derivedAttrVals = aiv.getParamValue();
										String[] derval = derivedAttrVals.split("`!!`");
										derivedAttrVals = derval[1];

										if(derivedAttrVals.contains("``")) {
											if(derivedAttrVals.contains("~~")){
												derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
											}
											if(derivedAttrVals.contains("``")){
												derivedAttrVals = derivedAttrVals.replaceAll("``", ",");
											}
											if(derivedAttrVals.contains("`~`")){
												derivedAttrVals = derivedAttrVals.replace("`~`", ",");
											}
										}else {
											if(derivedAttrVals.contains("~~")){
												derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
											}
											if(derivedAttrVals.contains("`~`")){
												derivedAttrVals=derivedAttrVals.replace("`~`", ",");
											}
										}
										
										paramValue = derivedAttrVals.trim();
										List<String> paramValueList = new ArrayList<String>();
										if(derivedAttrVals.contains(",")) {
											String[] paramValuewithtagList = paramValue.split(",");
											for(String val:paramValuewithtagList) {
												String textdata = Jsoup.parse(val).text();//convert html data to normal data
												paramValueList.add(textdata);
											}
										}else {
											paramValue = Jsoup.parse(derivedAttrVals.trim()).text();
										}
																				
										if(param1Value[k1].contains("/,")) {
											if(!paramValueList.isEmpty()) {
												String[] ruleParamValue = param1Value[k1].split("/,");

												int count = 0;
												for(int i1=0;i1<ruleParamValue.length;i1++) {
													for(int j=0;j<paramValueList.size();j++) {
														int compare = paramValueList.get(j).compareTo(ruleParamValue[i1]);
														if(operator[k1].equals("like")) {
															if(paramValueList.get(j).contains(ruleParamValue[i1]))count++;
														}else if(operator[k1].equals("not like")) {
															if(!paramValueList.get(j).contains(ruleParamValue[i1]))count++;
														}else if(operator[k1].equals("=")) {
															if(compare == 0)count++;
														}else if(operator[k1].equals("!=")) {
															if(compare != 0)count++;
														}
														if(count == ruleParamValue.length){
															notifyFlag=true;break;
														}
													}
													if(notifyFlag)break;
												}
											}else {
												int compare = paramValue.compareTo(param1Value[k1]);
												if(operator[k1].equals("like")) {
													if(paramValue.contains(param1Value[k1]))notifyFlag=true;
												}else if(operator[k1].equals("not like")) {
													if(!paramValue.contains(param1Value[k1]))notifyFlag=true;
												}else if(operator[k1].equals("=")) {
													if(compare == 0)notifyFlag=true;
												}else if(operator[k1].equals("!=")) {
													if(compare != 0)notifyFlag=true;
												}
											}
										}else {
											if(!paramValueList.isEmpty()) {
												String[] ruleParamValue = param1Value[k1].split("/,");

												int count = 0;
												for(int i1=0;i1<ruleParamValue.length;i1++) {
													for(int j=0;j<paramValueList.size();j++) {
														int compare = paramValueList.get(j).compareTo(ruleParamValue[i1]);
														if(operator[k1].equals("like")) {
															if(paramValueList.get(j).contains(ruleParamValue[i1]))count++;
														}else if(operator[k1].equals("not like")) {
															if(!paramValueList.get(j).contains(ruleParamValue[i1]))count++;
														}else if(operator[k1].equals("=")) {
															if(compare == 0)count++;
														}else if(operator[k1].equals("!=")) {
															if(compare != 0)count++;
														}
														if(count == ruleParamValue.length){
															notifyFlag=true;break;
														}
													}
													if(notifyFlag)break;
												}
											}else {
												int compare = paramValue.compareTo(param1Value[k1]);
												if(operator[k1].equals("like")) {
													if(paramValue.contains(param1Value[k1]))notifyFlag=true;
												}else if(operator[k1].equals("not like")) {
													if(!paramValue.contains(param1Value[k1]))notifyFlag=true;
												}else if(operator[k1].equals("=")) {
													if(compare == 0)notifyFlag=true;
												}else if(operator[k1].equals("!=")) {
													if(compare != 0)notifyFlag=true;
												}
											}
										}
										if(notifyFlag)break;
						        		
						        	}else if(aiv.getParamTypeId() == 6 && typeId.equals("6") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
						        		
						        		String derivedCompVal = aiv.getParamValue();
						        		int compare = derivedCompVal.compareTo(param1Value[k1]);
										if(operator[k1].equals("=")) {
											if(compare == 0)notifyFlag = true;
										}else if(operator[k1].equals("!=")) {
											if(compare != 0)notifyFlag = true;
										}
										if(notifyFlag)break;
						        		
						        	}else if(aiv.getParamTypeId() == 8 && typeId.equals("8") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
						        		
						        		String paramValue = "";
						        		String derivedAssetListValue = aiv.getParamValue();
										String finalValue = "";
										String[] data1 = derivedAssetListValue.split("`!!`");
										if(data1[0].equalsIgnoreCase("0")) {
											if(data1.length == 2){
												finalValue = data1[1];
											}else{
												finalValue = ""; 
											}
										}else {
											if(data1.length == 2){
												finalValue = data1[1];
											}else{
												finalValue = ""; 
											}
										}
										if(finalValue.contains("``")) {
											if(finalValue.contains("~~")){
												finalValue = finalValue.replaceAll("~~", ",");
											}
											if(finalValue.contains("``")){
												finalValue = finalValue.replaceAll("``", ",");
											}
											if(finalValue.contains("`~`")){
												finalValue = finalValue.replace("`~`", ",");
											}
										}else {
											if(finalValue.contains("~~")){
												finalValue = finalValue.replaceAll("~~", ",");
											}

											if(finalValue.contains("`~`")){
												finalValue = finalValue.replace("`~`", ",");
											}
										}
										
										paramValue = finalValue;
										List<String> paramValueList = new ArrayList<String>();
										if(finalValue.contains(",")) {
											String[] paramValuewithtagList = paramValue.split(",");
											for(String val:paramValuewithtagList) {
												String textdata = Jsoup.parse(val).text();//convert html data to normal data
												paramValueList.add(textdata);
											}
										}else {
											paramValue = Jsoup.parse(finalValue.trim()).text();
										}
																				
										if(param1Value[k1].contains("/,")) {
											if(!paramValueList.isEmpty()) {
												String[] ruleParamValue = param1Value[k1].split("/,");

												int count = 0;
												for(int i1=0;i1<ruleParamValue.length;i1++) {
													for(int j=0;j<paramValueList.size();j++) {
														int compare = paramValueList.get(j).compareTo(ruleParamValue[i1]);
														if(operator[k1].equals("like")) {
															if(paramValueList.get(j).contains(ruleParamValue[i1]))count++;
														}else if(operator[k1].equals("not like")) {
															if(!paramValueList.get(j).contains(ruleParamValue[i1]))count++;
														}else if(operator[k1].equals("=")) {
															if(compare == 0)count++;
														}else if(operator[k1].equals("!=")) {
															if(compare != 0)count++;
														}
														if(count == ruleParamValue.length){
															notifyFlag=true;break;
														}
													}
													if(notifyFlag)break;
												}
											}else {
												int compare = paramValue.compareTo(param1Value[k1]);
												if(operator[k1].equals("like")) {
													if(paramValue.contains(param1Value[k1]))notifyFlag=true;
												}else if(operator[k1].equals("not like")) {
													if(!paramValue.contains(param1Value[k1]))notifyFlag=true;
												}else if(operator[k1].equals("=")) {
													if(compare == 0)notifyFlag=true;
												}else if(operator[k1].equals("!=")) {
													if(compare != 0)notifyFlag=true;
												}
											}
										}else {
											if(!paramValueList.isEmpty()) {
												String[] ruleParamValue = param1Value[k1].split("/,");

												int count = 0;
												for(int i1=0;i1<ruleParamValue.length;i1++) {
													for(int j=0;j<paramValueList.size();j++) {
														int compare = paramValueList.get(j).compareTo(ruleParamValue[i1]);
														if(operator[k1].equals("like")) {
															if(paramValueList.get(j).contains(ruleParamValue[i1]))count++;
														}else if(operator[k1].equals("not like")) {
															if(!paramValueList.get(j).contains(ruleParamValue[i1]))count++;
														}else if(operator[k1].equals("=")) {
															if(compare == 0)count++;
														}else if(operator[k1].equals("!=")) {
															if(compare != 0)count++;
														}
														if(count == ruleParamValue.length){
															notifyFlag=true;break;
														}
													}
													if(notifyFlag)break;
												}
											}else {
												int compare = paramValue.compareTo(param1Value[k1]);
												if(operator[k1].equals("like")) {
													if(paramValue.contains(param1Value[k1]))notifyFlag=true;
												}else if(operator[k1].equals("not like")) {
													if(!paramValue.contains(param1Value[k1]))notifyFlag=true;
												}else if(operator[k1].equals("=")) {
													if(compare == 0)notifyFlag=true;
												}else if(operator[k1].equals("!=")) {
													if(compare != 0)notifyFlag=true;
												}
											}
										}
										if(notifyFlag)break;
						        		
						        	}else if(aiv.getParamTypeId() == 1 && typeId.equals("1") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
						        		
						        		List<String> paramValueList = new ArrayList<String>();
						        		if(aiv.getHasArray() == 1) {
						        			paramValueList = aiv.getTextDataList();
						        			String[] ruleParamValue = param1Value[k1].split("/,");
							        		int count = 0;
							        		if(paramValueList != null) {
							        			for(int i1 =0;i1<ruleParamValue.length;i1++) {
							        				for(String value : paramValueList) {
							        					int compare = value.compareTo(ruleParamValue[i1]);
							        					if(operator[k1].equals(">")) {
							        						if(compare > 0)count++;
							        					}else if(operator[k1].equals("<")) {
							        						if(compare < 0)count++;
							        					}else if(operator[k1].equals("=")) {
							        						if(compare == 0)count++;
							        					}else if(operator[k1].equals("!=")) {
							        						if(compare != 0)count++;
							        					}else if(operator[k1].equals(">=")) {
							        						if(compare == 0 || compare > 0)count++;
							        					}else if(operator[k1].equals("<=")) {
							        						if(compare == 0 || compare < 0)count++;
							        					}
							        					if(count == ruleParamValue.length){
										        			notifyFlag=true;break;
										        		}
							        				}
							        				if(notifyFlag)break;
							        			}
							        		}
							        		
						        		}else {
						        			String paramValue = "";
						        			if(aiv.getIsStatic() == 1) {
						        				paramValue = aiv.getStaticValue();
						        			}else {
						        				paramValue = aiv.getParamValue();
						        			}
						        			String[] ruleParamValue = param1Value[k1].split("/,");
							        		int count = 0;
							        		if(paramValue != null) {
							        			for(int i1=0;i1<ruleParamValue.length;i1++) {
							        				int compare = paramValue.compareTo(ruleParamValue[i1]);
							        				if(operator[k1].equals(">")) {
							        					if(compare > 0)count++;
							        				}else if(operator[k1].equals("<")) {
							        					if(compare < 0)count++;
							        				}else if(operator[k1].equals("=")) {
							        					if(compare == 0)count++;
							        				}else if(operator[k1].equals("!=")) {
							        					if(compare != 0)count++;
							        				}else if(operator[k1].equals(">=")) {
							        					if(compare == 0 || compare > 0)count++;
							        				}else if(operator[k1].equals("<=")) {
							        					if(compare == 0 || compare < 0)count++;
							        				}
							        				if(count == ruleParamValue.length){
									        			notifyFlag=true;break;
									        		}
							        			}
							        			if(notifyFlag)break;
							        		}
							        		
						        		}
						        		if(notifyFlag)break;
						        		
						        		
						        	}else if(aiv.getParamTypeId() == 7 && typeId.equals("7") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
						        		
						        		String paramValue = "";
						        		List<String> paramValueList = new ArrayList<String>();
						        		if(aiv.getHasArray() == 1) {
						        			paramValueList = aiv.getRTFwithOutTags();
						        			String[] ruleParamValue = param1Value[k1].split("/,");
							        		int count = 0;
							        		if(paramValueList != null) {
							        			for(int i1=0;i1<ruleParamValue.length;i1++) {
							        				for(String value : paramValueList) {
							        					int compare = value.compareTo(ruleParamValue[i1]);
							        					if(operator[k1].equals("like")) {
							        						if(value.contains(ruleParamValue[i1]))count++;
							        					}else if(operator[k1].equals("not like")) {
							        						if(!value.contains(ruleParamValue[i1]))count++;
							        					}else if(operator[k1].equals("=")) {
							        						if(compare == 0) count++;
							        					}else if(operator[k1].equals("!=")) {
							        						if(compare != 0) count++;
							        					}
							        					if(count == ruleParamValue.length){
										        			notifyFlag=true;break;
										        		}
							        				}
							        				if(notifyFlag)break;
							        			}
							        		}
							        		
						        		}else {
						        			paramValue = aiv.getRTFPlainText();
						        			String[] ruleParamValue = param1Value[k1].split("/,");
							        		int count = 0;
							        		if(paramValue != null) {
							        			for(int i1=0;i1<ruleParamValue.length;i1++) {
							        				int compare = paramValue.compareTo(ruleParamValue[i1]);
							        				if(operator[k1].equals("like")) {
							        					if(paramValue.contains(ruleParamValue[i1]))count++;
							        				}else if(operator[k1].equals("not like")) {
							        					if(!paramValue.contains(ruleParamValue[i1]))count++;
							        				}else if(operator[k1].equals("=")) {
							        					if(compare == 0) count++;
							        				}else if(operator[k1].equals("!=")) {
							        					if(compare != 0) count++;
							        				}
							        				if(count == ruleParamValue.length){
									        			notifyFlag=true;break;
									        		}
							        			}
							        		}
						        		}
						        		if(notifyFlag)break;
						        		
						        	}else if(aiv.getParamTypeId() == 2 && typeId.equals("2") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
						        		
						        		String paramValue = "";
						        		if(aiv.getIsStatic() == 1) {
						        			paramValue = aiv.getStaticValue();
						        		}else {
						        			paramValue = aiv.getParamValue();
						        		}
						        		if(paramValue != null) {
						        			int compare = paramValue.compareTo(param1Value[k1]);
						        			if(operator[k1].equals(">")) {
						        				if(compare > 0)notifyFlag=true;
						        			}else if(operator[k1].equals("<")) {
						        				if(compare < 0)notifyFlag=true;
						        			}else if(operator[k1].equals("=")) {
						        				if(compare == 0)notifyFlag=true;
						        			}else if(operator[k1].equals("!=")) {
						        				if(compare != 0)notifyFlag=true;
						        			}else if(operator[k1].equals(">=")) {
						        				if(compare == 0 || compare > 0)notifyFlag=true;
						        			}else if(operator[k1].equals("<=")) {
						        				if(compare == 0 || compare < 0)notifyFlag=true;
						        			}
						        		}
										if(notifyFlag)break;
						        		
						        	}else if(aiv.getParamTypeId() == 4 && typeId.equals("4") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
						        		
						        		String paramValue = "";
						        		if(aiv.getIsStatic() == 1) {
						        			paramValue = aiv.getStaticValue();
						        		}else {
						        			paramValue = aiv.getParamValue();
						        		}
						        		int count = 0;
						        		String[] ruleParamValue = param1Value[k1].split("/,");
						        		List<String> paramValueList = new ArrayList<>();
						        		if(paramValue != null) {
						        			paramValueList = Arrays.asList(paramValue.split("~~"));
						        			for(int i1=0;i1<ruleParamValue.length;i1++) {
						        				for(String value : paramValueList) {
						        					int compare = value.compareTo(ruleParamValue[i1]);
						        					if(operator[k1].equals("=")) {
						        						if(compare == 0){
						        							count++;
						        						}
						        					}else if(operator[k1].equals("!=")) {
						        						if(compare != 0) {
						        							count++;
						        						}
						        					}
						        					if(count == ruleParamValue.length){
									        			notifyFlag=true;break;
									        		}
						        				}
						        				if(notifyFlag)break;
						        			}
						        		}
						        		if(notifyFlag)break;
						        		
						        	}else if(aiv.getParamTypeId() == 9 && typeId.equals("9") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
						        		
						        		String[] ruleParamValue = param1Value[k1].split("/,");
						        		List<String> ldapMappingList = new ArrayList<String>();
						        		
						        		if(aiv.getLdapMappingList() != null) {
						        			for (String val : aiv.getLdapMappingList()) {
						        				String[] ldapmappingval = val.split("~~");
						        				for(String ldapdata : ldapmappingval) {
						        					ldapMappingList.add(ldapdata);
						        				}
						        			}
						        		}
						        		
						        		int count = 0;
						        		if(ldapMappingList != null) {
						        			for(int i1=0;i1<ruleParamValue.length;i1++) {
						        				for(String value : ldapMappingList) {
						        					int compare = value.compareTo(ruleParamValue[i1]);
						        					if(operator[k1].equals("like")) {
						        						if(value.contains(ruleParamValue[i1]))count++;
						        					}else if(operator[k1].equals("not like")) {
						        						if(!value.contains(ruleParamValue[i1]))count++;
						        					}else if(operator[k1].equals("=")) {
						        						if(compare == 0) count++;
						        					}else if(operator[k1].equals("!=")) {
						        						if(compare != 0) count++;
						        					}
						        					if(count == ruleParamValue.length){
						        						notifyFlag=true;break;
						        					}
						        				}
						        				if(notifyFlag)break;
						        			}
						        		}
						        		if(notifyFlag)break;
						        	}
						        }
						        
							}
							if(k1==0) {
								resultFlag = notifyFlag;
							}
							if(k1>0) {
								if (logicalOperator[k1-1].equalsIgnoreCase("or")) {
									resultFlag = resultFlag || notifyFlag;
							    } else {
							    	resultFlag = resultFlag && notifyFlag;
							    }
							}
//							
						}
						
						if(resultFlag) {
							JSONObject jsonObject = new JSONObject();
							String msg = apr.getParamRuleName()+" has met the rule for "+assetDef.getAssetName();
							jsonObject.put("rule", msg);
							jsonObject.put("assetId", assetId);
							jsonObject.put("assetName", assetDef.getAssetName());
							allMatchedRules.add(jsonObject);
						}
						
					}
				}
				
			}
			
			
		} catch (SQLException e) {
			log.error("getAllMatchedAssetParamRules || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.PARAM_RULES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllMatchedAssetParamRules || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllMatchedAssetParamRules || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllMatchedAssetParamRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllMatchedAssetParamRules || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return allMatchedRules;
	}
	
	
	public List<JSONObject> getAllMatchedAivParamRules(String userName, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getAllMatchedAivParamRules || Begin with userName : "+userName);
		}
		
		Connection conn1 = null;
		Response response = null;
		
		AssetDao assetDao = new AssetDao();
		WorkflowDao workflowDao = new WorkflowDao();
		AssetInstanceVersionsManager aivManager = new AssetInstanceVersionsManager();
		AssetInstanceVersionDao aivDao = new AssetInstanceVersionDao();
		
		List<JSONObject> allMatchedRules = new ArrayList<JSONObject>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllMatchedAivParamRules || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			if(log.isTraceEnabled()) {
				log.trace("getAllMatchedAivParamRules || calling getAivParamRulesByUserName() method to get the rules by userName");
			}
			List<Integer> aivIds = getAivIdsForAivParamRuleByUserName(userName, conn);
			
			for(Integer aivId : aivIds) {
				if(log.isTraceEnabled()) {
					log.trace("getAllMatchedAivParamRules || calling getAivParamRuleByAivid() method to get the rules by aivId");
				}
				List<AivParamRule> allAivParamRules = assetDao.getAivParamRule(userName, aivId, conn);
				
				if(log.isTraceEnabled()) {
					log.trace("getAllMatchedAivParamRules || calling getAssetInstanceVersionDetails() method to get the version details");
				}
				AssetInstanceVersion aivDetails = aivDao.getAssetInstanceVersionDetails(aivId, conn);
				
				if(log.isTraceEnabled()) {
					log.trace("getAllMatchedAivParamRules || calling getAssetInstancePropertiesDetails() method to get the properties");
				}
				response = aivManager.getAssetInstancePropertiesDetails(userName, aivDetails.getAssetName(), aivId.longValue());
				
				MyModel res = (MyModel) response.getEntity();
		        List<Object> data = res.getResult();
		        
				String paramId = "";String typeId = "";
				
				for(AivParamRule apr : allAivParamRules) {

					boolean resultFlag = true;
										
					String[] paramName = apr.getParamRuleValue().split("~~");
					String[] operator = apr.getParamRuleOperatorValue().split("~~");
					String[] param1Value = apr.getParamRuleParam1Value().split("~~");
					String[] logicalOperator = apr.getParamRulelogicalOperators().split("~~");
					
					for(int k1=0;k1<paramName.length;k1++) {
						boolean notifyFlag = false;

						String[] param = paramName[k1].split("_");
						paramId = param[0];
						typeId = param[1];
						
						if(paramId.equals("0")) {//workflow
							if(log.isTraceEnabled()) {
								log.trace("getAllMatchedAivParamRules || calling getWorkflowDetailsForAsset() method to get the workflow associated with the asset");
							}
							Workflow workflowDetails = workflowDao.getWorkflowDetailsForAsset(aivDetails.getAssetId(), conn);
							if(workflowDetails != null) {
								if(log.isTraceEnabled()) {
									log.trace("getAllMatchedAivParamRules || calling getStateIdByStateName() method to get the stateId based on the state name");
								}
								Long stateId = workflowDao.getStateIdByStateName(workflowDetails.getJsonStructure(), param1Value[k1], conn);
								
								if(log.isTraceEnabled()) {
									log.trace("getAllMatchedAivParamRules || calling getAssetInstancesByState() method to get the instances that are at same state");
								}
								List<AssetInstance> instancesList = workflowDao.getAssetInstancesByState(aivId.longValue(), stateId, operator[k1], conn);
								if(!instancesList.isEmpty()) {
									notifyFlag = true;
								}
							}
							
						}else {//parameter
					        for (int i=0; i<data.size();i++) {
					        	AssetInstanceVersion aiv = new AssetInstanceVersion();
					        	aiv = (AssetInstanceVersion) data.get(i);
					        	
					        	if(aiv.getParamTypeId() == 5 && typeId.equals("5") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
					        		
					        		String paramValue = "";
					        		String derivedAttrVals = aiv.getParamValue();
									String[] derval = derivedAttrVals.split("`!!`");
									derivedAttrVals = derval[1];

									if(derivedAttrVals.contains("``")) {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}
										if(derivedAttrVals.contains("``")){
											derivedAttrVals = derivedAttrVals.replaceAll("``", ",");
										}
										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals = derivedAttrVals.replace("`~`", ",");
										}
									}else {
										if(derivedAttrVals.contains("~~")){
											derivedAttrVals = derivedAttrVals.replaceAll("~~", ",");
										}
										if(derivedAttrVals.contains("`~`")){
											derivedAttrVals=derivedAttrVals.replace("`~`", ",");
										}
									}
									
									paramValue = derivedAttrVals.trim();
									List<String> paramValueList = new ArrayList<String>();
									if(derivedAttrVals.contains(",")) {
										String[] paramValuewithtagList = paramValue.split(",");
										for(String val:paramValuewithtagList) {
											String textdata = Jsoup.parse(val).text();//convert html data to normal data
											paramValueList.add(textdata);
										}
									}else {
										paramValue = Jsoup.parse(derivedAttrVals.trim()).text();
									}
																			
									if(param1Value[k1].contains("/,")) {
										if(!paramValueList.isEmpty()) {
											String[] ruleParamValue = param1Value[k1].split("/,");

											int count = 0;
											for(int i1=0;i1<ruleParamValue.length;i1++) {
												for(int j=0;j<paramValueList.size();j++) {
													int compare = paramValueList.get(j).compareTo(ruleParamValue[i1]);
													if(operator[k1].equals("like")) {
														if(paramValueList.get(j).contains(ruleParamValue[i1]))count++;
													}else if(operator[k1].equals("not like")) {
														if(!paramValueList.get(j).contains(ruleParamValue[i1]))count++;
													}else if(operator[k1].equals("=")) {
														if(compare == 0)count++;
													}else if(operator[k1].equals("!=")) {
														if(compare != 0)count++;
													}
													if(count == ruleParamValue.length){
														notifyFlag=true;break;
													}
												}
												if(notifyFlag)break;
											}
										}else {
											int compare = paramValue.compareTo(param1Value[k1]);
											if(operator[k1].equals("like")) {
												if(paramValue.contains(param1Value[k1]))notifyFlag=true;
											}else if(operator[k1].equals("not like")) {
												if(!paramValue.contains(param1Value[k1]))notifyFlag=true;
											}else if(operator[k1].equals("=")) {
												if(compare == 0)notifyFlag=true;
											}else if(operator[k1].equals("!=")) {
												if(compare != 0)notifyFlag=true;
											}
										}
									}else {
										if(!paramValueList.isEmpty()) {
											String[] ruleParamValue = param1Value[k1].split("/,");

											int count = 0;
											for(int i1=0;i1<ruleParamValue.length;i1++) {
												for(int j=0;j<paramValueList.size();j++) {
													int compare = paramValueList.get(j).compareTo(ruleParamValue[i1]);
													if(operator[k1].equals("like")) {
														if(paramValueList.get(j).contains(ruleParamValue[i1]))count++;
													}else if(operator[k1].equals("not like")) {
														if(!paramValueList.get(j).contains(ruleParamValue[i1]))count++;
													}else if(operator[k1].equals("=")) {
														if(compare == 0)count++;
													}else if(operator[k1].equals("!=")) {
														if(compare != 0)count++;
													}
													if(count == ruleParamValue.length){
														notifyFlag=true;break;
													}
												}
												if(notifyFlag)break;
											}
										}else {
											int compare = paramValue.compareTo(param1Value[k1]);
											if(operator[k1].equals("like")) {
												if(paramValue.contains(param1Value[k1]))notifyFlag=true;
											}else if(operator[k1].equals("not like")) {
												if(!paramValue.contains(param1Value[k1]))notifyFlag=true;
											}else if(operator[k1].equals("=")) {
												if(compare == 0)notifyFlag=true;
											}else if(operator[k1].equals("!=")) {
												if(compare != 0)notifyFlag=true;
											}
										}
									}
									if(notifyFlag)break;
					        		
					        	}else if(aiv.getParamTypeId() == 6 && typeId.equals("6") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
					        		
					        		String derivedCompVal = aiv.getParamValue();
					        		int compare = derivedCompVal.compareTo(param1Value[k1]);
									if(operator[k1].equals("=")) {
										if(compare == 0)notifyFlag = true;
									}else if(operator[k1].equals("!=")) {
										if(compare != 0)notifyFlag = true;
									}
									if(notifyFlag)break;
					        		
					        	}else if(aiv.getParamTypeId() == 8 && typeId.equals("8") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
					        		
					        		String paramValue = "";
					        		String derivedAssetListValue = aiv.getParamValue();
									String finalValue = "";
									String[] data1 = derivedAssetListValue.split("`!!`");
									if(data1[0].equalsIgnoreCase("0")) {
										if(data1.length == 2){
											finalValue = data1[1];
										}else{
											finalValue = ""; 
										}
									}else {
										if(data1.length == 2){
											finalValue = data1[1];
										}else{
											finalValue = ""; 
										}
									}
									if(finalValue.contains("``")) {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}
										if(finalValue.contains("``")){
											finalValue = finalValue.replaceAll("``", ",");
										}
										if(finalValue.contains("`~`")){
											finalValue = finalValue.replace("`~`", ",");
										}
									}else {
										if(finalValue.contains("~~")){
											finalValue = finalValue.replaceAll("~~", ",");
										}

										if(finalValue.contains("`~`")){
											finalValue = finalValue.replace("`~`", ",");
										}
									}
									
									paramValue = finalValue;
									List<String> paramValueList = new ArrayList<String>();
									if(finalValue.contains(",")) {
										String[] paramValuewithtagList = paramValue.split(",");
										for(String val:paramValuewithtagList) {
											String textdata = Jsoup.parse(val).text();//convert html data to normal data
											paramValueList.add(textdata);
										}
									}else {
										paramValue = Jsoup.parse(finalValue.trim()).text();
									}
																			
									if(param1Value[k1].contains("/,")) {
										if(!paramValueList.isEmpty()) {
											String[] ruleParamValue = param1Value[k1].split("/,");

											int count = 0;
											for(int i1=0;i1<ruleParamValue.length;i1++) {
												for(int j=0;j<paramValueList.size();j++) {
													int compare = paramValueList.get(j).compareTo(ruleParamValue[i1]);
													if(operator[k1].equals("like")) {
														if(paramValueList.get(j).contains(ruleParamValue[i1]))count++;
													}else if(operator[k1].equals("not like")) {
														if(!paramValueList.get(j).contains(ruleParamValue[i1]))count++;
													}else if(operator[k1].equals("=")) {
														if(compare == 0)count++;
													}else if(operator[k1].equals("!=")) {
														if(compare != 0)count++;
													}
													if(count == ruleParamValue.length){
														notifyFlag=true;break;
													}
												}
												if(notifyFlag)break;
											}
										}else {
											int compare = paramValue.compareTo(param1Value[k1]);
											if(operator[k1].equals("like")) {
												if(paramValue.contains(param1Value[k1]))notifyFlag=true;
											}else if(operator[k1].equals("not like")) {
												if(!paramValue.contains(param1Value[k1]))notifyFlag=true;
											}else if(operator[k1].equals("=")) {
												if(compare == 0)notifyFlag=true;
											}else if(operator[k1].equals("!=")) {
												if(compare != 0)notifyFlag=true;
											}
										}
									}else {
										if(!paramValueList.isEmpty()) {
											String[] ruleParamValue = param1Value[k1].split("/,");

											int count = 0;
											for(int i1=0;i1<ruleParamValue.length;i1++) {
												for(int j=0;j<paramValueList.size();j++) {
													int compare = paramValueList.get(j).compareTo(ruleParamValue[i1]);
													if(operator[k1].equals("like")) {
														if(paramValueList.get(j).contains(ruleParamValue[i1]))count++;
													}else if(operator[k1].equals("not like")) {
														if(!paramValueList.get(j).contains(ruleParamValue[i1]))count++;
													}else if(operator[k1].equals("=")) {
														if(compare == 0)count++;
													}else if(operator[k1].equals("!=")) {
														if(compare != 0)count++;
													}
													if(count == ruleParamValue.length){
														notifyFlag=true;break;
													}
												}
												if(notifyFlag)break;
											}
										}else {
											int compare = paramValue.compareTo(param1Value[k1]);
											if(operator[k1].equals("like")) {
												if(paramValue.contains(param1Value[k1]))notifyFlag=true;
											}else if(operator[k1].equals("not like")) {
												if(!paramValue.contains(param1Value[k1]))notifyFlag=true;
											}else if(operator[k1].equals("=")) {
												if(compare == 0)notifyFlag=true;
											}else if(operator[k1].equals("!=")) {
												if(compare != 0)notifyFlag=true;
											}
										}
									}
									if(notifyFlag)break;
					        		
					        	}else if(aiv.getParamTypeId() == 1 && typeId.equals("1") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
					        		
					        		List<String> paramValueList = new ArrayList<String>();
					        		if(aiv.getHasArray() == 1) {
					        			paramValueList = aiv.getTextDataList();
					        			String[] ruleParamValue = param1Value[k1].split("/,");
						        		int count = 0;
						        		if(paramValueList != null) {
						        			for(int i1 =0;i1<ruleParamValue.length;i1++) {
						        				for(String value : paramValueList) {
						        					int compare = value.compareTo(ruleParamValue[i1]);
						        					if(operator[k1].equals(">")) {
						        						if(compare > 0)count++;
						        					}else if(operator[k1].equals("<")) {
						        						if(compare < 0)count++;
						        					}else if(operator[k1].equals("=")) {
						        						if(compare == 0)count++;
						        					}else if(operator[k1].equals("!=")) {
						        						if(compare != 0)count++;
						        					}else if(operator[k1].equals(">=")) {
						        						if(compare == 0 || compare > 0)count++;
						        					}else if(operator[k1].equals("<=")) {
						        						if(compare == 0 || compare < 0)count++;
						        					}
						        					if(count == ruleParamValue.length){
									        			notifyFlag=true;break;
									        		}
						        				}
						        				if(notifyFlag)break;
						        			}
						        		}
						        		
					        		}else {
					        			String paramValue = "";
					        			if(aiv.getIsStatic() == 1) {
					        				paramValue = aiv.getStaticValue();
					        			}else {
					        				paramValue = aiv.getParamValue();
					        			}
					        			String[] ruleParamValue = param1Value[k1].split("/,");
						        		int count = 0;
						        		if(paramValue != null) {
						        			for(int i1=0;i1<ruleParamValue.length;i1++) {
						        				int compare = paramValue.compareTo(ruleParamValue[i1]);
						        				if(operator[k1].equals(">")) {
						        					if(compare > 0)count++;
						        				}else if(operator[k1].equals("<")) {
						        					if(compare < 0)count++;
						        				}else if(operator[k1].equals("=")) {
						        					if(compare == 0)count++;
						        				}else if(operator[k1].equals("!=")) {
						        					if(compare != 0)count++;
						        				}else if(operator[k1].equals(">=")) {
						        					if(compare == 0 || compare > 0)count++;
						        				}else if(operator[k1].equals("<=")) {
						        					if(compare == 0 || compare < 0)count++;
						        				}
						        				if(count == ruleParamValue.length){
								        			notifyFlag=true;break;
								        		}
						        			}
						        			if(notifyFlag)break;
						        		}
						        		
					        		}
					        		if(notifyFlag)break;
					        		
					        		
					        	}else if(aiv.getParamTypeId() == 7 && typeId.equals("7") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
					        		
					        		String paramValue = "";
					        		List<String> paramValueList = new ArrayList<String>();
					        		if(aiv.getHasArray() == 1) {
					        			paramValueList = aiv.getRTFwithOutTags();
					        			String[] ruleParamValue = param1Value[k1].split("/,");
						        		int count = 0;
						        		if(paramValueList != null) {
						        			for(int i1=0;i1<ruleParamValue.length;i1++) {
						        				for(String value : paramValueList) {
						        					int compare = value.compareTo(ruleParamValue[i1]);
						        					if(operator[k1].equals("like")) {
						        						if(value.contains(ruleParamValue[i1]))count++;
						        					}else if(operator[k1].equals("not like")) {
						        						if(!value.contains(ruleParamValue[i1]))count++;
						        					}else if(operator[k1].equals("=")) {
						        						if(compare == 0) count++;
						        					}else if(operator[k1].equals("!=")) {
						        						if(compare != 0) count++;
						        					}
						        					if(count == ruleParamValue.length){
									        			notifyFlag=true;break;
									        		}
						        				}
						        				if(notifyFlag)break;
						        			}
						        		}
						        		
					        		}else {
					        			paramValue = aiv.getRTFPlainText();
					        			String[] ruleParamValue = param1Value[k1].split("/,");
						        		int count = 0;
						        		if(paramValue != null) {
						        			for(int i1=0;i1<ruleParamValue.length;i1++) {
						        				int compare = paramValue.compareTo(ruleParamValue[i1]);
						        				if(operator[k1].equals("like")) {
						        					if(paramValue.contains(ruleParamValue[i1]))count++;
						        				}else if(operator[k1].equals("not like")) {
						        					if(!paramValue.contains(ruleParamValue[i1]))count++;
						        				}else if(operator[k1].equals("=")) {
						        					if(compare == 0) count++;
						        				}else if(operator[k1].equals("!=")) {
						        					if(compare != 0) count++;
						        				}
						        				if(count == ruleParamValue.length){
								        			notifyFlag=true;break;
								        		}
						        			}
						        		}
					        		}
					        		if(notifyFlag)break;
					        		
					        	}else if(aiv.getParamTypeId() == 2 && typeId.equals("2") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
					        		
					        		String paramValue = "";
					        		if(aiv.getIsStatic() == 1) {
					        			paramValue = aiv.getStaticValue();
					        		}else {
					        			paramValue = aiv.getParamValue();
					        		}
					        		if(paramValue != null) {
					        			int compare = paramValue.compareTo(param1Value[k1]);
					        			if(operator[k1].equals(">")) {
					        				if(compare > 0)notifyFlag=true;
					        			}else if(operator[k1].equals("<")) {
					        				if(compare < 0)notifyFlag=true;
					        			}else if(operator[k1].equals("=")) {
					        				if(compare == 0)notifyFlag=true;
					        			}else if(operator[k1].equals("!=")) {
					        				if(compare != 0)notifyFlag=true;
					        			}else if(operator[k1].equals(">=")) {
					        				if(compare == 0 || compare > 0)notifyFlag=true;
					        			}else if(operator[k1].equals("<=")) {
					        				if(compare == 0 || compare < 0)notifyFlag=true;
					        			}
					        		}
									if(notifyFlag)break;
					        		
					        	}else if(aiv.getParamTypeId() == 4 && typeId.equals("4") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
					        		
					        		String paramValue = "";
					        		if(aiv.getIsStatic() == 1) {
					        			paramValue = aiv.getStaticValue();
					        		}else {
					        			paramValue = aiv.getParamValue();
					        		}
					        		int count = 0;
					        		String[] ruleParamValue = param1Value[k1].split("/,");
					        		List<String> paramValueList = new ArrayList<>();
					        		if(paramValue != null) {
					        			paramValueList = Arrays.asList(paramValue.split("~~"));
					        			for(int i1=0;i1<ruleParamValue.length;i1++) {
					        				for(String value : paramValueList) {
					        					int compare = value.compareTo(ruleParamValue[i1]);
					        					if(operator[k1].equals("=")) {
					        						if(compare == 0){
					        							count++;
					        						}
					        					}else if(operator[k1].equals("!=")) {
					        						if(compare != 0) {
					        							count++;
					        						}
					        					}
					        					if(count == ruleParamValue.length){
								        			notifyFlag=true;break;
								        		}
					        				}
					        				if(notifyFlag)break;
					        			}
					        		}
					        		if(notifyFlag)break;
					        		
					        	}else if(aiv.getParamTypeId() == 9 && typeId.equals("9") && aiv.getAssetParamId().equals(Long.valueOf(paramId))) {
					        		
					        		String[] ruleParamValue = param1Value[k1].split("/,");
					        		List<String> ldapMappingList = new ArrayList<String>();
					        		
					        		if(aiv.getLdapMappingList() != null) {
					        			for (String val : aiv.getLdapMappingList()) {
					        				String[] ldapmappingval = val.split("~~");
					        				for(String ldapdata : ldapmappingval) {
					        					ldapMappingList.add(ldapdata);
					        				}
					        			}
					        		}
					        		
					        		int count = 0;
					        		if(ldapMappingList != null) {
					        			for(int i1=0;i1<ruleParamValue.length;i1++) {
					        				for(String value : ldapMappingList) {
					        					int compare = value.compareTo(ruleParamValue[i1]);
					        					if(operator[k1].equals("like")) {
					        						if(value.contains(ruleParamValue[i1]))count++;
					        					}else if(operator[k1].equals("not like")) {
					        						if(!value.contains(ruleParamValue[i1]))count++;
					        					}else if(operator[k1].equals("=")) {
					        						if(compare == 0) count++;
					        					}else if(operator[k1].equals("!=")) {
					        						if(compare != 0) count++;
					        					}
					        					if(count == ruleParamValue.length){
					        						notifyFlag=true;break;
					        					}
					        				}
					        				if(notifyFlag)break;
					        			}
					        		}
					        		if(notifyFlag)break;
					        	}
					        }
					        
						}
						if(k1==0) {
							resultFlag = notifyFlag;
						}
						if(k1>0) {
							if (logicalOperator[k1-1].equalsIgnoreCase("or")) {
								resultFlag = resultFlag || notifyFlag;
						    } else {
						    	resultFlag = resultFlag && notifyFlag;
						    }
						}
						
					}
					
					if(resultFlag) {
						JSONObject jsonObject = new JSONObject();
						String msg = apr.getParamRuleName()+" has met the rule for "+aivDetails.getAssetInstName();
						jsonObject.put("rule", msg);
						jsonObject.put("aivId", aivId);
						jsonObject.put("assetInstanceName", aivDetails.getAssetInstName());
						allMatchedRules.add(jsonObject);
					}
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getAllMatchedAivParamRules || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllMatchedAivParamRules || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllMatchedAivParamRules || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllMatchedAivParamRules || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllMatchedAivParamRules || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return allMatchedRules;
	}
	
	
	public List<Integer> getAivIdsForAivParamRuleByUserName(String userName, Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("getAivIdsForAivParamRuleByUserName || userName:" + userName+ " || Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<Integer> aivParamRuleList = new ArrayList<Integer>();
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAivIdsForAivParamRuleByUserName || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance()
					.getValue(Constants.GET_AIVIDS_FOR_AIV_PARAMRULE_BY_USERNAME));

			pstmt.setString(Constants.ONE, userName);
			if (log.isTraceEnabled()) {
				log.trace("getAivIdsForAivParamRuleByUserName || "+ PropertyFileReader.getInstance()
					.getValue(Constants.GET_AIVIDS_FOR_AIV_PARAMRULE_BY_USERNAME));
			}

			rs = pstmt.executeQuery();
			while (rs.next()) {
				aivParamRuleList.add(rs.getInt("aivId"));
				if (log.isTraceEnabled()) {
					log.trace("getAivIdsForAivParamRuleByUserName || " + aivParamRuleList.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getAivIdsForAivParamRuleByUserName || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.AIV_PARAM_RULE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAivIdsForAivParamRuleByUserName || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAivIdsForAivParamRuleByUserName || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAivIdsForAivParamRuleByUserName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAivIdsForAivParamRuleByUserName || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getAivIdsForAivParamRuleByUserName ||userName:" + userName+ " || End");
		}
		return aivParamRuleList;
	
		
	}
}