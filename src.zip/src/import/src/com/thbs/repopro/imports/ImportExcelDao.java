package com.thbs.repopro.imports;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.ShowHideColumn;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class ImportExcelDao {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	public int getCountOfLockedIds(Connection conn) throws RepoproException {
		if (log.isTraceEnabled()) {
			log.trace("getCountOfLockedIds ||begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedSt = null;
		ResultSet rs = null;
		int lockCount = 0;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			if (log.isTraceEnabled()) {
				log.trace("getCountOfLockedIds || "+ Constants.LOG_CONNECTION_OPEN);
			}
			
			preparedSt = conn.prepareStatement(
					PropertyFileReader.getInstance().getValue(Constants.GET_COUNT_OF_LOCKED_ASSET_INSTANCE_VERSION_ID));
			if (log.isTraceEnabled()) {
				log.trace("getCountOfLockedIds || "
						+ PropertyFileReader.getInstance().getValue(Constants.GET_COUNT_OF_LOCKED_ASSET_INSTANCE_VERSION_ID));
			}
			rs = preparedSt.executeQuery();

			while (rs.next()) {
				lockCount = rs.getInt("count(asset_instance_version_id)"); 
				if (log.isTraceEnabled()) {
					log.trace("getCountOfLockedIds || "+lockCount);
				}
			}
			
		} catch (SQLException e) {
			log.error("getCountOfLockedIds ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.GET_SHOWHIDE_COLUMN_DETAILS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("getCountOfLockedIds ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("getCountOfLockedIds ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
					.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("v ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedSt);
			if (log.isTraceEnabled()) {
				log.trace("getCountOfLockedIds ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("getCountOfLockedIds||exit");
		}

		return lockCount;
	}
	

}
