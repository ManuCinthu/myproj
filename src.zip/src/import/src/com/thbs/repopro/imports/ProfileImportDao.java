package com.thbs.repopro.imports;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProfileImportDao {
	private final static Logger log = LoggerFactory.getLogger("timeBased");
	
	
	
}
