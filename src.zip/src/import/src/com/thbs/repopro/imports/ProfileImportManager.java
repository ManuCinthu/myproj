package com.thbs.repopro.imports;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.GroupDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.GroupDetails;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.EncryptPassword;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;

@Path("/profileImport")
@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA })
@Consumes({ MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
public class ProfileImportManager {
	
	private final static Logger log = LoggerFactory.getLogger("timeBased");
	/**
	 * @method profileImport
	 * @description to import profile details
	 * @param userName
	 * @param formParams
	 * @return success response
	 * @throws RepoproException
	 */
	@POST
	@Path("/importExcelSheet")
	public Response profileImport(@QueryParam("userName") String userName,FormDataMultiPart formParams){
		if (log.isTraceEnabled()) {
			log.trace("profileImport ||userName:"+userName+"||Begin");
		}
		
		UserDao userDao = new UserDao();
		Connection conn = null;
		Long stTime = System.currentTimeMillis();
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Runtime r = Runtime.getRuntime();
		try{
			if (log.isTraceEnabled()) {
				log.trace("profileImport || "+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			FormDataBodyPart dataMultiPart = formParams.getField("importdata");
			
			InputStream inputstream = dataMultiPart.getEntityAs(InputStream.class);
			if (log.isTraceEnabled()) {
				log.trace("profileImport ||dao call of getProfileForUserName() method to get loggedin user profile");
			}
	        User user = userDao.retProfileForUserName(userName, conn);
	        
	        if (log.isTraceEnabled()) {
				log.trace("profileImport ||dao call of setProfileImportData() method");
			}
			setProfileImportData(conn,inputstream,user.getEmailId());
			
		
		retMsg = Constants.IMPORT_DONE;
		retScsFlr = Constants.SUCCESS;
		retStat = Status.OK;
		retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
	    }catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("profileImport || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if (log.isTraceEnabled()) {
			log.trace("profileImport ||userName:"+userName+"||End");
		}
		r.gc();
		return Response.status(retStat).entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
				
	}
	
	/**
	 * @method setProfileImportData
	 * @description to set profile import data
	 * @param conn
	 * @param inputStream
	 * @param logedinEmail
	 */
	public void setProfileImportData(Connection conn,InputStream inputStream,String logedinEmail)throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("setProfileImportData ||InputStream:"+inputStream+" logedinEmail:"+logedinEmail+"||Begin");
		}
		Connection conn1 = null;
		UserDao userDao = new UserDao();
		List<User> profiles = new ArrayList<User>();
		List<User> userListData = new ArrayList<User>();
	    Map<String,String> group = new HashMap<String,String>();
	    MailTemplateDao mailDao = new MailTemplateDao();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			boolean flag1 = true;
			String message = "";
	        //Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

	        //Iterate through each rows one by one
	        Iterator<Row> rowIterator = sheet.iterator();
	        
	        int i = 0;
	        if (log.isTraceEnabled()) {
				log.trace("setProfileImportData ||dao call of getUsers() method to get user profile list");
			}
	        userListData = userDao.getUsers(false,conn);
	        List<User> userList = new ArrayList<User>();
			for(User profile:userListData)
			{
				if(!profile.getUserName().equalsIgnoreCase("admin")){
					User user=new User();
					user.setUserId(profile.getUserId());
					user.setUserName(profile.getUserName());
					user.setFullName(profile.getFullName());
					user.setPassword(profile.getPassword());
					user.setEmailId(profile.getEmailId());
					user.setActiveFlag(profile.getActiveFlag());
					user.setDepartment(profile.getDepartment());
					user.setEncryptFullName(profile.getEncryptFullName());
					user.setEncryptEmailId(profile.getEncryptEmailId());
					user.setEncryptDepartment(profile.getEncryptDepartment());
					
					userList.add(user);	
				}
			}
	        while (rowIterator.hasNext()){
	        	Row row = rowIterator.next();
	            User profile = new User();
	            if(i>0){
	            	int j1 = 0;
	            	while (j1<9) 
		            {
	            		Cell cell = row.getCell(j1);
	            		if(cell!=null){
	                    	cell.setCellType(1);
	                    }
	            		if(j1 == 0){
	            			if(cell != null){

	            				String userName = cell.getStringCellValue();
	            				userName = userName.trim();
	            				if(userName.length()<1){
	            					flag1 = false;
	            					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to blank username provided in xlsx sheet. \n");
	            					}
	        						message = message + "RepoPro import user details failed due to blank username provided in xlsx sheet. \n";
	        					}
	            				if(userName.contains("  ")){
	            					flag1 = false;
	            					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to invalid username '"+userName+"' provided in xlsx sheet. \n");
	            					}
	            					message = message + "RepoPro import user details failed due to invalid username '"+userName+"' provided in xlsx sheet. \n";
	            				}
	            				if(userName.equalsIgnoreCase("Admin")){
	            					flag1 = false;
	            					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to invalid username '"+userName+"' provided in xlsx sheet. \n");
	            					}
	            					message = message + "RepoPro import user details failed due to invalid username '"+userName+"' provided in xlsx sheet. \n";
	            				}
	            				Pattern p1 = Pattern.compile("[^a-z0-9]", Pattern.CASE_INSENSITIVE);
	            				Matcher m = p1.matcher(userName);
	            				boolean b = m.find();

	            				if(b){
	            					flag1 = false;
	            					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to invalid username '"+userName+"' provided in xlsx sheet. \n");
	            					}
	            					message = message + "RepoPro import user details failed due to invalid username '"+userName+"' provided in xlsx sheet. \n";
	            				}
	            				if(userName.length()>50){
	            					flag1 = false;
	            					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to username '"+userName+"' size is greater than 50 characters. \n");
	            					}
	            					message = message + "RepoPro import user details failed due to username '"+userName+"' size is greater than 50 characters. \n";
	            				}
	            				profile.setUserName(userName);
	            			}else{
	        					flag1 = false;
	        					if (log.isErrorEnabled()) {
            						log.error("setProfileImportData || RepoPro import user details failed due to blank username provided in xlsx sheet. \n");
            					}
	        					message = message + "RepoPro import user details failed due to blank username provided in xlsx sheet. \n";
	    						
	        				}
	            		}
	            		if(j1 == 1){
	            			if(cell!=null){

		                		String firstName = cell.getStringCellValue();
		                		firstName = firstName.trim();
								if (firstName.length() < 1) {
									flag1 = false;
									String userName2 = "";
									if (profile.getUserName() == null) {
										userName2 = "blank";
									} else {
										userName2 = profile.getUserName();
									}
									if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to full name of user is left blank for user name "+userName2+" in xlsx sheet. \n");
	            					}
									message = message+ "RepoPro import user details failed due to full name of user is left blank for user name "+ userName2 + " in xlsx sheet. \n";
								}
		       		            Pattern p1 = Pattern.compile("[^.a-z -]", Pattern.CASE_INSENSITIVE);
	        					Matcher m = p1.matcher(firstName);
	        					boolean b = m.find();

	        					if (b){
	        						flag1 = false;
		                			String userName2 = "";
	               					if(profile.getUserName()==null){
	                					userName2 = "blank";
	                				}else {
	                					userName2 = profile.getUserName();
	                				}
	               					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to invalid full name '"+firstName+"' provided for user name "+userName2+" in xlsx sheet. \n");
	            					}
		                			message = message + "RepoPro import user details failed due to invalid full name '"+firstName+"' provided for user name "+userName2+" in xlsx sheet. \n";
	        					}
	        					if(firstName.length()>50){
	        						flag1 = false;
	        						String userName2 = "";
	               					if(profile.getUserName()==null){
	                					userName2 = "blank";
	                				}else {
	                					userName2 = profile.getUserName();
	                				}
	               					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to full name '"+firstName+"' size is greater than 50 characters for user name "+userName2+". \n");
	            					}
	        						message = message + "RepoPro import user details failed due to full name '"+firstName+"' size is greater than 50 characters for user name "+userName2+". \n";
	        					}
		                		profile.setFullName(firstName);
		                	}else{
		                		flag1 = false;   						
		                		String userName2 = "";
	               				if(profile.getUserName()==null){
	                				userName2 = "blank";
	                			}else {
	                				userName2 = profile.getUserName();
	                			}
	               				if (log.isErrorEnabled()) {
            						log.error("setProfileImportData || RepoPro import user details failed due to full name of user is left blank for user name "+userName2+" in xlsx sheet. \n");
            					}
		    					message = message + "RepoPro import user details failed due to full name of user is left blank for user name "+userName2+" in xlsx sheet. \n";
	    				    }
	            		}
	            		if(j1 == 2){

		                	if(cell!=null){
		                		String email = cell.getStringCellValue();
		                		email = email.trim();
		                		boolean flagz = true;
		                		if(email.length()<1){
		                			flagz = false;
		                			flag1 = false;
		    							String userName2 = "";
		               					if(profile.getUserName()==null){
		                					userName2 = "blank";
		                				}else {
		                					userName2 = profile.getUserName();
		                				}
		               					if (log.isErrorEnabled()) {
		            						log.error("setProfileImportData || RepoPro import user details failed due to user's email-id is left blank for user name "+userName2+" in xlsx sheet. \n");
		            					}
		    							message = message + "RepoPro import user details failed due to user's email-id is left blank for user name "+userName2+" in xlsx sheet. \n";
		                		}
		                		
		                		if(email.contains(" ") && email.length()>0){
		                			flagz = false;
		                			flag1 = false;
		                			String userName2 = "";
	               					if(profile.getUserName()==null){
	                					userName2 = "blank";
	                				}else {
	                					userName2 = profile.getUserName();
	                				}
	               					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to invalid email-id '"+email+"' provided for user name "+userName2+" in xlsx sheet. \n");
	            					}
		    						message = message + "RepoPro import user details failed due to invalid email-id '"+email+"' provided for user name "+userName2+" in xlsx sheet. \n";
		    					}
		                		if(flagz==true){
		                		String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w-_\\.]+\\.)+[\\w]+[\\w]$";
		                		Boolean b = email.matches(EMAIL_REGEX);
		                		   if(b==false){
		                			  flag1 = false;
		                			  String userName2 = "";
	               					  if(profile.getUserName()==null){
	                				        userName2 = "blank";
	                				  }else {
	                					userName2 = profile.getUserName();
	                				  }
	               					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to invalid email-id '"+email+"' provided for user name "+userName2+" in xlsx sheet. \n");
	            					}
	               					message = message + "RepoPro import user details failed due to invalid email-id '"+email+"' provided for user name "+userName2+" in xlsx sheet. \n";
		    					   }
		                		}
		                		if(email.length()>150){
	        						flag1 = false;
	        						String userName2 = "";
	               					if(profile.getUserName()==null){
	                					userName2 = "blank";
	                				}else {
	                					userName2 = profile.getUserName();
	                				}
	               					if (log.isErrorEnabled()) {
	            						log.error("setProfileImportData || RepoPro import user details failed due to email-id '"+email+"' size for user name "+userName2+" is greater than 150 characters. \n");
	            					}
	        						message = message + "RepoPro import user details failed due to email-id '"+email+"' size for user name "+userName2+" is greater than 150 characters. \n";
	        					}

		                		profile.setEmailId(email);
		                	}else{
		                		flag1 = false;
	     						String userName2 = "";
	               				if(profile.getUserName()==null){
	                				userName2 = "blank";
	                			}else {
	                				userName2 = profile.getUserName();
	                			}
	               				if (log.isErrorEnabled()) {
            						log.error("setProfileImportData || RepoPro import user details failed due to user's email-id is left blank for user name "+userName2+" in xlsx sheet. \n");
            					}
	     						message = message + "RepoPro import user details failed due to user's email-id is left blank for user name "+userName2+" in xlsx sheet. \n";
	    					}
		                }
	            		if(j1 == 3){
		                	if(cell!=null){
		                		String department = cell.getStringCellValue();
		                		department = department.trim();
		                		if(department.length()<1){
		                			flag1 = false;
		     							String userName2 = "";
		               					if(profile.getUserName()==null){
		                					userName2 = "blank";
		                				}else {
		                					userName2 = profile.getUserName();
		                				}
		               					if (log.isErrorEnabled()) {
		            						log.error("setProfileImportData || RepoPro import user details failed due to user's department is left blank for user name "+userName2+" in xlsx sheet. \n");
		            					}
		     							message = message + "RepoPro import user details failed due to user's department is left blank for user name "+userName2+" in xlsx sheet. \n";
		    					}
		                	  String iChars = "`!%^*=[];{}|<>?~";
		              		  for (int k = 0; k < department.length(); k++) 
		              		  {
		              			  if (iChars.indexOf(department.charAt(k)) != -1) 
		              			  {
		              				  flag1 = false;
		              				  if (log.isErrorEnabled()) {
		              					  log.error("setProfileImportData || RepoPro import user details failed due to user's department is invalid (Special characters except ':'\\\"+#$/\\\\&@.(),-_' are not allowed)for user name "+profile.getUserName()+" in xlsx sheet. \n");
		              				  }
		              				  message =message+ "RepoPro import user details failed due to user's department is invalid (Special characters except ':'\"+#$/\\&@.(),-_' are not allowed)for user name "+profile.getUserName()+" in xlsx sheet. \n";
		              				  break;
		              			  }
		              		  }
		              	     if(department.length()>50){
	        						flag1 = false;
	        						String userName2 = "";
	               					if(profile.getUserName()==null){
	                					userName2 = "blank";
	                				}else {
	                					userName2 = profile.getUserName();
	                				}
	               				 if(log.isErrorEnabled()) {
	              					 log.error("setProfileImportData || RepoPro import user details failed due to department '"+department+"' size for user name "+userName2+" is greater than 50 characters. \n");
	              				 }
	        					message = message + "RepoPro import user details failed due to department '"+department+"' size for user name "+userName2+" is greater than 50 characters. \n";
	        					}
		                		profile.setDepartment(department);
		                	}else{
		                		flag1 = false;
	     							String userName2 = "";
	               					if(profile.getUserName()==null){
	                					userName2 = "blank";
	                				}else {
	                					userName2 = profile.getUserName();
	                				}
	               					if(log.isErrorEnabled()) {
		              					 log.error("setProfileImportData || RepoPro import user details failed due to user's department is left blank for user name "+userName2+" in xlsx sheet. \n");
		              				}
	     							message = message + "RepoPro import user details failed due to user's department is left blank for user name "+userName2+" in xlsx sheet. \n";
		                	}
		                } 
	            		if(j1 == 4){
		                	
							if (cell != null) {
								String result4 = cell.getStringCellValue();
								result4 = result4.trim();
								if (result4.length() > 0) {
									group.put(profile.getUserName(), result4);
								} 
							}
		               }
	            	   if(j1 == 5){

		                	if(cell!=null){
		                		String result4 = cell.getStringCellValue();
		                		result4 = result4.trim();
		                		if(result4.length()<1){
		    						flag1 = false;
		     							String userName2 = "";
		               					if(profile.getUserName()==null){
		                					userName2 = "blank";
		                				}else {
		                					userName2 = profile.getUserName();
		                				}
		               					if(log.isErrorEnabled()) {
			              					 log.error("setProfileImportData || RepoPro import user details failed due to blank status for user name "+userName2+" in xlsx sheet. \n");
			              				}
		     							message = message + "RepoPro import user details failed due to blank status for user name "+userName2+" in xlsx sheet. \n";
		                		}
		                		if(!result4.equals("Active") && !result4.equals("Inactive") && result4.length()>0){
		    						flag1 = false;
		    							String userName2 = "";
	               						if(profile.getUserName()==null){
	               							userName2 = "blank";
	               						}else {
	               							userName2 = profile.getUserName();
	               						}
	               						if(log.isErrorEnabled()) {
			              					 log.error("setProfileImportData || RepoPro import user details failed due to invalid status '"+result4+"' for user name "+userName2+" in xlsx sheet. \n");
			              				}
		     							message = message + "RepoPro import user details failed due to invalid status '"+result4+"' for user name "+userName2+" in xlsx sheet. \n";
		    					}
		                		if(result4.equals("Active")){
		                			profile.setActiveFlag("1");
		                		}else{
		                			profile.setActiveFlag("0");
		                		}
		                	}else{
	    						flag1 = false;
	     							String userName2 = "";
	               					if(profile.getUserName()==null){
	                					userName2 = "blank";
	                				}else {
	                					userName2 = profile.getUserName();
	                				}
	               					if(log.isErrorEnabled()) {
		              					 log.error("setProfileImportData || RepoPro import user details failed due to blank status for user name "+userName2+" in xlsx sheet. \n");
		              				}
	     							message = message + "RepoPro import user details failed due to blank status for user name "+userName2+" in xlsx sheet. \n";
		                	}
		               }
	            	   if(j1 == 6) {//for encrypt full Name flag
	            		   if(cell!=null){
	            			   String encryptFullNameFlag = cell.getStringCellValue();
	            			   encryptFullNameFlag = encryptFullNameFlag.trim();

	            			   if(encryptFullNameFlag.length()<1){
	            				   flag1 = false;
	            				   String userName2 = "";
	            				   if(profile.getUserName()==null){
	            					   userName2 = "blank";
	            				   }else {
	            					   userName2 = profile.getUserName();
	            				   }
	            				   if(log.isErrorEnabled()) {
	            					   log.error("setProfileImportData || RepoPro import user details failed due to blank encrypt full name flag for user name "+userName2+" in xlsx sheet. \n");
	            				   }
	            				   message = message + "RepoPro import user details failed due to blank encrypt full name flag for user name "+userName2+" in xlsx sheet. \n";
	            			   }else {
	            				   String userName2 = "";
	            				   if(profile.getUserName()==null){
	            					   userName2 = "blank";
	            				   }else {
	            					   userName2 = profile.getUserName();
	            				   }
	            				   try {
	            					   if(encryptFullNameFlag.length()>1) {
	            						   flag1 = false;
		            					   if (log.isErrorEnabled()) {
			            					   log.error("setProfileImportData || RepoPro import user details failed due to invalid encrypt full name flag '"+encryptFullNameFlag+"' provided for user name "+userName2+" in xlsx sheet. \n");
			            				   }
			            				   message = message + "RepoPro import user details failed due to invalid encrypt full name flag '"+encryptFullNameFlag+"' provided for user name "+userName2+" in xlsx sheet. \n";
		            				   }
		            				   else if(Integer.parseInt(encryptFullNameFlag) == 0 || Integer.parseInt(encryptFullNameFlag) == 1) {
			            				   profile.setEncryptFullName(Integer.parseInt(encryptFullNameFlag));
		            				   }else {
		            					   flag1 = false;
		            					   if (log.isErrorEnabled()) {
			            					   log.error("setProfileImportData || RepoPro import user details failed due to invalid encrypt full name flag '"+encryptFullNameFlag+"' provided for user name "+userName2+" in xlsx sheet. \n");
			            				   }
			            				   message = message + "RepoPro import user details failed due to invalid encrypt full name flag '"+encryptFullNameFlag+"' provided for user name "+userName2+" in xlsx sheet. \n";
		            				   }
	            				   } catch (NumberFormatException e) {
	            					   if (log.isErrorEnabled()) {
		            					   log.error("setProfileImportData || RepoPro import user details failed due to invalid encrypt full name flag '"+encryptFullNameFlag+"' provided for user name "+userName2+" in xlsx sheet. \n");
		            				   }
	            					   message = message + "RepoPro import user details failed due to invalid encrypt full name flag '"+encryptFullNameFlag+"' provided for user name "+userName2+" in xlsx sheet. \n";
	            				   }
	            			   }
	            		   }else{
	            			   flag1 = false;
	            			   String userName2 = "";
	            			   if(profile.getUserName()==null){
	            				   userName2 = "blank";
	            			   }else {
	            				   userName2 = profile.getUserName();
	            			   }
	            			   if(log.isErrorEnabled()) {
	            				   log.error("setProfileImportData || RepoPro import user details failed due to blank encrypt full name flag for user name "+userName2+" in xlsx sheet. \n");
	            			   }
	            			   message = message + "RepoPro import user details failed due to blank encrypt full name flag for user name "+userName2+" in xlsx sheet. \n";
	            		   }
	            	   }
	            	   if(j1 == 7) {//for encrypt emailId flag
	            		   if(cell!=null){
	            			   String encryptEmailIdFlag = cell.getStringCellValue();
	            			   encryptEmailIdFlag = encryptEmailIdFlag.trim();

	            			   if(encryptEmailIdFlag.length()<1){
	            				   flag1 = false;
	            				   String userName2 = "";
	            				   if(profile.getUserName()==null){
	            					   userName2 = "blank";
	            				   }else {
	            					   userName2 = profile.getUserName();
	            				   }
	            				   if(log.isErrorEnabled()) {
	            					   log.error("setProfileImportData || RepoPro import user details failed due to blank encrypt Email Id flag for user name "+userName2+" in xlsx sheet. \n");
	            				   }
	            				   message = message + "RepoPro import user details failed due to blank encrypt Email Id flag for user name "+userName2+" in xlsx sheet. \n";
	            			   }else {
	            				   String userName2 = "";
	            				   if(profile.getUserName()==null){
	            					   userName2 = "blank";
	            				   }else {
	            					   userName2 = profile.getUserName();
	            				   }
	            				   try {
	            					   if(encryptEmailIdFlag.length()>1) {
	            						   flag1 = false;
		            					   if (log.isErrorEnabled()) {
			            					   log.error("setProfileImportData || RepoPro import user details failed due to invalid encrypt Email Id flag '"+encryptEmailIdFlag+"' provided for user name "+userName2+" in xlsx sheet. \n");
			            				   }
			            				   message = message + "RepoPro import user details failed due to invalid encrypt Email Id flag '"+encryptEmailIdFlag+"' provided for user name "+userName2+" in xlsx sheet. \n";
		            				   }
		            				   else if(Integer.parseInt(encryptEmailIdFlag) == 0 || Integer.parseInt(encryptEmailIdFlag) == 1) {
			            				   profile.setEncryptEmailId(Integer.parseInt(encryptEmailIdFlag));
		            				   }else {
		            					   flag1 = false;
		            					   if (log.isErrorEnabled()) {
			            					   log.error("setProfileImportData || RepoPro import user details failed due to invalid encrypt Email Id flag '"+encryptEmailIdFlag+"' provided for user name "+userName2+" in xlsx sheet. \n");
			            				   }
			            				   message = message + "RepoPro import user details failed due to invalid encrypt Email Id flag '"+encryptEmailIdFlag+"' provided for user name "+userName2+" in xlsx sheet. \n";
		            				   }
	            				   } catch (NumberFormatException e) {
	            					   if (log.isErrorEnabled()) {
		            					   log.error("setProfileImportData || RepoPro import user details failed due to invalid encrypt Email Id flag '"+encryptEmailIdFlag+"' provided for user name "+userName2+" in xlsx sheet. \n");
		            				   }
	            					   message = message + "RepoPro import user details failed due to invalid encrypt Email Id flag '"+encryptEmailIdFlag+"' provided for user name "+userName2+" in xlsx sheet. \n";
	            				   }
	            			   }
	            		   }else{
	            			   flag1 = false;
	            			   String userName2 = "";
	            			   if(profile.getUserName()==null){
	            				   userName2 = "blank";
	            			   }else {
	            				   userName2 = profile.getUserName();
	            			   }
	            			   if(log.isErrorEnabled()) {
	            				   log.error("setProfileImportData || RepoPro import user details failed due to blank encrypt Email Id flag for user name "+userName2+" in xlsx sheet. \n");
	            			   }
	            			   message = message + "RepoPro import user details failed due to blank encrypt Email Id flag for user name "+userName2+" in xlsx sheet. \n";
	            		   }
	            	   }
	            	   if(j1 == 8) {//for encrypt Dept flag
	            		   if(cell!=null){
	            			   String encryptDeptFlag = cell.getStringCellValue();
	            			   encryptDeptFlag = encryptDeptFlag.trim();

	            			   if(encryptDeptFlag.length()<1){
	            				   flag1 = false;
	            				   String userName2 = "";
	            				   if(profile.getUserName()==null){
	            					   userName2 = "blank";
	            				   }else {
	            					   userName2 = profile.getUserName();
	            				   }
	            				   if(log.isErrorEnabled()) {
	            					   log.error("setProfileImportData || RepoPro import user details failed due to blank encrypt Department flag for user name "+userName2+" in xlsx sheet. \n");
	            				   }
	            				   message = message + "RepoPro import user details failed due to blank encrypt Department flag for user name "+userName2+" in xlsx sheet. \n";
	            			   }else {
	            				   String userName2 = "";
	            				   if(profile.getUserName()==null){
	            					   userName2 = "blank";
	            				   }else {
	            					   userName2 = profile.getUserName();
	            				   }
	            				   try {
	            					   if(encryptDeptFlag.length()>1) {
	            						   flag1 = false;
		            					   if (log.isErrorEnabled()) {
			            					   log.error("setProfileImportData || RepoPro import user details failed due to invalid encrypt Department flag '"+encryptDeptFlag+"' provided for user name "+userName2+" in xlsx sheet. \n");
			            				   }
			            				   message = message + "RepoPro import user details failed due to invalid encrypt Department flag '"+encryptDeptFlag+"' provided for user name "+userName2+" in xlsx sheet. \n";
		            				   }
		            				   else if(Integer.parseInt(encryptDeptFlag) == 0 || Integer.parseInt(encryptDeptFlag) == 1) {
			            				   profile.setEncryptDepartment(Integer.parseInt(encryptDeptFlag));
		            				   }else {
		            					   flag1 = false;
		            					   if (log.isErrorEnabled()) {
			            					   log.error("setProfileImportData || RepoPro import user details failed due to invalid encrypt Department flag '"+encryptDeptFlag+"' provided for user name "+userName2+" in xlsx sheet. \n");
			            				   }
			            				   message = message + "RepoPro import user details failed due to invalid encrypt Department flag '"+encryptDeptFlag+"' provided for user name "+userName2+" in xlsx sheet. \n";
		            				   }
	            				   } catch (NumberFormatException e) {
	            					   if (log.isErrorEnabled()) {
		            					   log.error("setProfileImportData || RepoPro import user details failed due to invalid encrypt Department flag '"+encryptDeptFlag+"' provided for user name "+userName2+" in xlsx sheet. \n");
		            				   }
	            					   message = message + "RepoPro import user details failed due to invalid encrypt Department flag '"+encryptDeptFlag+"' provided for user name "+userName2+" in xlsx sheet. \n";
	            				   }
	            			   }
	            		   }else{
	            			   flag1 = false;
	            			   String userName2 = "";
	            			   if(profile.getUserName()==null){
	            				   userName2 = "blank";
	            			   }else {
	            				   userName2 = profile.getUserName();
	            			   }
	            			   if(log.isErrorEnabled()) {
	            				   log.error("setProfileImportData || RepoPro import user details failed due to blank encrypt Department flag for user name "+userName2+" in xlsx sheet. \n");
	            			   }
	            			   message = message + "RepoPro import user details failed due to blank encrypt Department flag for user name "+userName2+" in xlsx sheet. \n";
	            		   }
	            	   }
	            	   
	            	  j1 = j1 + 1;
	            	}
	            	if(profile.getUserName()!=null){
	        			profiles.add(profile);
	        		}
	            }
	        	i=i+1;
	        }
	        for(User p:userList){
	        	boolean isProfile = false;
	        	for(User pro:profiles){
	        		if(p.getUserName().equals(pro.getUserName())){
	        			isProfile = true;
	        		}
	        	}
	        	if(isProfile==false){
	        		flag1 = false;
	        		if(log.isErrorEnabled()) {
     					 log.error("setProfileImportData || RepoPro import user details failed due to missing profiles in xlsx sheet. \n");
     				}
					message = message + "RepoPro import user details failed due to missing profiles in xlsx sheet. \n";
	        	}
	        }
	        List<String> userName1 = new ArrayList<String>();
	        for(User pro:profiles){
	    		userName1.add(pro.getUserName());
	    	}
	       // Set<String> userName2 = new HashSet<String>(userName1);
	        String []dsf = new String[userName1.size()];
        	userName1.toArray(dsf);
        	for(int j =0;j<dsf.length;j++){
        		for(int k = j+1;k<dsf.length;k++){
        			if(dsf[j].equalsIgnoreCase(dsf[k])){
        				flag1 = false;
        				if(log.isErrorEnabled()) {
        					 log.error("setProfileImportData || RepoPro import user details failed due to duplicate user name(s) "+dsf[j]+" at multiple places in xlsx sheet. \n");
        				}
        				message = message + "RepoPro import user details failed due to duplicate user name(s) "+dsf[j]+" at multiple places in xlsx sheet. \n";
        			}
        		}
        	}
        	
        	 List<User> newProfiles = new ArrayList<User>();
             List<User> removeProfile = new ArrayList<User>();
             List<User> activateProfile = new ArrayList<User>();
             int k = 0;
             List<String> index = new ArrayList<String>();
             for(User p:profiles){
             	boolean flag = false;
             	for(User prof:userList){
             		String userName = p.getUserName();
             		if(userName.equals(prof.getUserName())){
             			if(prof.getActiveFlag().equalsIgnoreCase("2") && p.getActiveFlag().equalsIgnoreCase("1")){
             				p.setActiveFlag("2");
             			}
             			if(p.getActiveFlag().equalsIgnoreCase("1") && prof.getActiveFlag().equalsIgnoreCase("0")){
             				activateProfile.add(p);
             			}
             			p.setPassword(prof.getPassword());
             			p.setUserId(prof.getUserId());
             			flag = true;
             		}
             		
             	}
             	if(p.getActiveFlag()=="0"){
             		removeProfile.add(p);
             	}
             	if(flag==false){
             		User newProfile = new User();
             		newProfile.setUserName(p.getUserName());
             		newProfile.setFullName(p.getFullName());
             		newProfile.setDepartment(p.getDepartment());
             		newProfile.setEmailId(p.getEmailId());
             		newProfile.setEncryptFullName(p.getEncryptFullName());
             		newProfile.setEncryptEmailId(p.getEncryptEmailId());
             		newProfile.setEncryptDepartment(p.getEncryptDepartment());
             		newProfile.setSectionPosition("Tags~~0,Taxonomies~~1,Overview~~2,Properties~~3,Relationships & Reverse Relationships~~4,Revision History~~5,Discussion~~6,Versions~~7,Asset Visualization~~8");
             		newProfile.setSectionVisibility("Tags~~checked,Taxonomies~~checked,Overview~~checked,Properties~~checked,Relationships & Reverse Relationships~~checked,Revision History~~checked,Discussion~~checked,Versions~~checked,Asset Visualization~~checked");
             		
             		if(p.getActiveFlag() != null){
             			if(p.getActiveFlag().equalsIgnoreCase("1") || p.getActiveFlag().equalsIgnoreCase("2")){
             				newProfile.setActiveFlag("2");
             			}else {
             				newProfile.setActiveFlag("0");
             			}
             		}else{
             			newProfile.setActiveFlag("0");
             		}
             		/* changing the default password value */
             		String password = "Pa55w0rd!";
       			 	EncryptPassword encryptPwd = new EncryptPassword();
       			 	password = encryptPwd.encryptPassword(password);
             		newProfile.setPassword(password);
         			newProfiles.add(newProfile);
         			index.add(p.getUserName());
             	}
             	k = k + 1;
             }
             
             if(index.size()>0)
             for(String j:index){
             	int r = 0;
             	for(User p:profiles){
             		if(p.getUserName().equals(j)){
             			break;
             		}
             		r = r+ 1;
             	}
                  profiles.remove(r);
             }
             GroupDao groupDao = new GroupDao();
             if (log.isTraceEnabled()) {
 				log.trace("setProfileImportData ||dao call of getAllGroups() method to get all the group details");
 			 }
             List<GroupDetails> groupData = groupDao.getAllGroups(conn);
             Iterator<Map.Entry<String, String>> iterator = group.entrySet().iterator() ;
             while(iterator.hasNext()){
                 Map.Entry<String, String> groupInterate = iterator.next();
                 String[] groupDetails = groupInterate.getValue().split(",");
                 for(int q = 0;q<groupDetails.length;q++){
                 	boolean groupFlag = false;
                 	for(GroupDetails groupDetailsVo:groupData){
                 		if(groupDetails[q].equalsIgnoreCase("Guest")){
                 			flag1 = false;
                 			if(log.isErrorEnabled()) {
           					 log.error("setProfileImportData || RepoPro import user details failed due to invalid group name '"+groupDetails[q]+"' provided in xlsx sheet. \n");
                 			}
        					message = message + "RepoPro import user details failed due to invalid group name '"+groupDetails[q]+"' provided in xlsx sheet. \n";
        					break;
                 		}
                 		else if(groupDetails[q].equals(groupDetailsVo.getGroupName())){
                 			groupFlag = true;
                 		}
                 	}
                 	if(groupFlag==false){
             			flag1 = false;
             			if(log.isErrorEnabled()) {
          					 log.error("setProfileImportData || RepoPro import user details failed due to invalid group name in xlsx sheet. \n");
                		}
                 		message = message + "RepoPro import user details failed due to invalid group name in xlsx sheet. \n";
             			
                 	}
                 }
             }
             if(newProfiles.size()>0){
             	for(User pro:newProfiles){
             		if(!pro.getActiveFlag().equalsIgnoreCase("2")){
                 		flag1 = false;
                 		if(log.isErrorEnabled()) {
         					 log.error("setProfileImportData || RepoPro import user details failed as new profile's(user name ="+pro.getUserName()+") status must be active. \n");
                 		}
             			message = message + "RepoPro import user details failed as new profile's(user name ="+pro.getUserName()+") status must be active. \n";
             		}
             	}
             }
             
             if(flag1==false){
          
                	MailConfig mailConfig = mailDao.getMailConfig(conn);
        			SendEmail.sendTextMail(mailConfig,logedinEmail, MessageUtil.getMessage(
        					Constants.REPOPRO_IMPORT_USER_FAILURE), MessageUtil.getMessage(Constants.EMAIL_HDR) 
        					+ message+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
        			
        	
             }else{
            	 if(removeProfile.size()>0){
            		 for(User p:removeProfile){
            			 p.setActiveFlag("0");
            			 if (log.isTraceEnabled()) {
            				 log.trace("setProfileImportData ||dao call of updateActiveFlag() method to deactivate user");
            			 }
            			 userDao.updateActiveFlag(p, conn);
            		 }
            	 }

            	 if(newProfiles.size()>0){
            		 for(User addPro:newProfiles){
            			 /* changing the default password value */
            			 String password = "Pa55w0rd!";
            			 EncryptPassword encryptPwd = new EncryptPassword();
            			 password = encryptPwd.encryptPassword(password);
            			 addPro.setPassword(password);
            			 if (log.isTraceEnabled()) {
            				 log.trace("setProfileImportData ||dao call of addUser() method to add new user details");
            			 }
            			 Long newUserId = userDao.addUser(addPro,conn);
            			 addPro.setUserId(newUserId);
            			 if (log.isTraceEnabled()) {
            				 log.trace("setProfileImportData ||dao call of updateActiveFlag() method to activate new user");
            			 }
            			 userDao.updateActiveFlag(addPro, conn);
            			 String msg = "Your profile has been created as : \n User Name : "+ addPro.getUserName() +  "\nPassword :  Pa55w0rd!" + "\nFull Name : "+ addPro.getFullName() + "";
            			 if (log.isTraceEnabled()) {
            				 log.trace("setProfileImportData ||dao call of getMailConfig() method");
            			 }
            			 MailConfig mailConfig = mailDao.getMailConfig(conn);
            			 SendEmail.sendTextMail(mailConfig,addPro.getEmailId(), MessageUtil.getMessage(
            					 Constants.REPOPRO_PROFILE_CREATED), MessageUtil.getMessage(Constants.EMAIL_HDR) 
            					 + msg+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

            		 }
            	 }


            	 if(activateProfile.size()>0){
            		 for(User p:activateProfile){
            			 p.setActiveFlag("1");
            			 if (log.isTraceEnabled()) {
            				 log.trace("setProfileImportData ||dao call of updateActiveFlag() method to activate user");
            			 }
            			 userDao.updateActiveFlag(p, conn);
            		 }
            	 }

            	 if(profiles.size()>0){
            		 for(User pro:profiles){
            			 //getProfiles
            			 for(User pro1:userList){
            				 if(pro.getUserName().equals(pro1.getUserName())){
            					 if(!pro.getFullName().equals(pro1.getFullName())||!pro.getEmailId().equals(pro1.getEmailId())||!pro.getDepartment().equals(pro1.getDepartment())
            							 || pro.getEncryptFullName() != pro1.getEncryptFullName() || pro.getEncryptEmailId() != pro1.getEncryptEmailId() || pro.getEncryptDepartment() != pro1.getEncryptDepartment()){
            						 if (log.isTraceEnabled()) {
            							 log.trace("setProfileImportData ||dao call of updateUser() method to update user details");
            						 }
            						 userDao.updateUser(pro, conn);
            						 if (log.isTraceEnabled()) {
            							 log.trace("setProfileImportData ||dao call of retMailTemplateByTextName() method");
            						 }
            						 MailTemplate mtVo = mailDao.retMailTemplateByTextName(conn, "updateUserProfile");

            						 String mailTemp = mtVo.getMailTemplate();
            						 mailTemp = mailTemp.replaceAll("%fullName%", pro.getFullName()).replaceAll("%emailId%", pro.getEmailId()).replaceAll("%userName%", pro.getUserName());
            						 if (log.isTraceEnabled()) {
            							 log.trace("setProfileImportData ||dao call of getMailConfig() method");
            						 }
            						 MailConfig mailConfig = mailDao.getMailConfig(conn);
            						 SendEmail.sendTextMail(mailConfig,pro.getEmailId(), MessageUtil.getMessage(
            								 Constants.REPOPRO_PROFILE_UPDATED), MessageUtil.getMessage(Constants.EMAIL_HDR) 
            								 + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

            					 }
            				 }
            			 }
            		 }
            	 }
            	 Iterator<Map.Entry<String, String>> iterator1 = group.entrySet().iterator() ;

            	 while(iterator1.hasNext()){
            		 Map.Entry<String, String> groupInterate = iterator1.next();
            		 String[] groupDetails = groupInterate.getValue().split(",");
            		 String userName = groupInterate.getKey();
            		 String addedGroupIds = new String();
            		 if (log.isTraceEnabled()) {
            			 log.trace("setProfileImportData ||dao call of getProfileForUserName() method to get specific user details");
            		 }
            		 User user = userDao.retProfileForUserName(userName,conn);
            		 if (log.isTraceEnabled()) {
            			 log.trace("setProfileImportData ||dao call of getAllGroups() method to get all group details");
            		 }
            		 List<GroupDetails> groupDetail = groupDao.getAllGroups(conn);
            		 for(int q=0;q<groupDetails.length;q++){
            			 Long id = null;
            			 for(int l=0;l<groupDetail.size();l++){
            				 if(groupDetail.get(l).getGroupName().equalsIgnoreCase(groupDetails[q])){
            					 id = groupDetail.get(l).getGroupId(); 
            				 }
            			 }
            			 if(null!=id){
            				 addedGroupIds = addedGroupIds.concat(id+",");
            			 }
            		 }
            		 addedGroupIds= addedGroupIds.replaceAll(",$", "");
            		 String[] addedGroups = new String[]{}; 
            		 if(addedGroupIds!=null){
            			 addedGroups = addedGroupIds.toString().split(",");
            			 if (log.isTraceEnabled()) {
            				 log.trace("setProfileImportData ||dao call of addUserGroup() method to add user groups");
            			 }
            			 userDao.addUserGroup(user.getUserId(), addedGroups, conn);
            		 }

            	 }
            	 MailConfig mailConfig = mailDao.getMailConfig(conn);
        		 SendEmail.sendTextMail(mailConfig,logedinEmail, MessageUtil.getMessage(
        					Constants.REPOPRO_USER_IMPORT_SUCCESS), MessageUtil.getMessage(Constants.EMAIL_HDR) 
        					+ "User data imported successfully"+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
        			
            	 conn.commit(); 
            	 if (log.isTraceEnabled()) {
            		 log.trace("setProfileImportData ||InputStream:"+inputStream+" logedinEmail:"+logedinEmail+"||End");
            	 }
             }
		}catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				throw new RepoproException(e1);
			}
		}finally {
			if (log.isTraceEnabled()) {
				log.trace("setProfileImportData || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

	}
	
}
