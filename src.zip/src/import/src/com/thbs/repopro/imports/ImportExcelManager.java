package com.thbs.repopro.imports;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.activation.MimetypesFileTypeMap;
import javax.naming.directory.DirContext;
import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.assetinstance.AssetInstanceManager;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionsManager;
import com.thbs.repopro.assetinstanceversion.RevisionHistoryDao;
import com.thbs.repopro.dto.AivRevisionHistory;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstAssignTagging;
import com.thbs.repopro.dto.AssetInstDescSuccess;
import com.thbs.repopro.dto.AssetInstRelationship;
import com.thbs.repopro.dto.AssetInstVersionTaxonomy;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.AssetParamSuccess;
import com.thbs.repopro.dto.AssetRelationshipDef;
import com.thbs.repopro.dto.GlobalSetting;
import com.thbs.repopro.dto.LdapMapping;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.MailTemplate;
import com.thbs.repopro.dto.NameValue;
import com.thbs.repopro.dto.ParameterValues;
import com.thbs.repopro.dto.RecentActivity;
import com.thbs.repopro.dto.TaggingMaster;
import com.thbs.repopro.dto.TaxonomyMaster;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.Workflow;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.ldap.LDAPConnection;
import com.thbs.repopro.ldap.LDAPUser;
import com.thbs.repopro.ldap.LDAPUtility;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.miscellaneous.GlobalSettingDao;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.recentactivity.RecentActivityDao;
import com.thbs.repopro.relationship.RelationshipDao;
import com.thbs.repopro.subscription.SubscriptionDao;
import com.thbs.repopro.tagging.TaggingDao;
import com.thbs.repopro.taxonomies.TaxonomiesDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.CustomParameterPluginUtilies;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.workflow.WorkflowDao;

@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML,MediaType.MULTIPART_FORM_DATA})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML,MediaType.MULTIPART_FORM_DATA})
@Path("/import")
public class ImportExcelManager {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	private	Map<Long, List<TaxonomyMaster>> allTaxs =  null;
	List<Long> associatedTaxId = new ArrayList<Long>();
	private  static Boolean uploadInProcess = false; 
	
	void recurse(TaxonomyMaster t)throws RepoproException{

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);
			allTaxs.put(t.getTaxonomyId(), chldrn);
			for(TaxonomyMaster i: chldrn)
				recurse(i);
		}
		catch (RepoproException e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

	}

	void  recurse1(TaxonomyMaster t) throws RepoproException{

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);

			for(TaxonomyMaster a: chldrn){

				TaxonomyMaster t1 = new TaxonomyMaster();
				t1.setTaxonomyId(a.getTaxonomyId());
				t1.setTaxonomyName(a.getTaxonomyName());
				recurse1(t1);
				associatedTaxId.add(a.getTaxonomyId());
				associatedTaxId.add(t.getTaxonomyId());

			}
			associatedTaxId.add(t.getTaxonomyId());

		}catch (RepoproException e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
	}

	public void zipfileValidation() {
		
	}
	
	/**
	 * @method importExcelSheet
	 * @description import excel sheet
	 * @param userName
	 * @param radioVal
	 * @param radValStatic
	 * @param formParams
	 * @return
	 * @throws Exception 
	 */
	@POST
	@Path("/importExcelSheet")
	public Response importExcelSheet(@QueryParam("userName") String userName,
			@QueryParam("radioVal") String radioVal,@QueryParam("radValStatic") String radValStatic,
			FormDataMultiPart formParams,@Context ServletContext context) throws Exception{

		if (log.isTraceEnabled()) {
			log.trace("importExcelSheet ||UserName:"+userName+" RadioVal:"+radioVal+"||Begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;
		allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
		List<AssetRelationshipDef>  relNameList = null;
		FormDataBodyPart dataMultiPart;
		String splitAssetName = "";
		List<AssetParamDef> paramList = null;
		List<AssetInstanceVersion>  assetInstList = new ArrayList<AssetInstanceVersion>();
		List<AssetParamDef>    allCatsAndParamsForAsset = new ArrayList<AssetParamDef>();
		List<AssetInstanceVersion>  listAivo = new ArrayList<AssetInstanceVersion>();
		List<AssetInstanceVersion>  excelassetInstList = new ArrayList<AssetInstanceVersion>(); 
		List<AssetInstDescSuccess> aisdVoList = new ArrayList<AssetInstDescSuccess>();
		List<AssetParamSuccess> apsVoList = new ArrayList<AssetParamSuccess>();
		List<AssetParamSuccess> apeVoList = new ArrayList<AssetParamSuccess>();
		List<String> possValues = null;
		List<AssetInstVersionTaxonomy>   assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
		List<AssetInstance> azds = new ArrayList<AssetInstance>();
		List<AssetInstanceVersion>  assetInstList1 =  new ArrayList<AssetInstanceVersion>(); 
		List<List<AssetInstanceVersion>> assetInstList2 = new ArrayList<List<AssetInstanceVersion>>();
		List<AssetInstAssignTagging>    assetInstTaggingList = new ArrayList<AssetInstAssignTagging>();
		Map<String,List<AssetInstanceVersion>> listOfassetInstList = new LinkedHashMap<String,List<AssetInstanceVersion>>();
		Map<String,List<List<AssetInstanceVersion>>> listOfassetInstList1 = new LinkedHashMap<String,List<List<AssetInstanceVersion>>>();
		GlobalSetting globalLock;
		Set<String> lockedVersionIds = new HashSet<String>();
		TaggingDao taggingDao = new TaggingDao();
		AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
		StringBuilder errStr = new StringBuilder();
		AssetDao assetDao = new AssetDao();
		UserDao userDao = new UserDao();
		RelationshipDao relationshipDao = new RelationshipDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		WorkflowDao workflowDao = new WorkflowDao();
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();
		User profile = userDao.retProfiledetailsForUserName(userName, conn);
		globalLock = globalSettingDao.retGlobalSettingByName("Lock", conn);
		Runtime runTime = Runtime.getRuntime();
		CommonUtils commonUtils = new CommonUtils();
		StringBuilder errStrOfZipFolder = new StringBuilder();
		try {

			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (log.isTraceEnabled()){
				log.trace("importExcelSheet || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);

			/*LDAPConnection ldapConnection = LDAPConnection.getInstance();
			DirContext dirContext = ldapConnection.getDirContext();*/
			LDAPUtility ldapUtility = new LDAPUtility();
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			uploadInProcess = true;
			List<AssetDef> assetNameList = assetDao.getAllAssets(conn);
			relNameList = relationshipDao.getAllAssetRelationshipDef(conn);
			final List<TaxonomyMaster> tmList = taxonomyDao.getAllTaxonomiesByParentId(1L,conn);
			for(TaxonomyMaster t:tmList){
				recurse(t);
			}
			allTaxs.put((long) 1, tmList);
			dataMultiPart = formParams.getField("importdata");
			InputStream inputstream = dataMultiPart.getEntityAs(InputStream.class);
			String vals = dataMultiPart.getContentDisposition().getFileName();
			List<String> errorsOnZipFile = new ArrayList<String>();
			if(vals.endsWith(".zip")){
				InputStream fin;
				String nm = null;
				try 
				{
					fin = dataMultiPart.getEntityAs(InputStream.class);
					BufferedInputStream bin = new BufferedInputStream(inputstream);
					ZipInputStream zin = new ZipInputStream(bin);
					ZipEntry ze = null;
					File file4 = new File(System.getProperty("user.home")+"/RepoProUnzip");
					if (!file4.exists()) 
					{
						if (file4.mkdir()) {
						} else {
							System.out.println("XLSX Import: Failed to create directory unzip!");
						}
					}
					String excelFile = null;
					while ((ze = zin.getNextEntry()) != null) 
					{
						String filename = ze.getName();

						int idx = filename.replaceAll("\\\\", "/").lastIndexOf("/");
						nm =     idx >= 0 ? filename.substring(idx + 1) : filename;
						if(nm.equalsIgnoreCase("ImportIndex.xlsx"))
						{
							excelFile = nm ;
						}
						if(nm.trim().isEmpty()) continue;	//a folder, we are not interested
						OutputStream out = new FileOutputStream(System.getProperty("user.home")+"/RepoProUnzip/"+nm);
						byte[] buffer = new byte[8192];
						int len;
						while ((len = zin.read(buffer)) != -1)
						{
							out.write(buffer, 0, len);
						}
						out.close();
					}
					fin.close();
					File folder1 = new File(System.getProperty("user.home")+"/RepoProUnzip/");
					File[] listOfFiles1 = folder1.listFiles();
					if(excelFile == null){
						if (log.isErrorEnabled()) {
							log.error("Zip folder does not contain ImportIndex.xlsx file");
						}
						errStrOfZipFolder.append("Zip folder does not contain ImportIndex.xlsx file");
					}
					if(listOfFiles1 != null )
					{
						for (int g = 0; g < listOfFiles1.length; g++) 
						{
							if(excelFile != null){
								if(excelFile.equalsIgnoreCase("ImportIndex.xlsx"))
								{
									inputstream = new FileInputStream(System.getProperty("user.home")+"/RepoProUnzip/"+excelFile);	
									break;
								}
							}
						}
					}   
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
					throw e;
				} 
			} else{ 

				inputstream = dataMultiPart.getEntityAs(InputStream.class);
			}

			if(errStrOfZipFolder.length() == 0){
				if(radioVal.equalsIgnoreCase("usual")){

					List<String> errorsOnProc = new ArrayList<String>();

					XSSFWorkbook workbook = new XSSFWorkbook(inputstream);

					List<String> splitAssetList = new ArrayList<String>();

					Boolean flagForskip= false;
					if(errorsOnProc.size() == 0)
					{
						
						errorsOnProc = assetAttribute1stlevelValidation(errorsOnProc, workbook,
								flagForskip,splitAssetList,assetNameList,splitAssetName,paramList,conn);

						/*
						// attributes validation 1st layer
						
							
					*/}

					// Loop ends for Asset Attribute 1st level validation

					Boolean flagForskip1 = false;

					List<String> splitAssetList1 = new ArrayList<String>();

					if(errorsOnProc.size() == 0)
					{
						errorsOnProc = AssetRelationship1stlevelvalidation(errorsOnProc, workbook,
								relNameList,flagForskip1,splitAssetList,assetNameList);
						
						/*
						
								
					*/} 
					// Loop Ends for Asset relationship - first level

					// Loop Starts for Asset attribute value validation 2nd level
					
					if(errorsOnProc.size() == 0)
					{
						int ldapDuplicateCount = 0; 
						splitAssetName = null;
						for (int x = 0; x < workbook.getNumberOfSheets(); x=x+2) 
						{
							List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
							XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(x);
							XSSFRow row; 	
							//Iterator rows = sheet.rowIterator();
							Iterator<Row> rows = sheet.iterator();
							boolean flag1 = false;
							Map<String, List<String>> allPossVals = null ;
							while (rows.hasNext())
							{
								AssetInstance prhVo = new AssetInstance();
								row = (XSSFRow) rows.next();
								int  rowNum = row.getRowNum();
								if(row.getRowNum() == 0)
								{
									XSSFRow rowb = sheet.getRow(rowNum++);
									XSSFCell cellaa = rowb.getCell(0);
									if(cellaa != null)
									{
										if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
										{
											splitAssetName = cellaa.getStringCellValue();
											if(splitAssetName.length() == 0)
											{
												splitAssetName = "";  
											}
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
										{
											int val = (int)cellaa.getNumericCellValue(); 
											splitAssetName = String.valueOf(val); 
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
										{
											splitAssetName = cellaa.getStringCellValue();
										}
									}
									else
									{
										splitAssetName = "";
									}
									assetInstList = assetInstanceVersionDao.getAssetInstVerByAsset(splitAssetName, conn);
									continue;   
								}
								if( row.getRowNum()==1 )
								{
									continue; 
								}
								if( row.getRowNum()==2 )
								{
									AssetDef asset = assetInstanceDao.retAssetDetail(splitAssetName, conn);

									allTxs = taxonomyDao.getAllTaxonomiesByAssetId(asset.getAssetId(), conn);

									for(TaxonomyMaster t:allTxs)
									{
										recurse1(t); 
									}
									Set<Long> hs = new HashSet<Long>();
									hs.addAll(associatedTaxId);
									associatedTaxId.clear();
									associatedTaxId.addAll(hs);
									flag1 = asset.isVersionable();

									paramList = assetDao.getParamsByAsset(splitAssetName, conn);
									paramList = paramListData(paramList,conn);
									
									List<AssetParamDef> ldapparameter = new ArrayList<AssetParamDef>();
									List<AssetParamDef> ldapparameterRemoval = new ArrayList<AssetParamDef>();

									allCatsAndParamsForAsset = assetDao.getCategoryNameAndParametersByAssetId(asset.getAssetId(), conn);

									listAivo =  assetInstanceVersionDao.getAssetInstVerByAsset(splitAssetName, conn);

									allPossVals = new LinkedHashMap<String, List<String>>();
									List<AssetParamDef> filterList = new ArrayList<AssetParamDef>();
									for(int i=0; i<allCatsAndParamsForAsset.size(); i++)
									{
										if(allCatsAndParamsForAsset.get(i).getParamTypeId().equals(4L)){

											possValues = new ArrayList<String>();  

											if(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId().equals(1L)){

												filterList = assetDao.getFilterList(splitAssetName, allCatsAndParamsForAsset.get(i).getAssetParamName(), "CUSTOMLIST",userName,allCatsAndParamsForAsset.get(i).getMappedAssetId(),conn);

											}else if(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId().equals(2L)){

												filterList = assetDao.getFilterList(splitAssetName, allCatsAndParamsForAsset.get(i).getAssetParamName(), "ASSETLIST",userName,allCatsAndParamsForAsset.get(i).getMappedAssetId(),conn);

											}else if(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId().equals(3L)){

												filterList = assetDao.getFilterList(splitAssetName, allCatsAndParamsForAsset.get(i).getAssetParamName(), "NATIVEUSERLIST",userName,allCatsAndParamsForAsset.get(i).getMappedAssetId(),conn);

											}
											for(AssetParamDef assetParamDef:filterList){
												possValues.add(assetParamDef.getParamValue());
											}
											allPossVals.put(allCatsAndParamsForAsset.get(i).getAssetParamName(), possValues);
										}else if(allCatsAndParamsForAsset.get(i).getParamTypeId().equals(9L)) {
											
											ldapparameterRemoval.add(allCatsAndParamsForAsset.get(i));
											List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(allCatsAndParamsForAsset.get(i).getLdapMappingId(), conn);
											
											for(LdapMapping ldapAttributes:ldapMapping) {
												AssetParamDef assetparam = new AssetParamDef();
												assetparam.setAssetParamName(allCatsAndParamsForAsset.get(i).getAssetParamName());
												assetparam.setAssetParamId(allCatsAndParamsForAsset.get(i).getAssetParamId());
												assetparam.setAssetCategoryName(allCatsAndParamsForAsset.get(i).getAssetCategoryName());
												assetparam.setAssetCategoryId(allCatsAndParamsForAsset.get(i).getAssetCategoryId());
												assetparam.setMappedAssetId(allCatsAndParamsForAsset.get(i).getMappedAssetId());
												assetparam.setParamTypeId(allCatsAndParamsForAsset.get(i).getParamTypeId());
												assetparam.setListTypeParamTypeId(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId());
												assetparam.setDerivedAttributeComputation(allCatsAndParamsForAsset.get(i).getDerivedAttributeComputation());
												assetparam.setSize(allCatsAndParamsForAsset.get(i).getSize());
												assetparam.setAssetParamId(allCatsAndParamsForAsset.get(i).getAssetParamId());
												assetparam.setHasStaticValue(allCatsAndParamsForAsset.get(i).isHasStaticValue());
												assetparam.setHasMandatoryValue(allCatsAndParamsForAsset.get(i).isHasMandatoryValue());
												assetparam.setHasArray(allCatsAndParamsForAsset.get(i).getHasArray());
												assetparam.setListType(allCatsAndParamsForAsset.get(i).getListType());
												assetparam.setLdapMappingId(allCatsAndParamsForAsset.get(i).getLdapMappingId());
												assetparam.setAssetParamName(allCatsAndParamsForAsset.get(i).getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
												assetparam.setParamTypeId(allCatsAndParamsForAsset.get(i).getParamTypeId());
												ldapparameter.add(assetparam);
											}
										}
									}
									if(!ldapparameterRemoval.isEmpty()) {
										allCatsAndParamsForAsset.removeAll(ldapparameterRemoval);
									}

									if(!ldapparameter.isEmpty()) {
										allCatsAndParamsForAsset.addAll(ldapparameter);
									}
								}
								String cell1=null, cell2=null, cell3=null , cell4=null;

								XSSFRow rowb = sheet.getRow(rowNum++);

								XSSFCell cellbb = rowb.getCell(0);

								XSSFCell cellcc = rowb.getCell(1);

								XSSFCell celldd = rowb.getCell(2);

								XSSFCell cellee = rowb.getCell(3);

								if(cellbb != null)
								{
									if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell1 = cellbb.getStringCellValue();
										if(cell1.length() == 0)
										{
											cell1 = "";  
										}
									}
									if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellbb.getNumericCellValue(); 
										cell1 = String.valueOf(val); 
									}
									if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell1 = cellbb.getStringCellValue();
									}
								}
								else
								{
									cell1 = "";
								}
								if(cellcc != null)
								{
									if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell2 = cellcc.getStringCellValue();
										if(cell2.length() == 0)
										{
											cell2 = "";  
										}
									}
									if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellcc.getNumericCellValue(); 
										cell2 = String.valueOf(val); 
									}
									if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell2 = cellcc.getStringCellValue();
									}

								}
								else
								{
									cell2 = "";
								}


								if(celldd != null)
								{
									if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell3 = celldd.getStringCellValue();
										if(cell3.length() == 0)
										{
											cell3 = "";  
										}
									}
									if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)celldd.getNumericCellValue(); 
										cell3 = String.valueOf(val); 
									}
									if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell3 = celldd.getStringCellValue();
									}
								}
								else
								{
									cell3 = "";
								}
								if(cellee != null)
								{
									if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell4 = cellee.getStringCellValue();
										if(cell4.length() == 0)
										{
											cell4 = "";  
										}
									}
									if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellee.getNumericCellValue(); 
										cell4 = String.valueOf(val); 
									}
									if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell4 = cellee.getStringCellValue();
									}
								}
								else
								{
									cell4 = "";
								}
								if(cell1 != "" && cell2 != "" && cell3 != "" && cell4 != ""){
									AssetInstance ai = new AssetInstance();
									ai.setAssetName(splitAssetName.trim());

									if(flag1 == true){

										ai.setVersionName(cell3.trim());
										ai.setVersionable(true);
									}
									else
									{
										if(cell3.equals("NA")){
											ai.setVersionName(Constants.DEFAULT_VERSION); 
											ai.setVersionable(false);
										}
										else{
											ai.setVersionName(cell3.trim()); 
											ai.setVersionable(false);
										}
									}
									ai.setAssetInstName(cell2.trim());
									ai.setParentAssetInstName(null);
									ai.setParentAssetName(null);

									AssetInstanceVersion avVo = new AssetInstanceVersion();
									avVo.setAssetName(ai.getAssetName().trim());
									avVo.setAssetInstName(cell2.trim());
									avVo.setVersionName(ai.getVersionName().trim());
									excelassetInstList.add(avVo);
								}
							}
							for(AssetInstanceVersion aivo:assetInstList)
							{
								Boolean flagForNotRemove = false;
								for(AssetInstanceVersion aiv:excelassetInstList)
								{
									if(aivo.getAssetName().equalsIgnoreCase(aiv.getAssetName())&& aivo.getAssetInstName().equalsIgnoreCase(aiv.getAssetInstName()) &&  aivo.getVersionName().equalsIgnoreCase(aiv.getVersionName()))
									{
										flagForNotRemove = true;
										break;
									}
								}
								if(!flagForNotRemove)
								{   
									aivo.setAction("delete");

								}
							}
							rows = sheet.rowIterator();
							while (rows.hasNext())
							{
								String currentExclRecStat = "none"; 
								AssetInstance prhVo = new AssetInstance();
								row=(XSSFRow) rows.next();
								int  rowNum = row.getRowNum();

								if(row.getRowNum() == 0)
								{
									XSSFRow rowb = sheet.getRow(rowNum++);

									XSSFCell cellaa = rowb.getCell(0);

									if(cellaa != null)
									{
										if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
										{
											splitAssetName = cellaa.getStringCellValue();
											if(splitAssetName.length() == 0)
											{
												splitAssetName = "";  
											}
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
										{
											int val = (int)cellaa.getNumericCellValue(); 
											splitAssetName = String.valueOf(val); 
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
										{
											splitAssetName = cellaa.getStringCellValue();
										}			    		        	}
									else
									{
										splitAssetName = "";
									}
									continue;   
								}

								if( row.getRowNum()==1 )
								{
									continue; 
								}

								String newParamDataForRevision = "";

								String cell1= null, cell2 = null, cell3 = null , cell4 = null;

								XSSFRow rowb = sheet.getRow(rowNum++);

								XSSFCell cellbb = rowb.getCell(0);

								XSSFCell cellcc = rowb.getCell(1);

								XSSFCell celldd = rowb.getCell(2);

								XSSFCell cellee = rowb.getCell(3);

								if(cellbb != null)
								{
									if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell1 = cellbb.getStringCellValue();
										if(cell1.length() == 0)
										{
											cell1 = "";  
										}
									}
									if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{

										int val = (int)cellbb.getNumericCellValue(); 
										cell1 = String.valueOf(val); 
									}
									if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell1 = cellbb.getStringCellValue();
									}
								}
								else
								{
									cell1 = "";
								}

								if(cellcc != null)
								{
									if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell2 = cellcc.getStringCellValue();
										if(cell2.length() == 0)
										{
											cell2 = "";  
										}
									}
									if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellcc.getNumericCellValue(); 
										cell2 = String.valueOf(val); 
									}
									if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell2 = cellcc.getStringCellValue();
									}

								}
								else
								{
									cell2 = "";
								}

								if(celldd != null)
								{
									if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell3 = celldd.getStringCellValue();
										if(cell3.length() == 0)
										{
											cell3 = "";  
										}
									}
									if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)celldd.getNumericCellValue(); 
										cell3 = String.valueOf(val); 
									}
									if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell3 = celldd.getStringCellValue();
									}
								}
								else
								{
									cell3 = "";
								}

								if(cellee != null)
								{
									if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell4 = cellee.getStringCellValue();
										if(cell4.length() == 0)
										{
											cell4 = "";  
										}
									}
									if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellee.getNumericCellValue(); 
										cell4 = String.valueOf(val); 
									}
									if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell4 = cellee.getStringCellValue();
									}
								}
								else
								{
									cell4 = "";
								}
								if(splitAssetName!= "" && cell1 != "" && cell2 != "" && cell3 != "" && cell4 != "")
								{
									cell1  = cell1.trim();
									cell2  = cell2.trim();
									cell3  = cell3.trim();
									cell4  = cell4.trim();
									splitAssetName  = splitAssetName.trim();

									if(cell1.length() > 20)
									{
										if (log.isErrorEnabled()) {
											log.error(" Asset Instance Version Id exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
										}
										errorsOnProc.add(" Asset Instance Version Id exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
									}

									if(cell2.length() > 100)
									{
										if (log.isErrorEnabled()) {
											log.error(" Asset Instance Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
										}
										errorsOnProc.add(" Asset Instance Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
									}

									if(cell3.length() > 10)
									{
										if (log.isErrorEnabled()) {
											log.error(" Asset Instance Version Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
										}
										errorsOnProc.add(" Asset Instance Version Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
									}

									if(cell4.length() > 50000)
									{
										if (log.isErrorEnabled()) {
											log.error(" Asset Instance Description exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
										}
										errorsOnProc.add(" Asset Instance Description exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
									}

									Boolean flagForValidation11 = false;
									String iCharsw = "!@#$%^&*()+=-[]\\\';,/{}|.\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWYZ]";
									for (int i = 0; i < cell1.length(); i++) 
									{
										if (iCharsw.indexOf(cell1.trim().charAt(i)) != -1) 
										{
											flagForValidation11= true;
											break;
										}
									}

									String iChars1 = "!%^*=[];{}|<>?~";
									Boolean flagForValidation1 = false;
									for (int k = 0; k < cell2.length(); k++) 
									{
										if (iChars1.indexOf(cell2.charAt(k)) != -1) 
										{
											flagForValidation1 = true;
											break;
										}
									}
									AssetInstance ai = new AssetInstance();
									ai.setAssetName(splitAssetName);

									Boolean flagForValidation2 = false;
									if(flag1 == true){
										String iChars2 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWXYZ]";
										for (int i = 0; i < cell3.length(); i++) 
										{
											if (iChars2.indexOf(cell3.trim().charAt(i)) != -1) 
											{
												flagForValidation2= true;
												break;
											}
										}
									}

									if(flagForValidation11)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Characters/Alphabets not allowed for Asset Instance Version Id column except XXXX from "+ cell2+"_"+cell3+ " at "+splitAssetName);
										}
										errorsOnProc.add("Special Characters/Alphabets not allowed for Asset Instance Version Id column except XXXX from "+ cell2+"_"+cell3+ " at "+splitAssetName);
									}

									if(flagForValidation1)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Character not allowed in " + cell2+" at "+splitAssetName);
										}
										errorsOnProc.add("Special Character not allowed in " + cell2+" at "+splitAssetName);
									}
									if( flagForValidation2)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Characters/Alphabets not allowed for version column " + cell2+"_"+cell3+ " at "+splitAssetName);
										}
										errorsOnProc.add("Special Characters/Alphabets not allowed for version column " + cell2+"_"+cell3+ " at "+splitAssetName);
									}

									else
									{
										if(flag1 == true){

											if(cell3.matches("([0-9]{1})") || cell3.matches("([0-9]{1}.)"))
											{
												if (log.isErrorEnabled()) {
													log.error("Error : This Version Name format not allowed  for " + cell2+" at "+splitAssetName);
												}
												errorsOnProc.add("Error : This Version Name format not allowed  for " + cell2+" at "+splitAssetName);
											}
											ai.setVersionName(cell3);
											ai.setVersionable(true);
										}
										else
										{
											if(cell3.trim().equals("NA"))
											{
												ai.setVersionName(Constants.DEFAULT_VERSION); 
												ai.setVersionable(false);
											}
											else
											{
												if (log.isErrorEnabled()) {
													log.error("Please provide valid Version Name in " + cell2+" at "+splitAssetName);
												}
												errorsOnProc.add("Please provide valid Version Name in " + cell2+" at "+splitAssetName); 
											}
										}

										ai.setAssetInstName(cell2);
										ai.setParentAssetInstName(null);
										ai.setParentAssetName(null);

										AssetInstanceVersion avVo = new AssetInstanceVersion();
										Boolean flag12 = false;
										Boolean flagforupdate = false;

										for(AssetInstanceVersion aivo:assetInstList)
										{
											if( aivo.getAssetInstVersionId().toString().equals(cell1) && aivo.getAssetInstName().equalsIgnoreCase(cell2) && aivo.getVersionName().equalsIgnoreCase(ai.getVersionName()))
											{
												aivo.setAction("update");
												flagforupdate = true;
												flag12 = true;
												break;
											}
										}
										Boolean flagdf = true;
										if(!flag12)
										{  
											if(!cell1.equals("XXXX"))
											{
												if (log.isErrorEnabled()) {
													log.error("Error Found : Please check " + cell1+","+cell2+","+cell3+" of "+splitAssetName+" Attribute sheet");
												}
												errorsOnProc.add("Error Found : Please check " + cell1+","+cell2+","+cell3+" of "+splitAssetName+" Attribute sheet");
											}

											for(AssetInstanceVersion aivo:assetInstList)
											{
												if( aivo.getAssetInstName().equalsIgnoreCase(cell2) && aivo.getVersionName().equalsIgnoreCase(ai.getVersionName()))
												{
													if(cell1.equals("XXXX"))
													{
														if (log.isErrorEnabled()) {
															log.error("Error Found : Please check " + cell1+","+cell2+","+cell3+" of "+splitAssetName+" Attribute sheet");
														}
														errorsOnProc.add("Error Found : Please check " + cell1+","+cell2+","+cell3+" of "+splitAssetName+" Attribute sheet");
														break;
													}
												}
											}

											for(AssetRelationshipDef relNm :relNameList)
											{
												if(relNm.getFwdRelationType().equals("composition") || relNm.getFwdRelationType().equals("aggregation"))
												{
													if(relNm.getDestAssetName().equalsIgnoreCase(ai.getAssetName()))
													{
														flagdf= false;
													}
												}
											}
											if(flagdf)
											{
												Boolean flagforChech = false;
												for(AssetInstanceVersion aivo:assetInstList)
												{
													if( aivo.getAction()!= null)
													{
														if( aivo.getAssetInstName().equalsIgnoreCase(cell2) && !aivo.getAction().equals("delete"))
														{
															flagforChech = true;
															break;
														}
													}
												}
												if(!flagforChech)
												{
													avVo.setAssetName(ai.getAssetName());
													avVo.setAssetInstName(cell2);
													avVo.setVersionName(ai.getVersionName());
													avVo.setAssetInstVersionId(Long.parseLong("0000"));
													cell4 = commonUtils.httpSanitizerForCkEditor(cell4);
													avVo.setDescription(cell4);
													avVo.setAction("add");
													currentExclRecStat = "add";
													assetInstList.add(avVo);
												}
												else
												{
													if (log.isErrorEnabled()) {
														log.error("Error: versions cannot be added through excel import option for full import in attribute sheet: " + cell2+"_"+cell3+" of "+splitAssetName);
													}
													errorsOnProc.add("Error: versions cannot be added through excel import option for full import in attribute sheet: " + cell2+"_"+cell3+" of "+splitAssetName);

												}
											}
										}

										if( !flagdf )
										{
											if (log.isErrorEnabled()) {
												log.error("Error: Creating Asset Instance not allowed at  " + cell2+"_"+cell3+" of "+splitAssetName + " since it is a child asset type.");
											}
											errorsOnProc.add("Error: Creating Asset Instance not allowed at  " + cell2+"_"+cell3+" of "+splitAssetName + " since it is a child asset type.");
										}
										Boolean flagCheck = false;

										for (int u=0;u<listAivo.size();u++)
										{ 
											if(listAivo.get(u).getDescription() != null){
												if(listAivo.get(u).getAssetInstName().equalsIgnoreCase(ai.getAssetInstName()) && listAivo.get(u).getVersionName().equalsIgnoreCase(ai.getVersionName())&& listAivo.get(u).getDescription().equals(cell4))
												{
													flagCheck = true;

												}
											}
										}
										if(!flagCheck)
										{
											AssetInstDescSuccess aidVo = new AssetInstDescSuccess();
											aidVo.setAssetType(ai.getAssetName());
											aidVo.setAssetInstName(ai.getAssetInstName());
											//aidVo.setAssetInstanceDescription(cell4);
											cell4 = commonUtils.httpSanitizerForCkEditor(cell4);
											aidVo.setAssetInstanceDescription(cell4);
											aidVo.setParentAssetName(ai.getParentAssetName());
											aidVo.setParentAssetInstanceName(ai.getParentAssetInstName());
											aidVo.setVersionName(ai.getVersionName());

											aisdVoList.add(aidVo);

										}
										int i = 5;
										int j = 0;
										int y = 0;
										Map<String,String> paramMapFromDb1 = new HashMap<String,String>();
										if(flagforupdate)
										{
											//boolean flagForExportAndImport = false;
											AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
											List<AssetParamDef> paramMap = new ArrayList<AssetParamDef>();
											List<AssetInstanceVersion> assetdata = assetInstanceVersionsManager.getParameter(ai.getAssetName(),userName,aiv1.getAssetInstVersionId(),conn);
											for(AssetInstanceVersion aiv: assetdata){
												AssetParamDef apd = new AssetParamDef();
												if (aiv.getIsStatic() == 1) {
													if (aiv.getParamTypeId() == 3) {
														apd.setAssetParamName(aiv.getAssetParamName());
														apd.setParamValue(aiv.getApdFileName());
													}else{
														apd.setAssetParamName(aiv.getAssetParamName());
														apd.setParamValue(aiv.getStaticValue());
													}

												} else {
													if (aiv.getParamTypeId() == 3) {
														apd.setAssetParamName(aiv.getAssetParamName());
														apd.setParamValue(aiv.getFileName());
													}else if(aiv.getParamTypeId() == 1){
														if(aiv.getTextDataList()!= null){
															String textdata = String.join("~~", aiv.getTextDataList());
															apd.setAssetParamName(aiv.getAssetParamName());
															apd.setParamValue(textdata);
														}else{
															apd.setAssetParamName(aiv.getAssetParamName());
															apd.setParamValue(aiv.getParamValue());
														}
													}else if(aiv.getParamTypeId() == 7){
														if(aiv.getRTFwithTags()!= null){
															String textdata = String.join("~~", aiv.getRTFwithTags());
															apd.setAssetParamName(aiv.getAssetParamName());
															apd.setParamValue(textdata);
														}else{
															apd.setAssetParamName(aiv.getAssetParamName());
															apd.setParamValue(aiv.getParamValue());
														}
													}else if(aiv.getParamTypeId() == 9){
														if(aiv.getLdapMappingValue() != null) {
															List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(aiv.getLdapMappingId(), conn);
															for (Map.Entry<String,Integer> entry : aiv.getLdapMappingValue().entrySet()){
																for(LdapMapping ldapAttributes:ldapMapping) {
																	if(entry.getValue() == ldapAttributes.getLdapAttributeId()) {
																		apd.setAssetParamName(aiv.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
																		apd.setParamValue(null);
																	}
																}
															}
														}
													}else {
														apd.setAssetParamName(aiv.getAssetParamName());
														apd.setParamValue(aiv.getParamValue());
													}
												}
												paramMap.add(apd);
											}
											for (AssetParamDef assetdef : paramMap) paramMapFromDb1.put(assetdef.getAssetParamName(),assetdef.getParamValue());
										}
										List<String> paramNames = new ArrayList<String>() ;
										Collections.sort(paramList, new AssetParamDef());
										for (AssetParamDef pvo: paramList)
										{
											paramNames.add(pvo.getAssetParamName());
										}
										//Collections.sort(paramNames,String.CASE_INSENSITIVE_ORDER);
										Boolean pvalflag = false;
										List<String> ldapmappingdata = new ArrayList<String>();
										List<LdapMapping> ldapAttributeList = new ArrayList<LdapMapping>();
										List<String> ldapmappingfirstattributedata = new ArrayList<String>();
										int ldapcount = 0;
										for (String  paramName: paramNames)
										{
											AssetParamSuccess apsVo = new AssetParamSuccess();
											AssetParamSuccess apevo = new AssetParamSuccess();
											String paramVal = null;
											Boolean flag = false;
											for(AssetParamDef aiv:allCatsAndParamsForAsset)
											{ 
												if(aiv.getAssetParamName().equalsIgnoreCase(paramName)){
													XSSFCell cellee1 = rowb.getCell(i++);
													if(cellee1 != null )
													{
														if (cellee1.getCellType() == XSSFCell.CELL_TYPE_STRING)
														{
															paramVal = cellee1.getStringCellValue().trim();
															if(paramVal.length() == 0)
															{
																paramVal = "";  
															}
														}
														if (cellee1.getCellType() == XSSFCell.CELL_TYPE_BLANK)
														{
															paramVal = cellee1.getStringCellValue().trim();
															if(paramVal.length() == 0)
															{
																paramVal = "";  
															}
														}
														else if(cellee1.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
														{
															int val = (int)cellee1.getNumericCellValue(); 
															paramVal = String.valueOf(val); 
														}
													}
													else
													{
														paramVal = "";
													}
													Boolean chkFilePrmValFlag1 = false;
													if(flagforupdate)
													{
														for (Map.Entry<String, String> entry1 : paramMapFromDb1.entrySet()) {

															if(paramName.equalsIgnoreCase(entry1.getKey())){

																if(/*(paramVal.isEmpty() && entry1.getValue() == null) || */(paramVal.equals(entry1.getValue())) ){

																	chkFilePrmValFlag1 = true;
																	break;
																}
															}
														}	
													}
													//List<String> list = new ArrayList<S>(allPossVals.values());LinkedHashMap<String, List<String>>()
													if(flagforupdate || (paramVal != "" && paramVal != null)){
														if(!chkFilePrmValFlag1||(aiv.isHasMandatoryValue()&&paramVal.equalsIgnoreCase(""))){
															pvalflag = true;
															if(aiv.getParamTypeId().equals(4L))
															{
																if(aiv.getListTypeParamTypeId()!=null)
																{
																	if((aiv.getListTypeParamTypeId().equals(1L)))
																	{
																		possValues = null;
																		if(globalsetting.getGlobalSettingFlag() == 1){
																			paramVal = commonUtils.httpSanitizerForPlainText(paramVal);

																			//paramVal = StringEscapeUtils.escapeHtml4(paramVal);
																		}
																		for (Entry<String, List<String>> allpvals : allPossVals.entrySet())
																		{
																			if(allpvals.getKey().equalsIgnoreCase(paramName))
																				possValues = allpvals.getValue();
																		}
																		boolean listflag = false;
																		if(!paramVal.equalsIgnoreCase("")){
																			if(paramVal.contains("~~") && aiv.getListType() == 0){
																				listflag = false;
																				apevo.setErrorMessage(" multiple values are not allowed ");
																			}else if(paramVal.endsWith("~~")){
																				listflag = false;
																			}else{
																				List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																				boolean duplicateFlag = false;
																				Set<String> duplicate = new HashSet<String>();
																				duplicate.addAll(paramValList);
																				if(duplicate.size()<paramValList.size()){
																					duplicateFlag = true;
																				}
																				if(duplicateFlag == false){
																					int count = 0;
																					for(int k=0;k<possValues.size();k++){  
																						for(int l = 0; l < paramValList.size(); l++){
																							if (possValues.get(k).equals(paramValList.get(l))) {
																								count++;
																							}
																						}
																						if(count == paramValList.size()){
																							listflag = true;
																							break;
																						}
																					}
																				}
																			}
																		}
																		if(!aiv.isHasMandatoryValue()){
																			if(paramVal.equalsIgnoreCase("")){
																				listflag = true;
																			}
																		}
																		if(listflag == true)
																		{   
																			if(paramList.size()-1 == y)
																			{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																			}
																			else{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																			}
																			apsVo.setAssetType(ai.getAssetName());
																			apsVo.setAssetInstName(ai.getAssetInstName());
																			apsVo.setVersionName(ai.getVersionName());
																			apsVo.setParentAssetName(ai.getParentAssetName());
																			apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apsVo.setParamTypeName(aiv.getTypeName());
																			apsVo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setParamName(paramName);
																			apsVo.setParamValue(paramVal);
																			apsVo.setAssetParamId(aiv.getAssetParamId());
																			apsVo.setHasStaticValue(aiv.isHasStaticValue());
																			apsVoList.add(apsVo);
																			flag = true;
																			break;

																		}
																		if(flag == false)
																		{
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apevo.setParamTypeId(aiv.getParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}

																	if((aiv.getListTypeParamTypeId().equals(2L))){
																		possValues = null;
																		for (Entry<String, List<String>> allpvals : allPossVals.entrySet())
																		{
																			if(allpvals.getKey().equalsIgnoreCase(paramName))
																				possValues = allpvals.getValue();
																		}
																		boolean listflag = false;
																		if(!paramVal.equalsIgnoreCase("")){
																			if(paramVal.contains("~~") && aiv.getListType() == 0){
																				listflag = false;
																				apevo.setErrorMessage(" multiple values are not allowed ");
																			}else if(paramVal.endsWith("~~")){
																				listflag = false;
																			}else{
																				List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																				boolean duplicateFlag = false;
																				Set<String> duplicate = new HashSet<String>();
																				duplicate.addAll(paramValList);
																				if(duplicate.size()<paramValList.size()){
																					duplicateFlag = true;
																				}
																				if(duplicateFlag == false){
																					int count = 0;
																					for(int k=0;k<possValues.size();k++){  
																						for(int l = 0; l < paramValList.size(); l++){
																							if (possValues.get(k).equals(paramValList.get(l))) {
																								count++;
																							}
																						}
																						if(count == paramValList.size()){
																							listflag = true;
																							break;
																						}
																					}
																				}
																			}
																		}
																		if(!aiv.isHasMandatoryValue()){
																			if(paramVal.equalsIgnoreCase("")){
																				listflag = true;
																			}
																		}
																		if(listflag == true)
																		{   
																			if(paramList.size()-1 == y)
																			{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																			}
																			else{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																			}
																			apsVo.setAssetType(ai.getAssetName());
																			apsVo.setAssetInstName(ai.getAssetInstName());
																			apsVo.setVersionName(ai.getVersionName());
																			apsVo.setParentAssetName(ai.getParentAssetName());
																			apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apsVo.setParamTypeName(aiv.getTypeName());
																			apsVo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setParamName(paramName);
																			apsVo.setParamValue(paramVal);
																			apsVo.setAssetParamId(aiv.getAssetParamId());
																			apsVo.setHasStaticValue(aiv.isHasStaticValue());
																			apsVoList.add(apsVo);
																			flag = true;
																			break;

																		}
																		if(flag == false)
																		{
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apevo.setParamTypeId(aiv.getParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}

																	if((aiv.getListTypeParamTypeId().equals(3L)))
																	{
																		possValues = null;
																		for (Entry<String, List<String>> allpvals : allPossVals.entrySet())
																		{
																			if(allpvals.getKey().equalsIgnoreCase(paramName))
																				possValues = allpvals.getValue();
																		}
																		boolean listflag = false;
																		if(!paramVal.equalsIgnoreCase("")){
																			if(paramVal.contains("~~") && aiv.getListType() == 0){
																				listflag = false;
																				apevo.setErrorMessage(" multiple values are not allowed ");
																			}else if(paramVal.endsWith("~~")){
																				listflag = false;
																			}else{
																				List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																				boolean duplicateFlag = false;
																				Set<String> duplicate = new HashSet<String>();
																				duplicate.addAll(paramValList);
																				if(duplicate.size()<paramValList.size()){
																					duplicateFlag = true;
																				}
																				if(duplicateFlag == false){
																					int count = 0;
																					for(int k=0;k<possValues.size();k++){  
																						for(int l = 0; l < paramValList.size(); l++){
																							if (possValues.get(k).equals(paramValList.get(l))) {
																								count++;
																							}
																						}
																						if(count == paramValList.size()){
																							listflag = true;
																							break;
																						}
																					}
																				}
																			}
																		}
																		if(!aiv.isHasMandatoryValue()){
																			if(paramVal.equalsIgnoreCase("")){
																				listflag = true;
																			}
																		}
																		if(listflag == true)
																		{   
																			if(paramList.size()-1 == y)
																			{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																			}
																			else{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																			}
																			apsVo.setAssetType(ai.getAssetName());
																			apsVo.setAssetInstName(ai.getAssetInstName());
																			apsVo.setVersionName(ai.getVersionName());
																			apsVo.setParentAssetName(ai.getParentAssetName());
																			apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apsVo.setParamTypeName(aiv.getTypeName());
																			apsVo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setParamName(paramName);
																			apsVo.setParamValue(paramVal);
																			apsVo.setAssetParamId(aiv.getAssetParamId());
																			apsVo.setHasStaticValue(aiv.isHasStaticValue());
																			apsVoList.add(apsVo);
																			flag = true;
																			break;

																		}
																		if(flag == false)
																		{
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apevo.setParamTypeId(aiv.getParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}
																	if((aiv.getListTypeParamTypeId().equals(4L)))
																	{
																		boolean listflag = false;
																		boolean invaliddataflag = false;
																		if(!paramVal.equalsIgnoreCase("")){
																			if(paramVal.contains("~~") && aiv.getListType() == 0){
																				listflag = false;
																				apevo.setErrorMessage(" multiple values are not allowed ");
																			}else if(paramVal.endsWith("~~")){
																				listflag = false;
																			}else{
																				List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																				List<String> paramValList = new ArrayList<String>();
																				List<String> finalparamValList = new ArrayList<String>();
																				List<String> names = new ArrayList<String>();
																				List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
																				for(String data:firstParamValList){
																					if(data.contains("(") && data.contains(")")){
																						//fetching search string from saved result
																						String result = data.substring(data.indexOf("(") + 1, data.indexOf(")"));
																						names.add(data);
																						paramValList.add(result);
																					}else if(data.contains("(") || data.contains(")")){
																						invaliddataflag = true;
																						listflag = false;
																						break;
																					}else{
																						paramValList.add(data);
																					}
																				}
																				boolean duplicateFlag = false;
																				Set<String> duplicate = new HashSet<String>();
																				duplicate.addAll(paramValList);
																				if(duplicate.size()<paramValList.size()){
																					duplicateFlag = true;
																				}
																				if(invaliddataflag == false){
																					if(duplicateFlag == false){
																						LDAPConnection ldapConnection = LDAPConnection.getInstance();
																						DirContext dirContext = ldapConnection.getDirContext();
																						for(String data:paramValList){
																							listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,data);
																						if(listOfLDAPUsers.size() == 1){
																						for(LDAPUser finaldata:listOfLDAPUsers){
																							//invalid firstname validation,If invalid through an error as invalid data
																							for(String name:names){
																								if(name.contains("(")){
																									String result = name.substring(name.indexOf("(") + 1, name.indexOf(")"));
																									String fullname = name.substring(0,name.indexOf("("));
																									if(result.equalsIgnoreCase(finaldata.getUserId())){
																										if(!fullname.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																											invaliddataflag = true;
																											break;
																										}
																									}
																								}
																							}
																							if(invaliddataflag == true){
																								listflag = false;
																								break;
																							}else{
																								String val = finaldata.getFirstName()+" "+finaldata.getLastName()+"("+finaldata.getUserId()+")";
																								finalparamValList.add(val);
																								listflag = true;
																							}
																						}
																					}else{
																						listflag = false;
																						break;
																					}
																						}
																						if(!finalparamValList.isEmpty()){
																							paramVal = String.join("~~", finalparamValList);
																						}
																					}
																				}
																			}
																		}
																		if(!aiv.isHasMandatoryValue()){
																			if(paramVal.equalsIgnoreCase("")){
																				listflag = true;
																			}
																		}

																		if(listflag == true)
																		{     
																			if(paramList.size()-1 == y)
																			{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																			}
																			else{
																				newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal+Constants.APPEND_STRING;	
																			}
																			apsVo.setAssetType(ai.getAssetName());
																			apsVo.setAssetInstName(ai.getAssetInstName());
																			apsVo.setVersionName(ai.getVersionName());
																			apsVo.setParentAssetName(ai.getParentAssetName());
																			apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apsVo.setParamTypeName(aiv.getTypeName());
																			apsVo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setParamName(paramName);
																			apsVo.setParamValue(paramVal);
																			apsVo.setAssetParamId(aiv.getAssetParamId());
																			apsVo.setHasStaticValue(aiv.isHasStaticValue());
																			apsVoList.add(apsVo);
																			flag = true;
																			break;
																		}
																		if(flag == false)
																		{
																			if(apevo.getParamValue() != paramVal){
																				apevo.setAssetType(ai.getAssetName());
																				apevo.setAssetInstName(ai.getAssetInstName());
																				apevo.setVersionName(ai.getVersionName());
																				apevo.setParentAssetName(ai.getParentAssetName());
																				apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																				apevo.setVersionable(ai.isVersionable());
																				apevo.setParamTypeName(aiv.getTypeName());
																				apevo.setCatName(aiv.getAssetCategoryName());
																				apevo.setParamTypeId(aiv.getParamTypeId());
																				apevo.setParamName(paramName);
																				apevo.setParamValue(paramVal);
																				apevo.setAssetParamId(aiv.getAssetParamId());
																				apeVoList.add(apevo);
																			}
																		}
																	}
																}
															}
															else if((aiv.getParamTypeId().equals(2L)))
															{
																if (paramVal.matches("(^(((0[1-9]|[12][0-8])[/](0[1-9]|1[012]))|((29|30|31)[/](0[13578]|1[02]))|((29|30)[/](0[4,6,9]|11)))[/](19|[2-9][0-9])\\d\\d$)|(^29[/]02[/](19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)") || paramVal.equalsIgnoreCase("")) {
																	if(paramVal != ""){
																		String[] words = paramVal.split("/");
																		int num = Integer.parseInt(words[2]);
																		if(num > 2999)
																		{
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																		else
																		{
																			if(paramList.size()-1 == y)
																			{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																			}
																			else{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																			}
																			apsVo.setAssetType(ai.getAssetName());
																			apsVo.setAssetInstName(ai.getAssetInstName());
																			apsVo.setVersionName(ai.getVersionName());
																			apsVo.setParentAssetName(ai.getParentAssetName());
																			apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apsVo.setParamTypeName(aiv.getTypeName());
																			apsVo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																			apsVo.setParamName(paramName);
																			apsVo.setParamValue(paramVal);
																			apsVo.setAssetParamId(aiv.getAssetParamId());
																			apsVo.setHasStaticValue(aiv.isHasStaticValue());
																			apsVoList.add(apsVo);
																			flag = true;
																		}
																	}
																	else
																	{
																		if(!aiv.isHasMandatoryValue()){
																			if(paramList.size()-1 == y)
																			{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																			}
																			else{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																			}
																			apsVo.setAssetType(ai.getAssetName());
																			apsVo.setAssetInstName(ai.getAssetInstName());
																			apsVo.setVersionName(ai.getVersionName());
																			apsVo.setParentAssetName(ai.getParentAssetName());
																			apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apsVo.setParamTypeName(aiv.getTypeName());
																			apsVo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																			apsVo.setParamName(paramName);
																			apsVo.setParamValue(paramVal);
																			apsVo.setAssetParamId(aiv.getAssetParamId());
																			apsVo.setHasStaticValue(aiv.isHasStaticValue());
																			apsVoList.add(apsVo);
																			flag = true;
																		}
																		if(flag == false)
																		{
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apevo.setParamTypeId(aiv.getParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}
																}
																else
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}
															else if((aiv.getParamTypeId().equals(1L)))
															{
																boolean nonStaticCheck = true;
																if(globalsetting.getGlobalSettingFlag() == 1){
																	//paramVal = StringEscapeUtils.escapeHtml4(paramVal);
																	paramVal = commonUtils.httpSanitizerForPlainText(paramVal);
																}
																if(paramVal.startsWith("~~")||paramVal.endsWith("~~")){
																	nonStaticCheck = false;
																}else if(aiv.isHasStaticValue()){

																	if(paramVal.contains("~~")){
																		nonStaticCheck = false;
																		apevo.setErrorMessage(" multiple values are not allowed since parameter type is static! ");
																	}
																}else if(aiv.getHasArray() == 0){

																	if(paramVal.contains("~~")){
																		nonStaticCheck = false;
																		apevo.setErrorMessage(" multiple values are not allowed ");
																	}
																}
																if(nonStaticCheck == true){
																	if(!paramVal.equalsIgnoreCase(""))
																	{
																		if(paramList.size()-1 == y)
																		{
																			newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																		}
																		else{
																			newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																		}
																		apsVo.setAssetType(ai.getAssetName());
																		apsVo.setAssetInstName(ai.getAssetInstName());
																		apsVo.setVersionName(ai.getVersionName());
																		apsVo.setParentAssetName(ai.getParentAssetName());
																		apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apsVo.setParamTypeName(aiv.getTypeName());
																		apsVo.setCatName(aiv.getAssetCategoryName());
																		apsVo.setParamTypeId(aiv.getParamTypeId());
																		apsVo.setParamName(paramName);
																		//apsVo.setParamValue(paramVal);
																		apsVo.setHasStaticValue(aiv.isHasStaticValue());
																		apsVo.setHasArray(aiv.getHasArray());
																		apsVo.setAssetParamId(aiv.getAssetParamId());
																		boolean sizecheck = true;
																		if(aiv.isHasStaticValue()){
																			apsVo.setParamValue(paramVal);
																			if(paramVal.length()>(aiv.getSize())){
																				sizecheck = false;
																			}
																			apsVoList.add(apsVo);
																			if(sizecheck == true){
																				flag = true;
																			}
																		}else if(aiv.getHasArray() == 0){
																			apsVo.setParamValue(paramVal);
																			if(paramVal.length()>(aiv.getSize())){
																				sizecheck = false;
																			}
																			apsVoList.add(apsVo);
																			if(sizecheck == true){
																				flag = true;
																			}
																		}else{
																			List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																			boolean emptyCheck = true;
																			for(String data:paramValList){
																				String val = data.trim();
																				if(val.equalsIgnoreCase("")){
																					emptyCheck = false;
																					break;
																				}
																			}
																			if(emptyCheck == true){
																				apsVo.setTextDataList(paramValList);
																				for(String data:apsVo.getTextDataList()){
																					if(data.length()>(aiv.getSize())){
																						sizecheck = false;
																						break;
																					}
																				}
																				apsVoList.add(apsVo);
																				if(sizecheck == true){
																					flag = true;
																				}
																			}
																		}
																	}else { 
																		if(!aiv.isHasMandatoryValue()){
																			if(paramVal.equalsIgnoreCase("")){

																				if(paramList.size()-1 == y)
																				{
																					newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																				}
																				else{
																					newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																				}
																				apsVo.setAssetType(ai.getAssetName());
																				apsVo.setAssetInstName(ai.getAssetInstName());
																				apsVo.setVersionName(ai.getVersionName());
																				apsVo.setParentAssetName(ai.getParentAssetName());
																				apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																				apsVo.setParamTypeName(aiv.getTypeName());
																				apsVo.setCatName(aiv.getAssetCategoryName());
																				apsVo.setParamTypeId(aiv.getParamTypeId());
																				apsVo.setParamName(paramName);
																				if(aiv.isHasStaticValue()){
																					apsVo.setParamValue(paramVal);
																				}else if(aiv.getHasArray() == 0){
																					apsVo.setParamValue(paramVal);
																				}else{
																					List<String> paramValList = new ArrayList<String>();
																					apsVo.setTextDataList(paramValList);;
																				}
																				apsVo.setHasStaticValue(aiv.isHasStaticValue());
																				apsVo.setHasArray(aiv.getHasArray());
																				apsVo.setAssetParamId(aiv.getAssetParamId());
																				apsVoList.add(apsVo);
																				flag = true;
																			}
																		}
																	}
																	if(flag == false)
																	{

																		apevo.setAssetType(ai.getAssetName());
																		apevo.setAssetInstName(ai.getAssetInstName());
																		apevo.setVersionName(ai.getVersionName());
																		apevo.setParentAssetName(ai.getParentAssetName());
																		apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apevo.setVersionable(ai.isVersionable());
																		apevo.setParamTypeName(aiv.getTypeName());
																		apevo.setCatName(aiv.getAssetCategoryName());
																		apevo.setParamTypeId(aiv.getParamTypeId());
																		apevo.setParamName(paramName);
																		apevo.setParamValue(paramVal);
																		apevo.setAssetParamId(aiv.getAssetParamId());
																		apeVoList.add(apevo);
																	}
																}else{

																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);

																}
															}

															else if((aiv.getParamTypeId().equals(5L))||aiv.getParamTypeId().equals(6L)||aiv.getParamTypeId().equals(8L))
															{
																flag = true;
															}
															else if((aiv.getParamTypeId().equals(7L)))
															{
																boolean nonStaticCheck = true;
																if(globalsetting.getGlobalSettingFlag() == 1){
																	//paramVal = StringEscapeUtils.escapeHtml4(paramVal);
																	paramVal = commonUtils.httpSanitizerForCkEditor(paramVal);

																}
																if(paramVal.startsWith("~~")||paramVal.endsWith("~~")){
																	nonStaticCheck = false;
																}else if(aiv.isHasStaticValue()){

																	if(paramVal.contains("~~")){
																		nonStaticCheck = false;
																		apevo.setErrorMessage(" multiple values are not allowed since parameter type is static! ");
																	}
																}else if(aiv.getHasArray() == 0){

																	if(paramVal.contains("~~")){
																		nonStaticCheck = false;
																		apevo.setErrorMessage(" multiple values are not allowed");
																	}
																}
																if(nonStaticCheck == true){
																	if(!paramVal.equalsIgnoreCase("")){
																		if(paramList.size()-1 == y)
																		{
																			newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																		}
																		else{
																			newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																		}
																		apsVo.setAssetType(ai.getAssetName());
																		apsVo.setAssetInstName(ai.getAssetInstName());
																		apsVo.setVersionName(ai.getVersionName());
																		apsVo.setParentAssetName(ai.getParentAssetName());
																		apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apsVo.setParamTypeName(aiv.getTypeName());
																		apsVo.setCatName(aiv.getAssetCategoryName());
																		apsVo.setParamTypeId(aiv.getParamTypeId());
																		apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																		apsVo.setParamName(paramName);
																		boolean sizecheck = true;
																		if(aiv.isHasStaticValue()){
																			apsVo.setParamValue(paramVal);
																			if(paramVal.length()>25000){
																				sizecheck = false;
																			}
																			apsVo.setAssetParamId(aiv.getAssetParamId());
																			apsVo.setHasStaticValue(aiv.isHasStaticValue());
																			apsVo.setHasArray(aiv.getHasArray());
																			apsVoList.add(apsVo);
																			if(sizecheck == true){
																				flag = true;
																			}
																		}else if(aiv.getHasArray() == 0){
																			apsVo.setParamValue(paramVal);
																			if(paramVal.length()>25000){
																				sizecheck = false;
																			}
																			String textdata = Jsoup.parse(paramVal).text();
																			apsVo.setRTFPlainText(textdata);
																			apsVo.setAssetParamId(aiv.getAssetParamId());
																			apsVo.setHasStaticValue(aiv.isHasStaticValue());
																			apsVo.setHasArray(aiv.getHasArray());
																			apsVoList.add(apsVo);
																			if(sizecheck == true){
																				flag = true;
																			}
																		}else{
																			List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																			boolean emptyCheck = true;
																			for(String data:paramValList){
																				String val = data.trim();
																				if(val.equalsIgnoreCase("")){
																					emptyCheck = false;
																					break;
																				}
																			}
																			if(emptyCheck == true){
																				apsVo.setRTFwithTags(paramValList);
																				List<String> withOuttags = new ArrayList<String>();
																				for(String data:apsVo.getRTFwithTags()){
																					if(data.length()>25000){
																						sizecheck = false;
																						break;
																					}
																					String textdata = Jsoup.parse(data).text();
																					withOuttags.add(textdata);
																				}
																				apsVo.setRTFwithOutTags(withOuttags);
																				apsVo.setAssetParamId(aiv.getAssetParamId());
																				apsVo.setHasStaticValue(aiv.isHasStaticValue());
																				apsVo.setHasArray(aiv.getHasArray());
																				apsVoList.add(apsVo);
																				if(sizecheck == true){
																					flag = true;
																				}
																			}
																		}
																	}else{
																		if(!aiv.isHasMandatoryValue()){
																			if(paramVal.equalsIgnoreCase("")){

																				if(paramList.size()-1 == y)
																				{
																					newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																				}
																				else{
																					newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																				}
																				apsVo.setAssetType(ai.getAssetName());
																				apsVo.setAssetInstName(ai.getAssetInstName());
																				apsVo.setVersionName(ai.getVersionName());
																				apsVo.setParentAssetName(ai.getParentAssetName());
																				apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																				apsVo.setParamTypeName(aiv.getTypeName());
																				apsVo.setCatName(aiv.getAssetCategoryName());
																				apsVo.setParamTypeId(aiv.getParamTypeId());
																				apsVo.setParamName(paramName);
																				apsVo.setParamValue(paramVal);
																				apsVo.setHasStaticValue(aiv.isHasStaticValue());
																				apsVo.setHasArray(aiv.getHasArray());
																				apsVo.setAssetParamId(aiv.getAssetParamId());
																				if(aiv.isHasStaticValue()){
																					apsVo.setParamValue(paramVal);
																					apsVoList.add(apsVo);
																					flag = true;
																				}else if(aiv.getHasArray() == 0){
																					apsVo.setParamValue(paramVal);
																					apsVo.setRTFPlainText(paramVal);
																					apsVoList.add(apsVo);
																					flag = true;
																				}else{
																					List<String> paramValList = new ArrayList<String>();
																					paramValList.add(paramVal);
																					apsVo.setRTFwithTags(paramValList);
																					List<String> withOuttags = new ArrayList<String>();
																					withOuttags.add(paramVal);
																					apsVo.setRTFwithOutTags(withOuttags);
																					apsVoList.add(apsVo);
																					flag = true;
																				}
																			}
																		}
																	}
																	if(flag == false)
																	{
																		apevo.setAssetType(ai.getAssetName());
																		apevo.setAssetInstName(ai.getAssetInstName());
																		apevo.setVersionName(ai.getVersionName());
																		apevo.setParentAssetName(ai.getParentAssetName());
																		apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apevo.setVersionable(ai.isVersionable());
																		apevo.setParamTypeName(aiv.getTypeName());
																		apevo.setCatName(aiv.getAssetCategoryName());
																		apevo.setParamTypeId(aiv.getParamTypeId());
																		apevo.setParamName(paramName);
																		apevo.setParamValue(paramVal);
																		apevo.setAssetParamId(aiv.getAssetParamId());
																		apeVoList.add(apevo);
																	}
																}else{

																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}else if(aiv.getParamTypeId().equals(9L)) {
																if(ldapcount == ldapAttributeList.size()) {
																	ldapmappingdata.clear();
																	ldapmappingfirstattributedata.clear();
																	ldapcount = 0;
																	ldapDuplicateCount = 0;
																}
																String ldapParameter = null; 
																Map<String,Integer> finalParamValList = new LinkedHashMap<String,Integer>();
																String[] ldapMappingParameter = paramName.split("_",2);
																if(ldapDuplicateCount == 0) {
																	
																	ldapAttributeList = assetDao.getLdapMappingAttributeList(aiv.getLdapMappingId(), conn);
																	ldapParameter = ldapMappingParameter[0];
																	String attribute = ldapMappingParameter[1];
																	String attributeName = "";
																	for(LdapMapping displayName:ldapAttributeList) {
																		if(displayName.getAttributeDisplayName().equalsIgnoreCase(attribute)) {
																			attributeName = displayName.getAttributeName().substring(3);
																		}
																	}
																	
																	ldapDuplicateCount++;
																	ldapcount++;
																	boolean listflag = false;
																	//boolean zerolistflag = false;
																	boolean invaliddataflag = false;
																	if(!paramVal.equalsIgnoreCase("")){
																		if(paramVal.contains("~~") && aiv.getListType() == 0){
																			listflag = false;
																			apevo.setErrorMessage(" multiple values are not allowed ");
																		}else if(paramVal.endsWith("~~")){
																			listflag = false;
																		}else{
																			List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																			List<String> paramValList = new ArrayList<String>();
																			List<String> finalparamValList = new ArrayList<String>();
																			List<String> names = new ArrayList<String>();
																			List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
																			for(String data:firstParamValList){
																				if(data.contains("(") && data.contains(")")){
																					//fetching search string from saved result
																					String result = data.substring(data.indexOf("(") + 1, data.indexOf(")"));
																					names.add(data);
																					paramValList.add(result);
																				}else if(data.contains("(") || data.contains(")")){
																					invaliddataflag = true;
																					listflag = false;
																					break;
																				}else{
																					paramValList.add(data);
																				}
																			}
																			boolean duplicateFlag = false;
																			Set<String> duplicate = new HashSet<String>();
																			duplicate.addAll(paramValList);
																			if(duplicate.size()<paramValList.size()){
																				duplicateFlag = true;
																			}
																			ldapmappingfirstattributedata.addAll(paramValList);
																			if(invaliddataflag == false){
																				if(duplicateFlag == false){
																					LDAPConnection ldapConnection = LDAPConnection.getInstance();
																					DirContext dirContext = ldapConnection.getDirContext();
																					for(String data:paramValList){
																						listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,data);
																						invaliddataflag = ldapMappingAttributeValidation(listOfLDAPUsers, firstParamValList, attributeName);
																						if(listOfLDAPUsers.size() == 1){
																							for(LDAPUser finaldata:listOfLDAPUsers){
																								//invalid firstname validation,If invalid throw an error as invalid data
																								for(String name:names){
																									if(name.contains("(")){
																										String result = name.substring(name.indexOf("(") + 1, name.indexOf(")"));
																										String fullname = name.substring(0,name.indexOf("("));
																										if(result.equalsIgnoreCase(finaldata.getUserId())){
																											if(!fullname.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																												invaliddataflag = true;
																												break;
																											}
																										}
																									}
																								}
																								if(invaliddataflag == true){
																									listflag = false;
																									break;
																								}else{
																									String val = finaldata.getUserId();
																									finalparamValList.add(val);
																									listflag = true;
																								}
																							}
																						}else{
																							listflag = false;
																							break;
																						}
																					}
																					if(!finalparamValList.isEmpty()){
																						String ldapfinalstring = String.join("~~", finalparamValList);
																						finalParamValList = commonUtils.ldapDataconstruction(ldapfinalstring,ai.getAssetName(),ldapParameter,conn);
																						ldapmappingdata = finalParamValList.keySet().stream().collect(Collectors.toList());
																						paramVal = String.join("``", ldapmappingdata);
																					}
																				}
																			}
																		}
																	}
																	if(!aiv.isHasMandatoryValue()){
																		if(paramVal.equalsIgnoreCase("")){
																			listflag = true;
																		}
																	}

																	if(listflag == true)
																	{     
																		if(paramList.size()-1 == y)
																		{
																			newParamDataForRevision = newParamDataForRevision + ldapParameter+":"+ paramVal;
																		}
																		else{
																			newParamDataForRevision = newParamDataForRevision +ldapParameter+":"+ paramVal+Constants.APPEND_STRING;	
																		}
																		apsVo.setAssetType(ai.getAssetName());
																		apsVo.setAssetInstName(ai.getAssetInstName());
																		apsVo.setVersionName(ai.getVersionName());
																		apsVo.setParentAssetName(ai.getParentAssetName());
																		apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apsVo.setParamTypeName(aiv.getTypeName());
																		apsVo.setCatName(aiv.getAssetCategoryName());
																		apsVo.setParamTypeId(aiv.getParamTypeId());
																		apsVo.setParamName(ldapParameter);
																		apsVo.setParamValue(paramVal);
																		apsVo.setLdapMappingValue(finalParamValList);
																		apsVo.setAssetParamId(aiv.getAssetParamId());
																		apsVo.setHasStaticValue(aiv.isHasStaticValue());
																		apsVoList.add(apsVo);
																		flag = true;
																		break;
																	}
																	//if(zerolistflag == false){
																	if(flag == false)
																	{
																		if(apevo.getParamValue() != paramVal){
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apevo.setParamTypeId(aiv.getParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}
																}else {
																	ldapcount++;
																	ldapParameter = ldapMappingParameter[0];
																	String attribute = ldapMappingParameter[1];
																	String attributeName = "";
																	for(LdapMapping displayName:ldapAttributeList) {
																		if(displayName.getAttributeDisplayName().equalsIgnoreCase(attribute)) {
																			attributeName = displayName.getAttributeName().substring(3);
																		}
																	}
																	boolean listflag = false;
																	//boolean zerolistflag = false;
																	boolean invaliddataflag = false;
																	if(!paramVal.equalsIgnoreCase("")){
																		if(paramVal.contains("~~") && aiv.getListType() == 0){
																			listflag = false;
																			apevo.setErrorMessage(" multiple values are not allowed ");
																		}else if(paramVal.endsWith("~~")){
																			listflag = false;
																		}else{
																			List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																			List<String> paramValList = new ArrayList<String>();
																			List<String> finalparamValList = new ArrayList<String>();
																			List<String> names = new ArrayList<String>();
																			List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
																			for(String data:firstParamValList){
																				if(data.contains("(") && data.contains(")")){
																					//fetching search string from saved result
																					String result = data.substring(data.indexOf("(") + 1, data.indexOf(")"));
																					names.add(data);
																					paramValList.add(result);
																				}else if(data.contains("(") || data.contains(")")){
																					invaliddataflag = true;
																					listflag = false;
																					break;
																				}else{
																					paramValList.add(data);
																				}
																			}
																			boolean duplicateFlag = false;
																			Set<String> duplicate = new HashSet<String>();
																			duplicate.addAll(paramValList);
																			if(duplicate.size()<paramValList.size()){
																				duplicateFlag = true;
																			}
																			if(invaliddataflag == false){
																				if(duplicateFlag == false){
																					LDAPConnection ldapConnection = LDAPConnection.getInstance();
																					DirContext dirContext = ldapConnection.getDirContext();
																					for(String data:ldapmappingfirstattributedata){
																						listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,data);
																						invaliddataflag = ldapMappingAttributeValidation(listOfLDAPUsers, firstParamValList, attributeName);
																						if(listOfLDAPUsers.size() == 1){
																							for(LDAPUser finaldata:listOfLDAPUsers){
																								//invalid firstname validation,If invalid throw an error as invalid data
																								for(String name:names){
																									if(name.contains("(")){
																										String result = name.substring(name.indexOf("(") + 1, name.indexOf(")"));
																										String fullname = name.substring(0,name.indexOf("("));
																										if(result.equalsIgnoreCase(finaldata.getUserId())){
																											if(!fullname.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																												invaliddataflag = true;
																												break;
																											}
																										}
																									}
																								}
																							}
																							if(invaliddataflag == true){
																								listflag = false;
																								break;
																							}else{
																								//finalParamValList = commonUtils.ldapDataconstruction(finaldata.getUserId(),ai.getAssetName(),ldapParameter,conn);
																								//ldapmappingdata = finalParamValList.keySet().stream().collect(Collectors.toList());

																								listflag = true;
																							}
																						}else{
																							listflag = false;
																							break;
																						}
																					}
																					if(!finalparamValList.isEmpty()){
																						paramVal = String.join("``", finalparamValList);
																					}
																				}
																			}
																		}
																	}
																	if(!aiv.isHasMandatoryValue()){
																		if(paramVal.equalsIgnoreCase("")){
																			listflag = true;
																		}
																	}
																	if(listflag == true)
																	{     
																		flag = true;
																		break;
																	}
																	if(flag == false){
																		if(apevo.getParamValue() != paramVal){
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apevo.setParamTypeId(aiv.getParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}
																}
															
															}
															else
															{
																Boolean chkFilePrmValFlag = false;
																if(!currentExclRecStat.equalsIgnoreCase("add")){
																	for (Map.Entry<String, String> entry2 : paramMapFromDb1.entrySet()) {
																		if(paramName.equalsIgnoreCase(entry2.getKey())){
																			if(!paramVal.equalsIgnoreCase(entry2.getValue())){
																				chkFilePrmValFlag = true;
																			}
																		}
																	}	
																}  

																if((chkFilePrmValFlag && currentExclRecStat.equalsIgnoreCase("none")) || currentExclRecStat.equalsIgnoreCase("add")||(aiv.isHasMandatoryValue()&&paramVal.equalsIgnoreCase(""))){
																	if( paramVal != ""  && paramVal != null)
																	{
																		File folder = new File(System.getProperty("user.home")+"/RepoProUnzip/");
																		File[] listOfFiles = folder.listFiles();
																		if(listOfFiles != null ){
																			for (int g = 0; g < listOfFiles.length; g++) 
																			{
																				if (listOfFiles[g].isFile()) {
																					if(listOfFiles[g].getName().equalsIgnoreCase(paramVal))
																					{
																						if(paramList.size()-1 == y)
																						{
																							newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																						}
																						else{
																							newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																						}
																						apsVo.setAssetType(ai.getAssetName());
																						apsVo.setAssetInstName(ai.getAssetInstName());
																						apsVo.setVersionName(ai.getVersionName());
																						apsVo.setParentAssetName(ai.getParentAssetName());
																						apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																						apsVo.setParamTypeName(aiv.getTypeName());
																						apsVo.setCatName(aiv.getAssetCategoryName());
																						apsVo.setParamTypeId(aiv.getParamTypeId());
																						apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																						apsVo.setParamName(paramName);
																						apsVo.setParamValue(paramVal);
																						apsVo.setAssetParamId(aiv.getAssetParamId());
																						apsVo.setHasStaticValue(aiv.isHasStaticValue());
																						apsVoList.add(apsVo);
																						flag = true;
																					}
																				}
																			}
																			if(flag == false){
																				apevo.setFileExist("Not Found");
																			}
																		}
																		else
																		{
																			apevo.setFileExist("Not Found");

																		}

																		if(flag == false)
																		{
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}

																	else
																	{
																		if(!aiv.isHasMandatoryValue()){
																			if(paramList.size()-1 == y)
																			{
																				newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																			}
																			else{
																				newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal+Constants.APPEND_STRING;	
																			}
																			apsVo.setAssetType(ai.getAssetName());
																			apsVo.setAssetInstName(ai.getAssetInstName());
																			apsVo.setVersionName(ai.getVersionName());
																			apsVo.setParentAssetName(ai.getParentAssetName());
																			apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apsVo.setParamTypeName(aiv.getTypeName());
																			apsVo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																			apsVo.setParamName(paramName);
																			apsVo.setParamValue(paramVal);
																			apsVo.setAssetParamId(aiv.getAssetParamId());
																			apsVo.setHasStaticValue(aiv.isHasStaticValue());
																			apsVoList.add(apsVo);
																			flag = true;
																		}
																		if(flag == false)
																		{
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apsVo.setParamTypeId(aiv.getParamTypeId());
																			apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}
																}
															}
														}
													}
													if(paramList.size()-1 == j){
														break;
													}
													if(allCatsAndParamsForAsset.size()-1 > j)
													{
														j++;
													}
													else
													{
														j = 0;
													}
													y++;
												}
											}
										}


										XSSFCell cellii = rowb.getCell(i++);

										String val = null;
										if(cellii == null){
											val = "";
										}
										else{
											if (cellii.getCellType() == XSSFCell.CELL_TYPE_BLANK)
											{
												val = cellii.getStringCellValue();
												if(val.length() == 0)
												{
													val = "";  
												}
											}
											if(cellii.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
											{

												int val1 = (int)cellii.getNumericCellValue(); 
												val = String.valueOf(val1); 
											}
											if(cellii.getCellType() == XSSFCell.CELL_TYPE_STRING)
											{
												val = cellii.getStringCellValue();
											}
										}
										if(flagforupdate || (val != "" && val != null))
										{
											String[] addedTaxIds = new String[]{};
											String[] addedTaxIds1 = new String[]{};
											AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();

											aiatVo.setAssetName(ai.getAssetName());
											aiatVo.setAssetInstanceName(ai.getAssetInstName());
											aiatVo.setVersionName(ai.getVersionName());
											List<Long> idsForTaxon = new ArrayList<Long>();
											if(val.endsWith(","))
											{
												if (log.isErrorEnabled()) {
													log.error("Please provide a valid taxonomy for " + ai.getAssetInstName()+"_"+ai.getVersionName()+" of "+ai.getAssetName());
												}
												errorsOnProc.add("Please provide a valid taxonomy for " + ai.getAssetInstName()+"_"+ai.getVersionName()+" of "+ai.getAssetName());
											}
											else
											{
												if(val.length() > 0 )
												{
													if(!allTxs.isEmpty())
													{
														addedTaxIds = val.split(",");
														Boolean flag2 = true;


														for(int t =0; t< addedTaxIds.length && flag2; t++)
														{
															List<TaxonomyMaster> tmpTaxList = tmList;
															addedTaxIds1 = addedTaxIds[t].split("/");

															for(int h =0; h< addedTaxIds1.length; h++)
															{
																Boolean flag = false;
																Long taxNextId = null;
																for(TaxonomyMaster tm:tmpTaxList)
																{
																	if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
																		flag = true;
																		taxNextId = tm.getTaxonomyId();
																		break;
																	}
																}
																if(!flag)
																{
																	if (log.isErrorEnabled()) {
																		log.error("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
																	}
																	errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
																	flag2 = false;
																	break;
																}
																else
																{
																	for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
																	{
																		if(entry.getKey() ==  taxNextId)
																		{ 
																			tmpTaxList = entry.getValue();
																		}
																	}
																}
																if(h == addedTaxIds1.length-1)
																{

																	Boolean fl = false;
																	Boolean f2 = false;

																	if(associatedTaxId.contains(taxNextId)){

																	}
																	else{
																		f2 = true;
																	}

																	for(Long Id:idsForTaxon)
																	{
																		if(Id.equals(taxNextId))
																		{
																			fl = true;
																			break;
																		}

																	}
																	if(fl)
																	{
																		if (log.isErrorEnabled()) {
																			log.error("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
																		}
																		errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()); 
																	}
																	if(f2)
																	{
																		if (log.isErrorEnabled()) {
																			log.error("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset");
																		}
																		errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset"); 
																	}
																	else
																	{
																		idsForTaxon.add(taxNextId);
																	}
																}
															}
														}
													}
													else{
														if (log.isErrorEnabled()) {
															log.error("No taxonomy is associated with "+ai.getAssetName()+" asset");
														}
														errorsOnProc.add("No taxonomy is associated with "+ai.getAssetName()+" asset");
													}
												}

												else
												{
													idsForTaxon = Collections.<Long>emptyList();
												}
												aiatVo.setTaxonIds(idsForTaxon);
												assetInstassignList.add(aiatVo);
											}
										}

										XSSFCell celloo = rowb.getCell(i++);

										String valueTag = null;
										if(celloo == null)
										{
											valueTag = "";
										}
										else
										{
											if (celloo.getCellType() == XSSFCell.CELL_TYPE_BLANK)
											{
												valueTag = celloo.getStringCellValue();
												if(valueTag.length() == 0)
												{
													valueTag = "";  
												}
											}
											if(celloo.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
											{

												int val1 = (int)celloo.getNumericCellValue(); 
												valueTag = String.valueOf(val1); 
											}
											if(celloo.getCellType() == XSSFCell.CELL_TYPE_STRING)
											{
												valueTag = celloo.getStringCellValue();
											}
										}
										if(flagforupdate || (valueTag != "" && valueTag != null))
										{
											String iChars = "!@#$%^&*()+=[]\\\';./{}|\":<>?~";
											Boolean flagForValidation = false;
											for (int k = 0; k < valueTag.length(); k++) 
											{
												if (iChars.indexOf(valueTag.charAt(k)) != -1) 
												{
													flagForValidation = true;
													break;
												}
											}

											if(flagForValidation)
											{
												if (log.isErrorEnabled()) {
													log.error("Special Character not allowed for tagging in " + ai.getAssetInstName()+" of "+ai.getAssetName());
												}
												errorsOnProc.add("Special Character not allowed for tagging in " + ai.getAssetInstName()+" of "+ai.getAssetName()); 
											}
											else
											{
												if(valueTag.endsWith(","))
												{
													if (log.isErrorEnabled()) {
														log.error("Please provide a valid tag name " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
													}
													errorsOnProc.add("Please provide a valid tag name " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
												}
												else{
													String[] addedTagIds = new String[]{};

													AssetInstAssignTagging aiatVo1 = new AssetInstAssignTagging();

													aiatVo1.setAssetName(ai.getAssetName());
													aiatVo1.setAssetInstanceName(ai.getAssetInstName());
													aiatVo1.setVersionName(ai.getVersionName());
													List<String> tagNameXls = new ArrayList<String>();

													if(valueTag.length() > 0 )
													{
														addedTagIds = valueTag.split(",");
														for(int t =0; t< addedTagIds.length; t++)
														{
															if(addedTagIds[t].trim().length() > 50)
															{
																if (log.isErrorEnabled()) {
																	log.error(" Tag Name exceeds max length for " + cell2+"_"+cell3+" of "+splitAssetName);
																}
																errorsOnProc.add(" Tag Name exceeds max length for " + cell2+"_"+cell3+" of "+splitAssetName);
															}
															Boolean flagForDupTag = false;

															for (int l=0; l<addedTagIds.length; l++){
																for (int m=l+1; m<addedTagIds.length; m++){
																	if (addedTagIds[m].trim().equalsIgnoreCase(addedTagIds[l].trim())){
																		flagForDupTag = true;
																		break;
																	}
																}
															}
															if(flagForDupTag){
																if (log.isErrorEnabled()) {
																	log.error("Duplicate Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
																}
																errorsOnProc.add("Duplicate Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
																break;
															}
															else
															{
																if(!addedTagIds[t].trim().isEmpty() )
																{
																	tagNameXls.add(addedTagIds[t].trim());
																}
																else
																{
																	if (log.isErrorEnabled()) {
																		log.error("Empty Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
																	}
																	errorsOnProc.add("Empty Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
																	break;
																}
															}
														}
													}
													aiatVo1.setTagsFromXls(tagNameXls);
													assetInstTaggingList.add(aiatVo1);
												}
											}
										}

										if(pvalflag ){
											prhVo.setAssetName(ai.getAssetName());

											prhVo.setAssetInstName(ai.getAssetInstName());

											prhVo.setVersionName(ai.getVersionName());

											prhVo.setParamRevData(newParamDataForRevision);

											azds.add(prhVo);
										}
									}

									int counter = 0;

									if(cell3.equals("NA"))
									{
										cell3 = Constants.DEFAULT_VERSION;
									}
									for(int t=0;t<excelassetInstList.size();t++)
									{
										if(excelassetInstList.get(t).getAssetName().equalsIgnoreCase(splitAssetName)&& excelassetInstList.get(t).getAssetInstName().equalsIgnoreCase(cell2) && excelassetInstList.get(t).getVersionName().equalsIgnoreCase(cell3))
										{
											counter++;
										}
									}
									if(counter>1)
									{
										if (log.isErrorEnabled()) {
											log.error("Duplicate Asset Instance Name/Asset Instance Version Id/Version Name found for "+cell2+"_"+cell3+" at "+splitAssetName +" Attribute Sheet");
										}
										errorsOnProc.add("Duplicate Asset Instance Name/Asset Instance Version Id/Version Name found for "+cell2+"_"+cell3+" at "+splitAssetName +" Attribute Sheet");
										break;
									}
								}
								else
								{
									if((row.getRowNum() != 2) && (cell1 == "" || cell2 == "" || cell3 == "" || cell4 == ""))								{
										if (log.isErrorEnabled()) {
											log.error("Empty data not allowed for Asset Instance Version Id/Asset Instance Name/Version Name/Overview columns of "+splitAssetName +" Attribute Sheet");
										}
										errorsOnProc.add("Empty data not allowed for Asset Instance Version Id/Asset Instance Name/Version Name/Overview columns of "+splitAssetName +" Attribute Sheet");
										break;
									}
								}
							}

							String  assetInstVersionCheck = null;
							String assetInstNamCheck = null;
							for(AssetRelationshipDef relNm :relNameList)
							{
								if(relNm.getFwdRelationType().equals("composition") || relNm.getFwdRelationType().equals("aggregation"))
								{
									for(AssetInstanceVersion aivo:assetInstList)
									{
										if( aivo.getAction()!= null)
										{
											if(relNm.getSrcAssetName().equalsIgnoreCase(splitAssetName) && aivo.getAction().equals("delete"))
											{
												assetInstNamCheck = aivo.getAssetInstName();
												assetInstVersionCheck = aivo.getVersionName();
												if (log.isErrorEnabled()) {
													log.error("Error: Source asset instance of composition and aggregation cannot be deleted through excel import option for " + assetInstNamCheck+"_"+assetInstVersionCheck+" of "+splitAssetName+"\n");
												}
												errorsOnProc.add("Error: Source asset instance of composition and aggregation cannot be deleted through excel import option for " + assetInstNamCheck+"_"+assetInstVersionCheck+" of "+splitAssetName+"\n");
											}
										}
									}
								}
							}
							listOfassetInstList.put(splitAssetName, assetInstList);
						}
					}

					log.info("Asset Attribute 2nd level validation done for full import");

					List<AssetInstRelationship>  excelassetInstRelList = null ;

					Map<String,List<AssetInstRelationship>> listOfassetInstRelList = new LinkedHashMap<String,List<AssetInstRelationship>>();

					if(errorsOnProc.size() == 0 && apeVoList.isEmpty())
					{
						splitAssetName = null;

						for (int x = 1; x < workbook.getNumberOfSheets(); x=x+2) 
						{

							XSSFSheet sheet=(XSSFSheet) workbook.getSheetAt(x);

							excelassetInstRelList = new ArrayList<AssetInstRelationship>();

							List<AssetInstRelationship>  assetInstRelList = new ArrayList<AssetInstRelationship>();

							List<AssetInstRelationship>  assetInstRelListtemp = new ArrayList<AssetInstRelationship>();

							XSSFRow row; 

							//Iterator rows = sheet.rowIterator();
							Iterator<Row> rows = sheet.iterator();

							int l =2 ;

							while (rows.hasNext())
							{
								AssetInstance prhVo = new AssetInstance();

								row=(XSSFRow) rows.next();

								int  rowNum = row.getRowNum();

								if(row.getRowNum()==0 )
								{

									XSSFRow rowb = sheet.getRow(rowNum++);

									XSSFCell cellaa = rowb.getCell(0);


									if(cellaa != null)
									{
										if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
										{
											splitAssetName = cellaa.getStringCellValue();
											if(splitAssetName.length() == 0)
											{
												splitAssetName = "";  
											}
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
										{

											int val1 = (int)cellaa.getNumericCellValue(); 
											splitAssetName = String.valueOf(val1); 
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
										{
											splitAssetName = cellaa.getStringCellValue();
										}
									}
									else
									{
										splitAssetName = "";
									}


									continue; 
								}

								if( row.getRowNum()==1)
								{
									continue; 
								}

								rowNum = l;

								String cell1=null, cell2 = null, cell3 = null, cell4 = null, cell5 = null, cell6 = null, cell7 = null, cell8 = null, cell9 = null, cell10 = null,cell11 = null,cell12 = null;


								XSSFRow rowb = sheet.getRow(rowNum++);

								XSSFCell cellaa = rowb.getCell(0);

								XSSFCell cellbb = rowb.getCell(1);

								XSSFCell cellcc = rowb.getCell(2);

								XSSFCell celldd = rowb.getCell(3);

								XSSFCell cellee = rowb.getCell(4);

								XSSFCell cellff = rowb.getCell(5);

								XSSFCell cellgg = rowb.getCell(6);

								XSSFCell cellhh = rowb.getCell(7);

								XSSFCell cellii = rowb.getCell(8);

								XSSFCell celljj = rowb.getCell(9);

								XSSFCell cellkk = rowb.getCell(10);

								XSSFCell cellll = rowb.getCell(11);

								if(cellaa != null)
								{
									if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell1 = cellaa.getStringCellValue();
										if(cell1.length() == 0)
										{
											cell1 = "";  
										}
									}
									if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val1 = (int)cellaa.getNumericCellValue(); 
										cell1 = String.valueOf(val1); 
									}
									if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell1 = cellaa.getStringCellValue();
									}
								}
								else
								{
									cell1 = "";
								}

								if(cellbb != null)
								{
									if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell2 = cellbb.getStringCellValue();
										if(cell2.length() == 0)
										{
											cell2 = "";  
										}
									}
									if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellbb.getNumericCellValue(); 
										cell2 = String.valueOf(val); 
									}
									if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell2 = cellbb.getStringCellValue();
									}
								}
								else
								{
									cell2 = "";
								}

								if(cellcc != null)
								{
									if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell3 = cellcc.getStringCellValue();
										if(cell3.length() == 0)
										{
											cell3 = "";  
										}
									}
									if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellcc.getNumericCellValue(); 
										cell3 = String.valueOf(val); 
									}
									if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell3 = cellcc.getStringCellValue();
									}
								}
								else
								{
									cell3 = "";
								}


								if(celldd != null)
								{
									if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell4 = celldd.getStringCellValue();
										if(cell4.length() == 0)
										{
											cell4 = "";  
										}
									}
									if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)celldd.getNumericCellValue(); 
										cell4 = String.valueOf(val); 
									}
									if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell4 = celldd.getStringCellValue();
									}
								}
								else
								{
									cell4 = "";
								}

								if(cellee != null)
								{
									if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell5 = cellee.getStringCellValue();
										if(cell5.length() == 0)
										{
											cell5 = "";  
										}
									}
									if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellee.getNumericCellValue(); 
										cell5 = String.valueOf(val); 
									}
									if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell5 = cellee.getStringCellValue();
									}
								}
								else
								{
									cell5 = "";
								}

								if(cellff != null)
								{
									if (cellff.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell6 = cellff.getStringCellValue();
										if(cell6.length() == 0)
										{
											cell6 = "";  
										}
									}
									if(cellff.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellff.getNumericCellValue(); 
										cell6 = String.valueOf(val); 
									}
									if(cellff.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell6 = cellff.getStringCellValue();
									}
								}
								else
								{
									cell6 = "";
								}

								if(cellgg != null)
								{
									if (cellgg.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell7 = cellgg.getStringCellValue();
										if(cell7.length() == 0)
										{
											cell7 = "";  
										}
									}
									if(cellgg.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellgg.getNumericCellValue(); 
										cell7 = String.valueOf(val); 
									}
									if(cellgg.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell7 = cellgg.getStringCellValue();
									}
								}
								else
								{
									cell7 = "";
								}

								if(cellhh != null)
								{
									if (cellhh.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell8 = cellhh.getStringCellValue();
										if(cell8.length() == 0)
										{
											cell8 = "";  
										}
									}
									if(cellhh.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellhh.getNumericCellValue(); 
										cell8 = String.valueOf(val); 
									}
									if(cellhh.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell8 = cellhh.getStringCellValue();
									}
								}
								else
								{
									cell8 = "";
								}

								if(cellii != null)
								{
									if (cellii.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell9 = cellii.getStringCellValue();
										if(cell9.length() == 0)
										{
											cell9 = "";  
										}
									}
									if(cellii.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellii.getNumericCellValue(); 
										cell9 = String.valueOf(val); 
									}
									if(cellii.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell9 = cellii.getStringCellValue();
									}
								}
								else
								{
									cell9 = "";
								}


								if(celljj != null)
								{
									if (celljj.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell10 = celljj.getStringCellValue();
										if(cell10.length() == 0)
										{
											cell10 = "";  
										}
									}
									if(celljj.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)celljj.getNumericCellValue(); 
										cell10 = String.valueOf(val); 
									}
									if(celljj.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell10 = celljj.getStringCellValue();
									}
								}
								else
								{
									cell10 = "";
								}

								if(cellkk != null)
								{
									if (cellkk.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell11 = cellkk.getStringCellValue();
										if(cell11.length() == 0)
										{
											cell11 = "";  
										}
									}
									if(cellkk.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellkk.getNumericCellValue(); 
										cell11 = String.valueOf(val); 
									}
									if(cellkk.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell11 = cellkk.getStringCellValue();
									}
								}
								else
								{
									cell11 = "";
								}

								if(cellll != null)
								{
									if (cellll.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell12 = cellll.getStringCellValue();
										if(cell12.length() == 0)
										{
											cell12 = "";  
										}
									}
									if(cellll.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellll.getNumericCellValue(); 
										cell12 = String.valueOf(val); 
									}
									if(cellll.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell12 = cellll.getStringCellValue();
									}
								}
								else
								{
									cell12 = "";
								}

								AssetInstRelationship avVo = new AssetInstRelationship();

								avVo.setSrcAssetName(cell1);
								avVo.setSourceInstanceName(cell3);
								avVo.setSourceVersionName(cell4);
								avVo.setDestAssetName(cell8);
								avVo.setDestInstanceName(cell10);
								avVo.setDestInstanceVersionName(cell11);
								avVo.setDescrption(cell7);
								avVo.setRelationShipName(cell6);
								excelassetInstRelList.add(avVo);
								l++;
							}

							rows = sheet.rowIterator();

							int q = 2;

							while (rows.hasNext())
							{
								AssetInstance prhVo = new AssetInstance();

								row=(XSSFRow) rows.next();

								int  rowNum = row.getRowNum();

								if(row.getRowNum()==0 )
								{

									XSSFRow rowb = sheet.getRow(rowNum++);

									XSSFCell cellaa = rowb.getCell(0);

									if(cellaa != null)
									{
										if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
										{
											splitAssetName = cellaa.getStringCellValue();
											if(splitAssetName.length() == 0)
											{
												splitAssetName = "";  
											}
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
										{
											int val1 = (int)cellaa.getNumericCellValue(); 
											splitAssetName = String.valueOf(val1); 
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
										{
											splitAssetName = cellaa.getStringCellValue();
										}
									}
									else
									{
										splitAssetName = "";
									}

									AssetInstanceVersion srcAiv = new AssetInstanceVersion();
									AssetInstanceVersion destAiv = new AssetInstanceVersion();
									List<AssetInstRelationship> depAIs =  assetInstanceVersionDao.getNumOfDependentsForAssetInstByAssetType(splitAssetName, conn);

									for(AssetInstRelationship air:depAIs)
									{
										AssetInstRelationship airVo = new AssetInstRelationship();

										srcAiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(air.getSrcAssetInstVersionId(), conn);

										destAiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(air.getDestAssetInstVersionId(), conn);

										airVo.setSrcAssetName(srcAiv.getAssetName());
										airVo.setSrcAssetInstVersionId(air.getSrcAssetInstVersionId());
										airVo.setSourceInstanceName(srcAiv.getAssetInstName());
										airVo.setSourceVersionName(srcAiv.getVersionName());
										airVo.setDestAssetName(destAiv.getAssetName());
										airVo.setDestInstanceName(destAiv.getAssetInstName());
										airVo.setDestAssetInstVersionId(air.getDestAssetInstVersionId());
										airVo.setDestInstanceVersionName(destAiv.getVersionName());
										airVo.setDescrption(air.getDescrption());
										airVo.setRelationShipName(air.getRelationShipName());
										airVo.setAssetRelId(air.getAssetRelId());
										assetInstRelList.add(airVo);
										assetInstRelListtemp.add(airVo);
									}
									continue; 
								}

								if( row.getRowNum()==1)
								{
									continue; 
								}


								rowNum = q;

								String cell1=null, cell2 = null, cell3 = null, cell4 = null, cell5 = null, cell6 = null, cell7 = null, cell8 = null, cell9 = null, cell10 = null,cell11 = null,cell12 = null;


								XSSFRow rowb = sheet.getRow(rowNum++);

								XSSFCell cellaa = rowb.getCell(0);

								XSSFCell cellbb = rowb.getCell(1);

								XSSFCell cellcc = rowb.getCell(2);

								XSSFCell celldd = rowb.getCell(3);

								XSSFCell cellee = rowb.getCell(4);

								XSSFCell cellff = rowb.getCell(5);

								XSSFCell cellgg = rowb.getCell(6);

								XSSFCell cellhh = rowb.getCell(7);

								XSSFCell cellii = rowb.getCell(8);

								XSSFCell celljj = rowb.getCell(9);

								XSSFCell cellkk = rowb.getCell(10);

								XSSFCell cellll = rowb.getCell(11);

								if(cellaa != null)
								{
									if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell1 = cellaa.getStringCellValue();
										if(cell1.length() == 0)
										{
											cell1 = "";  
										}
									}
									if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val1 = (int)cellaa.getNumericCellValue(); 
										cell1 = String.valueOf(val1); 
									}
									if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell1 = cellaa.getStringCellValue();
									}
								}
								else
								{
									cell1 = "";
								}

								if(cellbb != null)
								{
									if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell2 = cellbb.getStringCellValue();
										if(cell2.length() == 0)
										{
											cell2 = "";  
										}
									}
									if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellbb.getNumericCellValue(); 
										cell2 = String.valueOf(val); 
									}
									if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell2 = cellbb.getStringCellValue();
									}
								}
								else
								{
									cell2 = "";
								}

								if(cellcc != null)
								{
									if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell3 = cellcc.getStringCellValue();
										if(cell3.length() == 0)
										{
											cell3 = "";  
										}
									}
									if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellcc.getNumericCellValue(); 
										cell3 = String.valueOf(val); 
									}
									if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell3 = cellcc.getStringCellValue();
									}
								}
								else
								{
									cell3 = "";
								}


								if(celldd != null)
								{
									if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell4 = celldd.getStringCellValue();
										if(cell4.length() == 0)
										{
											cell4 = "";  
										}
									}
									if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)celldd.getNumericCellValue(); 
										cell4 = String.valueOf(val); 
									}
									if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell4 = celldd.getStringCellValue();
									}
								}
								else
								{
									cell4 = "";
								}

								if(cellee != null)
								{
									if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell5 = cellee.getStringCellValue();
										if(cell5.length() == 0)
										{
											cell5 = "";  
										}
									}
									if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellee.getNumericCellValue(); 
										cell5 = String.valueOf(val); 
									}
									if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell5 = cellee.getStringCellValue();
									}
								}
								else
								{
									cell5 = "";
								}

								if(cellff != null)
								{
									if (cellff.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell6 = cellff.getStringCellValue();
										if(cell6.length() == 0)
										{
											cell6 = "";  
										}
									}
									if(cellff.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellff.getNumericCellValue(); 
										cell6 = String.valueOf(val); 
									}
									if(cellff.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell6 = cellff.getStringCellValue();
									}
								}
								else
								{
									cell6 = "";
								}

								if(cellgg != null)
								{
									if (cellgg.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell7 = cellgg.getStringCellValue();
										if(cell7.length() == 0)
										{
											cell7 = "";  
										}
									}
									if(cellgg.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellgg.getNumericCellValue(); 
										cell7 = String.valueOf(val); 
									}
									if(cellgg.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell7 = cellgg.getStringCellValue();
									}
								}
								else
								{
									cell7 = "";
								}

								if(cellhh != null)
								{
									if (cellhh.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell8 = cellhh.getStringCellValue();
										if(cell8.length() == 0)
										{
											cell8 = "";  
										}
									}
									if(cellhh.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellhh.getNumericCellValue(); 
										cell8 = String.valueOf(val); 
									}
									if(cellhh.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell8 = cellhh.getStringCellValue();
									}
								}
								else
								{
									cell8 = "";
								}

								if(cellii != null)
								{
									if (cellii.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell9 = cellii.getStringCellValue();
										if(cell9.length() == 0)
										{
											cell9 = "";  
										}
									}
									if(cellii.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellii.getNumericCellValue(); 
										cell9 = String.valueOf(val); 
									}
									if(cellii.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell9 = cellii.getStringCellValue();
									}
								}
								else
								{
									cell9 = "";
								}


								if(celljj != null)
								{
									if (celljj.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell10 = celljj.getStringCellValue();
										if(cell10.length() == 0)
										{
											cell10 = "";  
										}
									}
									if(celljj.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)celljj.getNumericCellValue(); 
										cell10 = String.valueOf(val); 
									}
									if(celljj.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell10 = celljj.getStringCellValue();
									}
								}
								else
								{
									cell10 = "";
								}

								if(cellkk != null)
								{
									if (cellkk.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell11 = cellkk.getStringCellValue();
										if(cell11.length() == 0)
										{
											cell11 = "";  
										}
									}
									if(cellkk.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellkk.getNumericCellValue(); 
										cell11 = String.valueOf(val); 
									}
									if(cellkk.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell11 = cellkk.getStringCellValue();
									}
								}
								else
								{
									cell11 = "";
								}

								if(cellll != null)
								{
									if (cellll.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										cell12 = cellll.getStringCellValue();
										if(cell12.length() == 0)
										{
											cell12 = "";  
										}
									}
									if(cellll.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellll.getNumericCellValue(); 
										cell12 = String.valueOf(val); 
									}
									if(cellll.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										cell12 = cellll.getStringCellValue();
									}
								}
								else
								{
									cell12 = "";
								}

								if(cell1!="" && cell2!="" && cell3!="" && cell4!="" && cell7!="" && cell8!="" && cell9!="" && cell10!="" && cell6!="")
								{

									cell1  = cell1.trim();
									cell2  = cell2.trim();
									cell3  = cell3.trim();
									cell7  = cell7.trim();
									cell8  = cell8.trim();
									cell9  = cell9.trim();
									cell5  = cell5.trim();
									cell6  = cell6.trim();
									cell4  = cell4.trim();
									cell10  = cell10.trim();

									if(cell1.length() > 50)
									{
										if (log.isErrorEnabled()) {
											log.error(" Source Asset Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
										}
										errorsOnProc.add(" Source Asset Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
									}

									if(cell3.length() > 100)
									{
										if (log.isErrorEnabled()) {
											log.error(" Source Asset Instance Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
										}
										errorsOnProc.add(" Source Asset Instance Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
									}

									if(cell4.length() > 10)
									{
										if (log.isErrorEnabled()) {
											log.error(" Source Asset Instance Version Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
										}
										errorsOnProc.add(" Source Asset Instance Version Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
									}
									if(cell8.length() > 50)
									{
										if (log.isErrorEnabled()) {
											log.error(" Target Asset Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
										}
										errorsOnProc.add(" Target Asset Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
									}
									if(cell10.length() > 100)
									{
										if (log.isErrorEnabled()) {
											log.error(" Target Asset Instance Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
										}
										errorsOnProc.add(" Target Asset Instance Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
									}
									if(cell11.length() > 10)
									{
										if (log.isErrorEnabled()) {
											log.error(" Target Asset Instance Version Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
										}
										errorsOnProc.add(" Target Asset Instance Version Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
									}
									if(cell2.length() > 20)
									{
										if (log.isErrorEnabled()) {
											log.error(" Source Asset Instance Version Id exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
										}
										errorsOnProc.add(" Source Asset Instance Version Id exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
									}
									if(cell9.length() > 20)
									{
										if (log.isErrorEnabled()) {
											log.error(" Target Asset Instance Version Id exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
										}
										errorsOnProc.add(" Target Asset Instance Version Id exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
									}

									String iChars1 = "!@#$%^&*()+=[]\\\';./{}|\":<>?~";

									Boolean flagForValidation1 = false;

									for (int k = 0; k < cell1.length(); k++) 
									{
										if (iChars1.indexOf(cell1.charAt(k)) != -1) 
										{
											flagForValidation1 = true;
											break;
										}
									}

									String iChars3 = "!%^*=[];{}|<>?~";

									Boolean flagForValidation3 = false;

									for (int k = 0; k < cell3.length(); k++) 
									{
										if (iChars3.indexOf(cell3.charAt(k)) != -1) 
										{
											flagForValidation3 = true;
											break;
										}
									}

									Boolean flagForValidation2 = false;

									String iChars2 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWXYZ]";
									for (int i = 0; i < cell4.length(); i++) 
									{
										if (iChars2.indexOf(cell4.trim().charAt(i)) != -1) 
										{
											flagForValidation2= true;
											break;
										}
									}


									String iChars4 = "!@#$%^&*()+=[]\\\';./{}|\":<>?~";

									Boolean flagForValidation4 = false;

									for (int k = 0; k < cell8.length(); k++) 
									{
										if (iChars4.indexOf(cell8.charAt(k)) != -1) 
										{
											flagForValidation4 = true;
											break;
										}
									}

									String iChars5 = "!%^*=[];{}|<>?~";

									Boolean flagForValidation5 = false;

									for (int k = 0; k < cell10.length(); k++) 
									{
										if (iChars5.indexOf(cell10.charAt(k)) != -1) 
										{
											flagForValidation5 = true;
											break;
										}
									}


									Boolean flagForValidation6 = false;

									String iChars6 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWXYZ]";

									for (int i = 0; i < cell11.length(); i++) 
									{
										if (iChars6.indexOf(cell11.trim().charAt(i)) != -1) 
										{
											flagForValidation6= true;
											break;
										}
									}

									Boolean flagForValidation7 = false;

									String iChars7 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWYZ]";

									for (int i = 0; i < cell2.length(); i++) 
									{
										if (iChars7.indexOf(cell2.trim().charAt(i)) != -1) 
										{
											flagForValidation7= true;
											break;
										}
									}

									Boolean flagForValidation8 = false;

									String iChars8 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWYZ]";

									for (int i = 0; i < cell9.length(); i++) 
									{
										if (iChars8.indexOf(cell9.trim().charAt(i)) != -1) 
										{
											flagForValidation8= true;
											break;
										}
									}


									if(flagForValidation1)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Character not allowed in source asset type column " + cell1+" at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Special Character not allowed in source asset type column " + cell1+" at "+splitAssetName+" Relationship sheet");
									}
									if(flagForValidation2)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Characters/Alphabets not allowed in  source asset instance version column " + cell4+" at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Special Characters/Alphabets not allowed in  source asset instance version column " + cell4+" at "+splitAssetName+" Relationship sheet");
									}
									if(flagForValidation3)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Character not allowed in source asset instance name column " + cell3+" at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Special Character not allowed in source asset instance name column " + cell3+" at "+splitAssetName+" Relationship sheet");
									}
									if(flagForValidation4)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Character not allowed in target asset type column " + cell8+" at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Special Character not allowed in target asset type column " + cell8+" at "+splitAssetName+" Relationship sheet");
									}
									if(flagForValidation6)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Characters/Alphabets not allowed in  target asset instance version column " + cell11+" at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Special Characters/Alphabets not allowed in  target asset instance version column " + cell11+" at "+splitAssetName+" Relationship sheet");
									}
									if(flagForValidation5)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Character not allowed in target asset instance name column " + cell10+" at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Special Character not allowed in target asset instance name column " + cell10+" at "+splitAssetName+" Relationship sheet");
									}
									if(flagForValidation7)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Characters/Alphabets not allowed except XXXX in  Source Asset Instance Version Id column " + cell2+" at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Special Characters/Alphabets not allowed except XXXX in  Source Asset Instance Version Id column " + cell2+" at "+splitAssetName+" Relationship sheet");
									}
									if(flagForValidation8)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Characters/Alphabets not allowed except XXXX in  Target Asset Instance Version Id column " + cell9+" at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Special Characters/Alphabets not allowed except XXXX in  Target Asset Instance Version Id column " + cell9+" at "+splitAssetName+" Relationship sheet");
									}
									AssetInstRelationship  avVo = new AssetInstRelationship();

									Boolean flag12 = false;
									for(AssetInstRelationship aivo:assetInstRelList)
									{
										if(aivo.getSrcAssetInstVersionId().toString().equals(cell2)&& aivo.getDestAssetInstVersionId().toString().equals(cell9) && aivo.getSrcAssetName().equalsIgnoreCase(cell1) && aivo.getSourceInstanceName().equalsIgnoreCase(cell3) && aivo.getSourceVersionName().equalsIgnoreCase(cell4)&&  aivo.getDestAssetName().equalsIgnoreCase(cell8) && aivo.getDestInstanceName().equalsIgnoreCase(cell10) && aivo.getDestInstanceVersionName().equalsIgnoreCase(cell11)&& cell7.equalsIgnoreCase(aivo.getDescrption()) && cell6.equalsIgnoreCase(aivo.getRelationShipName()) )
										{
											aivo.setAction("update");
											flag12 = true;
											break;
										}
									}
									String hhh = "";
									if(!flag12)
									{   
										avVo.setSrcAssetName(cell1);
										avVo.setSourceInstanceName(cell3);
										avVo.setSourceVersionName(cell4);
										if(cell2.equals("XXXX")){
											avVo.setSrcAssetInstVersionId(Long.valueOf("0000"));
										}else{
											avVo.setSrcAssetInstVersionId(Long.valueOf(cell2));
										}
										avVo.setDestAssetName(cell8);
										avVo.setDestInstanceName(cell10);
										avVo.setDestInstanceVersionName(cell11);
										if(cell9.equals("XXXX")){
											avVo.setDestAssetInstVersionId(Long.valueOf("0000"));
										}else{
											avVo.setDestAssetInstVersionId(Long.valueOf(cell9));
										}
										avVo.setDescrption(cell7);
										avVo.setRelationShipName(cell6);
										avVo.setAction("add");
										hhh = "add";
										assetInstRelList.add(avVo);
									}

									if(hhh.equals("add"))
									{
										Boolean flagCheck = false;

										for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
										{
											if(splitAssetName.equalsIgnoreCase(entry.getKey()))
											{
												for(AssetInstanceVersion aiv:entry.getValue())
												{
													if((aiv.getAssetInstVersionId().toString().equals(cell2) || cell2.equals("XXXX"))&& aiv.getAssetInstName().equalsIgnoreCase(cell3) && aiv.getVersionName().equalsIgnoreCase(cell4))
													{
														flagCheck = true;
														break;
													}
												}
											}
										}

										if(!flagCheck)
										{
											if (log.isErrorEnabled()) {
												log.error("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+ " Relationship sheet");
											}
											errorsOnProc.add("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+ " Relationship sheet");
										}

										else
										{ 
											Boolean flagCh = false;
											for(AssetRelationshipDef relNm :relNameList)
											{
												if(cell8.equalsIgnoreCase(relNm.getDestAssetName()) && cell1.equalsIgnoreCase(relNm.getSrcAssetName()) && cell7.equals(relNm.getDescription()) && cell6.equals(relNm.getFwdRelationType()))
												{
													flagCh = true;
													break;
												}
											}
											if(!flagCh)
											{
												if (log.isErrorEnabled()) {
													log.error("Error in Relation Details : Please check " + cell8+","+cell7+","+cell6+" of "+cell1+" Relationship sheet");
												}
												errorsOnProc.add("Error in Relation Details : Please check " + cell8+","+cell7+","+cell6+" of "+cell1+" Relationship sheet");
											}
											else
											{

												Boolean flagChec1 = false;

												for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
												{
													if(cell1.equalsIgnoreCase(entry.getKey()))
													{
														for(AssetInstanceVersion aiv:entry.getValue())
														{
															if(((aiv.getAssetInstVersionId().toString().equals(cell2)||cell2.equals("XXXX")) && aiv.getAssetInstName().equalsIgnoreCase(cell3) && aiv.getVersionName().equalsIgnoreCase(cell4)))
															{
																flagChec1 = true;
																break;
															}
														}
													}
												}
												Boolean flagChec = false;
												Boolean flagCond = false;
												Boolean flagCond1 = false;
												if(flagChec1){
													if(cell6.equals("association") || cell6.equals("classification"))
													{
														if(cell3.equalsIgnoreCase(cell10)&& cell1.equalsIgnoreCase(cell8))
														{
															if (log.isErrorEnabled()) {
																log.error("Error in Relationship Details: Source and Destination cannot be same Asset Instance " + cell10+"_"+cell11+" of "+cell8);
															}
															errorsOnProc.add("Error in Relationship Details: Source and Destination cannot be same Asset Instance " + cell10+"_"+cell11+" of "+cell8);

														}
														else{
															for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
															{
																if(cell8.equalsIgnoreCase(entry.getKey()))
																{
																	for(AssetInstanceVersion aiv:entry.getValue())
																	{
																		if(((aiv.getAssetInstVersionId().toString().equals(cell9)||cell9.equals("XXXX")) && aiv.getAssetInstName().equalsIgnoreCase(cell10) && aiv.getVersionName().equalsIgnoreCase(cell11)))
																		{
																			flagChec = true;
																			break;
																		}
																	}
																}
															}
														}
													}		    								
													else
													{
														//Validating asset instance id with XXXX value for new composition/aggregation relationships
														if(cell11.equals("1.0"))
														{  Boolean flagnewCond = false;
														for(AssetInstRelationship airvo : assetInstRelList)
														{
															if(!cell9.equals("XXXX") && airvo.getAction().equals("add"))
															{
																flagnewCond = true;
																break;
															}
														}
														if(flagnewCond)
														{
															if (log.isErrorEnabled()) {
																log.error("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
															}
															errorsOnProc.add("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
														}
														}
														if(cell11.equals("1.0"))
														{
															flagChec = true;
															for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
															{
																if(cell8.equalsIgnoreCase(entry.getKey()))
																{
																	for(AssetInstanceVersion aiv:entry.getValue())
																	{

																		if((!cell9.equals("XXXX") && aiv.getAssetInstName().equalsIgnoreCase(cell10) && aiv.getVersionName().equalsIgnoreCase(cell11)) && (!aiv.getAction().equals("delete"))  )
																		{
																			flagCond = true;
																			break;
																		}
																	}
																}
															} 
															for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
															{
																if(cell8.equalsIgnoreCase(entry.getKey()))
																{
																	for(AssetInstanceVersion aiv:entry.getValue())
																	{
																		if((cell9.equals("XXXX") && aiv.getAssetInstName().equalsIgnoreCase(cell10) && aiv.getVersionName().equalsIgnoreCase(cell11)) && (!aiv.getAction().equals("delete"))  )
																		{
																			flagCond1 = true;
																			break;
																		}
																	}
																}
															} 
														}
														else
														{
															if (log.isErrorEnabled()) {
																log.error("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
															}
															errorsOnProc.add("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
															break;
														}
													}
												}
												if(!flagChec || flagCond || flagCond1)
												{
													if (log.isErrorEnabled()) {
														log.error("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
													}
													errorsOnProc.add("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
												}

												if(!flagChec1)
												{
													if (log.isErrorEnabled()) {
														log.error("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
													}
													errorsOnProc.add("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
												}
											}
										}
									}

									int counter = 0;

									for(int t=0;t<excelassetInstRelList.size();t++)
									{
										if(excelassetInstRelList.get(t).getSrcAssetName().equalsIgnoreCase(cell1) && excelassetInstRelList.get(t).getSourceInstanceName().equalsIgnoreCase(cell3) && excelassetInstRelList.get(t).getSourceVersionName().equalsIgnoreCase(cell4)&& excelassetInstRelList.get(t).getDestAssetName().equalsIgnoreCase(cell8)&& excelassetInstRelList.get(t).getDestInstanceName().equalsIgnoreCase(cell10) && excelassetInstRelList.get(t).getDestInstanceVersionName().equalsIgnoreCase(cell11)&& excelassetInstRelList.get(t).getDescrption().equals(cell7)&& excelassetInstRelList.get(t).getRelationShipName().equals(cell6))
										{
											counter++;
										}
									}
									if(counter>1)
									{
										if (log.isErrorEnabled()) {
											log.error("Duplicate Relation found for "+cell3+"_"+cell4+" at "+splitAssetName +" Relationship Sheet");
										}
										errorsOnProc.add("Duplicate Relation found for "+cell3+"_"+cell4+" at "+splitAssetName +" Relationship Sheet");
									}
								}
								else
								{
									if(cell1 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Source Asset Type column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Source Asset Type column at "+splitAssetName+" Relationship sheet");
									}
									if(cell3 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Source Asset Instance Name column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Source Asset Instance Name column at "+splitAssetName+" Relationship sheet");
									}
									if(cell4 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Source Asset Instance Version column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Source Asset Instance Version column at "+splitAssetName+" Relationship sheet");
									}
									if(cell6 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Relation Type column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Relation Type column at "+splitAssetName+" Relationship sheet");
									}
									if(cell7 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Relation Name column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Relation Name column at "+splitAssetName+" Relationship sheet");
									}
									if(cell8 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Target Asset Type column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Target Asset Type column at "+splitAssetName+" Relationship sheet");
									}
									if(cell10 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Target Asset Instance Name column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Target Asset Instance Name column at "+splitAssetName+" Relationship sheet");
									}
									if(cell11 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Target Asset Instance version column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Target Asset Instance version column at "+splitAssetName+" Relationship sheet");
									}
									if(cell2 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Source Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Source Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
									}
									if(cell9 == "")
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Relationship data for Target Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
										}
										errorsOnProc.add("Please provide valid Relationship data for Target Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
									}
								}
								q++;
							}

							for(AssetInstRelationship aivo:assetInstRelListtemp)
							{
								if(aivo.getRelationShipName().equals("composition") || aivo.getRelationShipName().equals("aggregation"))
								{
									Boolean flagForNotRemove = false;

									for(AssetInstRelationship aiv:excelassetInstRelList)
									{
										if( aivo.getSrcAssetName().equalsIgnoreCase(aiv.getSrcAssetName()) && aivo.getSourceInstanceName().equalsIgnoreCase(aiv.getSourceInstanceName()) && aivo.getSourceVersionName().equalsIgnoreCase(aiv.getSourceVersionName())&&  aivo.getDestAssetName().equalsIgnoreCase(aiv.getDestAssetName()) && aivo.getDestInstanceName().equalsIgnoreCase(aiv.getDestInstanceName()) && aivo.getDestInstanceVersionName().equalsIgnoreCase(aiv.getDestInstanceVersionName()) && aivo.getDescrption().equals(aiv.getDescrption())&& aiv.getRelationShipName().equals(aivo.getRelationShipName()))
										{
											flagForNotRemove = true;
											break;
										}
									}
									if(!flagForNotRemove)
									{   
										aivo.setAction("skip");

									}
								}
								else
								{
									Boolean flagForNotRemove = false;

									for(AssetInstRelationship aiv:excelassetInstRelList)
									{ 
										if(aivo.getSrcAssetName().equalsIgnoreCase(aiv.getSrcAssetName()) && aivo.getSourceInstanceName().equalsIgnoreCase(aiv.getSourceInstanceName()) && aivo.getSourceVersionName().equalsIgnoreCase(aiv.getSourceVersionName())&&  aivo.getDestAssetName().equalsIgnoreCase(aiv.getDestAssetName()) && aivo.getDestInstanceName().equalsIgnoreCase(aiv.getDestInstanceName()) && aivo.getDestInstanceVersionName().equalsIgnoreCase(aiv.getDestInstanceVersionName())&& aivo.getDescrption().equals(aiv.getDescrption()) && aiv.getRelationShipName().equals(aivo.getRelationShipName()))
										{
											flagForNotRemove = true;
											break;
										}
									}
									if(!flagForNotRemove)
									{   
										aivo.setAction("delete");

									}
								}
							}
							for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
							{
								for(AssetInstanceVersion aiv:entry.getValue())
								{
									for(int r=0;r<assetInstRelList.size();r++)
									{
										if(assetInstRelList.get(r).getAction() != null)
										{
											if(entry.getKey().equalsIgnoreCase(assetInstRelList.get(r).getDestAssetName()) && assetInstRelList.get(r).getAction().equals("skip") && !aiv.getAction().equals("delete") && aiv.getAssetInstName().equalsIgnoreCase(assetInstRelList.get(r).getDestInstanceName()) && assetInstRelList.get(r).getDestInstanceVersionName().equalsIgnoreCase(aiv.getVersionName()) )
											{
												if (log.isErrorEnabled()) {
													log.error("Please delete the child asset instance "+aiv.getAssetInstName()+"_"+aiv.getVersionName()+" of "+entry.getKey()+" in attribute sheet for the relationship deleted in relationship sheet");
												}
												errorsOnProc.add("Please delete the child asset instance "+aiv.getAssetInstName()+"_"+aiv.getVersionName()+" of "+entry.getKey()+" in attribute sheet for the relationship deleted in relationship sheet");
											}
											if(entry.getKey().equalsIgnoreCase(assetInstRelList.get(r).getSrcAssetName()) && aiv.getAction().equals("delete") && aiv.getAssetInstName().equalsIgnoreCase(assetInstRelList.get(r).getSourceInstanceName()) && assetInstRelList.get(r).getSourceVersionName().equalsIgnoreCase(aiv.getVersionName()) )
											{
												assetInstRelList.remove(r);
											}
										}
									}
								}
							}
							listOfassetInstRelList.put(splitAssetName, assetInstRelList);
						}
					}
					//Asset Relation validation 2nd level validation done	

					// Loop Starts for Asset Attribute DB Updation 3rd level
					
					
				fullImportDBupdation(errorsOnProc, apeVoList, listOfassetInstList, apsVoList, assetInstanceDao, workflowDao, profile, 
						commonUtils, userName, assetInstanceVersionDao, assetInstanceVersionsManager, aisdVoList, 
						globalsetting, globalLock, radValStatic, lockedVersionIds, assetDao, context, azds, assetInstassignList,
						assetInstTaggingList, taggingDao, listOfassetInstRelList, relationshipDao, recentActivityDao, 
						errStr, conn);
					
					/*AssetInstanceManager assetInstanceManager = new AssetInstanceManager();
					List<AivRevisionHistory> aivRevHistList = new ArrayList<AivRevisionHistory>();
					List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
					Map<String,String> aivIds = new LinkedHashMap<String,String>();
					Map<String,Map<String,String>> taxIds = new LinkedHashMap<String,Map<String,String>>();

					String action = "";

					Object parameterChangeNotification = null;
					Object relatedParamChangeNotification = null;
					JSONObject j1 = null;
					List<Object> parameterChangefinaldata = new ArrayList<Object>();
					List<Object> relatedParamChangefinaldata = new ArrayList<Object>();



					if(errorsOnProc.isEmpty() && apeVoList.isEmpty())
					{
						for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
						{
							for(AssetInstanceVersion aiv:entry.getValue())
							{
								AssetInstance ai = new AssetInstance();
								ai.setAssetName(entry.getKey());

								AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

								ai.setAssetId(asset.getAssetId());
								ai.setAssetInstName(aiv.getAssetInstName());
								ai.setVersionName(aiv.getVersionName());
								ai.setOwner(profile.getUserName());
								//ai.setDescription(aiv.getDescription());
								ai.setDescription(commonUtils.httpSanitizerForCkEditor(aiv.getDescription()));

								if(aiv.getAction().equals("add")){
									//assetInstanceManager.addAssetInstanceHelper(ai,userName,false,true,false,conn);
									Response response = assetInstanceManager.addAssetInstanceHelper(ai,userName,false,true,false,conn);
									MyModel res = (MyModel) response.getEntity();
									List<Object> data = res.getResult();
									for (int i = 0; i < data.size(); i++) {
										AssetInstance aiResponse = new AssetInstance();
										aiResponse = (AssetInstance) data.get(i);
										ai.setAssetInstId(aiResponse.getAssetInstId());
										ai.setAssetInstVersionId(aiResponse.getAssetInstVersionId());
									}
									AssetInstanceVersion aivForAddingNewRevision = assetInstanceVersionDao
											.getAssetInstanceVersion(ai.getAssetInstId(),ai.getVersionName(), conn);
									if(aivForAddingNewRevision != null){
										AivRevisionHistory aivRevHist = new AivRevisionHistory();
										aivRevHist.setAivId(ai.getAssetInstVersionId());
										aivRevHist.setNewInstanceKey("N");
										aivRevHist.setOverviewData(ai.getDescription());
										aivRevHist.setRevId(ai.getVersionName()+".0");
										aivRevHistList.add(aivRevHist);
									}
									//recent Activity
									RecentActivity recentActivity = new RecentActivity();
									recentActivity.setAssetName(ai.getAssetName());
									recentActivity.setAssetInstName(ai.getAssetInstName());
									recentActivity.setAssetInstanceVersionName(ai.getVersionName());
									recentActivity.setAssetInstVersionId(ai.getAssetInstVersionId().toString());
									action = Constants.ACTIVITY_CREATE;
									recentActivity.setAction(action);
									recentActivityList.add(recentActivity);

									aivIds.put(ai.getAssetInstVersionId().toString(),aiv.getAction());
								}else if(aiv.getAction().equals("update")){

								}else{
									AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
									int versionFlag = 0;
									if(asset.isVersionable()){
										versionFlag = 1;
									}
									aivIds.put(aiv1.getAssetInstVersionId().toString(),aiv.getAction());

									assetInstanceVersionsManager.deleteAssetInstanceVersionsHelper(aiv1.getAssetInstanceId(),ai.getAssetInstName(),
											asset.getAssetId(),asset.getAssetName(),userName,1L,versionFlag,aiv1.getAssetInstVersionId(),ai.getVersionName(),true,conn);
								}
							}
						}

						List<AivRevisionHistory> rev = new ArrayList<AivRevisionHistory>();
						List<String> ids = new ArrayList<String>();
						for(int i=0;i<aisdVoList.size();i++)
						{
							AssetInstance ai = new AssetInstance();
							ai.setAssetName(aisdVoList.get(i).getAssetType());
							AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
							ai.setAssetId(asset.getAssetId());
							ai.setAssetInstName(aisdVoList.get(i).getAssetInstName());
							ai.setVersionName(aisdVoList.get(i).getVersionName());
							ai.setParentAssetName(aisdVoList.get(i).getParentAssetName());
							ai.setParentAssetInstName(aisdVoList.get(i).getParentAssetInstanceName());
							if(globalsetting.getGlobalSettingFlag() == 1){
								String description = commonUtils.httpSanitizerForCkEditor(aisdVoList.get(i).getAssetInstanceDescription());
								aisdVoList.get(i).setAssetInstanceDescription(description);
							}
							ai.setNewDescription(aisdVoList.get(i).getAssetInstanceDescription());

							AssetInstanceVersion aiv;
							aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
							ai.setAssetInstId(aiv.getAssetInstanceId());

							if(globalLock.getGlobalSettingFlag() == 1){
								if(radValStatic.equalsIgnoreCase("New")){
									if(aiv.getLockTime()==null){
										if(!aisdVoList.get(i).getAssetInstanceDescription().equals(aiv.getDescription())){
											ids.add(aiv.getAssetInstVersionId().toString());
											assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
											aiv.setVersionName(ai.getVersionName());
											aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
										}
									}
									else{
										long systemTime = System.currentTimeMillis();
										long databaseTime = aiv.getLockTime().getTime();
										if(systemTime>databaseTime){
											aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
											aiv.setLockedBy(null);
											aiv.setLockTime(null);
											assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);//unlock
											ids.add(aiv.getAssetInstVersionId().toString());
											assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
										}else{
											lockedVersionIds.add("Asset Instance Version Overview cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");			
										}
									}
								}
								else{
									if(aiv.getLockTime()!= null){
										if(!aisdVoList.get(i).getAssetInstanceDescription().equals(aiv.getDescription())){
											aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
											aiv.setLockedBy(null);
											aiv.setLockTime(null);
											assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
										}
									}
									assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
									ids.add(aiv.getAssetInstVersionId().toString());
									aiv.setVersionName(ai.getVersionName());
									aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
								}
							}
							else {
								//this will call when global Setting is No
								ids.add(aiv.getAssetInstVersionId().toString());
								assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
								aiv.setVersionName(ai.getVersionName());
								aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
							}
						}
						if(!rev.isEmpty()){
							aivRevHistList.addAll(rev);
						}
						List<String> data = new ArrayList<String>();
						for(Map.Entry<String,String> entry : aivIds.entrySet()){
							String id = entry.getKey();
							for(String finalid:ids){
								if(finalid.equalsIgnoreCase(id)){
									data.add(finalid);
								}
							}
						}
						ids.removeAll(data);
						for(String finalid:ids){
							aivIds.put(finalid,"update");
							//revision history for description(overview)
							for(int i=0;i<aisdVoList.size();i++){
								AssetInstance ai = new AssetInstance();
								ai.setAssetName(aisdVoList.get(i).getAssetType());
								AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
								ai.setAssetId(asset.getAssetId());
								ai.setAssetInstName(aisdVoList.get(i).getAssetInstName());
								ai.setVersionName(aisdVoList.get(i).getVersionName());
								ai.setParentAssetName(aisdVoList.get(i).getParentAssetName());
								ai.setParentAssetInstName(aisdVoList.get(i).getParentAssetInstanceName());
								ai.setNewDescription(aisdVoList.get(i).getAssetInstanceDescription());
								if(globalsetting.getGlobalSettingFlag() == 1){
									String description = commonUtils.httpSanitizerForCkEditor(aisdVoList.get(i).getAssetInstanceDescription());
									ai.setNewDescription(description);
								}
								AssetInstanceVersion aiv;
								aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
								ai.setAssetInstId(aiv.getAssetInstanceId());

								if(aiv.getAssetInstVersionId().toString().equalsIgnoreCase(finalid)){
									AivRevisionHistory aivRevHist = new AivRevisionHistory();
									aivRevHist.setOverviewKey("O");
									aivRevHist.setOverviewData(aisdVoList.get(i).getAssetInstanceDescription());
									aivRevHist.setAivId(Long.parseLong(finalid));
									aivRevHist.setVersionName(aisdVoList.get(i).getVersionName());
									aivRevHistList.add(aivRevHist);

									//recent Activity
									RecentActivity recentActivity = new RecentActivity();
									recentActivity.setAssetName(aisdVoList.get(i).getAssetType());
									recentActivity.setAssetInstName(aisdVoList.get(i).getAssetInstName());
									recentActivity.setAssetInstanceVersionName(aisdVoList.get(i).getVersionName());
									recentActivity.setAssetInstVersionId(finalid);
									recentActivityList.add(recentActivity);
								}
							}
						}

						if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
							AssetInstanceVersion assetInstver = null;
							for(int i=0;i<apsVoList.size();i++)
							{
								List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();

								NameValue nv = new NameValue();
								nv.setName(apsVoList.get(i).getParamName());

								AssetInstance ai = new AssetInstance();
								ai.setAssetName(apsVoList.get(i).getAssetType());
								ai.setAssetInstName(apsVoList.get(i).getAssetInstName());
								ai.setVersionName(apsVoList.get(i).getVersionName());

								AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
								ai.setAssetId(asset.getAssetId());
								ai.setParentAssetName(apsVoList.get(i).getParentAssetName());
								ai.setParentAssetInstName(apsVoList.get(i).getParentAssetInstanceName());

								nv.setName(apsVoList.get(i).getParamName());
								AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
								ai.setAssetInstVersionId(aiv.getAssetInstVersionId());
								if(!apsVoList.get(i).getParamTypeId().equals(3L))
								{
									assetInstver = new AssetInstanceVersion();
									assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
									if(apsVoList.get(i).getParamTypeId().equals(7L)){
										if(apsVoList.get(i).isHasStaticValue()){
											assetInstver.setParamValue(apsVoList.get(i).getParamValue());
										}else if(apsVoList.get(i).getHasArray()==0){
											assetInstver.setParamValue(apsVoList.get(i).getParamValue());
											assetInstver.setRTFPlainText(apsVoList.get(i).getRTFPlainText());
										}else{
											assetInstver.setRTFwithOutTags(apsVoList.get(i).getRTFwithOutTags());
											assetInstver.setRTFwithTags(apsVoList.get(i).getRTFwithTags());
										}
									}else if(apsVoList.get(i).getParamTypeId().equals(1L)){
										if(apsVoList.get(i).isHasStaticValue()){
											assetInstver.setParamValue(apsVoList.get(i).getParamValue());
										}else if(apsVoList.get(i).getHasArray()==0){
											assetInstver.setParamValue(apsVoList.get(i).getParamValue());
										}else{
											assetInstver.setTextDataList(apsVoList.get(i).getTextDataList());
										}
									}else{
										assetInstver.setParamValue(apsVoList.get(i).getParamValue());
									}

									assetInstver.setParamTypeId(apsVoList.get(i).getParamTypeId());
									if(apsVoList.get(i).isHasStaticValue() == false){
										assetInstver.setIsStatic(0);
									}else{
										assetInstver.setIsStatic(1);
									}
									apsVoList.get(i).isHasStaticValue();
									assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
									assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
									assetInstver.setAssetName(ai.getAssetName());
									assetInstver.setAssetInstName(apsVoList.get(i).getAssetInstName());
									assetInstver.setHasArray(apsVoList.get(i).getHasArray());
									assetInstver.setConn(conn);
									assetInstver.setLog(log);
									assetInstver.setUserId(1L);
									ListOfAssetInstanceProperties.add(assetInstver);

									if(CommonUtils.customParameterPluginNoficationClassName != null && CommonUtils.customParameterPluginPath != null){

										if(!CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") && !CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

											Class notificationInterface = CustomParameterPluginUtilies.getplugin();

											if(notificationInterface != null){
												Method method = null;
												Method relatedParamChangeMethod = null;
												try {
													method = notificationInterface.getMethod("notifyOnParameterValueChanges",new Class[]{List.class});
													relatedParamChangeMethod = notificationInterface.getMethod("notifyOnParameterValueChangesBasedOnOtherParameter",new Class[]{List.class});

												} catch (NoSuchMethodException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													throw new RepoproException(e.getMessage());
												} catch (SecurityException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													throw new RepoproException(e.getMessage());
												}

												Object instance = null;
												try {
													instance = notificationInterface.newInstance();
												} catch (InstantiationException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													throw new RepoproException(e.getMessage());
												} catch (IllegalAccessException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													throw new RepoproException(e.getMessage());
												}	


												try{
													parameterChangeNotification = method.invoke(instance,ListOfAssetInstanceProperties);

													if(parameterChangeNotification != null){
														JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

														if(jsonObject.has("Response Status")){
															String status = jsonObject.getString("Response Status");
															if(status.equalsIgnoreCase("failure")){
																errorsOnProc.add(jsonObject.getString("Response Message"));
															}else{
																parameterChangefinaldata.add(jsonObject);
															}
														}
													}

													relatedParamChangeNotification = relatedParamChangeMethod.invoke(instance,ListOfAssetInstanceProperties);
													if(relatedParamChangeNotification != null){
														JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

														if(jsonObject.has("Response Status")){
															String status = jsonObject.getString("Response Status");
															if(status.equalsIgnoreCase("failure")){
																errorsOnProc.add(jsonObject.getString("Response Message"));
															}else{
																relatedParamChangefinaldata.add(jsonObject);
															}
														}
													}
												}
												catch (IllegalAccessException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													throw new RepoproException(e.getMessage());
												} catch (IllegalArgumentException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													throw new RepoproException(e.getMessage());
												} catch (InvocationTargetException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													throw new RepoproException(e.getMessage());
												}catch(Exception e){
													e.printStackTrace();
													throw new RepoproException(e.getMessage());
												}
											}else{

												errorsOnProc.add("Invalid Plugin configuration");

											}
										}

										if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")|| CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){
											errorsOnProc.add("Invalid Plugin configuration");
										}
									}
									if(CommonUtils.customParameterPluginNoficationClassName != null ){
					        			if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")){
					        				errorsOnProc.add("Invalid Plugin configuration");
					        			}
					        		}else if(CommonUtils.customParameterPluginPath != null){
					        			if(CommonUtils.customParameterPluginPath .equalsIgnoreCase("")){
					        				errorsOnProc.add("Invalid Plugin configuration");
					        			}
					        		}
								}
							}
						}

						if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
							List<Long> actualparamAivId = new ArrayList<Long>();
							for(int i=0;i<apsVoList.size();i++)
							{
								NameValue nv = new NameValue();
								AssetInstance ai = new AssetInstance();
								ai.setAssetName(apsVoList.get(i).getAssetType());
								AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
								ai.setAssetId(asset.getAssetId());
								ai.setAssetInstName(apsVoList.get(i).getAssetInstName());
								ai.setVersionName(apsVoList.get(i).getVersionName());
								ai.setParentAssetName(apsVoList.get(i).getParentAssetName());
								ai.setParentAssetInstName(apsVoList.get(i).getParentAssetInstanceName());
								nv.setName(apsVoList.get(i).getParamName());
								AssetParamDef apd11 = assetDao.retParamIdForAssetAndParamName(apsVoList.get(i).getAssetType(), apsVoList.get(i).getParamName(), conn);

								AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
								ai.setAssetInstVersionId(aiv.getAssetInstVersionId());
								if(!apsVoList.get(i).getParamTypeId().equals(3L))
								{
									boolean flagCheck = false;
									if(apsVoList.get(i).isHasStaticValue() == false)
									{
										ParameterValues pv1	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);
										if(globalLock.getGlobalSettingFlag()== 1)
										{
											if(radValStatic.equalsIgnoreCase("New"))
											{
												if(pv1 != null)
												{
													if(aiv.getLockTime()!= null)
													{

														if(apd11.getParamTypeId().equals(7L) && apsVoList.get(i).getHasArray()==1){
															List<String> newTextData = apsVoList.get(i).getRTFwithTags();
															List<String> oldTextData = pv1.getRTFwithTags();
															if(!oldTextData.equals(newTextData)){
																//if(num < 0 || num > 0 ){
																flagCheck = false;
																long databaseTime = aiv.getLockTime().getTime();
																long systemTime = System.currentTimeMillis();
																if( systemTime > databaseTime){
																	if(apd11.getParamTypeId().equals(5L)){
																	}else if(apd11.getParamTypeId().equals(6L)){ 
																	}else if(apd11.getParamTypeId() == 8L){
																	}else{
																		aiv.setLockedBy(null);
																		aiv.setLockTime(null);
																		assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																		flagCheck = true;
																	}
																}else{
																	if (log.isErrorEnabled()) {
																		log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																	}
																	lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
																}
															}
														}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){

															List<String> newTextData = apsVoList.get(i).getTextDataList();
															List<String> oldTextData = pv1.getTextDataList();
															if(!oldTextData.equals(newTextData)){
																//if(num < 0 || num > 0 ){
																flagCheck = false;
																long databaseTime = aiv.getLockTime().getTime();
																long systemTime = System.currentTimeMillis();
																if( systemTime > databaseTime){
																	if(apd11.getParamTypeId().equals(5L)){
																	}else if(apd11.getParamTypeId().equals(6L)){ 
																	}else if(apd11.getParamTypeId().equals(8L)){
																	}else{
																		aiv.setLockedBy(null);
																		aiv.setLockTime(null);
																		assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																		flagCheck = true;
																	}
																}else{
																	if (log.isErrorEnabled()) {
																		log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																	}
																	lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
																}
															}
														}else if(apd11.getParamTypeId().equals(9L)){
															List<String> newLdapMappingData = apsVoList.get(i).getLdapMappingValue().keySet().stream()
																	.collect(Collectors.toList());
															List<String> oldLdapMappingData = pv1.getLdapMappingList();
															if(!oldLdapMappingData.equals(newLdapMappingData)){
																//if(num < 0 || num > 0 ){
																flagCheck = false;
																long databaseTime = aiv.getLockTime().getTime();
																long systemTime = System.currentTimeMillis();
																if( systemTime > databaseTime){
																	if(apd11.getParamTypeId().equals(5L)){
																	}else if(apd11.getParamTypeId().equals(6L)){ 
																	}else if(apd11.getParamTypeId().equals(8L)){
																	}else{
																		aiv.setLockedBy(null);
																		aiv.setLockTime(null);
																		assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																		flagCheck = true;
																	}
																}else{
																	if (log.isErrorEnabled()) {
																		log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																	}
																	lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
																}
															}
														}
														else{
															String oldValueImp = pv1.getValue().trim().toString();
															String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

															int num = oldValueImp.compareTo(newValueImp);

															if(num < 0 || num > 0 ){
																flagCheck = false;
																long databaseTime = aiv.getLockTime().getTime();
																long systemTime = System.currentTimeMillis();
																if( systemTime > databaseTime){
																	if(apd11.getParamTypeId().equals(5L)){
																	}else if(apd11.getParamTypeId().equals(6L)){ 
																	}else if(apd11.getParamTypeId().equals(8L)){
																	}else{
																		aiv.setLockedBy(null);
																		aiv.setLockTime(null);
																		assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																		flagCheck = true;
																	}
																}else{
																	if (log.isErrorEnabled()) {
																		log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																	}
																	lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
																}
															}
														}
													}
													else
													{
														flagCheck = true;  
													}
												}
												else
												{
													if(aiv.getLockTime()!= null)
													{
														if(apd11.getParamTypeId().equals(7L)&& apsVoList.get(i).getHasArray()==1){
															if(!apsVoList.get(i).getRTFwithTags().isEmpty())
															{
																flagCheck = false; 
																long databaseTime = aiv.getLockTime().getTime();
																long systemTime = System.currentTimeMillis();
																if( systemTime > databaseTime){
																	if(apd11.getParamTypeId().equals(5L)){
																	}else if(apd11.getParamTypeId().equals(6L)){ 
																	}else if(apd11.getParamTypeId().equals(8L)){
																	}else{
																		aiv.setLockedBy(null);
																		aiv.setLockTime(null);
																		assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																		flagCheck = true;
																	}
																}else{
																	if (log.isErrorEnabled()) {
																		log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																	}
																	lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
																}
															}
														}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){
															if(!apsVoList.get(i).getTextDataList().isEmpty())
															{
																flagCheck = false; 
																long databaseTime = aiv.getLockTime().getTime();
																long systemTime = System.currentTimeMillis();
																if( systemTime > databaseTime){
																	if(apd11.getParamTypeId().equals(5L)){
																	}else if(apd11.getParamTypeId().equals(6L)){ 
																	}else if(apd11.getParamTypeId().equals(8L)){
																	}else{
																		aiv.setLockedBy(null);
																		aiv.setLockTime(null);
																		assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																		flagCheck = true;
																	}
																}else{
																	if (log.isErrorEnabled()) {
																		log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																	}
																	lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
																}
															}

														}else if(apd11.getParamTypeId().equals(9L)){
															if(!apsVoList.get(i).getLdapMappingValue().isEmpty())
															{
																flagCheck = false; 
																long databaseTime = aiv.getLockTime().getTime();
																long systemTime = System.currentTimeMillis();
																if( systemTime > databaseTime){
																	if(apd11.getParamTypeId().equals(5L)){
																	}else if(apd11.getParamTypeId().equals(6L)){ 
																	}else if(apd11.getParamTypeId().equals(8L)){
																	}else{
																		aiv.setLockedBy(null);
																		aiv.setLockTime(null);
																		assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																		flagCheck = true;
																	}
																}else{
																	if (log.isErrorEnabled()) {
																		log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																	}
																	lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
																}
															}

														}else{
															if(!apsVoList.get(i).getParamValue().isEmpty())
															{
																flagCheck = false; 
																long databaseTime = aiv.getLockTime().getTime();
																long systemTime = System.currentTimeMillis();
																if( systemTime > databaseTime){
																	if(apd11.getParamTypeId().equals(5L)){
																	}else if(apd11.getParamTypeId().equals(6L)){ 
																	}else if(apd11.getParamTypeId().equals(8L)){
																	}else{
																		aiv.setLockedBy(null);
																		aiv.setLockTime(null);
																		assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																		flagCheck = true;
																	}
																}else{
																	if (log.isErrorEnabled()) {
																		log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																	}
																	lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
																}
															}
														}
													}
													else
													{
														flagCheck = true; 
													}
												}
											}
											else
											{
												if(pv1 != null)
												{
													if(aiv.getLockTime()!= null)
													{
														if(apd11.getParamTypeId().equals(7L)&& apsVoList.get(i).getHasArray()==1){
															List<String> newTextData = apsVoList.get(i).getRTFwithTags();
															List<String> oldTextData = pv1.getRTFwithTags();
															if(!oldTextData.equals(newTextData))
															{
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck = true;
																}
															}
														}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){
															List<String> newTextData = apsVoList.get(i).getTextDataList();
															List<String> oldTextData = pv1.getTextDataList();
															if(!oldTextData.equals(newTextData))
															{
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck = true;
																}
															}
														}else if(apd11.getParamTypeId().equals(9L)){
															List<String> newLdapMappingData = apsVoList.get(i).getLdapMappingValue().keySet().stream()
																	.collect(Collectors.toList());
															List<String> oldLdapMappingData = pv1.getLdapMappingList();
															if(!oldLdapMappingData.equals(newLdapMappingData))
															{
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck = true;
																}
															}
														
														}else{
															String oldValueImp = pv1.getValue().trim().toString();
															String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

															int num = oldValueImp.compareTo(newValueImp);
															if(num < 0 || num > 0 )
															{
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck = true;
																}
															}
														}

													}
													else{
														flagCheck = true;  
													}
												}
												else
												{
													if(aiv.getLockTime()!= null)
													{
														if(apd11.getParamTypeId().equals(7L)&& apsVoList.get(i).getHasArray()==1){
															if(!apsVoList.get(i).getRTFwithTags().isEmpty())
																//if(!apsVoList.get(i).getParamValue().isEmpty())
															{
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck = true;
																}
															}
														}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){
															if(!apsVoList.get(i).getTextDataList().isEmpty())
																//if(!apsVoList.get(i).getParamValue().isEmpty())
															{
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck = true;
																}
															}

														}else if(apd11.getParamTypeId().equals(9L)){
															if(!apsVoList.get(i).getLdapMappingValue().isEmpty())
																//if(!apsVoList.get(i).getParamValue().isEmpty())
															{
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck = true;
																}
															}

														}else{
															if(!apsVoList.get(i).getParamValue().isEmpty())
															{
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck = true;
																}
															}
														}
													}
													else
													{
														flagCheck = true; 
													}
												}
											}
										}
										else
										{
											flagCheck = true;
										}
									}
									else
									{
										if(globalLock.getGlobalSettingFlag()== 1)
										{
											if(radValStatic.equalsIgnoreCase("New"))
											{
												if(aiv.getLockTime()!= null)
												{
													//if(paramList.get(i).getStaticValue() != null)
													if(apd11.getStaticValue() != null)
													{
														String oldValueImp = apd11.getStaticValue().trim().toString();
														String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

														int num = oldValueImp.compareTo(newValueImp);

														if(num < 0 || num > 0 )
														{
															flagCheck = false;
															long databaseTime = aiv.getLockTime().getTime();
															long systemTime = System.currentTimeMillis();
															if( systemTime > databaseTime){
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck = true;
																}

															}else{
																if (log.isErrorEnabled()) {
																	log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																}
																lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
															}  
														}
													}
													else{
														if( !apsVoList.get(i).getParamValue().isEmpty()){
															flagCheck = false;
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
													}
												}
												else
												{
													flagCheck = true;
												}
											}
											else
											{
												if(aiv.getLockTime()!= null)
												{
													//if(paramList.get(i).getStaticValue() != null)
													if(apd11.getStaticValue() != null)
													{
														String oldValueImp = apd11.getStaticValue().trim().toString();
														String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

														int num = oldValueImp.compareTo(newValueImp);

														if(num < 0 || num > 0 )
														{
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}
													}
													else{
														if(!apsVoList.get(i).getParamValue().isEmpty()){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}
													}
												}
												else
												{
													flagCheck = true;
												}
											}
										}
										else
										{
											flagCheck = true;
										}
									}
									AssetInstanceVersion assetInstver = null;

									nv.setValue(apsVoList.get(i).getParamValue());
									if(flagCheck == true)
									{
										if(apd11.getParamTypeId().equals(5L)){
										}else if(apd11.getParamTypeId().equals(6L)){ 
										}else if(apd11.getParamTypeId().equals(8L)){
										}else{
											//nv.setValue(apsVoList.get(i).getParamValue());
											assetInstver = new AssetInstanceVersion();
											assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
											if(apd11.getParamTypeId().equals(7L)){
												if(apsVoList.get(i).isHasStaticValue()){
													assetInstver.setParamValue(apsVoList.get(i).getParamValue());
												}else if(apsVoList.get(i).getHasArray()==0){
													assetInstver.setParamValue(apsVoList.get(i).getParamValue());
													assetInstver.setRTFPlainText(apsVoList.get(i).getRTFPlainText());
												}else{
													assetInstver.setRTFwithOutTags(apsVoList.get(i).getRTFwithOutTags());
													assetInstver.setRTFwithTags(apsVoList.get(i).getRTFwithTags());
												}
											}else if(apd11.getParamTypeId().equals(1L)){
												if(apsVoList.get(i).isHasStaticValue()){
													assetInstver.setParamValue(apsVoList.get(i).getParamValue());
												}else if(apsVoList.get(i).getHasArray()==0){
													assetInstver.setParamValue(apsVoList.get(i).getParamValue());
												}else{
													assetInstver.setTextDataList(apsVoList.get(i).getTextDataList());
												}
											}else if(apd11.getParamTypeId().equals(9L)){
												
												assetInstver.setLdapMappingValue(apsVoList.get(i).getLdapMappingValue());
											}else{
												assetInstver.setParamValue(apsVoList.get(i).getParamValue());
											}
											//assetInstver.setParamValue(apsVoList.get(i).getParamValue());

											//assetInstver.setByteValue(nv.getByteValue());
											//assetInstver.setFileName(nv.getFileName());
											assetInstver.setParamTypeId(apd11.getParamTypeId());
											if(apsVoList.get(i).isHasStaticValue() == false){
												assetInstver.setIsStatic(0);
											}else{
												assetInstver.setIsStatic(1);
											}
											apsVoList.get(i).isHasStaticValue();
											//nv.setName(apsVoList.get(i).getParamName());
											//InputStream myInputStream = new ByteArrayInputStream(nv.getByteValue()); 
											//nv.setImage(myInputStream);
											assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
											assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
											assetInstver.setAssetName(ai.getAssetName());
											assetInstver.setHasArray(apsVoList.get(i).getHasArray());

											//recent activity
											actualparamAivId.add(ai.getAssetInstVersionId());

											//	assetInstanceVersionList.add(assetInstver);

											//assetInstanceVersionsManager.updateAssetInstancePropertiesRest(apsVoList.get(i).getAssetType(), apsVoList.get(i).getAssetInstName(), apsVoList.get(i).getVersionName(),userName,assetInstanceVersionList);
											assetInstanceVersionsManager.updateParameterForAssetInst(assetInstver, null, profile.getUserId(), conn);
											aiv.setVersionName(ai.getVersionName());
											aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);

										}
									}
								}
								else{
									boolean flagCheck1 = false;
									//AssetParamDef apd11 = assetDao.retParamIdForAssetAndParamName(apsVoList.get(i).getAssetType(), apsVoList.get(i).getParamName(), conn);
									if(apsVoList.get(i).isHasStaticValue() == false)
									{
										ParameterValues pv1	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);

										if(globalLock.getGlobalSettingFlag()== 1)
										{
											if(radValStatic.equalsIgnoreCase("New"))
											{
												if(pv1 != null)
												{
													if(pv1.getFileName() != null)
													{
														if(aiv.getLockTime()!= null)
														{
															if(!pv1.getFileName().equals(apsVoList.get(i).getParamValue()))
															{
																flagCheck1 = false;
																long databaseTime = aiv.getLockTime().getTime();
																long systemTime = System.currentTimeMillis();
																if( systemTime > databaseTime){
																	if(apd11.getParamTypeId().equals(5L)){
																	}else if(apd11.getParamTypeId().equals(6L)){ 
																	}else if(apd11.getParamTypeId().equals(8L)){
																	}else{
																		aiv.setLockedBy(null);
																		aiv.setLockTime(null);
																		assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																		flagCheck1 = true;
																	}
																}else{
																	if (log.isErrorEnabled()) {
																		log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																	}
																	lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
																}
															}
														}
														else{
															flagCheck1 = true;
														}
													}
												}
												else
												{
													if(aiv.getLockTime()!= null)
													{
														if(!apsVoList.get(i).getParamValue().isEmpty())
														{
															flagCheck1 = false;
															long databaseTime = aiv.getLockTime().getTime();
															long systemTime = System.currentTimeMillis();
															if( systemTime > databaseTime){
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck1 = true;
																}
															}else{
																if (log.isErrorEnabled()) {
																	log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
																}
																lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
															}
														}
													}
													else{
														flagCheck1 = true;
													}
												}
											}
											else
											{
												if(pv1 != null)
												{
													if(pv1.getFileName() != null)
													{
														if(aiv.getLockTime()!= null)
														{
															if(!pv1.getFileName().equals(apsVoList.get(i).getParamValue()))
															{
																if(apd11.getParamTypeId().equals(5L)){
																}else if(apd11.getParamTypeId().equals(6L)){ 
																}else if(apd11.getParamTypeId().equals(8L)){
																}else{
																	aiv.setLockedBy(null);
																	aiv.setLockTime(null);
																	assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																	flagCheck1 = true;
																}
															}
														}
													}
												}
												else
												{
													if(aiv.getLockTime()!= null)
													{
														if(!apsVoList.get(i).getParamValue().isEmpty())
														{
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck1 = true;
															}
														}
													}
												}
											}

										}
										else{
											flagCheck1 = true;
										}
									}
									else
									{
										if(globalLock.getGlobalSettingFlag()== 1)
										{if(radValStatic.equalsIgnoreCase("New"))
										{
											if(aiv.getLockTime()!= null)
											{
												if(apd11.getFileName() != null)
												{
													String oldValueImp = apd11.getFileName().trim().toString();
													String newValueImp = apsVoList.get(i).getParamValue().trim().toString();
													int num = oldValueImp.compareTo(newValueImp);

													if(num < 0 || num > 0 )
													{
														flagCheck1 = false;
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck1 = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}

													}
												}
												else{
													if( !apsVoList.get(i).getParamValue().isEmpty()){
														flagCheck1 = false;
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
													}
												}
											}
											else{
												flagCheck1 = true;
											}
										}
										else
										{
											if(aiv.getLockTime()!= null)
											{
												if(apd11.getFileName() != null)
												{
													String oldValueImp = apd11.getFileName().trim().toString();
													String newValueImp = apsVoList.get(i).getParamValue().trim().toString();
													int num = oldValueImp.compareTo(newValueImp);

													if(num < 0 || num > 0 )
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck1 = true;
														}
													}
												}
												else{
													if( !apsVoList.get(i).getParamValue().isEmpty()){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck1 = true;
														}
													}
												}
											}
											else{
												flagCheck1 = true;
											}
										}
										}
										else{
											flagCheck1 = true;
										}
									}
									//Map<String,String> paramMapFromDb = (Map<String, String>) assetDao.getParamValuesForAssetInst(ai.getAssetName(), ai.getVersionName(),ai.getAssetInstName(), conn);

									Map<String,String> paramMapFromDb = new LinkedHashMap<String, String>();
									AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
									List<AssetParamDef> paramMap = new ArrayList<AssetParamDef>();
									List<AssetInstanceVersion> assetdata = assetInstanceVersionsManager.getParameter(ai.getAssetName(),userName,aiv1.getAssetInstVersionId(),conn);
									for(AssetInstanceVersion aivData: assetdata){
										AssetParamDef apd = new AssetParamDef();
										if (aivData.getIsStatic() == 1) {
											if (aivData.getParamTypeId() == 3) {
												apd.setAssetParamName(aivData.getAssetParamName());
												apd.setParamValue(aivData.getApdFileName());
											}else{
												apd.setAssetParamName(aivData.getAssetParamName());
												apd.setParamValue(aivData.getStaticValue());
											}

										} else {
											if (aivData.getParamTypeId() == 3) {
												apd.setAssetParamName(aivData.getAssetParamName());
												apd.setParamValue(aivData.getFileName());
											}else if(aivData.getParamTypeId() == 1){
												if(aivData.getTextDataList()!= null){
													String textdata = String.join("~~", aivData.getTextDataList());
													apd.setAssetParamName(aivData.getAssetParamName());
													apd.setParamValue(textdata);
												}else{
													apd.setAssetParamName(aivData.getAssetParamName());
													apd.setParamValue(aivData.getParamValue());
												}
											}else if(aivData.getParamTypeId() == 7){
												if(aivData.getRTFwithTags()!= null){
													String textdata = String.join("~~", aivData.getRTFwithTags());
													apd.setAssetParamName(aivData.getAssetParamName());
													apd.setParamValue(textdata);
												}else{
													apd.setAssetParamName(aivData.getAssetParamName());
													apd.setParamValue(aivData.getParamValue());
												}
											}else if(aiv.getParamTypeId() == 9){
												if(aiv.getLdapMappingValue() != null) {
													List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(aiv.getLdapMappingId(), conn);
													for (Map.Entry<String,Integer> entry : aiv.getLdapMappingValue().entrySet()){
														for(LdapMapping ldapAttributes:ldapMapping) {
															if(entry.getValue() == ldapAttributes.getLdapAttributeId()) {
																apd.setAssetParamName(aiv.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
															//	LdapMapping attribute = assetDao.getLdapMappingAttributeByattributeId(attributeId, conn);
																///List<String> values = aiv.getLdapMappingValue().keySet().stream().collect(Collectors.toList());
																apd.setParamValue(null);
															}
														}
													}
												}
											}else {
												apd.setAssetParamName(aivData.getAssetParamName());
												apd.setParamValue(aivData.getParamValue());
											}
										}
										paramMap.add(apd);
									}
									for (AssetParamDef assetdef : paramMap) paramMapFromDb.put(assetdef.getAssetParamName(),assetdef.getParamValue()+"|"+apsVoList.get(i).isHasStaticValue());
									String OldFileName = null;
									boolean updateFlag = false;
									for (Map.Entry<String, String> entry : paramMapFromDb.entrySet()) {
										String splitStaticVal = entry.getValue().substring(entry.getValue().indexOf("|")+1);
										String splitVal = entry.getValue().substring(0,entry.getValue().indexOf("|"));
										if(apsVoList.get(i).getParamName().equalsIgnoreCase(entry.getKey())){
											if(!apsVoList.get(i).getParamValue().equalsIgnoreCase(splitVal.toString())){
												ParameterValues pv = null;
												AssetParamDef apd = null;
											
												if(apsVoList.get(i).getParamValue() != "" && apsVoList.get(i).getParamValue() !=null)	
												{
													File file= new File(System.getProperty("user.home")+"/RepoProUnzip/"+apsVoList.get(i).getParamValue());

													nv.setFileName(file.getName());

													nv.setByteValue(FileUtils.readFileToByteArray(file));

													nv.setFileMimeType(new MimetypesFileTypeMap().getContentType(file));

													OldFileName = splitVal.toString();
													 
													updateFlag = true;
													 break;}
												else{
													byte[] empty = {} ;
													nv.setFileName(apsVoList.get(i).getParamValue());
													nv.setByteValue(empty);
													nv.setFileMimeType(null);
													updateFlag = true;
													break;
												}	
											}	
										}
									}
									if(flagCheck1 == true)
									{
										if(updateFlag == true){
											AssetInstanceVersion assetInstver = null;
											if(apd11.getParamTypeId() == 5){
											}else if(apd11.getParamTypeId() == 6){ 
											} else if(apd11.getParamTypeId() == 8){
											}else{ 

												assetInstver = new AssetInstanceVersion();
												assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
												assetInstver.setParamValue(apsVoList.get(i).getParamValue());
												assetInstver.setParamTypeId(apd11.getParamTypeId());
												if(apsVoList.get(i).isHasStaticValue() == false){
													assetInstver.setIsStatic(0);
												}else{
													assetInstver.setIsStatic(1);
												}
												apsVoList.get(i).isHasStaticValue();
												nv.setName(apsVoList.get(i).getParamName());
												InputStream myInputStream = null ;
												myInputStream = new ByteArrayInputStream(nv.getByteValue()); 
												nv.setImage(myInputStream);
												assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
												assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());

												actualparamAivId.add(ai.getAssetInstVersionId());

												assetInstver.setAssetName(ai.getAssetName());
												assetInstanceVersionsManager.updateParameterForAssetInst(assetInstver,nv,profile.getUserId(),conn);

												aiv.setVersionName(ai.getVersionName());
												aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
												assetInstanceVersionDao.updateAivUpdatedOn(aiv,aiv.getAssetInstVersionId(), conn);

												assetInstver.setFileName(OldFileName);
												assetInstver.setNewFileName(nv.getFileName());
												InputStream myInputStream1 = null;
												myInputStream1 = new ByteArrayInputStream(nv.getByteValue()); 
												assetInstanceVersionsManager.getNameValue(assetInstver, myInputStream1, nv.getFileName(), context, conn);

											}
										}
									}
									if(!valMap1.isEmpty()){
								for (Map.Entry<String, String> entry : valMap1.entrySet())
								{
									ParameterValues pv	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);
									if(pv != null){
										String splitVal = entry.getValue().substring(entry.getValue().indexOf("|")+1);
										File oldfile =new File(request.getRealPath("")+"/images/thumbnailImages/" +splitVal);
										File newfile =new File(request.getRealPath("")+"/images/thumbnailImages/" +pv.getAssetParamId().toString() +"_"+ splitVal);
										oldfile.renameTo(newfile);
										File oldfile1 =new File(System.getProperty("user.home")+"/ThumbnailImages/" + splitVal);
										File newfile1 =new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString() +"_"+ splitVal);
										oldfile1.renameTo(newfile1);
									}
								}
							}
								}
								RecentActivity recentActivity = new RecentActivity();
						String action = Constants.ACTIVITY_MODIFY;
						String appendingMsg = "";
						recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						recentActivity.setAssetId(ai.getAssetId().toString());
						recentActivity.setAssetInstVersionId(ai.getAssetInstVersionId().toString());
						recentActivity.setUser_id(profile.getUserId());

						if (asset.isVersionable() == true) {
							String log = profile.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ ai.getAssetInstName() + ";"+ " Version " + ai.getVersionName();
							recentActivity.setDescription(log);
						} else {
							String log = profile.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ ai.getAssetInstName() + ";"+ appendingMsg;
							recentActivity.setDescription(log);
						}
						recentActivityDao.addRecentActivity(recentActivity, conn);

							}  //End of for

							List<Long> paramAivId = new ArrayList<Long>();
							List<Long> finalparamAivId = new ArrayList<Long>();

							for(int i=0;i<azds.size();i++)
							{
								AssetInstance ai = new AssetInstance();

								ai.setAssetName(azds.get(i).getAssetName());
								ai.setAssetInstName(azds.get(i).getAssetInstName());
								ai.setVersionName(azds.get(i).getVersionName());
								//revision history data for parameter
								AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);

								if(actualparamAivId.contains(aivVo.getAssetInstVersionId())){
									paramAivId.add(aivVo.getAssetInstVersionId());
									for(AivRevisionHistory paramRev:aivRevHistList){
										if(paramRev.getAivId().equals(aivVo.getAssetInstVersionId())){
											finalparamAivId.add(aivVo.getAssetInstVersionId());
											paramRev.setParameterKey("P");
											paramRev.setParameterData(azds.get(i).getParamRevData());
											paramRev.setVersionName(azds.get(i).getVersionName());
										}
									}
								}
									assetInstanceVersionsManager.addRevisionData("P",aivVo.getAssetInstVersionId(),ai.getVersionName(),null, null, 
								azds.get(i).getParamRevData(), null,userName,profile.getUserId(),null,conn);

							}
							paramAivId.removeAll(finalparamAivId);

							for(int i=0;i<azds.size();i++)
							{
								AssetInstance ai = new AssetInstance();
								ai.setAssetName(azds.get(i).getAssetName());
								ai.setAssetInstName(azds.get(i).getAssetInstName());
								ai.setVersionName(azds.get(i).getVersionName());
								//revision history data for parameter
								AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);

								for(Long paramRev:paramAivId){
									if(paramRev.equals(aivVo.getAssetInstVersionId())){
										AivRevisionHistory revHis = new AivRevisionHistory();
										revHis.setParameterKey("P");
										revHis.setParameterData(azds.get(i).getParamRevData());
										revHis.setVersionName(azds.get(i).getVersionName());
										revHis.setAivId(aivVo.getAssetInstVersionId());
										aivRevHistList.add(revHis);

										RecentActivity recentActivity = new RecentActivity();
										recentActivity.setAssetName(azds.get(i).getAssetName());
										recentActivity.setAssetInstName(azds.get(i).getAssetInstName());
										recentActivity.setAssetInstanceVersionName(azds.get(i).getVersionName());
										recentActivity.setAssetInstVersionId(aivVo.getAssetInstVersionId().toString());
										recentActivityList.add(recentActivity);

										aivIds.put(aivVo.getAssetInstVersionId().toString(),"update");
									}
								}
							}
							List<String> taxAivId = new ArrayList<String>();
							for(int i=0;i<assetInstassignList.size();i++)
							{
								AssetInstance ai = new AssetInstance();

								ai.setAssetName(assetInstassignList.get(i).getAssetName());
								ai.setAssetInstName(assetInstassignList.get(i).getAssetInstanceName());
								ai.setVersionName(assetInstassignList.get(i).getVersionName());

								AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);

								AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

								String taxonomies = null;
								taxonomies = StringUtils.join(assetInstassignList.get(i).getTaxonIds(), ',');

								if(globalLock.getGlobalSettingFlag()==1){
									if(radValStatic.equalsIgnoreCase("New")){

										if(aiv.getLockTime()==null){
											Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
													taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
											MyModel res = (MyModel) response.getEntity();
											Map<String,String> taxdata = res.getParamValues();
											taxIds.put(aiv.getAssetInstVersionId().toString(),taxdata);

											taxAivId.add(aiv.getAssetInstVersionId().toString());

											aiv.setVersionName(ai.getVersionName());
											aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
										}
										else{
											long databaseTime = aiv.getLockTime().getTime();
											long systemTime = System.currentTimeMillis();
											if( systemTime > databaseTime ){
												aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
												aiv.setLockedBy(null);
												aiv.setLockTime(null);
												assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);

												Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
														taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
												MyModel res = (MyModel) response.getEntity();
												Map<String,String> taxdata = res.getParamValues();
												taxIds.put(aiv.getAssetInstVersionId().toString(),taxdata);

												taxAivId.add(aiv.getAssetInstVersionId().toString());

												aiv.setVersionName(ai.getVersionName());
												aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
												assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
											}
											else{
												if (log.isErrorEnabled()) {
													log.error("Asset Instance Version Taxonomies cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
												lockedVersionIds.add("Asset Instance Version Taxonomies cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
											}
										}
									}
									else{
										if(aiv.getLockTime()!=null){
											aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
											aiv.setLockedBy(null);
											aiv.setLockTime(null);
											assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
										}
										Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
												taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
										MyModel res = (MyModel) response.getEntity();
										Map<String,String> taxdata = res.getParamValues();
										taxIds.put(aiv.getAssetInstVersionId().toString(),taxdata);
										taxAivId.add(aiv.getAssetInstVersionId().toString());

										aiv.setVersionName(ai.getVersionName());
										aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
									}
								}
								else{

									Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
											taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
									MyModel res = (MyModel) response.getEntity();
									Map<String,String> taxdata = res.getParamValues();
									taxIds.put(aiv.getAssetInstVersionId().toString(),taxdata);
									taxAivId.add(aiv.getAssetInstVersionId().toString());

									aiv.setVersionName(ai.getVersionName());
									aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
								}
							}

							List<String> taxdata = new ArrayList<String>();
							for(Map.Entry<String,String> entry : aivIds.entrySet()){
								String id = entry.getKey();
								for(String finalid:taxAivId){
									if(finalid.equalsIgnoreCase(id)){
										taxdata.add(finalid);
									}
								}
							}
							taxAivId.removeAll(taxdata);
							for(String finalid:taxAivId){
								aivIds.put(finalid,"update");
							}


							TaggingMaster taggingMaster = new TaggingMaster();
							for(int i=0;i<assetInstTaggingList.size();i++)
							{
								AssetInstance ai = new AssetInstance();

								ai.setAssetName(assetInstTaggingList.get(i).getAssetName());
								ai.setAssetInstName(assetInstTaggingList.get(i).getAssetInstanceName());
								ai.setVersionName(assetInstTaggingList.get(i).getVersionName());
								AssetInstanceVersion aivtag = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
								ai.setAssetInstVersionId(aivtag.getAssetInstVersionId());

								taggingMaster.setAssetInstanceVersionId(ai.getAssetInstVersionId());
								TaggingMaster tagsForAIV = taggingDao.getAllTags(taggingMaster, conn);
								List<String> tagsFromXls = assetInstTaggingList.get(i).getTagsFromXls();
								taggingMaster.setUserId(profile.getUserId());
								taggingMaster.setAssetInstanceVersionId(ai.getAssetInstVersionId());
								if(globalLock.getGlobalSettingFlag()==1){
									if(radValStatic.equalsIgnoreCase("New")){

										if(aivtag.getLockTime()==null){
											for (String tagNameFromXls : tagsFromXls )
											{
												boolean addflg = false;
												for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
												{
													if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
													{
														addflg = true;
														break;
													}
												}
												if(!addflg)
												{
													taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

												}
											}

											for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
											{
												boolean rmflg = false;
												taggingMaster.setTagId(tagNameForAIV.getKey());
												for( String tagNameFromXls: tagsFromXls)
												{
													if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
													{
														rmflg = true;
														break;
													}
												}

												if(!rmflg)
												{
													taggingDao.deleteTagsForImport(taggingMaster, conn);

												}
											}
											aivtag.setVersionName(ai.getVersionName());
											aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
										}
										else{
											long databaseTime = aivtag.getLockTime().getTime();
											long systemTime = System.currentTimeMillis();
											if( systemTime > databaseTime ){
												aivtag.setAssetInstVersionId(aivtag.getAssetInstVersionId());
												aivtag.setLockedBy(null);
												aivtag.setLockTime(null);
												assetInstanceVersionDao.updateAssetInstanceVersion(aivtag, conn);

												for (String tagNameFromXls : tagsFromXls )
												{
													boolean addflg = false;
													for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
													{
														if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
														{
															addflg = true;
															break;
														}
													}
													if(!addflg)
													{
														taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

													}
												}

												for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
												{
													boolean rmflg = false;
													taggingMaster.setTagId(tagNameForAIV.getKey());
													for( String tagNameFromXls: tagsFromXls)
													{
														if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
														{
															rmflg = true;
															break;
														}
													}

													if(!rmflg)
													{
														taggingDao.deleteTagsForImport(taggingMaster, conn);

													}
												}
												aivtag.setVersionName(ai.getVersionName());
												aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
												assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
											}
											else{
												if (log.isErrorEnabled()) {
													log.error("Asset Instance Version tags cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
												lockedVersionIds.add("Asset Instance Version tags cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
											}
										}
									}
									else{
										if(aivtag.getLockTime()!=null){
											aivtag.setAssetInstVersionId(aivtag.getAssetInstVersionId());
											aivtag.setLockedBy(null);
											aivtag.setLockTime(null);
											assetInstanceVersionDao.updateAssetInstanceVersion(aivtag, conn);
										}
										for (String tagNameFromXls : tagsFromXls )
										{
											boolean addflg = false;
											for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
											{
												if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
												{
													addflg = true;
													break;
												}
											}
											if(!addflg)
											{
												taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

											}
										}

										for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
										{
											boolean rmflg = false;
											taggingMaster.setTagId(tagNameForAIV.getKey());
											for( String tagNameFromXls: tagsFromXls)
											{
												if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
												{
													rmflg = true;
													break;
												}
											}

											if(!rmflg)
											{
												taggingDao.deleteTagsForImport(taggingMaster, conn);

											}
										}
										aivtag.setVersionName(ai.getVersionName());
										aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
									}
								}
								else{

									for (String tagNameFromXls : tagsFromXls )
									{
										boolean addflg = false;
										for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
										{
											if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
											{
												addflg = true;
												break;
											}
										}
										if(!addflg)
										{
											taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

										}
									}

									for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
									{
										boolean rmflg = false;
										taggingMaster.setTagId(tagNameForAIV.getKey());
										for( String tagNameFromXls: tagsFromXls)
										{
											if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
											{
												rmflg = true;
												break;
											}
										}

										if(!rmflg)
										{
											taggingDao.deleteTagsForImport(taggingMaster, conn);

										}
									}
									aivtag.setVersionName(ai.getVersionName());
									aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
								}
							}
						}
					}
					log.debug("Asset Attribute ,Taxonomy and Tagging DB updation done for full import "+listOfassetInstList.toString());

					// Loop Starts for Asset Instance Relationship update 3rd level
					List<Long> relSrcAivIds = new ArrayList<Long>();
					List<Long> recentActivityIds = new ArrayList<Long>();
					List<String> aivformailIds = new ArrayList<String>();
					if(errorsOnProc.isEmpty() && apeVoList.isEmpty())
					{
						for (Entry<String, List<AssetInstRelationship>> entry : listOfassetInstRelList.entrySet())
						{
							for(AssetInstRelationship aiv:entry.getValue())
							{
								AssetInstanceVersion ai = new AssetInstanceVersion();
								ai.setAssetName(aiv.getSrcAssetName());
								ai.setAssetInstName(aiv.getSourceInstanceName());
								ai.setVersionName(aiv.getSourceVersionName());
								AssetDef assetsrc = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

								AssetInstance assetIns = new AssetInstance();
								assetIns.setAssetName(ai.getAssetName());
								assetIns.setAssetInstName(ai.getAssetInstName());
								assetIns.setVersionName(ai.getVersionName());
								AssetInstanceVersion aivValue = assetInstanceVersionDao.getAssetInstanceVersion(assetIns, conn);
								ai.setAssetInstVersionId(aivValue.getAssetInstVersionId());

								if(aiv.getAction().equals("add"))
								{
									AssetInstance adr1 = new AssetInstance();

									adr1.setAssetName(aiv.getDestAssetName());
									AssetDef assetDataDest = assetInstanceDao.retAssetDetail(adr1.getAssetName(), conn);
									adr1.setAssetId(assetDataDest.getAssetId());
									adr1.setAssetInstName(aiv.getDestInstanceName());
									adr1.setOwner(userName);
									adr1.setVersionName("1.0");

									adr1.setParentVersionName(aiv.getSourceVersionName());
									adr1.setParentAssetName(aiv.getSrcAssetName());
									AssetDef assetDataSrc = assetInstanceDao.retAssetDetail(adr1.getParentAssetName(), conn);
									adr1.setParentAssetId(assetDataSrc.getAssetId());
									adr1.setParentAssetInstName(aiv.getSourceInstanceName());
									adr1.setOwner(profile.getUserName());

									AssetInstance parentAIVid = new AssetInstance();
									parentAIVid.setAssetName(adr1.getParentAssetName());
									parentAIVid.setAssetInstName(adr1.getParentAssetInstName());
									parentAIVid.setVersionName(adr1.getParentVersionName());
									AssetInstanceVersion parentaiv = assetInstanceVersionDao.getAssetInstanceVersion(parentAIVid, conn);
									adr1.setParentAssetInstVersionId(parentaiv.getAssetInstVersionId());

									if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation"))
									{
										//add child
										Response response = assetInstanceManager.addAssetInstanceHelper(adr1,userName,true,true,true,conn);
										MyModel res = (MyModel) response.getEntity();
										List<Object> data = res.getResult();
										for (int i = 0; i < data.size(); i++) {
											AssetInstance aiResponse = new AssetInstance();
											aiResponse = (AssetInstance) data.get(i);
											ai.setAssetInstanceId(aiResponse.getAssetInstId());
											ai.setAssetInstVersionId(aiResponse.getAssetInstVersionId());
										}
										aivIds.put(ai.getAssetInstVersionId().toString(),aiv.getAction());

										ai.setVersionName(ai.getVersionName());
										ai.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(ai, ai.getAssetInstVersionId(), conn);
									}
									else
									{
										//add relationship
										List<Long> addAssetInstanceVersionIds = new ArrayList<Long>();
										List<Long> selectedAssetRelationship = new ArrayList<Long>();
										List<Long> removedAssetInstanceVersionIds = new ArrayList<Long>();
										List<Long> removedAssetRelationship = new ArrayList<Long>();

										AssetInstance assetInstance = new AssetInstance();
										assetInstance.setAssetName(aiv.getDestAssetName());
										assetInstance.setAssetInstName(aiv.getDestInstanceName());
										assetInstance.setVersionName(aiv.getDestInstanceVersionName());

										AssetInstanceVersion aivo =	assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

										addAssetInstanceVersionIds.add(aivo.getAssetInstVersionId());

										AssetRelationshipDef ard = relationshipDao.retAssetRelDefForAssetsByRelationName(aiv.getSrcAssetName(),aiv.getDestAssetName(),aiv.getDescrption(), conn);

										selectedAssetRelationship.add(ard.getAssetRelId());

										ai.setAddDestAssetInstVersionIds(addAssetInstanceVersionIds);
										ai.setAddRelationshipIds(selectedAssetRelationship);
										ai.setRemovedDestAssetInstVersionIds(removedAssetInstanceVersionIds);
										ai.setRemovedRelationshipIds(removedAssetRelationship);
										ai.setSrcAssetInstanceVersionId(ai.getAssetInstVersionId().toString());

										ai.setAssetInstanceId(aivValue.getAssetInstanceId());
										ai.setAssetId(assetsrc.getAssetId());

										if(globalLock.getGlobalSettingFlag()==1){
											if(radValStatic.equalsIgnoreCase("New")){
												if(aivValue.getLockTime()==null){
													assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
													//get all the source asset instance version ids
													relSrcAivIds.add(ai.getAssetInstVersionId());
													recentActivityIds.add(ai.getAssetInstVersionId());
													//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

													aivo.setVersionName(ai.getVersionName());
													aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
													assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

												}
												else{
													long dataBaseTime = aivValue.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if(systemTime>dataBaseTime){
														aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
														aivValue.setLockedBy(null);
														aivValue.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);

														assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
														//get all the source asset instance version ids
														relSrcAivIds.add(ai.getAssetInstVersionId());
														recentActivityIds.add(ai.getAssetInstVersionId());
														//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

														aivo.setVersionName(ai.getVersionName());
														aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
														assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

													}
													else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
													}

												}
											}
											else{
												if(aivValue.getLockTime()!= null){
													aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
													aivValue.setLockedBy(null);
													aivValue.setLockTime(null);
													assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);
												}
												assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
												//get all the source asset instance version ids
												relSrcAivIds.add(ai.getAssetInstVersionId());
												recentActivityIds.add(ai.getAssetInstVersionId());
												//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

												aivo.setVersionName(ai.getVersionName());
												aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
												assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
											}
										} else{
											assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
											//get all the source asset instance version ids
											relSrcAivIds.add(ai.getAssetInstVersionId());
											recentActivityIds.add(ai.getAssetInstVersionId());
											//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

											aivo.setVersionName(ai.getVersionName());
											aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
										}
									}
								}
								else if(aiv.getAction().equals("update") || aiv.getAction().equals("skip")) {

									if(aiv.getAction().equals("skip")){
										if(globalLock.getGlobalSettingFlag()==1){
											if(radValStatic.equalsIgnoreCase("New")){
												// Do nothing
											}
											else{
												if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation")){

												}else{
													if(aivValue.getLockTime()!= null){
														aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
														aivValue.setLockedBy(null);
														aivValue.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);
													} 
												}
											}
										}
									}
								}else{

									//remove relationship
									if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation")){
										AssetInstance adr2 = new AssetInstance();
										adr2.setAssetName(aiv.getDestAssetName());
										adr2.setAssetInstName(aiv.getDestInstanceName());
										adr2.setVersionName(aiv.getDestInstanceVersionName());
										adr2.setOwner(profile.getUserName());

										AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
										AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(adr2, conn);
										int versionFlag = 0;
										if(asset.isVersionable()){
											versionFlag = 1;
										}
										assetInstanceVersionsManager.deleteAssetInstanceVersionsHelper(aiv1.getAssetInstanceId(),ai.getAssetInstName(),
												asset.getAssetId(),asset.getAssetName(),userName,1L,versionFlag,aiv1.getAssetInstVersionId(),ai.getVersionName(),true,conn);

										//aivIds.put(aiv1.getAssetInstVersionId().toString(),"update");
										aivformailIds.add(aiv1.getAssetInstVersionId().toString());

										aivValue.setVersionName(ai.getVersionName());
										aivValue.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aivValue, aivValue.getAssetInstVersionId(), conn);

									}else{
										List<Long> 	removeAssetInstanceVersionIds = new ArrayList<Long>();
										List<Long> 	removedAssetRelationship =  new ArrayList<Long>();
										List<Long> addAssetInstanceVersionIds = new ArrayList<Long>();
										List<Long> selectedAssetRelationship = new ArrayList<Long>();

										AssetInstance assetInstance = new AssetInstance();
										assetInstance.setAssetName(aiv.getDestAssetName());
										assetInstance.setAssetInstName(aiv.getDestInstanceName());
										assetInstance.setVersionName(aiv.getDestInstanceVersionName());

										AssetInstanceVersion aivo =	assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

										removeAssetInstanceVersionIds.add(aivo.getAssetInstVersionId());

										AssetRelationshipDef ard = relationshipDao.retAssetRelDefForAssetsByRelationName(aiv.getSrcAssetName(),aiv.getDestAssetName(),aiv.getDescrption(), conn);

										removedAssetRelationship.add(ard.getAssetRelId());

										ai.setRemovedDestAssetInstVersionIds(removeAssetInstanceVersionIds);
										ai.setRemovedRelationshipIds(removedAssetRelationship);
										ai.setAddDestAssetInstVersionIds(addAssetInstanceVersionIds);
										ai.setAddRelationshipIds(selectedAssetRelationship);
										ai.setSrcAssetInstanceVersionId(ai.getAssetInstVersionId().toString());
										ai.setAssetInstanceId(aivValue.getAssetInstanceId());
										ai.setAssetId(assetsrc.getAssetId());


										if(globalLock.getGlobalSettingFlag()==1){
											if(radValStatic.equalsIgnoreCase("New")){
												if(aivValue.getLockTime()==null){
													assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
													//get all the source asset instance version ids
													relSrcAivIds.add(ai.getAssetInstVersionId());
													recentActivityIds.add(ai.getAssetInstVersionId());
													//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

													aivo.setVersionName(ai.getVersionName());
													aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
													assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
												}
												else{
													long dataBaseTime = aivValue.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if(systemTime>dataBaseTime){
														aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
														aivValue.setLockedBy(null);
														aivValue.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);

														assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
														//get all the source asset instance version ids
														relSrcAivIds.add(ai.getAssetInstVersionId());
														recentActivityIds.add(ai.getAssetInstVersionId());
														//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

														aivo.setVersionName(ai.getVersionName());
														aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
														assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

													}
													else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
													}
												}
											}
											else{
												if(aivValue.getLockTime()!= null){
													aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
													aivValue.setLockedBy(null);
													aivValue.setLockTime(null);
													assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);
												}
												assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
												//get all the source asset instance version ids
												relSrcAivIds.add(ai.getAssetInstVersionId());
												recentActivityIds.add(ai.getAssetInstVersionId());
												//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

												aivo.setVersionName(ai.getVersionName());
												aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
												assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
											}
										}
										else{

											assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
											//get all the source asset instance version ids
											relSrcAivIds.add(ai.getAssetInstVersionId());
											recentActivityIds.add(ai.getAssetInstVersionId());
											//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

											aivo.setVersionName(ai.getVersionName());
											aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
										}
									}
								}
							}
						}
						log.debug("Asset Relationship DB Updation done for full import"+listOfassetInstRelList.toString());
					}
					// Loop Ends for Asset Instance Relationship update 3rd level

					//add revision history
					List<Long> relIds = new ArrayList<Long>();
					List<Long> recentActyIds = new ArrayList<Long>();
					List<String> mailIds = new ArrayList<String>();

					if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
						Set<Long> finalrelaivids = new HashSet<>();
						finalrelaivids.addAll(relSrcAivIds);
						relSrcAivIds.clear();
						relSrcAivIds.addAll(finalrelaivids);

						for(AivRevisionHistory revRel:aivRevHistList){
							for(Long srcaivids:relSrcAivIds){
								if(srcaivids.equals(revRel.getAivId())){
									relIds.add(srcaivids);
									AssetInstanceVersion aiv = new AssetInstanceVersion();
									aiv.setSrcAssetInstanceVersionId(srcaivids.toString());
									List<AssetInstance> aivos = assetInstanceManager.retFwdDependents(aiv,conn);
									String newRelationshipDataForRevision = "";
									int i = 1;
									for(AssetInstance aivoRev : aivos){
										AssetDef assetDef = assetDao.getAssetsByAssetId(aivoRev.getAssetId(), conn);
										if(i == aivos.size()){
											if(!assetDef.isVersionable()){
												newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
											}else{
												newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
											}	
										}else{
											if(!assetDef.isVersionable()){
												newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
											}else{
												newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
											}
										}
										i++;
									}
									revRel.setRelationshipKey("R");
									revRel.setRelationshipData(newRelationshipDataForRevision);
									AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(srcaivids,conn);
									if(aivVo != null){
										revRel.setVersionName(aivVo.getVersionName());
									}
								}
							}
						}
						//List<Long> finalrelIds = new ArrayList<Long>();
						relSrcAivIds.removeAll(relIds);
						for(Long srcaivids:relSrcAivIds){
							AssetInstanceVersion aiv = new AssetInstanceVersion();
							aiv.setSrcAssetInstanceVersionId(srcaivids.toString());
							List<AssetInstance> aivos = assetInstanceManager.retFwdDependents(aiv,conn);
							String newRelationshipDataForRevision = "";
							int i = 1;
							for(AssetInstance aivoRev : aivos){
								AssetDef assetDef = assetDao.getAssetsByAssetId(aivoRev.getAssetId(), conn);
								if(i == aivos.size()){
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
									}	
								}else{
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
									}
								}
								i++;
							}
							AivRevisionHistory aivRevHisrel = new AivRevisionHistory();
							aivRevHisrel.setRelationshipKey("R");
							aivRevHisrel.setRelationshipData(newRelationshipDataForRevision);
							AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(srcaivids,conn);
							if(aivVo != null){
								aivRevHisrel.setVersionName(aivVo.getVersionName());
							}
							aivRevHisrel.setAivId(srcaivids);
							aivRevHistList.add(aivRevHisrel);
						}

						//recent activity details for relationship data
						Set<Long> finalrecids = new HashSet<>();
						finalrecids.addAll(recentActivityIds);
						recentActivityIds.clear();
						recentActivityIds.addAll(finalrecids);

						for(RecentActivity recent:recentActivityList){
							for(Long recids:recentActivityIds){
								if(recids.toString().equals(recent.getAssetInstVersionId())){
									recentActyIds.add(recids);

								}
							}
						}

						recentActivityIds.removeAll(recentActyIds);
						for(Long recentAct:recentActivityIds){
							RecentActivity acticity = new RecentActivity();
							AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(recentAct,conn);
							if(aivVo != null){
								acticity.setAssetName(aivVo.getAssetName());
								acticity.setAssetInstName(aivVo.getAssetInstName());
								acticity.setAssetInstanceVersionName(aivVo.getVersionName());
								acticity.setAssetInstVersionId(aivVo.getAssetInstVersionId().toString());
								recentActivityList.add(acticity);

								aivIds.put(aivVo.getAssetInstVersionId().toString(),"update");
							}
						}


						Set<String> finalaivids = new HashSet<>();
						finalaivids.addAll(aivformailIds);
						aivformailIds.clear();
						aivformailIds.addAll(finalaivids);
						for(Map.Entry<String,String> entry : aivIds.entrySet()){
							for(String ids:aivformailIds){
								if(entry.getKey().equals(ids)){
									mailIds.add(ids);
								}
							}
						}
						aivformailIds.removeAll(mailIds);

						for(String ids:aivformailIds){
							aivIds.put(ids,"update");
						}

						//add revision history
						RevisionHistoryDao  revisionHistoryDao = new RevisionHistoryDao();
						for(AivRevisionHistory revFinal:aivRevHistList){
							String changeKey = "";  
							if(revFinal.getNewInstanceKey() != null){
								if(revFinal.getNewInstanceKey() == null){
									revFinal.setNewInstanceKey("");
								}
								if(revFinal.getRelationshipKey() == null){
									revFinal.setRelationshipKey("");
								}
								if(revFinal.getParameterKey() == null){
									revFinal.setParameterKey("");
								}
								changeKey = revFinal.getNewInstanceKey()+","+revFinal.getRelationshipKey()+","+revFinal.getParameterKey();
								List<String> list = Arrays.asList(changeKey.split(","));
								List<String> finallist = new ArrayList<String>();
								for(String emptydata:list){
									if(!emptydata.equalsIgnoreCase("")){
										finallist.add(emptydata);
									}
								}
								String listString = String.join(",", finallist);
								AivRevisionHistory aivRevHist = new AivRevisionHistory();
								aivRevHist.setAivId(revFinal.getAivId());
								aivRevHist.setRevId(revFinal.getRevId());
								aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								aivRevHist.setChangedKey(listString);
								aivRevHist.setOverviewData(revFinal.getOverviewData());
								if(revFinal.getRelationshipData() != null){
									aivRevHist.setRelationshipData(revFinal.getRelationshipData());
								}else{
									aivRevHist.setRelationshipData(null);
								}
								if(revFinal.getParameterData() != null){
									aivRevHist.setParameterData(revFinal.getParameterData());
								}else{
									aivRevHist.setParameterData(null);
								}
								aivRevHist.setUserId(profile.getUserId());
								aivRevHist.setUsedBy(null);

								revisionHistoryDao.addRevisionData(aivRevHist, conn);

								AssetInstanceVersion aivo = new AssetInstanceVersion();
								aivo.setVersionName("1.0");
								aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								aivo.setAssetInstVersionId(revFinal.getAivId());
								assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

							}else if(revFinal.getOverviewKey() != null){
								if(revFinal.getOverviewKey() == null){
									revFinal.setOverviewKey("");
									revFinal.setOverviewData("");
								}
								if(revFinal.getRelationshipKey() == null){
									revFinal.setRelationshipKey("");
									revFinal.setRelationshipData("");
								}
								if(revFinal.getParameterKey() == null){
									revFinal.setParameterKey("");
									revFinal.setParameterData("");
								}
								changeKey = revFinal.getOverviewKey()+","+revFinal.getRelationshipKey()+","+revFinal.getParameterKey();
								List<String> list = Arrays.asList(changeKey.split(","));
								List<String> finallist = new ArrayList<String>();
								for(String emptydata:list){
									if(!emptydata.equalsIgnoreCase("")){
										finallist.add(emptydata);
									}
								}
								String listString = String.join(",", finallist);
								assetInstanceVersionsManager.addRevisionData(listString, revFinal.getAivId(),revFinal.getVersionName(), 
										revFinal.getOverviewData(),revFinal.getRelationshipData(),revFinal.getParameterData(), null, userName,profile.getUserId(),"", conn);

								AssetInstanceVersion aivo = new AssetInstanceVersion();
								aivo.setVersionName(revFinal.getVersionName());
								aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								aivo.setAssetInstVersionId(revFinal.getAivId());
								assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
							}else{

								if(revFinal.getOverviewKey() == null){
									revFinal.setOverviewKey("");
									revFinal.setOverviewData("");
								}
								if(revFinal.getRelationshipKey() == null){
									revFinal.setRelationshipKey("");
									revFinal.setRelationshipData("");
								}
								if(revFinal.getParameterKey() == null){
									revFinal.setParameterKey("");
									revFinal.setParameterData("");
								}
								changeKey = revFinal.getOverviewKey()+","+revFinal.getRelationshipKey()+","+revFinal.getParameterKey();
								List<String> list = Arrays.asList(changeKey.split(","));
								List<String> finallist = new ArrayList<String>();
								for(String emptydata:list){
									if(!emptydata.equalsIgnoreCase("")){
										finallist.add(emptydata);
									}
								}
								String listString = String.join(",", finallist);
								assetInstanceVersionsManager.addRevisionData(listString, revFinal.getAivId(),revFinal.getVersionName(), 
										revFinal.getOverviewData(),revFinal.getRelationshipData(),revFinal.getParameterData(), null, userName,profile.getUserId(),"", conn);

								AssetInstanceVersion aivo = new AssetInstanceVersion();
								aivo.setVersionName(revFinal.getVersionName());
								aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								aivo.setAssetInstVersionId(revFinal.getAivId());
								assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
							}
						}
					}
					//add recent activity
					if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
						for(RecentActivity recentFinal:recentActivityList){
							RecentActivity recentActivity = new RecentActivity();
							if(recentFinal.getAction()!=null){
								if(recentFinal.getAction().equalsIgnoreCase(Constants.ACTIVITY_CREATE)){
									action = Constants.ACTIVITY_CREATE;
								}else{
									action = Constants.ACTIVITY_MODIFY;
								}
							}else{
								action = Constants.ACTIVITY_MODIFY;
							}
							String appendingMsg = "";
							recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							AssetDef asset = assetDao.getAssetsByAssetName(recentFinal.getAssetName(), conn);
							if (asset.isVersionable() == true) {
								String log = profile.getFullName() + ";" + action + ";"+ recentFinal.getAssetName() + ";"+ recentFinal.getAssetInstName() + ";"+ " Version " + recentFinal.getAssetInstanceVersionName();
								recentActivity.setDescription(log);
							} else {
								String log = profile.getFullName() + ";" + action + ";"+ recentFinal.getAssetName() + ";"+ recentFinal.getAssetInstName() + ";"+ appendingMsg;
								recentActivity.setDescription(log);
							}
							recentActivity.setUser_id(profile.getUserId());
							recentActivity.setAssetId(asset.getAssetId().toString());
							recentActivity.setAssetInstVersionId(recentFinal.getAssetInstVersionId().toString());
							recentActivityDao.addRecentActivity(recentActivity, conn);
						}
					}
					if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){

						MailTemplateDao mailTemplateDao = new MailTemplateDao();
						SubscriptionDao subscriptionDao = new SubscriptionDao();

						MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
						String mailTemp = null;

						for (Map.Entry<String,String> entry : aivIds.entrySet()) {

							if(entry.getValue().equalsIgnoreCase("add")){
								AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(entry.getKey()), conn);
								if(aiv != null){
									List<String> emailIds=subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);

									if(aiv.getVersionable() == true){
										MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
										mailTemp = mtVo1.getMailTemplate();
										String instName = aiv.getAssetInstName();
										instName = instName.replace("\\", "\\\\").replace("$", "\\$");
										//mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
										mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
									}else{
										MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
										mailTemp = mtVo.getMailTemplate();
										String instName = aiv.getAssetInstName();
										instName = instName.replace("\\", "\\\\").replace("$", "\\$");
										mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
										mailTemp = mailTemp.replaceAll("%assetType%", aiv.getAssetName());
									}
									if(emailIds!=null){
										for(String emailId:emailIds){
											if(aiv.getVersionable() == true) {
												SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
														MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

											}
											else {
												SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
														MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

											}
										}
									}
								}
							}else if(entry.getValue().equalsIgnoreCase("delete")){

							}else{

								AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(entry.getKey()), conn);
								if(aiv != null){
									List<String> emailIds=subscriptionDao.getAllSubscriptionsByAssetInstanceId(aiv.getAssetInstanceId(), conn);
									if(aiv.getVersionable() == true){
										MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForVersionableAsset");
										mailTemp = mtVo1.getMailTemplate();
										String instName = aiv.getAssetInstName();
										instName = instName.replace("\\", "\\\\").replace("$", "\\$");
										mailTemp = mailTemp.replaceAll("%assetInstName%",instName).replaceAll("%versionName%", aiv.getVersionName());
									}else{
										MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForNonVersionableAsset");
										mailTemp = mtVo.getMailTemplate();
										String instName = aiv.getAssetInstName();
										instName = instName.replace("\\", "\\\\").replace("$", "\\$");
										mailTemp = mailTemp.replaceAll("%assetInstName%", instName);

									}
									if(emailIds!=null){
										for(String emailId:emailIds){
											if(aiv.getVersionable() == true) {
												SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
														MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

											}
											else {
												SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
														MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

											}
										}
									}
								}
							}
						}
						//taxonomy mail configration for subscribed users
						for (Entry<String, Map<String, String>> entry : taxIds.entrySet()) {
							Map<String, String> childMap = entry.getValue();
							String assignTax = "";
							String unassignTax = "";
							String addTax = "";
							String removedTax = "";
							List<String> emailIdsList = new ArrayList<String>();
							List<String> emailIds1List = new ArrayList<String>();
							for (Entry<String, String> entry2 : childMap.entrySet()) {
								assignTax = entry2.getKey();
								unassignTax = entry2.getValue();
							}

							//added taxonomies
							if(!assignTax.equalsIgnoreCase("")){
								String addedTaxEmail = "";
								String[] addTaxFinal = assignTax.split("~~");
								addTax = addTaxFinal[0];
								if(addTaxFinal.length == 2){
									addedTaxEmail = addTaxFinal[1];
								}
								emailIdsList = Arrays.asList(addedTaxEmail.split(","));
							}


							//unassigned taxonomies
							if(!unassignTax.equalsIgnoreCase("")){
								String[] unassignTaxFinal = unassignTax.split("~~");
								removedTax = unassignTaxFinal[0];
								String unassignTaxEmail = "";

								if(unassignTaxFinal.length == 2){
									unassignTaxEmail = unassignTaxFinal[1];
								}
								emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
							}

							AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(entry.getKey()), conn);
							if(aiv != null){
								if (!emailIdsList.isEmpty()) {
									HashSet<String> listToSet = new HashSet<String>(emailIdsList);
									List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);

									if (aiv.getVersionable() == true) {
										MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
												"assignTaxNameForAssetInstanceForVersionableAsset");
										mailTemp = mtVo.getMailTemplate();
										String instName = aiv.getAssetInstName();
										instName = instName.replace("\\", "\\\\").replace("$", "\\$");
										mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
												.replaceAll("%assetInstName%",instName).replaceAll("%versionName%", aiv.getVersionName());
									} else {
										MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
												"assignTaxNameForAssetInstanceForNonVersionableAsset");
										mailTemp = mtVo.getMailTemplate();
										String instName = aiv.getAssetInstName();
										instName = instName.replace("\\", "\\\\").replace("$", "\\$");
										mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",instName);
									}

									for (String emailId : listWithoutDuplicates) {
										if (addTax != "") {
											SendEmail.sendTextMail(mailConfig, emailId,
													MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
													MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}
								}

								if (!emailIds1List.isEmpty()) {
									HashSet<String> listToSet = new HashSet<String>(emailIds1List);
									List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);

									if (aiv.getVersionable() == true) {
										MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
												"unassignTaxNameForAssetInstanceForVersionableAsset");
										mailTemp = mtVo.getMailTemplate();
										String instName = aiv.getAssetInstName();
										instName = instName.replace("\\", "\\\\").replace("$", "\\$");
										mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
												.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
									} else {
										MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
												"unassignTaxNameForAssetInstanceForNonVersionableAsset");
										mailTemp = mtVo.getMailTemplate();
										String instName = aiv.getAssetInstName();
										instName = instName.replace("\\", "\\\\").replace("$", "\\$");
										mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax).replaceAll("%assetInstName%", instName);
									}

									for (String emailId : listWithoutDuplicates) {
										if (removedTax != "") {
											SendEmail.sendTextMail(mailConfig, emailId,
													MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
													MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
															+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
										}
									}
								}
							}
						}


						for(Object jsondata:parameterChangefinaldata){

							JSONObject jsonObject = new JSONObject(jsondata.toString());

							if(jsonObject.has("Response Status")){
								String status = jsonObject.getString("Response Status");
								if(status.equalsIgnoreCase("success")){
									if(jsonObject.has("Notification")){
										String result = jsonObject.getString("Notification");
										result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
										if(!result.equalsIgnoreCase("\"\"")){
											JSONObject maillist = new JSONObject(result);
											if(maillist.has("Parameter changed")){
												String oldValue = maillist.getString("Old Value");
												List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
												String newValue = 	maillist.getString("New Value");
												List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
												String instanceName = maillist.getString("AssetInstanceName");
												String assetType = maillist.getString("Assetname");
												JSONArray emailArray = maillist.getJSONArray("Email Id");
												if(oldValue.equalsIgnoreCase("")){
													for(int j=0;j<emailArray.length();j++){
														SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																		+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
													}
												}else{
													for(int j=0;j<emailArray.length();j++){
														SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																		+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
													}
												}
											}
										}
									}
								}
							}
						}

						for(Object jsondata:relatedParamChangefinaldata){

							JSONObject jsonObject = new JSONObject(jsondata.toString());

							if(jsonObject.has("Response Status")){
								String status = jsonObject.getString("Response Status");
								if(status.equalsIgnoreCase("success")){
									if(jsonObject.has("Notification")){
										String result = jsonObject.getString("Notification");
										result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
										if(!result.equalsIgnoreCase("\"\"")){
											JSONObject maillist = new JSONObject(result);
											if(maillist.has("Parameter changed")){
												String oldValue = maillist.getString("Old Value");
												List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
												String newValue = 	maillist.getString("New Value");
												List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
												String instanceName = maillist.getString("AssetInstanceName");
												String assetType = maillist.getString("Assetname");
												JSONArray emailArray = maillist.getJSONArray("Email Id");
												if(oldValue.equalsIgnoreCase("")){
													for(int j=0;j<emailArray.length();j++){
														SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned  "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																		+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
													}
												}else{
													for(int j=0;j<emailArray.length();j++){
														SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
																MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
																MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																		+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
													}
												}
											}
										}
									}
								}
							}
						}
					}

					//error message construction
					if(!errorsOnProc.isEmpty() || !apeVoList.isEmpty())
					{
						Set<String> hs = new HashSet<String>();
						hs.addAll(errorsOnProc);
						errorsOnProc.clear();
						errorsOnProc.addAll(hs);
						for(int i=0;i<errorsOnProc.size();i++)
						{
							errStr.append(errorsOnProc.get(i)+"\n");
						}

						for(int i=0;i<apeVoList.size();i++)
						{
							if(apeVoList.get(i).getFileExist() != null)
							{
								if(apeVoList.get(i).getFileExist().equalsIgnoreCase("Not Found"))
								{
									if(apeVoList.get(i).isVersionable()){
										if (log.isErrorEnabled()) {
											log.error(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
										}
										errStr.append(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
									}
									else{
										if (log.isErrorEnabled()) {
											log.error(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
										}
										errStr.append(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
									}
								}
							}
							else
							{
								if(apeVoList.get(i).getErrorMessage() == null){
									if(apeVoList.get(i).isVersionable())
									{
										if (log.isErrorEnabled()) {
											log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
										}
										errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
									}
									else
									{
										if (log.isErrorEnabled()) {
											log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
										}
										errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
									}
								}else{
									if(apeVoList.get(i).isVersionable())
									{
										if (log.isErrorEnabled()) {
											log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
										}
										errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
									}
									else
									{
										if (log.isErrorEnabled()) {
											log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
										}
										errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
									}
								}
							}
						}
						log.debug("Asset Attribute and Asset Relationship Error Handling done"+apeVoList.toString());
						//return INPUT;
					}*/
				}else if(radioVal.equalsIgnoreCase("incUpdate")){

					incrementalUpdate(tmList,userName, radioVal, radValStatic, inputstream,errStr,lockedVersionIds,context,conn);

				}else{

					incrementalInsert(tmList,userName, radioVal, inputstream,errStr,context,conn);
				}
				if(errStr.length() == 0){
					conn.commit();
				}
			}
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet ||UserName:"+userName+" RadioVal:"+radioVal+"||end");
			}
			//uploadInProcess = false;
			retMsg = Constants.IMPORT_DONE;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;

		}catch (RepoproException e) {
			uploadInProcess = false;
			e.printStackTrace();
			if(e.getMessage().contains("LDAP_NAMEING_EXCEPTION")){
				errStr.append(Constants.LDAP_CONFIG_ERROR + "\n");
			}
			errStr.append("Data already exists or is incorrect. Please try again with proper input");
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		}catch (Exception e) {
			uploadInProcess = false;
			e.printStackTrace();
			errStr.append("General exception encountered while processing file. Please try again.\n");
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			CommonUtils.deleteDir(System.getProperty("user.home")+"/RepoProUnzip/");
			DBConnection.closeDbConnection(conn);
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		MailTemplateDao mailTemplateDao = new MailTemplateDao();
		MailConfig mailConfig = mailTemplateDao.getMailConfig(null);

		if(errStrOfZipFolder.length() != 0){
			SendEmail.sendTextMail(mailConfig,profile.getEmailId(), MessageUtil.getMessage(Constants.REPOPRO_IMPORT_XLSX_FAILED),
					MessageUtil.getMessage(Constants.EMAIL_HDR) + errStrOfZipFolder+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

		}else{
			if(errStr.length() != 0){
				SendEmail.sendTextMail(mailConfig,profile.getEmailId(), MessageUtil.getMessage(Constants.REPOPRO_IMPORT_XLSX_FAILED),
						MessageUtil.getMessage(Constants.EMAIL_HDR) + errStr+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
			}
			else{
				if(globalLock.getGlobalSettingFlag()==1){
					if(radioVal.equalsIgnoreCase("usual") || radioVal.equalsIgnoreCase("incUpdate")){
						if(radValStatic.equalsIgnoreCase("New")){
							StringBuffer versionIdInformation = null;
							StringBuffer sb=new StringBuffer();
							if(lockedVersionIds.size()!=0){
								versionIdInformation=new StringBuffer("The Locked Asset Instance Versions are :"+"\n\n");
								for (String id : lockedVersionIds) {
									sb.append(id+"\n");
								}
							}
							else{
								versionIdInformation=new StringBuffer("");
								sb.append("");
							}
							SendEmail.sendTextMail(mailConfig,profile.getEmailId(), MessageUtil.getMessage(Constants.REPOPRO_IMPORT_XLSX_SUCCESS),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + MessageUtil.getMessage(Constants.GLOBAL_UPLOAD_SUCCESS_MSG)+"\n\n"+versionIdInformation+"\n"+sb  + "\n\nRepoPro" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
						else{
							SendEmail.sendTextMail(mailConfig,profile.getEmailId(), MessageUtil.getMessage(Constants.REPOPRO_IMPORT_XLSX_SUCCESS),
									MessageUtil.getMessage(Constants.EMAIL_HDR) + MessageUtil.getMessage(Constants.GLOBAL_UPLOAD_SUCCESS_MSG)+"\n\nRepoPro" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
						}
					}else{
						SendEmail.sendTextMail(mailConfig,profile.getEmailId(), MessageUtil.getMessage(Constants.REPOPRO_IMPORT_XLSX_SUCCESS),
								MessageUtil.getMessage(Constants.EMAIL_HDR) + MessageUtil.getMessage(Constants.GLOBAL_UPLOAD_SUCCESS_MSG)+"\n\nRepoPro" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
					}
				}
				else{
					SendEmail.sendTextMail(mailConfig,profile.getEmailId(), MessageUtil.getMessage(Constants.REPOPRO_IMPORT_XLSX_SUCCESS),
							MessageUtil.getMessage(Constants.EMAIL_HDR) + MessageUtil.getMessage(Constants.GLOBAL_UPLOAD_SUCCESS_MSG)+"\n\nRepoPro" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

				}
			}
		}
		/*System.gc ();
		System.runFinalization ();*/
		runTime.gc();
		uploadInProcess = false;
		log.trace("importExcelSheet || end");
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	}


	/**
	 * @method incrementalInsert
	 * @description insertion of new asset instance details to application
	 * @param userName
	 * @param radioVal
	 * @param inputStream
	 * @return 
	 * @throws RepoproException
	 * @throws IOException
	 */
	public void incrementalInsert(List<TaxonomyMaster> tmList,String userName,String radioVal,InputStream inputStream,StringBuilder errStr,@Context ServletContext context,Connection conn) throws RepoproException, IOException{
		if (log.isTraceEnabled()) {
			log.trace("incrementalInsert ||UserName:"+userName+" RadioVal:"+radioVal+" InputStream:"+inputStream+" ||Begin");
		}

		Connection conn1= null;
		AssetDao assetDao = new AssetDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		List<AssetInstance> azds = new ArrayList<AssetInstance>();
		List<AssetParamDef> paramList = null;
		RelationshipDao relationshipDao = new RelationshipDao();
		List<AssetRelationshipDef>  relNameList = null;
		UserDao userDao = new UserDao();
		String splitAssetName = "";
		List<AssetParamSuccess> apsVoList = new ArrayList<AssetParamSuccess>();
		List<AssetParamSuccess> apeVoList = new ArrayList<AssetParamSuccess>();
		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		TaggingDao taggingDao = new TaggingDao();
		List<String> possValues = null;
		List<AssetInstanceVersion>  assetInstList = new ArrayList<AssetInstanceVersion>(); 
		List<AssetInstanceVersion>  assetInstList1 =  new ArrayList<AssetInstanceVersion>(); 
		List<List<AssetInstanceVersion>> assetInstList2 = new ArrayList<List<AssetInstanceVersion>>();
		List<AssetInstanceVersion>  excelassetInstList = new ArrayList<AssetInstanceVersion>(); 
		Map<String,List<AssetInstanceVersion>> listOfexcelassetInstList = new LinkedHashMap<String,List<AssetInstanceVersion>>();
		List<AssetInstVersionTaxonomy>   assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
		List<AssetInstAssignTagging>    assetInstTaggingList = new ArrayList<AssetInstAssignTagging>();
		Map<String,List<AssetInstanceVersion>> listOfassetInstList = new LinkedHashMap<String,List<AssetInstanceVersion>>();
		Map<String,List<List<AssetInstanceVersion>>> listOfassetInstList1 = new LinkedHashMap<String,List<List<AssetInstanceVersion>>>();
		List<AssetParamDef>    allCatsAndParamsForAsset = new ArrayList<AssetParamDef>();
		List<AssetInstanceVersion>  listAivo = new ArrayList<AssetInstanceVersion>();
		List<AssetInstDescSuccess> aisdVoList = new ArrayList<AssetInstDescSuccess>();
		GlobalSetting globalLock = new GlobalSetting();
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		WorkflowDao workflowDao = new WorkflowDao();
		CommonUtils commonUtils = new CommonUtils();

		try{
			GlobalSettingDao globalSettingDao = new GlobalSettingDao();
			globalLock = globalSettingDao.retGlobalSettingByName("Lock", conn);
			if (log.isTraceEnabled()){
				log.trace("incrementalInsert || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);

			/*LDAPConnection ldapConnection = LDAPConnection.getInstance();
			DirContext dirContext = ldapConnection.getDirContext();*/
			LDAPUtility ldapUtility = new LDAPUtility();
			
			List<String> splitAssetList = new ArrayList<String>();
			Boolean flagForskip= false;
			AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
			List<String> errorsOnProc = new ArrayList<String>();
			List<AssetDef> assetNameList = assetDao.getAllAssets(conn);

			User profile = userDao.retProfiledetailsForUserName(userName, conn);

			relNameList = relationshipDao.getAllAssetRelationshipDef(conn);

			XSSFWorkbook wb = new XSSFWorkbook(inputStream);

			for (int x = 0; x < wb.getNumberOfSheets(); x=x+2) 
			{
				splitAssetName = null;
				XSSFSheet sheet=wb.getSheetAt(x);
				XSSFRow row; 
				//Iterator rows = sheet.rowIterator();
				Iterator<Row> rows = sheet.iterator();

				Boolean flagForParam = false;
				Boolean flagOrder = false;
				Boolean flagForEmpAsset = false;

				if( sheet.getFirstRowNum()== 0)
				{
					while (rows.hasNext())
					{
						row = (XSSFRow) rows.next();
						int  rowNum = row.getRowNum();
						if(row.getRowNum()==0  )
						{
							XSSFRow rowb = sheet.getRow(rowNum++);
							XSSFCell cellaa = rowb.getCell(0);
							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									splitAssetName = cellaa.getStringCellValue();
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}	
								splitAssetList.add(splitAssetName);
							}
							else
							{
								splitAssetName = "";
								splitAssetList.add(splitAssetName);

							}
						}
						break;
					}
				}

				if(!flagForEmpAsset)
				{
					if( sheet.getFirstRowNum()== 0)
					{
						paramList = assetDao.getParamsDetailByAssetName(splitAssetName,conn);
						
						List<AssetParamDef> ldapmodifiedData = new ArrayList<AssetParamDef>();
						List<AssetParamDef> ldapmodifiedDataRemoval = new ArrayList<AssetParamDef>();
						for(AssetParamDef apd: paramList) {
							if(apd.getParamTypeId() == 9) {
								List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(apd.getLdapMappingId(), conn);
								for(LdapMapping ldapAttributes:ldapMapping) {
									AssetParamDef assetparam = new AssetParamDef();
									assetparam.setLdapMappingId(apd.getLdapMappingId());
									assetparam.setAssetParamName(apd.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
									assetparam.setParamTypeId(apd.getParamTypeId());
									ldapmodifiedData.add(assetparam);
								}
								ldapmodifiedDataRemoval.add(apd);
							}
						}
						if(!ldapmodifiedDataRemoval.isEmpty()) {
							paramList.removeAll(ldapmodifiedDataRemoval);
						}
						if(!ldapmodifiedData.isEmpty()) {
							paramList.addAll(ldapmodifiedData);
						}
						
						int s = 5;
						int f = 0;
						List<String> paramNames = new ArrayList<String>() ;
						List<String> paramNamesForOrder = new ArrayList<String>() ;
						List<String> paramNamesForOrder1 = new ArrayList<String>() ;
						paramNamesForOrder.add("Asset Instance Version Id");
						paramNamesForOrder.add("Asset Instance Name");
						paramNamesForOrder.add("Version Name");
						paramNamesForOrder.add("Overview");
						paramNamesForOrder.add("Created on");
						Collections.sort(paramList, new AssetParamDef());
						for(AssetParamDef pvo: paramList)
						{
							paramNames.add(pvo.getAssetParamName());
							paramNamesForOrder1.add(pvo.getAssetParamName());
						}
						//Collections.sort(paramNames,String.CASE_INSENSITIVE_ORDER);
						//Collections.sort(paramNamesForOrder1,String.CASE_INSENSITIVE_ORDER);
						paramNamesForOrder.addAll(paramNamesForOrder1);
						paramNamesForOrder.add("%%Taxonomies%%");
						paramNamesForOrder.add("%%Tags%%");
						for(int l=0;l<paramNamesForOrder.size();l++)
						{
							XSSFRow rowb = sheet.getRow(1);
							if(rowb != null) {
								XSSFCell cellp = rowb.getCell(f++);
								String valParam = null;
								if(cellp != null)
								{
									if (cellp.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										valParam = cellp.getStringCellValue();
										if(valParam.length() == 0)
										{
											valParam = "";  
										} 
									}else if(cellp.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellp.getNumericCellValue(); 
										valParam = String.valueOf(val); 
									}
									else if(cellp.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										valParam = ""; 
									}
									if(!valParam.equalsIgnoreCase(paramNamesForOrder.get(l))){
										flagOrder = true;
										break;
									}
								}
							}else{
								flagOrder = true;
								break;
							}
						}
						for (String pvo: paramNames)
						{
							XSSFRow rowb = sheet.getRow(1);
							if(rowb != null) {
								XSSFCell cellee = rowb.getCell(s++);
								String valParam = null;
								if(cellee != null)
								{
									if (cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										valParam = cellee.getStringCellValue();
										if(valParam.length() == 0)
										{
											valParam = "";  
										}
									}
									else if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellee.getNumericCellValue(); 
										valParam = String.valueOf(val); 
									}else if(cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK){
										valParam = ""; 
									}
								}
								else
								{
									valParam = "";
								}
								if(!pvo.equalsIgnoreCase(valParam))
								{
									flagForParam = true;
									break;
								}
								
							}else{
								flagForParam = true;
								break;
							}
						}
					}

					if(flagForParam || flagOrder )
					{
						//Parameter Mismatch
						if (log.isErrorEnabled()) {
							log.error("Error in asset name/parameter details for " + splitAssetName + ". Please check for wrong asset name,asset instance version id,wrong parameter names, missing parameters, incorrect alphabetical order.");
						}
						errorsOnProc.add("Error in asset name/parameter details for " + splitAssetName + ". Please check for wrong asset name,asset instance version id,wrong parameter names, missing parameters, incorrect alphabetical order.");
					}
				}
			}
			/*if(!flagForskip )
		{*/
			if(splitAssetList.size() == 1){
				Boolean flagname = false;
				for(int f=0;f<assetNameList.size();f++)
				{
					if(assetNameList.get(f).getAssetName().equals(splitAssetList.get(0)))
					{
						flagname = true;
						break;
					}
				}
				//}
				if(!flagname)
				{
					if (log.isErrorEnabled()) {
						log.error("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");
					}
					errorsOnProc.add("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");
				}
			}
			else
			{
				if(splitAssetList.size() == 0)
				{
					if (log.isErrorEnabled()) {
						log.error("Error : Atleast one asset attribute/relationship sheet must be present in excel sheet.");
					}
					errorsOnProc.add("Error : Atleast one asset attribute/relationship sheet must be present in excel sheet.");
				}
				else
				{
					if (log.isErrorEnabled()) {
						log.error("Error : More than one asset attribute/relationship sheet in excel sheet not allowed.");
					}
					errorsOnProc.add("Error : More than one asset attribute/relationship sheet in excel sheet not allowed.");
				}
			}
			// Loop ends for Asset Attribute 1st level validation

			log.debug("Asset Attribute 1st level validation end for incremental insert : "+splitAssetList);

			Boolean flagForskip1 = false;

			List<String> splitAssetList1 = new ArrayList<String>();

			if(errorsOnProc.size() == 0)
			{
				String	splitAssetName1 = null;
				for (int x = 1; x < wb.getNumberOfSheets(); x=x+2) 
				{
					XSSFSheet sheet = wb.getSheetAt(x);
					XSSFRow row; 
					//Iterator rows = sheet.rowIterator();
					Iterator<Row> rows = sheet.iterator();

					while (rows.hasNext())
					{
						row=(XSSFRow) rows.next();
						if(row.getRowNum() == 0){
							if( sheet.getFirstRowNum() == 0)
							{
								int  rowNum = row.getRowNum();
								if(row.getRowNum() == 0  )
								{
									XSSFRow rowb = sheet.getRow(rowNum++);
									XSSFCell cellaa = rowb.getCell(0);
									if(cellaa != null)
									{
										if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
										{
											splitAssetName1 = cellaa.getStringCellValue();
											if(splitAssetName1.length() == 0)
											{
												splitAssetName1 = "";  
											}
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
										{
											int val1 = (int)cellaa.getNumericCellValue(); 
											splitAssetName1 = String.valueOf(val1); 
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
										{
											splitAssetName1 = cellaa.getStringCellValue();
										}	
										splitAssetList1.add(splitAssetName1);
									}
									else
									{
										splitAssetName1 = "";
										splitAssetList1.add(splitAssetName1);
									}
								}
								break;
							}
						}
						if(row.getRowNum()== 1)
						{
							continue; 
						}

						int rowNum = row.getRowNum();

						String cell1 = null,cell2 = null,cell3 = null,cell6 = null;

						XSSFRow rowb = sheet.getRow(rowNum++);

						XSSFCell cellff = rowb.getCell(6);

						XSSFCell cellaa = rowb.getCell(0);

						XSSFCell cellbb = rowb.getCell(3);

						XSSFCell cellcc = rowb.getCell(2);

						if(cellaa != null)
						{
							if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellaa.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellaa.getNumericCellValue(); 
								cell1 = String.valueOf(val); 
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellaa.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellbb.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellbb.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell2 = "";
						}

						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = cellcc.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellcc.getNumericCellValue(); 
								cell3 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = cellcc.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}


						if(cellff != null)
						{
							if (cellff.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell6 = cellff.getStringCellValue();
								if(cell6.length() == 0)
								{
									cell6 = "";  
								}
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellff.getNumericCellValue(); 
								cell6 = String.valueOf(val); 
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell6 = cellff.getStringCellValue();
							}
						}
						else
						{
							cell6 = "";
						}

						Boolean flagForRel = false;

						if(cell1!="" && cell2!="" && cell3!="")
						{
							for(AssetRelationshipDef relNm :relNameList)
							{
								// Need to validate with attribute list
								if(relNm.getDescription().equals(cell6))	
								{
									flagForRel = true;
									break;
								}
							}
							if(!flagForRel)
							{
								if (log.isErrorEnabled()) {
									log.error("Error in Relation Name for " + cell2+"_"+cell3+" at "+cell1);
								}
								errorsOnProc.add("Error in Relation Name for " + cell2+"_"+cell3+" at "+cell1);
							}
						}
					}
				}

				if(splitAssetList1.size() == 1){
					Boolean flagname = false;
					for(int f=0;f<assetNameList.size();f++)
					{
						if(assetNameList.get(f).getAssetName().equals(splitAssetList1.get(0)))
						{
							flagname = true;
							break;
						}
					}
					if(!flagname)
					{
						if (log.isErrorEnabled()) {
							log.error("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");
						}
						errorsOnProc.add("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");

					}
				}
				else
				{
					if(splitAssetList.size() == 0)
					{
						if (log.isErrorEnabled()) {
							log.error("Error : Atleast one asset attribute/relationship sheet must be present in excel sheet.");
						}
						errorsOnProc.add("Error : Atleast one asset attribute/relationship sheet must be present in excel sheet.");
					}
					else
					{
						if (log.isErrorEnabled()) {
							log.error("Error : More than one asset attribute/relationship sheet in excel sheet not allowed.");
						}
						errorsOnProc.add("Error : More than one asset attribute/relationship sheet in excel sheet not allowed.");
					}
				}
			}
			log.info("Asset Relationship 1st level validation done for incremental insert");

			// Loop Starts for Asset attribute value validation 2nd level

			if(errorsOnProc.size() == 0)
			{
				splitAssetName = null;
				int ldapDuplicateCount = 0; 
				for (int x = 0; x < wb.getNumberOfSheets(); x=x+2) 
				{
					List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
					XSSFSheet sheet=wb.getSheetAt(x);
					XSSFRow row; 	
					//Iterator rows = sheet.rowIterator();
					Iterator<Row> rows = sheet.iterator();

					boolean flag1  = false;

					Map<String, List<String>> allPossVals = null ;

					while (rows.hasNext())
					{
						AssetInstance prhVo = new AssetInstance();

						row=(XSSFRow) rows.next();

						int  rowNum = row.getRowNum();

						if(row.getRowNum() == 0)
						{
							XSSFRow rowb = sheet.getRow(rowNum++);

							XSSFCell cellaa = rowb.getCell(0);

							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}
							}
							else
							{
								splitAssetName = "";
							}
							assetInstList = assetInstanceVersionDao.getAssetInstVerByAsset(splitAssetName, conn);
							List<AssetDef> assetNameListt =  assetDao.getAllAssetNames(userName,conn);
							for(int h=0;h<assetNameListt.size();h++)
							{
								if(!assetNameListt.get(h).getAssetName().equalsIgnoreCase(splitAssetName))
								{
									assetInstList1 = assetInstanceVersionDao.getAssetInstVerByAsset(assetNameListt.get(h).getAssetName(), conn);
								}
								assetInstList2.add(assetInstList1);
							}

							assetInstList2.add(assetInstList);
							continue;   
						}

						if( row.getRowNum()==1 )
						{
							continue; 
						}

						if(row.getRowNum() == 2)
						{
							AssetDef asset = assetInstanceDao.retAssetDetail(splitAssetName, conn);

							allTxs = taxonomyDao.getAllTaxonomiesByAssetId(asset.getAssetId(), conn);

							for(TaxonomyMaster t:allTxs)
							{
								recurse1(t); 
							}
							Set<Long> hs = new HashSet<Long>();
							hs.addAll(associatedTaxId);
							associatedTaxId.clear();
							associatedTaxId.addAll(hs);
							flag1 = asset.isVersionable();

							paramList = assetDao.getParamsByAsset(splitAssetName, conn);
							
							List<AssetParamDef> ldapmodifiedData = new ArrayList<AssetParamDef>();
							List<AssetParamDef> ldapmodifiedDataRemoval = new ArrayList<AssetParamDef>();
							for(AssetParamDef apd: paramList) {
								if(apd.getParamTypeId() == 9) {
									List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(apd.getLdapMappingId(), conn);
									for(LdapMapping ldapAttributes:ldapMapping) {
										AssetParamDef assetparam = new AssetParamDef();
										assetparam.setLdapMappingId(apd.getLdapMappingId());
										assetparam.setAssetParamName(apd.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
										assetparam.setParamTypeId(apd.getParamTypeId());
										ldapmodifiedData.add(assetparam);
									}
									ldapmodifiedDataRemoval.add(apd);
								}
							}
							if(!ldapmodifiedDataRemoval.isEmpty()) {
								paramList.removeAll(ldapmodifiedDataRemoval);
							}
							if(!ldapmodifiedData.isEmpty()) {
								paramList.addAll(ldapmodifiedData);
							}
							
							
							List<AssetParamDef> ldapparameter = new ArrayList<AssetParamDef>();
							List<AssetParamDef> ldapparameterRemoval = new ArrayList<AssetParamDef>();

							allCatsAndParamsForAsset = assetDao.getCategoryNameAndParametersByAssetId(asset.getAssetId(), conn);

							listAivo =  assetInstanceVersionDao.getAssetInstVerByAsset(splitAssetName, conn);

							allPossVals = new LinkedHashMap<String, List<String>>();
							List<AssetParamDef> filterList = new ArrayList<AssetParamDef>();
							for(int i=0; i<allCatsAndParamsForAsset.size(); i++)
							{
								if(allCatsAndParamsForAsset.get(i).getParamTypeId().equals(4L)){

									possValues = new ArrayList<String>();  

									if(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId().equals(1L)){

										filterList = assetDao.getFilterList(splitAssetName, allCatsAndParamsForAsset.get(i).getAssetParamName(), "CUSTOMLIST",userName,allCatsAndParamsForAsset.get(i).getMappedAssetId(),conn);

									}else if(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId().equals(2L)){

										filterList = assetDao.getFilterList(splitAssetName, allCatsAndParamsForAsset.get(i).getAssetParamName(), "ASSETLIST",userName,allCatsAndParamsForAsset.get(i).getMappedAssetId(),conn);

									}else if(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId().equals(3L)){

										filterList = assetDao.getFilterList(splitAssetName, allCatsAndParamsForAsset.get(i).getAssetParamName(), "NATIVEUSERLIST",userName,allCatsAndParamsForAsset.get(i).getMappedAssetId(),conn);

									}
									for(AssetParamDef assetParamDef:filterList){

										possValues.add(assetParamDef.getParamValue());

									}
									allPossVals.put(allCatsAndParamsForAsset.get(i).getAssetParamName(), possValues);
								}else if(allCatsAndParamsForAsset.get(i).getParamTypeId().equals(9L)) {

									ldapparameterRemoval.add(allCatsAndParamsForAsset.get(i));
									List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(allCatsAndParamsForAsset.get(i).getLdapMappingId(), conn);

									for(LdapMapping ldapAttributes:ldapMapping) {
										AssetParamDef assetparam = new AssetParamDef();
										assetparam.setAssetParamName(allCatsAndParamsForAsset.get(i).getAssetParamName());
										assetparam.setAssetParamId(allCatsAndParamsForAsset.get(i).getAssetParamId());
										assetparam.setAssetCategoryName(allCatsAndParamsForAsset.get(i).getAssetCategoryName());
										assetparam.setAssetCategoryId(allCatsAndParamsForAsset.get(i).getAssetCategoryId());
										assetparam.setMappedAssetId(allCatsAndParamsForAsset.get(i).getMappedAssetId());
										assetparam.setParamTypeId(allCatsAndParamsForAsset.get(i).getParamTypeId());
										assetparam.setListTypeParamTypeId(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId());
										assetparam.setDerivedAttributeComputation(allCatsAndParamsForAsset.get(i).getDerivedAttributeComputation());
										assetparam.setSize(allCatsAndParamsForAsset.get(i).getSize());
										assetparam.setAssetParamId(allCatsAndParamsForAsset.get(i).getAssetParamId());
										assetparam.setHasStaticValue(allCatsAndParamsForAsset.get(i).isHasStaticValue());
										assetparam.setHasMandatoryValue(allCatsAndParamsForAsset.get(i).isHasMandatoryValue());
										assetparam.setHasArray(allCatsAndParamsForAsset.get(i).getHasArray());
										assetparam.setListType(allCatsAndParamsForAsset.get(i).getListType());
										assetparam.setLdapMappingId(allCatsAndParamsForAsset.get(i).getLdapMappingId());
										assetparam.setAssetParamName(allCatsAndParamsForAsset.get(i).getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
										assetparam.setParamTypeId(allCatsAndParamsForAsset.get(i).getParamTypeId());
										ldapparameter.add(assetparam);
									}
								}
							}
							if(!ldapparameterRemoval.isEmpty()) {
								allCatsAndParamsForAsset.removeAll(ldapparameterRemoval);
							}
							if(!ldapparameter.isEmpty()) {
								allCatsAndParamsForAsset.addAll(ldapparameter);
							}
						}

						String cell1= null, cell2 = null, cell3 = null , cell4 = null;

						XSSFRow rowb = sheet.getRow(rowNum++);

						XSSFCell cellbb = rowb.getCell(0);

						XSSFCell cellcc = rowb.getCell(1);

						XSSFCell celldd = rowb.getCell(2);

						XSSFCell cellee = rowb.getCell(3);

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellbb.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellbb.getNumericCellValue(); 
								cell1 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}
						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellcc.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellcc.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellcc.getStringCellValue();
							}
						}
						else
						{
							cell2 = "";
						}

						if(celldd != null)
						{
							if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = celldd.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val1 = (int)celldd.getNumericCellValue(); 
								cell3 = String.valueOf(val1); 
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = celldd.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}
						if(cellee != null)
						{
							if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell4 = cellee.getStringCellValue();
								if(cell4.length() == 0)
								{
									cell4 = "";  
								}
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellee.getNumericCellValue(); 
								cell4 = String.valueOf(val); 
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell4 = cellee.getStringCellValue();
							}
						}
						else
						{
							cell4 = "";
						}

						AssetInstance ai = new AssetInstance();
						ai.setAssetName(splitAssetName.trim());
						if(flag1 == true){

							ai.setVersionName(cell3.trim());
							ai.setVersionable(true);
						}
						else
						{
							if(cell3.equals("NA")){
								ai.setVersionName(Constants.DEFAULT_VERSION); 
								ai.setVersionable(false);
							}
							else{
								ai.setVersionName(cell3.trim()); 
								ai.setVersionable(false);
							}
						}
						ai.setAssetInstName(cell2.trim());
						ai.setParentAssetInstName(null);
						ai.setParentAssetName(null);

						AssetInstanceVersion avVo = new AssetInstanceVersion();

						avVo.setAssetName(ai.getAssetName().trim());
						avVo.setAssetInstName(cell2.trim());
						avVo.setVersionName(ai.getVersionName().trim());
						excelassetInstList.add(avVo);
						listOfexcelassetInstList.put(ai.getAssetName(), excelassetInstList);

					}

					for(AssetInstanceVersion aivo:assetInstList)
					{
						Boolean flagForNotRemove = false;
						for(AssetInstanceVersion aiv:excelassetInstList)
						{
							if(aivo.getAssetName().equalsIgnoreCase(aiv.getAssetName())&& aivo.getAssetInstName().equalsIgnoreCase(aiv.getAssetInstName()) &&  aivo.getVersionName().equalsIgnoreCase(aiv.getVersionName()))
							{
								flagForNotRemove = true;
								break;
							}
						}
						if(!flagForNotRemove)
						{   
							aivo.setAction("delete");

						}
					}

					rows = sheet.rowIterator();

					while (rows.hasNext())
					{
						String currentExclRecStat = "none"; ///////ADDED
						AssetInstance prhVo = new AssetInstance();
						row = (XSSFRow) rows.next();
						int  rowNum = row.getRowNum();
						if(row.getRowNum() == 0)
						{
							XSSFRow rowb = sheet.getRow(rowNum++);
							XSSFCell cellaa = rowb.getCell(0);

							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									splitAssetName = cellaa.getStringCellValue();
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}
							}
							else
							{
								splitAssetName = "";
							}

							continue;   
						}

						if( row.getRowNum()==1 )
						{
							continue; 
						}

						String newParamDataForRevision = "";
						String cell1= null, cell2 = null, cell3 = null , cell4 = null;
						XSSFRow rowb = sheet.getRow(rowNum++);
						XSSFCell cellbb = rowb.getCell(0);
						XSSFCell cellcc = rowb.getCell(1);
						XSSFCell celldd = rowb.getCell(2);
						XSSFCell cellee = rowb.getCell(3);

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellbb.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellbb.getNumericCellValue(); 
								cell1 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}

						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellcc.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellcc.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellcc.getStringCellValue();
							}

						}
						else
						{
							cell2 = "";
						}

						if(celldd != null)
						{
							if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = celldd.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)celldd.getNumericCellValue(); 
								cell3 = String.valueOf(val); 
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = celldd.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}

						if(cellee != null)
						{
							if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell4 = cellee.getStringCellValue();
								if(cell4.length() == 0)
								{
									cell4 = "";  
								}
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellee.getNumericCellValue(); 
								cell4 = String.valueOf(val); 
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell4 = cellee.getStringCellValue();
							}
						}
						else
						{
							cell4 = "";
						}

						if(splitAssetName!= "" &&  cell1 != "" &&  cell2 != "" && cell3 != "" && cell4 != "")
						{
							cell1  = cell1.trim();
							cell2  = cell2.trim();
							cell3  = cell3.trim();
							cell4  = cell4.trim();
							splitAssetName  = splitAssetName.trim();

							if(cell1.length() > 20)
							{
								if (log.isErrorEnabled()) {
									log.error(" Asset Instance Version Id exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
								}
								errorsOnProc.add(" Asset Instance Version Id exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
							}
							if(cell2.length() > 100)
							{
								if (log.isErrorEnabled()) {
									log.error(" Asset Instance Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
								}
								errorsOnProc.add(" Asset Instance Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
							}
							if(cell3.length() > 10)
							{
								if (log.isErrorEnabled()) {
									log.error(" Asset Instance Version Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
								}
								errorsOnProc.add(" Asset Instance Version Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
							}
							if(cell4.length() > 50000)
							{
								if (log.isErrorEnabled()) {
									log.error(" Asset Instance Description exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
								}
								errorsOnProc.add(" Asset Instance Description exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
							}

							Boolean flagForValidation11 = false;
							String iCharsw = "!@#$%^&*()+=-[]\\\';,/{}|.\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWYZ][0123456789]";
							for (int i = 0; i < cell1.length(); i++) 
							{
								if (iCharsw.indexOf(cell1.trim().charAt(i)) != -1) {
									flagForValidation11 = true;
									break;
								}
							}

							String iChars1 = "!%^*=[];{}|<>?~";
							Boolean flagForValidation1 = false;
							for (int k = 0; k < cell2.length(); k++) 
							{
								if (iChars1.indexOf(cell2.charAt(k)) != -1) 
								{
									flagForValidation1 = true;
									break;
								}
							}
							AssetInstance ai = new AssetInstance();
							ai.setAssetName(splitAssetName);
							Boolean flagForValidation2 = false;
							if(flag1 == true){
								String iChars2 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWXYZ]";
								for (int i = 0; i < cell3.length(); i++) 
								{
									if (iChars2.indexOf(cell3.trim().charAt(i)) != -1) 
									{
										flagForValidation2= true;
										break;
									}
								}
							}

							if(flagForValidation11)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets/Numeric not allowed for Asset Instance Version Id column except XXXX from "+ cell2+"_"+cell3+ " at "+splitAssetName);
								}
								errorsOnProc.add("Special Characters/Alphabets/Numeric not allowed for Asset Instance Version Id column except XXXX from "+ cell2+"_"+cell3+ " at "+splitAssetName);
							}
							if(flagForValidation1)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in " + cell2+" at "+splitAssetName);
								}
								errorsOnProc.add("Special Character not allowed in " + cell2+" at "+splitAssetName);
							}
							if( flagForValidation2)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed for version column " + cell2+"_"+cell3+ " at "+splitAssetName);
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed for version column " + cell2+"_"+cell3+ " at "+splitAssetName);
							}

							else
							{
								if(flag1 == true){

									if(cell3.matches("([0-9]{1})") || cell3.matches("([0-9]{1}.)"))
									{
										if (log.isErrorEnabled()) {
											log.error("Error : This Version Name format not allowed  for " + cell2+" at "+splitAssetName);
										}
										errorsOnProc.add("Error : This Version Name format not allowed  for " + cell2+" at "+splitAssetName);
									}
									ai.setVersionName(cell3);
									ai.setVersionable(true);
								}
								else
								{
									if(cell3.trim().equals("NA"))
									{
										ai.setVersionName(Constants.DEFAULT_VERSION); 
										ai.setVersionable(false);
									}
									else
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Version Name in " + cell2+" at "+splitAssetName);
										}
										errorsOnProc.add("Please provide valid Version Name in " + cell2+" at "+splitAssetName); 
									}
								}
								ai.setAssetInstName(cell2);
								ai.setParentAssetInstName(null);
								ai.setParentAssetName(null);
								AssetInstanceVersion avVo = new AssetInstanceVersion();
								Boolean flag12 = false;
								Boolean flagforupdate = false;
								for(AssetInstanceVersion aivo:assetInstList)
								{
									if( aivo.getAssetInstName().equalsIgnoreCase(cell2) )
									{
										aivo.setAction("update");
										if (log.isErrorEnabled()) {
											log.error("Error: Existing asset instance not allowed through excel import for incremental insert option: " + cell2+"_"+cell3+" of "+splitAssetName);
										}
										errorsOnProc.add("Error: Existing asset instance not allowed through excel import for incremental insert option: " + cell2+"_"+cell3+" of "+splitAssetName);
										flagforupdate = true;
										flag12 = true;
										break;
									}
								}
								Boolean flagdf = true;
								if(!flag12)
								{  
									if(!cell1.equals("XXXX"))
									{
										if (log.isErrorEnabled()) {
											log.error("Error Found : Please check " + cell1+","+cell2+","+cell3+" of "+splitAssetName+" Attribute sheet");
										}
										errorsOnProc.add("Error Found : Please check " + cell1+","+cell2+","+cell3+" of "+splitAssetName+" Attribute sheet");
									}

									for(AssetRelationshipDef relNm :relNameList)
									{
										if(relNm.getFwdRelationType().equals("composition") || relNm.getFwdRelationType().equals("aggregation"))
										{
											if(relNm.getDestAssetName().equalsIgnoreCase(ai.getAssetName()))
											{
												flagdf= false;
											}
										}

									}
									if(flagdf)
									{
										Boolean flagforChech = false;
										for(AssetInstanceVersion aivo:assetInstList)
										{
											if( aivo.getAction()!= null)
											{
												if( aivo.getAssetInstName().equalsIgnoreCase(cell2) && !aivo.getAction().equals("delete"))
												{
													flagforChech = true;
													break;
												}
											}
										}
										if(!flagforChech)
										{
											avVo.setAssetName(ai.getAssetName());
											avVo.setAssetInstName(cell2);
											avVo.setVersionName(ai.getVersionName());
											avVo.setDescription(cell4);
											avVo.setAction("add");
											currentExclRecStat = "add";
											assetInstList.add(avVo);
										}
										else
										{
											if (log.isErrorEnabled()) {
												log.error("Error: versions cannot be added through excel import option: " + cell2+"_"+cell3+" of "+splitAssetName);
											}
											errorsOnProc.add("Error: versions cannot be added through excel import option: " + cell2+"_"+cell3+" of "+splitAssetName);
										}
									}
								}
								if( !flagdf )
								{
									if (log.isErrorEnabled()) {
										log.error("Error: Creating Asset Instance not allowed at  " + cell2+"_"+cell3+" of "+splitAssetName + " since it is a child asset type.");
									}
									errorsOnProc.add("Error: Creating Asset Instance not allowed at  " + cell2+"_"+cell3+" of "+splitAssetName + " since it is a child asset type.");
								}

								Boolean flagCheck = false;
								for (int u=0;u< listAivo.size();u++)
								{ 
									if(listAivo.get(u).getDescription() != null){
										if(listAivo.get(u).getAssetInstName().equalsIgnoreCase(ai.getAssetInstName()) && listAivo.get(u).getVersionName().equalsIgnoreCase(ai.getVersionName())&& listAivo.get(u).getDescription().equals(cell4) ){
											flagCheck = true;
										}
									}
								}

								if(!flagCheck)
								{
									AssetInstDescSuccess aidVo = new AssetInstDescSuccess();

									aidVo.setAssetType(ai.getAssetName());
									aidVo.setAssetInstName(ai.getAssetInstName());
									aidVo.setAssetInstanceDescription(cell4);
									aidVo.setParentAssetName(ai.getParentAssetName());
									aidVo.setParentAssetInstanceName(ai.getParentAssetInstName());
									aidVo.setVersionName(ai.getVersionName());
									aisdVoList.add(aidVo);

								}

								int i = 5;
								int j = 0;
								int y = 0;
								Map<String,String> paramMapFromDb1 = new HashMap<String,String>();

								if(flagforupdate)
								{

								}
								List<String> paramNames = new ArrayList<String>() ;
								Collections.sort(paramList, new AssetParamDef());
								for (AssetParamDef pvo: paramList)
								{
									paramNames.add(pvo.getAssetParamName());
								}
								//Collections.sort(paramNames,String.CASE_INSENSITIVE_ORDER);
								Boolean pvalflag = false;
								List<String> ldapmappingdata = new ArrayList<String>();
								List<LdapMapping> ldapAttributeList = new ArrayList<LdapMapping>();
								List<String> ldapmappingfirstattributedata = new ArrayList<String>();
								int ldapcount = 0;
								for (String  paramName: paramNames)
								{
									AssetParamSuccess apsVo = new AssetParamSuccess();
									AssetParamSuccess apevo = new AssetParamSuccess();
									String paramVal = null;
									Boolean flag = false;
									for(AssetParamDef aiv:allCatsAndParamsForAsset)
									{ 
										if(aiv.getAssetParamName().equalsIgnoreCase(paramName)){
											XSSFCell cellee1 = rowb.getCell(i++);
											if(cellee1 != null )
											{
												if (cellee1.getCellType() == XSSFCell.CELL_TYPE_STRING)
												{
													paramVal = cellee1.getStringCellValue().trim();
													if(paramVal.length() == 0)
													{
														paramVal = "";  
													}
												}
												if (cellee1.getCellType() == XSSFCell.CELL_TYPE_BLANK)
												{
													paramVal = cellee1.getStringCellValue().trim();
													if(paramVal.length() == 0)
													{
														paramVal = "";  
													}
												}
												else if(cellee1.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
												{
													int val = (int)cellee1.getNumericCellValue(); 
													paramVal = String.valueOf(val); 
												}
											}
											else
											{
												paramVal = "";
											}
											Boolean chkFilePrmValFlag1 = false;
											/*	if(flagforupdate)
										{
											for (Map.Entry<String, String> entry1 : paramMapFromDb1.entrySet()) {
												if(paramName.equalsIgnoreCase(entry1.getKey())){
													if((paramVal.isEmpty() && entry1.getValue() == null) || (paramVal.equals(entry1.getValue())) ){
														chkFilePrmValFlag1 = true;
														break;
													}
												}
											}	
										}*/
											if((paramVal != null)){
												if(!chkFilePrmValFlag1||(aiv.isHasMandatoryValue()&&paramVal.equalsIgnoreCase(""))){
													pvalflag = true;
													if(aiv.getParamTypeId().equals(4L))
													{
														if(aiv.getListTypeParamTypeId()!=null)
														{
															if((aiv.getListTypeParamTypeId().equals(1L)))
															{
																if(globalsetting.getGlobalSettingFlag() == 1){
																	paramVal = commonUtils.httpSanitizerForPlainText(paramVal);
																	//paramVal = StringEscapeUtils.escapeHtml4(paramVal);
																}
																possValues = null;
																for (Entry<String, List<String>> allpvals : allPossVals.entrySet())
																{
																	if(allpvals.getKey().equalsIgnoreCase(paramName))
																		possValues = allpvals.getValue();
																}

																boolean listflag = false;
																if(!paramVal.equalsIgnoreCase("")){
																	if(paramVal.contains("~~") && aiv.getListType() == 0){
																		listflag = false;
																		apevo.setErrorMessage(" multiple values are not allowed ");
																	}else if(paramVal.endsWith("~~")){
																		listflag = false;
																	}else{
																		List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																		boolean duplicateFlag = false;
																		Set<String> duplicate = new HashSet<String>();
																		duplicate.addAll(paramValList);
																		if(duplicate.size()<paramValList.size()){
																			duplicateFlag = true;
																		}
																		if(duplicateFlag == false){
																			int count = 0;
																			for(int k=0;k<possValues.size();k++){  
																				for(int l = 0; l < paramValList.size(); l++){
																					if (possValues.get(k).equals(paramValList.get(l))) {
																						count++;
																					}
																				}
																				if(count == paramValList.size()){
																					listflag = true;
																					break;
																				}
																			}
																		}
																	}
																}
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){
																		listflag = true;
																	}
																}
																if(listflag == true)
																{      
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVoList.add(apsVo);
																	flag = true;
																	break;

																}
																if(flag == false)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}

															if((aiv.getListTypeParamTypeId().equals(2L))){
																possValues = null;
																for (Entry<String, List<String>> allpvals : allPossVals.entrySet())
																{
																	if(allpvals.getKey().equalsIgnoreCase(paramName))
																		possValues = allpvals.getValue();
																}
																boolean listflag = false;
																if(!paramVal.equalsIgnoreCase("")){
																	if(paramVal.contains("~~") && aiv.getListType() == 0){
																		listflag = false;
																		apevo.setErrorMessage(" multiple values are not allowed ");
																	}else if(paramVal.endsWith("~~")){
																		listflag = false;
																	}else{
																		List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																		boolean duplicateFlag = false;
																		Set<String> duplicate = new HashSet<String>();
																		duplicate.addAll(paramValList);
																		if(duplicate.size()<paramValList.size()){
																			duplicateFlag = true;
																		}
																		if(duplicateFlag == false){
																			int count = 0;
																			for(int k=0;k<possValues.size();k++){  
																				for(int l = 0; l < paramValList.size(); l++){
																					if (possValues.get(k).equals(paramValList.get(l))) {
																						count++;
																					}
																				}
																				if(count == paramValList.size()){
																					listflag = true;
																					break;
																				}
																			}
																		}
																	}
																}
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){
																		listflag = true;
																	}
																}
																if(listflag == true)
																{    
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																	break;
																}
																if(flag == false)
																{
																	if(apevo.getParamValue() != paramVal)
																	{
																		apevo.setAssetType(ai.getAssetName());
																		apevo.setAssetInstName(ai.getAssetInstName());
																		apevo.setVersionName(ai.getVersionName());
																		apevo.setParentAssetName(ai.getParentAssetName());
																		apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apevo.setVersionable(ai.isVersionable());
																		apevo.setParamTypeName(aiv.getTypeName());
																		apevo.setCatName(aiv.getAssetCategoryName());
																		apevo.setParamTypeId(aiv.getParamTypeId());
																		apevo.setParamName(paramName);
																		apevo.setParamValue(paramVal);
																		apevo.setAssetParamId(aiv.getAssetParamId());
																		apeVoList.add(apevo);
																	}
																}
															}

															if((aiv.getListTypeParamTypeId().equals(3L)))
															{
																possValues = null;
																for (Entry<String, List<String>> allpvals : allPossVals.entrySet())
																{
																	if(allpvals.getKey().equalsIgnoreCase(paramName))
																		possValues = allpvals.getValue();
																}
																boolean listflag = false;
																if(!paramVal.equalsIgnoreCase("")){
																	if(paramVal.contains("~~") && aiv.getListType() == 0){
																		listflag = false;
																		apevo.setErrorMessage(" multiple values are not allowed ");
																	}else if(paramVal.endsWith("~~")){
																		listflag = false;
																	}else{
																		List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																		boolean duplicateFlag = false;
																		Set<String> duplicate = new HashSet<String>();
																		duplicate.addAll(paramValList);
																		if(duplicate.size()<paramValList.size()){
																			duplicateFlag = true;
																		}
																		if(duplicateFlag == false){
																			int count = 0;
																			for(int k=0;k<possValues.size();k++){  
																				for(int l = 0; l < paramValList.size(); l++){
																					if (possValues.get(k).equals(paramValList.get(l))) {
																						count++;
																					}
																				}
																				if(count == paramValList.size()){
																					listflag = true;
																					break;
																				}
																			}
																		}
																	}
																}
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){
																		listflag = true;
																	}
																}
																if(listflag == true)
																{      
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																	break;
																}
																if(flag == false)
																{
																	if(apevo.getParamValue() != paramVal){
																		apevo.setAssetType(ai.getAssetName());
																		apevo.setAssetInstName(ai.getAssetInstName());
																		apevo.setVersionName(ai.getVersionName());
																		apevo.setParentAssetName(ai.getParentAssetName());
																		apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apevo.setVersionable(ai.isVersionable());
																		apevo.setParamTypeName(aiv.getTypeName());
																		apevo.setCatName(aiv.getAssetCategoryName());
																		apevo.setParamTypeId(aiv.getParamTypeId());
																		apevo.setParamName(paramName);
																		apevo.setParamValue(paramVal);
																		apevo.setAssetParamId(aiv.getAssetParamId());
																		apeVoList.add(apevo);
																	}
																}
															}
															if((aiv.getListTypeParamTypeId().equals(4L)))
															{
																//message for not updateing ldap userlist type
																/*if(ai.isVersionable()){
																	invalidLdapIds.add("Skipped "+paramName+" under "+aiv.getAssetCategoryName()+" for asset instance "+ai.getAssetInstName()+"_"+ai.getVersionName()+" for "+ai.getAssetName()+" ,since it is ldap userlist Type\n");	 
																}else{
																	invalidLdapIds.add("Skipped "+paramName+" under "+aiv.getAssetCategoryName()+" for asset instance "+ai.getAssetInstName()+"_"+ai.getVersionName()+" for "+ai.getAssetName()+" ,since it is ldap userlist Type\n");	 
																}
																*/
																boolean listflag = false;
																//boolean zerolistflag = false;
																boolean invaliddataflag = false;
																if(!paramVal.equalsIgnoreCase("")){
																	if(paramVal.contains("~~") && aiv.getListType() == 0){
																		listflag = false;
																		apevo.setErrorMessage(" multiple values are not allowed ");
																	}else if(paramVal.endsWith("~~")){
																		listflag = false;
																	}else{
																		List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																		List<String> paramValList = new ArrayList<String>();
																		List<String> finalparamValList = new ArrayList<String>();
																		List<String> names = new ArrayList<String>();
																		List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
																		for(String data:firstParamValList){
																			if(data.contains("(") && data.contains(")")){
																				//fetching search string from saved result
																				String result = data.substring(data.indexOf("(") + 1, data.indexOf(")"));
																				names.add(data);
																				paramValList.add(result);
																			}else if(data.contains("(") || data.contains(")")){
																				invaliddataflag = true;
																				listflag = false;
																				break;
																			}else{
																				paramValList.add(data);
																			}
																		}
																		boolean duplicateFlag = false;
																		Set<String> duplicate = new HashSet<String>();
																		duplicate.addAll(paramValList);
																		if(duplicate.size()<paramValList.size()){
																			duplicateFlag = true;
																		}
																		if(invaliddataflag == false){
																			if(duplicateFlag == false){
																				LDAPConnection ldapConnection = LDAPConnection.getInstance();
																				DirContext dirContext = ldapConnection.getDirContext();
																				for(String data:paramValList){
																					listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,data);
																					/*zerolistflag = false;
																				if(listOfLDAPUsers.size() == 0){
																					zerolistflag = true;
																					//invalid search string(ignore the result related to invalid string)
																					if(ai.isVersionable()){
																						invalidLdapIds.add(data+" search string did not reterieve any result,So could not update "+paramName+" value under "+aiv.getAssetCategoryName()+" for asset instance "+ai.getAssetInstName()+"_"+ai.getVersionName()+" for "+ai.getAssetName()+"\n");	 
																					}else{
																						invalidLdapIds.add(data+" search string did not reterieve any result,So could not update "+paramName+" value under "+aiv.getAssetCategoryName()+" for asset instance "+ai.getAssetInstName()+" for "+ai.getAssetName()+"\n");	 
																					}
																				}else */if(listOfLDAPUsers.size() == 1){
																					for(LDAPUser finaldata:listOfLDAPUsers){
																						//invalid firstname validation,If invalid through an error as invalid data
																						for(String name:names){
																							if(name.contains("(")){
																								String result = name.substring(name.indexOf("(") + 1, name.indexOf(")"));
																								String fullname = name.substring(0,name.indexOf("("));
																								if(result.equalsIgnoreCase(finaldata.getUserId())){
																									if(!fullname.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																										invaliddataflag = true;
																										break;
																									}
																								}
																							}
																						}
																						if(invaliddataflag == true){
																							listflag = false;
																							break;
																						}else{
																							String val = finaldata.getFirstName()+" "+finaldata.getLastName()+"("+finaldata.getUserId()+")";
																							finalparamValList.add(val);
																							listflag = true;
																						}
																					}
																				}else{
																					listflag = false;
																					break;
																				}
																				}
																				if(!finalparamValList.isEmpty()){
																					paramVal = String.join("~~", finalparamValList);
																				}
																			}
																		}
																	}
																}
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){
																		listflag = true;
																	}
																}
																
																if(listflag == true)
																{     
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																	break;
																}
																//if(zerolistflag == false){
																	if(flag == false)
																	{
																		if(apevo.getParamValue() != paramVal){
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apevo.setParamTypeId(aiv.getParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}
																//}
															}
														}
													}
													else if((aiv.getParamTypeId().equals(2L)))
													{
														if (paramVal.matches("(^(((0[1-9]|[12][0-8])[/](0[1-9]|1[012]))|((29|30|31)[/](0[13578]|1[02]))|((29|30)[/](0[4,6,9]|11)))[/](19|[2-9][0-9])\\d\\d$)|(^29[/]02[/](19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)") || paramVal.equalsIgnoreCase("")) {
															if(paramVal != ""){
																String[] words = paramVal.split("/");
																int num = Integer.parseInt(words[2]);
																if(num > 2999)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
																else
																{
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																}
															}
															else
															{
																if(!aiv.isHasMandatoryValue()){
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVoList.add(apsVo);
																	flag = true;
																}
																if(flag == false)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}
														}
														else
														{
															apevo.setAssetType(ai.getAssetName());
															apevo.setAssetInstName(ai.getAssetInstName());
															apevo.setVersionName(ai.getVersionName());
															apevo.setParentAssetName(ai.getParentAssetName());
															apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
															apevo.setVersionable(ai.isVersionable());
															apevo.setParamTypeName(aiv.getTypeName());
															apevo.setCatName(aiv.getAssetCategoryName());
															apevo.setParamTypeId(aiv.getParamTypeId());
															apevo.setParamName(paramName);
															apevo.setParamValue(paramVal);
															apevo.setAssetParamId(aiv.getAssetParamId());
															apeVoList.add(apevo);
														}
													}
													else if((aiv.getParamTypeId().equals(1L)))
													{
														boolean nonStaticCheck = true;
														if(globalsetting.getGlobalSettingFlag() == 1){
															paramVal = commonUtils.httpSanitizerForPlainText(paramVal);

															//paramVal = StringEscapeUtils.escapeHtml4(paramVal);
														}
														if(paramVal.startsWith("~~")||paramVal.endsWith("~~")){
															nonStaticCheck = false;
														}else if(aiv.isHasStaticValue()){
															
															if(paramVal.contains("~~")){
																nonStaticCheck = false;
																apevo.setErrorMessage(" multiple values are not allowed since parameter type is static! ");
															}
														}else if(aiv.getHasArray() == 0){
															
															if(paramVal.contains("~~")){
																nonStaticCheck = false;
																apevo.setErrorMessage(" multiple values are not allowed ");
															}
														}
														if(nonStaticCheck == true){
															if(!paramVal.equalsIgnoreCase(""))
															{
																if(paramList.size()-1 == y)
																{
																	newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																}
																else{
																	newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																}
																apsVo.setAssetType(ai.getAssetName());
																apsVo.setAssetInstName(ai.getAssetInstName());
																apsVo.setVersionName(ai.getVersionName());
																apsVo.setParentAssetName(ai.getParentAssetName());
																apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apsVo.setParamTypeName(aiv.getTypeName());
																apsVo.setCatName(aiv.getAssetCategoryName());
																apsVo.setParamTypeId(aiv.getParamTypeId());
																apsVo.setParamName(paramName);
																//apsVo.setParamValue(paramVal);
																apsVo.setHasStaticValue(aiv.isHasStaticValue());
																apsVo.setHasArray(aiv.getHasArray());
																apsVo.setAssetParamId(aiv.getAssetParamId());
																boolean sizecheck = true;
																if(aiv.isHasStaticValue()){
																	apsVo.setParamValue(paramVal);
																	if(paramVal.length()>(aiv.getSize())){
																		sizecheck = false;
																	}
																	apsVoList.add(apsVo);
																	if(sizecheck == true){
																		flag = true;
																	}
																}else if(aiv.getHasArray() == 0){
																	apsVo.setParamValue(paramVal);
																	if(paramVal.length()>(aiv.getSize())){
																		sizecheck = false;
																	}
																	apsVoList.add(apsVo);
																	if(sizecheck == true){
																		flag = true;
																	}
																}else{
																	List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																	boolean emptyCheck = true;
																	for(String data:paramValList){
																		String val = data.trim();
																		if(val.equalsIgnoreCase("")){
																			emptyCheck = false;
																			break;
																		}
																	}
																	if(emptyCheck == true){
																		apsVo.setTextDataList(paramValList);
																		for(String data:apsVo.getTextDataList()){
																			if(data.length()>(aiv.getSize())){
																				sizecheck = false;
																				break;
																			}
																		}
																		apsVoList.add(apsVo);
																		if(sizecheck == true){
																			flag = true;
																		}
																	}
																}
															}else { 
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){

																		if(paramList.size()-1 == y)
																		{
																			newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																		}
																		else{
																			newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																		}
																		apsVo.setAssetType(ai.getAssetName());
																		apsVo.setAssetInstName(ai.getAssetInstName());
																		apsVo.setVersionName(ai.getVersionName());
																		apsVo.setParentAssetName(ai.getParentAssetName());
																		apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apsVo.setParamTypeName(aiv.getTypeName());
																		apsVo.setCatName(aiv.getAssetCategoryName());
																		apsVo.setParamTypeId(aiv.getParamTypeId());
																		apsVo.setParamName(paramName);
																		if(aiv.isHasStaticValue()){
																			apsVo.setParamValue(paramVal);
																		}else if(aiv.getHasArray() == 0){
																			apsVo.setParamValue(paramVal);
																		}else{
																			List<String> paramValList = new ArrayList<String>();
																			apsVo.setTextDataList(paramValList);;
																		}
																		apsVo.setHasStaticValue(aiv.isHasStaticValue());
																		apsVo.setHasArray(aiv.getHasArray());
																		apsVo.setAssetParamId(aiv.getAssetParamId());
																		apsVoList.add(apsVo);
																		flag = true;
																	}
																}
															}
															if(flag == false)
															{

																apevo.setAssetType(ai.getAssetName());
																apevo.setAssetInstName(ai.getAssetInstName());
																apevo.setVersionName(ai.getVersionName());
																apevo.setParentAssetName(ai.getParentAssetName());
																apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apevo.setVersionable(ai.isVersionable());
																apevo.setParamTypeName(aiv.getTypeName());
																apevo.setCatName(aiv.getAssetCategoryName());
																apevo.setParamTypeId(aiv.getParamTypeId());
																apevo.setParamName(paramName);
																apevo.setParamValue(paramVal);
																apevo.setAssetParamId(aiv.getAssetParamId());
																apeVoList.add(apevo);
															}
														}else{

															apevo.setAssetType(ai.getAssetName());
															apevo.setAssetInstName(ai.getAssetInstName());
															apevo.setVersionName(ai.getVersionName());
															apevo.setParentAssetName(ai.getParentAssetName());
															apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
															apevo.setVersionable(ai.isVersionable());
															apevo.setParamTypeName(aiv.getTypeName());
															apevo.setCatName(aiv.getAssetCategoryName());
															apevo.setParamTypeId(aiv.getParamTypeId());
															apevo.setParamName(paramName);
															apevo.setParamValue(paramVal);
															apevo.setAssetParamId(aiv.getAssetParamId());
															apeVoList.add(apevo);

														}
													}

													else if((aiv.getParamTypeId().equals(5L))||aiv.getParamTypeId().equals(6L)||aiv.getParamTypeId().equals(8L))
													{
														flag = true;
													}
													else if((aiv.getParamTypeId().equals(7L)))
													{
														boolean nonStaticCheck = true;
														if(globalsetting.getGlobalSettingFlag() == 1){
															paramVal = commonUtils.httpSanitizerForCkEditor(paramVal);

															//paramVal = StringEscapeUtils.escapeHtml4(paramVal);
														}
														if(paramVal.startsWith("~~")||paramVal.endsWith("~~")){
															nonStaticCheck = false;
														}else if(aiv.isHasStaticValue()){
															
															if(paramVal.contains("~~")){
																nonStaticCheck = false;
																apevo.setErrorMessage(" multiple values are not allowed since parameter type is static! ");
															}
														}else if(aiv.getHasArray() == 0){
															
															if(paramVal.contains("~~")){
																nonStaticCheck = false;
																apevo.setErrorMessage(" multiple values are not allowed");
															}
														}
														if(nonStaticCheck == true){
															if(!paramVal.equalsIgnoreCase("")){
																if(paramList.size()-1 == y)
																{
																	newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																}
																else{
																	newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																}
																apsVo.setAssetType(ai.getAssetName());
																apsVo.setAssetInstName(ai.getAssetInstName());
																apsVo.setVersionName(ai.getVersionName());
																apsVo.setParentAssetName(ai.getParentAssetName());
																apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apsVo.setParamTypeName(aiv.getTypeName());
																apsVo.setCatName(aiv.getAssetCategoryName());
																apsVo.setParamTypeId(aiv.getParamTypeId());
																apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																apsVo.setParamName(paramName);
																boolean sizecheck = true;
																if(aiv.isHasStaticValue()){
																	apsVo.setParamValue(paramVal);
																	if(paramVal.length()>25000){
																		sizecheck = false;
																	}
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVo.setHasArray(aiv.getHasArray());
																	apsVoList.add(apsVo);
																	if(sizecheck == true){
																		flag = true;
																	}
																}else if(aiv.getHasArray() == 0){
																	apsVo.setParamValue(paramVal);
																	if(paramVal.length()>25000){
																		sizecheck = false;
																	}
																	String textdata = Jsoup.parse(paramVal).text();
																	apsVo.setRTFPlainText(textdata);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVo.setHasArray(aiv.getHasArray());
																	apsVoList.add(apsVo);
																	if(sizecheck == true){
																		flag = true;
																	}
																}else{
																	List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																	boolean emptyCheck = true;
																	for(String data:paramValList){
																		String val = data.trim();
																		if(val.equalsIgnoreCase("")){
																			emptyCheck = false;
																			break;
																		}
																	}
																	if(emptyCheck == true){
																		apsVo.setRTFwithTags(paramValList);
																		List<String> withOuttags = new ArrayList<String>();
																		for(String data:apsVo.getRTFwithTags()){
																			if(data.length()>25000){
																				sizecheck = false;
																				break;
																			}
																			String textdata = Jsoup.parse(data).text();
																			withOuttags.add(textdata);
																		}
																		apsVo.setRTFwithOutTags(withOuttags);
																		apsVo.setAssetParamId(aiv.getAssetParamId());
																		apsVo.setHasStaticValue(aiv.isHasStaticValue());
																		apsVo.setHasArray(aiv.getHasArray());
																		apsVoList.add(apsVo);
																		if(sizecheck == true){
																			flag = true;
																		}
																	}
																}
															}else{
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){

																		if(paramList.size()-1 == y)
																		{
																			newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																		}
																		else{
																			newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																		}
																		apsVo.setAssetType(ai.getAssetName());
																		apsVo.setAssetInstName(ai.getAssetInstName());
																		apsVo.setVersionName(ai.getVersionName());
																		apsVo.setParentAssetName(ai.getParentAssetName());
																		apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apsVo.setParamTypeName(aiv.getTypeName());
																		apsVo.setCatName(aiv.getAssetCategoryName());
																		apsVo.setParamTypeId(aiv.getParamTypeId());
																		apsVo.setParamName(paramName);
																		apsVo.setParamValue(paramVal);
																		apsVo.setHasStaticValue(aiv.isHasStaticValue());
																		apsVo.setHasArray(aiv.getHasArray());
																		apsVo.setAssetParamId(aiv.getAssetParamId());
																		if(aiv.isHasStaticValue()){
																			apsVo.setParamValue(paramVal);
																			apsVoList.add(apsVo);
																			flag = true;
																		}else if(aiv.getHasArray() == 0){
																			apsVo.setParamValue(paramVal);
																			apsVo.setRTFPlainText(paramVal);
																			apsVoList.add(apsVo);
																			flag = true;
																		}else{
																			List<String> paramValList = new ArrayList<String>();
																			paramValList.add(paramVal);
																			apsVo.setRTFwithTags(paramValList);
																			List<String> withOuttags = new ArrayList<String>();
																			withOuttags.add(paramVal);
																			apsVo.setRTFwithOutTags(withOuttags);
																			apsVoList.add(apsVo);
																			flag = true;
																		}
																	}
																}
															}
															if(flag == false)
															{
																apevo.setAssetType(ai.getAssetName());
																apevo.setAssetInstName(ai.getAssetInstName());
																apevo.setVersionName(ai.getVersionName());
																apevo.setParentAssetName(ai.getParentAssetName());
																apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apevo.setVersionable(ai.isVersionable());
																apevo.setParamTypeName(aiv.getTypeName());
																apevo.setCatName(aiv.getAssetCategoryName());
																apevo.setParamTypeId(aiv.getParamTypeId());
																apevo.setParamName(paramName);
																apevo.setParamValue(paramVal);
																apevo.setAssetParamId(aiv.getAssetParamId());
																apeVoList.add(apevo);
															}
														}else{

															apevo.setAssetType(ai.getAssetName());
															apevo.setAssetInstName(ai.getAssetInstName());
															apevo.setVersionName(ai.getVersionName());
															apevo.setParentAssetName(ai.getParentAssetName());
															apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
															apevo.setVersionable(ai.isVersionable());
															apevo.setParamTypeName(aiv.getTypeName());
															apevo.setCatName(aiv.getAssetCategoryName());
															apevo.setParamTypeId(aiv.getParamTypeId());
															apevo.setParamName(paramName);
															apevo.setParamValue(paramVal);
															apevo.setAssetParamId(aiv.getAssetParamId());
															apeVoList.add(apevo);
														}
													}else if(aiv.getParamTypeId().equals(9L)) {
														if(ldapcount == ldapAttributeList.size()) {
															ldapmappingdata.clear();
															ldapmappingfirstattributedata.clear();
															ldapAttributeList.clear();
															ldapcount = 0;
															ldapDuplicateCount = 0;
														}
														String ldapParameter = null; 
														Map<String,Integer> finalParamValList = new LinkedHashMap<String,Integer>();
														String[] ldapMappingParameter = paramName.split("_",2);
														if(ldapDuplicateCount == 0) {
															ldapAttributeList = assetDao.getLdapMappingAttributeList(aiv.getLdapMappingId(), conn);
															ldapParameter = ldapMappingParameter[0];
															String attribute = ldapMappingParameter[1];
															String attributeName = "";
															for(LdapMapping displayName:ldapAttributeList) {
																if(displayName.getAttributeDisplayName().equalsIgnoreCase(attribute)) {
																	attributeName = displayName.getAttributeName().substring(3);
																}
															}
															
															ldapDuplicateCount++;
															ldapcount++;
															boolean listflag = false;
															//boolean zerolistflag = false;
															boolean invaliddataflag = false;
															if(!paramVal.equalsIgnoreCase("")){
																if(paramVal.contains("~~") && aiv.getListType() == 0){
																	listflag = false;
																	apevo.setErrorMessage(" multiple values are not allowed ");
																}else if(paramVal.endsWith("~~")){
																	listflag = false;
																}else{
																	List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																	List<String> paramValList = new ArrayList<String>();
																	List<String> finalparamValList = new ArrayList<String>();
																	List<String> names = new ArrayList<String>();
																	List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
																	for(String data:firstParamValList){
																		if(data.contains("(") && data.contains(")")){
																			//fetching search string from saved result
																			String result = data.substring(data.indexOf("(") + 1, data.indexOf(")"));
																			names.add(data);
																			paramValList.add(result);
																		}else if(data.contains("(") || data.contains(")")){
																			invaliddataflag = true;
																			listflag = false;
																			break;
																		}else{
																			paramValList.add(data);
																		}
																	}
																	boolean duplicateFlag = false;
																	Set<String> duplicate = new HashSet<String>();
																	duplicate.addAll(paramValList);
																	if(duplicate.size()<paramValList.size()){
																		duplicateFlag = true;
																	}
																	ldapmappingfirstattributedata.addAll(paramValList);
																	if(invaliddataflag == false){
																		if(duplicateFlag == false){
																			LDAPConnection ldapConnection = LDAPConnection.getInstance();
																			DirContext dirContext = ldapConnection.getDirContext();
																			for(String data:paramValList){
																				listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,data);
																				if(listOfLDAPUsers.size() == 1){
																					for(LDAPUser finaldata:listOfLDAPUsers){
																						int count = 0;
																						
																						if(attributeName.equalsIgnoreCase(commonUtils.LdapFirstName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapLastName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getLastName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapEmail)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getEmail())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapDept)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getDept())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapUserId)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getUserId())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapFullName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}
																						
																						
																						//invalid firstname validation,If invalid throw an error as invalid data
																						for(String name:names){
																							if(name.contains("(")){
																								String result = name.substring(name.indexOf("(") + 1, name.indexOf(")"));
																								String fullname = name.substring(0,name.indexOf("("));
																								if(result.equalsIgnoreCase(finaldata.getUserId())){
																									if(!fullname.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																										invaliddataflag = true;
																										break;
																									}
																								}
																							}
																						}
																						if(invaliddataflag == true){
																							listflag = false;
																							break;
																						}else{
																							String val = finaldata.getUserId();
																							finalparamValList.add(val);
																							listflag = true;
																						}
																					}
																				}else{
																					listflag = false;
																					break;
																				}
																			}
																			if(!finalparamValList.isEmpty()){
																				String ldapfinalstring = String.join("~~", finalparamValList);
																				finalParamValList = commonUtils.ldapDataconstruction(ldapfinalstring,ai.getAssetName(),ldapParameter,conn);
																				ldapmappingdata = finalParamValList.keySet().stream().collect(Collectors.toList());
																				paramVal = String.join("``", ldapmappingdata);
																			}
																		}
																	}
																}
															}
															if(!aiv.isHasMandatoryValue()){
																if(paramVal.equalsIgnoreCase("")){
																	
																	listflag = true;
																}
															}

															if(listflag == true)
															{     
																if(paramList.size()-1 == y)
																{
																	newParamDataForRevision = newParamDataForRevision + ldapParameter+":"+ paramVal;
																}
																else{
																	newParamDataForRevision = newParamDataForRevision +ldapParameter+":"+ paramVal+Constants.APPEND_STRING;	
																}
																apsVo.setAssetType(ai.getAssetName());
																apsVo.setAssetInstName(ai.getAssetInstName());
																apsVo.setVersionName(ai.getVersionName());
																apsVo.setParentAssetName(ai.getParentAssetName());
																apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apsVo.setParamTypeName(aiv.getTypeName());
																apsVo.setCatName(aiv.getAssetCategoryName());
																apsVo.setParamTypeId(aiv.getParamTypeId());
																apsVo.setParamName(ldapParameter);
																apsVo.setParamValue(paramVal);
																apsVo.setLdapMappingValue(finalParamValList);
																apsVo.setAssetParamId(aiv.getAssetParamId());
																apsVo.setHasStaticValue(aiv.isHasStaticValue());
																apsVoList.add(apsVo);
																flag = true;
																break;
															}
															//if(zerolistflag == false){
															if(flag == false)
															{
																if(apevo.getParamValue() != paramVal){
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}
														}else {
															ldapcount++;
															
															ldapParameter = ldapMappingParameter[0];
															String attribute = ldapMappingParameter[1];
															String attributeName = "";
															for(LdapMapping displayName:ldapAttributeList) {
																if(displayName.getAttributeDisplayName().equalsIgnoreCase(attribute)) {
																	attributeName = displayName.getAttributeName().substring(3);
																}
															}
															
															boolean listflag = false;
															//boolean zerolistflag = false;
															boolean invaliddataflag = false;
															if(!paramVal.equalsIgnoreCase("")){
																if(paramVal.contains("~~") && aiv.getListType() == 0){
																	listflag = false;
																	apevo.setErrorMessage(" multiple values are not allowed ");
																}else if(paramVal.endsWith("~~")){
																	listflag = false;
																}else{
																	List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																	List<String> paramValList = new ArrayList<String>();
																	List<String> finalparamValList = new ArrayList<String>();
																	List<String> names = new ArrayList<String>();
																	List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
																	for(String data:firstParamValList){
																		if(data.contains("(") && data.contains(")")){
																			//fetching search string from saved result
																			String result = data.substring(data.indexOf("(") + 1, data.indexOf(")"));
																			names.add(data);
																			paramValList.add(result);
																		}else if(data.contains("(") || data.contains(")")){
																			invaliddataflag = true;
																			listflag = false;
																			break;
																		}else{
																			paramValList.add(data);
																		}
																	}
																	boolean duplicateFlag = false;
																	Set<String> duplicate = new HashSet<String>();
																	duplicate.addAll(paramValList);
																	if(duplicate.size()<paramValList.size()){
																		duplicateFlag = true;
																	}
																	if(invaliddataflag == false){
																		if(duplicateFlag == false){
																			LDAPConnection ldapConnection = LDAPConnection.getInstance();
																			DirContext dirContext = ldapConnection.getDirContext();
																			for(String data:ldapmappingfirstattributedata){
																				listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,data);
																				if(listOfLDAPUsers.size() == 1){
																					for(LDAPUser finaldata:listOfLDAPUsers){
																						int count = 0;
																						if(attributeName.equalsIgnoreCase(commonUtils.LdapFirstName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapLastName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getLastName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapEmail)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getEmail())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapDept)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getDept())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapUserId)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getUserId())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapFullName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}
																						//invalid firstname validation,If invalid throw an error as invalid data
																						for(String name:names){
																							if(name.contains("(")){
																								String result = name.substring(name.indexOf("(") + 1, name.indexOf(")"));
																								String fullname = name.substring(0,name.indexOf("("));
																								if(result.equalsIgnoreCase(finaldata.getUserId())){
																									if(!fullname.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																										invaliddataflag = true;
																										break;
																									}
																								}
																							}
																						}
																					}
																					if(invaliddataflag == true){
																						listflag = false;
																						break;
																					}else{
																						//finalParamValList = commonUtils.ldapDataconstruction(finaldata.getUserId(),ai.getAssetName(),ldapParameter,conn);

																						//ldapmappingdata = finalParamValList.keySet().stream().collect(Collectors.toList());

																						listflag = true;
																					}
																				}else{
																					listflag = false;
																					break;
																				}
																			}
																			if(!finalparamValList.isEmpty()){
																				paramVal = String.join("``", finalparamValList);
																			}
																		}
																	}
																}
															}
															if(!aiv.isHasMandatoryValue()){
																if(paramVal.equalsIgnoreCase("")){
																	listflag = true;
																}
															}
															if(listflag == true)
															{     
																flag = true;
																break;
															}
															if(flag == false){
																if(apevo.getParamValue() != paramVal){
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}
														}
													
													}
													else
													{
														Boolean chkFilePrmValFlag = false;
														if(!currentExclRecStat.equalsIgnoreCase("add")){
															for (Map.Entry<String, String> entry2 : paramMapFromDb1.entrySet()) {
																if(paramName.equalsIgnoreCase(entry2.getKey())){
																	if(!paramVal.equalsIgnoreCase(entry2.getValue())){
																		chkFilePrmValFlag = true;
																	}
																}
															}	
														}  

														if((chkFilePrmValFlag && currentExclRecStat.equalsIgnoreCase("none")) || currentExclRecStat.equalsIgnoreCase("add")||(aiv.isHasMandatoryValue()&&paramVal.equalsIgnoreCase(""))){
															if( paramVal != ""  && paramVal != null)
															{
																File folder = new File(System.getProperty("user.home")+"/RepoProUnzip/");
																File[] listOfFiles = folder.listFiles();
																if(listOfFiles != null ){
																	for (int g = 0; g < listOfFiles.length; g++) 
																	{
																		if (listOfFiles[g].isFile()) {
																			if(listOfFiles[g].getName().equalsIgnoreCase(paramVal))
																			{
																				if(paramList.size()-1 == y)
																				{
																					newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																				}
																				else{
																					newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																				}
																				apsVo.setAssetType(ai.getAssetName());
																				apsVo.setAssetInstName(ai.getAssetInstName());
																				apsVo.setVersionName(ai.getVersionName());
																				apsVo.setParentAssetName(ai.getParentAssetName());
																				apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																				apsVo.setParamTypeName(aiv.getTypeName());
																				apsVo.setCatName(aiv.getAssetCategoryName());
																				apsVo.setParamTypeId(aiv.getParamTypeId());
																				apsVo.setParamName(paramName);
																				apsVo.setParamValue(paramVal);
																				apsVo.setAssetParamId(aiv.getAssetParamId());
																				apsVo.setHasStaticValue(aiv.isHasStaticValue());
																				apsVoList.add(apsVo);
																				flag = true;
																			}
																		}
																	}
																	if(flag == false){
																		apevo.setFileExist("Not Found");
																	}
																}
																else
																{
																	apevo.setFileExist("Not Found");
																}

																if(flag == false)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}

															else
															{
																if(!aiv.isHasMandatoryValue()){
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																}
																if(flag == false)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}
														}
													}
												}
											}
											if(paramList.size()-1 == j){
												break;
											}
											if(allCatsAndParamsForAsset.size()-1 > j)
											{
												j++;
											}
											else
											{
												j = 0;
											}
											y++;
										}
									}
								}

								XSSFCell cellii = rowb.getCell(i++);

								String val = null;
								if(cellii == null){
									val = "";
								}
								else{
									if (cellii.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										val = cellii.getStringCellValue();
										if(val.length() == 0)
										{
											val = "";  
										}
									}
									if(cellii.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val1 = (int)cellii.getNumericCellValue(); 
										val = String.valueOf(val1); 
									}
									if(cellii.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										val = cellii.getStringCellValue();
									}
								}
								if( val != "" && val != null)
								{
									String[] addedTaxIds = new String[]{};
									String[] addedTaxIds1 = new String[]{};
									AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();

									aiatVo.setAssetName(ai.getAssetName());
									aiatVo.setAssetInstanceName(ai.getAssetInstName());
									aiatVo.setVersionName(ai.getVersionName());
									List<Long> idsForTaxon = new ArrayList<Long>();
									if(val.endsWith(","))
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide a valid taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
										}
										errorsOnProc.add("Please provide a valid taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
									}
									else
									{
										if(val.length() > 0 )
										{
											if(!allTxs.isEmpty())
											{
												addedTaxIds = val.split(",");
												Boolean flag2 = true;
												for(int t =0; t< addedTaxIds.length && flag2; t++)
												{
													List<TaxonomyMaster> tmpTaxList = tmList;
													addedTaxIds1 = addedTaxIds[t].split("/");

													for(int h =0; h< addedTaxIds1.length; h++)
													{
														Boolean flag = false;
														Long taxNextId = null;
														for(TaxonomyMaster tm:tmpTaxList)
														{
															if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
																flag = true;
																taxNextId = tm.getTaxonomyId();
																break;
															}
														}
														if(!flag)
														{
															if (log.isErrorEnabled()) {
																log.error("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
															}
															errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
															flag2 = false;
															break;
														}
														else
														{
															for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
															{
																if(entry.getKey() ==  taxNextId)
																{ 
																	tmpTaxList = entry.getValue();
																}
															}
														}
														if(h == addedTaxIds1.length-1)
														{
															Boolean fl = false;
															Boolean f2 = false;
															if(associatedTaxId.contains(taxNextId)){

															}
															else{
																f2 = true;
															}
															for(Long Id:idsForTaxon)
															{
																if(Id.equals(taxNextId))
																{
																	fl = true;
																	break;
																}

															}
															if(fl)
															{
																if (log.isErrorEnabled()) {
																	log.error("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
																}
																errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()); 
															}
															if(f2)
															{
																if (log.isErrorEnabled()) {
																	log.error("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset");
																}
																errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset"); 
															}
															else
															{
																idsForTaxon.add(taxNextId);
															}
														}
													}
												}
											}
											else{
												if (log.isErrorEnabled()) {
													log.error("No taxonomy is associated with "+ai.getAssetName()+" asset");
												}
												errorsOnProc.add("No taxonomy is associated with "+ai.getAssetName()+" asset");
											}
										}
										else
										{
											idsForTaxon = Collections.<Long>emptyList();
										}
										aiatVo.setTaxonIds(idsForTaxon);
										assetInstassignList.add(aiatVo);
									}
								}

								XSSFCell celloo = rowb.getCell(i++);

								String valueTag;
								if(celloo == null)
								{
									valueTag = "";
								}
								else
								{
									valueTag = celloo.getStringCellValue();
								}
								if((valueTag != "" && valueTag != null))
								{
									String iChars = "!@#$%^&*()+=[]\\\';./{}|\":<>?~";
									Boolean flagForValidation = false;
									for (int k = 0; k < valueTag.length(); k++) 
									{
										if (iChars.indexOf(valueTag.charAt(k)) != -1) 
										{
											flagForValidation = true;
											break;
										}
									}
									if(flagForValidation)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Character not allowed for tagging in " + ai.getAssetInstName()+" of "+ai.getAssetName());
										}
										errorsOnProc.add("Special Character not allowed for tagging in " + ai.getAssetInstName()+" of "+ai.getAssetName()); 
									}
									else
									{
										if(valueTag.endsWith(","))
										{
											if (log.isErrorEnabled()) {
												log.error("Please provide a valid tag name " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
											}
											errorsOnProc.add("Please provide a valid tag name " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
										}
										else{
											String[] addedTagIds = new String[]{};
											AssetInstAssignTagging aiatVo1 = new AssetInstAssignTagging();
											aiatVo1.setAssetName(ai.getAssetName());
											aiatVo1.setAssetInstanceName(ai.getAssetInstName());
											aiatVo1.setVersionName(ai.getVersionName());
											//AssetInstanceVersion aivtag = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
											//aiatVo1.setAssetInstanceVersionId(aivtag.getAssetInstVersionId().toString());
											List<String> tagNameXls = new ArrayList<String>();

											if(valueTag.length() > 0 )
											{
												addedTagIds = valueTag.split(",");

												for(int t =0; t< addedTagIds.length; t++)
												{
													if(addedTagIds[t].trim().length() > 50)
													{
														if (log.isErrorEnabled()) {
															log.error(" Tag Name exceeds max length for " + cell2+"_"+cell3+" of "+splitAssetName);
														}
														errorsOnProc.add(" Tag Name exceeds max length for " + cell2+"_"+cell3+" of "+splitAssetName);
													}
													Boolean flagForDupTag = false;

													for (int l=0; l<addedTagIds.length; l++){
														for (int m=l+1; m<addedTagIds.length; m++){
															if (addedTagIds[m].trim().equalsIgnoreCase(addedTagIds[l].trim())){
																flagForDupTag = true;
																break;
															}
														}
													}

													if(flagForDupTag){
														if (log.isErrorEnabled()) {
															log.error("Duplicate Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
														}
														errorsOnProc.add("Duplicate Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
														break;
													}
													else
													{
														if(!addedTagIds[t].trim().isEmpty() )
														{
															tagNameXls.add(addedTagIds[t].trim());
														}
														else
														{
															if (log.isErrorEnabled()) {
																log.error("Empty Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
															}
															errorsOnProc.add("Empty Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
															break;
														}
													}
												}
											}
											aiatVo1.setTagsFromXls(tagNameXls);
											assetInstTaggingList.add(aiatVo1);
										}
									}
								}

								if(pvalflag ){
									prhVo.setAssetName(ai.getAssetName());

									prhVo.setAssetInstName(ai.getAssetInstName());

									prhVo.setVersionName(ai.getVersionName());

									prhVo.setParamRevData(newParamDataForRevision);

									azds.add(prhVo);
								}
							}

							int counter = 0;

							if(cell3.equals("NA"))
							{
								cell3 = Constants.DEFAULT_VERSION;
							}

							for(int t=0;t<excelassetInstList.size();t++)
							{
								if(excelassetInstList.get(t).getAssetName().equalsIgnoreCase(splitAssetName)&& excelassetInstList.get(t).getAssetInstName().equalsIgnoreCase(cell2) && excelassetInstList.get(t).getVersionName().equalsIgnoreCase(cell3))
								{
									counter++;
								}
							}
							if(counter>1)
							{
								if (log.isErrorEnabled()) {
									log.error("Duplicate Asset Instance Name/Asset Instance Version Id/Version Name found for "+cell2+"_"+cell3+" at "+splitAssetName +" Attribute Sheet");
								}
								errorsOnProc.add("Duplicate Asset Instance Name/Asset Instance Version Id/Version Name found for "+cell2+"_"+cell3+" at "+splitAssetName +" Attribute Sheet");
								break;
							}
						}
						else
						{
							if((cell1 == "" || cell2 == "" || cell3 == "" || cell4 == ""))
							{
								if (log.isErrorEnabled()) {
									log.error("Empty data not allowed for Asset Instance Version Id/Asset Instance Name/Version Name/Overview columns of "+splitAssetName +" Attribute Sheet");
								}
								errorsOnProc.add("Empty data not allowed for Asset Instance Version Id/Asset Instance Name/Version Name/Overview columns of "+splitAssetName +" Attribute Sheet");
								break;
							}
						}
					}
					listOfassetInstList.put(splitAssetName, assetInstList);
					listOfassetInstList1.put("", assetInstList2);
				}
			}
			log.info("Asset Attribute 2nd level validation done for incremental insert");

			// Loop Starts for Asset Relation validation 2nd level

			List<AssetInstRelationship>  excelassetInstRelList = null ;

			Map<String,List<AssetInstRelationship>> listOfassetInstRelList = new LinkedHashMap<String,List<AssetInstRelationship>>();

			if(errorsOnProc.size() == 0 && apeVoList.isEmpty())
			{
				splitAssetName = null;
				for (int x = 1; x < wb.getNumberOfSheets(); x=x+2) 
				{
					XSSFSheet sheet=wb.getSheetAt(x);

					excelassetInstRelList = new ArrayList<AssetInstRelationship>();

					List<AssetInstRelationship>  assetInstRelList = new ArrayList<AssetInstRelationship>();

					List<AssetInstRelationship>  assetInstRelListtemp = new ArrayList<AssetInstRelationship>();

					XSSFRow row; 

					//Iterator rows = sheet.rowIterator();
					Iterator<Row> rows = sheet.iterator();


					int l =2 ;

					while (rows.hasNext())
					{
						AssetInstance prhVo = new AssetInstance();

						row=(XSSFRow) rows.next();

						int  rowNum = row.getRowNum();

						if(row.getRowNum()== 0)
						{
							XSSFRow rowb = sheet.getRow(rowNum++);

							XSSFCell cellaa = rowb.getCell(0);

							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									splitAssetName = cellaa.getStringCellValue();
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}

							}
							else
							{
								splitAssetName = "";
							}
							continue; 
						}

						if( row.getRowNum()==1)
						{
							continue; 
						}

						rowNum = l;

						String cell1=null, cell2 = null, cell3 = null, cell4 = null, cell5 = null, cell6 = null, cell7 = null, cell8 = null, cell9 = null, cell10 = null,cell11 = null,cell12 = null;

						XSSFRow rowb = sheet.getRow(rowNum++);

						XSSFCell cellaa = rowb.getCell(0);

						XSSFCell cellbb = rowb.getCell(1);

						XSSFCell cellcc = rowb.getCell(2);

						XSSFCell celldd = rowb.getCell(3);

						XSSFCell cellee = rowb.getCell(4);

						XSSFCell cellff = rowb.getCell(5);

						XSSFCell cellgg = rowb.getCell(6);

						XSSFCell cellhh = rowb.getCell(7);

						XSSFCell cellii = rowb.getCell(8);

						XSSFCell celljj = rowb.getCell(9);

						XSSFCell cellkk = rowb.getCell(10);

						XSSFCell cellll = rowb.getCell(11);

						if(cellaa != null)
						{
							if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellaa.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val1 = (int)cellaa.getNumericCellValue(); 
								cell1 = String.valueOf(val1); 
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellaa.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellbb.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellbb.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell2 = "";
						}

						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = cellcc.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellcc.getNumericCellValue(); 
								cell3 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = cellcc.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}


						if(celldd != null)
						{
							if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell4 = celldd.getStringCellValue();
								if(cell4.length() == 0)
								{
									cell4 = "";  
								}
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)celldd.getNumericCellValue(); 
								cell4 = String.valueOf(val); 
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell4 = celldd.getStringCellValue();
							}
						}
						else
						{
							cell4 = "";
						}

						if(cellee != null)
						{
							if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell5 = cellee.getStringCellValue();
								if(cell5.length() == 0)
								{
									cell5 = "";  
								}
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellee.getNumericCellValue(); 
								cell5 = String.valueOf(val); 
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell5 = cellee.getStringCellValue();
							}
						}
						else
						{
							cell5 = "";
						}

						if(cellff != null)
						{
							if (cellff.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell6 = cellff.getStringCellValue();
								if(cell6.length() == 0)
								{
									cell6 = "";  
								}
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellff.getNumericCellValue(); 
								cell6 = String.valueOf(val); 
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell6 = cellff.getStringCellValue();
							}
						}
						else
						{
							cell6 = "";
						}

						if(cellgg != null)
						{
							if (cellgg.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell7 = cellgg.getStringCellValue();
								if(cell7.length() == 0)
								{
									cell7 = "";  
								}
							}
							if(cellgg.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellgg.getNumericCellValue(); 
								cell7 = String.valueOf(val); 
							}
							if(cellgg.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell7 = cellgg.getStringCellValue();
							}
						}
						else
						{
							cell7 = "";
						}

						if(cellhh != null)
						{
							if (cellhh.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell8 = cellhh.getStringCellValue();
								if(cell8.length() == 0)
								{
									cell8 = "";  
								}
							}
							if(cellhh.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellhh.getNumericCellValue(); 
								cell8 = String.valueOf(val); 
							}
							if(cellhh.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell8 = cellhh.getStringCellValue();
							}
						}
						else
						{
							cell8 = "";
						}

						if(cellii != null)
						{
							if (cellii.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell9 = cellii.getStringCellValue();
								if(cell9.length() == 0)
								{
									cell9 = "";  
								}
							}
							if(cellii.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellii.getNumericCellValue(); 
								cell9 = String.valueOf(val); 
							}
							if(cellii.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell9 = cellii.getStringCellValue();
							}
						}
						else
						{
							cell9 = "";
						}

						if(celljj != null)
						{
							if (celljj.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell10 = celljj.getStringCellValue();
								if(cell10.length() == 0)
								{
									cell10 = "";  
								}
							}
							if(celljj.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)celljj.getNumericCellValue(); 
								cell10 = String.valueOf(val); 
							}
							if(celljj.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell10 = celljj.getStringCellValue();
							}
						}
						else
						{
							cell10 = "";
						}

						if(cellkk != null)
						{
							if (cellkk.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell11 = cellkk.getStringCellValue();
								if(cell11.length() == 0)
								{
									cell11 = "";  
								}
							}
							if(cellkk.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellkk.getNumericCellValue(); 
								cell11 = String.valueOf(val);
							}
							if(cellkk.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell11 = cellkk.getStringCellValue();
							}
						}
						else
						{
							cell11 = "";
						}

						if(cellll != null)
						{
							if (cellll.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell12 = cellll.getStringCellValue();
								if(cell12.length() == 0)
								{
									cell12 = "";  
								}
							}
							if(cellll.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellll.getNumericCellValue(); 
								cell12 = String.valueOf(val); 
							}
							if(cellll.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell12 = cellll.getStringCellValue();
							}
						}
						else
						{
							cell12 = "";
						}

						AssetInstRelationship avVo = new AssetInstRelationship();

						avVo.setSrcAssetName(cell1);
						avVo.setSourceInstanceName(cell3);
						avVo.setSourceVersionName(cell4);
						avVo.setDestAssetName(cell8);
						avVo.setDestInstanceName(cell10);
						avVo.setDestInstanceVersionName(cell11);
						avVo.setDescrption(cell7);
						avVo.setRelationShipName(cell6);
						excelassetInstRelList.add(avVo);
						l++;
					}

					rows = sheet.rowIterator();

					int q = 2;

					while (rows.hasNext())
					{
						AssetInstance prhVo = new AssetInstance();

						row = (XSSFRow) rows.next();

						int  rowNum = row.getRowNum();

						if(row.getRowNum() == 0)
						{
							XSSFRow rowb = sheet.getRow(rowNum++);

							XSSFCell cellaa = rowb.getCell(0);

							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									splitAssetName = cellaa.getStringCellValue();
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}
							}
							else
							{
								splitAssetName = "";
							}
							AssetInstanceVersion srcAiv = new AssetInstanceVersion();
							AssetInstanceVersion destAiv = new AssetInstanceVersion();
							List<AssetInstRelationship> depAIs =  assetInstanceVersionDao.getNumOfDependentsForAssetInstByAssetType(splitAssetName, conn);

							for(AssetInstRelationship air:depAIs)
							{
								AssetInstRelationship airVo = new AssetInstRelationship();

								srcAiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(air.getSrcAssetInstVersionId(), conn);

								destAiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(air.getDestAssetInstVersionId(), conn);

								airVo.setSrcAssetName(srcAiv.getAssetName());
								airVo.setSrcAssetInstVersionId(srcAiv.getAssetInstVersionId());
								airVo.setSourceInstanceName(srcAiv.getAssetInstName());
								airVo.setSourceVersionName(srcAiv.getVersionName());
								airVo.setDestAssetName(destAiv.getAssetName());
								airVo.setDestInstanceName(destAiv.getAssetInstName());
								airVo.setDestAssetInstVersionId(destAiv.getAssetInstVersionId());
								airVo.setDestInstanceVersionName(destAiv.getVersionName());
								airVo.setDescrption(air.getDescrption());
								airVo.setRelationShipName(air.getRelationShipName());
								airVo.setAssetRelId(air.getAssetRelId());
								assetInstRelList.add(airVo);
								assetInstRelListtemp.add(airVo);
							}
							continue; 
						}

						if( row.getRowNum()==1)
						{
							continue; 
						}

						rowNum = q;

						String cell1=null, cell2 = null, cell3 = null, cell4 = null, cell5 = null, cell6 = null, cell7 = null, cell8 = null, cell9 = null, cell10 = null,cell11 = null,cell12 = null;

						XSSFRow rowb = sheet.getRow(rowNum++);

						XSSFCell cellaa = rowb.getCell(0);

						XSSFCell cellbb = rowb.getCell(1);

						XSSFCell cellcc = rowb.getCell(2);

						XSSFCell celldd = rowb.getCell(3);

						XSSFCell cellee = rowb.getCell(4);

						XSSFCell cellff = rowb.getCell(5);

						XSSFCell cellgg = rowb.getCell(6);

						XSSFCell cellhh = rowb.getCell(7);

						XSSFCell cellii = rowb.getCell(8);

						XSSFCell celljj = rowb.getCell(9);

						XSSFCell cellkk = rowb.getCell(10);

						XSSFCell cellll = rowb.getCell(11);

						if(cellaa != null)
						{
							if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellaa.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val1 = (int)cellaa.getNumericCellValue(); 
								cell1 = String.valueOf(val1); 
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellaa.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellbb.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellbb.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell2 = "";
						}

						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = cellcc.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellcc.getNumericCellValue(); 
								cell3 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = cellcc.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}


						if(celldd != null)
						{
							if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell4 = celldd.getStringCellValue();
								if(cell4.length() == 0)
								{
									cell4 = "";  
								}
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)celldd.getNumericCellValue(); 
								cell4 = String.valueOf(val); 
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell4 = celldd.getStringCellValue();
							}
						}
						else
						{
							cell4 = "";
						}

						if(cellee != null)
						{
							if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell5 = cellee.getStringCellValue();
								if(cell5.length() == 0)
								{
									cell5 = "";  
								}
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellee.getNumericCellValue(); 
								cell5 = String.valueOf(val); 
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell5 = cellee.getStringCellValue();
							}
						}
						else
						{
							cell5 = "";
						}

						if(cellff != null)
						{
							if (cellff.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell6 = cellff.getStringCellValue();
								if(cell6.length() == 0)
								{
									cell6 = "";  
								}
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellff.getNumericCellValue(); 
								cell6 = String.valueOf(val); 
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell6 = cellff.getStringCellValue();
							}
						}
						else
						{
							cell6 = "";
						}

						if(cellgg != null)
						{
							if (cellgg.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell7 = cellgg.getStringCellValue();
								if(cell7.length() == 0)
								{
									cell7 = "";  
								}
							}
							if(cellgg.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellgg.getNumericCellValue(); 
								cell7 = String.valueOf(val); 
							}
							if(cellgg.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell7 = cellgg.getStringCellValue();
							}
						}
						else
						{
							cell7 = "";
						}

						if(cellhh != null)
						{
							if (cellhh.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell8 = cellhh.getStringCellValue();
								if(cell8.length() == 0)
								{
									cell8 = "";  
								}
							}
							if(cellhh.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellhh.getNumericCellValue(); 
								cell8 = String.valueOf(val); 
							}
							if(cellhh.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell8 = cellhh.getStringCellValue();
							}
						}
						else
						{
							cell8 = "";
						}

						if(cellii != null)
						{
							if (cellii.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell9 = cellii.getStringCellValue();
								if(cell9.length() == 0)
								{
									cell9 = "";  
								}
							}
							if(cellii.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellii.getNumericCellValue(); 
								cell9 = String.valueOf(val); 
							}
							if(cellii.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell9 = cellii.getStringCellValue();
							}
						}
						else
						{
							cell9 = "";
						}


						if(celljj != null)
						{
							if (celljj.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell10 = celljj.getStringCellValue();
								if(cell10.length() == 0)
								{
									cell10 = "";  
								}
							}
							if(celljj.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)celljj.getNumericCellValue(); 
								cell10 = String.valueOf(val); 
							}
							if(celljj.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell10 = celljj.getStringCellValue();
							}
						}
						else
						{
							cell10 = "";
						}

						if(cellkk != null)
						{
							if (cellkk.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell11 = cellkk.getStringCellValue();
								if(cell11.length() == 0)
								{
									cell11 = "";  
								}
							}
							if(cellkk.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellkk.getNumericCellValue(); 
								cell11 = String.valueOf(val);
							}
							if(cellkk.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell11 = cellkk.getStringCellValue();
							}
						}
						else
						{
							cell11 = "";
						}

						if(cellll != null)
						{
							if (cellll.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell12 = cellll.getStringCellValue();
								if(cell12.length() == 0)
								{
									cell12 = "";  
								}
							}
							if(cellll.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellll.getNumericCellValue(); 
								cell12 = String.valueOf(val); 
							}
							if(cellll.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell12 = cellll.getStringCellValue();
							}
						}
						else
						{
							cell12 = "";
						}

						if(cell1!="" && cell2!="" && cell3!="" && cell4!="" && cell7!="" && cell8!="" && cell9!="" && cell10!="" && cell6!="")
						{
							cell1  = cell1.trim();
							cell2  = cell2.trim();
							cell3  = cell3.trim();
							cell7  = cell7.trim();
							cell8  = cell8.trim();
							cell9  = cell9.trim();
							cell5  = cell5.trim();
							cell6  = cell6.trim();
							cell4  = cell4.trim();
							cell10  = cell10.trim();

							if(cell1.length() > 50)
							{
								if (log.isErrorEnabled()) {
									log.error(" Source Asset Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
								}
								errorsOnProc.add(" Source Asset Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
							}

							if(cell3.length() > 100)
							{
								if (log.isErrorEnabled()) {
									log.error(" Source Asset Instance Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
								}
								errorsOnProc.add(" Source Asset Instance Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
							}

							if(cell4.length() > 10)
							{
								if (log.isErrorEnabled()) {
									log.error(" Source Asset Instance Version Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
								}
								errorsOnProc.add(" Source Asset Instance Version Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
							}

							if(cell8.length() > 50)
							{
								if (log.isErrorEnabled()) {
									log.error(" Target Asset Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
								}
								errorsOnProc.add(" Target Asset Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
							}

							if(cell10.length() > 100)
							{
								if (log.isErrorEnabled()) {
									log.error(" Target Asset Instance Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
								}
								errorsOnProc.add(" Target Asset Instance Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
							}

							if(cell11.length() > 10)
							{
								if (log.isErrorEnabled()) {
									log.error(" Target Asset Instance Version Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
								}
								errorsOnProc.add(" Target Asset Instance Version Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
							}

							if(cell2.length() > 20)
							{
								if (log.isErrorEnabled()) {
									log.error(" Source Asset Instance Version Id exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
								}
								errorsOnProc.add(" Source Asset Instance Version Id exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
							}

							if(cell9.length() > 20)
							{
								if (log.isErrorEnabled()) {
									log.error(" Target Asset Instance Version Id exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
								}
								errorsOnProc.add(" Target Asset Instance Version Id exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
							}

							String iChars1 = "!@#$%^&*()+=[]\\\';./{}|\":<>?~";

							Boolean flagForValidation1 = false;

							for (int k = 0; k < cell1.length(); k++) 
							{
								if (iChars1.indexOf(cell1.charAt(k)) != -1) 
								{
									flagForValidation1 = true;
									break;
								}
							}

							String iChars3 = "!%^*=[];{}|<>?~";

							Boolean flagForValidation3 = false;

							for (int k = 0; k < cell3.length(); k++) 
							{
								if (iChars3.indexOf(cell3.charAt(k)) != -1) 
								{
									flagForValidation3 = true;
									break;
								}
							}

							Boolean flagForValidation2 = false;

							String iChars2 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWXYZ]";
							for (int i = 0; i < cell4.length(); i++) 
							{
								if (iChars2.indexOf(cell4.trim().charAt(i)) != -1) 
								{
									flagForValidation2= true;
									break;
								}
							}

							String iChars4 = "!@#$%^&*()+=[]\\\';./{}|\":<>?~";
							Boolean flagForValidation4 = false;

							for (int k = 0; k < cell8.length(); k++) 
							{
								if (iChars4.indexOf(cell8.charAt(k)) != -1) 
								{
									flagForValidation4 = true;
									break;
								}
							}

							String iChars5 = "!%^*=[];{}|<>?~";

							Boolean flagForValidation5 = false;

							for (int k = 0; k < cell10.length(); k++) 
							{
								if (iChars5.indexOf(cell10.charAt(k)) != -1) 
								{
									flagForValidation5 = true;
									break;
								}
							}

							Boolean flagForValidation6 = false;

							String iChars6 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWXYZ]";
							for (int i = 0; i < cell11.length(); i++) 
							{
								if (iChars6.indexOf(cell11.trim().charAt(i)) != -1) 
								{
									flagForValidation6= true;
									break;
								}
							}

							Boolean flagForValidation7 = false;
							String iChars7 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWYZ]";
							for (int i = 0; i < cell2.length(); i++) 
							{
								if (iChars7.indexOf(cell2.trim().charAt(i)) != -1) 
								{
									flagForValidation7= true;
									break;
								}
							}
							Boolean flagForValidation8 = false;
							String iChars8 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWYZ]";
							for (int i = 0; i < cell9.length(); i++) 
							{
								if (iChars8.indexOf(cell9.trim().charAt(i)) != -1) 
								{
									flagForValidation8= true;
									break;
								}
							}

							if(flagForValidation1)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in source asset type column " + cell1+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Character not allowed in source asset type column " + cell1+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation2)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed in  source asset instance version column " + cell4+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed in  source asset instance version column " + cell4+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation3)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in source asset instance name column " + cell3+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Character not allowed in source asset instance name column " + cell3+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation4)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in target asset type column " + cell8+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Character not allowed in target asset type column " + cell8+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation6)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed in  target asset instance version column " + cell11+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed in  target asset instance version column " + cell11+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation5)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in target asset instance name column " + cell10+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Character not allowed in target asset instance name column " + cell10+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation7)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed except XXXX in  Source Asset Instance Version Id column " + cell2+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed except XXXX in  Source Asset Instance Version Id column " + cell2+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation8)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed except XXXX in  Target Asset Instance Version Id column " + cell9+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed except XXXX in  Target Asset Instance Version Id column " + cell9+" at "+splitAssetName+" Relationship sheet");
							}

							AssetInstRelationship avVo = new AssetInstRelationship();

							Boolean flag12 = false;
							for(AssetInstRelationship aivo:assetInstRelList)
							{
								if(aivo.getSrcAssetInstVersionId().toString().equals(cell2)&& aivo.getDestAssetInstVersionId().toString().equals(cell9) && aivo.getSrcAssetName().equalsIgnoreCase(cell1) && aivo.getSourceInstanceName().equalsIgnoreCase(cell3) && aivo.getSourceVersionName().equalsIgnoreCase(cell4)&&  aivo.getDestAssetName().equalsIgnoreCase(cell8) && aivo.getDestInstanceName().equalsIgnoreCase(cell10) && aivo.getDestInstanceVersionName().equalsIgnoreCase(cell11)&& cell7.equalsIgnoreCase(aivo.getDescrption()) && cell6.equalsIgnoreCase(aivo.getRelationShipName()) )
								{
									aivo.setAction("update");
									flag12 = true;
									break;
								}
							}
							String hhh = "";
							if(!flag12)
							{   

								avVo.setSrcAssetName(cell1);
								avVo.setSourceInstanceName(cell3);
								avVo.setSourceVersionName(cell4);
								if(cell2.equals("XXXX")){
									avVo.setSrcAssetInstVersionId(Long.valueOf("0000"));
								}else{
									avVo.setSrcAssetInstVersionId(Long.valueOf(cell2));
								}
								avVo.setDestAssetName(cell8);
								avVo.setDestInstanceName(cell10);
								avVo.setDestInstanceVersionName(cell11);
								if(cell9.equals("XXXX")){
									avVo.setDestAssetInstVersionId(Long.valueOf("0000"));
								}else{
									avVo.setDestAssetInstVersionId(Long.valueOf(cell9));
								}
								avVo.setDescrption(cell7);
								avVo.setRelationShipName(cell6);
								avVo.setAction("add");
								hhh = "add";
								assetInstRelList.add(avVo);

							}

							if(hhh.equals("add")|| hhh.equals(""))
							{
								Boolean flagCheck = false;

								for (Entry<String, List<AssetInstanceVersion>> entry : listOfexcelassetInstList.entrySet())
								{
									if(splitAssetName.equalsIgnoreCase(entry.getKey()))
									{
										for(AssetInstanceVersion aiv:entry.getValue())
										{
											if(("XXXX").equals(cell2)&& aiv.getAssetInstName().equalsIgnoreCase(cell3) && aiv.getVersionName().equalsIgnoreCase(cell4))
											{
												flagCheck = true;
												break;
											}
										}
									}
								}
								if(!flagCheck)
								{
									if (log.isErrorEnabled()) {
										log.error("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+ " Relationship sheet");
									}
									errorsOnProc.add("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+ " Relationship sheet");
								}
								else
								{ 
									Boolean flagCh = false;
									for(AssetRelationshipDef relNm :relNameList)
									{
										if(cell8.equalsIgnoreCase(relNm.getDestAssetName()) && cell1.equalsIgnoreCase(relNm.getSrcAssetName()) && cell7.equals(relNm.getDescription()) && cell6.equals(relNm.getFwdRelationType()))
										{
											flagCh = true;
											break;
										}
									}
									if(!flagCh)
									{
										if (log.isErrorEnabled()) {
											log.error("Error in Relation Details : Please check " + cell8+","+cell7+","+cell6+" of "+cell1+" Relationship sheet");
										}
										errorsOnProc.add("Error in Relation Details : Please check " + cell8+","+cell7+","+cell6+" of "+cell1+" Relationship sheet");
									}
									else
									{
										Boolean flagChec1 = false;
										for (Entry<String, List<AssetInstanceVersion>> entry : listOfexcelassetInstList.entrySet())
										{
											if(cell1.equalsIgnoreCase(entry.getKey()))
											{
												for(AssetInstanceVersion aiv:entry.getValue())
												{
													if((("XXXX").equals(cell2)&& aiv.getAssetInstName().equalsIgnoreCase(cell3) && aiv.getVersionName().equalsIgnoreCase(cell4)))
													{
														flagChec1 = true;
														break;
													}
												}
											}
										}
										Boolean flagChec = false;
										Boolean flagCond = false;
										if(flagChec1){
											if(cell6.equals("association") || cell6.equals("classification"))
											{
												if(cell3.equalsIgnoreCase(cell10)&& cell1.equalsIgnoreCase(cell8))
												{
													if (log.isErrorEnabled()) {
														log.error("Error in Relationship Details: Source and Destination cannot be same Asset Instance " + cell10+"_"+cell11+" of "+cell8);
													}
													errorsOnProc.add("Error in Relationship Details: Source and Destination cannot be same Asset Instance " + cell10+"_"+cell11+" of "+cell8);
													flagChec = true;
												}
												else
												{
													for (Entry<String, List<List<AssetInstanceVersion>>> entry : listOfassetInstList1.entrySet())
													{
														for(List<AssetInstanceVersion> aiv:entry.getValue())
														{
															for(AssetInstanceVersion aiv2:aiv ){
																if(cell8.equalsIgnoreCase(aiv2.getAssetName()))
																{
																	if(aiv2.getAssetInstVersionId() != null){
																		if(aiv2.getAssetInstVersionId().toString().equals(cell9)&& aiv2.getAssetInstName().equalsIgnoreCase(cell10) && aiv2.getVersionName().equalsIgnoreCase(cell11))
																		{
																			flagChec = true;
																			break;
																		}
																	}
																}
															}
														}
													} 
												}
											}		    								
											else
											{
												if(cell11.equals("1.0"))
												{
													flagChec = true;

													if(cell6.equals("composition") || cell6.equals("aggregation"))
													{
														if (log.isErrorEnabled()) {
															log.error("Error in Relation Details: Composition and Aggregation relation not allowed for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
														}
														errorsOnProc.add("Error in Relation Details: Composition and Aggregation relation not allowed for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
													}
													else
													{
														for (Entry<String, List<List<AssetInstanceVersion>>> entry : listOfassetInstList1.entrySet())
														{
															for(List<AssetInstanceVersion> aiv:entry.getValue())
															{
																for(AssetInstanceVersion aiv2:aiv ){
																	{
																		if(cell8.equalsIgnoreCase(aiv2.getAssetName()))
																		{

																			if((aiv2.getAssetInstVersionId().toString().equals(cell9)&& aiv2.getAssetInstName().equalsIgnoreCase(cell10) && aiv2.getVersionName().equalsIgnoreCase(cell11)) )
																			{
																				flagCond = true;
																				break;
																			}
																		}
																	}
																}
															}
														} 
													}
												}
												else
												{
													if (log.isErrorEnabled()) {
														log.error("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
													}
													errorsOnProc.add("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
													break;
												}
											}
										}
										if(!flagChec || flagCond)
										{
											if (log.isErrorEnabled()) {
												log.error("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
											}
											errorsOnProc.add("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
										}

										if(!flagChec1)
										{
											if (log.isErrorEnabled()) {
												log.error("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
											}
											errorsOnProc.add("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
										}
									}
								}
							}
							int counter = 0;

							for(int t=0;t<excelassetInstRelList.size();t++)
							{
								if(excelassetInstRelList.get(t).getSrcAssetName().equalsIgnoreCase(cell1) && excelassetInstRelList.get(t).getSourceInstanceName().equalsIgnoreCase(cell3) && excelassetInstRelList.get(t).getSourceVersionName().equalsIgnoreCase(cell4)&& excelassetInstRelList.get(t).getDestAssetName().equalsIgnoreCase(cell8)&& excelassetInstRelList.get(t).getDestInstanceName().equalsIgnoreCase(cell10) && excelassetInstRelList.get(t).getDestInstanceVersionName().equalsIgnoreCase(cell11)&& excelassetInstRelList.get(t).getDescrption().equals(cell7)&& excelassetInstRelList.get(t).getRelationShipName().equals(cell6))
								{
									counter++;
								}
							}
							if(counter>1)
							{
								if (log.isErrorEnabled()) {
									log.error("Duplicate Relation found for "+cell3+"_"+cell4+" at "+splitAssetName +" Relationship Sheet");
								}
								errorsOnProc.add("Duplicate Relation found for "+cell3+"_"+cell4+" at "+splitAssetName +" Relationship Sheet");
							}
						}
						else
						{
							if(cell1 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Source Asset Type column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Source Asset Type column at "+splitAssetName+" Relationship sheet");
							}
							if(cell3 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Source Asset Instance Name column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Source Asset Instance Name column at "+splitAssetName+" Relationship sheet");
							}
							if(cell4 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Source Asset Instance Version column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Source Asset Instance Version column at "+splitAssetName+" Relationship sheet");
							}
							if(cell6 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Relation Type column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Relation Type column at "+splitAssetName+" Relationship sheet");
							}
							if(cell7 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Relation Name column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Relation Name column at "+splitAssetName+" Relationship sheet");
							}
							if(cell7 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Target Asset Type column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Target Asset Type column at "+splitAssetName+" Relationship sheet");
							}
							if(cell10 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Target Asset Instance Name column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Target Asset Instance Name column at "+splitAssetName+" Relationship sheet");
							}
							if(cell11 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Target Asset Instance version column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Target Asset Instance version column at "+splitAssetName+" Relationship sheet");
							}

							if(cell2 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Source Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Source Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
							}

							if(cell9 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Target Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Target Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
							}
						}
						q++;
					}

					for(AssetInstRelationship aivo:assetInstRelListtemp)
					{
						if(aivo.getRelationShipName().equals("composition") || aivo.getRelationShipName().equals("aggregation"))
						{
							Boolean flagForNotRemove = false;

							for(AssetInstRelationship aiv:excelassetInstRelList)
							{
								if( aivo.getSrcAssetName().equalsIgnoreCase(aiv.getSrcAssetName()) && aivo.getSourceInstanceName().equalsIgnoreCase(aiv.getSourceInstanceName()) && aivo.getSourceVersionName().equalsIgnoreCase(aiv.getSourceVersionName())&&  aivo.getDestAssetName().equalsIgnoreCase(aiv.getDestAssetName()) && aivo.getDestInstanceName().equalsIgnoreCase(aiv.getDestInstanceName()) && aivo.getDestInstanceVersionName().equalsIgnoreCase(aiv.getDestInstanceVersionName()) && aivo.getDescrption().equals(aiv.getDescrption())&& aiv.getRelationShipName().equals(aivo.getRelationShipName()))
								{
									flagForNotRemove = true;
									break;
								}
							}
							if(!flagForNotRemove)
							{   
								aivo.setAction("skip");

							}
						}
						else
						{
							Boolean flagForNotRemove = false;

							for(AssetInstRelationship aiv:excelassetInstRelList)
							{ 
								if( aivo.getSrcAssetName().equalsIgnoreCase(aiv.getSrcAssetName()) && aivo.getSourceInstanceName().equalsIgnoreCase(aiv.getSourceInstanceName()) && aivo.getSourceVersionName().equalsIgnoreCase(aiv.getSourceVersionName())&&  aivo.getDestAssetName().equalsIgnoreCase(aiv.getDestAssetName()) && aivo.getDestInstanceName().equalsIgnoreCase(aiv.getDestInstanceName()) && aivo.getDestInstanceVersionName().equalsIgnoreCase(aiv.getDestInstanceVersionName()) && aivo.getDescrption().equals(aiv.getDescrption())&& aiv.getRelationShipName().equals(aivo.getRelationShipName()))
								{
									flagForNotRemove = true;
									break;
								}
							}
							if(!flagForNotRemove)
							{   
								aivo.setAction("delete");
							}
						}
					}
					listOfassetInstRelList.put(splitAssetName, assetInstRelList);
				}
			}
			log.info("Asset Relation validation 2nd level validation done for incremental insert");
			// Loop Ends for Asset Relation validation 2nd level

			// Loop Starts for Asset Attribute DB Updation 3rd level
			List<String> instIds = new ArrayList<String>();
			AssetInstanceManager assetInstanceManager = new AssetInstanceManager();
			List<AivRevisionHistory> aivRevHistList = new ArrayList<AivRevisionHistory>();
			List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
			Map<String,Map<String,String>> taxIds = new LinkedHashMap<String,Map<String,String>>();

			Object parameterChangeNotification = null;
        	Object relatedParamChangeNotification = null;
			List<Object> parameterChangefinaldata = new ArrayList<Object>();
			List<Object> relatedParamChangefinaldata = new ArrayList<Object>();
			
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty())
			{
				for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
				{
					for(AssetInstanceVersion aiv:entry.getValue())
					{
						AssetInstance ai = new AssetInstance();
						ai.setAssetName(entry.getKey());
						ai.setAssetInstName(aiv.getAssetInstName());
						AssetDef assetData = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
						ai.setAssetId(assetData.getAssetId());
						ai.setVersionName(aiv.getVersionName());
						ai.setOwner(profile.getUserName());
						ai.setDescription(aiv.getDescription());
						if(globalsetting.getGlobalSettingFlag() == 1){
							String description = commonUtils.httpSanitizerForCkEditor(aiv.getDescription());
							ai.setDescription(description);
						}
						
						if(aiv.getAction().equals("add"))
						{
							Response response = assetInstanceManager.addAssetInstanceHelper(ai,userName,false,true,false,conn);
							MyModel res = (MyModel) response.getEntity();
							List<Object> data = res.getResult();
							for (int i = 0; i < data.size(); i++) {
								AssetInstance aiResponse = new AssetInstance();
								aiResponse = (AssetInstance) data.get(i);
								ai.setAssetInstId(aiResponse.getAssetInstId());
								ai.setAssetInstVersionId(aiResponse.getAssetInstVersionId());
							}
							Long firstState = null;
							Workflow workflow = workflowDao.retWorkflowByAivId(ai.getAssetInstVersionId(), conn);
							if(workflow != null) {
								String jsonStructure = workflow.getJsonStructure();
								JSONObject jsonObject = new JSONObject(jsonStructure);
								
								for(int i=0;i<jsonObject.length();i++) {
									Iterator itr = jsonObject.keys();
									if(itr.hasNext()){
										firstState = Long.parseLong(itr.next().toString());
									}
								}
								assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
							}
							instIds.add(ai.getAssetInstVersionId().toString());
							AssetInstanceVersion aivForAddingNewRevision = assetInstanceVersionDao
									.getAssetInstanceVersion(ai.getAssetInstId(),ai.getVersionName(), conn);
							if(aivForAddingNewRevision != null){
								AivRevisionHistory aivRevHist = new AivRevisionHistory();
								aivRevHist.setAivId(ai.getAssetInstVersionId());
								aivRevHist.setNewInstanceKey("N");
								aivRevHist.setOverviewData(ai.getDescription());
								aivRevHist.setRevId(ai.getVersionName()+".0");
								aivRevHistList.add(aivRevHist);
							}
							RecentActivity recentActivity = new RecentActivity();
							recentActivity.setAssetName(ai.getAssetName());
							recentActivity.setAssetInstName(ai.getAssetInstName());
							recentActivity.setAssetInstanceVersionName(ai.getVersionName());
							recentActivity.setAssetInstVersionId(ai.getAssetInstVersionId().toString());
							recentActivityList.add(recentActivity);
						}
						if(aiv.getAction().equals("update"))
						{

						}
					}
				}
				for(int i=0;i<aisdVoList.size();i++)
				{
					AssetInstance ai = new AssetInstance();
					ai.setAssetName(aisdVoList.get(i).getAssetType());
					ai.setAssetInstName(aisdVoList.get(i).getAssetInstName());
					ai.setVersionName(aisdVoList.get(i).getVersionName());
					ai.setParentAssetName(aisdVoList.get(i).getParentAssetName());
					ai.setParentAssetInstName(aisdVoList.get(i).getParentAssetInstanceName());
					AssetInstanceVersion aiv;
					aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
				}

				if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
					
					AssetInstanceVersion assetInstver = null;
					for(int i=0;i<apsVoList.size();i++)
					{
						List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();
						NameValue nv = new NameValue();
						nv.setName(apsVoList.get(i).getParamName());

						AssetInstance ai = new AssetInstance();
						ai.setAssetName(apsVoList.get(i).getAssetType());
						ai.setAssetInstName(apsVoList.get(i).getAssetInstName());
						ai.setVersionName(apsVoList.get(i).getVersionName());

						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
						ai.setAssetId(asset.getAssetId());
						ai.setParentAssetName(apsVoList.get(i).getParentAssetName());
						ai.setParentAssetInstName(apsVoList.get(i).getParentAssetInstanceName());

						nv.setName(apsVoList.get(i).getParamName());
						AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
						ai.setAssetInstVersionId(aiv.getAssetInstVersionId());
						if(!apsVoList.get(i).getParamTypeId().equals(3L))
						{
							assetInstver = new AssetInstanceVersion();
							assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
							if(apsVoList.get(i).getParamTypeId().equals(7L)){
								if(apsVoList.get(i).isHasStaticValue()){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else if(apsVoList.get(i).getHasArray()==0){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
									assetInstver.setRTFPlainText(apsVoList.get(i).getRTFPlainText());
								}else{
									assetInstver.setRTFwithOutTags(apsVoList.get(i).getRTFwithOutTags());
									assetInstver.setRTFwithTags(apsVoList.get(i).getRTFwithTags());
								}
							}else if(apsVoList.get(i).getParamTypeId().equals(1L)){
								if(apsVoList.get(i).isHasStaticValue()){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else if(apsVoList.get(i).getHasArray()==0){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else{
									assetInstver.setTextDataList(apsVoList.get(i).getTextDataList());
								}
							}else if(apsVoList.get(i).getParamTypeId().equals(9L)){
								assetInstver.setLdapMappingValue(apsVoList.get(i).getLdapMappingValue());
							}else{
								assetInstver.setParamValue(apsVoList.get(i).getParamValue());
							}

							assetInstver.setParamTypeId(apsVoList.get(i).getParamTypeId());
							if(apsVoList.get(i).isHasStaticValue() == false){
								assetInstver.setIsStatic(0);
							}else{
								assetInstver.setIsStatic(1);
							}
							apsVoList.get(i).isHasStaticValue();
							assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
							assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
							assetInstver.setAssetName(ai.getAssetName());
							assetInstver.setAssetInstName(apsVoList.get(i).getAssetInstName());
							assetInstver.setHasArray(apsVoList.get(i).getHasArray());
							assetInstver.setConn(conn);
							assetInstver.setLog(log);
							assetInstver.setUserId(1L);
							ListOfAssetInstanceProperties.add(assetInstver);

							if(CommonUtils.customParameterPluginNoficationClassName != null && CommonUtils.customParameterPluginPath != null){

								if(!CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") && !CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

									Class notificationInterface = CustomParameterPluginUtilies.getplugin();

									if(notificationInterface != null){
										Method method = null;
										Method relatedParamChangeMethod = null;
										try {
											method = notificationInterface.getMethod("notifyOnParameterValueChanges",new Class[]{List.class});
											relatedParamChangeMethod = notificationInterface.getMethod("notifyOnParameterValueChangesBasedOnOtherParameter",new Class[]{List.class});

										} catch (NoSuchMethodException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (SecurityException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}

										Object instance = null;
										try {
											instance = notificationInterface.newInstance();
										} catch (InstantiationException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (IllegalAccessException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}	


										try{
											parameterChangeNotification = method.invoke(instance,ListOfAssetInstanceProperties);
											if(parameterChangeNotification != null){
												JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

												if(jsonObject.has("Response Status")){
													String status = jsonObject.getString("Response Status");
													if(status.equalsIgnoreCase("failure")){
														if (log.isErrorEnabled()) {
															log.error(jsonObject.getString("Response Message"));
														}
														errorsOnProc.add(jsonObject.getString("Response Message"));
													}else{
														parameterChangefinaldata.add(jsonObject);
													}
												}
											}

											relatedParamChangeNotification = relatedParamChangeMethod.invoke(instance,ListOfAssetInstanceProperties);
											if(relatedParamChangeNotification != null){
												JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

												if(jsonObject.has("Response Status")){
													String status = jsonObject.getString("Response Status");
													if(status.equalsIgnoreCase("failure")){
														if (log.isErrorEnabled()) {
															log.error(jsonObject.getString("Response Message"));
														}
														errorsOnProc.add(jsonObject.getString("Response Message"));
													}else{
														relatedParamChangefinaldata.add(jsonObject);
													}
												}
											}
										}
										catch (IllegalAccessException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (IllegalArgumentException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (InvocationTargetException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}catch(Exception e){
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}
									}else{
										if (log.isErrorEnabled()) {
											log.error("Invalid Plugin configuration");
										}
										errorsOnProc.add("Invalid Plugin configuration");

									}
								}

								if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")|| CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){
									if (log.isErrorEnabled()) {
										log.error("Invalid Plugin configuration");
									}
									errorsOnProc.add("Invalid Plugin configuration");
								}
							}
							if(CommonUtils.customParameterPluginNoficationClassName != null ){
			        			if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")){
			        				if (log.isErrorEnabled()) {
										log.error("Invalid Plugin configuration");
									}
			        				errorsOnProc.add("Invalid Plugin configuration");
			        			}
			        		}else if(CommonUtils.customParameterPluginPath != null){
			        			if(CommonUtils.customParameterPluginPath .equalsIgnoreCase("")){
			        				if (log.isErrorEnabled()) {
										log.error("Invalid Plugin configuration");
									}
			        				errorsOnProc.add("Invalid Plugin configuration");
			        			}
			        		}
						}
					}
				}
				
				
				if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
					//int countImp = 0;
					AssetInstanceVersion assetInstver = null;

					for(int i=0;i<apsVoList.size();i++)
					{
						NameValue nv = new NameValue();
						nv.setName(apsVoList.get(i).getParamName());
						AssetParamDef apd1 = assetInstanceVersionDao.getAssetParamDefByAssetNameAndParamName(apsVoList.get(i).getAssetType(), apsVoList.get(i).getParamName(),conn);
						/*if( !apsVoList.get(i).getParamValue().isEmpty() && apd1.isHasImportantValue() == true )
					{
						countImp++;
					}*/
						AssetInstance ai = new AssetInstance();
						ai.setAssetName(apsVoList.get(i).getAssetType());
						ai.setAssetInstName(apsVoList.get(i).getAssetInstName());
						ai.setVersionName(apsVoList.get(i).getVersionName());
						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
						ai.setAssetId(asset.getAssetId());
						ai.setParentAssetName(apsVoList.get(i).getParentAssetName());
						ai.setParentAssetInstName(apsVoList.get(i).getParentAssetInstanceName());
						nv.setName(apsVoList.get(i).getParamName());
						AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
						ai.setAssetInstVersionId(aiv.getAssetInstVersionId());
						if(!apsVoList.get(i).getParamTypeId().equals(3L))
						{
							assetInstver = new AssetInstanceVersion();
							assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
							if(apsVoList.get(i).getParamTypeId().equals(7L)){
								if(apsVoList.get(i).isHasStaticValue()){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else if(apsVoList.get(i).getHasArray()==0){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
									assetInstver.setRTFPlainText(apsVoList.get(i).getRTFPlainText());
								}else{
									assetInstver.setRTFwithOutTags(apsVoList.get(i).getRTFwithOutTags());
									assetInstver.setRTFwithTags(apsVoList.get(i).getRTFwithTags());
								}
							}else if(apsVoList.get(i).getParamTypeId().equals(1L)){
								if(apsVoList.get(i).isHasStaticValue()){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else if(apsVoList.get(i).getHasArray()==0){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else{
									assetInstver.setTextDataList(apsVoList.get(i).getTextDataList());
								}
							}else if(apsVoList.get(i).getParamTypeId().equals(9L)){
								assetInstver.setLdapMappingValue(apsVoList.get(i).getLdapMappingValue());
							}else{
								assetInstver.setParamValue(apsVoList.get(i).getParamValue());
							}

							assetInstver.setParamTypeId(apsVoList.get(i).getParamTypeId());
							if(apsVoList.get(i).isHasStaticValue() == false){
								assetInstver.setIsStatic(0);
							}else{
								assetInstver.setIsStatic(1);
							}
							apsVoList.get(i).isHasStaticValue();
							assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
							assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
							assetInstver.setAssetName(ai.getAssetName());
							assetInstver.setHasArray(apsVoList.get(i).getHasArray());

							assetInstanceVersionsManager.updateParameterForAssetInst(assetInstver, null, profile.getUserId(), conn);
							aiv.setVersionName(ai.getVersionName());
							aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);

							if(apd1.getParamTypeId() == 5){
							}else if(apd1.getParamTypeId() == 6){ 
							}else if(apd1.getParamTypeId() == 8){
							}else{
								aiv.setVersionName(ai.getVersionName());
								aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
							}
						}
						else{
							Map<String,String> paramMapFromDb = new LinkedHashMap<String, String>();
							AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
							List<AssetParamDef> paramMap = new ArrayList<AssetParamDef>();
							List<AssetInstanceVersion> assetdata = assetInstanceVersionsManager.getParameter(ai.getAssetName(),userName,aiv1.getAssetInstVersionId(),conn);
							for(AssetInstanceVersion aivData: assetdata){
								AssetParamDef apd = new AssetParamDef();
								if (aivData.getIsStatic() == 1) {
									if (aivData.getParamTypeId() == 3) {
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getApdFileName());
									}else{
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getStaticValue());
									}

								} else {
									if (aivData.getParamTypeId() == 3) {
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getFileName());
									}else if(aivData.getParamTypeId() == 1){
										if(aivData.getTextDataList()!= null){
											String textdata = String.join("~~", aivData.getTextDataList());
											apd.setAssetParamName(aivData.getAssetParamName());
											apd.setParamValue(textdata);
										}else{
											apd.setAssetParamName(aivData.getAssetParamName());
											apd.setParamValue(aivData.getParamValue());
										}
									}else if(aivData.getParamTypeId() == 7){
										if(aivData.getRTFwithTags()!= null){
											String textdata = String.join("~~", aivData.getRTFwithTags());
											apd.setAssetParamName(aivData.getAssetParamName());
											apd.setParamValue(textdata);
										}else{
											apd.setAssetParamName(aivData.getAssetParamName());
											apd.setParamValue(aivData.getParamValue());
										}
									}else if(aivData.getParamTypeId() == 9){
										if(aivData.getLdapMappingValue() != null) {
											List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(aivData.getLdapMappingId(), conn);
											for (Map.Entry<String,Integer> entry : aivData.getLdapMappingValue().entrySet()){
												for(LdapMapping ldapAttributes:ldapMapping) {
													if(entry.getValue() == ldapAttributes.getLdapAttributeId()) {
														apd.setAssetParamName(aivData.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
													//	LdapMapping attribute = assetDao.getLdapMappingAttributeByattributeId(attributeId, conn);
														///List<String> values = aiv.getLdapMappingValue().keySet().stream().collect(Collectors.toList());
														apd.setParamValue(null);
													}
												}
											}
										}
									}else {
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getParamValue());
									}
								}
								paramMap.add(apd);
							}
							for (AssetParamDef assetdef : paramMap) paramMapFromDb.put(assetdef.getAssetParamName(),assetdef.getParamValue()+"|"+apsVoList.get(i).isHasStaticValue());
							String OldFileName = null;
							boolean updateFlag = false;
							for (Map.Entry<String, String> entry : paramMapFromDb.entrySet()) {
								String splitStaticVal = entry.getValue().substring(entry.getValue().indexOf("|")+1);
								String splitVal = entry.getValue().substring(0,entry.getValue().indexOf("|"));
								//System.out.println("From DB :::: "+entry.getKey() +" : "+ entry.getValue());
								//System.out.println("From XL :::: "+apsVoList.get(i).getParamName() +" : "+ apsVoList.get(i).getParamValue());
								if(apsVoList.get(i).getParamName().equalsIgnoreCase(entry.getKey())){
									//if(!apsVoList.get(i).getParamValue().equalsIgnoreCase(splitVal.toString())){
									//System.out.println("Inside param value not matching");
									//ParameterValues pv	= assetInstanceManager.getParameterForAssetInstParamAndVersionName(ai, apsVoList.get(i).getParamName());
									ParameterValues pv = null;
									AssetParamDef apd = null;
									/*	if(splitStaticVal.equalsIgnoreCase("true"))
								{
									apd = assetDao.retParamIdForAssetAndParamName(apsVoList.get(i).getAssetType(), apsVoList.get(i).getParamName(), conn);
								}
								else
								{
									pv = assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);
								}*/
									if(apsVoList.get(i).getParamValue() != "" && apsVoList.get(i).getParamValue() !=null)	
									{
										File file= new File(System.getProperty("user.home")+"/RepoProUnzip/"+apsVoList.get(i).getParamValue());

										nv.setFileName(file.getName());

										nv.setByteValue(FileUtils.readFileToByteArray(file));

										nv.setFileMimeType(new MimetypesFileTypeMap().getContentType(file));

										OldFileName = splitVal.toString();

										/*if(file.getName().endsWith(".png") || file.getName().endsWith(".jpg") ||  file.getName().endsWith(".jpeg") ||file.getName().endsWith(".PNG") || file.getName().endsWith(".JPG") ||  file.getName().endsWith(".JPEG"))
									{
										if(file.getName().endsWith(".png") || file.getName().endsWith(".jpg") ||  file.getName().endsWith(".jpeg") ||file.getName().endsWith(".PNG") || file.getName().endsWith(".JPG") ||  file.getName().endsWith(".JPEG")){
											if(splitStaticVal.equalsIgnoreCase("true"))
											{
												FileOutputStream fos = new FileOutputStream(System.getProperty("java.io.tmpdir")+apd.getAssetParamId().toString()+"_"+file.getName());
												fos.write(FileUtils.readFileToByteArray(file));
												fos.close();
											}
											else
											{
												if(pv != null)
												{
													FileOutputStream fos = new FileOutputStream(System.getProperty("java.io.tmpdir")+pv.getAssetParamId().toString()+"_"+file.getName());
													fos.write(FileUtils.readFileToByteArray(file));
													fos.close();
												}
												else
												{
													FileOutputStream fos = new FileOutputStream(System.getProperty("java.io.tmpdir")+file.getName());
													fos.write(FileUtils.readFileToByteArray(file));
													fos.close();
												}
											}

											Image image ;

											if(splitStaticVal.equalsIgnoreCase("true"))
											{
												image = Toolkit.getDefaultToolkit().getImage(System.getProperty("java.io.tmpdir")+apd.getAssetParamId().toString()+"_"+file.getName());
											}
											else
											{
												if(pv != null)
												{

													image = Toolkit.getDefaultToolkit().getImage(System.getProperty("java.io.tmpdir")+pv.getAssetParamId().toString()+"_"+file.getName());
												}
												else
												{
													image = Toolkit.getDefaultToolkit().getImage(System.getProperty("java.io.tmpdir")+file.getName());
												} 
											}

											MediaTracker mediaTracker = new MediaTracker(new Container());
											mediaTracker.addImage(image, 0);
											int thumbWidth = 60;
											int thumbHeight = 60;
											int quality = 100;


											double thumbRatio = (double)thumbWidth / (double)thumbHeight;
											int imageWidth = image.getWidth(null);
											int imageHeight = image.getHeight(null);
											double imageRatio = (double)imageWidth / (double)imageHeight;
											if (thumbRatio < imageRatio) {
												thumbHeight = (int)(thumbWidth / imageRatio);
											} else {
												thumbWidth = (int)(thumbHeight * imageRatio);
											}

											// draw original image to thumbnail image object and
											// scale it to the new size on-the-fly
											BufferedImage thumbImage = new BufferedImage(thumbWidth, thumbHeight, BufferedImage.TYPE_INT_RGB);
											Graphics2D graphics2D = thumbImage.createGraphics();
											graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
											graphics2D.drawImage(image, 0, 0, thumbWidth, thumbHeight, null);

											// save thumbnail image to outFilename
											//System.out.println(request.getRealPath(""));
											BufferedOutputStream out;
											JPEGEncodeParam param;
											JPEGImageEncoder encoder;
											String sfile = "";


											// save thumbnail image to outFilename
											// System.out.println(getServletContext().getRealPath(""));
											File file4 = new File(System.getProperty("user.home")+"/ThumbnailImages");
											if (!file4.exists()) {
												if (file4.mkdir()) {
													System.out.println("Directory thumbnailimages is created!");
												} else {
													System.out.println("Failed to create directory thumbnailimages!");
												}
											}

											if(splitStaticVal.equalsIgnoreCase("true"))
											{
												out = new BufferedOutputStream(new FileOutputStream(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+file.getName()));
												sfile = request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+file.getName();
												encoder = JPEGCodec.createJPEGEncoder(out);
												param = encoder.getDefaultJPEGEncodeParam(thumbImage);
												quality = Math.max(0, Math.min(quality, 100));
												param.setQuality((float)quality / 100.0f, false);
												encoder.setJPEGEncodeParam(param);
												encoder.encode(thumbImage);
											}
											else
											{
												if(pv != null)
												{
													out = new BufferedOutputStream(new FileOutputStream(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+file.getName()));
													sfile = request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+file.getName();
													encoder = JPEGCodec.createJPEGEncoder(out);
													param = encoder.getDefaultJPEGEncodeParam(thumbImage);
													quality = Math.max(0, Math.min(quality, 100));
													param.setQuality((float)quality / 100.0f, false);
													encoder.setJPEGEncodeParam(param);
													encoder.encode(thumbImage);
												}
												else
												{
													out = new BufferedOutputStream(new FileOutputStream(request.getRealPath("")+"/images/thumbnailImages/"+file.getName()));
													sfile = request.getRealPath("")+"/images/thumbnailImages/"+file.getName();
													encoder = JPEGCodec.createJPEGEncoder(out);
													param = encoder.getDefaultJPEGEncodeParam(thumbImage);
													quality = Math.max(0, Math.min(quality, 100));
													param.setQuality((float)quality / 100.0f, false);
													encoder.setJPEGEncodeParam(param);
													encoder.encode(thumbImage);
													//copy from above to user.home
													java.util.Date date= new java.util.Date();
													String time = new Timestamp(date.getTime()).toString();
													valMap.put(apsVoList.get(i).getParamName(), time+"|"+file.getName());
												} 
											}
											out.close();
											File sourceFile = new File(sfile);
											String name = sourceFile.getName();
											File targetFile = new File(System.getProperty("user.home")+"/ThumbnailImages/"+name);
											FileUtils.copyFile(sourceFile, targetFile);

											if(!splitVal.toString().equalsIgnoreCase("null")){
												if(!splitVal.toString().equalsIgnoreCase(file.getName()))
												{ 
													if(splitStaticVal.equalsIgnoreCase("true"))
													{
														File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
														if(filePath.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File doesn't exist");

														File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
														if(file5.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File doesn't exist");
													}
													else
													{
														if(pv != null)
														{
															File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
															if(filePath.delete())
															{
																System.out.println(" File deleted");
															}
															else System.out.println("File doesn't exist");

															File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
															if(file5.delete())
															{
																System.out.println(" File deleted");
															}
															else System.out.println("File doesn't exist");
														}
														else
														{
															File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+splitVal);
															if(filePath.delete())
															{
																System.out.println(" File deleted");
															}
															else System.out.println("File doesn't exist");

															File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+splitVal);
															if(file5.delete())
															{
																System.out.println(" File deleted");
															}
															else System.out.println("File doesn't exist");
														}

													}

												} 
											}
										}
										else if(file.getName().equalsIgnoreCase("") || file.getName().equalsIgnoreCase("null")){
											if(!splitVal.toString().equalsIgnoreCase("null")){
												if(splitStaticVal.equalsIgnoreCase("true"))
												{
													File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
													if(filePath1.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File  doesn't exists");	

													File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
													if(file7.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist"); 
												}
												else
												{
													if(pv != null)
													{
														File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
														if(filePath1.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File  doesn't exists");	

														File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
														if(file7.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File doesn't exist");  
													}
													else
													{
														File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+splitVal);
														if(filePath1.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File  doesn't exists");	

														File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+splitVal);
														if(file7.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File doesn't exist"); 
													}
												}

											}
										}
										if(splitStaticVal.equalsIgnoreCase("true"))
										{
											File file1 = new File(System.getProperty("java.io.tmpdir")+apd.getAssetParamId().toString()+"_"+file.getName());
											if(file1.delete())
											{
												System.out.println(" File deleted");
											}
											else System.out.println("File doesn't exist"); 
										}
										else
										{
											if(pv != null)
											{
												File file1 = new File(System.getProperty("java.io.tmpdir")+pv.getAssetParamId().toString()+"_"+file.getName());
												if(file1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
											else
											{
												File file1 = new File(System.getProperty("java.io.tmpdir")+file.getName());
												if(file1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
										}
									}

									if(file.getName().equalsIgnoreCase("") && !splitVal.toString().equalsIgnoreCase("null")) 
									{
										if(!splitVal.toString().equalsIgnoreCase(file.getName()))
										{ 
											if(splitStaticVal.equalsIgnoreCase("true"))
											{
												File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
												if(filePath.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist");

												File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
												if(file5.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist");
											}
											else
											{
												if(pv != null)
												{
													File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
													if(filePath.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist");

													File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
													if(file5.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist");
												}
												else
												{
													File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+splitVal);
													if(filePath.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist");

													File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+splitVal);
													if(file5.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist");
												}
											}
										}
										if(splitStaticVal.equalsIgnoreCase("true"))
										{
											File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
											if(filePath1.delete())
											{
												System.out.println(" File deleted");
											}
											else System.out.println("File  doesn't exists");	

											File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
											if(file7.delete())
											{
												System.out.println(" File deleted");
											}
											else System.out.println("File doesn't exist"); 
										}
										else
										{
											if(pv != null)
											{
												File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
												if(filePath1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File  doesn't exists");	

												File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
												if(file7.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist");  
											}
											else
											{
												File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+splitVal);
												if(filePath1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File  doesn't exists");	
												File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+splitVal);
												if(file7.delete()){
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
										}
										if(splitStaticVal.equalsIgnoreCase("true")){
											File file1 = new File(System.getProperty("java.io.tmpdir")+apd.getAssetParamId().toString()+"_"+file.getName());
											if(file1.delete()){
												System.out.println(" File deleted");
											}
											else System.out.println("File doesn't exist"); 
										}
										else{
											if(pv != null){
												File file1 = new File(System.getProperty("java.io.tmpdir")+pv.getAssetParamId().toString()+"_"+file.getName());
												if(file1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
											else{
												File file1 = new File(System.getProperty("java.io.tmpdir")+file.getName());
												if(file1.delete()){
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
										}
									}
										 */updateFlag = true;
										 break;}
									else{
										byte[] empty = {} ;
										nv.setFileName(apsVoList.get(i).getParamValue());
										nv.setByteValue(empty);
										nv.setFileMimeType(null);
										updateFlag = true;
										break;
									}	
									//}	
								}
							}
							if(apd1.getParamTypeId() == 5){
							}else if(apd1.getParamTypeId() == 6){ 
							}else if(apd1.getParamTypeId() == 8){
							}else{ 
								if(updateFlag == true){
									assetInstver = new AssetInstanceVersion();
									assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
									assetInstver.setParamTypeId(apd1.getParamTypeId());
									if(apsVoList.get(i).isHasStaticValue() == false){
										assetInstver.setIsStatic(0);
									}else{
										assetInstver.setIsStatic(1);
									}
									apsVoList.get(i).isHasStaticValue();
									nv.setName(apsVoList.get(i).getParamName());
									InputStream myInputStream = null ;
									myInputStream = new ByteArrayInputStream(nv.getByteValue()); 
									nv.setImage(myInputStream);
									assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
									assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
									assetInstver.setAssetName(ai.getAssetName());
									assetInstanceVersionsManager.updateParameterForAssetInst(assetInstver,nv,profile.getUserId(),conn);

									aiv.setVersionName(ai.getVersionName());
									aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aiv,aiv.getAssetInstVersionId(), conn);

									assetInstver.setFileName(OldFileName);
									assetInstver.setNewFileName(nv.getFileName());
									InputStream myInputStream1 = null;
									myInputStream1 = new ByteArrayInputStream(nv.getByteValue()); 
									assetInstanceVersionsManager.getNameValue(assetInstver, myInputStream1, nv.getFileName(), context, conn);
								}

							}
							/*if(!valMap1.isEmpty()){
						for (Map.Entry<String, String> entry : valMap1.entrySet())
						{
							ParameterValues pv	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);
							if(pv != null){
								String splitVal = entry.getValue().substring(entry.getValue().indexOf("|")+1);
								File oldfile =new File(request.getRealPath("")+"/images/thumbnailImages/" +splitVal);
								File newfile =new File(request.getRealPath("")+"/images/thumbnailImages/" +pv.getAssetParamId().toString() +"_"+ splitVal);
								oldfile.renameTo(newfile);
								File oldfile1 =new File(System.getProperty("user.home")+"/ThumbnailImages/" + splitVal);
								File newfile1 =new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString() +"_"+ splitVal);
								oldfile1.renameTo(newfile1);
							}
						}
					}*/
						}//End of else

						/*RecentActivity recentActivity = new RecentActivity();
					String action = Constants.ACTIVITY_MODIFY;
					String appendingMsg = "";
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setAssetId(ai.getAssetId().toString());
					recentActivity.setAssetInstVersionId(ai.getAssetInstVersionId().toString());
					recentActivity.setUser_id(profile.getUserId());

					if (asset.isVersionable() == true) {
						String log = profile.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ ai.getAssetInstName() + ";"+ " Version " + ai.getVersionName();
						recentActivity.setDescription(log);
					} else {
						String log = profile.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ ai.getAssetInstName() + ";"+ appendingMsg;
						recentActivity.setDescription(log);
					}
					recentActivityDao.addRecentActivity(recentActivity, conn);*/

					}  //End of for

					List<Long> paramAivId = new ArrayList<Long>();
					List<Long> finalparamAivId = new ArrayList<Long>();
					for(int i=0;i<azds.size();i++)
					{
						AssetInstance ai = new AssetInstance();

						ai.setAssetName(azds.get(i).getAssetName());
						ai.setAssetInstName(azds.get(i).getAssetInstName());
						ai.setVersionName(azds.get(i).getVersionName());
						//revision history data for parameter
						AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);
						paramAivId.add(aivVo.getAssetInstVersionId());
						instIds.add(aivVo.getAssetInstVersionId().toString());
						for(AivRevisionHistory paramRev:aivRevHistList){
							if(paramRev.getAivId().equals(aivVo.getAssetInstVersionId())){
								finalparamAivId.add(aivVo.getAssetInstVersionId());
								paramRev.setParameterKey("P");
								paramRev.setParameterData(azds.get(i).getParamRevData());
								paramRev.setVersionName(azds.get(i).getVersionName());
							}
						}
						/*	assetInstanceVersionsManager.addRevisionData("P",aivVo.getAssetInstVersionId(),ai.getVersionName(),null, null, 
							azds.get(i).getParamRevData(), null,userName,profile.getUserId(),null,conn);*/

					}
					paramAivId.removeAll(finalparamAivId);

					for(int i=0;i<azds.size();i++)
					{
						AssetInstance ai = new AssetInstance();
						ai.setAssetName(azds.get(i).getAssetName());
						ai.setAssetInstName(azds.get(i).getAssetInstName());
						ai.setVersionName(azds.get(i).getVersionName());
						//revision history data for parameter
						AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);

						for(Long paramRev:paramAivId){
							if(paramRev.equals(aivVo.getAssetInstVersionId())){
								AivRevisionHistory revHis = new AivRevisionHistory();
								revHis.setParameterKey("P");
								revHis.setParameterData(azds.get(i).getParamRevData());
								revHis.setVersionName(azds.get(i).getVersionName());
								revHis.setAivId(aivVo.getAssetInstVersionId());
								aivRevHistList.add(revHis);

								RecentActivity recentActivity = new RecentActivity();
								recentActivity.setAssetName(azds.get(i).getAssetName());
								recentActivity.setAssetInstName(azds.get(i).getAssetInstName());
								recentActivity.setAssetInstanceVersionName(azds.get(i).getVersionName());
								recentActivity.setAssetInstVersionId(aivVo.getAssetInstVersionId().toString());
								recentActivityList.add(recentActivity);
							}
						}
					}

					for(int i=0;i<assetInstassignList.size();i++)
					{
						AssetInstance ai = new AssetInstance();

						ai.setAssetName(assetInstassignList.get(i).getAssetName());
						ai.setAssetInstName(assetInstassignList.get(i).getAssetInstanceName());
						ai.setVersionName(assetInstassignList.get(i).getVersionName());
						AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);
						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
						String taxonomies = null;
						taxonomies = StringUtils.join(assetInstassignList.get(i).getTaxonIds(), ',');
						Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aivVo.getAssetInstVersionId(),
								taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
						MyModel res = (MyModel) response.getEntity();
						Map<String,String> data = res.getParamValues();
						taxIds.put(aivVo.getAssetInstVersionId().toString(),data);
						instIds.add(aivVo.getAssetInstVersionId().toString());

					}

					TaggingMaster taggingMaster = new TaggingMaster();
					for(int i=0;i<assetInstTaggingList.size();i++)
					{
						AssetInstance ai = new AssetInstance();

						ai.setAssetName(assetInstTaggingList.get(i).getAssetName());
						ai.setAssetInstName(assetInstTaggingList.get(i).getAssetInstanceName());
						ai.setVersionName(assetInstTaggingList.get(i).getVersionName());
						AssetInstanceVersion aivtag = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
						ai.setAssetInstVersionId(aivtag.getAssetInstVersionId());
						taggingMaster.setAssetInstanceVersionId(ai.getAssetInstVersionId());
						TaggingMaster tagsForAIV = taggingDao.getAllTags(taggingMaster, conn);

						List<String> tagsFromXls = assetInstTaggingList.get(i).getTagsFromXls();
						taggingMaster.setUserId(profile.getUserId());
						taggingMaster.setAssetInstanceVersionId(ai.getAssetInstVersionId());
						for (String tagNameFromXls : tagsFromXls )
						{
							boolean addflg = false;
							for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
							{
								if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
								{
									addflg = true;
									break;
								}
							}
							if(!addflg)
							{
								taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

							}
						}

						for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
						{
							boolean rmflg = false;
							taggingMaster.setTagId(tagNameForAIV.getKey());
							for( String tagNameFromXls: tagsFromXls)
							{
								if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
								{
									rmflg = true;
									break;
								}
							}

							if(!rmflg)
							{
								taggingDao.deleteTagsForImport(taggingMaster, conn);

							}
						}
					}
				}
			}
			log.info("Asset Attribute ,Taxonomy and Tagging DB updation done for incremental insert "+listOfassetInstList.toString());

			// Loop Starts for Asset Instance Relationship update 3rd level
			List<Long> relSrcAivIds = new ArrayList<Long>();
			List<Long> recentActivityIds = new ArrayList<Long>();
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty())
			{
				for (Entry<String, List<AssetInstRelationship>> entry : listOfassetInstRelList.entrySet())
				{
					for(AssetInstRelationship aiv:entry.getValue())
					{
						AssetInstanceVersion ai = new AssetInstanceVersion();
						ai.setAssetName(aiv.getSrcAssetName());
						ai.setAssetInstName(aiv.getSourceInstanceName());
						ai.setVersionName(aiv.getSourceVersionName());
						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

						AssetInstance assetIns = new AssetInstance();
						assetIns.setAssetName(ai.getAssetName());
						assetIns.setAssetInstName(ai.getAssetInstName());
						assetIns.setVersionName(ai.getVersionName());
						AssetInstanceVersion aivValue = assetInstanceVersionDao.getAssetInstanceVersion(assetIns, conn);
						ai.setAssetInstVersionId(aivValue.getAssetInstVersionId());
						
						if(aiv.getAction().equals("add"))
						{
							AssetInstance adr1 = new AssetInstance();

							adr1.setAssetName(aiv.getDestAssetName());
							AssetDef assetDataDest = assetInstanceDao.retAssetDetail(adr1.getAssetName(), conn);
							adr1.setAssetId(assetDataDest.getAssetId());
							adr1.setAssetInstName(aiv.getDestInstanceName());
							adr1.setOwner(userName);
							adr1.setVersionName("1.0");

							adr1.setParentVersionName(aiv.getSourceVersionName());
							adr1.setParentAssetName(aiv.getSrcAssetName());
							AssetDef assetDataSrc = assetInstanceDao.retAssetDetail(adr1.getParentAssetName(), conn);
							adr1.setParentAssetId(assetDataSrc.getAssetId());
							adr1.setParentAssetInstName(aiv.getSourceInstanceName());
							adr1.setOwner(profile.getUserName());

							AssetInstance parentAIVid = new AssetInstance();
							parentAIVid.setAssetName(adr1.getParentAssetName());
							parentAIVid.setAssetInstName(adr1.getParentAssetInstName());
							parentAIVid.setVersionName(adr1.getParentVersionName());
							AssetInstanceVersion parentaiv = assetInstanceVersionDao.getAssetInstanceVersion(parentAIVid, conn);
							adr1.setParentAssetInstVersionId(parentaiv.getAssetInstVersionId());

							if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation"))
							{
								//add child
								Response response = assetInstanceManager.addAssetInstanceHelper(adr1,userName,true,true,true,conn);
								MyModel res = (MyModel) response.getEntity();
								List<Object> data = res.getResult();
								for (int i = 0; i < data.size(); i++) {
									AssetInstance aiResponse = new AssetInstance();
									aiResponse = (AssetInstance) data.get(i);
									ai.setAssetInstanceId(aiResponse.getAssetInstId());
									ai.setAssetInstVersionId(aiResponse.getAssetInstVersionId());
								}
								Long firstState = null;
								Workflow workflow = workflowDao.retWorkflowByAivId(ai.getAssetInstVersionId(), conn);
								if(workflow != null) {
									String jsonStructure = workflow.getJsonStructure();
									JSONObject jsonObject = new JSONObject(jsonStructure);
									
									for(int i=0;i<jsonObject.length();i++) {
										Iterator itr = jsonObject.keys();
										if(itr.hasNext()){
											firstState = Long.parseLong(itr.next().toString());
										}
									}
									assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
								}
								
								instIds.add(ai.getAssetInstVersionId().toString());
								
								Timestamp d=(Timestamp) new Date();
								ai.setUpdatedOn(d);
								assetInstanceVersionDao.updateAivUpdatedOn(ai, ai.getAssetInstVersionId(), conn);
							}
							else
							{
								//add relationship
								List<Long> addAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> selectedAssetRelationship = new ArrayList<Long>();
								List<Long> removedAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> removedAssetRelationship = new ArrayList<Long>();

								AssetInstance assetInstance = new AssetInstance();
								assetInstance.setAssetName(aiv.getDestAssetName());
								assetInstance.setAssetInstName(aiv.getDestInstanceName());
								assetInstance.setVersionName(aiv.getDestInstanceVersionName());

								AssetInstanceVersion aivo =	assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

								addAssetInstanceVersionIds.add(aivo.getAssetInstVersionId());

								AssetRelationshipDef ard = relationshipDao.retAssetRelDefForAssetsByRelationName(aiv.getSrcAssetName(),aiv.getDestAssetName(),aiv.getDescrption(), conn);

								selectedAssetRelationship.add(ard.getAssetRelId());

								ai.setAddDestAssetInstVersionIds(addAssetInstanceVersionIds);
								ai.setAddRelationshipIds(selectedAssetRelationship);
								ai.setRemovedDestAssetInstVersionIds(removedAssetInstanceVersionIds);
								ai.setRemovedRelationshipIds(removedAssetRelationship);
								ai.setSrcAssetInstanceVersionId(ai.getAssetInstVersionId().toString());
								ai.setAssetInstanceId(aivValue.getAssetInstanceId());
								ai.setAssetId(asset.getAssetId());
								assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
								//get all the source asset instance version ids
								relSrcAivIds.add(ai.getAssetInstVersionId());
								recentActivityIds.add(ai.getAssetInstVersionId());
								instIds.add(ai.getAssetInstVersionId().toString());

								aivo.setVersionName(ai.getVersionName());
								aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
							}
						}
						else if(aiv.getAction().equals("update") || aiv.getAction().equals("skip")) {
						}
					}
				}
				log.info("Asset Relationship DB Updation done for incremental insert"+listOfassetInstRelList.toString());
			}
			// Loop Ends for Asset Instance Relationship update 3rd level
			
			//add revision history
			List<Long> relIds = new ArrayList<Long>();
			List<Long> recentActyIds = new ArrayList<Long>();
			
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
				Set<Long> finalrelaivids = new HashSet<>();
				finalrelaivids.addAll(relSrcAivIds);
				relSrcAivIds.clear();
				relSrcAivIds.addAll(finalrelaivids);

				for(AivRevisionHistory revRel:aivRevHistList){
					for(Long srcaivids:relSrcAivIds){
						if(srcaivids.equals(revRel.getAivId())){
							relIds.add(srcaivids);
							AssetInstanceVersion aiv = new AssetInstanceVersion();
							aiv.setSrcAssetInstanceVersionId(srcaivids.toString());
							List<AssetInstance> aivos = assetInstanceManager.retFwdDependents(aiv,conn);
							String newRelationshipDataForRevision = "";
							int i = 1;
							for(AssetInstance aivoRev : aivos){
								AssetDef assetDef = assetDao.getAssetsByAssetId(aivoRev.getAssetId(), conn);
								if(i == aivos.size()){
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
									}	
								}else{
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
									}
								}
								i++;
							}
							revRel.setRelationshipKey("R");
							revRel.setRelationshipData(newRelationshipDataForRevision);
							AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(srcaivids,conn);
							if(aivVo != null){
								revRel.setVersionName(aivVo.getVersionName());
							}
						}
					}
				}
				//List<Long> finalrelIds = new ArrayList<Long>();
				relSrcAivIds.removeAll(relIds);
				for(Long srcaivids:relSrcAivIds){
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv.setSrcAssetInstanceVersionId(srcaivids.toString());
					List<AssetInstance> aivos = assetInstanceManager.retFwdDependents(aiv,conn);
					String newRelationshipDataForRevision = "";
					int i = 1;
					for(AssetInstance aivoRev : aivos){
						AssetDef assetDef = assetDao.getAssetsByAssetId(aivoRev.getAssetId(), conn);
						if(i == aivos.size()){
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
							}	
						}else{
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
							}
						}
						i++;
					}
					AivRevisionHistory aivRevHisrel = new AivRevisionHistory();
					aivRevHisrel.setRelationshipKey("R");
					aivRevHisrel.setRelationshipData(newRelationshipDataForRevision);
					AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(srcaivids,conn);
					if(aivVo != null){
						aivRevHisrel.setVersionName(aivVo.getVersionName());
					}
					aivRevHisrel.setAivId(srcaivids);
					aivRevHistList.add(aivRevHisrel);
				}

				//recent activity details for relationship data
				Set<Long> finalrecids = new HashSet<>();
				finalrecids.addAll(recentActivityIds);
				recentActivityIds.clear();
				recentActivityIds.addAll(finalrecids);

				for(RecentActivity recent:recentActivityList){
					for(Long recids:recentActivityIds){
						if(recids.toString().equals(recent.getAssetInstVersionId())){
							recentActyIds.add(recids);

						}
					}
				}

				recentActivityIds.removeAll(recentActyIds);
				for(Long recentAct:recentActivityIds){
					RecentActivity acticity = new RecentActivity();
					AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(recentAct,conn);
					if(aivVo != null){
						acticity.setAssetName(aivVo.getAssetName());
						acticity.setAssetInstName(aivVo.getAssetInstName());
						acticity.setAssetInstanceVersionName(aivVo.getVersionName());
						acticity.setAssetInstVersionId(aivVo.getAssetInstVersionId().toString());
						recentActivityList.add(acticity);
					}
				}

				// add revision history
				RevisionHistoryDao  revisionHistoryDao = new RevisionHistoryDao();
				for(AivRevisionHistory revFinal:aivRevHistList){
					String changeKey = "";  
					if(revFinal.getNewInstanceKey() == null){
						revFinal.setNewInstanceKey("");
					}
					if(revFinal.getRelationshipKey() == null){
						revFinal.setRelationshipKey("");
					}
					if(revFinal.getParameterKey() == null){
						revFinal.setParameterKey("");
					}
					changeKey = revFinal.getNewInstanceKey()+","+revFinal.getRelationshipKey()+","+revFinal.getParameterKey();
					List<String> list = Arrays.asList(changeKey.split(","));
					List<String> finallist = new ArrayList<String>();
					for(String emptydata:list){
						if(!emptydata.equalsIgnoreCase("")){
							finallist.add(emptydata);
						}
					}
					String listString = String.join(",", finallist);
					AivRevisionHistory aivRevHist = new AivRevisionHistory();
					aivRevHist.setAivId(revFinal.getAivId());
					aivRevHist.setRevId(revFinal.getRevId());
					aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					aivRevHist.setChangedKey(listString);
					aivRevHist.setOverviewData(revFinal.getOverviewData());
					if(revFinal.getRelationshipData() != null){
						aivRevHist.setRelationshipData(revFinal.getRelationshipData());
					}else{
						aivRevHist.setRelationshipData(null);
					}
					if(revFinal.getParameterData() != null){
						aivRevHist.setParameterData(revFinal.getParameterData());
					}else{
						aivRevHist.setParameterData(null);
					}
					aivRevHist.setUserId(profile.getUserId());
					aivRevHist.setUsedBy(null);

					revisionHistoryDao.addRevisionData(aivRevHist, conn);
					
					AssetInstanceVersion aivo = new AssetInstanceVersion();
					aivo.setVersionName("1.0");
					aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					aivo.setAssetInstVersionId(revFinal.getAivId());
					assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
				}
			}
			//add recent activity
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
				for(RecentActivity recentFinal:recentActivityList){
					RecentActivity recentActivity = new RecentActivity();
					String action = Constants.ACTIVITY_CREATE;
					String appendingMsg = "";
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					AssetDef asset = assetDao.getAssetsByAssetName(recentFinal.getAssetName(), conn);
					if (asset.isVersionable() == true) {
						String log = profile.getFullName() + ";" + action + ";"+ recentFinal.getAssetName() + ";"+ recentFinal.getAssetInstName() + ";"+ " Version " + recentFinal.getAssetInstanceVersionName();
						recentActivity.setDescription(log);
					} else {
						String log = profile.getFullName() + ";" + action + ";"+ recentFinal.getAssetName() + ";"+ recentFinal.getAssetInstName() + ";"+ appendingMsg;
						recentActivity.setDescription(log);
					}
					recentActivity.setUser_id(profile.getUserId());
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(recentFinal.getAssetInstVersionId().toString());
					recentActivityDao.addRecentActivity(recentActivity, conn);
				}
			}
			
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
				
				Set<String> ids = new HashSet<String>();
				ids.addAll(instIds);

				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				SubscriptionDao subscriptionDao = new SubscriptionDao();
				
				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				String mailTemp = null;
				
				for(String aivid:ids){
					AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(aivid), conn);
					if(aiv != null){
						List<String> emailIds=subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);
						/*
					if(aiv.getVersionable() == true){
						MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
						mailTemp = mtVo1.getMailTemplate();
						mailTemp = mailTemp.replaceAll("%assetInstName%", aiv.getAssetInstName()).replaceAll("%versionName%", aiv.getVersionName());
					}else{
						MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
						mailTemp = mtVo.getMailTemplate();
						mailTemp = mailTemp.replaceAll("%assetInstName%", aiv.getAssetInstName());
						mailTemp = mailTemp.replaceAll("%assetType%", aiv.getAssetName());

					}*/
						if(aiv.getVersionable() == true){
							MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
							mailTemp = mtVo1.getMailTemplate();
							String instName = aiv.getAssetInstName();
							instName = instName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
							mailTemp = mailTemp.replaceAll("%versionName%", aiv.getVersionName());
						}else{
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
							mailTemp = mtVo.getMailTemplate();
							String instName = aiv.getAssetInstName();
							instName = instName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
							mailTemp = mailTemp.replaceAll("%assetType%", aiv.getAssetName());
						}
						if(emailIds!=null){
							for(String emailId:emailIds){
								if(aiv.getVersionable() == true) {
									SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

								}
								else {
									SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

								}
							}
						}
					}
				}
				//taxonomy mail configration for subscribed users
				for (Entry<String, Map<String, String>> entry : taxIds.entrySet()) {
					Map<String, String> childMap = entry.getValue();
					String assignTax = "";
					String unassignTax = "";
					String addTax = "";
					String removedTax = "";
					List<String> emailIdsList = new ArrayList<String>();
					List<String> emailIds1List = new ArrayList<String>();
					for (Entry<String, String> entry2 : childMap.entrySet()) {
						assignTax = entry2.getKey();
						unassignTax = entry2.getValue();
					}

					//added taxonomies
					if(!assignTax.equalsIgnoreCase("")){
						String addedTaxEmail = "";
						String[] addTaxFinal = assignTax.split("~~");
						addTax = addTaxFinal[0];
						if(addTaxFinal.length == 2){
							addedTaxEmail = addTaxFinal[1];
						}
						emailIdsList = Arrays.asList(addedTaxEmail.split(","));
					}


					//unassigned taxonomies
					if(!unassignTax.equalsIgnoreCase("")){
						String[] unassignTaxFinal = unassignTax.split("~~");
						removedTax = unassignTaxFinal[0];
						String unassignTaxEmail = "";

						if(unassignTaxFinal.length == 2){
							unassignTaxEmail = unassignTaxFinal[1];
						}
						emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
					}
					
					AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(entry.getKey()), conn);
					if(aiv != null){
						if (!emailIdsList.isEmpty()) {
							//HashSet<String> listToSet = new HashSet<String>(emailIdsList);
							//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);

							if (aiv.getVersionable() == true) {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"assignTaxNameForAssetInstanceForVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
										.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
							} else {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"assignTaxNameForAssetInstanceForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",instName);
							}

							for (String emailId : emailIdsList) {
								if (addTax != "") {
									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								}
							}
						}

						if (!emailIds1List.isEmpty()) {
							//HashSet<String> listToSet = new HashSet<String>(emailIds1List);
							//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);

							if (aiv.getVersionable() == true) {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"unassignTaxNameForAssetInstanceForVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
										.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
							} else {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"unassignTaxNameForAssetInstanceForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax).replaceAll("%assetInstName%", instName);
							}

							for (String emailId : emailIds1List) {
								if (removedTax != "") {
									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								}
							}
						}
					}
				}
				
				for(Object jsondata:parameterChangefinaldata){

					JSONObject jsonObject = new JSONObject(jsondata.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result = jsonObject.getString("Notification");
								result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
								if(!result.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}
				
				for(Object jsondata:relatedParamChangefinaldata){

					JSONObject jsonObject = new JSONObject(jsondata.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result = jsonObject.getString("Notification");
								result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
								if(!result.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			
			//error message
			if(!errorsOnProc.isEmpty() || !apeVoList.isEmpty())
			{
				Set<String> hs = new HashSet<String>();
				hs.addAll(errorsOnProc);
				errorsOnProc.clear();
				errorsOnProc.addAll(hs); 
				for(int i=0;i<errorsOnProc.size();i++)
				{
					errStr.append(errorsOnProc.get(i)+"\n");
				}
				for(int i=0;i<apeVoList.size();i++)
				{
					if(apeVoList.get(i).getFileExist() != null)
					{
						if(apeVoList.get(i).getFileExist().equalsIgnoreCase("Not Found"))
						{
							if(apeVoList.get(i).isVersionable()){
								errStr.append(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
							else{
								errStr.append(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
						}
					}
					else
					{
						if(apeVoList.get(i).getErrorMessage() == null){
							if(apeVoList.get(i).isVersionable())
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
							else
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
						}else{
							if(apeVoList.get(i).isVersionable())
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
							}
							else
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
							}
						}
					}
				}
				log.info("Asset Attribute and Asset Relationship Error Handling done for incremental insert"+apeVoList.toString());
				//return INPUT;
			}
			if (log.isTraceEnabled()) {
				log.trace("incrementalInsert ||UserName:"+userName+" RadioVal:"+radioVal+" InputStream:"+inputStream+" ||Begin");
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
	}

	/**
	 * @method incrementalUpdate
	 * @description update existing asset instance details
	 * @param userName
	 * @param radioVal
	 * @param radValStatic
	 * @param inputStream
	 * @throws IOException
	 * @throws RepoproException
	 */
	public void incrementalUpdate(List<TaxonomyMaster> tmList,String userName,String radioVal,String radValStatic,InputStream inputStream,StringBuilder errStr,Set<String> lockedVersionIds,@Context ServletContext context,Connection conn) throws IOException, RepoproException{
		if (log.isTraceEnabled()) {
			log.trace("incrementalUpdate ||UserName:"+userName+" RadioVal:"+radioVal+" RadValStatic:"+radValStatic+" InputStream:"+inputStream+" ||Begin");
		}

		Connection conn1 = null;
		List<AssetRelationshipDef>  relNameList = null;
		String splitAssetName = "";
		List<AssetParamDef> paramList =  new ArrayList<AssetParamDef>();;
		List<AssetInstanceVersion>  assetInstList = new ArrayList<AssetInstanceVersion>();
		List<AssetParamDef>    allCatsAndParamsForAsset = new ArrayList<AssetParamDef>();
		List<AssetInstanceVersion>  listAivo = new ArrayList<AssetInstanceVersion>();
		List<AssetInstanceVersion>  excelassetInstList = new ArrayList<AssetInstanceVersion>(); 
		List<AssetInstDescSuccess> aisdVoList = new ArrayList<AssetInstDescSuccess>();
		List<AssetParamSuccess> apsVoList = new ArrayList<AssetParamSuccess>();
		List<AssetParamSuccess> apeVoList = new ArrayList<AssetParamSuccess>();
		List<String> possValues = null;
		List<AssetInstVersionTaxonomy>   assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
		List<AssetInstance> azds = new ArrayList<AssetInstance>();
		List<AssetInstanceVersion>  assetInstList1 =  new ArrayList<AssetInstanceVersion>(); 
		List<List<AssetInstanceVersion>> assetInstList2 = new ArrayList<List<AssetInstanceVersion>>();
		//Map<String,List<AssetInstanceVersion>> listOfexcelassetInstList = new LinkedHashMap<String,List<AssetInstanceVersion>>();
		List<AssetInstAssignTagging>    assetInstTaggingList = new ArrayList<AssetInstAssignTagging>();
		Map<String,List<AssetInstanceVersion>> listOfassetInstList = new LinkedHashMap<String,List<AssetInstanceVersion>>();
		Map<String,List<List<AssetInstanceVersion>>> listOfassetInstList1 = new LinkedHashMap<String,List<List<AssetInstanceVersion>>>();
		GlobalSetting globalLock;
		//Set<String> lockedVersionIds = new HashSet<String>();
		Map<String,String> valMap = new LinkedHashMap<String,String>();
		TaggingDao taggingDao = new TaggingDao();
		AssetInstanceVersionsManager assetInstanceVersionsManager = new AssetInstanceVersionsManager();
		AssetDao assetDao = new AssetDao();
		UserDao userDao = new UserDao();
		RelationshipDao relationshipDao = new RelationshipDao();
		AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
		RecentActivityDao recentActivityDao = new RecentActivityDao();
		GlobalSettingDao globalSettingDao = new GlobalSettingDao();
		List<String> errorsOnProc = new ArrayList<String>();
		CommonUtils commonUtils = new CommonUtils();

		List<String> splitAssetList = new ArrayList<String>();
		try{
			
			/*LDAPConnection ldapConnection = LDAPConnection.getInstance();
			DirContext dirContext = ldapConnection.getDirContext();*/
			LDAPUtility ldapUtility = new LDAPUtility();
			
			Boolean flagForskip= false;

			XSSFWorkbook wb = new XSSFWorkbook(inputStream);

			List<AssetDef> assetNameList = assetDao.getAllAssets(conn);

			User profile = userDao.retProfiledetailsForUserName(userName, conn);

			relNameList = relationshipDao.getAllAssetRelationshipDef(conn);

			globalLock = globalSettingDao.retGlobalSettingByName("Lock", conn);
			if (log.isTraceEnabled()){
				log.trace("incrementalUpdate || call of retGlobalSettingByName method");
			}
			GlobalSetting globalsetting = globalSettingDao.retGlobalSettingByName(Constants.CROSS_SITE_SCRIPTING, conn);

			for (int x = 0; x < wb.getNumberOfSheets(); x=x+2) 
			{
				splitAssetName = null;
				XSSFSheet sheet=wb.getSheetAt(x);
				XSSFRow row; 
				//Iterator rows = sheet.rowIterator();
				Iterator<Row> rows = sheet.iterator();

				Boolean flagForParam = false;
				Boolean flagOrder = false;
				Boolean flagForEmpAsset = false;

				if( sheet.getFirstRowNum()== 0)
				{
					while (rows.hasNext())
					{
						row = (XSSFRow) rows.next();
						int  rowNum = row.getRowNum();
						if(row.getRowNum()==0  )
						{
							XSSFRow rowb = sheet.getRow(rowNum++);
							XSSFCell cellaa = rowb.getCell(0);
							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									splitAssetName = cellaa.getStringCellValue();
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}	
								splitAssetList.add(splitAssetName);
							}
							else
							{
								splitAssetName = "";
								splitAssetList.add(splitAssetName);

							}
						}
						break;
					}
				}

				if(!flagForEmpAsset)
				{
					if( sheet.getFirstRowNum()== 0)
					{
						paramList = assetDao.getParamsDetailByAssetName(splitAssetName,conn);
						List<AssetParamDef> ldapmodifiedData = new ArrayList<AssetParamDef>();
						List<AssetParamDef> ldapmodifiedDataRemoval = new ArrayList<AssetParamDef>();
						Collections.sort(paramList, new AssetParamDef());
						for(AssetParamDef apd: paramList) {
							if(apd.getParamTypeId() == 9) {
								List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(apd.getLdapMappingId(), conn);
								for(LdapMapping ldapAttributes:ldapMapping) {
									AssetParamDef assetparam = new AssetParamDef();
									assetparam.setLdapMappingId(apd.getLdapMappingId());
									assetparam.setAssetParamName(apd.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
									assetparam.setParamTypeId(apd.getParamTypeId());
									ldapmodifiedData.add(assetparam);
								}
								ldapmodifiedDataRemoval.add(apd);
							}
						}
						if(!ldapmodifiedDataRemoval.isEmpty()) {
							paramList.removeAll(ldapmodifiedDataRemoval);
						}
						if(!ldapmodifiedData.isEmpty()) {
							paramList.addAll(ldapmodifiedData);
						}
						int s = 5;
						int f = 0;
						List<String> paramNames = new ArrayList<String>() ;
						List<String> paramNamesForOrder = new ArrayList<String>() ;
						List<String> paramNamesForOrder1 = new ArrayList<String>() ;
						paramNamesForOrder.add("Asset Instance Version Id");
						paramNamesForOrder.add("Asset Instance Name");
						paramNamesForOrder.add("Version Name");
						paramNamesForOrder.add("Overview");
						paramNamesForOrder.add("Created On");
						
						Collections.sort(paramList, new AssetParamDef());
						
						for(AssetParamDef pvo: paramList)
						{
							paramNames.add(pvo.getAssetParamName());
							paramNamesForOrder1.add(pvo.getAssetParamName());
						}
						
						//Collections.sort(paramNames,String.CASE_INSENSITIVE_ORDER);
					//	Collections.sort(paramNamesForOrder1,String.CASE_INSENSITIVE_ORDER);
						paramNamesForOrder.addAll(paramNamesForOrder1);
						paramNamesForOrder.add("%%Taxonomies%%");
						paramNamesForOrder.add("%%Tags%%");
						for(int l=0;l<paramNamesForOrder.size();l++)
						{
							XSSFRow rowb = sheet.getRow(1);
							if(rowb != null) {
								XSSFCell cellp = rowb.getCell(f++);
								String valParam = null;
								if(cellp != null)
								{
									if (cellp.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										valParam = cellp.getStringCellValue();
										if(valParam.length() == 0)
										{
											valParam = "";  
										} 
									}else if(cellp.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellp.getNumericCellValue(); 
										valParam = String.valueOf(val); 
									}
									else if(cellp.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										valParam = ""; 
									}
									if(!valParam.equalsIgnoreCase(paramNamesForOrder.get(l))){
										flagOrder = true;
										break;
									}
								}
							}else {
								flagForParam = true;
								break;
							}
						}
						for (String pvo: paramNames)
						{
							XSSFRow rowb = sheet.getRow(1);
							if(rowb != null) {
								XSSFCell cellee = rowb.getCell(s++);
								String valParam = null;
								if(cellee != null)
								{
									if (cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										valParam = cellee.getStringCellValue();
										if(valParam.length() == 0)
										{
											valParam = "";  
										}
									}
									else if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellee.getNumericCellValue(); 
										valParam = String.valueOf(val); 
									}
								}
								else
								{
									valParam = "";
								}
								if(!pvo.equalsIgnoreCase(valParam))
								{
									flagForParam = true;
									break;
								}
							}else {
								flagForParam = true;
								break;
							}
						}
					}

					if(flagForParam || flagOrder )
					{
						//Parameter Mismatch
						if (log.isErrorEnabled()) {
							log.error("Error in asset name/parameter details for " + splitAssetName + ". Please check for wrong asset name,asset instance version id,wrong parameter names, missing parameters, incorrect alphabetical order.");
						}
						errorsOnProc.add("Error in asset name/parameter details for " + splitAssetName + ". Please check for wrong asset name,asset instance version id,wrong parameter names, missing parameters, incorrect alphabetical order.");
					}
				}
			}
			if(splitAssetList.size() == 1){
				Boolean flagname = false;
				for(int f=0;f<assetNameList.size();f++)
				{
					if(assetNameList.get(f).getAssetName().equals(splitAssetList.get(0)))
					{
						flagname = true;
						break;
					}
				}
				if(!flagname)
				{
					if (log.isErrorEnabled()) {
						log.error("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");
					}
					errorsOnProc.add("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");
				}
			}
			else
			{
				if(splitAssetList.size() == 0)
				{
					if (log.isErrorEnabled()) {
						log.error("Error : Atleast one asset attribute/relationship sheet must be present in excel sheet.");
					}
					errorsOnProc.add("Error : Atleast one asset attribute/relationship sheet must be present in excel sheet.");
				}
				else
				{
					if (log.isErrorEnabled()) {
						log.error("Error : More than one asset attribute/relationship sheet in excel sheet not allowed.");
					}
					errorsOnProc.add("Error : More than one asset attribute/relationship sheet in excel sheet not allowed.");
				}
			}

			// Loop ends for Asset Attribute 1st level validation

			log.info("Asset Attribute 1st level validation end for incremental update : "+splitAssetList);

			// Loop starts for Asset relationship 1st level validation
			Boolean flagForskip1 = false;

			List<String> splitAssetList1 = new ArrayList<String>();

			if(errorsOnProc.size() == 0)
			{
				String	splitAssetName1 = null;
				for (int x = 1; x < wb.getNumberOfSheets(); x=x+2) 
				{
					XSSFSheet sheet = wb.getSheetAt(x);
					XSSFRow row; 
					//Iterator rows = sheet.rowIterator();
					Iterator<Row> rows = sheet.iterator();

					while (rows.hasNext())
					{
						row=(XSSFRow) rows.next();
						if(row.getRowNum() == 0){
							if( sheet.getFirstRowNum() == 0)
							{
								int  rowNum = row.getRowNum();
								if(row.getRowNum() == 0  )
								{
									XSSFRow rowb = sheet.getRow(rowNum++);
									XSSFCell cellaa = rowb.getCell(0);
									if(cellaa != null)
									{
										if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
										{
											splitAssetName1 = cellaa.getStringCellValue();
											if(splitAssetName1.length() == 0)
											{
												splitAssetName1 = "";  
											}
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
										{
											int val1 = (int)cellaa.getNumericCellValue(); 
											splitAssetName1 = String.valueOf(val1); 
										}
										if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
										{
											splitAssetName1 = cellaa.getStringCellValue();
										}	
										splitAssetList1.add(splitAssetName1);
									}
									else
									{
										splitAssetName1 = "";
										splitAssetList1.add(splitAssetName1);
									}
								}
								break;
							}
						}
						if(row.getRowNum()== 1)
						{
							continue; 
						}

						int rowNum = row.getRowNum();

						String cell1 = null,cell2 = null,cell3 = null,cell6 = null;

						XSSFRow rowb = sheet.getRow(rowNum++);

						XSSFCell cellff = rowb.getCell(6);

						XSSFCell cellaa = rowb.getCell(0);

						XSSFCell cellbb = rowb.getCell(3);

						XSSFCell cellcc = rowb.getCell(2);

						if(cellaa != null)
						{
							if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellaa.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellaa.getNumericCellValue(); 
								cell1 = String.valueOf(val); 
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellaa.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellbb.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellbb.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell2 = "";
						}

						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = cellcc.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellcc.getNumericCellValue(); 
								cell3 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = cellcc.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}


						if(cellff != null)
						{
							if (cellff.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell6 = cellff.getStringCellValue();
								if(cell6.length() == 0)
								{
									cell6 = "";  
								}
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellff.getNumericCellValue(); 
								cell6 = String.valueOf(val); 
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell6 = cellff.getStringCellValue();
							}
						}
						else
						{
							cell6 = "";
						}

						Boolean flagForRel = false;

						if(cell1!="" && cell2!="" && cell3!="")
						{
							for(AssetRelationshipDef relNm :relNameList)
							{
								// Need to validate with attribute list
								if(relNm.getDescription().equals(cell6))	
								{
									flagForRel = true;
									break;
								}
							}
							if(!flagForRel)
							{
								if (log.isErrorEnabled()) {
									log.error("Error in Relation Name for " + cell2+"_"+cell3+" at "+cell1);
								}
								errorsOnProc.add("Error in Relation Name for " + cell2+"_"+cell3+" at "+cell1);
							}
						}
					}
				}

				if(splitAssetList1.size() == 1){
					Boolean flagname = false;
					for(int f=0;f<assetNameList.size();f++)
					{
						if(assetNameList.get(f).getAssetName().equals(splitAssetList1.get(0)))
						{
							flagname = true;
							break;
						}
					}
					if(!flagname)
					{
						if (log.isErrorEnabled()) {
							log.error("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");
						}
						errorsOnProc.add("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");

					}
				}
				else
				{
					if(splitAssetList.size() == 0)
					{
						if (log.isErrorEnabled()) {
							log.error("Error : Atleast one asset attribute/relationship sheet must be present in excel sheet.");
						}
						errorsOnProc.add("Error : Atleast one asset attribute/relationship sheet must be present in excel sheet.");
					}
					else
					{
						if (log.isErrorEnabled()) {
							log.error("Error : More than one asset attribute/relationship sheet in excel sheet not allowed.");
						}
						errorsOnProc.add("Error : More than one asset attribute/relationship sheet in excel sheet not allowed.");
					}
				}
			}
			log.info("Asset Relationship 1st level validation done for incremental update");
			// Loop Ends for Asset relationship - first level

			// Loop Starts for Asset attribute value validation 2nd level
			if(errorsOnProc.size() == 0)
			{
				splitAssetName = null;
				int ldapDuplicateCount = 0; 
				for (int x = 0; x < wb.getNumberOfSheets(); x=x+2) 
				{
					List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
					XSSFSheet sheet=wb.getSheetAt(x);
					XSSFRow row; 	
					//Iterator rows = sheet.rowIterator();
					Iterator<Row> rows = sheet.iterator();

					boolean flag1  = false;

					Map<String, List<String>> allPossVals = null ;

					while (rows.hasNext())
					{
						AssetInstance prhVo = new AssetInstance();

						row=(XSSFRow) rows.next();

						int  rowNum = row.getRowNum();

						if(row.getRowNum() == 0)
						{
							XSSFRow rowb = sheet.getRow(rowNum++);

							XSSFCell cellaa = rowb.getCell(0);

							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}
							}
							else
							{
								splitAssetName = "";
							}
							assetInstList = assetInstanceVersionDao.getAssetInstVerByAsset(splitAssetName, conn);
							List<AssetDef> assetNameListt =  assetDao.getAllAssetNames(userName,conn);
							for(int h=0;h<assetNameListt.size();h++)
							{
								if(!assetNameListt.get(h).getAssetName().equalsIgnoreCase(splitAssetName))
								{
									assetInstList1 = assetInstanceVersionDao.getAssetInstVerByAsset(assetNameListt.get(h).getAssetName(), conn);
								}
								assetInstList2.add(assetInstList1);
							}

							assetInstList2.add(assetInstList);
							continue;   
						}

						if( row.getRowNum()==1 )
						{
							continue; 
						}

						if(row.getRowNum() == 2)
						{
							AssetDef asset = assetInstanceDao.retAssetDetail(splitAssetName, conn);

							allTxs = taxonomyDao.getAllTaxonomiesByAssetId(asset.getAssetId(), conn);

							for(TaxonomyMaster t:allTxs)
							{
								recurse1(t); 
							}
							Set<Long> hs = new HashSet<Long>();
							hs.addAll(associatedTaxId);
							associatedTaxId.clear();
							associatedTaxId.addAll(hs);
							flag1 = asset.isVersionable();

							paramList = assetDao.getParamsByAsset(splitAssetName, conn);
							
							List<AssetParamDef> ldapmodifiedData = new ArrayList<AssetParamDef>();
							List<AssetParamDef> ldapmodifiedDataRemoval = new ArrayList<AssetParamDef>();
							for(AssetParamDef apd: paramList) {
								if(apd.getParamTypeId() == 9) {
									List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(apd.getLdapMappingId(), conn);
									for(LdapMapping ldapAttributes:ldapMapping) {
										AssetParamDef assetparam = new AssetParamDef();
										assetparam.setLdapMappingId(apd.getLdapMappingId());
										assetparam.setAssetParamName(apd.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
										assetparam.setParamTypeId(apd.getParamTypeId());
										ldapmodifiedData.add(assetparam);
									}
									ldapmodifiedDataRemoval.add(apd);
								}
							}
							if(!ldapmodifiedDataRemoval.isEmpty()) {
								paramList.removeAll(ldapmodifiedDataRemoval);
							}
							if(!ldapmodifiedData.isEmpty()) {
								paramList.addAll(ldapmodifiedData);
							}
							
							
							List<AssetParamDef> ldapparameter = new ArrayList<AssetParamDef>();
							List<AssetParamDef> ldapparameterRemoval = new ArrayList<AssetParamDef>();

							allCatsAndParamsForAsset = assetDao.getCategoryNameAndParametersByAssetId(asset.getAssetId(), conn);

							listAivo =  assetInstanceVersionDao.getAssetInstVerByAsset(splitAssetName, conn);

							allPossVals = new LinkedHashMap<String, List<String>>();
							List<AssetParamDef> filterList = new ArrayList<AssetParamDef>();
							for(int i=0; i<allCatsAndParamsForAsset.size(); i++)
							{
								if(allCatsAndParamsForAsset.get(i).getParamTypeId().equals(4L)){

									possValues = new ArrayList<String>();  

									if(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId().equals(1L)){

										filterList = assetDao.getFilterList(splitAssetName, allCatsAndParamsForAsset.get(i).getAssetParamName(), "CUSTOMLIST",userName,allCatsAndParamsForAsset.get(i).getMappedAssetId(),conn);

									}else if(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId().equals(2L)){

										filterList = assetDao.getFilterList(splitAssetName, allCatsAndParamsForAsset.get(i).getAssetParamName(), "ASSETLIST",userName,allCatsAndParamsForAsset.get(i).getMappedAssetId(),conn);

									}else if(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId().equals(3L)){

										filterList = assetDao.getFilterList(splitAssetName, allCatsAndParamsForAsset.get(i).getAssetParamName(), "NATIVEUSERLIST",userName,allCatsAndParamsForAsset.get(i).getMappedAssetId(),conn);

									}
									for(AssetParamDef assetParamDef:filterList){

										possValues.add(assetParamDef.getParamValue());

									}
									allPossVals.put(allCatsAndParamsForAsset.get(i).getAssetParamName(), possValues);
								
								}else if(allCatsAndParamsForAsset.get(i).getParamTypeId().equals(9L)) {
									
									ldapparameterRemoval.add(allCatsAndParamsForAsset.get(i));
									List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(allCatsAndParamsForAsset.get(i).getLdapMappingId(), conn);
									
									for(LdapMapping ldapAttributes:ldapMapping) {
										AssetParamDef assetparam = new AssetParamDef();
										assetparam.setAssetParamName(allCatsAndParamsForAsset.get(i).getAssetParamName());
										assetparam.setAssetParamId(allCatsAndParamsForAsset.get(i).getAssetParamId());
										assetparam.setAssetCategoryName(allCatsAndParamsForAsset.get(i).getAssetCategoryName());
										assetparam.setAssetCategoryId(allCatsAndParamsForAsset.get(i).getAssetCategoryId());
										assetparam.setMappedAssetId(allCatsAndParamsForAsset.get(i).getMappedAssetId());
										assetparam.setParamTypeId(allCatsAndParamsForAsset.get(i).getParamTypeId());
										assetparam.setListTypeParamTypeId(allCatsAndParamsForAsset.get(i).getListTypeParamTypeId());
										assetparam.setDerivedAttributeComputation(allCatsAndParamsForAsset.get(i).getDerivedAttributeComputation());
										assetparam.setSize(allCatsAndParamsForAsset.get(i).getSize());
										assetparam.setAssetParamId(allCatsAndParamsForAsset.get(i).getAssetParamId());
										assetparam.setHasStaticValue(allCatsAndParamsForAsset.get(i).isHasStaticValue());
										assetparam.setHasMandatoryValue(allCatsAndParamsForAsset.get(i).isHasMandatoryValue());
										assetparam.setHasArray(allCatsAndParamsForAsset.get(i).getHasArray());
										assetparam.setListType(allCatsAndParamsForAsset.get(i).getListType());
										assetparam.setLdapMappingId(allCatsAndParamsForAsset.get(i).getLdapMappingId());
										assetparam.setAssetParamName(allCatsAndParamsForAsset.get(i).getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
										assetparam.setParamTypeId(allCatsAndParamsForAsset.get(i).getParamTypeId());
										ldapparameter.add(assetparam);
									}
								}
							}
							if(!ldapparameterRemoval.isEmpty()) {
								allCatsAndParamsForAsset.removeAll(ldapparameterRemoval);
							}

							if(!ldapparameter.isEmpty()) {
								allCatsAndParamsForAsset.addAll(ldapparameter);
							}
						}

						String cell1= null, cell2 = null, cell3 = null , cell4 = null;

						XSSFRow rowb = sheet.getRow(rowNum++);

						XSSFCell cellbb = rowb.getCell(0);

						XSSFCell cellcc = rowb.getCell(1);

						XSSFCell celldd = rowb.getCell(2);

						XSSFCell cellee = rowb.getCell(3);

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellbb.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellbb.getNumericCellValue(); 
								cell1 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}
						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellcc.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellcc.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellcc.getStringCellValue();
							}
						}
						else
						{
							cell2 = "";
						}

						if(celldd != null)
						{
							if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = celldd.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val1 = (int)celldd.getNumericCellValue(); 
								cell3 = String.valueOf(val1); 
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = celldd.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}
						if(cellee != null)
						{
							if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell4 = cellee.getStringCellValue();
								if(cell4.length() == 0)
								{
									cell4 = "";  
								}
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellee.getNumericCellValue(); 
								cell4 = String.valueOf(val); 
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell4 = cellee.getStringCellValue();
							}
						}
						else
						{
							cell4 = "";
						}

						AssetInstance ai = new AssetInstance();
						ai.setAssetName(splitAssetName.trim());
						if(flag1 == true){

							ai.setVersionName(cell3.trim());
							ai.setVersionable(true);
						}
						else
						{
							if(cell3.equals("NA")){
								ai.setVersionName(Constants.DEFAULT_VERSION); 
								ai.setVersionable(false);
							}
							else{
								ai.setVersionName(cell3.trim()); 
								ai.setVersionable(false);
							}
						}
						ai.setAssetInstName(cell2.trim());
						ai.setParentAssetInstName(null);
						ai.setParentAssetName(null);

						AssetInstanceVersion avVo = new AssetInstanceVersion();

						avVo.setAssetName(ai.getAssetName().trim());
						avVo.setAssetInstName(cell2.trim());
						avVo.setVersionName(ai.getVersionName().trim());
						//AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
						//avVo.setAssetInstVersionId(aiv.getAssetInstVersionId());
						excelassetInstList.add(avVo);
						//listOfexcelassetInstList.put(ai.getAssetName(), excelassetInstList);

					}

					for(AssetInstanceVersion aivo:assetInstList)
					{
						Boolean flagForNotRemove = false;
						for(AssetInstanceVersion aiv:excelassetInstList)
						{
							if(aivo.getAssetName().equalsIgnoreCase(aiv.getAssetName())&& aivo.getAssetInstName().equalsIgnoreCase(aiv.getAssetInstName()) &&  aivo.getVersionName().equalsIgnoreCase(aiv.getVersionName()))
							{
								flagForNotRemove = true;
								break;
							}
						}
						if(!flagForNotRemove)
						{   
							aivo.setAction("delete");

						}
					}

					rows = sheet.rowIterator();

					while (rows.hasNext())
					{
						String currentExclRecStat = "none"; ///////ADDED
						AssetInstance prhVo = new AssetInstance();
						row = (XSSFRow) rows.next();
						int  rowNum = row.getRowNum();
						if(row.getRowNum() == 0)
						{
							XSSFRow rowb = sheet.getRow(rowNum++);
							XSSFCell cellaa = rowb.getCell(0);

							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									splitAssetName = cellaa.getStringCellValue();
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}
							}
							else
							{
								splitAssetName = "";
							}

							continue;   
						}

						if( row.getRowNum()==1 )
						{
							continue; 
						}

						String newParamDataForRevision = "";
						String cell1= null, cell2 = null, cell3 = null , cell4 = null;
						XSSFRow rowb = sheet.getRow(rowNum++);
						XSSFCell cellbb = rowb.getCell(0);
						XSSFCell cellcc = rowb.getCell(1);
						XSSFCell celldd = rowb.getCell(2);
						XSSFCell cellee = rowb.getCell(3);

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellbb.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellbb.getNumericCellValue(); 
								cell1 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}

						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellcc.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellcc.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellcc.getStringCellValue();
							}

						}
						else
						{
							cell2 = "";
						}

						if(celldd != null)
						{
							if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = celldd.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)celldd.getNumericCellValue(); 
								cell3 = String.valueOf(val); 
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = celldd.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}

						if(cellee != null)
						{
							if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell4 = cellee.getStringCellValue();
								if(cell4.length() == 0)
								{
									cell4 = "";  
								}
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{

								int val = (int)cellee.getNumericCellValue(); 
								cell4 = String.valueOf(val); 
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell4 = cellee.getStringCellValue();
							}
						}
						else
						{
							cell4 = "";
						}

						if(splitAssetName!= "" &&  cell1 != "" &&  cell2 != "" && cell3 != "" && cell4 != "")
						{
							cell1  = cell1.trim();
							cell2  = cell2.trim();
							cell3  = cell3.trim();
							cell4  = cell4.trim();
							splitAssetName  = splitAssetName.trim();

							if(cell1.length() > 20)
							{
								if (log.isErrorEnabled()) {
									log.error(" Asset Instance Version Id exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
								}
								errorsOnProc.add(" Asset Instance Version Id exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
							}
							if(cell2.length() > 100)
							{
								if (log.isErrorEnabled()) {
									log.error(" Asset Instance Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
								}
								errorsOnProc.add(" Asset Instance Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
							}
							if(cell3.length() > 10)
							{
								if (log.isErrorEnabled()) {
									log.error(" Asset Instance Version Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
								}
								errorsOnProc.add(" Asset Instance Version Name exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
							}
							if(cell4.length() > 50000)
							{
								if (log.isErrorEnabled()) {
									log.error(" Asset Instance Description exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
								}
								errorsOnProc.add(" Asset Instance Description exceeds max length for " + cell2+"_"+cell3+" at "+splitAssetName);
							}

							Boolean flagForValidation11 = false;
							String iCharsw = "!@#$%^&*()+=-[]\\\';,/{}|.\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWYZ]";
							for (int i = 0; i < cell1.length(); i++) 
							{
								if (iCharsw.indexOf(cell1.trim().charAt(i)) != -1) {
									flagForValidation11 = true;
									break;
								}
							}

							String iChars1 = "!%^*=[];{}|<>?~";
							Boolean flagForValidation1 = false;
							for (int k = 0; k < cell2.length(); k++) 
							{
								if (iChars1.indexOf(cell2.charAt(k)) != -1) 
								{
									flagForValidation1 = true;
									break;
								}
							}
							AssetInstance ai = new AssetInstance();
							ai.setAssetName(splitAssetName);
							Boolean flagForValidation2 = false;
							if(flag1 == true){
								String iChars2 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWXYZ]";
								for (int i = 0; i < cell3.length(); i++) 
								{
									if (iChars2.indexOf(cell3.trim().charAt(i)) != -1) 
									{
										flagForValidation2= true;
										break;
									}
								}
							}

							if(flagForValidation11)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets/Numeric not allowed for Asset Instance Version Id column except XXXX from "+ cell2+"_"+cell3+ " at "+splitAssetName);
								}
								errorsOnProc.add("Special Characters/Alphabets/Numeric not allowed for Asset Instance Version Id column except XXXX from "+ cell2+"_"+cell3+ " at "+splitAssetName);
							}
							if(flagForValidation1)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in " + cell2+" at "+splitAssetName);
								}
								errorsOnProc.add("Special Character not allowed in " + cell2+" at "+splitAssetName);
							}
							if( flagForValidation2)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed for version column " + cell2+"_"+cell3+ " at "+splitAssetName);
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed for version column " + cell2+"_"+cell3+ " at "+splitAssetName);
							}

							else
							{
								if(flag1 == true){

									if(cell3.matches("([0-9]{1})") || cell3.matches("([0-9]{1}.)"))
									{
										if (log.isErrorEnabled()) {
											log.error("Error : This Version Name format not allowed  for " + cell2+" at "+splitAssetName);
										}
										errorsOnProc.add("Error : This Version Name format not allowed  for " + cell2+" at "+splitAssetName);
									}
									ai.setVersionName(cell3);
									ai.setVersionable(true);
								}
								else
								{
									if(cell3.trim().equals("NA"))
									{
										ai.setVersionName(Constants.DEFAULT_VERSION); 
										ai.setVersionable(false);
									}
									else
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide valid Version Name in " + cell2+" at "+splitAssetName);
										}
										errorsOnProc.add("Please provide valid Version Name in " + cell2+" at "+splitAssetName); 
									}
								}
								ai.setAssetInstName(cell2);
								ai.setParentAssetInstName(null);
								ai.setParentAssetName(null);
								//	AssetInstanceVersion avVo = new AssetInstanceVersion();
								Boolean flag12 = false;
								Boolean flagforupdate = false;
								for(AssetInstanceVersion aivo:assetInstList)
								{
									if( aivo.getAssetInstVersionId().toString().equals(cell1) && aivo.getAssetInstName().equalsIgnoreCase(cell2) && aivo.getVersionName().equalsIgnoreCase(ai.getVersionName()))
									{
										aivo.setAction("update");
										//errorsOnProc.add("Error: Existing asset instance not allowed through excel import for incremental insert option: " + cell2+"_"+cell3+" of "+splitAssetName);
										flagforupdate = true;
										flag12 = true;
										break;
									}
								}
								Boolean flagdf = true;
								if(!flag12)
								{  
									if(!cell1.equals("XXXX"))
									{
										if (log.isErrorEnabled()) {
											log.error("Error Found : Please check " + cell1+","+cell2+","+cell3+" of "+splitAssetName+" Attribute sheet");
										}
										errorsOnProc.add("Error Found : Please check " + cell1+","+cell2+","+cell3+" of "+splitAssetName+" Attribute sheet");
									}

									for(AssetRelationshipDef relNm :relNameList)
									{
										if(relNm.getFwdRelationType().equals("composition") || relNm.getFwdRelationType().equals("aggregation"))
										{
											if(relNm.getDestAssetName().equalsIgnoreCase(ai.getAssetName()))
											{
												flagdf= false;
											}
										}

									}
									if(flagdf)
									{
										Boolean flagforChech = false;
										for(AssetInstanceVersion aivo:assetInstList)
										{
											if( aivo.getAction()!= null)
											{
												if( aivo.getAssetInstName().equalsIgnoreCase(cell2) && !aivo.getAction().equals("delete"))
												{
													flagforChech = true;
													break;
												}
											}
										}
										if(!flagforChech)
										{
											//avVo.setAssetName(ai.getAssetName());
											//avVo.setAssetInstName(cell2);
											//avVo.setVersionName(ai.getVersionName());
											//avVo.setAction("add");
											currentExclRecStat = "add";
											//assetInstList.add(avVo);
											if (log.isErrorEnabled()) {
												log.error("Error: New asset instance was found for Incremental Update in attribute sheet: " + cell2+"_"+cell3+" of "+splitAssetName);
											}
											errorsOnProc.add("Error: New asset instance was found for Incremental Update in attribute sheet: " + cell2+"_"+cell3+" of "+splitAssetName);

										}
										else
										{
											if (log.isErrorEnabled()) {
												log.error("Error: versions cannot be added through excel import option for Incremental Update in attribute sheet: " + cell2+"_"+cell3+" of "+splitAssetName);
											}
											errorsOnProc.add("Error: versions cannot be added through excel import option for Incremental Update in attribute sheet: " + cell2+"_"+cell3+" of "+splitAssetName);
										}
									}
								}
								if( !flagdf )
								{
									if (log.isErrorEnabled()) {
										log.error("Error: Creating Asset Instance not allowed at  " + cell2+"_"+cell3+" of "+splitAssetName + " since it is a child asset type.");
									}
									errorsOnProc.add("Error: Creating Asset Instance not allowed at  " + cell2+"_"+cell3+" of "+splitAssetName + " since it is a child asset type.");
								}

								Boolean flagCheck = false;

								for (int u=0;u< listAivo.size();u++)
								{ 
									if(listAivo.get(u).getDescription() != null){
										if(listAivo.get(u).getAssetInstName().equalsIgnoreCase(ai.getAssetInstName()) && listAivo.get(u).getVersionName().equalsIgnoreCase(ai.getVersionName())&& listAivo.get(u).getDescription().equals(cell4) ){
											flagCheck = true;
										}
									}
								}

								if(!flagCheck)
								{
									AssetInstDescSuccess aidVo = new AssetInstDescSuccess();

									aidVo.setAssetType(ai.getAssetName());
									aidVo.setAssetInstName(ai.getAssetInstName());
									aidVo.setAssetInstanceDescription(cell4);
									aidVo.setParentAssetName(ai.getParentAssetName());
									aidVo.setParentAssetInstanceName(ai.getParentAssetInstName());
									aidVo.setVersionName(ai.getVersionName());
									aisdVoList.add(aidVo);

								}

								int i = 5;
								int j = 0;
								int y = 0;
								Map<String,String> paramMapFromDb1 = new HashMap<String,String>();

								if(flagforupdate)
								{
									//boolean flagForExportAndImport = false;
									AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
									List<AssetParamDef> paramMap = new ArrayList<AssetParamDef>();
									List<AssetInstanceVersion> assetdata = assetInstanceVersionsManager.getParameter(ai.getAssetName(),userName,aiv1.getAssetInstVersionId(),conn);
									for(AssetInstanceVersion aiv: assetdata){
										AssetParamDef apd = new AssetParamDef();
										if (aiv.getIsStatic() == 1) {
											if (aiv.getParamTypeId() == 3) {
												apd.setAssetParamName(aiv.getAssetParamName());
												apd.setParamValue(aiv.getApdFileName());
											}else{
												apd.setAssetParamName(aiv.getAssetParamName());
												apd.setParamValue(aiv.getStaticValue());
											}

										} else {
											if (aiv.getParamTypeId() == 3) {
												apd.setAssetParamName(aiv.getAssetParamName());
												apd.setParamValue(aiv.getFileName());
											}else if(aiv.getParamTypeId() == 1){
												if(aiv.getTextDataList()!= null){
													String textdata = String.join("~~", aiv.getTextDataList());
													apd.setAssetParamName(aiv.getAssetParamName());
													apd.setParamValue(textdata);
												}else{
													apd.setAssetParamName(aiv.getAssetParamName());
													apd.setParamValue(aiv.getParamValue());
												}
											}else if(aiv.getParamTypeId() == 7){
												if(aiv.getRTFwithTags()!= null){
													String textdata = String.join("~~", aiv.getRTFwithTags());
													apd.setAssetParamName(aiv.getAssetParamName());
													apd.setParamValue(textdata);
												}else{
													apd.setAssetParamName(aiv.getAssetParamName());
													apd.setParamValue(aiv.getParamValue());
												}
											}else if(aiv.getParamTypeId() == 9){
												if(aiv.getLdapMappingValue() != null) {
													List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(aiv.getLdapMappingId(), conn);
													for (Map.Entry<String,Integer> entry : aiv.getLdapMappingValue().entrySet()){
														for(LdapMapping ldapAttributes:ldapMapping) {
															if(entry.getValue() == ldapAttributes.getLdapAttributeId()) {
																apd.setAssetParamName(aiv.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
															//	LdapMapping attribute = assetDao.getLdapMappingAttributeByattributeId(attributeId, conn);
																///List<String> values = aiv.getLdapMappingValue().keySet().stream().collect(Collectors.toList());
																apd.setParamValue(null);
															}
														}
													}
												}
											}else {
												apd.setAssetParamName(aiv.getAssetParamName());
												apd.setParamValue(aiv.getParamValue());
											}
										}
										paramMap.add(apd);
									}
									for (AssetParamDef assetdef : paramMap) paramMapFromDb1.put(assetdef.getAssetParamName(),assetdef.getParamValue());
								}
								List<String> paramNames = new ArrayList<String>() ;
								Collections.sort(paramList, new AssetParamDef());
								for (AssetParamDef pvo: paramList)
								{
									paramNames.add(pvo.getAssetParamName());
								}
								//Collections.sort(paramNames,String.CASE_INSENSITIVE_ORDER);
								Boolean pvalflag = false;
								List<String> ldapmappingdata = new ArrayList<String>();
								List<LdapMapping> ldapAttributeList = new ArrayList<LdapMapping>();
								List<String> ldapmappingfirstattributedata = new ArrayList<String>();
								int ldapcount = 0;
								for (String  paramName: paramNames)
								{
									AssetParamSuccess apsVo = new AssetParamSuccess();
									AssetParamSuccess apevo = new AssetParamSuccess();
									String paramVal = null;
									Boolean flag = false;
									for(AssetParamDef aiv:allCatsAndParamsForAsset)
									{ 
										if(aiv.getAssetParamName().equalsIgnoreCase(paramName)){
											XSSFCell cellee1 = rowb.getCell(i++);
											if(cellee1 != null )
											{
												if (cellee1.getCellType() == XSSFCell.CELL_TYPE_STRING)
												{
													paramVal = cellee1.getStringCellValue().trim();
													if(paramVal.length() == 0)
													{
														paramVal = "";  
													}
												}
												if (cellee1.getCellType() == XSSFCell.CELL_TYPE_BLANK)
												{
													paramVal = cellee1.getStringCellValue().trim();
													if(paramVal.length() == 0)
													{
														paramVal = "";  
													}
												}
												else if(cellee1.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
												{
													int val = (int)cellee1.getNumericCellValue(); 
													paramVal = String.valueOf(val); 
												}
											}
											else
											{
												paramVal = "";
											}
											Boolean chkFilePrmValFlag1 = false;
											if(flagforupdate)
											{
												for (Map.Entry<String, String> entry1 : paramMapFromDb1.entrySet()) {
													if(paramName.equalsIgnoreCase(entry1.getKey())){
														if(/*(paramVal.isEmpty() && entry1.getValue() == null) || */(paramVal.equals(entry1.getValue())) ){
															chkFilePrmValFlag1 = true;
															break;
														}
													}
												}	
											}
											if(flagforupdate ||(paramVal != "" && paramVal != null)){
												if(!chkFilePrmValFlag1||(aiv.isHasMandatoryValue() && paramVal.equalsIgnoreCase(""))){
													pvalflag = true;
													if(aiv.getParamTypeId().equals(4L))
													{
														if(aiv.getListTypeParamTypeId()!=null)
														{
															if((aiv.getListTypeParamTypeId().equals(1L)))
															{
																if(globalsetting.getGlobalSettingFlag() == 1){
																	paramVal = commonUtils.httpSanitizerForPlainText(paramVal);
																	//paramVal = StringEscapeUtils.escapeHtml4(paramVal);
																}
																possValues = null;
																for (Entry<String, List<String>> allpvals : allPossVals.entrySet())
																{
																	if(allpvals.getKey().equalsIgnoreCase(paramName))
																		possValues = allpvals.getValue();
																}

																boolean listflag = false;
																if(!paramVal.equalsIgnoreCase("")){
																	if(paramVal.contains("~~") && aiv.getListType() == 0){
																		listflag = false;
																		apevo.setErrorMessage(" multiple values are not allowed ");
																	}else if(paramVal.endsWith("~~")){
																		listflag = false;
																	}else{
																		List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																		boolean duplicateFlag = false;
																		Set<String> duplicate = new HashSet<String>();
																		duplicate.addAll(paramValList);
																		if(duplicate.size()<paramValList.size()){
																			duplicateFlag = true;
																		}
																		if(duplicateFlag == false){
																			int count = 0;
																			for(int k=0;k<possValues.size();k++){  
																				for(int l = 0; l < paramValList.size(); l++){
																					if (possValues.get(k).equals(paramValList.get(l))) {
																						count++;
																					}
																				}
																				if(count == paramValList.size()){
																					listflag = true;
																					break;
																				}
																			}
																		}
																	}
																}
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){
																		listflag = true;
																	}
																}
																if(listflag == true)
																{     
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																	break;
																}
																if(flag == false)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}

															if((aiv.getListTypeParamTypeId().equals(2L))){
																possValues = null;
																for (Entry<String, List<String>> allpvals : allPossVals.entrySet())
																{
																	if(allpvals.getKey().equalsIgnoreCase(paramName))
																		possValues = allpvals.getValue();
																}
																boolean listflag = false;
																if(!paramVal.equalsIgnoreCase("")){
																	if(paramVal.contains("~~") && aiv.getListType() == 0){
																		listflag = false;
																		apevo.setErrorMessage(" multiple values are not allowed ");
																	}else if(paramVal.endsWith("~~")){
																		listflag = false;
																	}else{
																		List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																		boolean duplicateFlag = false;
																		Set<String> duplicate = new HashSet<String>();
																		duplicate.addAll(paramValList);
																		if(duplicate.size()<paramValList.size()){
																			duplicateFlag = true;
																		}
																		if(duplicateFlag == false){
																			int count = 0;
																			for(int k=0;k<possValues.size();k++){  
																				for(int l = 0; l < paramValList.size(); l++){
																					if (possValues.get(k).equals(paramValList.get(l))) {
																						count++;
																					}
																				}
																				if(count == paramValList.size()){
																					listflag = true;
																					break;
																				}
																			}
																		}
																	}
																}
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){
																		listflag = true;
																	}
																}
																if(listflag == true)
																{    
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																	break;
																}
																if(flag == false)
																{
																	if(apevo.getParamValue() != paramVal)
																	{
																		apevo.setAssetType(ai.getAssetName());
																		apevo.setAssetInstName(ai.getAssetInstName());
																		apevo.setVersionName(ai.getVersionName());
																		apevo.setParentAssetName(ai.getParentAssetName());
																		apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apevo.setVersionable(ai.isVersionable());
																		apevo.setParamTypeName(aiv.getTypeName());
																		apevo.setCatName(aiv.getAssetCategoryName());
																		apevo.setParamTypeId(aiv.getParamTypeId());
																		apevo.setParamName(paramName);
																		apevo.setParamValue(paramVal);
																		apevo.setAssetParamId(aiv.getAssetParamId());
																		apeVoList.add(apevo);
																	}
																}
															}

															if((aiv.getListTypeParamTypeId().equals(3L)))
															{
																possValues = null;
																for (Entry<String, List<String>> allpvals : allPossVals.entrySet())
																{
																	if(allpvals.getKey().equalsIgnoreCase(paramName))
																		possValues = allpvals.getValue();
																}
																boolean listflag = false;
																if(!paramVal.equalsIgnoreCase("")){
																	if(paramVal.contains("~~") && aiv.getListType() == 0){
																		listflag = false;
																		apevo.setErrorMessage(" multiple values are not allowed ");
																	}else if(paramVal.endsWith("~~")){
																		listflag = false;
																	}else{
																		List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																		boolean duplicateFlag = false;
																		Set<String> duplicate = new HashSet<String>();
																		duplicate.addAll(paramValList);
																		if(duplicate.size()<paramValList.size()){
																			duplicateFlag = true;
																		}
																		if(duplicateFlag == false){
																			int count = 0;
																			for(int k=0;k<possValues.size();k++){  
																				for(int l = 0; l < paramValList.size(); l++){
																					if (possValues.get(k).equals(paramValList.get(l))) {
																						count++;
																					}
																				}
																				if(count == paramValList.size()){
																					listflag = true;
																					break;
																				}
																			}
																		}
																	}
																}
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){
																		listflag = true;
																	}
																}
																if(listflag == true)
																{     
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																	break;
																}
																if(flag == false)
																{
																	if(apevo.getParamValue() != paramVal){
																		apevo.setAssetType(ai.getAssetName());
																		apevo.setAssetInstName(ai.getAssetInstName());
																		apevo.setVersionName(ai.getVersionName());
																		apevo.setParentAssetName(ai.getParentAssetName());
																		apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apevo.setVersionable(ai.isVersionable());
																		apevo.setParamTypeName(aiv.getTypeName());
																		apevo.setCatName(aiv.getAssetCategoryName());
																		apevo.setParamTypeId(aiv.getParamTypeId());
																		apevo.setParamName(paramName);
																		apevo.setParamValue(paramVal);
																		apevo.setAssetParamId(aiv.getAssetParamId());
																		apeVoList.add(apevo);
																	}
																}
															}
															if((aiv.getListTypeParamTypeId().equals(4L)))
															{
																/*if(ai.isVersionable()){
																	invalidLdapIds.add("Skipped "+paramName+" under "+aiv.getAssetCategoryName()+" for asset instance "+ai.getAssetInstName()+"_"+ai.getVersionName()+" for "+ai.getAssetName()+" ,since it is ldap userlist Type\n");	 
																}else{
																	invalidLdapIds.add("Skipped "+paramName+" under "+aiv.getAssetCategoryName()+" for asset instance "+ai.getAssetInstName()+"_"+ai.getVersionName()+" for "+ai.getAssetName()+" ,since it is ldap userlist Type\n");	 
																}*/
																
																
																boolean listflag = false;
																//boolean zerolistflag = false;
																boolean invaliddataflag = false;
																if(!paramVal.equalsIgnoreCase("")){
																	if(paramVal.contains("~~") && aiv.getListType() == 0){
																		listflag = false;
																		apevo.setErrorMessage(" multiple values are not allowed ");
																	}else if(paramVal.endsWith("~~")){
																		listflag = false;
																	}else{
																		List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																		List<String> paramValList = new ArrayList<String>();
																		List<String> finalparamValList = new ArrayList<String>();
																		List<String> names = new ArrayList<String>();
																		List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
																		for(String data:firstParamValList){
																			if(data.contains("(") && data.contains(")")){
																				//fetching search string from saved result
																				String result = data.substring(data.indexOf("(") + 1, data.indexOf(")"));
																				names.add(data);
																				paramValList.add(result);
																			}else if(data.contains("(") || data.contains(")")){
																				invaliddataflag = true;
																				listflag = false;
																				break;
																			}else{
																				paramValList.add(data);
																			}
																		}
																		boolean duplicateFlag = false;
																		Set<String> duplicate = new HashSet<String>();
																		duplicate.addAll(paramValList);
																		if(duplicate.size()<paramValList.size()){
																			duplicateFlag = true;
																		}
																		if(invaliddataflag == false){
																			if(duplicateFlag == false){
																				LDAPConnection ldapConnection = LDAPConnection.getInstance();
																				DirContext dirContext = ldapConnection.getDirContext();
																				for(String data:paramValList){
																					listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,data);
																					/*zerolistflag = false;
																				if(listOfLDAPUsers.size() == 0){
																					zerolistflag = true;
																					//invalid search string(ignore the result related to invalid string)
																					if(ai.isVersionable()){
																						invalidLdapIds.add(data+" search string did not reterieve any result,So could not update "+paramName+" value under "+aiv.getAssetCategoryName()+" for asset instance "+ai.getAssetInstName()+"_"+ai.getVersionName()+" for "+ai.getAssetName()+"\n");	 
																					}else{
																						invalidLdapIds.add(data+" search string did not reterieve any result,So could not update "+paramName+" value under "+aiv.getAssetCategoryName()+" for asset instance "+ai.getAssetInstName()+" for "+ai.getAssetName()+"\n");	 
																					}
																				}else */if(listOfLDAPUsers.size() == 1){
																					for(LDAPUser finaldata:listOfLDAPUsers){
																						//invalid firstname validation,If invalid throw an error as invalid data
																						for(String name:names){
																							if(name.contains("(")){
																								String result = name.substring(name.indexOf("(") + 1, name.indexOf(")"));
																								String fullname = name.substring(0,name.indexOf("("));
																								if(result.equalsIgnoreCase(finaldata.getUserId())){
																									if(!fullname.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																										invaliddataflag = true;
																										break;
																									}
																								}
																							}
																						}
																						if(invaliddataflag == true){
																							listflag = false;
																							break;
																						}else{
																							String val = finaldata.getFirstName()+" "+finaldata.getLastName()+"("+finaldata.getUserId()+")";
																							finalparamValList.add(val);
																							listflag = true;
																						}
																					}
																				}else{
																					listflag = false;
																					break;
																				}
																				}
																				if(!finalparamValList.isEmpty()){
																					paramVal = String.join("~~", finalparamValList);
																				}
																			}
																		}
																	}
																}
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){
																		listflag = true;
																	}
																}
																
																if(listflag == true)
																{     
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																	break;
																}
																//if(zerolistflag == false){
																	if(flag == false)
																	{
																		if(apevo.getParamValue() != paramVal){
																			apevo.setAssetType(ai.getAssetName());
																			apevo.setAssetInstName(ai.getAssetInstName());
																			apevo.setVersionName(ai.getVersionName());
																			apevo.setParentAssetName(ai.getParentAssetName());
																			apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																			apevo.setVersionable(ai.isVersionable());
																			apevo.setParamTypeName(aiv.getTypeName());
																			apevo.setCatName(aiv.getAssetCategoryName());
																			apevo.setParamTypeId(aiv.getParamTypeId());
																			apevo.setParamName(paramName);
																			apevo.setParamValue(paramVal);
																			apevo.setAssetParamId(aiv.getAssetParamId());
																			apeVoList.add(apevo);
																		}
																	}
																//}
															}
														}
													}
													else if((aiv.getParamTypeId().equals(2L)))
													{
														if (paramVal.matches("(^(((0[1-9]|[12][0-8])[/](0[1-9]|1[012]))|((29|30|31)[/](0[13578]|1[02]))|((29|30)[/](0[4,6,9]|11)))[/](19|[2-9][0-9])\\d\\d$)|(^29[/]02[/](19|[2-9][0-9])(00|04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)$)") || paramVal.equalsIgnoreCase("")) {
															if(paramVal != ""){
																String[] words = paramVal.split("/");
																int num = Integer.parseInt(words[2]);
																if(num > 2999)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
																else
																{
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																}
															}
															else
															{
																if(!aiv.isHasMandatoryValue()){
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVoList.add(apsVo);
																	flag = true;
																}
																if(flag == false)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}
														}
														else
														{
															apevo.setAssetType(ai.getAssetName());
															apevo.setAssetInstName(ai.getAssetInstName());
															apevo.setVersionName(ai.getVersionName());
															apevo.setParentAssetName(ai.getParentAssetName());
															apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
															apevo.setVersionable(ai.isVersionable());
															apevo.setParamTypeName(aiv.getTypeName());
															apevo.setCatName(aiv.getAssetCategoryName());
															apevo.setParamTypeId(aiv.getParamTypeId());
															apevo.setParamName(paramName);
															apevo.setParamValue(paramVal);
															apevo.setAssetParamId(aiv.getAssetParamId());
															apeVoList.add(apevo);
														}
													}
													else if((aiv.getParamTypeId().equals(1L)))
													{
														boolean nonStaticCheck = true;
														if(globalsetting.getGlobalSettingFlag() == 1){
															paramVal = commonUtils.httpSanitizerForPlainText(paramVal);
														}
														if(paramVal.startsWith("~~")||paramVal.endsWith("~~")){
															nonStaticCheck = false;
														}else if(aiv.isHasStaticValue()){
															if(paramVal.contains("~~")){
																nonStaticCheck = false;
																apevo.setErrorMessage(" multiple values are not allowed since parameter type is static! ");
															}
														}else if(aiv.getHasArray() == 0){
															if(paramVal.contains("~~")){
																nonStaticCheck = false;
																apevo.setErrorMessage(" multiple values are not allowed ");
															}
														}
														if(nonStaticCheck == true){
															if(!paramVal.equalsIgnoreCase(""))
															{
																if(paramList.size()-1 == y)
																{
																	newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																}
																else{
																	newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																}
																apsVo.setAssetType(ai.getAssetName());
																apsVo.setAssetInstName(ai.getAssetInstName());
																apsVo.setVersionName(ai.getVersionName());
																apsVo.setParentAssetName(ai.getParentAssetName());
																apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apsVo.setParamTypeName(aiv.getTypeName());
																apsVo.setCatName(aiv.getAssetCategoryName());
																apsVo.setParamTypeId(aiv.getParamTypeId());
																apsVo.setParamName(paramName);
																//apsVo.setParamValue(paramVal);
																apsVo.setHasStaticValue(aiv.isHasStaticValue());
																apsVo.setHasArray(aiv.getHasArray());
																apsVo.setAssetParamId(aiv.getAssetParamId());
																boolean sizecheck = true;
																if(aiv.isHasStaticValue()){
																	apsVo.setParamValue(paramVal);
																	if(paramVal.length()>(aiv.getSize())){
																		sizecheck = false;
																	}
																	apsVoList.add(apsVo);
																	if(sizecheck == true){
																		flag = true;
																	}
																}else if(aiv.getHasArray() == 0){
																	apsVo.setParamValue(paramVal);
																	if(paramVal.length()>(aiv.getSize())){
																		sizecheck = false;
																	}
																	apsVoList.add(apsVo);
																	if(sizecheck == true){
																		flag = true;
																	}
																}else{
																	List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																	boolean emptyCheck = true;
																	for(String data:paramValList){
																		String val = data.trim();
																		if(val.equalsIgnoreCase("")){
																			emptyCheck = false;
																			break;
																		}
																	}
																	if(emptyCheck == true){
																		apsVo.setTextDataList(paramValList);
																		for(String data:apsVo.getTextDataList()){
																			if(data.length()>(aiv.getSize())){
																				sizecheck = false;
																				break;
																			}
																		}
																		apsVoList.add(apsVo);
																		if(sizecheck == true){
																			flag = true;
																		}
																	}
																}
															}else { 
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){

																		if(paramList.size()-1 == y)
																		{
																			newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																		}
																		else{
																			newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																		}
																		apsVo.setAssetType(ai.getAssetName());
																		apsVo.setAssetInstName(ai.getAssetInstName());
																		apsVo.setVersionName(ai.getVersionName());
																		apsVo.setParentAssetName(ai.getParentAssetName());
																		apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apsVo.setParamTypeName(aiv.getTypeName());
																		apsVo.setCatName(aiv.getAssetCategoryName());
																		apsVo.setParamTypeId(aiv.getParamTypeId());
																		apsVo.setParamName(paramName);
																		if(aiv.isHasStaticValue()){
																			apsVo.setParamValue(paramVal);
																		}else if(aiv.getHasArray() == 0){
																			apsVo.setParamValue(paramVal);
																		}else{
																			List<String> paramValList = new ArrayList<String>();
																			apsVo.setTextDataList(paramValList);;
																		}
																		apsVo.setHasStaticValue(aiv.isHasStaticValue());
																		apsVo.setHasArray(aiv.getHasArray());
																		apsVo.setAssetParamId(aiv.getAssetParamId());
																		apsVoList.add(apsVo);
																		flag = true;
																	}
																}
															}
															if(flag == false)
															{

																apevo.setAssetType(ai.getAssetName());
																apevo.setAssetInstName(ai.getAssetInstName());
																apevo.setVersionName(ai.getVersionName());
																apevo.setParentAssetName(ai.getParentAssetName());
																apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apevo.setVersionable(ai.isVersionable());
																apevo.setParamTypeName(aiv.getTypeName());
																apevo.setCatName(aiv.getAssetCategoryName());
																apevo.setParamTypeId(aiv.getParamTypeId());
																apevo.setParamName(paramName);
																apevo.setParamValue(paramVal);
																apevo.setAssetParamId(aiv.getAssetParamId());
																apeVoList.add(apevo);
															}
														}else{

															apevo.setAssetType(ai.getAssetName());
															apevo.setAssetInstName(ai.getAssetInstName());
															apevo.setVersionName(ai.getVersionName());
															apevo.setParentAssetName(ai.getParentAssetName());
															apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
															apevo.setVersionable(ai.isVersionable());
															apevo.setParamTypeName(aiv.getTypeName());
															apevo.setCatName(aiv.getAssetCategoryName());
															apevo.setParamTypeId(aiv.getParamTypeId());
															apevo.setParamName(paramName);
															apevo.setParamValue(paramVal);
															apevo.setAssetParamId(aiv.getAssetParamId());
															apeVoList.add(apevo);
														
														}
													}
													else if((aiv.getParamTypeId().equals(5L))||aiv.getParamTypeId().equals(6L)||aiv.getParamTypeId().equals(8L))
													{
														flag = true;
													}
													else if((aiv.getParamTypeId().equals(7L)))
													{
														boolean nonStaticCheck = true;
														if(globalsetting.getGlobalSettingFlag() == 1){
															paramVal = commonUtils.httpSanitizerForCkEditor(paramVal);
														}
														if(paramVal.startsWith("~~")||paramVal.endsWith("~~")){
															nonStaticCheck = false;
														}else if(aiv.isHasStaticValue()){
															if(paramVal.contains("~~")){
																nonStaticCheck = false;
																apevo.setErrorMessage(" multiple values are not allowed since parameter type is static! ");
															}
														}else if(aiv.getHasArray() == 0){
															if(paramVal.contains("~~")){
																nonStaticCheck = false;
																apevo.setErrorMessage(" multiple values are not allowed ");
															}
														}
														if(nonStaticCheck == true){
															if(!paramVal.equalsIgnoreCase("")){
																if(paramList.size()-1 == y)
																{
																	newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																}
																else{
																	newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																}
																apsVo.setAssetType(ai.getAssetName());
																apsVo.setAssetInstName(ai.getAssetInstName());
																apsVo.setVersionName(ai.getVersionName());
																apsVo.setParentAssetName(ai.getParentAssetName());
																apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apsVo.setParamTypeName(aiv.getTypeName());
																apsVo.setCatName(aiv.getAssetCategoryName());
																apsVo.setParamTypeId(aiv.getParamTypeId());
																apsVo.setListTypeParamTypeId(aiv.getListTypeParamTypeId());
																apsVo.setParamName(paramName);
																boolean sizecheck = true;
																if(aiv.isHasStaticValue()){
																	apsVo.setParamValue(paramVal);
																	if(paramVal.length()>25000){
																		sizecheck = false;
																	}
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVo.setHasArray(aiv.getHasArray());
																	apsVoList.add(apsVo);
																	if(sizecheck == true){
																		flag = true;
																	}
																}else if(aiv.getHasArray() == 0){
																	apsVo.setParamValue(paramVal);
																	if(paramVal.length()>25000){
																		sizecheck = false;
																	}
																	String textdata = Jsoup.parse(paramVal).text();
																	apsVo.setRTFPlainText(textdata);
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVo.setHasArray(aiv.getHasArray());
																	apsVoList.add(apsVo);
																	if(sizecheck == true){
																		flag = true;
																	}
																}else{
																	List<String> paramValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																	boolean emptyCheck = true;
																	for(String data:paramValList){
																		String val = data.trim();
																		if(val.equalsIgnoreCase("")){
																			emptyCheck = false;
																			break;
																		}
																	}
																	if(emptyCheck == true){
																		apsVo.setRTFwithTags(paramValList);
																		List<String> withOuttags = new ArrayList<String>();
																		for(String data:apsVo.getRTFwithTags()){
																			if(data.length()>25000){
																				sizecheck = false;
																				break;
																			}
																			String textdata = Jsoup.parse(data).text();
																			withOuttags.add(textdata);
																		}
																		apsVo.setRTFwithOutTags(withOuttags);
																		apsVo.setAssetParamId(aiv.getAssetParamId());
																		apsVo.setHasStaticValue(aiv.isHasStaticValue());
																		apsVo.setHasArray(aiv.getHasArray());
																		apsVoList.add(apsVo);
																		if(sizecheck == true){
																			flag = true;
																		}
																	}
																}
															}else{
																if(!aiv.isHasMandatoryValue()){
																	if(paramVal.equalsIgnoreCase("")){

																		if(paramList.size()-1 == y)
																		{
																			newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal;
																		}
																		else{
																			newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																		}
																		apsVo.setAssetType(ai.getAssetName());
																		apsVo.setAssetInstName(ai.getAssetInstName());
																		apsVo.setVersionName(ai.getVersionName());
																		apsVo.setParentAssetName(ai.getParentAssetName());
																		apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																		apsVo.setParamTypeName(aiv.getTypeName());
																		apsVo.setCatName(aiv.getAssetCategoryName());
																		apsVo.setParamTypeId(aiv.getParamTypeId());
																		apsVo.setParamName(paramName);
																		apsVo.setParamValue(paramVal);
																		apsVo.setHasStaticValue(aiv.isHasStaticValue());
																		apsVo.setHasArray(aiv.getHasArray());
																		apsVo.setAssetParamId(aiv.getAssetParamId());
																		if(aiv.isHasStaticValue()){
																			apsVo.setParamValue(paramVal);
																			apsVoList.add(apsVo);
																			flag = true;
																		}else if(aiv.getHasArray() == 0){
																			apsVo.setParamValue(paramVal);
																			apsVo.setRTFPlainText(paramVal);
																			apsVoList.add(apsVo);
																			flag = true;
																		}else{
																			List<String> paramValList = new ArrayList<String>();
																			paramValList.add(paramVal);
																			apsVo.setRTFwithTags(paramValList);
																			List<String> withOuttags = new ArrayList<String>();
																			withOuttags.add(paramVal);
																			apsVo.setRTFwithOutTags(withOuttags);
																			apsVoList.add(apsVo);
																			flag = true;
																		}
																	}
																}
															}
															if(flag == false)
															{
																apevo.setAssetType(ai.getAssetName());
																apevo.setAssetInstName(ai.getAssetInstName());
																apevo.setVersionName(ai.getVersionName());
																apevo.setParentAssetName(ai.getParentAssetName());
																apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apevo.setVersionable(ai.isVersionable());
																apevo.setParamTypeName(aiv.getTypeName());
																apevo.setCatName(aiv.getAssetCategoryName());
																apevo.setParamTypeId(aiv.getParamTypeId());
																apevo.setParamName(paramName);
																apevo.setParamValue(paramVal);
																apevo.setAssetParamId(aiv.getAssetParamId());
																apeVoList.add(apevo);
															}
														}else{

															apevo.setAssetType(ai.getAssetName());
															apevo.setAssetInstName(ai.getAssetInstName());
															apevo.setVersionName(ai.getVersionName());
															apevo.setParentAssetName(ai.getParentAssetName());
															apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
															apevo.setVersionable(ai.isVersionable());
															apevo.setParamTypeName(aiv.getTypeName());
															apevo.setCatName(aiv.getAssetCategoryName());
															apevo.setParamTypeId(aiv.getParamTypeId());
															apevo.setParamName(paramName);
															apevo.setParamValue(paramName);
															apevo.setAssetParamId(aiv.getAssetParamId());
															apeVoList.add(apevo);
														}
													}else if(aiv.getParamTypeId().equals(9L)) {
														
														if(ldapcount == ldapAttributeList.size()) {
															ldapmappingdata.clear();
															ldapmappingfirstattributedata.clear();
															ldapcount = 0;
															ldapDuplicateCount = 0;
														}
														
														String ldapParameter = null; 
														Map<String,Integer> finalParamValList = new LinkedHashMap<String,Integer>();
														String[] ldapMappingParameter = paramName.split("_", 2);
														if(ldapDuplicateCount == 0) {
															ldapAttributeList = assetDao.getLdapMappingAttributeList(aiv.getLdapMappingId(), conn);
															ldapParameter = ldapMappingParameter[0];
															String attribute = ldapMappingParameter[1];
															String attributeName = "";
															for(LdapMapping displayName:ldapAttributeList) {
																if(displayName.getAttributeDisplayName().equalsIgnoreCase(attribute)) {
																	attributeName = displayName.getAttributeName().substring(3);
																}
															}
															ldapDuplicateCount++;
															ldapcount++;
															boolean listflag = false;
															//boolean zerolistflag = false;
															boolean invaliddataflag = false;
															if(!paramVal.equalsIgnoreCase("")){
																if(paramVal.contains("~~") && aiv.getListType() == 0){
																	listflag = false;
																	apevo.setErrorMessage(" multiple values are not allowed ");
																}else if(paramVal.endsWith("~~")){
																	listflag = false;
																}else{
																	List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																	List<String> paramValList = new ArrayList<String>();
																	List<String> finalparamValList = new ArrayList<String>();
																	List<String> names = new ArrayList<String>();
																	List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
																	for(String data:firstParamValList){
																		if(data.contains("(") && data.contains(")")){
																			//fetching search string from saved result
																			String result = data.substring(data.indexOf("(") + 1, data.indexOf(")"));
																			names.add(data);
																			paramValList.add(result);
																		}else if(data.contains("(") || data.contains(")")){
																			invaliddataflag = true;
																			listflag = false;
																			break;
																		}else{
																			paramValList.add(data);
																		}
																	}
																	boolean duplicateFlag = false;
																	Set<String> duplicate = new HashSet<String>();
																	duplicate.addAll(paramValList);
																	if(duplicate.size()<paramValList.size()){
																		duplicateFlag = true;
																	}
																	ldapmappingfirstattributedata.addAll(paramValList);
																	if(invaliddataflag == false){
																		if(duplicateFlag == false){
																			LDAPConnection ldapConnection = LDAPConnection.getInstance();
																			DirContext dirContext = ldapConnection.getDirContext();
																			for(String data:paramValList){
																				listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,data);
																				if(listOfLDAPUsers.size() == 1){
																					for(LDAPUser finaldata:listOfLDAPUsers){
																						int count = 0;
																						
																						if(attributeName.equalsIgnoreCase(commonUtils.LdapFirstName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapLastName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getLastName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapEmail)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getEmail())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapDept)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getDept())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapUserId)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getUserId())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapFullName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}
																						
																						
																						//invalid firstname validation,If invalid throw an error as invalid data
																						for(String name:names){
																							if(name.contains("(")){
																								String result = name.substring(name.indexOf("(") + 1, name.indexOf(")"));
																								String fullname = name.substring(0,name.indexOf("("));
																								if(result.equalsIgnoreCase(finaldata.getUserId())){
																									if(!fullname.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																										invaliddataflag = true;
																										break;
																									}
																								}
																							}
																						}
																						if(invaliddataflag == true){
																							listflag = false;
																							break;
																						}else{
																							String val = finaldata.getUserId();
																							finalparamValList.add(val);
																							listflag = true;
																						}
																					}
																				}else{
																					listflag = false;
																					break;
																				}
																			}
																			if(!finalparamValList.isEmpty()){
																				String ldapfinalstring = String.join("~~", finalparamValList);
																				finalParamValList = commonUtils.ldapDataconstruction(ldapfinalstring,ai.getAssetName(),ldapParameter,conn);
																				ldapmappingdata = finalParamValList.keySet().stream().collect(Collectors.toList());
																				paramVal = String.join("``", ldapmappingdata);
																			}
																		}
																	}
																}
															}
															if(!aiv.isHasMandatoryValue()){
																if(paramVal.equalsIgnoreCase("")){
																	listflag = true;
																}
															}

															if(listflag == true)
															{     
																if(paramList.size()-1 == y)
																{
																	newParamDataForRevision = newParamDataForRevision + ldapParameter+":"+ paramVal;
																}
																else{
																	newParamDataForRevision = newParamDataForRevision +ldapParameter+":"+ paramVal+Constants.APPEND_STRING;	
																}
																apsVo.setAssetType(ai.getAssetName());
																apsVo.setAssetInstName(ai.getAssetInstName());
																apsVo.setVersionName(ai.getVersionName());
																apsVo.setParentAssetName(ai.getParentAssetName());
																apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																apsVo.setParamTypeName(aiv.getTypeName());
																apsVo.setCatName(aiv.getAssetCategoryName());
																apsVo.setParamTypeId(aiv.getParamTypeId());
																apsVo.setParamName(ldapParameter);
																apsVo.setParamValue(paramVal);
																apsVo.setLdapMappingValue(finalParamValList);
																apsVo.setAssetParamId(aiv.getAssetParamId());
																apsVo.setHasStaticValue(aiv.isHasStaticValue());
																apsVoList.add(apsVo);
																flag = true;
																break;
															}
															//if(zerolistflag == false){
															if(flag == false)
															{
																if(apevo.getParamValue() != paramVal){
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}
														}else {
															ldapcount++;
															//ldapAttributeList = assetDao.getLdapMappingAttributeList(aiv.getLdapMappingId(), conn);
															ldapParameter = ldapMappingParameter[0];
															String attribute = ldapMappingParameter[1];
															String attributeName = "";
															for(LdapMapping displayName:ldapAttributeList) {
																if(displayName.getAttributeDisplayName().equalsIgnoreCase(attribute)) {
																	attributeName = displayName.getAttributeName().substring(3);
																}
															}
															
															boolean listflag = false;
															//boolean zerolistflag = false;
															boolean invaliddataflag = false;
															if(!paramVal.equalsIgnoreCase("")){
																if(paramVal.contains("~~") && aiv.getListType() == 0){
																	listflag = false;
																	apevo.setErrorMessage(" multiple values are not allowed ");
																}else if(paramVal.endsWith("~~")){
																	listflag = false;
																}else{
																	List<String> firstParamValList = new ArrayList<String>(Arrays.asList(paramVal.split("~~")));
																	List<String> paramValList = new ArrayList<String>();
																	List<String> finalparamValList = new ArrayList<String>();
																	List<String> names = new ArrayList<String>();
																	List<LDAPUser> listOfLDAPUsers = new ArrayList<LDAPUser>();
																	for(String data:firstParamValList){
																		if(data.contains("(") && data.contains(")")){
																			//fetching search string from saved result
																			String result = data.substring(data.indexOf("(") + 1, data.indexOf(")"));
																			names.add(data);
																			paramValList.add(result);
																		}else if(data.contains("(") || data.contains(")")){
																			invaliddataflag = true;
																			listflag = false;
																			break;
																		}else{
																			paramValList.add(data);
																		}
																	}
																	boolean duplicateFlag = false;
																	Set<String> duplicate = new HashSet<String>();
																	duplicate.addAll(paramValList);
																	if(duplicate.size()<paramValList.size()){
																		duplicateFlag = true;
																	}
																	if(invaliddataflag == false){
																		if(duplicateFlag == false){
																			LDAPConnection ldapConnection = LDAPConnection.getInstance();
																			DirContext dirContext = ldapConnection.getDirContext();
																			for(String data:ldapmappingfirstattributedata){
																				listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,data);
																				if(listOfLDAPUsers.size() == 1){
																					for(LDAPUser finaldata:listOfLDAPUsers){
																						int count = 0;
																						if(attributeName.equalsIgnoreCase(commonUtils.LdapFirstName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapLastName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getLastName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapEmail)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getEmail())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapDept)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getDept())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapUserId)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getUserId())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}else if(attributeName.equalsIgnoreCase(commonUtils.LdapFullName)) {
																							for(String ldapdata:firstParamValList) {
																								if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																									count++;
																								}
																								if(count == firstParamValList.size()) {
																									invaliddataflag = true;
																									break;
																								}
																							}
																						}
																						//invalid firstname validation,If invalid throw an error as invalid data
																						for(String name:names){
																							if(name.contains("(")){
																								String result = name.substring(name.indexOf("(") + 1, name.indexOf(")"));
																								String fullname = name.substring(0,name.indexOf("("));
																								if(result.equalsIgnoreCase(finaldata.getUserId())){
																									if(!fullname.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
																										invaliddataflag = true;
																										break;
																									}
																								}
																							}
																						}
																					}
																					if(invaliddataflag == true){
																						listflag = false;
																						break;
																					}else{
																						//finalParamValList = commonUtils.ldapDataconstruction(finaldata.getUserId(),ai.getAssetName(),ldapParameter,conn);
																						//ldapmappingdata = finalParamValList.keySet().stream().collect(Collectors.toList());

																						listflag = true;
																					}
																				}else{
																					listflag = false;
																					break;
																				}
																			}
																			if(!finalparamValList.isEmpty()){
																				paramVal = String.join("``", finalparamValList);
																			}
																		}
																	}
																}
															}
															if(!aiv.isHasMandatoryValue()){
																if(paramVal.equalsIgnoreCase("")){
																	listflag = true;
																}
															}
															if(listflag == true)
															{     
																flag = true;
																break;
															}
															if(flag == false){
																if(apevo.getParamValue() != paramVal){
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}
														}
													}
													else
													{
														Boolean chkFilePrmValFlag = false;
														/*
													List<AssetParamDef> paramMap = assetDao.getParamValuesForAssetInst(ai.getAssetName(),ai.getAssetInstName(), ai.getVersionName(), conn);
													for (AssetParamDef assetdef : paramMap) paramMapFromDb1.put(assetdef.getAssetParamName(),assetdef.getParamValue());
														 */
														if(!currentExclRecStat.equalsIgnoreCase("add")){
															for (Map.Entry<String, String> entry2 : paramMapFromDb1.entrySet()) {
																if(paramName.equalsIgnoreCase(entry2.getKey())){
																	if(!paramVal.equalsIgnoreCase(entry2.getValue())){
																		chkFilePrmValFlag = true;
																	}
																}
															}	
														}  

														if((chkFilePrmValFlag && currentExclRecStat.equalsIgnoreCase("none")) || currentExclRecStat.equalsIgnoreCase("add")||(aiv.isHasMandatoryValue()&&paramVal.equalsIgnoreCase(""))){
															if( paramVal != ""  && paramVal != null)
															{
																File folder = new File(System.getProperty("user.home")+"/RepoProUnzip/");
																File[] listOfFiles = folder.listFiles();
																if(listOfFiles != null ){
																	for (int g = 0; g < listOfFiles.length; g++) 
																	{
																		if (listOfFiles[g].isFile()) {
																			if(listOfFiles[g].getName().equalsIgnoreCase(paramVal))
																			{
																				if(paramList.size()-1 == y)
																				{
																					newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																				}
																				else{
																					newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal+Constants.APPEND_STRING;	
																				}
																				apsVo.setAssetType(ai.getAssetName());
																				apsVo.setAssetInstName(ai.getAssetInstName());
																				apsVo.setVersionName(ai.getVersionName());
																				apsVo.setParentAssetName(ai.getParentAssetName());
																				apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																				apsVo.setParamTypeName(aiv.getTypeName());
																				apsVo.setCatName(aiv.getAssetCategoryName());
																				apsVo.setParamTypeId(aiv.getParamTypeId());
																				apsVo.setParamName(paramName);
																				apsVo.setParamValue(paramVal);
																				apsVo.setHasStaticValue(aiv.isHasStaticValue());
																				apsVo.setAssetParamId(aiv.getAssetParamId());
																				apsVoList.add(apsVo);
																				flag = true;
																			}

																		}
																	}
																	if(flag == false){
																		apevo.setFileExist("Not Found");
																	}
																}
																else
																{
																	apevo.setFileExist("Not Found");
																}

																if(flag == false)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}

															else
															{
																if(!aiv.isHasMandatoryValue()){
																	if(paramList.size()-1 == y)
																	{
																		newParamDataForRevision = newParamDataForRevision + paramName+":"+ paramVal;
																	}
																	else{
																		newParamDataForRevision = newParamDataForRevision +paramName+":"+ paramVal+Constants.APPEND_STRING;	
																	}
																	apsVo.setAssetType(ai.getAssetName());
																	apsVo.setAssetInstName(ai.getAssetInstName());
																	apsVo.setVersionName(ai.getVersionName());
																	apsVo.setParentAssetName(ai.getParentAssetName());
																	apsVo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apsVo.setParamTypeName(aiv.getTypeName());
																	apsVo.setCatName(aiv.getAssetCategoryName());
																	apsVo.setParamTypeId(aiv.getParamTypeId());
																	apsVo.setParamName(paramName);
																	apsVo.setParamValue(paramVal);
																	apsVo.setHasStaticValue(aiv.isHasStaticValue());
																	apsVo.setAssetParamId(aiv.getAssetParamId());
																	apsVoList.add(apsVo);
																	flag = true;
																}
																if(flag == false)
																{
																	apevo.setAssetType(ai.getAssetName());
																	apevo.setAssetInstName(ai.getAssetInstName());
																	apevo.setVersionName(ai.getVersionName());
																	apevo.setParentAssetName(ai.getParentAssetName());
																	apevo.setParentAssetInstanceName(ai.getParentAssetInstName());
																	apevo.setVersionable(ai.isVersionable());
																	apevo.setParamTypeName(aiv.getTypeName());
																	apevo.setCatName(aiv.getAssetCategoryName());
																	apevo.setParamTypeId(aiv.getParamTypeId());
																	apevo.setParamName(paramName);
																	apevo.setParamValue(paramVal);
																	apevo.setAssetParamId(aiv.getAssetParamId());
																	apeVoList.add(apevo);
																}
															}
														}
													}
												}
											}
											if(paramList.size()-1 == j){
												break;
											}
											if(allCatsAndParamsForAsset.size()-1 > j)
											{
												j++;
											}
											else
											{
												j = 0;
											}
											y++;
										}
									}
								}

								XSSFCell cellii = rowb.getCell(i++);

								String val = null;
								if(cellii == null){
									val = "";
								}
								else{
									if (cellii.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										val = cellii.getStringCellValue();
										if(val.length() == 0)
										{
											val = "";  
										}
									}
									if(cellii.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val1 = (int)cellii.getNumericCellValue(); 
										val = String.valueOf(val1); 
									}
									if(cellii.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										val = cellii.getStringCellValue();
									}
								}
								if( flagforupdate || (val != "" && val != null))
								{
									String[] addedTaxIds = new String[]{};
									String[] addedTaxIds1 = new String[]{};
									AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();

									aiatVo.setAssetName(ai.getAssetName());
									aiatVo.setAssetInstanceName(ai.getAssetInstName());
									aiatVo.setVersionName(ai.getVersionName());
									List<Long> idsForTaxon = new ArrayList<Long>();
									if(val.endsWith(","))
									{
										if (log.isErrorEnabled()) {
											log.error("Please provide a valid taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
										}
										errorsOnProc.add("Please provide a valid taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
									}
									else
									{
										if(val.length() > 0 )
										{
											if(!allTxs.isEmpty())
											{
												addedTaxIds = val.split(",");
												Boolean flag2 = true;
												for(int t =0; t< addedTaxIds.length && flag2; t++)
												{
													List<TaxonomyMaster> tmpTaxList = tmList;
													addedTaxIds1 = addedTaxIds[t].split("/");

													for(int h =0; h< addedTaxIds1.length; h++)
													{
														Boolean flag = false;
														Long taxNextId = null;
														for(TaxonomyMaster tm:tmpTaxList)
														{
															if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
																flag = true;
																taxNextId = tm.getTaxonomyId();
																break;
															}
														}
														if(!flag)
														{
															if (log.isErrorEnabled()) {
																log.error("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
															}
															errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
															flag2 = false;
															break;
														}
														else
														{
															for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
															{
																if(entry.getKey() ==  taxNextId)
																{ 
																	tmpTaxList = entry.getValue();
																}
															}
														}
														if(h == addedTaxIds1.length-1)
														{
															Boolean fl = false;
															Boolean f2 = false;
															if(associatedTaxId.contains(taxNextId)){

															}
															else{
																f2 = true;
															}
															for(Long Id:idsForTaxon)
															{
																if(Id.equals(taxNextId))
																{
																	fl = true;
																	break;
																}

															}
															if(fl)
															{
																if (log.isErrorEnabled()) {
																	log.error("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
																}
																errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()); 
															}
															if(f2)
															{
																if (log.isErrorEnabled()) {
																	log.error("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset");
																}
																errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset"); 
															}
															else
															{
																idsForTaxon.add(taxNextId);
															}
														}
													}
												}
											}
											else{
												if (log.isErrorEnabled()) {
													log.error("No taxonomy is associated with "+ai.getAssetName()+" asset");
												}
												errorsOnProc.add("No taxonomy is associated with "+ai.getAssetName()+" asset");
											}
										}
										else
										{
											idsForTaxon = Collections.<Long>emptyList();
										}
										aiatVo.setTaxonIds(idsForTaxon);
										assetInstassignList.add(aiatVo);
									}
								}

								XSSFCell celloo = rowb.getCell(i++);

								String valueTag = null;
								if(celloo == null)
								{
									valueTag = "";
								}
								else
								{
									if (celloo.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										valueTag = celloo.getStringCellValue();
										if(valueTag.length() == 0)
										{
											valueTag = "";  
										}
									}
									if(celloo.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val1 = (int)celloo.getNumericCellValue(); 
										valueTag = String.valueOf(val1); 
									}
									if(celloo.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										valueTag = celloo.getStringCellValue();
									}
								}
								if(flagforupdate ||(valueTag != "" && valueTag != null))
								{
									String iChars = "!@#$%^&*()+=[]\\\';./{}|\":<>?~";
									Boolean flagForValidation = false;
									for (int k = 0; k < valueTag.length(); k++) 
									{
										if (iChars.indexOf(valueTag.charAt(k)) != -1) 
										{
											flagForValidation = true;
											break;
										}
									}
									if(flagForValidation)
									{
										if (log.isErrorEnabled()) {
											log.error("Special Character not allowed for tagging in " + ai.getAssetInstName()+" of "+ai.getAssetName());
										}
										errorsOnProc.add("Special Character not allowed for tagging in " + ai.getAssetInstName()+" of "+ai.getAssetName()); 
									}
									else
									{
										if(valueTag.endsWith(","))
										{
											if (log.isErrorEnabled()) {
												log.error("Please provide a valid tag name " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
											}
											errorsOnProc.add("Please provide a valid tag name " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
										}
										else{
											String[] addedTagIds = new String[]{};
											AssetInstAssignTagging aiatVo1 = new AssetInstAssignTagging();
											aiatVo1.setAssetName(ai.getAssetName());
											aiatVo1.setAssetInstanceName(ai.getAssetInstName());
											aiatVo1.setVersionName(ai.getVersionName());
											List<String> tagNameXls = new ArrayList<String>();

											if(valueTag.length() > 0 )
											{
												addedTagIds = valueTag.split(",");

												for(int t =0; t< addedTagIds.length; t++)
												{
													if(addedTagIds[t].trim().length() > 50)
													{
														if (log.isErrorEnabled()) {
															log.error(" Tag Name exceeds max length for " + cell2+"_"+cell3+" of "+splitAssetName);
														}
														errorsOnProc.add(" Tag Name exceeds max length for " + cell2+"_"+cell3+" of "+splitAssetName);
													}
													Boolean flagForDupTag = false;

													for (int l=0; l<addedTagIds.length; l++){
														for (int m=l+1; m<addedTagIds.length; m++){
															if (addedTagIds[m].trim().equalsIgnoreCase(addedTagIds[l].trim())){
																flagForDupTag = true;
																break;
															}
														}
													}

													if(flagForDupTag){
														if (log.isErrorEnabled()) {
															log.error("Duplicate Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
														}
														errorsOnProc.add("Duplicate Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
														break;
													}
													else
													{
														if(!addedTagIds[t].trim().isEmpty() )
														{
															tagNameXls.add(addedTagIds[t].trim());
														}
														else
														{
															if (log.isErrorEnabled()) {
																log.error("Empty Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
															}
															errorsOnProc.add("Empty Tag Name found at " + cell2+"_"+cell3+" of "+splitAssetName);
															break;
														}
													}
												}
											}
											aiatVo1.setTagsFromXls(tagNameXls);
											assetInstTaggingList.add(aiatVo1);
										}
									}
								}

								if(pvalflag ){
									prhVo.setAssetName(ai.getAssetName());

									prhVo.setAssetInstName(ai.getAssetInstName());

									prhVo.setVersionName(ai.getVersionName());

									prhVo.setParamRevData(newParamDataForRevision);

									azds.add(prhVo);
								}
							}

							int counter = 0;

							if(cell3.equals("NA"))
							{
								cell3 = Constants.DEFAULT_VERSION;
							}

							for(int t=0;t<excelassetInstList.size();t++)
							{
								if(excelassetInstList.get(t).getAssetName().equalsIgnoreCase(splitAssetName)&& excelassetInstList.get(t).getAssetInstName().equalsIgnoreCase(cell2) && excelassetInstList.get(t).getVersionName().equalsIgnoreCase(cell3))
								{
									counter++;
								}
							}
							if(counter>1)
							{
								if (log.isErrorEnabled()) {
									log.error("Duplicate Asset Instance Name/Asset Instance Version Id/Version Name found for "+cell2+"_"+cell3+" at "+splitAssetName +" Attribute Sheet");
								}
								errorsOnProc.add("Duplicate Asset Instance Name/Asset Instance Version Id/Version Name found for "+cell2+"_"+cell3+" at "+splitAssetName +" Attribute Sheet");
								break;
							}
						}
						else
						{
							if((cell1 == "" || cell2 == "" || cell3 == "" || cell4 == ""))
							{
								if (log.isErrorEnabled()) {
									log.error("Empty data not allowed for Asset Instance Version Id/Asset Instance Name/Version Name/Overview columns of "+splitAssetName +" Attribute Sheet");
								}
								errorsOnProc.add("Empty data not allowed for Asset Instance Version Id/Asset Instance Name/Version Name/Overview columns of "+splitAssetName +" Attribute Sheet");
								break;
							}
						}
					}
					listOfassetInstList.put(splitAssetName, assetInstList);
					listOfassetInstList1.put("", assetInstList2);
				}
			}
			log.info("Asset Attribute 2nd level validation done for incremental update");

			// Loop Starts for Asset Relation validation 2nd level
			List<AssetInstRelationship>  excelassetInstRelList = null ;

			Map<String,List<AssetInstRelationship>> listOfassetInstRelList = new LinkedHashMap<String,List<AssetInstRelationship>>();

			if(errorsOnProc.size() == 0 && apeVoList.isEmpty())
			{
				splitAssetName = null;
				for (int x = 1; x < wb.getNumberOfSheets(); x=x+2) 
				{
					XSSFSheet sheet=wb.getSheetAt(x);

					excelassetInstRelList = new ArrayList<AssetInstRelationship>();

					List<AssetInstRelationship>  assetInstRelList = new ArrayList<AssetInstRelationship>();

					List<AssetInstRelationship>  assetInstRelListtemp = new ArrayList<AssetInstRelationship>();

					XSSFRow row; 

					//Iterator rows = sheet.rowIterator();
					Iterator<Row> rows = sheet.iterator();


					int l =2 ;

					while (rows.hasNext())
					{
						AssetInstance prhVo = new AssetInstance();

						row=(XSSFRow) rows.next();

						int  rowNum = row.getRowNum();

						if(row.getRowNum()== 0)
						{
							XSSFRow rowb = sheet.getRow(rowNum++);

							XSSFCell cellaa = rowb.getCell(0);

							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									splitAssetName = cellaa.getStringCellValue();
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}

							}
							else
							{
								splitAssetName = "";
							}
							continue; 
						}

						if( row.getRowNum()==1)
						{
							continue; 
						}

						rowNum = l;

						String cell1=null, cell2 = null, cell3 = null, cell4 = null, cell5 = null, cell6 = null, cell7 = null, cell8 = null, cell9 = null, cell10 = null,cell11 = null,cell12 = null;

						XSSFRow rowb = sheet.getRow(rowNum++);

						XSSFCell cellaa = rowb.getCell(0);

						XSSFCell cellbb = rowb.getCell(1);

						XSSFCell cellcc = rowb.getCell(2);

						XSSFCell celldd = rowb.getCell(3);

						XSSFCell cellee = rowb.getCell(4);

						XSSFCell cellff = rowb.getCell(5);

						XSSFCell cellgg = rowb.getCell(6);

						XSSFCell cellhh = rowb.getCell(7);

						XSSFCell cellii = rowb.getCell(8);

						XSSFCell celljj = rowb.getCell(9);

						XSSFCell cellkk = rowb.getCell(10);

						XSSFCell cellll = rowb.getCell(11);

						if(cellaa != null)
						{
							if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellaa.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val1 = (int)cellaa.getNumericCellValue(); 
								cell1 = String.valueOf(val1); 
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellaa.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellbb.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellbb.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell2 = "";
						}

						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = cellcc.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellcc.getNumericCellValue(); 
								cell3 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = cellcc.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}


						if(celldd != null)
						{
							if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell4 = celldd.getStringCellValue();
								if(cell4.length() == 0)
								{
									cell4 = "";  
								}
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)celldd.getNumericCellValue(); 
								cell4 = String.valueOf(val); 
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell4 = celldd.getStringCellValue();
							}
						}
						else
						{
							cell4 = "";
						}

						if(cellee != null)
						{
							if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell5 = cellee.getStringCellValue();
								if(cell5.length() == 0)
								{
									cell5 = "";  
								}
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellee.getNumericCellValue(); 
								cell5 = String.valueOf(val); 
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell5 = cellee.getStringCellValue();
							}
						}
						else
						{
							cell5 = "";
						}

						if(cellff != null)
						{
							if (cellff.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell6 = cellff.getStringCellValue();
								if(cell6.length() == 0)
								{
									cell6 = "";  
								}
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellff.getNumericCellValue(); 
								cell6 = String.valueOf(val); 
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell6 = cellff.getStringCellValue();
							}
						}
						else
						{
							cell6 = "";
						}

						if(cellgg != null)
						{
							if (cellgg.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell7 = cellgg.getStringCellValue();
								if(cell7.length() == 0)
								{
									cell7 = "";  
								}
							}
							if(cellgg.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellgg.getNumericCellValue(); 
								cell7 = String.valueOf(val); 
							}
							if(cellgg.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell7 = cellgg.getStringCellValue();
							}
						}
						else
						{
							cell7 = "";
						}

						if(cellhh != null)
						{
							if (cellhh.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell8 = cellhh.getStringCellValue();
								if(cell8.length() == 0)
								{
									cell8 = "";  
								}
							}
							if(cellhh.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellhh.getNumericCellValue(); 
								cell8 = String.valueOf(val); 
							}
							if(cellhh.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell8 = cellhh.getStringCellValue();
							}
						}
						else
						{
							cell8 = "";
						}

						if(cellii != null)
						{
							if (cellii.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell9 = cellii.getStringCellValue();
								if(cell9.length() == 0)
								{
									cell9 = "";  
								}
							}
							if(cellii.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellii.getNumericCellValue(); 
								cell9 = String.valueOf(val); 
							}
							if(cellii.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell9 = cellii.getStringCellValue();
							}
						}
						else
						{
							cell9 = "";
						}

						if(celljj != null)
						{
							if (celljj.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell10 = celljj.getStringCellValue();
								if(cell10.length() == 0)
								{
									cell10 = "";  
								}
							}
							if(celljj.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)celljj.getNumericCellValue(); 
								cell10 = String.valueOf(val); 
							}
							if(celljj.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell10 = celljj.getStringCellValue();
							}
						}
						else
						{
							cell10 = "";
						}

						if(cellkk != null)
						{
							if (cellkk.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell11 = cellkk.getStringCellValue();
								if(cell11.length() == 0)
								{
									cell11 = "";  
								}
							}
							if(cellkk.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellkk.getNumericCellValue(); 
								cell11 = String.valueOf(val);
							}
							if(cellkk.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell11 = cellkk.getStringCellValue();
							}
						}
						else
						{
							cell11 = "";
						}

						if(cellll != null)
						{
							if (cellll.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell12 = cellll.getStringCellValue();
								if(cell12.length() == 0)
								{
									cell12 = "";  
								}
							}
							if(cellll.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellll.getNumericCellValue(); 
								cell12 = String.valueOf(val); 
							}
							if(cellll.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell12 = cellll.getStringCellValue();
							}
						}
						else
						{
							cell12 = "";
						}

						AssetInstRelationship avVo = new AssetInstRelationship();

						avVo.setSrcAssetName(cell1);
						avVo.setSourceInstanceName(cell3);
						avVo.setSourceVersionName(cell4);
						avVo.setDestAssetName(cell8);
						avVo.setDestInstanceName(cell10);
						avVo.setDestInstanceVersionName(cell11);
						avVo.setDescrption(cell7);
						avVo.setRelationShipName(cell6);
						excelassetInstRelList.add(avVo);
						l++;
					}

					rows = sheet.rowIterator();

					int q = 2;

					while (rows.hasNext())
					{
						AssetInstance prhVo = new AssetInstance();

						row = (XSSFRow) rows.next();

						int  rowNum = row.getRowNum();

						if(row.getRowNum() == 0)
						{
							XSSFRow rowb = sheet.getRow(rowNum++);

							XSSFCell cellaa = rowb.getCell(0);

							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									splitAssetName = cellaa.getStringCellValue();
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val1 = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val1); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}
							}
							else
							{
								splitAssetName = "";
							}
							AssetInstanceVersion srcAiv = new AssetInstanceVersion();
							AssetInstanceVersion destAiv = new AssetInstanceVersion();
							List<AssetInstRelationship> depAIs =  assetInstanceVersionDao.getNumOfDependentsForAssetInstByAssetType(splitAssetName, conn);

							for(AssetInstRelationship air:depAIs)
							{
								srcAiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(air.getSrcAssetInstVersionId(), conn);
								for(int t=0;t<excelassetInstList.size();t++)
								{
									if(srcAiv.getAssetName().equalsIgnoreCase(excelassetInstList.get(t).getAssetName())&& excelassetInstList.get(t).getAssetInstName().equalsIgnoreCase(srcAiv.getAssetInstName()) && excelassetInstList.get(t).getVersionName().equalsIgnoreCase(srcAiv.getVersionName()))
									{
										destAiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(air.getDestAssetInstVersionId(), conn);

										AssetInstRelationship airVo = new AssetInstRelationship();
										airVo.setSrcAssetName(srcAiv.getAssetName());
										airVo.setSrcAssetInstVersionId(srcAiv.getAssetInstVersionId());
										airVo.setSourceInstanceName(srcAiv.getAssetInstName());
										airVo.setSourceVersionName(srcAiv.getVersionName());
										airVo.setDestAssetName(destAiv.getAssetName());
										airVo.setDestInstanceName(destAiv.getAssetInstName());
										airVo.setDestAssetInstVersionId(destAiv.getAssetInstVersionId());
										airVo.setDestInstanceVersionName(destAiv.getVersionName());
										airVo.setDescrption(air.getDescrption());
										airVo.setRelationShipName(air.getRelationShipName());
										airVo.setAssetRelId(air.getAssetRelId());
										assetInstRelList.add(airVo);
										assetInstRelListtemp.add(airVo);
									}
								}
							}
							continue; 
						}

						if( row.getRowNum()==1)
						{
							continue; 
						}

						rowNum = q;

						String cell1=null, cell2 = null, cell3 = null, cell4 = null, cell5 = null, cell6 = null, cell7 = null, cell8 = null, cell9 = null, cell10 = null,cell11 = null,cell12 = null;

						XSSFRow rowb = sheet.getRow(rowNum++);

						XSSFCell cellaa = rowb.getCell(0);

						XSSFCell cellbb = rowb.getCell(1);

						XSSFCell cellcc = rowb.getCell(2);

						XSSFCell celldd = rowb.getCell(3);

						XSSFCell cellee = rowb.getCell(4);

						XSSFCell cellff = rowb.getCell(5);

						XSSFCell cellgg = rowb.getCell(6);

						XSSFCell cellhh = rowb.getCell(7);

						XSSFCell cellii = rowb.getCell(8);

						XSSFCell celljj = rowb.getCell(9);

						XSSFCell cellkk = rowb.getCell(10);

						XSSFCell cellll = rowb.getCell(11);

						if(cellaa != null)
						{
							if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell1 = cellaa.getStringCellValue();
								if(cell1.length() == 0)
								{
									cell1 = "";  
								}
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val1 = (int)cellaa.getNumericCellValue(); 
								cell1 = String.valueOf(val1); 
							}
							if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell1 = cellaa.getStringCellValue();
							}
						}
						else
						{
							cell1 = "";
						}

						if(cellbb != null)
						{
							if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell2 = cellbb.getStringCellValue();
								if(cell2.length() == 0)
								{
									cell2 = "";  
								}
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellbb.getNumericCellValue(); 
								cell2 = String.valueOf(val); 
							}
							if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell2 = cellbb.getStringCellValue();
							}
						}
						else
						{
							cell2 = "";
						}

						if(cellcc != null)
						{
							if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell3 = cellcc.getStringCellValue();
								if(cell3.length() == 0)
								{
									cell3 = "";  
								}
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellcc.getNumericCellValue(); 
								cell3 = String.valueOf(val); 
							}
							if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell3 = cellcc.getStringCellValue();
							}
						}
						else
						{
							cell3 = "";
						}


						if(celldd != null)
						{
							if (celldd.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell4 = celldd.getStringCellValue();
								if(cell4.length() == 0)
								{
									cell4 = "";  
								}
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)celldd.getNumericCellValue(); 
								cell4 = String.valueOf(val); 
							}
							if(celldd.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell4 = celldd.getStringCellValue();
							}
						}
						else
						{
							cell4 = "";
						}

						if(cellee != null)
						{
							if (cellee.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell5 = cellee.getStringCellValue();
								if(cell5.length() == 0)
								{
									cell5 = "";  
								}
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellee.getNumericCellValue(); 
								cell5 = String.valueOf(val); 
							}
							if(cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell5 = cellee.getStringCellValue();
							}
						}
						else
						{
							cell5 = "";
						}

						if(cellff != null)
						{
							if (cellff.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell6 = cellff.getStringCellValue();
								if(cell6.length() == 0)
								{
									cell6 = "";  
								}
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellff.getNumericCellValue(); 
								cell6 = String.valueOf(val); 
							}
							if(cellff.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell6 = cellff.getStringCellValue();
							}
						}
						else
						{
							cell6 = "";
						}

						if(cellgg != null)
						{
							if (cellgg.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell7 = cellgg.getStringCellValue();
								if(cell7.length() == 0)
								{
									cell7 = "";  
								}
							}
							if(cellgg.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellgg.getNumericCellValue(); 
								cell7 = String.valueOf(val); 
							}
							if(cellgg.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell7 = cellgg.getStringCellValue();
							}
						}
						else
						{
							cell7 = "";
						}

						if(cellhh != null)
						{
							if (cellhh.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell8 = cellhh.getStringCellValue();
								if(cell8.length() == 0)
								{
									cell8 = "";  
								}
							}
							if(cellhh.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellhh.getNumericCellValue(); 
								cell8 = String.valueOf(val); 
							}
							if(cellhh.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell8 = cellhh.getStringCellValue();
							}
						}
						else
						{
							cell8 = "";
						}

						if(cellii != null)
						{
							if (cellii.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell9 = cellii.getStringCellValue();
								if(cell9.length() == 0)
								{
									cell9 = "";  
								}
							}
							if(cellii.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellii.getNumericCellValue(); 
								cell9 = String.valueOf(val); 
							}
							if(cellii.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell9 = cellii.getStringCellValue();
							}
						}
						else
						{
							cell9 = "";
						}


						if(celljj != null)
						{
							if (celljj.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell10 = celljj.getStringCellValue();
								if(cell10.length() == 0)
								{
									cell10 = "";  
								}
							}
							if(celljj.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)celljj.getNumericCellValue(); 
								cell10 = String.valueOf(val); 
							}
							if(celljj.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell10 = celljj.getStringCellValue();
							}
						}
						else
						{
							cell10 = "";
						}

						if(cellkk != null)
						{
							if (cellkk.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell11 = cellkk.getStringCellValue();
								if(cell11.length() == 0)
								{
									cell11 = "";  
								}
							}
							if(cellkk.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellkk.getNumericCellValue(); 
								cell11 = String.valueOf(val);
							}
							if(cellkk.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell11 = cellkk.getStringCellValue();
							}
						}
						else
						{
							cell11 = "";
						}

						if(cellll != null)
						{
							if (cellll.getCellType() == XSSFCell.CELL_TYPE_BLANK)
							{
								cell12 = cellll.getStringCellValue();
								if(cell12.length() == 0)
								{
									cell12 = "";  
								}
							}
							if(cellll.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
							{
								int val = (int)cellll.getNumericCellValue(); 
								cell12 = String.valueOf(val); 
							}
							if(cellll.getCellType() == XSSFCell.CELL_TYPE_STRING)
							{
								cell12 = cellll.getStringCellValue();
							}
						}
						else
						{
							cell12 = "";
						}

						if(cell1!="" && cell2!="" && cell3!="" && cell4!="" && cell7!="" && cell8!="" && cell9!="" && cell10!="" && cell6!="")
						{
							cell1  = cell1.trim();
							cell2  = cell2.trim();
							cell3  = cell3.trim();
							cell7  = cell7.trim();
							cell8  = cell8.trim();
							cell9  = cell9.trim();
							cell5  = cell5.trim();
							cell6  = cell6.trim();
							cell4  = cell4.trim();
							cell10  = cell10.trim();

							if(cell1.length() > 50)
							{
								if (log.isErrorEnabled()) {
									log.error(" Source Asset Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
								}
								errorsOnProc.add(" Source Asset Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
							}

							if(cell3.length() > 100)
							{
								if (log.isErrorEnabled()) {
									log.error(" Source Asset Instance Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
								}
								errorsOnProc.add(" Source Asset Instance Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
							}

							if(cell4.length() > 10)
							{
								if (log.isErrorEnabled()) {
									log.error(" Source Asset Instance Version Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
								}
								errorsOnProc.add(" Source Asset Instance Version Name exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
							}

							if(cell8.length() > 50)
							{
								if (log.isErrorEnabled()) {
									log.error(" Target Asset Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
								}
								errorsOnProc.add(" Target Asset Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
							}

							if(cell10.length() > 100)
							{
								if (log.isErrorEnabled()) {
									log.error(" Target Asset Instance Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
								}
								errorsOnProc.add(" Target Asset Instance Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
							}

							if(cell11.length() > 10)
							{
								if (log.isErrorEnabled()) {
									log.error(" Target Asset Instance Version Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
								}
								errorsOnProc.add(" Target Asset Instance Version Name exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
							}

							if(cell2.length() > 20)
							{
								if (log.isErrorEnabled()) {
									log.error(" Source Asset Instance Version Id exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
								}
								errorsOnProc.add(" Source Asset Instance Version Id exceeds max length at " + cell3+"_"+cell4+" at "+splitAssetName);
							}

							if(cell9.length() > 20)
							{
								if (log.isErrorEnabled()) {
									log.error(" Target Asset Instance Version Id exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
								}
								errorsOnProc.add(" Target Asset Instance Version Id exceeds max length at " + cell10+"_"+cell11+" at "+splitAssetName);
							}

							String iChars1 = "!@#$%^&*()+=[]\\\';./{}|\":<>?~";

							Boolean flagForValidation1 = false;

							for (int k = 0; k < cell1.length(); k++) 
							{
								if (iChars1.indexOf(cell1.charAt(k)) != -1) 
								{
									flagForValidation1 = true;
									break;
								}
							}

							String iChars3 = "!%^*=[];{}|<>?~";

							Boolean flagForValidation3 = false;

							for (int k = 0; k < cell3.length(); k++) 
							{
								if (iChars3.indexOf(cell3.charAt(k)) != -1) 
								{
									flagForValidation3 = true;
									break;
								}
							}

							Boolean flagForValidation2 = false;

							String iChars2 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWXYZ]";
							for (int i = 0; i < cell4.length(); i++) 
							{
								if (iChars2.indexOf(cell4.trim().charAt(i)) != -1) 
								{
									flagForValidation2= true;
									break;
								}
							}

							String iChars4 = "!@#$%^&*()+=[]\\\';./{}|\":<>?~";
							Boolean flagForValidation4 = false;

							for (int k = 0; k < cell8.length(); k++) 
							{
								if (iChars4.indexOf(cell8.charAt(k)) != -1) 
								{
									flagForValidation4 = true;
									break;
								}
							}

							String iChars5 = "!%^*=[];{}|<>?~";

							Boolean flagForValidation5 = false;

							for (int k = 0; k < cell10.length(); k++) 
							{
								if (iChars5.indexOf(cell10.charAt(k)) != -1) 
								{
									flagForValidation5 = true;
									break;
								}
							}

							Boolean flagForValidation6 = false;

							String iChars6 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWXYZ]";
							for (int i = 0; i < cell11.length(); i++) 
							{
								if (iChars6.indexOf(cell11.trim().charAt(i)) != -1) 
								{
									flagForValidation6= true;
									break;
								}
							}

							Boolean flagForValidation7 = false;
							String iChars7 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWYZ]";
							for (int i = 0; i < cell2.length(); i++) 
							{
								if (iChars7.indexOf(cell2.trim().charAt(i)) != -1) 
								{
									flagForValidation7= true;
									break;
								}
							}
							Boolean flagForValidation8 = false;
							String iChars8 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?~[abcdefghijklmnopqrstuvwxyz][ABCDEFGHIJKLMNOPQRSTUVWYZ]";
							for (int i = 0; i < cell9.length(); i++) 
							{
								if (iChars8.indexOf(cell9.trim().charAt(i)) != -1) 
								{
									flagForValidation8= true;
									break;
								}
							}

							if(flagForValidation1)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in source asset type column " + cell1+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Character not allowed in source asset type column " + cell1+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation2)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed in  source asset instance version column " + cell4+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed in  source asset instance version column " + cell4+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation3)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in source asset instance name column " + cell3+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Character not allowed in source asset instance name column " + cell3+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation4)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in target asset type column " + cell8+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Character not allowed in target asset type column " + cell8+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation6)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed in  target asset instance version column " + cell11+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed in  target asset instance version column " + cell11+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation5)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Character not allowed in target asset instance name column " + cell10+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Character not allowed in target asset instance name column " + cell10+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation7)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed except XXXX in  Source Asset Instance Version Id column " + cell2+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed except XXXX in  Source Asset Instance Version Id column " + cell2+" at "+splitAssetName+" Relationship sheet");
							}

							if(flagForValidation8)
							{
								if (log.isErrorEnabled()) {
									log.error("Special Characters/Alphabets not allowed except XXXX in  Target Asset Instance Version Id column " + cell9+" at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Special Characters/Alphabets not allowed except XXXX in  Target Asset Instance Version Id column " + cell9+" at "+splitAssetName+" Relationship sheet");
							}

							AssetInstRelationship avVo = new AssetInstRelationship();

							Boolean flag12 = false;
							for(AssetInstRelationship aivo:assetInstRelList)
							{
								if(aivo.getDestAssetInstVersionId().toString().equals(cell9) && aivo.getSrcAssetInstVersionId().toString().equals(cell2)&& aivo.getSrcAssetName().equalsIgnoreCase(cell1) && aivo.getSourceInstanceName().equalsIgnoreCase(cell3) && aivo.getSourceVersionName().equalsIgnoreCase(cell4)&&  aivo.getDestAssetName().equalsIgnoreCase(cell8) && aivo.getDestInstanceName().equalsIgnoreCase(cell10) && aivo.getDestInstanceVersionName().equalsIgnoreCase(cell11)&& cell7.equals(aivo.getDescrption()) && cell6.equals(aivo.getRelationShipName()) )
								{
									aivo.setAction("update");
									flag12 = true;
									break;
								}
							}
							String hhh = "";
							if(!flag12)
							{   
								avVo.setSrcAssetName(cell1);
								avVo.setSourceInstanceName(cell3);
								avVo.setSourceVersionName(cell4);
								if(cell2.equals("XXXX")){
									avVo.setSrcAssetInstVersionId(Long.valueOf("0000"));
								}else{
									avVo.setSrcAssetInstVersionId(Long.valueOf(cell2));
								}
								avVo.setDestAssetName(cell8);
								avVo.setDestInstanceName(cell10);
								avVo.setDestInstanceVersionName(cell11);
								if(cell9.equals("XXXX")){
									avVo.setDestAssetInstVersionId(Long.valueOf("0000"));
								}else{
									avVo.setDestAssetInstVersionId(Long.valueOf(cell9));
								}
								avVo.setDescrption(cell7);
								avVo.setRelationShipName(cell6);
								avVo.setAction("add");
								hhh = "add";
								assetInstRelList.add(avVo);
							}

							if(hhh.equals("add"))
							{
								Boolean flagCheck = false;
								for(AssetInstanceVersion aiv1:excelassetInstList)
								{
									if(!("XXXX").equals(cell2)&& aiv1.getAssetInstName().equalsIgnoreCase(cell3) && aiv1.getVersionName().equalsIgnoreCase(cell4))
									{
										flagCheck = true;
									}
								}
								if(!flagCheck)
								{
									if (log.isErrorEnabled()) {
										log.error("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+ " Relationship sheet");
									}
									errorsOnProc.add("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+ " Relationship sheet");
								}
								else
								{ 
									Boolean flagCh = false;
									for(AssetRelationshipDef relNm :relNameList)
									{
										if(cell8.equalsIgnoreCase(relNm.getDestAssetName()) && cell1.equalsIgnoreCase(relNm.getSrcAssetName()) && cell7.equals(relNm.getDescription()) && cell6.equals(relNm.getFwdRelationType()))
										{
											flagCh = true;
											break;
										}
									}
									if(!flagCh)
									{
										if (log.isErrorEnabled()) {
											log.error("Error in Relation Details : Please check " + cell8+","+cell7+","+cell6+" of "+cell1+" Relationship sheet");
										}
										errorsOnProc.add("Error in Relation Details : Please check " + cell8+","+cell7+","+cell6+" of "+cell1+" Relationship sheet");
									}
									else
									{
										Boolean flagChec1 = false;
										for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
										{
											if(cell1.equalsIgnoreCase(entry.getKey()))
											{
												for(AssetInstanceVersion aiv:entry.getValue())
												{
													if((aiv.getAssetInstVersionId().toString().equals(cell2)&& aiv.getAssetInstName().equalsIgnoreCase(cell3) && aiv.getVersionName().equalsIgnoreCase(cell4)))
													{
														flagChec1 = true;
														break;
													}
												}
											}
										}
										Boolean flagChec = false;
										Boolean flagCond = false;
										if(flagChec1){
											if(cell6.equals("association") || cell6.equals("classification"))
											{
												if(cell3.equalsIgnoreCase(cell10)&& cell1.equalsIgnoreCase(cell8))
												{
													if (log.isErrorEnabled()) {
														log.error("Error in Relationship Details: Source and Destination cannot be same Asset Instance " + cell10+"_"+cell11+" of "+cell8);
													}
													errorsOnProc.add("Error in Relationship Details: Source and Destination cannot be same Asset Instance " + cell10+"_"+cell11+" of "+cell8);
													flagChec = true;
												}
												else
												{
													for (Entry<String, List<List<AssetInstanceVersion>>> entry : listOfassetInstList1.entrySet())
													{
														for(List<AssetInstanceVersion> aiv:entry.getValue())
														{
															for(AssetInstanceVersion aiv2:aiv ){
																if(cell8.equalsIgnoreCase(aiv2.getAssetName()))
																{
																	if(aiv2.getAssetInstVersionId() != null){
																		if(aiv2.getAssetInstVersionId().toString().equals(cell9)&& aiv2.getAssetInstName().equalsIgnoreCase(cell10) && aiv2.getVersionName().equalsIgnoreCase(cell11))
																		{
																			flagChec = true;
																			break;
																		}
																	}
																}
															}
														}
													} 
												}
											}		    								
											else
											{
												if(cell11.equals("1.0"))
												{
													flagChec = true;

													if(cell6.equals("composition") || cell6.equals("aggregation"))
													{
														if (log.isErrorEnabled()) {
															log.error("Error in Relation Details: Composition and Aggregation relation not allowed for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
														}
														errorsOnProc.add("Error in Relation Details: Composition and Aggregation relation not allowed for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
													}
													else
													{
														for (Entry<String, List<List<AssetInstanceVersion>>> entry : listOfassetInstList1.entrySet())
														{
															for(List<AssetInstanceVersion> aiv:entry.getValue())
															{
																for(AssetInstanceVersion aiv2:aiv ){
																	{
																		if(cell8.equalsIgnoreCase(aiv2.getAssetName()))
																		{

																			if((aiv2.getAssetInstVersionId().toString().equals(cell9)&& aiv2.getAssetInstName().equalsIgnoreCase(cell10) && aiv2.getVersionName().equalsIgnoreCase(cell11)) )
																			{
																				flagCond = true;
																				break;
																			}
																		}
																	}
																}
															}
														} 
													}
												}
												else
												{
													if (log.isErrorEnabled()) {
														log.error("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
													}
													errorsOnProc.add("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
													break;
												}
											}
										}
										if(!flagChec || flagCond)
										{
											if (log.isErrorEnabled()) {
												log.error("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
											}
											errorsOnProc.add("Error in Relation Details for " + cell10+"_"+cell11+" of "+cell8);
										}

										if(!flagChec1)
										{
											if (log.isErrorEnabled()) {
												log.error("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
											}
											errorsOnProc.add("Error in Relation Details for " + cell3+"_"+cell4+" of "+cell1+" Relationship sheet");
										}
									}
								}
							}
							int counter = 0;

							for(int t=0;t<excelassetInstRelList.size();t++)
							{
								if(excelassetInstRelList.get(t).getSrcAssetName().equalsIgnoreCase(cell1) && excelassetInstRelList.get(t).getSourceInstanceName().equalsIgnoreCase(cell3) && excelassetInstRelList.get(t).getSourceVersionName().equalsIgnoreCase(cell4)&& excelassetInstRelList.get(t).getDestAssetName().equalsIgnoreCase(cell8)&& excelassetInstRelList.get(t).getDestInstanceName().equalsIgnoreCase(cell10) && excelassetInstRelList.get(t).getDestInstanceVersionName().equalsIgnoreCase(cell11)&& excelassetInstRelList.get(t).getDescrption().equals(cell7)&& excelassetInstRelList.get(t).getRelationShipName().equals(cell6))
								{
									counter++;
								}
							}
							if(counter>1)
							{
								if (log.isErrorEnabled()) {
									log.error("Duplicate Relation found for "+cell3+"_"+cell4+" at "+splitAssetName +" Relationship Sheet");
								}
								errorsOnProc.add("Duplicate Relation found for "+cell3+"_"+cell4+" at "+splitAssetName +" Relationship Sheet");
							}
						}
						else
						{
							if(cell1 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Source Asset Type column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Source Asset Type column at "+splitAssetName+" Relationship sheet");
							}
							if(cell3 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Source Asset Instance Name column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Source Asset Instance Name column at "+splitAssetName+" Relationship sheet");
							}
							if(cell4 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Source Asset Instance Version column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Source Asset Instance Version column at "+splitAssetName+" Relationship sheet");
							}
							if(cell6 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Relation Type column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Relation Type column at "+splitAssetName+" Relationship sheet");
							}
							if(cell7 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Relation Name column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Relation Name column at "+splitAssetName+" Relationship sheet");
							}
							if(cell7 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Target Asset Type column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Target Asset Type column at "+splitAssetName+" Relationship sheet");
							}
							if(cell10 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Target Asset Instance Name column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Target Asset Instance Name column at "+splitAssetName+" Relationship sheet");
							}
							if(cell11 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Target Asset Instance version column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Target Asset Instance version column at "+splitAssetName+" Relationship sheet");
							}

							if(cell2 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Source Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Source Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
							}

							if(cell9 == "")
							{
								if (log.isErrorEnabled()) {
									log.error("Please provide valid Relationship data for Target Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
								}
								errorsOnProc.add("Please provide valid Relationship data for Target Asset Instance Version Id column at "+splitAssetName+" Relationship sheet");
							}
						}
						q++;
					}

					for(AssetInstRelationship aivo:assetInstRelListtemp)
					{
						if(aivo.getRelationShipName().equals("composition") || aivo.getRelationShipName().equals("aggregation"))
						{
							Boolean flagForNotRemove = false;

							for(AssetInstRelationship aiv:excelassetInstRelList)
							{
								if( aivo.getSrcAssetName().equalsIgnoreCase(aiv.getSrcAssetName()) && aivo.getSourceInstanceName().equalsIgnoreCase(aiv.getSourceInstanceName()) && aivo.getSourceVersionName().equalsIgnoreCase(aiv.getSourceVersionName())&&  aivo.getDestAssetName().equalsIgnoreCase(aiv.getDestAssetName()) && aivo.getDestInstanceName().equalsIgnoreCase(aiv.getDestInstanceName()) && aivo.getDestInstanceVersionName().equalsIgnoreCase(aiv.getDestInstanceVersionName()) && aivo.getDescrption().equals(aiv.getDescrption())&& aiv.getRelationShipName().equals(aivo.getRelationShipName()))
								{
									flagForNotRemove = true;
									break;
								}
							}
							if(!flagForNotRemove)
							{   
								aivo.setAction("skip");
								if (log.isErrorEnabled()) {
									log.error("Error in Relation Details: Composition and Aggregation relation cannot be delete for " + aivo.getSourceInstanceName()+"_"+aivo.getSourceVersionName()+" of "+aivo.getSrcAssetName()+" Relationship sheet");
								}
								errorsOnProc.add("Error in Relation Details: Composition and Aggregation relation cannot be delete for " + aivo.getSourceInstanceName()+"_"+aivo.getSourceVersionName()+" of "+aivo.getSrcAssetName()+" Relationship sheet");
							}
						}
						else
						{
							Boolean flagForNotRemove = false;

							for(AssetInstRelationship aiv:excelassetInstRelList)
							{ 
								if( aivo.getSrcAssetName().equalsIgnoreCase(aiv.getSrcAssetName()) && aivo.getSourceInstanceName().equalsIgnoreCase(aiv.getSourceInstanceName()) && aivo.getSourceVersionName().equalsIgnoreCase(aiv.getSourceVersionName())&&  aivo.getDestAssetName().equalsIgnoreCase(aiv.getDestAssetName()) && aivo.getDestInstanceName().equalsIgnoreCase(aiv.getDestInstanceName()) && aivo.getDestInstanceVersionName().equalsIgnoreCase(aiv.getDestInstanceVersionName()) && aivo.getDescrption().equals(aiv.getDescrption())&& aiv.getRelationShipName().equals(aivo.getRelationShipName()))
								{
									flagForNotRemove = true;
									break;
								}
							}
							if(!flagForNotRemove)
							{   
								aivo.setAction("delete");
							}
						}
					}
					listOfassetInstRelList.put(splitAssetName, assetInstRelList);
				}
			}
			log.info("Asset Relation validation 2nd level validation done for incremental insert");
			// Loop Ends for Asset Relation validation 2nd level

			// Loop Starts for Asset Attribute DB Updation 3rd level

			AssetInstanceManager assetInstanceManager = new AssetInstanceManager();
			List<AivRevisionHistory> aivRevHistList = new ArrayList<AivRevisionHistory>();
			List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
			List<String> aivIds = new ArrayList<String>();
			Map<String,Map<String,String>> taxIds = new LinkedHashMap<String,Map<String,String>>();
			List<Long> actualparamAivId = new ArrayList<Long>();
			
			
			Object parameterChangeNotification = null;
        	Object relatedParamChangeNotification = null;
			List<Object> parameterChangefinaldata = new ArrayList<Object>();
			List<Object> relatedParamChangefinaldata = new ArrayList<Object>();

			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
				
				for(int i=0;i<apsVoList.size();i++)
				{
					List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();
					AssetInstanceVersion assetInstver = null;
					NameValue nv = new NameValue();
					nv.setName(apsVoList.get(i).getParamName());

					AssetInstance ai = new AssetInstance();
					ai.setAssetName(apsVoList.get(i).getAssetType());
					ai.setAssetInstName(apsVoList.get(i).getAssetInstName());
					ai.setVersionName(apsVoList.get(i).getVersionName());

					AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
					ai.setAssetId(asset.getAssetId());
					ai.setParentAssetName(apsVoList.get(i).getParentAssetName());
					ai.setParentAssetInstName(apsVoList.get(i).getParentAssetInstanceName());

					nv.setName(apsVoList.get(i).getParamName());
					AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
					ai.setAssetInstVersionId(aiv.getAssetInstVersionId());
					if(!apsVoList.get(i).getParamTypeId().equals(3L))
					{
						assetInstver = new AssetInstanceVersion();
						assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
						if(apsVoList.get(i).getParamTypeId().equals(7L)){
							if(apsVoList.get(i).isHasStaticValue()){
								assetInstver.setParamValue(apsVoList.get(i).getParamValue());
							}else if(apsVoList.get(i).getHasArray()==0){
								assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								assetInstver.setRTFPlainText(apsVoList.get(i).getRTFPlainText());
							}else{
								assetInstver.setRTFwithOutTags(apsVoList.get(i).getRTFwithOutTags());
								assetInstver.setRTFwithTags(apsVoList.get(i).getRTFwithTags());
							}
						}else if(apsVoList.get(i).getParamTypeId().equals(1L)){
							if(apsVoList.get(i).isHasStaticValue()){
								assetInstver.setParamValue(apsVoList.get(i).getParamValue());
							}else if(apsVoList.get(i).getHasArray()==0){
								assetInstver.setParamValue(apsVoList.get(i).getParamValue());
							}else{
								assetInstver.setTextDataList(apsVoList.get(i).getTextDataList());
							}
						}else if(apsVoList.get(i).getParamTypeId().equals(9L)){
							assetInstver.setLdapMappingValue(apsVoList.get(i).getLdapMappingValue());
						}else{
							assetInstver.setParamValue(apsVoList.get(i).getParamValue());
						}

						assetInstver.setParamTypeId(apsVoList.get(i).getParamTypeId());
						if(apsVoList.get(i).isHasStaticValue() == false){
							assetInstver.setIsStatic(0);
						}else{
							assetInstver.setIsStatic(1);
						}
						apsVoList.get(i).isHasStaticValue();
						assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
						assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
						assetInstver.setAssetName(ai.getAssetName());
						assetInstver.setAssetInstName(ai.getAssetInstName());
						assetInstver.setHasArray(apsVoList.get(i).getHasArray());
						assetInstver.setConn(conn);
						assetInstver.setLog(log);
						assetInstver.setUserId(1L);
						ListOfAssetInstanceProperties.add(assetInstver);
						
						
						if(CommonUtils.customParameterPluginNoficationClassName != null && CommonUtils.customParameterPluginPath != null){

							if(!CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") && !CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

								Class notificationInterface = CustomParameterPluginUtilies.getplugin();

								if(notificationInterface != null){
									Method method = null;
									Method relatedParamChangeMethod = null;
									try {
										method = notificationInterface.getMethod("notifyOnParameterValueChanges",new Class[]{List.class});
										relatedParamChangeMethod = notificationInterface.getMethod("notifyOnParameterValueChangesBasedOnOtherParameter",new Class[]{List.class});

									} catch (NoSuchMethodException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
										throw new RepoproException(e.getMessage());
									} catch (SecurityException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
										throw new RepoproException(e.getMessage());
									}

									Object instance = null;
									try {
										instance = notificationInterface.newInstance();
									} catch (InstantiationException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
										throw new RepoproException(e.getMessage());
									} catch (IllegalAccessException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
										throw new RepoproException(e.getMessage());
									}	


									try{
										parameterChangeNotification = method.invoke(instance,ListOfAssetInstanceProperties);

										if(parameterChangeNotification != null){
											JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

											if(jsonObject.has("Response Status")){
												String status = jsonObject.getString("Response Status");
												if(status.equalsIgnoreCase("failure")){
													if (log.isErrorEnabled()) {
														log.error(jsonObject.getString("Response Message"));
													}
													errorsOnProc.add(jsonObject.getString("Response Message"));
												}else{
													parameterChangefinaldata.add(jsonObject);
												}
											}
										}

										relatedParamChangeNotification = relatedParamChangeMethod.invoke(instance,ListOfAssetInstanceProperties);
										if(relatedParamChangeNotification != null){
											JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

											if(jsonObject.has("Response Status")){
												String status = jsonObject.getString("Response Status");
												if(status.equalsIgnoreCase("failure")){
													if (log.isErrorEnabled()) {
														log.error(jsonObject.getString("Response Message"));
													}
													errorsOnProc.add(jsonObject.getString("Response Message"));
												}else{
													relatedParamChangefinaldata.add(jsonObject);
												}
											}
										}
									}
									catch (IllegalAccessException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
										throw new RepoproException(e.getMessage());
									} catch (IllegalArgumentException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
										throw new RepoproException(e.getMessage());
									} catch (InvocationTargetException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
										throw new RepoproException(e.getMessage());
									}catch(Exception e){
										e.printStackTrace();
										throw new RepoproException(e.getMessage());
									}
								}else{
									if (log.isErrorEnabled()) {
										log.error("Invalid Plugin configuration");
									}
									errorsOnProc.add("Invalid Plugin configuration");
									
								}
							}
							if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")|| CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){
								if (log.isErrorEnabled()) {
									log.error("Invalid Plugin configuration");
								}
								errorsOnProc.add("Invalid Plugin configuration");
							}
						}
						if(CommonUtils.customParameterPluginNoficationClassName != null ){
		        			if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")){
		        				if (log.isErrorEnabled()) {
									log.error("Invalid Plugin configuration");
								}
		        				errorsOnProc.add("Invalid Plugin configuration");
		        			}
		        		}else if(CommonUtils.customParameterPluginPath != null){
		        			if(CommonUtils.customParameterPluginPath .equalsIgnoreCase("")){
		        				if (log.isErrorEnabled()) {
									log.error("Invalid Plugin configuration");
								}
		        				errorsOnProc.add("Invalid Plugin configuration");
		        			}
		        		}
					}
				}
			}

				
			
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty())
			{
				for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
				{
					for(AssetInstanceVersion aiv:entry.getValue())
					{
						AssetInstance ai = new AssetInstance();
						ai.setAssetName(entry.getKey());

						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

						ai.setAssetId(asset.getAssetId());
						ai.setAssetInstName(aiv.getAssetInstName());
						ai.setVersionName(aiv.getVersionName());
						ai.setOwner(profile.getUserName());
						if(aiv.getAction().equals("update")){

						}
					}
				}
				for(int i=0;i<aisdVoList.size();i++)
				{
					AssetInstance ai = new AssetInstance();
					ai.setAssetName(aisdVoList.get(i).getAssetType());
					AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
					ai.setAssetId(asset.getAssetId());
					ai.setAssetInstName(aisdVoList.get(i).getAssetInstName());
					ai.setVersionName(aisdVoList.get(i).getVersionName());
					ai.setParentAssetName(aisdVoList.get(i).getParentAssetName());
					ai.setParentAssetInstName(aisdVoList.get(i).getParentAssetInstanceName());
					if(globalsetting.getGlobalSettingFlag() == 1){
						String description = commonUtils.httpSanitizerForCkEditor(aisdVoList.get(i).getAssetInstanceDescription());
						aisdVoList.get(i).setAssetInstanceDescription(description);
					}
					ai.setNewDescription(aisdVoList.get(i).getAssetInstanceDescription());

					AssetInstanceVersion aiv;
					aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
					ai.setAssetInstId(aiv.getAssetInstanceId());
					

					if(globalLock.getGlobalSettingFlag() == 1){
						if(radValStatic.equalsIgnoreCase("New")){
							if(aiv.getLockTime()==null){
								if(!aisdVoList.get(i).getAssetInstanceDescription().equals(aiv.getDescription())){
									assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
									//mail aivids
									aivIds.add(aiv.getAssetInstVersionId().toString());
									
									//revision history for description(overview)
									AivRevisionHistory aivRevHist = new AivRevisionHistory();
									aivRevHist.setOverviewKey("O");
									aivRevHist.setOverviewData(ai.getNewDescription());
									aivRevHist.setAivId(aiv.getAssetInstVersionId());
									aivRevHist.setVersionName(aisdVoList.get(i).getVersionName());
									aivRevHistList.add(aivRevHist);
									
									//recent Activity
									RecentActivity recentActivity = new RecentActivity();
									recentActivity.setAssetName(ai.getAssetName());
									recentActivity.setAssetInstName(ai.getAssetInstName());
									recentActivity.setAssetInstanceVersionName(ai.getVersionName());
									recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
									recentActivityList.add(recentActivity);
									
									aiv.setVersionName(ai.getVersionName());
									aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
								}
							}
							else{
								long systemTime = System.currentTimeMillis();
								long databaseTime = aiv.getLockTime().getTime();
								if(systemTime>databaseTime){
									aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
									aiv.setLockedBy(null);
									aiv.setLockTime(null);
									assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);//unlock
									
									//mail aivids
									aivIds.add(aiv.getAssetInstVersionId().toString());
									
									//revision history for description(overview)
									AivRevisionHistory aivRevHist = new AivRevisionHistory();
									aivRevHist.setOverviewKey("O");
									aivRevHist.setOverviewData(ai.getNewDescription());
									aivRevHist.setAivId(aiv.getAssetInstVersionId());
									aivRevHist.setVersionName(aisdVoList.get(i).getVersionName());
									aivRevHistList.add(aivRevHist);
									
									//recent Activity
									RecentActivity recentActivity = new RecentActivity();
									recentActivity.setAssetName(ai.getAssetName());
									recentActivity.setAssetInstName(ai.getAssetInstName());
									recentActivity.setAssetInstanceVersionName(ai.getVersionName());
									recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
									recentActivityList.add(recentActivity);
									
									assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
								}else{
									if (log.isErrorEnabled()) {
										log.error("Asset Instance Version Overview cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
									}
									lockedVersionIds.add("Asset Instance Version Overview cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");			
								}
							}
						}
						else{
							if(aiv.getLockTime()!= null){
								if(!aisdVoList.get(i).getAssetInstanceDescription().equals(aiv.getDescription())){
									aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
									aiv.setLockedBy(null);
									aiv.setLockTime(null);
									assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
								}
							}
							assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
							//mail aivids
							aivIds.add(aiv.getAssetInstVersionId().toString());
							
							//revision history for description(overview)
							AivRevisionHistory aivRevHist = new AivRevisionHistory();
							aivRevHist.setOverviewKey("O");
							aivRevHist.setOverviewData(ai.getNewDescription());
							aivRevHist.setAivId(aiv.getAssetInstVersionId());
							aivRevHist.setVersionName(aisdVoList.get(i).getVersionName());
							aivRevHistList.add(aivRevHist);
							
							//recent Activity
							RecentActivity recentActivity = new RecentActivity();
							recentActivity.setAssetName(ai.getAssetName());
							recentActivity.setAssetInstName(ai.getAssetInstName());
							recentActivity.setAssetInstanceVersionName(ai.getVersionName());
							recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
							recentActivityList.add(recentActivity);
							
							aiv.setVersionName(ai.getVersionName());
							aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
						}
					}
					else {
						//this will call when global Setting is No
						//mail aivids
						aivIds.add(aiv.getAssetInstVersionId().toString());
						
						//revision history for description(overview)
						AivRevisionHistory aivRevHist = new AivRevisionHistory();
						aivRevHist.setOverviewKey("O");
						aivRevHist.setOverviewData(ai.getNewDescription());
						aivRevHist.setAivId(aiv.getAssetInstVersionId());
						aivRevHist.setVersionName(aisdVoList.get(i).getVersionName());
						aivRevHistList.add(aivRevHist);
						
						//recent Activity
						RecentActivity recentActivity = new RecentActivity();
						recentActivity.setAssetName(ai.getAssetName());
						recentActivity.setAssetInstName(ai.getAssetInstName());
						recentActivity.setAssetInstanceVersionName(ai.getVersionName());
						recentActivity.setAssetInstVersionId(aiv.getAssetInstVersionId().toString());
						recentActivityList.add(recentActivity);
						
						assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
						aiv.setVersionName(ai.getVersionName());
						aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
					}
				}

				for(int i=0;i<apsVoList.size();i++)
				{
					NameValue nv = new NameValue();
					AssetInstance ai = new AssetInstance();
					ai.setAssetName(apsVoList.get(i).getAssetType());
					AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
					ai.setAssetId(asset.getAssetId());
					ai.setAssetInstName(apsVoList.get(i).getAssetInstName());
					ai.setVersionName(apsVoList.get(i).getVersionName());
					ai.setParentAssetName(apsVoList.get(i).getParentAssetName());
					ai.setParentAssetInstName(apsVoList.get(i).getParentAssetInstanceName());
					nv.setName(apsVoList.get(i).getParamName());
					AssetParamDef apd11 = assetDao.retParamIdForAssetAndParamName(apsVoList.get(i).getAssetType(), apsVoList.get(i).getParamName(), conn);

					AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
					ai.setAssetInstVersionId(aiv.getAssetInstVersionId());

					if(!apsVoList.get(i).getParamTypeId().equals(3L))
					{
						boolean flagCheck = false;
						if(apsVoList.get(i).isHasStaticValue() == false)
						{
							ParameterValues pv1	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);
							if(globalLock.getGlobalSettingFlag()== 1)
							{
								if(radValStatic.equalsIgnoreCase("New"))
								{
									if(pv1 != null)
									{
										if(aiv.getLockTime()!= null)
										{
											if(apd11.getParamTypeId().equals(7L) && apsVoList.get(i).getHasArray()==1){
												List<String> newTextData = apsVoList.get(i).getRTFwithTags();
												List<String> oldTextData = pv1.getRTFwithTags();
												if(!oldTextData.equals(newTextData)){
													//if(num < 0 || num > 0 ){
													flagCheck = false;
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){

												List<String> newTextData = apsVoList.get(i).getTextDataList();
												List<String> oldTextData = pv1.getTextDataList();
												if(!oldTextData.equals(newTextData)){
													//if(num < 0 || num > 0 ){
													flagCheck = false;
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											
											}else if(apd11.getParamTypeId().equals(9L)) {
												List<String> newLdapMappingData = apsVoList.get(i).getLdapMappingValue().keySet().stream()
														.collect(Collectors.toList());
												List<String> oldLdapMappingData = pv1.getLdapMappingList();
												if(!oldLdapMappingData.equals(newLdapMappingData)){
													//if(num < 0 || num > 0 ){
													flagCheck = false;
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											}else{
												String oldValueImp = pv1.getValue().trim().toString();
												String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

												int num = oldValueImp.compareTo(newValueImp);

												if(num < 0 || num > 0 ){
													flagCheck = false;
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											}
											
										}
										else
										{
											flagCheck = true;  
										}
									}
									else
									{
										if(aiv.getLockTime()!= null)
										{
											if(apd11.getParamTypeId().equals(7L) && apsVoList.get(i).getHasArray()==1){
												if(!apsVoList.get(i).getRTFwithTags().isEmpty())
												{
													flagCheck = false; 
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){
												if(!apsVoList.get(i).getTextDataList().isEmpty())
												{
													flagCheck = false; 
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											}else if(apd11.getParamTypeId().equals(9L)){
												if(!apsVoList.get(i).getLdapMappingValue().isEmpty())
												{
													flagCheck = false; 
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											}else{
												if(!apsVoList.get(i).getParamValue().isEmpty())
												{
													flagCheck = false; 
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											}
											
										}
										else
										{
											flagCheck = true; 
										}
									}
								}
								else
								{
									if(pv1 != null)
									{
										if(aiv.getLockTime()!= null)
										{
											if(apd11.getParamTypeId().equals(7L)&& apsVoList.get(i).getHasArray()==1){
												List<String> newTextData = apsVoList.get(i).getRTFwithTags();
												List<String> oldTextData = pv1.getRTFwithTags();
												if(!oldTextData.equals(newTextData))
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){
												List<String> newTextData = apsVoList.get(i).getTextDataList();
												List<String> oldTextData = pv1.getTextDataList();
												if(!oldTextData.equals(newTextData))
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											
											}else if(apd11.getParamTypeId().equals(9L)){
												List<String> newLdapMappingData = apsVoList.get(i).getLdapMappingValue().keySet().stream()
														.collect(Collectors.toList());
												List<String> oldLdapMappingData = pv1.getLdapMappingList();
												if(!oldLdapMappingData.equals(newLdapMappingData))
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											
											}else{
												String oldValueImp = pv1.getValue().trim().toString();
												String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

												int num = oldValueImp.compareTo(newValueImp);
												if(num < 0 || num > 0 )
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											}
											
										}
										else{
											flagCheck = true;  
										}
									}
									else
									{
										if(aiv.getLockTime()!= null)
										{
											if(apd11.getParamTypeId().equals(7L)&& apsVoList.get(i).getHasArray()==1){
												if(!apsVoList.get(i).getRTFwithTags().isEmpty())
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){
												if(!apsVoList.get(i).getTextDataList().isEmpty())
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											
											}else if(apd11.getParamTypeId().equals(9L)){
												if(!apsVoList.get(i).getLdapMappingValue().isEmpty())
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											
											}else{
												if(!apsVoList.get(i).getParamValue().isEmpty())
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											}
										}
										else
										{
											flagCheck = true; 
										}
									}
								}
							}
							else
							{
								flagCheck = true;
							}
						}
						else
						{
							if(globalLock.getGlobalSettingFlag()== 1)
							{
								if(radValStatic.equalsIgnoreCase("New"))
								{
									if(aiv.getLockTime()!= null)
									{
										//if(paramList.get(i).getStaticValue() != null)
										if(apd11.getStaticValue() != null)
										{
											String oldValueImp = apd11.getStaticValue().trim().toString();
											String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

											int num = oldValueImp.compareTo(newValueImp);

											if(num < 0 || num > 0 )
											{
												flagCheck = false;
												long databaseTime = aiv.getLockTime().getTime();
												long systemTime = System.currentTimeMillis();
												if( systemTime > databaseTime){
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}

												}else{
													if (log.isErrorEnabled()) {
														log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
													}
													lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
												}  
											}
										}
										else{
											if( !apsVoList.get(i).getParamValue().isEmpty()){
												flagCheck = false;
												if (log.isErrorEnabled()) {
													log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
												lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
											}
										}
									}
									else
									{
										flagCheck = true;
									}
								}
								else
								{
									if(aiv.getLockTime()!= null)
									{
										//if(paramList.get(i).getStaticValue() != null)
										if(apd11.getStaticValue() != null)
										{
											String oldValueImp = apd11.getStaticValue().trim().toString();
											String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

											int num = oldValueImp.compareTo(newValueImp);

											if(num < 0 || num > 0 )
											{
												if(apd11.getParamTypeId().equals(5L)){
												}else if(apd11.getParamTypeId().equals(6L)){ 
												}else if(apd11.getParamTypeId().equals(8L)){
												}else{
													aiv.setLockedBy(null);
													aiv.setLockTime(null);
													assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
													flagCheck = true;
												}
											}
										}
										else{
											if(!apsVoList.get(i).getParamValue().isEmpty()){
												if(apd11.getParamTypeId().equals(5L)){
												}else if(apd11.getParamTypeId().equals(6L)){ 
												}else if(apd11.getParamTypeId().equals(8L)){
												}else{
													aiv.setLockedBy(null);
													aiv.setLockTime(null);
													assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
													flagCheck = true;
												}
											}
										}
									}
									else
									{
										flagCheck = true;
									}
								}
							}
							else
							{
								flagCheck = true;
							}
						}
						AssetInstanceVersion assetInstver = null;

						nv.setValue(apsVoList.get(i).getParamValue());
						if(flagCheck == true)
						{
							assetInstver = new AssetInstanceVersion();
							assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
							if(apd11.getParamTypeId().equals(7L)){
								if(apsVoList.get(i).isHasStaticValue()){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else if(apsVoList.get(i).getHasArray()==0){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
									assetInstver.setRTFPlainText(apsVoList.get(i).getRTFPlainText());
								}else{
									assetInstver.setRTFwithOutTags(apsVoList.get(i).getRTFwithOutTags());
									assetInstver.setRTFwithTags(apsVoList.get(i).getRTFwithTags());
								}
							}else if(apd11.getParamTypeId().equals(1L)){
								if(apsVoList.get(i).isHasStaticValue()){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else if(apsVoList.get(i).getHasArray()==0){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else{
									assetInstver.setTextDataList(apsVoList.get(i).getTextDataList());
								}
							}else if(apsVoList.get(i).getParamTypeId().equals(9L)){
								assetInstver.setLdapMappingValue(apsVoList.get(i).getLdapMappingValue());
							}else{
								assetInstver.setParamValue(apsVoList.get(i).getParamValue());

							}
							
							assetInstver.setParamTypeId(apsVoList.get(i).getParamTypeId());
							if(apsVoList.get(i).isHasStaticValue() == false){
								assetInstver.setIsStatic(0);
							}else{
								assetInstver.setIsStatic(1);
							}
							apsVoList.get(i).isHasStaticValue();
							assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
							assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
							
							actualparamAivId.add(ai.getAssetInstVersionId());
							
							assetInstver.setAssetName(ai.getAssetName());
							assetInstver.setHasArray(apsVoList.get(i).getHasArray());
							assetInstanceVersionsManager.updateParameterForAssetInst(assetInstver, null, profile.getUserId(), conn);

							aiv.setVersionName(ai.getVersionName());
							aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);

							if(apd11.getParamTypeId().equals(5L)){
							}else if(apd11.getParamTypeId().equals(6L)){ 
							}else if(apd11.getParamTypeId().equals(8L)){
							}else{

								aiv.setVersionName(ai.getVersionName());
								aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);

							}
						}
					}

					else {
						boolean flagCheck1 = false;
						if(apsVoList.get(i).isHasStaticValue() == false)
						{
							ParameterValues pv1	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);

							if(globalLock.getGlobalSettingFlag()== 1)
							{
								if(radValStatic.equalsIgnoreCase("New"))
								{
									if(pv1 != null)
									{
										if(pv1.getFileName() != null)
										{
											if(aiv.getLockTime()!= null)
											{
												if(!pv1.getFileName().equals(apsVoList.get(i).getParamValue()))
												{
													flagCheck1 = false;
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck1 = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											}
											else{
												flagCheck1 = true;
											}
										}
									}
									else
									{
										if(aiv.getLockTime()!= null)
										{
											if(!apsVoList.get(i).getParamValue().isEmpty())
											{
												flagCheck1 = false;
												long databaseTime = aiv.getLockTime().getTime();
												long systemTime = System.currentTimeMillis();
												if( systemTime > databaseTime){
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck1 = true;
													}
												}else{
													if (log.isErrorEnabled()) {
														log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
													}
													lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
												}
											}
										}
										else{
											flagCheck1 = true;
										}
									}
								}
								else
								{
									if(pv1 != null)
									{
										if(pv1.getFileName() != null)
										{
											if(aiv.getLockTime()!= null)
											{
												if(!pv1.getFileName().equals(apsVoList.get(i).getParamValue()))
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck1 = true;
													}
												}
											}
										}
									}
									else
									{
										if(aiv.getLockTime()!= null)
										{
											if(!apsVoList.get(i).getParamValue().isEmpty())
											{
												if(apd11.getParamTypeId().equals(5L)){
												}else if(apd11.getParamTypeId().equals(6L)){ 
												}else if(apd11.getParamTypeId().equals(8L)){
												}else{
													aiv.setLockedBy(null);
													aiv.setLockTime(null);
													assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
													flagCheck1 = true;
												}
											}
										}
									}
								}

							}
							else{
								flagCheck1 = true;
							}
						}
						else
						{
							if(globalLock.getGlobalSettingFlag()== 1)
							{
								if(radValStatic.equalsIgnoreCase("New"))
								{
									if(aiv.getLockTime()!= null)
									{
										if(apd11.getFileName() != null)
										{
											String oldValueImp = apd11.getFileName().trim().toString();
											String newValueImp = apsVoList.get(i).getParamValue().trim().toString();
											int num = oldValueImp.compareTo(newValueImp);

											if(num < 0 || num > 0 )
											{
												flagCheck1 = false;
												long databaseTime = aiv.getLockTime().getTime();
												long systemTime = System.currentTimeMillis();
												if( systemTime > databaseTime){
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck1 = true;
													}
												}else{
													if (log.isErrorEnabled()) {
														log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
													}
													lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
												}

											}
										}
										else{
											if( !apsVoList.get(i).getParamValue().isEmpty()){
												flagCheck1 = false;
												if (log.isErrorEnabled()) {
													log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
												lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
											}
										}
									}
									else{
										flagCheck1 = true;
									}
								}
								else
								{
									if(aiv.getLockTime()!= null)
									{
										if(apd11.getFileName() != null)
										{
											String oldValueImp = apd11.getFileName().trim().toString();
											String newValueImp = apsVoList.get(i).getParamValue().trim().toString();
											int num = oldValueImp.compareTo(newValueImp);

											if(num < 0 || num > 0 )
											{
												if(apd11.getParamTypeId().equals(5L)){
												}else if(apd11.getParamTypeId().equals(6L)){ 
												}else if(apd11.getParamTypeId().equals(8L)){
												}else{
													aiv.setLockedBy(null);
													aiv.setLockTime(null);
													assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
													flagCheck1 = true;
												}
											}
										}
										else{
											if( !apsVoList.get(i).getParamValue().isEmpty()){
												if(apd11.getParamTypeId().equals(5L)){
												}else if(apd11.getParamTypeId().equals(6L)){ 
												}else if(apd11.getParamTypeId().equals(8L)){
												}else{
													aiv.setLockedBy(null);
													aiv.setLockTime(null);
													assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
													flagCheck1 = true;
												}
											}
										}
									}
									else{
										flagCheck1 = true;
									}
								}
							}
							else{
								flagCheck1 = true;
							}
						}

						Map<String,String> paramMapFromDb = new LinkedHashMap<String, String>();
						AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
						List<AssetParamDef> paramMap = new ArrayList<AssetParamDef>();
						List<AssetInstanceVersion> assetdata = assetInstanceVersionsManager.getParameter(ai.getAssetName(),userName,aiv1.getAssetInstVersionId(),conn);
						for(AssetInstanceVersion aivData: assetdata){
							AssetParamDef apd = new AssetParamDef();
							if (aivData.getIsStatic() == 1) {
								if (aivData.getParamTypeId() == 3) {
									apd.setAssetParamName(aivData.getAssetParamName());
									apd.setParamValue(aivData.getApdFileName());
								}else{
									apd.setAssetParamName(aivData.getAssetParamName());
									apd.setParamValue(aivData.getStaticValue());
								}

							} else {
								if (aivData.getParamTypeId() == 3) {
									apd.setAssetParamName(aivData.getAssetParamName());
									apd.setParamValue(aivData.getFileName());
								}else if(aivData.getParamTypeId() == 1){
									if(aivData.getTextDataList()!= null){
										String textdata = String.join("~~", aivData.getTextDataList());
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(textdata);
									}else{
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getParamValue());
									}
								}else if(aivData.getParamTypeId() == 7){
									if(aivData.getRTFwithTags()!= null){
										String textdata = String.join("~~", aivData.getRTFwithTags());
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(textdata);
									}else{
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getParamValue());
									}
								}else if(aivData.getParamTypeId() == 9){
									if(aivData.getLdapMappingValue() != null) {
										List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(aivData.getLdapMappingId(), conn);
										for (Map.Entry<String,Integer> entry : aivData.getLdapMappingValue().entrySet()){
											for(LdapMapping ldapAttributes:ldapMapping) {
												if(entry.getValue() == ldapAttributes.getLdapAttributeId()) {
													apd.setAssetParamName(aivData.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
												//	LdapMapping attribute = assetDao.getLdapMappingAttributeByattributeId(attributeId, conn);
													///List<String> values = aiv.getLdapMappingValue().keySet().stream().collect(Collectors.toList());
													apd.setParamValue(null);
												}
											}
										}
									}
								}else {
									apd.setAssetParamName(aivData.getAssetParamName());
									apd.setParamValue(aivData.getParamValue());
								}
							}
							paramMap.add(apd);
						}
						for (AssetParamDef assetdef : paramMap) paramMapFromDb.put(assetdef.getAssetParamName(),assetdef.getParamValue()+"|"+apsVoList.get(i).isHasStaticValue());
						String OldFileName = null; 
						boolean updateFlag = false;
						for (Map.Entry<String, String> entry : paramMapFromDb.entrySet()) {
							String splitStaticVal = entry.getValue().substring(entry.getValue().indexOf("|")+1);
							String splitVal = entry.getValue().substring(0,entry.getValue().indexOf("|"));
							if(apsVoList.get(i).getParamName().equalsIgnoreCase(entry.getKey())){
								if(!apsVoList.get(i).getParamValue().equalsIgnoreCase(splitVal.toString())){
									//ParameterValues pv	= assetInstanceManager.getParameterForAssetInstParamAndVersionName(ai, apsVoList.get(i).getParamName());
									ParameterValues pv = null;
									AssetParamDef apd = null;
									/*if(splitStaticVal.equalsIgnoreCase("true"))
								{
									apd = assetDao.retParamIdForAssetAndParamName(apsVoList.get(i).getAssetType(), apsVoList.get(i).getParamName(), conn);
								}
								else
								{
									pv = assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);
								}*/
									if(apsVoList.get(i).getParamValue() != "" && apsVoList.get(i).getParamValue() !=null)	
									{
										File file= new File(System.getProperty("user.home")+"/RepoProUnzip/"+apsVoList.get(i).getParamValue());

										nv.setFileName(file.getName());

										nv.setByteValue(FileUtils.readFileToByteArray(file));

										nv.setFileMimeType(new MimetypesFileTypeMap().getContentType(file));

										OldFileName = splitVal.toString();

										/*if(file.getName().endsWith(".png") || file.getName().endsWith(".jpg") ||  file.getName().endsWith(".jpeg") ||file.getName().endsWith(".PNG") || file.getName().endsWith(".JPG") ||  file.getName().endsWith(".JPEG"))
									{
										if(file.getName().endsWith(".png") || file.getName().endsWith(".jpg") ||  file.getName().endsWith(".jpeg") ||file.getName().endsWith(".PNG") || file.getName().endsWith(".JPG") ||  file.getName().endsWith(".JPEG")){
											if(splitStaticVal.equalsIgnoreCase("true"))
											{
												FileOutputStream fos = new FileOutputStream(System.getProperty("java.io.tmpdir")+apd.getAssetParamId().toString()+"_"+file.getName());
												fos.write(FileUtils.readFileToByteArray(file));
												fos.close();
											}
											else
											{
												if(pv != null)
												{
													FileOutputStream fos = new FileOutputStream(System.getProperty("java.io.tmpdir")+pv.getAssetParamId().toString()+"_"+file.getName());
													fos.write(FileUtils.readFileToByteArray(file));
													fos.close();
												}
												else
												{
													FileOutputStream fos = new FileOutputStream(System.getProperty("java.io.tmpdir")+file.getName());
													fos.write(FileUtils.readFileToByteArray(file));
													fos.close();
												}
											}

											Image image ;

											if(splitStaticVal.equalsIgnoreCase("true"))
											{
												image = Toolkit.getDefaultToolkit().getImage(System.getProperty("java.io.tmpdir")+apd.getAssetParamId().toString()+"_"+file.getName());
											}
											else
											{
												if(pv != null)
												{

													image = Toolkit.getDefaultToolkit().getImage(System.getProperty("java.io.tmpdir")+pv.getAssetParamId().toString()+"_"+file.getName());
												}
												else
												{
													image = Toolkit.getDefaultToolkit().getImage(System.getProperty("java.io.tmpdir")+file.getName());
												} 
											}

											MediaTracker mediaTracker = new MediaTracker(new Container());
											mediaTracker.addImage(image, 0);
											int thumbWidth = 60;
											int thumbHeight = 60;
											int quality = 100;


											double thumbRatio = (double)thumbWidth / (double)thumbHeight;
											int imageWidth = image.getWidth(null);
											int imageHeight = image.getHeight(null);
											double imageRatio = (double)imageWidth / (double)imageHeight;
											if (thumbRatio < imageRatio) {
												thumbHeight = (int)(thumbWidth / imageRatio);
											} else {
												thumbWidth = (int)(thumbHeight * imageRatio);
											}

											// draw original image to thumbnail image object and
											// scale it to the new size on-the-fly
											BufferedImage thumbImage = new BufferedImage(thumbWidth, thumbHeight, BufferedImage.TYPE_INT_RGB);
											Graphics2D graphics2D = thumbImage.createGraphics();
											graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
											graphics2D.drawImage(image, 0, 0, thumbWidth, thumbHeight, null);

											// save thumbnail image to outFilename
											//System.out.println(request.getRealPath(""));
											BufferedOutputStream out;
											JPEGEncodeParam param;
											JPEGImageEncoder encoder;
											String sfile = "";


											// save thumbnail image to outFilename
											// System.out.println(getServletContext().getRealPath(""));
											File file4 = new File(System.getProperty("user.home")+"/ThumbnailImages");
											if (!file4.exists()) {
												if (file4.mkdir()) {
													System.out.println("Directory thumbnailimages is created!");
												} else {
													System.out.println("Failed to create directory thumbnailimages!");
												}
											}

											if(splitStaticVal.equalsIgnoreCase("true"))
											{
												out = new BufferedOutputStream(new FileOutputStream(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+file.getName()));
												sfile = request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+file.getName();
												encoder = JPEGCodec.createJPEGEncoder(out);
												param = encoder.getDefaultJPEGEncodeParam(thumbImage);
												quality = Math.max(0, Math.min(quality, 100));
												param.setQuality((float)quality / 100.0f, false);
												encoder.setJPEGEncodeParam(param);
												encoder.encode(thumbImage);
											}
											else
											{
												if(pv != null)
												{
													out = new BufferedOutputStream(new FileOutputStream(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+file.getName()));
													sfile = request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+file.getName();
													encoder = JPEGCodec.createJPEGEncoder(out);
													param = encoder.getDefaultJPEGEncodeParam(thumbImage);
													quality = Math.max(0, Math.min(quality, 100));
													param.setQuality((float)quality / 100.0f, false);
													encoder.setJPEGEncodeParam(param);
													encoder.encode(thumbImage);
												}
												else
												{
													out = new BufferedOutputStream(new FileOutputStream(request.getRealPath("")+"/images/thumbnailImages/"+file.getName()));
													sfile = request.getRealPath("")+"/images/thumbnailImages/"+file.getName();
													encoder = JPEGCodec.createJPEGEncoder(out);
													param = encoder.getDefaultJPEGEncodeParam(thumbImage);
													quality = Math.max(0, Math.min(quality, 100));
													param.setQuality((float)quality / 100.0f, false);
													encoder.setJPEGEncodeParam(param);
													encoder.encode(thumbImage);
													//copy from above to user.home
													java.util.Date date= new java.util.Date();
													String time = new Timestamp(date.getTime()).toString();
													valMap.put(apsVoList.get(i).getParamName(), time+"|"+file.getName());
												} 
											}
											out.close();
											File sourceFile = new File(sfile);
											String name = sourceFile.getName();
											File targetFile = new File(System.getProperty("user.home")+"/ThumbnailImages/"+name);
											FileUtils.copyFile(sourceFile, targetFile);

											if(!splitVal.toString().equalsIgnoreCase("null")){
												if(!splitVal.toString().equalsIgnoreCase(file.getName()))
												{ 
													if(splitStaticVal.equalsIgnoreCase("true"))
													{
														File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
														if(filePath.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File doesn't exist");

														File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
														if(file5.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File doesn't exist");
													}
													else
													{
														if(pv != null)
														{
															File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
															if(filePath.delete())
															{
																System.out.println(" File deleted");
															}
															else System.out.println("File doesn't exist");

															File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
															if(file5.delete())
															{
																System.out.println(" File deleted");
															}
															else System.out.println("File doesn't exist");
														}
														else
														{
															File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+splitVal);
															if(filePath.delete())
															{
																System.out.println(" File deleted");
															}
															else System.out.println("File doesn't exist");

															File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+splitVal);
															if(file5.delete())
															{
																System.out.println(" File deleted");
															}
															else System.out.println("File doesn't exist");
														}

													}

												} 
											}
										}
										else if(file.getName().equalsIgnoreCase("") || file.getName().equalsIgnoreCase("null")){
											if(!splitVal.toString().equalsIgnoreCase("null")){
												if(splitStaticVal.equalsIgnoreCase("true"))
												{
													File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
													if(filePath1.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File  doesn't exists");	

													File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
													if(file7.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist"); 
												}
												else
												{
													if(pv != null)
													{
														File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
														if(filePath1.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File  doesn't exists");	

														File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
														if(file7.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File doesn't exist");  
													}
													else
													{
														File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+splitVal);
														if(filePath1.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File  doesn't exists");	

														File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+splitVal);
														if(file7.delete())
														{
															System.out.println(" File deleted");
														}
														else System.out.println("File doesn't exist"); 
													}
												}

											}
										}
										if(splitStaticVal.equalsIgnoreCase("true"))
										{
											File file1 = new File(System.getProperty("java.io.tmpdir")+apd.getAssetParamId().toString()+"_"+file.getName());
											if(file1.delete())
											{
												System.out.println(" File deleted");
											}
											else System.out.println("File doesn't exist"); 
										}
										else
										{
											if(pv != null)
											{
												File file1 = new File(System.getProperty("java.io.tmpdir")+pv.getAssetParamId().toString()+"_"+file.getName());
												if(file1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
											else
											{
												File file1 = new File(System.getProperty("java.io.tmpdir")+file.getName());
												if(file1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
										}
									}

									if(file.getName().equalsIgnoreCase("") && !splitVal.toString().equalsIgnoreCase("null")) 
									{
										if(!splitVal.toString().equalsIgnoreCase(file.getName()))
										{ 
											if(splitStaticVal.equalsIgnoreCase("true"))
											{
												File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
												if(filePath.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist");

												File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
												if(file5.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist");
											}
											else
											{
												if(pv != null)
												{
													File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
													if(filePath.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist");

													File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
													if(file5.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist");
												}
												else
												{
													File filePath = new File(request.getRealPath("")+"/images/thumbnailImages/"+splitVal);
													if(filePath.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist");

													File file5 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+splitVal);
													if(file5.delete())
													{
														System.out.println(" File deleted");
													}
													else System.out.println("File doesn't exist");
												}
											}
										}
										if(splitStaticVal.equalsIgnoreCase("true"))
										{
											File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
											if(filePath1.delete())
											{
												System.out.println(" File deleted");
											}
											else System.out.println("File  doesn't exists");	

											File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+apd.getAssetParamId().toString()+"_"+splitVal);
											if(file7.delete())
											{
												System.out.println(" File deleted");
											}
											else System.out.println("File doesn't exist"); 
										}
										else
										{
											if(pv != null)
											{
												File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
												if(filePath1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File  doesn't exists");	

												File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString()+"_"+splitVal);
												if(file7.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist");  
											}
											else
											{
												File filePath1 = new File(request.getRealPath("")+"/images/thumbnailImages/"+splitVal);
												if(filePath1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File  doesn't exists");	
												File file7 = new File(System.getProperty("user.home")+"/ThumbnailImages/"+splitVal);
												if(file7.delete()){
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
										}
										if(splitStaticVal.equalsIgnoreCase("true")){
											File file1 = new File(System.getProperty("java.io.tmpdir")+apd.getAssetParamId().toString()+"_"+file.getName());
											if(file1.delete()){
												System.out.println(" File deleted");
											}
											else System.out.println("File doesn't exist"); 
										}
										else{
											if(pv != null){
												File file1 = new File(System.getProperty("java.io.tmpdir")+pv.getAssetParamId().toString()+"_"+file.getName());
												if(file1.delete())
												{
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
											else{
												File file1 = new File(System.getProperty("java.io.tmpdir")+file.getName());
												if(file1.delete()){
													System.out.println(" File deleted");
												}
												else System.out.println("File doesn't exist"); 
											}
										}
									}
										 */
										updateFlag = true;
										break;
										}
									else{
										byte[] empty = {} ;
										nv.setFileName(apsVoList.get(i).getParamValue());
										nv.setByteValue(empty);
										nv.setFileMimeType(null);
										updateFlag = true;
										break;
									}	
								}	
							}
						}
						if(flagCheck1 == true)
						{
							if(updateFlag == true){
								AssetInstanceVersion assetInstver = null;
								if(apd11.getParamTypeId().equals(5L)){
								}else if(apd11.getParamTypeId().equals(6L)){ 
								}else if(apd11.getParamTypeId().equals(8L)){
								}else{
									assetInstver = new AssetInstanceVersion();
									assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
									assetInstver.setParamTypeId(apd11.getParamTypeId());
									if(apsVoList.get(i).isHasStaticValue() == false){
										assetInstver.setIsStatic(0);
									}else{
										assetInstver.setIsStatic(1);
									}
									apsVoList.get(i).isHasStaticValue();
									nv.setName(apsVoList.get(i).getParamName());
									InputStream myInputStream = null ;
									myInputStream = new ByteArrayInputStream(nv.getByteValue()); 
									nv.setImage(myInputStream);
									assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
									assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
									
									//recent activity
									actualparamAivId.add(ai.getAssetInstVersionId());
									
									assetInstver.setAssetName(ai.getAssetName());
									assetInstanceVersionsManager.updateParameterForAssetInst(assetInstver,nv,profile.getUserId(),conn);

									aiv.setVersionName(ai.getVersionName());
									aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aiv,aiv.getAssetInstVersionId(), conn);

									assetInstver.setFileName(OldFileName);
									assetInstver.setNewFileName(nv.getFileName());
									InputStream myInputStream1 = null;
									myInputStream1 = new ByteArrayInputStream(nv.getByteValue()); 
									assetInstanceVersionsManager.getNameValue(assetInstver, myInputStream1, nv.getFileName(), context, conn);
								}
							}
						}


						/*if(!valMap1.isEmpty()){
						for (Map.Entry<String, String> entry : valMap1.entrySet())
						{
							ParameterValues pv	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);
							if(pv != null){
								String splitVal = entry.getValue().substring(entry.getValue().indexOf("|")+1);
								File oldfile =new File(request.getRealPath("")+"/images/thumbnailImages/" +splitVal);
								File newfile =new File(request.getRealPath("")+"/images/thumbnailImages/" +pv.getAssetParamId().toString() +"_"+ splitVal);
								oldfile.renameTo(newfile);
								File oldfile1 =new File(System.getProperty("user.home")+"/ThumbnailImages/" + splitVal);
								File newfile1 =new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString() +"_"+ splitVal);
								oldfile1.renameTo(newfile1);
							}
						}
					}*/
					}
					/*RecentActivity recentActivity = new RecentActivity();
					String action = Constants.ACTIVITY_MODIFY;
					String appendingMsg = "";
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					recentActivity.setAssetId(ai.getAssetId().toString());
					recentActivity.setAssetInstVersionId(ai.getAssetInstVersionId().toString());
					recentActivity.setUser_id(profile.getUserId());

					if (asset.isVersionable() == true) {
						String log = profile.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ ai.getAssetInstName() + ";"+ " Version " + ai.getVersionName();
						recentActivity.setDescription(log);
					} else {
						String log = profile.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ ai.getAssetInstName() + ";"+ appendingMsg;
						recentActivity.setDescription(log);
					}
					recentActivityDao.addRecentActivity(recentActivity, conn);*/

				}  //End of for

				List<Long> paramAivId = new ArrayList<Long>();
				List<Long> finalparamAivId = new ArrayList<Long>();
				for(int i=0;i<azds.size();i++)
				{
					AssetInstance ai = new AssetInstance();

					ai.setAssetName(azds.get(i).getAssetName());
					ai.setAssetInstName(azds.get(i).getAssetInstName());
					ai.setVersionName(azds.get(i).getVersionName());
					//revision history data for parameter
					AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);
					
					if(actualparamAivId.contains(aivVo.getAssetInstVersionId())){
						paramAivId.add(aivVo.getAssetInstVersionId());
						
						for(AivRevisionHistory paramRev:aivRevHistList){
							if(paramRev.getAivId().equals(aivVo.getAssetInstVersionId())){
								finalparamAivId.add(aivVo.getAssetInstVersionId());
								paramRev.setParameterKey("P");
								paramRev.setParameterData(azds.get(i).getParamRevData());
								paramRev.setVersionName(azds.get(i).getVersionName());
							}
						}
					}
				/*	assetInstanceVersionsManager.addRevisionData("P",aivVo.getAssetInstVersionId(),ai.getVersionName(),null, null, 
							azds.get(i).getParamRevData(), null,userName,profile.getUserId(),null,conn);*/

				}
				paramAivId.removeAll(finalparamAivId);
				
				for(int i=0;i<azds.size();i++)
				{
					AssetInstance ai = new AssetInstance();
					ai.setAssetName(azds.get(i).getAssetName());
					ai.setAssetInstName(azds.get(i).getAssetInstName());
					ai.setVersionName(azds.get(i).getVersionName());
					//revision history data for parameter
					AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);

					for(Long paramRev:paramAivId){
						if(paramRev.equals(aivVo.getAssetInstVersionId())){
							AivRevisionHistory revHis = new AivRevisionHistory();
							revHis.setParameterKey("P");
							revHis.setParameterData(azds.get(i).getParamRevData());
							revHis.setVersionName(azds.get(i).getVersionName());
							revHis.setAivId(aivVo.getAssetInstVersionId());
							aivRevHistList.add(revHis);
							
							RecentActivity recentActivity = new RecentActivity();
							recentActivity.setAssetName(azds.get(i).getAssetName());
							recentActivity.setAssetInstName(azds.get(i).getAssetInstName());
							recentActivity.setAssetInstanceVersionName(azds.get(i).getVersionName());
							recentActivity.setAssetInstVersionId(aivVo.getAssetInstVersionId().toString());
							recentActivityList.add(recentActivity);
							
							aivIds.add(aivVo.getAssetInstVersionId().toString());
						}
					}
				}
				
				
				for(int i=0;i<assetInstassignList.size();i++)
				{
					AssetInstance ai = new AssetInstance();

					ai.setAssetName(assetInstassignList.get(i).getAssetName());
					ai.setAssetInstName(assetInstassignList.get(i).getAssetInstanceName());
					ai.setVersionName(assetInstassignList.get(i).getVersionName());

					AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);

					AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

					String taxonomies = null;
					taxonomies = StringUtils.join(assetInstassignList.get(i).getTaxonIds(), ',');

					if(globalLock.getGlobalSettingFlag()==1){
						if(radValStatic.equalsIgnoreCase("New")){

							if(aiv.getLockTime()==null){
								Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
										taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
								MyModel res = (MyModel) response.getEntity();
								Map<String,String> data = res.getParamValues();
								taxIds.put(aiv.getAssetInstVersionId().toString(),data);
								aivIds.add(aiv.getAssetInstVersionId().toString());

								aiv.setVersionName(ai.getVersionName());
								aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
							}
							else{
								long databaseTime = aiv.getLockTime().getTime();
								long systemTime = System.currentTimeMillis();
								if( systemTime > databaseTime ){
									aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
									aiv.setLockedBy(null);
									aiv.setLockTime(null);
									assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);

									Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
											taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
									MyModel res = (MyModel) response.getEntity();
									Map<String,String> data = res.getParamValues();
									taxIds.put(aiv.getAssetInstVersionId().toString(),data);
									aivIds.add(aiv.getAssetInstVersionId().toString());

									aiv.setVersionName(ai.getVersionName());
									aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
								}
								else{
									if (log.isErrorEnabled()) {
										log.error("Asset Instance Version Taxonomies cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
									}
									lockedVersionIds.add("Asset Instance Version Taxonomies cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
								}
							}
						}
						else{
							if(aiv.getLockTime()!=null){
								aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
								aiv.setLockedBy(null);
								aiv.setLockTime(null);
								assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
							}
							Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
									taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
							MyModel res = (MyModel) response.getEntity();
							Map<String,String> data = res.getParamValues();
							taxIds.put(aiv.getAssetInstVersionId().toString(),data);
							aivIds.add(aiv.getAssetInstVersionId().toString());

							aiv.setVersionName(ai.getVersionName());
							aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
						}
					}
					else{

						Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
								taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
						MyModel res = (MyModel) response.getEntity();
						Map<String,String> data = res.getParamValues();
						taxIds.put(aiv.getAssetInstVersionId().toString(),data);
						aivIds.add(aiv.getAssetInstVersionId().toString());

						aiv.setVersionName(ai.getVersionName());
						aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
					}
				}
				
				TaggingMaster taggingMaster = new TaggingMaster();
				for(int i=0;i<assetInstTaggingList.size();i++)
				{
					AssetInstance ai = new AssetInstance();

					ai.setAssetName(assetInstTaggingList.get(i).getAssetName());
					ai.setAssetInstName(assetInstTaggingList.get(i).getAssetInstanceName());
					ai.setVersionName(assetInstTaggingList.get(i).getVersionName());
					AssetInstanceVersion aivtag = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
					ai.setAssetInstVersionId(aivtag.getAssetInstVersionId());

					taggingMaster.setAssetInstanceVersionId(ai.getAssetInstVersionId());
					TaggingMaster tagsForAIV = taggingDao.getAllTags(taggingMaster, conn);
					List<String> tagsFromXls = assetInstTaggingList.get(i).getTagsFromXls();
					taggingMaster.setUserId(profile.getUserId());
					taggingMaster.setAssetInstanceVersionId(ai.getAssetInstVersionId());


					if(globalLock.getGlobalSettingFlag()==1){
						if(radValStatic.equalsIgnoreCase("New")){

							if(aivtag.getLockTime()==null){
								for (String tagNameFromXls : tagsFromXls )
								{
									boolean addflg = false;
									for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
									{
										if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
										{
											addflg = true;
											break;
										}
									}
									if(!addflg)
									{
										taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

									}
								}

								for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
								{
									boolean rmflg = false;
									taggingMaster.setTagId(tagNameForAIV.getKey());
									for( String tagNameFromXls: tagsFromXls)
									{
										if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
										{
											rmflg = true;
											break;
										}
									}

									if(!rmflg)
									{
										taggingDao.deleteTagsForImport(taggingMaster, conn);

									}
								}
								aivtag.setVersionName(ai.getVersionName());
								aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
							}
							else{
								long databaseTime = aivtag.getLockTime().getTime();
								long systemTime = System.currentTimeMillis();
								if( systemTime > databaseTime ){
									aivtag.setAssetInstVersionId(aivtag.getAssetInstVersionId());
									aivtag.setLockedBy(null);
									aivtag.setLockTime(null);
									assetInstanceVersionDao.updateAssetInstanceVersion(aivtag, conn);

									for (String tagNameFromXls : tagsFromXls )
									{
										boolean addflg = false;
										for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
										{
											if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
											{
												addflg = true;
												break;
											}
										}
										if(!addflg)
										{
											taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

										}
									}

									for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
									{
										boolean rmflg = false;
										taggingMaster.setTagId(tagNameForAIV.getKey());
										for( String tagNameFromXls: tagsFromXls)
										{
											if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
											{
												rmflg = true;
												break;
											}
										}

										if(!rmflg)
										{
											taggingDao.deleteTagsForImport(taggingMaster, conn);

										}
									}
									aivtag.setVersionName(ai.getVersionName());
									aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
								}
								else{
									if (log.isErrorEnabled()) {
										log.error("Asset Instance Version tags cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
									}
									lockedVersionIds.add("Asset Instance Version tags cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
								}
							}
						}
						else{
							if(aivtag.getLockTime()!=null){
								aivtag.setAssetInstVersionId(aivtag.getAssetInstVersionId());
								aivtag.setLockedBy(null);
								aivtag.setLockTime(null);
								assetInstanceVersionDao.updateAssetInstanceVersion(aivtag, conn);
							}
							for (String tagNameFromXls : tagsFromXls )
							{
								boolean addflg = false;
								for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
								{
									if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
									{
										addflg = true;
										break;
									}
								}
								if(!addflg)
								{
									taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

								}
							}

							for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
							{
								boolean rmflg = false;
								taggingMaster.setTagId(tagNameForAIV.getKey());
								for( String tagNameFromXls: tagsFromXls)
								{
									if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
									{
										rmflg = true;
										break;
									}
								}

								if(!rmflg)
								{
									taggingDao.deleteTagsForImport(taggingMaster, conn);

								}
							}
							aivtag.setVersionName(ai.getVersionName());
							aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
						}
					}
					else{

						for (String tagNameFromXls : tagsFromXls )
						{
							boolean addflg = false;
							for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
							{
								if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
								{
									addflg = true;
									break;
								}
							}
							if(!addflg)
							{
								taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

							}
						}

						for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
						{
							boolean rmflg = false;
							taggingMaster.setTagId(tagNameForAIV.getKey());
							for( String tagNameFromXls: tagsFromXls)
							{
								if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
								{
									rmflg = true;
									break;
								}
							}

							if(!rmflg)
							{
								taggingDao.deleteTagsForImport(taggingMaster, conn);

							}
						}
						aivtag.setVersionName(ai.getVersionName());
						aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
					}
				}
			}
			log.info("Asset Attribute ,Taxonomy and Tagging DB updation done for incremental update "+listOfassetInstList.toString());

			// Loop Starts for Asset Instance Relationship update 3rd level
			List<Long> relSrcAivIds = new ArrayList<Long>();
			List<Long> recentActivityIds = new ArrayList<Long>();
			Map<String,String> aivIdslist = new LinkedHashMap<String,String>();

			if(errorsOnProc.isEmpty() && apeVoList.isEmpty())
			{
				for (Entry<String, List<AssetInstRelationship>> entry : listOfassetInstRelList.entrySet())
				{
					for(AssetInstRelationship aiv:entry.getValue())
					{
						AssetInstanceVersion ai = new AssetInstanceVersion();
						ai.setAssetName(aiv.getSrcAssetName());
						ai.setAssetInstName(aiv.getSourceInstanceName());
						ai.setVersionName(aiv.getSourceVersionName());
						AssetDef assetsrc = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

						AssetInstance assetIns = new AssetInstance();
						assetIns.setAssetName(ai.getAssetName());
						assetIns.setAssetInstName(ai.getAssetInstName());
						assetIns.setVersionName(ai.getVersionName());
						AssetInstanceVersion aivValue = assetInstanceVersionDao.getAssetInstanceVersion(assetIns, conn);
						ai.setAssetInstVersionId(aivValue.getAssetInstVersionId());
						
						if(aiv.getAction().equals("add"))
						{
							AssetInstance adr1 = new AssetInstance();

							adr1.setAssetName(aiv.getDestAssetName());
							AssetDef assetDataDest = assetInstanceDao.retAssetDetail(adr1.getAssetName(), conn);
							adr1.setAssetId(assetDataDest.getAssetId());
							adr1.setAssetInstName(aiv.getDestInstanceName());
							adr1.setOwner(userName);
							adr1.setVersionName("1.0");

							adr1.setParentVersionName(aiv.getSourceVersionName());
							adr1.setParentAssetName(aiv.getSrcAssetName());
							AssetDef assetDataSrc = assetInstanceDao.retAssetDetail(adr1.getParentAssetName(), conn);
							adr1.setParentAssetId(assetDataSrc.getAssetId());
							adr1.setParentAssetInstName(aiv.getSourceInstanceName());
							adr1.setOwner(profile.getUserName());

							AssetInstance parentAIVid = new AssetInstance();
							parentAIVid.setAssetName(adr1.getParentAssetName());
							parentAIVid.setAssetInstName(adr1.getParentAssetInstName());
							parentAIVid.setVersionName(adr1.getParentVersionName());
							AssetInstanceVersion parentaiv = assetInstanceVersionDao.getAssetInstanceVersion(parentAIVid, conn);
							adr1.setParentAssetInstVersionId(parentaiv.getAssetInstVersionId());

							if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation"))
							{
								//add child
								Response response = assetInstanceManager.addAssetInstanceHelper(adr1,userName,true,true,true,conn);
								MyModel res = (MyModel) response.getEntity();
								List<Object> data = res.getResult();
								for (int i = 0; i < data.size(); i++) {
									AssetInstance aiResponse = new AssetInstance();
									aiResponse = (AssetInstance) data.get(i);
									ai.setAssetInstanceId(aiResponse.getAssetInstId());
									ai.setAssetInstVersionId(aiResponse.getAssetInstVersionId());
								}
								aivIdslist.put(ai.getAssetInstVersionId().toString(),aiv.getAction());
								
								ai.setVersionName(ai.getVersionName());
								ai.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(ai, ai.getAssetInstVersionId(), conn);
							}
							else
							{
								//add relationship
								List<Long> addAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> selectedAssetRelationship = new ArrayList<Long>();
								List<Long> removedAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> removedAssetRelationship = new ArrayList<Long>();

								AssetInstance assetInstance = new AssetInstance();
								assetInstance.setAssetName(aiv.getDestAssetName());
								assetInstance.setAssetInstName(aiv.getDestInstanceName());
								assetInstance.setVersionName(aiv.getDestInstanceVersionName());

								AssetInstanceVersion aivo =	assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

								addAssetInstanceVersionIds.add(aivo.getAssetInstVersionId());

								AssetRelationshipDef ard = relationshipDao.retAssetRelDefForAssetsByRelationName(aiv.getSrcAssetName(),aiv.getDestAssetName(),aiv.getDescrption(), conn);

								selectedAssetRelationship.add(ard.getAssetRelId());

								ai.setAddDestAssetInstVersionIds(addAssetInstanceVersionIds);
								ai.setAddRelationshipIds(selectedAssetRelationship);
								ai.setRemovedDestAssetInstVersionIds(removedAssetInstanceVersionIds);
								ai.setRemovedRelationshipIds(removedAssetRelationship);
								ai.setSrcAssetInstanceVersionId(ai.getAssetInstVersionId().toString());
								ai.setAssetInstanceId(aivValue.getAssetInstanceId());
								ai.setAssetId(assetsrc.getAssetId());

								if(globalLock.getGlobalSettingFlag()==1){
									if(radValStatic.equalsIgnoreCase("New")){
										if(aivValue.getLockTime()==null){
											assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
											//get all the source asset instance version ids
											relSrcAivIds.add(ai.getAssetInstVersionId());
											recentActivityIds.add(ai.getAssetInstVersionId());
											aivIds.add(ai.getAssetInstVersionId().toString());
											
											aivo.setVersionName(ai.getVersionName());
											aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

										}
										else{
											long dataBaseTime = aivValue.getLockTime().getTime();
											long systemTime = System.currentTimeMillis();
											if(systemTime>dataBaseTime){
												aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
												aivValue.setLockedBy(null);
												aivValue.setLockTime(null);
												assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);

												assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
												//get all the source asset instance version ids
												relSrcAivIds.add(ai.getAssetInstVersionId());
												recentActivityIds.add(ai.getAssetInstVersionId());
												aivIds.add(ai.getAssetInstVersionId().toString());
												
												aivo.setVersionName(ai.getVersionName());
												aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
												assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

											}
											else{
												if (log.isErrorEnabled()) {
													log.error("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
												lockedVersionIds.add("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
											}

										}
									}
									else{
										if(aivValue.getLockTime()!= null){
											aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
											aivValue.setLockedBy(null);
											aivValue.setLockTime(null);
											assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);
										}
										assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
										//get all the source asset instance version ids
										relSrcAivIds.add(ai.getAssetInstVersionId());
										recentActivityIds.add(ai.getAssetInstVersionId());
										aivIds.add(ai.getAssetInstVersionId().toString());
										
										aivo.setVersionName(ai.getVersionName());
										aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
									}
								} else{
									assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
									//get all the source asset instance version ids
									relSrcAivIds.add(ai.getAssetInstVersionId());
									recentActivityIds.add(ai.getAssetInstVersionId());
									aivIds.add(ai.getAssetInstVersionId().toString());
									
									aivo.setVersionName(ai.getVersionName());
									aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
								}
							}
						}
						else if(aiv.getAction().equals("update"))
						{

						}
						else if(aiv.getAction().equals("skip")) {

							//remove relationship
							if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation")){
								AssetInstance adr2 = new AssetInstance();
								adr2.setAssetName(aiv.getDestAssetName());
								adr2.setAssetInstName(aiv.getDestInstanceName());
								adr2.setVersionName(aiv.getDestInstanceVersionName());
								adr2.setOwner(profile.getUserName());

								AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
								AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(adr2, conn);
								int versionFlag = 0;
								if(asset.isVersionable()){
									versionFlag = 1;
								}
								assetInstanceVersionsManager.deleteAssetInstanceVersionsHelper(aiv1.getAssetInstanceId(),ai.getAssetInstName(),
										asset.getAssetId(),asset.getAssetName(),userName,1L,versionFlag,aiv1.getAssetInstVersionId(),ai.getVersionName(),true,conn);
								aivIds.add(aiv1.getAssetInstVersionId().toString());

								aivValue.setVersionName(ai.getVersionName());
								aivValue.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aivValue, aivValue.getAssetInstVersionId(), conn);
							}
						}else{

							//remove relationship
							if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation")){
								AssetInstance adr2 = new AssetInstance();
								adr2.setAssetName(aiv.getDestAssetName());
								adr2.setAssetInstName(aiv.getDestInstanceName());
								adr2.setVersionName(aiv.getDestInstanceVersionName());
								adr2.setOwner(profile.getUserName());

								AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
								AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(adr2, conn);
								int versionFlag = 0;
								if(asset.isVersionable()){
									versionFlag = 1;
								}
								assetInstanceVersionsManager.deleteAssetInstanceVersionsHelper(aiv1.getAssetInstanceId(),ai.getAssetInstName(),
										asset.getAssetId(),asset.getAssetName(),userName,1L,versionFlag,aiv1.getAssetInstVersionId(),ai.getVersionName(),true,conn);
								aivIds.add(aiv1.getAssetInstVersionId().toString());

								aivValue.setVersionName(ai.getVersionName());
								aivValue.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aivValue, aivValue.getAssetInstVersionId(), conn);

							}else{
								List<Long> 	removeAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> 	removedAssetRelationship =  new ArrayList<Long>();
								List<Long> addAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> selectedAssetRelationship = new ArrayList<Long>();

								AssetInstance assetInstance = new AssetInstance();
								assetInstance.setAssetName(aiv.getDestAssetName());
								assetInstance.setAssetInstName(aiv.getDestInstanceName());
								assetInstance.setVersionName(aiv.getDestInstanceVersionName());

								AssetInstanceVersion aivo =	assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

								removeAssetInstanceVersionIds.add(aivo.getAssetInstVersionId());

								AssetRelationshipDef ard = relationshipDao.retAssetRelDefForAssetsByRelationName(aiv.getSrcAssetName(),aiv.getDestAssetName(),aiv.getDescrption(), conn);

								removedAssetRelationship.add(ard.getAssetRelId());

								ai.setRemovedDestAssetInstVersionIds(removeAssetInstanceVersionIds);
								ai.setRemovedRelationshipIds(removedAssetRelationship);
								ai.setAddDestAssetInstVersionIds(addAssetInstanceVersionIds);
								ai.setAddRelationshipIds(selectedAssetRelationship);
								ai.setSrcAssetInstanceVersionId(ai.getAssetInstVersionId().toString());
								ai.setAssetInstanceId(aivValue.getAssetInstanceId());
								ai.setAssetId(assetsrc.getAssetId());

								if(globalLock.getGlobalSettingFlag()==1){
									if(radValStatic.equalsIgnoreCase("New")){
										if(aivValue.getLockTime()==null){
											assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
											//get all the source asset instance version ids
											relSrcAivIds.add(ai.getAssetInstVersionId());
											recentActivityIds.add(ai.getAssetInstVersionId());
											aivIds.add(ai.getAssetInstVersionId().toString());

											aivo.setVersionName(ai.getVersionName());
											aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
										}
										else{
											long dataBaseTime = aivValue.getLockTime().getTime();
											long systemTime = System.currentTimeMillis();
											if(systemTime>dataBaseTime){
												aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
												aivValue.setLockedBy(null);
												aivValue.setLockTime(null);
												assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);

												assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
												//get all the source asset instance version ids
												relSrcAivIds.add(ai.getAssetInstVersionId());
												recentActivityIds.add(ai.getAssetInstVersionId());
												aivIds.add(ai.getAssetInstVersionId().toString());

												aivo.setVersionName(ai.getVersionName());
												aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
												assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

											}
											else{
												if (log.isErrorEnabled()) {
													log.error("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
												lockedVersionIds.add("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
											}
										}
									}
									else{
										if(aivValue.getLockTime()!= null){
											aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
											aivValue.setLockedBy(null);
											aivValue.setLockTime(null);
											assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);
										}
										assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
										//get all the source asset instance version ids
										relSrcAivIds.add(ai.getAssetInstVersionId());
										recentActivityIds.add(ai.getAssetInstVersionId());
										aivIds.add(ai.getAssetInstVersionId().toString());

										aivo.setVersionName(ai.getVersionName());
										aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
									}
								}
								else{
									assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
									//get all the source asset instance version ids
									relSrcAivIds.add(ai.getAssetInstVersionId());
									recentActivityIds.add(ai.getAssetInstVersionId());
									aivIds.add(ai.getAssetInstVersionId().toString());
									
									aivo.setVersionName(ai.getVersionName());
									aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
								}
							}
						}
					}
				}
				log.info("Asset Relationship DB Updation done for incremental insert"+listOfassetInstRelList.toString());
			}
			// Loop Ends for Asset Instance Relationship update 3rd level
			
			//add revision history
			List<Long> relIds = new ArrayList<Long>();
			List<Long> recentActyIds = new ArrayList<Long>();

			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
				Set<Long> finalrelaivids = new HashSet<>();
				finalrelaivids.addAll(relSrcAivIds);
				relSrcAivIds.clear();
				relSrcAivIds.addAll(finalrelaivids);

				for(AivRevisionHistory revRel:aivRevHistList){
					for(Long srcaivids:relSrcAivIds){
						if(srcaivids.equals(revRel.getAivId())){
							relIds.add(srcaivids);
							AssetInstanceVersion aiv = new AssetInstanceVersion();
							aiv.setSrcAssetInstanceVersionId(srcaivids.toString());
							List<AssetInstance> aivos = assetInstanceManager.retFwdDependents(aiv,conn);
							String newRelationshipDataForRevision = "";
							int i = 1;
							for(AssetInstance aivoRev : aivos){
								AssetDef assetDef = assetDao.getAssetsByAssetId(aivoRev.getAssetId(), conn);
								if(i == aivos.size()){
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
									}	
								}else{
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
									}
								}
								i++;
							}
							revRel.setRelationshipKey("R");
							revRel.setRelationshipData(newRelationshipDataForRevision);
							AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(srcaivids,conn);
							if(aivVo != null){
								revRel.setVersionName(aivVo.getVersionName());
							}
							revRel.setAivId(srcaivids);
						}
					}
				}
				//List<Long> finalrelIds = new ArrayList<Long>();
				relSrcAivIds.removeAll(relIds);
				for(Long srcaivids:relSrcAivIds){
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv.setSrcAssetInstanceVersionId(srcaivids.toString());
					List<AssetInstance> aivos = assetInstanceManager.retFwdDependents(aiv,conn);
					String newRelationshipDataForRevision = "";
					int i = 1;
					for(AssetInstance aivoRev : aivos){
						AssetDef assetDef = assetDao.getAssetsByAssetId(aivoRev.getAssetId(), conn);
						if(i == aivos.size()){
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
							}	
						}else{
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
							}
						}
						i++;
					}
					AivRevisionHistory aivRevHisrel = new AivRevisionHistory();
					aivRevHisrel.setRelationshipKey("R");
					aivRevHisrel.setRelationshipData(newRelationshipDataForRevision);
					AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(srcaivids,conn);
					if(aivVo != null){
						aivRevHisrel.setVersionName(aivVo.getVersionName());
					}
					aivRevHisrel.setAivId(srcaivids);
					aivRevHistList.add(aivRevHisrel);
				}

				//recent activity details for relationship data
				Set<Long> finalrecids = new HashSet<>();
				finalrecids.addAll(recentActivityIds);
				recentActivityIds.clear();
				recentActivityIds.addAll(finalrecids);

				for(RecentActivity recent:recentActivityList){
					for(Long recids:recentActivityIds){
						if(recids.toString().equals(recent.getAssetInstVersionId())){
							recentActyIds.add(recids);

						}
					}
				}

				recentActivityIds.removeAll(recentActyIds);
				for(Long recentAct:recentActivityIds){
					RecentActivity acticity = new RecentActivity();
					AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(recentAct,conn);
					if(aivVo != null){
						acticity.setAssetName(aivVo.getAssetName());
						acticity.setAssetInstName(aivVo.getAssetInstName());
						acticity.setAssetInstanceVersionName(aivVo.getVersionName());
						acticity.setAssetInstVersionId(aivVo.getAssetInstVersionId().toString());
						recentActivityList.add(acticity);
					}
				}

				//add revision history
				for(AivRevisionHistory revFinal:aivRevHistList){
					String changeKey = "";  
					if(revFinal.getOverviewKey() == null){
						revFinal.setOverviewKey("");
						revFinal.setOverviewData("");
					}
					if(revFinal.getRelationshipKey() == null){
						revFinal.setRelationshipKey("");
						revFinal.setRelationshipData("");
					}
					if(revFinal.getParameterKey() == null){
						revFinal.setParameterKey("");
						revFinal.setParameterData("");
					}
					changeKey = revFinal.getOverviewKey()+","+revFinal.getRelationshipKey()+","+revFinal.getParameterKey();
					List<String> list = Arrays.asList(changeKey.split(","));
					List<String> finallist = new ArrayList<String>();
					for(String emptydata:list){
						if(!emptydata.equalsIgnoreCase("")){
							finallist.add(emptydata);
						}
					}
					String listString = String.join(",", finallist);
					assetInstanceVersionsManager.addRevisionData(listString, revFinal.getAivId(),revFinal.getVersionName(), 
							revFinal.getOverviewData(),revFinal.getRelationshipData(),revFinal.getParameterData(), null, userName,profile.getUserId(),"", conn);
				
					AssetInstanceVersion aivo = new AssetInstanceVersion();
					aivo.setVersionName(revFinal.getVersionName());
					aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					aivo.setAssetInstVersionId(revFinal.getAivId());
					assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
				}			
			}
			//add recent activity
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
				for(RecentActivity recentFinal:recentActivityList){
					RecentActivity recentActivity = new RecentActivity();
					String action = Constants.ACTIVITY_MODIFY;
					String appendingMsg = "";
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					AssetDef asset = assetDao.getAssetsByAssetName(recentFinal.getAssetName(), conn);
					if (asset.isVersionable() == true) {
						String log = profile.getFullName() + ";" + action + ";"+ recentFinal.getAssetName() + ";"+ recentFinal.getAssetInstName() + ";"+ " Version " + recentFinal.getAssetInstanceVersionName();
						recentActivity.setDescription(log);
					} else {
						String log = profile.getFullName() + ";" + action + ";"+ recentFinal.getAssetName() + ";"+ recentFinal.getAssetInstName() + ";"+ appendingMsg;
						recentActivity.setDescription(log);
					}
					recentActivity.setUser_id(profile.getUserId());
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(recentFinal.getAssetInstVersionId().toString());
					recentActivityDao.addRecentActivity(recentActivity, conn);
				}
			}
			
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
				
				Set<String> ids = new HashSet<String>();
				ids.addAll(aivIds);

				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				SubscriptionDao subscriptionDao = new SubscriptionDao();
				
				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				String mailTemp = null;
				
				for (Map.Entry<String,String> entry : aivIdslist.entrySet()) {
					if(entry.getValue().equalsIgnoreCase("add")){
						AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(entry.getKey()), conn);
						if(aiv != null){
							List<String> emailIds=subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);

							if(aiv.getVersionable() == true){
								MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
								mailTemp = mtVo1.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assetInstName%",instName).replaceAll("%versionName%", aiv.getVersionName());
							}else{
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
								mailTemp = mailTemp.replaceAll("%assetType%", aiv.getAssetName());
							}
							if(emailIds!=null){
								for(String emailId:emailIds){
									if(aiv.getVersionable() == true) {
										SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
												MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

									}
									else {
										SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
												MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

									}
								}
							}
						}
					}
				}
				
				for(String aivid:ids){
					AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(aivid), conn);
					if(aiv != null){
						List<String> emailIds=subscriptionDao.getAllSubscriptionsByAssetInstanceId(aiv.getAssetInstanceId(), conn);

						if(aiv.getVersionable() == true){
							MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForVersionableAsset");
							mailTemp = mtVo1.getMailTemplate();
							String instName = aiv.getAssetInstName();
							instName = instName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
						}else{
							MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForNonVersionableAsset");
							mailTemp = mtVo.getMailTemplate();
							String instName = aiv.getAssetInstName();
							instName = instName.replace("\\", "\\\\").replace("$", "\\$");
							mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
						}
						if(emailIds!=null){
							for(String emailId:emailIds){
								if(aiv.getVersionable() == true) {
									SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

								}
								else {
									SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

								}
							}
						}
					}
				}
				//taxonomy mail configration for subscribed users
				for (Entry<String, Map<String, String>> entry : taxIds.entrySet()) {
					Map<String, String> childMap = entry.getValue();
					String assignTax = "";
					String unassignTax = "";
					String addTax = "";
					String removedTax = "";
					List<String> emailIdsList = new ArrayList<String>();
					List<String> emailIds1List = new ArrayList<String>();
					for (Entry<String, String> entry2 : childMap.entrySet()) {
						assignTax = entry2.getKey();
						unassignTax = entry2.getValue();
					}

					//added taxonomies
					if(!assignTax.equalsIgnoreCase("")){
						String addedTaxEmail = "";
						String[] addTaxFinal = assignTax.split("~~");
						addTax = addTaxFinal[0];
						if(addTaxFinal.length == 2){
							addedTaxEmail = addTaxFinal[1];
						}
						emailIdsList = Arrays.asList(addedTaxEmail.split(","));
					}


					//unassigned taxonomies
					if(!unassignTax.equalsIgnoreCase("")){
						String[] unassignTaxFinal = unassignTax.split("~~");
						removedTax = unassignTaxFinal[0];
						String unassignTaxEmail = "";

						if(unassignTaxFinal.length == 2){
							unassignTaxEmail = unassignTaxFinal[1];
						}
						emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
					}
					
					AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(entry.getKey()), conn);
					if(aiv != null){
						if (!emailIdsList.isEmpty()) {
							//HashSet<String> listToSet = new HashSet<String>(emailIdsList);
							//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);

							if (aiv.getVersionable() == true) {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"assignTaxNameForAssetInstanceForVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
										.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
							} else {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"assignTaxNameForAssetInstanceForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",instName);
							}

							for (String emailId : emailIdsList) {
								if (addTax != "") {
									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								}
							}
						}

						if (!emailIds1List.isEmpty()) {
							//HashSet<String> listToSet = new HashSet<String>(emailIds1List);
							//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);

							if (aiv.getVersionable() == true) {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"unassignTaxNameForAssetInstanceForVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
										.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
							} else {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"unassignTaxNameForAssetInstanceForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax).replaceAll("%assetInstName%",instName);
							}

							for (String emailId : emailIds1List) {
								if (removedTax != "") {
									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								}
							}
						}
					}
				}
				
				for(Object jsondata:parameterChangefinaldata){

					JSONObject jsonObject = new JSONObject(jsondata.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result = jsonObject.getString("Notification");
								result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
								if(!result.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}
				
				for(Object jsondata:relatedParamChangefinaldata){

					JSONObject jsonObject = new JSONObject(jsondata.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result = jsonObject.getString("Notification");
								result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
								if(!result.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}
			}

			//error message construction
			if(!errorsOnProc.isEmpty() || !apeVoList.isEmpty())
			{
				Set<String> hs = new HashSet<String>();
				hs.addAll(errorsOnProc);
				errorsOnProc.clear();
				errorsOnProc.addAll(hs);
				for(int i=0;i<errorsOnProc.size();i++)
				{
					errStr.append(errorsOnProc.get(i)+"\n");
				}
				for(int i=0;i<apeVoList.size();i++)
				{
					if(apeVoList.get(i).getFileExist() != null)
					{
						if(apeVoList.get(i).getFileExist().equalsIgnoreCase("Not Found"))
						{
							if(apeVoList.get(i).isVersionable()){
								if (log.isErrorEnabled()) {
									log.error(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
							else{
								if (log.isErrorEnabled()) {
									log.error(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
						}
					}
					else
					{
						if(apeVoList.get(i).getErrorMessage() == null){
							if(apeVoList.get(i).isVersionable())
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
							else
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
						}else{
							if(apeVoList.get(i).isVersionable())
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
							}
							else
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
							}
						}
					}
				}
				log.info("Asset Attribute and Asset Relationship Error Handling done"+apeVoList.toString());
			}
			if (log.isTraceEnabled()) {
				log.trace("incrementalUpdate ||UserName:"+userName+" RadioVal:"+radioVal+" RadValStatic:"+radValStatic+" InputStream:"+inputStream+" ||End");
			}
		}catch(Exception e){
			e.printStackTrace();			
			throw new RepoproException(e.getMessage());
		}
	}
	
	/**
	 * @method lockingUsers
	 * @return
	 */
	@GET
	@Path("/lockingUsers")
	public Response lockingUsers(){

		log.trace("lockingUsers || begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		ImportExcelDao importExcelDao = new ImportExcelDao();
		List<String>  jsonlist = new ArrayList<String>();
		int count = 0;
		String msg = null;
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("lockingUsers || "+ Constants.LOG_CONNECTION_OPEN);
			}
			
			count = importExcelDao.getCountOfLockedIds(conn);
			msg = "Please select the option to deal with locked instance versions: (At present " + count+" are locked)";
			
			jsonlist.add(msg);
			retMsg = Constants.SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("lockingUsers || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("lockingUsers ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(jsonlist))).build();

	}
	
	/**
	 * @method doExcelUpload
	 * @return success response
	 */
	@GET
	@Path("/uploadProgress")
	public Response doExcelUpload(){

		log.trace("doExcelUpload || begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<String>  jsonlist = new ArrayList<String>();
		String msg = "0";
		try {

			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("doExcelUpload || "+ Constants.LOG_CONNECTION_OPEN);
			}
			if(uploadInProcess){
				msg = "1";
			}
			jsonlist.add(msg);
			
			retMsg = Constants.SUCCESS;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("doExcelUpload || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("doExcelUpload ||  exit ");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(jsonlist))).build();

	}
	
	public boolean ldapMappingAttributeValidation(List<LDAPUser> listOfLDAPUsers,List<String> firstParamValList,String attributeName) {

		CommonUtils commonUtils = new CommonUtils();
		boolean invaliddataflag = false;
		for(LDAPUser finaldata:listOfLDAPUsers){
			int count = 0;
			
			if(attributeName.equalsIgnoreCase(commonUtils.LdapFirstName)) {
				for(String ldapdata:firstParamValList) {
					if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName())){
						count++;
					}
					if(count == firstParamValList.size()) {
						invaliddataflag = true;
						break;
					}
				}
			}else if(attributeName.equalsIgnoreCase(commonUtils.LdapLastName)) {
				for(String ldapdata:firstParamValList) {
					if(!ldapdata.equalsIgnoreCase(finaldata.getLastName())){
						count++;
					}
					if(count == firstParamValList.size()) {
						invaliddataflag = true;
						break;
					}
				}
			}else if(attributeName.equalsIgnoreCase(commonUtils.LdapEmail)) {
				for(String ldapdata:firstParamValList) {
					if(!ldapdata.equalsIgnoreCase(finaldata.getEmail())){
						count++;
					}
					if(count == firstParamValList.size()) {
						invaliddataflag = true;
						break;
					}
				}
			}else if(attributeName.equalsIgnoreCase(commonUtils.LdapDept)) {
				for(String ldapdata:firstParamValList) {
					if(!ldapdata.equalsIgnoreCase(finaldata.getDept())){
						count++;
					}
					if(count == firstParamValList.size()) {
						invaliddataflag = true;
						break;
					}
				}
			}else if(attributeName.equalsIgnoreCase(commonUtils.LdapUserId)) {
				for(String ldapdata:firstParamValList) {
					if(!ldapdata.equalsIgnoreCase(finaldata.getUserId())){
						count++;
					}
					if(count == firstParamValList.size()) {
						invaliddataflag = true;
						break;
					}
				}
			}else if(attributeName.equalsIgnoreCase(commonUtils.LdapFullName)) {
				for(String ldapdata:firstParamValList) {
					if(!ldapdata.equalsIgnoreCase(finaldata.getFirstName()+" "+finaldata.getLastName())){
						count++;
					}
					if(count == firstParamValList.size()) {
						invaliddataflag = true;
						break;
					}
				}
			}
		}
		return invaliddataflag;
	} 
	
	public List<AssetParamDef> paramListData(List<AssetParamDef> paramList,Connection conn)throws RepoproException{
		List<AssetParamDef> ldapmodifiedData = new ArrayList<AssetParamDef>();
		List<AssetParamDef> ldapmodifiedDataRemoval = new ArrayList<AssetParamDef>();
		AssetDao assetDao = new AssetDao();
		try {
			for(AssetParamDef apd: paramList) {
				if(apd.getParamTypeId() == 9) {
					List<LdapMapping> ldapMapping;

					ldapMapping = assetDao.getLdapMappingAttributeList(apd.getLdapMappingId(), conn);

					for(LdapMapping ldapAttributes:ldapMapping) {
						AssetParamDef assetparam = new AssetParamDef();
						assetparam.setLdapMappingId(apd.getLdapMappingId());
						assetparam.setAssetParamName(apd.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
						assetparam.setParamTypeId(apd.getParamTypeId());
						ldapmodifiedData.add(assetparam);
					}
					ldapmodifiedDataRemoval.add(apd);
				}
			}
			if(!ldapmodifiedDataRemoval.isEmpty()) {
				paramList.removeAll(ldapmodifiedDataRemoval);
			}
			if(!ldapmodifiedData.isEmpty()) {
				paramList.addAll(ldapmodifiedData);
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		return paramList;
	}
	
	
	public List<String> AssetRelationship1stlevelvalidation(List<String> errorsOnProc,XSSFWorkbook workbook,
			List<AssetRelationshipDef> relNameList,Boolean flagForskip1,List<String> splitAssetList,
			List<AssetDef> assetNameList) throws RepoproException {
		try {
			for (int x = 1; x < workbook.getNumberOfSheets(); x=x+2) 
			{
				XSSFSheet sheet=(XSSFSheet) workbook.getSheetAt(x);
				XSSFRow row; 
				//Iterator rows = sheet.rowIterator();
				Iterator<Row> rows = sheet.iterator();

				while (rows.hasNext()){
					row = (XSSFRow) rows.next();
					if(row.getRowNum()== 0 || row.getRowNum()== 1){
						continue; 
					}
					int rowNum = row.getRowNum();
					String cell1 = null,cell2= null,cell3= null,cell6= null;
					XSSFRow rowb = sheet.getRow(rowNum++);
					XSSFCell cellff = rowb.getCell(6);
					XSSFCell cellaa = rowb.getCell(0);
					XSSFCell cellbb = rowb.getCell(3);
					XSSFCell cellcc = rowb.getCell(2);

					if(cellaa != null)
					{
						if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
						{
							cell1 = cellaa.getStringCellValue();
							if(cell1.length() == 0)
							{
								cell1 = "";  
							}
						}
						if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
						{
							int val = (int)cellaa.getNumericCellValue(); 
							cell1 = String.valueOf(val); 
						}
						if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
						{
							cell1 = cellaa.getStringCellValue();
						}
					}
					else
					{
						cell1 = "";
					}

					if(cellbb != null)
					{
						if (cellbb.getCellType() == XSSFCell.CELL_TYPE_BLANK)
						{
							cell2 = cellbb.getStringCellValue();
							if(cell2.length() == 0)
							{
								cell2 = "";  
							}
						}
						if(cellbb.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
						{
							int val = (int)cellbb.getNumericCellValue(); 
							cell2 = String.valueOf(val); 
						}
						if(cellbb.getCellType() == XSSFCell.CELL_TYPE_STRING)
						{
							cell2 = cellbb.getStringCellValue();
						}
					}
					else
					{
						cell2 = "";
					}
					if(cellcc != null)
					{
						if (cellcc.getCellType() == XSSFCell.CELL_TYPE_BLANK)
						{
							cell3 = cellcc.getStringCellValue();
							if(cell3.length() == 0)
							{
								cell3 = "";  
							}
						}
						if(cellcc.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
						{
							int val = (int)cellcc.getNumericCellValue(); 
							cell3 = String.valueOf(val); 
						}
						if(cellcc.getCellType() == XSSFCell.CELL_TYPE_STRING)
						{
							cell3 = cellcc.getStringCellValue();
						}
					}
					else
					{
						cell3 = "";
					}
					if(cellff != null)
					{
						if (cellff.getCellType() == XSSFCell.CELL_TYPE_BLANK)
						{
							cell6 = cellff.getStringCellValue();
							if(cell6.length() == 0)
							{
								cell6 = "";  
							}
						}
						if(cellff.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
						{

							int val = (int)cellff.getNumericCellValue(); 
							cell6 = String.valueOf(val); 
						}
						if(cellff.getCellType() == XSSFCell.CELL_TYPE_STRING)
						{
							cell6 = cellff.getStringCellValue();
						}
					}
					else
					{
						cell6 = "";
					}

					Boolean flagForRel = false;

					if(cell1!="" && cell2!="" && cell3!="")
					{
						for(AssetRelationshipDef relNm :relNameList)
						{
							if(relNm.getDescription().equals(cell6))	
							{
								flagForRel = true;
								break;
							}
						}
						if(!flagForRel)
						{
							if (log.isErrorEnabled()) {
								log.error("Error in Relation Name for " + cell2+"_"+cell3+" at "+cell1);
							}
							errorsOnProc.add("Error in Relation Name for " + cell2+"_"+cell3+" at "+cell1);
						}
					}
					if(log.isDebugEnabled()){
						log.debug("importExcelSheet||value of cell0:"+rowb.getCell(0)+"cell2:"+rowb.getCell(2)+"cell3:"+rowb.getCell(3)+"cell6:"+rowb.getCell(6)+
								" at row "+row.getRowNum());
					}
				}
			}

			if(!flagForskip1)
			{
				Boolean flagname = false;
				for(int f=0;f<assetNameList.size();f++)
				{
					if(!assetNameList.get(f).getAssetName().equals(splitAssetList.get(f)))
					{
						flagname = true;
						break;
					}
				}
				if(flagname)
				{
					if (log.isErrorEnabled()) {
						log.error("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");
					}
					errorsOnProc.add("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");

				}
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		return errorsOnProc;
	}
	
	public List<String> assetAttribute1stlevelValidation(List<String> errorsOnProc,XSSFWorkbook workbook,
			Boolean flagForskip,List<String> splitAssetList,List<AssetDef> assetNameList,
			String splitAssetName,List<AssetParamDef> paramList,Connection conn) throws RepoproException{

		// attributes validation 1st layer
		splitAssetName = null;
		AssetDao assetDao = new AssetDao();
		try {
			for (int x = 0; x < workbook.getNumberOfSheets(); x=x+2) 
			{
				XSSFSheet sheet= (XSSFSheet) workbook.getSheetAt(x);
				XSSFRow row; 
				//Iterator rows = sheet.rowIterator();
				Iterator<Row> rows = sheet.iterator();

				Boolean flagForParam = false;
				Boolean flagOrder = false;
				Boolean flagForEmpAsset = false;
				int noOfSheetsForAttributes = workbook.getNumberOfSheets()/2;
				if(assetNameList.size() != noOfSheetsForAttributes)
				{
					if (log.isErrorEnabled()) {
						log.error("Error Missing/MisMatch excel sheet with Asset Names in Application. Please upload a valid excel sheet");
					}
					errorsOnProc.add("Error Missing/MisMatch excel sheet with Asset Names in Application. Please upload a valid excel sheet");
					flagForskip = true;
					break;
				}
				if( sheet.getFirstRowNum()== 0)
				{
					while (rows.hasNext())
					{
						row=(XSSFRow) rows.next();
						int  rowNum = row.getRowNum();
						if(row.getRowNum()== 0)
						{
							XSSFRow rowb = sheet.getRow(rowNum++);
							XSSFCell cellaa = rowb.getCell(0);
							if(cellaa != null)
							{
								if (cellaa.getCellType() == XSSFCell.CELL_TYPE_BLANK)
								{
									splitAssetName = cellaa.getStringCellValue();
									if(splitAssetName.length() == 0)
									{
										splitAssetName = "";  
									}
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
								{
									int val = (int)cellaa.getNumericCellValue(); 
									splitAssetName = String.valueOf(val); 
								}
								if(cellaa.getCellType() == XSSFCell.CELL_TYPE_STRING)
								{
									splitAssetName = cellaa.getStringCellValue();
								}
								if(splitAssetName.equalsIgnoreCase(""))
								{
									flagForEmpAsset = true;
									log.error("Please provide a valid asset name in the excel sheet.");
									errorsOnProc.add("Please provide a valid asset name in the excel sheet.");
									break;
								}
								splitAssetList.add(splitAssetName);
							}
							else
							{
								splitAssetName = "";
								splitAssetList.add(splitAssetName);
							}
							if(log.isDebugEnabled()){
								log.debug("importExcelSheet||value of cell0 at row "+row.getRowNum()+" is "+cellaa);
							}
						}
						break;
					}
				}
				if(!flagForEmpAsset)
				{
					if( sheet.getFirstRowNum()== 0)
					{
						paramList = assetDao.getParamsByAsset(splitAssetName, conn);

						paramList = paramListData(paramList,conn);

						int s = 5;
						int f = 0;
						List<String> paramNames = new ArrayList<String>() ;
						List<String> paramNamesForOrder = new ArrayList<String>() ;
						List<String> paramNamesForOrder1 = new ArrayList<String>() ;
						paramNamesForOrder.add("Asset Instance Version Id");
						paramNamesForOrder.add("Asset Instance Name");
						paramNamesForOrder.add("Version Name");
						paramNamesForOrder.add("Overview");
						paramNamesForOrder.add("Created On");
						Collections.sort(paramList, new AssetParamDef());
						for(AssetParamDef pvo: paramList)
						{
							paramNames.add(pvo.getAssetParamName());
							paramNamesForOrder1.add(pvo.getAssetParamName());
						}
						//Collections.sort(paramNames,String.CASE_INSENSITIVE_ORDER);
						//Collections.sort(paramNamesForOrder1,String.CASE_INSENSITIVE_ORDER);

						paramNamesForOrder.addAll(paramNames);
						paramNamesForOrder.add("%%Taxonomies%%");
						paramNamesForOrder.add("%%Tags%%");

						for(int l=0;l<paramNamesForOrder.size();l++)
						{
							XSSFRow rowb = sheet.getRow(1);
							if(rowb != null) {
								XSSFCell cellp = rowb.getCell(f++);
								String valParam = null;
								if(cellp != null)
								{
									if (cellp.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										valParam = cellp.getStringCellValue();
										if(valParam.length() == 0)
										{
											valParam = "";  
										}
									}else if(cellp.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellp.getNumericCellValue(); 
										valParam = String.valueOf(val); 
									}
									else if(cellp.getCellType() == XSSFCell.CELL_TYPE_BLANK)
									{
										valParam = ""; 
									}
									if(!valParam.equalsIgnoreCase(paramNamesForOrder.get(l))){
										flagOrder = true;
										break;
									}
									if(log.isDebugEnabled()){
										log.debug("importExcelSheet||value of cell "+l+" at row "+sheet.getFirstRowNum()+" is "+cellp);
									}
								}
							}else {
								flagOrder = true;
								break;
							}
						}
						for (String pvo: paramNames)
						{
							XSSFRow rowb = sheet.getRow(1);
							if(rowb != null) {
								XSSFCell cellee = rowb.getCell(s++);
								String valParam = null;
								if(cellee != null)
								{
									if (cellee.getCellType() == XSSFCell.CELL_TYPE_STRING)
									{
										valParam = cellee.getStringCellValue();
										if(valParam.length() == 0)
										{
											valParam = "";  
										}
									}
									else if(cellee.getCellType() == XSSFCell.CELL_TYPE_NUMERIC)
									{
										int val = (int)cellee.getNumericCellValue(); 
										valParam = String.valueOf(val); 
									}
								}
								else
								{
									valParam = "";
								}
								if(!pvo.equalsIgnoreCase(valParam))
								{
									flagForParam = true;
									break;
								}
								if(log.isDebugEnabled()){
									log.debug("importExcelSheet||value of cell "+s+" at row "+sheet.getFirstRowNum()+" is "+cellee);
								}
							}else {
								flagForParam = true;
								break;
							}
						}
					}
					if(flagForParam || flagOrder )
					{
						if (log.isErrorEnabled()) {
							log.error("Error in asset name/parameter details for " + splitAssetName + ". Please check for wrong asset name,asset instance version id,wrong parameter names, missing parameters, incorrect alphabetical order.");
						}
						errorsOnProc.add("Error in asset name/parameter details for " + splitAssetName + ". Please check for wrong asset name,asset instance version id,wrong parameter names, missing parameters, incorrect alphabetical order.");
					}
				}
			}
			if(!flagForskip )
			{
				Boolean flagname = false;
				if(splitAssetList.size() == 1){
					flagname = false;
					for(int f=0;f<assetNameList.size();f++)
					{
						if(!assetNameList.get(f).getAssetName().equals(splitAssetList.get(f)))
						{
							flagname = true;
							break;
						}
					}
				}
				if(flagname)
				{
					if (log.isErrorEnabled()) {
						log.error("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");
					}
					errorsOnProc.add("Error MisMatch/Incorrect order in excel sheet  with Asset Names in Application.");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		return errorsOnProc;
	}
	
	
	public void fullImportDBupdation(List<String> errorsOnProc,List<AssetParamSuccess> apeVoList,Map<String,List<AssetInstanceVersion>> listOfassetInstList
			,List<AssetParamSuccess> apsVoList,AssetInstanceDao assetInstanceDao, WorkflowDao workflowDao, User profile,CommonUtils commonUtils,String userName
			,AssetInstanceVersionDao assetInstanceVersionDao,AssetInstanceVersionsManager assetInstanceVersionsManager,
			List<AssetInstDescSuccess> aisdVoList,GlobalSetting globalsetting,GlobalSetting globalLock,
			String radValStatic,Set<String> lockedVersionIds,AssetDao assetDao,@Context ServletContext context,List<AssetInstance> azds,
			List<AssetInstVersionTaxonomy> assetInstassignList,List<AssetInstAssignTagging> assetInstTaggingList,TaggingDao taggingDao,
			Map<String,List<AssetInstRelationship>> listOfassetInstRelList,RelationshipDao relationshipDao,RecentActivityDao recentActivityDao,StringBuilder errStr,Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("fullImportDBupdation ||Begin");
		}
		// Loop Starts for Asset Attribute DB Updation 3rd level
		AssetInstanceManager assetInstanceManager = new AssetInstanceManager();
		List<AivRevisionHistory> aivRevHistList = new ArrayList<AivRevisionHistory>();
		List<RecentActivity> recentActivityList = new ArrayList<RecentActivity>();
		Map<String,String> aivIds = new LinkedHashMap<String,String>();
		Map<String,Map<String,String>> taxIds = new LinkedHashMap<String,Map<String,String>>();

		String action = "";

		Object parameterChangeNotification = null;
		Object relatedParamChangeNotification = null;
		JSONObject j1 = null;
		List<Object> parameterChangefinaldata = new ArrayList<Object>();
		List<Object> relatedParamChangefinaldata = new ArrayList<Object>();

		try {

			if(errorsOnProc.isEmpty() && apeVoList.isEmpty())
			{
				for (Entry<String, List<AssetInstanceVersion>> entry : listOfassetInstList.entrySet())
				{
					for(AssetInstanceVersion aiv:entry.getValue())
					{
						AssetInstance ai = new AssetInstance();
						ai.setAssetName(entry.getKey());

						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

						ai.setAssetId(asset.getAssetId());
						ai.setAssetInstName(aiv.getAssetInstName());
						ai.setVersionName(aiv.getVersionName());
						ai.setOwner(profile.getUserName());
						//ai.setDescription(aiv.getDescription());
						ai.setDescription(commonUtils.httpSanitizerForCkEditor(aiv.getDescription()));

						if(aiv.getAction().equals("add")){
							//assetInstanceManager.addAssetInstanceHelper(ai,userName,false,true,false,conn);
							Response response = assetInstanceManager.addAssetInstanceHelper(ai,userName,false,true,false,conn);
							MyModel res = (MyModel) response.getEntity();
							List<Object> data = res.getResult();
							for (int i = 0; i < data.size(); i++) {
								AssetInstance aiResponse = new AssetInstance();
								aiResponse = (AssetInstance) data.get(i);
								ai.setAssetInstId(aiResponse.getAssetInstId());
								ai.setAssetInstVersionId(aiResponse.getAssetInstVersionId());
							}
							Long firstState = null;
							Workflow workflow = workflowDao.retWorkflowByAivId(ai.getAssetInstVersionId(), conn);
							if(workflow != null) {
								String jsonStructure = workflow.getJsonStructure();
								JSONObject jsonObject = new JSONObject(jsonStructure);
								
								for(int i=0;i<jsonObject.length();i++) {
									Iterator itr = jsonObject.keys();
									if(itr.hasNext()){
										firstState = Long.parseLong(itr.next().toString());
									}
								}
								assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
							}
							AssetInstanceVersion aivForAddingNewRevision = assetInstanceVersionDao
									.getAssetInstanceVersion(ai.getAssetInstId(),ai.getVersionName(), conn);
							if(aivForAddingNewRevision != null){
								AivRevisionHistory aivRevHist = new AivRevisionHistory();
								aivRevHist.setAivId(ai.getAssetInstVersionId());
								aivRevHist.setNewInstanceKey("N");
								aivRevHist.setOverviewData(ai.getDescription());
								aivRevHist.setRevId(ai.getVersionName()+".0");
								aivRevHistList.add(aivRevHist);
							}
							//recent Activity
							RecentActivity recentActivity = new RecentActivity();
							recentActivity.setAssetName(ai.getAssetName());
							recentActivity.setAssetInstName(ai.getAssetInstName());
							recentActivity.setAssetInstanceVersionName(ai.getVersionName());
							recentActivity.setAssetInstVersionId(ai.getAssetInstVersionId().toString());
							action = Constants.ACTIVITY_CREATE;
							recentActivity.setAction(action);
							recentActivityList.add(recentActivity);

							aivIds.put(ai.getAssetInstVersionId().toString(),aiv.getAction());
						}else if(aiv.getAction().equals("update")){

						}else{
							AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
							int versionFlag = 0;
							if(asset.isVersionable()){
								versionFlag = 1;
							}
							aivIds.put(aiv1.getAssetInstVersionId().toString(),aiv.getAction());

							assetInstanceVersionsManager.deleteAssetInstanceVersionsHelper(aiv1.getAssetInstanceId(),ai.getAssetInstName(),
									asset.getAssetId(),asset.getAssetName(),userName,1L,versionFlag,aiv1.getAssetInstVersionId(),ai.getVersionName(),true,conn);
						}
					}
				}

				List<AivRevisionHistory> rev = new ArrayList<AivRevisionHistory>();
				List<String> ids = new ArrayList<String>();
				for(int i=0;i<aisdVoList.size();i++)
				{
					AssetInstance ai = new AssetInstance();
					ai.setAssetName(aisdVoList.get(i).getAssetType());
					AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
					ai.setAssetId(asset.getAssetId());
					ai.setAssetInstName(aisdVoList.get(i).getAssetInstName());
					ai.setVersionName(aisdVoList.get(i).getVersionName());
					ai.setParentAssetName(aisdVoList.get(i).getParentAssetName());
					ai.setParentAssetInstName(aisdVoList.get(i).getParentAssetInstanceName());
					if(globalsetting.getGlobalSettingFlag() == 1){
						String description = commonUtils.httpSanitizerForCkEditor(aisdVoList.get(i).getAssetInstanceDescription());
						aisdVoList.get(i).setAssetInstanceDescription(description);
					}
					ai.setNewDescription(aisdVoList.get(i).getAssetInstanceDescription());

					AssetInstanceVersion aiv;
					aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
					ai.setAssetInstId(aiv.getAssetInstanceId());

					if(globalLock.getGlobalSettingFlag() == 1){
						if(radValStatic.equalsIgnoreCase("New")){
							if(aiv.getLockTime()==null){
								if(!aisdVoList.get(i).getAssetInstanceDescription().equals(aiv.getDescription())){
									ids.add(aiv.getAssetInstVersionId().toString());
									assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
									aiv.setVersionName(ai.getVersionName());
									aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
								}
							}
							else{
								long systemTime = System.currentTimeMillis();
								long databaseTime = aiv.getLockTime().getTime();
								if(systemTime>databaseTime){
									aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
									aiv.setLockedBy(null);
									aiv.setLockTime(null);
									assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);//unlock
									ids.add(aiv.getAssetInstVersionId().toString());
									assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
								}else{
									lockedVersionIds.add("Asset Instance Version Overview cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");			
								}
							}
						}
						else{
							if(aiv.getLockTime()!= null){
								if(!aisdVoList.get(i).getAssetInstanceDescription().equals(aiv.getDescription())){
									aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
									aiv.setLockedBy(null);
									aiv.setLockTime(null);
									assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
								}
							}
							assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
							ids.add(aiv.getAssetInstVersionId().toString());
							aiv.setVersionName(ai.getVersionName());
							aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
						}
					}
					else {
						//this will call when global Setting is No
						ids.add(aiv.getAssetInstVersionId().toString());
						assetInstanceManager.updateAssetInstanceDescriptionHelper(ai,profile.getUserName(),true,conn);
						aiv.setVersionName(ai.getVersionName());
						aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
					}
				}
				if(!rev.isEmpty()){
					aivRevHistList.addAll(rev);
				}
				List<String> data = new ArrayList<String>();
				for(Map.Entry<String,String> entry : aivIds.entrySet()){
					String id = entry.getKey();
					for(String finalid:ids){
						if(finalid.equalsIgnoreCase(id)){
							data.add(finalid);
						}
					}
				}
				ids.removeAll(data);
				for(String finalid:ids){
					aivIds.put(finalid,"update");
					//revision history for description(overview)
					for(int i=0;i<aisdVoList.size();i++){
						AssetInstance ai = new AssetInstance();
						ai.setAssetName(aisdVoList.get(i).getAssetType());
						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
						ai.setAssetId(asset.getAssetId());
						ai.setAssetInstName(aisdVoList.get(i).getAssetInstName());
						ai.setVersionName(aisdVoList.get(i).getVersionName());
						ai.setParentAssetName(aisdVoList.get(i).getParentAssetName());
						ai.setParentAssetInstName(aisdVoList.get(i).getParentAssetInstanceName());
						ai.setNewDescription(aisdVoList.get(i).getAssetInstanceDescription());
						if(globalsetting.getGlobalSettingFlag() == 1){
							String description = commonUtils.httpSanitizerForCkEditor(aisdVoList.get(i).getAssetInstanceDescription());
							ai.setNewDescription(description);
						}
						AssetInstanceVersion aiv;
						aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
						ai.setAssetInstId(aiv.getAssetInstanceId());

						if(aiv.getAssetInstVersionId().toString().equalsIgnoreCase(finalid)){
							AivRevisionHistory aivRevHist = new AivRevisionHistory();
							aivRevHist.setOverviewKey("O");
							aivRevHist.setOverviewData(aisdVoList.get(i).getAssetInstanceDescription());
							aivRevHist.setAivId(Long.parseLong(finalid));
							aivRevHist.setVersionName(aisdVoList.get(i).getVersionName());
							aivRevHistList.add(aivRevHist);

							//recent Activity
							RecentActivity recentActivity = new RecentActivity();
							recentActivity.setAssetName(aisdVoList.get(i).getAssetType());
							recentActivity.setAssetInstName(aisdVoList.get(i).getAssetInstName());
							recentActivity.setAssetInstanceVersionName(aisdVoList.get(i).getVersionName());
							recentActivity.setAssetInstVersionId(finalid);
							recentActivityList.add(recentActivity);
						}
					}
				}

				if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
					AssetInstanceVersion assetInstver = null;
					for(int i=0;i<apsVoList.size();i++)
					{
						List<AssetInstanceVersion> ListOfAssetInstanceProperties = new ArrayList<AssetInstanceVersion>();

						NameValue nv = new NameValue();
						nv.setName(apsVoList.get(i).getParamName());

						AssetInstance ai = new AssetInstance();
						ai.setAssetName(apsVoList.get(i).getAssetType());
						ai.setAssetInstName(apsVoList.get(i).getAssetInstName());
						ai.setVersionName(apsVoList.get(i).getVersionName());

						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
						ai.setAssetId(asset.getAssetId());
						ai.setParentAssetName(apsVoList.get(i).getParentAssetName());
						ai.setParentAssetInstName(apsVoList.get(i).getParentAssetInstanceName());

						nv.setName(apsVoList.get(i).getParamName());
						AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
						ai.setAssetInstVersionId(aiv.getAssetInstVersionId());
						if(!apsVoList.get(i).getParamTypeId().equals(3L))
						{
							assetInstver = new AssetInstanceVersion();
							assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
							if(apsVoList.get(i).getParamTypeId().equals(7L)){
								if(apsVoList.get(i).isHasStaticValue()){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else if(apsVoList.get(i).getHasArray()==0){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
									assetInstver.setRTFPlainText(apsVoList.get(i).getRTFPlainText());
								}else{
									assetInstver.setRTFwithOutTags(apsVoList.get(i).getRTFwithOutTags());
									assetInstver.setRTFwithTags(apsVoList.get(i).getRTFwithTags());
								}
							}else if(apsVoList.get(i).getParamTypeId().equals(1L)){
								if(apsVoList.get(i).isHasStaticValue()){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else if(apsVoList.get(i).getHasArray()==0){
									assetInstver.setParamValue(apsVoList.get(i).getParamValue());
								}else{
									assetInstver.setTextDataList(apsVoList.get(i).getTextDataList());
								}
							}else{
								assetInstver.setParamValue(apsVoList.get(i).getParamValue());
							}

							assetInstver.setParamTypeId(apsVoList.get(i).getParamTypeId());
							if(apsVoList.get(i).isHasStaticValue() == false){
								assetInstver.setIsStatic(0);
							}else{
								assetInstver.setIsStatic(1);
							}
							apsVoList.get(i).isHasStaticValue();
							assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
							assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
							assetInstver.setAssetName(ai.getAssetName());
							assetInstver.setAssetInstName(apsVoList.get(i).getAssetInstName());
							assetInstver.setHasArray(apsVoList.get(i).getHasArray());
							assetInstver.setConn(conn);
							assetInstver.setLog(log);
							assetInstver.setUserId(1L);
							ListOfAssetInstanceProperties.add(assetInstver);

							if(CommonUtils.customParameterPluginNoficationClassName != null && CommonUtils.customParameterPluginPath != null){

								if(!CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("") && !CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){

									Class notificationInterface = CustomParameterPluginUtilies.getplugin();

									if(notificationInterface != null){
										Method method = null;
										Method relatedParamChangeMethod = null;
										try {
											method = notificationInterface.getMethod("notifyOnParameterValueChanges",new Class[]{List.class});
											relatedParamChangeMethod = notificationInterface.getMethod("notifyOnParameterValueChangesBasedOnOtherParameter",new Class[]{List.class});

										} catch (NoSuchMethodException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (SecurityException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}

										Object instance = null;
										try {
											instance = notificationInterface.newInstance();
										} catch (InstantiationException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (IllegalAccessException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}	


										try{
											parameterChangeNotification = method.invoke(instance,ListOfAssetInstanceProperties);

											if(parameterChangeNotification != null){
												JSONObject jsonObject = new JSONObject(parameterChangeNotification.toString());

												if(jsonObject.has("Response Status")){
													String status = jsonObject.getString("Response Status");
													if(status.equalsIgnoreCase("failure")){
														if (log.isErrorEnabled()) {
															log.error(jsonObject.getString("Response Message"));
														}
														errorsOnProc.add(jsonObject.getString("Response Message"));
													}else{
														parameterChangefinaldata.add(jsonObject);
													}
												}
											}

											relatedParamChangeNotification = relatedParamChangeMethod.invoke(instance,ListOfAssetInstanceProperties);
											if(relatedParamChangeNotification != null){
												JSONObject jsonObject = new JSONObject(relatedParamChangeNotification.toString());

												if(jsonObject.has("Response Status")){
													String status = jsonObject.getString("Response Status");
													if(status.equalsIgnoreCase("failure")){
														if (log.isErrorEnabled()) {
															log.error(jsonObject.getString("Response Message"));
														}
														errorsOnProc.add(jsonObject.getString("Response Message"));
													}else{
														relatedParamChangefinaldata.add(jsonObject);
													}
												}
											}
										}
										catch (IllegalAccessException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (IllegalArgumentException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										} catch (InvocationTargetException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}catch(Exception e){
											e.printStackTrace();
											throw new RepoproException(e.getMessage());
										}
									}else{
										if (log.isErrorEnabled()) {
											log.error("Invalid Plugin configuration");
										}
										errorsOnProc.add("Invalid Plugin configuration");

									}
								}

								if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")|| CommonUtils.customParameterPluginPath.equalsIgnoreCase("")){
									if (log.isErrorEnabled()) {
										log.error("Invalid Plugin configuration");
									}
									errorsOnProc.add("Invalid Plugin configuration");
								}
							}
							if(CommonUtils.customParameterPluginNoficationClassName != null ){
								if(CommonUtils.customParameterPluginNoficationClassName .equalsIgnoreCase("")){
									if (log.isErrorEnabled()) {
										log.error("Invalid Plugin configuration");
									}
									errorsOnProc.add("Invalid Plugin configuration");
								}
							}else if(CommonUtils.customParameterPluginPath != null){
								if(CommonUtils.customParameterPluginPath .equalsIgnoreCase("")){
									if (log.isErrorEnabled()) {
										log.error("Invalid Plugin configuration");
									}
									errorsOnProc.add("Invalid Plugin configuration");
								}
							}
						}
					}
				}

				if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
					List<Long> actualparamAivId = new ArrayList<Long>();
					for(int i=0;i<apsVoList.size();i++)
					{
						NameValue nv = new NameValue();
						AssetInstance ai = new AssetInstance();
						ai.setAssetName(apsVoList.get(i).getAssetType());
						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
						ai.setAssetId(asset.getAssetId());
						ai.setAssetInstName(apsVoList.get(i).getAssetInstName());
						ai.setVersionName(apsVoList.get(i).getVersionName());
						ai.setParentAssetName(apsVoList.get(i).getParentAssetName());
						ai.setParentAssetInstName(apsVoList.get(i).getParentAssetInstanceName());
						nv.setName(apsVoList.get(i).getParamName());
						AssetParamDef apd11 = assetDao.retParamIdForAssetAndParamName(apsVoList.get(i).getAssetType(), apsVoList.get(i).getParamName(), conn);

						AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
						ai.setAssetInstVersionId(aiv.getAssetInstVersionId());
						if(!apsVoList.get(i).getParamTypeId().equals(3L))
						{
							boolean flagCheck = false;
							if(apsVoList.get(i).isHasStaticValue() == false)
							{
								ParameterValues pv1	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);
								if(globalLock.getGlobalSettingFlag()== 1)
								{
									if(radValStatic.equalsIgnoreCase("New"))
									{
										if(pv1 != null)
										{
											if(aiv.getLockTime()!= null)
											{

												if(apd11.getParamTypeId().equals(7L) && apsVoList.get(i).getHasArray()==1){
													List<String> newTextData = apsVoList.get(i).getRTFwithTags();
													List<String> oldTextData = pv1.getRTFwithTags();
													if(!oldTextData.equals(newTextData)){
														//if(num < 0 || num > 0 ){
														flagCheck = false;
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId() == 8L){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}
													}
												}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){

													List<String> newTextData = apsVoList.get(i).getTextDataList();
													List<String> oldTextData = pv1.getTextDataList();
													if(!oldTextData.equals(newTextData)){
														//if(num < 0 || num > 0 ){
														flagCheck = false;
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}
													}
												}else if(apd11.getParamTypeId().equals(9L)){
													List<String> newLdapMappingData = apsVoList.get(i).getLdapMappingValue().keySet().stream()
															.collect(Collectors.toList());
													List<String> oldLdapMappingData = pv1.getLdapMappingList();
													if(!oldLdapMappingData.equals(newLdapMappingData)){
														//if(num < 0 || num > 0 ){
														flagCheck = false;
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}
													}
												}
												else{
													String oldValueImp = pv1.getValue().trim().toString();
													String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

													int num = oldValueImp.compareTo(newValueImp);

													if(num < 0 || num > 0 ){
														flagCheck = false;
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}
													}
												}
											}
											else
											{
												flagCheck = true;  
											}
										}
										else
										{
											if(aiv.getLockTime()!= null)
											{
												if(apd11.getParamTypeId().equals(7L)&& apsVoList.get(i).getHasArray()==1){
													if(!apsVoList.get(i).getRTFwithTags().isEmpty())
													{
														flagCheck = false; 
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}
													}
												}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){
													if(!apsVoList.get(i).getTextDataList().isEmpty())
													{
														flagCheck = false; 
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}
													}

												}else if(apd11.getParamTypeId().equals(9L)){
													if(!apsVoList.get(i).getLdapMappingValue().isEmpty())
													{
														flagCheck = false; 
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}
													}

												}else{
													if(!apsVoList.get(i).getParamValue().isEmpty())
													{
														flagCheck = false; 
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}
													}
												}
											}
											else
											{
												flagCheck = true; 
											}
										}
									}
									else
									{
										if(pv1 != null)
										{
											if(aiv.getLockTime()!= null)
											{
												if(apd11.getParamTypeId().equals(7L)&& apsVoList.get(i).getHasArray()==1){
													List<String> newTextData = apsVoList.get(i).getRTFwithTags();
													List<String> oldTextData = pv1.getRTFwithTags();
													if(!oldTextData.equals(newTextData))
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}
												}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){
													List<String> newTextData = apsVoList.get(i).getTextDataList();
													List<String> oldTextData = pv1.getTextDataList();
													if(!oldTextData.equals(newTextData))
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}
												}else if(apd11.getParamTypeId().equals(9L)){
													List<String> newLdapMappingData = apsVoList.get(i).getLdapMappingValue().keySet().stream()
															.collect(Collectors.toList());
													List<String> oldLdapMappingData = pv1.getLdapMappingList();
													if(!oldLdapMappingData.equals(newLdapMappingData))
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}

												}else{
													String oldValueImp = pv1.getValue().trim().toString();
													String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

													int num = oldValueImp.compareTo(newValueImp);
													if(num < 0 || num > 0 )
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}
												}

											}
											else{
												flagCheck = true;  
											}
										}
										else
										{
											if(aiv.getLockTime()!= null)
											{
												if(apd11.getParamTypeId().equals(7L)&& apsVoList.get(i).getHasArray()==1){
													if(!apsVoList.get(i).getRTFwithTags().isEmpty())
														//if(!apsVoList.get(i).getParamValue().isEmpty())
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}
												}else if(apd11.getParamTypeId().equals(1L)&& apsVoList.get(i).getHasArray()==1){
													if(!apsVoList.get(i).getTextDataList().isEmpty())
														//if(!apsVoList.get(i).getParamValue().isEmpty())
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}

												}else if(apd11.getParamTypeId().equals(9L)){
													if(!apsVoList.get(i).getLdapMappingValue().isEmpty())
														//if(!apsVoList.get(i).getParamValue().isEmpty())
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}

												}else{
													if(!apsVoList.get(i).getParamValue().isEmpty())
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}
													}
												}
											}
											else
											{
												flagCheck = true; 
											}
										}
									}
								}
								else
								{
									flagCheck = true;
								}
							}
							else
							{
								if(globalLock.getGlobalSettingFlag()== 1)
								{
									if(radValStatic.equalsIgnoreCase("New"))
									{
										if(aiv.getLockTime()!= null)
										{
											//if(paramList.get(i).getStaticValue() != null)
											if(apd11.getStaticValue() != null)
											{
												String oldValueImp = apd11.getStaticValue().trim().toString();
												String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

												int num = oldValueImp.compareTo(newValueImp);

												if(num < 0 || num > 0 )
												{
													flagCheck = false;
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck = true;
														}

													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}  
												}
											}
											else{
												if( !apsVoList.get(i).getParamValue().isEmpty()){
													flagCheck = false;
													if (log.isErrorEnabled()) {
														log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
													}
													lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
											}
										}
										else
										{
											flagCheck = true;
										}
									}
									else
									{
										if(aiv.getLockTime()!= null)
										{
											//if(paramList.get(i).getStaticValue() != null)
											if(apd11.getStaticValue() != null)
											{
												String oldValueImp = apd11.getStaticValue().trim().toString();
												String newValueImp = apsVoList.get(i).getParamValue().trim().toString();

												int num = oldValueImp.compareTo(newValueImp);

												if(num < 0 || num > 0 )
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											}
											else{
												if(!apsVoList.get(i).getParamValue().isEmpty()){
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck = true;
													}
												}
											}
										}
										else
										{
											flagCheck = true;
										}
									}
								}
								else
								{
									flagCheck = true;
								}
							}
							AssetInstanceVersion assetInstver = null;

							nv.setValue(apsVoList.get(i).getParamValue());
							if(flagCheck == true)
							{
								if(apd11.getParamTypeId().equals(5L)){
								}else if(apd11.getParamTypeId().equals(6L)){ 
								}else if(apd11.getParamTypeId().equals(8L)){
								}else{
									//nv.setValue(apsVoList.get(i).getParamValue());
									assetInstver = new AssetInstanceVersion();
									assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
									if(apd11.getParamTypeId().equals(7L)){
										if(apsVoList.get(i).isHasStaticValue()){
											assetInstver.setParamValue(apsVoList.get(i).getParamValue());
										}else if(apsVoList.get(i).getHasArray()==0){
											assetInstver.setParamValue(apsVoList.get(i).getParamValue());
											assetInstver.setRTFPlainText(apsVoList.get(i).getRTFPlainText());
										}else{
											assetInstver.setRTFwithOutTags(apsVoList.get(i).getRTFwithOutTags());
											assetInstver.setRTFwithTags(apsVoList.get(i).getRTFwithTags());
										}
									}else if(apd11.getParamTypeId().equals(1L)){
										if(apsVoList.get(i).isHasStaticValue()){
											assetInstver.setParamValue(apsVoList.get(i).getParamValue());
										}else if(apsVoList.get(i).getHasArray()==0){
											assetInstver.setParamValue(apsVoList.get(i).getParamValue());
										}else{
											assetInstver.setTextDataList(apsVoList.get(i).getTextDataList());
										}
									}else if(apd11.getParamTypeId().equals(9L)){

										assetInstver.setLdapMappingValue(apsVoList.get(i).getLdapMappingValue());
									}else{
										assetInstver.setParamValue(apsVoList.get(i).getParamValue());
									}
									//assetInstver.setParamValue(apsVoList.get(i).getParamValue());

									//assetInstver.setByteValue(nv.getByteValue());
									//assetInstver.setFileName(nv.getFileName());
									assetInstver.setParamTypeId(apd11.getParamTypeId());
									if(apsVoList.get(i).isHasStaticValue() == false){
										assetInstver.setIsStatic(0);
									}else{
										assetInstver.setIsStatic(1);
									}
									apsVoList.get(i).isHasStaticValue();
									//nv.setName(apsVoList.get(i).getParamName());
									//InputStream myInputStream = new ByteArrayInputStream(nv.getByteValue()); 
									//nv.setImage(myInputStream);
									assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
									assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());
									assetInstver.setAssetName(ai.getAssetName());
									assetInstver.setHasArray(apsVoList.get(i).getHasArray());

									//recent activity
									actualparamAivId.add(ai.getAssetInstVersionId());

									//	assetInstanceVersionList.add(assetInstver);

									//assetInstanceVersionsManager.updateAssetInstancePropertiesRest(apsVoList.get(i).getAssetType(), apsVoList.get(i).getAssetInstName(), apsVoList.get(i).getVersionName(),userName,assetInstanceVersionList);
									assetInstanceVersionsManager.updateParameterForAssetInst(assetInstver, null, profile.getUserId(), conn);
									aiv.setVersionName(ai.getVersionName());
									aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);

								}
							}
						}
						else{
							boolean flagCheck1 = false;
							//AssetParamDef apd11 = assetDao.retParamIdForAssetAndParamName(apsVoList.get(i).getAssetType(), apsVoList.get(i).getParamName(), conn);
							if(apsVoList.get(i).isHasStaticValue() == false)
							{
								ParameterValues pv1	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);

								if(globalLock.getGlobalSettingFlag()== 1)
								{
									if(radValStatic.equalsIgnoreCase("New"))
									{
										if(pv1 != null)
										{
											if(pv1.getFileName() != null)
											{
												if(aiv.getLockTime()!= null)
												{
													if(!pv1.getFileName().equals(apsVoList.get(i).getParamValue()))
													{
														flagCheck1 = false;
														long databaseTime = aiv.getLockTime().getTime();
														long systemTime = System.currentTimeMillis();
														if( systemTime > databaseTime){
															if(apd11.getParamTypeId().equals(5L)){
															}else if(apd11.getParamTypeId().equals(6L)){ 
															}else if(apd11.getParamTypeId().equals(8L)){
															}else{
																aiv.setLockedBy(null);
																aiv.setLockTime(null);
																assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
																flagCheck1 = true;
															}
														}else{
															if (log.isErrorEnabled()) {
																log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
															}
															lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
														}
													}
												}
												else{
													flagCheck1 = true;
												}
											}
										}
										else
										{
											if(aiv.getLockTime()!= null)
											{
												if(!apsVoList.get(i).getParamValue().isEmpty())
												{
													flagCheck1 = false;
													long databaseTime = aiv.getLockTime().getTime();
													long systemTime = System.currentTimeMillis();
													if( systemTime > databaseTime){
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck1 = true;
														}
													}else{
														if (log.isErrorEnabled()) {
															log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
														}
														lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
													}
												}
											}
											else{
												flagCheck1 = true;
											}
										}
									}
									else
									{
										if(pv1 != null)
										{
											if(pv1.getFileName() != null)
											{
												if(aiv.getLockTime()!= null)
												{
													if(!pv1.getFileName().equals(apsVoList.get(i).getParamValue()))
													{
														if(apd11.getParamTypeId().equals(5L)){
														}else if(apd11.getParamTypeId().equals(6L)){ 
														}else if(apd11.getParamTypeId().equals(8L)){
														}else{
															aiv.setLockedBy(null);
															aiv.setLockTime(null);
															assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
															flagCheck1 = true;
														}
													}
												}
											}
										}
										else
										{
											if(aiv.getLockTime()!= null)
											{
												if(!apsVoList.get(i).getParamValue().isEmpty())
												{
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck1 = true;
													}
												}
											}
										}
									}

								}
								else{
									flagCheck1 = true;
								}
							}
							else
							{
								if(globalLock.getGlobalSettingFlag()== 1)
								{if(radValStatic.equalsIgnoreCase("New"))
								{
									if(aiv.getLockTime()!= null)
									{
										if(apd11.getFileName() != null)
										{
											String oldValueImp = apd11.getFileName().trim().toString();
											String newValueImp = apsVoList.get(i).getParamValue().trim().toString();
											int num = oldValueImp.compareTo(newValueImp);

											if(num < 0 || num > 0 )
											{
												flagCheck1 = false;
												long databaseTime = aiv.getLockTime().getTime();
												long systemTime = System.currentTimeMillis();
												if( systemTime > databaseTime){
													if(apd11.getParamTypeId().equals(5L)){
													}else if(apd11.getParamTypeId().equals(6L)){ 
													}else if(apd11.getParamTypeId().equals(8L)){
													}else{
														aiv.setLockedBy(null);
														aiv.setLockTime(null);
														assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
														flagCheck1 = true;
													}
												}else{
													if (log.isErrorEnabled()) {
														log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
													}
													lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");	 
												}

											}
										}
										else{
											if( !apsVoList.get(i).getParamValue().isEmpty()){
												flagCheck1 = false;
												if (log.isErrorEnabled()) {
													log.error("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
												lockedVersionIds.add("Asset Instance Version parameters details cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
											}
										}
									}
									else{
										flagCheck1 = true;
									}
								}
								else
								{
									if(aiv.getLockTime()!= null)
									{
										if(apd11.getFileName() != null)
										{
											String oldValueImp = apd11.getFileName().trim().toString();
											String newValueImp = apsVoList.get(i).getParamValue().trim().toString();
											int num = oldValueImp.compareTo(newValueImp);

											if(num < 0 || num > 0 )
											{
												if(apd11.getParamTypeId().equals(5L)){
												}else if(apd11.getParamTypeId().equals(6L)){ 
												}else if(apd11.getParamTypeId().equals(8L)){
												}else{
													aiv.setLockedBy(null);
													aiv.setLockTime(null);
													assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
													flagCheck1 = true;
												}
											}
										}
										else{
											if( !apsVoList.get(i).getParamValue().isEmpty()){
												if(apd11.getParamTypeId().equals(5L)){
												}else if(apd11.getParamTypeId().equals(6L)){ 
												}else if(apd11.getParamTypeId().equals(8L)){
												}else{
													aiv.setLockedBy(null);
													aiv.setLockTime(null);
													assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
													flagCheck1 = true;
												}
											}
										}
									}
									else{
										flagCheck1 = true;
									}
								}
								}
								else{
									flagCheck1 = true;
								}
							}
							//Map<String,String> paramMapFromDb = (Map<String, String>) assetDao.getParamValuesForAssetInst(ai.getAssetName(), ai.getVersionName(),ai.getAssetInstName(), conn);

							Map<String,String> paramMapFromDb = new LinkedHashMap<String, String>();
							AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
							List<AssetParamDef> paramMap = new ArrayList<AssetParamDef>();
							List<AssetInstanceVersion> assetdata = assetInstanceVersionsManager.getParameter(ai.getAssetName(),userName,aiv1.getAssetInstVersionId(),conn);
							for(AssetInstanceVersion aivData: assetdata){
								AssetParamDef apd = new AssetParamDef();
								if (aivData.getIsStatic() == 1) {
									if (aivData.getParamTypeId() == 3) {
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getApdFileName());
									}else{
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getStaticValue());
									}

								} else {
									if (aivData.getParamTypeId() == 3) {
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getFileName());
									}else if(aivData.getParamTypeId() == 1){
										if(aivData.getTextDataList()!= null){
											String textdata = String.join("~~", aivData.getTextDataList());
											apd.setAssetParamName(aivData.getAssetParamName());
											apd.setParamValue(textdata);
										}else{
											apd.setAssetParamName(aivData.getAssetParamName());
											apd.setParamValue(aivData.getParamValue());
										}
									}else if(aivData.getParamTypeId() == 7){
										if(aivData.getRTFwithTags()!= null){
											String textdata = String.join("~~", aivData.getRTFwithTags());
											apd.setAssetParamName(aivData.getAssetParamName());
											apd.setParamValue(textdata);
										}else{
											apd.setAssetParamName(aivData.getAssetParamName());
											apd.setParamValue(aivData.getParamValue());
										}
									}else if(aivData.getParamTypeId() == 9){
										if(aivData.getLdapMappingValue() != null) {
											List<LdapMapping> ldapMapping = assetDao.getLdapMappingAttributeList(aivData.getLdapMappingId(), conn);
											for (Map.Entry<String,Integer> entry : aivData.getLdapMappingValue().entrySet()){
												for(LdapMapping ldapAttributes:ldapMapping) {
													if(entry.getValue() == ldapAttributes.getLdapAttributeId()) {
														apd.setAssetParamName(aivData.getAssetParamName()+"_"+ldapAttributes.getAttributeDisplayName());
														//	LdapMapping attribute = assetDao.getLdapMappingAttributeByattributeId(attributeId, conn);
														///List<String> values = aiv.getLdapMappingValue().keySet().stream().collect(Collectors.toList());
														apd.setParamValue(null);
													}
												}
											}
										}
									}else {
										apd.setAssetParamName(aivData.getAssetParamName());
										apd.setParamValue(aivData.getParamValue());
									}
								}
								paramMap.add(apd);
							}
							for (AssetParamDef assetdef : paramMap) paramMapFromDb.put(assetdef.getAssetParamName(),assetdef.getParamValue()+"|"+apsVoList.get(i).isHasStaticValue());
							String OldFileName = null;
							boolean updateFlag = false;
							for (Map.Entry<String, String> entry : paramMapFromDb.entrySet()) {
								String splitStaticVal = entry.getValue().substring(entry.getValue().indexOf("|")+1);
								String splitVal = entry.getValue().substring(0,entry.getValue().indexOf("|"));
								if(apsVoList.get(i).getParamName().equalsIgnoreCase(entry.getKey())){
									if(!apsVoList.get(i).getParamValue().equalsIgnoreCase(splitVal.toString())){
										ParameterValues pv = null;
										AssetParamDef apd = null;

										if(apsVoList.get(i).getParamValue() != "" && apsVoList.get(i).getParamValue() !=null)	
										{
											File file= new File(System.getProperty("user.home")+"/RepoProUnzip/"+apsVoList.get(i).getParamValue());

											nv.setFileName(file.getName());

											nv.setByteValue(FileUtils.readFileToByteArray(file));

											nv.setFileMimeType(new MimetypesFileTypeMap().getContentType(file));

											OldFileName = splitVal.toString();

											updateFlag = true;
											break;}
										else{
											byte[] empty = {} ;
											nv.setFileName(apsVoList.get(i).getParamValue());
											nv.setByteValue(empty);
											nv.setFileMimeType(null);
											updateFlag = true;
											break;
										}	
									}	
								}
							}
							if(flagCheck1 == true)
							{
								if(updateFlag == true){
									AssetInstanceVersion assetInstver = null;
									if(apd11.getParamTypeId() == 5){
									}else if(apd11.getParamTypeId() == 6){ 
									} else if(apd11.getParamTypeId() == 8){
									}else{ 

										assetInstver = new AssetInstanceVersion();
										assetInstver.setAssetParamName(apsVoList.get(i).getParamName());
										assetInstver.setParamValue(apsVoList.get(i).getParamValue());
										assetInstver.setParamTypeId(apd11.getParamTypeId());
										if(apsVoList.get(i).isHasStaticValue() == false){
											assetInstver.setIsStatic(0);
										}else{
											assetInstver.setIsStatic(1);
										}
										apsVoList.get(i).isHasStaticValue();
										nv.setName(apsVoList.get(i).getParamName());
										InputStream myInputStream = null ;
										myInputStream = new ByteArrayInputStream(nv.getByteValue()); 
										nv.setImage(myInputStream);
										assetInstver.setAssetParamId(apsVoList.get(i).getAssetParamId());
										assetInstver.setAssetInstVersionId(ai.getAssetInstVersionId());

										actualparamAivId.add(ai.getAssetInstVersionId());

										assetInstver.setAssetName(ai.getAssetName());
										assetInstanceVersionsManager.updateParameterForAssetInst(assetInstver,nv,profile.getUserId(),conn);

										aiv.setVersionName(ai.getVersionName());
										aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aiv,aiv.getAssetInstVersionId(), conn);

										assetInstver.setFileName(OldFileName);
										assetInstver.setNewFileName(nv.getFileName());
										InputStream myInputStream1 = null;
										myInputStream1 = new ByteArrayInputStream(nv.getByteValue()); 
										assetInstanceVersionsManager.getNameValue(assetInstver, myInputStream1, nv.getFileName(), context, conn);

									}
								}
							}
							/*if(!valMap1.isEmpty()){
					for (Map.Entry<String, String> entry : valMap1.entrySet())
					{
						ParameterValues pv	= assetDao.getParameterForAssetInstParamAndVersionId(apsVoList.get(i).getParamName(),aiv.getAssetInstVersionId(), conn);
						if(pv != null){
							String splitVal = entry.getValue().substring(entry.getValue().indexOf("|")+1);
							File oldfile =new File(request.getRealPath("")+"/images/thumbnailImages/" +splitVal);
							File newfile =new File(request.getRealPath("")+"/images/thumbnailImages/" +pv.getAssetParamId().toString() +"_"+ splitVal);
							oldfile.renameTo(newfile);
							File oldfile1 =new File(System.getProperty("user.home")+"/ThumbnailImages/" + splitVal);
							File newfile1 =new File(System.getProperty("user.home")+"/ThumbnailImages/"+pv.getAssetParamId().toString() +"_"+ splitVal);
							oldfile1.renameTo(newfile1);
						}
					}
				}*/
						}
						/*RecentActivity recentActivity = new RecentActivity();
			String action = Constants.ACTIVITY_MODIFY;
			String appendingMsg = "";
			recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
			recentActivity.setAssetId(ai.getAssetId().toString());
			recentActivity.setAssetInstVersionId(ai.getAssetInstVersionId().toString());
			recentActivity.setUser_id(profile.getUserId());

			if (asset.isVersionable() == true) {
				String log = profile.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ ai.getAssetInstName() + ";"+ " Version " + ai.getVersionName();
				recentActivity.setDescription(log);
			} else {
				String log = profile.getFullName() + ";" + action + ";"+ asset.getAssetName() + ";"+ ai.getAssetInstName() + ";"+ appendingMsg;
				recentActivity.setDescription(log);
			}
			recentActivityDao.addRecentActivity(recentActivity, conn);*/

					}  //End of for

					List<Long> paramAivId = new ArrayList<Long>();
					List<Long> finalparamAivId = new ArrayList<Long>();

					for(int i=0;i<azds.size();i++)
					{
						AssetInstance ai = new AssetInstance();

						ai.setAssetName(azds.get(i).getAssetName());
						ai.setAssetInstName(azds.get(i).getAssetInstName());
						ai.setVersionName(azds.get(i).getVersionName());
						//revision history data for parameter
						AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);

						if(actualparamAivId.contains(aivVo.getAssetInstVersionId())){
							paramAivId.add(aivVo.getAssetInstVersionId());
							for(AivRevisionHistory paramRev:aivRevHistList){
								if(paramRev.getAivId().equals(aivVo.getAssetInstVersionId())){
									finalparamAivId.add(aivVo.getAssetInstVersionId());
									paramRev.setParameterKey("P");
									paramRev.setParameterData(azds.get(i).getParamRevData());
									paramRev.setVersionName(azds.get(i).getVersionName());
								}
							}
						}
						/*	assetInstanceVersionsManager.addRevisionData("P",aivVo.getAssetInstVersionId(),ai.getVersionName(),null, null, 
					azds.get(i).getParamRevData(), null,userName,profile.getUserId(),null,conn);*/

					}
					paramAivId.removeAll(finalparamAivId);

					for(int i=0;i<azds.size();i++)
					{
						AssetInstance ai = new AssetInstance();
						ai.setAssetName(azds.get(i).getAssetName());
						ai.setAssetInstName(azds.get(i).getAssetInstName());
						ai.setVersionName(azds.get(i).getVersionName());
						//revision history data for parameter
						AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);

						for(Long paramRev:paramAivId){
							if(paramRev.equals(aivVo.getAssetInstVersionId())){
								AivRevisionHistory revHis = new AivRevisionHistory();
								revHis.setParameterKey("P");
								revHis.setParameterData(azds.get(i).getParamRevData());
								revHis.setVersionName(azds.get(i).getVersionName());
								revHis.setAivId(aivVo.getAssetInstVersionId());
								aivRevHistList.add(revHis);

								RecentActivity recentActivity = new RecentActivity();
								recentActivity.setAssetName(azds.get(i).getAssetName());
								recentActivity.setAssetInstName(azds.get(i).getAssetInstName());
								recentActivity.setAssetInstanceVersionName(azds.get(i).getVersionName());
								recentActivity.setAssetInstVersionId(aivVo.getAssetInstVersionId().toString());
								recentActivityList.add(recentActivity);

								aivIds.put(aivVo.getAssetInstVersionId().toString(),"update");
							}
						}
					}
					List<String> taxAivId = new ArrayList<String>();
					for(int i=0;i<assetInstassignList.size();i++)
					{
						AssetInstance ai = new AssetInstance();

						ai.setAssetName(assetInstassignList.get(i).getAssetName());
						ai.setAssetInstName(assetInstassignList.get(i).getAssetInstanceName());
						ai.setVersionName(assetInstassignList.get(i).getVersionName());

						AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersion(ai,conn);

						AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

						String taxonomies = null;
						taxonomies = StringUtils.join(assetInstassignList.get(i).getTaxonIds(), ',');

						if(globalLock.getGlobalSettingFlag()==1){
							if(radValStatic.equalsIgnoreCase("New")){

								if(aiv.getLockTime()==null){
									Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
											taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
									MyModel res = (MyModel) response.getEntity();
									Map<String,String> taxdata = res.getParamValues();
									taxIds.put(aiv.getAssetInstVersionId().toString(),taxdata);

									taxAivId.add(aiv.getAssetInstVersionId().toString());

									aiv.setVersionName(ai.getVersionName());
									aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
								}
								else{
									long databaseTime = aiv.getLockTime().getTime();
									long systemTime = System.currentTimeMillis();
									if( systemTime > databaseTime ){
										aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
										aiv.setLockedBy(null);
										aiv.setLockTime(null);
										assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);

										Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
												taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
										MyModel res = (MyModel) response.getEntity();
										Map<String,String> taxdata = res.getParamValues();
										taxIds.put(aiv.getAssetInstVersionId().toString(),taxdata);

										taxAivId.add(aiv.getAssetInstVersionId().toString());

										aiv.setVersionName(ai.getVersionName());
										aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
									}
									else{
										if (log.isErrorEnabled()) {
											log.error("Asset Instance Version Taxonomies cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
										}
										lockedVersionIds.add("Asset Instance Version Taxonomies cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
									}
								}
							}
							else{
								if(aiv.getLockTime()!=null){
									aiv.setAssetInstVersionId(aiv.getAssetInstVersionId());
									aiv.setLockedBy(null);
									aiv.setLockTime(null);
									assetInstanceVersionDao.updateAssetInstanceVersion(aiv, conn);
								}
								Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
										taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
								MyModel res = (MyModel) response.getEntity();
								Map<String,String> taxdata = res.getParamValues();
								taxIds.put(aiv.getAssetInstVersionId().toString(),taxdata);
								taxAivId.add(aiv.getAssetInstVersionId().toString());

								aiv.setVersionName(ai.getVersionName());
								aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
							}
						}
						else{

							Response response = assetInstanceVersionsManager.addTaxonomyForAssetInstanceVersionHelper(aiv.getAssetInstVersionId(),
									taxonomies,asset.isVersionable(),ai.getVersionName(),ai.getAssetInstName(),true,conn);
							MyModel res = (MyModel) response.getEntity();
							Map<String,String> taxdata = res.getParamValues();
							taxIds.put(aiv.getAssetInstVersionId().toString(),taxdata);
							taxAivId.add(aiv.getAssetInstVersionId().toString());

							aiv.setVersionName(ai.getVersionName());
							aiv.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							assetInstanceVersionDao.updateAivUpdatedOn(aiv, aiv.getAssetInstVersionId(), conn);
						}
					}

					List<String> taxdata = new ArrayList<String>();
					for(Map.Entry<String,String> entry : aivIds.entrySet()){
						String id = entry.getKey();
						for(String finalid:taxAivId){
							if(finalid.equalsIgnoreCase(id)){
								taxdata.add(finalid);
							}
						}
					}
					taxAivId.removeAll(taxdata);
					for(String finalid:taxAivId){
						aivIds.put(finalid,"update");
					}


					TaggingMaster taggingMaster = new TaggingMaster();
					for(int i=0;i<assetInstTaggingList.size();i++)
					{
						AssetInstance ai = new AssetInstance();

						ai.setAssetName(assetInstTaggingList.get(i).getAssetName());
						ai.setAssetInstName(assetInstTaggingList.get(i).getAssetInstanceName());
						ai.setVersionName(assetInstTaggingList.get(i).getVersionName());
						AssetInstanceVersion aivtag = assetInstanceVersionDao.getAssetInstanceVersion(ai, conn);
						ai.setAssetInstVersionId(aivtag.getAssetInstVersionId());

						taggingMaster.setAssetInstanceVersionId(ai.getAssetInstVersionId());
						TaggingMaster tagsForAIV = taggingDao.getAllTags(taggingMaster, conn);
						List<String> tagsFromXls = assetInstTaggingList.get(i).getTagsFromXls();
						taggingMaster.setUserId(profile.getUserId());
						taggingMaster.setAssetInstanceVersionId(ai.getAssetInstVersionId());
						if(globalLock.getGlobalSettingFlag()==1){
							if(radValStatic.equalsIgnoreCase("New")){

								if(aivtag.getLockTime()==null){
									for (String tagNameFromXls : tagsFromXls )
									{
										boolean addflg = false;
										for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
										{
											if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
											{
												addflg = true;
												break;
											}
										}
										if(!addflg)
										{
											taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

										}
									}

									for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
									{
										boolean rmflg = false;
										taggingMaster.setTagId(tagNameForAIV.getKey());
										for( String tagNameFromXls: tagsFromXls)
										{
											if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
											{
												rmflg = true;
												break;
											}
										}

										if(!rmflg)
										{
											taggingDao.deleteTagsForImport(taggingMaster, conn);

										}
									}
									aivtag.setVersionName(ai.getVersionName());
									aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
								}
								else{
									long databaseTime = aivtag.getLockTime().getTime();
									long systemTime = System.currentTimeMillis();
									if( systemTime > databaseTime ){
										aivtag.setAssetInstVersionId(aivtag.getAssetInstVersionId());
										aivtag.setLockedBy(null);
										aivtag.setLockTime(null);
										assetInstanceVersionDao.updateAssetInstanceVersion(aivtag, conn);

										for (String tagNameFromXls : tagsFromXls )
										{
											boolean addflg = false;
											for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
											{
												if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
												{
													addflg = true;
													break;
												}
											}
											if(!addflg)
											{
												taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

											}
										}

										for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
										{
											boolean rmflg = false;
											taggingMaster.setTagId(tagNameForAIV.getKey());
											for( String tagNameFromXls: tagsFromXls)
											{
												if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
												{
													rmflg = true;
													break;
												}
											}

											if(!rmflg)
											{
												taggingDao.deleteTagsForImport(taggingMaster, conn);

											}
										}
										aivtag.setVersionName(ai.getVersionName());
										aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
									}
									else{
										if (log.isErrorEnabled()) {
											log.error("Asset Instance Version tags cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
										}
										lockedVersionIds.add("Asset Instance Version tags cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
									}
								}
							}
							else{
								if(aivtag.getLockTime()!=null){
									aivtag.setAssetInstVersionId(aivtag.getAssetInstVersionId());
									aivtag.setLockedBy(null);
									aivtag.setLockTime(null);
									assetInstanceVersionDao.updateAssetInstanceVersion(aivtag, conn);
								}
								for (String tagNameFromXls : tagsFromXls )
								{
									boolean addflg = false;
									for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
									{
										if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
										{
											addflg = true;
											break;
										}
									}
									if(!addflg)
									{
										taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

									}
								}

								for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
								{
									boolean rmflg = false;
									taggingMaster.setTagId(tagNameForAIV.getKey());
									for( String tagNameFromXls: tagsFromXls)
									{
										if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
										{
											rmflg = true;
											break;
										}
									}

									if(!rmflg)
									{
										taggingDao.deleteTagsForImport(taggingMaster, conn);

									}
								}
								aivtag.setVersionName(ai.getVersionName());
								aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
							}
						}
						else{

							for (String tagNameFromXls : tagsFromXls )
							{
								boolean addflg = false;
								for (Map.Entry<Long, String> tagNameAIV : tagsForAIV.getTagNames().entrySet())
								{
									if(tagNameFromXls.equalsIgnoreCase(tagNameAIV.getValue())) 
									{
										addflg = true;
										break;
									}
								}
								if(!addflg)
								{
									taggingDao.addTagsForImport(taggingMaster,tagNameFromXls, conn);

								}
							}

							for (Map.Entry<Long, String> tagNameForAIV : tagsForAIV.getTagNames().entrySet())
							{
								boolean rmflg = false;
								taggingMaster.setTagId(tagNameForAIV.getKey());
								for( String tagNameFromXls: tagsFromXls)
								{
									if(tagNameForAIV.getValue().equals(tagNameFromXls)) 
									{
										rmflg = true;
										break;
									}
								}

								if(!rmflg)
								{
									taggingDao.deleteTagsForImport(taggingMaster, conn);

								}
							}
							aivtag.setVersionName(ai.getVersionName());
							aivtag.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
							assetInstanceVersionDao.updateAivUpdatedOn(aivtag, aivtag.getAssetInstVersionId(), conn);
						}
					}
				}
			}
			log.debug("Asset Attribute ,Taxonomy and Tagging DB updation done for full import "+listOfassetInstList.toString());

			// Loop Starts for Asset Instance Relationship update 3rd level
			List<Long> relSrcAivIds = new ArrayList<Long>();
			List<Long> recentActivityIds = new ArrayList<Long>();
			List<String> aivformailIds = new ArrayList<String>();
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty())
			{
				for (Entry<String, List<AssetInstRelationship>> entry : listOfassetInstRelList.entrySet())
				{
					for(AssetInstRelationship aiv:entry.getValue())
					{
						AssetInstanceVersion ai = new AssetInstanceVersion();
						ai.setAssetName(aiv.getSrcAssetName());
						ai.setAssetInstName(aiv.getSourceInstanceName());
						ai.setVersionName(aiv.getSourceVersionName());
						AssetDef assetsrc = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);

						AssetInstance assetIns = new AssetInstance();
						assetIns.setAssetName(ai.getAssetName());
						assetIns.setAssetInstName(ai.getAssetInstName());
						assetIns.setVersionName(ai.getVersionName());
						AssetInstanceVersion aivValue = assetInstanceVersionDao.getAssetInstanceVersion(assetIns, conn);
						ai.setAssetInstVersionId(aivValue.getAssetInstVersionId());

						if(aiv.getAction().equals("add"))
						{
							AssetInstance adr1 = new AssetInstance();

							adr1.setAssetName(aiv.getDestAssetName());
							AssetDef assetDataDest = assetInstanceDao.retAssetDetail(adr1.getAssetName(), conn);
							adr1.setAssetId(assetDataDest.getAssetId());
							adr1.setAssetInstName(aiv.getDestInstanceName());
							adr1.setOwner(userName);
							adr1.setVersionName("1.0");

							adr1.setParentVersionName(aiv.getSourceVersionName());
							adr1.setParentAssetName(aiv.getSrcAssetName());
							AssetDef assetDataSrc = assetInstanceDao.retAssetDetail(adr1.getParentAssetName(), conn);
							adr1.setParentAssetId(assetDataSrc.getAssetId());
							adr1.setParentAssetInstName(aiv.getSourceInstanceName());
							adr1.setOwner(profile.getUserName());

							AssetInstance parentAIVid = new AssetInstance();
							parentAIVid.setAssetName(adr1.getParentAssetName());
							parentAIVid.setAssetInstName(adr1.getParentAssetInstName());
							parentAIVid.setVersionName(adr1.getParentVersionName());
							AssetInstanceVersion parentaiv = assetInstanceVersionDao.getAssetInstanceVersion(parentAIVid, conn);
							adr1.setParentAssetInstVersionId(parentaiv.getAssetInstVersionId());

							if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation"))
							{
								//add child
								Response response = assetInstanceManager.addAssetInstanceHelper(adr1,userName,true,true,true,conn);
								MyModel res = (MyModel) response.getEntity();
								List<Object> data = res.getResult();
								for (int i = 0; i < data.size(); i++) {
									AssetInstance aiResponse = new AssetInstance();
									aiResponse = (AssetInstance) data.get(i);
									ai.setAssetInstanceId(aiResponse.getAssetInstId());
									ai.setAssetInstVersionId(aiResponse.getAssetInstVersionId());
								}
								Long firstState = null;
								Workflow workflow = workflowDao.retWorkflowByAivId(ai.getAssetInstVersionId(), conn);
								if(workflow != null) {
									String jsonStructure = workflow.getJsonStructure();
									JSONObject jsonObject = new JSONObject(jsonStructure);
									
									for(int i=0;i<jsonObject.length();i++) {
										Iterator itr = jsonObject.keys();
										if(itr.hasNext()){
											firstState = Long.parseLong(itr.next().toString());
										}
									}
									assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
								}
								aivIds.put(ai.getAssetInstVersionId().toString(),aiv.getAction());

								ai.setVersionName(ai.getVersionName());
								ai.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(ai, ai.getAssetInstVersionId(), conn);
							}
							else
							{
								//add relationship
								List<Long> addAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> selectedAssetRelationship = new ArrayList<Long>();
								List<Long> removedAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> removedAssetRelationship = new ArrayList<Long>();

								AssetInstance assetInstance = new AssetInstance();
								assetInstance.setAssetName(aiv.getDestAssetName());
								assetInstance.setAssetInstName(aiv.getDestInstanceName());
								assetInstance.setVersionName(aiv.getDestInstanceVersionName());

								AssetInstanceVersion aivo =	assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

								addAssetInstanceVersionIds.add(aivo.getAssetInstVersionId());

								AssetRelationshipDef ard = relationshipDao.retAssetRelDefForAssetsByRelationName(aiv.getSrcAssetName(),aiv.getDestAssetName(),aiv.getDescrption(), conn);

								selectedAssetRelationship.add(ard.getAssetRelId());

								ai.setAddDestAssetInstVersionIds(addAssetInstanceVersionIds);
								ai.setAddRelationshipIds(selectedAssetRelationship);
								ai.setRemovedDestAssetInstVersionIds(removedAssetInstanceVersionIds);
								ai.setRemovedRelationshipIds(removedAssetRelationship);
								ai.setSrcAssetInstanceVersionId(ai.getAssetInstVersionId().toString());

								ai.setAssetInstanceId(aivValue.getAssetInstanceId());
								ai.setAssetId(assetsrc.getAssetId());

								if(globalLock.getGlobalSettingFlag()==1){
									if(radValStatic.equalsIgnoreCase("New")){
										if(aivValue.getLockTime()==null){
											assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
											//get all the source asset instance version ids
											relSrcAivIds.add(ai.getAssetInstVersionId());
											recentActivityIds.add(ai.getAssetInstVersionId());
											//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

											aivo.setVersionName(ai.getVersionName());
											aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

										}
										else{
											long dataBaseTime = aivValue.getLockTime().getTime();
											long systemTime = System.currentTimeMillis();
											if(systemTime>dataBaseTime){
												aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
												aivValue.setLockedBy(null);
												aivValue.setLockTime(null);
												assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);

												assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
												//get all the source asset instance version ids
												relSrcAivIds.add(ai.getAssetInstVersionId());
												recentActivityIds.add(ai.getAssetInstVersionId());
												//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

												aivo.setVersionName(ai.getVersionName());
												aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
												assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

											}
											else{
												if (log.isErrorEnabled()) {
													log.error("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
												lockedVersionIds.add("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
											}

										}
									}
									else{
										if(aivValue.getLockTime()!= null){
											aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
											aivValue.setLockedBy(null);
											aivValue.setLockTime(null);
											assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);
										}
										assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
										//get all the source asset instance version ids
										relSrcAivIds.add(ai.getAssetInstVersionId());
										recentActivityIds.add(ai.getAssetInstVersionId());
										//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

										aivo.setVersionName(ai.getVersionName());
										aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
									}
								} else{
									assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
									//get all the source asset instance version ids
									relSrcAivIds.add(ai.getAssetInstVersionId());
									recentActivityIds.add(ai.getAssetInstVersionId());
									//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

									aivo.setVersionName(ai.getVersionName());
									aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
								}
							}
						}
						else if(aiv.getAction().equals("update") || aiv.getAction().equals("skip")) {

							if(aiv.getAction().equals("skip")){
								if(globalLock.getGlobalSettingFlag()==1){
									if(radValStatic.equalsIgnoreCase("New")){
										// Do nothing
									}
									else{
										if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation")){

										}else{
											if(aivValue.getLockTime()!= null){
												aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
												aivValue.setLockedBy(null);
												aivValue.setLockTime(null);
												assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);
											} 
										}
									}
								}
							}
						}else{

							//remove relationship
							if(aiv.getRelationShipName().equals("composition") || aiv.getRelationShipName().equals("aggregation")){
								AssetInstance adr2 = new AssetInstance();
								adr2.setAssetName(aiv.getDestAssetName());
								adr2.setAssetInstName(aiv.getDestInstanceName());
								adr2.setVersionName(aiv.getDestInstanceVersionName());
								adr2.setOwner(profile.getUserName());

								AssetDef asset = assetInstanceDao.retAssetDetail(ai.getAssetName(), conn);
								AssetInstanceVersion aiv1 = assetInstanceVersionDao.getAssetInstanceVersion(adr2, conn);
								int versionFlag = 0;
								if(asset.isVersionable()){
									versionFlag = 1;
								}
								assetInstanceVersionsManager.deleteAssetInstanceVersionsHelper(aiv1.getAssetInstanceId(),ai.getAssetInstName(),
										asset.getAssetId(),asset.getAssetName(),userName,1L,versionFlag,aiv1.getAssetInstVersionId(),ai.getVersionName(),true,conn);

								//aivIds.put(aiv1.getAssetInstVersionId().toString(),"update");
								aivformailIds.add(aiv1.getAssetInstVersionId().toString());

								aivValue.setVersionName(ai.getVersionName());
								aivValue.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
								assetInstanceVersionDao.updateAivUpdatedOn(aivValue, aivValue.getAssetInstVersionId(), conn);

							}else{
								List<Long> 	removeAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> 	removedAssetRelationship =  new ArrayList<Long>();
								List<Long> addAssetInstanceVersionIds = new ArrayList<Long>();
								List<Long> selectedAssetRelationship = new ArrayList<Long>();

								AssetInstance assetInstance = new AssetInstance();
								assetInstance.setAssetName(aiv.getDestAssetName());
								assetInstance.setAssetInstName(aiv.getDestInstanceName());
								assetInstance.setVersionName(aiv.getDestInstanceVersionName());

								AssetInstanceVersion aivo =	assetInstanceVersionDao.getAssetInstanceVersion(assetInstance, conn);

								removeAssetInstanceVersionIds.add(aivo.getAssetInstVersionId());

								AssetRelationshipDef ard = relationshipDao.retAssetRelDefForAssetsByRelationName(aiv.getSrcAssetName(),aiv.getDestAssetName(),aiv.getDescrption(), conn);

								removedAssetRelationship.add(ard.getAssetRelId());

								ai.setRemovedDestAssetInstVersionIds(removeAssetInstanceVersionIds);
								ai.setRemovedRelationshipIds(removedAssetRelationship);
								ai.setAddDestAssetInstVersionIds(addAssetInstanceVersionIds);
								ai.setAddRelationshipIds(selectedAssetRelationship);
								ai.setSrcAssetInstanceVersionId(ai.getAssetInstVersionId().toString());
								ai.setAssetInstanceId(aivValue.getAssetInstanceId());
								ai.setAssetId(assetsrc.getAssetId());


								if(globalLock.getGlobalSettingFlag()==1){
									if(radValStatic.equalsIgnoreCase("New")){
										if(aivValue.getLockTime()==null){
											assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
											//get all the source asset instance version ids
											relSrcAivIds.add(ai.getAssetInstVersionId());
											recentActivityIds.add(ai.getAssetInstVersionId());
											//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

											aivo.setVersionName(ai.getVersionName());
											aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
											assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
										}
										else{
											long dataBaseTime = aivValue.getLockTime().getTime();
											long systemTime = System.currentTimeMillis();
											if(systemTime>dataBaseTime){
												aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
												aivValue.setLockedBy(null);
												aivValue.setLockTime(null);
												assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);

												assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
												//get all the source asset instance version ids
												relSrcAivIds.add(ai.getAssetInstVersionId());
												recentActivityIds.add(ai.getAssetInstVersionId());
												//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

												aivo.setVersionName(ai.getVersionName());
												aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
												assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

											}
											else{
												if (log.isErrorEnabled()) {
													log.error("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
												}
												lockedVersionIds.add("Asset Instance Version Relationships cannot be modified for the "+ai.getAssetInstName()+"_"+ai.getVersionName()+" from "+ai.getAssetName()+" Asset");
											}
										}
									}
									else{
										if(aivValue.getLockTime()!= null){
											aivValue.setAssetInstVersionId(aivValue.getAssetInstVersionId());
											aivValue.setLockedBy(null);
											aivValue.setLockTime(null);
											assetInstanceVersionDao.updateAssetInstanceVersion(aivValue, conn);
										}
										assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
										//get all the source asset instance version ids
										relSrcAivIds.add(ai.getAssetInstVersionId());
										recentActivityIds.add(ai.getAssetInstVersionId());
										//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

										aivo.setVersionName(ai.getVersionName());
										aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
										assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
									}
								}
								else{

									assetInstanceManager.saveDependencyHelper(ai,profile.getUserName(),true,conn);
									//get all the source asset instance version ids
									relSrcAivIds.add(ai.getAssetInstVersionId());
									recentActivityIds.add(ai.getAssetInstVersionId());
									//aivIds.put(ai.getAssetInstVersionId().toString(),"update");

									aivo.setVersionName(ai.getVersionName());
									aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
									assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
								}
							}
						}
					}
				}
				log.debug("Asset Relationship DB Updation done for full import"+listOfassetInstRelList.toString());
			}
			// Loop Ends for Asset Instance Relationship update 3rd level

			//add revision history
			List<Long> relIds = new ArrayList<Long>();
			List<Long> recentActyIds = new ArrayList<Long>();
			List<String> mailIds = new ArrayList<String>();

			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
				Set<Long> finalrelaivids = new HashSet<>();
				finalrelaivids.addAll(relSrcAivIds);
				relSrcAivIds.clear();
				relSrcAivIds.addAll(finalrelaivids);

				for(AivRevisionHistory revRel:aivRevHistList){
					for(Long srcaivids:relSrcAivIds){
						if(srcaivids.equals(revRel.getAivId())){
							relIds.add(srcaivids);
							AssetInstanceVersion aiv = new AssetInstanceVersion();
							aiv.setSrcAssetInstanceVersionId(srcaivids.toString());
							List<AssetInstance> aivos = assetInstanceManager.retFwdDependents(aiv,conn);
							String newRelationshipDataForRevision = "";
							int i = 1;
							for(AssetInstance aivoRev : aivos){
								AssetDef assetDef = assetDao.getAssetsByAssetId(aivoRev.getAssetId(), conn);
								if(i == aivos.size()){
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
									}	
								}else{
									if(!assetDef.isVersionable()){
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
									}else{
										newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
									}
								}
								i++;
							}
							revRel.setRelationshipKey("R");
							revRel.setRelationshipData(newRelationshipDataForRevision);
							AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(srcaivids,conn);
							if(aivVo != null){
								revRel.setVersionName(aivVo.getVersionName());
							}
						}
					}
				}
				//List<Long> finalrelIds = new ArrayList<Long>();
				relSrcAivIds.removeAll(relIds);
				for(Long srcaivids:relSrcAivIds){
					AssetInstanceVersion aiv = new AssetInstanceVersion();
					aiv.setSrcAssetInstanceVersionId(srcaivids.toString());
					List<AssetInstance> aivos = assetInstanceManager.retFwdDependents(aiv,conn);
					String newRelationshipDataForRevision = "";
					int i = 1;
					for(AssetInstance aivoRev : aivos){
						AssetDef assetDef = assetDao.getAssetsByAssetId(aivoRev.getAssetId(), conn);
						if(i == aivos.size()){
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]";	
							}	
						}else{
							if(!assetDef.isVersionable()){
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
							}else{
								newRelationshipDataForRevision = newRelationshipDataForRevision + aivoRev.getAssetName()+"-->"+aivoRev.getAssetInstName()+"_"+aivoRev.getVersionName()+" ["+aivoRev.getAssetRelationshipName()+"]"+"&<!!>&";	
							}
						}
						i++;
					}
					AivRevisionHistory aivRevHisrel = new AivRevisionHistory();
					aivRevHisrel.setRelationshipKey("R");
					aivRevHisrel.setRelationshipData(newRelationshipDataForRevision);
					AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(srcaivids,conn);
					if(aivVo != null){
						aivRevHisrel.setVersionName(aivVo.getVersionName());
					}
					aivRevHisrel.setAivId(srcaivids);
					aivRevHistList.add(aivRevHisrel);
				}

				//recent activity details for relationship data
				Set<Long> finalrecids = new HashSet<>();
				finalrecids.addAll(recentActivityIds);
				recentActivityIds.clear();
				recentActivityIds.addAll(finalrecids);

				for(RecentActivity recent:recentActivityList){
					for(Long recids:recentActivityIds){
						if(recids.toString().equals(recent.getAssetInstVersionId())){
							recentActyIds.add(recids);

						}
					}
				}

				recentActivityIds.removeAll(recentActyIds);
				for(Long recentAct:recentActivityIds){
					RecentActivity acticity = new RecentActivity();
					AssetInstanceVersion aivVo = assetInstanceVersionDao.getAssetInstanceVersionDetails(recentAct,conn);
					if(aivVo != null){
						acticity.setAssetName(aivVo.getAssetName());
						acticity.setAssetInstName(aivVo.getAssetInstName());
						acticity.setAssetInstanceVersionName(aivVo.getVersionName());
						acticity.setAssetInstVersionId(aivVo.getAssetInstVersionId().toString());
						recentActivityList.add(acticity);

						aivIds.put(aivVo.getAssetInstVersionId().toString(),"update");
					}
				}


				Set<String> finalaivids = new HashSet<>();
				finalaivids.addAll(aivformailIds);
				aivformailIds.clear();
				aivformailIds.addAll(finalaivids);
				for(Map.Entry<String,String> entry : aivIds.entrySet()){
					for(String ids:aivformailIds){
						if(entry.getKey().equals(ids)){
							mailIds.add(ids);
						}
					}
				}
				aivformailIds.removeAll(mailIds);

				for(String ids:aivformailIds){
					aivIds.put(ids,"update");
				}

				//add revision history
				RevisionHistoryDao  revisionHistoryDao = new RevisionHistoryDao();
				for(AivRevisionHistory revFinal:aivRevHistList){
					String changeKey = "";  
					if(revFinal.getNewInstanceKey() != null){
						if(revFinal.getNewInstanceKey() == null){
							revFinal.setNewInstanceKey("");
						}
						if(revFinal.getRelationshipKey() == null){
							revFinal.setRelationshipKey("");
						}
						if(revFinal.getParameterKey() == null){
							revFinal.setParameterKey("");
						}
						changeKey = revFinal.getNewInstanceKey()+","+revFinal.getRelationshipKey()+","+revFinal.getParameterKey();
						List<String> list = Arrays.asList(changeKey.split(","));
						List<String> finallist = new ArrayList<String>();
						for(String emptydata:list){
							if(!emptydata.equalsIgnoreCase("")){
								finallist.add(emptydata);
							}
						}
						String listString = String.join(",", finallist);
						AivRevisionHistory aivRevHist = new AivRevisionHistory();
						aivRevHist.setAivId(revFinal.getAivId());
						aivRevHist.setRevId(revFinal.getRevId());
						aivRevHist.setRevisedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						aivRevHist.setChangedKey(listString);
						aivRevHist.setOverviewData(revFinal.getOverviewData());
						if(revFinal.getRelationshipData() != null){
							aivRevHist.setRelationshipData(revFinal.getRelationshipData());
						}else{
							aivRevHist.setRelationshipData(null);
						}
						if(revFinal.getParameterData() != null){
							aivRevHist.setParameterData(revFinal.getParameterData());
						}else{
							aivRevHist.setParameterData(null);
						}
						aivRevHist.setUserId(profile.getUserId());
						aivRevHist.setUsedBy(null);

						revisionHistoryDao.addRevisionData(aivRevHist, conn);

						AssetInstanceVersion aivo = new AssetInstanceVersion();
						aivo.setVersionName("1.0");
						aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						aivo.setAssetInstVersionId(revFinal.getAivId());
						assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);

					}else if(revFinal.getOverviewKey() != null){
						if(revFinal.getOverviewKey() == null){
							revFinal.setOverviewKey("");
							revFinal.setOverviewData("");
						}
						if(revFinal.getRelationshipKey() == null){
							revFinal.setRelationshipKey("");
							revFinal.setRelationshipData("");
						}
						if(revFinal.getParameterKey() == null){
							revFinal.setParameterKey("");
							revFinal.setParameterData("");
						}
						changeKey = revFinal.getOverviewKey()+","+revFinal.getRelationshipKey()+","+revFinal.getParameterKey();
						List<String> list = Arrays.asList(changeKey.split(","));
						List<String> finallist = new ArrayList<String>();
						for(String emptydata:list){
							if(!emptydata.equalsIgnoreCase("")){
								finallist.add(emptydata);
							}
						}
						String listString = String.join(",", finallist);
						assetInstanceVersionsManager.addRevisionData(listString, revFinal.getAivId(),revFinal.getVersionName(), 
								revFinal.getOverviewData(),revFinal.getRelationshipData(),revFinal.getParameterData(), null, userName,profile.getUserId(),"", conn);

						AssetInstanceVersion aivo = new AssetInstanceVersion();
						aivo.setVersionName(revFinal.getVersionName());
						aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						aivo.setAssetInstVersionId(revFinal.getAivId());
						assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
					}else{

						if(revFinal.getOverviewKey() == null){
							revFinal.setOverviewKey("");
							revFinal.setOverviewData("");
						}
						if(revFinal.getRelationshipKey() == null){
							revFinal.setRelationshipKey("");
							revFinal.setRelationshipData("");
						}
						if(revFinal.getParameterKey() == null){
							revFinal.setParameterKey("");
							revFinal.setParameterData("");
						}
						changeKey = revFinal.getOverviewKey()+","+revFinal.getRelationshipKey()+","+revFinal.getParameterKey();
						List<String> list = Arrays.asList(changeKey.split(","));
						List<String> finallist = new ArrayList<String>();
						for(String emptydata:list){
							if(!emptydata.equalsIgnoreCase("")){
								finallist.add(emptydata);
							}
						}
						String listString = String.join(",", finallist);
						assetInstanceVersionsManager.addRevisionData(listString, revFinal.getAivId(),revFinal.getVersionName(), 
								revFinal.getOverviewData(),revFinal.getRelationshipData(),revFinal.getParameterData(), null, userName,profile.getUserId(),"", conn);

						AssetInstanceVersion aivo = new AssetInstanceVersion();
						aivo.setVersionName(revFinal.getVersionName());
						aivo.setUpdatedOn(new Timestamp(Calendar.getInstance().getTimeInMillis()));
						aivo.setAssetInstVersionId(revFinal.getAivId());
						assetInstanceVersionDao.updateAivUpdatedOn(aivo, aivo.getAssetInstVersionId(), conn);
					}
				}
			}
			//add recent activity
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){
				for(RecentActivity recentFinal:recentActivityList){
					RecentActivity recentActivity = new RecentActivity();
					if(recentFinal.getAction()!=null){
						if(recentFinal.getAction().equalsIgnoreCase(Constants.ACTIVITY_CREATE)){
							action = Constants.ACTIVITY_CREATE;
						}else{
							action = Constants.ACTIVITY_MODIFY;
						}
					}else{
						action = Constants.ACTIVITY_MODIFY;
					}
					String appendingMsg = "";
					recentActivity.setActivityTimestamp(new Timestamp(Calendar.getInstance().getTimeInMillis()));
					AssetDef asset = assetDao.getAssetsByAssetName(recentFinal.getAssetName(), conn);
					if (asset.isVersionable() == true) {
						String log = profile.getFullName() + ";" + action + ";"+ recentFinal.getAssetName() + ";"+ recentFinal.getAssetInstName() + ";"+ " Version " + recentFinal.getAssetInstanceVersionName();
						recentActivity.setDescription(log);
					} else {
						String log = profile.getFullName() + ";" + action + ";"+ recentFinal.getAssetName() + ";"+ recentFinal.getAssetInstName() + ";"+ appendingMsg;
						recentActivity.setDescription(log);
					}
					recentActivity.setUser_id(profile.getUserId());
					recentActivity.setAssetId(asset.getAssetId().toString());
					recentActivity.setAssetInstVersionId(recentFinal.getAssetInstVersionId().toString());
					recentActivityDao.addRecentActivity(recentActivity, conn);
				}
			}
			if(errorsOnProc.isEmpty() && apeVoList.isEmpty()){

				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				SubscriptionDao subscriptionDao = new SubscriptionDao();

				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				String mailTemp = null;

				for (Map.Entry<String,String> entry : aivIds.entrySet()) {

					if(entry.getValue().equalsIgnoreCase("add")){
						AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(entry.getKey()), conn);
						if(aiv != null){
							List<String> emailIds=subscriptionDao.getSubscribersForAsset(aiv.getAssetId(), conn);

							if(aiv.getVersionable() == true){
								MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceVersion");
								mailTemp = mtVo1.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								//mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
								mailTemp = mailTemp.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
							}else{
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"createAssetInstanceNonVersion");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assetInstName%", instName);
								mailTemp = mailTemp.replaceAll("%assetType%", aiv.getAssetName());
							}
							if(emailIds!=null){
								for(String emailId:emailIds){
									if(aiv.getVersionable() == true) {
										SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
												MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

									}
									else {
										SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
												MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

									}
								}
							}
						}
					}else if(entry.getValue().equalsIgnoreCase("delete")){

					}else{

						AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(entry.getKey()), conn);
						if(aiv != null){
							List<String> emailIds=subscriptionDao.getAllSubscriptionsByAssetInstanceId(aiv.getAssetInstanceId(), conn);
							if(aiv.getVersionable() == true){
								MailTemplate mtVo1 = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForVersionableAsset");
								mailTemp = mtVo1.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assetInstName%",instName).replaceAll("%versionName%", aiv.getVersionName());
							}else{
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,"updateAssetInstanceForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assetInstName%", instName);

							}
							if(emailIds!=null){
								for(String emailId:emailIds){
									if(aiv.getVersionable() == true) {
										SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
												MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

									}
									else {
										SendEmail.sendTextMail(mailConfig,emailId, MessageUtil.getMessage(Constants.REPOPRO_ASSET_INSTANCE_UPDATE),
												MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));

									}
								}
							}
						}
					}
				}
				//taxonomy mail configration for subscribed users
				for (Entry<String, Map<String, String>> entry : taxIds.entrySet()) {
					Map<String, String> childMap = entry.getValue();
					String assignTax = "";
					String unassignTax = "";
					String addTax = "";
					String removedTax = "";
					List<String> emailIdsList = new ArrayList<String>();
					List<String> emailIds1List = new ArrayList<String>();
					for (Entry<String, String> entry2 : childMap.entrySet()) {
						assignTax = entry2.getKey();
						unassignTax = entry2.getValue();
					}

					//added taxonomies
					if(!assignTax.equalsIgnoreCase("")){
						String addedTaxEmail = "";
						String[] addTaxFinal = assignTax.split("~~");
						addTax = addTaxFinal[0];
						if(addTaxFinal.length == 2){
							addedTaxEmail = addTaxFinal[1];
						}
						emailIdsList = Arrays.asList(addedTaxEmail.split(","));
					}


					//unassigned taxonomies
					if(!unassignTax.equalsIgnoreCase("")){
						String[] unassignTaxFinal = unassignTax.split("~~");
						removedTax = unassignTaxFinal[0];
						String unassignTaxEmail = "";

						if(unassignTaxFinal.length == 2){
							unassignTaxEmail = unassignTaxFinal[1];
						}
						emailIds1List = Arrays.asList(unassignTaxEmail.split(","));
					}

					AssetInstanceVersion aiv = assetInstanceVersionDao.getAssetInstanceVersionDetails(Long.parseLong(entry.getKey()), conn);
					if(aiv != null){
						if (!emailIdsList.isEmpty()) {
							//HashSet<String> listToSet = new HashSet<String>(emailIdsList);
							//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);

							if (aiv.getVersionable() == true) {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"assignTaxNameForAssetInstanceForVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax)
										.replaceAll("%assetInstName%",instName).replaceAll("%versionName%", aiv.getVersionName());
							} else {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"assignTaxNameForAssetInstanceForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%assignTaxName%", addTax).replaceAll("%assetInstName%",instName);
							}

							for (String emailId : emailIdsList) {
								if (addTax != "") {
									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								}
							}
						}

						if (!emailIds1List.isEmpty()) {
							//HashSet<String> listToSet = new HashSet<String>(emailIds1List);
							//List<String> listWithoutDuplicates = new ArrayList<String>(listToSet);

							if (aiv.getVersionable() == true) {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"unassignTaxNameForAssetInstanceForVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax)
										.replaceAll("%assetInstName%", instName).replaceAll("%versionName%", aiv.getVersionName());
							} else {
								MailTemplate mtVo = mailTemplateDao.retMailTemplateByTextName(conn,
										"unassignTaxNameForAssetInstanceForNonVersionableAsset");
								mailTemp = mtVo.getMailTemplate();
								String instName = aiv.getAssetInstName();
								instName = instName.replace("\\", "\\\\").replace("$", "\\$");
								mailTemp = mailTemp.replaceAll("%unassignTaxName%", removedTax).replaceAll("%assetInstName%", instName);
							}

							for (String emailId : emailIds1List) {
								if (removedTax != "") {
									SendEmail.sendTextMail(mailConfig, emailId,
											MessageUtil.getMessage(Constants.REPOPRO_TAXONOMY_SUBSCRIPTION_UPDATE),
											MessageUtil.getMessage(Constants.EMAIL_HDR) + mailTemp + "\n"
													+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
								}
							}
						}
					}
				}


				for(Object jsondata:parameterChangefinaldata){

					JSONObject jsonObject = new JSONObject(jsondata.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result = jsonObject.getString("Notification");
								result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
								if(!result.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}

				for(Object jsondata:relatedParamChangefinaldata){

					JSONObject jsonObject = new JSONObject(jsondata.toString());

					if(jsonObject.has("Response Status")){
						String status = jsonObject.getString("Response Status");
						if(status.equalsIgnoreCase("success")){
							if(jsonObject.has("Notification")){
								String result = jsonObject.getString("Notification");
								result = result.substring(result.indexOf("[")+1, result.lastIndexOf("]"));
								if(!result.equalsIgnoreCase("\"\"")){
									JSONObject maillist = new JSONObject(result);
									if(maillist.has("Parameter changed")){
										String oldValue = maillist.getString("Old Value");
										List<String> oldValueList = new ArrayList<String>(Arrays.asList(oldValue.split("~~")));
										String newValue = 	maillist.getString("New Value");
										List<String> newValueList = new ArrayList<String>(Arrays.asList(newValue.split("~~")));
										String instanceName = maillist.getString("AssetInstanceName");
										String assetType = maillist.getString("Assetname");
										JSONArray emailArray = maillist.getJSONArray("Email Id");
										if(oldValue.equalsIgnoreCase("")){
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been assigned  "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}else{
											for(int j=0;j<emailArray.length();j++){
												SendEmail.sendTextMail(mailConfig,emailArray.getString(j),
														MessageUtil.getMessage(Constants.INSTANCE_DETAILS_MODIFIED),
														MessageUtil.getMessage(Constants.EMAIL_HDR)+ maillist.getString("Parameter changed")+" parameter details has been changed from "+oldValueList +" to "+newValueList+" in "+instanceName+" assetinstance under "+assetType +" Asset Type\n"
																+ MessageUtil.getMessage(Constants.EMAIL_NOTE));
											}
										}
									}
								}
							}
						}
					}
				}
			}
			
			//error message construction
			if(!errorsOnProc.isEmpty() || !apeVoList.isEmpty())
			{
				Set<String> hs = new HashSet<String>();
				hs.addAll(errorsOnProc);
				errorsOnProc.clear();
				errorsOnProc.addAll(hs);
				for(int i=0;i<errorsOnProc.size();i++)
				{
					errStr.append(errorsOnProc.get(i)+"\n");
				}

				for(int i=0;i<apeVoList.size();i++)
				{
					if(apeVoList.get(i).getFileExist() != null)
					{
						if(apeVoList.get(i).getFileExist().equalsIgnoreCase("Not Found"))
						{
							if(apeVoList.get(i).isVersionable()){
								if (log.isErrorEnabled()) {
									log.error(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
							else{
								if (log.isErrorEnabled()) {
									log.error(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append(apeVoList.get(i).getParamValue() +" file not found for "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
						}
					}
					else
					{
						if(apeVoList.get(i).getErrorMessage() == null){
							if(apeVoList.get(i).isVersionable())
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
							else
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+"\n");
							}
						}else{
							if(apeVoList.get(i).isVersionable())
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+"_"+apeVoList.get(i).getVersionName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
							}
							else
							{
								if (log.isErrorEnabled()) {
									log.error("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
								}
								errStr.append("Please Provide valid data at "+apeVoList.get(i).getParamName()+" under "+apeVoList.get(i).getCatName()+" for asset instance "+apeVoList.get(i).getAssetInstName()+" for "+apeVoList.get(i).getAssetType()+" since "+apeVoList.get(i).getErrorMessage()+"\n");
							}
						}
					}
				}
			}
			log.debug("Asset Atotribute and Asset Relationship Error Handling done"+apeVoList.toString());
		}catch(Exception e) {
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
		if (log.isTraceEnabled()) {
			log.trace("fullImportDBupdation ||end");
		}
	}
}
