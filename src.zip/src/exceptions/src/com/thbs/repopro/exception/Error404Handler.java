package com.thbs.repopro.exception;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

public class Error404Handler extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Method to handle GET method request.
	   public void doGet(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException 
	   {
		   //System.out.println(request.getHeader("Accept"));
		   String acceptType = request.getHeader("Accept");
		   if(acceptType.equalsIgnoreCase("*/*") || acceptType.equalsIgnoreCase("application/json"))
		   {
		    response.setContentType("application/json; charset=UTF-8");
		    response.setStatus(HttpServletResponse.SC_NOT_FOUND);
	        PrintWriter printout = response.getWriter();

	        JSONObject JObject = new JSONObject(); 
	        JObject.put("message", "Resource not found!"); 
	        JObject.put("status", "NOT_FOUND"); 
	        JObject.put("statusCode", "404"); 
            printout.print(JObject);
	        printout.flush();
	   }
		   else
		   {
			   response.sendRedirect("404.html");  
		   }
		   
	   }
	   
	// Method to handle POST method request.
	   public void doPost(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException {

	      doGet(request, response);
	   }
}
