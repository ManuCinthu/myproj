package com.thbs.repopro.exception;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

public class Error405Handler extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Method to handle GET method request.
	   public void doGet(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException 
	   {
		   //System.out.println(request.getHeader("Accept"));
		   String acceptType = request.getHeader("Accept");
		   if(acceptType.equalsIgnoreCase("*/*") || acceptType.equalsIgnoreCase("application/json"))
		   {
		    response.setContentType("application/json; charset=UTF-8");
		    response.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
	        PrintWriter printout = response.getWriter();

	        JSONObject JObject = new JSONObject(); 
	        JObject.put("message", "Method not allowed!"); 
	        JObject.put("status", "METHOD_NOT_ALLOWED"); 
	        JObject.put("statusCode", "405"); 
            printout.print(JObject);
	        printout.flush();
	   }
		  
		   
	   }
	   
	// Method to handle POST method request.
	   public void doPost(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException {

	      doGet(request, response);
	   }
}
