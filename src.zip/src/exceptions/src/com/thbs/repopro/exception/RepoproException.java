package com.thbs.repopro.exception;

/**
 * @author THBS
 *
 */
public class RepoproException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param message
	 */
	public RepoproException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
	/**
	 * @param throwable
	 */
	public RepoproException(Throwable throwable) {
		// TODO Auto-generated constructor stub
		super(throwable);
	}
	
	/**
	 * @param throwable
	 * @param message
	 */
	public RepoproException(Throwable throwable, String message) {
		// TODO Auto-generated constructor stub
		super(message, throwable);
	}

}
