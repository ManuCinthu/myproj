package com.thbs.repopro.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.MyModel;

/**
 * @author THBS
 *
 */
@Provider
public class RepoproExceptionMapper implements
		ExceptionMapper<RepoproException> {

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.ws.rs.ext.ExceptionMapper#toResponse(java.lang.Throwable)
	 */
	@Override
	public Response toResponse(RepoproException noContentException) {
		MyModel errorMessage = new MyModel(Constants.GET_STATUS_FAILURE,
				Constants.FAILURE, noContentException.getMessage());
		return Response.status(Status.NOT_FOUND).entity(errorMessage).build();
	}
}
