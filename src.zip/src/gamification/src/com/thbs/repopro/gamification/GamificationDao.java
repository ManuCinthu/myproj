package com.thbs.repopro.gamification;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.RoleDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.GamificationDetails;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class GamificationDao {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : retGamificationPoints
	 * @description : get sum of points obtained by each user
	 * @param userId
	 * @param conn
	 * @return Points obtained
	 * @throws RepoproException
	 */
	public String retGamificationPoints(Long userId, Connection conn)
			throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("addGamificationPoint||UserId:" + userId + "||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		String points = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retGamificationPoints ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_GAMIFICATION_POINTS));
			preparedStmt.setLong(Constants.ONE, userId);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retGamificationPoints ||"
						+ PropertyFileReader.getInstance().getValue(Constants.RET_GAMIFICATION_POINTS));
			}

			if (rs.next()) {
				points = rs.getString("points");

			}

			if (log.isTraceEnabled()) {
				log.trace("retGamificationPoints ||" + points);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retGamificationPoints ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GAMIFICATION_POINTS_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retGamificationPoints ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retGamificationPoints ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retGamificationPoints ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("retGamificationPoints ||"
						+ Constants.LOG_CONNECTION_CLOSE);

			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("addGamificationPoint ||UserId:" + userId + "|| End");
		}

		return points;
	}

	/**
	 * @method : retGamificationDetails
	 * @description : get gamification points details
	 * @param from
	 * @param to
	 * @param conn
	 * @return success response
	 * @throws RepoproException
	 */
	public List<GamificationDetails> retGamificationDetails(int from,String userName, Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("retGamificationDetails||from:" + from + " ||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDetails gameDetails = null;
		
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetails ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			
			boolean userFlag = false;
			User user2 = userDao.retProfileForUserName(userName, conn);
			userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user2.getUserId(), conn);
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
					break;
				}
			}
			
			if(userName.equalsIgnoreCase("admin")) {
				userFlag = true;
			}
			
			if(userFlag) {
				preparedStmt = conn.prepareStatement(PropertyFileReader.getInstance()
								.getValue(Constants.RET_GAMIFICATION_DETAILS_FOR_LOGGED_IN_USER));
				
				preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
				preparedStmt.setLong(Constants.TWO, from);
			}else {
				preparedStmt = conn
						.prepareStatement(PropertyFileReader.getInstance()
								.getValue(Constants.RET_GAMIFICATION_DETAILS));
				
				preparedStmt.setString(Constants.ONE, userName);
				preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
				preparedStmt.setLong(Constants.SEVEN, from);
			}
			
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetails ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_GAMIFICATION_DETAILS));
			}

			while (rs.next()) {
				gameDetails = new GamificationDetails();
				gameDetails.setActivityTimestamp(rs.getString("activity_timestamp"));
				gameDetails.setUserId(rs.getLong("user_id"));
				gameDetails.setAction(rs.getString("action"));
				gameDetails.setField(rs.getString("field"));
				gameDetails.setAssetId(rs.getString("asset_id"));
				gameDetails.setAssetInstanceVersionId(rs.getString("asset_instance_version_id"));
				gameDetails.setPoints(rs.getString("points"));
				gameDetails.setInstanceDetails(rs.getString("instance_details"));
				gameDetails.setFullName(rs.getString("masked_full_name"));
				gameDetails.setImageName(rs.getString("image_name"));
				gameDetails.setEncryptImage(rs.getInt("encrypt_image"));
				
				gameDetailsList.add(gameDetails);
				if (log.isTraceEnabled()) {
					log.trace("retGamificationDetails ||"
							+ gameDetails.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retGamificationDetails ||"
						+ gameDetailsList.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retGamificationDetails ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GAMIFICATION_DETAILS_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retGamificationDetails ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retGamificationDetails ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retGamificationDetails ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetails ||"
						+ Constants.LOG_CONNECTION_CLOSE);

			}
		
		}
		if (log.isTraceEnabled()) {
			log.trace("retGamificationDetails||from:" + from + " || End");
		}

		return gameDetailsList;
	}
	
	
	/**
	 * @method : addGamificationPoint
	 * @param gamePoint
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public GamificationDetails addGamificationPoint(GamificationDetails gamePoint, Connection conn)
			throws RepoproException{
		
		if (log.isDebugEnabled()) {
			log.debug("addGamificationPoint" + gamePoint.toString() + " Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		int val = 0;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addGamificationPoint: " + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_GAMIFICATION_POINT));

			preparedStmt.setString(Constants.ONE, gamePoint.getActivityTimestamp());
			preparedStmt.setLong(Constants.TWO, gamePoint.getUserId());
			preparedStmt.setString(Constants.THREE,gamePoint.getAction());
			preparedStmt.setString(Constants.FOUR,gamePoint.getField());
			preparedStmt.setString(Constants.FIVE,gamePoint.getAssetId());
			preparedStmt.setString(Constants.SIX,gamePoint.getAssetInstanceVersionId());
			preparedStmt.setString(Constants.SEVEN,gamePoint.getPoints());
			preparedStmt.setString(Constants.EIGHT,gamePoint.getInstanceDetails());

			val = preparedStmt.executeUpdate();
			
			rs = preparedStmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				gamePoint.setGamificationId(rs.getLong(1));
			}

			if (log.isTraceEnabled()) {
				log.trace("addGamificationPoint:"
						+ PropertyFileReader.getInstance().getValue(
								Constants.ADD_GAMIFICATION_POINT));
			}

		}catch (SQLException e) {
			e.printStackTrace();
			log.error("addGamificationPoint ||"
					+ Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.ADD_GAMIFICATION_POINT_DETAILS_FAILED));
		} catch (IOException e) {
			log.error("addGamificationPoint ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addGamificationPoint ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addGamificationPoint ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addGamificationPoint: " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isDebugEnabled()) {

			log.debug("addGamificationPoint:" + gamePoint.toString() + " End");
		}
		
		return gamePoint;
		
	}
	
	/**
	 * @method : retGamificationDetails
	 * @description : get gamification points details
	 * @param from
	 * @param to
	 * @param conn
	 * @return success response
	 * @throws RepoproException
	 */
	public List<GamificationDetails> retGamificationDetailsExport(String userName, Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("retGamificationDetailsExport ||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDetails gameDetails = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetailsExport ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.RET_GAMIFICATION_DETAILS_EXPORT));
			
			preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
			preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
			
			rs = preparedStmt.executeQuery();
			
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetailsExport ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_GAMIFICATION_DETAILS_EXPORT));
			}

			while (rs.next()) {
				gameDetails = new GamificationDetails();
				gameDetails.setActivityTimestamp(rs.getString("activity_timestamp"));
				gameDetails.setUserId(rs.getLong("user_id"));
				gameDetails.setAction(rs.getString("action"));
				gameDetails.setField(rs.getString("field"));
				gameDetails.setAssetId(rs.getString("asset_id"));
				gameDetails.setAssetInstanceVersionId(rs.getString("asset_instance_version_id"));
				gameDetails.setPoints(rs.getString("points"));
				gameDetails.setInstanceDetails(rs.getString("instance_details"));
				gameDetails.setFullName(rs.getString("decrypted_full_name"));
				
				gameDetailsList.add(gameDetails);
				if (log.isTraceEnabled()) {
					log.trace("retGamificationDetailsExport ||" + gameDetails.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retGamificationDetailsExport ||"
						+ gameDetailsList.toString());
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retGamificationDetailsExport ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GAMIFICATION_DETAILS_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retGamificationDetailsExport ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retGamificationDetailsExport ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retGamificationDetailsExport ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetailsExport ||"
						+ Constants.LOG_CONNECTION_CLOSE);

			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("retGamificationDetailsExport || End");
		}

		return gameDetailsList;
	}
	
	/**
	 * @method : retGamificationDetailsByUserId
	 * @description : get gamification points details
	 * @param from
	 * @param userId
	 * @param conn
	 * @return success response
	 * @throws RepoproException
	 */
	public List<GamificationDetails> retGamificationDetailsByUserId(int from, Long userId , String userName, Connection conn) throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("retGamificationDetailsByUserName||from:" + from + " ||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDetails gameDetails = null;
		
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetailsByUserId ||"
						+ Constants.LOG_CONNECTION_OPEN);
			}
			
			boolean userFlag = false;
			User user2 = userDao.retProfileForUserName(userName, conn);
			userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user2.getUserId(), conn);
			for(UserFunction uf : userfunctionMappedWithRoleId){
				if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
					userFlag = true;
					break;
				}
			}
			
			if(userName.equalsIgnoreCase("admin")) {
				userFlag = true;
			}
			
			if(userFlag) {
				preparedStmt = conn
						.prepareStatement(PropertyFileReader.getInstance()
								.getValue(Constants.RET_GAMIFICATION_DETAILS_BY_USERID_FOR_LOGGED_IN_USER));
				
				preparedStmt.setString(Constants.ONE, CommonUtils.encryptionKey);
				preparedStmt.setLong(Constants.TWO, userId);
				preparedStmt.setLong(Constants.THREE, from);
				
			}else {
				preparedStmt = conn
						.prepareStatement(PropertyFileReader.getInstance()
								.getValue(Constants.RET_GAMIFICATION_DETAILS_BY_USERID));
				
				preparedStmt.setString(Constants.ONE, userName);
				preparedStmt.setString(Constants.TWO, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.THREE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
				preparedStmt.setString(Constants.SIX, CommonUtils.encryptionKey);
				preparedStmt.setLong(Constants.SEVEN, userId);
				preparedStmt.setLong(Constants.EIGHT, from);
			}
			
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetailsByUserId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.RET_GAMIFICATION_DETAILS_BY_USERID));
			}

			while (rs.next()) {
				gameDetails = new GamificationDetails();
				gameDetails.setActivityTimestamp(rs.getString("activity_timestamp"));
				gameDetails.setUserId(rs.getLong("user_id"));
				gameDetails.setAction(rs.getString("action"));
				gameDetails.setField(rs.getString("field"));
				gameDetails.setAssetId(rs.getString("asset_id"));
				gameDetails.setAssetInstanceVersionId(rs.getString("asset_instance_version_id"));
				gameDetails.setPoints(rs.getString("points"));
				gameDetails.setInstanceDetails(rs.getString("instance_details"));
				gameDetails.setImageName(rs.getString("image_name"));
				gameDetails.setFullName(rs.getString("masked_full_name"));
				gameDetails.setEncryptImage(rs.getInt("encrypt_image"));
				
				gameDetailsList.add(gameDetails);
				if (log.isTraceEnabled()) {
					log.trace("retGamificationDetailsByUserId ||"
							+ gameDetails.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retGamificationDetailsByUserId ||"
						+ gameDetailsList.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retGamificationDetailsByUserId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GAMIFICATION_DETAILS_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retGamificationDetailsByUserId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retGamificationDetailsByUserId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retGamificationDetailsByUserId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetailsByUserId ||"
						+ Constants.LOG_CONNECTION_CLOSE);

			}
		
		}
		if (log.isTraceEnabled()) {
			log.trace("retGamificationDetailsByUserId || End");
		}

		return gameDetailsList;
	}
	
	
	public List<GamificationDetails> filterGamificationDetails(String value, int from,
			String userName, Connection conn) throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("retGamificationDetails||from:" + from + " ||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDetails gameDetails = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetails ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.FILTER_GAMIFICATION_DETAILS));
			
			preparedStmt.setString(Constants.ONE, value);
			preparedStmt.setString(Constants.TWO, value);
			preparedStmt.setString(Constants.THREE, value);
			preparedStmt.setString(Constants.FOUR, value);
			preparedStmt.setString(Constants.FIVE, value);
			preparedStmt.setString(Constants.SIX, value);
			preparedStmt.setString(Constants.SEVEN, value);
			preparedStmt.setInt(Constants.EIGHT, from);
			
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetails ||" + PropertyFileReader.getInstance().getValue(
								Constants.FILTER_GAMIFICATION_DETAILS));
			}

			while (rs.next()) {
				gameDetails = new GamificationDetails();
				gameDetails.setActivityTimestamp(rs.getString("activity_timestamp"));
				gameDetails.setUserId(rs.getLong("user_id"));
				gameDetails.setAction(rs.getString("action"));
				gameDetails.setField(rs.getString("field"));
				gameDetails.setAssetId(rs.getString("asset_id"));
				gameDetails.setAssetInstanceVersionId(rs.getString("asset_instance_version_id"));
				gameDetails.setPoints(rs.getString("points"));
				gameDetails.setInstanceDetails(rs.getString("instance_details"));
				gameDetails.setFullName(rs.getString("full_name"));
				gameDetails.setImageName(rs.getString("image_name"));
				
				gameDetailsList.add(gameDetails);
				if (log.isTraceEnabled()) {
					log.trace("retGamificationDetails ||"
							+ gameDetails.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("retGamificationDetails ||"
						+ gameDetailsList.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("retGamificationDetails ||" + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(MessageUtil.getMessage(Constants.GAMIFICATION_DETAILS_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("retGamificationDetails ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retGamificationDetails ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retGamificationDetails ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetails ||" + Constants.LOG_CONNECTION_CLOSE);

			}
		}
		if (log.isTraceEnabled()) {
			log.trace("retGamificationDetails|| End");
		}
		return gameDetailsList;
	}
	
	
	public List<GamificationDetails> filterGamificationDetailsByUserId(String value, int from,
			Long userId, Connection conn) throws RepoproException{
		
		if (log.isTraceEnabled()) {
			log.trace("filterGamificationDetailsByUserId ||from:" + from + " ||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDetails gameDetails = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("filterGamificationDetailsByUserId ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn
					.prepareStatement(PropertyFileReader.getInstance()
							.getValue(Constants.FILTER_GAMIFICATION_DETAILS_BY_USERID));
			
			preparedStmt.setLong(Constants.ONE, userId);
			preparedStmt.setString(Constants.TWO, value);
			preparedStmt.setString(Constants.THREE, value);
			preparedStmt.setString(Constants.FOUR, value);
			preparedStmt.setString(Constants.FIVE, value);
			preparedStmt.setString(Constants.SIX, value);
			preparedStmt.setString(Constants.SEVEN, value);
			preparedStmt.setInt(Constants.EIGHT, from);
			
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("filterGamificationDetailsByUserId ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.FILTER_GAMIFICATION_DETAILS_BY_USERID));
			}

			while (rs.next()) {
				gameDetails = new GamificationDetails();
				gameDetails.setActivityTimestamp(rs.getString("activity_timestamp"));
				gameDetails.setUserId(rs.getLong("user_id"));
				gameDetails.setAction(rs.getString("action"));
				gameDetails.setField(rs.getString("field"));
				gameDetails.setAssetId(rs.getString("asset_id"));
				gameDetails.setAssetInstanceVersionId(rs.getString("asset_instance_version_id"));
				gameDetails.setPoints(rs.getString("points"));
				gameDetails.setInstanceDetails(rs.getString("instance_details"));
				gameDetails.setFullName(rs.getString("full_name"));
				gameDetails.setImageName(rs.getString("image_name"));
				
				gameDetailsList.add(gameDetails);
				if (log.isTraceEnabled()) {
					log.trace("filterGamificationDetailsByUserId ||" + gameDetails.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("filterGamificationDetailsByUserId ||" + gameDetailsList.toString());
			}
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("filterGamificationDetailsByUserId ||"
					+ Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.GAMIFICATION_DETAILS_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("filterGamificationDetailsByUserId ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("filterGamificationDetailsByUserId ||"
					+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("filterGamificationDetailsByUserId ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("filterGamificationDetailsByUserId ||" + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		if (log.isTraceEnabled()) {
			log.trace("retGamificationDetailsByUserId || End");
		}
		return gameDetailsList;
	}
}
