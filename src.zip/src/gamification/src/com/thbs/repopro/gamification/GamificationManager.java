package com.thbs.repopro.gamification;

import java.sql.Connection;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.GamificationDetails;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.LeaderBoardUtil;
import com.thbs.repopro.util.MyModel;

@Path("/gameDetails")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class GamificationManager {

	private final static Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : retGamificationPoints
	 * @description : calculate points obtained and assign ranks
	 * @return Response Success message
	 * @throws RepoproException
	 */
	@GET
	@Path("/pointList")
	public Response retGamificationPoints(@QueryParam("from") int from, @QueryParam("to") int to, 
			@QueryParam("userName") String userName) {
		if(log.isTraceEnabled()){
			log.trace("retGamificationPoints ||from:"+from+" Begin");
		}
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		Map<String, Integer> mapList = new LinkedHashMap<String, Integer>();
		List<GamificationDetails> gamelist = new ArrayList<GamificationDetails>();
		GamificationDetails gamepoint = new GamificationDetails();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retGamificationPoints || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
		
			Map<String, Integer> mapListdata = new LinkedHashMap<String, Integer>();
		
			mapList = LeaderBoardUtil.getLeaderBoardRank(userName);
			int i = 0;
			@SuppressWarnings("rawtypes")
			Iterator it = mapList.entrySet().iterator();
			while (it.hasNext()) {
				@SuppressWarnings("rawtypes")
				Map.Entry pair = (Map.Entry) it.next();
				if (from <= i && to >= i) {
					mapListdata.put(pair.getKey().toString(),(Integer)pair.getValue());
				}
				++i;
			}
			gamepoint.setMapPointList(mapListdata);
			gamelist.add(gamepoint);

			if (log.isDebugEnabled()) {
				log.debug("retGamificationPoints ||list of ranks along with points :"
						+ gamepoint.getMapPointList().toString()
						+ "retrieved successfully");
			}
			if (gamepoint.getMapPointList().isEmpty()) {
				retMsg = Constants.GAMIFICATION_POINTS_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.RANKS_ADDED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("SQL Exception retGamificationPoints ||" + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception retGamificationPoints ||" + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("retGamificationPoints ||"+ Constants.LOG_CONNECTION_CLOSE);
			}
		}

		log.trace("retGamificationPoints || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(gamelist))).build();
	}

	/**
	 * @method retGamificationDetails
	 * @description retrieve list of game details
	 * @param from
	 * @param to
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/pointDetails")
	public Response retGamificationDetails(@QueryParam("from") int from, @QueryParam("userName") String userName) {

		log.trace("retGamificationDetails ||from:"+from+" Begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDao gamificationDao = new GamificationDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetails || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetails || dao call of retGamificationDetails() method to retrieve Game Details list");
			}

			gameDetailsList = gamificationDao.retGamificationDetails(from,userName,conn);

			for (int i = 0; i < gameDetailsList.size(); i++) {
				String instanceData = gameDetailsList.get(i).getInstanceDetails();
				String[] splitedArray = instanceData.split("~");
				gameDetailsList.get(i).setAssetName(splitedArray[0]);
				gameDetailsList.get(i).setAssetInstanceName(splitedArray[1]);
				gameDetailsList.get(i).setAssetInstanceVersionName(splitedArray[2]);
				
				String activityTimestamp = gameDetailsList.get(i).getActivityTimestamp();
				
				DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
				LocalDateTime abc = LocalDateTime.parse(activityTimestamp, dateTimeFormatter);
				dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
				String format = abc.format(dateTimeFormatter);
				
				//String format =  new SimpleDateFormat("YYYY-MM-dd HH:mm:ss.S").format(activityTimestamp);
				//Timestamp timestamp = new Timestamp(new SimpleDateFormat("dd/MM/YYYY HH:mm").parse(format).getTime());
				gameDetailsList.get(i).setActivityTimestamp(format);
			}

			if (log.isDebugEnabled()) {
				log.debug("retGamificationDetails ||list of game details:"
						+ gameDetailsList.size() + "retrieved successfully");
			}
			if (gameDetailsList.isEmpty()) {
				retMsg = Constants.GAMIFICATION_DETAILS_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.GAMIFICATION_DETAILS_RETREIEVED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("SQL Exception retGamificationDetails ||"
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception retGamificationDetails ||"
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("retGamificationDetails ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("retGamificationDetails || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(gameDetailsList))).build();
	}
	
	/**
	 * @method retRankForSpecificUser
	 * @description to get rank for specific user
	 * @param userId
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/userRank")
	public Response retRankForSpecificUser(@QueryParam("userId") Long userId) {

		if (log.isTraceEnabled()) {
			log.trace("retRankForSpecificUser || userId:"+userId+"||begin");
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		Map<String, Integer> mapList = new LinkedHashMap<String, Integer>();
		List<GamificationDetails> gamelist = new ArrayList<GamificationDetails>();
		GamificationDetails gamepoint = new GamificationDetails();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retRankForSpecificUser || "+ Constants.LOG_CONNECTION_OPEN);
			}
		
			Map<String, Integer> mapListdata = new LinkedHashMap<String, Integer>();
			if (log.isTraceEnabled()) {
				log.trace("retRankForSpecificUser || call of getLeaderBoardRank method ");
			}
			
			UserDao userDao = new UserDao();
			User userByUserId = userDao.getUserByUserId(userId, conn);
			
			mapList = LeaderBoardUtil.getLeaderBoardRank(userByUserId.getUserName());
			
			for (Map.Entry<String, Integer> entry : mapList.entrySet()) {
				String[] gamedata = entry.getKey().split("~");
				Long gameuserid = Long.parseLong(gamedata[2]);
				if(gameuserid.equals(userId)){
					mapListdata.put(entry.getKey(),entry.getValue());
					break;
				}
			}
			gamepoint.setMapPointList(mapListdata);
			gamelist.add(gamepoint);

			if (log.isDebugEnabled()) {
				log.debug("retRankForSpecificUser || rank for specific user:"
						+ gamepoint.getMapPointList().toString()+ "retrieved successfully");
			}
			if (gamepoint.getMapPointList().isEmpty()) {
				retMsg = Constants.GAMIFICATION_POINTS_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.RANKS_FETCHED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("SQL Exception retRankForSpecificUser ||" + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception retRankForSpecificUser ||" + e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("retRankForSpecificUser ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
		}

		if (log.isTraceEnabled()) {
			log.trace("retRankForSpecificUser || userId:"+userId+"||End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(gamelist))).build();
	}

	/**
	 * @method retGamificationDetailsByUserId
	 * @description retrieve list of game details
	 * @param from
	 * @param userName
	 * @return success response
	 * @throws RepoproException
	 */
	@GET
	@Path("/gamificationDetailsByUserId")
	public Response retGamificationDetailsByUserId(@QueryParam("from") int from ,@QueryParam("userId") Long userId,
			@QueryParam("userName") String userName) {

		log.trace("retGamificationDetailsByUserId for userId  || "+userId+ " from:"+from+" Begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDao gamificationDao = new GamificationDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetailsByUserId || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetailsByUserId || dao call of retGamificationDetails() method to retrieve Game Details list");
			}

			gameDetailsList = gamificationDao.retGamificationDetailsByUserId(from,userId,userName,conn);

			for (int i = 0; i < gameDetailsList.size(); i++) {
				String instanceData = gameDetailsList.get(i).getInstanceDetails();
				String[] splitedArray = instanceData.split("~");
				gameDetailsList.get(i).setAssetName(splitedArray[0]);
				gameDetailsList.get(i).setAssetInstanceName(splitedArray[1]);
				gameDetailsList.get(i).setAssetInstanceVersionName(splitedArray[2]);
				
				String activityTimestamp = gameDetailsList.get(i).getActivityTimestamp();
				
				DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
				LocalDateTime abc = LocalDateTime.parse(activityTimestamp, dateTimeFormatter);
				dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
				String format = abc.format(dateTimeFormatter);
				
				//String format =  new SimpleDateFormat("YYYY-MM-dd HH:mm:ss.S").format(activityTimestamp);
				//Timestamp timestamp = new Timestamp(new SimpleDateFormat("dd/MM/YYYY HH:mm").parse(format).getTime());
				gameDetailsList.get(i).setActivityTimestamp(format);
			}

			if (log.isDebugEnabled()) {
				log.debug("retGamificationDetailsByUserId ||list of game details:"
						+ gameDetailsList.size() + "retrieved successfully");
			}
			if (gameDetailsList.isEmpty()) {
				retMsg = Constants.GAMIFICATION_DETAILS_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.GAMIFICATION_DETAILS_RETREIEVED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("SQL Exception retGamificationDetailsByUserId ||"
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception retGamificationDetailsByUserId ||"
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("retGamificationDetailsByUserId ||"
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("retGamificationDetailsByUserId || End");

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(gameDetailsList))).build();
	}
	
/***Wrapper function***/
	@GET
	@Path("/userRankMain")
	public Response retRankForSpecificUserMain(
			@QueryParam("userName") String userName) {
		log.trace("retRankForSpecificUserMain || Begin");
		Connection conn = null;
		Response response = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		try {
			if (log.isTraceEnabled()) {
				log.trace("retRankForSpecificUserMain || "
						+ Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			} else {
				UserDao userDao = new UserDao();
				User user = new User();
				user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;
					return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
				response = this.retRankForSpecificUser(user.getUserId());
				return response;
			}
		} catch (RepoproException e) {
			log.error("retRankForSpecificUserMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			log.error("retRankForSpecificUserMain || "
					+ Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retRankForSpecificUserMain || "
						+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("retRankForSpecificUserMain || End");
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/***Wrapper function***/
	@GET
	@Path("/retGamificationDetailsByUserNameMain")
	public Response retGamificationDetailsByUserNameMain(@QueryParam("from") int from ,
			@QueryParam("userName") String userName) {

		log.trace("retGamificationDetailsByUserNameMain for userName  || "+userName+ " from:"+from+" Begin");

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		Response response = null;
		
		UserDao userDao = new UserDao();

		try {
			if (log.isTraceEnabled()) {
				log.trace("retGamificationDetailsByUserNameMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			if (userName.equalsIgnoreCase("guest")) {
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				response = Response.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg))
						.build();
			} else {
				User user = userDao.getUserIdByUserName(userName, conn);
				if (user.getUserId() == null) {
					retStat = Status.FORBIDDEN;
					retMsg = Constants.USER_NOT_AUTHORIZED;
					retScsFlr = Constants.NOT_AUTHORIZED;
					retStatScsFlr = Constants.FORBIDDEN;

					log.trace("retGamificationDetailsByUserNameMain || End");
					return Response
							.status(retStat)
							.entity(new MyModel(retStatScsFlr, retScsFlr,
									retMsg)).build();
				}
				response = retGamificationDetailsByUserId(from, user.getUserId(), userName);
				return response;
			}
			
			
		} catch (RepoproException e) {
			log.error("SQL Exception retGamificationDetailsByUserNameMain ||"
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception retGamificationDetailsByUserNameMain ||"
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("retGamificationDetailsByUserNameMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		log.trace("retGamificationDetailsByUserNameMain || End");

		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	/**
	 * @method : filterGamificationDetails
	 * @param key
	 * @param value
	 * @param from
	 * @param userName
	 * @return
	 */
	@GET
	@Path("/filterGamificationDetails")
	public Response filterGamificationDetails(@QueryParam("value") String value, @QueryParam("from") int from,
			@QueryParam("userName") String userName){
		
		if(log.isTraceEnabled()){
			log.trace("filterGamificationDetails || value : "+ value 
					+"from:"+from+" +userName :"+userName+" ||Begin");
		}
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDao gamificationDao = new GamificationDao();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("filterGamificationDetails || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("filterGamificationDetails || dao call of filterGamificationDetails() method to retrieve Game Details list");
			}

			gameDetailsList = gamificationDao.filterGamificationDetails(value, from, userName, conn);

			for (int i = 0; i < gameDetailsList.size(); i++) {
				String instanceData = gameDetailsList.get(i).getInstanceDetails();
				String[] splitedArray = instanceData.split("~");
				gameDetailsList.get(i).setAssetName(splitedArray[0]);
				gameDetailsList.get(i).setAssetInstanceName(splitedArray[1]);
				gameDetailsList.get(i).setAssetInstanceVersionName(splitedArray[2]);
				
				String activityTimestamp = gameDetailsList.get(i).getActivityTimestamp();
				
				DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
				LocalDateTime abc = LocalDateTime.parse(activityTimestamp, dateTimeFormatter);
				dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
				String format = abc.format(dateTimeFormatter);
				
				gameDetailsList.get(i).setActivityTimestamp(format);
			}

			if (log.isDebugEnabled()) {
				log.debug("filterGamificationDetails ||list of game details:"
						+ gameDetailsList.size() + "retrieved successfully");
			}
			if (gameDetailsList.isEmpty()) {
				retMsg = Constants.GAMIFICATION_DETAILS_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.GAMIFICATION_DETAILS_RETREIEVED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("SQL Exception filterGamificationDetails ||"
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception filterGamificationDetails ||"
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("filterGamificationDetails ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("filterGamificationDetails || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(gameDetailsList))).build();
	}
	
	
	/**
	 * @method : filterGamificationDetailsByUserId
	 * @param key
	 * @param value
	 * @param from
	 * @param userName
	 * @return
	 */
	@GET
	@Path("/filterGamificationDetailsByUserId")
	public Response filterGamificationDetailsByUserId(@QueryParam("value") String value, 
			@QueryParam("from") int from, @QueryParam("userName") String userName){
		
		if(log.isTraceEnabled()){
			log.trace("filterGamificationDetailsByUserId || value : "+ value 
					+"from:"+from+" +userName :"+userName+" ||Begin");
		}
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;

		List<GamificationDetails> gameDetailsList = new ArrayList<GamificationDetails>();
		GamificationDao gamificationDao = new GamificationDao();
		UserDao userDao = new UserDao();
		User user = new User();

		try {
			if (log.isTraceEnabled()) {
				log.trace("filterGamificationDetailsByUserId || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			if (log.isTraceEnabled()) {
				log.trace("filterGamificationDetailsByUserId || dao call of filterGamificationDetailsByUserId() method to retrieve Game Details list");
			}
			
			user = userDao.getUserIdByUserName(userName, null);
			
			gameDetailsList = gamificationDao.filterGamificationDetailsByUserId(value, from, user.getUserId(), conn);

			for (int i = 0; i < gameDetailsList.size(); i++) {
				String instanceData = gameDetailsList.get(i).getInstanceDetails();
				String[] splitedArray = instanceData.split("~");
				gameDetailsList.get(i).setAssetName(splitedArray[0]);
				gameDetailsList.get(i).setAssetInstanceName(splitedArray[1]);
				gameDetailsList.get(i).setAssetInstanceVersionName(splitedArray[2]);
				
				String activityTimestamp = gameDetailsList.get(i).getActivityTimestamp();
				
				DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
				LocalDateTime abc = LocalDateTime.parse(activityTimestamp, dateTimeFormatter);
				dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
				String format = abc.format(dateTimeFormatter);
				
				gameDetailsList.get(i).setActivityTimestamp(format);
			}

			if (log.isDebugEnabled()) {
				log.debug("filterGamificationDetailsByUserId ||list of game details:"
						+ gameDetailsList.size() + "retrieved successfully");
			}
			if (gameDetailsList.isEmpty()) {
				retMsg = Constants.GAMIFICATION_DETAILS_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			} else {
				retMsg = Constants.GAMIFICATION_DETAILS_RETREIEVED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		} catch (RepoproException e) {
			log.error("SQL Exception filterGamificationDetailsByUserId ||"
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception filterGamificationDetailsByUserId ||"
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isDebugEnabled()) {
				log.debug("filterGamificationDetailsByUserId ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("filterGamificationDetailsByUserId || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(gameDetailsList))).build();
	}
}