package com.thbs.repopro.advancedsearch;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AdvancedSearch;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class AdvancedSearchDao {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	public AdvancedSearch advancedSearch(String userName, Connection conn) throws RepoproException{
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		AdvancedSearch advancedSearchs = new AdvancedSearch();
		String usecaseStr = "";
		try{
			
			if (log.isTraceEnabled()){
				log.trace("advancedSearch || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
		
		pstmt = conn.prepareStatement(PropertyFileReader
				.getInstance().getValue(Constants.GET_ADVANCED_SEARCH_DETAILS));
		
		rs = pstmt.executeQuery();
		
		List<String> strArray = new ArrayList<String>();
	    //AssetDao assetDao = new AssetDao();
		while(rs.next()){
			
			String useCase = rs.getString("usecase");
			//String[] strUseCase = useCase.split("by");
			//String StrUseCaseVal = strUseCase[1];
			//String StrUseCaseValue = StrUseCaseVal.trim();
			
			 strArray.add(useCase);
			 
			
	/*		if(StrUseCaseVal.trim().equalsIgnoreCase("API") || StrUseCaseVal.trim().equalsIgnoreCase("Datasource Name")){
				AssetParamDef apd = assetDao.getAssetParamAccess(userName,StrUseCaseValue,"Operations",conn);
				
				if(apd != null){
			         strArray.add(useCase);
				}
			  }else{
				  strArray.add(useCase);
			  }*/
			}
		advancedSearchs.setUseCaseTotalCount(strArray.size());
		usecaseStr = StringUtils.join(strArray, ',');
		advancedSearchs.setUsecase(usecaseStr);
		
		}catch(SQLException e){
			log.error("advancedSearch || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ADVANCED_SEARCH_DATA_NOT_FOUND));
			
		}catch(IOException e){
			log.error("advancedSearch || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		}catch(PropertyVetoException e){
			log.error("advancedSearch || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
		throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}
		
		catch(Exception e){
			
			log.error("advancedSearch || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
			
			
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("advancedSearch || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		
		return advancedSearchs;
		
	}

	public List<AdvancedSearch> advancedSearchByUsecase(String usecase,Connection conn) throws RepoproException {
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
       List<AdvancedSearch> advancedSearchList = null;
       AdvancedSearch advancedSearch = null;
		try{
			if (log.isTraceEnabled()){
				log.trace("advancedSearchByUsecase || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}	
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ADVANCED_SEARCH_DETAILS_BY_USECASE));
			
			pstmt.setString(Constants.ONE, usecase);
			rs = pstmt.executeQuery();
			advancedSearchList = new ArrayList<AdvancedSearch>();
			
			while(rs.next()){
				 advancedSearch = new AdvancedSearch();
				advancedSearch.setUsecase(rs.getString("usecase"));
				advancedSearch.setParameters(rs.getString("parameters"));
				advancedSearchList.add(advancedSearch);
			}
			
		}catch(SQLException e){
			
			log.error("advancedSearchByUsecase || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ADVANCED_SEARCH_BY_USECASE_DATA_NOT_FOUND));
			
		}catch(IOException e){
			
			log.error("advancedSearchByUsecase || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		}catch(PropertyVetoException e){
			log.error("advancedSearchByUsecase || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
		throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch(Exception e){
			log.error("advancedSearchByUsecase || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("advancedSearchByUsecase || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return advancedSearchList;
	
	}
	
	 public List<Object> advancedSearchByUsecaseDetails(String usecase, String parameters,String userName,Connection conn) throws RepoproException {
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		List<String> parameterValuesList = null;
		AdvancedSearch advancedSearch = new AdvancedSearch();
		List<Object> objectsList = null;
		
		try{
			if (log.isTraceEnabled()){
				log.trace("advancedSearchByUsecase || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}	
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ADVANCED_SEARCH_DETAILS_BY_USECASE));
			
			pstmt.setString(Constants.ONE, usecase);
			
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				advancedSearch.setUsecase(rs.getString("usecase"));
				advancedSearch.setQuery(rs.getString("query"));
			}
			
			String query = advancedSearch.getQuery();
			pstmt1 = conn.prepareStatement(query);
			
			/*AssetInstanceVersionDao  assetInstanceVersionDao = new AssetInstanceVersionDao();
			
			boolean roleFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName,conn);
			
			if(roleFlag == true){
				pstmt1.setString(Constants.ONE,"admin");
			}else{
				if(userName.equalsIgnoreCase("roleAnonymous")){
					pstmt1.setString(Constants.ONE,"guest");
				}else{
					pstmt1.setString(Constants.ONE,userName);
				}
			
			}*/
			
			pstmt1.setString(Constants.ONE,userName);
			
			String paramArrs[] = parameters.split("`~`");
			int paramCount = 2;
			for(String str : paramArrs) {
				String params[] = str.split("~~");
				pstmt1.setString(paramCount, params[1]);
				paramCount++;
			}
			
			//pstmt1.setString(Constants.TWO,parameterValuesList.get(1));
			
			
			rs1 = pstmt1.executeQuery();
			int columnCount = rs1.getMetaData().getColumnCount();
		     objectsList = new ArrayList<Object>();
		     int p = 0;
		     String s = null;
		     
		     while(rs1.next()){
		    	 s = new String("");
		    	 for(p=1; p<=columnCount; p++){
			    	 s = s.concat(rs1.getMetaData().getColumnLabel(p)+":~:"+rs1.getString(p) + "~~");
		    	 }
		    	 s=s.substring(0,  s.length() - 2);
		    	 objectsList.add(s);
			}
		     
		}catch(SQLException e){
			
			log.error("advancedSearchByUsecase || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ADVANCED_SEARCH_BY_USECASE_DATA_NOT_FOUND));
			
		}catch(IOException e){
			
			log.error("advancedSearchByUsecase || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
			
		}catch(PropertyVetoException e){
			log.error("advancedSearchByUsecase || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
		throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch(Exception e){
			log.error("advancedSearchByUsecase || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("advancedSearchByUsecase || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return objectsList;
	
	}
	
	public boolean advancedSearchExport(XSSFSheet mySheet,XSSFCellStyle cellHeaderStyle ,String usecase, String parameters,String userName,Connection conn) throws RepoproException {

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		AdvancedSearch advancedSearch = new AdvancedSearch();

		try{
			if (log.isTraceEnabled()){
				log.trace("advancedSearchExport || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}	

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ADVANCED_SEARCH_DETAILS_BY_USECASE));

			pstmt.setString(Constants.ONE, usecase);


			rs = pstmt.executeQuery();

			while(rs.next()){
				advancedSearch.setUsecase(rs.getString("usecase"));
				advancedSearch.setQuery(rs.getString("query"));
			}

			String query = advancedSearch.getQuery();
			pstmt1 = conn.prepareStatement(query);

			AssetInstanceVersionDao  assetInstanceVersionDao = new AssetInstanceVersionDao();

			boolean roleFlag = assetInstanceVersionDao.findAdminRightsByUserName(userName,conn);

			if(roleFlag == true){
				pstmt1.setString(Constants.ONE,"admin");
			}else{
				if(userName.equalsIgnoreCase("roleAnonymous")){
					pstmt1.setString(Constants.ONE,"guest");
				}else{
					pstmt1.setString(Constants.ONE,userName);
				}

			}

			String paramArrs[] = parameters.split("`~`");
			int paramCount = 2;
			for(String str : paramArrs) {
				String params[] = str.split("~~");
				pstmt1.setString(paramCount, params[1]);
				paramCount++;
			}

			rs1 = pstmt1.executeQuery();
			int columnCount = rs1.getMetaData().getColumnCount();
			int p = 0;
			String s = null;
			int rowNum = 0;
			XSSFRow rowa = null;

			int a = 0;
			Cell cell0 = null;
			String str1 = "";
			String finalColName = "";
			while(rs1.next()){
				if(a==0){
					rowa = mySheet.createRow(rowNum++);
					for(p=1; p<=columnCount; p++){
						s = rs1.getMetaData().getColumnLabel(p);
						
						str1 = s.replace("_", " ");
						finalColName = str1.substring(0, 1).toUpperCase() + str1.substring(1);

						XSSFCell cell0a=  rowa.createCell(p-1);
						cell0a.setCellValue(finalColName);
						cell0a.setCellStyle(cellHeaderStyle);
					}
					a++;
				}
				rowa = mySheet.createRow(rowNum++);
				for(p=1; p<=columnCount; p++){
					s = rs1.getString(p) ; 

					cell0 = rowa.createCell(p-1);
					cell0.setCellValue(s);
				}
			}

		}catch(SQLException e){

			log.error("advancedSearchExport || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ADVANCED_SEARCH_BY_USECASE_DATA_NOT_FOUND));

		}catch(IOException e){

			log.error("advancedSearchExport || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		}catch(PropertyVetoException e){
			log.error("advancedSearchExport || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch(Exception e){
			log.error("advancedSearchExport || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("advancedSearchExport || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return true;
	}
	
	/**
	 * @method advancedSearchFeature
	 * @param conn
	 * @return boolean 
	 * @throws RepoproException
	 */
	public boolean advancedSearchFeature(Connection conn) throws RepoproException{
		if (log.isTraceEnabled()) {
			log.trace("advancedSearchFeature || begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		boolean featureFlag = false;
		try{
			if (log.isTraceEnabled()){
				log.trace("advancedSearchFeature || " + Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}	
			if (log.isTraceEnabled()) {
				log.trace("advancedSearchFeature || "
						+ PropertyFileReader.getInstance().getValue(Constants.GET_ADVANCED_SEARCH_DATA));
			}
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ADVANCED_SEARCH_DATA));

			rs = pstmt.executeQuery();

			while(rs.next()){
				featureFlag = true;
			}
			
		}catch(SQLException e){

			log.error("advancedSearchFeature || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ADVANCED_SEARCH_BY_USECASE_DATA_NOT_FOUND));

		}catch(IOException e){

			log.error("advancedSearchFeature || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));

		}catch(PropertyVetoException e){
			log.error("advancedSearchFeature || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch(Exception e){
			log.error("advancedSearchFeature || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("advancedSearchFeature || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if (log.isTraceEnabled()) {
			log.trace("advancedSearchFeature || End");
		}
		return featureFlag;
	}
	

}
