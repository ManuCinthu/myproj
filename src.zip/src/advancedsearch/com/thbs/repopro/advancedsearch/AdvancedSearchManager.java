package com.thbs.repopro.advancedsearch;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.dto.AdvancedSearch;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;


@Produces({ MediaType.APPLICATION_JSON})
@Path("/customSearch")
public class AdvancedSearchManager {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	//get all use cases
	@GET
	public Response getAdvancedSearchDetails(@QueryParam("userName") String userName){
		
		
		if(log.isTraceEnabled()){
			log.trace("getAdvancedSearchDetails || Begin ");
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		AdvancedSearch  advancedSearch =  new AdvancedSearch();
		List<AdvancedSearch> advancedSearchList = new ArrayList<AdvancedSearch>();
		
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AdvancedSearchDao advancedSearchDao = new AdvancedSearchDao();
			advancedSearch = advancedSearchDao.advancedSearch(userName,conn);
			advancedSearchList.add(advancedSearch);
			
			retStat = Status.OK;
			retMsg = Constants.ADVANCED_SEARCH_RETRIEVED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
		}catch(RepoproException e){
			
			log.error("getAdvancedSearchDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}catch(Exception e){
			
			log.error("getAdvancedSearchDetails || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getAdvancedSearchDetails || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(advancedSearchList))).build();
		
	}
	//ui purpose
	@GET
	@Path("/customSearchByUsecase")
	public Response getAdvancedSearchDetailsByUsecase(@QueryParam("usecase") String usecase){
		
		if(log.isTraceEnabled()){
			log.trace("getAdvancedSearchDetailsByUsecase || Begin ");
		}

		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<AdvancedSearch> advancedSearchList = null;
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			advancedSearchList = new ArrayList<AdvancedSearch>();
			AdvancedSearchDao advancedSearchDao = new AdvancedSearchDao();
			advancedSearchList = advancedSearchDao.advancedSearchByUsecase(usecase,conn);
			
			retStat = Status.OK;
			retMsg = Constants.ADVANCED_SEARCH_BY_USECASE_RETRIEVED_SUCCESSFULLY;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
		}catch(RepoproException e){
			
			log.error("getAdvancedSearchDetailsByUsecase || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}catch(Exception e){
			
			log.error("getAdvancedSearchDetailsByUsecase || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getAdvancedSearchDetailsByUsecase || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(advancedSearchList))).build();
		
	}
	//
	@GET
	@Encoded
	@Path("/customSearchByUsecaseDetails")
	public Response getAdvancedSearchDetailsByUsecaseDetails(@QueryParam("usecase") String usecase,@QueryParam("parameters") String parameters,@QueryParam("userName") String userName){
		
		
		if(log.isTraceEnabled()){
			log.trace("getAdvancedSearchDetailsByUsecase || Begin ");
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<Object>  advancedSearchDetailsList =  new ArrayList<Object>();
		List<AdvancedSearch> advancedSearchList = null;
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			advancedSearchList = new ArrayList<AdvancedSearch>();
			AdvancedSearchDao advancedSearchDao = new AdvancedSearchDao();
			//get
			advancedSearchList = advancedSearchDao.advancedSearchByUsecase(usecase, conn);
			/*System.out.println(parameters);
			//put
			String[] paramVal = parameters.split(",");
			for(String str : paramVal) {
				for(AdvancedSearch ad : advancedSearchList) {
					String[] newStrArr = ad.getParameters().split(",");
					String newStr = newStrArr[0];
					String[] paramLeftArr = str.split("~~");
					String paramLeft = paramLeftArr[0];
					String[] dbLeftArray = newStr.split("~~");
					String dbLeft = dbLeftArray[0];
					if(paramLeft.equalsIgnoreCase(dbLeft)){
						
					}
					System.out.println(ad.getParameters());
				}
			System.out.println(str);
			}*/
			parameters = parameters.replaceAll("\\+", "%2b");
			parameters = URLDecoder.decode(parameters, "UTF-8");
			usecase = URLDecoder.decode(usecase, "UTF-8");
			userName = URLDecoder.decode(userName, "UTF-8");
			
			advancedSearchDetailsList = advancedSearchDao.advancedSearchByUsecaseDetails(usecase, parameters, userName,conn);
			conn.commit();
			
			if(advancedSearchDetailsList.isEmpty()){
				retStat = Status.OK;
				retMsg = Constants.ADVANCED_SEARCH_DETAILS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retStat = Status.OK;
				retMsg = Constants.ADVANCED_SEARCH_BY_USECASE_DETAILS_RETRIEVED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			
			
		}catch(RepoproException e){
			
			log.error("getAdvancedSearchDetailsByUsecase || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}catch(Exception e){
			
			log.error("getAdvancedSearchDetailsByUsecase || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getAdvancedSearchDetailsByUsecase || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(advancedSearchDetailsList))).build();
		
	}
	
	
	@GET
	@Path("/getAllUsecases")
	public Response getAdvancedSearchDetailsMain(@HeaderParam("token") String token){
		
		if(log.isTraceEnabled()){
			log.trace("getAdvancedSearchDetailsMain || Begin ");
		}

		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
				
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			UserDao userDao = new UserDao();
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			
			response = this.getAdvancedSearchDetails(userName);
			
			MyModel res = (MyModel) response.getEntity();
			JSONObject json = new JSONObject();
			JSONObject j1 = new JSONObject();
			List<Object> data = res.getResult();
			List<Object> finaldata = new ArrayList<Object>();
			int count = 0;
			for(int i=0;i<data.size();i++){
				j1 = new JSONObject();
				AdvancedSearch as = new AdvancedSearch();
				as = (AdvancedSearch) data.get(i);
				j1.put("useCase", as.getUsecase().split(","));
				count = as.getUseCaseTotalCount();
				finaldata.add(j1);
			}
			if(count == 0){
				retStat = Status.NOT_FOUND;
				retMsg = Constants.USECASE_NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			json.put("totalCount", count);
			json.put("result", finaldata);
	    	json.put("message", res.getMessage());
			json.put("status", res.getStatus());
			json.put("statusCode", res.getStatusCode());
			//json.put("totalCount", as.getUseCaseTotalCount());
			
			log.trace("getAdvancedSearchDetailsMain || End");
			
			return Response.status(retStat).entity(json.toString())
					.build();
			
			
		}catch(RepoproException e){
			
			log.error("getAdvancedSearchDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}catch(Exception e){
			
			log.error("getAdvancedSearchDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getAdvancedSearchDetailsMain || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	
	@GET
	@Encoded
	@Path("/getUsecaseDetails")
	public Response getAdvancedSearchDetailsByUsecaseDetailsMain(@QueryParam("usecase") String usecase,
			@QueryParam("parameters") String parameters,
			@HeaderParam("token") String token){
		
		if(usecase == null || parameters == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		try{
			usecase = URLDecoder.decode(usecase, "UTF-8");
			parameters = URLDecoder.decode(parameters, "UTF-8");
			usecase = usecase.trim();
			parameters = parameters.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(usecase.isEmpty() || parameters.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		Response response = null;
		try{
			UserDao userDao = new UserDao();
			if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AdvancedSearchDao advancedSearchDao = new AdvancedSearchDao();
			AdvancedSearch advancedSearch = advancedSearchDao.advancedSearch(userName, conn);
			
			String[] splitUseCase = advancedSearch.getUsecase().split(",");
			List<String> useCaseList = Arrays.asList(splitUseCase);
			if(!useCaseList.contains(usecase)){
				retStat = Status.NOT_FOUND;
				retMsg = Constants.USECASE_NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			parameters = URLEncoder.encode(parameters, "UTF-8");
			usecase = URLEncoder.encode(usecase, "UTF-8");
			response = this.getAdvancedSearchDetailsByUsecaseDetails(usecase,parameters,userName);
			
			MyModel res = (MyModel) response.getEntity();
			JSONObject json = new JSONObject();
			List<Object> data = res.getResult();
			
			if(res.getMessage().equals("ADVANCED_SEARCH_DETAILS_NOT_FOUND")){
				return Response
						.status(Status.NOT_FOUND)
						.entity(new MyModelRest(Constants.GET_STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.ADVANCED_SEARCH_DATA_NOT_FOUND)))
						.build();
			}
			
			json.put("result", data);
	    	json.put("message", res.getMessage());
			json.put("status", res.getStatus());
			json.put("statusCode", res.getStatusCode());
			json.put("totalCount", data.size());

			log.trace("getAdvancedSearchDetailsByUsecaseDetailsMain || End");
			
			return Response.status(retStat).entity(json.toString())
					.build();
			
			
		}catch(RepoproException e){
			
			log.error("getAdvancedSearchDetailsByUsecaseDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}catch(Exception e){
			
			log.error("getAdvancedSearchDetailsByUsecaseDetailsMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("getAdvancedSearchDetailsByUsecaseDetailsMain || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
		
	}
	
	/**
	 * @method checkForAdvanceSearchfeature
	 * @return success response
	 */
	@GET
	@Encoded
	@Path("/customSearchFeature")
	public Response checkForAdvanceSearchfeature(){
		if(log.isTraceEnabled()){
			log.trace("checkForAdvanceSearchfeature || Begin ");
		}
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<Object>  advancedSearchDetailsList =  new ArrayList<Object>();
		
		try{
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			AdvancedSearchDao advancedSearchDao = new AdvancedSearchDao();
			
			boolean featureFlag = advancedSearchDao.advancedSearchFeature(conn);
			
			advancedSearchDetailsList.add(featureFlag);
			
			if(featureFlag == false){
				retStat = Status.OK;
				retMsg = Constants.ADVANCED_SEARCH_DETAILS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else{
				retStat = Status.OK;
				retMsg = Constants.ADVANCED_SEARCH_BY_USECASE_DETAILS_RETRIEVED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
		}catch(RepoproException e){
			
			log.error("checkForAdvanceSearchfeature || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}catch(Exception e){
			
			log.error("checkForAdvanceSearchfeature || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			
		}finally{
			if (log.isTraceEnabled()) {
				log.trace("checkForAdvanceSearchfeature || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(advancedSearchDetailsList))).build();
		
	}
}
