package com.thbs.repopro.subscription;

import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.Encoded;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstVersionTaxonomy;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.GroupAssetInstVersionAccess;
import com.thbs.repopro.dto.TaxonomyMaster;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserAssetInstanceSubscription;
import com.thbs.repopro.dto.UserAssetSubscription;
import com.thbs.repopro.dto.UserTaxonomySubscription;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.taxonomies.TaxonomiesDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;

@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Path("/subscription")
public class SubscriptionManager {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	private	Map<Long, List<TaxonomyMaster>> allTaxs =  null;
	List<Long> associatedTaxId = new ArrayList<Long>();
	
	void recurse(TaxonomyMaster t){

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);
			allTaxs.put(t.getTaxonomyId(), chldrn);
			for(TaxonomyMaster i: chldrn)
				recurse(i);
		}
		catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

	}

	void  recurse1(TaxonomyMaster t){

		TaxonomiesDao taxonomyDao = new TaxonomiesDao();
		Connection conn = null;
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			List<TaxonomyMaster> chldrn = taxonomyDao.getAllTaxonomiesByParentId(t.getTaxonomyId(), conn);

			for(TaxonomyMaster a: chldrn){

				TaxonomyMaster t1 = new TaxonomyMaster();
				t1.setTaxonomyId(a.getTaxonomyId());
				t1.setTaxonomyName(a.getTaxonomyName());
				recurse1(t1);
				associatedTaxId.add(a.getTaxonomyId());
				associatedTaxId.add(t.getTaxonomyId());

			}
			associatedTaxId.add(t.getTaxonomyId());

		}catch (RepoproException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("importExcelSheet || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
	}
	
	
	/**
	 * @method : assetSubscribeUnsubscribe
	 * @param userId
	 * @param assetId
	 * @param subscriptionFlag
	 * @return
	 */
	@PUT
	@Path("/assetsubscription")
	public Response assetSubscribeUnsubscribe(@QueryParam("userId") Long userId, 
			@QueryParam("assetId") Long assetId, @QueryParam("subscriptionFlag") String subscriptionFlag){
		
		if(log.isTraceEnabled()){
			log.trace("assetSubscribeUnsubscribe || Begin with userId : "+ userId 
					+"\t userId : "+userId +"\t subscriptionFlag "+ subscriptionFlag);
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		List<UserAssetSubscription> userAssetSubscriptionList = new ArrayList<UserAssetSubscription>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("assetSubscribeUnsubscribe || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			SubscriptionDao dao = new SubscriptionDao();
			
			UserAssetSubscription userAssetSubscription = new UserAssetSubscription();
			userAssetSubscription.setUserId(userId);
			userAssetSubscription.setAssetId(assetId);
			
			if(subscriptionFlag.equalsIgnoreCase(Constants.UNSUBSCRIBE)){
				if (log.isTraceEnabled()) {
					log.trace("assetSubscribeUnsubscribe || dao method called : assetUnsubscription()");
				}
				dao.assetUnsubscription(userAssetSubscription, conn);
				
				conn.commit();
				
				retMsg = Constants.UNSUBSCRIBED_FROM_ASSET;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			}else if(subscriptionFlag.equalsIgnoreCase(Constants.SUBSCRIBE)){
				if (log.isTraceEnabled()) {
					log.trace("assetSubscribeUnsubscribe || dao method called : assetSubscription()");
				}
				UserAssetSubscription assetSubscription = dao.assetSubscription(userAssetSubscription, conn);
				Long subscriptionId = assetSubscription.getSubscriptionId();
				
				userAssetSubscription.setSubscriptionId(subscriptionId);
				userAssetSubscriptionList.add(userAssetSubscription);
				
				conn.commit();
				
				retMsg = Constants.SUBSCRIBED_TO_ASSET;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}
			
			
		} catch(RepoproException e){
			log.error("assetSubscribeUnsubscribe || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}

		} catch(Exception e){
			log.error("assetSubscribeUnsubscribe || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("assetSubscribeUnsubscribe || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("assetSubscribeUnsubscribe || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, 
						new ArrayList<Object>(userAssetSubscriptionList)))
				.build();
	}
	
	/**
	 * @method : assetInstanceSubscribeUnsubscribe
	 * @param userId
	 * @param assetInstanceId
	 * @param subscriptionFlag
	 * @return
	 */
	@PUT
	@Path("/assetinstancesubscription")
	public Response assetInstanceSubscribeUnsubscribe(@QueryParam("userId") Long userId, 
			@QueryParam("assetInstanceId") Long assetInstanceId,
			@QueryParam("subscriptionFlag") String subscriptionFlag){
		
		if(log.isTraceEnabled()){
			log.trace("assetInstanceSubscribeUnsubscribe || Begin with userId : "+ userId 
					+"\t assetInstanceId : "+assetInstanceId +"\t subscriptionFlag "+ subscriptionFlag);
		}
		
		Connection conn = null;
		
		List<UserAssetInstanceSubscription> userAssetInstanceSubscriptionList = 
				new ArrayList<UserAssetInstanceSubscription>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("assetInstanceSubscribeUnsubscribe || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			SubscriptionDao dao = new SubscriptionDao();
			
			UserAssetInstanceSubscription userAssetInstanceSubscription = new UserAssetInstanceSubscription();
			
			userAssetInstanceSubscription.setUserId(userId);
			userAssetInstanceSubscription.setAssetInstanceId(assetInstanceId);
			
			if(subscriptionFlag.equalsIgnoreCase(Constants.UNSUBSCRIBE)){
				if (log.isTraceEnabled()) {
					log.trace("assetInstanceSubscribeUnsubscribe || dao method called : assetInstanceUnsubscription()");
				}
				dao.assetInstanceUnsubscription(userAssetInstanceSubscription, conn);
				
				conn.commit();
				
				retMsg = Constants.UNSUBSCRIBED_FROM_ASSET_INSTANCE;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			}else if(subscriptionFlag.equalsIgnoreCase(Constants.SUBSCRIBE)){
				if (log.isTraceEnabled()) {
					log.trace("assetInstanceSubscribeUnsubscribe || dao method called : assetInstanceSubscription()");
				}
				UserAssetInstanceSubscription assetInstanceSubscription = 
						dao.assetInstanceSubscription(userAssetInstanceSubscription, conn);
				Long subscriptionId = assetInstanceSubscription.getSubscriptionId();
				
				userAssetInstanceSubscription.setSubscriptionId(subscriptionId);
				userAssetInstanceSubscriptionList.add(userAssetInstanceSubscription);
				
				conn.commit();
				
				retMsg = Constants.SUBSCRIBED_TO_ASSET_INSTANCE;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}
			
			
		} catch(RepoproException e){
			log.error("assetInstanceSubscribeUnsubscribe || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch(Exception e){
			log.error("assetInstanceSubscribeUnsubscribe || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("assetInstanceSubscribeUnsubscribe || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("assetInstanceSubscribeUnsubscribe || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, 
						new ArrayList<Object>(userAssetInstanceSubscriptionList)))
				.build();
	}
	
	/**
	 * @method : taxonomySubscribeUnsubscribe
	 * @param userId
	 * @param taxonomyId
	 * @param subscriptionFlag
	 * @return
	 */
	@PUT
	@Path("/taxonomysubscription")
	public Response taxonomySubscribeUnsubscribe(@QueryParam("userId") Long userId, 
			@QueryParam("taxonomyId") Long taxonomyId,
			@QueryParam("subscriptionFlag") String subscriptionFlag){
		
		if(log.isTraceEnabled()){
			log.trace("taxonomySubscribeUnsubscribe || Begin with userId : "+ userId 
					+"\t taxonomyId : "+ taxonomyId +"\t subscriptionFlag "+ subscriptionFlag);
		}
		
		Connection conn = null;
		
		List<UserTaxonomySubscription> taxonomySubscriptionList = new ArrayList<UserTaxonomySubscription>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("taxonomySubscribeUnsubscribe || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			SubscriptionDao dao = new SubscriptionDao();
			
			UserTaxonomySubscription uts = new UserTaxonomySubscription();
			uts.setTaxonomyId(taxonomyId);
			uts.setUserId(userId);
			
			if(subscriptionFlag.equalsIgnoreCase(Constants.UNSUBSCRIBE)){
				if (log.isTraceEnabled()) {
					log.trace("taxonomySubscribeUnsubscribe || dao method called : taxonomyUnsubscription()");
				}
				dao.taxonomyUnsubscription(uts, conn);
				
				conn.commit();
				
				retMsg = Constants.UNSUBSCRIBED_FROM_TAXONOMY;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			}else if(subscriptionFlag.equalsIgnoreCase(Constants.SUBSCRIBE)){
				if (log.isTraceEnabled()) {
					log.trace("taxonomySubscribeUnsubscribe || dao method called : taxonomySubscription()");
				}
				UserTaxonomySubscription taxonomySubscription = dao.taxonomySubscription(uts, conn);
				
				Long newTaxonomyId = taxonomySubscription.getUserTaxonomySubscriptionId();
				
				uts.setUserTaxonomySubscriptionId(newTaxonomyId);
				taxonomySubscriptionList.add(uts);
				
				conn.commit();
				
				retMsg = Constants.SUBSCRIBED_TO_TAXONOMY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}
			
			
		} catch(RepoproException e){
			log.error("taxonomySubscribeUnsubscribe || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} catch(Exception e){
			log.error("taxonomySubscribeUnsubscribe || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
			}
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("assetSubscriptionUnsubscription || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()){
			log.trace("taxonomySubscribeUnsubscribe || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, 
						new ArrayList<Object>(taxonomySubscriptionList)))
				.build();
	}
	
	
	/***Wrapper function***/
	@PUT
	@Encoded
	@Path("/asset")
	public Response assetSubscribeUnsubscribeMain(
			@QueryParam("assetName") String assetName, @QueryParam("subscriptionFlag") String subscriptionFlag,
			@HeaderParam("token") String token){
		
		if(assetName == null || subscriptionFlag == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		try{
			assetName = URLDecoder.decode(assetName,"UTF-8");
			assetName = assetName.trim();
			subscriptionFlag = URLDecoder.decode(subscriptionFlag, "UTF-8");
			subscriptionFlag = subscriptionFlag.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(assetName.isEmpty() || subscriptionFlag.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
				
		if(log.isTraceEnabled()){
			log.trace("assetSubscribeUnsubscribeMain || Begin with assetName : "+assetName +"\t subscriptionFlag "+ subscriptionFlag);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		assetName = assetName.trim();
		subscriptionFlag = subscriptionFlag.trim();
		SubscriptionDao subscriptionDao = new SubscriptionDao();
		List<UserAssetSubscription> userAssetSubscriptionList = new ArrayList<UserAssetSubscription>();
		Response response = null;
		
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (log.isTraceEnabled()){
				log.trace("assetSubscribeUnsubscribeMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			
			AssetDao assetDao =new AssetDao();
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("assetSubscribeUnsubscribeMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			User user = new User();
			user = userDao.getUserIdByUserName(userName, null);
			if (user.getUserId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("assetSubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			AssetDef ad = new AssetDef();
			ad = assetDao.getAssetsByAssetName(assetName, null);
			if (ad.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("assetSubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			if(!subscriptionFlag.equalsIgnoreCase(Constants.SUBSCRIBE) && !subscriptionFlag.equalsIgnoreCase(Constants.UNSUBSCRIBE)){
				 return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
			
			List<String> assetSubscriptions = subscriptionDao.getAllSubscriptionsByUserAsset(ad.getAssetId(), user.getUserId(), null);
			
			if(!assetSubscriptions.isEmpty() && subscriptionFlag.equalsIgnoreCase(Constants.SUBSCRIBE)){
								
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ALREADY_SUBSCRIBED;
				retStatScsFlr = Constants.STATUS_FAILURE;
				log.trace("assetSubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				
			}
			if(assetSubscriptions.isEmpty() && subscriptionFlag.equalsIgnoreCase(Constants.UNSUBSCRIBE)){
				
				retStat = Status.BAD_REQUEST;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ALREADY_UNSUBSCRIBED;
				retStatScsFlr = Constants.STATUS_FAILURE;
				log.trace("assetSubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			response = this.assetSubscribeUnsubscribe(user.getUserId(), ad.getAssetId(), subscriptionFlag);
			MyModel res = (MyModel) response.getEntity();				
			JSONObject json = new JSONObject();
			
			json.put("message", res.getMessage());
			json.put("status", res.getStatus());
			json.put("statusCode", res.getStatusCode());
			log.trace("assetSubscribeUnsubscribeMain || End");
			
			return Response.status(retStat).entity(json.toString())
					.build();
			
		} catch(RepoproException e){
			log.error("assetSubscribeUnsubscribeMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			

		} catch(Exception e){
			log.error("assetSubscribeUnsubscribeMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("assetSubscribeUnsubscribeMain || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if(log.isTraceEnabled()){
			log.trace("assetSubscribeUnsubscribeMain || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg))
				.build();
	}
	
	/***Wrapper function***/
	@PUT
	@Encoded
	@Path("/assetInstance")
	public Response assetInstanceSubscribeUnsubscribeMain(
			@QueryParam("assetName") String assetName, @QueryParam("assetInstanceName") String assetInstName,
			@QueryParam("subscriptionFlag") String subscriptionFlag,
			@HeaderParam("token") String token){
		
		if(assetName == null || assetInstName == null ||subscriptionFlag == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		try{
			assetName = URLDecoder.decode(assetName, "UTF-8");
			assetName = assetName.trim();
			assetInstName = URLDecoder.decode(assetInstName, "UTF-8");
			assetInstName = assetInstName.trim();
			subscriptionFlag = URLDecoder.decode(subscriptionFlag, "UTF-8");
			subscriptionFlag = subscriptionFlag.trim();
		}catch(Exception e){
			e.printStackTrace();
		}
		if(assetName.isEmpty() || assetInstName.isEmpty() || subscriptionFlag.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		if(log.isTraceEnabled()){
			log.trace("assetInstanceSubscribeUnsubscribeMain || Begin with assetName : "+assetName +"\t subscriptionFlag "+ subscriptionFlag);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		Response response = null;
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		assetName = assetName.trim();
		assetInstName = assetInstName.trim();
		subscriptionFlag = subscriptionFlag.trim();
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (log.isTraceEnabled()){
				log.trace("assetInstanceSubscribeUnsubscribeMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			AssetDao assetDao = new AssetDao();
			SubscriptionDao subscriptionDao = new SubscriptionDao();
			AssetInstanceVersionDao assetInstanceVersionDao = new AssetInstanceVersionDao();
			AssetInstanceDao assetInstDao =new AssetInstanceDao();
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("assetInstanceSubscribeUnsubscribeMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			User user = new User();
			user = userDao.getUserIdByUserName(userName, null);
			if (user.getUserId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("assetInstanceSubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			AssetDef ad = new AssetDef();
			ad = assetDao.getAssetsByAssetName(assetName, null);
			if (ad.getAssetId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("assetInstanceSubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			Long assetInstId = assetInstDao.getAssetInstIdByName(assetInstName,ad.getAssetId(), null);
			if (assetInstId == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.ASSET_INSTANCE_DATA_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("assetInstanceSubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			if(!subscriptionFlag.equalsIgnoreCase(Constants.SUBSCRIBE) && !subscriptionFlag.equalsIgnoreCase(Constants.UNSUBSCRIBE)){
				 return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
			
			Boolean viewFlag = false;
			List<GroupAssetInstVersionAccess> groupAssetInstVersionAccessList = new ArrayList<GroupAssetInstVersionAccess>();
			List<AssetInstanceVersion> assetInstanceVersions = assetInstanceVersionDao.getAssetInstanceVersions(assetInstId, null);
			
			for(AssetInstanceVersion aiv : assetInstanceVersions){
				Long aivId = aiv.getAssetInstVersionId();
				groupAssetInstVersionAccessList = assetInstanceVersionDao.retAivAccessRights(aivId, userName, null);

				for (int i = 0; i < groupAssetInstVersionAccessList.size(); i++) {
					if (groupAssetInstVersionAccessList.get(i).getViewAccess().equals(1L)) {
						viewFlag = true;
						break;
					}
				}
			}
			if(viewFlag){
				UserAssetInstanceSubscription assetInstanceSubscription = subscriptionDao.getAllSubscriptionsByAssetInstance(assetInstId, user.getUserId(), null);
				if(assetInstanceSubscription.getSubscriptionFlag().equalsIgnoreCase("subscribed") && subscriptionFlag.equalsIgnoreCase(Constants.SUBSCRIBE)){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ALREADY_SUBSCRIBED;
					retStatScsFlr = Constants.STATUS_FAILURE;
					log.trace("assetSubscribeUnsubscribeMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				if(assetInstanceSubscription.getSubscriptionFlag().equalsIgnoreCase("unsubscribed") && subscriptionFlag.equalsIgnoreCase(Constants.UNSUBSCRIBE)){
					retStat = Status.BAD_REQUEST;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ALREADY_UNSUBSCRIBED;
					retStatScsFlr = Constants.STATUS_FAILURE;
					log.trace("assetSubscribeUnsubscribeMain || End");
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				
				response = this.assetInstanceSubscribeUnsubscribe(user.getUserId(), assetInstId, subscriptionFlag);
				MyModel res = (MyModel) response.getEntity();				
				JSONObject json = new JSONObject();
				
				json.put("message", res.getMessage());
				json.put("status", res.getStatus());
				json.put("statusCode", res.getStatusCode());
				log.trace("assetInstanceSubscribeUnsubscribeMain || End");
				
				return Response.status(retStat).entity(json.toString())
						.build();
			}else{
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
			}
			
		} catch(RepoproException e){
			log.error("assetInstanceSubscribeUnsubscribeMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
		} catch(Exception e){
			log.error("assetInstanceSubscribeUnsubscribeMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("assetInstanceSubscribeUnsubscribeMain || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if(log.isTraceEnabled()){
			log.trace("assetInstanceSubscribeUnsubscribeMain || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg))
				.build();
	}
	
	
	/***Wrapper function***/
	@PUT
	@Path("/taxonomy")
	public Response taxonomySubscribeUnsubscribeMain(@QueryParam("userName") String userName, 
			@QueryParam("taxonomyName") String taxonomyName,
			@QueryParam("subscriptionFlag") String subscriptionFlag){
		
		if(userName == null|| taxonomyName == null || subscriptionFlag == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		if(userName.isEmpty()|| taxonomyName.isEmpty() || subscriptionFlag.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		
		if(log.isTraceEnabled()){
			log.trace("taxonomySubscribeUnsubscribeMain || Begin with userName : "+ userName 
					+"\t taxonomyName : "+ taxonomyName +"\t subscriptionFlag "+ subscriptionFlag);
		}
		
		List<UserTaxonomySubscription> taxonomySubscriptionList = new ArrayList<UserTaxonomySubscription>();
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		UserDao userDao = new UserDao();
		Response response = null;
		allTaxs =  new LinkedHashMap<Long, List<TaxonomyMaster>>();
		List<AssetInstVersionTaxonomy>   assetInstassignList = new ArrayList<AssetInstVersionTaxonomy>();
		List<TaxonomyMaster> allTxs = new ArrayList<TaxonomyMaster>();
		userName = userName.trim();
		taxonomyName = taxonomyName.trim();
		subscriptionFlag = subscriptionFlag.trim();
		try {
			if (log.isTraceEnabled()){
				log.trace("taxonomySubscribeUnsubscribeMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, null);
				if(user.getUserId() == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			SubscriptionDao subscriptionDao = new SubscriptionDao();
			TaxonomiesDao taxonomiesDao = new TaxonomiesDao();
			if (userName.equalsIgnoreCase("guest")) {
				userName = "roleAnonymous";
				retStat = Status.FORBIDDEN;
				retMsg = Constants.USER_NOT_AUTHORIZED;
				retScsFlr = Constants.NOT_AUTHORIZED;
				retStatScsFlr = Constants.FORBIDDEN;
				log.trace("taxonomySubscribeUnsubscribeMain || End");
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			User user = new User();
			user = userDao.getUserIdByUserName(userName, null);
			if (user.getUserId() == null) {
				retStat = Status.NOT_FOUND;
				retScsFlr = Constants.FAILURE;
				retMsg = Constants.USER_NOT_FOUND;
				retStatScsFlr = Constants.GET_STATUS_FAILURE;
				log.trace("taxonomySubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			/*Long parentTaxonomyId = taxonomiesDao.getTaxonomyIdByName(parentTaxonomyName,null);
			
			TaxonomyMaster childTaxonomyName = taxonomiesDao.getTaxonomyNameByParentId(taxonomyName, parentTaxonomyId, null);
			
			response = this.taxonomySubscribeUnsubscribe(user.getUserId(), childTaxonomyName.getTaxonomyId(), subscriptionFlag);
			return response;*/
			

			if (log.isTraceEnabled()) {
				log.trace("taxonomySubscribeUnsubscribeMain || dao method called : getTaxonomyIdByName ");
			}
			final List<TaxonomyMaster> tmList = taxonomiesDao.getAllTaxonomiesByParentId(1L,null);
			for(TaxonomyMaster t:tmList){
				recurse(t);
			}
			allTaxs.put((long) 1, tmList);


			allTxs = taxonomiesDao.getAllTaxonomies(null);

			for(TaxonomyMaster t:allTxs)
			{
				recurse1(t); 
			}
			Set<Long> hs = new HashSet<Long>();
			hs.addAll(associatedTaxId);
			associatedTaxId.clear();
			associatedTaxId.addAll(hs);


			String[] addedTaxIds = new String[]{};
			String[] addedTaxIds1 = new String[]{};
			AssetInstVersionTaxonomy aiatVo = new AssetInstVersionTaxonomy();
			boolean TaxAssignedForAsset = false;
			/*aiatVo.setAssetName(ai.getAssetName());
			aiatVo.setAssetInstanceName(ai.getAssetInstName());
			aiatVo.setVersionName(ai.getVersionName());*/
			List<Long> idsForTaxon = new ArrayList<Long>();
			Long taxNextId = null;
			if(taxonomyName.endsWith(","))
			{
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModel(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
			else
			{
				if(taxonomyName.length() > 0 )
				{
					if(!allTxs.isEmpty())
					{
						addedTaxIds = taxonomyName.split(",");
						Boolean flag2 = true;


						for(int t =0; t< addedTaxIds.length && flag2; t++)
						{
							List<TaxonomyMaster> tmpTaxList = tmList;
							addedTaxIds1 = addedTaxIds[t].split("/");

							for(int h =0; h< addedTaxIds1.length; h++)
							{
								/*for (TaxonomyMaster tm : tax) {
									for (String taxNames : addedTaxIds1) {
										if (tm.getTaxonomyName().equalsIgnoreCase(taxNames)) {
											TaxAssignedForAsset = true;
											break;
										}
									}
								}

								if (!TaxAssignedForAsset) {
									retStat = Status.OK;
									retScsFlr = Constants.FAILURE;
									retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_ADD;
									retStatScsFlr = Constants.GET_STATUS_SUCCESS;
									return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

								}*/
								Boolean flag = false;
								
								for(TaxonomyMaster tm:tmpTaxList)
								{
									if(tm.getTaxonomyName().equalsIgnoreCase(addedTaxIds1[h].trim())){
										flag = true;
										taxNextId = tm.getTaxonomyId();
										break;
									}
								}
								if(!flag)
								{
									//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName());
									flag2 = false;
									retStat = Status.NOT_FOUND;
									retScsFlr = Constants.FAILURE;
									//retMsg = Constants.TAXONOMY_NOT_PRESENT_TO_SUBSCRIBE;
									retStatScsFlr = Constants.GET_STATUS_FAILURE;
									return Response.status(retStat).entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

								}
								else
								{
									for (Entry<Long, List<TaxonomyMaster>> entry : allTaxs.entrySet())
									{
										if(entry.getKey() ==  taxNextId)
										{ 
											tmpTaxList = entry.getValue();
										}
									}
								}
								if(h == addedTaxIds1.length-1)
								{

									Boolean fl = false;
									Boolean f2 = false;

									if(associatedTaxId.contains(taxNextId)){

									}
									else{
										f2 = true;
									}

									for(Long Id:idsForTaxon)
									{
										if(Id.equals(taxNextId))
										{
											fl = true;
											break;
										}

									}
									if(fl)
									{
										//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()); 
									}
									if(f2)
									{
										//errorsOnProc.add("Error in taxonomy for " + ai.getAssetInstName()+"_"+cell3+" of "+ai.getAssetName()+". This taxonomy "+addedTaxIds1[h].trim()+" is not associated with "+ai.getAssetName()+" asset"); 
									}
									else
									{
										idsForTaxon.add(taxNextId);
									}
								}
							}
						}
					}
					else{
						/*if (log.isErrorEnabled()) {
							log.error("No taxonomy is associated with "+ai.getAssetName()+" asset");
						}*/
						//errorsOnProc.add("No taxonomy is associated with "+ai.getAssetName()+" asset");
						retStat = Status.NOT_FOUND;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
						retStatScsFlr = Constants.GET_STATUS_FAILURE;

						log.trace("taxonomySubscribeUnsubscribeMain || End");
						return Response
								.status(retStat)
								.entity(new MyModel(retStatScsFlr,
										retScsFlr, retMsg)).build();
					}
				}

				else
				{
					idsForTaxon = Collections.<Long>emptyList();
				}
				aiatVo.setTaxonIds(idsForTaxon);
				assetInstassignList.add(aiatVo);
			}
			//for(int i=0;i<assetInstassignList.size();i++){
				//String taxonomies = null;
				//taxonomies = StringUtils.join(assetInstassignList.get(i).getTaxonIds(), ',');
				
			UserAssetInstanceSubscription taxonomySubscription = subscriptionDao.getAllSubscriptionsByTaxonomy(user.getUserId(), taxNextId, null);
			if(taxonomySubscription.getSubscriptionFlag().equalsIgnoreCase("subscribed") && subscriptionFlag.equalsIgnoreCase(Constants.SUBSCRIBE)){
				JSONObject json = new JSONObject();
				
				json.put("message", Constants.ALREADY_SUBSCRIBED);
				json.put("status", Constants.FAILURE);
				json.put("statusCode", Constants.STATUS_FAILURE);
				log.trace("taxonomySubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(json.toString())
						.build();
			}
			if(taxonomySubscription.getSubscriptionFlag().equalsIgnoreCase("unsubscribed") && subscriptionFlag.equalsIgnoreCase(Constants.UNSUBSCRIBE)){
				JSONObject json = new JSONObject();
				
				json.put("message", Constants.ALREADY_UNSUBSCRIBED);
				json.put("status", Constants.FAILURE);
				json.put("statusCode", Constants.STATUS_FAILURE);
				log.trace("assetSubscribeUnsubscribeMain || End");
				return Response.status(retStat).entity(json.toString())
						.build();
			}
			response = this.taxonomySubscribeUnsubscribe(user.getUserId(), taxNextId, subscriptionFlag);

			MyModel res = (MyModel) response.getEntity();				
			JSONObject json = new JSONObject();

			json.put("message", res.getMessage());
			json.put("status", res.getStatus());
			json.put("statusCode", res.getStatusCode());
			log.trace("taxonomySubscribeUnsubscribeMain || End");

			return Response.status(retStat).entity(json.toString())
					.build();
			//}
			/*List<Long> taxids = new ArrayList<Long>();
				for (String names : taxList) {
					Long taxonomyId = taxonomiesDao
							.getTaxonomyIdByName(names, null);
					if (taxonomyId == null) {
						retStat = Status.OK;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.TAXONOMY_DATA_NOT_FOUND;
						retStatScsFlr = Constants.GET_STATUS_SUCCESS;

						log.trace("addTaxonomyForAssetInstanceVersionMain || End");
						return Response
								.status(retStat)
								.entity(new MyModel(retStatScsFlr,
										retScsFlr, retMsg)).build();
					}
					taxids.add(taxonomyId);
				}
				String finaltaxid = StringUtils.join(taxids, ',');
			 */
			/*response = aivManager
						.addTaxonomyForAssetInstanceVersion(
								aiv.getAssetInstVersionId(),
								finaltaxid, aiv.getVersionable(),
								versionName, assetInstName);*/
			/*log.trace("addTaxonomyForAssetInstanceVersionMain || End");
				return response;*/
		
			
			
			
		} catch(RepoproException e){
			log.error("taxonomySubscribeUnsubscribeMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
		} catch(Exception e){
			log.error("taxonomySubscribeUnsubscribeMain || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
			
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("taxonomySubscribeUnsubscribeMain || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if(log.isTraceEnabled()){
			log.trace("taxonomySubscribeUnsubscribeMain || End");
		}
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr,retScsFlr, retMsg))
				.build();
	}
}
