package com.thbs.repopro.subscription;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.UserAssetInstanceSubscription;
import com.thbs.repopro.dto.UserAssetSubscription;
import com.thbs.repopro.dto.UserTaxonomySubscription;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class SubscriptionDao {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	
	/**
	 * @method : assetSubscription
	 * @param userAssetSubscription
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public UserAssetSubscription assetSubscription(UserAssetSubscription userAssetSubscription, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("assetSubscription || "+ userAssetSubscription.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("assetSubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ASSET_SUBSCRIPTION));
			
			pstmt.setLong(Constants.ONE, userAssetSubscription.getUserId());
			pstmt.setLong(Constants.TWO, userAssetSubscription.getAssetId());
			
			if (log.isTraceEnabled()) {
				log.trace("assetSubscription || "+ PropertyFileReader.getInstance().
						getValue(Constants.ASSET_SUBSCRIPTION));
			}
			
			pstmt.execute();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				userAssetSubscription.setSubscriptionId(rs.getLong(1));
			}
			
		} catch (SQLException e) {
			log.error("assetSubscription || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UNABLE_TO_SUBSCRIBE_TO_ASSET));
		} catch (IOException e) {
			log.error("assetSubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("assetSubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("assetSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("assetSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}

		if(log.isTraceEnabled()){
			log.trace("assetSubscription || End");
		}
		return userAssetSubscription;
		
	}
	
	
	/**
	 * @method : assetUnsubscription
	 * @param userAssetSubscription
	 * @param conn
	 * @throws RepoproException
	 */
	public void assetUnsubscription(UserAssetSubscription userAssetSubscription, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("assetUnsubscription || "+ userAssetSubscription.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("assetUnsubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ASSET_UNSUBSCRIPTION));
			
			pstmt.setLong(Constants.ONE, userAssetSubscription.getUserId());
			pstmt.setLong(Constants.TWO, userAssetSubscription.getAssetId());
			
			if (log.isTraceEnabled()) {
				log.trace("assetUnsubscription || "+ PropertyFileReader.getInstance().
						getValue(Constants.ASSET_UNSUBSCRIPTION));
			}
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("assetUnsubscription || " + Constants.LOG_DELETE_SQLEXCEPTION+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UNABLE_TO_UNSUBSCRIBE_FROM_ASSET));
		} catch (IOException e) {
			log.error("assetUnsubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("assetUnsubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("assetUnsubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("assetUnsubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("assetUnsubscription || End");
		}
		
	}
	
	
	/**
	 * @method : assetInstanceSubscription
	 * @param userAssetInstanceSubscription
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public UserAssetInstanceSubscription assetInstanceSubscription(UserAssetInstanceSubscription userAssetInstanceSubscription, 
			Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("assetInstanceSubscription || "+ userAssetInstanceSubscription.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("assetInstanceSubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ASSET_INSTANCE_SUBSCRIPTION));
			
			pstmt.setLong(Constants.ONE, userAssetInstanceSubscription.getUserId());
			pstmt.setLong(Constants.TWO, userAssetInstanceSubscription.getAssetInstanceId());
			
			if (log.isTraceEnabled()) {
				log.trace("assetInstanceSubscription || "+ PropertyFileReader.getInstance().
						getValue(Constants.ASSET_INSTANCE_SUBSCRIPTION));
			}
			
			pstmt.execute();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				userAssetInstanceSubscription.setSubscriptionId(rs.getLong(1));
			}
			
		} catch (SQLException e) {
			log.error("assetInstanceSubscription || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UNABLE_TO_SUBSCRIBE_TO_ASSET_INSTANCE));
		} catch (IOException e) {
			log.error("assetInstanceSubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("assetInstanceSubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("assetInstanceSubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("assetInstanceSubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}

		if(log.isTraceEnabled()){
			log.trace("assetInstanceSubscription || End");
		}
		return userAssetInstanceSubscription;
	}
	
	
	/**
	 * @method : assetInstanceUnsubscription
	 * @param uais
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public void assetInstanceUnsubscription(UserAssetInstanceSubscription uais, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("assetInstanceUnsubscription || "+ uais.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;		
		
		try {
			if (log.isTraceEnabled()){
				log.trace("assetInstanceUnsubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ASSET_INSTANCE_UNSUBSCRIPTION));
			
			pstmt.setLong(Constants.ONE, uais.getUserId());
			pstmt.setLong(Constants.TWO, uais.getAssetInstanceId());
			
			if (log.isTraceEnabled()) {
				log.trace("assetInstanceUnsubscription || "+ PropertyFileReader.getInstance().
						getValue(Constants.ASSET_INSTANCE_UNSUBSCRIPTION));
			}
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("assetInstanceUnsubscription || " + Constants.LOG_DELETE_SQLEXCEPTION+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UNABLE_TO_UNSUBSCRIBE_FROM_ASSET_INSTANCE));
		} catch (IOException e) {
			log.error("assetInstanceUnsubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("assetInstanceUnsubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("assetInstanceUnsubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("assetInstanceUnsubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("assetInstanceUnsubscription || End");
		}
		//return uais;
	}
	
	
	/**
	 * @method : taxonomySubscription
	 * @param uts
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public UserTaxonomySubscription taxonomySubscription(UserTaxonomySubscription uts, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("taxonomySubscription || "+ uts.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("taxonomySubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.TAXONOMY_SUBSCRIPTION));
			
			pstmt.setLong(Constants.ONE, uts.getUserId());
			pstmt.setLong(Constants.TWO, uts.getTaxonomyId());
			
			if (log.isTraceEnabled()) {
				log.trace("taxonomySubscription || "+ PropertyFileReader.getInstance().
						getValue(Constants.TAXONOMY_SUBSCRIPTION));
			}
			
			pstmt.execute();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				uts.setUserTaxonomySubscriptionId(rs.getLong(1));
			}
			
			
		} catch (SQLException e) {
			log.error("taxonomySubscription || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UNABLE_TO_SUBSCRIBE_TO_TAXONOMY));
		} catch (IOException e) {
			log.error("taxonomySubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("taxonomySubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("taxonomySubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("taxonomySubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}

		if(log.isTraceEnabled()){
			log.trace("taxonomySubscription || End");
		}
		return uts;
	}

	
	/**
	 * @method : taxonomyUnsubscription
	 * @param uts
	 * @param conn
	 * @throws RepoproException
	 */
	public void taxonomyUnsubscription(UserTaxonomySubscription uts, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("taxonomyUnsubscription || "+ uts.toString() +" Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("taxonomyUnsubscription || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.TAXONOMY_UNSUBSCRIPTION));
			
			pstmt.setLong(Constants.ONE, uts.getUserId());
			pstmt.setLong(Constants.TWO, uts.getTaxonomyId());
			
			if (log.isTraceEnabled()) {
				log.trace("taxonomyUnsubscription || "+ PropertyFileReader.getInstance().
						getValue(Constants.TAXONOMY_UNSUBSCRIPTION));
			}
			
			pstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			log.error("taxonomyUnsubscription || " + Constants.LOG_DELETE_SQLEXCEPTION+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.UNABLE_TO_UNSUBSCRIBE_FROM_TAXONOMY));
		} catch (IOException e) {
			log.error("taxonomyUnsubscription || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("taxonomyUnsubscription || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("taxonomyUnsubscription || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("taxonomyUnsubscription || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("taxonomyUnsubscription || End");
		}
		
	}
	
	/**
	 * @method : getAllSubscriptionsByAsset
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public UserAssetSubscription getAllSubscriptionsByAsset(Long assetId, Long userId, Connection conn) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByAsset || Begin with assetId : "+ assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		UserAssetSubscription uas = new UserAssetSubscription();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllSubscriptionsByAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_SUBSCRIPTIONS_BY_ASSET));
			
			pstmt.setLong(Constants.ONE, assetId);
			pstmt.setLong(Constants.TWO, userId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByAsset || "+ PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_SUBSCRIPTIONS_BY_ASSET));
			}
			
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				uas.setSubscriptionFlag("subscribed");
			}
			else{
				uas.setSubscriptionFlag("unsubscribed");
			}
			
			
		} catch (SQLException e) {
			log.error("getAllSubscriptionsByAsset || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllSubscriptionsByAsset || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllSubscriptionsByAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllSubscriptionsByAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByAsset || End");
		}
		return uas;
	}
	
	/**
	 * @method : getAllSubscriptionsByAssetInstance
	 * @param assetInstanceId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public UserAssetInstanceSubscription getAllSubscriptionsByAssetInstance(Long assetInstanceId, Long userId,
			Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByAssetInstance || Begin with assetId : "+ assetInstanceId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		UserAssetInstanceSubscription uais = new UserAssetInstanceSubscription();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllSubscriptionsByAssetInstance || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_SUBSCRIPTIONS_BY_ASSET_INSTANCE));
			
			pstmt.setLong(Constants.ONE, assetInstanceId);
			pstmt.setLong(Constants.TWO, userId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByAssetInstance || "+ PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_SUBSCRIPTIONS_BY_ASSET_INSTANCE));
			}
			
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				uais.setSubscriptionFlag("subscribed");
			}else{
				uais.setSubscriptionFlag("unsubscribed");
			}
			
			
		} catch (SQLException e) {
			log.error("getAllSubscriptionsByAssetInstance || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSET_INSTANCE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllSubscriptionsByAssetInstance || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllSubscriptionsByAssetInstance || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllSubscriptionsByAssetInstance || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByAssetInstance || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByAssetInstance || End");
		}
		return uais;	
	}

	/**
	 * @method getAllSubscriptionsByUserAsset
	 * @description to get the subscribed emailids
	 * @param assetId
	 * @param userId
	 * @param conn
	 * @return List<String>
	 * @throws RepoproException
	 */
	public List<String> getAllSubscriptionsByUserAsset(Long assetId, Long userId,
			Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByUserAsset || Begin with assetId : "+ assetId+" userId:"+userId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<String> emailIds = new ArrayList<String>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllSubscriptionsByUserAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_USER_ASSETS_SUBSCRIPTION));
			
			pstmt.setLong(Constants.ONE, assetId);
			pstmt.setLong(Constants.TWO, userId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByUserAsset || "+ PropertyFileReader.getInstance().
						getValue(Constants.RET_USER_ASSETS_SUBSCRIPTION));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				
				emailIds.add(rs.getString("email_id")); 
			}
			if (log.isDebugEnabled()) {
				log.trace("getAllSubscriptionsByUserAsset ||subscribed emailIds:"+emailIds.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAllSubscriptionsByUserAsset || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_ASSETS_SUBSCRIPTION_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllSubscriptionsByUserAsset || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllSubscriptionsByUserAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllSubscriptionsByUserAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByUserAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByUserAsset || End");
		}
		return emailIds;	
	}
	/**
	 * @method getAllSubscriptionsByAssetInstanceId
	 * @param assetId
	 * @param userId
	 * @param conn
	 * @return List<String>
	 * @throws RepoproException
	 */
	public List<String> getAllSubscriptionsByAssetInstanceId(Long assetInstanceId,Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByAssetInstanceId || Begin with assetInstanceId : "+ assetInstanceId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<String> emailIds = new ArrayList<String>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllSubscriptionsByAssetInstanceId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_USER_ASSET_INSTANCE_SUBSCRIPTION));
			
			pstmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			pstmt.setLong(Constants.TWO, assetInstanceId);
			
			
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByAssetInstanceId || "+ PropertyFileReader.getInstance().
						getValue(Constants.RET_USER_ASSET_INSTANCE_SUBSCRIPTION));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				emailIds.add(rs.getString("decrypted_email_id")); 
			}
			if (log.isDebugEnabled()) {
				log.trace("getAllSubscriptionsByAssetInstanceId ||subscribed emailIds:"+emailIds.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAllSubscriptionsByAssetInstanceId || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_ASSET_INSTANCE_SUBSCRIPTION_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllSubscriptionsByAssetInstanceId || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllSubscriptionsByAssetInstanceId || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllSubscriptionsByAssetInstanceId || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByAssetInstanceId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByAssetInstanceId || End");
		}
		return emailIds;	
	}
	
	/**
	 * @method : getSubscribersForAsset
	 * @param assetId
	 * @param conn
	 * @return
	 * @throws RepoproException 
	 */
	public List<String> getSubscribersForAsset(Long assetId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getSubscribersForAsset || Begin with assetId : "+ assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<String> emailIds = new ArrayList<String>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getSubscribersForAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_SUBSCRIBERS_FOR_ASSET));
			
			pstmt.setString(Constants.ONE, CommonUtils.encryptionKey);
			pstmt.setLong(Constants.TWO, assetId);
			
			
			if (log.isTraceEnabled()) {
				log.trace("getSubscribersForAsset || "+ PropertyFileReader.getInstance().
						getValue(Constants.RET_SUBSCRIBERS_FOR_ASSET));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				emailIds.add(rs.getString("decrypted_email_id")); 
			}
			
			if (log.isDebugEnabled()) {
				log.trace("getSubscribersForAsset ||subscribed emailIds:"+emailIds.toString());
			}
			
		} catch (SQLException e) {
			log.error("getSubscribersForAsset || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_ASSETS_SUBSCRIPTION_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getSubscribersForAsset || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getSubscribersForAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getSubscribersForAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getSubscribersForAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getSubscribersForAsset || End");
		}
		return emailIds;	
	}
	
	
	/**
	 * @method : getAllSubscriptionsByTaxonomy
	 * @param taxonomyId
	 * @param userId
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public UserAssetInstanceSubscription getAllSubscriptionsByTaxonomy(Long userId, Long taxonomyId,
			Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByTaxonomy || Begin with userId : "+ userId +
					"taxonomyId : "+ taxonomyId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		UserAssetInstanceSubscription uais = new UserAssetInstanceSubscription();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllSubscriptionsByTaxonomy || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_SUBSCRIPTIONS_BY_TAXONOMY));
			
			pstmt.setLong(Constants.ONE, userId);
			pstmt.setLong(Constants.TWO, taxonomyId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByTaxonomy || "+ PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_SUBSCRIPTIONS_BY_TAXONOMY));
			}
			
			rs = pstmt.executeQuery();
			
			if(rs.next()){
				uais.setSubscriptionFlag("subscribed");
			}else{
				uais.setSubscriptionFlag("unsubscribed");
			}
			
			
		} catch (SQLException e) {
			log.error("getAllSubscriptionsByTaxonomy || " + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSET_INSTANCE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllSubscriptionsByTaxonomy || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllSubscriptionsByTaxonomy || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		}catch (Exception e) {
			log.error("getAllSubscriptionsByTaxonomy || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllSubscriptionsByTaxonomy || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAllSubscriptionsByTaxonomy || End");
		}
		return uais;	
	}
}
