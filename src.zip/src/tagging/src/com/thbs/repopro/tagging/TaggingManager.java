package com.thbs.repopro.tagging;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.AssetInstanceVersion;
import com.thbs.repopro.dto.GroupAssetInstVersionAccess;
import com.thbs.repopro.dto.TaggingMaster;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;

@Path("/tagdetails")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class TaggingManager {
	private final static Logger log = LoggerFactory.getLogger("timeBased");
	TaggingDao taggingDao = new TaggingDao();

	/**
	 * @method : getAllTags
	 * @description : to get list of tags
	 * @param user_id
	 * @param assetInstanceVersionId
	 * @return Response Success message
	 * @throws RepoproException
	 */
	@GET
	public Response getAllTags(@QueryParam("assetInstanceVersionId") Long assetInstanceVersionId) {
		
		if (log.isTraceEnabled()) {
			log.trace("getAllTags ||  Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;

		TaggingMaster tagMaster = new TaggingMaster();
		List<TaggingMaster> jsonlist = new ArrayList<TaggingMaster>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllTags || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();

			tagMaster.setAssetInstanceVersionId(assetInstanceVersionId);

			if (log.isTraceEnabled()) {
				log.trace("getAllTags || dao call of getAllTags() to get list of all tag");
			}
			tagMaster = taggingDao.getAllTags(tagMaster, conn);
			jsonlist.add(tagMaster);
			
			if (tagMaster.getTagNames().isEmpty()) {
				return Response
						.status(Status.OK)
						.entity(new MyModel(Constants.GET_STATUS_SUCCESS,
								Constants.FAILURE, MessageUtil
										.getMessage(Constants.NO_TAGS_FOUND))).build();
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllTags ||" + tagMaster.getTagNames().size()
						+ " tag names retrieved successfully");
			}

			retStat = Status.OK;
			retMsg = Constants.LIST_BY_ASSET_INSTANCE_VERSION_ID;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;

		} catch (RepoproException e) {
			log.error("SQL Exception getAllTags|| " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("SQL Exception getAllTags|| " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllTags||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}

		if (log.isTraceEnabled()) {
			log.trace("getAllTags || End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(jsonlist))).build();

	}

	/**
	 * @method : addTags
	 * @description : to add list of tags
	 * @param taggingMaster
	 * @return Response Success message
	 * @throws RepoproException
	 */
	@POST
	@Path("/taglist")
	public Response addTags(TaggingMaster taggingMaster) {
		
		if (log.isTraceEnabled()) {
			log.trace("addTags || Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn = null;

		try {
			if (log.isTraceEnabled()) {
				log.trace("addTags ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			Response res =  this.addTagsHelper(taggingMaster,false,conn);
			return res;
			
		} catch (RepoproException e) {
			log.error("SQL Exception addTags ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
		} catch (Exception e) {
			log.error("SQL Exception addTags ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			
		} finally {
			if(conn != null){
			if (log.isTraceEnabled()) {
				log.trace("addTags ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		}

		if (log.isTraceEnabled()) {
			log.trace("addTags || End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();

	}

public Response addTagsHelper(TaggingMaster taggingMaster,boolean commitFlag,Connection conn)throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("addTagsHelper || Begin");
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Connection conn1 = null;

		TaggingMaster tagMaster = new TaggingMaster();
		List<TaggingMaster> jsonlist = new ArrayList<TaggingMaster>();

		try {
			if(conn == null){
			if (log.isTraceEnabled()) {
				log.trace("addTagsHelper ||" + Constants.LOG_CONNECTION_OPEN);
			}
			conn1 = DBConnection.getInstance().getConnection();
			conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addTagsHelper || dao call of addTags() method  to add list of tagNames");
			}
			
			tagMaster = taggingDao.addTags(taggingMaster, conn);
			
			jsonlist.add(tagMaster);

			if(commitFlag == false){
			conn.commit();
			}

			if (log.isDebugEnabled()) {
				log.debug("addTagsHelper ||" + jsonlist.toString()
						+ " tag data added successfully");
			}
			retMsg = Constants.TAGS_SAVED_SUCCESSFULLY;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			
		} catch (RepoproException e) {
			log.error("SQL Exception addTagsHelper ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				if(commitFlag == false){
				conn.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
				throw new RepoproException(e1.getMessage());
			}
			throw new RepoproException(e.getMessage());
		} catch (Exception e) {
			log.error("SQL Exception addTagsHelper ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			try {
				if(commitFlag == false){
				conn.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				retScsFlr = Constants.FAILURE;
				retMsg = e1.getMessage();
				throw new RepoproException(e1.getMessage());
			}
			throw new RepoproException(e.getMessage());
		} finally {
			if(conn1 != null){
			if (log.isTraceEnabled()) {
				log.trace("addTagsHelper ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			}
			if(commitFlag == false){
				if (log.isTraceEnabled()) {
					log.trace("addTagsHelper ||" + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
		}

		if (log.isTraceEnabled()) {
			log.trace("addTagsHelper || End");
		}

		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
						new ArrayList<Object>(jsonlist))).build();

	}

}
