package com.thbs.repopro.tagging;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.TaggingMaster;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class TaggingDao {
	private static final Logger log = LoggerFactory.getLogger("timeBased");

	/**
	 * @method : getAllTags
	 * @description : get list of tags with same userId and assetInstanceVersionId
	 * @param tagMaster
	 * @param conn
	 * @return TaggingMaster
	 * @throws RepoproException
	 */
	public TaggingMaster getAllTags(TaggingMaster tagMaster, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getAllTags ||userId:" + tagMaster.getUserId()
					+ ",AssetInstanceVersionId:"
					+ tagMaster.getAssetInstanceVersionId() + "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		Map<Long, String> data = new HashMap<Long, String>();

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getAllTags ||" + Constants.LOG_CONNECTION_OPEN);
			}
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_TAGS));
			preparedStmt.setLong(Constants.ONE,tagMaster.getAssetInstanceVersionId());
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getAllTags ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.GET_ALL_TAGS));
			}

			while (rs.next()) {
				data.put(rs.getLong("tag_id"), rs.getString("tag_name"));
				if (log.isTraceEnabled()) {
					log.trace("getAllTags ||" + data.toString());
				}
			}
			tagMaster.setTagNames(data);

			if (log.isDebugEnabled()) {
				log.debug("getAllRoleData ||" + tagMaster.toString());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getAllTags ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.NO_TAGS_FOUND));
		} catch (IOException e) {
			log.error("getAllTags ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllTags ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllTags ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getAllTags ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("getAllTags ||userId:" + tagMaster.getUserId()
					+ ",AssetInstanceVersionId:"
					+ tagMaster.getAssetInstanceVersionId() + "|| End");
		}

		return tagMaster;
	}

	/**
	 * @method:addTags
	 * @description:insertion of list of tags with same userId and assetInstanceVersionId
	 * @param taggingMaster
	 * @param conn
	 * @return TaggingMaster
	 * @throws RepoproException
	 */
	public TaggingMaster addTags(TaggingMaster taggingMaster, Connection conn)
			throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("addTags||" + taggingMaster.toString() + "||Begin");
		}
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		PreparedStatement preparedStmt1 = null;
		ResultSet rs = null;

		TaggingMaster tag = null;
		Map<Long, String> names = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addTags ||" + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt1 = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_TAGS_DATA));
			
			preparedStmt1.setLong(Constants.ONE, taggingMaster.getAssetInstanceVersionId());
			preparedStmt1.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("addTags ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_TAGS_DATA));
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_TAG_DATA));

			names = new HashMap<Long, String>();
			if(!taggingMaster.getTagNames().isEmpty()){
				for (String key : taggingMaster.getTagNames().values()) {

					preparedStmt.setString(Constants.ONE, key);
					preparedStmt.setLong(Constants.TWO, taggingMaster.getUserId());
					preparedStmt.setLong(Constants.THREE,taggingMaster.getAssetInstanceVersionId());
					preparedStmt.execute();

					if (log.isTraceEnabled()) {
						log.trace("addTags ||"
								+ PropertyFileReader.getInstance().getValue(Constants.ADD_TAG_DATA));
					}

					tag = new TaggingMaster();
					rs = preparedStmt.getGeneratedKeys();
					if (rs != null && rs.next()) {
						taggingMaster.setTagId(rs.getLong(1));
					}
					names.put(taggingMaster.getTagId(), key);
				}
				tag.setTagNames(names);
				tag.setUserId(taggingMaster.getUserId());
				tag.setAssetInstanceVersionId(taggingMaster.getAssetInstanceVersionId());
				if (log.isDebugEnabled()) {
					log.debug("getAllRoleData ||" + tag.toString());
				}
			}
		} catch (SQLException e) {
			log.error("addTags ||" + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INSERT_TAGS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addTags ||" + Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addTags ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addTags ||" + Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt1);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addTags ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {
			log.trace("addTags||" + taggingMaster.toString() + "||End");
		}
		return tag;
	}
	/**
	 * 
	 * @param taggingMaster
	 * @param tagName
	 * @param conn
	 * @throws RepoproException
	 */
	public int addTagsForImport(TaggingMaster taggingMaster,String tagName, Connection conn)
			throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("addTagsForImport||" + taggingMaster.toString() + "||Begin");
		}
		int count = 0;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("addTags ||" + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.ADD_TAG_DATA_FOR_IMPORT));


			preparedStmt.setString(Constants.ONE, tagName);
			preparedStmt.setLong(Constants.TWO, taggingMaster.getUserId());
			preparedStmt.setLong(Constants.THREE,taggingMaster.getAssetInstanceVersionId());
			count = preparedStmt.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("addTagsForImport ||"
						+ PropertyFileReader.getInstance().getValue(Constants.ADD_TAG_DATA_FOR_IMPORT));
			}

		} catch (SQLException e) {
			log.error("addTagsForImport ||" + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INSERT_TAGS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("addTagsForImport ||" + Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("addTagsForImport ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("addTagsForImport ||" + Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("addTagsForImport ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {
			log.trace("addTagsForImport||" + taggingMaster.toString() + "||End");
		}
		return count;
	}
	
	/**
	 * @method deleteTagsForImport
	 * @param taggingMaster
	 * @param conn
	 * @throws RepoproException
	 */
	public int deleteTagsForImport(TaggingMaster taggingMaster, Connection conn)
			throws RepoproException {
		
		if (log.isTraceEnabled()) {
			log.trace("deleteTagsForImport||" + taggingMaster.toString() + "||Begin");
		}
		int y = 0;
		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;

		TaggingMaster tag = null;
		Map<Long, String> names = null;
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("deleteTagsForImport ||" + Constants.LOG_CONNECTION_OPEN);
			}

			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.DELETE_TAGS_DATA_IMPORT));
			
			preparedStmt.setLong(Constants.ONE, taggingMaster.getTagId());
			y = preparedStmt.executeUpdate();
			if (log.isTraceEnabled()) {
				log.trace("deleteTagsForImport ||"
						+ PropertyFileReader.getInstance().getValue(
								Constants.DELETE_TAGS_DATA_IMPORT));
			}
		} catch (SQLException e) {
			log.error("deleteTagsForImport ||" + Constants.LOG_CREATE_SQLEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.INSERT_TAGS_FAILED));
		} catch (IOException e) {
			e.printStackTrace();
			log.error("deleteTagsForImport ||" + Constants.LOG_IOEXCEPTION + e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			log.error("deleteTagsForImport ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("deleteTagsForImport ||" + Constants.LOG_EXCEPTION + e.getMessage());
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteTagsForImport ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if (log.isTraceEnabled()) {
			log.trace("deleteTagsForImport||" + taggingMaster.toString() + "||End");
		}
		return y;
	}
	
	
	public TaggingMaster getTagDetailsByTagName(String assetInstVersionId, String tagName, Connection conn)
			throws RepoproException {

		if (log.isTraceEnabled()) {
			log.trace("getTagDetailsByTagName ||assetInstVersionId:" + assetInstVersionId + "tagName : " +tagName+ "|| Begin");
		}

		Connection conn1 = null;
		PreparedStatement preparedStmt = null;
		ResultSet rs = null;
		
		TaggingMaster tagMaster = null;
		
		try {
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			if (log.isTraceEnabled()) {
				log.trace("getTagDetailsByTagName ||" + Constants.LOG_CONNECTION_OPEN);
			}
			
			preparedStmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_TAG_DETAILS_BY_AIV_ID));
			
			preparedStmt.setString(Constants.ONE, assetInstVersionId);
			preparedStmt.setString(Constants.TWO, tagName);
			rs = preparedStmt.executeQuery();

			if (log.isTraceEnabled()) {
				log.trace("getTagDetailsByTagName ||" + PropertyFileReader.getInstance().getValue(
								Constants.GET_TAG_DETAILS_BY_AIV_ID));
			}

			while (rs.next()) {
				tagMaster = new TaggingMaster();
				tagMaster.setTagId(rs.getLong("tag_id"));
				tagMaster.setUserId(rs.getLong("user_id"));
				tagMaster.setAssetInstanceVersionId(rs.getLong("asset_instance_version_id"));
				if (log.isTraceEnabled()) {
					log.trace("getTagDetailsByTagName ||" + tagMaster.toString());
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("getTagDetailsByTagName ||" + Constants.LOG_GET_SQLEXCEPTION
					+ e.getMessage());
			throw new RepoproException(
					MessageUtil.getMessage(Constants.NO_TAGS_FOUND));
		} catch (IOException e) {
			log.error("getTagDetailsByTagName ||" + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getTagDetailsByTagName ||" + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil
							.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getTagDetailsByTagName ||" + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(preparedStmt);
			DBConnection.closeDbConnection(conn1);
			if (log.isTraceEnabled()) {
				log.trace("getTagDetailsByTagName ||" + Constants.LOG_CONNECTION_CLOSE);
			}
			
		}
		if (log.isTraceEnabled()) {
			log.trace("getTagDetailsByTagName || End");
		}
		return tagMaster;
	}
}
