package com.thbs.repopro.ldap;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.util.CommonUtils;;

/**
 * This class provides function for authentication of users in LDAP server.
 * 
 * @author THBS
 * 
 */
public class LDAPAuthentication {

	private static final Logger logger = LoggerFactory.getLogger(LDAPAuthentication.class);

	/**
	 * authenticateUser
	 * <h1>public boolean authenticateUser({@link String} userId, {@link String}
	 * password)</h1>
	 * <p>
	 * This method authenticates user in LDAP server.
	 * </p>
	 * 
	 * @param userId
	 *            : unique id of the user
	 * @param password
	 *            : password of the user
	 * @return true: if authenticated successfully <br/>
	 *         false: otherwise
	 * @author THBS
	 */
	public boolean authenticateUser(String userId, String password) {

		try {

			/*
			 * The properties of the LDAP server is stored in
			 * ApplicationResopurces.properties file.
			 */

			String host = CommonUtils.LdapHost;
			String port = CommonUtils.LdapPort;
			String uName = CommonUtils.LdapUserName;
			String pass = CommonUtils.LdapPassword;
			String authentication = CommonUtils.LdapAuthenticationType;
			String baseDn = CommonUtils.LdapBaseDn;
			String url = host + ":" + port;
			String ldapActiveDirectory = CommonUtils.LdapActiveDirectory;
			String ldapReferral = CommonUtils.LdapRefferal; // Referral

			String distinguishedName = "";

			Hashtable<String, Object> env1 = new Hashtable<String, Object>(11);
			env1.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");

			/* Specify host and port to use for directory service */
			env1.put(Context.PROVIDER_URL, url);
			env1.put(Context.SECURITY_AUTHENTICATION, authentication);
			if (ldapActiveDirectory.equals("true")) {
				env1.put(Context.SECURITY_PROTOCOL, "ssl");
			}
			env1.put(Context.SECURITY_PRINCIPAL, uName);
			env1.put(Context.SECURITY_CREDENTIALS, pass);
			env1.put(Context.REFERRAL, ldapReferral); // Referral
			SearchControls constraints = new SearchControls();
			constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
			String[] attrIDs = { CommonUtils.LdapLastName, CommonUtils.LdapFirstName, CommonUtils.LdapEmail,
					CommonUtils.LdapDept, CommonUtils.LdapUserId, CommonUtils.LdapRefferal };
			constraints.setReturningAttributes(attrIDs);

			LdapContext ctx = new InitialLdapContext(env1, null);

			NamingEnumeration results = ctx.search(CommonUtils.LdapBaseDn, CommonUtils.LdapUserId + "=" + userId,
					constraints);

			while (results != null && results.hasMore()) {
				SearchResult si = (SearchResult) results.next();
				System.out.println("LDAPAUTH_getNameInNamespace: " + si.getNameInNamespace());
				System.out.println("LDAPAUTH_getName: " + si.getName());
				distinguishedName = si.getNameInNamespace();
			}

			Hashtable<String, String> env = new Hashtable<String, String>();
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, url);
			env.put(Context.SECURITY_AUTHENTICATION, authentication);
			env.put(Context.REFERRAL, ldapReferral); // Referral
			if (CommonUtils.LdapKeyRequired.equals("true")) {

				System.setProperty("javax.net.ssl.trustStore", CommonUtils.LdapCertificateDetails);
				System.setProperty("javax.net.ssl.trustStorePassword", CommonUtils.LdapTrustStorePassword);
			}
			// String securityPrincipal = CommonUtils.LdapUserId+ "="+ userId+
			// ","+ baseDn;

			/*
			 * if(uName.length()==0) { env.put(Context.SECURITY_PRINCIPAL,
			 * securityPrincipal); } else { String domain[] = new
			 * String[uName.split("\\@").length]; domain = uName.split("\\@");
			 */
			env.put(Context.SECURITY_PRINCIPAL, distinguishedName);
			// }

			env.put(Context.SECURITY_CREDENTIALS, password);
			if (ldapActiveDirectory.equals("true")) {
				env.put(Context.SECURITY_PROTOCOL, "ssl");
			}
			DirContext dirContext = new InitialDirContext(env);

			return true;

		} catch (Exception e) {
			//e.printStackTrace();
			logger.info(e.getMessage());
			return false;
		}

	}

}
