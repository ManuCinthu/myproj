package com.thbs.repopro.ldap;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.PagedResultsControl;
import javax.naming.ldap.PagedResultsResponseControl;

import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;

/**
 * This utility class talks to LDAP. The major functionality is to retrieve all
 * entries from LDAP.
 * 
 * @author THBS
 * 
 */
public class LDAPUtility {
	
	
	@SuppressWarnings("unlikely-arg-type")
	public List<LDAPUser> getListOfLDAPUsers(DirContext dirContext,String uid) throws RepoproException{
		List<LDAPUser> ladpUsers = new ArrayList<LDAPUser>();
		LDAPUser ldapUser = null;
		String userName = CommonUtils.LdapUserName;
		try {
			// Perform the search
			NamingEnumeration answer = null;
			
			String host = CommonUtils.LdapHost;
			String port = CommonUtils.LdapPort;
			String searchFilter = CommonUtils.LdapSearchFilter;
			if(CommonUtils.LdapWildCardSearch.equalsIgnoreCase("true")) {
				searchFilter = searchFilter.replace("*", uid+"*");	
			}else {
				searchFilter = searchFilter.replace("*", uid);
			}
			
			//searchFilter = searchFilter.replace("*", uid+"*");
			
			String providerUrl = host+":"+port;
			SearchControls constraints = new SearchControls();
            constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
            String[] attrIDs = {CommonUtils.LdapLastName,CommonUtils.LdapFirstName,CommonUtils.LdapEmail,CommonUtils.LdapDept,CommonUtils.LdapUserId,CommonUtils.LdapRefferal};
            constraints.setReturningAttributes(attrIDs);
			ladpUsers = pagination(providerUrl,searchFilter,constraints,CommonUtils.LdapActiveDirectory,CommonUtils.LdapUserName,CommonUtils.LdapPassword,CommonUtils.LdapAuthenticationType,CommonUtils.LdapRefferal);
			

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//throw e;
			throw new RepoproException(e.getMessage());
		}
		return ladpUsers;
	}
	
	public List<LDAPUser> pagination(String providerUrl,String searchFilter,SearchControls constraints,String val,String securityPrincipal,String password,String authenticationType,String refferal)
	throws RepoproException{
		NamingEnumeration results = null;
		List<LDAPUser> ladpUsers = new ArrayList<LDAPUser>();
		LDAPUser ldapUser = null;
	Hashtable<String, Object> env = new Hashtable<String, Object>(11);
    env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");

    /* Specify host and port to use for directory service */
    env.put(Context.PROVIDER_URL, providerUrl);
	env.put(Context.SECURITY_AUTHENTICATION,authenticationType);
    if(val.equals("true"))
	{
	  env.put(Context.SECURITY_PROTOCOL, "ssl");
	}
    env.put(Context.SECURITY_PRINCIPAL, securityPrincipal);
    env.put(Context.SECURITY_CREDENTIALS, password);
    if(null != refferal && !refferal.isEmpty()){
		env.put(Context.REFERRAL, refferal);
	}

    try {
      LdapContext ctx = new InitialLdapContext(env, null);

      // Activate paged results
      int pageSize = 100;
      byte[] cookie = null;
      ctx.setRequestControls(new Control[] { new PagedResultsControl(pageSize,Control.NONCRITICAL) });
      int total;

    
    		 results = ctx.search(CommonUtils.LdapBaseDn,searchFilter, constraints);
    	
         
    	
    	  
        /* for each entry print out name + all attrs and values */
        while (results != null && results.hasMore()) {
          SearchResult si = (SearchResult) results.next();
         // System.out.println(si.getName());
         // String attrsValaues = si.getAttributes().toString();
        //  System.out.println("attrsValaues : "+attrsValaues);
  		
			

			NamingEnumeration<? extends Attribute> attributes = si
					.getAttributes().getAll();
			Attribute attribute = null;

			ldapUser = new LDAPUser();

			while (attributes.hasMore()) {

				attribute = attributes.next();
				String attributeId = attribute.getID();
				if (attributeId.equalsIgnoreCase(CommonUtils.LdapFirstName)) {
					ldapUser.setFirstName((String) attribute.get());
				}
				if (attributeId.equals(CommonUtils.LdapLastName)) {
					ldapUser.setLastName((String) attribute.get());
				}
				if (attributeId.equals(CommonUtils.LdapEmail)) {
					ldapUser.setEmail((String) attribute.get());
				}
				if (attributeId.equals(CommonUtils.LdapUserId)) {
					ldapUser.setUserId((String) attribute.get());
				}
				if (attributeId.equals(CommonUtils.LdapDept)) {
					ldapUser.setDept((String) attribute.get());
				}
			
			}

		ladpUsers.add(ldapUser);
		}
    }
       
 catch (NamingException e) {
      System.err.println("PagedSearch failed.");
      e.printStackTrace();
		throw new RepoproException(e.getMessage()+" LDAP_NAMEING_EXCEPTION");

    } catch (IOException ie) {
      System.err.println("PagedSearch failed.");
      ie.printStackTrace();
		throw new RepoproException(ie.getMessage());

    }
   // System.out.println("results : "+results.toString());
	return ladpUsers;
	
  }
}
		
