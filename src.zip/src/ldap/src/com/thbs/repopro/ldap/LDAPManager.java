package com.thbs.repopro.ldap;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.naming.directory.DirContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.LdapMapping;
import com.thbs.repopro.dto.MailConfig;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.mail.SendEmail;
import com.thbs.repopro.miscellaneous.MailTemplateDao;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;


@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Path("/ldapmanager")
public class LDAPManager {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	@GET
	@Path("/getallldapusers")
	public Response retrieveAllLdapUsers(@QueryParam("uid") String uid) {
		if(log.isTraceEnabled()){
			log.trace("retrieveAllLdapUsers || Begin with uid : "+ uid);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<LDAPUser> listOfLDAPUsers = null;
		try {
			
			LDAPConnection ldapConnection = LDAPConnection.getInstance();
			DirContext dirContext = ldapConnection.getDirContext();
			LDAPUtility ldapUtility = new LDAPUtility();
			 listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,uid);
			
			//System.out.println(listOfLDAPUsers.toString());

			if (listOfLDAPUsers.size() != 0) {
				retMsg = Constants.LDAP_DETAILS_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			} else {
				retMsg = Constants.LDAP_DETAILS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			log.debug("retrieveAllLdapUsers || retrieved "+ listOfLDAPUsers.toString());

			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			if(e.getMessage().contains("LDAP_NAMEING_EXCEPTION")){
				retMsg = Constants.LDAP_CONFIG_ERROR;
			}
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			return Response
					.status(retStat).entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();

		} catch(Exception e){
			log.error("retrieveAllLdapUsers || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} 
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(listOfLDAPUsers))).build();

	}
	
	@GET
	@Path("/getallldapusersByMappingId")
	public Response retrieveAllLdapUsersByMappingId(@QueryParam("uid") String uid,@QueryParam("assetName") String assetName,@QueryParam("paramName") String paramName) {
		if(log.isTraceEnabled()){
			log.trace("retrieveAllLdapUsersByMappingId || Begin with uid : "+ uid);
		}

		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		List<LDAPUser> listOfLDAPUsers = null;
		List<LDAPUser> listOfLDAPUsersFinal = new ArrayList<LDAPUser>();
		AssetDao assetDao = new AssetDao();
		Connection conn = null;
		try {
			if (log.isTraceEnabled()) {
				log.trace("retrieveAllLdapUsersByMappingId || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			LDAPConnection ldapConnection = LDAPConnection.getInstance();
			DirContext dirContext = ldapConnection.getDirContext();
			LDAPUtility ldapUtility = new LDAPUtility();
			listOfLDAPUsers = ldapUtility.getListOfLDAPUsers(dirContext,uid);
			
			AssetParamDef assetParamDef = assetDao.getParamIdForAssetAndParamName(assetName, paramName, conn);
			
			List<LdapMapping> ldapAttributeList = assetDao.getLdapMappingAttributeList(assetParamDef.getLdapMappingId(), conn);
			
			for(LDAPUser finaldata:listOfLDAPUsers) {
				LDAPUser ldapUser = new LDAPUser();
				for(LdapMapping attribute:ldapAttributeList){
					String attributeName = attribute.getAttributeName().substring(3);
					if(attributeName.equalsIgnoreCase(CommonUtils.LdapFirstName)) {
						ldapUser.setFirstName(finaldata.getFirstName());
						ldapUser.setFirstNameAttributeId(attribute.getLdapAttributeId());
					}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapLastName)) {
						ldapUser.setLastName(finaldata.getLastName());
						ldapUser.setLastNameAttributeId(attribute.getLdapAttributeId()); 
					}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapEmail)) {
						ldapUser.setEmail(finaldata.getEmail());
						ldapUser.setEmailAttributeId(attribute.getLdapAttributeId());
					}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapDept)) {
						ldapUser.setDept(finaldata.getDept());
						ldapUser.setDeptAttributeId(attribute.getLdapAttributeId());
					}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapUserId)) {
						ldapUser.setUserId(finaldata.getUserId());
						ldapUser.setUserIdAttributeId(attribute.getLdapAttributeId());
					}else if(attributeName.equalsIgnoreCase(CommonUtils.LdapFullName)) {
						ldapUser.setFullName(finaldata.getFirstName()+" "+finaldata.getLastName());
						ldapUser.setFullNameAttributeId(attribute.getLdapAttributeId());
					}
				}
				if(ldapUser != null) {
					listOfLDAPUsersFinal.add(ldapUser);
				}
			}

			if (listOfLDAPUsers.size() != 0) {
				retMsg = Constants.LDAP_DETAILS_FETCHED;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;

			} else {
				retMsg = Constants.LDAP_DETAILS_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			log.debug("retrieveAllLdapUsersByMappingId || retrieved "+ listOfLDAPUsers.toString());

			
		} catch (RepoproException e) {
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			if(e.getMessage().contains("LDAP_NAMEING_EXCEPTION")){
				retMsg = Constants.LDAP_CONFIG_ERROR;
			}
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
			return Response
					.status(retStat).entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();

		} catch(Exception e){
			log.error("retrieveAllLdapUsersByMappingId || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		}finally {
			if (log.isTraceEnabled()) {
				log.trace("retrieveAllLdapUsersByMappingId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		} 
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr,
						retScsFlr, retMsg,
						new ArrayList<Object>(listOfLDAPUsersFinal))).build();

	}
	
	
	@POST
	@Path("/addUserFromLDAP")
	public Response addUserFromLDAP(List<LDAPUser> ldapUser){
		

		if (log.isTraceEnabled()) {
			log.trace("addUserFromLDAP || begin with : ldapUser " + ldapUser.toString());
		}
		if (ldapUser == null) {
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModel(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil
							.getMessage(Constants.INVALID_REQUEST)))
							.build();
		} else {

			Status retStat = Status.OK;
			String retMsg = null;
			String retScsFlr = null;
			int retStatScsFlr = 0;
			List<String> jsonList = new ArrayList<String>();
			Connection conn = null;
			UserDao userDao = new UserDao();
			User userList = new User();
			String jsonRslt;
			boolean duplicateNameFlag = false;
			boolean duplicateEmailIdFlag = false;
		    StringBuffer duplicateName = new StringBuffer();
		    StringBuffer duplicateEmailId = new StringBuffer();

			try {
				if (log.isTraceEnabled()) {
					log.trace("addUserFromLDAP || " + Constants.LOG_CONNECTION_OPEN);
				}
				conn = DBConnection.getInstance().getConnection();
				conn.setAutoCommit(false);

				if (log.isTraceEnabled()) {
					log.trace("addUserFromLDAP || dao method called : getUsers()");
				}
				List<User> usersList = userDao.getUsers(false, conn);
				List<LDAPUser> LdapList = new ArrayList<LDAPUser>();
				
				
				for(LDAPUser ldap : ldapUser ){
					ldap.setFullName(ldap.getFirstName()+" "+ldap.getLastName());
					LdapList.add(ldap);
				}
				
				
				for(User user : usersList ){
					for(LDAPUser ldap : LdapList){
						if(ldap.getUserId().trim().equalsIgnoreCase(user.getUserName())){
						duplicateName.append(ldap.getUserId() +",");
						duplicateNameFlag = true;
						break;
						}
					}
				}
				for(User user : usersList ){
					for(LDAPUser ldap : LdapList){
						if(ldap.getEmail().trim().equalsIgnoreCase(user.getEmailId())){
							duplicateEmailId.append(ldap.getEmail() +",");
							duplicateEmailIdFlag = true;
						   break;
						}
					}
				}
				
				if(duplicateName.length() != 0){
					duplicateName = duplicateName.deleteCharAt(duplicateName.lastIndexOf(","));
					//duplicateName =	duplicateName.deleteCharAt(duplicateName.length()-1);
				}
				if(duplicateEmailId.length() != 0){
					duplicateEmailId = duplicateEmailId.deleteCharAt(duplicateEmailId.lastIndexOf(","));
					
				}
				
				
				if (duplicateNameFlag) {
					log.warn("addUserFromLDAP || entered user name already exist || "
							+ "userName : " +duplicateName );

					jsonRslt = "UserName: " +duplicateName +" Already Exist" ;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.USER_NAME_EXIST),
									new ArrayList<Object>(jsonList))).build();
					
				}/*else if(duplicateEmailIdFlag){
					log.warn("addUserFromLDAP || entered user EmailId already exist || "
							+ "EmailId : " +duplicateEmailId );

					jsonRslt = "EmailId: " +duplicateEmailId +" Already Exist" ;
					jsonList.add(jsonRslt);
					return Response
							.status(Status.OK)
							.entity(new MyModel(
									Constants.INSERT_STATUS_SUCCESS,
									Constants.FAILURE,
									MessageUtil
									.getMessage(Constants.EMAIL_EXIST),
									new ArrayList<Object>(jsonList))).build();
					
				}*/else {
					
					if (log.isTraceEnabled()) {
						log.trace("addUserFromLDAP || dao method called : addUserFromLDAP(userList)");
					}

					for (LDAPUser ldap : ldapUser) {
						userList.setFullName(ldap.getFullName());
						userList.setUserName(ldap.getUserId());
						userList.setEmailId(ldap.getEmail());
						userList.setDepartment(ldap.getDept());
						userList.setPassword("");
						userList.setSectionPosition("Tags~~0,Taxonomies~~1,Overview~~2,Properties~~3,Relationships & Reverse Relationships~~4,Revision History~~5,Discussion~~6,Versions~~7,Asset Visualization~~8");
						userList.setSectionVisibility("Tags~~checked,Taxonomies~~checked,Overview~~checked,Properties~~checked,Relationships & Reverse Relationships~~checked,Revision History~~checked,Discussion~~checked,Versions~~checked,Asset Visualization~~checked");
						userDao.addUser(userList, conn);

					}
					jsonRslt = "User added successfully";
					jsonList.add(jsonRslt);
					
					conn.commit();
					
				}
	
				
				retStat = Status.OK;
				retMsg = Constants.USER_CREATED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;

				for (LDAPUser LDAP : ldapUser) {
					
				MailTemplateDao mailTemplateDao = new MailTemplateDao();
				String msg = "Your profile has been created as : \n User Name : "+ LDAP.getUserId() + "\nFull Name : "+ LDAP.getFullName() + "";
				MailConfig mailConfig = mailTemplateDao.getMailConfig(conn);
				SendEmail.sendTextMail(mailConfig, LDAP.getEmail(), MessageUtil.getMessage(
						Constants.REPOPRO_PROFILE_CREATED), MessageUtil.getMessage(Constants.EMAIL_HDR) 
						+ msg+ "\n" +MessageUtil.getMessage(Constants.EMAIL_NOTE));
				}


			}

			catch (RepoproException e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}
			}catch (Exception e) {
				e.printStackTrace();
				retStat = Status.INTERNAL_SERVER_ERROR;
				retMsg = e.getMessage();
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
				try {
					conn.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
					retStat = Status.INTERNAL_SERVER_ERROR;
					retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
					retScsFlr = Constants.FAILURE;
					retMsg = e1.getMessage();
				}

			} finally {
				if (log.isTraceEnabled()) {
					log.trace("addUserFromLDAP || " + Constants.LOG_CONNECTION_CLOSE);
				}
				DBConnection.closeDbConnection(conn);
			}
			if (log.isTraceEnabled()) {
				log.trace("addUserFromLDAP  || " + jsonList.toString() + " || end");
			}
			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(jsonList))).build();
		}
		
	}
}
