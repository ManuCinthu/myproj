package com.thbs.repopro.ldap;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;

public class LDAPConnection {

	private DirContext dirContext;
	private static LDAPConnection ldapConnection;

	private LDAPConnection() throws RepoproException{
		// TODO Auto-generated constructor stub

		String host = CommonUtils.LdapHost;
		String port = CommonUtils.LdapPort;
		String userName = CommonUtils.LdapUserName;
		String password = CommonUtils.LdapPassword;
		String authentication = CommonUtils.LdapAuthenticationType;
		String ldapActiveDirectory = CommonUtils.LdapActiveDirectory;
		String ldapReferral = CommonUtils.LdapRefferal;

		String url = host + ":" + port;

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.PROVIDER_URL, url);
		env.put(Context.SECURITY_AUTHENTICATION, authentication);
		if (ldapActiveDirectory.equals("true")) {
			env.put(Context.SECURITY_PROTOCOL, "ssl");
		}
		// System.out.println("userName ="+userName+" length
		// ="+userName.length());
		// if(userName.length()!=0){
		// System.out.println("In");
		env.put(Context.SECURITY_PRINCIPAL, userName);
		env.put(Context.SECURITY_CREDENTIALS, password);
		env.put(Context.REFERRAL, ldapReferral);
		// }
		if (CommonUtils.LdapKeyRequired.equals("true")) {

			System.setProperty("javax.net.ssl.trustStore", CommonUtils.LdapCertificateDetails);
			System.setProperty("javax.net.ssl.trustStorePassword", CommonUtils.LdapTrustStorePassword);
		}
		DirContext ctx = null;
		try {
			ctx = new InitialDirContext(env);
			this.dirContext = ctx;
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}
	}

	public static LDAPConnection getInstance() throws RepoproException{
		if (ldapConnection == null) {
			try {
				ldapConnection = new LDAPConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new RepoproException(e.getMessage()+" LDAP_NAMEING_EXCEPTION");
			}
		}
		return ldapConnection;
	}

	public DirContext getDirContext() {
		return dirContext;
	}

}
