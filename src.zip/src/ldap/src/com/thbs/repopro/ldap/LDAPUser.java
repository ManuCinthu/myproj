package com.thbs.repopro.ldap;

public class LDAPUser {

	private String userId;
	private String firstName;
	private String lastName;
	private String email;
	private String dept;
	private String fullName;
	private int userIdAttributeId;
	private int firstNameAttributeId;
	private int lastNameAttributeId;;
	private int emailAttributeId;;
	private int deptAttributeId;;
	private int fullNameAttributeId;;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getUserIdAttributeId() {
		return userIdAttributeId;
	}

	public void setUserIdAttributeId(int userIdAttributeId) {
		this.userIdAttributeId = userIdAttributeId;
	}

	public int getFirstNameAttributeId() {
		return firstNameAttributeId;
	}

	public void setFirstNameAttributeId(int firstNameAttributeId) {
		this.firstNameAttributeId = firstNameAttributeId;
	}

	public int getLastNameAttributeId() {
		return lastNameAttributeId;
	}

	public void setLastNameAttributeId(int lastNameAttributeId) {
		this.lastNameAttributeId = lastNameAttributeId;
	}

	public int getEmailAttributeId() {
		return emailAttributeId;
	}

	public void setEmailAttributeId(int emailAttributeId) {
		this.emailAttributeId = emailAttributeId;
	}

	public int getDeptAttributeId() {
		return deptAttributeId;
	}

	public void setDeptAttributeId(int deptAttributeId) {
		this.deptAttributeId = deptAttributeId;
	}

	public int getFullNameAttributeId() {
		return fullNameAttributeId;
	}

	public void setFullNameAttributeId(int fullNameAttributeId) {
		this.fullNameAttributeId = fullNameAttributeId;
	}

	@Override
	public String toString() {
		return "LDAPUser [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", dept=" + dept + ", fullName=" + fullName + ", userIdAttributeId=" + userIdAttributeId
				+ ", firstNameAttributeId=" + firstNameAttributeId + ", lastNameAttributeId=" + lastNameAttributeId
				+ ", emailAttributeId=" + emailAttributeId + ", deptAttributeId=" + deptAttributeId
				+ ", fullNameAttributeId=" + fullNameAttributeId + "]";
	}

}
