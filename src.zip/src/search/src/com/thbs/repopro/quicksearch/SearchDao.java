package com.thbs.repopro.quicksearch;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.RoleDao;
import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.dto.AdminAccessName;
import com.thbs.repopro.dto.LdapMapping;
import com.thbs.repopro.dto.QuickSearch;
import com.thbs.repopro.dto.SearchResponse;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.dto.UserFunction;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class SearchDao {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	int rem = 0;
	int constantLimit = 0;
	
	/**
	 * @method : search
	 * @param searchString
	 * @param options
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public SearchResponse search(String searchString, String options, String userName, Connection conn, boolean restApiFlag, int from, int range, String sortBy, String sortOrder, boolean restApiFlagWithoutLimit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("search || Begin with searchString : "+ searchString +"\t options : "+ options +" \t username : "+ userName);
		}
				
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		String[] keywords;
		List<String> consString = new ArrayList<String>();
		
		SearchResponse searchResponse = new SearchResponse();
		
		HashMap<String, Object> finalMap = new HashMap<String, Object>();
		
		HashMap<String, List<QuickSearch>> searchMap = new HashMap<String, List<QuickSearch>>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("search || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			Pattern regex = Pattern.compile("[^\\s\"']+|\"([^\"]*)\"|'([^']*)'");
			Matcher regexMatcher = regex.matcher(searchString);
			
			while (regexMatcher.find()) {
				if (regexMatcher.group(1) != null) {
					consString.add(regexMatcher.group(1));
				} else if (regexMatcher.group(2) != null) {
					consString.add(regexMatcher.group(2));
				} else {
					consString.add(regexMatcher.group());
				}
			}
			
			keywords = consString.toArray(new String[consString.size()]);
			
			List<String> keywordsForDB = new ArrayList<String>();
			for(int i = 0; i < keywords.length; i++){
				//keywords[i] = "*" + keywords[i] + "*";
				
				/*if(keywords[i].equals("*")){
					for(int j = i; j < keywords.length -1; j++){
						keywordsForDB.add(j, keywords[j+1]);
					}
					break;
				}
				else{*/
					keywordsForDB.add(i, keywords[i]);
				//}
			}
			
			List<QuickSearch> superList = new ArrayList<QuickSearch>();
			int numOfQueriesToBeRun = 0;
			
			//keyword search
			if(options.equalsIgnoreCase("keyword")){
				numOfQueriesToBeRun = 8;
				List<QuickSearch> profiles = new ArrayList<>();
				List<QuickSearch> assets = new ArrayList<>();
				List<QuickSearch> assetInsts = new ArrayList<>();
				List<QuickSearch> params = new ArrayList<>();
				List<QuickSearch> taxonomies = new ArrayList<>();
				List<QuickSearch> tagging  = new ArrayList<>();
				List<QuickSearch> taxonomiesDetails = new ArrayList<>();
				List<QuickSearch> taxonomiesAsset = new ArrayList<>();
				
				if(restApiFlag == true) {
					rem = range%numOfQueriesToBeRun;
					double limit1 = Double.valueOf(range)/Double.valueOf(numOfQueriesToBeRun);
					if(limit1<1) {
						limit1 = 1;
					}else {
						limit1 = Math.floor(limit1);
					}
					constantLimit = (int) limit1;
				}
				
				int limit = constantLimit;
				if(range>8) {
					limit = limit+rem;
				}
				
				for (String keyword : keywordsForDB){
					
					/*assetInsts.addAll(getAssetInstanceMatchedWithKeyword(keyword, userName, conn, restApiFlag, from, range, numOfQueriesToBeRun, restApiFlagWithoutLimit));
					params.addAll(getParametersMatchedWithKeyword(keyword, userName, conn, restApiFlag, from, range, numOfQueriesToBeRun, restApiFlagWithoutLimit));
					taxonomies.addAll(getAllassignedAssetInstanceTaxonomy(keyword, userName, conn, restApiFlag, from, range, numOfQueriesToBeRun, restApiFlagWithoutLimit));
					tagging.addAll(getAllassignedAssetInstanceTagging(keyword, userName, conn, restApiFlag, from, range, numOfQueriesToBeRun, restApiFlagWithoutLimit));
					taxonomiesDetails.addAll(getAllassignedAssetInstanceTaxonomyDetails(keyword, userName, conn, restApiFlag, from, range, numOfQueriesToBeRun, restApiFlagWithoutLimit));
					assets.addAll(getAssetsMatchedWithKeyword(keyword, userName, conn, restApiFlag, from, range, numOfQueriesToBeRun, restApiFlagWithoutLimit));
					profiles.addAll(getProfileMatchedWithKeyword(keyword, conn, restApiFlag, from, range, numOfQueriesToBeRun, restApiFlagWithoutLimit));*/
					
					
					profiles.addAll(getProfileMatchedWithKeyword(keyword, conn, restApiFlag, from, restApiFlagWithoutLimit, limit, userName));
					
					limit = constantLimit + getRem(limit, profiles.size());
					assets.addAll(getAssetsMatchedWithKeyword(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, assets.size());
					assetInsts.addAll(getAssetInstanceMatchedWithKeyword(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, assetInsts.size());
					taxonomies.addAll(getAllassignedAssetInstanceTaxonomy(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, taxonomies.size());
					taxonomiesDetails.addAll(getAllassignedAssetInstanceTaxonomyDetails(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, taxonomiesDetails.size());
					taxonomiesAsset.addAll(getAllassignedAssetInstanceTaxonomyDetailsForAsset(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, taxonomiesAsset.size());
					tagging.addAll(getAllassignedAssetInstanceTagging(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, tagging.size());
					params.addAll(getParametersMatchedWithKeyword(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
				}
				
				/*superList=check(superList, profiles);
				searchMap.put("profile", superList);
				
				superList=check(superList, assets);
				searchMap.put("assetType", superList);*/
				
				superList=check(superList, assetInsts);
				searchMap.put("assetInstanceType", superList);
				
				superList=check(superList, params);
				searchMap.put("parameters", superList);
				
				superList=check(superList,taxonomies);
				searchMap.put("taxonomy", superList);
				
				superList=check(superList,tagging);
				searchMap.put("tagging", superList);
				
				//sorting
				if(sortBy != null && sortOrder != null) {
					if(sortBy.equalsIgnoreCase("AssetInstanceName")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(superList, new Sortbyname());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(superList, new SortbynameRev());
						}
					}
					else if(sortBy.equalsIgnoreCase("AssetInstanceVersionId")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(superList, new Sortbyid());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(superList, new SortbyidRev());
						}
					}
				}
								
				superList=check(superList,taxonomiesDetails);
				searchMap.put("taxonomyDetails", superList);
				
				superList=check(superList,taxonomiesAsset);
				searchMap.put("taxonomyDetails", superList);
				
				superList=check(superList, assets);
				searchMap.put("assetType", superList);
				
				superList=check(superList, profiles);
				searchMap.put("profile", superList);
			}
			
			else if(options.equalsIgnoreCase("taxonomy")){
				numOfQueriesToBeRun = 3;
				List<QuickSearch> taxonomies = new ArrayList<>();
				List<QuickSearch> taxonomiesDetails = new ArrayList<>();
				List<QuickSearch> taxonomiesAsset = new ArrayList<>();
				
				if(restApiFlag == true) {
					rem = range%numOfQueriesToBeRun;
					double limit1 = Double.valueOf(range)/Double.valueOf(numOfQueriesToBeRun);
					if(limit1<1) {
						limit1 = 1;
					}else {
						limit1 = Math.floor(limit1);
					}
					constantLimit = (int) limit1;
				}
				
				int limit = constantLimit + rem;
				
				for (String keyword : keywordsForDB){
					
					taxonomies.addAll(getAllassignedAssetInstanceTaxonomy(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, taxonomies.size());
					taxonomiesDetails.addAll(getAllassignedAssetInstanceTaxonomyDetails(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, taxonomiesDetails.size());
					taxonomiesAsset.addAll(getAllassignedAssetInstanceTaxonomyDetailsForAsset(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
				}
				superList=check(superList,taxonomies);
				searchMap.put("taxonomy", superList);
				
				//sorting
				if(sortBy != null && sortOrder != null) {
					if(sortBy.equalsIgnoreCase("AssetInstanceName")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(superList, new Sortbyname());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(superList, new SortbynameRev());
						}
					}
					else if(sortBy.equalsIgnoreCase("AssetInstanceVersionId")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(superList, new Sortbyid());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(superList, new SortbyidRev());
						}
					}
				}
				
				superList=check(superList,taxonomiesDetails);
				searchMap.put("taxonomyDetails", superList);
				
				superList=check(superList,taxonomiesAsset);
				searchMap.put("taxonomyDetails", superList);
			}
			else if(options.equalsIgnoreCase("tags")){
				numOfQueriesToBeRun = 1;
				List<QuickSearch> tagging  = new ArrayList<>();
				
				if(restApiFlag == true) {
					rem = range%numOfQueriesToBeRun;
					double limit1 = Double.valueOf(range)/Double.valueOf(numOfQueriesToBeRun);
					if(limit1<1) {
						limit1 = 1;
					}else {
						limit1 = Math.floor(limit1);
					}
					constantLimit = (int) limit1;
				}
				
				int limit = constantLimit + rem;
				
				for (String keyword : keywordsForDB){
					tagging.addAll(getAllassignedAssetInstanceTagging(keyword, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
				}
				superList=check(superList,tagging);
				searchMap.put("tagging", superList);
				
				//sorting
				if(sortBy != null && sortOrder != null) {
					if(sortBy.equalsIgnoreCase("AssetInstanceName")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(superList, new Sortbyname());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(superList, new SortbynameRev());
						}
					}
					else if(sortBy.equalsIgnoreCase("AssetInstanceVersionId")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(superList, new Sortbyid());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(superList, new SortbyidRev());
						}
					}
				}
			}
			else{
				numOfQueriesToBeRun = 3;
				//particular asset search
				//List<QuickSearch> profiles = new ArrayList<>();
				List<QuickSearch> assetTypeList = new ArrayList<>();
				List<QuickSearch> assetInstanceTypeList = new ArrayList<>();
				List<QuickSearch> paramsTypeList = new ArrayList<>();
				
				if(restApiFlag == true) {
					rem = range%numOfQueriesToBeRun;
					double limit1 = Double.valueOf(range)/Double.valueOf(numOfQueriesToBeRun);
					if(limit1<1) {
						limit1 = 1;
					}else {
						limit1 = Math.floor(limit1);
					}
					constantLimit = (int) limit1;
				}
				
				int limit = constantLimit + rem;
				
				for (String keyword : keywordsForDB){
					//profiles.addAll(getProfileMatchedWithKeyword(keyword, conn));
					
					assetTypeList.addAll(getAssetsMatchedWithKeywordForAssetName(keyword, options, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, assetTypeList.size());
					assetInstanceTypeList.addAll(getAssetInstanceMatchedWithKeywordForAssetType(keyword, options, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));
					
					limit = constantLimit + getRem(limit, assetInstanceTypeList.size());
					paramsTypeList.addAll(getParametersMatchedWithKeywordForAssetType(keyword, options, userName, conn, restApiFlag, from, restApiFlagWithoutLimit, limit));					
				}
				/*superList=check(superList, profiles);
				searchMap.put("profile", superList);*/
				
				superList=check(superList, assetInstanceTypeList);
				searchMap.put("assetInstanceType", superList);
				
				superList=check(superList, paramsTypeList);
				searchMap.put("parameters", superList);
				
				//sorting
				if(sortBy != null && sortOrder != null) {
					if(sortBy.equalsIgnoreCase("AssetInstanceName")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(superList, new Sortbyname());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(superList, new SortbynameRev());
						}
					}
					else if(sortBy.equalsIgnoreCase("AssetInstanceVersionId")) {
						if(sortOrder.equalsIgnoreCase("asc")) {
							Collections.sort(superList, new Sortbyid());
						}else if(sortOrder.equalsIgnoreCase("desc")) {
							Collections.sort(superList, new SortbyidRev());
						}
					}
				}
				
				
				superList=check(superList, assetTypeList);
				searchMap.put("assetType", superList);
			}
			
			/*if(superList.size()>range) {
				superList = superList.subList(0, range);
			}*/
			
			/*Collections.sort(superList, new QuickSearch());
			Collections.sort(superList, Collections.reverseOrder());*/
			
			/*superList.sort((QuickSearch s1, QuickSearch s2)->s1.getAssetInstVersionId().intValue()-s2.getAssetInstVersionId().intValue());
			
			superList.sort((QuickSearch s1, QuickSearch s2)->s2.getAssetInstVersionId().intValue()-s1.getAssetInstVersionId().intValue());
			
			superList.sort((QuickSearch s1, QuickSearch s2)->s1.getAssetInstName().compareTo(s2.getAssetInstName()));
			
			superList.sort((QuickSearch s1, QuickSearch s2)->s1.getAssetInstName().compareTo(s2.getAssetInstName()));
			*/
			finalMap.putAll(searchMap);
			Set<Object> obj = new LinkedHashSet<Object>(superList);
			
			searchResponse.setTotalCount(obj.size());
			searchResponse.setSearchResponse(obj);
			
		} catch (SQLException e) {
			log.error("search || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.SEARCH_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("search || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("search || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("search || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("search || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("search || End");
		}
		return searchResponse;
	}
	
	/**
	 * @method : getProfileMatchedWithKeyword
	 * @param keyword
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<QuickSearch> getProfileMatchedWithKeyword(String keyword, Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit, String loggedinUserName) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getProfileMatchedWithKeyword || Begin with searchString : "+keyword);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		QuickSearch user = null;
		List<QuickSearch> userList = new ArrayList<QuickSearch>();
		
		UserDao userDao = new UserDao();
		RoleDao roledao = new RoleDao();
		List<UserFunction> userfunctionMappedWithRoleId = new ArrayList<UserFunction>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getProfileMatchedWithKeyword || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			//keyword = keyword.replace("*","");
			boolean userFlag = false;
			if(!loggedinUserName.equalsIgnoreCase("roleAnonymous")) {
				User user2 = userDao.retProfileForUserName(loggedinUserName, conn);
				userfunctionMappedWithRoleId = roledao.retAllRoleFunctionsMappedWithUserId(user2.getUserId(), conn);
				for(UserFunction uf : userfunctionMappedWithRoleId){
					if(uf.getFunctionDescription().equalsIgnoreCase("ROLE_MNG_USERS")){
						userFlag = true;
						break;
					}
				}
			}
			
			if(loggedinUserName.equalsIgnoreCase("admin")) {
				userFlag = true;
			}
			
			boolean userDetailsFlag = false;
			if(!loggedinUserName.equalsIgnoreCase("roleAnonymous")) {
				User userDetails = userDao.retProfiledetailsForUserName(loggedinUserName, conn);
				if(userDetails.getUserName().toLowerCase().contains(keyword.toLowerCase()) || userDetails.getFullName().toLowerCase().contains(keyword.toLowerCase())
						|| userDetails.getEmailId().toLowerCase().contains(keyword.toLowerCase()) || userDetails.getDepartment().toLowerCase().contains(keyword.toLowerCase())) {
					
					userDetailsFlag = true;
				}
			}
			
			if(restApiFlag == true) {

				if(userFlag) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_PROFILE_WITH_LIMIT_FOR_LOGGED_IN_USER));

					pstmt.setString(Constants.ONE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWO, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SIX, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
					pstmt.setString(Constants.NINE, "%"+keyword+"%");
					pstmt.setString(Constants.TEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.ELEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.TWELVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTEEN, "%"+keyword+"%");
					pstmt.setInt(Constants.FOURTEEN, from);
					pstmt.setInt(Constants.FIFTEEN, limit);

					if (log.isTraceEnabled()) {
						log.trace("getProfileMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_PROFILE_WITH_LIMIT_FOR_LOGGED_IN_USER));
					}
				}else {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_PROFILE_WITH_LIMIT));

					pstmt.setString(Constants.ONE, loggedinUserName);
					pstmt.setString(Constants.TWO, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SIX, CommonUtils.encryptionKey);

					pstmt.setString(Constants.SEVEN, loggedinUserName);
					pstmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
					pstmt.setString(Constants.NINE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.ELEVEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWELVE, CommonUtils.encryptionKey);

					pstmt.setString(Constants.THIRTEEN, loggedinUserName);
					pstmt.setString(Constants.FOURTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FIFTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SIXTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SEVENTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.EIGHTEEN, CommonUtils.encryptionKey);

					pstmt.setString(Constants.NINETEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTY, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYONE, CommonUtils.encryptionKey);

					pstmt.setString(Constants.TWENTYTWO, "%"+keyword+"%");
					pstmt.setString(Constants.TWENTYTHREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYFOUR, "%"+keyword+"%");
					pstmt.setString(Constants.TWENTYFIVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYSIX, "%"+keyword+"%");
					pstmt.setString(Constants.TWENTYSEVEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYEIGHT, "%"+keyword+"%");
					
					pstmt.setString(Constants.TWENTYNINE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTY, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYONE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYTWO, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYTHREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYFOUR, CommonUtils.encryptionKey);
					if(userDetailsFlag) {
						pstmt.setString(Constants.THIRTYFIVE, loggedinUserName);
					}else {
						pstmt.setString(Constants.THIRTYFIVE, "");
					}
					
					pstmt.setInt(Constants.THIRTYSIX, from);
					pstmt.setInt(Constants.THIRTYSEVEN, limit);

					if (log.isTraceEnabled()) {
						log.trace("getProfileMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_PROFILE_WITH_LIMIT));
					}
				}
			}
			else if(restApiFlagWithoutLimit == true) {

				if(userFlag == true) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_PROFILE_WITHOUT_LIMIT_FOR_LOGGED_IN_USER));

					pstmt.setString(Constants.ONE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWO, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SIX, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
					pstmt.setString(Constants.NINE, "%"+keyword+"%");
					pstmt.setString(Constants.TEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.ELEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.TWELVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTEEN, "%"+keyword+"%");

					if (log.isTraceEnabled()) {
						log.trace("getProfileMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_PROFILE_WITHOUT_LIMIT_FOR_LOGGED_IN_USER));
					}
				}else {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_PROFILE_WITHOUT_LIMIT));

					pstmt.setString(Constants.ONE, loggedinUserName);
					pstmt.setString(Constants.TWO, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SIX, CommonUtils.encryptionKey);

					pstmt.setString(Constants.SEVEN, loggedinUserName);
					pstmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
					pstmt.setString(Constants.NINE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.ELEVEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWELVE, CommonUtils.encryptionKey);

					pstmt.setString(Constants.THIRTEEN, loggedinUserName);
					pstmt.setString(Constants.FOURTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FIFTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SIXTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SEVENTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.EIGHTEEN, CommonUtils.encryptionKey);

					pstmt.setString(Constants.NINETEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTY, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYONE, CommonUtils.encryptionKey);

					pstmt.setString(Constants.TWENTYTWO, "%"+keyword+"%");
					pstmt.setString(Constants.TWENTYTHREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYFOUR, "%"+keyword+"%");
					pstmt.setString(Constants.TWENTYFIVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYSIX, "%"+keyword+"%");
					pstmt.setString(Constants.TWENTYSEVEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYEIGHT, "%"+keyword+"%");
					
					pstmt.setString(Constants.TWENTYNINE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTY, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYONE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYTWO, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYTHREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYFOUR, CommonUtils.encryptionKey);
					if(userDetailsFlag) {
						pstmt.setString(Constants.THIRTYFIVE, loggedinUserName);
					}else {
						pstmt.setString(Constants.THIRTYFIVE, "");
					}

					if (log.isTraceEnabled()) {
						log.trace("getProfileMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_PROFILE_WITHOUT_LIMIT));
					}
				}
			}
			else {
				if(userFlag == true) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_PROFILE_FOR_LOGGED_IN_USER));
					
					pstmt.setString(Constants.ONE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWO, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SIX, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
					pstmt.setString(Constants.NINE, "%"+keyword+"%");
					pstmt.setString(Constants.TEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.ELEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.TWELVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTEEN, "%"+keyword+"%");
					
					if (log.isTraceEnabled()) {
						log.trace("getProfileMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_PROFILE_FOR_LOGGED_IN_USER));
					}
				}else {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_PROFILE));

					pstmt.setString(Constants.ONE, loggedinUserName);
					pstmt.setString(Constants.TWO, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FOUR, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FIVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SIX, CommonUtils.encryptionKey);
					
					pstmt.setString(Constants.SEVEN, loggedinUserName);
					pstmt.setString(Constants.EIGHT, CommonUtils.encryptionKey);
					pstmt.setString(Constants.NINE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.ELEVEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWELVE, CommonUtils.encryptionKey);
					
					pstmt.setString(Constants.THIRTEEN, loggedinUserName);
					pstmt.setString(Constants.FOURTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.FIFTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SIXTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.SEVENTEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.EIGHTEEN, CommonUtils.encryptionKey);
					
					pstmt.setString(Constants.NINETEEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTY, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYONE, CommonUtils.encryptionKey);
					
					pstmt.setString(Constants.TWENTYTWO, "%"+keyword+"%");
					pstmt.setString(Constants.TWENTYTHREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYFOUR, "%"+keyword+"%");
					pstmt.setString(Constants.TWENTYFIVE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYSIX, "%"+keyword+"%");
					pstmt.setString(Constants.TWENTYSEVEN, CommonUtils.encryptionKey);
					pstmt.setString(Constants.TWENTYEIGHT, "%"+keyword+"%");
					
					pstmt.setString(Constants.TWENTYNINE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTY, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYONE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYTWO, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYTHREE, CommonUtils.encryptionKey);
					pstmt.setString(Constants.THIRTYFOUR, CommonUtils.encryptionKey);
					if(userDetailsFlag) {
						pstmt.setString(Constants.THIRTYFIVE, loggedinUserName);
					}else {
						pstmt.setString(Constants.THIRTYFIVE, "");
					}
					
					if (log.isTraceEnabled()) {
						log.trace("getProfileMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_PROFILE));
					}
				}
			}
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				Map<String, String> matchedWordsMap = new HashMap<String, String>();
				HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
				
				Long userId = rs.getLong("user_id");
				String userName = rs.getString("user_name");
				String emailId = rs.getString("masked_email_id");
				String fullName = rs.getString("masked_full_name");
				String dept = rs.getString("masked_department");
				String imageName = rs.getString("image_name");
				
				boolean isUserNameExists = StringUtils.containsIgnoreCase(userName, keyword);
				boolean isEmailIdExists = StringUtils.containsIgnoreCase(emailId, keyword);
				boolean isFullNameExists = StringUtils.containsIgnoreCase(fullName, keyword);
				boolean isDeptExists = StringUtils.containsIgnoreCase(dept, keyword);
				
				if(isUserNameExists){
					matchedWordsMap.put(Constants.USER_NAME_MATCHED, userName);
					if (log.isDebugEnabled()) {
						log.debug("getProfileMatchedWithKeyword || " + userName + "is matched");
					}
				}
				
				if(isEmailIdExists){
					matchedWordsMap.put(Constants.EMAIL_ID_MATCHED, emailId);
					if (log.isDebugEnabled()) {
						log.debug("getProfileMatchedWithKeyword || " + emailId + "is matched");
					}
				}
				
				if(isFullNameExists){
					matchedWordsMap.put(Constants.FULL_NAME_MATCHED, fullName);
					if (log.isDebugEnabled()) {
						log.debug("getProfileMatchedWithKeyword || " + fullName + "is matched");
					}
				}
				
				if(isDeptExists){
					matchedWordsMap.put(Constants.DEPT_MATCHED, dept);
					if (log.isDebugEnabled()) {
						log.debug("getProfileMatchedWithKeyword || " + dept + "is matched");
					}
				}
				
				combinedMatchedResult.putAll(matchedWordsMap);
				
				user = new QuickSearch();
				user.setFullName(fullName);
				user.setEmailId(emailId);
				user.setDepartment(dept);
				user.setSearchBy("Profile");
				user.setUserId(userId);
				user.setUserName(userName);
				user.setImageName(imageName);
				user.setUserMap(combinedMatchedResult);
				user.setEncryptFullName(rs.getInt("encrypt_full_name"));
				user.setEncryptEmailId(rs.getInt("encrypt_email_id"));
				user.setEncryptDepartment(rs.getInt("encrypt_department"));
				user.setEncryptImage(rs.getInt("encrypt_image"));
				user.setDecryptedFullName(rs.getString("decrypted_full_name"));
				user.setDecryptedEmailId(rs.getString("decrypted_email_id"));
				user.setDecryptedDept(rs.getString("decrypted_dept"));
				
				userList.add(user);
				if(log.isTraceEnabled()){
					log.debug("getProfileMatchedWithKeyword || "+ userList.toString());
				}
			}
						
			if(log.isDebugEnabled()){
				log.debug("getProfileMatchedWithKeyword || "+ userList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getProfileMatchedWithKeyword || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.USER_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getProfileMatchedWithKeyword || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getProfileMatchedWithKeyword || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getProfileMatchedWithKeyword || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getProfileMatchedWithKeyword || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getProfileMatchedWithKeyword || End ");
		}
		return userList;
	}
	
	/**
	 * @method : getAssetsMatchedWithKeyword
	 * @param keyword
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<QuickSearch> getAssetsMatchedWithKeyword(String keyword, String userName, Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) 
			throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAssetsMatchedWithKeyword || Begin with searchString : "+ keyword 
					+"\t username : "+userName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		QuickSearch assets = null;
		List<QuickSearch> assetsList = new ArrayList<QuickSearch>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAssetsMatchedWithKeyword || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			//keyword = keyword.replace("*","");
			
			//guest user
			if(userName.equalsIgnoreCase("roleAnonymous")){
				
				if(restApiFlag == true) {
										
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_FOR_GUEST_WITH_LIMIT));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setInt(Constants.THREE, from);
					pstmt.setInt(Constants.FOUR, limit);

					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_FOR_GUEST_WITH_LIMIT));
					}
				}
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_FOR_GUEST_WITHOUT_LIMIT));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_FOR_GUEST_WITHOUT_LIMIT));
					}
				}
				else {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_FOR_GUEST));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");

					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_FOR_GUEST));
					}
				}
				rs = pstmt.executeQuery();
				
			}else{
				//logged in users
				
				if(restApiFlag == true) {
															
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_WITH_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
							actualvalue = keyword;
							actualvalue = actualvalue.replace("&", "&amp;");
							actualvalue = actualvalue.replace("'", "&#39;");
							actualvalue = actualvalue.replace("<", "&lt;");
							actualvalue = actualvalue.replace(">", "&gt;");
							actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setInt(Constants.THREE, from);
					pstmt.setInt(Constants.FOUR, limit);
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_WITH_LIMIT));
					}
				}
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_WITHOUT_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
							actualvalue = keyword;
							actualvalue = actualvalue.replace("&", "&amp;");
							actualvalue = actualvalue.replace("'", "&#39;");
							actualvalue = actualvalue.replace("<", "&lt;");
							actualvalue = actualvalue.replace(">", "&gt;");
							actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
										
					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_WITHOUT_LIMIT));
					}
				}
				else {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");

					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeyword || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET));
					}
				}
				rs = pstmt.executeQuery();
			}
			
			while(rs.next()){
				Map<String, String> matchedWordsMap = new HashMap<String, String>();
				HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
				
				Long assetId = rs.getLong("asset_id");
				String assetName = rs.getString("asset_name");
				String desc = rs.getString("description");
				boolean versionable = rs.getBoolean("versionable");
				
				boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
				boolean isDescExists = StringUtils.containsIgnoreCase(desc, keyword);
				
				if(isAssetNameExists){
					matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
					if (log.isDebugEnabled()) {
						log.debug("getAssetsMatchedWithKeyword || " + assetName + "is matched");
					}
				}
				
				if(isDescExists){
					matchedWordsMap.put(Constants.DESC_MATCHED, desc);
					if (log.isDebugEnabled()) {
						log.debug("getAssetsMatchedWithKeyword || " + desc + "is matched");
					}
				}
				
				combinedMatchedResult.putAll(matchedWordsMap);
				
				assets = new QuickSearch();
				assets.setSearchBy("Asset");
				assets.setAssetId(assetId);
				assets.setAssetName(assetName);
				assets.setAssetDescription(desc);
				assets.setVersionable(versionable);
				assets.setAssetMap(combinedMatchedResult);
				assetsList.add(assets);
				if(log.isTraceEnabled()){
					log.debug("getAssetsMatchedWithKeyword || "+ assets.toString());
				}
				
			}
						
			if(log.isDebugEnabled()){
				log.debug("getAssetsMatchedWithKeyword || "+ assetsList.toString());
			}
			
			
		} catch (SQLException e) {
			log.error("getAssetsMatchedWithKeyword || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetsMatchedWithKeyword || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetsMatchedWithKeyword || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetsMatchedWithKeyword || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetsMatchedWithKeyword || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAssetsMatchedWithKeyword || End ");
		}
		return assetsList;
	}
	
	/**
	 * @method : getAssetsMatchedWithKeywordForAssetName
	 * @param keyword
	 * @param options
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<QuickSearch> getAssetsMatchedWithKeywordForAssetName(String keyword, String options, 
			String userName, Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAssetsMatchedWithKeywordForAssetName || Begin with searchString : "+keyword +" \t options : "+ options +" \t userName : "+ userName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		QuickSearch assets = null;
		List<QuickSearch> assetsList = new ArrayList<QuickSearch>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAssetsMatchedWithKeywordForAssetName || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			//keyword = keyword.replace("*","");
			
			//guest user
			if(userName.equalsIgnoreCase("roleAnonymous")){
				
				if(restApiFlag == true) {
										
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setString(Constants.THREE, options);
					pstmt.setInt(Constants.FOUR, from);
					pstmt.setInt(Constants.FIVE, limit);
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeywordForAssetName || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT));
					}
				}
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setString(Constants.THREE, options);
										
					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeywordForAssetName || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT));
					}
				}
				else {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setString(Constants.THREE, options);

					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeywordForAssetName || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_FOR_GUEST));
					}
				}
				rs = pstmt.executeQuery();
			}
			else{
				//logged in users
				
				if(restApiFlag == true) {
										
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_WITH_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setString(Constants.THREE, options);
					pstmt.setInt(Constants.FOUR, from);
					pstmt.setInt(Constants.FIVE, limit);
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeywordForAssetName || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_WITH_LIMIT));
					}
				}
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_WITHOUT_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setString(Constants.THREE, options);
										
					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeywordForAssetName || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE_WITHOUT_LIMIT));
					}
				}
				else {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setString(Constants.THREE, options);

					if (log.isTraceEnabled()) {
						log.trace("getAssetsMatchedWithKeywordForAssetName || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_MATCHED_ASSET_FOR_ASSET_TYPE));
					}
				}
				rs = pstmt.executeQuery();
			}
			
			while(rs.next()){
				Map<String, String> matchedWordsMap = new HashMap<String, String>();
				HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
				
				Long assetId = rs.getLong("asset_id");
				String assetName = rs.getString("asset_name");
				String desc = rs.getString("description");
				boolean versionable = rs.getBoolean("versionable");
				
				boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
				boolean isDescExists = StringUtils.containsIgnoreCase(desc, keyword);
				
				if(isAssetNameExists){
					matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
					if (log.isDebugEnabled()) {
						log.debug("getAssetsMatchedWithKeywordForAssetName || " + assetName + "is matched");
					}
				}
				
				if(isDescExists){
					matchedWordsMap.put(Constants.DESC_MATCHED, desc);
					if (log.isDebugEnabled()) {
						log.debug("getAssetsMatchedWithKeywordForAssetName || " + desc + "is matched");
					}
				}
				
				combinedMatchedResult.putAll(matchedWordsMap);
				
				assets = new QuickSearch();
				assets.setSearchBy("Asset");
				assets.setAssetId(assetId);
				assets.setAssetName(assetName);
				assets.setAssetDescription(desc);
				assets.setVersionable(versionable);
				assets.setAssetMap(combinedMatchedResult);
				assetsList.add(assets);
				if(log.isTraceEnabled()){
					log.debug("getAssetsMatchedWithKeywordForAssetName || "+ assets.toString());
				}
				
			}
			
			
		} catch (SQLException e) {
			log.error("getAssetsMatchedWithKeywordForAssetName || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetsMatchedWithKeywordForAssetName || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetsMatchedWithKeywordForAssetName || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetsMatchedWithKeywordForAssetName || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetsMatchedWithKeywordForAssetName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAssetsMatchedWithKeywordForAssetName || End ");
		}
		return assetsList;
	}
	
	
	/**
	 * @method : getAssetInstanceMatchedWithKeywordForAssetType
	 * @param keyword
	 * @param options
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<QuickSearch> getAssetInstanceMatchedWithKeywordForAssetType(String keyword, 
			String options, String userName, Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAssetInstanceMatchedWithKeywordForAssetType || Begin with searchString : "
					+keyword +" \t options : "+ options +" \t username : "+ userName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		
		QuickSearch ai = null;
		AdminAccessName adminAccessName = null;
		List<QuickSearch> assetInstanceList = new ArrayList<QuickSearch>();
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		boolean flag = false;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAssetInstanceMatchedWithKeywordForAssetType || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			//keyword = keyword.replace("*","");
			
			//guest user
			if (userName.equalsIgnoreCase("roleAnonymous")) {
				
				if(restApiFlag == true) {
					
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
					pstmt.setString(Constants.THREE, options);
					pstmt.setInt(Constants.FOUR, from);
					pstmt.setInt(Constants.FIVE, limit);

					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT));
					}
				}
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
					pstmt.setString(Constants.THREE, options);
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT));
					}
				}
				else {
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
					pstmt.setString(Constants.THREE, options);

					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_GUEST));
					}
				}
				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					
					Long assetInstId = rs.getLong("asset_inst_id");
					String assetName = rs.getString("asset_name");
					String assetInstName = rs.getString("asset_inst_name");
					String assetInstDesc = rs.getString("description");
					Long aivId = rs.getLong("asset_instance_version_id");
					boolean versionable = rs.getBoolean("versionable");
					
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isAssetInstDescExists = StringUtils.containsIgnoreCase(assetInstDesc, keyword);
					
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeywordForAssetType || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeywordForAssetType || " + assetInstName + "is matched");
						}
					}
					
					if(isAssetInstDescExists){
						matchedWordsMap.put(Constants.ASSET_INST_DESC_MATCHED, assetInstDesc);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeywordForAssetType || " + assetInstDesc + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					ai = new QuickSearch();
					ai.setSearchBy("Asset Instance");
					ai.setAssetInstId(assetInstId);
					ai.setAssetName(assetName);
					ai.setAssetInstName(assetInstName);
					ai.setAssetInstDescription(assetInstDesc);
					ai.setAssetInstVersionId(aivId);
					ai.setAssetInstanceMap(combinedMatchedResult);
					ai.setAssetDescription(rs.getString("assetdescription"));
					ai.setAssetId(rs.getLong("asset_id"));
					ai.setVersionable(versionable);
					if(versionable){
						ai.setVersionName(rs.getString("version_name"));
					}else{
						ai.setVersionName("N/A");
					}
					
					assetInstanceList.add(ai);
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "+ ai.toString());
					}
				}
				if(log.isDebugEnabled()){
					log.debug("getAssetInstanceMatchedWithKeywordForAssetType || "+ assetInstanceList.toString());
				}
			}
			else{
				//checking for admin rights
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				
				pstmt.setString(Constants.ONE, userName);
				
				if (log.isTraceEnabled()) {
					log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				}

				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					adminAccessName = new AdminAccessName();
					adminAccessName.setUserName(rs.getString("user_name"));
					adminAccessName.setGroupName(rs.getString("group_name"));
					adminAccessName.setRoleName(rs.getString("role_name"));
					adminAccessNameList.add(adminAccessName);
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeywordForAssetType || returning resultset for admin "
								+ "check : "+ adminAccessName.toString());
					}
				}
				if(log.isDebugEnabled()){
					log.debug("getAssetInstanceMatchedWithKeywordForAssetType || "+ adminAccessNameList.toString());
				}

				for (AdminAccessName adminAccess : adminAccessNameList) {
					if (adminAccess.getUserName().equalsIgnoreCase("admin")
							|| adminAccess.getGroupName().equalsIgnoreCase("group-admin")
							|| adminAccess.getRoleName().equalsIgnoreCase("role-admin")) {
						flag = true;
					}
				}
				
				//admin users
				if(flag){
					
					if(restApiFlag == true) {
												
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_WITH_LIMIT));
						
						pstm.setString(Constants.ONE, "%"+keyword+"%");
						pstm.setString(Constants.TWO, "%"+keyword+"%");
						pstm.setString(Constants.THREE, options);
						pstm.setInt(Constants.FOUR, from);
						pstm.setInt(Constants.FIVE, limit);
						
						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_WITH_LIMIT));
						}
					}
					else if(restApiFlagWithoutLimit == true) {
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_WITHOUT_LIMIT));
						
						pstm.setString(Constants.ONE, "%"+keyword+"%");
						pstm.setString(Constants.TWO, "%"+keyword+"%");
						pstm.setString(Constants.THREE, options);
												
						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_WITHOUT_LIMIT));
						}
					}
					else {
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE));

						pstm.setString(Constants.ONE, "%"+keyword+"%");
						pstm.setString(Constants.TWO, "%"+keyword+"%");
						pstm.setString(Constants.THREE, options);

						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE));
						}
					}
					rs1 = pstm.executeQuery();
				}
				//non-admin users
				else{
					
					if(restApiFlag == true) {
												
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						
						pstm.setString(Constants.ONE, userName);
						pstm.setString(Constants.TWO, "%"+keyword+"%");
						pstm.setString(Constants.THREE, "%"+keyword+"%");
						pstm.setString(Constants.FOUR, options);
						pstm.setInt(Constants.FIVE, from);
						pstm.setInt(Constants.SIX, limit);
				
						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						}
					}
					else if(restApiFlagWithoutLimit == true) {
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						
						pstm.setString(Constants.ONE, userName);
						pstm.setString(Constants.TWO, "%"+keyword+"%");
						pstm.setString(Constants.THREE, "%"+keyword+"%");
						pstm.setString(Constants.FOUR, options);
										
						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						}
					}
					else {
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS));

						pstm.setString(Constants.ONE, userName);
						pstm.setString(Constants.TWO, "%"+keyword+"%");
						pstm.setString(Constants.THREE, "%"+keyword+"%");
						pstm.setString(Constants.FOUR, options);

						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS));
						}
					}
					rs1 = pstm.executeQuery();	
				}
				while (rs1.next()) {
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					
					Long assetInstId = rs1.getLong("asset_inst_id");
					String assetName = rs1.getString("asset_name");
					String assetInstName = rs1.getString("asset_inst_name");
					String assetInstDesc = rs1.getString("description");
					Long aivId = rs1.getLong("asset_instance_version_id");
					boolean versionable = rs1.getBoolean("versionable");
					
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isAssetInstDescExists = StringUtils.containsIgnoreCase(assetInstDesc, keyword);
					
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeywordForAssetType || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeywordForAssetType || " + assetInstName + "is matched");
						}
					}
					
					if(isAssetInstDescExists){
						matchedWordsMap.put(Constants.ASSET_INST_DESC_MATCHED, assetInstDesc);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeywordForAssetType || " + assetInstDesc + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					ai = new QuickSearch();
					ai.setSearchBy("Asset Instance");
					ai.setAssetInstId(assetInstId);
					ai.setAssetName(assetName);
					ai.setAssetInstName(assetInstName);
					ai.setAssetInstDescription(assetInstDesc);
					ai.setAssetInstVersionId(aivId);
					ai.setAssetInstanceMap(combinedMatchedResult);
					ai.setAssetDescription(rs1.getString("assetdescription"));
					ai.setAssetId(rs1.getLong("asset_id"));
					ai.setVersionable(versionable);
					if(versionable){
						ai.setVersionName(rs1.getString("version_name"));
					}else{
						ai.setVersionName("N/A");
					}
					
					assetInstanceList.add(ai);
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeywordForAssetType || "+ ai.toString());
					}
				}
				
				if(log.isDebugEnabled()){
					log.debug("getAssetInstanceMatchedWithKeywordForAssetType || "+ assetInstanceList.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getAssetInstanceMatchedWithKeywordForAssetType || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetInstanceMatchedWithKeywordForAssetType || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetInstanceMatchedWithKeywordForAssetType || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetInstanceMatchedWithKeywordForAssetType || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs1);
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstm);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceMatchedWithKeywordForAssetType || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAssetInstanceMatchedWithKeywordForAssetType || End ");
		}
		return assetInstanceList;
	}
	
	/**
	 * @method : getAssetInstanceMatchedWithKeyword
	 * @param keyword
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<QuickSearch> getAssetInstanceMatchedWithKeyword(String keyword, String userName,
			Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAssetInstanceMatchedWithKeyword || Begin with searchString : "+ keyword 
					+"\t username : "+userName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		
		QuickSearch ai = null;
		AdminAccessName adminAccessName = null;
		List<QuickSearch> searchList = new ArrayList<QuickSearch>();
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		boolean flag = false;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAssetInstanceMatchedWithKeyword || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			//keyword = keyword.replace("*","");
			
			//guest user
			if (userName.equalsIgnoreCase("roleAnonymous")) {
				
				if(restApiFlag == true) {
					
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST_WITH_LIMIT));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setString(Constants.THREE, "%"+keyword+"%");
					pstmt.setInt(Constants.FOUR, from);
					pstmt.setInt(Constants.FIVE, limit);

					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeyword || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST_WITH_LIMIT));
					}
				}
				
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST_WITHOUT_LIMIT));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setString(Constants.THREE, "%"+keyword+"%");
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeyword || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST_WITHOUT_LIMIT));
					}
				}
				
				else {
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					String actualvalue = "";
					if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
						actualvalue = keyword;
						actualvalue = actualvalue.replace("&", "&amp;");
						actualvalue = actualvalue.replace("'", "&#39;");
						actualvalue = actualvalue.replace("<", "&lt;");
						actualvalue = actualvalue.replace(">", "&gt;");
						actualvalue = actualvalue.replace("\"", "&quot;");
					}else{
						actualvalue = keyword;
					}
					pstmt.setString(Constants.TWO, "%"+actualvalue+"%");
					pstmt.setString(Constants.THREE, "%"+keyword+"%");

					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeyword || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_GUEST));
					}
				}
				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					
					Long assetInstId = rs.getLong("asset_inst_id");
					String assetName = rs.getString("asset_name");
					String assetInstName = rs.getString("asset_inst_name");
					String assetInstDesc = rs.getString("description");
					Long aivId = rs.getLong("asset_instance_version_id");
					boolean versionable = rs.getBoolean("versionable");
					
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isAssetInstDescExists = StringUtils.containsIgnoreCase(assetInstDesc, keyword);
					
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeyword || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeyword || " + assetInstName + "is matched");
						}
					}
					
					if(isAssetInstDescExists){
						matchedWordsMap.put(Constants.ASSET_INST_DESC_MATCHED, assetInstDesc);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeyword || " + assetInstDesc + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					ai = new QuickSearch();
					ai.setSearchBy("Asset Instance");
					ai.setAssetInstId(assetInstId);
					ai.setAssetName(assetName);
					ai.setAssetInstName(assetInstName);
					ai.setAssetInstDescription(assetInstDesc);
					ai.setAssetInstVersionId(aivId);
					ai.setAssetInstanceMap(combinedMatchedResult);
					ai.setAssetDescription(rs.getString("assetdescription"));
					ai.setAssetId(rs.getLong("asset_id"));
					ai.setVersionable(versionable);
					if(versionable){
						ai.setVersionName(rs.getString("version_name"));
					}else{
						ai.setVersionName("N/A");
					}
					
					searchList.add(ai);
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeyword || "+ ai.toString());
					}
				}
				if(log.isDebugEnabled()){
					log.debug("getAssetInstanceMatchedWithKeyword || "+ searchList.toString());
				}
			}
			else{
				//checking for admin rights
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				
				pstmt.setString(Constants.ONE, userName);
				
				if (log.isTraceEnabled()) {
					log.trace("getAssetsMatchedWithKeyword || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				}

				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					adminAccessName = new AdminAccessName();
					adminAccessName.setUserName(rs.getString("user_name"));
					adminAccessName.setGroupName(rs.getString("group_name"));
					adminAccessName.setRoleName(rs.getString("role_name"));
					adminAccessNameList.add(adminAccessName);
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeyword || returning resultset for admin "
								+ "check : "+ adminAccessName.toString());
					}
				}
				if(log.isDebugEnabled()){
					log.debug("getAssetInstanceMatchedWithKeyword || "+ adminAccessNameList.toString());
				}

				for (AdminAccessName adminAccess : adminAccessNameList) {
					if (adminAccess.getUserName().equalsIgnoreCase("admin")
							|| adminAccess.getGroupName().equalsIgnoreCase("group-admin")
							|| adminAccess.getRoleName().equalsIgnoreCase("role-admin")) {
						flag = true;
					}
				}
				
				//admin users
				if(flag){
					if(restApiFlag == true) {
												
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_WITH_LIMIT));
						
						pstm.setString(Constants.ONE, "%"+keyword+"%");
						String actualvalue = "";
						if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
								actualvalue = keyword;
								actualvalue = actualvalue.replace("&", "&amp;");
								actualvalue = actualvalue.replace("'", "&#39;");
								actualvalue = actualvalue.replace("<", "&lt;");
								actualvalue = actualvalue.replace(">", "&gt;");
								actualvalue = actualvalue.replace("\"", "&quot;");
						}else{
							actualvalue = keyword;
						}
						pstm.setString(Constants.TWO, "%"+actualvalue+"%");
						pstm.setString(Constants.THREE, "%"+keyword+"%");
						pstm.setInt(Constants.FOUR, from);
						pstm.setInt(Constants.FIVE, limit);
						
						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeyword || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_WITH_LIMIT));
						}
					}
					
					else if(restApiFlagWithoutLimit == true) {
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_WITHOUT_LIMIT));
						
						pstm.setString(Constants.ONE, "%"+keyword+"%");
						String actualvalue = "";
						if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
								actualvalue = keyword;
								actualvalue = actualvalue.replace("&", "&amp;");
								actualvalue = actualvalue.replace("'", "&#39;");
								actualvalue = actualvalue.replace("<", "&lt;");
								actualvalue = actualvalue.replace(">", "&gt;");
								actualvalue = actualvalue.replace("\"", "&quot;");
						}else{
							actualvalue = keyword;
						}
						pstm.setString(Constants.TWO, "%"+actualvalue+"%");
						pstm.setString(Constants.THREE, "%"+keyword+"%");
												
						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeyword || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_WITHOUT_LIMIT));
						}
					}
					else {
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE));

						pstm.setString(Constants.ONE, "%"+keyword+"%");
						String actualvalue = "";
						if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
							actualvalue = keyword;
							actualvalue = actualvalue.replace("&", "&amp;");
							actualvalue = actualvalue.replace("'", "&#39;");
							actualvalue = actualvalue.replace("<", "&lt;");
							actualvalue = actualvalue.replace(">", "&gt;");
							actualvalue = actualvalue.replace("\"", "&quot;");
						}else{
							actualvalue = keyword;
						}
						pstm.setString(Constants.TWO, "%"+actualvalue+"%");
						pstm.setString(Constants.THREE, "%"+keyword+"%");

						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeyword || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE));
						}
					}
					rs1 = pstm.executeQuery();
				}
				//non-admin users
				else{
					
					if(restApiFlag == true) {
												
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						
						pstm.setString(Constants.ONE, userName);
						pstm.setString(Constants.TWO, "%"+keyword+"%");
						String actualvalue = "";
						if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
							actualvalue = keyword;
							actualvalue = actualvalue.replace("&", "&amp;");
							actualvalue = actualvalue.replace("'", "&#39;");
							actualvalue = actualvalue.replace("<", "&lt;");
							actualvalue = actualvalue.replace(">", "&gt;");
							actualvalue = actualvalue.replace("\"", "&quot;");
						}else{
							actualvalue = keyword;
						}
						pstm.setString(Constants.THREE, "%"+actualvalue+"%");
						pstm.setString(Constants.FOUR, "%"+keyword+"%");
						pstm.setInt(Constants.FIVE, from);
						pstm.setInt(Constants.SIX, limit);
				
						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeyword || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						}
					}
					
					else if(restApiFlagWithoutLimit == true) {
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						
						pstm.setString(Constants.ONE, userName);
						pstm.setString(Constants.TWO, "%"+keyword+"%");
						String actualvalue = "";
						if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
							actualvalue = keyword;
							actualvalue = actualvalue.replace("&", "&amp;");
							actualvalue = actualvalue.replace("'", "&#39;");
							actualvalue = actualvalue.replace("<", "&lt;");
							actualvalue = actualvalue.replace(">", "&gt;");
							actualvalue = actualvalue.replace("\"", "&quot;");
						}else{
							actualvalue = keyword;
						}
						pstm.setString(Constants.THREE, "%"+actualvalue+"%");
						pstm.setString(Constants.FOUR, "%"+keyword+"%");
										
						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeyword || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						}
					}
					else {
						pstm = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
								Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS));

						pstm.setString(Constants.ONE, userName);
						pstm.setString(Constants.TWO, "%"+keyword+"%");
						String actualvalue = "";
						if (keyword.contains("&")||keyword.contains("'")||keyword.contains("<")||keyword.contains(">")||keyword.contains("\"")){
							actualvalue = keyword;
							actualvalue = actualvalue.replace("&", "&amp;");
							actualvalue = actualvalue.replace("'", "&#39;");
							actualvalue = actualvalue.replace("<", "&lt;");
							actualvalue = actualvalue.replace(">", "&gt;");
							actualvalue = actualvalue.replace("\"", "&quot;");
						}else{
							actualvalue = keyword;
						}
						pstm.setString(Constants.THREE, "%"+actualvalue+"%");
						pstm.setString(Constants.FOUR, "%"+keyword+"%");

						if (log.isTraceEnabled()) {
							log.trace("getAssetInstanceMatchedWithKeyword || "
									+ PropertyFileReader.getInstance().getValue(
											Constants.RET_ALL_MATCHED_ASSET_INSTANCE_FOR_ACCESS_RIGHTS));
						}
					}
					rs1 = pstm.executeQuery();	
				}
				
				while (rs1.next()) {
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					
					Long assetInstId = rs1.getLong("asset_inst_id");
					String assetName = rs1.getString("asset_name");
					String assetInstName = rs1.getString("asset_inst_name");
					String assetInstDesc = rs1.getString("description");
					Long aivId = rs1.getLong("asset_instance_version_id");
					boolean versionable = rs1.getBoolean("versionable");
					
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isAssetInstDescExists = StringUtils.containsIgnoreCase(assetInstDesc, keyword);
					
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeyword || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeyword || " + assetInstName + "is matched");
						}
					}
					
					if(isAssetInstDescExists){
						matchedWordsMap.put(Constants.ASSET_INST_DESC_MATCHED, assetInstDesc);
						if (log.isDebugEnabled()) {
							log.debug("getAssetInstanceMatchedWithKeyword || " + assetInstDesc + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					ai = new QuickSearch();
					ai.setSearchBy("Asset Instance");
					ai.setAssetInstId(assetInstId);
					ai.setAssetName(assetName);
					ai.setAssetInstName(assetInstName);
					ai.setAssetInstDescription(assetInstDesc);
					ai.setAssetInstVersionId(aivId);
					ai.setAssetInstanceMap(combinedMatchedResult);
					ai.setAssetDescription(rs1.getString("assetdescription"));
					ai.setAssetId(rs1.getLong("asset_id"));
					ai.setVersionable(versionable);
					if(versionable){
						ai.setVersionName(rs1.getString("version_name"));
					}else{
						ai.setVersionName("N/A");
					}
					
					searchList.add(ai);
					
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeyword || "+ ai.toString());
					}
					
				}
								
				if(log.isDebugEnabled()){
					log.debug("getAssetInstanceMatchedWithKeyword || "+ searchList.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getAssetInstanceMatchedWithKeyword || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.ASSET_INSTANCE_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetInstanceMatchedWithKeyword || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetInstanceMatchedWithKeyword || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetInstanceMatchedWithKeyword || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs1);
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstm);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstanceMatchedWithKeyword || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAssetInstanceMatchedWithKeyword || End ");
		}
		return searchList;
	}
	
	/**
	 * @method : getParametersMatchedWithKeyword
	 * @param keyword
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<QuickSearch> getParametersMatchedWithKeyword(String keyword, String userName, 
			Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getParametersMatchedWithKeyword || Begin with searchString : "+ keyword 
					+"\t username : "+userName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		
		boolean flag = false;
		
		AdminAccessName adminAccessName = null;
		QuickSearch apd = null;
		AssetDao assetDao = new AssetDao();
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		List<QuickSearch> paramsList = new ArrayList<QuickSearch>();
		
		ArrayList<String> textParamValues = new ArrayList<String>();
		ArrayList<String> richTextParamValues = new ArrayList<String>();
		ArrayList<String> dateValues = new ArrayList<String>();
		ArrayList<String> fileValues = new ArrayList<String>();
		ArrayList<String> ldapMappingValues = new ArrayList<String>();
		try {
			if (log.isTraceEnabled()){
				log.trace("getParametersMatchedWithKeyword || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			//keyword = keyword.replace("*","");
			
			//guest user
			if (userName.equalsIgnoreCase("roleAnonymous")){
				
				if(restApiFlag == true) {
										
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_PARAMETER_FOR_GUEST_WITH_LIMIT));
			
					pstmt.setString(Constants.ONE, "Guest");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
					pstmt.setString(Constants.THREE, "%"+keyword+"%");
					pstmt.setString(Constants.FOUR, "%"+keyword+"%");
					pstmt.setString(Constants.FIVE, "%"+keyword+"%");
					pstmt.setString(Constants.SIX, "Guest");
					pstmt.setString(Constants.SEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.EIGHT, "%"+keyword+"%");
					pstmt.setString(Constants.NINE, "%"+keyword+"%");
					pstmt.setString(Constants.TEN, "%"+keyword+"%");
					pstmt.setInt(Constants.ELEVEN, from);
					pstmt.setInt(Constants.TWELVE, limit);
			
					if (log.isTraceEnabled()) {
						log.trace("getParametersMatchedWithKeyword || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_GUEST_WITH_LIMIT));
					}
				}
				
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_PARAMETER_FOR_GUEST_WITHOUT_LIMIT));
			
					pstmt.setString(Constants.ONE, "Guest");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
					pstmt.setString(Constants.THREE, "%"+keyword+"%");
					pstmt.setString(Constants.FOUR, "%"+keyword+"%");
					pstmt.setString(Constants.FIVE, "%"+keyword+"%");
					pstmt.setString(Constants.SIX, "Guest");
					pstmt.setString(Constants.SEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.EIGHT, "%"+keyword+"%");
					pstmt.setString(Constants.NINE, "%"+keyword+"%");
					pstmt.setString(Constants.TEN, "%"+keyword+"%");
								
					if (log.isTraceEnabled()) {
						log.trace("getParametersMatchedWithKeyword || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_GUEST_WITHOUT_LIMIT));
					}
				}
				
				else {
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_PARAMETER_FOR_GUEST));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
					pstmt.setString(Constants.THREE, "%"+keyword+"%");
					pstmt.setString(Constants.FOUR, "%"+keyword+"%");
					//pstmt.setString(Constants.FIVE, "%"+keyword+"%");
					pstmt.setString(Constants.FIVE, "Guest");

					if (log.isTraceEnabled()) {
						log.trace("getParametersMatchedWithKeyword || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_GUEST));
					}
				}
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					HashMap<String, Object> paramMap = new HashMap<String, Object>();
					
					String assetName = rs.getString("asset_name");
					String assetInstName = rs.getString("asset_inst_name");
					Long aivId = rs.getLong("asset_instance_version_id");
					String versionName = rs.getString("version_name");
					String assetParamName = rs.getString("asset_param_name");
					String value = rs.getString("value");
					boolean versionable = rs.getBoolean("versionable");
					String assetInstDesc = rs.getString("description");
					Long paramTypeId = rs.getLong("param_type_id");
					String fileName = rs.getString("fileName");
					Long apdId = rs.getLong("asset_param_id");
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isVersionNameExists = StringUtils.containsIgnoreCase(versionName, keyword);
					boolean isValueExists = StringUtils.containsIgnoreCase(value, keyword);
					int ldapAttributeId = rs.getInt("ldap_attribute_id");
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeyword || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeyword || " + assetInstName + "is matched");
						}
					}
					
					if(isVersionNameExists){
						matchedWordsMap.put(Constants.VERSION_NAME_MATCHED, versionName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeyword || " + versionName + "is matched");
						}
					}
					if(isValueExists){
						matchedWordsMap.put(Constants.VALUE_MATCHED, value);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeyword || " + value + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					apd = new QuickSearch();
					
					if(paramsList.size()>0){
						int lastIndex = paramsList.size()-1;
						Long assetParamId = paramsList.get(lastIndex).getAssetParamId();
						if(rs.getLong("asset_param_id")==assetParamId && rs.getLong("asset_instance_version_id")==paramsList.get(lastIndex).getAssetInstVersionId()){
							apd = paramsList.get(lastIndex);
							paramMap = apd.getParamMap()!= null?apd.getParamMap():paramMap;
							if(rs.getLong("param_type_id") == 7L){
								richTextParamValues = (ArrayList<String>) paramsList.get(lastIndex).getParamValues();
								if(richTextParamValues != null){
									richTextParamValues.add(rs.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,richTextParamValues);
								}
							}else if(rs.getLong("param_type_id") == 1L){
								textParamValues = (ArrayList<String>) paramsList.get(lastIndex).getTextValues();
								if(textParamValues != null){
									textParamValues.add(rs.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,textParamValues);
								}
							}else if(rs.getLong("param_type_id") == 9L){
								ldapMappingValues = (ArrayList<String>) paramsList.get(lastIndex).getLdapMappingValues();
								if(ldapMappingValues != null){
									LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
									ldapMappingValues.add(ldapMapping.getAttributeDisplayName()+":"+rs.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,ldapMappingValues);
								}
							}
							apd.setAssetParamId(apdId);
							apd.setParamMap(paramMap);
							paramsList.set(lastIndex, apd);
							continue;
						}
						else if(rs.getLong("asset_instance_version_id")==paramsList.get(lastIndex).getAssetInstVersionId()){
							apd = paramsList.get(lastIndex);
							paramMap = apd.getParamMap()!= null?apd.getParamMap():paramMap;
							if(rs.getLong("param_type_id") == 7L){
								richTextParamValues = new ArrayList<String>();
								if(richTextParamValues != null){
									richTextParamValues.add(rs.getString("value"));
									apd.setParamValues(richTextParamValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,richTextParamValues);
								}
							}else if(rs.getLong("param_type_id") == 1L){
								textParamValues = new ArrayList<String>();
								if(textParamValues != null){
									textParamValues.add(rs.getString("value"));
									apd.setTextValues(textParamValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,textParamValues);
								}
							}else if(rs.getLong("param_type_id") == 9L){
								ldapMappingValues = new ArrayList<String>();
								if(ldapMappingValues != null){
									LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
									ldapMappingValues.add(ldapMapping.getAttributeDisplayName()+":"+rs.getString("value"));
									apd.setLdapMappingValues(ldapMappingValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,ldapMappingValues);
								}
							}
							else if(rs.getLong("param_type_id") == 2L){
								dateValues = new ArrayList<String>();
								if(dateValues != null){
									dateValues.add(rs.getString("value"));
									apd.setDateValues(dateValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,dateValues);
								}
							}else if(rs.getLong("param_type_id") == 3L){
								fileValues = new ArrayList<String>();
								if(fileValues != null){
									fileValues.add(rs.getString("fileName"));
									apd.setFileValues(fileValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,fileValues);
								}
							}else {
								apd.setParamValue(value);
								paramMap.put(assetParamName+"`~`"+paramTypeId, value);
							}
							apd.setAssetParamId(apdId);
							apd.setParamMap(paramMap);
							paramsList.set(lastIndex, apd);
							continue;
						}
					}
					ArrayList<String> ldapMappingValues1 = new ArrayList<String>();
					ArrayList<String> textParamValues1 = new ArrayList<String>();
					ArrayList<String> richTextParamValues1 = new ArrayList<String>();
					ArrayList<String> dateValues1 = new ArrayList<String>();
					ArrayList<String> fileValues1 = new ArrayList<String>();
					
					if(rs.getLong("param_type_id") == 7L){
						
						richTextParamValues1.add(rs.getString("value"));
						apd.setParamValues(richTextParamValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, richTextParamValues1);
						
					}else if(rs.getLong("param_type_id") == 1L){
						
						textParamValues1.add(rs.getString("value"));
						apd.setTextValues(textParamValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, textParamValues1);
						
					}else if(rs.getLong("param_type_id") == 9L){
						LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
						ldapMappingValues1.add(ldapMapping.getAttributeDisplayName()+":"+rs.getString("value"));
						apd.setLdapMappingValues(ldapMappingValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, ldapMappingValues1);
						
					}else if(paramTypeId == 3L){
						fileValues1.add(rs.getString("fileName"));
						apd.setFileValues(fileValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, fileValues1);
						
					}else if(paramTypeId == 2L){
						dateValues1.add(rs.getString("value"));
						apd.setDateValues(dateValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, dateValues1);
					}else{
						apd.setParamValue(value);
						paramMap.put(assetParamName+"`~`"+paramTypeId, value);
					}
					
					apd.setSearchBy("Asset Instance");
					apd.setAssetName(assetName);
					apd.setAssetInstName(assetInstName);
					apd.setAssetInstVersionId(aivId);
					apd.setAssetInstDescription(assetInstDesc);
					apd.setAssetParamName(assetParamName);
					apd.setVersionable(versionable);
					apd.setAssetDescription(rs.getString("assetdescription"));
					apd.setAssetId(rs.getLong("asset_id"));
					apd.setAssetInstId(rs.getLong("asset_inst_id"));
					apd.setAssetParamId(apdId);
					/*if(paramTypeId == 3){//3 is file type
						apd.setFileName(fileName);
						paramMap.put(assetParamName+"`~`"+paramTypeId, fileName);
					}else{
						apd.setParamValue(value);
					}*/
					apd.setParamTypeId(paramTypeId);
					//paramMap.put(assetParamName+"`~`"+paramTypeId, value);
										
					apd.setParameterMap(combinedMatchedResult);
					
					if(versionable){
						apd.setVersionName(rs.getString("version_name"));
					}else{
						apd.setVersionName("N/A");
					}
					apd.setParamMap(paramMap);
					paramsList.add(apd);
					
					if (log.isTraceEnabled()) {
						log.trace("getParametersMatchedWithKeyword || "+ apd.toString());
					}
					
				}
				if(log.isDebugEnabled()){
					log.debug("getParametersMatchedWithKeyword || "+ paramsList.toString());
				}
			}
			else{
				//checking for admin rights
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				
				pstmt.setString(Constants.ONE, userName);
				
				if (log.isTraceEnabled()) {
					log.trace("getParametersMatchedWithKeyword || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				}

				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					adminAccessName = new AdminAccessName();
					adminAccessName.setUserName(rs.getString("user_name"));
					adminAccessName.setGroupName(rs.getString("group_name"));
					adminAccessName.setRoleName(rs.getString("role_name"));
					adminAccessNameList.add(adminAccessName);
					if (log.isTraceEnabled()) {
						log.trace("getParametersMatchedWithKeyword || returning resultset for admin check : "
								+ adminAccessName.toString());
					}
				}

				for (AdminAccessName adminAccess : adminAccessNameList) {
					if (adminAccess.getUserName().equalsIgnoreCase("admin")
							|| adminAccess.getGroupName().equalsIgnoreCase("group-admin")
							|| adminAccess.getRoleName().equalsIgnoreCase("role-admin")) {
						flag = true;
					}
				}
				
				//admin	users
				if(flag){
					
					if(restApiFlag == true) {
												
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_WITH_LIMIT));
						
						pstmt1.setString(Constants.ONE, "%"+keyword+"%");
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setString(Constants.SIX, "%"+keyword+"%");
						pstmt1.setString(Constants.SEVEN, "%"+keyword+"%");
						pstmt1.setString(Constants.EIGHT, "%"+keyword+"%");
						//pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setInt(Constants.NINE, from);
						pstmt1.setInt(Constants.TEN, limit);
						
						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeyword || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_WITH_LIMIT));
						}
					}
					else if(restApiFlagWithoutLimit == true) {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_WITHOUT_LIMIT));
						
						pstmt1.setString(Constants.ONE, "%"+keyword+"%");
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setString(Constants.SIX, "%"+keyword+"%");
						pstmt1.setString(Constants.SEVEN, "%"+keyword+"%");
						pstmt1.setString(Constants.EIGHT, "%"+keyword+"%");
						//pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
												
						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeyword || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_WITHOUT_LIMIT));
						}
					}
					
					else {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER));

						pstmt1.setString(Constants.ONE, "%"+keyword+"%");
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						//pstmt1.setString(Constants.FIVE, "%"+keyword+"%");

						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeyword || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER));
						}
					}
					rs1 = pstmt1.executeQuery();
					
				}
				//non-admin users
				else{
					
					if(restApiFlag == true) {
												
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						
						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setString(Constants.SIX, userName);
						pstmt1.setString(Constants.SEVEN, "%"+keyword+"%");
						pstmt1.setString(Constants.EIGHT, "%"+keyword+"%");
						pstmt1.setString(Constants.NINE, "%"+keyword+"%");
						pstmt1.setString(Constants.TEN, "%"+keyword+"%");
						//pstmt1.setString(Constants.SIX, "%"+keyword+"%");
						pstmt1.setInt(Constants.ELEVEN, from);
						pstmt1.setInt(Constants.TWELVE, limit);
						
						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeyword || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						}
					}
					
					else if(restApiFlagWithoutLimit == true) {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						
						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setString(Constants.SIX, userName);
						pstmt1.setString(Constants.SEVEN, "%"+keyword+"%");
						pstmt1.setString(Constants.EIGHT, "%"+keyword+"%");
						pstmt1.setString(Constants.NINE, "%"+keyword+"%");
						pstmt1.setString(Constants.TEN, "%"+keyword+"%");
						//pstmt1.setString(Constants.SIX, "%"+keyword+"%");
												
						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeyword || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						}
					}
					else {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS));

						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						//pstmt1.setString(Constants.SIX, "%"+keyword+"%");

						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeyword || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ACCESS_RIGHTS));
						}
					}
					rs1 = pstmt1.executeQuery();
					
				}
				
				while(rs1.next()){
					
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					HashMap<String, Object> paramMap = new HashMap<String, Object>();
					
					String assetName = rs1.getString("asset_name");
					String assetInstName = rs1.getString("asset_inst_name");
					Long aivId = rs1.getLong("asset_instance_version_id");
					String versionName = rs1.getString("version_name");
					String assetParamName = rs1.getString("asset_param_name");
					String value = rs1.getString("value");
					boolean versionable = rs1.getBoolean("versionable");
					String assetInstDesc = rs1.getString("description");
					Long paramTypeId = rs1.getLong("param_type_id");
					String fileName = rs1.getString("fileName");
					Long apdId = rs1.getLong("asset_param_id");
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isVersionNameExists = StringUtils.containsIgnoreCase(versionName, keyword);
					boolean isValueExists = StringUtils.containsIgnoreCase(value, keyword);
					int ldapAttributeId = rs1.getInt("ldap_attribute_id");
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeyword || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeyword || " + assetInstName + "is matched");
						}
					}
					
					if(isVersionNameExists){
						matchedWordsMap.put(Constants.VERSION_NAME_MATCHED, versionName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeyword || " + versionName + "is matched");
						}
					}
					if(isValueExists){
						matchedWordsMap.put(Constants.VALUE_MATCHED, value);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeyword || " + value + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					apd = new QuickSearch();
					
					if(paramsList.size()>0){
						int lastIndex = paramsList.size()-1;
						Long assetParamId = paramsList.get(lastIndex).getAssetParamId();
						if(rs1.getLong("asset_param_id")==assetParamId && rs1.getLong("asset_instance_version_id")==paramsList.get(lastIndex).getAssetInstVersionId()){
							apd = paramsList.get(lastIndex);
							paramMap = apd.getParamMap()!= null?apd.getParamMap():paramMap;
							if(rs1.getLong("param_type_id") == 7L){
								richTextParamValues = (ArrayList<String>) paramsList.get(lastIndex).getParamValues();
								if(richTextParamValues != null){
									richTextParamValues.add(rs1.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,richTextParamValues);
								}
							}else if(rs1.getLong("param_type_id") == 1L){
								textParamValues = (ArrayList<String>) paramsList.get(lastIndex).getTextValues();
								if(textParamValues != null){
									textParamValues.add(rs1.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,textParamValues);
								}
							}else if(rs1.getLong("param_type_id") == 9L){
								ldapMappingValues = (ArrayList<String>) paramsList.get(lastIndex).getLdapMappingValues();
								if(ldapMappingValues != null){
									LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
									ldapMappingValues.add(ldapMapping.getAttributeDisplayName()+":"+rs1.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,ldapMappingValues);
								}
							}
							apd.setAssetParamId(apdId);
							apd.setParamMap(paramMap);
							paramsList.set(lastIndex, apd);
							continue;
						}
						else if(rs1.getLong("asset_instance_version_id")==paramsList.get(lastIndex).getAssetInstVersionId()){
							apd = paramsList.get(lastIndex);
							paramMap = apd.getParamMap()!= null?apd.getParamMap():paramMap;
							if(rs1.getLong("param_type_id") == 7L){
								richTextParamValues = new ArrayList<String>();
								if(richTextParamValues != null){
									richTextParamValues.add(rs1.getString("value"));
									apd.setParamValues(richTextParamValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,richTextParamValues);
								}
							}else if(rs1.getLong("param_type_id") == 1L){
								textParamValues = new ArrayList<String>();
								if(textParamValues != null){
									textParamValues.add(rs1.getString("value"));
									apd.setTextValues(textParamValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,textParamValues);
								}
							}else if(rs1.getLong("param_type_id") == 9L){
								ldapMappingValues = new ArrayList<String>();
								if(ldapMappingValues != null){
									LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
									ldapMappingValues.add(ldapMapping.getAttributeDisplayName()+":"+rs1.getString("value"));
									apd.setLdapMappingValues(ldapMappingValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,ldapMappingValues);
								}
							}else if(rs1.getLong("param_type_id") == 2L){
								dateValues = new ArrayList<String>();
								if(dateValues != null){
									dateValues.add(rs1.getString("value"));
									apd.setDateValues(dateValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,dateValues);
								}
							}else if(rs1.getLong("param_type_id") == 3L){
								fileValues = new ArrayList<String>();
								if(fileValues != null){
									fileValues.add(rs1.getString("fileName"));
									apd.setFileValues(fileValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,fileValues);
								}
							}else {
								apd.setParamValue(value);
								paramMap.put(assetParamName+"`~`"+paramTypeId, value);
							}
							apd.setAssetParamId(apdId);
							apd.setParamMap(paramMap);
							paramsList.set(lastIndex, apd);
							continue;
						}
					}
					
					ArrayList<String> ldapMappingValues1 = new ArrayList<String>();
					ArrayList<String> textParamValues1 = new ArrayList<String>();
					ArrayList<String> richTextParamValues1 = new ArrayList<String>();
					ArrayList<String> dateValues1 = new ArrayList<String>();
					ArrayList<String> fileValues1 = new ArrayList<String>();
					
					if(rs1.getLong("param_type_id") == 7L){
						
						richTextParamValues1.add(rs1.getString("value"));
						apd.setParamValues(richTextParamValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, richTextParamValues1);
						
					}else if(rs1.getLong("param_type_id") == 1L){
						
						textParamValues1.add(rs1.getString("value"));
						apd.setTextValues(textParamValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, textParamValues1);
						
					}else if(rs1.getLong("param_type_id") == 9L){
						LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
						ldapMappingValues1.add(ldapMapping.getAttributeDisplayName()+":"+rs1.getString("value"));
						apd.setLdapMappingValues(ldapMappingValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, ldapMappingValues1);
						
					}else if(paramTypeId == 3L){
						fileValues1.add(rs1.getString("fileName"));
						apd.setFileValues(fileValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, fileValues1);
						
					}else if(paramTypeId == 2L){
						dateValues1.add(rs1.getString("value"));
						apd.setDateValues(dateValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, dateValues1);
					}
					else{
						apd.setParamValue(value);
						paramMap.put(assetParamName+"`~`"+paramTypeId, value);
					}
					
					apd.setSearchBy("Asset Instance");
					apd.setAssetName(assetName);
					apd.setAssetInstName(assetInstName);
					apd.setAssetInstVersionId(aivId);
					apd.setAssetInstDescription(assetInstDesc);
					apd.setAssetParamName(assetParamName);
					apd.setVersionable(versionable);
					apd.setAssetParamId(apdId);
					apd.setAssetDescription(rs1.getString("assetdescription"));
					apd.setAssetId(rs1.getLong("asset_id"));
					apd.setAssetInstId(rs1.getLong("asset_inst_id"));
					/*if(paramTypeId == 3){//3 is file type
						apd.setFileName(fileName);
						paramMap.put(assetParamName+"`~`"+paramTypeId, fileName);
					}else{
						apd.setParamValue(value);
						paramMap.put(assetParamName+"`~`"+paramTypeId, value);
					}*/
					apd.setParamTypeId(paramTypeId);
					
					apd.setParameterMap(combinedMatchedResult);
					
					if(versionable){
						apd.setVersionName(rs1.getString("version_name"));
					}else{
						apd.setVersionName("N/A");
					}
					apd.setParamMap(paramMap);
					paramsList.add(apd);
					
					if (log.isTraceEnabled()) {
						log.trace("getParametersMatchedWithKeyword || "+ apd.toString());
					}
					
				}
				
				if(log.isDebugEnabled()){
					log.debug("getParametersMatchedWithKeyword || "+ paramsList.toString());
				}
			}
				
			
		} catch (SQLException e) {
			log.error("getParametersMatchedWithKeyword || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getParametersMatchedWithKeyword || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getParametersMatchedWithKeyword || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getParametersMatchedWithKeyword || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs1);
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt1);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getParametersMatchedWithKeyword || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getParametersMatchedWithKeyword || End ");
		}
		
		return paramsList;
	}
	
	
	/**
	 * @method : getParametersMatchedWithKeywordForAssetType
	 * @param keyword
	 * @param options
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<QuickSearch> getParametersMatchedWithKeywordForAssetType(String keyword, String options,
			String userName, Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getParametersMatchedWithKeywordForAssetType || begin with searchString : "
					+ keyword +" \t assetType : "+ options +" \t username : "+ userName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		
		boolean flag = false;
		
		QuickSearch apd = null;
		AdminAccessName adminAccessName = null;
		AssetDao assetDao = new AssetDao();
		List<QuickSearch> paramsList = new ArrayList<QuickSearch>();
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		
		ArrayList<String> ldapMappingValues = new ArrayList<String>();
		ArrayList<String> textParamValues = new ArrayList<String>();
		ArrayList<String> richTextParamValues = new ArrayList<String>();
		ArrayList<String> dateValues = new ArrayList<String>();
		ArrayList<String> fileValues = new ArrayList<String>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getParametersMatchedWithKeywordForAssetType || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			//keyword = keyword.replace("*","");
			
			//guest user
			if (userName.equalsIgnoreCase("roleAnonymous")){
				
				if(restApiFlag == true) {
										
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT));
			
					pstmt.setString(Constants.ONE, options);
					pstmt.setString(Constants.TWO, "Guest");
					pstmt.setString(Constants.THREE, "%"+keyword+"%");
					pstmt.setString(Constants.FOUR, "%"+keyword+"%");
					pstmt.setString(Constants.FIVE, "%"+keyword+"%");
					pstmt.setString(Constants.SIX, "%"+keyword+"%");
					pstmt.setString(Constants.SEVEN, options);
					pstmt.setString(Constants.EIGHT, "Guest");
					pstmt.setString(Constants.NINE, "%"+keyword+"%");
					pstmt.setString(Constants.TEN, "%"+keyword+"%");
					pstmt.setString(Constants.ELEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.TWELVE, "%"+keyword+"%");
					pstmt.setInt(Constants.THIRTEEN, from);
					pstmt.setInt(Constants.FOURTEEN, limit);

					
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeyword || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST_WITH_LIMIT));
					}
				}
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT));
			
					pstmt.setString(Constants.ONE, options);
					pstmt.setString(Constants.TWO, "Guest");
					pstmt.setString(Constants.THREE, "%"+keyword+"%");
					pstmt.setString(Constants.FOUR, "%"+keyword+"%");
					pstmt.setString(Constants.FIVE, "%"+keyword+"%");
					pstmt.setString(Constants.SIX, "%"+keyword+"%");
					pstmt.setString(Constants.SEVEN, options);
					pstmt.setString(Constants.EIGHT, "Guest");
					pstmt.setString(Constants.NINE, "%"+keyword+"%");
					pstmt.setString(Constants.TEN, "%"+keyword+"%");
					pstmt.setString(Constants.ELEVEN, "%"+keyword+"%");
					pstmt.setString(Constants.TWELVE, "%"+keyword+"%");
										
					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeyword || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST_WITHOUT_LIMIT));
					}
				}
				else {
					pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(
							Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
					pstmt.setString(Constants.THREE, "%"+keyword+"%");
					pstmt.setString(Constants.FOUR, "%"+keyword+"%");
					//pstmt.setString(Constants.FIVE, "%"+keyword+"%");
					pstmt.setString(Constants.FIVE, options);
					pstmt.setString(Constants.SIX, options);
					pstmt.setString(Constants.SEVEN, "Guest");


					if (log.isTraceEnabled()) {
						log.trace("getAssetInstanceMatchedWithKeyword || "+ PropertyFileReader.
								getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_GUEST));
					}
				}
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					HashMap<String, Object> paramMap = new HashMap<String, Object>();
					
					String assetName = rs.getString("asset_name");
					String assetInstName = rs.getString("asset_inst_name");
					Long aivId = rs.getLong("asset_instance_version_id");
					String versionName = rs.getString("version_name");
					String assetParamName = rs.getString("asset_param_name");
					String value = rs.getString("value");
					boolean versionable = rs.getBoolean("versionable");
					String assetInstDesc = rs.getString("description");
					Long paramTypeId = rs.getLong("param_type_id");
					String fileName = rs.getString("fileName");
					Long apdId = rs.getLong("asset_param_id");
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isVersionNameExists = StringUtils.containsIgnoreCase(versionName, keyword);
					boolean isValueExists = StringUtils.containsIgnoreCase(value, keyword);
					int ldapAttributeId = rs.getInt("ldap_attribute_id");
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeywordForAssetType || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeywordForAssetType || " + assetInstName + "is matched");
						}
					}
					
					if(isVersionNameExists){
						matchedWordsMap.put(Constants.VERSION_NAME_MATCHED, versionName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeywordForAssetType || " + versionName + "is matched");
						}
					}
					if(isValueExists){
						matchedWordsMap.put(Constants.VALUE_MATCHED, value);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeywordForAssetType || " + value + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					apd = new QuickSearch();
					
					if(paramsList.size()>0){
						int lastIndex = paramsList.size()-1;
						Long assetParamId = paramsList.get(lastIndex).getAssetParamId();
						if(rs.getLong("asset_param_id")==assetParamId && rs.getLong("asset_instance_version_id")==paramsList.get(lastIndex).getAssetInstVersionId()){
							apd = paramsList.get(lastIndex);
							paramMap = apd.getParamMap()!= null?apd.getParamMap():paramMap;
							if(rs.getLong("param_type_id") == 7L){
								richTextParamValues = (ArrayList<String>) paramsList.get(lastIndex).getParamValues();
								if(richTextParamValues != null){
									richTextParamValues.add(rs.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,richTextParamValues);
								}
							}else if(rs.getLong("param_type_id") == 1L){
								textParamValues = (ArrayList<String>) paramsList.get(lastIndex).getTextValues();
								if(textParamValues != null){
									textParamValues.add(rs.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,textParamValues);
								}
							}else if(rs.getLong("param_type_id") == 9L){
								ldapMappingValues = (ArrayList<String>) paramsList.get(lastIndex).getLdapMappingValues();
								if(ldapMappingValues != null){
									LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
									ldapMappingValues.add(ldapMapping.getAttributeDisplayName()+":"+rs.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,ldapMappingValues);
								}
							}
							apd.setAssetParamId(apdId);
							apd.setParamMap(paramMap);
							paramsList.set(lastIndex, apd);
							continue;
						}
						else if(rs.getLong("asset_instance_version_id")==paramsList.get(lastIndex).getAssetInstVersionId()){
							apd = paramsList.get(lastIndex);
							paramMap = apd.getParamMap()!= null?apd.getParamMap():paramMap;
							if(rs.getLong("param_type_id") == 7L){
								richTextParamValues = new ArrayList<String>();
								if(richTextParamValues != null){
									richTextParamValues.add(rs.getString("value"));
									apd.setParamValues(richTextParamValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,richTextParamValues);
								}
							}else if(rs.getLong("param_type_id") == 1L){
								textParamValues = new ArrayList<String>();
								if(textParamValues != null){
									textParamValues.add(rs.getString("value"));
									apd.setTextValues(textParamValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,textParamValues);
								}
							}else if(rs.getLong("param_type_id") == 9L){
								ldapMappingValues = new ArrayList<String>();
								if(ldapMappingValues != null){
									LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
									ldapMappingValues.add(ldapMapping.getAttributeDisplayName()+":"+rs.getString("value"));
									apd.setLdapMappingValues(ldapMappingValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,ldapMappingValues);
								}
							}else if(rs.getLong("param_type_id") == 2L){
								dateValues = new ArrayList<String>();
								if(dateValues != null){
									dateValues.add(rs.getString("value"));
									apd.setDateValues(dateValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,dateValues);
								}
							}else if(rs.getLong("param_type_id") == 3L){
								fileValues = new ArrayList<String>();
								if(fileValues != null){
									fileValues.add(rs.getString("fileName"));
									apd.setFileValues(fileValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,fileValues);
								}
							}else {
								apd.setParamValue(value);
								paramMap.put(assetParamName+"`~`"+paramTypeId, value);
							}
							apd.setAssetParamId(apdId);
							apd.setParamMap(paramMap);
							paramsList.set(lastIndex, apd);
							continue;
						}
					}
					
					ArrayList<String> ldapMappingValues1 = new ArrayList<String>();
					ArrayList<String> textParamValues1 = new ArrayList<String>();
					ArrayList<String> richTextParamValues1 = new ArrayList<String>();
					ArrayList<String> dateValues1 = new ArrayList<String>();
					ArrayList<String> fileValues1 = new ArrayList<String>();
					
					if(rs.getLong("param_type_id") == 7L){
						
						richTextParamValues1.add(rs.getString("value"));
						apd.setParamValues(richTextParamValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, richTextParamValues1);
						
					}else if(rs.getLong("param_type_id") == 1L){
						
						textParamValues1.add(rs.getString("value"));
						apd.setTextValues(textParamValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, textParamValues1);
						
					}else if(rs.getLong("param_type_id") == 9L){
						LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
						ldapMappingValues1.add(ldapMapping.getAttributeDisplayName()+":"+rs.getString("value"));
						apd.setLdapMappingValues(ldapMappingValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, ldapMappingValues1);
						
					}else if(paramTypeId == 3L){
						fileValues1.add(rs.getString("fileName"));
						apd.setFileValues(fileValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, fileValues1);
						
					}else if(paramTypeId == 2L){
						dateValues1.add(rs.getString("value"));
						apd.setDateValues(dateValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, dateValues1);
					}else{
						apd.setParamValue(value);
						paramMap.put(assetParamName+"`~`"+paramTypeId, value);
					}
					
					apd.setSearchBy("Asset Instance");
					apd.setAssetName(assetName);
					apd.setAssetInstName(assetInstName);
					apd.setAssetInstVersionId(aivId);
					apd.setVersionable(versionable);
					apd.setAssetInstDescription(assetInstDesc);
					apd.setAssetParamName(assetParamName);
					apd.setAssetDescription(rs.getString("assetdescription"));
					apd.setAssetId(rs.getLong("asset_id"));
					apd.setAssetInstId(rs.getLong("asset_inst_id"));
					apd.setAssetParamId(apdId);
					/*if(paramTypeId == 3){//3 is file type
						apd.setFileName(fileName);
						paramMap.put(assetParamName+"`~`"+paramTypeId, fileName);
					}else{
						apd.setParamValue(value);
					}
					apd.setParamTypeId(paramTypeId);
					paramMap.put(assetParamName+"`~`"+paramTypeId, value);*/
					
					apd.setParamMap(paramMap);
					
					apd.setParameterMap(combinedMatchedResult);
					
					if(versionable){
						apd.setVersionName(rs.getString("version_name"));
					}else{
						apd.setVersionName("N/A");
					}
					
					paramsList.add(apd);
					
					if (log.isTraceEnabled()) {
						log.trace("getParametersMatchedWithKeywordForAssetType || "+ apd.toString());
					}
					
				}
				if(log.isDebugEnabled()){
					log.debug("getParametersMatchedWithKeywordForAssetType || "+ paramsList.toString());
				}
			}
			else{
				//checking for admin rights
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				
				pstmt.setString(Constants.ONE, userName);
				
				if (log.isTraceEnabled()) {
					log.trace("getParametersMatchedWithKeywordForAssetType || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				}

				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					adminAccessName = new AdminAccessName();
					adminAccessName.setUserName(rs.getString("user_name"));
					adminAccessName.setGroupName(rs.getString("group_name"));
					adminAccessName.setRoleName(rs.getString("role_name"));
					adminAccessNameList.add(adminAccessName);
					if (log.isTraceEnabled()) {
						log.trace("getParametersMatchedWithKeywordForAssetType || returning resultset for admin check : "
								+ adminAccessName.toString());
					}
				}
				
				for (AdminAccessName adminAccess : adminAccessNameList) {
					if (adminAccess.getUserName().equalsIgnoreCase("admin")
							|| adminAccess.getGroupName().equalsIgnoreCase("group-admin")
							|| adminAccess.getRoleName().equalsIgnoreCase("role-admin")) {
						flag = true;
					}
				}
				
				//admin users
				if(flag){
					
					if(restApiFlag == true) {
												
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_WITH_LIMIT));
						
						pstmt1.setString(Constants.ONE, options);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setString(Constants.SIX, options);
						pstmt1.setString(Constants.SEVEN, "%"+keyword+"%");
						pstmt1.setString(Constants.EIGHT, "%"+keyword+"%");
						pstmt1.setString(Constants.NINE, "%"+keyword+"%");
						pstmt1.setString(Constants.TEN, "%"+keyword+"%");
						pstmt1.setInt(Constants.ELEVEN, from);
						pstmt1.setInt(Constants.TWELVE, limit);
						
						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeywordForAssetType || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_WITH_LIMIT));
						}
					}
					else if(restApiFlagWithoutLimit == true) {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_WITHOUT_LIMIT));
						
						pstmt1.setString(Constants.ONE, options);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setString(Constants.SIX, options);
						pstmt1.setString(Constants.SEVEN, "%"+keyword+"%");
						pstmt1.setString(Constants.EIGHT, "%"+keyword+"%");
						pstmt1.setString(Constants.NINE, "%"+keyword+"%");
						pstmt1.setString(Constants.TEN, "%"+keyword+"%");
												
						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeywordForAssetType || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_WITHOUT_LIMIT));
						}
					}
					else {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE));

						pstmt1.setString(Constants.ONE, "%"+keyword+"%");
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						//pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, options);

						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeywordForAssetType || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE));
						}
					}
					rs1 = pstmt1.executeQuery();
					
				}
				//non-admin users
				else{
					
					if(restApiFlag == true) {
												
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						
						pstmt1.setString(Constants.ONE, options);
						pstmt1.setString(Constants.TWO, userName);
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setString(Constants.SIX, "%"+keyword+"%");
						pstmt1.setString(Constants.SEVEN, options);
						pstmt1.setString(Constants.EIGHT, userName);
						pstmt1.setString(Constants.NINE, "%"+keyword+"%");
						pstmt1.setString(Constants.TEN, "%"+keyword+"%");
						pstmt1.setString(Constants.ELEVEN, "%"+keyword+"%");
						pstmt1.setString(Constants.TWELVE, "%"+keyword+"%");
						pstmt1.setInt(Constants.THIRTEEN, from);
						pstmt1.setInt(Constants.FOURTEEN, limit);

						
						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeywordForAssetType || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						}
					}
					else if(restApiFlagWithoutLimit == true) {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						
						pstmt1.setString(Constants.ONE, options);
						pstmt1.setString(Constants.TWO, userName);
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						pstmt1.setString(Constants.SIX, "%"+keyword+"%");
						pstmt1.setString(Constants.SEVEN, options);
						pstmt1.setString(Constants.EIGHT, userName);
						pstmt1.setString(Constants.NINE, "%"+keyword+"%");
						pstmt1.setString(Constants.TEN, "%"+keyword+"%");
						pstmt1.setString(Constants.ELEVEN, "%"+keyword+"%");
						pstmt1.setString(Constants.TWELVE, "%"+keyword+"%");
												
						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeywordForAssetType || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						}
					}
					else {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS));

						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, "%"+keyword+"%");
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setString(Constants.FIVE, "%"+keyword+"%");
						//pstmt1.setString(Constants.SIX, "%"+keyword+"%");
						pstmt1.setString(Constants.SIX, options);


						if (log.isTraceEnabled()) {
							log.trace("getParametersMatchedWithKeywordForAssetType || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_MATCHED_PARAMETER_FOR_ASSET_TYPE_FOR_ACCESS_RIGHTS));
						}
					}
					rs1 = pstmt1.executeQuery();
					
				}
				
				while(rs1.next()){
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					HashMap<String, Object> paramMap = new HashMap<String, Object>();
					
					String assetName = rs1.getString("asset_name");
					String assetInstName = rs1.getString("asset_inst_name");
					Long aivId = rs1.getLong("asset_instance_version_id");
					String versionName = rs1.getString("version_name");
					String assetParamName = rs1.getString("asset_param_name");
					String value = rs1.getString("value");
					boolean versionable = rs1.getBoolean("versionable");
					String assetInstDesc = rs1.getString("description");
					Long paramTypeId = rs1.getLong("param_type_id");
					String fileName = rs1.getString("fileName");
					Long apdId = rs1.getLong("asset_param_id");
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isVersionNameExists = StringUtils.containsIgnoreCase(versionName, keyword);
					boolean isValueExists = StringUtils.containsIgnoreCase(value, keyword);
					int ldapAttributeId = rs1.getInt("ldap_attribute_id");
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeywordForAssetType || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeywordForAssetType || " + assetInstName + "is matched");
						}
					}
					
					if(isVersionNameExists){
						matchedWordsMap.put(Constants.VERSION_NAME_MATCHED, versionName);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeywordForAssetType || " + versionName + "is matched");
						}
					}
					if(isValueExists){
						matchedWordsMap.put(Constants.VALUE_MATCHED, value);
						if (log.isDebugEnabled()) {
							log.debug("getParametersMatchedWithKeywordForAssetType || " + value + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					apd = new QuickSearch();
					
					if(paramsList.size()>0){
						int lastIndex = paramsList.size()-1;
						Long assetParamId = paramsList.get(lastIndex).getAssetParamId();
						if(rs1.getLong("asset_param_id")==assetParamId && rs1.getLong("asset_instance_version_id")==paramsList.get(lastIndex).getAssetInstVersionId()){
							apd = paramsList.get(lastIndex);
							paramMap = apd.getParamMap()!= null?apd.getParamMap():paramMap;
							if(rs1.getLong("param_type_id") == 7L){
								richTextParamValues = (ArrayList<String>) paramsList.get(lastIndex).getParamValues();
								if(richTextParamValues != null){
									richTextParamValues.add(rs1.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,richTextParamValues);
								}
							}else if(rs1.getLong("param_type_id") == 1L){
								textParamValues = (ArrayList<String>) paramsList.get(lastIndex).getTextValues();
								if(textParamValues != null){
									textParamValues.add(rs1.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,textParamValues);
								}
							}else if(rs1.getLong("param_type_id") == 9L){
								ldapMappingValues = (ArrayList<String>) paramsList.get(lastIndex).getLdapMappingValues();
								if(ldapMappingValues != null){
									LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
									ldapMappingValues.add(ldapMapping.getAttributeDisplayName()+":"+rs1.getString("value"));
									paramMap.put(assetParamName+"`~`"+paramTypeId,ldapMappingValues);
								}
							}
							apd.setAssetParamId(apdId);
							apd.setParamMap(paramMap);
							paramsList.set(lastIndex, apd);
							continue;
						}
						else if(rs1.getLong("asset_instance_version_id")==paramsList.get(lastIndex).getAssetInstVersionId()){
							apd = paramsList.get(lastIndex);
							paramMap = apd.getParamMap()!= null?apd.getParamMap():paramMap;
							if(rs1.getLong("param_type_id") == 7L){
								richTextParamValues = new ArrayList<String>();
								if(richTextParamValues != null){
									richTextParamValues.add(rs1.getString("value"));
									apd.setParamValues(richTextParamValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,richTextParamValues);
								}
							}else if(rs1.getLong("param_type_id") == 1L){
								textParamValues = new ArrayList<String>();
								if(textParamValues != null){
									textParamValues.add(rs1.getString("value"));
									apd.setTextValues(textParamValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,textParamValues);
								}
							}else if(rs1.getLong("param_type_id") == 9L){
								ldapMappingValues = new ArrayList<String>();
								if(ldapMappingValues != null){
									LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
									ldapMappingValues.add(ldapMapping.getAttributeDisplayName()+":"+rs1.getString("value"));
									apd.setLdapMappingValues(ldapMappingValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,ldapMappingValues);
								}
							}
							else if(rs1.getLong("param_type_id") == 2L){
								dateValues = new ArrayList<String>();
								if(dateValues != null){
									dateValues.add(rs1.getString("value"));
									apd.setDateValues(dateValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,dateValues);
								}
							}else if(rs1.getLong("param_type_id") == 3L){
								fileValues = new ArrayList<String>();
								if(fileValues != null){
									fileValues.add(rs1.getString("fileName"));
									apd.setFileValues(fileValues);
									paramMap.put(assetParamName+"`~`"+paramTypeId,fileValues);
								}
							}else {
								apd.setParamValue(value);
								paramMap.put(assetParamName+"`~`"+paramTypeId, value);
							}
							apd.setAssetParamId(apdId);
							apd.setParamMap(paramMap);
							paramsList.set(lastIndex, apd);
							continue;
						}
					}
					
					ArrayList<String> ldapMappingValues1 = new ArrayList<String>();
					ArrayList<String> textParamValues1 = new ArrayList<String>();
					ArrayList<String> richTextParamValues1 = new ArrayList<String>();
					ArrayList<String> dateValues1 = new ArrayList<String>();
					ArrayList<String> fileValues1 = new ArrayList<String>();
					
					if(rs1.getLong("param_type_id") == 7L){
						
						richTextParamValues1.add(rs1.getString("value"));
						apd.setParamValues(richTextParamValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, richTextParamValues1);
						
					}else if(rs1.getLong("param_type_id") == 1L){
						
						textParamValues1.add(rs1.getString("value"));
						apd.setTextValues(textParamValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, textParamValues1);
						
					}else if(rs1.getLong("param_type_id") == 9L){
						LdapMapping ldapMapping = assetDao.getLdapMappingAttributeByattributeId(ldapAttributeId,conn);
						ldapMappingValues1.add(ldapMapping.getAttributeDisplayName()+":"+rs1.getString("value"));
						apd.setLdapMappingValues(ldapMappingValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, ldapMappingValues1);
						
					}else if(paramTypeId == 3L){
						fileValues1.add(rs1.getString("fileName"));
						apd.setFileValues(fileValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, fileValues1);
						
					}else if(paramTypeId == 2L){
						dateValues1.add(rs1.getString("value"));
						apd.setDateValues(dateValues1);
						paramMap.put(assetParamName+"`~`"+paramTypeId, dateValues1);
					}else{
						apd.setParamValue(value);
						paramMap.put(assetParamName+"`~`"+paramTypeId, value);
					}
					
					apd.setSearchBy("Asset Instance");
					apd.setAssetName(assetName);
					apd.setAssetInstName(assetInstName);
					apd.setAssetInstVersionId(aivId);
					apd.setAssetInstDescription(assetInstDesc);
					apd.setAssetParamName(assetParamName);
					apd.setVersionable(versionable);
					apd.setAssetDescription(rs1.getString("assetdescription"));
					apd.setAssetId(rs1.getLong("asset_id"));
					apd.setAssetInstId(rs1.getLong("asset_inst_id"));
					apd.setAssetParamId(apdId);
					/*if(paramTypeId == 3){//3 is file type
						apd.setFileName(fileName);
						paramMap.put(assetParamName+"`~`"+paramTypeId, fileName);
					}else{
						apd.setParamValue(value);
					}
					apd.setParamTypeId(paramTypeId);
					paramMap.put(assetParamName+"`~`"+paramTypeId, value);*/
					
					apd.setParamMap(paramMap);
					
					apd.setParameterMap(combinedMatchedResult);
					
					if(versionable){
						apd.setVersionName(rs1.getString("version_name"));
					}else{
						apd.setVersionName("N/A");
					}
					
					paramsList.add(apd);
					
					if (log.isTraceEnabled()) {
						log.trace("getParametersMatchedWithKeywordForAssetType || "+ apd.toString());
					}
					
				}
				if(log.isDebugEnabled()){
					log.debug("getParametersMatchedWithKeywordForAssetType || "+ paramsList.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getParametersMatchedWithKeywordForAssetType || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.PARAMETER_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getParametersMatchedWithKeywordForAssetType || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getParametersMatchedWithKeywordForAssetType || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getParametersMatchedWithKeywordForAssetType || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs1);
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt1);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getParametersMatchedWithKeywordForAssetType || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getParametersMatchedWithKeywordForAssetType || End ");
		}
		return paramsList;
	}
	
	
	
	/**
	 * @method : getAllassignedAssetInstanceTagging
	 * @param keyword
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<QuickSearch> getAllassignedAssetInstanceTagging(String keyword,
			String userName,Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllassignedAssetInstanceTagging || Begin with searchString : "+ keyword 
					+"\t username : "+userName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		
		QuickSearch ai = null;
		AdminAccessName adminAccessName = null;
		List<QuickSearch> searchList = new ArrayList<QuickSearch>();
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		
		ArrayList<String> tagValues = new ArrayList<String>();
		
		boolean flag = false;
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllassignedAssetInstanceTagging || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			//keyword = keyword.replace("*","");
			
			//guest user
			if(userName.equalsIgnoreCase("roleAnonymous")){
				
				if(restApiFlag == true) {
										
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST_WITH_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
					pstmt.setInt(Constants.THREE, from);
					pstmt.setInt(Constants.FOUR, limit);
					
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST_WITH_LIMIT));
					}
				}
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST_WITHOUT_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
										
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST_WITHOUT_LIMIT));
					}
				}
				else {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");

					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_GUEST));
					}
				}
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					HashMap<Long, Object> tagMap = new HashMap<Long, Object>();
					
					Long assetInstId = rs.getLong("asset_inst_id");
					String assetName = rs.getString("asset_name");
					String assetInstName = rs.getString("asset_inst_name");
					String assetInstDesc = rs.getString("description");
					Long aivId = rs.getLong("asset_instance_version_id");
					boolean versionable = rs.getBoolean("versionable");
					
					Long tagId = rs.getLong("tag_id");
					String tagName = rs.getString("tag_name");
					
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isAssetInstDescExists = StringUtils.containsIgnoreCase(assetInstDesc, keyword);
					
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTagging || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTagging || " + assetInstName + "is matched");
						}
					}
					
					if(isAssetInstDescExists){
						matchedWordsMap.put(Constants.ASSET_INST_DESC_MATCHED, assetInstDesc);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTagging || " + assetInstDesc + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					ai = new QuickSearch();
					
					if(searchList.size()>0){
						int lastIndex = searchList.size()-1;
						if(rs.getLong("asset_instance_version_id")==searchList.get(lastIndex).getAssetInstVersionId()){
							ai = searchList.get(lastIndex);
							tagMap = ai.getTaggingMap()!= null?ai.getTaggingMap():tagMap;

							tagValues = (ArrayList<String>) searchList.get(lastIndex).getTagValues();
							if(tagValues != null){
								tagValues.add(rs.getString("tag_name"));
								tagMap.put(tagId, tagName);
							}

							ai.setTaggingMap(tagMap);
							searchList.set(lastIndex, ai);
							continue;
						}
					}
					
					ArrayList<String> tagValues1 = new ArrayList<String>();
					tagValues1.add(rs.getString("tag_name"));
					ai.setTagValues(tagValues1);
					
					ai.setSearchBy("Asset Instance");
					ai.setAssetInstId(assetInstId);
					ai.setAssetName(assetName);
					ai.setAssetInstName(assetInstName);
					ai.setAssetInstDescription(assetInstDesc);
					ai.setAssetInstVersionId(aivId);
					ai.setAssetInstanceMap(combinedMatchedResult);
					ai.setAssetDescription(rs.getString("assetdescription"));
					ai.setAssetId(rs.getLong("asset_id"));
					ai.setVersionable(versionable);
					ai.setTagId(tagId);
					ai.setTagName(tagName);
					
					tagMap.put(tagId, tagName);
					ai.setTaggingMap(tagMap);
					
					if(versionable){
						ai.setVersionName(rs.getString("version_name"));
					}else{
						ai.setVersionName("N/A");
					}
					
					searchList.add(ai);
					
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTagging || "+ ai.toString());
					}
				}
				if(log.isDebugEnabled()){
					log.debug("getAllassignedAssetInstanceTagging || "+ searchList.toString());
				}
			}
			else{
				//checking for admin rights
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				
				pstmt.setString(Constants.ONE, userName);
				
				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				}

				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					adminAccessName = new AdminAccessName();
					adminAccessName.setUserName(rs.getString("user_name"));
					adminAccessName.setGroupName(rs.getString("group_name"));
					adminAccessName.setRoleName(rs.getString("role_name"));
					adminAccessNameList.add(adminAccessName);
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTagging || returning resultset for admin "
								+ "check : "+ adminAccessName.toString());
					}
				}

				for (AdminAccessName adminAccess : adminAccessNameList) {
					if (adminAccess.getUserName().equalsIgnoreCase("admin")
							|| adminAccess.getGroupName().equalsIgnoreCase("group-admin")
							|| adminAccess.getRoleName().equalsIgnoreCase("role-admin")) {
						flag = true;
					}
				}
				
				//admin users
				if(flag){
					
					if(restApiFlag == true) {
												
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_WITH_LIMIT));
						
						pstmt1.setString(Constants.ONE, "%"+keyword+"%");
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setInt(Constants.THREE, from);
						pstmt1.setInt(Constants.FOUR, limit);
						
						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_WITH_LIMIT));
						}
					}
					else if(restApiFlagWithoutLimit == true) {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_WITHOUT_LIMIT));
						
						pstmt1.setString(Constants.ONE, "%"+keyword+"%");
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
												
						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_WITHOUT_LIMIT));
						}
					}
					else {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING));

						pstmt1.setString(Constants.ONE, "%"+keyword+"%");

						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING));
						}
					}
					rs1 = pstmt1.executeQuery();
				}
				//non-admin users
				else{
					
					if(restApiFlag == true) {
												
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.
										RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						
						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, userName);
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setInt(Constants.FIVE, from);
						pstmt1.setInt(Constants.SIX, limit);
						
						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
									getValue(Constants.
											RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						}
					}
					else if(restApiFlagWithoutLimit == true) {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.
										RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						
						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, userName);
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
												
						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
									getValue(Constants.
											RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						}
					}
					else {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.
										RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS));

						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");

						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTagging || "+PropertyFileReader.getInstance().
									getValue(Constants.
											RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAGGING_FOR_ACCESS_RIGHTS));
						}
					}
					rs1 = pstmt1.executeQuery();
				}
				
				while(rs1.next()){
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					HashMap<Long, Object> tagMap = new HashMap<Long, Object>();
					
					Long assetInstId = rs1.getLong("asset_inst_id");
					String assetName = rs1.getString("asset_name");
					String assetInstName = rs1.getString("asset_inst_name");
					String assetInstDesc = rs1.getString("description");
					Long aivId = rs1.getLong("asset_instance_version_id");
					boolean versionable = rs1.getBoolean("versionable");
					
					Long tagId = rs1.getLong("tag_id");
					String tagName = rs1.getString("tag_name");
					
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isAssetInstDescExists = StringUtils.containsIgnoreCase(assetInstDesc, keyword);
					
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTagging || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTagging || " + assetInstName + "is matched");
						}
					}
					
					if(isAssetInstDescExists){
						matchedWordsMap.put(Constants.ASSET_INST_DESC_MATCHED, assetInstDesc);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTagging || " + assetInstDesc + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					ai = new QuickSearch();
					
					if(searchList.size()>0){
						int lastIndex = searchList.size()-1;
						if(rs1.getLong("asset_instance_version_id")==searchList.get(lastIndex).getAssetInstVersionId()){
							ai = searchList.get(lastIndex);
							tagMap = ai.getTaggingMap()!= null?ai.getTaggingMap():tagMap;

							tagValues = (ArrayList<String>) searchList.get(lastIndex).getTagValues();
							if(tagValues != null){
								tagValues.add(rs1.getString("tag_name"));
								tagMap.put(tagId, tagName);
							}

							ai.setTaggingMap(tagMap);
							searchList.set(lastIndex, ai);
							continue;
						}
					}
					
					ArrayList<String> tagValues1 = new ArrayList<String>();
					tagValues1.add(rs1.getString("tag_name"));
					ai.setTagValues(tagValues1);
					
					ai.setSearchBy("Asset Instance");
					ai.setAssetInstId(assetInstId);
					ai.setAssetName(assetName);
					ai.setAssetInstName(assetInstName);
					ai.setAssetInstDescription(assetInstDesc);
					ai.setAssetInstVersionId(aivId);
					ai.setAssetInstanceMap(combinedMatchedResult);
					ai.setVersionable(versionable);
					ai.setTagId(tagId);
					ai.setTagName(tagName);
					ai.setAssetDescription(rs1.getString("assetdescription"));
					ai.setAssetId(rs1.getLong("asset_id"));
					tagMap.put(tagId, tagName);
					ai.setTaggingMap(tagMap);
					
					if(versionable){
						ai.setVersionName(rs1.getString("version_name"));
					}else{
						ai.setVersionName("N/A");
					}
					
					searchList.add(ai);
					
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTagging || "+ ai.toString());
					}
				}
				if(log.isDebugEnabled()){
					log.debug("getAllassignedAssetInstanceTagging || "+ searchList.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getAllassignedAssetInstanceTagging || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAGGING_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllassignedAssetInstanceTagging || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllassignedAssetInstanceTagging || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllassignedAssetInstanceTagging || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs1);
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt1);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllassignedAssetInstanceTagging || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAllassignedAssetInstanceTagging || End ");
		}
		return searchList;
	}
	
	
	/**
	 * @method : getAllassignedAssetInstanceTaxonomy
	 * @param keyword
	 * @param userName
	 * @param conn
	 * @return
	 * @throws RepoproException
	 */
	public List<QuickSearch> getAllassignedAssetInstanceTaxonomy(String keyword,
			String userName,Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllassignedAssetInstanceTaxonomy || Begin with searchString : "+ keyword 
					+"\t username : "+userName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		PreparedStatement pstmt1 = null;
		PreparedStatement pstmt2 = null;
		PreparedStatement pstmt3 = null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		
		QuickSearch ai = null;
		AdminAccessName adminAccessName = null;
		
		List<QuickSearch> searchList = new ArrayList<QuickSearch>();
		List<AdminAccessName> adminAccessNameList = new ArrayList<AdminAccessName>();
		
		boolean flag = false;
		
		ArrayList<String> taxValues = new ArrayList<String>();
		
		
		try {
			if (log.isTraceEnabled()){
				log.trace("getAllassignedAssetInstanceTaxonomy || " + Constants.LOG_CONNECTION_OPEN);
			}
			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			//keyword = keyword.replace("*","");
			
			//guest user
			if(userName.equalsIgnoreCase("roleAnonymous")){
				
				if(restApiFlag == true) {
										
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST_WITH_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
					pstmt.setInt(Constants.THREE, from);
					pstmt.setInt(Constants.FOUR, limit);
					
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST_WITH_LIMIT));
					}
				}
				else if(restApiFlagWithoutLimit == true) {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST_WITHOUT_LIMIT));
					
					pstmt.setString(Constants.ONE, "%"+keyword+"%");
					pstmt.setString(Constants.TWO, "%"+keyword+"%");
										
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST_WITHOUT_LIMIT));
					}
				}
				else {
					pstmt = conn.prepareStatement(PropertyFileReader
							.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST));

					pstmt.setString(Constants.ONE, "%"+keyword+"%");

					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
								getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_GUEST));
					}
				}
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					HashMap<Long, Object> taxMap = new HashMap<Long, Object>();
					
					Long assetInstId = rs.getLong("asset_inst_id");
					String assetName = rs.getString("asset_name");
					String assetInstName = rs.getString("asset_inst_name");
					String assetInstDesc = rs.getString("description");
					Long aivId = rs.getLong("asset_instance_version_id");
					boolean versionable = rs.getBoolean("versionable");
					
					Long taxId = rs.getLong("taxonomy_id");
					String taxName = rs.getString("taxonomy_name");
					
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isAssetInstDescExists = StringUtils.containsIgnoreCase(assetInstDesc, keyword);
					
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTaxonomy || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTaxonomy || " + assetInstName + "is matched");
						}
					}
					
					if(isAssetInstDescExists){
						matchedWordsMap.put(Constants.ASSET_INST_DESC_MATCHED, assetInstDesc);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTaxonomy || " + assetInstDesc + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					ai = new QuickSearch();
					
					if(searchList.size()>0){
						int lastIndex = searchList.size()-1;
						if(rs.getLong("asset_instance_version_id")==searchList.get(lastIndex).getAssetInstVersionId()){
							ai = searchList.get(lastIndex);
							taxMap = ai.getTaxonomyMap()!= null?ai.getTaxonomyMap():taxMap;

							taxValues = (ArrayList<String>) searchList.get(lastIndex).getTaxValues();
							if(taxValues != null){
								taxValues.add(rs.getString("taxonomy_name"));
								taxMap.put(taxId, taxName);
							}

							ai.setTaxonomyMap(taxMap);
							searchList.set(lastIndex, ai);
							continue;
						}
					}
					
					ArrayList<String> taxValues1 = new ArrayList<String>();
					taxValues1.add(rs.getString("taxonomy_name"));
					ai.setTaxValues(taxValues1);
					
					ai.setSearchBy("Asset Instance");
					ai.setAssetInstId(assetInstId);
					ai.setAssetName(assetName);
					ai.setAssetInstName(assetInstName);
					ai.setAssetInstDescription(assetInstDesc);
					ai.setAssetInstVersionId(aivId);
					ai.setVersionable(versionable);
					ai.setTaxonomyId(taxId);
					ai.setTaxonomyName(taxName);
					ai.setAssetInstanceMap(combinedMatchedResult);
					ai.setAssetDescription(rs.getString("assetdescription"));
					ai.setAssetId(rs.getLong("asset_id"));
					taxMap.put(taxId, taxName);
					ai.setTaxonomyMap(taxMap);
					
					if(versionable){
						ai.setVersionName(rs.getString("version_name"));
					}else{
						ai.setVersionName("N/A");
					}
					
					searchList.add(ai);
					
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTaxonomy || "+ ai.toString());
					}
				}
				if(log.isDebugEnabled()){
					log.debug("getAllassignedAssetInstanceTaxonomy || "+ searchList.toString());
				}
			}
			else{
				//checking for admin rights
				pstmt = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				
				pstmt.setString(Constants.ONE, userName);
				
				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
							getValue(Constants.GET_ALL_INSTANCES_BASED_ON_ADMIN_RIGHTS));
				}

				rs = pstmt.executeQuery();
				
				while (rs.next()) {
					adminAccessName = new AdminAccessName();
					adminAccessName.setUserName(rs.getString("user_name"));
					adminAccessName.setGroupName(rs.getString("group_name"));
					adminAccessName.setRoleName(rs.getString("role_name"));
					adminAccessNameList.add(adminAccessName);
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTaxonomy || returning resultset for admin "
								+ "check : "+ adminAccessName.toString());
					}
				}

				for (AdminAccessName adminAccess : adminAccessNameList) {
					if (adminAccess.getUserName().equalsIgnoreCase("admin")
							|| adminAccess.getGroupName().equalsIgnoreCase("group-admin")
							|| adminAccess.getRoleName().equalsIgnoreCase("role-admin")) {
						flag = true;
					}
				}
				
				//admin users
				if(flag){
					if(restApiFlag == true) {
												
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_WITH_LIMIT));
						
						pstmt1.setString(Constants.ONE, "%"+keyword+"%");
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setInt(Constants.THREE, from);
						pstmt1.setInt(Constants.FOUR, limit);
						
						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_WITH_LIMIT));
						}
					}
					else if(restApiFlagWithoutLimit == true) {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_WITHOUT_LIMIT));
						
						pstmt1.setString(Constants.ONE, "%"+keyword+"%");
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
												
						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_WITHOUT_LIMIT));
						}
					}
					else {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY));

						pstmt1.setString(Constants.ONE, "%"+keyword+"%");

						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
									getValue(Constants.RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY));
						}
					}
					rs1 = pstmt1.executeQuery();
				}
				//non-admin users
				else{
					
					if(restApiFlag == true) {
												
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.
										RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						
						
						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, userName);
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
						pstmt1.setInt(Constants.FIVE, from);
						pstmt1.setInt(Constants.SIX, limit);
						
						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
									getValue(Constants.
											RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS_WITH_LIMIT));
						}
					}
					else if(restApiFlagWithoutLimit == true) {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.
										RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						
						
						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");
						pstmt1.setString(Constants.THREE, userName);
						pstmt1.setString(Constants.FOUR, "%"+keyword+"%");
												
						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
									getValue(Constants.
											RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS_WITHOUT_LIMIT));
						}
					}
					else {
						pstmt1 = conn.prepareStatement(PropertyFileReader
								.getInstance().getValue(Constants.
										RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS));

						pstmt1.setString(Constants.ONE, userName);
						pstmt1.setString(Constants.TWO, "%"+keyword+"%");

						if (log.isTraceEnabled()) {
							log.trace("getAllassignedAssetInstanceTaxonomy || "+PropertyFileReader.getInstance().
									getValue(Constants.
											RET_ALL_ASSET_INSTANCE_FOR_ASSIGNED_TAXONOMY_FOR_ACCESS_RIGHTS));
						}
					}
					rs1 = pstmt1.executeQuery();
				}
				
				while(rs1.next()){
					
					Map<String, String> matchedWordsMap = new HashMap<String, String>();
					HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
					HashMap<Long, Object> taxMap = new HashMap<Long, Object>();
					
					Long assetInstId = rs1.getLong("asset_inst_id");
					String assetName = rs1.getString("asset_name");
					String assetInstName = rs1.getString("asset_inst_name");
					String assetInstDesc = rs1.getString("description");
					Long aivId = rs1.getLong("asset_instance_version_id");
					boolean versionable = rs1.getBoolean("versionable");
					
					Long taxId = rs1.getLong("taxonomy_id");
					String taxName = rs1.getString("taxonomy_name");
					
					boolean isAssetNameExists = StringUtils.containsIgnoreCase(assetName, keyword);
					boolean isAssetInstNameExists = StringUtils.containsIgnoreCase(assetInstName, keyword);
					boolean isAssetInstDescExists = StringUtils.containsIgnoreCase(assetInstDesc, keyword);
					
					if(isAssetNameExists){
						matchedWordsMap.put(Constants.ASSET_NAME_MATCHED, assetName);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTaxonomy || " + assetName + "is matched");
						}
					}
					
					if(isAssetInstNameExists){
						matchedWordsMap.put(Constants.ASSET_INST_NAME_MATCHED, assetInstName);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTaxonomy || " + assetInstName + "is matched");
						}
					}
					
					if(isAssetInstDescExists){
						matchedWordsMap.put(Constants.ASSET_INST_DESC_MATCHED, assetInstDesc);
						if (log.isDebugEnabled()) {
							log.debug("getAllassignedAssetInstanceTaxonomy || " + assetInstDesc + "is matched");
						}
					}
					
					combinedMatchedResult.putAll(matchedWordsMap);
					
					ai = new QuickSearch();
					
					if(searchList.size()>0){
						int lastIndex = searchList.size()-1;
						if(rs1.getLong("asset_instance_version_id")==searchList.get(lastIndex).getAssetInstVersionId()){
							ai = searchList.get(lastIndex);
							taxMap = ai.getTaxonomyMap()!= null?ai.getTaxonomyMap():taxMap;

							taxValues = (ArrayList<String>) searchList.get(lastIndex).getTaxValues();
							if(taxValues != null){
								taxValues.add(rs1.getString("taxonomy_name"));
								taxMap.put(taxId, taxName);
							}

							ai.setTaxonomyMap(taxMap);
							searchList.set(lastIndex, ai);
							continue;
						}
					}
					
					ArrayList<String> taxValues1 = new ArrayList<String>();
					taxValues1.add(rs1.getString("taxonomy_name"));
					ai.setTaxValues(taxValues1);
					
					ai.setSearchBy("Asset Instance");
					ai.setAssetInstId(assetInstId);
					ai.setAssetName(assetName);
					ai.setAssetInstName(assetInstName);
					ai.setAssetInstDescription(assetInstDesc);
					ai.setAssetInstVersionId(aivId);
					ai.setVersionable(versionable);
					ai.setTaxonomyId(taxId);
					ai.setTaxonomyName(taxName);
					ai.setAssetInstanceMap(combinedMatchedResult);
					ai.setAssetDescription(rs1.getString("assetdescription"));
					ai.setAssetId(rs1.getLong("asset_id"));
					taxMap.put(taxId, taxName);
					ai.setTaxonomyMap(taxMap);
					
					if(versionable){
						ai.setVersionName(rs1.getString("version_name"));
					}else{
						ai.setVersionName("N/A");
					}
					
					searchList.add(ai);
					
					if (log.isTraceEnabled()) {
						log.trace("getAllassignedAssetInstanceTaxonomy || "+ ai.toString());
					}
				}
				
				if(log.isDebugEnabled()){
					log.debug("getAllassignedAssetInstanceTaxonomy || "+ searchList.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getAllassignedAssetInstanceTaxonomy || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllassignedAssetInstanceTaxonomy || " + Constants.LOG_IOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllassignedAssetInstanceTaxonomy || " + Constants.LOG_PROPERTYVETOEXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllassignedAssetInstanceTaxonomy || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs3);
			DBConnection.closeResultSet(rs2);
			DBConnection.closeResultSet(rs1);
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt3);
			DBConnection.closePreparedStatement(pstmt2);
			DBConnection.closePreparedStatement(pstmt1);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllassignedAssetInstanceTaxonomy || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
			
		}
		if(log.isTraceEnabled()){
			log.trace("getAllassignedAssetInstanceTaxonomy || End ");
		}
		
		return searchList;
	}
	
	
	public List<QuickSearch> check(List<QuickSearch> superList,List<QuickSearch> qs){
		
		for(QuickSearch search:qs){
			
			if(superList.contains(search)){
				
				int index = superList.indexOf(search);
				superList.get(index).updateMissingAttributes(search);
				
			}else{
				superList.add(search);
			}
		}
		return superList;
	}
	
	
	public List<QuickSearch> getAllassignedAssetInstanceTaxonomyDetails(String keyword,
			String userName,Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllassignedAssetInstanceTaxonomyDetails || Begin with searchString : "+ keyword 
					+"\t username : "+userName);
		}
		
		Connection conn1 = null;
		
		PreparedStatement pstmt2 = null;
		PreparedStatement pstmt3 = null;
		
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		
		QuickSearch ai = null;
		
		List<QuickSearch> searchList = new ArrayList<QuickSearch>();
		
		try {
			if(restApiFlag == true) {
				
				pstmt2 = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_WITH_LIMIT));

				pstmt2.setString(Constants.ONE, "%"+keyword+"%");
				pstmt2.setInt(Constants.TWO, from);
				pstmt2.setInt(Constants.THREE, limit);

				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTaxonomyDetails || "+PropertyFileReader.getInstance().
							getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_WITH_LIMIT));
				}
			}
			else if(restApiFlagWithoutLimit == true) {
				pstmt2 = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_WITHOUT_LIMIT));

				pstmt2.setString(Constants.ONE, "%"+keyword+"%");
				
				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTaxonomyDetails || "+PropertyFileReader.getInstance().
							getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_WITHOUT_LIMIT));
				}
			}
			else {
				pstmt2 = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY));

				pstmt2.setString(Constants.ONE, "%"+keyword+"%");


				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTaxonomyDetails || "+PropertyFileReader.getInstance().
							getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY));
				}
			}
			rs2 = pstmt2.executeQuery();

			while(rs2.next()){

				Map<String, String> matchedWordsMap = new HashMap<String, String>();
				HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
				HashMap<Long, Object> taxMap = new HashMap<Long, Object>();

				String taxonomyName = rs2.getString("taxonomy_name");
				Long taxId = rs2.getLong("taxonomy_id");

				boolean istaxonomyNameExists = StringUtils.containsIgnoreCase(taxonomyName, keyword);

				if(istaxonomyNameExists){
					matchedWordsMap.put(Constants.TAXONOMY_NAME_MATCHED, taxonomyName);
					if (log.isDebugEnabled()) {
						log.debug("getAllassignedAssetInstanceTaxonomyDetails || " + taxonomyName + "is matched");
					}
				}

				combinedMatchedResult.putAll(matchedWordsMap);

				ai = new QuickSearch();
				ai.setSearchBy("Taxonomy");
				ai.setTaxonomyName(taxonomyName);
				ai.setAssetInstanceMap(combinedMatchedResult);
				ai.setTaxonomyId(taxId);
				ai.setTaxonomyName(taxonomyName);

				taxMap.put(taxId, taxonomyName);
				ai.setTaxonomyMap(taxMap);
				searchList.add(ai);

				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTaxonomyDetails || "+ ai.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllassignedAssetInstanceTaxonomyDetails || "+ searchList.toString());
			}
			
		}catch (SQLException e) {
			log.error("getAllassignedAssetInstanceTaxonomyDetails || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (Exception e) {
			log.error("getAllassignedAssetInstanceTaxonomyDetails || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs3);
			DBConnection.closeResultSet(rs2);
			DBConnection.closePreparedStatement(pstmt3);
			DBConnection.closePreparedStatement(pstmt2);
			if (log.isTraceEnabled()) {
				log.trace("getAllassignedAssetInstanceTaxonomyDetails || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAllassignedAssetInstanceTaxonomyDetails || End ");
		}
		return searchList;
	}
	
	
	
	public List<QuickSearch> getAllassignedAssetInstanceTaxonomyDetailsForAsset(String keyword,
			String userName,Connection conn, boolean restApiFlag, int from, boolean restApiFlagWithoutLimit, int limit) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllassignedAssetInstanceTaxonomyDetailsForAsset || Begin with searchString : "+ keyword 
					+"\t username : "+userName);
		}
		
		Connection conn1 = null;
		
		PreparedStatement pstmt3 = null;
		
		ResultSet rs3 = null;
		
		QuickSearch ai = null;
		
		List<QuickSearch> searchList = new ArrayList<QuickSearch>();
		
		try {
			if(restApiFlag == true) {

				pstmt3 = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET_WITH_LIMIT));

				pstmt3.setString(Constants.ONE, "%"+keyword+"%");
				pstmt3.setInt(Constants.TWO, from);
				pstmt3.setInt(Constants.THREE, limit);


				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTaxonomyDetailsForAsset || "+PropertyFileReader.getInstance().
							getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET_WITH_LIMIT));
				}
			}
			else if(restApiFlagWithoutLimit == true) {
				pstmt3 = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET_WITHOUT_LIMIT));

				pstmt3.setString(Constants.ONE, "%"+keyword+"%");

				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTaxonomyDetailsForAsset || "+PropertyFileReader.getInstance().
							getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET_WITHOUT_LIMIT));
				}
			}
			else {
				pstmt3 = conn.prepareStatement(PropertyFileReader
						.getInstance().getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET));

				pstmt3.setString(Constants.ONE, "%"+keyword+"%");


				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTaxonomyDetailsForAsset || "+PropertyFileReader.getInstance().
							getValue(Constants.RET_ALL_MATCHED_TAXOXNOMY_FOR_ASSET));
				}
			}
			rs3 = pstmt3.executeQuery();

			while(rs3.next()){

				Map<String, String> matchedWordsMap = new HashMap<String, String>();
				HashMap<String, String> combinedMatchedResult = new HashMap<String, String>();
				HashMap<Long, Object> taxMap = new HashMap<Long, Object>();

				String taxonomyName = rs3.getString("taxonomy_name");
				Long taxId = rs3.getLong("taxonomy_id");
				Long assetId = rs3.getLong("asset_id");
				String assetName = rs3.getString("asset_name");
				String desc = rs3.getString("description");

				boolean istaxonomyNameExists = StringUtils.containsIgnoreCase(taxonomyName, keyword);

				if(istaxonomyNameExists){
					matchedWordsMap.put(Constants.TAXONOMY_NAME_MATCHED, taxonomyName);
					if (log.isDebugEnabled()) {
						log.debug("getAllassignedAssetInstanceTaxonomyDetailsForAsset || " + taxonomyName + "is matched");
					}
				}

				combinedMatchedResult.putAll(matchedWordsMap);

				ai = new QuickSearch();
				ai.setSearchBy("Asset");
				ai.setTaxonomyName(taxonomyName);
				ai.setAssetInstanceMap(combinedMatchedResult);
				ai.setTaxonomyId(taxId);
				ai.setTaxonomyName(taxonomyName);

				taxMap.put(taxId, taxonomyName);
				ai.setTaxonomyMap(taxMap);

				ai.setAssetId(assetId);
				ai.setAssetName(assetName);
				ai.setAssetDescription(desc);
				searchList.add(ai);

				if (log.isTraceEnabled()) {
					log.trace("getAllassignedAssetInstanceTaxonomyDetailsForAsset || "+ ai.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAllassignedAssetInstanceTaxonomyDetailsForAsset || "+ searchList.toString());
			}

		}catch (SQLException e) {
			log.error("getAllassignedAssetInstanceTaxonomyDetailsForAsset || " + Constants.LOG_GET_SQLEXCEPTION 
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(
					MessageUtil.getMessage(Constants.TAXONOMY_DATA_NOT_FOUND));
		} catch (Exception e) {
			log.error("getAllassignedAssetInstanceTaxonomyDetailsForAsset || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs3);
			DBConnection.closePreparedStatement(pstmt3);
			if (log.isTraceEnabled()) {
				log.trace("getAllassignedAssetInstanceTaxonomyDetailsForAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAllassignedAssetInstanceTaxonomyDetailsForAsset || End ");
		}
		return searchList;
	}
	
	
	class Sortbyname implements Comparator<QuickSearch> {
		
		public int compare(QuickSearch o1, QuickSearch o2) {
			return o1.getAssetInstName().toLowerCase().compareTo(o2.getAssetInstName().toLowerCase());
		} 
	}
	
	class SortbynameRev implements Comparator<QuickSearch> {
		
		public int compare(QuickSearch o1, QuickSearch o2) {
			return o2.getAssetInstName().toLowerCase().compareTo(o1.getAssetInstName().toLowerCase());
		} 
	}
	
	class Sortbyid implements Comparator<QuickSearch> {

		public int compare(QuickSearch o1, QuickSearch o2) {
			return o1.getAssetInstVersionId().compareTo(o2.getAssetInstVersionId());
		} 
	}
	
	class SortbyidRev implements Comparator<QuickSearch> {

		public int compare(QuickSearch o1, QuickSearch o2) {
			return o2.getAssetInstVersionId().compareTo(o1.getAssetInstVersionId());
		} 
	}
	
	public int getRem(int limit, int listSize) {
		int remainder = 0;

		remainder = limit - listSize;
		//limit = limit + rem;


		return remainder;

	}
}
