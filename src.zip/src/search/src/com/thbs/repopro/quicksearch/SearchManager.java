package com.thbs.repopro.quicksearch;

import java.net.URLDecoder;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.Encoded;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.accesscontrol.UserDao;
import com.thbs.repopro.asset.AssetDao;
import com.thbs.repopro.assetinstanceversion.AssetInstanceVersionDao;
import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetParamDef;
import com.thbs.repopro.dto.QuickSearch;
import com.thbs.repopro.dto.SearchResponse;
import com.thbs.repopro.dto.User;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.CommonUtils;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.MyModel;
import com.thbs.repopro.util.MyModelRest;

@Produces({ MediaType.APPLICATION_JSON})
@Consumes({ MediaType.APPLICATION_JSON })
@Path("/search")
public class SearchManager {

	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	/**
	 * @method : search
	 * @param searchString
	 * @param options
	 * @param userName
	 * @return
	 */
	@GET
	@Encoded
	@Path("/quickSearchUI")
	public Response search(@QueryParam("searchString") String searchString,
			@QueryParam("options") String options,
			@QueryParam("userName") String userName,
			@QueryParam("restApiFlag") boolean restApiFlag,
			@QueryParam ("from") int from,
			@QueryParam ("range") int range,
			@QueryParam ("sortBy") String sortBy,
			@QueryParam ("sortOrder") String sortOrder,
			@QueryParam ("restApiFlagWithoutLimit") boolean restApiFlagWithoutLimit){
				
		if(log.isTraceEnabled()){
			log.trace("search || Begin with searchString : "+ searchString 
					+"\t options : "+ options);
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		searchString = searchString.trim();
		options = options.trim();
		userName = userName.trim();
		SearchResponse searchResponse = new SearchResponse();
		
		List<SearchResponse> responseList = new ArrayList<SearchResponse>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("search || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			searchString = URLDecoder.decode(searchString, "UTF-8");
			options = URLDecoder.decode(options, "UTF-8");
			
			conn = DBConnection.getInstance().getConnection();
			
			SearchDao dao = new SearchDao();
			
			searchResponse = dao.search(searchString, options, userName, conn, restApiFlag, from, range, sortBy, sortOrder, restApiFlagWithoutLimit);
			searchResponse.setTotalCount(searchResponse.getTotalCount());
			
			responseList.add(searchResponse);
			
			if(searchResponse.getSearchResponse().isEmpty()){
				retMsg = Constants.SEARCH_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			retMsg = Constants.SEARCH_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			log.debug("search || retrieved "+ searchResponse.getTotalCount()+ " search results successfully");
			log.trace("search || End");
			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(responseList))).build();
			
		} catch(RepoproException e){
			log.error("search || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("search || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("search || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if(log.isTraceEnabled()){
			log.trace("search || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/***Wrapper function***/
	@GET
	@Encoded
	@Path("/quickSearch")
	public Response searchMain(@QueryParam("searchString") String searchString,
			@QueryParam("options") String options,
			@HeaderParam("token") String token, @QueryParam("selectParameter") String selectParameter,
			@QueryParam("start") String from,
			@QueryParam("maxResults") String range,
			@QueryParam("sortBy") String sortBy,
			@QueryParam("sortOrder") String sortOrder){
		
		if(searchString == null|| options == null){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					.build();
		}
		
		if(searchString.isEmpty()|| options.isEmpty()){
			return Response
					.status(Status.BAD_REQUEST)
					.entity(new MyModelRest(Constants.STATUS_FAILURE,
							Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					.build();
		}
		
		try {
			if(from != null) {
				from = URLDecoder.decode(from, "UTF-8");
				from = from.trim();
			}
			if(range != null) {
				range = URLDecoder.decode(range, "UTF-8");
				range = range.trim();
			}
			if(sortBy != null) {
				sortBy = URLDecoder.decode(sortBy, "UTF-8");
				sortBy = sortBy.trim();
			}
			if(sortOrder != null) {
				sortOrder = URLDecoder.decode(sortOrder, "UTF-8");
				sortOrder = sortOrder.trim();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(from != null && !from.trim().isEmpty()) {
			if(!from.matches("[0-9]+")){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						.build();
			}
		}
		
		if(range != null && !range.trim().isEmpty()) {
			if(!range.matches("[0-9]+")){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						.build();
			}
		}
		
		if(from != null && range != null) {
			from = from.trim(); range = range.trim();
			if(!from.isEmpty() && !range.isEmpty()) {
				if(Integer.parseInt(from) == 0 && Integer.parseInt(range) == 0) {
						return Response
								.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
								.build();
				}
			}
		}
		
		if(from == null) {
			from = "0";
			if(range != null) {
				if(range != "0") {
					return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
							.build();
				}
			}
		}
		if(range == null) {
			range = "0";
			if(from != null) {
				if(from != "0") {
					return Response
							.status(Status.BAD_REQUEST)
							.entity(new MyModelRest(Constants.STATUS_FAILURE,
									Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
							.build();
				}
			}
		}
		if(from != null) {
			if(from.trim().isEmpty()) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
		}
		if(range != null) {
			if(range.trim().isEmpty()) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
		}
		if(from != null) {
			if(!from.isEmpty()) {
				if(Integer.parseInt(from)>0 && Integer.parseInt(range) == 0) {
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
			}
		}
		
		if(sortBy == null) {
			if(sortOrder != null) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					     .build();
			}
		}
		if(sortOrder == null) {
			if(sortBy != null) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_QUERY_PARAMETER_NAME)))
					     .build();
			}
		}
		if(sortBy != null) {
			if(sortBy.trim().isEmpty()) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
		}
		if(sortOrder != null) {
			if(sortOrder.trim().isEmpty()) {
				return Response
					     .status(Status.BAD_REQUEST)
					     .entity(new MyModelRest(Constants.STATUS_FAILURE,
					       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
					     .build();
			}
		}
		if(sortBy != null) {
			if(!sortBy.trim().isEmpty()) {
				if(!sortBy.equalsIgnoreCase("AssetInstanceName") && !sortBy.equalsIgnoreCase("AssetInstanceVersionId")){
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_SORT_BY_ATTRIBUTE)))
						     .build();
				}
			}
		}
		if(sortOrder != null) {
			if(!sortOrder.trim().isEmpty()) {
				if(!sortOrder.equalsIgnoreCase("ASC") && !sortOrder.equalsIgnoreCase("DESC")){
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_SORTING_ORDER)))
						     .build();
				}
			}
		}
		
		log.trace("searchMain || Begin");
		Connection conn = null;
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		Response response = null;
		searchString = searchString.trim();
		options = options.trim();
		if(selectParameter != null){
			selectParameter = selectParameter.trim();
		}
		CommonUtils commonUtils = new CommonUtils();
		String userName = "";
		UserDao userDao = new UserDao();
				
		try {
			userName = commonUtils.getUserNameFromNativeOroAuthMode(token);
			/*if(token != null){
				User userdata = commonUtils.userDetails(token);
				User username = userDao.getUserByUserId( userdata.getUserId(), null);
				userName = username.getUserName();
			}else{
				userName = "guest";
			}*/
			if (log.isTraceEnabled()) {
				log.trace("searchMain || " + Constants.LOG_CONNECTION_OPEN);
			}
			conn = DBConnection.getInstance().getConnection();
			
			String searchString1 = URLDecoder.decode(searchString,"UTF-8");
			searchString1 = searchString1.trim();
			String options1 = URLDecoder.decode(options, "UTF-8");
			options1 = options1.trim();
			
			if(searchString1.isEmpty() || options1.isEmpty()){
				return Response
						.status(Status.BAD_REQUEST)
						.entity(new MyModelRest(Constants.STATUS_FAILURE,
								Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						.build();
			}
			
			if(selectParameter != null){
				selectParameter = URLDecoder.decode(selectParameter, "UTF-8");
				selectParameter = selectParameter.trim();
				if(selectParameter.endsWith(",") || selectParameter.startsWith(",")){
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
			}
						
			if(options1.equalsIgnoreCase("keyword") || options1.equalsIgnoreCase("taxonomy") || options1.equalsIgnoreCase("tags")){
				if(selectParameter != null ) {
					if(selectParameter.isEmpty()) {
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
				}
				if(selectParameter != null && !selectParameter.equalsIgnoreCase("")){
					return Response
						     .status(Status.BAD_REQUEST)
						     .entity(new MyModelRest(Constants.STATUS_FAILURE,
						       Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA)))
						     .build();
				}
			}
			
			if(!userName.equalsIgnoreCase("guest")){
				User user = userDao.getUserIdByUserName(userName, conn);
				if(user == null){
					retStat = Status.UNAUTHORIZED;
					retMsg = Constants.USER_NOT_AUTHENTICATED;
					retScsFlr = Constants.NOT_AUTHENTICATED;
					retStatScsFlr = Constants.UNAUTHORIZED;
					return Response.status(retStat).entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();	
				}
			}
			if(userName.equalsIgnoreCase("guest")){
				userName = "roleAnonymous";
			}
			
			boolean paramFlag = false;
			
			AssetDao assetDao = new AssetDao();
			AssetInstanceVersionDao aivDao = new AssetInstanceVersionDao();
			List<AssetParamDef> apdList = new ArrayList<AssetParamDef>();
			
			if(!(options1.equalsIgnoreCase("keyword") || options1.equalsIgnoreCase("taxonomy") || options1.equalsIgnoreCase("tags"))){
				paramFlag = true;
				AssetDef assetDef = assetDao.getAssetsByAssetName(options1, null);
				if (assetDef.getAssetId() == null) {
					retStat = Status.NOT_FOUND;
					retScsFlr = Constants.FAILURE;
					retMsg = Constants.ASSET_DATA_NOT_FOUND;
					retStatScsFlr = Constants.GET_STATUS_FAILURE;

					log.trace("search || End");
					return Response
							.status(retStat)
							.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
				}
				
				if(selectParameter != null ) {
					if(selectParameter.isEmpty()) {
						return Response.status(Status.BAD_REQUEST)
								.entity(new MyModelRest(Constants.STATUS_FAILURE,
										Constants.FAILURE, MessageUtil.getMessage(Constants.INVALID_DATA))).build();
					}
				}
				
				if(selectParameter != null && !selectParameter.equalsIgnoreCase("")){
					String[] splitInputField = selectParameter.split(",");
					List<String> selectParameterList = Arrays.asList(splitInputField);
					
					for(int i=0;i<splitInputField.length;i++){
						splitInputField[i] = splitInputField[i].trim().toLowerCase();
						///AssetParamDef params = assetDao.getAssetParamIdByName(splitInputField[i], options1, conn);
						AssetParamDef params = assetDao.getParamIdForAssetAndParamName(options1,splitInputField[i],conn);

						if(params == null){
							retStat = Status.NOT_FOUND;
							retScsFlr = Constants.FAILURE;
							retMsg = Constants.PARAMETER_NOT_FOUND;
							retStatScsFlr = Constants.GET_STATUS_FAILURE;
							
							log.trace("search || End");
							return Response
									.status(retStat)
									.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
						}
						boolean paramAccessFlag = true;
						if(!userName.equalsIgnoreCase("admin")){
							AssetParamDef paramaccess = assetDao.getAssetParamAccess(userName,splitInputField[i],options1,null);
							if(paramaccess == null || paramaccess.getAssetParamId() == null){
								paramAccessFlag = false;//no access to that parameter
								retStat = Status.FORBIDDEN;
								retMsg = Constants.USER_NOT_AUTHORIZED;
								retScsFlr = Constants.NOT_AUTHORIZED;
								retStatScsFlr = Constants.FORBIDDEN;
								log.trace("search || End");
								return Response.status(retStat)
										.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
							
							}
						}
					}
					
					boolean duplicateFlag = false;
					Set<String> duplicate = new HashSet<String>();
					duplicate.addAll(selectParameterList);
					if(duplicate.size()<selectParameterList.size()) {
						duplicateFlag = true;
					}
					if(duplicateFlag) {
						retStat = Status.BAD_REQUEST;
						retScsFlr = Constants.FAILURE;
						retMsg = Constants.ASSET_PARAM_NAME_ALREADY_EXISTS;
						retStatScsFlr = Constants.STATUS_FAILURE;
						return Response.status(retStat)
								.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
					}
				}
				
			}
			
			boolean restApiFlag = false;
			if(from != null && range != null && Integer.parseInt(range) != 0) {
				restApiFlag = true;
			}
			
			boolean restApiFlagWithoutLimit = false;
			if(from != null && range != null && Integer.parseInt(range) == 0) {
				restApiFlagWithoutLimit = true;
			}
			
			response = this.search(searchString, options, userName, restApiFlag, Integer.parseInt(from), Integer.parseInt(range),sortBy, sortOrder, restApiFlagWithoutLimit);
			MyModel res = (MyModel) response.getEntity();
			List<Object> data = res.getResult();
			JSONObject finalResultJSON = new JSONObject();
			List<Object> finalResultArray = new ArrayList<Object>();
			
			for (int i = 0; i < data.size(); i++) {
				SearchResponse searchResponse = (SearchResponse) data.get(i);				
				//finalResultJSON.put("totalCount", searchResponse.getTotalCount());
				//searchResponse.getSearchResponse().forEach(quicksearch ->{
					
				for(Object quicksearch : searchResponse.getSearchResponse()){
					
					QuickSearch searchLocal = (QuickSearch)quicksearch;
					JSONObject quickSearchJsonObject = null;
					try{
						quickSearchJsonObject = new JSONObject();
						// Check if attribute is not null and add it to json
						
						if(searchLocal.getUserName()!=null){
							quickSearchJsonObject.put("userName", searchLocal.getUserName());
						}
						if(searchLocal.getFullName()!=null){
							quickSearchJsonObject.put("fullName", searchLocal.getFullName());
						}
						if(searchLocal.getEmailId()!=null){
							quickSearchJsonObject.put("emailId", searchLocal.getEmailId());
						}
						if(searchLocal.getDepartment()!=null){
							quickSearchJsonObject.put("department", searchLocal.getDepartment());
						}
												
						if(searchLocal.getAssetName()!=null){
							quickSearchJsonObject.put("assetName", searchLocal.getAssetName());
						}
						if(searchLocal.getAssetDescription()!=null){
							quickSearchJsonObject.put("assetDescription", searchLocal.getAssetDescription());
							
						}
						
						if(searchLocal.getAssetInstName()!=null){
							quickSearchJsonObject.put("assetInstanceName", searchLocal.getAssetInstName());
						}
						if(searchLocal.getAssetInstDescription()!=null){
							quickSearchJsonObject.put("assetInstanceDescription", searchLocal.getAssetInstDescription());
						}
						if(searchLocal.getAssetInstVersionId()!=null){
							quickSearchJsonObject.put("assetInstanceVersionId", searchLocal.getAssetInstVersionId());
						}
						
						if(searchLocal.isVersionable()){
							quickSearchJsonObject.put("versionName", searchLocal.getVersionName());
						}else{
							quickSearchJsonObject.put("versionName", searchLocal.getVersionName());
						}
						
						/*if(searchLocal.getAssetParamName()!=null){
							quickSearchJsonObject.put("assetParameterName", searchLocal.getAssetParamName());
						}
						if(searchLocal.getParamValue()!=null){
							quickSearchJsonObject.put("assetParameterValue", searchLocal.getParamValue());
						}*/
						HashMap<String, Object> parameterMap = null;
						if(searchLocal.getParamMap()!=null && searchLocal.getParamMap().size()>0){
							parameterMap = new HashMap<String, Object>();
							for(Map.Entry<String,Object> entry : searchLocal.getParamMap().entrySet()){
								if(entry.getValue() instanceof List){
									String key = entry.getKey().split("`~`")[0];
									List<String> paramList = (List<String>) entry.getValue();
									for(int p=0;p<paramList.size();p++){
										String param= paramList.get(p);
										if(param.contains("~~")){
											paramList.set(p,param.replace("~~", ","));
										}
									}
									parameterMap.put(key, paramList);
								}else if(entry.getValue() instanceof String){
									String val = (String)entry.getValue();
									if(val.contains("~~")){
										parameterMap.put(entry.getKey().split("`~`")[0], val.replace("~~", ","));
									}else{
										parameterMap.put(entry.getKey().split("`~`")[0], val);
									}
								}
								
							}
						}
						if(searchLocal.getParamMap()!=null){
							quickSearchJsonObject.put("metaData", parameterMap);
						}
						
						if(selectParameter != null && !selectParameter.equalsIgnoreCase("")){
							HashMap<String, String> selectParameterMap = new HashMap<String, String>();
							
							String[] splitInputField = selectParameter.split(",");
							for(int k=0;k<splitInputField.length;k++){
								
								splitInputField[k] = splitInputField[k].trim();
								AssetParamDef params = assetDao.getAssetParamIdByName(splitInputField[k], options1, conn);
								apdList = aivDao.getParamNamesAndValuesByParamId(params.getAssetParamId(), conn);

								for(AssetParamDef apd : apdList){
									
									if(paramFlag == true){
										if(searchLocal.getAssetInstVersionId()!=null){
											long searchAivId = searchLocal.getAssetInstVersionId();
											long assetInstVersionId = apd.getAssetInstVersionId();
											if(searchAivId == assetInstVersionId){
												if(apd.getParamTypeId() == 3){
													selectParameterMap.put(apd.getAssetParamName(), apd.getFileName());
												}else{
													selectParameterMap.put(apd.getAssetParamName(), apd.getParamValue().replace("~~", ","));
												}
												quickSearchJsonObject.put("selectParameter", selectParameterMap);
											}
										}else{
											continue;
										}
									}
								}
							}
						}
						
						
						HashMap<Long, Object> taxonomyMap = null;
						if(searchLocal.getTaxonomyMap()!=null && searchLocal.getTaxonomyMap().size()>0){
							taxonomyMap = new HashMap<Long, Object>();
							for(Map.Entry<Long,Object> entry : searchLocal.getTaxonomyMap().entrySet()){
								taxonomyMap.put(entry.getKey(), entry.getValue());
							}
						}
						if(searchLocal.getTaxonomyMap()!=null){
							quickSearchJsonObject.put("taxonomyData", taxonomyMap);
						}
						/*if(searchLocal.getTaxonomyId()!=null){
							quickSearchJsonObject.put("taxonomyId", searchLocal.getTaxonomyId());
						}
						if(searchLocal.getTaxonomyName()!=null){
							quickSearchJsonObject.put("taxonomyName", searchLocal.getTaxonomyName());
						}*/
						
						HashMap<Long, Object> taggingMap = null;
						if(searchLocal.getTaggingMap()!=null && searchLocal.getTaggingMap().size()>0){
							taggingMap = new HashMap<Long, Object>();
							for(Map.Entry<Long,Object> entry : searchLocal.getTaggingMap().entrySet()){
								taggingMap.put(entry.getKey(), entry.getValue());
							}
						}
						if(searchLocal.getTaggingMap()!=null){
							quickSearchJsonObject.put("tagData", taggingMap);
						}
						
					}catch(Exception e){
						e.printStackTrace();					
					}
					finalResultArray.add(quickSearchJsonObject);
				}
				//);
			}
			if(data.isEmpty()){
				retMsg = Constants.SEARCH_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response
						.status(retStat)
						.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			finalResultJSON.put("message", Constants.SEARCH_DATA_FETCHED);
			finalResultJSON.put("status", Constants.SUCCESS);
			finalResultJSON.put("statusCode", Constants.GET_STATUS_SUCCESS);
			finalResultJSON.put("result", finalResultArray);
			log.trace("searchMain || End");
			return Response.status(retStat).entity(finalResultJSON.toString()).build();
			
		} catch (RepoproException e) {
			log.error("searchMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch (Exception e) {
			log.error("searchMain || " + Constants.LOG_EXCEPTION
					+ e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("searchMain || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		log.trace("searchMain || End");
		return Response
				.status(retStat)
				.entity(new MyModelRest(retStatScsFlr, retScsFlr, retMsg)).build();
	}
	
	/*
	@GET
	@Encoded
	@Path("/quickSearchRest")
	public Response searchForRest(@QueryParam("searchString") String searchString,
			@QueryParam("options") String options,
			@QueryParam("userName") String userName){
		
		if(log.isTraceEnabled()){
			log.trace("searchForRest || Begin with searchString : "+ searchString +"\t options : "+ options
					+"userName : "+userName);
		}
		
		Connection conn = null;
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		searchString = searchString.trim();
		options = options.trim();
		userName = userName.trim();
		SearchResponse searchResponse = new SearchResponse();
		
		List<SearchResponse> responseList = new ArrayList<SearchResponse>();
		
		try {
			if (log.isTraceEnabled()){
				log.trace("searchForRest || " + Constants.LOG_CONNECTION_OPEN);
			}
			
			searchString = URLDecoder.decode(searchString, "UTF-8");
			options = URLDecoder.decode(options, "UTF-8");
			
			conn = DBConnection.getInstance().getConnection();
			
			SearchDao dao = new SearchDao();
			
			searchResponse = dao.searchForRest(searchString, options, userName, conn);
			searchResponse.setTotalCount(searchResponse.getTotalCount());
			
			responseList.add(searchResponse);
			
			if(searchResponse.getSearchResponse().isEmpty()){
				retMsg = Constants.SEARCH_DATA_NOT_FOUND;
				retScsFlr = Constants.SUCCESS;
				retStat = Status.OK;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
				return Response
						.status(retStat)
						.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
			}
			
			retMsg = Constants.SEARCH_DATA_FETCHED;
			retScsFlr = Constants.SUCCESS;
			retStat = Status.OK;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			log.debug("searchForRest || retrieved "+ searchResponse.getTotalCount()+ " search results successfully");
			log.trace("searchForRest || End");
			return Response
					.status(retStat)
					.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg,
							new ArrayList<Object>(responseList))).build();
			
			
		} catch(RepoproException e){
			log.error("searchForRest || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("searchForRest || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("searchForRest || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		
		if(log.isTraceEnabled()){
			log.trace("searchForRest || End");
		}
		
		return Response
				.status(retStat)
				.entity(new MyModel(retStatScsFlr, retScsFlr, retMsg)).build();
	}*/
	
}
