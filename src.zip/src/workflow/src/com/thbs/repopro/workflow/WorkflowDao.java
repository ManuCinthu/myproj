package com.thbs.repopro.workflow;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.dto.AssetDef;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.Workflow;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MessageUtil;
import com.thbs.repopro.util.PropertyFileReader;

public class WorkflowDao {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	
	public List<Workflow> getAllWorkflows(Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getAllWorkflows || Begin");
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Workflow workflow = null;
		Map<Long, String> selectedAssets = new HashMap<Long, String>();
		List<Workflow> workFlowList = new ArrayList<Workflow>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllWorkflows || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			Map<Long, String> allAssetNames = getAllAssetsWithWorkflowEnabled(conn);
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_WORKFLOWS));
			
			if (log.isTraceEnabled()) {
				log.trace("getAllWorkflows || " + PropertyFileReader.getInstance().getValue(Constants.GET_ALL_WORKFLOWS));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				workflow = new Workflow();
				
				if(workFlowList.size()>0){
					int lastIndex = workFlowList.size()-1;
					Workflow workflow2 = workFlowList.get(lastIndex);
					Long workflowId = workFlowList.get(lastIndex).getWorkflowId();
					if(rs.getLong("workflow_id") == workflowId) {
						selectedAssets = workFlowList.get(lastIndex).getAssignedAssets();
						selectedAssets.put(rs.getLong("asset_id"),rs.getString("asset_name"));
						workFlowList.set(lastIndex, workflow2);
						continue;
					}
				}
				
				Map<Long, String> selectedAssets1 = new HashMap<Long, String>();
				
				workflow.setWorkflowId(rs.getLong("workflow_id"));
				workflow.setWorkflowName(rs.getString("workflow_name"));
				workflow.setJsonStructure(rs.getString("json_structure"));
								
				selectedAssets1.put(rs.getLong("asset_id"),rs.getString("asset_name"));
				workflow.setAssignedAssets(selectedAssets1);
				
				workflow.setAllAssets(allAssetNames);
				
				workFlowList.add(workflow);
				
				if(log.isTraceEnabled()) {
					log.trace("getAllWorkflows || "+workflow.toString());
				}
			}
						
			/*if(workFlowList.size() == 0) {
				workflow = new Workflow();
				workflow.setAllAssets(allAssetNames);
				workFlowList.set(0, workflow);
			}*/
			
			for(Workflow workflow2 : workFlowList) {
				Map<Long, String> assignedAssetsToWorkflow = workflow2.getAssignedAssets();
				for(Map.Entry<Long, String> map : assignedAssetsToWorkflow.entrySet()) {
					boolean flagIfStateAssigned = retIfWorkflowStateIsUpdated(map.getKey(), conn);
					workflow2.setFlagIfStateUpdated(flagIfStateAssigned);
					if(flagIfStateAssigned) {
						break;
					}
				}
			}
						
			if(log.isDebugEnabled()){
				log.debug("getAllWorkflows || "+workFlowList.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAllWorkflows || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllWorkflows || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllWorkflows || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllWorkflows || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllWorkflows || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return workFlowList;
	}
	
	
	public Workflow addWorkflow(Workflow workflow, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("addWorkflow || Begin" + workflow.toString());
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addWorkflow || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.ADD_WORKFLOW));
			pstmt.setString(Constants.ONE, workflow.getWorkflowName());
			pstmt.setString(Constants.TWO, workflow.getJsonStructure());
			
			if (log.isTraceEnabled()) {
				log.trace("addWorkflow || " + PropertyFileReader.getInstance().getValue(Constants.ADD_WORKFLOW));
			}
			
			pstmt.executeUpdate();
			
			rs = pstmt.getGeneratedKeys();
			if (rs != null && rs.next()) {
				workflow.setWorkflowId(rs.getLong(1));
			}
			
		} catch (SQLException e) {
			log.error("addWorkflow || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_NOT_ADDED));
		} catch (IOException e) {
			log.error("addWorkflow || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addWorkflow || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("addWorkflow || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return workflow;
	}
	
	
	public Workflow getWorkflowByName(String workflowName, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getWorkflowByName || Begin with workflowName : "+workflowName);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Workflow workflow = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowByName || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_WORKFLOW_BY_NAME));
			
			pstmt.setString(Constants.ONE, workflowName);
			
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowByName || " + PropertyFileReader.getInstance().getValue(Constants.GET_WORKFLOW_BY_NAME));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				workflow = new Workflow();
				workflow.setWorkflowId(rs.getLong("workflow_id"));
				workflow.setWorkflowName(rs.getString("workflow_name"));
				workflow.setJsonStructure(rs.getString("json_structure"));
				
				if(log.isTraceEnabled()) {
					log.trace("getWorkflowByName || "+workflow.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getWorkflowByName || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_NOT_FOUND));
		} catch (IOException e) {
			log.error("getWorkflowByName || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getWorkflowByName || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getWorkflowByName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowByName || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return workflow;
	}
	
	
	public Workflow getWorkflowById(Long workflowId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getWorkflowById || Begin with workflowId : "+workflowId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Workflow workflow = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowById || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_WORKFLOW_BY_ID));
			
			pstmt.setLong(Constants.ONE, workflowId);
			
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowById || " + PropertyFileReader.getInstance().getValue(Constants.GET_WORKFLOW_BY_ID));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				workflow = new Workflow();
				workflow.setWorkflowId(rs.getLong("workflow_id"));
				workflow.setWorkflowName(rs.getString("workflow_name"));
				workflow.setJsonStructure(rs.getString("json_structure"));
				
				if(log.isTraceEnabled()) {
					log.trace("getWorkflowById || "+workflow.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getWorkflowById || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_NOT_FOUND));
		} catch (IOException e) {
			log.error("getWorkflowById || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getWorkflowById || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getWorkflowById || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowById || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return workflow;
	}
	
	
	public boolean deleteWorkflow(Long workflowId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("deleteWorkflow || Begin with workflowId : "+workflowId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		boolean status = false;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteWorkflow || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_WORKFLOW));
			
			pstmt.setLong(Constants.ONE, workflowId);
			
			if (log.isTraceEnabled()) {
				log.trace("deleteWorkflow || " + PropertyFileReader.getInstance().getValue(Constants.DELETE_WORKFLOW));
			}
			
			pstmt.executeUpdate();
			status = true;
			
		} catch (SQLException e) {
			log.error("deleteWorkflow || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteWorkflow || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteWorkflow || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteWorkflow || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return status;
	}
	
	
	public Workflow updateWorkflow(Workflow workflow, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("updateWorkflow || Begin "+workflow.toString());
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("updateWorkflow || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_WORKFLOW));
			
			pstmt.setString(Constants.ONE, workflow.getWorkflowName());
			pstmt.setString(Constants.TWO, workflow.getJsonStructure());
			pstmt.setLong(Constants.THREE, workflow.getWorkflowId());
			
			if (log.isTraceEnabled()) {
				log.trace("updateWorkflow || " + PropertyFileReader.getInstance().getValue(Constants.UPDATE_WORKFLOW));
			}
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("updateWorkflow || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_NOT_UPDATED));
		} catch (IOException e) {
			log.error("updateWorkflow || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("updateWorkflow || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("updateWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("updateWorkflow || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return workflow;
	}
	
	
	public void addWorkflowLink(Long assetId, Long workflowId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("addWorkflowLink || Begin with assetId : "+assetId +" workflowId : "+workflowId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt1 = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("addWorkflowLink || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			/*//deleting all the assets linked to a workflow
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_WORKFLOW_LINK));
			pstmt.setLong(Constants.ONE, workflowId);
			
			if (log.isTraceEnabled()) {
				log.trace("addWorkflowLink || " + PropertyFileReader.getInstance().getValue(Constants.DELETE_WORKFLOW_LINK));
			}
			pstmt.executeUpdate();*/
			
			pstmt1 = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.ADD_WORKFLOW_LINK));
			pstmt1.setLong(Constants.ONE, workflowId);
			pstmt1.setLong(Constants.TWO, assetId);
			
			if (log.isTraceEnabled()) {
				log.trace("addWorkflowLink || " + PropertyFileReader.getInstance().getValue(Constants.ADD_WORKFLOW_LINK));
			}
			pstmt1.executeUpdate();
			
		} catch (SQLException e) {
			log.error("addWorkflowLink || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_LINK_NOT_ADDED));
		} catch (IOException e) {
			log.error("addWorkflowLink || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("addWorkflowLink || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("addWorkflowLink || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt1);
			if (log.isTraceEnabled()) {
				log.trace("addWorkflowLink || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
	}
	
	
	public List<Long> getAssetsLinkedToWorkflow(Long workflowId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getAssetsLinkedToWorkflow || Begin with workflowId : "+workflowId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		List<Long> assetIdsList = new ArrayList<>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetsLinkedToWorkflow || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ASSETS_LINKED_TO_WORKFLOW));
			
			pstmt.setLong(Constants.ONE, workflowId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAssetsLinkedToWorkflow || " + PropertyFileReader.getInstance().getValue(
						Constants.GET_ASSETS_LINKED_TO_WORKFLOW));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				assetIdsList.add(rs.getLong("asset_id"));
				
				if(log.isTraceEnabled()) {
					log.trace("getAssetsLinkedToWorkflow || "+assetIdsList.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("getAssetsLinkedToWorkflow || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetsLinkedToWorkflow || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAssetsLinkedToWorkflow || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAssetsLinkedToWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetsLinkedToWorkflow || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAssetsLinkedToWorkflow || End");
		}
		return assetIdsList;
	}
	
	
	public void deleteAssetInstanceLinkFromWorkflow(Long aivId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("deleteAssetInstanceLinkFromWorkflow || Begin with aivId : "+aivId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.UPDATE_INSTANCE_STATE));
			
			pstmt.setString(Constants.ONE, null);
			pstmt.setLong(Constants.TWO, aivId);
			
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceLinkedToRepresentation || " + PropertyFileReader.getInstance().getValue(Constants.UPDATE_INSTANCE_STATE));
			}
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.UNABLE_TO_UPDATE_ASSET_INSTANCE_VERSION));
		} catch (IOException e) {
			log.error("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetInstanceLinkedToRepresentation || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("deleteAssetInstanceLinkedToRepresentation || End");
		}
	}
	
	
	public Workflow retWorkflowByAivId(Long aivId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("retWorkflowByAivId || Begin with aivId : "+aivId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Workflow workflow = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("retWorkflowByAivId || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.RET_WORKFLOW_BY_AIV_ID));
			
			pstmt.setLong(Constants.ONE, aivId);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				workflow = new Workflow();
				workflow.setWorkflowId(rs.getLong("workflow_id"));
				workflow.setWorkflowName(rs.getString("workflow_name"));
				workflow.setJsonStructure(rs.getString("json_structure"));
				//workflow.setAivId(rs.getLong("asset_instance_version_id"));
				workflow.setCurrentStatus(rs.getLong("current_status"));
				
				if(log.isTraceEnabled()) {
					log.trace("retWorkflowByAivId || "+workflow.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("retWorkflowByAivId || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_NOT_FOUND));
		} catch (IOException e) {
			log.error("retWorkflowByAivId || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retWorkflowByAivId || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retWorkflowByAivId || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retWorkflowByAivId || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("retWorkflowByAivId || End");
		}
		return workflow;
	}
	
	
	public void deleteWorkflowLink(Long workflowId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("deleteWorkflowLink || Begin with workflowId : "+workflowId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteWorkflowLink || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			//deleting all the assets linked to a workflow
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_WORKFLOW_LINK));
			pstmt.setLong(Constants.ONE, workflowId);
			
			if (log.isTraceEnabled()) {
				log.trace("deleteWorkflowLink || " + PropertyFileReader.getInstance().getValue(Constants.DELETE_WORKFLOW_LINK));
			}
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("deleteWorkflowLink || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_LINK_NOT_DELETED));
		} catch (IOException e) {
			log.error("deleteWorkflowLink || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteWorkflowLink || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteWorkflowLink || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteWorkflowLink || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
	}
	
	
	public Workflow retWorkflowAssignedToAsset(Long assetId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("retWorkflowAssignedToAsset || Begin with assetId : "+assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Workflow workflow = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("retWorkflowAssignedToAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_WORKFLOW_ASSIGNED_TO_ASSET));
			
			pstmt.setLong(Constants.ONE, assetId);
			
			if (log.isTraceEnabled()) {
				log.trace("retWorkflowAssignedToAsset || " + PropertyFileReader.getInstance().getValue(
						Constants.GET_WORKFLOW_ASSIGNED_TO_ASSET));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				workflow = new Workflow();
				//workflow.setAssetId(rs.getLong("asset_id"));
				workflow.setWorkflowId(rs.getLong("workflow_id"));
				
				if(log.isTraceEnabled()) {
					log.trace("retWorkflowAssignedToAsset || "+workflow.toString());
				}
			}
			
		} catch (SQLException e) {
			log.error("retWorkflowAssignedToAsset || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.WORKFLOW_NOT_FOUND));
		} catch (IOException e) {
			log.error("retWorkflowAssignedToAsset || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("retWorkflowAssignedToAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("retWorkflowAssignedToAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retWorkflowAssignedToAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("retWorkflowAssignedToAsset || End");
		}
		return workflow;
	}
	
	
	public void deleteAssetLinkFromWorkflow(Long assetId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("deleteAssetLinkFromWorkflow || Begin with assetId : "+assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetLinkFromWorkflow || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.DELETE_WORKFLOW_LINK_FROM_ASSET));
			
			pstmt.setString(Constants.ONE, null);
			pstmt.setLong(Constants.TWO, assetId);
			
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetLinkFromWorkflow || " + PropertyFileReader.getInstance().getValue(
						Constants.DELETE_WORKFLOW_LINK_FROM_ASSET));
			}
			
			pstmt.executeUpdate();
			
		} catch (SQLException e) {
			log.error("deleteAssetLinkFromWorkflow || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.UNABLE_TO_UPDATE_ASSET_INSTANCE_VERSION));
		} catch (IOException e) {
			log.error("deleteAssetLinkFromWorkflow || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("deleteAssetLinkFromWorkflow || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("deleteAssetLinkFromWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("deleteAssetLinkFromWorkflow || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("deleteAssetLinkFromWorkflow || End");
		}
	}
	
	
	public Map<Long, String> getAllAssetsWithWorkflowEnabled(Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()){
			log.trace("getAllAssetsWithWorkflowEnabled || Begin");
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetDef assetDef = null;
		
		Map<Long, String> assetList = new HashMap<>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsWithWorkflowEnabled || " + Constants.LOG_CONNECTION_OPEN);
			}

			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}


			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.GET_ALL_ASSETS_WITH_WORKFLOW));

			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsWithWorkflowEnabled || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_ALL_ASSETS_WITH_WORKFLOW));
			}

			rs = pstmt.executeQuery();
			while(rs.next()){
				assetDef = new AssetDef();
				assetDef.setAssetId(rs.getLong("asset_id"));
				assetDef.setAssetName(rs.getString("asset_name"));
				
				assetList.put(rs.getLong("asset_id"), rs.getString("asset_name"));

				if (log.isTraceEnabled()) {
					log.trace("getAllAssetsWithWorkflowEnabled || "+ assetDef.toString());
				}
			}
			if (log.isDebugEnabled()) {
				log.debug("getAllAssetsWithWorkflowEnabled || "+ assetList.toString());
			}


		} catch (SQLException e) {
			log.error("getAllAssetsWithWorkflowEnabled || " + Constants.LOG_UPDATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSETS_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAllAssetsWithWorkflowEnabled || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllAssetsWithWorkflowEnabled || "+ Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllAssetsWithWorkflowEnabled || " + Constants.LOG_EXCEPTION+ e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllAssetsWithWorkflowEnabled || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return assetList;
	}
	
	
	public boolean retIfWorkflowStateIsUpdated(Long assetId, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("retIfWorkflowStateIsUpdated || Begin with assetId : "+ assetId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		boolean flagIfStateUpdated = false;

		try {
			if (log.isTraceEnabled()) {
				log.trace("retIfWorkflowStateIsUpdated || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_STATES_ASSIGNED_FOR_ASSET));

			pstmt.setLong(Constants.ONE, assetId);

			if (log.isTraceEnabled()) {
				log.trace("retIfWorkflowStateIsUpdated || "+PropertyFileReader.getInstance().
						getValue(Constants.GET_STATES_ASSIGNED_FOR_ASSET));
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				flagIfStateUpdated = true;
			}


		} catch (SQLException e) {
			log.error("retIfWorkflowStateIsUpdated || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("retIfWorkflowStateIsUpdated || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("retIfWorkflowStateIsUpdated || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("retIfWorkflowStateIsUpdated || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("retIfWorkflowStateIsUpdated || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("retIfWorkflowStateIsUpdated || End");
		}
		return flagIfStateUpdated;
	}
	
	
	public List<String> getAllStatesOfWorkflow(Long assetId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getAllStatesOfWorkflow || Begin with assetId : "+assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		String jsonStructure = "";
		List<String> workFlowNames = new ArrayList<String>();
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getAllStatesOfWorkflow || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_STATES_BY_ASSET));
			
			pstmt.setLong(Constants.ONE, assetId);
			
			if (log.isTraceEnabled()) {
				log.trace("getAllStatesOfWorkflow || " + PropertyFileReader.getInstance()
							.getValue(Constants.GET_ALL_STATES_BY_ASSET));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				jsonStructure = rs.getString("json_structure");
				JSONObject jsonObject = new JSONObject(jsonStructure);
				for(int i=0;i<jsonObject.length();i++) {
					JSONObject object = new JSONObject(jsonObject.get(Integer.toString(i)).toString());
					workFlowNames.add(object.getString("instanceState"));
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getAllStatesOfWorkflow || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.NO_STATES_TO_DISPLAY));
		} catch (IOException e) {
			log.error("getAllStatesOfWorkflow || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getAllStatesOfWorkflow || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getAllStatesOfWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAllStatesOfWorkflow || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return workFlowNames;
	}
	
	
	public Long getStateIdByStateName(String jsonStructure, String stateName, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getStateIdByStateName || Begin with jsonStructure : "+jsonStructure+"\t stateName : "+stateName);
		}
		
		Long stateId = null;
		
		try {
			JSONObject jsonObject = new JSONObject(jsonStructure);
			
			Iterator itr = jsonObject.keys();
			while(itr.hasNext()) {
				String id = itr.next().toString();
				String string = jsonObject.get(id).toString();
				
				String instanceState = new JSONObject(string).getString("instanceState");
				if(instanceState.equalsIgnoreCase(stateName)) {
					stateId = Long.parseLong(id);
				}
			}
						
		}catch (Exception e) {
			log.error("getStateIdByStateName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getStateIdByStateName || " + Constants.LOG_CONNECTION_CLOSE);
			}
		}
		return stateId;
	}
	
	
	public Workflow getWorkflowDetailsForAsset(Long assetId, Connection conn) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getWorkflowDetailsForAsset || Begin with assetId : "+assetId);
		}
		
		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Workflow workflow = null;
		
		try {
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowDetailsForAsset || " + Constants.LOG_CONNECTION_OPEN);
			}
			if (conn == null) {
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}
			
			pstmt = conn.prepareStatement(PropertyFileReader.getInstance().getValue(Constants.GET_ALL_STATES_BY_ASSET));
			
			pstmt.setLong(Constants.ONE, assetId);
			
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowDetailsForAsset || " + PropertyFileReader.getInstance()
							.getValue(Constants.GET_ALL_STATES_BY_ASSET));
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				workflow = new Workflow();
				workflow.setWorkflowId(rs.getLong("workflow_id"));
				workflow.setWorkflowName(rs.getString("workflow_name"));
				workflow.setJsonStructure(rs.getString("json_structure"));
				if(log.isTraceEnabled()) {
					log.trace("getWorkflowDetailsForAsset || "+workflow.toString());
				}
			}
			
			
		} catch (SQLException e) {
			log.error("getWorkflowDetailsForAsset || " + Constants.LOG_CREATE_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.NO_STATES_TO_DISPLAY));
		} catch (IOException e) {
			log.error("getWorkflowDetailsForAsset || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.IO_OPERATION_FAILED));
		} catch (PropertyVetoException e) {
			log.error("getWorkflowDetailsForAsset || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.INVALID_INPUT_FOR_PROPERTY_FILE));
		} catch (Exception e) {
			log.error("getWorkflowDetailsForAsset || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} finally {
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowDetailsForAsset || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		return workflow;
	}
	
	
	public List<AssetInstance> getAssetInstancesByState(Long aivId, Long stateId, String operator, Connection conn) throws RepoproException {

		if(log.isTraceEnabled()){
			log.trace("getAssetInstancesByState || Begin with aivId : "+ aivId+"\t stateId : "+stateId);
		}

		Connection conn1 = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		AssetInstance ai = null;
		List<AssetInstance> assetInstanceList = new ArrayList<AssetInstance>();

		try {
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancesByState || "+ Constants.LOG_CONNECTION_OPEN);
			}

			if(conn == null){
				conn1 = DBConnection.getInstance().getConnection();
				conn = conn1;
			}

			pstmt = conn.prepareStatement(PropertyFileReader
					.getInstance().getValue(Constants.RET_ASSET_INST_VERSION_BY_ASSET_VERSION_ID)+" and current_status"+operator+stateId);

			pstmt.setLong(Constants.ONE, aivId);
			//pstmt.setLong(Constants.TWO, stateId);

			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancesByState || "+PropertyFileReader.getInstance().
						getValue(Constants.RET_ASSET_INST_VERSION_BY_ASSET_VERSION_ID)+" and current_status"+operator+stateId);
			}

			rs = pstmt.executeQuery();

			while(rs.next()){
				ai = new AssetInstance();
				ai.setAssetInstVersionId(rs.getLong("asset_instance_version_id"));

				assetInstanceList.add(ai);

				if(log.isTraceEnabled()){
					log.trace("getAssetInstancesByState || "+ ai.toString());
				}
			}
			if(log.isDebugEnabled()){
				log.debug("getAssetInstancesByState || "+ assetInstanceList.toString());
			}
			
		} catch (SQLException e) {
			log.error("getAssetInstancesByState || " + Constants.LOG_GET_SQLEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(MessageUtil.getMessage(Constants.ASSET_INSTANCES_NOT_FOUND));
		} catch (IOException e) {
			log.error("getAssetInstancesByState || " + Constants.LOG_IOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		} catch (PropertyVetoException e) {
			log.error("getAssetInstancesByState || " + Constants.LOG_PROPERTYVETOEXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}catch (Exception e) {
			log.error("getAssetInstancesByState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			throw new RepoproException(e.getMessage());
		}finally{
			DBConnection.closeResultSet(rs);
			DBConnection.closePreparedStatement(pstmt);
			if (log.isTraceEnabled()) {
				log.trace("getAssetInstancesByState || " + Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn1);
		}
		if(log.isTraceEnabled()){
			log.trace("getAssetInstancesByState || End");
		}
		return assetInstanceList;
	}
	
}
