package com.thbs.repopro.workflow;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thbs.repopro.assetinstance.AssetInstanceDao;
import com.thbs.repopro.dto.AssetInstance;
import com.thbs.repopro.dto.InstanceStatus;
import com.thbs.repopro.dto.Workflow;
import com.thbs.repopro.exception.RepoproException;
import com.thbs.repopro.util.Constants;
import com.thbs.repopro.util.DBConnection;
import com.thbs.repopro.util.MyModel;

@Path("/workflow")
@Produces({ MediaType.APPLICATION_JSON })
@Consumes({ MediaType.APPLICATION_JSON })
public class WorkflowManager {
	
	private final static Logger log	= LoggerFactory.getLogger("timeBased" );
	
	
	@GET
	@Path("/getAllWorkflows")
	public Response getAllWorkflows() throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("getAllWorkflows || Begin");
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		List<Workflow> workflowList = new ArrayList<Workflow>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			WorkflowDao workflowDao = new WorkflowDao();
			workflowList = workflowDao.getAllWorkflows(conn);
			
			retStat = Status.OK;
			retMsg = Constants.GET_ALL_WORKFLOWS;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
			
		} catch(RepoproException e){
			log.error("getAllWorkflows || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getAllWorkflows || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getAllWorkflows || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("getAllWorkflows || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(workflowList))).build();
	}
	
	
	/*@POST
	@Path("/addWorkflow")
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response addWorkflow(@FormDataParam ("workflowJson") String workflowJson) {
		
		if(log.isTraceEnabled()) {
			log.trace("addWorkflow || Begin" + workflowJson.toString());
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		String workflowName = "";
		
		Connection conn = null;
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			String jsonData = workflowJson;
			JSONObject jsonObj = new JSONObject(jsonData);
			
			workflowName = (String) jsonObj.get("workflowName");
			String assetIds = jsonObj.get("assetIds").toString();
			JSONArray assetIdsArray = new JSONArray(assetIds); 
			String json = jsonObj.get("json").toString();
			JSONArray jsonStructureArray = new JSONArray(json);
			
			Workflow workflow = new Workflow();
			workflow.setWorkflowName(workflowName);
			workflow.setJsonStructure(json);
			
			WorkflowDao workflowDao = new WorkflowDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			
			Workflow workflow2 = workflowDao.getWorkflowByName(workflowName, conn);
			if(workflow2 != null) {
				retStat = Status.OK;
				retMsg = Constants.WORKFLOW_NAME_ALREADY_EXISTS;
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			}else {
				workflowDao.addWorkflow(workflow, conn);
				for(int i=0;i<assetIdsArray.length();i++) {
					workflowDao.addWorkflowLink(assetIdsArray.getLong(i), workflow.getWorkflowId(), conn);
					
					//get all instances of the asset to update the initial status
					List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(assetIdsArray.getLong(i), conn);
					Long firstState = assetInstanceDao.retFirstState(json);
					for(AssetInstance ai : instancesList) {
						assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
					}
				}
				
				conn.commit();
				
				retMsg = Constants.WORKFLOW_ADDED_SUCCESSFULLY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;
			}
			
		} catch(RepoproException e){
			log.error("addWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} catch(Exception e){
			log.error("addWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("addWorkflow || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("addWorkflow || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	}*/
	
	
	@GET
	@Path("/getWorkflowByName")
	public Response getWorkflowByName(@QueryParam("workflowId") String workflowName) {
		
		if(log.isTraceEnabled()) {
			log.trace("getWorkflowByName || Begin with workflowName : "+workflowName);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		Workflow workflow = null;
		List<Workflow> workflowList = new ArrayList<Workflow>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			WorkflowDao workflowDao = new WorkflowDao();
			workflow = workflowDao.getWorkflowByName(workflowName, conn);
			
			workflowList.add(workflow);
			
			retStat = Status.OK;
			retMsg = Constants.GET_WORKFLOW_BY_NAME;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			
		} catch(RepoproException e){
			log.error("getWorkflowByName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("getWorkflowByName || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("getWorkflowByName || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("getWorkflowByName || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(workflowList))).build();
	}
	
	
	@DELETE
	@Path("/deleteWorkflow")
	public Response deleteWorkflow(@QueryParam("workflowId") Long workflowId) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("deleteWorkflow || Begin with workflowId : "+workflowId);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			WorkflowDao workflowDao = new WorkflowDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			
			List<Long> assetIdsList = workflowDao.getAssetsLinkedToWorkflow(workflowId, conn);
			for(Long assetId : assetIdsList) {
				workflowDao.deleteAssetLinkFromWorkflow(assetId, conn);
				List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(assetId, conn);
				for(AssetInstance ai : instancesList) {
					workflowDao.deleteAssetInstanceLinkFromWorkflow(ai.getAssetInstVersionId(), conn);
				}
			}
			
			boolean status = workflowDao.deleteWorkflow(workflowId, conn);
			
			if(status) {
				conn.commit();
				retStat = Status.OK;
				retMsg = Constants.WORKFLOW_DELETED_SUCCESSFULLY;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			}else {
				retStat = Status.OK;
				retMsg = Constants.WORKFLOW_NOT_DELETED;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.DELETE_STATUS_SUCCESS;
			}
			
		} catch(RepoproException e){
			log.error("deleteWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} catch(Exception e){
			log.error("deleteWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.DELETE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("deleteWorkflow || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("deleteWorkflow || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	}
	
	
	/*@PUT
	@Path("/updateWorkflow")
	@Consumes({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	@Produces({MediaType.APPLICATION_JSON, MediaType.MULTIPART_FORM_DATA})
	public Response updateWorkflow(@FormDataParam ("workflowJson") String workflowJson) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("updateWorkflow || Begin : "+workflowJson.toString());
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		String workflowId;
		String workflowName = "";
		Long[] assetIds = new Long[] {};
		String jsonStructure = "";
		
		Connection conn = null;
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			String jsonData = workflowJson;
			JSONObject jsonObj = new JSONObject(jsonData);
			
			workflowId = (String) jsonObj.get("workflowId");
			workflowName = (String) jsonObj.get("workflowName");
			assetIds = (Long[]) jsonObj.get("assetIds");
			jsonStructure =  (String) jsonObj.get("json");
			
			workflowId = jsonObj.get("workflowId").toString();
			workflowName = (String) jsonObj.get("workflowName");
			String assetId = jsonObj.get("assetIds").toString();
			JSONArray assetIdsArray = new JSONArray(assetId); 
			String json = jsonObj.get("json").toString();
			JSONArray jsonStructureArray = new JSONArray(json);
			
			Workflow workflow = new Workflow();
			workflow.setWorkflowId(Long.parseLong(workflowId));
			workflow.setWorkflowName(workflowName);
			workflow.setJsonStructure(json);
			
			WorkflowDao workflowDao = new WorkflowDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			
			Workflow workflowDetailsById = workflowDao.getWorkflowById(workflow.getWorkflowId(), conn);
			if(!workflowDetailsById.getWorkflowName().equalsIgnoreCase(workflowName)) {
				Workflow workflow2 = workflowDao.getWorkflowByName(workflow.getWorkflowName(), conn);
				if(workflow2 != null) {
					retStat = Status.OK;
					retMsg = Constants.WORKFLOW_NAME_ALREADY_EXISTS;
					retScsFlr = Constants.FAILURE;
					retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
				}
			} else {
				workflowDao.updateWorkflow(workflow, conn);
				
				for(int i=0;i<assetIdsArray.length();i++) {
					workflowDao.addWorkflowLink(assetIdsArray.getLong(i), workflow.getWorkflowId(), conn);
					
					//get all instances of the asset to update the initial status
					List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(assetIdsArray.getLong(i), conn);
					Long firstState = assetInstanceDao.retFirstState(json);
					for(AssetInstance ai : instancesList) {
						assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
					}
				}
				
				if(assetIdsArray.length() == 0) {
					List<Long> assetIdsLinkedToAsset = workflowDao.getAssetsLinkedToWorkflow(workflow.getWorkflowId(), conn);
					for(Long ids : assetIdsLinkedToAsset) {
						List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(ids, conn);
						for(AssetInstance ai : instancesList) {
							workflowDao.deleteAssetInstanceLinkFromWorkflow(ai.getAssetInstVersionId(), conn);
						}
					}
					//deleting the link between asset and workflow
					workflowDao.deleteWorkflowLink(workflow.getWorkflowId(), conn);
				}
				
				conn.commit();
				
				retMsg = Constants.WORKFLOW_UPDATED_SUCCESSFULLY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			}
			
		} catch(RepoproException e){
			log.error("updateWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch(Exception e){
			log.error("updateWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateWorkflow || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("updateWorkflow || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	}*/
	
	
	@GET
	@Path("/retNextState")
	public Response retNextState(@QueryParam("aivId") Long aivId) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("retNextState || Begin with aivId : "+aivId);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		List<Workflow> workflowList = new ArrayList<>();
		Map<Long,String> nextStates = new HashMap<Long,String>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			WorkflowDao workflowDao = new WorkflowDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			
			Workflow workflow = workflowDao.retWorkflowByAivId(aivId, conn);
			
			if(workflow != null) {
				Long currentState = workflow.getCurrentStatus();
				String jsonStructure = workflow.getJsonStructure();
				
				nextStates = assetInstanceDao.retrieveNextState(currentState, jsonStructure, conn);
				workflow.setNextStates(nextStates);
				
				workflowList.add(workflow);
				
				retMsg = Constants.STATE_FETCHED_SUCCESSFULLY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else {
				retMsg = Constants.NO_STATES_TO_DISPLAY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			
		} catch(RepoproException e){
			log.error("retNextStatus || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("retNextStatus || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retNextStatus || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("retNextStatus || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(workflowList))).build();
	}
	
	
	@PUT
	@Path("/updateInstanceState")
	public Response updateInstanceState(@QueryParam("aivId") Long aivId, @QueryParam("updatedState") Long updatedState) 
			throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("updateInstanceState || Begin with aivId :"+aivId +"currentState : "+updatedState);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		List<String> nextState = new ArrayList<>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();
			
			assetInstanceDao.updateAssetInstanceState(aivId, updatedState, conn);
						
			conn.commit();
			
			retMsg = Constants.STATE_UPDATED_SUCCESSFULLY;
			retStat = Status.OK;
			retScsFlr = Constants.SUCCESS;
			retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			
		} catch(RepoproException e){
			log.error("updateInstanceState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch(Exception e){
			log.error("updateInstanceState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("updateInstanceState || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("updateInstanceState || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(nextState))).build();
	}
	
	
	@GET
	@Path("/retFirstState")
	public Response retFirstState(@QueryParam("aivId") Long aivId) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("retFirstState || Begin with aivId : "+aivId);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		String instanceState = "";
		
		List<Workflow> workflowList = new ArrayList<>();
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);
			
			WorkflowDao workflowDao = new WorkflowDao();
			
			Workflow workflow = workflowDao.retWorkflowByAivId(aivId, conn);
			
			if(workflow != null) {
				Long currentState = workflow.getCurrentStatus();
				String jsonStructure = workflow.getJsonStructure();
				
				//Long state = assetInstanceDao.retFirstStateOnLoad(currentState, jsonStructure);
				
				JSONObject jsonObject = new JSONObject(jsonStructure);
				//for(int i=0;i<jsonArray.length();i++) {
					String setOfElementDetails = jsonObject.get(currentState.toString()).toString();
					JSONObject elementDetailsObject = new JSONObject(setOfElementDetails);

					//for(int j=0; j<elementDetailsArray.length(); j++){
						//JSONObject elementDetailsJsonObj = elementDetailsObject.getJSONObject(j);
						instanceState = elementDetailsObject.getString("instanceState");
					//}
				//}
				
				Map<Long,String> nextState = new HashMap<Long,String>();
				nextState.put(currentState, instanceState);
				
				workflow.setNextStates(nextState);
				
				workflowList.add(workflow);
				
				retMsg = Constants.STATE_FETCHED_SUCCESSFULLY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}else {
				retMsg = Constants.NO_STATES_TO_DISPLAY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.GET_STATUS_SUCCESS;
			}
			
		} catch(RepoproException e){
			log.error("retFirstState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} catch(Exception e){
			log.error("retFirstState || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.GET_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("retFirstState || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("retFirstState || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg, new ArrayList<Object>(workflowList))).build();
		
	}
	
	
	@PUT
	@Path("/saveWorkflow")
	public Response saveWorkflow(List<Workflow> workflows) throws RepoproException{
		
		if(log.isTraceEnabled()) {
			log.trace("saveWorkflow || Begin with workflows : " + workflows);
		}
		
		Status retStat = Status.OK;
		String retMsg = null;
		String retScsFlr = null;
		int retStatScsFlr = 0;
		
		Connection conn = null;
		
		String workflowId = "";
		String workflowName = "";
		Long[] assetIdsArray;
		Map<String, InstanceStatus> json;
		
		try {
			conn = DBConnection.getInstance().getConnection();
			conn.setAutoCommit(false);

			/*JSONArray workflowJsonArray = new JSONArray(workflowJsonData);*/

			WorkflowDao workflowDao = new WorkflowDao();
			AssetInstanceDao assetInstanceDao = new AssetInstanceDao();

			boolean duplicateFlag = false;

			for(int i=0;i<workflows.size();i++) {
				Workflow workflow = workflows.get(i);

				if(workflow.getWorkflowId() != null) {
					workflowId = workflow.getWorkflowId().toString();
				}else {
					workflowId = "";
				}

				workflowName = workflow.getWorkflowName();
				assetIdsArray = workflow.getSelectedAssets();
				json = workflow.getStatus();
				
				List<Long> selectedAssetIdsList = new ArrayList<Long>(Arrays.asList(assetIdsArray));
				List<Long> selectedAssetIdsListCopy = new ArrayList<Long>(Arrays.asList(assetIdsArray));

				if(workflowId.isEmpty()) {
					Workflow addWorkflow = new Workflow();
					addWorkflow.setWorkflowName(workflowName);
					addWorkflow.setJsonStructure(workflow.statusToJsonObject().toString());

					Workflow workflow2 = workflowDao.getWorkflowByName(workflowName, conn);
					if(workflow2 != null) {
						duplicateFlag = true;
						retStat = Status.OK;
						retMsg = Constants.WORKFLOW_NAME_ALREADY_EXISTS;
						retScsFlr = Constants.FAILURE;
						retStatScsFlr = Constants.INSERT_STATUS_SUCCESS;break;
					}//else {
					workflowDao.addWorkflow(addWorkflow, conn);
					for(int j=0;j<assetIdsArray.length;j++) {
						workflowDao.addWorkflowLink(assetIdsArray[j], addWorkflow.getWorkflowId(), conn);

						//get all instances of the asset to update the initial status
						List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(assetIdsArray[j], conn);
						Long firstState = assetInstanceDao.retFirstState(json);
						for(AssetInstance ai : instancesList) {
							assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
						}
					}
					//}
				}else {
					Workflow updateWorkflow = new Workflow();
					updateWorkflow.setWorkflowId(Long.parseLong(workflowId));
					updateWorkflow.setWorkflowName(workflowName);
					updateWorkflow.setJsonStructure(workflow.statusToJsonObject().toString());

					Workflow workflowDetailsById = workflowDao.getWorkflowById(updateWorkflow.getWorkflowId(), conn);
					if(!workflowDetailsById.getWorkflowName().equalsIgnoreCase(workflowName)) {
						Workflow workflow2 = workflowDao.getWorkflowByName(updateWorkflow.getWorkflowName(), conn);
						if(workflow2 != null) {
							duplicateFlag = true;
							retStat = Status.OK;
							retMsg = Constants.WORKFLOW_NAME_ALREADY_EXISTS;
							retScsFlr = Constants.FAILURE;
							retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;break;
						}
					} //else {
					workflowDao.updateWorkflow(updateWorkflow, conn);
					
					if(assetIdsArray.length == 0) {
						List<Long> assetIdsLinkedToAsset = workflowDao.getAssetsLinkedToWorkflow(updateWorkflow.getWorkflowId(), conn);
						for(Long ids : assetIdsLinkedToAsset) {
							workflowDao.deleteAssetLinkFromWorkflow(ids, conn);
							List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(ids, conn);
							for(AssetInstance ai : instancesList) {
								workflowDao.deleteAssetInstanceLinkFromWorkflow(ai.getAssetInstVersionId(), conn);
							}
						}
					}
					
					if(assetIdsArray.length != 0) {
						List<Long> assetIdsList = workflowDao.getAssetsLinkedToWorkflow(updateWorkflow.getWorkflowId(), conn);
						List<Long> dbAssetIdsList = new ArrayList<Long>(assetIdsList);
						List<Long> dbAssetIdsListCopy = new ArrayList<Long>(assetIdsList);
						
						selectedAssetIdsList.removeAll(dbAssetIdsList);
						dbAssetIdsListCopy.removeAll(selectedAssetIdsListCopy);
						
						for(Long assetId : dbAssetIdsListCopy) {
							workflowDao.deleteAssetLinkFromWorkflow(assetId, conn);
							List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(assetId, conn);
							for(AssetInstance ai : instancesList) {
								workflowDao.deleteAssetInstanceLinkFromWorkflow(ai.getAssetInstVersionId(), conn);
							}
						}
						
						for(int k=0;k<selectedAssetIdsList.size();k++) {
							workflowDao.addWorkflowLink(selectedAssetIdsList.get(k), updateWorkflow.getWorkflowId(), conn);
							
							//get all instances of the asset to update the initial status
							/*List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(selectedAssetIdsList.get(k), conn);
							Long firstState = assetInstanceDao.retFirstState(json);
							for(AssetInstance ai : instancesList) {
								assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
							}*/
							assetInstanceDao.updateAssetInstanceStateToInitialState(selectedAssetIdsList.get(k), json, conn);
						}
						
						Collections.sort(assetIdsList);
						Collections.sort(selectedAssetIdsListCopy);
						JSONObject json1 = new JSONObject(workflowDetailsById.getJsonStructure());
						if(assetIdsList.equals(selectedAssetIdsListCopy) && json1.length() != (json.keySet().size())) {
							for(Long assetIds : selectedAssetIdsListCopy) {
								/*List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(assetIds, conn);
								Long firstState = assetInstanceDao.retFirstState(json);
								for(AssetInstance ai : instancesList) {
									assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
								}*/
								assetInstanceDao.updateAssetInstanceStateToInitialState(assetIds, json, conn);
							}
						}
						
						if(!assetIdsList.equals(selectedAssetIdsListCopy) && json1.length() != (json.keySet().size())) {
							for(Long assetIds : selectedAssetIdsListCopy) {
								/*List<AssetInstance> instancesList = assetInstanceDao.getAllAssetInstancesForAsset(assetIds, conn);
								Long firstState = assetInstanceDao.retFirstState(json);
								for(AssetInstance ai : instancesList) {
									assetInstanceDao.updateAssetInstanceState(ai.getAssetInstVersionId(),firstState,conn);
								}*/
								assetInstanceDao.updateAssetInstanceStateToInitialState(assetIds, json, conn);
							}
						}
					}
					//}
				}
			}
			
			if(duplicateFlag) {
				retStat = Status.OK;
				retMsg = Constants.WORKFLOW_NAME_ALREADY_EXISTS;
				retScsFlr = Constants.FAILURE;
				retStatScsFlr = Constants.INSERT_STATUS_FAILURE;
			}else {
				conn.commit();

				retMsg = Constants.WORKFLOW_UPDATED_SUCCESSFULLY;
				retStat = Status.OK;
				retScsFlr = Constants.SUCCESS;
				retStatScsFlr = Constants.UPDATE_STATUS_SUCCESS;
			}

		} catch(RepoproException e){
			log.error("saveWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} catch(Exception e){
			log.error("saveWorkflow || " + Constants.LOG_EXCEPTION + e.getMessage());
			e.printStackTrace();
			retStat = Status.INTERNAL_SERVER_ERROR;
			retMsg = e.getMessage();
			retScsFlr = Constants.FAILURE;
			retStatScsFlr = Constants.UPDATE_STATUS_FAILURE;
		} finally {
			if (log.isTraceEnabled()) {
				log.trace("saveWorkflow || "+ Constants.LOG_CONNECTION_CLOSE);
			}
			DBConnection.closeDbConnection(conn);
		}
		if(log.isTraceEnabled()) {
			log.trace("saveWorkflow || End");
		}
		return Response.status(retStat)
				.entity(new MyModel(retStatScsFlr,retScsFlr, retMsg)).build();
	}
}
